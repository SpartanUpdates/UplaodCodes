package com.example.lyricsvideo.Adapter;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.activity.SelectImageActivity;
import com.example.lyricsvideo.Interface.OnItemClickListner;
import com.example.lyricsvideo.Model.ImageInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.application.App;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import de.hdodenhof.circleimageview.CircleImageView;


public class ImageAlbumAdapter extends RecyclerView.Adapter<ImageAlbumAdapter.Holder> {
    private App application;
    private ArrayList<String> FolderList;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> itemClickListner;
    private RequestManager glidemanager;
    private SelectImageActivity activity;


    public ImageAlbumAdapter(final Context activity) {
        this.glidemanager = Glide.with(activity);
        this.application = App.getInstance();
        this.FolderList = new ArrayList<>(this.application.getAllAlbumList().keySet());
        this.activity = (SelectImageActivity) activity;
        Collections.sort(this.FolderList, new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return s1.compareToIgnoreCase(s2);
            }
        });
        if (FolderList.size() != 0) {
            this.application.setSelectedFolderId(this.FolderList.get(0));
        } else {
            Toast.makeText(application, "No Image Album Found In Your Phone Please Add Some Image First", Toast.LENGTH_SHORT).show();
        }
        this.inflater = LayoutInflater.from(activity);
    }


    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }

    public int getItemCount() {
        return FolderList == null ? 0 : FolderList.size();
    }

    public String getItem(final int pos) {
        return this.FolderList.get(pos);
    }

    public void onBindViewHolder(@NonNull final Holder holder, final int pos) {
        final String currentFolderId = this.getItem(pos);
        final ImageInfo data = this.application.getImageByAlbum(currentFolderId).get(0);
        holder.tvAlbumName.setSelected(true);

        String imagecount = String.valueOf(application.getImageByAlbum(currentFolderId).size());
        holder.tvAlbumNoofImage.setText(imagecount);
        holder.tvAlbumName.setSelected(true);
        holder.tvAlbumName.setText(data.folderName);
        AppFont.Textfont(activity, holder.tvAlbumName);
        AppFont.Textfont(activity, holder.tvAlbumNoofImage);
        if (currentFolderId.equals(application.getSelectedFolderId())) {
            holder.Ivtransparent.setVisibility(View.GONE);
            holder.tvAlbumNoofImage.setVisibility(View.GONE);
        } else {
            holder.Ivtransparent.setVisibility(View.VISIBLE);
            holder.tvAlbumNoofImage.setVisibility(View.VISIBLE);
        }
        this.glidemanager.load(data.ImagePath).into(holder.IvAlbumthumbline);
        holder.llAlbumSelect.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                ImageAlbumAdapter.this.application.setSelectedFolderId(currentFolderId);
                if (ImageAlbumAdapter.this.itemClickListner != null) {
                    ImageAlbumAdapter.this.itemClickListner.onItemClick(v, data);
                }
                ImageAlbumAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull final ViewGroup parent, final int pos) {
        return new Holder(this.inflater.inflate(R.layout.row_items_by_album, parent, false));
    }

    public class Holder extends RecyclerView.ViewHolder {
        CircleImageView IvAlbumthumbline, Ivtransparent;
        TextView tvAlbumName, tvAlbumNoofImage;
        View parent;
        private LinearLayout llAlbumSelect;

        private Holder(final View v) {
            super(v);
            this.parent = v;
            this.IvAlbumthumbline = v.findViewById(R.id.iv_AlbumThumbline);
            this.Ivtransparent = v.findViewById(R.id.iv_transparant);
            this.tvAlbumName = v.findViewById(R.id.tv_AlbumName);
            this.tvAlbumNoofImage = v.findViewById(R.id.tv_TotalImage);
            this.llAlbumSelect = v.findViewById(R.id.ll_AlbumSelectView);
        }

        public void onItemClick(final View view, final Object item) {
            if (ImageAlbumAdapter.this.itemClickListner != null) {
                ImageAlbumAdapter.this.itemClickListner.onItemClick(view, item);
            }
        }
    }
}
