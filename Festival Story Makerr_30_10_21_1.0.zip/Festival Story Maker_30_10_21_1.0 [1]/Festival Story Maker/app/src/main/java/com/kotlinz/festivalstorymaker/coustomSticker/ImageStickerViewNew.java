package com.kotlinz.festivalstorymaker.coustomSticker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.widget.ScrollView;

import androidx.appcompat.widget.AppCompatImageView;

public class ImageStickerViewNew  extends AppCompatImageView
{
    public float A;
    public float A0;
    public float B;
    public float B0;
    public float C;
    public float C0;
    public float D;
    public boolean D0;
    public float E;
    public float E0;
    public float F;
    public float G;
    public float H;
    public float I;
    public Paint J;
    public Bitmap K;
    public int L;
    public long M;
    public int N;
    public Matrix O;
    public PointF P;
    public float Q;
    public c R;
    public a S;
    public float T;
    public Bitmap U;
    public int V;
    public int W;
    public int a0;
    public int b0;
    public float c0;
    public float d0;
    public int e0;
    public String f0;
    public float g;
    public String g0;
    public float h;
    public b h0;
    public Bitmap i;
    public boolean i0;
    public int j;
    public boolean j0;
    public int k;
    public int k0;
    public DisplayMetrics l;
    public int l0;
    public Rect m;
    public boolean m0;
    public Rect n;
    public float n0;
    public Rect o;
    public float o0;
    public Rect p;
    public boolean p0;
    public Rect q;
    public ScrollView q0;
    public Bitmap r;
    public Paint r0;
    public Bitmap s;
    public Paint s0;
    public double t;
    public float t0;
    public boolean u;
    public float u0;
    public boolean v;
    public float v0;
    public boolean w;
    public float w0;
    public boolean x;
    public float x0;
    public boolean y;
    public float y0;
    public float z;
    public float z0;

    public ImageStickerViewNew(final Context context, final String f0, final float n, final float n2, final float d0, final float c0, final int e0, final boolean p8) {
        super(context);
        this.g = 1.2f;
        this.h = 0.5f;
        this.v = true;
        this.y = false;
        this.L = 0;
        this.M = 0L;
        this.O = new Matrix();
        this.P = new PointF();
        this.T = 0.0f;
        this.c0 = 0.0f;
        this.d0 = 0.3f;
        this.i0 = false;
        this.j0 = false;
        this.m0 = false;
        this.p0 = false;
        this.E0 = 0.0f;
        this.f0 = f0;
        this.H = n;
        this.I = n2;
        this.A = n;
        this.B = n2;
        this.d0 = d0;
        this.c0 = c0;
        this.e0 = e0;
        this.p0 = p8;
        this.r0 = this.i();
        this.s0 = this.i();
        this.d();
    }

    public ImageStickerViewNew(final Context context, final String f0, final float n, final float n2, final float d0, final float c0, final int e0, final boolean p9, final ScrollView q0) {
        super(context);
        this.g = 1.2f;
        this.h = 0.5f;
        this.v = true;
        this.y = false;
        this.L = 0;
        this.M = 0L;
        this.O = new Matrix();
        this.P = new PointF();
        this.T = 0.0f;
        this.c0 = 0.0f;
        this.d0 = 0.3f;
        this.i0 = false;
        this.j0 = false;
        this.m0 = false;
        this.p0 = false;
        this.E0 = 0.0f;
        this.f0 = f0;
        this.H = n;
        this.I = n2;
        this.A = n;
        this.B = n2;
        this.d0 = d0;
        this.q0 = q0;
        this.c0 = c0;
        this.e0 = e0;
        this.p0 = p9;
        this.d();
    }

    public final float c(final MotionEvent motionEvent) {
        return (float)Math.hypot(motionEvent.getX(0) - this.P.x, motionEvent.getY(0) - this.P.y);
    }

    public final void d() {
        this.m = new Rect();
        this.o = new Rect();
        this.n = new Rect();
        this.q = new Rect();
        this.p = new Rect();
        (this.J = new Paint()).setColor(0);
        this.J.setAntiAlias(true);
        this.J.setDither(true);
        this.J.setStyle(Paint.Style.STROKE);
        this.J.setStrokeWidth(1.0f);
        final DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
        this.l = displayMetrics;
        this.N = displayMetrics.widthPixels;
        this.i();
        this.i();
        this.i();
        this.i();
        this.i();
        this.i();
    }

    public final boolean e(final MotionEvent motionEvent, final Rect rect) {
        final int left = rect.left;
        final int right = rect.right;
        final int top = rect.top;
        final int bottom = rect.bottom;
        boolean b2;
        final boolean b = b2 = false;
        if (motionEvent.getX(0) >= left) {
            b2 = b;
            if (motionEvent.getX(0) <= right) {
                b2 = b;
                if (motionEvent.getY(0) >= top) {
                    b2 = b;
                    if (motionEvent.getY(0) <= bottom) {
                        b2 = true;
                    }
                }
            }
        }
        return b2;
    }

    public final boolean f(final MotionEvent motionEvent) {
        final Rect o = this.o;
        final int left = o.left;
        final int top = o.top;
        final int right = o.right;
        final int bottom = o.bottom;
        boolean b2;
        final boolean b = b2 = false;
        if (motionEvent.getX(0) >= left - 20) {
            b2 = b;
            if (motionEvent.getX(0) <= right + 20) {
                b2 = b;
                if (motionEvent.getY(0) >= top - 20) {
                    b2 = b;
                    if (motionEvent.getY(0) <= bottom + 20) {
                        b2 = true;
                    }
                }
            }
        }
        return b2;
    }

    public final void g(final MotionEvent motionEvent) {
        final float[] array = new float[9];
        this.O.getValues(array);
        this.P.set((array[1] * 0.0f + array[0] * 0.0f + array[2] + motionEvent.getX(0)) / 2.0f, (array[4] * 0.0f + array[3] * 0.0f + array[5] + motionEvent.getY(0)) / 2.0f);
    }

    public Bitmap getBitmaps() {
        return this.K;
    }

    public float getHeights() {
        return this.D;
    }

    public float getLastScale() {
        return this.C;
    }

    public float getLayoutLastX() {
        return this.F;
    }

    public float getLayoutLastY() {
        return this.G;
    }

    public float getRotate() {
        return this.c0;
    }

    public float getScale() {
        return this.d0;
    }

    public int getStickerId() {
        return this.e0;
    }

    public String getStickerPath() {
        return this.f0;
    }

    public float getWidths() {
        return this.E;
    }

    public final float h(final MotionEvent motionEvent) {
        final float[] array = new float[9];
        this.O.getValues(array);
        return (float)Math.toDegrees(Math.atan2(motionEvent.getY(0) - (array[4] * 0.0f + array[3] * 0.0f + array[5]), motionEvent.getX(0) - (array[1] * 0.0f + array[0] * 0.0f + array[2])));
    }

    public final Paint i() {
        final Paint paint = new Paint();
        paint.setColor(0);
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.0f);
        paint.setPathEffect((PathEffect)new DashPathEffect(new float[] { 10.0f, 15.0f }, 1.0f));
        return paint;
    }

    public final float j(final MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() == 2) {
            final float n = motionEvent.getX(0) - motionEvent.getX(1);
            final float n2 = motionEvent.getY(0) - motionEvent.getY(1);
            return (float)Math.sqrt(n2 * n2 + n * n);
        }
        return 0.0f;
    }

    public void onDraw(final Canvas canvas) {
        if (this.K == null) {
            return;
        }
        final float[] array = new float[9];
        this.O.getValues(array);
        final float u0 = array[0];
        this.u0 = u0;
        final float v0 = array[1];
        this.v0 = v0;
        this.u0 = v0 * 0.0f + (u0 * 0.0f + array[2]);
        this.v0 = array[4] * 0.0f + array[3] * 0.0f + array[5];
        final float z0 = array[0];
        this.z0 = z0;
        final float n = (float)this.b0;
        this.z0 = array[1] * 0.0f + z0 * n + array[2];
        this.t0 = array[4] * 0.0f + array[3] * n + array[5];
        final float a0 = array[0];
        this.A0 = a0;
        final float w0 = array[1];
        this.w0 = w0;
        final float n2 = (float)this.a0;
        this.A0 = w0 * n2 + a0 * 0.0f + array[2];
        this.w0 = array[4] * n2 + array[3] * 0.0f + array[5];
        this.B0 = array[1] * n2 + array[0] * n + array[2];
        this.C0 = array[4] * n2 + array[3] * n + array[5];
        canvas.save();
        final Rect m = this.m;
        final int k = this.k;
        final float z2 = this.z0;
        final float n3 = (float)(k / 3);
        m.left = (int)(z2 - n3);
        m.right = (int)(n3 + z2);
        final int j = this.j;
        final float t0 = this.t0;
        final float n4 = (float)(j / 3);
        m.top = (int)(t0 - n4);
        m.bottom = (int)(n4 + t0);
        final Rect o = this.o;
        final int w2 = this.W;
        final float b0 = this.B0;
        final float n5 = (float)(w2 / 3);
        o.left = (int)(b0 - n5);
        o.right = (int)(n5 + b0);
        final int v2 = this.V;
        final float c0 = this.C0;
        final float n6 = (float)(v2 / 3);
        o.top = (int)(c0 - n6);
        o.bottom = (int)(n6 + c0);
        final Rect p = this.p;
        final float u2 = this.u0;
        final float n7 = (float)(k / 3);
        p.left = (int)(u2 - n7);
        p.right = (int)(n7 + u2);
        final float v3 = this.v0;
        final float n8 = (float)(k / 3);
        p.top = (int)(v3 - n8);
        p.bottom = (int)(v3 + n8);
        final Rect n9 = this.n;
        final float a2 = this.A0;
        n9.left = (int)(a2 - n8);
        n9.right = (int)(n8 + a2);
        final float w3 = this.w0;
        n9.top = (int)(w3 - n8);
        n9.bottom = (int)(w3 + n8);
        final Rect q = this.q;
        q.left = (m.left - p.left) / 2 + (int)(a2 - n8);
        q.right = (m.left - p.left) / 2 + (int)(a2 + n8);
        q.top = (int)(w3 - n8) + 150;
        q.bottom = (int)(w3 + n8) + 150;
        if (this.u) {
            canvas.setMatrix(this.O);
            final long uptimeMillis = SystemClock.uptimeMillis();
            if (this.M == 0L) {
                this.M = uptimeMillis;
            }
            throw null;
        }
        canvas.drawBitmap(this.K, this.O, (Paint)null);
        if (this.v) {
            canvas.drawLine(this.u0, this.v0, this.z0, this.t0, this.J);
            canvas.drawLine(this.z0, this.t0, this.B0, this.C0, this.J);
            canvas.drawLine(this.A0, this.w0, this.B0, this.C0, this.J);
            canvas.drawLine(this.A0, this.w0, this.u0, this.v0, this.J);
            this.E = (float)(this.o.centerX() - this.n.centerX());
            this.D = (float)(this.o.centerY() - this.m.centerY());
            this.F = (float)(this.K.getWidth() / 2 + this.p.centerX());
            this.G = (float)(this.K.getHeight() / 2 + this.p.centerY());
            if (this.i0 || this.j0) {
                final float u3 = this.u0;
                this.y0 = (this.z0 - u3) / 2.0f + u3;
                final float v4 = this.v0;
                final float x0 = (this.w0 - v4) / 2.0f + v4;
                canvas.drawLine(u3 - 3000.0f, this.x0 = x0, u3 + 3000.0f, x0, this.r0);
                final float y0 = this.y0;
                final float v5 = this.v0;
                canvas.drawLine(y0, v5 - 3000.0f, y0, v5 + 3000.0f, this.s0);
            }
            if (!this.m0) {
                canvas.drawBitmap(this.i, (Rect)null, this.p, (Paint)null);
            }
            canvas.drawBitmap(this.U, (Rect)null, this.o, (Paint)null);
            if (!this.j0) {
                canvas.drawBitmap(this.s, (Rect)null, this.q, (Paint)null);
            }
            this.R.c(Boolean.TRUE);
            this.D0 = true;
        }
        else {
            this.R.c(Boolean.FALSE);
            if (this.p0) {
                final b h0 = this.h0;
                if (h0 != null && this.D0) {
                    this.D0 = false;
                    h0.t(this.F, this.G, this.K, this.g0);
                }
            }
        }
        canvas.restore();
    }

    public boolean onTouchEvent(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        boolean b2 = false;
        Label_1844: {
            Label_1033: {
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked == 2) {
                            final boolean y = this.y;
                            final float n = 1.0f;
                            float n4;
                            if (y) {
                                final float j = this.j(motionEvent);
                                float n2;
                                if (j != 0.0f && j >= 20.0f) {
                                    n2 = (j / this.Q - 1.0f) * 0.09f + 1.0f;
                                }
                                else {
                                    n2 = 1.0f;
                                }
                                final float n3 = Math.abs(this.n.left - this.o.left) * n2 / this.T;
                                float c = 0.0f;
                                Label_0178: {
                                    if (n3 <= this.h) {
                                        c = n;
                                        if (n2 < 1.0f) {
                                            break Label_0178;
                                        }
                                    }
                                    if (n3 >= this.g) {
                                        c = n;
                                        if (n2 > 1.0f) {
                                            break Label_0178;
                                        }
                                    }
                                    this.z = this.c(motionEvent);
                                    c = n2;
                                }
                                this.C = c;
                                n4 = c;
                                if (this.j0) {
                                    final Matrix o = this.O;
                                    final float h = this.h(motionEvent);
                                    final float e0 = this.E0;
                                    final PointF p = this.P;
                                    o.postRotate((h - e0) * 2.0f, p.x, p.y);
                                    this.E0 = this.h(motionEvent);
                                    n4 = c;
                                }
                            }
                            else if (this.w) {
                                if (this.j0) {
                                    final Matrix o2 = this.O;
                                    final float h2 = this.h(motionEvent);
                                    final float e2 = this.E0;
                                    final PointF p2 = this.P;
                                    o2.postRotate((h2 - e2) * 2.0f, p2.x, p2.y);
                                    this.E0 = this.h(motionEvent);
                                }
                                float c2 = this.c(motionEvent) / this.z;
                                final double n5 = this.c(motionEvent);
                                final double t = this.t;
                                Double.isNaN(n5);
                                Label_0473: {
                                    if (n5 / t > this.h || c2 >= 1.0f) {
                                        final double n6 = this.c(motionEvent);
                                        final double t2 = this.t;
                                        Double.isNaN(n6);
                                        if (n6 / t2 < this.g || c2 <= 1.0f) {
                                            this.z = this.c(motionEvent);
                                            break Label_0473;
                                        }
                                    }
                                    c2 = n;
                                    if (!this.f(motionEvent)) {
                                        this.w = false;
                                        c2 = n;
                                    }
                                }
                                this.C = c2;
                                n4 = c2;
                            }
                            else {
                                if (!this.x) {
                                    break Label_1033;
                                }
                                final float x = motionEvent.getX(0);
                                final float y2 = motionEvent.getY(0);
                                if (this.m0) {
                                    if (this.p.centerX() < 0 && x - this.A < 0.0f) {
                                        return false;
                                    }
                                    if (this.p.centerY() < 0 && y2 - this.B < 0.0f) {
                                        return false;
                                    }
                                    if (this.m.centerX() > this.o0 && x - this.A > 0.0f) {
                                        return false;
                                    }
                                    if (this.o.centerY() > this.n0 && y2 - this.B > 0.0f) {
                                        return false;
                                    }
                                }
                                this.O.postTranslate(x - this.A, y2 - this.B);
                                this.A = x;
                                this.B = y2;
                                this.invalidate();
                                if (this.i0) {
                                    final Paint s0 = this.s0;
                                    final int n7 = (int)this.y0;
                                    final int n8 = this.k0 / 2;
                                    final int n9 = -65536;
                                    int color;
                                    if (n7 == n8) {
                                        color = -65536;
                                    }
                                    else {
                                        color = 0;
                                    }
                                    s0.setColor(color);
                                    final Paint r0 = this.r0;
                                    int color2;
                                    if ((int)this.x0 == this.l0 / 2) {
                                        color2 = n9;
                                    }
                                    else {
                                        color2 = 0;
                                    }
                                    r0.setColor(color2);
                                }
                                break Label_1033;
                            }
                            final Matrix o3 = this.O;
                            final PointF p3 = this.P;
                            o3.postScale(n4, n4, p3.x, p3.y);
                            this.invalidate();
                            break Label_1033;
                        }
                        if (actionMasked != 3) {
                            if (actionMasked != 5) {
                                break Label_1033;
                            }
                            if (this.j(motionEvent) > 20.0f) {
                                this.Q = this.j(motionEvent);
                                this.y = true;
                                this.g(motionEvent);
                            }
                            else {
                                this.y = false;
                            }
                            this.x = false;
                            this.w = false;
                            break Label_1033;
                        }
                    }
                    this.w = false;
                    this.x = false;
                    this.y = false;
                }
                else if (this.e(motionEvent, this.p)) {
                    final c r2 = this.R;
                    if (r2 != null) {
                        r2.b(this);
                    }
                }
                else if (this.f(motionEvent)) {
                    this.w = true;
                    this.E0 = this.h(motionEvent);
                    this.g(motionEvent);
                    this.z = this.c(motionEvent);
                }
                else if (this.e(motionEvent, this.p)) {
                    this.bringToFront();
                    final c r3 = this.R;
                    if (r3 != null) {
                        r3.d(this);
                    }
                }
                else {
                    final float[] array = new float[9];
                    this.O.getValues(array);
                    final float n10 = array[0];
                    final float n11 = array[1];
                    final float n12 = array[2];
                    final float n13 = array[3];
                    final float n14 = array[4];
                    final float n15 = array[5];
                    final float n16 = array[0];
                    final float n17 = (float)this.b0;
                    final float n18 = array[1];
                    final float n19 = array[2];
                    final float n20 = array[3];
                    final float n21 = array[4];
                    final float n22 = array[5];
                    final float n23 = array[0];
                    final float n24 = array[1];
                    final float n25 = (float)this.a0;
                    final float n26 = array[2];
                    final float n27 = array[3];
                    final float n28 = array[4];
                    final float n29 = array[5];
                    final float n30 = array[0];
                    final float n31 = array[1];
                    final float n32 = array[2];
                    final float n33 = array[3];
                    final float n34 = array[4];
                    final float n35 = array[5];
                    final float x2 = motionEvent.getX(0);
                    final float y3 = motionEvent.getY(0);
                    final float[] array2 = { com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n11, 0.0f, n10 * 0.0f, n12), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n18, 0.0f, n16 * n17, n19), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n31, n25, n30 * n17, n32), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n24, n25, n23 * 0.0f, n26) };
                    final float[] array3 = { com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n14, 0.0f, n13 * 0.0f, n15), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n21, 0.0f, n20 * n17, n22), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n34, n25, n33 * n17, n35), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n28, n25, n27 * 0.0f, n29) };
                    final double hypot = Math.hypot(array2[0] - array2[1], array3[0] - array3[1]);
                    final double hypot2 = Math.hypot(array2[1] - array2[2], array3[1] - array3[2]);
                    final double hypot3 = Math.hypot(array2[3] - array2[2], array3[3] - array3[2]);
                    final double hypot4 = Math.hypot(array2[0] - array2[3], array3[0] - array3[3]);
                    final double hypot5 = Math.hypot(x2 - array2[0], y3 - array3[0]);
                    final double hypot6 = Math.hypot(x2 - array2[1], y3 - array3[1]);
                    final double hypot7 = Math.hypot(x2 - array2[2], y3 - array3[2]);
                    final double hypot8 = Math.hypot(x2 - array2[3], y3 - array3[3]);
                    final double a = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot, hypot5, hypot6, 2.0);
                    final double a2 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot2, hypot6, hypot7, 2.0);
                    final double a3 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot3, hypot7, hypot8, 2.0);
                    final double a4 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot4, hypot8, hypot5, 2.0);
                    if (Math.abs(hypot * hypot2 - (Math.sqrt((a4 - hypot5) * ((a4 - hypot8) * ((a4 - hypot4) * a4))) + (Math.sqrt((a3 - hypot8) * ((a3 - hypot7) * ((a3 - hypot3) * a3))) + (Math.sqrt((a2 - hypot7) * ((a2 - hypot6) * ((a2 - hypot2) * a2))) + Math.sqrt((a - hypot6) * ((a - hypot5) * ((a - hypot) * a))))))) >= 0.5 && !this.e(motionEvent, this.q)) {
                        final boolean b = false;
                        this.setInEdit(false);
                        final c r4 = this.R;
                        b2 = b;
                        if (r4 != null) {
                            r4.c(Boolean.FALSE);
                            b2 = b;
                        }
                        break Label_1844;
                    }
                    else {
                        this.x = true;
                        this.A = motionEvent.getX(0);
                        this.B = motionEvent.getY(0);
                    }
                }
            }
            b2 = true;
        }
        if (b2) {
            final c r5 = this.R;
            if (r5 != null) {
                r5.a(this);
            }
        }
        Label_1971: {
            if (this.q0 != null) {
                final int action = motionEvent.getAction();
                Label_1959: {
                    if (action != 0) {
                        ScrollView scrollView;
                        if (action != 1) {
                            if (action != 5) {
                                if (action != 6) {
                                    break Label_1971;
                                }
                                scrollView = this.q0;
                            }
                            else {
                                if (this.v) {
                                    break Label_1959;
                                }
                                break Label_1971;
                            }
                        }
                        else {
                            scrollView = this.q0;
                        }
                        scrollView.requestDisallowInterceptTouchEvent(false);
                        break Label_1971;
                    }
                    if (!this.v) {
                        break Label_1971;
                    }
                }
                this.q0.requestDisallowInterceptTouchEvent(true);
            }
        }
        if (motionEvent.getAction() != 6 && motionEvent.getAction() != 1) {
            if (motionEvent.getAction() == 2 && this.j0) {
                final a s2 = this.S;
                if (s2 != null) {
                    s2.a(this.y0, this.x0);
                    return b2;
                }
            }
        }
        else {
            if (this.i0) {
                this.s0.setColor(0);
                this.r0.setColor(0);
            }
            if (this.j0) {
                final a s3 = this.S;
                if (s3 != null) {
                    s3.b();
                }
            }
        }
        return b2;
    }

    public void setBitmap(final Bitmap k, final Boolean b) {
        this.O.reset();
        this.K = k;
        this.b0 = k.getWidth();
        final int height = this.K.getHeight();
        this.a0 = height;
        this.D = (float)height;
        final int b2 = this.b0;
        this.E = (float)b2;
        this.t = Math.hypot(b2, height) / 2.0;
        final int b3 = this.b0;
        final int a0 = this.a0;
        Label_0253: {
            int n4 = 0;
            int n5 = 0;
            Label_0240: {
                if (b3 >= a0) {
                    final float n = (float)(this.N * 10 / 100);
                    final float n2 = (float)b3;
                    if (n2 < n) {
                        this.h = 1.0f;
                    }
                    else {
                        this.h = n * 1.0f / n2;
                    }
                    final int b4 = this.b0;
                    final int n3 = this.N;
                    n4 = b4;
                    n5 = n3;
                    if (b4 <= n3) {
                        break Label_0240;
                    }
                }
                else {
                    final float n6 = (float)(this.N * 10 / 100);
                    final float n7 = (float)a0;
                    if (n7 < n6) {
                        this.h = 1.0f;
                    }
                    else {
                        this.h = n6 * 1.0f / n7;
                    }
                    final int a2 = this.a0;
                    final int n8 = this.N;
                    n4 = a2;
                    n5 = n8;
                    if (a2 <= n8) {
                        break Label_0240;
                    }
                }
                this.g = 1.0f;
                break Label_0253;
            }
            this.g = n5 * 1.0f / n4;
        }
        this.i = BitmapFactory.decodeResource(this.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_delete_sticker);
        this.r = BitmapFactory.decodeResource(this.getResources(), com.kotlinz.festivalstorymaker.R.drawable.icon_flip);
        this.U = BitmapFactory.decodeResource(this.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_resize_sticker);
        this.s = BitmapFactory.decodeResource(this.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_text_sticker_move);
        this.k = (int)(this.i.getWidth() * 1.0f);
        this.j = (int)(this.i.getHeight() * 1.0f);
        this.W = (int)(this.i.getWidth() * 1.0f);
        this.V = (int)(this.i.getHeight() * 1.0f);
        this.r.getWidth();
        this.r.getHeight();
        this.s.getWidth();
        this.s.getHeight();
        final int b5 = this.b0;
        this.T = (float)b5;
        final Matrix o = this.O;
        final float d0 = this.d0;
        o.postScale(this.C = d0, d0, (float)(b5 / 2), (float)(this.a0 / 2));
        this.O.postTranslate(this.H - this.b0 / 2, this.I - this.a0 / 2);
        this.invalidate();
    }

    public void setCanvasOperationListener(final a s) {
        this.S = s;
    }

    public void setDialogVisibility(final boolean d0) {
        this.D0 = d0;
    }

    public void setDimention(final Bitmap k, final float n, final float n2, final float n3, final float n4) {
        final int b0 = (int)n;
        this.b0 = b0;
        final int a0 = (int)n2;
        this.a0 = a0;
        this.K = k;
        this.I = n4;
        this.H = n3;
        this.A = n3;
        this.B = n4;
        this.K = Bitmap.createScaledBitmap(k, b0, a0, false);
        this.invalidate();
    }

    public void setGif(final boolean u) {
        this.u = u;
    }

    @Override
    public void setImageResource(final int n) {
        this.setBitmap(BitmapFactory.decodeResource(this.getResources(), n), Boolean.FALSE);
    }

    public void setInEdit(final boolean v) {
        this.v = v;
        this.invalidate();
    }

    public void setListner(final b h0, final String g0) {
        this.h0 = h0;
        this.g0 = g0;
    }

    public void setOperationListener(final c r) {
        this.R = r;
    }

    public void setRotate(final float c0) {
        this.c0 = c0;
        this.invalidate();
    }

    public void setScale(final float d0) {
        this.d0 = d0;
        this.invalidate();
    }

    public void setScroll(final ScrollView q0) {
        this.q0 = q0;
    }

    public void setSize(float n) {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.K.getHeight());
        sb.append("");
        final float n2 = n / Float.parseFloat(sb.toString());
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(this.K.getWidth());
        sb2.append("");
        final float float1 = Float.parseFloat(sb2.toString());
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(this.K.getHeight());
        sb3.append("");
        n = float1 * n / Float.parseFloat(sb3.toString());
        final StringBuilder sb4 = new StringBuilder();
        sb4.append(this.K.getWidth());
        sb4.append("");
        n /= Float.parseFloat(sb4.toString());
        this.O.postScale(n, n2, this.H, this.I);
        this.invalidate();
    }

    public void setWH(final int k0, final int l0) {
        this.k0 = k0;
        this.l0 = l0;
    }

    public interface a
    {
        void a(final float p0, final float p1);

        void b();
    }

    public interface b
    {
        void t(final float p0, final float p1, final Bitmap p2, final String p3);
    }

    public interface c
    {
        void a(final ImageStickerViewNew p0);

        void b(final ImageStickerViewNew p0);

        void c(final Boolean p0);

        void d(final ImageStickerViewNew p0);
    }
}
