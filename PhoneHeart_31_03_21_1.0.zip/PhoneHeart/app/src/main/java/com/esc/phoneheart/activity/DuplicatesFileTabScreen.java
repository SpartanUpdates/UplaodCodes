package com.esc.phoneheart.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Files;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.phoneheart.R;
import com.esc.phoneheart.duplicatefiles.DupFileHomeScreen;
import com.esc.phoneheart.duplicatefiles.DupFileMediaMapData;
import com.esc.phoneheart.duplicatefiles.DuplicateFileMediaData;
import com.esc.phoneheart.duplicatefiles.DuplicateFilesData;
import com.esc.phoneheart.interfaceclass.DialogListners;
import com.esc.phoneheart.kprogresshud.KProgressHUD;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.adapter.SectionsPagerAdapter;
import com.esc.phoneheart.utility.FileUtil;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.MediaStoreUtil;
import com.esc.phoneheart.utility.MountPoints;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.tabs.TabLayout;
import java.io.File;
import java.util.ArrayList;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

public class DuplicatesFileTabScreen extends ParentScreen implements DialogListners {
    public static final String TAG = DuplicatesFileTabScreen.class.getSimpleName();
    public AsyncTask<String, Integer, DELETION> deleteTask;
    public AppCompatCheckBox checkAll;
    public ProgressDialog displayProgress;
    public TabLayout tablayout;
    public int notdeleted;
    public TextView tvTotSize;
    public TextView tvTotSizeUnit;
    public boolean fromTouch = false;

    public static class AnonymousClass8 {
        public static final int[] a;

        static {
            int[] iArr = new int[DELETION.values().length];
            a = iArr;
            iArr[DELETION.ERROR.ordinal()] = 1;
            a[DELETION.PERMISSION.ordinal()] = 2;
            a[DELETION.SUCCESS.ordinal()] = 3;
            a[DELETION.SELECTION.ordinal()] = 4;
            a[DELETION.NOTDELETION.ordinal()] = 5;
        }
    }

    public enum DELETION {
        SUCCESS,
        ERROR,
        PERMISSION,
        SELECTION,
        FINISH,
        NOTDELETION
    }

    private void deleteFiles() {
        Util.appendLogphonecleaner(TAG, "method deletionTask calling", GlobalData.FILE_NAME);
        deleteTask = new AsyncTask<String, Integer, DELETION>() {
            private boolean deleteImageFile(File file) {
                boolean z;
                if (file.exists()) {
                    delete(file);
                    z = !file.exists();
                    if (z) {
                        DuplicatesFileTabScreen.this.updateMediaScannerPath(file);
                    } else {
                        boolean isKitKat = FileUtil.isKitKat();
                    }
                } else {
                    DuplicatesFileTabScreen.this.updateMediaScannerPath(file);
                    z = true;
                }
                if (Build.VERSION.SDK_INT == 21) {
                    return true;
                }
                return z;
            }

            private DELETION normalDeletion() {
                String str = " normal deletion befire deleteImageFile";
                String str2 = "";
                try {
                    Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "in normal deletion", str2);
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, " normal deletion befire loop");
                    DuplicateFilesData duplicateFilesData = PhoneCleaner.getInstance().duplicateFilesData;
                    int i = 0;
                    for (int i2 = 0; i2 < duplicateFilesData.duplicateFilesMediaDataList.size(); i2++) {
                        ArrayList<DupFileMediaMapData> arrayList = ((DuplicateFileMediaData) duplicateFilesData.duplicateFilesMediaDataList.get(i2)).fileTypeDataList;
                        for (int i3 = 0; i3 < arrayList.size(); i3++) {
                            ArrayList<BigSizeFilesWrapper> arrayList2 = ((DupFileMediaMapData) arrayList.get(i3)).list;
                            int size = arrayList2.size();
                            int i4 = 0;
                            while (i4 < size) {
                                BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) arrayList2.get(i4);
                                if (bigSizeFilesWrapper.ischecked) {
                                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, str);
                                    if (deleteImageFile(new File(bigSizeFilesWrapper.path))) {
                                        Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, str);
                                        String a2 = DuplicatesFileTabScreen.TAG;
                                        StringBuilder sb = new StringBuilder();
                                        sb.append("normal delete success with path===");
                                        sb.append(bigSizeFilesWrapper.path);
                                        Util.appendLogphonecleaner(a2, sb.toString(), str2);
                                        i++;
                                        DuplicatesFileTabScreen.this.displayProgress.setProgress(i);
                                        duplicateFilesData.removeNode(bigSizeFilesWrapper);
                                        arrayList2.remove(i4);
                                        size--;
                                    } else {
                                        DuplicatesFileTabScreen.this.notdeleted = DuplicatesFileTabScreen.this.notdeleted + 1;
                                        String a3 = DuplicatesFileTabScreen.TAG;
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append("normal delete failed with path===");
                                        sb2.append(bigSizeFilesWrapper.path);
                                        Util.appendLogphonecleaner(a3, sb2.toString(), str2);
                                    }
                                }
                                i4++;
                            }
                        }
                    }
                    if (DuplicatesFileTabScreen.this.notdeleted > 0) {
                        return DELETION.NOTDELETION;
                    }
                    return DELETION.SUCCESS;
                } catch (Exception e) {
                    String a4 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Normal deletion exception====");
                    sb3.append(e.getMessage());
                    Util.appendLogphonecleaner(a4, sb3.toString(), GlobalData.FILE_NAME);
                    String a5 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("22 Normal deletion exception====");
                    sb4.append(e.getMessage());
                    Util.appendLogphonecleanerbug(a5, sb4.toString());
                    DELETION deletion = DELETION.ERROR;
                    if (DuplicatesFileTabScreen.this.notdeleted > 0) {
                        return DELETION.NOTDELETION;
                    }
                    return DELETION.SUCCESS;
                } catch (Throwable unused) {
                    if (DuplicatesFileTabScreen.this.notdeleted > 0) {
                        return DELETION.NOTDELETION;
                    }
                    return DELETION.SUCCESS;
                }
            }

            public boolean delete(File file) {
                file.delete();
                if (file.exists()) {
                    String[] strArr = {file.getAbsolutePath()};
                    ContentResolver contentResolver = DuplicatesFileTabScreen.this.getContentResolver();
                    Uri contentUri = Files.getContentUri("external");
                    String str = "_data=?";
                    contentResolver.delete(contentUri, str, strArr);
                    if (file.exists()) {
                        contentResolver.delete(contentUri, str, strArr);
                    }
                }
                return true;
            }

            public void onPreExecute() {
                super.onPreExecute();
                DuplicatesFileTabScreen.this.notdeleted = 0;
                String str = "method deletionTask pre execute calling";
                Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, str, GlobalData.FILE_NAME);
                Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, str);
                DuplicatesFileTabScreen.this.displayProgress = new ProgressDialog(DuplicatesFileTabScreen.this);
                DuplicatesFileTabScreen.this.getWindow().addFlags(2097280);
                ProgressDialog b = DuplicatesFileTabScreen.this.displayProgress;
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(DuplicatesFileTabScreen.this.getResources().getString(R.string.cleaning));
                b.setTitle(sb.toString());
                DuplicatesFileTabScreen.this.displayProgress.setCanceledOnTouchOutside(false);
                DuplicatesFileTabScreen.this.displayProgress.setProgressStyle(1);
                DuplicatesFileTabScreen.this.displayProgress.setCancelable(false);
                DuplicatesFileTabScreen.this.displayProgress.setMax((int) PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems);
                DuplicatesFileTabScreen.this.displayProgress.show();
            }

            public DELETION doInBackground(String... strArr) {
                Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "method deletionTask doinbackground calling", GlobalData.FILE_NAME);
                Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "in doin background");
                if (strArr != null) {
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "string != null");
                    return DuplicatesFileTabScreen.this.permissionBasedDeletion();
                }
                Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "in doinbg bfore isdeletionbelowsix ");
                if (FileUtil.IsDeletionBelow6()) {
                    Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "method deletionTask os below 5.0", GlobalData.FILE_NAME);
                    return normalDeletion();
                }
                Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "in doinbg after isdeletionbelowsix ");
                ArrayList returnMountPOints = MountPoints.returnMountPOints(DuplicatesFileTabScreen.this);
                String a2 = DuplicatesFileTabScreen.TAG;
                StringBuilder sb = new StringBuilder();
                sb.append("in doinbg mount points ");
                sb.append(returnMountPOints);
                Util.appendLogphonecleanerbug(a2, sb.toString());
                if (returnMountPOints == null) {
                    String a3 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("in doinbg mount points == null ");
                    sb2.append(returnMountPOints);
                    Util.appendLogphonecleanerbug(a3, sb2.toString());
                    Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "mount points arr is null", GlobalData.FILE_NAME);
                    return normalDeletion();
                } else if (returnMountPOints.size() == 1) {
                    String a4 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("in doinbg mount points == 1 ");
                    sb3.append(returnMountPOints.size());
                    Util.appendLogphonecleanerbug(a4, sb3.toString());
                    Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "mount points arr size is 1", GlobalData.FILE_NAME);
                    return normalDeletion();
                } else {
                    String a5 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("mount points arr size is ");
                    sb4.append(returnMountPOints.size());
                    Util.appendLogphonecleaner(a5, sb4.toString(), GlobalData.FILE_NAME);
                    String a6 = DuplicatesFileTabScreen.TAG;
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("in doinbg mount points size ==  ");
                    sb5.append(returnMountPOints.size());
                    Util.appendLogphonecleanerbug(a6, sb5.toString());
                    File file = new File((String) returnMountPOints.get(1));
                    if (file.listFiles() == null || file.listFiles().length == 0) {
                        Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "in doinbg temp.listFiles() == null || temp.listFiles().length == 0 ");
                        return normalDeletion();
                    } else if (Build.VERSION.SDK_INT <= 21) {
                        return DELETION.SUCCESS;
                    } else {
                        if (!DuplicatesFileTabScreen.this.isBothStorageCanDelete(returnMountPOints)) {
                            String a7 = DuplicatesFileTabScreen.TAG;
                            StringBuilder sb6 = new StringBuilder();
                            sb6.append("in doinbg Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP both can't delete ");
                            sb6.append(returnMountPOints.size());
                            Util.appendLogphonecleanerbug(a7, sb6.toString());
                            Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "file is not able to write on external.Taking Permission", GlobalData.FILE_NAME);
                            return DELETION.PERMISSION;
                        }
                        String a8 = DuplicatesFileTabScreen.TAG;
                        StringBuilder sb7 = new StringBuilder();
                        sb7.append("in doinbg Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP both can delete ");
                        sb7.append(returnMountPOints.size());
                        Util.appendLogphonecleanerbug(a8, sb7.toString());
                        Util.appendLogphonecleaner(DuplicatesFileTabScreen.TAG, "file is able to write on external", GlobalData.FILE_NAME);
                        return DuplicatesFileTabScreen.this.permissionBasedDeletion();
                    }
                }
            }

            public void onPostExecute(DELETION deletion) {
                super.onPostExecute(deletion);
                String a2 = DuplicatesFileTabScreen.TAG;
                StringBuilder sb = new StringBuilder();
                sb.append("method deletionTask onPostExecute() calling with status====");
                sb.append(deletion.name());
                Util.appendLogphonecleaner(a2, sb.toString(), GlobalData.FILE_NAME);
                Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "on post execute  ");
                if (DuplicatesFileTabScreen.this.displayProgress != null && DuplicatesFileTabScreen.this.displayProgress.isShowing()) {
                    DuplicatesFileTabScreen.this.displayProgress.dismiss();
                }
                DuplicatesFileTabScreen.this.getWindow().clearFlags(128);
                String a3 = DuplicatesFileTabScreen.TAG;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("onpostexecute b4 switch case ");
                sb2.append(deletion.name());
                Util.appendLogphonecleanerbug(a3, sb2.toString());
                int i = AnonymousClass8.a[deletion.ordinal()];
                String str = "";
                if (i == 1) {
                    Toast.makeText(DuplicatesFileTabScreen.this, str, Toast.LENGTH_LONG).show();
                } else if (i == 2) {
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "bfore permissionAlert");
                    DuplicatesFileTabScreen.this.permissionAlert();
                } else if (i == 3) {
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "onpostexecute success");
                    DuplicatesFileTabScreen.this.successDeletion();
                } else if (i == 4) {
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "onpostexecute selection");
                    DuplicatesFileTabScreen duplicatesFileTabScreen = DuplicatesFileTabScreen.this;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(str);
                    sb3.append(DuplicatesFileTabScreen.this.getResources().getString(R.string.junk_atlest_one));
                    Toast.makeText(duplicatesFileTabScreen, sb3.toString(), Toast.LENGTH_SHORT).show();
                } else if (i == 5) {
                    Util.appendLogphonecleanerbug(DuplicatesFileTabScreen.TAG, "onpostexecute successdeletion");
                    DuplicatesFileTabScreen.this.successDeletion();
                }
            }

            public void onProgressUpdate(Integer... numArr) {
                super.onProgressUpdate(numArr);
                DuplicatesFileTabScreen.this.displayProgress.setProgress(numArr[0].intValue());
            }
        };
        ArrayList<String> list = new ArrayList();
        boolean z = true;
        for (int i = 0; i < list.size(); i++) {
            if (list != null && list.size() >1){
                File file = new File((String) list.get(1));
                if (file.listFiles() != null) {
                }
            }
        }
        if (!z) {
            this.deleteTask.execute(new String[0]);
        } else if (!isBothStorageCanDelete(list)) {
            permissionAlert();
        } else {
            this.deleteTask.execute(new String[]{"permissiondeletion"});
        }
    }

    private boolean isBothStorageCanDelete(ArrayList<String> arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (!FileUtil.isWritableNormalOrSaf(this, new File((String) arrayList.get(i)))) {
                    return false;
                }
            }
        }
        return true;
    }

    private void markUnmarkAll(boolean z) {
        int i = 0;
        boolean z2 = z;
        int selectedTabPosition = this.tablayout.getSelectedTabPosition();
        String string = getString(SectionsPagerAdapter.TAB_TITLES[selectedTabPosition]);
        boolean z3 = false;
        int i2 = 0;
        while (true) {
            long j = 1;
            if (i2 >= PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.size()) {
                break;
            }
            ArrayList<DupFileMediaMapData> arrayList = ((DuplicateFileMediaData) PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.get(i2)).fileTypeDataList;
            int i3 = 0;
            while (i3 < arrayList.size()) {
                int i4 = 0;
                while (i4 < ((DupFileMediaMapData) arrayList.get(i3)).list.size()) {
                    if (i4 != 0) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i4);
                        if (bigSizeFilesWrapper.type.equalsIgnoreCase(string) && bigSizeFilesWrapper.ischecked != z2) {
                            bigSizeFilesWrapper.ischecked = z2;
                            StringBuilder sb = new StringBuilder();
                            sb.append(bigSizeFilesWrapper.name);
                            sb.append("  (");
                            sb.append(Util.convertBytes(bigSizeFilesWrapper.size));
                            if (z2) {
                                DuplicateFilesData duplicateFilesData = PhoneCleaner.getInstance().duplicateFilesData;
                                i = i2;
                                duplicateFilesData.totalSelectedSize += bigSizeFilesWrapper.size;
                                PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems += j;
                            } else {
                                i = i2;
                                PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize -= bigSizeFilesWrapper.size;
                                PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems--;
                            }
                            i4++;
                            i2 = i;
                            z3 = false;
                            j = 1;
                        }
                    } else if (z2) {
                        if (((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i)).ischecked) {
                            ((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i)).ischecked = z3;
                            PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize += ((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i)).size;
                            PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems += j;
                        }
                    } else if (((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(z3 ? 1 : 0)).ischecked) {
                        ((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i)).ischecked = z3;
                        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize += ((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i3)).list.get(i)).size;
                        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems += j;
                    }
                    i = i2;
                    i4++;
                    i2 = i;
                    z3 = false;
                    j = 1;
                }
                int i5 = i2;
                i3++;
                z3 = false;
                j = 1;
            }
            i2++;
            z3 = false;
        }
        setViewPager();
        this.tablayout.getTabAt(selectedTabPosition).select();
        if (PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems == 0) {
            ((TextView) findViewById(R.id.btn_clean)).setText(R.string.clean);
            ((TextView) findViewById(R.id.btn_clean)).setEnabled(false);
            return;
        }
        long j2 = PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems;
        String str = ")";
        String str2 = " (";
        String str3 = " ";
        if (j2 == 1) {
            TextView textView = (TextView) findViewById(R.id.btn_clean);
            StringBuilder sb2 = new StringBuilder();
            sb2.append(getString(R.string.clean));
            sb2.append(str3);
            sb2.append(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems);
            sb2.append(str3);
            sb2.append(getString(R.string.file_manage_items));
            sb2.append(str2);
            sb2.append(Util.convertBytes(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize));
            sb2.append(str);
            textView.setText(sb2.toString());
            ((TextView) findViewById(R.id.btn_clean)).setEnabled(true);
            return;
        }
        TextView textView2 = (TextView) findViewById(R.id.btn_clean);
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getString(R.string.clean));
        sb3.append(str3);
        sb3.append(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems);
        sb3.append(str3);
        sb3.append(getString(R.string.file_manage_items));
        sb3.append(str2);
        sb3.append(Util.convertBytes(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize));
        sb3.append(str);
        textView2.setText(sb3.toString());
        ((TextView) findViewById(R.id.btn_clean)).setEnabled(true);
    }

    private void permissionAlert() {
        final Dialog dialog = new Dialog(this);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        dialog.findViewById(R.id.dialog_img).setVisibility(View.GONE);
        dialog.findViewById(R.id.dialog_title).setVisibility(View.GONE);
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getString(R.string.pcl_sdcard_permission_delete));
        ((TextView) dialog.findViewById(R.id.ll_no_txt)).setText(getString(R.string.pcl_deny));
        ((TextView) dialog.findViewById(R.id.ll_yes_txt)).setText(getString(R.string.pcl_grant));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DuplicatesFileTabScreen.this.doubleClicked()) {
                    DuplicatesFileTabScreen.this.deleteTask.execute(new String[0]);
                }
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DuplicatesFileTabScreen.this.doubleClicked()) {
                    dialog.dismiss();
                    DuplicatesFileTabScreen duplicatesFileTabScreen = DuplicatesFileTabScreen.this;
                    SplashScreen.showdialog_sdcard(duplicatesFileTabScreen, duplicatesFileTabScreen);
                }
            }
        });
        dialog.show();
    }

    private DELETION permissionBasedDeletion() {
        String str = "in permissionbased deletion finally  notdeleted =  ";
        Util.appendLogphonecleanerbug(TAG, "in permissionbased deletion");
        String str2;
        String str3;
        StringBuilder stringBuilder;
        try {
            Util.appendLogphonecleanerbug(TAG, "in permissionbased deletion before loop");
            DuplicateFilesData duplicateFilesData = PhoneCleaner.getInstance().duplicateFilesData;
            boolean z = false;
            int i = 0;
            int i2 = 0;
            while (i < duplicateFilesData.duplicateFilesMediaDataList.size()) {
                DuplicateFilesData duplicateFilesData2;
                ArrayList arrayList = ((DuplicateFileMediaData) duplicateFilesData.duplicateFilesMediaDataList.get(i)).fileTypeDataList;
                int i3 = 0;
                while (i3 < arrayList.size()) {
                    ArrayList arrayList2 = ((DupFileMediaMapData) arrayList.get(i3)).list;
                    int size = arrayList2.size();
                    int i4 = 0;
                    while (i4 < size) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) arrayList2.get(i4);
                        if (bigSizeFilesWrapper.ischecked) {
                            boolean exists;
                            File file = new File(bigSizeFilesWrapper.path);
                            String str4 = TAG;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("in permissionbased deletion in loop : 1. ");
                            stringBuilder2.append(z);
                            Util.appendLogphonecleanerbug(str4, stringBuilder2.toString());
                            if (file.delete()) {
                                exists = file.exists();
                            } else {
                                exists = FileUtil.deleteFile(this, file);
                            }
                            String str5 = TAG;
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("in permissionbased deletion in loop : 2. ");
                            stringBuilder3.append(exists);
                            Util.appendLogphonecleanerbug(str5, stringBuilder3.toString());
                            if (!exists) {
                                exists = FileUtil.deleteFile(this, file);
                            }
                            str2 = TAG;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("in permissionbased deletion in loop : 3. ");
                            stringBuilder2.append(exists);
                            Util.appendLogphonecleanerbug(str2, stringBuilder2.toString());
                            str2 = "";
                            if (exists) {
                                str5 = TAG;
                                stringBuilder3 = new StringBuilder();
                                duplicateFilesData2 = duplicateFilesData;
                                stringBuilder3.append("in permissionbased deletion in loop : deleted = true ");
                                stringBuilder3.append(exists);
                                Util.appendLogphonecleanerbug(str5, stringBuilder3.toString());
                                str3 = TAG;
                                StringBuilder stringBuilder4 = new StringBuilder();
                                stringBuilder4.append("normal delete success with path===");
                                stringBuilder4.append(bigSizeFilesWrapper.path);
                                Util.appendLogphonecleaner(str3, stringBuilder4.toString(), str2);
                                PhoneCleaner.getInstance().duplicateFilesData.removeNode(bigSizeFilesWrapper);
                                arrayList2.remove(i4);
                                i2++;
                                this.displayProgress.setProgress(i2);
                                updateMediaScannerPath(file);
                                size--;
                                duplicateFilesData = duplicateFilesData2;
                                z = false;
                            } else {
                                duplicateFilesData2 = duplicateFilesData;
                                this.notdeleted++;
                                str3 = TAG;
                                StringBuilder stringBuilder5 = new StringBuilder();
                                stringBuilder5.append("in permissionbased deletion in loop : deleted = false ");
                                stringBuilder5.append(exists);
                                Util.appendLogphonecleanerbug(str3, stringBuilder5.toString());
                                str3 = TAG;
                                stringBuilder5 = new StringBuilder();
                                stringBuilder5.append("normal delete failed with path===");
                                stringBuilder5.append(bigSizeFilesWrapper.path);
                                Util.appendLogphonecleaner(str3, stringBuilder5.toString(), str2);
                            }
                        } else {
                            duplicateFilesData2 = duplicateFilesData;
                        }
                        i4++;
                        duplicateFilesData = duplicateFilesData2;
                        z = false;
                    }
                    duplicateFilesData2 = duplicateFilesData;
                    i3++;
                    z = false;
                }
                duplicateFilesData2 = duplicateFilesData;
                i++;
                z = false;
            }
            str3 = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.notdeleted);
            Util.appendLogphonecleanerbug(str3, stringBuilder.toString());
            if (this.notdeleted > 0) {
                return DELETION.NOTDELETION;
            }
            return DELETION.SUCCESS;
        } catch (Exception e) {
            str2 = TAG;
            StringBuilder stringBuilder6 = new StringBuilder();
            stringBuilder6.append("in permissionbased deletion exception 1.  ");
            stringBuilder6.append(e.getMessage());
            Util.appendLogphonecleanerbug(str2, stringBuilder6.toString());
            str2 = TAG;
            stringBuilder6 = new StringBuilder();
            stringBuilder6.append("Permission deletion exception====");
            stringBuilder6.append(e.getMessage());
            Util.appendLogphonecleaner(str2, stringBuilder6.toString(), GlobalData.FILE_NAME);
            DELETION deletion = DELETION.ERROR;
            str3 = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.notdeleted);
            Util.appendLogphonecleanerbug(str3, stringBuilder.toString());
            if (this.notdeleted > 0) {
                return DELETION.NOTDELETION;
            }
            return DELETION.SUCCESS;
        } catch (Throwable unused) {
            str3 = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(this.notdeleted);
            Util.appendLogphonecleanerbug(str3, stringBuilder.toString());
            if (this.notdeleted > 0) {
                return DELETION.NOTDELETION;
            }
            return DELETION.SUCCESS;
        }
    }

    private void setViewPager() {
        this.tablayout = (TabLayout) findViewById(R.id.tabs);
        ViewPager viewPager = (ViewPager) findViewById(R.id.view_pager);
        viewPager.setAdapter(new SectionsPagerAdapter(this, getSupportFragmentManager()));
        this.tablayout.setupWithViewPager(viewPager);
    }

    private void showConfirmDialog() {
        Util.appendLogphonecleaner(TAG, "showConfirmDialog--- clean item ", GlobalData.FILE_NAME);
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        if (getIntent().getBooleanExtra("FROMHOME", false)) {
            ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.dup_files_title));
        } else {
            ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.dup_files_title));
        }
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dup_photo_cleanconfirm_message));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DuplicatesFileTabScreen.this.doubleClicked()) {
                    dialog.dismiss();
                }
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DuplicatesFileTabScreen.this.doubleClicked()) {
                    dialog.dismiss();
                    DuplicatesFileTabScreen.this.deleteFiles();
                }
            }
        });
        dialog.show();
    }

    private void successDeletion() {
        Intent intent = new Intent(this, FinalScreen.class);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(Util.convertBytes(PhoneCleaner.getInstance().duplicateFilesData.recoveredSpace));
        intent.putExtra("DATA", stringBuilder.toString());
        intent.putExtra("TYPE", "Recovered");
        intent.putExtra("FROMLARGE", true);
        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize = 0;
        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems = 0;
        ((TextView) findViewById(R.id.btn_clean)).setText(R.string.clean);
        ((TextView) findViewById(R.id.btn_clean)).setEnabled(false);
        startActivity(intent);
    }

    private void updateMediaScannerPath(File file) {
        if (FileUtil.isKitKat()) {
            Uri uriFromFile = MediaStoreUtil.getUriFromFile(this, file.getAbsolutePath());
            if (uriFromFile != null) {
                getContentResolver().delete(uriFromFile, null, null);
            }
        } else if (FileUtil.isSystemAndroid5()) {
            Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            intent.setData(Uri.fromFile(file));
            sendBroadcast(intent);
        } else {
            MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, null, null);
        }
    }

    public void clickOK() {
    }

    public boolean delete(File file) {
        file.delete();
        if (file.exists()) {
            String[] strArr = new String[]{file.getAbsolutePath()};
            ContentResolver contentResolver = getContentResolver();
            Uri contentUri = Files.getContentUri("external");
            String str = "_data=?";
            contentResolver.delete(contentUri, str, strArr);
            if (file.exists()) {
                contentResolver.delete(contentUri, str, strArr);
            }
        }
        return true;
    }

    public void getSelection() {
        String string = getString(SectionsPagerAdapter.TAB_TITLES[this.tablayout.getSelectedTabPosition()]);
        for (int i = 0; i < PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.size(); i++) {
            DuplicateFileMediaData duplicateFileMediaData = (DuplicateFileMediaData) PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.get(i);
            if (duplicateFileMediaData.mediaName.equalsIgnoreCase(string)) {
                ArrayList arrayList = duplicateFileMediaData.fileTypeDataList;
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    int i3 = 1;
                    while (i3 < ((DupFileMediaMapData) arrayList.get(i2)).list.size()) {
                        if (((BigSizeFilesWrapper) ((DupFileMediaMapData) arrayList.get(i2)).list.get(i3)).ischecked) {
                            i3++;
                        } else {
                            this.checkAll.setChecked(false);
                            return;
                        }
                    }
                }
                continue;
            }
        }
        this.checkAll.setChecked(true);

    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_duplicates_file);
        setDeviceDimensio();
        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize = 0;
        PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems = 0;
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            Drawable backArrow = getResources().getDrawable(R.drawable.ic_back_selector);
            getSupportActionBar().setHomeAsUpIndicator(backArrow);
            getSupportActionBar().setTitle((CharSequence) "");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        setViewPager();
        loadAd();
        this.checkAll = (AppCompatCheckBox) findViewById(R.id.check_all);
        this.tvTotSize = (TextView) findViewById(R.id.junkdisplay_sizetv);
        this.tvTotSizeUnit = (TextView) findViewById(R.id.junkdisplay_sizetv_unit);
        findViewById(R.id.btn_clean).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems == 0) {
                    Toast.makeText(DuplicatesFileTabScreen.this, getResources().getString(R.string.junk_atlest_one), Toast.LENGTH_LONG).show();
                } else {
                    showConfirmDialog();
                }
            }
        });
        this.tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                DuplicatesFileTabScreen.this.getSelection();
            }

            public void onTabUnselected(TabLayout.Tab tab) {
            }
        });

        this.checkAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (DuplicatesFileTabScreen.this.fromTouch) {
                    if (z) {
                        DuplicatesFileTabScreen.this.markUnmarkAll(true);
                    } else {
                        DuplicatesFileTabScreen.this.markUnmarkAll(false);
                    }
                    DuplicatesFileTabScreen.this.fromTouch = false;
                }
            }
        });
        this.checkAll.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                DuplicatesFileTabScreen.this.fromTouch = true;
                return false;
            }
        });

    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd()
    {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(DuplicatesFileTabScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                    startActivity(new Intent(DuplicatesFileTabScreen.this, DupFileHomeScreen.class));
                    finish();
                    break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(DuplicatesFileTabScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    public void onBackPressed()
    {
        id = 100;
        if (interstitial !=null && interstitial.isLoaded()){
            DialogShow();
            AdsDialogShow();
        }else {
            startActivity(new Intent(DuplicatesFileTabScreen.this, DupFileHomeScreen.class));
            finish();
        }
    }

    public void onResume() {
        super.onResume();
        PhoneCleaner.getInstance().duplicateFilesData.refresh();
        this.tvTotSize.setText(Util.convertBytes_only(PhoneCleaner.getInstance().duplicateFilesData.totalDuplicatesSize));
        this.tvTotSizeUnit.setText(Util.convertBytes_unit(PhoneCleaner.getInstance().duplicateFilesData.totalDuplicatesSize));
    }
}
