package com.esc.socialmediacleaner.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.activity.FileTabsScreen;
import com.esc.socialmediacleaner.datastructure.AllData;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.util.Util;

import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import java.io.File;
import java.util.ArrayList;

public class FilesAdapter extends RecyclerView.Adapter<FilesAdapter.MyViewHolder> {
    private final AppCompatCheckBox checkBoxSelectAll;
    private final Context context;
    private final ArrayList<FileDataWrapper> dataList;
    private int type = 0;

    public class MyViewHolder extends ViewHolder {
        private CheckBox cBox;
        private LinearLayout checkBoxLout;
        private ImageView imgIcon;
//        private ImageView imgShare;
        public TextView size;
        public TextView title;

        MyViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.tvfile_name);
            this.size = (TextView) view.findViewById(R.id.tv_file_size);
            this.imgIcon = (ImageView) view.findViewById(R.id.img_fileicon);
//            this.imgShare = (ImageView) view.findViewById(R.id.img_share);
            this.checkBoxLout = (LinearLayout) view.findViewById(R.id.check_down_layout);
            this.cBox = (CheckBox) view.findViewById(R.id.check_download);
        }
    }

    public FilesAdapter(Context context, ArrayList<FileDataWrapper> arrayList, AppCompatCheckBox appCompatCheckBox) {
        this.context = context;
        this.dataList = arrayList;
        try {
            this.type = ((FileDataWrapper) arrayList.get(0)).type.ordinal();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.checkBoxSelectAll = appCompatCheckBox;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_adapter, viewGroup, false));
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, final int i) {
        final FileDataWrapper fileDataWrapper = (FileDataWrapper) this.dataList.get(i);
        myViewHolder.title.setText(String.format("%s", new Object[]{fileDataWrapper.name}));
        myViewHolder.size.setText(Util.convertBytes(fileDataWrapper.size));
        if (this.type == 2) {
            myViewHolder.imgIcon.setImageDrawable(getADrawable(R.drawable.ic_selector_audio));
        } else {
            myViewHolder.imgIcon.setImageDrawable(getADrawable(R.drawable.ic_selector_folder));
        }
        ((View) myViewHolder.title.getParent()).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    FilesAdapter.this.openDownloadFile(FilesAdapter.this.context, new File(fileDataWrapper.path));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        myViewHolder.checkBoxLout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AllData allData = MyApplication.getInstance().allData;
                if (fileDataWrapper.ischecked) {
                    myViewHolder.cBox.setChecked(false);
                    allData.unCheckItem((FileDataWrapper) FilesAdapter.this.dataList.get(i));
                } else {
                    myViewHolder.cBox.setChecked(true);
                    allData.checkItem((FileDataWrapper) FilesAdapter.this.dataList.get(i));
                }
                Button button = (Button) ((FileTabsScreen) FilesAdapter.this.context).findViewById(R.id.btn_delete);
                TextView textView = (TextView) ((FileTabsScreen) FilesAdapter.this.context).findViewById(R.id.tv_all_selection);
                String str = "/";
                StringBuilder stringBuilder;
                if (allData.totSelectedItem == 0) {
                    button.setText(FilesAdapter.this.context.getString(R.string.str_delete));
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(MyApplication.getInstance().allData.totSelectedItem);
                    stringBuilder.append(str);
                    stringBuilder.append(MyApplication.getInstance().allData.total_filetype);
                    textView.setText(stringBuilder.toString());
                    if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        button.setBackground(FilesAdapter.this.context.getDrawable(R.drawable.btn_gray_round));
                    }
//                    button.setTextColor(Color.parseColor("#9a9a9a"));
                } else {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(FilesAdapter.this.context.getString(R.string.str_delete));
                    stringBuilder2.append(" ");
                    stringBuilder2.append(Util.convertBytes(allData.totSelectedSize));
                    button.setText(stringBuilder2.toString());
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(MyApplication.getInstance().allData.totSelectedItem);
                    stringBuilder.append(str);
                    stringBuilder.append(MyApplication.getInstance().allData.total_filetype);
                    textView.setText(stringBuilder.toString());
                    if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        button.setBackground(FilesAdapter.this.context.getDrawable(R.drawable.btn_bg_round));
                    }
//                    button.setTextColor(Color.parseColor("#000000"));
                }
//                ((FileTabsScreen) FilesAdapter.this.context).loadAD();
                FilesAdapter.this.checkBoxSelectAll.setChecked(FilesAdapter.this.getCheck());
            }
        });
        /*myViewHolder.imgShare.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Uri uriForFile = FileProvider.getUriForFile(FilesAdapter.this.context, "social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.fileprovider", new File(fileDataWrapper.path));
                FilesAdapter.this.context.startActivity(Intent.createChooser(IntentBuilder.from((FileTabsScreen) FilesAdapter.this.context).setStream(uriForFile).setType("text/html").getIntent().setAction("android.intent.action.SEND").setDataAndType(uriForFile, "image/*").addFlags(1), FilesAdapter.this.context.getString(R.string.share)));
            }
        });*/
        if (fileDataWrapper.ischecked) {
            myViewHolder.cBox.setChecked(true);
        } else {
            myViewHolder.cBox.setChecked(false);
        }
    }

    private boolean getCheck() {
        ArrayList arrayList = MyApplication.getInstance().allData.appList;
        boolean z = false;
        for (int i = 0; i < arrayList.size(); i++) {
            if (!((FileDataWrapper) arrayList.get(i)).ischecked) {
                break;
            }
        }
        z = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e("CHEEEE", stringBuilder.toString());
        return z;
    }

    private void openDownloadFile(Context context, File file) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setFlags(335544320);
        intent.addFlags(1);
        Uri uriForFile = FileProvider.getUriForFile(context, "social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.fileprovider", file);
        String mimeType = Util.getMimeType(file.getAbsolutePath());
        if (mimeType != null) {
            intent.setDataAndType(uriForFile, mimeType);
        } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
            intent.setDataAndType(uriForFile, "application/msword");
        } else if (file.toString().contains(".pdf")) {
            intent.setDataAndType(uriForFile, "application/pdf");
        } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
        } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
        } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
            intent.setDataAndType(uriForFile, "application/x-wav");
        } else if (file.toString().contains(".rtf")) {
            intent.setDataAndType(uriForFile, "application/rtf");
        } else if (file.toString().contains(".wav") || file.toString().contains(".mp3")) {
            intent.setDataAndType(uriForFile, "audio/*");
        } else if (file.toString().contains(".gif")) {
            intent.setDataAndType(uriForFile, "image/gif");
        } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
            intent.setDataAndType(uriForFile, "image/*");
        } else if (file.toString().contains(".txt")) {
            intent.setDataAndType(uriForFile, "text/plain");
        } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
            intent.setDataAndType(uriForFile, "video/*");
        } else if (file.toString().contains(".apk")) {
            intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(uriForFile, "*/*");
        }
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Drawable getADrawable(int i) {
        if (VERSION.SDK_INT >= 21) {
            return this.context.getResources().getDrawable(i, this.context.getTheme());
        }
        return this.context.getResources().getDrawable(i);
    }

    public int getItemCount() {
        return this.dataList.size();
    }
}
