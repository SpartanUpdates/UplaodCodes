package com.kotlinz.videostatusmaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import com.kotlinz.videostatusmaker.Activity.ActivityMyCreations;
import com.kotlinz.videostatusmaker.R;
import com.kotlinz.videostatusmaker.Utils.RoundedImageView;

public class MyCreationAdapter extends BaseAdapter {
    private ArrayList<String> stringArrayList;
    LayoutInflater inflater;
    private Context context;

    public MyCreationAdapter(final Context mContext, final ArrayList<String> list) {
        this.inflater = null;
        this.context = mContext;
        this.stringArrayList = list;
        this.inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.stringArrayList = list;
    }

    public int getCount() {
        return this.stringArrayList.size();
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(final int n, final View view, final ViewGroup viewGroup) {
        View inflate = view;
        if (view == null) {
            inflate = this.inflater.inflate(R.layout.mycreation_adapter, (ViewGroup) null);
        }
        final RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.mainLay);
        final RoundedImageView roundedImageView = (RoundedImageView) inflate.findViewById(R.id.image);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.bg_img);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.play_icon);
        roundedImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        final int n2 = widthPixels * 913 / 1080;
        final int n3 = heightPixels * 845 / 1920;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n2, n3);
        layoutParams.addRule(14);
        final int n4 = heightPixels * 10 / 1920;
        layoutParams.setMargins(n4, n4, n4, n4);
        relativeLayout.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        imageView.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(widthPixels * 969 / 1080, n3));
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(widthPixels * 805 / 1080, heightPixels * 800 / 1920);
        layoutParams2.addRule(14);
        layoutParams2.setMargins(0, heightPixels * 5 / 1920, 0, 0);
        roundedImageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(widthPixels * 150 / 1080, heightPixels * 150 / 1920);
        layoutParams3.addRule(13);
        imageView2.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        roundedImageView.setCornerRadius(widthPixels * 35 / 1080);
        Glide.with(this.context).load((String) this.stringArrayList.get(n)).crossFade().error(R.drawable.mywork_bg).into((ImageView) roundedImageView);
        inflate.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ((ActivityMyCreations) MyCreationAdapter.this.context).preview(n);
            }
        });
        return inflate;
    }
}
