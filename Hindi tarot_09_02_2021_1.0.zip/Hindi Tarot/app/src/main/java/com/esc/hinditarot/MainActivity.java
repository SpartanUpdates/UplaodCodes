package com.esc.hinditarot;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.ironsource.mediationsdk.IronSource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public static final String SELECTED_CATEGORY = "com.waf.hinditarot.SELECTED_CATEGORY";
    public Activity activity = MainActivity.this;
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (MainActivity.i == 0) {
                MainActivity.i++;
                MainActivity.startbool = true;
                MainActivity.handler.postDelayed(MainActivity.changeAdBool, (long) i);
                return;
            }
            MainActivity.showbool = true;
            MainActivity.i = 0;
            MainActivity.stopbool = true;
            MainActivity.stopRunnable();
        }
    };
    public static Editor editor;
    public static Typeface georgiar;
    public static Handler handler = new Handler();
    static int i = 0;
    public static Typeface roboto;
    public static SharedPreferences sharedPreferences;
    public static boolean showbool = false;
    public static int showcnt = 0;
    public static boolean startbool = false;
    public static boolean stopbool = false;
    ImageView btnFamily;
    ImageView btnHealth;
    ImageView btnLife;
    ImageView btnLove;
    ImageView btnMoney;
    Intent intent;
    public String selectedCategory;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_actionbar_layout, null);
        sharedPreferences = getApplicationContext().getSharedPreferences("MYPREF", 0);
        editor = sharedPreferences.edit();
        georgiar = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        roboto = Typeface.createFromAsset(getAssets(), "fonts/RobotoSlab-Regular.ttf");
        this.btnLove = findViewById(R.id.ivLove);
        BannerAds();
        this.btnLove.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.intent = new Intent(mainActivity.getApplicationContext(), ChooseCard.class);
                MainActivity.this.intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.loveNrel));
                mainActivity = MainActivity.this;
                mainActivity.selectedCategory = "Love & Relationships";
                mainActivity.intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
                Map hashMap = new HashMap();
                hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
                mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.intent);
            }
        });
        this.btnMoney = findViewById(R.id.ivMoney);
        this.btnMoney.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.intent = new Intent(mainActivity.getApplicationContext(), ChooseCard.class);
                MainActivity.this.intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.money));
                mainActivity = MainActivity.this;
                mainActivity.selectedCategory = "Money";
                mainActivity.intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
                Map hashMap = new HashMap();
                hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
                mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.intent);
            }
        });
        this.btnLife = findViewById(R.id.ivlife);
        this.btnLife.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.intent = new Intent(mainActivity.getApplicationContext(), ChooseCard.class);
                MainActivity.this.intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.life));
                mainActivity = MainActivity.this;
                mainActivity.selectedCategory = "Life";
                mainActivity.intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
                Map hashMap = new HashMap();
                hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
                mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.intent);
            }
        });
        this.btnFamily = findViewById(R.id.ivfamily);
        this.btnFamily.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.intent = new Intent(mainActivity.getApplicationContext(), ChooseCard.class);
                MainActivity.this.intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.familyNfriends));
                mainActivity = MainActivity.this;
                mainActivity.selectedCategory = "Family & Friends";
                mainActivity.intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
                Map hashMap = new HashMap();
                hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
                mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.intent);
            }
        });
        this.btnHealth = findViewById(R.id.ivHealth);
        this.btnHealth.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.intent = new Intent(mainActivity.getApplicationContext(), ChooseCard.class);
                MainActivity.this.intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.health));
                mainActivity = MainActivity.this;
                mainActivity.selectedCategory = "Health";
                mainActivity.intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
                Map hashMap = new HashMap();
                hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
                mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.intent);
            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void stopRunnable() {
        if (stopbool) {
            handler.removeCallbacks(changeAdBool);
        }
    }


    public void onBackPressed() {
        showcnt = 0;
        Intent intent = new Intent(this, SplashActivity.class);
        startActivity(intent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
