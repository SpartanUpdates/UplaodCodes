package com.kotlinz.festivalstorymaker.sticker;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.view.MotionEvent;

public class d implements f {
    @Override
    public void a(final StickerView stickerView, final MotionEvent motionEvent) {
        final e b = stickerView.B;
        if (b != null) {
            b.f(stickerView.t);
            final Matrix g = b.g;
            final PointF t = stickerView.t;
            g.preScale(-1.0f, 1.0f, t.x, t.y);
            b.h ^= true;
            final StickerView.a c = stickerView.C;
            if (c != null) {
                c.d(b);
            }
            stickerView.invalidate();
        }
    }

    @Override
    public void b(final StickerView stickerView, final MotionEvent motionEvent) {
    }

    @Override
    public void c(final StickerView stickerView, final MotionEvent motionEvent) {
    }
}
