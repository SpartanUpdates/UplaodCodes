package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BusinessTemplateAdapter extends RecyclerView.Adapter<BusinessTemplateAdapter.MyViewHolder> {

    Activity activity;
    private ArrayList<CategoryWiseData> festivalFrameResponsesList;
    public a r;
    public int s;

    public BusinessTemplateAdapter(Activity activity, ArrayList<CategoryWiseData> festivalFrameResponsesList, a aVar, int i) {
        this.activity = activity;
        this.festivalFrameResponsesList = festivalFrameResponsesList;
        this.r = aVar;
        this.s = i;
    }

    public interface a {
        void a(int i, int i2);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_highlight_bg_list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.imgLock.setVisibility(View.GONE);
        Glide.with(activity).load(festivalFrameResponsesList.get(position).getThemeThumbnail()).placeholder(R.drawable.progress).fitCenter().into(holder.img);
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.a(position, s);
            }
        });
    }

    @Override
    public int getItemCount() {
        return festivalFrameResponsesList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;
        @BindView(R.id.imgLock)
        public ImageView imgLock;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
