package com.esc.socialmediacleaner.util;

import android.content.Context;

public class AdsToShow {
    private final int[] adsPriority;

    public AdsToShow(Context context) {
        this.adsPriority = new SavedData(context).getAdsPriority();
    }

    public int getAdType(int i) {
        int[] iArr = this.adsPriority;
        if (i > iArr.length) {
            return 10;
        }
        return iArr[i - 1];
    }
}
