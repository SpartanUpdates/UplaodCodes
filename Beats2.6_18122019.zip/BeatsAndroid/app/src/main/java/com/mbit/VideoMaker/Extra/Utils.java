package com.mbit.VideoMaker.Extra;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import com.mbit.VideoMaker.Model.VideoData;
import com.mbit.VideoMaker.application.MyApplication;

import org.json.JSONObject;

import java.io.File;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

public class Utils {
    public static final Utils INSTANCE;
    public static long mDeleteFileCount;
    public static String SongCropCommanPath;
    public static String d;

    static {
        INSTANCE = new Utils();
        Utils.mDeleteFileCount = 0L;
        Utils.SongCropCommanPath = Environment.getExternalStorageDirectory() + File.separator + "Beats" + File.separator + "My Story";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory());
        stringBuilder.append(File.separator);
        stringBuilder.append(MyApplication.e);
        d = stringBuilder.toString();

    }

    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Beats/";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Utils.INSTANCE.getStoryFolderPath();
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }

    public static float dp2px(final Resources resources, final float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(final Resources resources, final float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }

    public static ArrayList<VideoData> getAllCreatedVideoList(Context context) {
        final ArrayList<VideoData> AllVideoList = new ArrayList<>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = context.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPP_FOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoData videoInfo = new VideoData();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    AllVideoList.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
        return AllVideoList;
    }

    public final String getAPP_FOLDER() {
        return "Beats";
    }

    public final String getOutputPath() {
        final String path = String.valueOf(Environment.getExternalStorageDirectory().toString()) + File.separator + this.getAPP_FOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getAudioFolderPath() {
        final String path = String.valueOf(this.getOutputPath()) + "Online Music" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getStoryFolderPath() {
        final String path = String.valueOf(this.getOutputPath()) + "My Story" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getMusicFolderPath() {
        final String path = String.valueOf(this.getOutputPath()) + "Online Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath() {
        final String path = String.valueOf(this.getOutputPath()) + ".ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public String getPostDataString(JSONObject params) throws Exception {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        Iterator<String> itr = params.keys();
        while (itr.hasNext()) {
            String key = itr.next();
            Object value = params.get(key);
            if (first)
                first = false;
            else
                result.append("&");
            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));
        }
        return result.toString();
    }

    public void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                this.deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    public String TimeStampConverter(long milliSeconds) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

}
