package com.esc.socialmediacleaner.loader;

import android.widget.Scroller;

class ScrollerCompatIcs {
    ScrollerCompatIcs() {
    }

    public static float getCurrVelocity(Scroller scroller) {
        return scroller.getCurrVelocity();
    }
}
