package com.esc.dailyrandomfacts.util;


import android.annotation.SuppressLint;
import androidx.lifecycle.GeneratedAdapter;
import androidx.lifecycle.Lifecycle.Event;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MethodCallsLogger;

public class AppLifecycleObserver_LifecycleAdapter implements GeneratedAdapter {
    final AppLifecycleObserver mReceiver;

    AppLifecycleObserver_LifecycleAdapter(AppLifecycleObserver appLifecycleObserver) {
        this.mReceiver = appLifecycleObserver;
    }

    @SuppressLint("RestrictedApi")
    public void callMethods(LifecycleOwner lifecycleOwner, Event event, boolean z, MethodCallsLogger methodCallsLogger) {
        Object obj = methodCallsLogger != null ? 1 : null;
        if (!z) {
            if (event == Event.ON_START) {
                if (obj == null || methodCallsLogger.approveCall("onEnterForeground", 1)) {
                    this.mReceiver.onEnterForeground();
                }
            } else if (event == Event.ON_STOP) {
                if (obj == null || methodCallsLogger.approveCall("onEnterBackground", 1)) {
                    this.mReceiver.onEnterBackground();
                }
            } else {
                if (event == Event.ON_DESTROY && (obj == null || methodCallsLogger.approveCall("onCloseApp", 1))) {
                    this.mReceiver.onCloseApp();
                }
            }
        }
    }
}
