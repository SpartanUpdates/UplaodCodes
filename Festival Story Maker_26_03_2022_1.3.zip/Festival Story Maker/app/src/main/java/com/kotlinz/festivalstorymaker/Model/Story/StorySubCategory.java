package com.kotlinz.festivalstorymaker.Model.Story;

import com.google.gson.annotations.SerializedName;

public class StorySubCategory {
    @SerializedName("response")
    private StoryCategoryResponse mResponse;
    @SerializedName("success")
    private String mSuccess;

    public StoryCategoryResponse getResponse() {
        return mResponse;
    }

    public void setResponse(StoryCategoryResponse response) {
        mResponse = response;
    }

    public String getSuccess() {
        return mSuccess;
    }

    public void setSuccess(String success) {
        mSuccess = success;
    }
}
