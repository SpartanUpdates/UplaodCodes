package com.esc.dailyrandomfacts.util;

import android.content.Context;
import android.graphics.Typeface;
import java.util.Hashtable;

public class FontCache {
    private static Hashtable<String, Typeface> fontCache = new Hashtable();

    public static Typeface get(String str, Context context) {
        Typeface typeface = (Typeface) fontCache.get(str);
        if (typeface == null) {
            try {
                typeface = Typeface.createFromAsset(context.getAssets(), str);
                fontCache.put(str, typeface);
            } catch (Exception unused) {
                return null;
            }
        }
        return typeface;
    }
}
