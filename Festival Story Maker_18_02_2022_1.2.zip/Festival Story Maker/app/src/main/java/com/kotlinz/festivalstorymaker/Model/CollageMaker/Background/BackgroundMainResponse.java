package com.kotlinz.festivalstorymaker.Model.CollageMaker.Background;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class BackgroundMainResponse {

	@SerializedName("background_category_name")
	private String backgroundCategoryName;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("background_cat_id")
	private int backgroundCatId;

	@SerializedName("background_images")
	private ArrayList<BackgroundImagesItem> backgroundImages;

	@SerializedName("background_category_thumbnail")
	private Object backgroundCategoryThumbnail;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public String getBackgroundCategoryName(){
		return backgroundCategoryName;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public int getBackgroundCatId(){
		return backgroundCatId;
	}

	public ArrayList<BackgroundImagesItem> getBackgroundImages(){
		return backgroundImages;
	}

	public Object getBackgroundCategoryThumbnail(){
		return backgroundCategoryThumbnail;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}
}