package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;

public class SetColorList implements ColorListAdapter.a {
    public final  CollageMakerDetailActivity activity;

    public SetColorList(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.activity = collageMakerDetailActivity;
    }

    public final void D(int i) {
        this.activity.D(i);
    }
}
