package com.wavymusic.Favourite.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.Favourite.Fragment.FavouriteFragmentUv;
import com.wavymusic.Favourite.Fragment.FavouriteFragmentWavy;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;

public class FavouriteActivity extends AppCompatActivity {

    Activity activity = FavouriteActivity.this;
    TabLayout tabFavourite;
    ViewPager vpFavourite;
    ImageView ivback;
    private String IsFrom;
    public String IsMian;
    ViewPagerAdapter viewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        IsFrom = getIntent().getStringExtra("IsFrom");
        IsMian = getIntent().getStringExtra("IsMain");
        Log.e("TAG","IsMian"+IsMian);
        ivback = findViewById(R.id.ivBack);
        tabFavourite = findViewById(R.id.tab_favourite);
        tabFavourite.addTab(tabFavourite.newTab().setText("Bits"));
        tabFavourite.addTab(tabFavourite.newTab().setText("SlideShow"));
        vpFavourite = (ViewPager) findViewById(R.id.vp_favourite);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        SetAdapter();
    }


    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class ViewPagerAdapter extends FragmentStatePagerAdapter {
        int mNumOfTabs;

        public ViewPagerAdapter(FragmentManager fm, int NoofTabs) {
            super(fm);
            this.mNumOfTabs = NoofTabs;
        }

        @Override
        public int getCount() {
            return mNumOfTabs;
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    FavouriteFragmentWavy fragmentWavy = new FavouriteFragmentWavy();
                    return fragmentWavy;
                case 1:
                    FavouriteFragmentUv fragmentUv = new FavouriteFragmentUv();
                    return fragmentUv;
                default:
                    return null;
            }
        }
    }

    private void SetAdapter() {
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), tabFavourite.getTabCount());
        vpFavourite.setAdapter(viewPagerAdapter);
        if (IsFrom.equals("Wavy")) {
            vpFavourite.setCurrentItem(0);
        } else {
            vpFavourite.setCurrentItem(1);
        }
        vpFavourite.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabFavourite));
        tabFavourite.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vpFavourite.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}