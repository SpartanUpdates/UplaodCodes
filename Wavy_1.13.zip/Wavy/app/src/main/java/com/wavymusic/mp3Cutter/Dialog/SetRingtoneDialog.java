package com.wavymusic.mp3Cutter.Dialog;

import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.multidex.BuildConfig;
import com.facebook.ads.AdError;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.wavymusic.WidgetView.Indicator;
import com.wavymusic.application.MyApplication;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SetRingtoneDialog extends BottomSheetDialogFragment implements View.OnClickListener {
    public static String Tag = "PlayRingtoneBottomDialog";
    int A = 101;
    public FrameLayout C;
    public MediaPlayer mediaPlayer;
    public Handler handler = new Handler();
    private boolean F = true;
    public Indicator indicator;
    private LinearLayout rootlayout;
    public Context context;
    String songPath;
    String songName;
    TextView tvEndCounter;
    TextView tvStartCounter;
    TextView tvSongName;
    SeekBar Songseekbar;
    ImageView ivPlayPause;
    ImageView ivClose;
    LinearLayout llRingtone;
    LinearLayout llAlarm;
    LinearLayout llContact;
    LinearLayout llShare;
    TextView tvRingtone;
    TextView tvAlarm;
    TextView tvContact;
    TextView tvShare;


    public static SetRingtoneDialog a(String str, String str2) {
        Bundle bundle = new Bundle();
        if (str2.equalsIgnoreCase(BuildConfig.FLAVOR)) {
            str2 = MyApplication.a(str);
        }
        bundle.putString("songName", str2);
        bundle.putString("songPath", str);
        SetRingtoneDialog fVar = new SetRingtoneDialog();
        fVar.setArguments(bundle);
        return fVar;
    }

    private void ShowDialog(final BottomSheetDialog a) {
        final FrameLayout frameLayout = a.findViewById(R.id.design_bottom_sheet);
        final BottomSheetBehavior<FrameLayout> b = BottomSheetBehavior.from(frameLayout);
        final ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
        if (layoutParams != null) {
            layoutParams.height = this.rootlayout.getMeasuredHeight();
        }
        frameLayout.setLayoutParams(layoutParams);
        b.setState(BottomSheetBehavior.STATE_EXPANDED);
    }

    public static void setRingTonePathsdk29(File file, final Context context) {
        OutputStream openOutputStream;
        Throwable th;
        Log.e("Ringtone", "version  29");
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", file.getName());
        contentValues.put("mime_type", "audio/mp3");
        contentValues.put("is_ringtone", true);
        Uri insert = context.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, contentValues);
        try {
            openOutputStream = context.getContentResolver().openOutputStream(insert);
            try {
                byte[] bArr = new byte[((int) file.length())];
                BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
                bufferedInputStream.read(bArr, 0, bArr.length);
                bufferedInputStream.close();
                openOutputStream.write(bArr);
                openOutputStream.close();
                openOutputStream.flush();
            } catch (IOException e2) {
                e2.printStackTrace();
            } catch (Throwable th2) {
                th = th2;
                throw th;
            }
            if (openOutputStream != null) {
                openOutputStream.close();
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        } catch (Throwable th3) {
            th3.printStackTrace();
        }
        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
        ((Activity) context).runOnUiThread(new Runnable() {
            /* class com.example.videostatus.dialog.f.AnonymousClass3 */

            public void run() {
                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
            }
        });
        Log.e("Ringtone", "New Uri : " + insert);
        return;
    }

    public static void setAlarmpath(String str, Context context) {
        if (str != null) {
            try {
                String str2 = Utils.f + File.separator + "Ringtone" + File.separator + "ringtone.mp3";
                File file = new File(str2);
                copyData(str, str2, Utils.f + File.separator + "Ringtone");
                Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(file.getAbsolutePath());
                Cursor query = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, "_data Like ? ", new String[]{file.getAbsolutePath()}, null);
                if (query != null && query.moveToFirst()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(query.getColumnCount());
                    sb.append(BuildConfig.FLAVOR);
                    sb.append(query);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("_data", query.getString(query.getColumnIndex("_data")));
                    contentValues.put("title", query.getString(query.getColumnIndex("title")));
                    contentValues.put("mime_type", query.getString(query.getColumnIndex("mime_type")));
                    contentValues.put("artist", BuildConfig.FLAVOR);
                    contentValues.put("is_ringtone", true);
                    contentValues.put("is_notification", true);
                    contentValues.put("is_alarm", true);
                    contentValues.put("is_music", false);
                    Uri withAppendedId = ContentUris.withAppendedId(contentUriForPath, (long) query.getInt(query.getColumnIndex("_id")));
                    context.getContentResolver().update(withAppendedId, contentValues, "_data=\"" + file.getAbsolutePath() + "\"", null);
                    RingtoneManager.setActualDefaultRingtoneUri(context, 4, withAppendedId);
                    Toast.makeText(context, context.getString(R.string.alarm_seted), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void getData(Bundle bundle) {
        if (bundle != null) {
            this.songPath = bundle.getString("songPath");
            this.songName = bundle.getString("songName");
        }
    }

    private void SetSongPath(String str) {
        Log.e("testplayringtone", "setPlayerData : " + str);
        if (str != null) {
            try {
                Log.e("testplayringtone", "not null call : ");
                setMediaPlayer();
                this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_pause));
                this.indicator.setVisibility(View.VISIBLE);
            } catch (IllegalStateException e2) {
                Log.e("Erronplaysong", e2.getMessage());
                e2.printStackTrace();
                return;
            }
        }
        if (this.songName != null) {
            this.tvSongName.setText(this.songName);
        }
    }

    public static void setRingTonePath(final String str, final Context context) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    if (str != null) {
                        String str = Utils.f + File.separator + "Ringtone" + File.separator + "ringtone.mp3";
                        File file = new File(str);
                        SetRingtoneDialog.copyData(str, str, Utils.f + File.separator + "Ringtone");
                        StringBuilder sb = new StringBuilder();
                        sb.append("path : ");
                        sb.append(str);
                        Log.e("Ringtone", sb.toString());
                        if (Build.VERSION.SDK_INT >= 29) {
                            SetRingtoneDialog.setRingTonePathsdk29(file, context);
                            return;
                        }
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_data", file.getAbsolutePath());
                        contentValues.put("title", BuildConfig.FLAVOR + file.getName());
                        contentValues.put("is_ringtone", true);
                        contentValues.put("mime_type", "audio/mp3");
                        Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath("file://" + file.getAbsolutePath());
                        context.getContentResolver().delete(contentUriForPath, "_data=\"" + file.getAbsolutePath() + "\"", null);
                        Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                        Log.e("Ringtone", "New Uri : " + insert);
                        ((Activity) context).runOnUiThread(new Runnable() {

                            public void run() {
                                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }).start();
    }

    public static void copyData(String str, String str2, String str3) {
        String str4;
        String str5;
        try {
            File file = new File(str3);
            if (!file.exists()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            FileOutputStream fileOutputStream = new FileOutputStream(str2);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (FileNotFoundException e2) {
            str4 = "tag";
            str5 = e2.getMessage();
            Log.e(str4, str5);
        } catch (Exception e3) {
            str4 = "tag";
            str5 = e3.getMessage();
            Log.e(str4, str5);
        }
    }

    private void setListner() {
        this.ivPlayPause.setOnClickListener(this);
        this.Songseekbar.setClickable(false);
        this.llRingtone.setOnClickListener(this);
        this.llAlarm.setOnClickListener(this);
        this.llContact.setOnClickListener(this);
        this.llShare.setOnClickListener(this);
        this.ivClose.setOnClickListener(this);
        this.Songseekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                String str;
                StringBuilder sb;
                TextView textView;
                int ceil = (int) Math.ceil((double) (((float) i) / 1000.0f));
                if (ceil < 10) {
                    textView = SetRingtoneDialog.this.tvStartCounter;
                    sb = new StringBuilder();
                    str = "0:0";
                } else {
                    textView = SetRingtoneDialog.this.tvStartCounter;
                    sb = new StringBuilder();
                    str = "0:";
                }
                sb.append(str);
                sb.append(ceil);
                textView.setText(sb.toString());
                Math.round((((double) i) / ((double) seekBar.getMax())) * ((double) (seekBar.getWidth() - (seekBar.getThumbOffset() * 2))));
//                if (i > 0 && f.this.D != null && !f.this.D.isPlaying()) {
//                    f.this.q.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_play));
//                    f.this.p.setProgress(0);
//                }
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                if (SetRingtoneDialog.this.mediaPlayer != null && SetRingtoneDialog.this.mediaPlayer.isPlaying()) {
                    SetRingtoneDialog.this.mediaPlayer.seekTo(seekBar.getProgress());
                }
            }
        });
    }

    private void setMediaPlayer() {
        try {
            if (this.mediaPlayer == null || !this.mediaPlayer.isPlaying()) {
                if (this.mediaPlayer == null) {
                    this.mediaPlayer = MediaPlayer.create(this.context, Uri.parse(this.songPath));
                    this.mediaPlayer.start();
                    this.indicator.setVisibility(View.VISIBLE);
                    this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                        public void onCompletion(MediaPlayer mediaPlayer) {
                            SetRingtoneDialog.this.handler.removeCallbacksAndMessages(null);
                            SetRingtoneDialog.this.mediaPlayer.stop();
                            SetRingtoneDialog.this.mediaPlayer.reset();
                            SetRingtoneDialog.this.mediaPlayer = null;
                            SetRingtoneDialog.this.Songseekbar.setProgress(0);
                            SetRingtoneDialog.this.tvStartCounter.setText("0:00");
                            SetRingtoneDialog.this.handler.removeCallbacksAndMessages(null);
                            SetRingtoneDialog.this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_play));
                            SetRingtoneDialog.this.indicator.setVisibility(View.GONE);
                        }
                    });
                    this.Songseekbar.setMax(this.mediaPlayer.getDuration() / 100);
                    tvEndCounter.setText("0:" + (this.mediaPlayer.getDuration() / AdError.NETWORK_ERROR_CODE) + BuildConfig.FLAVOR);
                    ((Activity) this.context).runOnUiThread(new Runnable() {

                        public void run() {
                            String str;
                            StringBuilder sb;
                            if (SetRingtoneDialog.this.mediaPlayer != null) {
                                SetRingtoneDialog.this.Songseekbar.setProgress(SetRingtoneDialog.this.mediaPlayer.getCurrentPosition() / 100);
                                int ceil = (int) Math.ceil((double) (SetRingtoneDialog.this.mediaPlayer.getCurrentPosition() / AdError.NETWORK_ERROR_CODE));
                                if (ceil < 10) {
                                    sb = new StringBuilder();
                                    str = "0:0";
                                } else {
                                    sb = new StringBuilder();
                                    str = "0:";
                                }
                                sb.append(str);
                                sb.append(ceil);
                                tvStartCounter.setText(sb.toString());
                            }
                            SetRingtoneDialog.this.handler.postDelayed(this, 100);
                        }
                    });
                    this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_pause));
                } else {
                    this.mediaPlayer.start();
                    this.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                        public void onCompletion(MediaPlayer mediaPlayer) {
                            SetRingtoneDialog.this.handler.removeCallbacksAndMessages(null);
                            SetRingtoneDialog.this.mediaPlayer.stop();
                            SetRingtoneDialog.this.mediaPlayer.reset();
                            SetRingtoneDialog.this.mediaPlayer = null;
                            SetRingtoneDialog.this.Songseekbar.setProgress(0);
                            SetRingtoneDialog.this.tvStartCounter.setText("0:00");
                            SetRingtoneDialog.this.handler.removeCallbacksAndMessages(null);
                            SetRingtoneDialog.this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_play));
                            SetRingtoneDialog.this.indicator.setVisibility(View.GONE);
                        }
                    });
                    this.Songseekbar.setMax(this.mediaPlayer.getDuration() / 100);
                    tvEndCounter.setText("0:" + (this.mediaPlayer.getDuration() / AdError.NETWORK_ERROR_CODE) + BuildConfig.FLAVOR);
                    ((Activity) this.context).runOnUiThread(new Runnable() {

                        public void run() {
                            String str;
                            StringBuilder sb;
                            if (SetRingtoneDialog.this.mediaPlayer != null) {
                                SetRingtoneDialog.this.Songseekbar.setProgress(SetRingtoneDialog.this.mediaPlayer.getCurrentPosition() / 100);
                                int ceil = (int) Math.ceil((double) (SetRingtoneDialog.this.mediaPlayer.getCurrentPosition() / AdError.NETWORK_ERROR_CODE));
                                if (ceil < 10) {
                                    sb = new StringBuilder();
                                    str = "0:0";
                                } else {
                                    sb = new StringBuilder();
                                    str = "0:";
                                }
                                sb.append(str);
                                sb.append(ceil);
                                tvStartCounter.setText(sb.toString());
                            }
                            SetRingtoneDialog.this.handler.postDelayed(this, 100);
                        }
                    });
                    this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_pause));
                }
                indicator.setVisibility(View.VISIBLE);
                return;
            }
            this.mediaPlayer.pause();
            this.handler.removeCallbacksAndMessages(null);
            this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_play));
            this.indicator.setVisibility(View.GONE);
        } catch (IllegalStateException e2) {
            e2.printStackTrace();
        }
    }

    private void setAlarm() {
        Log.e("TagTest", "setAsAlarmRingtone");
        try {
            if (this.songPath != null) {
                Log.e("TagTest", "songPath=>" + this.songPath);
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                    } else if (h() && this.songPath != null) {
                        Log.e("rrpath", this.songPath);
                    } else {
                        return;
                    }
                    setAlarmpath(songPath, context);
                } catch (Exception e2) {
                    e2.printStackTrace();
                    Log.e("TagTest", "setAsAlarmRingtone Exce=>" + e2.getMessage());
                    Log.e("rrpath", e2.getMessage());
                    Toast.makeText(context, getString(R.string.unable_to_set_alarm_ringtone), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    private void setRingTone() {
        String str;
        try {
            if (this.songPath != null) {
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                        str = this.songPath;
                    } else if (h() && this.songPath != null) {
                        Log.e("rrpath", this.songPath);
                        str = this.songPath;
                    } else {
                        return;
                    }
                    setRingTonePath(str, context);
                } catch (Exception e2) {
                    e2.printStackTrace();
                    Log.e("rrpath", e2.getMessage());
                    Toast.makeText(context, getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    private boolean h() {
        if (Build.VERSION.SDK_INT < 23) {
            return false;
        }
        if (Settings.System.canWrite(this.context)) {
            return true;
        }
        Setting();
        return false;
    }

    private void Setting() {
        if (Build.VERSION.SDK_INT >= 23) {
            Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
            intent.setData(Uri.parse("package:" + this.context.getPackageName()));
            getActivity().startActivityForResult(intent, 111);
        }
    }

    public void setFont(TextView textView) {
        textView.setTypeface(Typeface.createFromAsset(this.context.getAssets(), "fonts/OpenSans_Regular.ttf"));
    }

    public void Share(String str) {
        File file = new File(str);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("audio/*");
        intent.putExtra("android.intent.extra.SUBJECT", this.context.getString(R.string.app_name));
        intent.putExtra("android.intent.extra.TEXT", " Get Popular Ringtone at Wavy Music https://play.google.com/store/apps/details?id=" + this.context.getPackageName());
        intent.putExtra("android.intent.extra.TITLE", "Wavy Music : Particle.ly Video Status Maker");
        final Uri ShareUri = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", file);
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(intent, context.getString(R.string.share_audio)));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivClose :
//                dismiss();
                dismiss();
                return;
            case R.id.ivPlayPause :
                try {
                    setMediaPlayer();
                    return;
                } catch (Exception e2) {
                    e2.printStackTrace();
                    return;
                }
            case R.id.llAlarm :
                setAlarm();
                return;
            case R.id.llContact :
            default:
                return;
            case R.id.llRingtone :
                MyApplication.aF = this.songPath;
                setRingTone();
                return;
            case R.id.llShare :
                Share(this.songPath);
                return;
        }
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        setCancelable(false);
        return layoutInflater.inflate(R.layout.play_ringtone_bottom_dialog, viewGroup, false);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
    }

    @Override
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
    }

    @Override
    public void onPause() {
        super.onPause();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer == null) {
            return;
        }
        if (mediaPlayer.isPlaying()) {
            this.F = true;
            this.mediaPlayer.pause();
            return;
        }
        this.F = false;
    }

    @Override
    public void onResume() {
        super.onResume();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            this.ivPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.icon_player_play));
            this.indicator.setVisibility(View.GONE);
        }
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        getData(getArguments());
        if (getDialog() != null) {
            getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {

                public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                    if (i != 4) {
                        return false;
                    }
                    SetRingtoneDialog.this.onDetach();
                    return true;
                }
            });
        }
        Songseekbar = view.findViewById(R.id.seekbarSong);
        tvStartCounter = view.findViewById(R.id.tvStartCounter);
        tvEndCounter = view.findViewById(R.id.tvEndCounter);
        tvSongName = view.findViewById(R.id.tvSongName);
        ivPlayPause = view.findViewById(R.id.ivPlayPause);
        llRingtone = view.findViewById(R.id.llRingtone);
        llAlarm = view.findViewById(R.id.llAlarm);
        llContact = view.findViewById(R.id.llContact);
        llShare = view.findViewById(R.id.llShare);
        indicator = view.findViewById(R.id.animation);
        tvRingtone = view.findViewById(R.id.tvRingtone);
        tvShare = view.findViewById(R.id.tvShare);
        tvAlarm = view.findViewById(R.id.tvAlarm);
        tvContact = view.findViewById(R.id.tvContact);
        ivClose = view.findViewById(R.id.ivClose);
        rootlayout = view.findViewById(R.id.root_layout);
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {

            public void onShow(DialogInterface dialogInterface) {
                SetRingtoneDialog.this.ShowDialog((BottomSheetDialog) dialogInterface);

            }
        });
        setListner();
        setFont(this.tvRingtone);
        setFont(this.tvAlarm);
        setFont(this.tvContact);
        setFont(this.tvShare);
        SetSongPath(this.songPath);
    }
}