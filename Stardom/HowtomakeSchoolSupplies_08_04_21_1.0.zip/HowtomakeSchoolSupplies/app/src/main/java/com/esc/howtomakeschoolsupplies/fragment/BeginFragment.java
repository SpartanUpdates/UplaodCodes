package com.esc.howtomakeschoolsupplies.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.TextView;
import com.esc.howtomakeschoolsupplies.R;
import com.esc.howtomakeschoolsupplies.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import java.util.HashMap;
import kotlin.jvm.internal.Intrinsics;

public class BeginFragment extends Fragment implements View.OnClickListener {
    private HashMap findViewCache;
    private EventBeginFragment mEventBeginFragment;
    private MediaPlayer mp;
    private ImageButton btn_start;
    private ImageButton img_favorite;
    private TextView tvprivacy_policy;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    public interface EventBeginFragment {
        void onClickBtnBegin();

        void onClickBtnFavorite();
    }

    public void ClearFindViewByIdCache() {
        HashMap hashMap = this.findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public void onDestroyView() {
        super.onDestroyView();
        ClearFindViewByIdCache();
    }

    public void onAttach(Context context) {
        Intrinsics.checkParameterIsNotNull(context, "context");
        super.onAttach(context);
        this.mEventBeginFragment = (EventBeginFragment) context;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.fragment_begin, viewGroup, false);
        Intrinsics.checkExpressionValueIsNotNull(inflate, "inflater.inflate(R.layou…_begin, container, false)");
        btn_start = inflate.findViewById(R.id.btn_start);
        img_favorite = inflate.findViewById(R.id.img_favorite);
        tvprivacy_policy = inflate.findViewById(R.id.tvprivacy_policy);
        Intrinsics.checkExpressionValueIsNotNull(tvprivacy_policy, "rootView.privacy_policy");
        Context activity = getActivity();
        Resources resources = getResources();
        FragmentActivity requireActivity = requireActivity();
        Intrinsics.checkExpressionValueIsNotNull(requireActivity, "requireActivity()");
        MediaPlayer create = MediaPlayer.create(activity, resources.getIdentifier("click2", "raw", requireActivity.getPackageName()));
        Intrinsics.checkExpressionValueIsNotNull(create, "MediaPlayer.create(\n    …().packageName)\n        )");
        this.mp = create;

        loadAd();

        if (tvprivacy_policy == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mPrivacyPolicy");
        }

        Animation loadAnimation2 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon1);
        Animation loadAnimation3 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon2);
        Animation loadAnimation4 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon3);
        inflate.findViewById(R.id.cont_button_favorite).startAnimation(loadAnimation2);
        inflate.findViewById(R.id.rl_start).startAnimation(loadAnimation3);
        inflate.findViewById(R.id.icon).startAnimation(loadAnimation4);
        btn_start.setOnClickListener(this);
        img_favorite.setOnClickListener(this);
        tvprivacy_policy.setOnClickListener(this);
        return inflate;
    }

    EventBeginFragment eventBeginFragment;
    String str = "mEventBeginFragment";
    public void onClick(View view) {
        Intrinsics.checkParameterIsNotNull(view, "view");
        MediaPlayer mediaPlayer = this.mp;
        if (mediaPlayer == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mp");
        }
        mediaPlayer.start();

        switch (view.getId()) {
            case R.id.btn_start:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(getActivity())
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    eventBeginFragment = this.mEventBeginFragment;
                    if (eventBeginFragment == null) {
                        Intrinsics.throwUninitializedPropertyAccessException(str);
                    }
                    eventBeginFragment.onClickBtnBegin();
                }
                return;

            case R.id.img_favorite:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(getActivity())
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                id = 101;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    eventBeginFragment = this.mEventBeginFragment;
                    if (eventBeginFragment == null) {
                        Intrinsics.throwUninitializedPropertyAccessException(str);
                    }
                    eventBeginFragment.onClickBtnFavorite();
                }
                return;

            case R.id.tvprivacy_policy:
                try {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                    startActivity(intent1);
                }catch (Exception e)
                {
                    e.printStackTrace();
                }

                return;
            default:
                return;
        }
    }

    private void loadAd() {

        if(isAdded())
        {
            //interstitial FullScreenAd
            interstitialAd = new InterstitialAd(getActivity());
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.setAdListener(new AdListener() {
                @SuppressLint("WrongConstant")
                @Override
                public void onAdClosed() {
                    switch (id) {
                        case 100:
                            eventBeginFragment = mEventBeginFragment;
                            if (eventBeginFragment == null) {
                                Intrinsics.throwUninitializedPropertyAccessException(str);
                            }
                            eventBeginFragment.onClickBtnBegin();
                            break;

                        case 101:
                            eventBeginFragment = mEventBeginFragment;
                            if (eventBeginFragment == null) {
                                Intrinsics.throwUninitializedPropertyAccessException(str);
                            }
                            eventBeginFragment.onClickBtnFavorite();
                            break;
                    }
                    requestNewInterstitial();
                }

                public void onAdFailedToLoad(int errorCode) {
                    super.onAdFailedToLoad(errorCode);
                }
            });
            interstitialAd.loadAd(new AdRequest.Builder().build());
        }
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(getActivity());
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
