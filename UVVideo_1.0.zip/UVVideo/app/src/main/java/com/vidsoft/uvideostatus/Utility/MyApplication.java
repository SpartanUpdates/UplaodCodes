package com.vidsoft.uvideostatus.Utility;

import android.app.Application;

public class MyApplication extends Application {
    public void onCreate() {
        super.onCreate();
        TypefaceUtil.overrideFont(getApplicationContext(), "SERIF", "helvetica_neue_regular.ttf");

    }
}
