﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerController : MonoBehaviour
{
    public static PlayerController instance;

    public float _playerSpeed;

    private float prevTouchPos;

    private bool bPressed;

    int SwapSensitive;

    int totalCoin = 0;

    public GameObject lastTouchObject;

    Vector3 normalGravity = new Vector3(0, -9.11f, 0), HighGravity = new Vector3(0, -5000f, 0);
   
    public Transform rayPos;

    public Vector3 platfromPos;
    void Awake()
    {
        instance = this;
        SwapSensitive = PlayerPrefs.GetInt("SwapSensitive");
    }

    void Update()
    {
        if (!GameManager.instance.isGameOver && !GameManager.instance.isGameFinish)
        {
            RaycastHit hit;
            if (Physics.Raycast(rayPos.position, -Vector3.up * 2, out hit))
            {
                if (hit.collider.CompareTag("Platfrom"))
                {
                    Physics.gravity = normalGravity;
                    platfromPos = hit.transform.position;
                }
                else
                    Physics.gravity = HighGravity;
            }
        }
    }
  
    Vector3 localCameraPosition;

    float num, num2, tempX;

    float roadWith = 8;
   
    Touch touch;

    void FixedUpdate()
    {
        if (!GameManager.instance.isGameOver && !GameManager.instance.isGameFinish)
        {
#if UNITY_ANDROID && !UNITY_EDITOR

            if (Input.touchCount == 1)
            {
                 touch = Input.GetTouch(0);
                    num = UnityEngine.Input.mousePosition.x / (float)Screen.width;

                switch (touch.phase)
                {
                    case TouchPhase.Began:
                        this.prevTouchPos = num;
                        this.bPressed = true;
                        if (GameManager.instance.pressMeText.activeSelf)
                        {
                            if(!Manager.instance.isOneTimePlay)
                                GameManager.instance.pressMeText.gameObject.SetActive(false);
                            Manager.instance.isOneTimePlay = true;
                        }
                        break;

                    case TouchPhase.Moved:

                        if (this.bPressed)
                        {
                            num2 = (num - this.prevTouchPos) * (float)Screen.width * Time.deltaTime;
                            num2 *= SwapSensitive;
                            this.prevTouchPos = num;
                            tempX = this.transform.localPosition.x;
                            if ((tempX + num2) < -roadWith)
                            {
                                num2 = -roadWith - tempX;
                            }
                            else if ((tempX + num2) > roadWith)
                            {
                                num2 = roadWith - tempX;
                            }
                            this.transform.Translate(num2 * Time.deltaTime * 20, 0f, 0f);
                        }
                        else
                        {
                            this.prevTouchPos = num;
                            this.bPressed = true;
                        }
                        break;

                    case TouchPhase.Ended:
                        this.bPressed = false;
                        break;
                }
            }
#endif
#if UNITY_EDITOR
            num = UnityEngine.Input.mousePosition.x / (float)Screen.width;
            if (Input.GetMouseButtonDown(0))
            {
                this.prevTouchPos = num;
                this.bPressed = true;
                if (GameManager.instance.pressMeText.activeSelf)
                {
                    if(!Manager.instance.isOneTimePlay)
                        GameManager.instance.pressMeText.gameObject.SetActive(false);
                    Manager.instance.isOneTimePlay = true;
                }
            }
            else if (Input.GetMouseButton(0))
            {
                if (this.bPressed)
                {
                    num2 = (num - this.prevTouchPos) * (float)Screen.width * Time.deltaTime;
                    num2 *= SwapSensitive;
                    this.prevTouchPos = num;
                    tempX = this.transform.localPosition.x;
                    if ((tempX + num2) < -roadWith)
                    {
                        num2 = -roadWith - tempX;
                    }
                    else if ((tempX + num2) > roadWith)
                    {
                        num2 = roadWith - tempX;
                    }
                    this.transform.Translate(num2 * Time.deltaTime * 20, 0f, 0f);
                }
                else
                {
                    this.prevTouchPos = num;
                    this.bPressed = true;
                }
            }
            else if (Input.GetMouseButtonUp(0))
            {
                this.bPressed = false;
            }
            else
            {
                this.bPressed = false;
            }
#endif
            transform.position += transform.forward * _playerSpeed;

            localCameraPosition = Camera.main.transform.localPosition;
            localCameraPosition.x = (this.transform.localPosition.x / 2f) * Time.deltaTime * 40;
            Camera.main.transform.localPosition = localCameraPosition;
        }
    }

    public bool isObstacleTouch=false,isBaseObstacle=false;

    public Vector3 endPos;

    public Animator rubberAnimator;
    void OnCollisionEnter(Collision target)
    {
        if (target.gameObject.CompareTag("Obstacle"))
        {
            if (!GameManager.instance.isGameOver)
            {
                SoundManger.instance.objHit.Play();
                SoundManger.instance.bgPlayMusic.Stop();
                endPos = transform.position;
                Physics.gravity = normalGravity;
                this.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
                this.GetComponent<Rigidbody>().AddRelativeForce(-Vector3.forward * 5, ForceMode.Impulse);
                GameOverEffect(target.gameObject);
            }
        }
        if (target.gameObject.CompareTag("Finish"))
        {
            target.collider.enabled = false;
            SoundManger.instance.gameFinish.Play();
            SoundManger.instance.bgPlayMusic.Stop();
            rubberAnimator.Play("RubberFinish");
            GameManager.instance.GameFinished();
        }
    }
    void GameOverEffect(GameObject temps)
    {
        GameManager.instance.GameOver();
        SoundManger.instance.gameOver.PlayDelayed(0.5f);

        lastTouchObject = temps.gameObject;

        GameObject lastTouchObject4 = FindParentWithTag(temps.gameObject, "Obstacle");

        if (lastTouchObject4 != null)
            lastTouchObject = lastTouchObject4;
        if (temps.gameObject.name == "BaseObstacle")
            isBaseObstacle = true;
        else
            isObstacleTouch = true;
    }
    void OnTriggerEnter(Collider target)
    {
        if (target.gameObject.CompareTag("Obstacle"))
        {
            if (!GameManager.instance.isGameOver)
            {
                SoundManger.instance.bgPlayMusic.Stop();
                endPos = transform.position;
                GameOverEffect(target.gameObject);
            }
        }
        if (target.CompareTag("PowerUp"))
        {
            SoundManger.instance.inkGet.Play();
            SoundManger.instance.Vibrate();
            GameManager.instance.maxParticles += Random.Range(700, 1000);
            GameManager.instance.distanceImage.GetComponentInParent<Animator>().Play("barDistance2");
            GameManager.instance.StartCoroutine("LifeLinePowerUp", 0.1f);
            Destroy(target.gameObject);
        }
        if (target.CompareTag("Coins"))
        {
            target.gameObject.GetComponent<BoxCollider>().enabled = false;
            SoundManger.instance.coinGet.Play();
            SoundManger.instance.Vibrate();
            PlayerPrefs.SetInt("Coins", PlayerPrefs.GetInt("Coins") + 10);
            totalCoin+=10;
            GameManager.instance.levelScore.text = totalCoin + "";
        }
        if (target.CompareTag("Keys"))
        {
            SoundManger.instance.keyGet.Play();
            SoundManger.instance.Vibrate();
            GameManager.instance.isKeyInsti = false;
            GameManager.instance.isKeyOneTime = false;
            PlayerPrefs.SetInt("KeyLevel0" + PlayerPrefs.GetInt("LevelNumber"), 1);
            PlayerPrefs.SetInt("KeyCount", PlayerPrefs.GetInt("KeyCount") + 1);
        }
    }

    void OnDestroy()
    {
        Time.timeScale = 1;
    }
    public static GameObject FindParentWithTag(GameObject childObject, string tag)
    {
        Transform t = childObject.transform;
        while (t.parent != null)
        {
            if (t.parent.tag == tag)
            {
                return t.parent.gameObject;
            }
            t = t.parent.transform;
        }
        return null;
    }
}
