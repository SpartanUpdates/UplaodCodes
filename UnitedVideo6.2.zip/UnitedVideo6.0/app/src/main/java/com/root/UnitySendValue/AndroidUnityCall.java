package com.root.UnitySendValue;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import com.UnitedVideos.ArrangeImages.activity.ArrangePhotosActivityUv;
import com.UnitedVideos.ImageSelection.activity.SelectImageActivityUv;
import com.UnitedVideos.SongSelection.activity.DefaultSongActivityUv;
import com.UnitedVideos.TextChange.activity.TextEditActivityUv;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.ContentLanguage.activity.LanguageSelectActivity;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.DashBord.activity.ThemeAllActivityUv;
import com.wavymusic.DashBord.activity.ThemeAllActivityWavy;
import com.wavymusic.ImageSelection.activity.SelectImageActivity;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.ShareVideo.activity.ShareActivity;
import com.wavymusic.SongSelection.activity.SongSelectActivity;
import com.wavymusic.TextChange.activity.TextEditActivity;
import com.wavymusic.UnityPlayerActivity;

import java.io.File;

public class AndroidUnityCall {

    /*Wavy Music Start */
    public static void HomeActivity(Context context) {
       /* if (LanguagePref.a(context).a("pref_key_is_language_set", false)) {
            if (MyApplication.IsHomeAdsDisplay) {
                loadHomeActivityWithAds(context);
            } else {
                loadHomeActivity(context);
            }
        }
        else {
            Intent intent = new Intent(context, LanguageSelectActivity.class);
            context.startActivity(intent);
        }*/
        if (MyApplication.IsHomeAdsDisplay) {
            loadHomeActivityWithAds(context);
        } else {
            loadHomeActivity(context);
        }
    }

    private static void loadHomeActivityWithAds(final Context context) {
        MyApplication.AppLaunchContex = context;
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                if (MyApplication.IsHomeAdsDisplay && MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
                    MyApplication.IsHomeAdsDisplay = true;
                    MyApplication.fbinterstitialAd.show();
                } else {
                    loadHomeActivity(context);
                }
            }
        });
    }

    public static void loadHomeActivity(Context context) {
     /*   Intent intent = new Intent(context, HomeActivity.class);
        intent.putExtra("IsFromLanguage", false);
        intent.putExtra("IsFromMain", true);
        context.startActivity(intent);*/
        Intent intent = new Intent(context, DashbordActivity.class);
        intent.putExtra("IsFromLanguage", false);
        intent.putExtra("IsFromMain", true);
        context.startActivity(intent);
    }

    public static void OpenGallery(Context context) {
        MyApplication.IsSelectImageFrom = false;
        MyApplication.TotalSelectedImage = 6;
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, SelectImageActivity.class);
        intent.putExtra("NoofImage", 6);
        context.startActivity(intent);
    }

    public static void SelectSong(Context context) {
        context.startActivity(new Intent(context, SongSelectActivity.class));
    }

    public static void ChangeName(Context context, String str) {
        Intent intent = new Intent(context, TextEditActivity.class);
        intent.putExtra("JsonStr", str);
        context.startActivity(intent);
    }

    public static void PlayVideo(final Context context, final String VideoPath) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                UnityPlayerActivity.unityPlayeractivity.particalCatAdapter.selectedPosition = -1;
                UnityPlayerActivity.unityPlayeractivity.particalItemAdapter.selectedPosition = -1;
                String path = Utils.INSTANCE.getStoryFolderPath() + VideoPath;
                MyApplication.VidoePath = path.substring(path.lastIndexOf("/") + 1);
                Intent intent = new Intent(context, ShareActivity.class);
                intent.putExtra("VideoUrl", path);
                intent.putExtra("VideoPosition", 0);
                intent.putExtra("IsVideoFromAndroidList", false);
                context.startActivity(intent);
                ScanVideoList(context, Utils.INSTANCE.getStoryFolderPath() + File.separator + MyApplication.VidoePath);
                ClearSelection(context);
                AppGeneral.LastTime = 0.0f;
                DeleteCropImages();
            }
        }, 100);
    }


    public static void createVideo(final Context context, final String videoInputName, final String VideoOutputName) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                AppGeneral.AudioVideoShort(context, videoInputName, VideoOutputName);
            }
        }, 100);
    }

    public static void prepareSongForCreateVideo(Context context, String VideoOutNameMute, String fromSdcard, String AudioInputpath, String VideoInputNameUnited) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        AppGeneral.AddSongTOVideo(context, VideoOutNameMute, fromSdcard, AudioInputpath, VideoInputNameUnited);
    }

    public static void BackToMain(final Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                ((Activity) context).runOnUiThread(new Runnable() {
                    public final void run() {
                        UnityPlayerActivity.unityPlayeractivity.HideParticalWavy();
                        UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutWavy();
                        UnityPlayerActivity.unityPlayeractivity.DeSelectButton();
                    }
                });
                AndroidUnityCall.showClose(context);
                UnityPlayerActivity.unityPlayeractivity.particalCatAdapter.selectedPosition = -1;
                UnityPlayerActivity.unityPlayeractivity.particalItemAdapter.selectedPosition = -1;
                AndroidUnityCall.ClearSelection(context);
            }
        });
    }

    public static void BackToMainWavyViewAll(final Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                ((Activity) context).runOnUiThread(new Runnable() {
                    public final void run() {
                        UnityPlayerActivity.unityPlayeractivity.HideParticalWavy();
                        UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutWavy();
                        UnityPlayerActivity.unityPlayeractivity.DeSelectButton();
                    }
                });
                AndroidUnityCall.showCloseWavyViewAll(context);
                UnityPlayerActivity.unityPlayeractivity.particalCatAdapter.selectedPosition = -1;
                UnityPlayerActivity.unityPlayeractivity.particalItemAdapter.selectedPosition = -1;
                AndroidUnityCall.ClearSelection(context);
            }
        });
    }

    public static void CloseFilterPanel(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HideFilterPanelWavy();
            }
        });
    }

    public static void GoToPreview(Context context) {
        try {
            ((Activity) context).runOnUiThread(new Runnable() {
                public final void run() {
                    UnityPlayerActivity.unityPlayeractivity.ShowBottomPanelLayoutWavy();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void HideLyricStyles(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.StyleGoneWithoutAnimation();
                UnityPlayerActivity.unityPlayeractivity.HideParticalWavy();
                UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutWavy();
                UnityPlayerActivity.unityPlayeractivity.SetSelection(false, false);
            }
        });
    }

    /*Wavy Music End*/

    /*United Video Start */
    public static void HomeActivityUv(final Context cntx) {
        Intent i = new Intent(cntx, DashbordActivity.class);
        cntx.startActivity(i);
    }

    public static void ImageSelectionUv(Context cntx, int width, int hight, int numOfImages, String isCut, String IsFrom) {
        MyApplication.TotalSelectedImage = numOfImages;
        Intent intent = new Intent(cntx, SelectImageActivityUv.class);
        intent.putExtra("hight", hight);
        intent.putExtra("width", width);
        intent.putExtra("isCut", isCut);
        intent.putExtra("isfrom", IsFrom);
        cntx.startActivity(intent);
    }

    public static void ImageSelectionForFbAdsCloseUv(Context cntx, int width, int hight, int numOfImages, String isCut, boolean imageupdate, String IsFrom) {
        MyApplication.TotalSelectedImage = numOfImages;
        Intent intent = new Intent(cntx, SelectImageActivityUv.class);
        intent.putExtra("hight", hight);
        intent.putExtra("width", width);
        intent.putExtra("isCut", isCut);
        intent.putExtra("Imageupdate", imageupdate);
        intent.putExtra("isfrom", IsFrom);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        cntx.startActivity(intent);
    }

    public static void ArrangeActivityUv(Context context, boolean arrange) {
        Intent i = new Intent(context, ArrangePhotosActivityUv.class);
        i.putExtra("Imagearrange", arrange);
        context.startActivity(i);
    }

    public static void SongSelectionUv(Context cntx) {
        Intent i = new Intent(cntx, DefaultSongActivityUv.class);
        cntx.startActivity(i);
    }

    public static void ChangeNameUv(Context context, String JsonData) {
        Intent intent = new Intent(context, TextEditActivityUv.class);
        intent.putExtra("JsonStr", JsonData);
        context.startActivity(intent);
    }

    public static void VideoPlayActivityUv(final Context context, final String VideoPath) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                String path = Utils.INSTANCE.getStoryFolderPath() + VideoPath;
                MyApplication.VidoePath = path.substring(path.lastIndexOf("/") + 1);
                Intent intent = new Intent(context, ShareActivity.class);
                intent.putExtra("VideoUrl", path);
                intent.putExtra("VideoPosition", 0);
                intent.putExtra("IsVideoFromAndroidList", false);
                context.startActivity(intent);
                ScanVideoList(context, Utils.INSTANCE.getStoryFolderPath() + File.separator + MyApplication.VidoePath);
                AndroidUnityCall.ClearSelectionUv(context);
                AppGeneral.LastTime = 0.0f;
                DeleteCropImages();
                ;
            }
        }, 100);
    }

    public static void GoToPreviewUv(Context context) {
        try {
            ((Activity) context).runOnUiThread(new Runnable() {
                public final void run() {
                    UnityPlayerActivity.unityPlayeractivity.ShowBottomPanelLayoutUv();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void HideBottomDataUv(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutUv();
            }
        });
    }

    public static void BackToMainUv(final Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutUv();
                AndroidUnityCall.showClose(context);
            }
        });
    }
    public static void BackToMainUvViewAll(final Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HideBottomPanelLayoutUv();
                AndroidUnityCall.showCloseUvViewAll(context);
            }
        });
    }

    public static void createVideoUv(final Context context, final String VideoMuteName, final String VideoFinalName) {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                AppGeneral.AudioVideoShortUv(context, VideoMuteName, VideoFinalName);
            }
        }, 100);
    }

    public static void prepareSongForCreateVideoUv(final Context context, String AudioTime, String VideoMuteName, String FromSdCard, String AudioInputPath, String VideoFinalName) {
        AppGeneral.AddSongTOVideoUv(context, AudioTime, VideoMuteName, FromSdCard, AudioInputPath, VideoFinalName);
    }
    /*United Video End*/

    /*Common Method For Both Plugin Start*/
    public static void PutLog(Context context, String value) {
        Log.e("TAG", "TextValue" + value);
    }

    public static void HideBannerAds(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void ClearSelection(Context context) {
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImages().clear();
    }

    public static void ClearSelectionUv(Context context) {
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImagesUV().clear();
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + "CropTempImg" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void ScanVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showClose(final Context context) {
        Intent intent = new Intent(context, DashbordActivity.class);
        context.startActivity(intent);
    }
    private static void showCloseWavyViewAll(final Context context) {
        Intent intent = new Intent(context, ThemeAllActivityWavy.class);
        context.startActivity(intent);
    }
    private static void showCloseUvViewAll(final Context context) {
        Intent intent = new Intent(context, ThemeAllActivityUv.class);
        context.startActivity(intent);
    }
    /*Common Method For Both Plugin End*/
}
