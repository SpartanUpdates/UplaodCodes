package com.kotlinz.videoCollage.interfaces;

import android.graphics.Bitmap;

public interface OnSetImageStickerInterface {
    void onGetSticker(Bitmap bitmap);
}
