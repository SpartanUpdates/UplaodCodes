package com.xyz.vehiclemanager.bikedetails.bikedealer.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeDealer
{
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("data")
    public ArrayList<BikeDealer> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("dealerName")
    public String dealerName;
    @SerializedName("dealerAddress")
    public String dealerAddress;
    @SerializedName("dealerContactNo")
    public String dealerContactNo;

    public BikeDealer() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDealerName() {
        return dealerName;
    }

    public void setDealerName(String dealerName) {
        this.dealerName = dealerName;
    }

    public String getDealerAddress() {
        return dealerAddress;
    }

    public void setDealerAddress(String dealerAddress) {
        this.dealerAddress = dealerAddress;
    }

    public String getDealerContactNo() {
        return dealerContactNo;
    }

    public void setDealerContactNo(String dealerContactNo) {
        this.dealerContactNo = dealerContactNo;
    }

    public ArrayList<BikeDealer> getData() {
        return data;
    }

    public void setData(ArrayList<BikeDealer> data) {
        this.data = data;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
