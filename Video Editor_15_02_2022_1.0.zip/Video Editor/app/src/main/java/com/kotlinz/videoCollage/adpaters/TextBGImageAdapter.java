package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.TextBGImageAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class TextBGImageAdapter extends Adapter<TextBGImageAdapter.ViewHolder> {
    private Context context;
    private ArrayList<String> listImage;
    private TextBGImageAdapterCallBackInterface listener;
    private int pos = 0;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgTextBgImage;
        ImageView imgTextBgImageSelector;

        ViewHolder(View view) {
            super(view);
            this.imgTextBgImage = (ImageView) view.findViewById(R.id.img_txet_bg_image);
            this.imgTextBgImageSelector = (ImageView) view.findViewById(R.id.img_text_bg_image_selector);
        }
    }

    public TextBGImageAdapter(ArrayList<String> arrayList, Context context, TextBGImageAdapterCallBackInterface textBGImageAdapterCallBackInterface) {
        this.listImage = arrayList;
        this.listener = textBGImageAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_text_bg_image, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        InputStream open;
        String str = (String) this.listImage.get(i);
        try {
            AssetManager assets = this.context.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("background/");
            stringBuilder.append(str);
            open = assets.open(stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
            open = null;
        }
        viewHolder.imgTextBgImage.setImageBitmap(BitmapFactory.decodeStream(open));
        viewHolder.imgTextBgImage.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextBGImageAdapter.this.pos = i;
                TextBGImageAdapter.this.listener.itemClick(i);
                TextBGImageAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgTextBgImageSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgTextBgImageSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.listImage.size();
    }
}
