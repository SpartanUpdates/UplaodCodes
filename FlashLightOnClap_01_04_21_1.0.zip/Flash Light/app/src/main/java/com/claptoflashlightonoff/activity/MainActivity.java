package com.claptoflashlightonoff.activity;

import android.app.*;
import android.annotation.*;

import com.claptoflashlightonoff.kprogresshud.KProgressHUD;
import com.claptoflashlightonoff.pref.EPreferences;
import com.claptoflashlightonoff.util.SoundLevelView;
import com.claptoflashlightonoff.model.SoundMeter;
import com.claptoflashlightonoff.util.Utility;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.example.speaktourchtight.R;

import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.graphics.*;
import android.preference.*;
import android.graphics.drawable.*;
import android.content.*;
import android.net.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.os.*;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({"NewApi"})
public class MainActivity extends Activity implements View.OnClickListener {
    private Camera camera;
    boolean hasFlash;
    private ImageButton ibClap;
    private ImageButton ibColor;
    private ImageButton ibPolice;
    private TextView img;
    private boolean isFlashOn;
    private LinearLayout llGuide;
    private SoundLevelView mDisplay;
    private Handler mHandler;
    private Runnable mPollTask;
    private boolean mRunning;
    private SoundMeter mSensor;
    private Runnable mSleepTask;
    private TextView mStatusView;
    private int mThreshold;
    private PowerManager.WakeLock mWakeLock;
    private Camera.Parameters params;
    private SharedPreferences prefs;
    private TextView tvGuide;
    private EPreferences ePreferences;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private UnifiedNativeAd nativeAd;
    private int Adid;
    private KProgressHUD hud;
    private ImageView iv_menuOption;

    public MainActivity() {
        this.prefs = null;
        this.mRunning = false;
        this.mHandler = new Handler();
        this.isFlashOn = false;
        this.mSleepTask = new Runnable() {
            @Override
            public void run() {
                MainActivity.this.start();
            }
        };
        this.mPollTask = new Runnable() {
            @Override
            public void run() {
                final double amplitude = MainActivity.this.mSensor.getAmplitude();
                MainActivity.this.updateDisplay("Monitoring Voice...", amplitude);
                if (amplitude > MainActivity.this.mThreshold) {
                    MainActivity.this.callForHelp();
                    MainActivity.this.llGuide.setVisibility(View.GONE);
                }
                MainActivity.this.mHandler.postDelayed(MainActivity.this.mPollTask, 300L);
            }
        };
    }

    private void addListerner() {
        this.llGuide.setOnClickListener(this);
        this.ibClap.setOnClickListener(this);
        this.ibColor.setOnClickListener(this);
        this.ibPolice.setOnClickListener(this);
        iv_menuOption.setOnClickListener(this);
        findViewById(R.id.imgGetMore).setOnClickListener(this);
    }

    private void bindview() {
        this.tvGuide = (TextView) findViewById(R.id.tvGuide);
        this.prefs = getSharedPreferences(Utility.PREF_NAME, 0);
        this.llGuide = (LinearLayout) findViewById(R.id.llGuide);
        this.img = (TextView) findViewById(R.id.policescreen);
        this.mStatusView = (TextView) findViewById(R.id.status);
        this.mDisplay = (SoundLevelView) findViewById(R.id.volume);
        this.ibColor = (ImageButton) findViewById(R.id.ibColor);
        this.ibClap = (ImageButton) findViewById(R.id.ibClap);
        this.ibPolice = (ImageButton) findViewById(R.id.ibPolice);
        iv_menuOption = findViewById(R.id.iv_menuOption);
    }

    private void callForHelp() {
        if (this.isFlashOn) {
            this.turnOffFlash();
            return;
        }
        this.turnOnFlash();
    }

    private void getCamera() {
        if (this.camera != null) {
            return;
        }
        try {
            this.camera = Camera.open();
            this.params = this.camera.getParameters();
        } catch (RuntimeException ex) {
        }
    }

    private void init() {
        this.tvGuide.setTypeface(Typeface.createFromAsset(this.getAssets(), "majalla.ttf"));
        final SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.getBaseContext());
        if (!defaultSharedPreferences.getBoolean(this.getString(R.string.main), false)) {
            final SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putBoolean(this.getString(R.string.main), (boolean) Boolean.TRUE);
            edit.commit();
        } else {
            this.llGuide.setVisibility(View.GONE);
        }
        this.img.setBackgroundResource(R.drawable.imagesa);
        ((AnimationDrawable) this.img.getBackground()).start();
        this.hasFlash = this.getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        this.mSensor = new SoundMeter();
        this.mWakeLock = ((PowerManager) this.getSystemService(POWER_SERVICE)).newWakeLock(6, "NoiseAlert");
        this.getCamera();
        this.start();
        this.initializeApplicationConstants();
        this.mDisplay.setLevel(0, this.mThreshold);
        if (!this.mRunning) {
            this.mRunning = true;
            this.start();
        }
    }

    private void initializeApplicationConstants() {
        this.mThreshold = 8;
    }

    private void loadColorActivity() {
        final Intent intent = new Intent((Context) this, (Class) ColorActivity.class);
        intent.putExtra("Act", "MainActivity");
        startActivity(intent);
        finish();
    }

    private void loadPoliceActivity() {
        final Intent intent = new Intent((Context) this, (Class) PoliceActivity.class);
        intent.putExtra("Act", "MainActivity");
        startActivity(intent);
        if (this.camera != null) {
            this.camera.release();
            this.camera = null;
        }
        stop();
        finish();
    }

    private void loadTorchActivity() {
        this.startActivity(new Intent((Context) this, (Class) TourchActivity.class));
        this.finish();
    }

    private void start() {
        this.mSensor.start();
        if (!this.mWakeLock.isHeld()) {
            this.mWakeLock.acquire();
        }
        this.mHandler.postDelayed(this.mPollTask, 300L);
    }

    private void stop() {
        if (this.mWakeLock.isHeld()) {
            this.mWakeLock.release();
        }
        this.mHandler.removeCallbacks(this.mSleepTask);
        this.mHandler.removeCallbacks(this.mPollTask);
        this.mSensor.stop();
        this.mDisplay.setLevel(0, 0);
        this.updateDisplay("stopped...", 0.0);
        this.mRunning = false;
    }

    private void turnOffFlash() {
        if (!this.isFlashOn || this.camera == null || this.params == null) {
            return;
        }
        (this.params = this.camera.getParameters()).setFlashMode("off");
        this.camera.setParameters(this.params);
        this.camera.stopPreview();
        this.isFlashOn = false;
    }

    private void turnOnFlash() {
        if (this.isFlashOn || this.camera == null || this.params == null) {
            return;
        }
        (this.params = this.camera.getParameters()).setFlashMode("torch");
        this.camera.setParameters(this.params);
        this.camera.startPreview();
        this.isFlashOn = true;
    }

    private void updateDisplay(final String text, final double n) {
        this.mStatusView.setText((CharSequence) text);
        this.mDisplay.setLevel((int) n, this.mThreshold);
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_mainc);
        ePreferences = EPreferences.getInstance(this);
        bindview();
        init();
        addListerner();
        loadAd();
        BannerAds();
    }

    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.llGuide:
                this.llGuide.setVisibility(View.GONE);
                break;

            case R.id.ibColor:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadColorActivity();
                }
                break;

            case R.id.ibPolice:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 101;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadPoliceActivity();
                }
                break;

            case R.id.ibClap:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 102;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadTorchActivity();
                }
                break;

            case R.id.iv_menuOption:
                PopupMenu popup = new PopupMenu(MainActivity.this, iv_menuOption);
                popup.getMenuInflater().inflate(R.menu.option_menu, popup.getMenu());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.share:
                                Intent intent = new Intent(Intent.ACTION_SEND);
                                intent.setType("text/plain");
                                intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.share_msg) + getPackageName());
                                startActivity(Intent.createChooser(intent, "Share Via"));
                                break;

                            case R.id.rate:
                                try {
                                    startActivity(new Intent(Intent.ACTION_VIEW,
                                            Uri.parse(getResources().getString(R.string.rate_us)
                                                    + getPackageName())));
                                } catch (ActivityNotFoundException e) {
                                    Toast.makeText(MainActivity.this, "You don't have Google Play Store installed",
                                            Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case R.id.privacy:
                                try {
                                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                                    startActivity(intent1);
                                } catch (ActivityNotFoundException e) {
                                    e.printStackTrace();
                                }
                                break;
                        }

                        return true;
                    }
                });

                popup.show();
                break;

            default:
                return;
        }
    }

    private void loadAd() {

        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        MainActivity.this.loadColorActivity();
                        break;

                    case 101:
                        MainActivity.this.loadPoliceActivity();
                        break;

                    case 102:
                        MainActivity.this.loadTorchActivity();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(MainActivity.this);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(MainActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    protected void onDestroy() {
        if (this.camera != null) {
            this.camera.release();
            this.camera = null;
        }
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        if (this.camera != null) {
            this.camera.release();
            this.camera = null;
        }
        this.stop();
    }

    protected void onResume() {
        super.onResume();
        this.getCamera();
        this.start();
    }

    public void onStop() {
        super.onStop();
        if (this.camera != null) {
            this.camera.release();
            this.camera = null;
        }
        this.stop();
    }
}
