package com.UnitedVideos.SongSelection.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.UnitedVideos.SongSelection.Fragment.PhoneSongByCatFragmentUv;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.SongSelection.Fragment.PhoneSongByCatFragment;
import com.wavymusic.SongSelection.Model.PhoneSong;
import com.wavymusic.SongSelection.Model.PhoneSongAllFolders;
import com.wavymusic.SongSelection.Model.PhoneSongModel;
import com.wavymusic.SongSelection.View.PlayMusicControllerView;
import com.wavymusic.SongSelection.songCrop.controler.Mediacontroler;
import com.wavymusic.SongSelection.videolib.libffmpeg.Util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class PhoneSongActivityUv extends AppCompatActivity implements PlayMusicControllerView.playmusicControllerinterface {

    public List<PhoneSongModel> localTrackList = new ArrayList<>();
    public static PhoneSongAllFolders PhoneSongFolders;
    //SongEndTime
    public long SongEndTime;
    //Song Start Time
    public long SongSatrtTime;
    private PlayMusicControllerView songCropControlView;
    private long SongCurrentPosition;
    public Mediacontroler mediacontroler;
    public int id;
    public InterstitialAd fbinterstitialAd;
    public com.google.android.gms.ads.InterstitialAd mInterstitialAdUv;
    Activity activity = PhoneSongActivityUv.this;
    PagerAdapter pagerAdapter;
    TextView tvseekchangetime;
    String[] command;
    String FinalSongCropPath;
    TextView tvNoSong;
    RelativeLayout layoutSongCut;
    private SimpleDateFormat simpleDateFormat;
    private Handler handler = new Handler();
    private ImageView ivplaymusic;
    private boolean isPlaySong = true;
    private TextView tvselectmusicname;
    private TextView tvplaytime;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextView tvtitle;
    private TextView tvendtime;
    private boolean isStart = true;
    private PhoneSongModel musicRes;
    private Process process;
    private String output;
    private long timeout;
    ImageView ivback;
    public static boolean l = false;
    public int SelectedPosition;
    public int SelectedTabPosition;
    public int SelectedSongposition;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_song);
        SelectedPosition = 0;
        SelectedSongposition = -1;
        SelectedTabPosition = -1;
        simpleDateFormat = new SimpleDateFormat("mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        PutAnalyticsEvent();
        LocalSongsFeatch();
        BindView();
        BannerAds();
        CallInterstitialAd();
        CallInterstitialAdAdmobUv();
        if (localTrackList.size() > 0) {
            tvtitle.setVisibility(View.GONE);
        } else {
            tvtitle.setVisibility(View.VISIBLE);
        }
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "PhoneSongActivityUv");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void onResume() {
        super.onResume();
        SelectedSongposition = -1;
        SelectedTabPosition = -1;
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Musicpause() {
        mediacontroler.isSongStart();
        mediacontroler.setSeekposition(SongCurrentPosition);
        ivplaymusic.setImageResource(R.drawable.icon_player_pause);
    }

    public void Musicplay() {
        mediacontroler.isSongPause();
        SongCurrentPosition = mediacontroler.getSongposition();
        ivplaymusic.setImageResource(R.drawable.icon_player_play);
    }

    public boolean isSongPlay() {
        if (mediacontroler.isSongPlaying()) {
            return true;
        }
        mediacontroler.isSongPlaying();
        return false;
    }

    public void t() {
        if (this.mediacontroler.isSongPlaying()) {
            Musicplay();
        } else {
            Musicpause();
        }
    }

    public void setSong(PhoneSongModel phoneSongModel, int i) {
        SelectedSongposition = i;
        SelectedPosition = phoneSongModel.a();
        Music(phoneSongModel);
        mediacontroler.isSongStart();
    }


    public void Music(final PhoneSongModel musicRes) {
        this.musicRes = musicRes;
        handler.post(new Runnable() {

            public void run() {
                tvselectmusicname.setText(musicRes.m5778d());
                mediacontroler.setSongPath(musicRes.c());
                mediacontroler.SetSongSource();
                if (PhoneSongActivityUv.l) {
                    Musicpause();
                } else {
                    Musicplay();
                }
                songCropControlView.a(musicRes.e(), musicRes.e());
                songCropControlView.a();
            }
        });
        new Thread(new Play()).start();
    }


    public void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        isPlaySong = false;
        l = false;
        mediacontroler.isSongStop();
        super.onDestroy();
    }

    public void onStart() {
        super.onStart();
        if (isStart) {
            mediacontroler = new Mediacontroler(activity);
            isStart = false;
        }
    }

    public void onStop() {
        super.onStop();
        if (mediacontroler.isSongPlaying()) {
            Musicplay();
        }
    }

    public void a() {
        Musicplay();
        this.tvseekchangetime.setVisibility(View.VISIBLE);
        tvselectmusicname.setVisibility(View.GONE);
    }

    public void a(long songSatrtTime) {
        SongSatrtTime = songSatrtTime;
        SongCurrentPosition = songSatrtTime;
        TextView textView = this.tvseekchangetime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(simpleDateFormat.format(songSatrtTime));
        stringBuilder.append("-");
        stringBuilder.append(simpleDateFormat.format(SongEndTime));
        textView.setText(stringBuilder.toString());
    }

    public void b() {
        this.tvseekchangetime.setVisibility(View.GONE);
        tvselectmusicname.setVisibility(View.VISIBLE);
        SongCurrentPosition = SongSatrtTime;
        Musicpause();
    }

    public void b(long songEndTime) {
        SongEndTime = songEndTime;
        this.tvendtime.setText(simpleDateFormat.format(songEndTime));
        TextView textView = this.tvseekchangetime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(simpleDateFormat.format(SongSatrtTime));
        stringBuilder.append("-");
        stringBuilder.append(simpleDateFormat.format(songEndTime));
        textView.setText(stringBuilder.toString());
    }

    public long getMaxDuration() {
        return SongEndTime - SongSatrtTime;
    }

    private void BindView() {
        this.timeout = Long.MAX_VALUE;
        tvtitle = findViewById(R.id.tv_name);
        ivback = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.viewpager);
        ivplaymusic = findViewById(R.id.img_play_music);
        FrameLayout frameLayout = findViewById(R.id.btn_play_music);
        songCropControlView = findViewById(R.id.music_controller_view);
        songCropControlView.setOnMusicPlayControllerListener(this);
        tvplaytime = findViewById(R.id.txt_play_time);
        this.tvendtime = findViewById(R.id.txt_end_time);
        tvselectmusicname = findViewById(R.id.music);
        tvseekchangetime = findViewById(R.id.seektime);
        tvNoSong = findViewById(R.id.tv_no_music_found);
        layoutSongCut = findViewById(R.id.rl_cuttor_main);
        frameLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediacontroler.getSongPath() != null) {
                    if (mediacontroler.isSongPlaying()) {
                        Musicplay();
                        return;
                    } else {
                        Musicpause();
                    }
                }
            }
        });
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        if (PhoneSongFolders == null) {
            PhoneSongFolders = new PhoneSongAllFolders();
        }
        if (PhoneSongFolders.getMusicFolders().size() > 0) {
            setUpPagerNew();
            SetTabLayout();
        } else {
            tvNoSong.setVisibility(View.VISIBLE);
            layoutSongCut.setVisibility(View.GONE);
        }
    }

    private void CallInterstitialAd() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial_Uv));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (id) {
                    case 202:
                        AppConstant.PhoneSongActivityUv = 1;
                        Done();
                        break;
                }
            }
        });
        fbinterstitialAd.loadAd();
    }


    private void CallInterstitialAdAdmobUv() {
        mInterstitialAdUv = new com.google.android.gms.ads.InterstitialAd(this);
        mInterstitialAdUv.setAdUnitId(getResources().getString(R.string.interstitialUv));
        mInterstitialAdUv.loadAd(new AdRequest.Builder().build());
        mInterstitialAdUv.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 202:
                        AppConstant.PhoneSongActivityUv = 1;
                        Done();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void Done() {
        musicRes.a(SongSatrtTime);
        musicRes.b(SongEndTime);
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append(File.separator);
        sb.append("United Videos");
        sb.append(File.separator);
        sb.append("Crop Song");
        final File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStorageDirectory());
        sb2.append(File.separator);
        sb2.append("United Videos");
        sb2.append(File.separator);
        sb2.append("Crop Song");
        sb2.append(File.separator);
        sb2.append("temp.mp3");
        FinalSongCropPath = sb2.toString();
        command = new String[]{getFFmpeg(activity), "-i", musicRes.c(), "-ss", getTimeDuration(musicRes.b()), "-t", getTimeDuration(musicRes.f()), "-acodec", "copy", "-y", FinalSongCropPath};
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("Path :");
        sb3.append(FinalSongCropPath);
        new CropSongAsync().execute();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(pagerAdapter.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setUpPagerNew() {
        pagerAdapter = new PagerAdapter(getSupportFragmentManager());
        for (int i = 0; i < PhoneSongFolders.getMusicFolders().size(); i++) {
            pagerAdapter.addFrag(PhoneSongByCatFragmentUv.getInstance(i, i), "");
        }
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void LocalSongsFeatch() {
        localTrackList.clear();
        PhoneSongFolders = new PhoneSongAllFolders();
        PhoneSongFolders.getMusicFolders().clear();
        ContentResolver musicResolver = activity.getContentResolver();
        Uri musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");

        if (musicCursor != null && musicCursor.moveToFirst()) {
            int titleColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ARTIST);
            int albumColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ALBUM);
            int pathColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.DATA);
            int durationColumn = musicCursor.getColumnIndex(MediaStore.Audio.Media.DURATION);

            do {
                int thisId = musicCursor.getInt(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String thisAlbum = musicCursor.getString(albumColumn);
                String path = musicCursor.getString(pathColumn);
                long duration = musicCursor.getLong(durationColumn);
                PhoneSongModel lt = new PhoneSongModel(thisId, thisTitle, thisArtist, thisAlbum, path, duration);
                lt.l(false);
                localTrackList.add(lt);
                File f = new File(path);
                String dirName = f.getParentFile().getName();
                if (getFolder(dirName) == null) {
                    PhoneSong mf = new PhoneSong(dirName);
                    mf.getLocalTracks().add(lt);
                    PhoneSongFolders.getMusicFolders().add(mf);
                } else {
                    getFolder(dirName).getLocalTracks().add(lt);
                }
            }
            while (musicCursor.moveToNext());
        }

        if (musicCursor != null)
            musicCursor.close();

    }

    public PhoneSong getFolder(String folderName) {
        PhoneSong mf = null;
        for (int i = 0; i < PhoneSongFolders.getMusicFolders().size(); i++) {
            PhoneSong mf1 = PhoneSongFolders.getMusicFolders().get(i);
            if (mf1.getFolderName().equals(folderName)) {
                mf = mf1;
                break;
            }
        }
        return mf;
    }

    private File getFileDirectory(final Context context) {
        return context.getFilesDir();
    }

    private String getFFmpeg(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(getFileDirectory(context).getAbsolutePath()));
        sb.append(File.separator);
        sb.append("ffmpeg");
        return sb.toString();
    }

    @SuppressLint("DefaultLocale")
    public String getTimeDuration(final long n) {
        return String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(n), TimeUnit.MILLISECONDS.toMinutes(n), TimeUnit.MILLISECONDS.toSeconds(n) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n)));
    }

    private void checkAndUpdateProcess() throws TimeoutException {
        while (!Util.isProcessCompleted(this.process)) {
            if (Util.isProcessCompleted(this.process)) {
                return;
            }
            if (timeout != Long.MAX_VALUE && System.currentTimeMillis() > System.currentTimeMillis() + timeout) {
                throw new TimeoutException("FFmpeg timed out");
            }
            try {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    output = String.valueOf(this.output) + line + "\n";
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public class Play implements Runnable {

        public void run() {
            while (isPlaySong) {
                songCropControlView.setPlayProgress(mediacontroler.getSongposition());
                if (((long) mediacontroler.getSongposition()) >= SongEndTime) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("start : ");
                    stringBuilder.append(SongSatrtTime);
                    mediacontroler.setSeekposition(SongSatrtTime);
                }
                new Play.p(this);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        class p implements Runnable {

            final Play play;

            p(Play play) {
                this.play = play;
            }

            public void run() {
                tvplaytime.setText(simpleDateFormat.format(mediacontroler.getSongposition()));
            }
        }
    }

    private class PagerAdapter extends FragmentPagerAdapter {

        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(R.layout.row_phone_song_cat, null);
            TextView tv = tab.findViewById(R.id.folder_name);
            tv.setText(PhoneSongFolders.getMusicFolders().get(position).getFolderName());
            return tab;
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class CropSongAsync extends AsyncTask<Void, Void, Void> {
        ProgressDialog a;

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (a != null && this.a.isShowing()) {
                this.a.dismiss();
            }
            Intent intent = new Intent();
            intent.putExtra("audio_path", FinalSongCropPath);
            setResult(-1, intent);
            finish();

        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                process = Runtime.getRuntime().exec(command);
                if (process != null) {
                    try {
                        checkAndUpdateProcess();
                    } catch (TimeoutException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            (this.a = new ProgressDialog(activity)).setMessage("Please Waiting...");
            this.a.setCancelable(false);
            this.a.show();
        }
    }
}