package com.xyz.vehiclemanager.car.CarVarianDetails.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.CarVarianDetails.activity.CarVariantTabActivity;
import com.xyz.vehiclemanager.car.CarVarianDetails.adapter.CarFeaturesAdapter;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarFeatures;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarVariantRoot;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarFeatureFragment extends Fragment
{
    private View view;
    private ArrayList<Item> safety = new ArrayList<>();
    private ArrayList<Item> brakingAndTraction = new ArrayList<>();
    private ArrayList<Item> locksAndSecurity = new ArrayList<>();
    private ArrayList<Item> comfortAndConvenience = new ArrayList<>();
    private ArrayList<Item> seatAndUpjolstery = new ArrayList<>();
    private ArrayList<Item> storage = new ArrayList<>();
    private ArrayList<Item> doorWindowsMirrorsWipers = new ArrayList<>();
    private ArrayList<Item> exterior = new ArrayList<>();
    private ArrayList<Item> lighting = new ArrayList<>();
    private ArrayList<Item> instrumention = new ArrayList<>();
    private ArrayList<Item> entertainmentInformationCommunication = new ArrayList<>();
    private ArrayList<Item> manufacturesWarranty = new ArrayList<>();
    private RecyclerView featuresRecycleView;
    private RtoDetailsInterface rtoDetailsInterface;
    private CarFeaturesAdapter carFeaturesAdapter;
    private Item item;

    public CarFeatureFragment()
    {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.fragment_feature, container, false);

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        featuresRecycleView=view.findViewById(R.id.rv_feature);
        getVariantDetail();

        return view;
    }
    private void getVariantDetail() {
        Call<CarVariantRoot> call = rtoDetailsInterface.getCarVariantsDetail(CarVariantTabActivity.varientId);
        call.enqueue(new Callback<CarVariantRoot>() {
            @Override
            public void onResponse(Call<CarVariantRoot> call, Response<CarVariantRoot> response) {
                if (response.isSuccessful()) {
                    if (CarVariantTabActivity.dialog != null && CarVariantTabActivity.dialog.isShowing())
                    {
                        CarVariantTabActivity.dialog.dismiss();
                    }
                    ArrayList<CarFeatures> variantlist = response.body().getDetails().getFeatures();
                    for (int i = 0; i < variantlist.size(); i++) {
                        String key = variantlist.get(i).getKey();
                        ArrayList<Item> itemlist = response.body().getDetails().getFeatures().get(i).getItems();
                        if (key.equals("Safety")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                safety.add(item);
                            }
                        }
                        if (key.equals("Braking & Traction")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                brakingAndTraction.add(item);
                            }
                        }
                        if (key.equals("Locks & Security")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                locksAndSecurity.add(item);
                            }
                        }
                        if (key.equals("Comfort & Convenience")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                comfortAndConvenience.add(item);
                            }
                        }
                        if (key.equals("Seats & Upholstery")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                seatAndUpjolstery.add(item);
                            }
                        }
                        if (key.equals("Storage")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                storage.add(item);
                            }
                        }
                        if (key.equals("Doors, Windows, Mirrors & Wipers")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                doorWindowsMirrorsWipers.add(item);
                            }
                        }
                        if (key.equals("Exterior")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                exterior.add(item);
                            }
                        }
                        if (key.equals("Lighting")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                lighting.add(item);
                            }
                        }
                        if (key.equals("Instrumentation")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                instrumention.add(item);
                            }
                        }
                        if (key.equals("Entertainment, Information & Communication")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                entertainmentInformationCommunication.add(item);
                            }
                        }
                        if (key.equals("Manufacturer Warranty")) {
                            for (int j = 0; j < itemlist.size(); j++) {
                                item = new Item();
                                String sAttrName = itemlist.get(j).getAttrName();
                                String sAttrValue = itemlist.get(j).getAttrValue();
                                item.setAttrName(sAttrName);
                                item.setAttrValue(sAttrValue);
                                manufacturesWarranty.add(item);
                            }
                        }
                    }
                    carFeaturesAdapter = new CarFeaturesAdapter(getActivity(), variantlist, safety, brakingAndTraction, locksAndSecurity, comfortAndConvenience, seatAndUpjolstery, storage, doorWindowsMirrorsWipers, exterior, lighting, instrumention, entertainmentInformationCommunication, manufacturesWarranty);
                    featuresRecycleView.setAdapter(carFeaturesAdapter);
                    featuresRecycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
                }
            }

            @Override
            public void onFailure(Call<CarVariantRoot> call, Throwable t) {
                if (CarVariantTabActivity.dialog != null && CarVariantTabActivity.dialog.isShowing())
                {
                    CarVariantTabActivity.dialog.dismiss();
                }
               Toast.makeText(getActivity(), "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}