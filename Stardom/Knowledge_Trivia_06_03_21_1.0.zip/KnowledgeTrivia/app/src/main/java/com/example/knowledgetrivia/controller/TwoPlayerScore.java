package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.InputDeviceCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.DatabaseHelper;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.models.LevelScore;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;

import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;

public class TwoPlayerScore extends AppCompatActivity {
    Activity activity = TwoPlayerScore.this;
    private String name1;
    private String name2;
    private double score1;
    private double score2;
    private MediaPlayer tick;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_two_player_score);

        interstitialAd();

        Intent intent = getIntent();
        String str = "name1";
        this.name1 = intent.getStringExtra(str);
        String str2 = "name2";
        this.name2 = intent.getStringExtra(str2);
        this.score1 = intent.getDoubleExtra("score1", Utils.DOUBLE_EPSILON);
        this.score2 = intent.getDoubleExtra("score2", Utils.DOUBLE_EPSILON);
        ((TextView) findViewById(R.id.player1name)).setText(this.name1);
        ((TextView) findViewById(R.id.player2name)).setText(this.name2);
        TextView textView = (TextView) findViewById(R.id.player1score);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.score1);
        String str3 = "";
        stringBuilder.append(str3);
        textView.setText(stringBuilder.toString());
        textView = (TextView) findViewById(R.id.player2score);
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.score2);
        stringBuilder.append(str3);
        textView.setText(stringBuilder.toString());
        textView = (TextView) findViewById(R.id.winline);
        double d = this.score1;
        double d2 = this.score2;
        String str4 = " Wins";
        if (d > d2) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(intent.getStringExtra(str));
            stringBuilder2.append(str4);
            textView.setText(stringBuilder2.toString());
        } else if (d2 > d) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(intent.getStringExtra(str2));
            stringBuilder3.append(str4);
            textView.setText(stringBuilder3.toString());
        } else {
            textView.setText("Match Draw");
        }
        MediaPlayer.create(this, R.raw.fireworks).start();
        this.tick = MediaPlayer.create(this, R.raw.tick);

        KonfettiView konfettiView = (KonfettiView) findViewById(R.id.viewKonfetti);


        konfettiView.build()
                .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                .setDirection(0.0, 359.0)
                .setSpeed(1f, 5f)
                .setFadeOutEnabled(true)
                .setTimeToLive(2000L)
                .addSizes(new Size(12, 5))
                .setPosition(-50f, konfettiView.getWidth() + 50f, -50f, -50f)
                .streamFor(300, 5000L);

        findViewById(R.id.playagain).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    TwoPlayerScore.this.tick.start();
                    Intent intent = new Intent(TwoPlayerScore.this, TwoPlayerShowingQuestion.class);
                    intent.putExtra("name1", TwoPlayerScore.this.name1);
                    intent.putExtra("name2", TwoPlayerScore.this.name2);
                    TwoPlayerScore.this.startActivity(intent);
                    TwoPlayerScore.this.finish();
                }

            }
        });
        findViewById(R.id.home).setOnClickListener(new OnClickListener() {

            public void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    TwoPlayerScore.this.tick.start();
                    TwoPlayerScore.this.finish();
                }
            }
        });
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        TwoPlayerScore.this.tick.start();
                        Intent intent = new Intent(TwoPlayerScore.this, TwoPlayerShowingQuestion.class);
                        intent.putExtra("name1", TwoPlayerScore.this.name1);
                        intent.putExtra("name2", TwoPlayerScore.this.name2);
                        TwoPlayerScore.this.startActivity(intent);
                        TwoPlayerScore.this.finish();
                        break;
                    case 101:
                        TwoPlayerScore.this.tick.start();
                        TwoPlayerScore.this.finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
