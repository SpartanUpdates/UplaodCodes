﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace BallCollect
{
    public class DataBase : MonoBehaviour
    {
        public static void SetCurrentLevel(int level)
        {
            PlayerPrefs.SetInt("CurrentLevel", level);
        }
        public static int GetCurrentLevel()
        {
            return PlayerPrefs.GetInt("CurrentLevel");
        }

        public static void SetCoins(int coins)
        {
            PlayerPrefs.SetInt("Coins", coins);
        }
        public static int GetCoins()
        {
            return PlayerPrefs.GetInt("Coins");
        }


        public static void SetSoundOn(int no)
        {
            PlayerPrefs.SetInt("SoundOn", no);
        }
        public static int GetSoundOn()
        {
            return PlayerPrefs.GetInt("SoundOn");
        }

        public static void SetMusicOn(int no)
        {
            PlayerPrefs.SetInt("MusicOn", no);
        }
        public static int GetMusicOn()
        {
            return PlayerPrefs.GetInt("MusicOn");
        }

        public static void SetVibrationOn(int no)
        {
            PlayerPrefs.SetInt("VibrateOn", no);
        }
        public static int GetVibrationOn()
        {
            return PlayerPrefs.GetInt("VibrateOn");
        }

        public static void SetPlayer(int no)
        {
            PlayerPrefs.SetInt("CurrentPlayer", no);
        }
        public static int GetPlayer()
        {
            return PlayerPrefs.GetInt("CurrentPlayer");
        }

        public static void SetBall(int no)
        {
            PlayerPrefs.SetInt("CurrentBall", no);
        }
        public static int GetBall()
        {
            return PlayerPrefs.GetInt("CurrentBall");
        }

        public static void SetLastLevel(int no)
        {
            PlayerPrefs.SetInt("LastLevel", no);
        }
        public static int GetLastLevel ()
        {
            return PlayerPrefs.GetInt("LastLevel");
        }
    }
}