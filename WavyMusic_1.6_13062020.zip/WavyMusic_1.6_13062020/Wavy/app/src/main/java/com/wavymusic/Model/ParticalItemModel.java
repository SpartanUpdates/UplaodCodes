package com.wavymusic.Model;

public class ParticalItemModel {
    private int ThemeId;
    private int catId;
    private String ThemeName;
    private String ThemeInfo;
    private String BundelName;
    private String GmaeObjName;
    private String ThemeBundel;
    private String ThumbImage;
    private boolean IsFromAsset;
    private String IsPreimum;
    private String ThemeUnity3dPath;
    private int BundelSize;
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
    public boolean j;
//    public boolean IsAssetSelected=false;

    public int getThemeId() {
        return ThemeId;
    }

    public void setThemeId(int themeId) {
        ThemeId = themeId;
    }

    public int getCatId() {
        return catId;
    }

    public void setCatId(int catId) {
        this.catId = catId;
    }

    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public String getThemeInfo() {
        return ThemeInfo;
    }

    public void setThemeInfo(String themeInfo) {
        ThemeInfo = themeInfo;
    }

    public String getBundelName() {
        return BundelName;
    }

    public void setBundelName(String bundelName) {
        BundelName = bundelName;
    }


    public String getGmaeObjName() {
        return GmaeObjName;
    }

    public void setGmaeObjName(String gmaeObjName) {
        GmaeObjName = gmaeObjName;
    }

    public String getThemeBundel() {
        return ThemeBundel;
    }

    public void setThemeBundel(String themeBundel) {
        ThemeBundel = themeBundel;
    }

    public String getThumbImage() {
        return ThumbImage;
    }

    public void setThumbImage(String thumbImage) {
        ThumbImage = thumbImage;
    }

    public boolean isFromAsset() {
        return IsFromAsset;
    }

    public void setFromAsset(boolean fromAsset) {
        IsFromAsset = fromAsset;
    }

    public String getIsPreimum() {
        return IsPreimum;
    }

    public void setIsPreimum(String isPreimum) {
        IsPreimum = isPreimum;
    }

    public String getThemeUnity3dPath() {
        return ThemeUnity3dPath;
    }

    public void setThemeUnity3dPath(String themeUnity3dPath) {
        ThemeUnity3dPath = themeUnity3dPath;
    }

    public int getBundelSize() {
        return BundelSize;
    }

    public void setBundelSize(int bundelSize) {
        BundelSize = bundelSize;
    }
}
