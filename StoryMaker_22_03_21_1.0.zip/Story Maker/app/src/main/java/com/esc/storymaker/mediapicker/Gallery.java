package com.esc.storymaker.mediapicker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.VpMainAdapter;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.mediapicker.fragments.ImagesFrag;
import com.esc.storymaker.mediapicker.models.TabItem;
import com.esc.storymaker.mediapicker.utils.AppUtil;
import com.esc.storymaker.mediapicker.utils.ContractsUtil;
import com.flyco.tablayout.CommonTabLayout;
import com.flyco.tablayout.listener.CustomTabEntity;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;

public class Gallery extends AppCompatActivity {
    public static final String mypreference = "myprefadmob";
    private ImageView ImageOverlayadview;
    AppCompatActivity activity;
    ConnectionDetector connectionDetector;
    private CommonTabLayout ctlMain;
    private FragmentManager fm;
    private ArrayList<Fragment> mFragments = new ArrayList();
    private int mode;
    SharedPreferences sharedpreferences;
    private ArrayList<CustomTabEntity> tabItems = new ArrayList();
    private ArrayList<Integer> tabSelectedIcons = new ArrayList();
    private String[] tabTitles;
    private TextView tbTitle;
    private ViewPager vpMain;
    int whichAdFirst;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private void init() {
        this.fm = getSupportFragmentManager();
        this.vpMain = (ViewPager) findViewById(R.id.vp_main);
        this.ctlMain = (CommonTabLayout) findViewById(R.id.ctl_main);
        this.tbTitle = (TextView) findViewById(R.id.tb_title);
        this.tbTitle.setText(getIntent().getStringExtra("title"));
        findViewById(R.id.tb_close).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Gallery.this.onBackPressed();
            }
        });
        this.mode = getIntent().getIntExtra("mode", 0);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_gallery);
        this.sharedpreferences = getSharedPreferences("myprefadmob", 0);
        this.activity = this;
        this.connectionDetector = new ConnectionDetector(getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.ImageOverlayadview = (ImageView) findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        BannerAds();
/*        if (isConnectingToInternet) {

        } else {
            findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }*/
        init();
        AppUtil.permissionGranted(this, "android.permission.WRITE_EXTERNAL_STORAGE");
    }

    public void setTabBar() {
        this.mFragments = new ArrayList();
        int i = this.mode;
        if (i == 0) {
            this.mFragments.add(ImagesFrag.getInstance());
        } else if (i == 1) {
            this.mFragments.add(ImagesFrag.getInstance());
        }
        this.tabSelectedIcons = new ArrayList();
        this.tabSelectedIcons.addAll(ContractsUtil.tabIcons.keySet());
        this.tabTitles = new String[0];
        this.tabTitles = getResources().getStringArray(R.array.tab_titles);
        this.tabItems = new ArrayList();
        int i2 = 0;
        while (true) {
            String[] strArr = this.tabTitles;
            if (i2 < strArr.length) {
                this.tabItems.add(new TabItem(strArr[i2], ((Integer) this.tabSelectedIcons.get(i2)).intValue(), ((Integer) ContractsUtil.tabIcons.get(this.tabSelectedIcons.get(i2))).intValue()));
                i2++;
            } else {
                this.ctlMain.setTabData(this.tabItems);
                this.ctlMain.setOnTabSelectListener(new OnTabSelectListener() {
                    public void onTabReselect(int i) {
                    }

                    public void onTabSelect(int i) {
                        Gallery.this.vpMain.setCurrentItem(i);
                    }
                });
                this.vpMain.setAdapter(new VpMainAdapter(getSupportFragmentManager(), this.mFragments));
                this.vpMain.addOnPageChangeListener(new OnPageChangeListener() {
                    public void onPageScrollStateChanged(int i) {
                    }

                    public void onPageScrolled(int i, float f, int i2) {
                    }

                    public void onPageSelected(int i) {
                        Gallery.this.ctlMain.setCurrentTab(i);
                    }
                });
                this.vpMain.setCurrentItem(0);
                this.vpMain.setOffscreenPageLimit(this.mode + 1);
                return;
            }
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addFragment(Fragment fragment) {
        this.fm.executePendingTransactions();
        FragmentTransaction beginTransaction = this.fm.beginTransaction();
        beginTransaction.setCustomAnimations(R.anim.slide_in_top, R.anim.slide_in_top);
        beginTransaction.replace(R.id.fl_fragment_detail, fragment);
        beginTransaction.commitAllowingStateLoss();
        findViewById(R.id.fl_fragment_detail).setVisibility(View.VISIBLE);
    }

    public void sendResult(String str) {
        Intent intent = new Intent();
        intent.putExtra("filePath", str);
        setResult(-1, intent);
        finish();
    }

    public void onBackPressed() {
        if (findViewById(R.id.fl_fragment_detail).isShown()) {
            findViewById(R.id.fl_fragment_detail).setVisibility(View.GONE);
            if (this.fm.findFragmentById(R.id.fl_fragment_detail) != null) {
                this.fm.beginTransaction().remove(this.fm.findFragmentById(R.id.fl_fragment_detail)).commit();
            }
        }
        finish();
    }



    public void checkDisplayOverlayBannerG() {
        if (new Utils(this.activity).checkTimeB()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void checkDisplayOverlayBannerFB() {
        if (new Utils(this.activity).checkTimeBf()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }

}
