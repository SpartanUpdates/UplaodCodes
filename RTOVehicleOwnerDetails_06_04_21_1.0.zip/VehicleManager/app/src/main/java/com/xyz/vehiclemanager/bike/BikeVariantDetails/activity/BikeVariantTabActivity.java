package com.xyz.vehiclemanager.bike.BikeVariantDetails.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.adapter.VarientFragmentPageAdapter;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeFeaturesFragment;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeOverViewFragment;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment.BikeSpecificationsFragment;

public class BikeVariantTabActivity extends AppCompatActivity {
    Activity activity = BikeVariantTabActivity.this;
    public static String varientName, varientId;
    private ImageView iv_back;
    private TabLayout tabLayout;
    private VarientFragmentPageAdapter varientFragmentPageAdapter;
    private ViewPager viewPager;
    private TextView tv_title;
    public static AppCompatDialog dialog;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_variant_tab);

        varientName = getIntent().getStringExtra("VarientName");
        varientId = getIntent().getStringExtra("VarientId");

        iv_back = findViewById(R.id.iv_back);
        tv_title = findViewById(R.id.tv_title);
        viewPager = findViewById(R.id.viewPager);
        setViewPager();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();

        tv_title.setText(varientName);
        PutAnalyticsEvent();
        BannerAds();
        DialogAnimation();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeVariantTabActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setViewPager() {
        varientFragmentPageAdapter = new VarientFragmentPageAdapter(getSupportFragmentManager());
        varientFragmentPageAdapter.addFragment(new BikeOverViewFragment(), "Overview");
        varientFragmentPageAdapter.addFragment(new BikeSpecificationsFragment(), "Specifications");
        varientFragmentPageAdapter.addFragment(new BikeFeaturesFragment(), "Features");
        viewPager.setAdapter(varientFragmentPageAdapter);
    }

    private void CreateTab() {
        TextView overView = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        overView.setText("OverView");
        tabLayout.getTabAt(0).setCustomView(overView);

        TextView specification = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        specification.setText("Specification");
        tabLayout.getTabAt(1).setCustomView(specification);

        TextView features = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        features.setText("Features");
        tabLayout.getTabAt(2).setCustomView(features);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(BikeVariantTabActivity.this, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}