package com.kotlinz.videoeditor.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.kotlinz.videoeditor.Adapter.FragmentAdapter;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.google.android.material.tabs.TabLayout;

public class MyCreationActivity extends AppCompatActivity {

    Activity activity = MyCreationActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView creationback;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mycreation_activity);

        viewPager = findViewById(R.id.pager);
        FragmentAdapter adapter = new FragmentAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);

        creationback = findViewById(R.id.backcreation);

        creationback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(activity, StartActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 6;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        startActivity(new Intent(activity, StartActivity.class));
                        finish();
                    }
                }
            }
        });
    }
}

