package api.natsuite.natcorder;

import api.natsuite.natcorder.utility.*;

import android.os.*;
import android.util.*;

import java.io.*;

import android.view.*;
import android.media.*;
import android.opengl.*;

import java.nio.*;

import api.natsuite.natrender.*;

public class MP4Recorder implements MediaRecorder {
    private final int width;
    private final int height;
    private final MediaCodec videoCodec;
    private final MediaCodec audioCodec;
    private final GLRenderContext renderContext;
    private final HandlerThread audioQueueThread;
    private MediaWriter mediaWriter;
    private Handler renderContextHandler;
    private Handler audioQueueHandler;
    private GLBlitEncoder blitEncoder;
    private int frameTexture;
    private final Runnable videoCodecFlusher;
    private final Runnable audioCodecFlusher;

    public MP4Recorder(final int width, final int height, final float framerate, final int bitrate, final int keyframeInterval, final int sampleRate, final int channelCount) {
        this.audioQueueThread = new HandlerThread("MP4Recorder Audio Thread");
        this.videoCodecFlusher = new Runnable() {
            @Override
            public void run() {
                final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                while (true) {
                    try {
                        Thread.sleep(2L);
                    } catch (InterruptedException ex) {
                    }
                    final int bufferIndex = MP4Recorder.this.videoCodec.dequeueOutputBuffer(bufferInfo, -1L);
                    if (bufferIndex < 0) {
                        continue;
                    }
                    final MediaFormat format = MP4Recorder.this.videoCodec.getOutputFormat();
                    final ByteBuffer buffer = MP4Recorder.this.videoCodec.getOutputBuffer(bufferIndex);
                    MP4Recorder.this.mediaWriter.appendVideoFrame(format, buffer, bufferInfo);
                    MP4Recorder.this.videoCodec.releaseOutputBuffer(bufferIndex, false);
                    if ((bufferInfo.flags & 0x4) != 0x0) {
                        break;
                    }
                }
                Log.v("Unity", "NatCorder: MP4 video encoder encountered EOS");
                MP4Recorder.this.videoCodec.stop();
                MP4Recorder.this.videoCodec.release();
                MP4Recorder.this.mediaWriter.finishWriting();
            }
        };
        this.audioCodecFlusher = new Runnable() {
            @Override
            public void run() {
                final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                long lastAudioBufferTimestamp = 0L;
                while (true) {
                    try {
                        Thread.sleep(2L);
                    } catch (InterruptedException ex) {
                    }
                    final int bufferIndex = MP4Recorder.this.audioCodec.dequeueOutputBuffer(bufferInfo, -1L);
                    if (bufferIndex < 0) {
                        continue;
                    }
                    while (bufferInfo.presentationTimeUs < lastAudioBufferTimestamp) {
                        final MediaCodec.BufferInfo bufferInfo2 = bufferInfo;
                        bufferInfo2.presentationTimeUs += 23219L;
                    }
                    lastAudioBufferTimestamp = bufferInfo.presentationTimeUs;
                    final MediaFormat format = MP4Recorder.this.audioCodec.getOutputFormat();
                    final ByteBuffer buffer = MP4Recorder.this.audioCodec.getOutputBuffer(bufferIndex);
                    MP4Recorder.this.mediaWriter.appendAudioFrame(format, buffer, bufferInfo);
                    MP4Recorder.this.audioCodec.releaseOutputBuffer(bufferIndex, false);
                    if ((bufferInfo.flags & 0x4) != 0x0) {
                        break;
                    }
                }
                Log.v("Unity", "NatCorder: MP4 audio encoder encountered EOS");
                MP4Recorder.this.audioCodec.stop();
                MP4Recorder.this.audioCodec.release();
                MP4Recorder.this.mediaWriter.finishWriting();
            }
        };
        MediaCodec videoCodec = null;
        final MediaFormat videoFormat = MediaFormat.createVideoFormat("video/avc", width, height);
        Log.e("bitrate", "" + bitrate);
        Log.e("rate", "" + framerate);
        Log.e("i-frame-interval", "" + keyframeInterval);
        Log.e("Sample Rate", "" + sampleRate);
        Log.e("Chanel Count", "" + channelCount);

        videoFormat.setInteger("color-format", 2130708361);
        videoFormat.setInteger("bitrate", bitrate);
        videoFormat.setFloat("frame-rate", framerate);
        videoFormat.setInteger("i-frame-interval", keyframeInterval);

//        videoFormat.setInteger("color-format", 2130708361);
//        videoFormat.setInteger("bitrate", 3378908);
//        videoFormat.setFloat("frame-rate", 30);
//        videoFormat.setInteger("i-frame-interval", 1);

        Log.v("Unity", "NatCorder: Preparing MP4 video encoder with format: " + videoFormat);
        try {
            videoCodec = MediaCodec.createEncoderByType("video/avc");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        videoCodec.configure(videoFormat, (Surface) null, (MediaCrypto) null, 1);
        MediaCodec audioCodec = null;
        if (sampleRate != 0 || channelCount != 0) {
            final MediaFormat audioFormat = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channelCount);
            audioFormat.setInteger("aac-profile", 2);
            audioFormat.setInteger("channel-mask", (channelCount == 2) ? 12 : 16);
            audioFormat.setInteger("bitrate", 64000);
            audioFormat.setInteger("channel-count", channelCount);
            audioFormat.setInteger("max-input-size", 16384);
            Log.v("Unity", "NatCorder: Preparing MP4 audio encoder with format: " + audioFormat);
            try {
                audioCodec = MediaCodec.createEncoderByType("audio/mp4a-latm");
            } catch (IOException ex2) {
            }
            audioCodec.configure(audioFormat, (Surface) null, (MediaCrypto) null, 1);
        }
        this.width = width;
        this.height = height;
        this.videoCodec = videoCodec;
        this.renderContext = new GLRenderContext((EGLContext) null, videoCodec.createInputSurface(), true);
        this.audioCodec = audioCodec;
    }

    @Override
    public void startRecording(final String recordingPath, final Callback completionHandler) {
        try {
            this.mediaWriter = new MediaWriter(recordingPath, (this.audioCodec != null) ? 2 : 1, completionHandler);
        } catch (IOException ex) {
            Log.e("Unity", "NatCorder Error: Failed to create MP4 writer with error: " + ex.getLocalizedMessage());
            this.videoCodec.release();
            if (this.audioCodec != null) {
                this.audioCodec.release();
            }
            return;
        }
        this.videoCodec.start();
        if (this.audioCodec != null) {
            this.audioCodec.start();
            this.audioQueueThread.start();
            this.audioQueueHandler = new Handler(this.audioQueueThread.getLooper());
        }
        this.renderContext.start();
        (this.renderContextHandler = new Handler(this.renderContext.getLooper())).post((Runnable) new Runnable() {
            @Override
            public void run() {
                MP4Recorder.this.blitEncoder = GLBlitEncoder.blitEncoder();
                MP4Recorder.this.frameTexture = GLBlitEncoder.getTexture();
                GLES30.glTexImage2D(3553, 0, 6408, MP4Recorder.this.width, MP4Recorder.this.height, 0, 6408, 5121, (Buffer) null);
            }
        });
        new Thread(this.videoCodecFlusher, "MP4Recorder Video Encoding Thread").start();
        if (this.audioCodec != null) {
            new Thread(this.audioCodecFlusher, "MP4Recorder Audio Encoding Thread").start();
        }
    }

    @Override
    public synchronized void stopRecording() {
        if (this.audioQueueHandler != null) {
            this.audioQueueHandler.post((Runnable) new Runnable() {
                @Override
                public void run() {
                    final int bufferIndex = MP4Recorder.this.audioCodec.dequeueInputBuffer(-1L);
                    MP4Recorder.this.audioCodec.queueInputBuffer(bufferIndex, 0, 0, 0L, 4);
                }
            });
            this.audioQueueThread.quitSafely();
        }
        this.renderContextHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                MP4Recorder.this.blitEncoder.release();
                MP4Recorder.this.renderContext.getSurface().release();
                GLBlitEncoder.releaseTexture(MP4Recorder.this.frameTexture);
                MP4Recorder.this.videoCodec.signalEndOfInputStream();
            }
        });
        this.renderContext.quitSafely();
    }

    @Override
    public synchronized void encodeFrame(final ByteBuffer pixelBuffer, final long timestamp) {
        final byte[] pixelData = new byte[this.width * this.height * 4];
        pixelBuffer.get(pixelData);
        this.renderContextHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                GLES30.glBindTexture(3553, MP4Recorder.this.frameTexture);
                GLES30.glTexSubImage2D(3553, 0, 0, 0, MP4Recorder.this.width, MP4Recorder.this.height, 6408, 5121, (Buffer) ByteBuffer.wrap(pixelData));
                MP4Recorder.this.blitEncoder.blit(MP4Recorder.this.frameTexture);
                MP4Recorder.this.renderContext.setPresentationTime(timestamp);
                MP4Recorder.this.renderContext.swapBuffers();
            }
        });
    }

    @Override
    public synchronized void encodeFrame(final long nativeBuffer, final long timestamp) {
        this.encodeFrame(Unmanaged.wrapBuffer(nativeBuffer, (long) (this.width * this.height * 4)), timestamp);
    }

    @Override
    public synchronized void encodeSamples(final float[] samples, final long timestamp) {
        this.audioQueueHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                final short[] sampleBuffer = new short[samples.length];
                for (int i = 0; i < samples.length; ++i) {
                    sampleBuffer[i] = (short) (samples[i] * 32767.0f);
                }
                final int bufferIndex = MP4Recorder.this.audioCodec.dequeueInputBuffer(-1L);
                final ByteBuffer buffer = MP4Recorder.this.audioCodec.getInputBuffer(bufferIndex);
                buffer.asShortBuffer().put(sampleBuffer);
                MP4Recorder.this.audioCodec.queueInputBuffer(bufferIndex, 0, sampleBuffer.length * 2, timestamp / 1000L, 0);
            }
        });
    }
}
