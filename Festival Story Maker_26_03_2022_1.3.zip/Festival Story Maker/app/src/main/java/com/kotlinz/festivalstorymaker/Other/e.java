package com.kotlinz.festivalstorymaker.Other;

import com.google.gson.reflect.TypeToken;

import java.util.List;

public class e extends TypeToken<List<String>> {
}
