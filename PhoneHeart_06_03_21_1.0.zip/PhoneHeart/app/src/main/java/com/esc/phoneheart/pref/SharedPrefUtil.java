package com.esc.phoneheart.pref;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class SharedPrefUtil {
    public static final String ADUNIT_DATA = "ADUNIT_DATA";
    public static final String AFTERCOOLTEMP = "AFTERCOOLTEMP";
    public static final String FIRST_LAUNCH = "first_launch";
    public static final String HIDE_AUTOSTART = "HIDE_AUTOSTART";
    public static final String INST_DET_SENT = "INST_DET_SENT";
    public static final String JUNCCLEANTIME = "junccleantime";
    public static String LASTBOOSTTIME = "lastboosttime";
    public static final String LASTCOOLTIME = "LASTCOOLTIME";
    public static final String LASTTIMEJUNKCLEANED = "LASTTIMEJUNKCLEANED";
    public static final String LAST_SCREEN = "LAST_SCREEN";
    public static final String LAST_TIME_VISIT = "LAST_TIME_VISIT";
    public static String LOGIN_STATUS = "login_status";
    public static final String LUSED_JUNK = "LUSED_JUNK";
    public static final String LUSED_SPACE_MANAGER = "LUSED_SPACE_MANAGER";
    public static final String PIX = "PIX";
    public static final String PUSHTOKEN = "PUSHTOKEN";
    public static final String RAMATPAUSE = "RAMATPAUSE";
    public static final String RAMPAUSE = "RAMPAUSE";
    public static final String RATED = "RATED2";
    public static final String RATED_AT = "RATED_AT";
    public static final String REALTIME_PROTECTION_STATE = "real_time_protection_state";
    public static final String REFFER_CODE = "reffer";
    public static final String RETEN_TRACKED = "RETEN_TRACKED";
    public static final String SPLASH_FIRST = "SPLASH_FIRST";
    public static final String USER_SP = "def_spr";
    public static final String RES_VCOUNT = "RES_VCOUNT";

    public Context mContext;
    public SharedPreferences sharedPreferences;

    public SharedPrefUtil(Context context) {
        this.mContext = context;
        try {
            this.sharedPreferences = context.getSharedPreferences(USER_SP, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getBoolean(String str) {
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(USER_SP, 0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(sharedPreferences.getBoolean(str, false));
        Log.e(str, stringBuilder.toString());
        return sharedPreferences.getBoolean(str, false);
    }

    public int getInt(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getInt(str, 0);
    }

    public String getString(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getString(str, null);
    }

    public void saveBoolean(String str, boolean z) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putBoolean(str, z);
        edit.apply();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e(str, stringBuilder.toString());
    }

    public void saveInt(String str, int i) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putInt(str, i);
        edit.apply();
    }

    public void saveLastTimeUsed(String str, long j) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putLong(str, j);
        edit.apply();
    }

    public void saveString(String str, String str2) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putString(str, str2);
        edit.apply();
    }
}
