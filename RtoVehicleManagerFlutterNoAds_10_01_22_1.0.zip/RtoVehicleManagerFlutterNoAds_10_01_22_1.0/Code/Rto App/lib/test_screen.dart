import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Test extends StatefulWidget {
  const Test({Key? key}) : super(key: key);

  @override
  _TestState createState() => _TestState();
}

class _TestState extends State<Test> {
  int? _currIndex;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: IconButton(
            icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 500),
                transitionBuilder: (child, anim) => RotationTransition(
                      turns: child.key == ValueKey('icon1')
                          ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                          : child.key == ValueKey('icon2')
                              ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                              : Tween<double>(begin: 0.75, end: 1)
                                  .animate(anim),
                      child: ScaleTransition(scale: anim, child: child),
                    ),
                child: _currIndex == 0
                    ? Image.asset("assets/images/b.png",
                        key: const ValueKey('icon1'))
                    : Icon(
                        CupertinoIcons.check_mark_circled,
                        key: const ValueKey('icon2'),
                      )),
            onPressed: () {
              setState(() {
                _currIndex = _currIndex == 0 ? 1 : 0;
              });
            },
          ),
        ),
      ),
    );
  }
}
