package com.esc.socialmediacleaner.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class SavedData {
    private static final String ACCEPT = "ACCEPT";
    private static final String USER_SP = "def_spr";
    private Context mContext;
    private SharedPreferences sharedPreferences;

    public SavedData(Context context) {
        this.mContext = context;
        try {
            this.sharedPreferences = context.getSharedPreferences(USER_SP, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getString(String str) {
        return this.mContext.getSharedPreferences(USER_SP, 0).getString(str, null);
    }

    public void saveBoolean(String str, boolean z) {
        Editor edit = this.mContext.getSharedPreferences(USER_SP, 0).edit();
        edit.putBoolean(str, z);
        edit.apply();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        Log.e(str, stringBuilder.toString());
    }

    public boolean getBoolean(String str) {
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(USER_SP, 0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(sharedPreferences.getBoolean(str, false));
        Log.e(str, stringBuilder.toString());
        return sharedPreferences.getBoolean(str, false);
    }

    public void setAccepted() {
        saveBoolean(ACCEPT, true);
    }

    public boolean isAccepted() {
        return getBoolean(ACCEPT);
    }

}
