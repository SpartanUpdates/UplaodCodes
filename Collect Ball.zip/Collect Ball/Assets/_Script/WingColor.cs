﻿using UnityEngine;

public class WingColor : MonoBehaviour
{
    public MeshRenderer targetMesh;
    private void OnEnable()
    {
        this.GetComponent<MeshRenderer>().material = targetMesh.material;
    }
}
