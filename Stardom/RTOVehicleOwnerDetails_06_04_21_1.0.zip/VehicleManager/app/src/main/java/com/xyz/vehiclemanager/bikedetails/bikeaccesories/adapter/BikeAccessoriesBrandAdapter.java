package com.xyz.vehiclemanager.bikedetails.bikeaccesories.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikeaccesories.activity.BikeAccessoriesDetailActivity;
import com.xyz.vehiclemanager.model.BikeBrands;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BikeAccessoriesBrandAdapter extends RecyclerView.Adapter<BikeAccessoriesBrandAdapter.MyViewHolder>
{
    Context mcontext;
    ArrayList<BikeBrands> bikeServiceBrands;

    public class MyViewHolder extends RecyclerView.ViewHolder{
       ImageView iv_bikebrandImage;
       TextView tv_bikebrandName;
       LinearLayout rl_bikebrand;

        public MyViewHolder(@NonNull View itemView) {
           super(itemView);

           iv_bikebrandImage = itemView.findViewById(R.id.iv_bikebrandImage);
           tv_bikebrandName = itemView.findViewById(R.id.tv_bikebrandName);
           rl_bikebrand = itemView.findViewById(R.id.ll_bikebrand);
       }
    }

    public BikeAccessoriesBrandAdapter(Context context, ArrayList<BikeBrands> bikeServiceBrands) {
        this.mcontext = context;
        this.bikeServiceBrands = bikeServiceBrands;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_bikebrands,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final BikeBrands bikeBrands = bikeServiceBrands.get(position);
        holder.tv_bikebrandName.setText(bikeBrands.getBrandName());

        Glide.with(mcontext)
                .load(bikeBrands.getImageUrl())
                .placeholder(R.drawable.ic_bike)
                .into(holder.iv_bikebrandImage);

        holder.rl_bikebrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mcontext, BikeAccessoriesDetailActivity.class);
                intent.putExtra("id", bikeBrands.getId());
                intent.putExtra("brandName",bikeBrands.getBrandName());
                mcontext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bikeServiceBrands.size();
    }
}
