package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.Models.b;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BackgroundListAdapter extends RecyclerView.Adapter<BackgroundListAdapter.ViewHolder> {

    public Activity activity;
    public ArrayList<b> backgroundList;
    public a i;
    public int SelectedPosition;
    public SeekBar seekBar;

    public BackgroundListAdapter(Activity activity, ArrayList<b> arrayList, int i, a aVar, SeekBar seekBar) {
        this.activity = activity;
        this.backgroundList = arrayList;
        this.i = aVar;
        this.SelectedPosition = i;
        this.seekBar = seekBar;
    }


    public interface a {
        void a(int i, int i2, SeekBar seekBar);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_highlight_bg_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (((b) this.backgroundList.get(position)).g.length() > 0) {
            Picasso.get().load(((b) this.backgroundList.get(position)).g).placeholder(R.drawable.progress).into(holder.img,null);
        }
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (((com.kotlinz.festivalstorymaker.Models.b) backgroundList.get(position)).h.equalsIgnoreCase("0")) {
                    if (backgroundList.get(position) == null) {
                        return;
                    }
                } else if (!Utils.y(activity, true)) {
                    return;
                }
                i.a(position, SelectedPosition, seekBar);
            }
        });

    }

    @Override
    public int getItemCount() {
        return backgroundList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
