package com.esc.flashlight.service;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.receiver.ScreenReceiver;
import com.esc.flashlight.util.FlashAlertUtil;
import com.esc.flashlight.util.PrefManager;


public class ScreenOnOffService extends Service {
    public static final String EXTRA_BOOT_COMPLETED = "boot_completed";
    private static final String TAG = "ScreenOnOffService";
    private ScreenReceiver sReceiver;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        String str = TAG;
        Log.d(str, "onCreate");
        if (this.sReceiver == null) {
            this.sReceiver = new ScreenReceiver();
        }
        Context applicationContext = getApplicationContext();
        Intent intent = new Intent(applicationContext, this.sReceiver.getClass());
        String str2 = "android.intent.action.SCREEN_ON";
        intent.setAction(str2);
        if (PendingIntent.getBroadcast(applicationContext, 0, intent, 134217728) == null) {
            IntentFilter intentFilter = new IntentFilter(str2);
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            Log.d(str, "registerReceiver ");
            registerReceiver(this.sReceiver, intentFilter);
        }
    }

    public void onStart(Intent intent, int i) {
        String str = TAG;
        Log.d(str, "onStart");
        if (intent != null && intent.getBooleanExtra(EXTRA_BOOT_COMPLETED, false)) {
            Context applicationContext = getApplicationContext();
            PrefManager prefManager = APP.getPrefManager();
            if (!prefManager.getUseScreenOn()) {
                if (FlashAlertUtil.isScreenOn(applicationContext)) {
                    Log.d(str, "boot completed and screen on");
                    prefManager.setScreenOnTime(SystemClock.elapsedRealtime() - FlashAlertUtil.SCREEN_ON_SAFE_DELAY);
                    return;
                }
                prefManager.setScreenOnTime(-1);
            }
        }
    }

    public void onDestroy() {
        String str = TAG;
        Log.d(str, "onDestroy");
        super.onDestroy();
        try {
            if (this.sReceiver != null) {
                unregisterReceiver(this.sReceiver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        PrefManager prefManager = APP.getPrefManager();
        if (!prefManager.getUseScreenOn() && prefManager.getUseTotally()) {
            startService(new Intent(getApplicationContext(), getClass()));
        }
    }
}
