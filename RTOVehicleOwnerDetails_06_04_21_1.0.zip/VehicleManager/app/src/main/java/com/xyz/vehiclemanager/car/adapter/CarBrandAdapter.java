package com.xyz.vehiclemanager.car.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.activity.CarCategoryActivity;
import com.xyz.vehiclemanager.model.CarBrands;

import java.util.ArrayList;

public class CarBrandAdapter extends RecyclerView.Adapter<CarBrandAdapter.ViewHolder> {

    Context context;
    ArrayList<CarBrands> carbrandlist;

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView iv_carbrands;
        TextView tv_carbrandsname;
        LinearLayout ll_carbrand;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_carbrands = itemView.findViewById(R.id.iv_carbrands);
            tv_carbrandsname = itemView.findViewById(R.id.tv_carbrandsname);
            ll_carbrand = itemView.findViewById(R.id.ll_carbrand);
        }
    }

    public CarBrandAdapter(Context context, ArrayList<CarBrands> bikeBrandModelArrayList) {
        this.context = context;
        this.carbrandlist = bikeBrandModelArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_carbrads,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CarBrands carBrand = carbrandlist.get(position);
        holder.tv_carbrandsname.setText(carBrand.getBrandName());
        Glide.with(context).load(carBrand.getImageUrl()).placeholder(R.drawable.ic_car).into(holder.iv_carbrands);
        final String id= String.valueOf(carBrand.getId());

        holder.ll_carbrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, CarCategoryActivity.class);
                intent.putExtra("id", id);
                intent.putExtra("name", carBrand.getBrandName());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {
        return carbrandlist.size();
    }
}
