package com.vidsoft.collagemaker.Utils.Stickers;

import android.os.Build;
import android.util.Log;
import android.view.MotionEvent;

public class WrapMotionEvent {
	protected MotionEvent event;

	protected WrapMotionEvent(final MotionEvent event) {
		super();
		this.event = event;
	}

	private void verifyPointerIndex(final int n) {
		if (n > 0) {
			throw new IllegalArgumentException(
					"Invalid pointer index for Donut/Cupcake");
		}
	}

	public static WrapMotionEvent wrap(final MotionEvent motionEvent) {
		if (Integer.parseInt(Build.VERSION.SDK) >= 5) {
			Log.d("WrapMotionEvent", "Using Eclair version");
			return new EclairMotionEvent(motionEvent);
		}
		Log.d("WrapMotionEvent", "Using Cupcake/Donut version");
		return new WrapMotionEvent(motionEvent);
	}

	public int getAction() {
		return this.event.getAction();
	}

	public int getPointerCount() {
		return 1;
	}

	public int getPointerId(final int n) {
		this.verifyPointerIndex(n);
		return 0;
	}

	public float getX() {
		return this.event.getX();
	}

	public float getX(final int n) {
		this.verifyPointerIndex(n);
		return this.getX();
	}

	public float getY() {
		return this.event.getY();
	}

	public float getY(final int n) {
		this.verifyPointerIndex(n);
		return this.getY();
	}
}
