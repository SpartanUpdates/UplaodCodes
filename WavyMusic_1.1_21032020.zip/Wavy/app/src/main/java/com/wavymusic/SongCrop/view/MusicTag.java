package com.wavymusic.SongCrop.view;

import android.util.Log;

public class MusicTag {
    public static boolean a = true;

    public static void a(String str, String str2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str2);
            Log.i(str, stringBuilder.toString());
        }
    }

    public static void b(String str, String str2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str2);
        }
    }

    public static void c(String str, String str2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str2);
        }
    }

    public static void d(String str, String str2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str2);
        }
    }

    public static void e(String str, String str2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str2);
            Log.d(str, stringBuilder.toString());
        }
    }
}
