package com.claptoflashlightonoff.util;

public interface onDragSwitchChangeListener {
  void switchChangeState(boolean z);
}
