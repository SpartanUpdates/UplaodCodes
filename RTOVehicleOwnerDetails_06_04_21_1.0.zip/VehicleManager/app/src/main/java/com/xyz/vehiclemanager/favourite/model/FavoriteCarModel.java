package com.xyz.vehiclemanager.favourite.model;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "FavoriteCar",indices = @Index(value = {"modelId"},unique = true))
public class FavoriteCarModel
{
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String modelId;
    public String modelName;
    public String exShowroomPrice;
    public String imageUrl;

    public FavoriteCarModel(String modelId, String modelName, String exShowroomPrice, String imageUrl) {
        this.modelId = modelId;
        this.modelName = modelName;
        this.exShowroomPrice = exShowroomPrice;
        this.imageUrl = imageUrl;
    }

    public int getId() {
        return id;
    }

    public String getModelId() {
        return modelId;
    }

    public String getModelName() {
        return modelName;
    }

    public String getExShowroomPrice() {
        return exShowroomPrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
