package com.kotlinz.videoCollage.puzzleview.slant;


import com.kotlinz.videoCollage.flying.puzzle.Line;

public class ThreeSlantLayout extends NumberSlantLayout {
    public int getThemeCount() {
        return 6;
    }

    public ThreeSlantLayout(int i) {
        super(i);
    }

    public void layout() {
        int i = this.theme;
        if (i == 0) {
            addLine(0, Line.Direction.HORIZONTAL, 0.5f);
            addLine(0, Line.Direction.VERTICAL, 0.56f, 0.44f);
        } else if (i == 1) {
            addLine(0, Line.Direction.HORIZONTAL, 0.5f);
            addLine(1, Line.Direction.VERTICAL, 0.56f, 0.44f);
        } else if (i == 2) {
            addLine(0, Line.Direction.VERTICAL, 0.5f);
            addLine(0, Line.Direction.HORIZONTAL, 0.56f, 0.44f);
        } else if (i == 3) {
            addLine(0, Line.Direction.VERTICAL, 0.5f);
            addLine(1, Line.Direction.HORIZONTAL, 0.56f, 0.44f);
        } else if (i == 4) {
            addLine(0, Line.Direction.HORIZONTAL, 0.44f, 0.56f);
            addLine(0, Line.Direction.VERTICAL, 0.56f, 0.44f);
        } else if (i == 5) {
            addLine(0, Line.Direction.VERTICAL, 0.56f, 0.44f);
            addLine(1, Line.Direction.HORIZONTAL, 0.44f, 0.56f);
        }
    }
}
