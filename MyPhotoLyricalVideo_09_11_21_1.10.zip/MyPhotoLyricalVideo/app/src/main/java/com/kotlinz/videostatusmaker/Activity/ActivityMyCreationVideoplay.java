package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.os.StrictMode;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import java.io.File;
import java.util.concurrent.TimeUnit;
import com.kotlinz.videostatusmaker.Utils.Utils;
import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class ActivityMyCreationVideoplay extends Activity implements View.OnClickListener {
    Activity activity = ActivityMyCreationVideoplay.this;
    ImageView ivBack;
    VideoView videoView;
    Drawable drawable_bitmap;
    RelativeLayout relativeLayout;
    ImageView delete;
    TextView endTime;
    Typeface typeface;
    RelativeLayout relativeLayout1;
    String strNewurl;
    LinearLayout play_lay;
    ImageView play_pause;
    SeekBar player_seek;
    Runnable run = new Runnable() {
        @Override
        public void run() {
            ActivityMyCreationVideoplay.this.seekUpdation();
        }
    };
    Handler seekHandler = new Handler();
    ImageView share;
    TextView start_time;
    TextView title;
    private ImageView imgFacebook;
    private ImageView imgInstagram;
    private ImageView imgTwitter;
    private ImageView imgWhatsApp;

    private NativeAd nativeAd;

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.saved_video);
        final StrictMode.VmPolicy.Builder strictMode$VmPolicy$Builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(strictMode$VmPolicy$Builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            strictMode$VmPolicy$Builder.detectFileUriExposure();
        }
        this.getWindow().addFlags(1024);
        PutAnalyticsEvent();
        bindView();
        LoadNativeAds();
        addListener();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityMyCreationVideoplay");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    protected void onPause() {
        this.videoView.pause();
        this.videoView.setBackgroundDrawable(this.drawable_bitmap);
        this.play_pause.setImageResource(R.drawable.play);
        super.onPause();
    }

    public void seekUpdation() {
        this.player_seek.setMax(this.videoView.getDuration());
        this.start_time.setText(String.format("%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getCurrentPosition())), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds((long) this.videoView.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getCurrentPosition())))}));
        this.endTime.setText(String.format("%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getDuration())), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds((long) this.videoView.getDuration()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) this.videoView.getDuration())))}));
        this.player_seek.setProgress(this.videoView.getCurrentPosition());
        this.seekHandler.postDelayed(this.run, 10);
    }

    public void onBackPressed() {
        this.videoView.stopPlayback();
        Utils.count = 0;
        startActivity(new Intent(ActivityMyCreationVideoplay.this, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    private void init() {
        final MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(this.strNewurl = ActivityMyCreations.photoArrayList.get(ActivityMyCreations.pos));
            mediaPlayer.prepare();
            if (mediaPlayer.getVideoWidth() < mediaPlayer.getVideoHeight()) {
                final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0);
                layoutParams.weight = 9.1f;
                this.relativeLayout1.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
            } else {
                this.delete.setVisibility(View.VISIBLE);
                this.share.setVisibility(View.VISIBLE);
            }
            this.videoView.setVideoPath(this.strNewurl);
            this.videoView.setOnCompletionListener((MediaPlayer.OnCompletionListener) new MediaPlayer.OnCompletionListener() {
                public void onCompletion(final MediaPlayer mediaPlayer) {
                    ActivityMyCreationVideoplay.this.play_pause.setImageResource(R.drawable.play);
                    ActivityMyCreationVideoplay.this.player_seek.setProgress(0);
                }
            });
            this.videoView.start();
            this.seekUpdation();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        videoView.stopPlayback();
                        Utils.count = 0;
                        MyApplication.AdsId = 15;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.share.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityMyCreationVideoplay.this.share_video();
            }
        });

        this.play_pause.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityMyCreationVideoplay.this.videoView.setBackgroundDrawable((Drawable) null);
                if (ActivityMyCreationVideoplay.this.videoView.isPlaying()) {
                    ActivityMyCreationVideoplay.this.videoView.pause();
                    ActivityMyCreationVideoplay.this.play_pause.setImageResource(R.drawable.play);
                    return;
                }
                ActivityMyCreationVideoplay.this.videoView.start();
                ActivityMyCreationVideoplay.this.play_pause.setImageResource(R.drawable.play);
            }
        });
        this.delete.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityMyCreationVideoplay.this.delete_video();
            }
        });
        try {
            Glide.with(this).load(this.strNewurl).listener(new RequestListener<String, GlideDrawable>() {
                @Override
                public boolean onException(final Exception ex, final String s, final Target<GlideDrawable> target, final boolean b) {
                    return true;
                }

                @Override
                public boolean onResourceReady(final GlideDrawable bitmap, final String s, final Target<GlideDrawable> target, final boolean b, final boolean b2) {
                    ActivityMyCreationVideoplay.this.drawable_bitmap = bitmap;
                    return true;
                }
            }).into((ImageView) this.findViewById(R.id.im));
        } catch (Exception ex2) {
            ex2.toString();
        }
        this.player_seek.setEnabled(false);
    }

    private void addListener() {
        this.imgFacebook.setOnClickListener(this);
        this.imgInstagram.setOnClickListener(this);
        this.imgWhatsApp.setOnClickListener(this);
        this.imgTwitter.setOnClickListener(this);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ActivityMyCreationVideoplay.this.nativeAd != null) {
                            ActivityMyCreationVideoplay.this.nativeAd.destroy();
                        }
                        ActivityMyCreationVideoplay.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void bindView() {
        this.videoView = (VideoView) findViewById(R.id.bg_video);
        this.share = (ImageView) findViewById(R.id.share);
        this.delete = (ImageView) findViewById(R.id.delete);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.title = (TextView) findViewById(R.id.title);
        this.relativeLayout1 = (RelativeLayout) findViewById(R.id.main);
        this.relativeLayout = (RelativeLayout) findViewById(R.id.center_lay);
        this.play_lay = (LinearLayout) findViewById(R.id.play_lay);
        this.start_time = (TextView) findViewById(R.id.start_time);
        this.endTime = (TextView) findViewById(R.id.end_time);
        this.play_pause = (ImageView) findViewById(R.id.play_pause);
        this.player_seek = (SeekBar) findViewById(R.id.player_seek);
        this.imgWhatsApp = (ImageView) findViewById(R.id.imgFacebook);
        this.imgFacebook = (ImageView) findViewById(R.id.imgWhatsApp);
        this.imgInstagram = (ImageView) findViewById(R.id.imgInstagram);
        this.imgTwitter = (ImageView) findViewById(R.id.imgTwitter);
    }


    void delete_video() {
        final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder((Context) this);
        alertDialog$Builder.setTitle((CharSequence) "Confirm Delete !");
        alertDialog$Builder.setMessage((CharSequence) "Are you sure to delete Video??");
        alertDialog$Builder.setPositiveButton((CharSequence) "YES", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
                if (new File(ActivityMyCreationVideoplay.this.strNewurl).delete()) {
                    ActivityMyCreations.photoArrayList.remove(ActivityMyCreations.pos);
                    MediaScannerConnection.scanFile((Context) ActivityMyCreationVideoplay.this, new String[]{ActivityMyCreationVideoplay.this.strNewurl}, new String[]{"video/*"}, (MediaScannerConnection.OnScanCompletedListener) null);
                    Toast.makeText((Context) ActivityMyCreationVideoplay.this, (CharSequence) "File Deleted", Toast.LENGTH_SHORT).show();
                }
                ActivityMyCreationVideoplay.this.onBackPressed();
            }
        });
        alertDialog$Builder.setNegativeButton((CharSequence) "NO", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
            }
        });
        alertDialog$Builder.show();
    }

    void share_video() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        File file = new File(this.strNewurl);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file://");
        stringBuilder.append(file.getAbsolutePath());
        intent.putExtra("android.intent.extra.STREAM", Uri.parse(stringBuilder.toString()));
        startActivity(Intent.createChooser(intent, "Share Video"));
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgFacebook:
                shareImageWhatsApp("com.facebook.katana", "Facebook");
                return;
            case R.id.imgInstagram:
                shareImageWhatsApp("com.instagram.android", "Instagram");
                return;
            case R.id.imgTwitter:
                shareImageWhatsApp("com.twitter.android", "Twitter");
                return;
            case R.id.imgWhatsApp:
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
                return;


            default:
        }

    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    public void shareImageWhatsApp(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(this.strNewurl));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.strNewurl));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, "Create Amazing Photo Layrics Videos"));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }
}
