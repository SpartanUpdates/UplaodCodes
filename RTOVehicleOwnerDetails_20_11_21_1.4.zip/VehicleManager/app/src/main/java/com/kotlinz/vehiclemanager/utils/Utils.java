package com.kotlinz.vehiclemanager.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.io.IOException;
import java.io.InputStream;

public class Utils {
    public static String id2 = "=";
    public static String[] actorsname = new String[]{"Amitabh Bachachan", "Farhan Akhtar", "Sanjay Dutt", "Arbaaz Khan", "Ranbir R Kapoor", "John Abraham", "Arjun Kapoor", "Hritik R Roshan", "Kapil Sharma", "Emran Hashmi", "Amir Khan", "David Dhawan", "Sidharth Malhotra", "Sushant Singh Rajput", "Sonu Pankaj Sood", "Shahid Kapoor", "Neil Nitin Mukesh", "Vivek Anand Oberoi", "Prabhas Uvsr", "Abhishek Bachachan"};
    public static String[] actorsnum = new String[]{"MH02EE1100", "MH02BJ7800", "MH02CB4545", "MH02BY2727", "MH02BT0008", "MH02CZ0300", "MH02CP2600", "MH46AD1001", "MH04FZ7740", "MH02CP8880", "MH02DZ0007", "MH02CW7668", "MH02DN1600", "MH02EC4747", "MH02DM0007", "MH02EH7000", "MH01AU2277", "MH14FM9707", "AP09CJ5677", "MH02CV2882"};
    public static String id3 = "MmNlYTI3YzA5OD";
    public static String[] actressesname = new String[]{"Shraddha Kapoor", "Parineeti Chopra", "Alia Bhatt", "Shilpa Shetty", "Priyanka Chopra", "Bipasa Basu", "Kareena Kapoor", "Shweta Tiwari", "Jacqueline G Fernandez", "Sonakshi Sinha", "Sonam Kapoor", "Neha Saraf", "Vidya Balan", "Rani Mukherjee", "Neha Sharma", "Kangana A Ranaut", "Rekha Ganeshan", "Asin Thottumkal", "Genelia D'Souza"};
    public static String[] actressesnum = new String[]{"MH04GM9660", "HR01AH0081", "MH02DW1500", "MH05CA0010", "MH02DJ9099", "MH02CZ0700", "MH02DZ4323", "MH02DJ8434", "MH02CL0200", "MH12JB0222", "MH46AL6116", "MH01BN5539", "MH03AR9577", "MH02JP9927", "MH43AT6990", "MH02BM0005", "MH02BJ4681", "MH02BZ0004", "MH02BP5550"};
    public static String[] dancersname = new String[]{"Tiger Shroff", "Allu Arjun", "Farha Khan", "Mudassar Khan", "Hema Malini", "Kunwar Amar"};
    public static String id4 = "ZhZGM0Y2I4ZTY";
    public static String[] dancersnum = new String[]{"MH02EP0447", "AP09CQ0666", "MH02DJ6444", "MH04DR5499", "HR26AM5556", "MH01AE8398"};
    public static String[] mrperfectsname = new String[]{"Mukesh Ambani", "Anil Ambani", "Ratan Tata", "Acharya Balkrishna", "Raj Kundra", "Anand Mahindra", "Naveen Jindal", "Aakash Ambani"};
    public static String[] mrperfectsnum = new String[]{"MH01CP8619", "DL4CAN5193", "MH01AL0111", "UK08AL0008", "MH05CA0010", "MH01BR1555", "DL3CBV3946", "MH01CL0123"};
    public static String id5 = "NDIxOTAzNTI2M";
    public static String[] politiciansname = new String[]{"Narendra Modi", "Arun Jaitley", "Jayalalitha", "Mulayam Singh", "Nitin Gadakari", "Swaroop Paresh Rawal", "Akhilesh Yadav"};
    public static String[] politiciansnum = new String[]{"DL4CCB3333", "DL10CA6666", "TN09BE6167", "UP32BG5804", "MH49AE2700", "MH02EP6798", "UP65CM4149"};
    public static String[] singersname = new String[]{"Arijit Singh", "Sonu Nigam", "Anu Malik", "Satinder Pal Singh Sartaaj", "Arman Malik", "Farhan Javed Akhtar", "Aditya Udit Narayan Jha", "Abhijit Bhattacharya", "Abhijit Sawant", "Salim P Merchant", "Amit Kumar Verma", "Joseph Vijay"};
    public static String[] singersnum = new String[]{"MP04CM6578", "MH02CG0002", "MH02EP7027", "DL06CM5689", "PY01BS4040", "MH02DZ7800", "MH14FZ6000", "MH40AR0919", "MH02DW7576", "MH02DN0600", "CG07BE4966", "TN07BV0014"};
    public static String[] sportspersonsname = new String[]{"Mahendra Singh Dhoni", "Virat Kohli"};
    public static String[] sportspersonsnum = new String[]{"JH01AV1976", "HR26BW0018"};
    public static String id = id3 + id4 + "0" + politiciansname[0].charAt(0) + "DIxOTAzNTI2MmQ";

    //Method for check the Network is Available or not
    public static boolean isOnline(Context context) {
        NetworkInfo netInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            return false;
        }
        return true;
    }

    public static String getStateCityFromJson(Context context, String fileName) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

}
