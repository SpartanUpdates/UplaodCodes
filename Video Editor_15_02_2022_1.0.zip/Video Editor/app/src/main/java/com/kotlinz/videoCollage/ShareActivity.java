package com.kotlinz.videoCollage;

import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.SurfaceTexture;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.views.AutoFitTextureView;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener, TextureView.SurfaceTextureListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener {
    private String from;
    private ImageView imgFace;
    private ImageView imgInsta;
    private ImageView imgLink;
    private ImageView imgMore;
    private ImageView imgMsg;
    private ImageView imgPreview;
    private ImageView imgWhat;
    private LinearLayout linSeekView;
    private Handler mHandler;
    private int mVideoHeight;
    private int mVideoWidth;
    private MediaPlayer mediaPlayer;
    private String path;
    private ImageView playPause;
    private SeekBar seekBar;
    public SurfaceTexture surfaceTexture;
    private TextView textDuration;
    private AutoFitTextureView textureView;
    private TextView txtImageSize;

    ImageView iv_back, iv_done;

    private NativeAd nativeAd;

    public ShareActivity() {
        this.mHandler = new Handler();
    }

    public String convertSecondsToHMmSs(final long n) {
        return String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(n), TimeUnit.MILLISECONDS.toSeconds(n));
    }

    public String getStringSizeLengthFile(final long n) {
        final DecimalFormat decimalFormat = new DecimalFormat("0.00");
        final float n2 = (float) n;
        if (n2 < 1048576.0f) {
            final StringBuilder sb = new StringBuilder();
            sb.append(decimalFormat.format(n2 / 1024.0f));
            sb.append(" KB");
            return sb.toString();
        }
        if (n2 < 1.07374182E9f) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(decimalFormat.format(n2 / 1048576.0f));
            sb2.append(" MB");
            return sb2.toString();
        }
        if (n2 < 1.09951163E12f) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(decimalFormat.format(n2 / 1.07374182E9f));
            sb3.append(" GB");
            return sb3.toString();
        }
        return "";
    }

    public void mediaInit() {
        if (Uri.parse(this.path) != null && this.surfaceTexture != null) {
            this.mediaRelease();
            try {
                final MediaPlayer mediaPlayer = new MediaPlayer();
                (this.mediaPlayer = mediaPlayer).setAudioSessionId(mediaPlayer.getAudioSessionId());
                this.mediaPlayer.setOnPreparedListener(this);
                this.mediaPlayer.setOnCompletionListener(this);
                this.mediaPlayer.setOnErrorListener(this);
                this.mediaPlayer.setDataSource(this, Uri.parse(this.path), null);
                this.mediaPlayer.setSurface(new Surface(this.surfaceTexture));
                this.mediaPlayer.setAudioStreamType(3);
                this.mediaPlayer.prepareAsync();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("openVideo error ");
        sb.append(Uri.parse(this.path));
        sb.append(" ");
        sb.append(this.surfaceTexture);
        sb.append(" ");
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(" mediaInit :: if ::-> ");
        sb2.append(sb.toString());
        Log.e("ShareActivity", sb2.toString());
    }

    public void mediaRelease() {
        final MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
    }

    public void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.startActivity(new Intent(this, StartActivity.class));

    }

    public void onClick(final View view) {
        final int id = view.getId();
        final int n = 0;
        final int n2 = 0;
        Label_1111:
        {
            switch (id) {
                case R.id.img_what: {
                    final Intent intent = new Intent("android.intent.action.SEND");
                    if (Util.isVideoFile(this.path)) {
                        intent.setType("video/*");
                    } else {
                        intent.setType("image/*");
                    }
                    intent.setPackage("com.whatsapp");
                    intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.path)));
                    try {
                        this.startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                        Toast.makeText(this, "Whatsapp have not been installed.", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                case R.id.img_msg: {
                    final Intent intent2 = new Intent("android.intent.action.VIEW");
                    if (Util.isVideoFile(this.path)) {
                        intent2.setType("video/*");
                    } else {
                        intent2.setType("image/*");
                    }
                    intent2.setAction("android.intent.action.SEND");
                    intent2.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.path)));
                    final Iterator iterator = this.getPackageManager().queryIntentActivities(intent2, 0).iterator();
                    while (true) {
                        ResolveInfo resolveInfo;
                        do {
                            final int n3 = n2;
                            if (iterator.hasNext()) {
                                resolveInfo = (ResolveInfo) iterator.next();
                            } else {
                                if (n3 != 0) {
                                    this.startActivity(Intent.createChooser(intent2, "Share images..."));
                                    break Label_1111;
                                }
                                Toast.makeText(this, "Please Install Facebook Messenger", Toast.LENGTH_LONG).show();
                                break Label_1111;
                            }
                        } while (!resolveInfo.activityInfo.packageName.toLowerCase().equalsIgnoreCase("com.facebook.orca") && !resolveInfo.activityInfo.packageName.toLowerCase().equalsIgnoreCase("com.facebook.mlite"));
                        intent2.setPackage(resolveInfo.activityInfo.packageName);
                        final int n3 = 1;
                        continue;
                    }
                }
                case R.id.img_more: {
                    final Intent intent3 = new Intent("android.intent.action.SEND");
                    intent3.putExtra("android.intent.extra.SUBJECT", "Video Maker");
                    if (Util.isVideoFile(this.path)) {
                        intent3.setType("video/*");
                    } else {
                        intent3.setType("image/*");
                    }
                    intent3.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.path)));
                    this.startActivity(Intent.createChooser(intent3, "Where to Share?"));
                    break;
                }
                case R.id.img_insta: {
                    final Intent intent4 = new Intent("android.intent.action.SEND");
                    if (Util.isVideoFile(this.path)) {
                        intent4.setType("video/*");
                    } else {
                        intent4.setType("image/*");
                    }
                    intent4.setPackage("com.instagram.android");
                    final ContentResolver contentResolver = this.getContentResolver();
                    final String[] array = {"_id", "title", "datetaken"};
                    final Uri external_CONTENT_URI = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    final StringBuilder sb = new StringBuilder();
                    sb.append(array[1]);
                    sb.append(" DESC");
                    final Cursor query = contentResolver.query(external_CONTENT_URI, array, null, null, sb.toString());
                    if (query.moveToFirst()) {
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append("last picture (");
                        sb2.append(query.getString(1));
                        sb2.append(") taken on: ");
                        sb2.append(new Date(query.getLong(2)));
                        Log.i("Test", sb2.toString());
                    }
                    intent4.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.path)));
                    query.close();
                    try {
                        this.startActivity(intent4);
                    } catch (ActivityNotFoundException ex2) {
                        Toast.makeText(this, "Instagram have not been installed.", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                case R.id.img_in: {
                    final Intent intent5 = new Intent("android.intent.action.SEND");
                    if (Util.isVideoFile(this.path)) {
                        intent5.setType("video/*");
                    } else {
                        intent5.setType("image/*");
                    }
                    intent5.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, "com.kotlinz.videoeditor.provider", new File(this.path)));
                    final Iterator iterator2 = this.getPackageManager().queryIntentActivities(intent5, 0).iterator();
                    while (true) {
                        ResolveInfo resolveInfo2;
                        do {
                            final int n4 = n;
                            if (iterator2.hasNext()) {
                                resolveInfo2 = (ResolveInfo) iterator2.next();
                            } else {
                                if (n4 != 0) {
                                    this.startActivity(intent5);
                                    break Label_1111;
                                }
                                Toast.makeText(this, "LinkedIn app not Insatlled in your mobile", Toast.LENGTH_LONG).show();
                                break Label_1111;
                            }
                        } while (!resolveInfo2.activityInfo.packageName.toLowerCase().startsWith("com.linkedin.android") && !resolveInfo2.activityInfo.packageName.toLowerCase().startsWith("com.linkedin.android.lite"));
                        intent5.setPackage(resolveInfo2.activityInfo.packageName);
                        final int n4 = 1;
                        continue;
                    }
                }
                case R.id.img_face: {
                    break;
                }
            }
        }
    }

    public void onCompletion(final MediaPlayer mediaPlayer) {
        this.seekBar.setProgress(0);
       // mediaPlayer.start();
        playPause.setBackgroundResource(R.drawable.ic_play_upress);
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_share);
        this.path = getIntent().getStringExtra("SELECTED_PATH");
        this.from = getIntent().getStringExtra("FROM");
        PutAnalyticsEvent();
        LoadNativeAds();
        this.imgPreview = findViewById(R.id.img_preview);
        this.textureView = findViewById(R.id.texture_view);
        this.txtImageSize = findViewById(R.id.txt_image_size);
        this.imgFace = findViewById(R.id.img_face);
        this.imgWhat = findViewById(R.id.img_what);
        this.imgInsta = findViewById(R.id.img_insta);
        this.imgMsg = findViewById(R.id.img_msg);
        this.imgLink = findViewById(R.id.img_in);
        this.imgMore = findViewById(R.id.img_more);
        this.linSeekView = findViewById(R.id.lin_seek_view);
        this.playPause = findViewById(R.id.btnPlayVideo);
        this.seekBar = findViewById(R.id.seek_vid);
        this.textDuration = findViewById(R.id.txt_duration);
        iv_back = findViewById(R.id.iv_back);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        iv_done=findViewById(R.id.iv_done);
        iv_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShareActivity.this,StartActivity.class));
                finish();
            }
        });

        this.seekBar.setProgress(0);
        this.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                if (ShareActivity.this.mediaPlayer != null && b) {
                    ShareActivity.this.mediaPlayer.seekTo(n * 1000);
                }
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (ShareActivity.this.mediaPlayer != null) {
                    ShareActivity.this.seekBar.setProgress(ShareActivity.this.mediaPlayer.getCurrentPosition() / 1000);
                }
                ShareActivity.this.mHandler.postDelayed(this, 1000L);
            }
        });
        if (Util.isVideoFile(this.path)) {
            this.linSeekView.setVisibility(View.VISIBLE);
            this.imgPreview.setVisibility(View.GONE);
            this.textureView.setVisibility(View.VISIBLE);
            final MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
            mediaMetadataRetriever.setDataSource(this.path);
            final int intValue = Integer.valueOf(mediaMetadataRetriever.extractMetadata(18));
            final int intValue2 = Integer.valueOf(mediaMetadataRetriever.extractMetadata(19));
            final int intValue3 = Integer.valueOf(mediaMetadataRetriever.extractMetadata(9));
            mediaMetadataRetriever.release();
            this.textureView.setAspectRatio(intValue, intValue2);
            this.mVideoWidth = intValue;
            this.mVideoHeight = intValue2;
            this.textureView.setSurfaceTextureListener(this);
            this.textDuration.setText(this.convertSecondsToHMmSs(intValue3));
            this.seekBar.setMax(intValue3 / 1000);
        } else {
            this.linSeekView.setVisibility(View.GONE);
            this.textureView.setVisibility(View.GONE);
            this.imgPreview.setVisibility(View.VISIBLE);
            this.imgPreview.setImageBitmap(BitmapFactory.decodeFile(this.path));
        }
        final long length = new File(this.path).length();
        final TextView txtImageSize = this.txtImageSize;
        final StringBuilder sb = new StringBuilder();
        sb.append("Size - ");
        sb.append(this.getStringSizeLengthFile(length));
        txtImageSize.setText(sb.toString());
        this.imgFace.setOnClickListener(this);
        this.imgWhat.setOnClickListener(this);
        this.imgInsta.setOnClickListener(this);
        this.imgMsg.setOnClickListener(this);
        this.imgLink.setOnClickListener(this);
        this.imgMore.setOnClickListener(this);
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ShareActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ShareActivity.this.nativeAd != null) {
                            ShareActivity.this.nativeAd.destroy();
                        }
                        ShareActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {

            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public boolean onError(final MediaPlayer mediaPlayer, final int n, final int n2) {
        return true;
    }

    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    protected void onPause() {
        super.onPause();
        final MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        }
    }

    public void onPrepared(final MediaPlayer mediaPlayer1) {
        Log.e("mediaPlayer.start","starrrrttt==");
        this.mediaPlayer.start();
        playPause.setBackgroundResource(R.drawable.ic_pause_unpresss);
        playPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    playPause.setBackgroundResource(R.drawable.ic_play_upress);
                } else {
                    mediaPlayer.start();
                    playPause.setBackgroundResource(R.drawable.ic_pause_unpresss);
                }
            }
        });
    }

    protected void onResume() {
        super.onResume();
      /*  final MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            this.mediaPlayer.start();
            playPause.setBackgroundResource(R.drawable.ic_pause_unpresss);
        }*/
    }

    public void onSurfaceTextureAvailable(final SurfaceTexture surfaceTexture, final int n, final int n2) {
        this.surfaceTexture = surfaceTexture;
        final MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.setSurface(new Surface(surfaceTexture));
        }
        this.mediaInit();
    }

    public boolean onSurfaceTextureDestroyed(final SurfaceTexture surfaceTexture) {
        return false;
    }

    public void onSurfaceTextureSizeChanged(final SurfaceTexture surfaceTexture, int mVideoWidth, int videoHeight) {
        final MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            this.mVideoWidth = mediaPlayer.getVideoWidth();
            videoHeight = this.mediaPlayer.getVideoHeight();
            this.mVideoHeight = videoHeight;
            mVideoWidth = this.mVideoWidth;
            if (mVideoWidth != 0 && videoHeight != 0) {
                surfaceTexture.setDefaultBufferSize(mVideoWidth, videoHeight);
            }
        }
    }

    public void onSurfaceTextureUpdated(final SurfaceTexture surfaceTexture) {

    }
}
