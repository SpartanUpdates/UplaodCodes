package com.esc.uvideostatus.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.esc.uvideostatus.Activity.DownloadPlayActivity;
import com.esc.uvideostatus.Activity.VideoPlayActivity;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.FontTextView;
import com.esc.uvideostatus.Utility.Utility;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;

public class DownloadAdapter1 extends Adapter<RecyclerView.ViewHolder> {
    public List<VideoData> VideoList = new ArrayList();
    private Activity context;
    File file;
    private String imgPath;
    String title;
    DownloadPlayActivity downloadPlayActivity;
    private ProgressDialog progressDialog;


    private class ImageDownloadAndSave extends AsyncTask<String, Void, Bitmap> {
        private ImageDownloadAndSave() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Plz wait");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.show();
            Toast.makeText(DownloadAdapter1.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public Bitmap doInBackground(String... strArr) {
            String str = strArr[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(strArr[1]);
            stringBuilder.append(".mp4");
            downloadImagesToSdCard(str, stringBuilder.toString());
            return null;
        }

        public void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);

            new Handler().postDelayed(new Runnable() {
                public void run() {
                    progressDialog.dismiss();
                }
            }, 1000);
            Log.d("TAG", "onPostExecute: ");
            DownloadAdapter1.this.shareMultiplePhotos();
        }

        private void downloadImagesToSdCard(String str, String str2) {
            String str3 = "/";
            DownloadAdapter1.this.imgPath = str;
            DownloadAdapter1 suggestionAdapter = DownloadAdapter1.this;
            suggestionAdapter.title = str2;
            try {
                URL url = new URL(suggestionAdapter.imgPath);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(Environment.getExternalStorageDirectory());
                stringBuilder.append(str3);
                stringBuilder.append(DownloadAdapter1.this.context.getString(R.string.app_name));
                File file = new File(stringBuilder.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                String[] split = DownloadAdapter1.this.imgPath.split(Pattern.quote(str3));
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("captureImage: ");
                stringBuilder2.append(DownloadAdapter1.this.imgPath);
                stringBuilder2.append("    ");
                stringBuilder2.append(split[split.length - 1]);
                Log.d("TAG", stringBuilder2.toString());
                DownloadAdapter1.this.file = new File(file.getAbsolutePath(), split[split.length - 1]);
                if (!DownloadAdapter1.this.file.exists()) {
                    URLConnection openConnection = url.openConnection();
                    InputStream inputStream = null;
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode() == 200) {
                        inputStream = httpURLConnection.getInputStream();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(DownloadAdapter1.this.file);
                    int contentLength = httpURLConnection.getContentLength();
                    byte[] bArr = new byte[1024];
                    int i = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        i += read;
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("downloadedSize:");
                        stringBuilder3.append(i);
                        stringBuilder3.append("totalSize:");
                        stringBuilder3.append(contentLength);
                        Log.i("Progress:", stringBuilder3.toString());
                    }
                    fileOutputStream.close();
                }
                Log.d("test", "Image Saved in sdcard..");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    class ProgressBack extends AsyncTask<String, String, String> {
        ProgressDialog mProgressDialog;

        public void onPreExecute() {
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Plz wait");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.show();
            Toast.makeText(DownloadAdapter1.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public String doInBackground(String... strArr) {
            DownloadAdapter1 suggestionAdapter = DownloadAdapter1.this;
            String str = strArr[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(strArr[1]);
            stringBuilder.append(".mp4");
            suggestionAdapter.DownloadFile(str, stringBuilder.toString());
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(str);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    progressDialog.dismiss();
                }
            }, 1000);
            Toast.makeText(DownloadAdapter1.this.context, "Downloaded Sucessfully", Toast.LENGTH_LONG).show();
        }
    }

    public class AdViewHolder extends RecyclerView.ViewHolder {
        FrameLayout frameLayout;
        private NativeBannerAd nativeBannerAd;
        private TextView tvLoadingAd;

        public AdViewHolder(View view) {
            super(view);
            tvLoadingAd = view.findViewById(R.id.tvLoadingAd);
            frameLayout = view.findViewById(R.id.fl_adplaceholder);
            Display defaultDisplay = DownloadAdapter1.this.context.getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            int i = displayMetrics.heightPixels;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public CardView cardView;
        public FontTextView duration;
        public ImageView idIvVideoOption;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.idIvVideoOption = view.findViewById(R.id.idIvVideoOption);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = view.findViewById(R.id.tvVideoListingDuration);
            this.cardView = view.findViewById(R.id.cardview);
            this.duration = view.findViewById(R.id.duration);
            this.idIvVideoOption.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    try {
                        if (DownloadAdapter1.this.VideoList != null && ViewHolder.this.getAdapterPosition() < DownloadAdapter1.this.VideoList.size()) {
                            DownloadAdapter1.this.showVideoOption(DownloadAdapter1.this.VideoList.get(ViewHolder.this.getAdapterPosition()), ViewHolder.this.idIvVideoOption);
                        }
                    } catch (Exception unused) {
                    }
                }
            });
            this.llVideoList.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (DownloadAdapter1.this.VideoList != null && ViewHolder.this.getAdapterPosition() < DownloadAdapter1.this.VideoList.size() && ViewHolder.this.getAdapterPosition() != -1) {
                        DownloadAdapter1.this.downloadPlayActivity.playVideo(DownloadAdapter1.this.VideoList.get(ViewHolder.this.getAdapterPosition()));
                    }
                }
            });
        }
    }

    public DownloadAdapter1(Activity context, ArrayList<VideoData> arrayList) {
        this.VideoList = arrayList;
        this.context = context;
        downloadPlayActivity = (DownloadPlayActivity) context;
        Log.e("VideoList",""+VideoList.size());
        notifyDataSetChanged();
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 1) {
            return new AdViewHolder(from.inflate(R.layout.suggetion_nativead_layout, viewGroup, false));
        } else {
            return new ViewHolder(from.inflate(R.layout.suggestion_layout, viewGroup, false));
        }
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof AdViewHolder) {
            try {
                final AdViewHolder adViewHolder = (AdViewHolder) viewHolder;
                //FaceBookNativeAds
                adViewHolder.nativeBannerAd = new NativeBannerAd(context, context.getResources().getString(R.string.fb_nativebanner_VideoPlayActivity));
                adViewHolder.nativeBannerAd.setAdListener(new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {

                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        Log.e("TAG", "NativeAd ad failed to load: " + adError.getErrorMessage());

                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        Log.e("TAG", "loaded native ad");

                        adViewHolder.tvLoadingAd.setVisibility(View.GONE);
                        View adView = NativeBannerAdView.render(context, adViewHolder.nativeBannerAd, NativeBannerAdView.Type.HEIGHT_50);
                        adViewHolder.frameLayout.addView(adView);

                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                        Log.e("TAG", "NativeAd ad clicked!");

                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                        Log.e("TAG", "NativeAd ad impression logged!");
                    }
                });

                adViewHolder.nativeBannerAd.loadAd();
            } catch (Exception unused) {
            }
        } else {
            VideoData videoData = this.VideoList.get(i);
            ((ViewHolder) viewHolder).tvVideoListingName.setText(videoData.getTitle());
            ((ViewHolder) viewHolder).tvVideoListingSize.setText(videoData.getLikes());
            FontTextView fontTextView = ((ViewHolder) viewHolder).tvVideoListingDuration;
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(Utility.getViews(Double.parseDouble(videoData.getViews())));
//            Log.e("getView",""+videoData.getViews());
                stringBuilder.append(" views");
                fontTextView.setText(stringBuilder.toString());
            }catch (Exception e){
                e.printStackTrace();
            }
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.video_placeholder);
            requestOptions.error(R.drawable.video_placeholder);
            Glide.with(this.context).load(videoData.getThumbnail()).apply(requestOptions).into(((ViewHolder) viewHolder).tvVideoListingThumbnail);

        }
    }

    public int getItemCount() {
        Log.e("ListSize",""+VideoList.size());
        return this.VideoList.size();

    }

    public int getItemViewType(int i) {
        if (i!=0 && i%4 == 0) {
            return 1;
        }
        return 0;
//        return this.VideoList.get(i).getType();
    }

    public void showVideoOption(final VideoData videoData, ImageView imageView) {
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.bottomsheet_video_option, null);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this.context);
        bottomSheetDialog.setContentView(inflate);
        TextView textView = bottomSheetDialog.findViewById(R.id.videoOption_Download);
        TextView textView2 = bottomSheetDialog.findViewById(R.id.videoOption_Details);
        bottomSheetDialog.findViewById(R.id.videoOption_Share).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ImageDownloadAndSave().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ProgressBack().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DownloadAdapter1.this.context);
                @SuppressLint("WrongConstant") View inflate = ((LayoutInflater) DownloadAdapter1.this.context.getSystemService("layout_inflater")).inflate(R.layout.dialog_report, null);
                builder.setView(inflate);
                Button button = inflate.findViewById(R.id.btn_report);
                Button button2 = inflate.findViewById(R.id.btn_cancel);
                final AlertDialog create = builder.create();
                button2.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        create.cancel();
                    }
                });
                button.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        Toast.makeText(DownloadAdapter1.this.context, "Thanks for reporting", Toast.LENGTH_LONG).show();
                        create.cancel();
                    }
                });
                create.show();
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.show();
    }

    public void addAll(List<VideoData> list) {
        this.VideoList = new ArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("addAll12346: ");
        stringBuilder.append(this.VideoList.size());
        Log.d("TAG", stringBuilder.toString());
        int i = 1;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 6;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.VideoList.add(videoData);
                this.VideoList.add(list.get(i2));
            } else {
                this.VideoList.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public void DownloadFile(String str, String str2) {
        try {
            str = str.replace(" ", "%20");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/Video_player");
            File file = new File(stringBuilder.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            URL url = new URL(str);
            File file2 = new File(file, str2);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(url.openConnection().getInputStream());
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(20000);
            while (true) {
                int read = bufferedInputStream.read();
                if (read != -1) {
                    byteArrayBuffer.append((byte) read);
                } else {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    fileOutputStream.write(byteArrayBuffer.toByteArray());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void shareMultiplePhotos() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.SUBJECT", "Share");
        Activity activity = context;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.context.getApplicationContext().getPackageName());
        stringBuilder.append(".provider");
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(activity, stringBuilder.toString(), this.file));
        this.context.startActivity(Intent.createChooser(intent, "Select"));
    }
}