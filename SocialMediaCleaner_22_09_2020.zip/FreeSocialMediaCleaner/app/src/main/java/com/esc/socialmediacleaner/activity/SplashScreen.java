package com.esc.socialmediacleaner.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.util.FullAdScreen;
import com.esc.socialmediacleaner.util.SavedData;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class SplashScreen extends FullAdScreen implements OnClickListener {
    private Button btn_start;
    private TextView txt_privacypolicy;
    private boolean isPaused = false;
    private boolean proceed = false;

    private void checkWhtherLoadAdorNot() {
    }

    public void onResume() {
        super.onResume();
        this.isPaused = false;
        if (!this.proceed) {
            return;
        }

        finish();
        startActivity(new Intent(this, HomeScreen.class));
    }

    public void onPause() {
        super.onPause();
        this.isPaused = true;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        try {
            getSupportActionBar().hide();
        } catch (Exception e) {
            e.printStackTrace();
        }
        init();
        setDeviceDimensions();
        setLitners();
        loadAd();
        if (new SavedData(this).isAccepted()) {
            layoutSecond();
        } else {
            layoutFirst();
        }
        checkWhtherLoadAdorNot();
        MyApplication.getInstance().view_enlarged = false;
    }

    private void layoutSecond() {
        findViewById(R.id.post_launch_layout).setVisibility(View.VISIBLE);
        findViewById(R.id.first_launch_layout).setVisibility(View.GONE);

        new Handler().postDelayed(new Runnable() {
            public void run() {
                SplashScreen.this.proceed = true;

                SplashScreen.this.finish();
                SplashScreen.this.startActivity(new Intent(SplashScreen.this, HomeScreen.class));
            }
        }, 5000);
    }

    private void layoutFirst() {
        findViewById(R.id.post_launch_layout).setVisibility(View.GONE);
        findViewById(R.id.first_launch_layout).setVisibility(View.VISIBLE);
    }

    private void setDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService("window");
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
    }

    private void setLitners() {
        this.btn_start.setOnClickListener(this);
        txt_privacypolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Intent.ACTION_VIEW);
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                startActivity(intent1);
            }
        });
    }

    private void init() {
        this.btn_start = (Button) findViewById(R.id.btn_start);
        txt_privacypolicy = findViewById(R.id.txt_privacypolicy);
    }

    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btn_start:
            id = 100;
            if (interstitial !=null && interstitial.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                finish();
                startActivity(new Intent(this, HomeScreen.class));
                new SavedData(this).setAccepted();
            }
        }
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;
    private void loadAd() {

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(SplashScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id)
                {
                    case 100:
                        finish();
                        startActivity(new Intent(SplashScreen.this, HomeScreen.class));
                        new SavedData(SplashScreen.this).setAccepted();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(SplashScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
