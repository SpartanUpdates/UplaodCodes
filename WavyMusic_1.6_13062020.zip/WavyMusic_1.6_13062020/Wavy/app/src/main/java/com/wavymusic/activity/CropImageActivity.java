package com.wavymusic.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.application.MyApplication;
import com.wavymusic.cropImage.CropImage;
import com.wavymusic.cropImage.ad;
import com.wavymusic.cropImage.c;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.UCropFragment;
import com.yalantis.ucrop.UCropFragmentCallback;
import com.yalantis.ucrop.model.AspectRatio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;


public class CropImageActivity extends AppCompatActivity implements UCropFragmentCallback {
    private static final String TAG = "SampleActivity";
    public String z;
    public float y = 1.0f;
    public String result_conc = "";
    public String SingleImagePath = "";
    Activity activity = CropImageActivity.this;
    String[] mAllPath;
    String mConcatPath;
    int CurrentPosition;
    int last_crop_idx;
    int pera_h;
    int pera_w;
    int NoofImage;
    TextView tvtitle;
    ImageView ivback;
    ProgressBar Croploader;
    TextView tvCropDone;
    int Screenheight, Screenwidth;
    private UCropFragment fragment;
    private MyApplication application;
    private boolean mShowLoader;
    //    InterstitialAd mInterstitialAd;
    KProgressHUD hud;

    public CropImageActivity() {
        this.mConcatPath = "";
        this.last_crop_idx = 0;
        CurrentPosition = 0;
        this.pera_h = -1;
        this.pera_w = -1;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_image);
        application = MyApplication.getInstance();
        NoofImage = getIntent().getIntExtra("NoofImage", 0);
        tvtitle = findViewById(R.id.tool_title);
        ivback = findViewById(R.id.ivBack);
        Croploader = findViewById(R.id.iv_Crop_loader);
        tvCropDone = findViewById(R.id.tv_crop_done);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SampleCropActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
//        InterstitialAd();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        Screenheight = displayMetrics.heightPixels;
        Screenwidth = displayMetrics.widthPixels;
        this.z = r();
        this.setImageBunch();
        c(Uri.fromFile(new File(this.mAllPath[this.last_crop_idx])));
//        if (application.getSelectedImages().size() == 2) {
//            tvCropDone.setText("Done");
//        }
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tvCropDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fragment != null && fragment.isAdded()) ;
                fragment.cropAndSaveImage();

            }
        });

    }


    public String getOutFilePath(String str, int i) {
        str = new File(str).getName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.z);
        stringBuilder.append(new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()));
        String str2 = "_";
        stringBuilder.append(str2);
        stringBuilder.append(i);
        stringBuilder.append(str2);
        stringBuilder.append(str.substring(str.lastIndexOf(".")));
        return stringBuilder.toString();

    }

    public void setImageBunch() {
        String ConcatPath = null;
        ConcatPath = this.getIntent().getStringExtra("path");
        if (!ConcatPath.equals("")) {
            final String[] allPath = ConcatPath.split("\\" + MyApplication.SPLIT_PATTERN);
            this.mAllPath = allPath;
            this.mConcatPath = ConcatPath;
        } else {
            Toast.makeText(this, "No Img Found", Toast.LENGTH_SHORT).show();
        }
        CropImageActivity.this.tvtitle.setText(String.valueOf("Crop Photo" + "(" + 1 + "/" + this.mAllPath.length + ")"));

    }

    public final void c(Uri uri) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SampleCropImage");
        stringBuilder.append(".jpg");
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), stringBuilder.toString())));
        uCrop = basisConfig(uCrop);
        uCrop = advancedConfig(uCrop);
        setupFragment(uCrop);
    }

    private UCrop basisConfig(@NonNull UCrop uCrop) {
        try {
            int maxWidth = 720;
            int maxHeight = 1280;
            if (maxWidth > UCrop.MIN_SIZE && maxHeight > UCrop.MIN_SIZE) {
                uCrop = uCrop.withMaxResultSize(maxWidth, maxHeight);
            }
        } catch (NumberFormatException e) {
            Log.e(TAG, "Number please", e);
        }
        return uCrop;
    }

    private UCrop advancedConfig(@NonNull UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();
        options.setHideBottomControls(true);
        options.setAspectRatioOptions(0, new AspectRatio(null, 720.0f, 1280.0f));
        return uCrop.withOptions(options);
//        UCrop.Options options = new UCrop.Options();
//        options.setHideBottomControls(true);
//        options.setAspectRatioOptions(0,
//                new AspectRatio(null, Screenwidth, Screenheight));
//        return uCrop.withOptions(options);
    }

    public void setupFragment(UCrop uCrop) {
        fragment = uCrop.getFragment(uCrop.getIntent(this).getExtras());
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, fragment, UCropFragment.TAG).commitAllowingStateLoss();
    }

    @Override
    public void loadingProgress(boolean showLoader) {
        mShowLoader = showLoader;
        if (!mShowLoader) {
            tvCropDone.setVisibility(View.VISIBLE);
            Croploader.setVisibility(View.GONE);
        } else {
            Croploader.setVisibility(View.VISIBLE);
            tvCropDone.setVisibility(View.GONE);
        }
    }

    @Override
    public void onCropFinish(UCropFragment.UCropResult result) {
        switch (result.mResultCode) {
            case RESULT_OK:
                handleCropResult(result.mResultData);
                break;
            case UCrop.RESULT_ERROR:
                handleCropError(result.mResultData);
                break;
        }

    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.menu_crop).setVisible(!mShowLoader);
        menu.findItem(R.id.menu_loader).setVisible(mShowLoader);
        return super.onPrepareOptionsMenu(menu);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == UCrop.REQUEST_CROP) {
                handleCropResult(data);
            }
        }
        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }

    private void handleCropResult(@NonNull Intent result) {
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null) {
            b(resultUri);
        } else {
            Toast.makeText(CropImageActivity.this, R.string.toast_cannot_retrieve_cropped_image, Toast.LENGTH_SHORT).show();
        }
    }

    public final void b(Uri uri) {
        if (uri == null || !uri.getScheme().equals("file")) {
            Toast.makeText(this, getString(R.string.toast_unexpected_error), Toast.LENGTH_LONG).show();
            return;
        }
        try {
            a(uri);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public final String r() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(s());
        stringBuilder.append("CropTempImg");
        stringBuilder.append(File.separator);
        String stringBuilder2 = stringBuilder.toString();
        File file = new File(stringBuilder2);
        if (!file.exists()) {
            file.mkdirs();
        }
        return stringBuilder2;
    }

    public final String s() {
        StringBuilder stringBuilder = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString()));
        stringBuilder.append(File.separator);
        stringBuilder.append(q());
        stringBuilder.append(File.separator);
        String stringBuilder2 = stringBuilder.toString();
        File file = new File(stringBuilder2);
        if (!file.exists()) {
            file.mkdirs();
        }
        return stringBuilder2;
    }

    public final String q() {
        return MyApplication.AppName;
    }


    public final void a(Uri uri) {
        String[] strArr = this.mAllPath;
        int i = this.last_crop_idx;
        File file = new File(getOutFilePath(strArr[i], i));
        CropImage aVar = new CropImage();
        aVar.b(this.mAllPath[this.last_crop_idx]);
        aVar.a(file.getAbsolutePath());
        MyApplication myApplication = this.application;
        myApplication.AddCropImages(aVar);
        final FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(new File(uri.getPath()));
            final FileOutputStream fileOutputStream = new FileOutputStream(file);
            final FileChannel channel = fileInputStream.getChannel();
            channel.transferTo(0L, channel.size(), fileOutputStream.getChannel());
            fileInputStream.close();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.last_crop_idx++;
        CurrentPosition++;
        int i2 = this.last_crop_idx;
        strArr = this.mAllPath;
        if (CurrentPosition == myApplication.getSelectedImages().size()) {
            tvCropDone.setText("Done");
        }
        if (i2 < strArr.length) {
            c(Uri.fromFile(new File(strArr[i2])));
        } else {
            this.last_crop_idx = strArr.length - 1;
            loadAds();
        }
        tvtitle.setText(String.valueOf("Crop Photo" + "(" + (CropImageActivity.this.last_crop_idx + 1) + "/" + this.mAllPath.length + ")"));

        final Bitmap a4 = c.a(file.getAbsolutePath());
        if (a4.getHeight() < 1280 || a4.getWidth() < 720) {
            a(a(a4, (float) 720, (float) 1280), file);
        }
    }

//    private void InterstitialAd() {
//        mInterstitialAd = new InterstitialAd(activity);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
////                if (fragment != null && fragment.isAdded()) ;
////                fragment.cropAndSaveImage();
//                SelectedImages();
//            }
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//            }
//
//            @Override
//            public void onAdFailedToLoad(int i) {
//                super.onAdFailedToLoad(i);
//            }
//        });
//    }

    private void loadAds() {
        if (MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
            MyApplication.AdsId = 1;
            MyApplication.AdsShowContext = activity;
            MyApplication.fbinterstitialAd.show();
            /*try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    }
                }
            }, 2000);*/
        } else {
            SelectedImages();
        }
    }

    private void SelectedImages() {
        for (int i = 0; i < this.application.getCropImages().size(); ++i) {
            if (i == 0) {
                result_conc = this.application.getCropImages().get(i).a();
            } else {
                result_conc = String.valueOf(result_conc) + MyApplication.SPLIT_PATTERN + this.application.getCropImages().get(i).a();
            }
        }
        String MethodName;
        String GameobjectName;
        if (MyApplication.IsSelectImageFrom) {
            MyApplication.IsSelectImageFrom = false;
            MethodName = "StaticThemeDataBase";
            GameobjectName = "LoadDefaultData";
        } else {
            MethodName = "GameManager";
            GameobjectName = "ReturnImagePath";
        }
        UnityPlayer.UnitySendMessage(MethodName, GameobjectName, result_conc);
        finish();
    }

    public Bitmap a(Bitmap bitmap, float f, float f2) {
        Bitmap bitmap2 = bitmap;
        float f3 = f;
        float f4 = f2;
        float width = f3 / ((float) bitmap.getWidth());
        float height = f4 / ((float) bitmap.getHeight());
        if (width < f3) {
            height = ((float) bitmap.getWidth()) * width;
            width *= (float) bitmap.getHeight();
        } else if (height < f4) {
            float height2 = height * ((float) bitmap.getHeight());
            height = ((float) bitmap.getWidth()) * height;
            width = height2;
        } else {
            width = 0.0f;
            height = 0.0f;
        }
        int i = (int) f3;
        int i2 = (int) f4;
        Bitmap a = ad.a(bitmap2, i, i2);

        float f5 = 1.0f;
        if (bitmap2 != null) {
            bitmap.getWidth();
            bitmap.getHeight();
        }
        if (a != null) {
            f5 = ((float) a.getWidth()) / ((float) a.getHeight());
        }
        f3 = (float) i;
        Bitmap createBitmap = Bitmap.createBitmap((int) f3, i2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        if (a == null || a.isRecycled()) {
        } else {
            int i3;
            int i4;
            int width2 = a.getWidth();
            int height3 = a.getHeight();
            if (f5 < this.y) {
                f5 = (((float) a.getWidth()) / f3) * f4;
                height3 = ((int) (((float) a.getHeight()) - f5)) / 2;
                i3 = ((int) f5) + height3;
                i4 = width2;
                width2 = 0;
            } else {
                f5 = (((float) a.getHeight()) / f4) * f3;
                width2 = ((int) (((float) a.getWidth()) - f5)) / 2;
                i4 = ((int) f5) + width2;
                i3 = height3;
                height3 = 0;
            }
            canvas.drawBitmap(a, new Rect(width2, height3, i4, i3), new RectF(0.0f, 0.0f, f3, f4), null);
        }
        if (bitmap2 != null) {
            f3 = (f3 - height) / 2.0f;
            f4 = (f4 - width) / 2.0f;
            canvas.drawBitmap(bitmap2, new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()), new RectF(f3, f4, height + f3, width + f4), null);
        }
        return createBitmap;
    }


    public final void a(Bitmap bitmap, File file) {
        String absolutePath = file.getAbsolutePath();
        if (file.exists()) {
            file.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(absolutePath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("ThrowableResultOfMethodCallIgnored")
    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            Toast.makeText(CropImageActivity.this, cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(CropImageActivity.this, R.string.toast_unexpected_error, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (MyApplication.fbinterstitialAd != null) {
            MyApplication.fbinterstitialAd.destroy();
        }
        super.onDestroy();
    }

    public void onBackPressed() {
        MyApplication.TotalSelectedImage = NoofImage;
//        MyApplication.getInstance().getSelectedImageslist().clear();
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(activity, SelectImageActivity.class);
        intent.putExtra("NoofImage", NoofImage);
        startActivity(intent);
        finish();
    }
}
