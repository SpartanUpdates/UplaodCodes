package com.unitedvideosapp.photovideomaker.videolib.libffmpeg;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeoutException;

class FFmpegExecuteAsyncTask extends AsyncTask<Void, String, CommandResult> {

    private final String[] str_cmd;
    private final FFmpegExecuteResponseHandler abc_ExecuteResponseHandler;
    private final ShellCommand shell_Command;
    private final long timeout;
    private long start_Time;
    private Process process;
    private String output = "";

    FFmpegExecuteAsyncTask(String[] cmd, long timeout,
                           FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler) {
        this.str_cmd = cmd;
        this.timeout = timeout;
        this.abc_ExecuteResponseHandler = ffmpegExecuteResponseHandler;
        this.shell_Command = new ShellCommand();
    }

    @Override
    protected void onPreExecute() {
        start_Time = System.currentTimeMillis();
        if (abc_ExecuteResponseHandler != null) {
            abc_ExecuteResponseHandler.onStart();
        }
    }

    @Override
    protected CommandResult doInBackground(Void... params) {
        try {
            process = shell_Command.run(str_cmd);
            if (process == null) {
                return CommandResult.getDummyFailureResponse();
            }
            checkAndUpdateProcess();
            return CommandResult.getOutputFromProcess(process);
        } catch (TimeoutException e) {
            return new CommandResult(false, e.getMessage());
        } catch (Exception e) {
        } finally {
            Util.destroyProcess(process);
        }
        return CommandResult.getDummyFailureResponse();
    }

    @Override
    protected void onProgressUpdate(String... values) {
        if (values != null && values[0] != null
                && abc_ExecuteResponseHandler != null) {
            abc_ExecuteResponseHandler.onProgress(values[0]);
        }
    }

    @Override
    protected void onPostExecute(CommandResult commandResult) {
        if (abc_ExecuteResponseHandler != null) {
            output += commandResult.output;
            if (commandResult.success) {
                abc_ExecuteResponseHandler.onSuccess(output);
            } else {
                abc_ExecuteResponseHandler.onFailure(output);
            }
            abc_ExecuteResponseHandler.onFinish();
        }
    }

    private void checkAndUpdateProcess() throws TimeoutException,
            InterruptedException {
        while (!Util.isProcessCompleted(process)) {
            if (Util.isProcessCompleted(process)) {
                return;
            }

            if (timeout != Long.MAX_VALUE
                    && System.currentTimeMillis() > start_Time + timeout) {
                throw new TimeoutException("FFmpeg timed out");
            }

            try {
                String line;
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getErrorStream()));
                while ((line = reader.readLine()) != null) {
                    if (isCancelled()) {
                        return;
                    }

                    output += line + "\n";
                    publishProgress(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    boolean isProcessCompleted() {
        return Util.isProcessCompleted(process);
    }

}