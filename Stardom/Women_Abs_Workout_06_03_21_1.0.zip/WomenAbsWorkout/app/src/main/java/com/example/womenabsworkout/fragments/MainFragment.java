package com.example.womenabsworkout.fragments;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.app.NotificationCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.After_Main_Activity;
import com.example.womenabsworkout.activities.CalculateActivity;
import com.example.womenabsworkout.activities.DayActivity;
import com.example.womenabsworkout.activities.MainActivity;
import com.example.womenabsworkout.activities.RestDayActivity;
import com.example.womenabsworkout.adapters.AllDayAdapter;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseHelper;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.listners.RecyclerItemClickListener;
import com.example.womenabsworkout.newscreen.Library;
import com.example.womenabsworkout.receiver.NotificationReceiver;
import com.example.womenabsworkout.utils.AppUtils;
import com.example.womenabsworkout.utils.CommonMethods;
import com.example.womenabsworkout.utils.Constants;
import com.google.android.exoplayer2.extractor.ts.TsExtractor;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;

import static android.os.Build.VERSION_CODES.Q;


public class MainFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public float Heightincms = 0.0f;
    public AllDayAdapter adapter;
    public ArrayList<String> arr = new ArrayList();
    public Context context;
    public DatabaseOperations databaseOperations;
    public TextView dayleft;
    public int daysCompletionConter = 0;
    public String exc_type;
    public RadioButton female;
    public EditText ft;
    public int height;
    public EditText inches;
    Intent intent;
    public RadioButton kg;
    public RadioButton lbs;
    public Library library;
    public SharedPreferences mSharedPreferences;
    MainActivity mainActivity2;
    public RadioButton male;
    public EditText months;
    public NavigationView nav_view;
    public TextView percentScore1;
    public Editor prefsEditor;
    public ProgressBar progressBar;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public BroadcastReceiver progressReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            double doubleExtra = intent.getDoubleExtra(AppUtils.KEY_PROGRESS, 0.0d);
            try {
                ((WorkoutData) MainFragment.this.workoutDataList.get(MainFragment.this.workoutPosition)).setProgress((float) doubleExtra);
                MainFragment.this.total_progress = 0.0d;
                int i = 0;
                MainFragment.this.daysCompletionConter = 0;
                while (true) {
                    String str = "dev";
                    if (i < Constants.TOTAL_DAYS) {
                        MainFragment.this.getContext();
                        double d = MainFragment.this.total_progress;
                        double progress = (double) ((WorkoutData) MainFragment.this.workoutDataList.get(i)).getProgress();
                        Double.isNaN(progress);
                        MainFragment.this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("totalprogressreceiver");
                        stringBuilder.append(MainFragment.this.total_progress);
                        Log.i(str, stringBuilder.toString());
                        if (((WorkoutData) MainFragment.this.workoutDataList.get(i)).getProgress() >= 99.0f) {
                            MainFragment.this.daysCompletionConter++;
                        }
                        i++;
                    } else {
                        MainFragment.this.getContext();
                        MainFragment.this.daysCompletionConter += MainFragment.this.daysCompletionConter / 3;
                        MainFragment.this.progressBar.setProgress((int) MainFragment.this.total_progress);
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("totalprogressreceiver1");
                        stringBuilder2.append(MainFragment.this.total_progress);
                        Log.i(str, stringBuilder2.toString());
                        TextView textView = MainFragment.this.percentScore1;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append((int) MainFragment.this.total_progress);
                        stringBuilder2.append("%");
                        textView.setText(stringBuilder2.toString());
                        textView = MainFragment.this.dayleft;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(Constants.TOTAL_DAYS - MainFragment.this.daysCompletionConter);
                        stringBuilder2.append(MainFragment.this.getString(R.string.dayleft));
                        textView.setText(stringBuilder2.toString());
                        MainFragment.this.adapter.notifyDataSetChanged();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("");
                        stringBuilder3.append(doubleExtra);
                        Log.i("progress broadcast", stringBuilder3.toString());
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    public RecyclerView recyclerView;
    public double total_progress = 0.0d;
    public EditText weight;
    public int width;
    public List<WorkoutData> workoutDataList;
    public int workoutPosition = -1;
    public EditText year;

    private float calculateHeightinCentimeter(float f) {
        return (float) ((int) (f * 100.0f));
    }

    public int calculateBMI(float f, float f2) {
        return (int) (f2 / (f * f));
    }

    public boolean isRestDay(int i) {
        return i == 4;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @SuppressLint("NewApi")
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        List allDaysProgress;
        int i;
        View inflate = layoutInflater.inflate(R.layout.activity_main, viewGroup, false);
        super.onCreate(bundle);
        this.context = getContext();

        interstitialAd();

        this.library = new Library(this.context);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        this.mSharedPreferences = defaultSharedPreferences;
        this.library.updateLocale(defaultSharedPreferences.getString("languageToLoad", ""));
        this.prefsEditor = this.mSharedPreferences.edit();
        String str = "beginner";
        this.exc_type = this.mSharedPreferences.getString("yoga_type", str);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
        this.percentScore1 = (TextView) inflate.findViewById(R.id.percentScore);
        this.dayleft = (TextView) inflate.findViewById(R.id.daysLeft);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.b);
        this.recyclerView = (RecyclerView) inflate.findViewById(R.id.recycler);
        if (!this.exc_type.equalsIgnoreCase(str)) {
            imageView.setBackground(getResources().getDrawable(R.mipmap.banner_111));
        }
        this.databaseOperations = new DatabaseOperations(getContext());
        String str2 = "thirtyday";
        boolean z = this.mSharedPreferences.getBoolean(str2, false);
        String str3 = "daysInserted";
        if (!this.mSharedPreferences.getBoolean(str3, false) && this.databaseOperations.CheckDBEmpty(DatabaseHelper.EXC_DAY_TABLE) == 0) {
            this.databaseOperations.insertExcALLDayData();
            Editor edit = this.mSharedPreferences.edit();
            edit.putBoolean(str3, true);
            edit.apply();
        }
        List list = this.workoutDataList;
        if (list != null) {
            list.clear();
        }
        if (this.exc_type.equalsIgnoreCase(str)) {
            allDaysProgress = this.databaseOperations.getAllDaysProgress();
        } else {
            if (!this.databaseOperations.tableExists(DatabaseHelper.EXC_DAY_TABLE_ADVANCED)) {
                this.databaseOperations.createAdvTable();
            }
            if (this.databaseOperations.CheckDBEmpty(DatabaseHelper.EXC_DAY_TABLE_ADVANCED) == 0) {
                this.databaseOperations.insertExcALLDayDataAdv();
                Editor edit2 = this.mSharedPreferences.edit();
                edit2.putBoolean(str3, true);
                edit2.apply();
            }
            allDaysProgress = this.databaseOperations.getAllDaysProgressAdv();
        }
        ((ImageView) inflate.findViewById(R.id.back_arrow)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainFragment.this.onBackPressed();
            }
        });
        ((ImageView) inflate.findViewById(R.id.reset_process)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainFragment.this.restartDialog();
            }
        });
        this.workoutDataList = allDaysProgress;
        ProgressBar progressBar = (ProgressBar) inflate.findViewById(R.id.progress);
        this.progressBar = progressBar;
        progressBar.setProgressDrawable(getResources().getDrawable(R.drawable.launch_progressbar));
        for (i = 0; i < Constants.TOTAL_DAYS; i++) {
            double d = this.total_progress;
            double progress = (double) ((WorkoutData) this.workoutDataList.get(i)).getProgress();
            Double.isNaN(progress);
            this.total_progress = (double) ((float) (d + ((progress * 4.348d) / 100.0d)));
            if (((WorkoutData) this.workoutDataList.get(i)).getProgress() >= 99.0f) {
                this.daysCompletionConter++;
            }
        }
        i = this.daysCompletionConter;
        this.daysCompletionConter = i + (i / 3);
        this.progressBar.setProgress((int) this.total_progress);
        TextView textView = this.percentScore1;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((int) this.total_progress);
        stringBuilder.append("%");
        textView.setText(stringBuilder.toString());
        textView = this.dayleft;
        stringBuilder = new StringBuilder();
        stringBuilder.append(Constants.TOTAL_DAYS - this.daysCompletionConter);
        stringBuilder.append(getString(R.string.dayleft));
        textView.setText(stringBuilder.toString());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        this.adapter = new AllDayAdapter(getContext(), this.workoutDataList);
        this.recyclerView.getRecycledViewPool().clear();
        for (int i2 = 1; i2 <= Constants.TOTAL_DAYS; i2++) {
            ArrayList arrayList = this.arr;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Day ");
            stringBuilder2.append(i2);
            arrayList.add(stringBuilder2.toString());
        }
        if (z) {
            Editor edit3 = this.mSharedPreferences.edit();
            edit3.putBoolean(str2, false);
            edit3.apply();
            restartExcercise();
            this.daysCompletionConter = 0;
        }
        this.recyclerView.setAdapter(this.adapter);
        this.recyclerView.setLayoutManager(linearLayoutManager);

        this.recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(), new RecyclerItemClickListener.onItemClickListener() {
            public void OnItem(View view, int i) {
                Intent intent;
                MainFragment.this.workoutPosition = i;
                if ((MainFragment.this.workoutPosition + 1) % 4 == 0) {
                    intent = new Intent(MainFragment.this.getContext(), RestDayActivity.class);
                } else if (((WorkoutData) MainFragment.this.workoutDataList.get(i)).getProgress() < 99.0f) {
                    intent = new Intent(MainFragment.this.getContext(), DayActivity.class);
                    intent.putExtra("day", (String) MainFragment.this.arr.get(i));
                    intent.putExtra("day_num", i);
                    intent.putExtra(NotificationCompat.CATEGORY_PROGRESS, ((WorkoutData) MainFragment.this.workoutDataList.get(i)).getProgress());
                } else {
                    MainFragment.this.excRepeatConfirmDialog(i);
                    return;
                }
                MainFragment.this.startActivity(intent);
            }
        }));

        DrawerLayout drawerLayout = (DrawerLayout) inflate.findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        if (VERSION.SDK_INT >= Q && VERSION.SDK_INT >= Q)
        {
            ((NotificationManager) Objects.requireNonNull((NotificationManager) getActivity().getSystemService(NotificationManager.class))).createNotificationChannel(new NotificationChannel(getString(R.string.default_notification_channel_id), getString(R.string.default_notification_channel_name), NotificationManager.IMPORTANCE_HIGH));
        }
        if (getActivity().getIntent().getExtras() != null)
        {
            for (String str4 : getActivity().getIntent().getExtras().keySet()) {
                Object obj = getActivity().getIntent().getExtras().get(str4);
                stringBuilder = new StringBuilder();
                stringBuilder.append("Key: ");
                stringBuilder.append(str4);
                stringBuilder.append(" Value: ");
                stringBuilder.append(obj);
                Log.d("selfie camera", stringBuilder.toString());
            }
        }

        StrictMode.setVmPolicy(new VmPolicy.Builder().build());
        Calendar instance = Calendar.getInstance(TimeZone.getDefault());
        String str4 = "%02d";
        String.format(str4, new Object[]{Integer.valueOf(instance.get(11))});
        String str5 = ":";
        String.format(str4, new Object[]{Integer.valueOf(instance.get(12))});
        String.format(str4, new Object[]{Integer.valueOf(instance.get(13))});
        String.format("%03d", new Object[]{Integer.valueOf(instance.get(14))});
        SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(getContext());

        if (!Boolean.valueOf(defaultSharedPreferences2.getBoolean("user_selection", false)).booleanValue())
        {
            String str6 = "ReminderCheck";
            Log.d(str6, "Reminder set in Completion page");
            Editor edit4 = defaultSharedPreferences2.edit();
            String str7 = "notification_hour";
            edit4.putInt(str7, instance.get(11));
            String str8 = "notification_minute";
            edit4.putInt(str8, instance.get(12));
            edit4.apply();
            new CommonMethods(this.context).setAlarm(defaultSharedPreferences2.getInt(str7, instance.get(11)), defaultSharedPreferences2.getInt(str8, instance.get(12)), 0);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Reminder set in ");
            stringBuilder3.append(defaultSharedPreferences2.getInt(str7, instance.get(11)));
            stringBuilder3.append(str5);
            stringBuilder3.append(defaultSharedPreferences2.getInt(str8, instance.get(12)));
            stringBuilder3.append(str5);
            stringBuilder3.append(0);
            Log.d(str6, stringBuilder3.toString());
        }
        getActivity().registerReceiver(this.progressReceiver, new IntentFilter(AppUtils.WORKOUT_BROADCAST_FILTER));
        return inflate;
    }

    public float calculateMetres(float f, float f2) {
        double d = (double) (f + (f2 / 12.0f));
        Double.isNaN(d);
        f = (float) (d / 3.28d);
        this.Heightincms = calculateHeightinCentimeter(f);
        return f;
    }

    public float calculateweight(float f) {
        if (!this.lbs.isChecked()) {
            return f;
        }
        double d = (double) f;
        Double.isNaN(d);
        return (float) (d * 0.453592d);
    }

    public void excRepeatConfirmDialog(final int i) {
        final Dialog dialog = new Dialog(this.context, R.style.Theme_Dialog);
        try {
            dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.repeat_confirm_addialog_layout);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setCancelable(true);
        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                try {
                    List allDaysProgress;
                    CharSequence stringBuilder;
                    dialog.dismiss();
                    String str = (String) MainFragment.this.arr.get(i);
                    if (MainFragment.this.workoutDataList != null) {
                        MainFragment.this.workoutDataList.clear();
                    }
                    if (MainFragment.this.exc_type.equalsIgnoreCase("beginner"))
                    {
                        MainFragment.this.databaseOperations.insertExcDayData(str, 0.0f);
                        MainFragment.this.databaseOperations.insertExcCounter(str, 0);
                        MainFragment.this.getContext();
                        allDaysProgress = MainFragment.this.databaseOperations.getAllDaysProgress();
                    } else {
                        MainFragment.this.databaseOperations.insertExcDayDataAdv(str, 0.0f);
                        MainFragment.this.databaseOperations.insertExcCounterAdv(str, 0);
                        MainFragment.this.getContext();
                        allDaysProgress = MainFragment.this.databaseOperations.getAllDaysProgressAdv();
                    }
                    MainFragment.this.workoutDataList = allDaysProgress;
                    MainFragment.this.adapter = new AllDayAdapter(MainFragment.this.getContext(), MainFragment.this.workoutDataList);
                    MainFragment.this.recyclerView.getRecycledViewPool().clear();
                    MainFragment.this.recyclerView.setAdapter(MainFragment.this.adapter);
                    MainFragment.this.daysCompletionConter--;
                    TextView textView = MainFragment.this.dayleft;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(Constants.TOTAL_DAYS - MainFragment.this.daysCompletionConter);
                    stringBuilder2.append(MainFragment.this.getString(R.string.dayleft));
                    textView.setText(stringBuilder2.toString());
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("totalprogress");
                    stringBuilder3.append(MainFragment.this.total_progress);
                    Log.i("dev", stringBuilder3.toString());
                    if (MainFragment.this.daysCompletionConter > 0) {
                        MainFragment.this.progressBar.setProgress((int) (MainFragment.this.total_progress - 4.348d));
                        textView = MainFragment.this.percentScore1;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append((int) (MainFragment.this.total_progress - 4.348d));
                        stringBuilder2.append("%");
                        stringBuilder = stringBuilder2.toString();
                    } else {
                        MainFragment.this.progressBar.setProgress(0);
                        textView = MainFragment.this.percentScore1;
                        stringBuilder = "0%";
                    }
                    textView.setText(stringBuilder);
                    Intent intent = new Intent(MainFragment.this.getContext(), DayActivity.class);
                    intent.putExtra("day", str);
                    intent.putExtra("day_num", i);
                    MainFragment.this.library.saveInt("workoutPosition", Integer.valueOf(MainFragment.this.workoutPosition), MainFragment.this.getContext());
                    MainFragment.this.library.preData(str, i, ((WorkoutData) MainFragment.this.workoutDataList.get(i)).getProgress(), MainFragment.this.exc_type, MainFragment.this.getContext());
                    MainFragment.this.startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void reminderpopup() {
        final Dialog dialog = new Dialog(getContext());
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.reminder_popup);
        dialog.setCancelable(true);
        dialog.setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                MainFragment.this.nav_view.getMenu().getItem(0).setChecked(true);
            }
        });
        dialog.getWindow().setLayout(-1, -2);
        final TimePicker timePicker = (TimePicker) dialog.findViewById(R.id.datePicker1reminder);
        ((Button) dialog.findViewById(R.id.set_reminder)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = ":";
                String str2 = "ReminderCheck";
                String str3 = "notification_minute";
                String str4 = "notification_hour";
                try {
                    int hour;
                    int minute;
                    dialog.dismiss();
                    if (VERSION.SDK_INT >= Q) {
                        hour = timePicker.getHour();
                        minute = timePicker.getMinute();
                    } else {
                        hour = timePicker.getCurrentHour().intValue();
                        minute = timePicker.getCurrentMinute().intValue();
                    }
                    MainFragment.this.prefsEditor.putBoolean("user_selection", true);
                    MainFragment.this.prefsEditor.putInt(str4, hour);
                    MainFragment.this.prefsEditor.putInt(str3, minute);
                    Log.d(str2, "Reminder set in Main page");
                    MainFragment.this.prefsEditor.apply();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Reminder set in ");
                    stringBuilder.append(MainFragment.this.mSharedPreferences.getInt(str4, hour));
                    stringBuilder.append(str);
                    stringBuilder.append(MainFragment.this.mSharedPreferences.getInt(str3, minute));
                    stringBuilder.append(str);
                    stringBuilder.append(0);
                    Log.d(str2, stringBuilder.toString());
                    MainFragment.this.setAlarm(MainFragment.this.mSharedPreferences.getInt(str4, hour), MainFragment.this.mSharedPreferences.getInt(str3, minute), 0);
                    MainFragment.this.nav_view.getMenu().getItem(0).setChecked(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        dialog.show();
    }

    public void restartDialog()
    {
        final Dialog dialog = new Dialog(getContext(), R.style.Theme_Dialog);
        try {
            dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        dialog.setContentView(R.layout.restart_confirm_addialog_layout);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setCancelable(true);

        ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                try {

                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        try {
                            hud = KProgressHUD.create(getActivity())
                                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                    .setLabel("Showing Ads")
                                    .setDetailsLabel("Please Wait...");
                            hud.show();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    hud.dismiss();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();

                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                    id = 100;
                                    mInterstitialAd.show();
                                }
                            }
                        }, 2000);
                    } else {
                        MainFragment.this.restartExcercise();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void shareApp() {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("start workout in your Home. : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getActivity().getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.setType("text/plain");
        startActivity(intent);
    }

    public void b() {
        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        final Dialog dialog = new Dialog(getContext(), R.style.AppTheme);
        dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        dialog.getWindow().setLayout(-1, -1);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setFlags(1024, 1024);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setContentView(R.layout.activity_customdialog_heightcheckout);
        dialog.setCancelable(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.setCancelable(true);
        this.lbs = (RadioButton) dialog.findViewById(R.id.lbs);
        this.kg = (RadioButton) dialog.findViewById(R.id.kg);
        this.male = (RadioButton) dialog.findViewById(R.id.male);
        this.female = (RadioButton) dialog.findViewById(R.id.female);
        this.ft = (EditText) dialog.findViewById(R.id.feet);
        this.inches = (EditText) dialog.findViewById(R.id.inches);
        this.year = (EditText) dialog.findViewById(R.id.year);
        this.months = (EditText) dialog.findViewById(R.id.month);
        this.weight = (EditText) dialog.findViewById(R.id.weight);
        ((Button) dialog.findViewById(R.id.calculate)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                int i;
                String str = "";
                if (MainFragment.this.year.getText().toString().equals(str) || MainFragment.this.months.getText().toString().equals(str) || MainFragment.this.ft.getText().toString().equals(str) || MainFragment.this.inches.getText().toString().equals(str) || MainFragment.this.weight.getText().toString().equals(str)) {
                    i = R.string.fields;
                } else if (MainFragment.this.year.getText().toString().matches(str) || Integer.parseInt(MainFragment.this.year.getText().toString()) < 5 || Integer.parseInt(MainFragment.this.year.getText().toString()) > 100) {
                    i = R.string.agerange;
                } else if (MainFragment.this.months.getText().toString().matches(str) || Integer.parseInt(MainFragment.this.months.getText().toString()) < 0 || Integer.parseInt(MainFragment.this.months.getText().toString()) > 12) {
                    i = R.string.monthrange;
                } else if (MainFragment.this.ft.getText().toString().matches(str) || Integer.parseInt(MainFragment.this.ft.getText().toString()) < 2 || Integer.parseInt(MainFragment.this.ft.getText().toString()) > 7) {
                    i = R.string.feetrange;
                } else if (MainFragment.this.inches.getText().toString().matches(str) || Integer.parseInt(MainFragment.this.inches.getText().toString()) < 0 || Integer.parseInt(MainFragment.this.inches.getText().toString()) > 12) {
                    i = R.string.inchrange;
                } else {
                    String str2 = "HEIGHT";
                    String str3 = "BMI";
                    MainFragment mainFragment;
                    float calculateMetres;
                    MainFragment mainFragment2;
                    if (MainFragment.this.kg.isChecked()) {
                        if (!MainFragment.this.weight.getText().toString().matches(str) && Integer.parseInt(MainFragment.this.weight.getText().toString()) >= 5 && Integer.parseInt(MainFragment.this.weight.getText().toString()) <= TsExtractor.TS_STREAM_TYPE_HDMV_DTS) {
                            mainFragment = MainFragment.this;
                            calculateMetres = mainFragment.calculateMetres(Float.parseFloat(mainFragment.ft.getText().toString()), Float.parseFloat(MainFragment.this.inches.getText().toString()));
                            mainFragment2 = MainFragment.this;
                            int calculateBMI = mainFragment2.calculateBMI(calculateMetres, mainFragment2.calculateweight(Float.parseFloat(mainFragment2.weight.getText().toString())));
                            mainFragment2 = MainFragment.this;
                            mainFragment2.prefsEditor = mainFragment2.mSharedPreferences.edit();
                            MainFragment.this.prefsEditor.putFloat(str3, (float) calculateBMI);
                            MainFragment.this.prefsEditor.putFloat(str2, MainFragment.this.Heightincms);
                            MainFragment.this.prefsEditor.apply();
                            MainFragment.this.intent = new Intent(MainFragment.this.getContext(), CalculateActivity.class);
                        }
                    } else if (!MainFragment.this.lbs.isChecked()) {
                        return;
                    } else {
                        if (!MainFragment.this.weight.getText().toString().matches(str) && Integer.parseInt(MainFragment.this.weight.getText().toString()) >= 11 && Integer.parseInt(MainFragment.this.weight.getText().toString()) <= 286) {
                            mainFragment = MainFragment.this;
                            calculateMetres = mainFragment.calculateMetres(Float.parseFloat(mainFragment.ft.getText().toString()), Float.parseFloat(MainFragment.this.inches.getText().toString()));
                            mainFragment2 = MainFragment.this;
                            calculateMetres = (float) mainFragment2.calculateBMI(calculateMetres, mainFragment2.calculateweight(Float.parseFloat(mainFragment2.weight.getText().toString())));
                            mainFragment2 = MainFragment.this;
                            mainFragment2.prefsEditor = mainFragment2.mSharedPreferences.edit();
                            MainFragment.this.prefsEditor.putFloat(str3, calculateMetres);
                            MainFragment.this.prefsEditor.putFloat(str2, MainFragment.this.Heightincms);
                            MainFragment.this.prefsEditor.apply();
                            MainFragment.this.intent = new Intent(MainFragment.this.mainActivity2, CalculateActivity.class);
                        }
                    }
                    MainFragment.this.mainActivity2.startActivity(MainFragment.this.intent.putExtra(str3, MainFragment.this.mSharedPreferences.getFloat(str3, 0.0f)).putExtra(str2, MainFragment.this.mSharedPreferences.getFloat(str2, 0.0f)));
                    dialog.dismiss();
                    return;
                }
                Toast.makeText(MainFragment.this.getContext(), i, Toast.LENGTH_SHORT).show();
            }
        });
        this.nav_view.getMenu().getItem(0).setChecked(true);
        dialog.show();
    }

    public static MainFragment newInstance(String str, String str2) {
        MainFragment mainFragment = new MainFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        mainFragment.setArguments(bundle);
        return mainFragment;
    }

    public boolean onNavigationItemSelected(MenuItem menuItem) {
        String str = "android.intent.action.VIEW";
        int itemId = menuItem.getItemId();
        if (!(itemId == R.id.trainingplan || itemId == R.id.meals_plan)) {
            if (itemId == R.id.reminder) {
                reminderpopup();
            } else if (itemId == R.id.restartprogress) {
                restartDialog();
            } else if (itemId == R.id.calculate) {
                b();
            } else if (itemId == R.id.share) {
                shareApp();
            } else if (itemId == R.id.rateus) {
                try {
                    startActivity(new Intent(str, Uri.parse("market://details?id="+context.getPackageName())));
                } catch (ActivityNotFoundException unused) {
                    startActivity(new Intent(str, Uri.parse("http://play.google.com/store/apps/details?id="+context.getPackageName())));
                }
            }
        }
        return true;
    }

    public void onResume() {
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void restartExcercise() {
        Editor edit = this.mSharedPreferences.edit();
        String str = "daysInserted";
        edit.putBoolean(str, false);
        edit.apply();
        for (int i = 0; i < 30; i++)
        {
            String str2 = (String) this.arr.get(i);
            this.databaseOperations.insertExcDayData(str2, 0.0f);
            this.databaseOperations.insertExcCounter(str2, 0);
        }
        edit.putBoolean(str, true);
        edit.apply();
        List list = this.workoutDataList;
        if (list != null) {
            list.clear();
        }
        this.workoutDataList = this.exc_type.equalsIgnoreCase("beginner") ? this.databaseOperations.getAllDaysProgress() : this.databaseOperations.getAllDaysProgressAdv();
        this.adapter = new AllDayAdapter(getContext(), this.workoutDataList);
        this.recyclerView.getRecycledViewPool().clear();
        this.recyclerView.setAdapter(this.adapter);
        this.progressBar.setProgress(0);
        this.percentScore1.setText("0%");
        TextView textView = this.dayleft;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constants.TOTAL_DAYS);
        stringBuilder.append(" Days left");
        textView.setText(stringBuilder.toString());
    }

    @SuppressLint("WrongConstant")
    public void setAlarm(int i, int i2, int i3)
    {
        Calendar instance = Calendar.getInstance();
        instance.set(11, i);
        instance.set(12, i2);
        instance.set(13, i3);
        ((AlarmManager) getActivity().getSystemService(NotificationCompat.CATEGORY_ALARM)).setRepeating(AlarmManager.RTC_WAKEUP, instance.getTimeInMillis(), 86400000, PendingIntent.getBroadcast(getContext(), 100, new Intent(getContext(), NotificationReceiver.class), 134217728));
    }

    public void onBackPressed() {
        startActivity(new Intent(getContext(), After_Main_Activity.class));
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        MainFragment.this.restartExcercise();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(getActivity());
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
