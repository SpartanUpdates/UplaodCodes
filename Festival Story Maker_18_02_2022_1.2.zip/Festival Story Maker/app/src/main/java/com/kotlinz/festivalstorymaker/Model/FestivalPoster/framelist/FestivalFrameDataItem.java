package com.kotlinz.festivalstorymaker.Model.FestivalPoster.framelist;

import com.google.gson.annotations.SerializedName;

public class FestivalFrameDataItem {

	@SerializedName("frame_name")
	private String frameName;

	@SerializedName("subcategory_id")
	private String subcategoryId;

	@SerializedName("image")
	private String image;

	@SerializedName("maincategory_id")
	private String maincategoryId;

	@SerializedName("mask_image")
	private String maskImage;

	@SerializedName("is_image_count")
	private String isImageCount;

	@SerializedName("thumb")
	private String thumb;

	@SerializedName("is_free")
	private String isFree;

	@SerializedName("is_mask")
	private String isMask;

	@SerializedName("id")
	private String id;

	public String getFrameName(){
		return frameName;
	}

	public String getSubcategoryId(){
		return subcategoryId;
	}

	public String getImage(){
		return image;
	}

	public String getMaincategoryId(){
		return maincategoryId;
	}

	public String getMaskImage(){
		return maskImage;
	}

	public String getIsImageCount(){
		return isImageCount;
	}

	public String getThumb(){
		return thumb;
	}

	public String getIsFree(){
		return isFree;
	}

	public String getIsMask(){
		return isMask;
	}

	public String getId(){
		return id;
	}
}