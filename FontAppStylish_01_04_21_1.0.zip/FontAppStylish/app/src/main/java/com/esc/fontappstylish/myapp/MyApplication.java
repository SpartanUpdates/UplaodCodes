package com.esc.fontappstylish.myapp;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import com.esc.fontappstylish.OpenAds.AppOpenManager;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MyApplication extends Application {

    AppOpenManager appOpenManager;

    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        AudienceNetworkAds.initialize(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        appOpenManager = new AppOpenManager(this);
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public static final String TAG = MyApplication.class.getSimpleName();

    private static MyApplication mInstance;
    private static Context context;

    public static Context getContext() {
        return context;
    }

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }
}
