class VehicleMileageModel {
  final String randomId;
  final String date;
  final String lastreserve;
  final String currentreserve;
  final String totalprice;
  final String totalfuel;
  final String kmperltr;
  final String rsperltr;
  final String rsperkm;

  VehicleMileageModel(
      {required this.randomId,
      required this.date,
      required this.lastreserve,
      required this.currentreserve,
      required this.totalprice,
      required this.totalfuel,
      required this.kmperltr,
      required this.rsperltr,
      required this.rsperkm});

  VehicleMileageModel.fromMap(Map<String, dynamic> res)
      : randomId = res['randomId'],
        date = res['date'],
        lastreserve = res['lastreserve'],
        currentreserve = res['currentreserve'],
        totalprice = res['totalprice'],
        totalfuel = res['totalfuel'],
        kmperltr = res['kmperltr'],
        rsperltr = res['rsperltr'],
        rsperkm = res['rsperkm'];

  Map<String, Object?> toMap() {
    return {
      'randomId': randomId,
      'date': date,
      'lastreserve': lastreserve,
      'currentreserve': currentreserve,
      'totalprice': totalprice,
      'totalfuel': totalfuel,
      'kmperltr': kmperltr,
      'rsperltr': rsperltr,
      'rsperkm': rsperkm,
    };
  }
}
