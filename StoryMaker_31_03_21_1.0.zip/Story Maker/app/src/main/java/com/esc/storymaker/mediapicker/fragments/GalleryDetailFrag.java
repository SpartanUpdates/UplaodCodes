package com.esc.storymaker.mediapicker.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnItemTouchListener;

import com.esc.storymaker.R;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.mediapicker.Gallery;
import com.esc.storymaker.mediapicker.adapters.MediaAdapter;
import com.esc.storymaker.mediapicker.utils.ClickListener;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;

public class GalleryDetailFrag extends Fragment {
    public static final String mypreference = "myprefadmob";
    public static List<Boolean> selected = new ArrayList();
    private ImageView ImageOverlayadview;
    Activity activity;
    LinearLayout adContainer;
    private AdView bannerAdView;
    private LinearLayout bannerContainer;
    ConnectionDetector connectionDetector;
    int displayad;
    public String from;
    AdView mAdView;
    private MediaAdapter mAdapter;
    private final List<String> mediaList = new ArrayList();
    private View rootView;
    private RecyclerView rvDetail;
    SharedPreferences sharedpreferences;
    private TextView tbTitle;
    public String title;
    int whichAdFirst;

    public static class RecyclerTouchListener implements OnItemTouchListener {
        private final ClickListener clickListener;
        private final GestureDetector gestureDetector;

        public void onRequestDisallowInterceptTouchEvent(boolean z) {
        }

        public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
        }

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            this.gestureDetector = new GestureDetector(context, new SimpleOnGestureListener() {
                public boolean onSingleTapUp(MotionEvent motionEvent) {
                    return true;
                }

                public void onLongPress(MotionEvent motionEvent) {
                    View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
                    if (findChildViewUnder != null) {
                        if (clickListener != null) {
                            clickListener.onLongClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
                        }
                    }
                }
            });
        }

        public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
            View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
            if (!(findChildViewUnder == null || this.clickListener == null || !this.gestureDetector.onTouchEvent(motionEvent))) {
                this.clickListener.onClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
            }
            return false;
        }
    }

    public static GalleryDetailFrag getInstance(String str, String str2) {
        GalleryDetailFrag galleryDetailFrag = new GalleryDetailFrag();
        galleryDetailFrag.title = str;
        galleryDetailFrag.from = str2;
        return galleryDetailFrag;
    }

    private void init() {
        this.tbTitle = this.rootView.findViewById(R.id.tb_title);
        this.tbTitle.setText(this.title);
        this.rootView.findViewById(R.id.tb_back).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GalleryDetailFrag.this.getActivity().onBackPressed();
            }
        });
        this.mediaList.clear();
        selected.clear();
        if (this.from == null) {
            getActivity().onBackPressed();
        }
        if (this.from.equals("Images")) {
            this.mediaList.addAll(ImagesFrag.imagesList);
            selected.addAll(ImagesFrag.selected);
        } else {
            this.mediaList.addAll(VideosFrag.videosList);
            selected.addAll(VideosFrag.selected);
        }
        this.rvDetail = this.rootView.findViewById(R.id.rv_detail);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_gallery_detail, viewGroup, false);
        this.sharedpreferences = getActivity().getSharedPreferences("myprefadmob", 0);
        this.activity = getActivity();
        this.connectionDetector = new ConnectionDetector(this.activity.getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.adContainer = this.rootView.findViewById(R.id.adView);
        this.bannerContainer = this.rootView.findViewById(R.id.banner_container);
        this.ImageOverlayadview = this.rootView.findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        if (isConnectingToInternet) {
            int i = this.displayad;
        } else {
            this.rootView.findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        init();
        populateRecyclerView();
        return this.rootView;
    }

    private void populateRecyclerView() {
        if (this.from.equals("Images")) {
            this.mAdapter = new MediaAdapter(getActivity(), this.mediaList, selected, false);
        } else {
            this.mAdapter = new MediaAdapter(getActivity(), this.mediaList, selected, true);
        }
        this.rvDetail.setLayoutManager(new GridLayoutManager(getContext(), 3));
        this.rvDetail.getItemAnimator().setChangeDuration(0);
        this.rvDetail.setAdapter(this.mAdapter);
        this.rvDetail.addOnItemTouchListener(new RecyclerTouchListener(getContext(), this.rvDetail, new ClickListener() {
            public void onLongClick(View view, int i) {
            }

            public void onClick(View view, int i) {
                ((Gallery) GalleryDetailFrag.this.getActivity()).sendResult(GalleryDetailFrag.this.mediaList.get(i));
            }
        }));
    }
}
