package com.MV.Lyrics.Home.Model;

public class ThemeHorizontalModel {

    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
    public boolean IsNativeAds = false;
    private String categoryid;
    private String themeid;
    private String ThemeName;
    private String image;
    private String Bundelurl;
    private String BundelPath;
    private String Bundelname;
    private int Bundelfilesize;
    private String GameobjectName;
    private String isNewRealise;
    private String particalThumb;
    private String ZipFolderName;
    private String ZipDownloadCatName;
    private String Unity3DName;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public String getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(String categoryid) {
        this.categoryid = categoryid;
    }

    public String getThemeid() {
        return themeid;
    }

    public void setThemeid(String themeid) {
        this.themeid = themeid;
    }

    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getBundelurl() {
        return Bundelurl;
    }

    public void setBundelurl(String bundelurl) {
        Bundelurl = bundelurl;
    }

    public String getBundelPath() {
        return BundelPath;
    }

    public void setBundelPath(String bundelPath) {
        BundelPath = bundelPath;
    }

    public String getBundelname() {
        return Bundelname;
    }

    public void setBundelname(String bundelname) {
        Bundelname = bundelname;
    }

    public int getBundelfilesize() {
        return Bundelfilesize;
    }

    public void setBundelfilesize(int bundelfilesize) {
        Bundelfilesize = bundelfilesize;
    }


    public String getGameobjectName() {
        return GameobjectName;
    }

    public void setGameobjectName(String gameobjectName) {
        GameobjectName = gameobjectName;
    }



    public boolean isAvailableOffline() {
        return isAvailableOffline;
    }

    public void setAvailableOffline(boolean availableOffline) {
        isAvailableOffline = availableOffline;
    }

    public boolean isDownloading() {
        return isDownloading;
    }

    public void setDownloading(boolean downloading) {
        isDownloading = downloading;
    }

    public boolean isNativeAds() {
        return IsNativeAds;
    }

    public void setNativeAds(boolean nativeAds) {
        IsNativeAds = nativeAds;
    }

    public String isNewRealise() {
        return isNewRealise;
    }

    public void setNewRealise(String newRealise) {
        isNewRealise = newRealise;
    }

    public String getParticalThumb() {
        return particalThumb;
    }

    public void setParticalThumb(String particalThumb) {
        this.particalThumb = particalThumb;
    }

    public String getZipFolderName() {
        return ZipFolderName;
    }

    public void setZipFolderName(String zipFolderName) {
        ZipFolderName = zipFolderName;
    }

    public String getZipDownloadCatName() {
        return ZipDownloadCatName;
    }

    public void setZipDownloadCatName(String zipDownloadCatName) {
        ZipDownloadCatName = zipDownloadCatName;
    }

    public String getUnity3DName() {
        return Unity3DName;
    }

    public void setUnity3DName(String unity3DName) {
        Unity3DName = unity3DName;
    }

}
