package com.cybertechinfosoft.photoslideshowwithmusic.activity;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.cybertechinfosoft.photoslideshowwithmusic.MyApplication;
import com.cybertechinfosoft.photoslideshowwithmusic.OnProgressReceiver;
import com.cybertechinfosoft.photoslideshowwithmusic.R;
import com.cybertechinfosoft.photoslideshowwithmusic.service.CreateVideoService;
import com.cybertechinfosoft.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.cybertechinfosoft.photoslideshowwithmusic.util.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jpardogo.android.googleprogressbar.library.ChromeFloatingCirclesDrawable;

public class ProgressActivity extends AppCompatActivity implements OnProgressReceiver {
    private MyApplication application;
    final float[] from;
    final float[] hsv;
    boolean isComplate;
    float lastProg;
    final float[] to;
    private TextView tvProgress;

    public ProgressActivity() {
        this.from = new float[3];
        this.to = new float[3];
        this.hsv = new float[3];
        this.lastProg = 0.0f;
        this.isComplate = true;
    }

//    private NativeAd mNativeAd;

//    private void loadAd() {
//        mNativeAd = new NativeAd(this, getString(R.string.Fb_native));
//        mNativeAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onMediaDownloaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
//                View adView = NativeAdView.render(ProgressActivity.this, mNativeAd, NativeAdView.Type.HEIGHT_300);
//                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
//                // Add the Native Banner Ad View to your ad container
//                nativeBannerAdContainer.addView(adView);
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        });
//
//        mNativeAd.loadAd();
//    }

    private void bindView() {
        this.tvProgress = (TextView) this.findViewById(R.id.tvProgress);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ProgressActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    //GoogleAnalytics
    private void GoogleAnalyticsEvent() {
        MyApplication application = (MyApplication) getApplication();
        Tracker mTracker = application.getDefaultTracker();
        mTracker.setScreenName("ProgressActivity");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());
    }

    private void changePercentageOnText(final float lastProg) {
        synchronized (this) {
            if (this.isComplate) {
                final ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{this.lastProg, lastProg});
                ofFloat.setDuration(300L);
                ofFloat.setInterpolator((TimeInterpolator) new LinearInterpolator());
                ofFloat.addUpdateListener((ValueAnimator.AnimatorUpdateListener) new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                        ProgressActivity.this.hsv[0] = ProgressActivity.this.from[0] + (ProgressActivity.this.to[0] - ProgressActivity.this.from[0]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[1] = ProgressActivity.this.from[1] + (ProgressActivity.this.to[1] - ProgressActivity.this.from[1]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[2] = ProgressActivity.this.from[2] + (ProgressActivity.this.to[2] - ProgressActivity.this.from[2]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.tvProgress.setText((CharSequence) String.format(" %05.2f%%", (float) valueAnimator.getAnimatedValue()));
                    }
                });
                ofFloat.addListener((Animator.AnimatorListener) new Animator.AnimatorListener() {
                    public void onAnimationCancel(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationEnd(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationRepeat(final Animator animator) {
                    }

                    public void onAnimationStart(final Animator animator) {
                        ProgressActivity.this.isComplate = false;
                    }
                });
                ofFloat.start();
                this.lastProg = lastProg;
            }
        }
    }


    public void onBackPressed() {
    }

    ProgressBar mProgressBar;

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_progress);
        this.getWindow().addFlags(128);
        this.application = MyApplication.getInstance();
        this.bindView();
        loadAd();
        PutAnalyticsEvent();
        GoogleAnalyticsEvent();
        mProgressBar = (ProgressBar) findViewById(R.id.google_progress);
        Rect bounds = mProgressBar.getIndeterminateDrawable().getBounds();
        mProgressBar.setIndeterminateDrawable(getProgressDrawable());
        mProgressBar.getIndeterminateDrawable().setBounds(bounds);
    }

    private UnifiedNativeAd nativeAd;

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.admob_nativeadavance_id));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
//                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_native, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.findViewById(R.id.ad_body).setSelected(true);
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }


    private Drawable getProgressDrawable() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        int value = Integer.parseInt(prefs.getString(getString(R.string.progressBar_pref_key), getString(R.string.progressBar_pref_defValue)));
        Drawable progressDrawable = null;
        progressDrawable = new ChromeFloatingCirclesDrawable.Builder(this)
                .colors(getProgressDrawableColors())
                .build();


        return progressDrawable;
    }


    private int[] getProgressDrawableColors() {
        int[] colors = new int[4];
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        colors[0] = prefs.getInt(getString(R.string.firstcolor_pref_key), getResources().getColor(R.color.red));
        colors[1] = prefs.getInt(getString(R.string.secondcolor_pref_key), getResources().getColor(R.color.blue));
        colors[2] = prefs.getInt(getString(R.string.thirdcolor_pref_key), getResources().getColor(R.color.yellow));
        colors[3] = prefs.getInt(getString(R.string.fourthcolor_pref_key), getResources().getColor(R.color.green));
        return colors;
    }


    public void onImageProgressFrameUpdate(final float n) {
        this.runOnUiThread((Runnable) new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 25.0f / 100.0f);
            }
        });
    }

    public void onOverlayingFinish(final String s) {
    }

    public void onProgressFinish(final String s) {
        if (MyApplication.IsVideo) {
            Utils.isVideoCreationRunning = false;
            final Intent intent = new Intent((Context) this, (Class) Activity_VideoPlay.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("android.intent.extra.TEXT", s);
            intent.putExtra("KEY", "FromProgress");
            this.application.isFristTimeTheme = true;
            ActivityAnimUtil.startActivitySafely((View) this.tvProgress, intent);
            super.onBackPressed();
        }
    }

    protected void onResume() {
        super.onResume();
        this.application.setOnProgressReceiver((OnProgressReceiver) this);
    }

    protected void onStop() {
        super.onStop();
        this.application.setOnProgressReceiver((OnProgressReceiver) null);
        if (MyApplication.isMyServiceRunning((Context) this, (Class) CreateVideoService.class)) {
//            this.finish();
        }
    }

    public void onVideoProgressFrameUpdate(final float n) {
        this.runOnUiThread((Runnable) new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 75.0f / 100.0f + 25.0f);
            }
        });
    }
}
