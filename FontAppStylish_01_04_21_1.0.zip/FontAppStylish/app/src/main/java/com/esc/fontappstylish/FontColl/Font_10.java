package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Font_10 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"ค", "๖", "¢", "໓", "ē", "f", "ງ", "h", "i", "ว", "k", "l", "๓", "ຖ", "໐", "p", "๑", "r", "Ş", "t", "น", "ง", "ຟ", "x", "ฯ", "ຊ"};
    }

    public String getName() {
        return "ค๖¢";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"ค", "๖", "¢", "໓", "ē", "f", "ງ", "h", "i", "ว", "k", "l", "๓", "ຖ", "໐", "p", "๑", "r", "Ş", "t", "น", "ง", "ຟ", "x", "ฯ", "ຊ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
