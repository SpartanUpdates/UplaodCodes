package com.esc.storymaker.adapters;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import java.util.ArrayList;

public class SrvTemplateSectionAdapter extends RecyclerView.Adapter<SrvTemplateSectionAdapter.SectionViewHolder> {
    private ArrayList<String> categories;
    private MainActivity mainActivity;

    public class SectionViewHolder extends ViewHolder {
        private CardView cvMain;
        private RecyclerView itemRecyclerView;
        private LinearLayout llRoot;
        private TextView tvTitle;

        public SectionViewHolder(View view) {
            super(view);
            cvMain=view.findViewById(R.id.cv_main);
            llRoot = view.findViewById(R.id.ll_root);
            tvTitle = view.findViewById(R.id.tv_title);
            itemRecyclerView = view.findViewById(R.id.item_recycler_view);
        }
    }

    public SrvTemplateSectionAdapter(MainActivity mainActivity, ArrayList<String> arrayList) {
        this.mainActivity = mainActivity;
        this.categories = arrayList;
    }

    public SectionViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new SectionViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.header_templates, viewGroup, false));
    }

    public void onBindViewHolder(SectionViewHolder sectionViewHolder, int i) {
        sectionViewHolder.tvTitle.setText(this.categories.get(i));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.mainActivity, RecyclerView.HORIZONTAL, false);
        SrvTemplateItemsAdapter srvTemplateItemsAdapter = new SrvTemplateItemsAdapter(this.mainActivity, this.categories.get(i));
        sectionViewHolder.itemRecyclerView.setHasFixedSize(true);
        sectionViewHolder.itemRecyclerView.setNestedScrollingEnabled(true);
        sectionViewHolder.itemRecyclerView.setLayoutManager(linearLayoutManager);
        sectionViewHolder.itemRecyclerView.setAdapter(srvTemplateItemsAdapter);
    }

    public int getItemCount() {
        return this.categories.size();
    }
}
