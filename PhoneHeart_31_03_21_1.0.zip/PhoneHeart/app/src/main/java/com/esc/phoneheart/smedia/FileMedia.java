package com.esc.phoneheart.smedia;

import com.esc.phoneheart.model.MediaList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class FileMedia {
    public String TAG = "SocialMedia";
    public ArrayList<MediaList> arrContents;
    public HashMap<Integer, MediaList> hmFileTypeToMediaList;
    public String name;

    public FileMedia(String str) {
        this.name = str;
        this.arrContents = new ArrayList();
    }

    public void updateHashMapFileTypeToMediaList() {
        try {
            this.hmFileTypeToMediaList = new HashMap(this.arrContents.size());
            Iterator it = this.arrContents.iterator();
            while (it.hasNext()) {
                MediaList mediaList = (MediaList) it.next();
                try {
                    this.hmFileTypeToMediaList.put(Integer.valueOf(mediaList.mediaType.ordinal()), mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
