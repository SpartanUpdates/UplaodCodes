package com.vidsoft.videostatusmaker.Utils;

import java.io.*;

public class StickerPropertyModel implements Serializable
{
  private static final long serialVersionUID = 3800737478616389410L;
  private float degree;
  private int horizonMirror;
  private int order;
  private float scaling;
  private long stickerId;
  private String stickerURL;
  private String text;
  private float xLocation;
  private float yLocation;

  public float getDegree() {
    return this.degree;
  }

  public int getHorizonMirror() {
    return this.horizonMirror;
  }

  public int getOrder() {
    return this.order;
  }

  public float getScaling() {
    return this.scaling;
  }

  public long getStickerId() {
    return this.stickerId;
  }

  public String getStickerURL() {
    return this.stickerURL;
  }

  public String getText() {
    return this.text;
  }

  public float getxLocation() {
    return this.xLocation;
  }

  public float getyLocation() {
    return this.yLocation;
  }

  public void setDegree(final float degree) {
    this.degree = degree;
  }

  public void setHorizonMirror(final int horizonMirror) {
    this.horizonMirror = horizonMirror;
  }

  public void setOrder(final int order) {
    this.order = order;
  }

  public void setScaling(final float scaling) {
    this.scaling = scaling;
  }

  public void setStickerId(final long stickerId) {
    this.stickerId = stickerId;
  }

  public void setStickerURL(final String stickerURL) {
    this.stickerURL = stickerURL;
  }

  public void setText(final String text) {
    this.text = text;
  }

  public void setxLocation(final float xLocation) {
    this.xLocation = xLocation;
  }

  public void setyLocation(final float yLocation) {
    this.yLocation = yLocation;
  }
}
