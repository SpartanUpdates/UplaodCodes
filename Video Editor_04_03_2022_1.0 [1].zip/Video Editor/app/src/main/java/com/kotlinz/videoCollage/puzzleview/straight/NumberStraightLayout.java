package com.kotlinz.videoCollage.puzzleview.straight;

import android.util.Log;
import com.kotlinz.videoCollage.flying.puzzle.straight.StraightPuzzleLayout;


public abstract class NumberStraightLayout extends StraightPuzzleLayout {
    static final String TAG = "NumberStraightLayout";
    protected int theme;

    public abstract int getThemeCount();

    public NumberStraightLayout(int i) {
        if (i >= getThemeCount()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("NumberStraightLayout: the most theme count is ");
            stringBuilder.append(getThemeCount());
            stringBuilder.append(" ,you should let theme from 0 to ");
            stringBuilder.append(getThemeCount() - 1);
            stringBuilder.append(" .");
            Log.e(TAG, stringBuilder.toString());
        }
        this.theme = i;
    }

    public int getTheme() {
        return this.theme;
    }
}
