package com.wavymusic.TextChange.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.R;
import com.wavymusic.TextChange.Adapter.TextAdapter;
import com.wavymusic.kprogresshud.KProgressHUD;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.NativeAds.NativeAdvanceAds.populateNativeAdView;

public class TextEditActivity extends AppCompatActivity {

    public RecyclerView rvTextEdit;
    Activity activity = TextEditActivity.this;
    public static ArrayList<String> textList = new ArrayList();
    public static ArrayList<String> EditableTextList = new ArrayList();
    TextAdapter ChangeTextAdapter;
    String JsonResponse;
    ImageView ivInfoMessage;
    AlertDialog alertDialog;
    TextView tvtitle, tvchangemessage;
    ImageView ivback;
    TextView tvDone;

    private UnifiedNativeAd nativeAd;

    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_edit);
        tvtitle = findViewById(R.id.tv_edit_message);
        tvDone = findViewById(R.id.tv_done);
        tvchangemessage = findViewById(R.id.tv_change_message);
        ivback = findViewById(R.id.ivBack);
        if (textList != null && EditableTextList != null) {
            textList.clear();
            EditableTextList.clear();
        }
        PutAnalyticsEvent();
        CallNativeAds();
        interstitialAd();
        Init();
        SetTextAdapter();
        tvDone.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }
                else {
                    GetJsonResponse();
                }
            }
        });
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    public static String GetJsonArray(ArrayList<String> arrayList) {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < arrayList.size()) {
                jSONArray.put(arrayList.get(i).equals("") ? EditableTextList.get(i) : arrayList.get(i));
                i++;
            }
            jSONObject.put("data", jSONArray);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FINAL Down Json:");
            stringBuilder.append(jSONObject.toString());
            return jSONObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "TextEditActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void Init() {
        rvTextEdit = findViewById(R.id.rv_edit_Message);
        ivInfoMessage = findViewById(R.id.iv_message_info);
        ivInfoMessage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setMessage("This messages will appear in video.");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertDialog.dismiss();
                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
                alertDialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent));

            }
        });
    }

    private void CallNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.native_adview);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.InterstitialAd_id_Wavy));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                requestInterstitial();
                GetJsonResponse();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }
    public ArrayList<String> setTextResponse(String str) {
        ArrayList<String> arrayList = new ArrayList();
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                for (int i = 0; i < jSONArray.length(); i++) {
                    arrayList.add(jSONArray.getString(i));
                }
                return arrayList;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void SetTextAdapter() {
        getTextInputResponse();
        ChangeTextAdapter = new TextAdapter(textList, this);
        GridLayoutManager manager = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rvTextEdit.setLayoutManager(manager);
        rvTextEdit.setHasFixedSize(true);
        rvTextEdit.setAdapter(ChangeTextAdapter);
    }

    public void GetJsonResponse() {
        String ChangeTextResponse = GetJsonArray(textList);
        UnityPlayer.UnitySendMessage("WavyThemeData", "ReturnTextResponce", ChangeTextResponse);
        finish();
    }

    public void getTextInputResponse() {
        JsonResponse = getIntent().getStringExtra("JsonStr");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InputJson = ");
        stringBuilder.append(JsonResponse);
        textList.addAll(setTextResponse(JsonResponse));
        EditableTextList.addAll(textList);
    }


    public void onBackPressed() {
        super.onBackPressed();
        if (textList != null && EditableTextList != null) {
            textList.clear();
            EditableTextList.clear();
        }
        finish();
    }

}
