package com.kotlinz.festivalstorymaker.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Layout;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.appizona.yehiahd.fastsave.FastSave;
import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.BusinessTemplateAdapter;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalCategoryRlatedAdapter;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalFrameListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalImageListAdapter;
import com.kotlinz.festivalstorymaker.Download.BusinessTemplateDownload;
import com.kotlinz.festivalstorymaker.Download.DownloadTemplateImage;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.customer.AddCustomer;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.Other.g.c;
import com.kotlinz.festivalstorymaker.Other.o.u.a.hb;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.Utils.MagnifierView;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerSavePath;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.cameraonly.CameraOnlyConfig;
import com.kotlinz.festivalstorymaker.roomdatabase.BusinessDatabase;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.TextSticker;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FestivalDetailActivity_New extends BaseActivity implements c, hb, com.kotlinz.festivalstorymaker.Other.k.c, MagnifierView.c, FontListAdapter.a, com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a {

    Activity activity = FestivalDetailActivity_New.this;

    public static boolean n1;
    public static TextView o1;
    public static BorderedTextView p1;
    public TextStickerViewNew1 A0;
    public List<String> B0;
    public boolean C0;
    public boolean D0 = false;
    public boolean E0 = false;
    public boolean F0 = true;
    public List<String> G0 = new ArrayList();
    public hb H0;
    public ArrayList<File> I0 = new ArrayList();
    public boolean J0 = false;
    public boolean K0 = false;
    public int[][] L0;
    public int[] M0;
    public ArrayList<Integer> N0;
    public ImageView O0;
    public boolean P0;
    public boolean Q0;
    public MagnifierView R;
    public ArrayList<View> R0 = new ArrayList();
    public boolean S = false;
    public ArrayList<View> S0 = new ArrayList();
    public boolean T = false;
    public ArrayList<View> T0 = new ArrayList();
    public int U = 7;
    public ArrayList<View> U0 = new ArrayList();
    public int V = 756;
    public Boolean V0;
    public int W = 1;
    public Boolean W0;
    public int X = 6;
    public boolean X0;
    public int Y = 9;
    public boolean Y0;
    public com.kotlinz.festivalstorymaker.Other.g.a Z;
    public boolean Z0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.festival.k> a0;
    public TextStickerViewNew1 a1;
    public ImageStickerViewNew b1;
    public JSONObject c0;
    public Font c1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.cardBt)
    public CardView cardBt;
    @BindView(com.kotlinz.festivalstorymaker.R.id.cardEditor)
    public CardView cardEditor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.cardWt)
    public CardView cardWt;
    public JSONObject d0;
    public FontListAdapter d1;
    public JSONArray e0;
    public com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter e1;
    public com.kotlinz.festivalstorymaker.Models.festival.w f0;
    public int f1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.frame)
    public FrameLayout frame;
    public com.kotlinz.festivalstorymaker.Models.festival.k g0;
    public int g1;
    public JSONObject h0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.festival.f0.c> h1;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.festival.w> i0;
    public com.kotlinz.festivalstorymaker.Models.festival.f0.c i1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView imgAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView imgAlignCenter;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView imgAlignLeft;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView imgAlignRight;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView imgAllCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgBlur)
    public ImageView imgBlur;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView imgCaps;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView imgColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFestival)
    public ImageView imgFestival;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView imgFirstCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView imgFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFrame)
    public ImageView imgFrame;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView imgLine;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView imgSmall;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView imgSpace;
    public AppConstant j0;
    public String j1;
    public String k0;
    public String k1;
    public String l0;
    public Utils l1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listBottomFrames)
    public RecyclerView listBottomFrames;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView listColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView listFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listFrames)
    public RecyclerView listFrames;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listImages)
    public RecyclerView listImages;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout llCaps;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llColors;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;
    public Dialog m1;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlMain)
    public FrameLayout mainFrame;
    public int n0 = -1;
    public int m0 = -1;
    public int o0;
    public int p0;
    public com.kotlinz.festivalstorymaker.Other.g.a Q;
    public MagnifierView.c q0;
    public HashMap<String, String> r0;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog)
    public RelativeLayout rlBottomMoveDeleteDialog;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlMainFrameView)
    public RelativeLayout rlMainFrameView;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlMainView)
    public RelativeLayout rlMainView;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rvPrimaryColor)
    public RecyclerView rvPrimaryColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rvSecondaryColor)
    public RecyclerView rvSecondaryColor;
    public FestivalImageListAdapter s0;
    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView scroll;
    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBar)
    public SeekBar seekBar;
    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar seekBarFontHeight;
    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar seekBarFontSpacing;
    public FestivalFrameListAdapter t0;
    public String u0;
    public String v0;

    public String w0;
    public String x0;
    public String y0;
    public ByteArrayOutputStream z0;

    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    public ArrayList<CategoryWiseData> bottomFrameList;
    public BusinessTemplateAdapter businessTemplateAdapter;
    public LinearLayoutManager mLayoutManager;

    public ArrayList<CategoryWiseData> festivalSubCategoryList = new ArrayList<>();
    public FestivalCategoryRlatedAdapter festivalSubCategoryAdapter;

    Gson gson = new Gson();

    String CatId;

    @BindView(com.kotlinz.festivalstorymaker.R.id.sticker_view)
    StickerView stickerView;

    Utils utils;

    String DataFileName;
    String[] SplitName;


    private int PageNumber = 1;


    public class d implements Runnable {
        public final TextStickerViewNew1 n;

        public d(TextStickerViewNew1 textStickerViewNew1) {
            this.n = textStickerViewNew1;
        }

        public void run() {
            this.n.c();
        }
    }

    public class f implements View.OnClickListener {
        public final View n;
        public final com.kotlinz.festivalstorymaker.Models.g o;

        public f(View view, com.kotlinz.festivalstorymaker.Models.g iVar) {
            this.n = view;
            this.o = iVar;
        }

        public void onClick(View view) {
            FestivalDetailActivity_New.this.K0();
            TextView textView = FestivalDetailActivity_New.o1;
            if (textView != null) {
                textView.setBackground(null);
            }
            view = this.n;
            if (view instanceof ImageView) {
                FestivalDetailActivity_New.this.O0 = (ImageView) view;
            } else if (view instanceof BorderedTextView) {
                FestivalDetailActivity_New.p1 = (BorderedTextView) view;
            } else {
                FestivalDetailActivity_New.o1 = (TextView) view;
            }
            String str = "1";
            FestivalDetailActivity_New.this.P0 = this.o.G.equals(str);
            FestivalDetailActivity_New.this.Q0 = this.o.D.equals(str);
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            View view2 = this.n;
            festivalDetailActivity_New.X0 = view2 instanceof TextView;
            festivalDetailActivity_New.Y0 = view2 instanceof TextView;
            festivalDetailActivity_New.Z0 = view2 instanceof BorderedTextView;
        }
    }

    public class g implements View.OnClickListener {
        public void onClick(View view) {
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            if (festivalDetailActivity_New.S) {
                festivalDetailActivity_New.S = false;
            } else {
                festivalDetailActivity_New.K0();
            }
        }
    }

    public class o implements View.OnClickListener {
        public void onClick(View view) {
            FestivalDetailActivity_New.this.m1.dismiss();
            FestivalDetailActivity_New.this.O0();
        }
    }

    public class p implements View.OnClickListener {
        public void onClick(View view) {
            FestivalDetailActivity_New.this.m1.dismiss();
           /*  g0.b.W(FestivalDetailActivity_New.this);*/
        }
    }

    public class q implements View.OnClickListener {
        public void onClick(View view) {
            FestivalDetailActivity_New.this.m1.dismiss();
        }
    }

    public class r implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            FestivalDetailActivity_New.this.cardWt.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            FestivalDetailActivity_New.this.cardWt.getLayoutParams().height = FestivalDetailActivity_New.this.cardWt.getWidth();
            FestivalDetailActivity_New.this.cardWt.requestLayout();
        }
    }

    public class s implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            FestivalDetailActivity_New.this.cardBt.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            FestivalDetailActivity_New.this.cardBt.getLayoutParams().height = FestivalDetailActivity_New.this.cardBt.getWidth();
            FestivalDetailActivity_New.this.cardBt.requestLayout();
        }
    }

    public class t implements View.OnClickListener {
        public void onClick(View view) {
            int i;
            FestivalDetailActivity_New.this.K0();
            int i2 = 0;
            while (true) {
                i = -16777216;
                if (i2 >= FestivalDetailActivity_New.this.U0.size()) {
                    break;
                }
                if (FestivalDetailActivity_New.this.U0.get(i2) instanceof ImageView) {
                    ImageView imageView = (ImageView) FestivalDetailActivity_New.this.U0.get(i2);
                    if (!FestivalDetailActivity_New.this.V0.booleanValue()) {
                        i = -1;
                    }
                    imageView.setColorFilter(i);
                } else if (FestivalDetailActivity_New.this.U0.get(i2) instanceof BorderedTextView) {
                    BorderedTextView borderedTextView = (BorderedTextView) FestivalDetailActivity_New.this.U0.get(i2);
                    if (!FestivalDetailActivity_New.this.V0.booleanValue()) {
                        i = -1;
                    }
                    borderedTextView.setBorderedColor(i);
                } else {
                    TextView textView = (TextView) FestivalDetailActivity_New.this.U0.get(i2);
                    if (!FestivalDetailActivity_New.this.V0.booleanValue()) {
                        i = -1;
                    }
                    textView.setTextColor(i);
                }
                i2++;
            }
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            festivalDetailActivity_New.V0 = Boolean.valueOf(festivalDetailActivity_New.V0.booleanValue() ^ true);
            festivalDetailActivity_New = FestivalDetailActivity_New.this;
            CardView cardView = festivalDetailActivity_New.cardWt;
            if (festivalDetailActivity_New.V0.booleanValue()) {
                i = -1;
            }
            cardView.setCardBackgroundColor(i);
        }
    }

    public class u implements View.OnClickListener {
        public void onClick(View view) {
            int i;
            FestivalDetailActivity_New.this.K0();
            int i2 = 0;
            while (true) {
                i = -1;
                if (i2 >= FestivalDetailActivity_New.this.T0.size()) {
                    break;
                }
                if (FestivalDetailActivity_New.this.T0.get(i2) instanceof ImageView) {
                    ImageView imageView = (ImageView) FestivalDetailActivity_New.this.T0.get(i2);
                    if (!FestivalDetailActivity_New.this.W0.booleanValue()) {
                        i = -16777216;
                    }
                    imageView.setColorFilter(i);
                } else if (FestivalDetailActivity_New.this.T0.get(i2) instanceof BorderedTextView) {
                    BorderedTextView borderedTextView = (BorderedTextView) FestivalDetailActivity_New.this.T0.get(i2);
                    if (!FestivalDetailActivity_New.this.W0.booleanValue()) {
                        i = -16777216;
                    }
                    borderedTextView.setBorderedColor(i);
                } else {
                    TextView textView = (TextView) FestivalDetailActivity_New.this.T0.get(i2);
                    if (!FestivalDetailActivity_New.this.W0.booleanValue()) {
                        i = -16777216;
                    }
                    textView.setTextColor(i);
                }
                i2++;
            }
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            festivalDetailActivity_New.W0 = Boolean.valueOf(festivalDetailActivity_New.W0.booleanValue() ^ true);
            festivalDetailActivity_New = FestivalDetailActivity_New.this;
            CardView cardView = festivalDetailActivity_New.cardBt;
            if (festivalDetailActivity_New.W0.booleanValue()) {
                i = -16777216;
            }
            cardView.setCardBackgroundColor(i);
        }
    }

    public class v implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            FestivalDetailActivity_New.this.rvPrimaryColor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            FestivalDetailActivity_New.this.rvPrimaryColor.getLayoutParams().height = FestivalDetailActivity_New.this.rvPrimaryColor.getWidth();
            FestivalDetailActivity_New.this.rvPrimaryColor.requestLayout();
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            RecyclerView recyclerView = festivalDetailActivity_New.rvPrimaryColor;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.f0(festivalDetailActivity_New, festivalDetailActivity_New.N0, 0, festivalDetailActivity_New.H0, false, recyclerView.getWidth()));
        }
    }

    public class w implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            FestivalDetailActivity_New.this.rvSecondaryColor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            FestivalDetailActivity_New.this.rvSecondaryColor.getLayoutParams().height = FestivalDetailActivity_New.this.rvSecondaryColor.getWidth();
            FestivalDetailActivity_New.this.rvSecondaryColor.requestLayout();
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            RecyclerView recyclerView = festivalDetailActivity_New.rvSecondaryColor;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.f0(festivalDetailActivity_New, festivalDetailActivity_New.N0, 0, festivalDetailActivity_New.H0, true, recyclerView.getWidth()));
        }
    }

    public class y extends AsyncTask<Void, Void, File> {
        public File a = null;


        @Override
        protected void onPostExecute(File file) {
            super.onPostExecute(file);
            file = this.a;
            if (file != null) {
                FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
                FestivalDetailActivity_New festivalDetailActivity_New2;
                if (festivalDetailActivity_New.C0) {
                    if (festivalDetailActivity_New.k1.length() <= 0) {
                        return;
                    }
                    if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
                    }
                } else if (festivalDetailActivity_New.J0 || festivalDetailActivity_New.K0) {
                    FestivalDetailActivity_New.this.l1.u();
                    /* new g0.a.d(festivalDetailActivity_New, festivalDetailActivity_New.I0, festivalDetailActivity_New.K0 ? "1" : "0").execute(new Void[0]);*/
                    festivalDetailActivity_New2 = FestivalDetailActivity_New.this;
                    festivalDetailActivity_New2.J0 = false;
                    festivalDetailActivity_New2.K0 = false;
                } else {
                    Utils.K(festivalDetailActivity_New, file);
                    FestivalDetailActivity_New.this.l1.u();
                    festivalDetailActivity_New2 = FestivalDetailActivity_New.this;
                    festivalDetailActivity_New2.s0(festivalDetailActivity_New2);
                }
            }
        }

        @Override
        protected File doInBackground(Void... voids) {
            try {
                Bitmap r0 = FestivalDetailActivity_New.this.r0(FestivalDetailActivity_New.this.C0 ? FestivalDetailActivity_New.this.rlMainFrameView : FestivalDetailActivity_New.this.cardEditor);
                File H = FestivalDetailActivity_New.this.C0 ? Utils.H("0") : Utils.t0(0);
                this.a = H;
                if (H != null) {
                    FileOutputStream fileOutputStream = new FileOutputStream(this.a.getAbsolutePath());
                    r0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                }
                FestivalDetailActivity_New.this.I0.add(this.a);
                Utils.K(FestivalDetailActivity_New.this, this.a);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            FestivalDetailActivity_New.this.I0.clear();
        }
    }

    public class z extends AsyncTask<Void, Void, Void> {
        public RelativeLayout a;

        public z(RelativeLayout frameLayout) {
            this.a = frameLayout;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            utils.u();
            DownloadComplete();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            File o0;
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            List list = festivalDetailActivity_New.B0;
            try {
                Bitmap r0 = festivalDetailActivity_New.r0(this.a);
                o0 = x0();
                FileOutputStream fileOutputStream = new FileOutputStream(o0.getAbsolutePath());
                r0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.close();
                Utils.K(FestivalDetailActivity_New.this, o0);
            } catch (Exception e) {
                e.printStackTrace();
                o0 = null;
            }
            list.add(o0.getAbsolutePath());
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            utils = new Utils(FestivalDetailActivity_New.this);
            utils.c(a.getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            utils.m();
        }
    }

    public class ColorListAdapter extends RecyclerView.Adapter<ColorListAdapter.ViewHolder> {
        public Activity p;
        public String[] q;

        public ColorListAdapter(Activity activity, String[] strArr) {
            this.p = activity;
            this.q = strArr;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(com.kotlinz.festivalstorymaker.R.layout.adapter_color_list_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            LinearLayout linearLayout;
            Drawable drawable;
            holder.card.setCardBackgroundColor(Color.parseColor(q[position]));
            if (this.q[position].contains("FFFFFF")) {
                linearLayout = holder.llbg;
                drawable = this.p.getResources().getDrawable(com.kotlinz.festivalstorymaker.R.drawable.rounded_corner_black_border);
            } else {
                linearLayout = holder.llbg;
                drawable = null;
            }
            linearLayout.setBackground(drawable);
            holder.card.setOnClickListener(new com.kotlinz.festivalstorymaker.Models.festival.y5(FestivalDetailActivity_New.this, this, position));
        }

        @Override
        public int getItemCount() {
            return q.length;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            @BindView(com.kotlinz.festivalstorymaker.R.id.card)
            public CardView card;
            @BindView(com.kotlinz.festivalstorymaker.R.id.llbg)
            public LinearLayout llbg;

            public ViewHolder(View view) {
                super(view);
                ButterKnife.bind(this, view);
            }
        }
    }

    public File x0() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post" + File.separator + "Festival";
        final String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(file);
        sb.append(File.separator);
        sb.append(s);
        sb.append(".jpg");
        final String string = sb.toString();
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        return new File(string);
    }

    private void DownloadComplete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.layout_download_complete, null);
        builder.setView(customLayout);
        AlertDialog dialog = builder.create();
        ImageView ivOk = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.iv_ok);
        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public class a implements FestivalFrameListAdapter.a {
        public void a(int i, int i2) {
            frame.removeAllViews();
            frame.requestLayout();
            if (B0.get(i).length() > 0) {
                TextStickerViewNew1 textStickerViewNew1 = A0;
                if (textStickerViewNew1 != null) {
                    mainFrame.removeView(textStickerViewNew1);
                }
                imgFrame.setImageURI(Uri.parse(B0.get(i)));
                imgFrame.setScaleType(ImageView.ScaleType.CENTER_CROP);
            } else if (i == 0) {
                Q0();
            } else {
                imgFrame.setImageURI(null);
            }
        }
    }

    public class b implements TextStickerViewNew1.a {
        public final TextStickerViewNew1 a;

        public b(TextStickerViewNew1 textStickerViewNew1) {
            this.a = textStickerViewNew1;
        }

        public void a(TextStickerViewNew1 textStickerViewNew1) {
            FestivalDetailActivity_New.this.scroll.requestDisallowInterceptTouchEvent(true);
            TextStickerViewNew1 textStickerViewNew12 = FestivalDetailActivity_New.this.a1;
            if (textStickerViewNew12 != null) {
                textStickerViewNew12.setInEdit(false);
                FestivalDetailActivity_New.this.a1.setShowHelpBox(false);
            }
            FestivalDetailActivity_New.this.a1 = textStickerViewNew1;
            textStickerViewNew1.setInEdit(true);
            FestivalDetailActivity_New.this.a1.setShowHelpBox(true);
        }

        public void b(TextStickerViewNew1 textStickerViewNew1) {
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            festivalDetailActivity_New.u0(festivalDetailActivity_New.mainFrame, this.a);
        }

        public void c(TextStickerViewNew1 textStickerViewNew1) {
            if (FestivalDetailActivity_New.this.a1 != null && textStickerViewNew1.getTag().equals(FestivalDetailActivity_New.this.a1.getTag()) && textStickerViewNew1.u) {
                FestivalDetailActivity_New.this.mainFrame.removeView(textStickerViewNew1);
            }
        }


        public void d(TextStickerViewNew1 textStickerViewNew1) {
            FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
            festivalDetailActivity_New.S = true;
            festivalDetailActivity_New.a1 = textStickerViewNew1;
            festivalDetailActivity_New.U0(true);
        }
    }

    public class c implements TextStickerViewNew1.b {
        public void a(boolean z, TextStickerViewNew1 textStickerViewNew1) {
            if (FestivalDetailActivity_New.this.llTextEditor.isShown() && !z) {
                FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
                TextStickerViewNew1 textStickerViewNew12 = festivalDetailActivity_New.a1;
                if (textStickerViewNew12 == null || textStickerViewNew12 == textStickerViewNew1) {
                    festivalDetailActivity_New.U0(z);
                }
            }
        }
    }

    public class l implements TextInputDilaog.d {
        public final FrameLayout a;
        public final TextStickerViewNew1 b;

        public l(FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
            this.a = frameLayout;
            this.b = textStickerViewNew1;
        }

        public void a(String str, int i) {
            if (str.length() == 0) {
                this.a.removeView(this.b);
                this.a.requestLayout();
                return;
            }
            this.b.setText(str);
        }

        public void b(String str) {
        }
    }

    public class m implements FestivalCategoryRlatedAdapter.a {
        public void a(int i, int i2) {
            FestivalDetailActivity_New.this.K0();
            if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
                if (C0) {
                } else if (festivalSubCategoryList.get(i).getThemeThumbnail().length() <= 0 || new File(Utils.n0(FestivalDetailActivity_New.this.festivalSubCategoryList.get(i).getThemeThumbnail())).length() > 0) {
                    k0 = Utils.n0(festivalSubCategoryList.get(i).getThemeThumbnail());
                    imgFestival.setImageURI(Uri.parse(k0));
                    R0(k0);
                } else {
                    if ((com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false))) {
                        Utils bVar = new Utils(activity);
                        String FestivalTemplateName = festivalSubCategoryList.get(i).getThemeThumbnail().substring(festivalSubCategoryList.get(i).getThemeThumbnail().lastIndexOf("/") + 1);
                        new DownloadTemplateImage(FestivalDetailActivity_New.this, imgFestival, festivalSubCategoryList.get(i).getThemeThumbnail(), FestivalTemplateName, bVar);
                    }
                }
            }
        }
    }

    public class n extends RecyclerView.OnScrollListener {
        public void a(RecyclerView recyclerView, int i) {
            if (!recyclerView.canScrollHorizontally(1) && i == 0) {
                FestivalDetailActivity_New festivalDetailActivity_New = FestivalDetailActivity_New.this;
                if (festivalDetailActivity_New.T) {
                    festivalDetailActivity_New.W++;
                }
            }
        }
    }


    public static class x extends BottomSheetDialogFragment {
        public CoordinatorLayout.Behavior t0;

        public class a implements View.OnClickListener {
            public void onClick(View view) {
                CoordinatorLayout.Behavior behavior = x.this.t0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setPeekHeight(5);
                }
                FestivalDetailActivity_New.n1 = false;
                CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                cameraOnlyConfig.returnMode = ReturnMode.CAMERA_ONLY;
                FragmentActivity j = x.this.getActivity();
                Intent intent = new Intent(j, ImagePickerActivity.class);
                intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                j.startActivityForResult(intent, 553);
            }
        }

        public class b implements View.OnClickListener {
            public void onClick(View view) {
                CoordinatorLayout.Behavior behavior = x.this.t0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setPeekHeight(5);
                }
                FestivalDetailActivity_New.n1 = false;
                ImagePicker aVar = new ImagePicker.ImagePickerWithActivity(getActivity());
                ImagePickerConfig imagePickerConfig = aVar.config;
                imagePickerConfig.showCamera = true;
                imagePickerConfig.returnMode = ReturnMode.GALLERY_ONLY;
                aVar.single();
                aVar.config.includeAnimation = false;
                aVar.start();
            }
        }

        @SuppressLint("RestrictedApi")
        @Override
        public void setupDialog(@NonNull Dialog dialog, int style) {
            super.setupDialog(dialog, style);
            View inflate = View.inflate(getActivity(), com.kotlinz.festivalstorymaker.R.layout.dialog_select_image, null);
            dialog.setContentView(inflate);
            CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams) ((View) inflate.getParent()).getLayoutParams()).getBehavior();
            this.t0 = behavior;
            if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                ((BottomSheetBehavior) behavior).setPeekHeight(3);
            }
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llCamera).setOnClickListener(new a());
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llGallery).setOnClickListener(new b());
        }

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

    }

    public FestivalDetailActivity_New() {
        Boolean bool = Boolean.TRUE;
        this.V0 = bool;
        this.W0 = bool;
        this.X0 = false;
        this.Y0 = false;
        this.Z0 = false;
        this.f1 = -1;
        this.g1 = -1;
        this.h1 = new ArrayList();
    }


    public static void y0(FestivalDetailActivity_New festivalDetailActivity_New, String str, String str2, String str3, String str4, String str5) {
        festivalDetailActivity_New.imgBlur.setVisibility(View.GONE);
        festivalDetailActivity_New.u0 = str;
        festivalDetailActivity_New.v0 = str2;
        festivalDetailActivity_New.w0 = str3;
        festivalDetailActivity_New.x0 = str4;
        festivalDetailActivity_New.y0 = str5;

        AddCustomer addCustomer = new AddCustomer();
        addCustomer.setName(str);
        addCustomer.setMobileNo(str2);
        addCustomer.setEmail(str3);
        addCustomer.setOccupation(str4);
        addCustomer.setCity(str5);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Utils.t(festivalDetailActivity_New));
        stringBuilder.append("");
        addCustomer.setDeviceId(stringBuilder.toString());
        addCustomer.setDeviceType("A");

        //adding to database
        BusinessDatabase.getBusinessDetailsDatabase(festivalDetailActivity_New).addBusinessDeo().insertBusinessDetails(addCustomer);
        festivalDetailActivity_New.m1.dismiss();
    }

    public final void C0(com.kotlinz.festivalstorymaker.Models.g iVar, View view) {
        ArrayList arrayList;
        String str = "1";
        if (iVar.G.equalsIgnoreCase(str)) {
            arrayList = this.R0;
        } else if (iVar.D.equalsIgnoreCase(str)) {
            arrayList = this.S0;
        } else if (iVar.E.equalsIgnoreCase(str)) {
            arrayList = this.T0;
        } else {
            if (iVar.F.equalsIgnoreCase(str)) {
                arrayList = this.U0;
            }
            if (!iVar.G.equals(str) || iVar.D.equals(str) || iVar.E.equals(str) || iVar.F.equals(str)) {
                view.setOnClickListener(new f(view, iVar));
            }
            return;
        }
        arrayList.add(view);
        if (iVar.G.equals(str)) {
        }
        view.setOnClickListener(new f(view, iVar));
    }

    /*public final void D0() {
        TextStickerViewNew1 textStickerViewNew1 = this.A0;
        if (textStickerViewNew1 != null) {
            this.mainFrame.removeView(textStickerViewNew1);
        }
        textStickerViewNew1 = new TextStickerViewNew1(this, this.scroll, this.n0, this.m0);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        this.layoutParams = layoutParams;
        layoutParams.addRule(10);
        textStickerViewNew1.j0 = true;
        textStickerViewNew1.setLayoutParams(this.layoutParams);
        Font aVar = new Font();
        aVar.a = -16777216;
        aVar.b = (float) 7;
        aVar.c = Typeface.createFromAsset(getAssets(), "fonts/Mont-Bold.ttf");
        textStickerViewNew1.setFont(aVar);
        textStickerViewNew1.setLayoutX(this.n0 / 2);
        textStickerViewNew1.setLayoutY(this.m0 - 60);
        textStickerViewNew1.setScale(5.0f);
        textStickerViewNew1.setPaddingLeft(10);
        textStickerViewNew1.setPaddingRight(10);
        textStickerViewNew1.setAlign(Layout.Alignment.ALIGN_CENTER);
        textStickerViewNew1.setOpacity(255);
        textStickerViewNew1.setUnderLine(false);
        textStickerViewNew1.setInEdit(false);
        textStickerViewNew1.setStrikethrough(false);
        textStickerViewNew1.setLetterSpacing(0.0f);
        textStickerViewNew1.setLineSpacing(10.0f);
        StringBuilder stringBuilder = new StringBuilder();
        String str = "";
        stringBuilder.append(FastSave.getInstance().getString(AppConstant.w2, str).toLowerCase());
        stringBuilder.append("|");
        stringBuilder.append(FastSave.getInstance().getString(AppConstant.x2, str).toLowerCase());
        textStickerViewNew1.setText(stringBuilder.toString());
        textStickerViewNew1.setOperationListener(new b(textStickerViewNew1));
        textStickerViewNew1.setOnOutSideTouchListner(new c());
        Utils.g0(this.h1, textStickerViewNew1);
        this.h1.add(new com.kotlinz.festivalstorymaker.Models.festival.f0.c());
        this.mainFrame.addView(textStickerViewNew1);
        this.mainFrame.requestLayout();
        this.A0 = textStickerViewNew1;
        new Handler().postDelayed(new d(textStickerViewNew1), 1000);
    }*/

    @SuppressLint({"NewApi"})
    public final void E0(int i) {
        int i2 = -16777216;
        this.imgAlignCenter.setColorFilter(i == 0 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        this.imgAlignLeft.setColorFilter(i == -1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = this.imgAlignRight;
        if (i != 1) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        this.j1 = this.a1.getText();
        TextStickerViewNew1 textStickerViewNew1 = this.a1;
        Layout.Alignment alignment = i == 0 ? Layout.Alignment.ALIGN_CENTER : i == 1 ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
        textStickerViewNew1.setAlign(alignment);
        this.a1.setText(this.j1);
        this.a1.requestLayout();
        com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = this.h1.get(((Integer) this.a1.getTag()).intValue());
        this.i1 = cVar;
        cVar.c = i;
        this.h1.set(((Integer) this.a1.getTag()).intValue(), this.i1);
    }

    public final void F0(int i) {
        int i2 = -16777216;
        this.imgFirstCap.setColorFilter(i == 1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        this.imgAllCap.setColorFilter(i == 2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = this.imgSmall;
        if (i != 0) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.a1.getText();
        this.j1 = str;
        if (i != -1) {
            TextStickerViewNew1 textStickerViewNew1 = this.a1;
            str = i == 2 ? str.toUpperCase() : i == 0 ? str.toLowerCase() : t0(str);
            textStickerViewNew1.setText(str);
        }
        com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = this.h1.get(((Integer) this.a1.getTag()).intValue());
        this.i1 = cVar;
        cVar.e = i;
        this.h1.set(((Integer) this.a1.getTag()).intValue(), this.i1);
    }

    public final void G0(int i) {
        int i2 = 0;
        if (this.X0) {
            this.X0 = false;
            for (int i3 = 0; i3 < this.T0.size(); i3++) {
                if (this.T0.get(i3) instanceof ImageView) {
                    ((ImageView) this.T0.get(i3)).setColorFilter(i);
                } else {
                    ((TextView) this.T0.get(i3)).setTextColor(i);
                }
            }
            while (i2 < this.U0.size()) {
                if (this.U0.get(i2) instanceof ImageView) {
                    ((ImageView) this.U0.get(i2)).setColorFilter(i);
                } else {
                    ((TextView) this.U0.get(i2)).setTextColor(i);
                }
                i2++;
            }
        } else if (this.P0) {
            I0(true, i);
        } else if (this.Q0) {
            I0(false, i);
        } else if (!this.Y0) {
            ImageView imageView = this.O0;
            if (imageView != null) {
                imageView.setColorFilter(i);
            }
        } else if (this.Z0) {
            BorderedTextView borderedTextView = p1;
            if (borderedTextView != null) {
                borderedTextView.setBorderedColor(i);
            }
        } else {
            TextView textView = o1;
            if (textView != null) {
                textView.setTextColor(i);
            }
        }
    }

    public final void H0(ImageView imageView) {
        LinearLayout linearLayout;
        ImageView imageView2 = this.imgFont;
        int i = -16777216;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = this.imgColor;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = this.imgAlign;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = this.imgSpace;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = this.imgLine;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = this.imgCaps;
        if (imageView != imageView2) {
            i = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView2.setColorFilter(i);
        if (imageView == this.imgFont) {
            linearLayout = this.llFonts;
        } else if (imageView == this.imgColor) {
            linearLayout = this.llColors;
        } else if (imageView == this.imgAlign) {
            linearLayout = this.llAlign;
        } else if (imageView == this.imgSpace) {
            linearLayout = this.llSpacing;
        } else if (imageView == this.imgLine) {
            linearLayout = this.llLine;
        } else if (imageView == this.imgCaps) {
            linearLayout = this.llCaps;
        } else {
            return;
        }
        linearLayout.bringToFront();
    }

    @Override
    public void L(int i, String str) {

    }

    @Override
    public void I(int i, String str) {

    }

    @Override
    public void z(int i, String s) {
        final String s2 = "1";
        if (i == 66) {
            ArrayList<com.kotlinz.festivalstorymaker.Models.g> e = this.j0.getFestivalEditThemeData(this, s);
            frame.removeAllViews();
            ArrayList<com.kotlinz.festivalstorymaker.Models.g> list = e;
            Float value;
            Float value2;
            int width;
            int height;
            ImageView imageView;
            List b;
            Bitmap decodeFile;
            ImageStickerViewNew imageStickerViewNew;
            float n3;
            String j;
            Font a;
            AssetManager assets;
            StringBuilder f2;
            com.kotlinz.festivalstorymaker.Models.g k = null;
            float floatValue;
            float floatValue2;
            double n4;
            double n5;
            com.kotlinz.festivalstorymaker.Models.g l;
            TextView o;
            TextView o2 = null;
            com.kotlinz.festivalstorymaker.Models.g m;
            BorderedTextView q;
            float n6;
            float n7;
            ArrayList<com.kotlinz.festivalstorymaker.Models.g> list2 = null;
            int n8;
            ImageView imageView2;
            for (i = 0; i < e.size(); ++i, list = list2) {
                value = Float.parseFloat(list.get(i).h) * n0 / 1080.0f;
                value2 = Float.parseFloat(list.get(i).i) * n0 / 1080.0f;
                width = (int) (Float.parseFloat(list.get(i).j) * n0 / 1080.0f);
                height = (int) (Float.parseFloat(list.get(i).k) * n0 / 1080.0f);
                Label_2293:
                {
                    if (list.get(i).g.contains("shape")) {
                        imageView = new ImageView(this);
                        imageView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
                        imageView.setX(value);
                        imageView.setY(value2);
                        imageView.getLayoutParams().width = width;
                        imageView.getLayoutParams().height = height;
                        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        imageView.requestLayout();
                        frame.addView(imageView);
                        C0(list.get(i), imageView);
                    } else if (list.get(i).H.equals(s2)) {
                        b = Utils.n(this);
                        if (b.size() > 0) {
                            decodeFile = BitmapFactory.decodeFile((String) b.get(0));
                            imageStickerViewNew = new ImageStickerViewNew(this, b.get(0).toString(), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m((float) decodeFile.getWidth(), (float) (decodeFile.getWidth() * height / decodeFile.getHeight()), 2.0f, (float) (decodeFile.getWidth() / 2)), (float) (decodeFile.getHeight() / 2 - (decodeFile.getHeight() - height) / 2), 1.0f, 0.0f, 2, true);
                            imageStickerViewNew.setGif(false);
                            imageStickerViewNew.setInEdit(false);
                            imageStickerViewNew.setScaleType(ImageView.ScaleType.FIT_CENTER);
                            imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                            imageStickerViewNew.setSize((float) height);
                            imageStickerViewNew.setOperationListener(new com.kotlinz.festivalstorymaker.Listener.festival.a5(this, frame));
                            frame.addView(imageStickerViewNew);
                            frame.requestLayout();
                        }
                    } else {
                        if (list.get(i).e.equalsIgnoreCase("text")) {
                            n3 = Float.parseFloat(list.get(i).w) * o0 / 1080.0f;
                            j = list.get(i).A;
                            a = new Font();
                            a.b = n3 / Resources.getSystem().getDisplayMetrics().density;
                            assets = this.getAssets();
                            f2 = new StringBuilder("fonts/");
                            f2.append(Utils.k(this, j));
                            a.c = Typeface.createFromAsset(assets, f2.toString());
                            k = list.get(i);
                            floatValue = value;
                            floatValue2 = value2;
                            Label_2088:
                            {
                                if (k.n.length() <= 0) {
                                    n4 = width;
                                    n5 = height;
                                    l = k;
                                    o = Utils.fFestival(this, k, floatValue, floatValue2, n4, n5, a, true, true);
                                    o.setIncludeFontPadding(false);
                                    o.setTextColor(Color.parseColor(l.v));
                                    o.setOnTouchListener(new com.kotlinz.festivalstorymaker.Listener.festival.c5(this, new GestureDetector(new com.kotlinz.festivalstorymaker.Listener.festival.b5(this, o, l))));
                                    o2 = o;
                                    if (l.y.length() <= 0) {
                                        break Label_2088;
                                    }
                                    o2 = o;
                                    if (Integer.parseInt(l.y) <= 0) {
                                        break Label_2088;
                                    }
                                    o2 = o;
                                } else {
                                    m = k;
                                    q = Utils.hf(this, m, floatValue, floatValue2, width, height, a, true);
                                    q.setIncludeFontPadding(false);
                                    q.setTextColor(Color.parseColor(m.v));
                                    q.setOnTouchListener(new com.kotlinz.festivalstorymaker.Listener.festival.e5(this, new GestureDetector(new com.kotlinz.festivalstorymaker.Listener.festival.d5(this, q, m))));
                                    o2 = q;
                                    if (m.y.length() <= 0) {
                                        break Label_2088;
                                    }
                                    o2 = q;
                                    if (Integer.parseInt(m.y) <= 0) {
                                        break Label_2088;
                                    }
                                    o2 = q;
                                }
                                n6 = (float) (height / 2);
                                n7 = (float) (width / 2);
                                o2.setX(floatValue - n6 + n7);
                                o2.setY(floatValue2 - n7 + n6);
                                o2.setRotation((float) Integer.parseInt(k.y));
                                o2.getLayoutParams().height = width;
                                o2.getLayoutParams().width = height;
                                o2.requestLayout();
                            }
                            frame.addView(o2);
                            frame.requestLayout();
                            C0(k, o2);
                            list2 = e;
                            break Label_2293;
                        }
                        n8 = (i = i);
                        list2 = list;
                        if (!list.get(n8).e.equalsIgnoreCase("text")) {
                            imageView2 = new ImageView(this);
                            imageView2.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
                            imageView2.setX(value);
                            imageView2.setY(value2);
                            imageView2.getLayoutParams().width = width;
                            imageView2.getLayoutParams().height = height;
                            Glide.with(activity).load(list.get(n8).f).into(imageView2);
                            imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            imageView2.requestLayout();
                            frame.addView(imageView2);
                            C0(list.get(n8), imageView2);
                            list2 = list;
                            i = n8;
                        }
                        break Label_2293;
                    }
                    list2 = list;
                }
                frame.requestLayout();
            }
        }
    }

    public final void I0(boolean z, int i) {
        int i2 = 0;
        if (z) {
            while (i2 < this.R0.size()) {
                if (this.R0.get(i2) instanceof ImageView) {
                    ((ImageView) this.R0.get(i2)).setColorFilter(i);
                } else if (this.R0.get(i2) instanceof BorderedTextView) {
                    ((BorderedTextView) this.R0.get(i2)).setBorderedColor(i);
                } else {
                    ((TextView) this.R0.get(i2)).setTextColor(i);
                }
                i2++;
            }
            return;
        }
        while (i2 < this.S0.size()) {
            if (this.S0.get(i2) instanceof ImageView) {
                ((ImageView) this.S0.get(i2)).setColorFilter(i);
            } else if (this.S0.get(i2) instanceof BorderedTextView) {
                ((BorderedTextView) this.S0.get(i2)).setBorderedColor(i);
            } else {
                ((TextView) this.S0.get(i2)).setTextColor(i);
            }
            i2++;
        }
    }


    public final void J0() {
        int i = 0;
        if (!F0) {
            i = 8;
        }
    }

    public void K(Typeface typeface, int i) {
        Font font = this.a1.getFont();
        this.c1 = font;
        font.c = typeface;
        this.a1.setFont(font);
        com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = this.h1.get(((Integer) this.a1.getTag()).intValue());
        this.i1 = cVar;
        cVar.f = i;
        this.h1.set(((Integer) this.a1.getTag()).intValue(), this.i1);
    }

    public void K0() {
        if (this.rlBottomMoveDeleteDialog.isShown()) {
            T0(false);
        }
        TextStickerViewNew1 textStickerViewNew1 = this.a1;
        if (textStickerViewNew1 != null) {
            textStickerViewNew1.setInEdit(false);
        }
        ImageStickerViewNew imageStickerViewNew = this.b1;
        if (imageStickerViewNew != null) {
            imageStickerViewNew.setInEdit(false);
        }
        TextView textView = o1;
        if (textView != null) {
            textView.setBackground(null);
        }
        if (findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            U0(false);
        }
        if (this.rlBottomMoveDeleteDialog.isShown()) {
            T0(false);
        }
        for (int i = 0; i < this.mainFrame.getChildCount(); i++) {
            if (this.mainFrame.getChildAt(i) instanceof ImageStickerViewNew) {
                ((ImageStickerViewNew) this.mainFrame.getChildAt(i)).setInEdit(false);
            }
        }
    }


    public void M(int i) {
        Font font = this.a1.getFont();
        this.c1 = font;
        font.a = Color.parseColor(colorList[i]);
        this.a1.setFont(this.c1);
        com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = this.h1.get(((Integer) this.a1.getTag()).intValue());
        this.i1 = cVar;
        cVar.d = i;
        this.h1.set(((Integer) this.a1.getTag()).intValue(), this.i1);
    }


    public final void O0() {
        J0();
        if (this.D0) {
            if (this.C0) {
                new y().execute();
                return;
            }
            new BaseActivity.b().execute(this.cardEditor);
        } else if (this.E0) {
            new y().execute();
        }
    }


    public final void Q0() {
        z0 = new ByteArrayOutputStream();
        Intent putExtra = new Intent(getApplicationContext(), SelectFestivalFrameActivity.class);
        startActivityForResult(putExtra, 7024);
    }


    public final void R0(final String s) {
        H0 = this;
        cardWt.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                cardWt.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                cardWt.getLayoutParams().height = FestivalDetailActivity_New.this.cardWt.getWidth();
                cardWt.requestLayout();
            }
        });
        cardBt.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                cardBt.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                cardBt.getLayoutParams().height = cardBt.getWidth();
                cardBt.requestLayout();
            }
        });
        cardWt.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                K0();
                int n = 0;
                int n2;
                while (true) {
                    final int size = FestivalDetailActivity_New.this.U0.size();
                    n2 = -16777216;
                    if (n >= size) {
                        break;
                    }
                    if (FestivalDetailActivity_New.this.U0.get(n) instanceof ImageView) {
                        final ImageView imageView = (ImageView) FestivalDetailActivity_New.this.U0.get(n);
                        if (!FestivalDetailActivity_New.this.V0) {
                            n2 = -1;
                        }
                        imageView.setColorFilter(n2);
                    } else if (FestivalDetailActivity_New.this.U0.get(n) instanceof BorderedTextView) {
                        final BorderedTextView borderedTextView = (BorderedTextView) FestivalDetailActivity_New.this.U0.get(n);
                        if (!FestivalDetailActivity_New.this.V0) {
                            n2 = -1;
                        }
                        borderedTextView.setBorderedColor(n2);
                    } else {
                        final TextView textView = (TextView) FestivalDetailActivity_New.this.U0.get(n);
                        if (!FestivalDetailActivity_New.this.V0) {
                            n2 = -1;
                        }
                        textView.setTextColor(n2);
                    }
                    ++n;
                }
                final FestivalDetailActivity_New n3 = FestivalDetailActivity_New.this;
                n3.V0 ^= true;
                final FestivalDetailActivity_New n4 = FestivalDetailActivity_New.this;
                final CardView cardWt = n4.cardWt;
                if (n4.V0) {
                    n2 = -1;
                }
                cardWt.setCardBackgroundColor(n2);
            }
        });
        this.cardBt.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                FestivalDetailActivity_New.this.K0();
                int n = 0;
                int n2;
                while (true) {
                    final int size = FestivalDetailActivity_New.this.T0.size();
                    n2 = -1;
                    if (n >= size) {
                        break;
                    }
                    if (FestivalDetailActivity_New.this.T0.get(n) instanceof ImageView) {
                        final ImageView imageView = (ImageView) FestivalDetailActivity_New.this.T0.get(n);
                        if (!FestivalDetailActivity_New.this.W0) {
                            n2 = -16777216;
                        }
                        imageView.setColorFilter(n2);
                    } else if (FestivalDetailActivity_New.this.T0.get(n) instanceof BorderedTextView) {
                        final BorderedTextView borderedTextView = (BorderedTextView) FestivalDetailActivity_New.this.T0.get(n);
                        if (!FestivalDetailActivity_New.this.W0) {
                            n2 = -16777216;
                        }
                        borderedTextView.setBorderedColor(n2);
                    } else {
                        final TextView textView = (TextView) FestivalDetailActivity_New.this.T0.get(n);
                        if (!FestivalDetailActivity_New.this.W0) {
                            n2 = -16777216;
                        }
                        textView.setTextColor(n2);
                    }
                    ++n;
                }
                final FestivalDetailActivity_New n3 = FestivalDetailActivity_New.this;
                n3.W0 = true;
                final FestivalDetailActivity_New n4 = FestivalDetailActivity_New.this;
                final CardView cardBt = n4.cardBt;
                if (n4.W0) {
                    n2 = -16777216;
                }
                cardBt.setCardBackgroundColor(n2);
            }
        });
        this.N0 = new ArrayList<Integer>();
        final int length = s.length();
        final int n = 0;
        final int n2 = 0;
        int i = 0;
        if (length > 0) {
            final Bitmap p = Utils.p(this, Uri.fromFile(new File(s)));
            if (p != null) {
                p.compress(Bitmap.CompressFormat.PNG, 100, new ByteArrayOutputStream());
                final int[][] f = Utils.s(p);
                this.L0 = f;
                final int[] a = com.kotlinz.festivalstorymaker.Other.l.n.a.a.a.aa.a(f, 25);
                this.M0 = a;
                while (i < a.length) {
                    N0.add(a[i]);
                    ++i;
                }
            } else {
                String[] stringArray = getResources().getStringArray(com.kotlinz.festivalstorymaker.R.array.default_tone_colors);
                for (int length2 = stringArray.length, j = n; j < length2; ++j) {
                    N0.add(Color.parseColor(stringArray[j]));
                }
            }
        } else {
            final String[] stringArray2 = getResources().getStringArray(com.kotlinz.festivalstorymaker.R.array.default_tone_colors);
            for (int length3 = stringArray2.length, k = n2; k < length3; ++k) {
                N0.add(Color.parseColor(stringArray2[k]));
            }
        }
        N0.add(-1);
        N0.add(-16777216);
        N0.add(null);
        rvPrimaryColor.getViewTreeObserver().addOnGlobalLayoutListener(new v());
        rvSecondaryColor.getViewTreeObserver().addOnGlobalLayoutListener(new w());

    }

    public final void S0() {
        ArrayList arrayList = new ArrayList();
        B0 = arrayList;
        String str = "";
        arrayList.add(str);
        B0.add(str);
        B0.addAll(Utils.u(this));
        FestivalFrameListAdapter festivalFrameListAdapter = new FestivalFrameListAdapter(this, B0, new a(), -1);
        t0 = festivalFrameListAdapter;
        listFrames.setAdapter(festivalFrameListAdapter);
        listFrames.setHasFixedSize(true);
    }


    public void T(int i, String str) {

    }

    public final void T0(boolean z) {
        View findViewById = findViewById(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500, com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog, findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        findViewById.setVisibility(z ? View.VISIBLE : View.GONE);
    }

    public final void U0(boolean z) {
        if (z) {
            H0(this.imgFont);
            com.kotlinz.festivalstorymaker.Models.festival.f0.c cVar = this.h1.get(((Integer) this.a1.getTag()).intValue());
            this.f1 = cVar.d;
            this.g1 = cVar.f;
            this.seekBarFontSpacing.setProgress(cVar.a);
            this.seekBarFontHeight.setProgress(cVar.b);
            this.e1.k(this.f1);
            this.d1.k(this.g1);
            E0(cVar.c);
            F0(cVar.e);
        }
        View findViewById = findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500, com.kotlinz.festivalstorymaker.R.id.llTextEditor, findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        findViewById.setVisibility(z ? View.VISIBLE : View.GONE);
    }


    public void X(float f) {
        this.R = null;
        this.rlFull.setVisibility(View.GONE);
    }

    public void V(int i) {

    }

    public void Y(int i, int i2) {
        K0();
        G0(i2);
    }

    public void j(boolean z, boolean z2, int i, int i2) {
        K0();
        this.P0 = false;
        this.Q0 = false;
        this.X0 = false;
        if (z) {
            if (z2) {
                this.P0 = true;
            } else {
                this.Q0 = true;
            }
            T0(true);
            ((RecyclerView) findViewById(com.kotlinz.festivalstorymaker.R.id.rlColor)).setAdapter(new ColorListAdapter(this, getResources().getStringArray(com.kotlinz.festivalstorymaker.R.array.colors_list)));
            findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setVisibility(View.GONE);
            findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setVisibility(View.INVISIBLE);
            findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableMove).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.h5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.i5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.txtCancel).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.j5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.txtDone).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.k5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.llColorPicker).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.l5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.llPickColor).setVisibility(View.GONE);
            findViewById(com.kotlinz.festivalstorymaker.R.id.llPickColor).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.m5(this));
            findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.n5(this));
        } else I0(z2, i2);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        int i3 = AppConstant.e0;
        if (724 == i) {
            if (Utils.b) {
                O0();
            }
        } else if (ImagePicker.shouldHandle(i, i2, intent)) {
            String str = ImagePicker.getFirstImageOrNull(intent).path;
            this.k0 = str;
            this.imgFestival.setImageBitmap(Utils.A(str));
        } else if (i2 == -1 && i == 69) {
            this.imgFestival.setImageURI(intent.getParcelableExtra("com.yalantis.ucrop.OutputUri"));
        } else {
            i2 = AppConstant.b0;
            String str2 = "path";
            if (i != 7924 || intent == null) {
                i2 = AppConstant.c0;
                if (i == 7024) {
                    S0();
                    if (intent != null && !intent.getStringExtra(str2).isEmpty()) {
                        imgFrame.setImageURI(Uri.parse(intent.getStringExtra(str2)));
                        imgFrame.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        return;
                    }
                    return;
                }
                return;
            }
            String stringExtra = intent.getStringExtra(str2);
            if (!stringExtra.isEmpty()) {
                i2 = 0;
                while (i2 < frame.getChildCount()) {
                    if (frame.getChildAt(i2).getTag() != null && (frame.getChildAt(i2) instanceof ImageStickerViewNew)) {
                        frame.removeViewAt(i2);
                    }
                    i2++;
                }
                File file = new File(stringExtra);
                if (file.exists()) {
                    try {
                        Bitmap decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                        ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, stringExtra, 110.0f, 110.0f, 1.0f, 0.0f, 2, true);
                        imageStickerViewNew.setGif(false);
                        imageStickerViewNew.j0 = true;
                        imageStickerViewNew.setWH(n0, m0);
                        imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                        imageStickerViewNew.setOperationListener(new com.kotlinz.festivalstorymaker.Listener.festival.o5(this, imageStickerViewNew));
                        imageStickerViewNew.setInEdit(false);
                        imageStickerViewNew.setSize(150.0f);
                        frame.addView(imageStickerViewNew);
                        frame.requestLayout();
                    } catch (OutOfMemoryError e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void onBackPressed() {
        if (findViewById(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog).isShown()) {
            T0(false);
        } else if (findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            U0(false);
        } else {
            finish();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @OnClick({com.kotlinz.festivalstorymaker.R.id.iv_back, com.kotlinz.festivalstorymaker.R.id.cardShare, com.kotlinz.festivalstorymaker.R.id.cardLogo, com.kotlinz.festivalstorymaker.R.id.cardFrame, com.kotlinz.festivalstorymaker.R.id.cardEmailNumber, com.kotlinz.festivalstorymaker.R.id.iv_download, com.kotlinz.festivalstorymaker.R.id.cardAddText})
    public void onClick(final View view) {
        this.K0();
        Label_0919:
        {
            Label_0912:
            {
                switch (view.getId()) {
                    default: {
                        return;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.iv_back: {
                        this.finish();
                        return;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.cardShare: {
                        for (int i = 0; i < this.mainFrame.getChildCount(); ++i) {
                            if (this.mainFrame.getChildAt(i) instanceof ImageStickerViewNew) {
                                ((ImageStickerViewNew) this.mainFrame.getChildAt(i)).setInEdit(false);
                            }
                        }
                        if (this.C0) {
                            this.D0 = true;
                            new y().execute(new Void[0]);
                            return;
                        }
                        new BaseActivity.b().execute(cardEditor);
                        break;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.cardLogo: {
                        Intent putExtra = new Intent(activity, SelectLogoActivity.class);
                        startActivityForResult(putExtra, 7924);
                        return;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.cardFrame: {
                        Q0();
                        return;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.cardEmailNumber: {
                        this.m1 = new Dialog(activity, com.kotlinz.festivalstorymaker.R.style.FullScreenDialog);
                        m1.requestWindowFeature(1);
                        this.m1.setContentView(com.kotlinz.festivalstorymaker.R.layout.custo_dialog);
                        this.m1.setCancelable(false);
                        final WindowManager.LayoutParams attributes = this.m1.getWindow().getAttributes();
                        this.m1.getWindow().setLayout(-1, -1);
                        this.m1.getWindow().setAttributes(attributes);
                        this.m1.show();
                        final EditText editText = this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.edtName);
                        final EditText editText2 = this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.edtMobileNumber);
                        final EditText editText3 = this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.edtEmail);
                        final EditText editText4 = this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.edtOccupation);
                        final EditText editText5 = this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.edtCity);
                        editText2.setText(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.j(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.j(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.j(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.j(FastSave.getInstance(), AppConstant.y2, "", editText4), AppConstant.z2, "", editText5), AppConstant.v2, "", editText), AppConstant.x2, "", editText3).getString(AppConstant.w2, ""));
                        this.imgBlur.setImageBitmap(Utils.S(this));
                        editText2.setOnEditorActionListener(new com.kotlinz.festivalstorymaker.Listener.festival.v5(this, editText2, editText, editText3, editText4, editText5));
                        this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtGo).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.w5(this, editText, editText2, editText3, editText4, editText5));
                        this.m1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtCancel).setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.x5(this));
                        this.m1.show();
                        this.imgBlur.setVisibility(View.VISIBLE);
                        return;
                    }
                    case com.kotlinz.festivalstorymaker.R.id.iv_download: {
                        if (rlMainFrameView.getChildCount() > 0) {
                            new z(rlMainFrameView).execute();
                            O0();
                            return;
                        }
                        O0();
                    }
                    case com.kotlinz.festivalstorymaker.R.id.cardAddText: {
                        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                        View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.add_text_dialog, null);
                        builder.setCancelable(false);
                        builder.setView(customLayout);
                        AlertDialog dialog = builder.create();
                        EditText etText = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_edit_text);
                        ImageView ivCancel = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_cancel_tv);
                        ImageView ivDone = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_done_tv);
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        ivDone.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                TextSticker sticker = new TextSticker(activity);
                                if (etText.getText().toString().matches("")) {
                                    Toast.makeText(activity, "Enter Text First", Toast.LENGTH_SHORT).show();
                                } else {
                                    sticker.setText(etText.getText().toString());
                                    sticker.setTextColor(Color.BLACK);
                                    sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
                                    sticker.resizeText();
                                    stickerView.addSticker(sticker);
                                    dialog.dismiss();
                                }
                            }
                        });
                        dialog.show();
                        imgFestival.setOnTouchListener(new View.OnTouchListener() {
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {
                                switch (event.getAction()) {
                                    case MotionEvent.ACTION_DOWN:
                                        stickerView.setLocked(!stickerView.isLocked());
                                        break;
                                }
                                return false;
                            }
                        });
                        stickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
                            @Override
                            public void onStickerAdded(@NonNull Sticker sticker) {

                            }

                            @Override
                            public void onStickerClicked(@NonNull Sticker sticker) {
                                if (sticker instanceof TextSticker) {
                                    ((TextSticker) sticker).setTextColor(Color.BLACK);
                                    stickerView.replace(sticker);
                                    stickerView.invalidate();
                                }
                            }

                            @Override
                            public void onStickerDeleted(@NonNull Sticker sticker) {

                            }

                            @Override
                            public void onStickerDragFinished(@NonNull Sticker sticker) {

                            }

                            @Override
                            public void onStickerTouchedDown(@NonNull Sticker sticker) {
                                scroll.requestDisallowInterceptTouchEvent(true);
                            }

                            @Override
                            public void onStickerZoomFinished(@NonNull Sticker sticker) {

                            }

                            @Override
                            public void onStickerFlipped(@NonNull Sticker sticker) {

                            }

                            @Override
                            public void onStickerDoubleTapped(@NonNull Sticker sticker) {

                            }
                        });
                        return;
                    }
                }
                return;
            }
        }
    }

    @OnClick
    public void onClicks(View view) {
        ImageView imageView;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.imgAlign:
                imageView = this.imgAlign;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter:
                E0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft:
                E0(-1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight:
                E0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap:
                F0(2);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgCaps:
                imageView = this.imgCaps;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgColor:
                imageView = this.imgColor;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap:
                F0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgFont:
                imageView = this.imgFont;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgLine:
                imageView = this.imgLine;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgSmall:
                F0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgSpace:
                imageView = this.imgSpace;
                break;
            default:
                return;
        }
        H0(imageView);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_festival_detail);
        ButterKnife.bind(this);
        this.C0 = getIntent().getBooleanExtra("isAnimatedVideo", false);
        this.i0 = (ArrayList) getIntent().getSerializableExtra("tutorialList");
        String str = "image";
        CatId = getIntent().getStringExtra("catid");
        this.k0 = getIntent().getStringExtra(str);
        this.l0 = getIntent().getStringExtra(str);
        bottomFrameList = new ArrayList<>();
        InitProgressDialog();
        FastSave.init(activity);
        this.j0 = new AppConstant();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        GetBusinessTemplate(PageNumber);
        GetFestivalCategoryDataByID(CatId);
        this.Z = new com.kotlinz.festivalstorymaker.Other.g.a(this, this);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        p0 = displayMetrics.heightPixels;
        o0 = displayMetrics.widthPixels;
        q0 = new com.kotlinz.festivalstorymaker.Listener.festival.e0f(this);
        int i = 8;
        R0(C0 ? "" : this.k0);
        J0();
        Utils.d();
        imgFont.setColorFilter(-16777216);
        llFonts.bringToFront();
        FontListAdapter fontListAdapter = new FontListAdapter(this, this.fontList, new com.kotlinz.festivalstorymaker.Listener.festival.w(this), this.g1);
        d1 = fontListAdapter;
        listFont.setAdapter(fontListAdapter);
        com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter colorListAdapter = new com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter(this, this.colorList, new com.kotlinz.festivalstorymaker.Listener.festival.n0(this), this.f1);
        listColor.setAdapter(colorListAdapter);
        seekBarFontSpacing.setOnSeekBarChangeListener(new com.kotlinz.festivalstorymaker.Listener.festival.p5(this));
        seekBarFontHeight.setOnSeekBarChangeListener(new com.kotlinz.festivalstorymaker.Listener.festival.q5(this));
        cardEditor.getViewTreeObserver().addOnPreDrawListener(new com.kotlinz.festivalstorymaker.Listener.festival.g5(this));
        S0();
        listBottomFrames.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (!recyclerView.canScrollHorizontally(1) && newState == 0) {
                    if (PageNumber < 4) {
                        PageNumber++;
                        GetBusinessTemplate(PageNumber);
                    }
                }
            }
        });
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }


    private void GetBusinessTemplate(int PageNo) {
        Call<JsonObject> call1 = apiInterface.getFestivalCategoryWiseDataNew(com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant.token, com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant.ApplicationId, com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant.FestivalBusinessTemplate, String.valueOf(PageNo));
        call1.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    int LastItemPosition = bottomFrameList.size();
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            final JSONObject jsonObject = jsonArray.getJSONObject(i);
                            CategoryWiseData categoryWiseData = new CategoryWiseData();
                            categoryWiseData.setThemeThumbnail(jsonObject.getString("theme_thumbnail"));
                            categoryWiseData.setFestivalName(jsonObject.getString("festival_name"));
                            categoryWiseData.setUpdatedAt(jsonObject.getString("updated_at"));
                            categoryWiseData.setIsPro(jsonObject.getString("is_pro"));
                            categoryWiseData.setThemeId(Integer.parseInt(jsonObject.getString("theme_id")));
                            categoryWiseData.setCreatedAt(jsonObject.getString("created_at"));
                            categoryWiseData.setModuleName(jsonObject.getString("module_name"));
                            categoryWiseData.setApplicationId(jsonObject.getString("application_id"));
                            categoryWiseData.setDatafile(jsonObject.getString("datafile"));
                            categoryWiseData.setVersion(jsonObject.getString("version"));
                            bottomFrameList.add(categoryWiseData);
                        }
                        businessTemplateAdapter = new BusinessTemplateAdapter(activity, bottomFrameList, new BusinessTemplateAdapter.a() {
                            @Override
                            public void a(int i, int i2) {
                                final CategoryWiseData categoryWiseData = bottomFrameList.get(i);
                                final TextStickerViewNew1 a0 = A0;
                                if (a0 != null) {
                                    mainFrame.removeView(a0);
                                }
                                final ImageView imgFrame = FestivalDetailActivity_New.this.imgFrame;
                                if (imgFrame != null) {
                                    imgFrame.setImageURI(null);
                                }
                                if (bottomFrameList.get(i).getDatafile() != null) {
                                    DataFileName = bottomFrameList.get(i).getDatafile().substring(bottomFrameList.get(i).getDatafile().lastIndexOf('/') + 1);
                                }

                                if (DataFileName.indexOf(".") > 0)
                                    DataFileName = DataFileName.substring(0, DataFileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
                                SplitName = DataFileName.split("Theme");
                                String SplitFileName = "Theme" + " " + SplitName[1];

                                Constant.TextFilePath = com.kotlinz.festivalstorymaker.AppUtils.Utils.INSTANCE.getBusinessTemplateFolderPath(activity) + categoryWiseData.getModuleName() + File.separator + SplitFileName + File.separator + SplitFileName + ".txt";
                                Constant.FolderPath = com.kotlinz.festivalstorymaker.AppUtils.Utils.INSTANCE.getBusinessTemplateFolderPath(activity) + categoryWiseData.getModuleName() + File.separator + SplitFileName;

                                String DataFilePath = bottomFrameList.get(i).getDatafile().replace("theme_thumb", "datafile");
                                if (new File(com.kotlinz.festivalstorymaker.AppUtils.Utils.INSTANCE.getBusinessTemplateFolderPath(activity) + categoryWiseData.getModuleName() + File.separator + SplitFileName + File.separator + SplitFileName + ".txt").exists()) {
                                    GetEditData();
                                } else {
                                    new BusinessTemplateDownload(FestivalDetailActivity_New.this, DataFilePath, DataFileName, categoryWiseData);
                                }
                            }
                        }, 0);
                        mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
                        listBottomFrames.setLayoutManager(mLayoutManager);
                        listBottomFrames.setAdapter(businessTemplateAdapter);
                        listBottomFrames.scrollToPosition(LastItemPosition);
                        progressDialog.dismiss();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }


    public void GetFestivalCategoryDataByID(String festivalId) {
        progressDialog.show();
        Call<CategoryWiseResponse> call = apiInterface.getFestivalCategoryWiseData(com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant.token, com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant.ApplicationId, festivalId, "1");
        call.enqueue(new Callback<CategoryWiseResponse>() {
            @Override
            public void onResponse(Call<CategoryWiseResponse> call, Response<CategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    CategoryWiseResponse festivalCategoryWiseResponse = gson.fromJson(new Gson().toJson(response.body()), CategoryWiseResponse.class);
                    festivalSubCategoryList = festivalCategoryWiseResponse.getData();
                    festivalSubCategoryAdapter = new FestivalCategoryRlatedAdapter(activity, festivalSubCategoryList, new m(), 0);
                    mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
                    listImages.setLayoutManager(mLayoutManager);
                    listImages.setAdapter(festivalSubCategoryAdapter);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<CategoryWiseResponse> call, Throwable t) {
                Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void GetEditData() {
        File fileEvents = new File(Constant.TextFilePath);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileEvents));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
            String Response = text.toString();
            Z.a.z(66, Response);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void onDestroy() {
        Utils bVar = this.l1;
        if (bVar != null) {
            bVar.u();
        }
        super.onDestroy();
        if (l0.length() > 0 && new File(l0).exists()) {
            new File(l0).delete();
        }
    }


    public Bitmap r0(View view) {
        int height = view.getHeight() * 2;
        int width = view.getWidth() * 2;
        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.UNSPECIFIED));
        Bitmap bitmap = null;
        try {
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.translate(0.0f, 0.0f);
            canvas.drawColor(-1, PorterDuff.Mode.CLEAR);
            canvas.scale(2.0f, 2.0f);
            view.draw(canvas);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return bitmap;
        }
    }

    public final void u0(FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new l(frameLayout, textStickerViewNew1);
    }


    @Override
    public void P(float f) {

    }

    @Override
    public void D(int p0) {

    }

    @Override
    public void B(Typeface typeface, int i) {

    }

}