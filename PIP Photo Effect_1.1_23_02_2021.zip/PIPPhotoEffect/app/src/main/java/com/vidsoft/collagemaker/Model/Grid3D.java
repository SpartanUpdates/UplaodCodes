package com.vidsoft.collagemaker.Model;

public class Grid3D {
    int image;
    int layout;
    int thumb;

    public Grid3D(int paramInt1, int paramInt2, int paramInt3) {
        this.thumb = paramInt1;
        this.layout = paramInt2;
        this.image = paramInt3;
    }

    public int getImage() {
        return this.image;
    }

    public int getLayout() {
        return this.layout;
    }

    public int getThumb() {
        return this.thumb;
    }

    public void setImage(int paramInt) {
        this.image = paramInt;
    }

    public void setLayout(int paramInt) {
        this.layout = paramInt;
    }

    public void setThumb(int paramInt) {
        this.thumb = paramInt;
    }
}