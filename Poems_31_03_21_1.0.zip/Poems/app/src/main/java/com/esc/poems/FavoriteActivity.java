package com.esc.poems;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FavoriteActivity extends AppCompatActivity {
    Activity activity = FavoriteActivity.this;
    protected static DataBaseHelper baseHelper;
    protected static ArrayList<String> cat;
    protected static Editor editor;
    protected static SharedPreferences sharedPreferences;
    private FavoriteRecyclerViewAdapter adapter;
    private Dialog dialogD;
    private ArrayList<String> f;
    private Typeface face;
    private Typeface face3;
    private ArrayList<String> mid;
    private ArrayList<String> msg;
    private RecyclerView recyclerview;
    private TextView textView;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_favorite);
        int i = 0;
        SharedPreferences sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        sharedPreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#ffffff'>Poems</font>"));
        baseHelper = new DataBaseHelper(getApplicationContext());
        this.face = Typeface.createFromAsset(getAssets(), "fonts/roboto_thin.ttf");
        this.face3 = Typeface.createFromAsset(getAssets(), "fonts/roboto_medium.ttf");
        this.textView = findViewById(R.id.favheading);
        this.recyclerview = findViewById(R.id.fav_listview);
        this.textView.setTypeface(this.face, Typeface.BOLD);
        this.msg = new ArrayList();
        this.mid = new ArrayList();
        this.f = new ArrayList();
        cat = new ArrayList();
        this.msg = baseHelper.getFavoriteMessages();
        this.mid = baseHelper.getFavoriteMessagesid();
        this.f = baseHelper.getFavorite();
        while (i < this.mid.size()) {
            cat.add(i, baseHelper.getFavSection(Integer.parseInt(this.mid.get(i))));
            i++;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("bfsadpt.........");
        stringBuilder.append(this.f.size());
        stringBuilder.append("....");
        stringBuilder.append(this.msg.size());
        Log.e("size", stringBuilder.toString());
        this.recyclerview.setLayoutManager(new LinearLayoutManager(this));
        FavoriteRecyclerViewAdapter favoriteRecyclerViewAdapter = new FavoriteRecyclerViewAdapter(this, this.msg, this.mid, this.f);
        this.adapter = favoriteRecyclerViewAdapter;
        this.recyclerview.setAdapter(favoriteRecyclerViewAdapter);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
