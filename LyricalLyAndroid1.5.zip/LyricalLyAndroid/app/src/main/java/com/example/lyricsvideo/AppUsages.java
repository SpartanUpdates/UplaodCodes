package com.example.lyricsvideo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alphamovie.lib.AlphaMovieView;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.activity.MainActivity;
import com.example.lyricsvideo.videolib.libffmpeg.FFmpeg;
import com.example.lyricsvideo.videolib.libffmpeg.FFmpegLoadBinaryResponseHandler;
import com.example.lyricsvideo.videolib.libffmpeg.exceptions.FFmpegNotSupportedException;
import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.unity3d.player.UnityPlayer;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


public class AppUsages {
    public static Context context;
    public static float prog;
    public static Dialog alertDialog;
    public static Dialog ProgressDialog;
    public static TextView tvprogress;
    public static boolean IsPreview = false;
    static String timeRe;
    static Float last;
    static Float videoLengthInSec;
    static String[] strCommand;
    static String MuteVideoPath;
    static String TransparentVideoPath;
    static String OutputVideoPath;
    static String OutputVideoName;
    private static boolean isPause;

    static {
        AppUsages.last = 0.0f;
        AppUsages.isPause = false;
        AppUsages.timeRe = "\\btime=\\b\\d\\d:\\d\\d:\\d\\d.\\d\\d";
    }


    static void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    private static boolean unpackZip(final String path, final String zipname) {
        try {
            final InputStream is = new FileInputStream(String.valueOf(path) + zipname);
            final ZipInputStream zis = new ZipInputStream(new BufferedInputStream(is));
            final byte[] buffer = new byte[1024];
            ZipEntry ze;
            while ((ze = zis.getNextEntry()) != null) {
                final String filename = ze.getName();
                if (ze.isDirectory()) {
                    final File fmd = new File(String.valueOf(path) + filename);
                    fmd.mkdirs();
                } else {
                    final FileOutputStream fout = new FileOutputStream(String.valueOf(path) + filename);
                    int count;
                    while ((count = zis.read(buffer)) != -1) {
                        fout.write(buffer, 0, count);
                    }
                    fout.close();
                    zis.closeEntry();
                }
            }
            zis.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static void LoadFromUnity(final Context cntx) {
        try {
            loadLib(cntx);
        } catch (FFmpegNotSupportedException e) {
            e.printStackTrace();
        }
    }

    public static void loadLib(final Context cntx) throws FFmpegNotSupportedException {
        final File f = new File(Utils.CommanPath);
        if (!f.exists()) {
            f.mkdirs();
        }
        final FFmpeg fFmpeg = FFmpeg.getInstance(cntx);
        fFmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
            @Override
            public void onStart() {
            }

            @Override
            public void onFinish() {
            }

            @Override
            public void onSuccess(final String cpuType) {
            }

            @Override
            public void onFailure(final String cpuType) {
            }

            @Override
            public void onSuccess() {
                try {
                    final String[] command_chk = {"/system/bin/ls", "-l", String.valueOf(AppUsages.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg"};
                    final String[] command_run = {"/system/bin/chmod", "744", String.valueOf(AppUsages.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg"};
                    AppUsages.checkPermission(command_chk);
                    AppUsages.checkPermission(command_run);
                    AppUsages.checkPermission(command_chk);
                    UnityPlayer.UnitySendMessage("XMLReader", "FFMpegStatus", "ok");

                } catch (IOException | InterruptedException ex2) {
                    ex2.printStackTrace();
                }
            }

            @Override
            public void onFailure() {
                UnityPlayer.UnitySendMessage("XMLReader", "FFMpegStatus", "error");
            }
        });
    }

    public static void checkPermission(final String[] arg_command) throws IOException, InterruptedException {
        final Process process = Runtime.getRuntime().exec(arg_command);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        final String output = "";
        String line;
        while ((line = reader.readLine()) != null) {
            output.concat(String.valueOf(line) + "\n");
        }
        reader.close();
        process.waitFor();
    }

    public static boolean isFullExtracted(final String FullFilePath) {
        boolean Extracted = false;
        final File mFile = new File(FullFilePath);
        final long armeabi_v7a_size = 18439556L;
        final long x86_size = 21898044L;
        Extracted = (mFile.length() >= armeabi_v7a_size);
        return Extracted;
    }

    static void getContx(final Context context) {
        AppUsages.context = context;
    }


    public static void loadFFMpeg(Context ctx) {
        context = ctx;
        final File ffmpegFile = new File(String.valueOf(AppUsages.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg");
        if (ffmpegFile.exists()) {
            LoadFromUnity(AppUsages.context);
        } else {
            new AppUsages.UnzipDownloadedFile().execute();
        }
    }

    static void close(final OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    static void close(final InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    static boolean copyBinaryFromAssetsToData(final Context context, final String fileNameFromAssets, final String outputFileName) {
        final File filesDirectory = new File(Utils.getHiddenFolderPath());
        try {
            final InputStream is = context.getAssets().open(fileNameFromAssets);
            final FileOutputStream os = new FileOutputStream(new File(filesDirectory, outputFileName));
            final byte[] buffer = new byte[4096];
            int n;
            while (-1 != (n = is.read(buffer))) {
                os.write(buffer, 0, n);
            }
            close(os);
            close(is);
            return true;
        } catch (IOException e) {
            return false;
        }
    }


    public static void PlayVideo(final Context context, boolean IsFrom) {
        alertDialog = new Dialog(context, R.style.Transparent);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.setContentView(R.layout.coustom_dialog_unity);
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
        Uri uri = Uri.parse(CallFromUnity.TransparantVideoPath);
        final AlphaMovieView alphaMovieView = alertDialog.findViewById(R.id.video_player);
        LinearLayout linearLayout = alertDialog.findViewById(R.id.ll_note);
        final Button btnCreateVideo = alertDialog.findViewById(R.id.btn_createVideo);
        final ImageView Ivback = alertDialog.findViewById(R.id.iv_player_back);
        alphaMovieView.setVideoFromUri(context, uri);
        alphaMovieView.start();
        alphaMovieView.setLooping(false);
        if (IsFrom) {
            linearLayout.setVisibility(View.VISIBLE);
            btnCreateVideo.setVisibility(View.GONE);
            Ivback.setVisibility(View.GONE);
        } else {
            linearLayout.setVisibility(View.GONE);
            btnCreateVideo.setVisibility(View.VISIBLE);
            Ivback.setVisibility(View.VISIBLE);
        }
        Ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityPlayer.UnitySendMessage("XMLReader", "CallToAndroid", "");
                AppUsages.IsPreview = false;
                alertDialog.dismiss();
            }
        });
        btnCreateVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityPlayer.UnitySendMessage("XMLReader", "ShowAnimation", CallFromUnity.UnityXmlPath);
                UnityPlayer.UnitySendMessage("XMLReader", "StartAgainAnimation", "");
                btnCreateVideo.setVisibility(View.GONE);
                Ivback.setVisibility(View.GONE);
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }

//    public static void ShowVideoProgress(Context context) {
//        alertDialog.dismiss();
//        ProgressDialog = new Dialog(context, R.style.Transparent);
//        ProgressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        ProgressDialog.setContentView(R.layout.activity_progress_video);
//        ProgressDialog.setCancelable(false);
//        ProgressDialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
//        tvprogress = ProgressDialog.findViewById(R.id.tv_progress);
//        ProgressDialog.show();
//    }

    public static void VideoMearge(final Context context, String VideoMuteName, String VideoFinalName) {
        AppUsages.context = context;
        alertDialog.dismiss();
        MuteVideoPath = Utils.INSTANCE.getLyricsVideoStory() + VideoMuteName;
        OutputVideoPath = Utils.INSTANCE.getLyricsVideoStory() + VideoFinalName;
        OutputVideoName = VideoFinalName;
        TransparentVideoPath = CallFromUnity.TransparantVideoPath;
//        ((Activity) AppUsages.context).runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                ShowVideoProgress(context);
//            }
//        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                new ProcessVideoOverlapping().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        }, 2000L);
    }

    public static void execFFmpegBinary(final String[] array) {
        try {
            MainActivity.ffmpeg.execute(array, new ExecuteBinaryResponseHandler() {
                @Override
                public void onFailure(final String s) {

                }

                @Override
                public void onFinish() {
                }

                @Override
                public void onProgress(final String s) {
                    final int durationVideo = Videoduration(TransparentVideoPath);
                    final Float seconds = durationVideo / 1000.0f;
                    AppUsages.videoLengthInSec = seconds;
                    prog = durationToprogtess(s);
                    ((Activity) AppUsages.context).runOnUiThread(new Runnable() {
                        @SuppressLint("SetTextI18n")
                        public void run() {
                            if (prog >= 100) {
                                UnityPlayer.UnitySendMessage("StackManager", "VideoProgressMix", String.valueOf(prog));
                            } else {
                                UnityPlayer.UnitySendMessage("StackManager", "VideoProgressMix", String.valueOf(prog));
                            }
                        }
                    });
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onSuccess(String string) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(Environment.getExternalStorageDirectory().getPath());
                    sb.append("/");
                    sb.append(AppUsages.context.getResources().getString(R.string.app_name));
                    string = sb.toString();
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(string);
                    sb2.append("/temp");
                    removeFrameImage(sb2.toString());
                    if (isPause) {
                        return;
                    }
                    if (new File(MuteVideoPath).exists()) {
                        new File(MuteVideoPath).delete();
                    }
//                    ProgressDialog.dismiss();
                    UnityPlayer.UnitySendMessage("StackManager", "VideoComepleted", "ok");
                }
            });
        } catch (com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException ex) {
            Log.e("TAG", "FFmpegCommandAlreadyRunningException" + ex.getMessage());
        }
    }

    private static Float durationToprogtess(final String input) {
        Float progress = 0.0f;
        final Matcher matcher = Pattern.compile(AppUsages.timeRe).matcher(input);
        final int SECOND = 1;
        final int MINUTE = SECOND * 60;
        final int HOUR = MINUTE * 60;
        if (TextUtils.isEmpty((CharSequence) input) || !input.contains("time=")) {
            return AppUsages.last;
        }
        while (matcher.find()) {
            String time = matcher.group();
            time = time.substring(time.lastIndexOf(61) + 1);
            final String[] splitTime = time.split(":");
            final float hour = Float.valueOf(splitTime[0]) * HOUR + Float.valueOf(splitTime[1]) * MINUTE + Float.valueOf(splitTime[2]);
            progress = (float) (int) (hour * 100.0f / AppUsages.videoLengthInSec);
        }
        return AppUsages.last = progress;
    }

    private static int Videoduration(final String file) {
        MediaPlayer mp = MediaPlayer.create(AppUsages.context, Uri.parse(file));
        final int duration = mp.getDuration();
        mp.release();
        return duration;
    }

    public static void removeFrameImage(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    final File file2 = listFiles[i];
                    if (file2.getName().endsWith(".jpg") || file2.getName().endsWith(".png")) {
                        file2.delete();
                    }
                }
            }
        }
    }

    static class UnzipDownloadedFile extends AsyncTask<Void, Void, Void> {
        String LocalmArcName;
        File LocalFullFile;

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected Void doInBackground(final Void... arg0) {
            this.LocalmArcName = "armeabi-v7a";
            this.LocalFullFile = new File(String.valueOf(Utils.getFileDownloadName(this.LocalmArcName)) + File.separator + "ffmpeg");
            copyBinaryFromAssetsToData(context, String.valueOf("armeabi-v7a") + ".zip", String.valueOf("armeabi-v7a") + ".zip");
            unpackZip(String.valueOf(Utils.getHiddenFolderPath()) + File.separator, "armeabi-v7a.zip");
            return null;
        }

        protected void onPostExecute(final Void result) {
            if (!AppUsages.isFullExtracted(this.LocalFullFile.getAbsolutePath())) {
                AppUsages.deleteRecursive(this.LocalFullFile);
                new UnzipDownloadedFile().execute();
            } else {
                AppUsages.LoadFromUnity(AppUsages.context);
            }
            super.onPostExecute(result);
        }
    }

    public static class ProcessVideoOverlapping extends AsyncTask<Integer, Integer, List<String>> {
        protected List<String> doInBackground(final Integer... array) {
            strCommand = new String[]{
                    "-i",
                    String.valueOf(Uri.parse(MuteVideoPath)),
                    "-i",
                    String.valueOf(Uri.parse(TransparentVideoPath)),
                    "-filter_complex",
                    "[1:v]colorkey=0x000000:0.5:0.5[colorOverlay];[0:v][colorOverlay]overlay[v_out]",
                    "-map",
                    "[v_out]",
                    "-map",
                    "1:a",
                    "-strict",
                    "-2",
                    "-preset",
                    "veryfast",
                    "-g",
                    "120",
                    OutputVideoPath};
            execFFmpegBinary(strCommand);
            return null;
        }

        protected void onPostExecute(final List<String> list) {

        }

        protected void onPreExecute() {
        }
    }

}
