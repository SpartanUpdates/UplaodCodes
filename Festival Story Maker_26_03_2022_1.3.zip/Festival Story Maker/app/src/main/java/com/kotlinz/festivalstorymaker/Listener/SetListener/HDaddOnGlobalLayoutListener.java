package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;

public class HDaddOnGlobalLayoutListener implements OnGlobalLayoutListener {
    public final HighlightDetailsDetailActivity activity;

    public HDaddOnGlobalLayoutListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
        this.activity = highlightDetailsDetailActivity;
    }

    public void onGlobalLayout() {
        if (activity.flFramelayout.getViewTreeObserver().isAlive()) {
            activity.flFramelayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }
        activity.a0 = activity.flFramelayout.getWidth();
        for (int i = 0; i < activity.Y.size(); i++) {
            activity.u0(i);
        }
    }
}
