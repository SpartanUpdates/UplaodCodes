package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewManager;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class TaroCardsQuestionActivity extends AppCompatActivity {
    Activity activity = TaroCardsQuestionActivity.this;
    static final String[] cardnames = new String[]{"ACE OF CUPS", "TWO OF CUPS", "THREE OF CUPS", "FOUR OF CUPS", "FIVE OF CUPS", "SIX OF CUPS", "SEVEN OF CUPS", "EIGHT OF CUPS", "NINE OF CUPS", "TEN OF CUPS", "PAGE OF CUPS", "KNIGHT OF CUPS", "QUEEN OF CUPS", "KING OF CUPS", "ACE OF WANDS", "TWO OF WANDS", "THREE OF WANDS", "FOUR OF WANDS", "FIVE OF WANDS", "SIX OF WANDS", "SEVEN OF WANDS", "EIGHT OF WANDS", "NINE OF WANDS", "TEN OF WANDS", "PAGE OF WANDS", "KNIGHT OF WANDS", "QUEEN OF WANDS", "KING OF WANDS", "ACE OF SWORDS", "TWO OF SWORDS", "THREE OF SWORDS", "FOUR OF SWORDS", "FIVE OF SWORDS", "SIX OF SWORDS", "SEVEN OF SWORDS", "EIGHT OF SWORDS", "NINE OF SWORDS", "TEN OF SWORDS", "PAGE OF SWORDS", "KNIGHT OF SWORDS", "QUEEN OF SWORDS", "KING OF SWORDS", "ACE OF PENTACLES", "TWO OF PENTACLES", "THREE OF PENTACLES", "FOUR OF PENTACLES", "FIVE OF PENTACLES", "SIX OF PENTACLES", "SEVEN OF PENTACLES", "EIGHT OF PENTACLES", "NINE OF PENTACLES", "TEN OF PENTACLES", "PAGE OF PENTACLES", "KNIGHT OF PENTACLES", "QUEEN OF PENTACLES", "KING OF PENTACLES", "DEATH", "JUDGEMENT", "JUSTICE", "STRENGTH", "TEMPERANCE", "THE CHARIOT", "THE DEVIL", "THE EMPEROR", "THE EMPRESS", "THE FOOL", "THE HANGED MAN", "THE HERMIT", "THE HIEROPHANT", "THE HIGH PRIESTESS", "THE LOVERS", "THE MAGICIAN", "THE MOON", "THE STAR", "THE SUN", "THE TOWER", "THE WORLD", "WHEEL OF FORTUNE"};
    static final String[] cardnames2 = new String[78];
    static Typeface face;
    static ImageView[] img;
    static ImageView[] img1;
    static ImageView[] img2;
    static ImageView[] shuufelimg;
    static ImageView[] shuufelimg1;
    static ImageView[] shuufelimg2;
    static ImageView tempimg;
    static ImageView[] tempimg3;
    static ImageView[] tempimg4;
    static ImageView[] tempimg5;
    static ImageView[] tempimgs;
    static ImageView[] tempimgs1;
    public static Boolean viewedNotification = Boolean.valueOf(false);
    AnimationListener animlist;
    int cardcount = 0;
    final int[] cardint;
    String cc;
    String cc2;
    String[] cname = new String[3];
    String[] cname2;
    String[] cname4 = new String[4];
    String[] cname5 = new String[5];
    int globflag;
    String head;
    int id1 = 26;
    int id2 = 52;
    OnClickListener imgclick;
    int index;
    MarginLayoutParams[] l;
    MarginLayoutParams[] l1;
    MarginLayoutParams[] l2;
    String locale;
    LayoutParams lp;
    RelativeLayout main;
    int offst;
    ImageView[] row1;
    ImageView[] row2;
    ImageView[] row3;
    CountDownTimer time;
    CountDownTimer time1;
    CountDownTimer time2;
    CountDownTimer timemain;
    int timerflag = 0;
    CountDownTimer timetemp;
    TextView titleview;
    TranslateAnimation[] translateAnimation;
    TranslateAnimation[] translateAnimation1;
    TranslateAnimation[] translateAnimation2;
    String type;
    ViewManager vg;
    ViewManager vg1;
    ViewManager vg2;
    int x = 0;
    int xmargin = 10;
    int xofst;
    int xofst1;
    int xofst2;
    int[][] xypos1;
    int y = 0;
    int ymargin = 5;
    int yofst;
    int yofst1;
    int yofst2;
    int z = 0;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public TaroCardsQuestionActivity() {
        String str = "";
        this.locale = str;
        this.cardint = new int[]{R.string.aceofcups, R.string.twoofcups, R.string.threeofcups, R.string.fourofcups, R.string.fiveofcups, R.string.sixofcups, R.string.sevenofcups, R.string.eightofcups, R.string.nineofcups, R.string.tenofcups, R.string.pageofcups, R.string.knightofcups, R.string.queenofcups, R.string.kingofcups, R.string.aceofwands, R.string.twoofwands, R.string.threeofwands, R.string.fourofwands, R.string.fiveofwands, R.string.sixofwands, R.string.sevenofwands, R.string.eightofwands, R.string.nineofwands, R.string.tenofwands, R.string.pageofwands, R.string.knightofwands, R.string.queenofwands, R.string.kingofwands, R.string.aceofswords, R.string.twoofswords, R.string.threeofswords, R.string.fourofswords, R.string.fiveofswords, R.string.sixofswords, R.string.sevenofswords, R.string.eightofswords, R.string.nineofswords, R.string.tenofswords, R.string.pageofswords, R.string.knightofswords, R.string.queenofswords, R.string.kingofswords, R.string.aceofpentacles, R.string.twoofpentacles, R.string.threeofpentacles, R.string.fourofpentacles, R.string.fiveofpentacles, R.string.sixofpentacles, R.string.sevenofpentacles, R.string.eightofpentacles, R.string.nineofpentacles, R.string.tenofpentacles, R.string.pageofpentacles, R.string.knightofpentacles, R.string.queenofpentacles, R.string.kingofpentacles, R.string.death, R.string.judgement, R.string.justice, R.string.strength, R.string.temperance, R.string.thechariot, R.string.thedevil, R.string.theemperor, R.string.theempress, R.string.thefool, R.string.thehangedman, R.string.thehermit, R.string.thehierophant, R.string.thehighpriestress, R.string.thelovers, R.string.themagician, R.string.themoon, R.string.thestar, R.string.thesun, R.string.thetower, R.string.theworld, R.string.wheeloffortune};
        this.globflag = 1;
        this.offst = 1;
        this.xofst = 10;
        this.yofst = 10;
        this.xofst1 = 100;
        this.yofst1 = 10;
        this.xofst2 = Callback.DEFAULT_DRAG_ANIMATION_DURATION;
        this.yofst2 = 10;
        this.type = "one";
        this.head = "Daily Tarot Horoscope";
        this.cc = str;
        this.cc2 = str;
        this.cname2 = new String[5];
        this.imgclick = new OnClickListener() {
            public void onClick(View view) {
                String[] strArr = new String[]{"ACE OF CUPS", "TWO OF CUPS", "THREE OF CUPS", "FOUR OF CUPS", "FIVE OF CUPS", "SIX OF CUPS", "SEVEN OF CUPS", "EIGHT OF CUPS", "NINE OF CUPS", "TEN OF CUPS", "PAGE OF CUPS", "KNIGHT OF CUPS", "QUEEN OF CUPS", "KING OF CUPS", "ACE OF WANDS", "TWO OF WANDS", "THREE OF WANDS", "FOUR OF WANDS", "FIVE OF WANDS", "SIX OF WANDS", "SEVEN OF WANDS", "EIGHT OF WANDS", "NINE OF WANDS", "TEN OF WANDS", "PAGE OF WANDS", "KNIGHT OF WANDS", "QUEEN OF WANDS", "KING OF WANDS", "ACE OF SWORDS", "TWO OF SWORDS", "THREE OF SWORDS", "FOUR OF SWORDS", "FIVE OF SWORDS", "SIX OF SWORDS", "SEVEN OF SWORDS", "EIGHT OF SWORDS", "NINE OF SWORDS", "TEN OF SWORDS", "PAGE OF SWORDS", "KNIGHT OF SWORDS", "QUEEN OF SWORDS", "KING OF SWORDS", "ACE OF PENTACLES", "TWO OF PENTACLES", "THREE OF PENTACLES", "FOUR OF PENTACLES", "FIVE OF PENTACLES", "SIX OF PENTACLES", "SEVEN OF PENTACLES", "EIGHT OF PENTACLES", "NINE OF PENTACLES", "TEN OF PENTACLES", "PAGE OF PENTACLES", "KNIGHT OF PENTACLES", "QUEEN OF PENTACLES", "KING OF PENTACLES", "DEATH", "JUDGEMENT", "JUSTICE", "STRENGTH", "TEMPERANCE", "THE CHARIOT", "THE DEVIL", "THE EMPEROR", "THE EMPRESS", "THE FOOL", "THE HANGED MAN", "THE HERMIT", "THE HIEROPHANT", "THE HIGH PRIESTESS", "THE LOVERS", "THE MAGICIAN", "THE MOON", "THE STAR", "THE SUN", "THE TOWER", "THE WORLD", "WHEEL OF FORTUNE"};
                boolean equals = TaroCardsQuestionActivity.this.type.equals("one");
                String str = "ccc2";
                String str2 = "ccc";
                String str3 = "ques";
                String str4 = "name2";
                String str5 = "name";
                String str6 = " || subtype = ";
                String str7 = " || type = ";
                String str8 = " || ccc2 = ";
                String str9 = " || ccc = ";
                String str10 = " || ques = ";
                String str11 = " || name2 = ";
                String str12 = "subtype";
                String str13 = "TaroCardsQuestion";
                String str14 = "type";
                String str15 = "";
                String str16;
                String str17;
                String str18;
                if (equals) {
                    str16 = str15;
                    Log.e("ONE", "ONE CLICK");
                    TaroCardsQuestionActivity.tempimg = (ImageView) view;
                    str17 = (String) TaroCardsQuestionActivity.tempimg.getTag();
                    str18 = str;
                    String str19 = str2;
                    str = str16;
                    for (int i = 0; i < 78; i++) {
                        if (str17.equals(strArr[i])) {
                            str = TaroCardsQuestionActivity.cardnames2[i];
                        }
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("trac IF TYPE = ONE => name = ");
                    stringBuilder.append(str17);
                    stringBuilder.append(str11);
                    stringBuilder.append(str);
                    stringBuilder.append(str10);
                    stringBuilder.append(TaroCardsQuestionActivity.this.head);
                    stringBuilder.append(str9);
                    stringBuilder.append(TaroCardsQuestionActivity.this.cc);
                    stringBuilder.append(str8);
                    stringBuilder.append(TaroCardsQuestionActivity.this.cc2);
                    stringBuilder.append(str7);
                    stringBuilder.append(TaroCardsQuestionActivity.this.type);
                    stringBuilder.append(str6);
                    Log.e(str13, stringBuilder.toString());
                    TaroCardsQuestionActivity.tempimg.setVisibility(View.GONE);
                    Intent intent = new Intent(TaroCardsQuestionActivity.this, TaroResultActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(str5, str17);
                    bundle.putString(str4, str);
                    bundle.putString(str3, TaroCardsQuestionActivity.this.head);
                    bundle.putString(str19, TaroCardsQuestionActivity.this.cc);
                    bundle.putString(str18, TaroCardsQuestionActivity.this.cc2);
                    bundle.putString(str14, TaroCardsQuestionActivity.this.type);
                    bundle.putString(str12, str16);
                    intent.putExtras(bundle);
                    TaroCardsQuestionActivity.this.startActivityForResult(intent, 0);
                    Log.e("TAG", "TaroResult..");
                    TaroCardsQuestionActivity.this.finish();
                    return;
                }
                String str20 = str13;
                str13 = str15;
                str15 = str2;
                str17 = str12;
                str2 = str14;
                str14 = str6;
                str16 = str7;
                String[] strArr2;
                Intent intent2;
                StringBuilder stringBuilder2;
                TaroCardsQuestionActivity taroCardsQuestionActivity;
                if (TaroCardsQuestionActivity.this.type.equals("three")) {
                    TaroCardsQuestionActivity.tempimg3[TaroCardsQuestionActivity.this.cardcount] = (ImageView) view;
                    str18 = str8;
                    TaroCardsQuestionActivity.this.cname[TaroCardsQuestionActivity.this.cardcount] = (String) TaroCardsQuestionActivity.tempimg3[TaroCardsQuestionActivity.this.cardcount].getTag();
                    TaroCardsQuestionActivity.tempimg3[TaroCardsQuestionActivity.this.cardcount].setVisibility(View.GONE);
                    int i2 = 0;
                    while (i2 < 78) {
                        strArr2 = strArr;
                        if (strArr[i2].equals(TaroCardsQuestionActivity.this.cname[TaroCardsQuestionActivity.this.cardcount])) {
                            TaroCardsQuestionActivity.this.cname2[TaroCardsQuestionActivity.this.cardcount] = TaroCardsQuestionActivity.cardnames2[i2];
                        }
                        i2++;
                        strArr = strArr2;
                    }
                    if (TaroCardsQuestionActivity.this.cardcount == 2) {
                        intent2 = new Intent(TaroCardsQuestionActivity.this, TaroResultActivity.class);
                        Bundle bundle2 = new Bundle();
                        bundle2.putStringArray(str5, TaroCardsQuestionActivity.this.cname);
                        bundle2.putStringArray(str4, TaroCardsQuestionActivity.this.cname2);
                        bundle2.putString(str3, TaroCardsQuestionActivity.this.head);
                        bundle2.putString(str15, TaroCardsQuestionActivity.this.cc);
                        bundle2.putString(str, TaroCardsQuestionActivity.this.cc2);
                        bundle2.putString(str2, TaroCardsQuestionActivity.this.type);
                        bundle2.putString(str17, str13);
                        intent2.putExtras(bundle2);
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("trac IF TYPE = THREE => name = ");
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cname);
                        stringBuilder2.append(str11);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cname2);
                        stringBuilder2.append(str10);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.head);
                        stringBuilder2.append(str9);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cc);
                        stringBuilder2.append(str18);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cc2);
                        stringBuilder2.append(str16);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.type);
                        stringBuilder2.append(str14);
                        Log.e(str20, stringBuilder2.toString());
                        TaroCardsQuestionActivity.this.startActivity(intent2);
                        TaroCardsQuestionActivity.this.finish();
                        return;
                    }
                    taroCardsQuestionActivity = TaroCardsQuestionActivity.this;
                    taroCardsQuestionActivity.cardcount++;
                    return;
                }
                strArr2 = strArr;
                str7 = str8;
                str6 = str14;
                str8 = str16;
                int i3;
                Bundle bundle3;
                if (TaroCardsQuestionActivity.this.type.equals("four")) {
                    TaroCardsQuestionActivity.tempimg4[TaroCardsQuestionActivity.this.cardcount] = (ImageView) view;
                    str16 = str8;
                    TaroCardsQuestionActivity.this.cname4[TaroCardsQuestionActivity.this.cardcount] = (String) TaroCardsQuestionActivity.tempimg4[TaroCardsQuestionActivity.this.cardcount].getTag();
                    TaroCardsQuestionActivity.tempimg4[TaroCardsQuestionActivity.this.cardcount].setVisibility(View.GONE);
                    for (i3 = 0; i3 < 78; i3++) {
                        if (TaroCardsQuestionActivity.this.cname4[TaroCardsQuestionActivity.this.cardcount].equals(strArr2[i3])) {
                            TaroCardsQuestionActivity.this.cname2[TaroCardsQuestionActivity.this.cardcount] = TaroCardsQuestionActivity.cardnames2[i3];
                        }
                    }
                    if (TaroCardsQuestionActivity.this.cardcount == 3) {
                        intent2 = new Intent(TaroCardsQuestionActivity.this, TaroResultActivity.class);
                        bundle3 = new Bundle();
                        bundle3.putStringArray(str5, TaroCardsQuestionActivity.this.cname4);
                        bundle3.putStringArray(str4, TaroCardsQuestionActivity.this.cname2);
                        bundle3.putString(str3, TaroCardsQuestionActivity.this.head);
                        bundle3.putString(str15, TaroCardsQuestionActivity.this.cc);
                        bundle3.putString(str, TaroCardsQuestionActivity.this.cc2);
                        bundle3.putString(str2, TaroCardsQuestionActivity.this.type);
                        bundle3.putString(str17, str13);
                        intent2.putExtras(bundle3);
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("trac IF TYPE = FOUR(3) => name = ");
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cname4);
                        stringBuilder2.append(str11);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cname2);
                        stringBuilder2.append(str10);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.head);
                        stringBuilder2.append(str9);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cc);
                        stringBuilder2.append(str7);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.cc2);
                        stringBuilder2.append(str16);
                        stringBuilder2.append(TaroCardsQuestionActivity.this.type);
                        stringBuilder2.append(str14);
                        Log.e(str20, stringBuilder2.toString());
                        TaroCardsQuestionActivity.this.startActivity(intent2);
                        TaroCardsQuestionActivity.this.finish();
                        return;
                    }
                    taroCardsQuestionActivity = TaroCardsQuestionActivity.this;
                    taroCardsQuestionActivity.cardcount++;
                    return;
                }
                String str21 = str20;
                str6 = str14;
                TaroCardsQuestionActivity.tempimg5[TaroCardsQuestionActivity.this.cardcount] = (ImageView) view;
                str16 = str8;
                TaroCardsQuestionActivity.this.cname5[TaroCardsQuestionActivity.this.cardcount] = (String) TaroCardsQuestionActivity.tempimg5[TaroCardsQuestionActivity.this.cardcount].getTag();
                TaroCardsQuestionActivity.tempimg5[TaroCardsQuestionActivity.this.cardcount].setVisibility(View.GONE);
                for (i3 = 0; i3 < 78; i3++) {
                    if (TaroCardsQuestionActivity.this.cname5[TaroCardsQuestionActivity.this.cardcount].equals(strArr2[i3])) {
                        TaroCardsQuestionActivity.this.cname2[TaroCardsQuestionActivity.this.cardcount] = TaroCardsQuestionActivity.cardnames2[i3];
                    }
                }
                if (TaroCardsQuestionActivity.this.cardcount == 4) {
                    intent2 = new Intent(TaroCardsQuestionActivity.this, TaroResultActivity.class);
                    bundle3 = new Bundle();
                    bundle3.putStringArray(str5, TaroCardsQuestionActivity.this.cname5);
                    bundle3.putStringArray(str4, TaroCardsQuestionActivity.this.cname2);
                    bundle3.putString(str3, TaroCardsQuestionActivity.this.head);
                    bundle3.putString(str15, TaroCardsQuestionActivity.this.cc);
                    bundle3.putString(str, TaroCardsQuestionActivity.this.cc2);
                    bundle3.putString(str2, TaroCardsQuestionActivity.this.type);
                    bundle3.putString(str17, str13);
                    intent2.putExtras(bundle3);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("trac IF TYPE = FOUR(4) => name = ");
                    stringBuilder2.append(TaroCardsQuestionActivity.this.cname5);
                    stringBuilder2.append(str11);
                    stringBuilder2.append(TaroCardsQuestionActivity.this.cname2);
                    stringBuilder2.append(str10);
                    stringBuilder2.append(TaroCardsQuestionActivity.this.head);
                    stringBuilder2.append(str9);
                    stringBuilder2.append(TaroCardsQuestionActivity.this.cc);
                    stringBuilder2.append(str7);
                    stringBuilder2.append(TaroCardsQuestionActivity.this.cc2);
                    stringBuilder2.append(str16);
                    stringBuilder2.append(TaroCardsQuestionActivity.this.type);
                    stringBuilder2.append(str14);
                    Log.e(str20, stringBuilder2.toString());
                    startActivity(intent2);
                    finish();
                    return;
                }
                taroCardsQuestionActivity = TaroCardsQuestionActivity.this;
                taroCardsQuestionActivity.cardcount++;
            }
        };
    }

    public void onCreate(Bundle bundle) {
        int i;
        TextView textView;
        StringBuilder stringBuilder;
        int i2;
        int i3;
        super.onCreate(bundle);
        setContentView(R.layout.main);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("cardquestion");
        stringBuilder2.append(AlarmReceiver.isAlarmNotified);
        Log.e("isalarmnotified", stringBuilder2.toString());
        String language = getResources().getConfiguration().locale.getLanguage();
        this.locale = language;
        if (language.contains("hi")) {
            face = Typeface.createFromAsset(getAssets(), "fonts/MANGAL.TTF");
        } else {
            face = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        }
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
        int i4 = 0;
        for (i = 0; i < 78; i++) {
            cardnames2[i] = getResources().getString(this.cardint[i]);
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        Bundle extras = getIntent().getExtras();
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, null);
        TextView textView2 = inflate.findViewById(R.id.title);
        this.titleview = textView2;
        textView2.setTypeface(face);
        getSupportActionBar().setCustomView(inflate);
        String str = this.locale;
        String str2 = "vi";
        if (!(str == null || str.contains(str2))) {
            this.titleview.setTypeface(face);
        }
        this.titleview.setTextColor(getResources().getColor(R.color.white));
        String str3 = "";
        if (AlarmReceiver.isAlarmNotified) {
            viewedNotification = Boolean.valueOf(true);
            if (this.locale.contains("ja") || this.locale.contains("th") || this.locale.contains("da") || this.locale.contains("pl") || this.locale.contains("ko") || this.locale.contains("zh") || this.locale.contains("tr") || this.locale.contains("es") || this.locale.contains("fr") || this.locale.contains("hi") || this.locale.contains("nb") || this.locale.contains("sv") || this.locale.contains("de") || this.locale.contains("it") || this.locale.contains("ms") || this.locale.contains("ru") || this.locale.contains("nl") || this.locale.contains("fi") || this.locale.contains("el") || this.locale.contains("in") || this.locale.contains(str2) || this.locale.contains("tl")) {
                this.head = extras.getString("head");
                this.type = extras.getString("type");
                this.cc = extras.getString("ccc");
                this.cc2 = extras.getString("ccc2");
                textView = this.titleview;
                stringBuilder = new StringBuilder();
                stringBuilder.append(str3);
                stringBuilder.append(this.head);
                textView.setText(stringBuilder.toString());
                AlarmReceiver.isAlarmNotified = false;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("head = ");
                stringBuilder2.append(this.head);
                stringBuilder2.append("  type = ");
                stringBuilder2.append(this.type);
                stringBuilder2.append("  cc = ");
                stringBuilder2.append(this.cc);
                stringBuilder2.append("   cc2 = ");
                stringBuilder2.append(this.cc2);
                Log.e("track", stringBuilder2.toString());
            } else {
                this.head = getResources().getString(R.string.dailytaro);
                this.cc = "Daily Tarot Horoscope";
                this.type = "one";
                AlarmReceiver.isAlarmNotified = false;
                textView = this.titleview;
                stringBuilder = new StringBuilder();
                stringBuilder.append(str3);
                stringBuilder.append(this.head);
                textView.setText(stringBuilder.toString());
            }
        } else {
            try {
                this.head = extras.getString("head");
                this.type = extras.getString("type");
                this.cc = extras.getString("ccc");
                this.cc2 = extras.getString("ccc2");
                textView = this.titleview;
                stringBuilder = new StringBuilder();
                stringBuilder.append(str3);
                stringBuilder.append(this.head);
                textView.setText(stringBuilder.toString());
                stringBuilder = new StringBuilder();
                stringBuilder.append("head = ");
                stringBuilder.append(this.head);
                stringBuilder.append("  type = ");
                stringBuilder.append(this.type);
                stringBuilder.append("  cc = ");
                stringBuilder.append(this.cc);
                stringBuilder.append("   cc2 = ");
                stringBuilder.append(this.cc2);
                Log.e("track", stringBuilder.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        textView = findViewById(R.id.texthead);
        stringBuilder = new StringBuilder();
        stringBuilder.append(getResources().getString(R.string.ychoose));
        stringBuilder.append(" ");
        stringBuilder.append(this.head);
        textView.setText(stringBuilder.toString());
        if (!this.locale.contains(str2)) {
            textView.setTypeface(face);
        }
        textView = findViewById(R.id.note);
        if (this.type.equals("one")) {
            if (this.cc.equals("Daily Tarot Horoscope")) {
                textView.setText(getResources().getString(R.string.drawacard));
            } else {
                textView.setText(getResources().getString(R.string.thinkNdrawacard));
            }
        } else if (this.type.equals("three")) {
            textView.setText(getResources().getString(R.string.draw3cards));
        } else if (this.type.equals("four")) {
            textView.setText(getResources().getString(R.string.draw4cards));
        } else {
            textView.setText(getResources().getString(R.string.draw5cards));
        }
        if (!this.locale.contains(str2)) {
            textView.setTypeface(face);
        }
        ImageView imageView = findViewById(R.id.imageView53);
        this.l = new MarginLayoutParams[26];
        this.l1 = new MarginLayoutParams[26];
        this.l2 = new MarginLayoutParams[26];
        tempimg3 = new ImageView[3];
        tempimg4 = new ImageView[4];
        tempimg5 = new ImageView[5];
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TaroCardsQuestionActivity.this.shuffelcards();
                TaroCardsQuestionActivity.this.animate();
            }
        });
        this.main = findViewById(R.id.relativeLayout1);
        ImageView[] imageViews = new ImageView[26];
        img = imageViews;
        img1 = new ImageView[26];
        img2 = new ImageView[26];
        imageViews[0] = findViewById(R.id.imageView1);
        img[1] = findViewById(R.id.imageView2);
        img[2] = findViewById(R.id.imageView3);
        img[3] = findViewById(R.id.imageView4);
        img[4] = findViewById(R.id.imageView5);
        img[5] = findViewById(R.id.imageView6);
        img[6] = findViewById(R.id.imageView7);
        img[7] = findViewById(R.id.imageView8);
        img[8] = findViewById(R.id.imageView9);
        img[9] = findViewById(R.id.imageView10);
        img[10] = findViewById(R.id.imageView11);
        img[11] = findViewById(R.id.imageView12);
        img[12] = findViewById(R.id.imageView13);
        img[13] = findViewById(R.id.imageView14);
        img[14] = findViewById(R.id.imageView15);
        img[15] = findViewById(R.id.imageView16);
        img[16] = findViewById(R.id.imageView17);
        img[17] = findViewById(R.id.imageView18);
        img[18] = findViewById(R.id.imageView19);
        img[19] = findViewById(R.id.imageView20);
        img[20] = findViewById(R.id.imageView21);
        img[21] = findViewById(R.id.imageView22);
        img[22] = findViewById(R.id.imageView23);
        img[23] = findViewById(R.id.imageView24);
        img[24] = findViewById(R.id.imageView25);
        img[25] = findViewById(R.id.imageView26);
        img1[0] = findViewById(R.id.imageView27);
        img1[1] = findViewById(R.id.imageView28);
        img1[2] = findViewById(R.id.imageView29);
        img1[3] = findViewById(R.id.imageView30);
        img1[4] = findViewById(R.id.imageView31);
        img1[5] = findViewById(R.id.imageView32);
        img1[6] = findViewById(R.id.imageView33);
        img1[7] = findViewById(R.id.imageView34);
        img1[8] = findViewById(R.id.imageView35);
        img1[9] = findViewById(R.id.imageView36);
        img1[10] = findViewById(R.id.imageView37);
        img1[11] = findViewById(R.id.imageView38);
        img1[12] = findViewById(R.id.imageView39);
        img1[13] = findViewById(R.id.imageView40);
        img1[14] = findViewById(R.id.imageView41);
        img1[15] = findViewById(R.id.imageView42);
        img1[16] = findViewById(R.id.imageView43);
        img1[17] = findViewById(R.id.imageView44);
        img1[18] = findViewById(R.id.imageView45);
        img1[19] = findViewById(R.id.imageView46);
        img1[20] = findViewById(R.id.imageView47);
        img1[21] = findViewById(R.id.imageView48);
        img1[22] = findViewById(R.id.imageView49);
        img1[23] = findViewById(R.id.imageView50);
        img1[24] = findViewById(R.id.imageView51);
        img1[25] = findViewById(R.id.imageView52);
        img2[0] = findViewById(R.id.imageView55);
        img2[1] = findViewById(R.id.imageView56);
        img2[2] = findViewById(R.id.imageView57);
        img2[3] = findViewById(R.id.imageView58);
        img2[4] = findViewById(R.id.imageView59);
        img2[5] = findViewById(R.id.imageView60);
        img2[6] = findViewById(R.id.imageView61);
        img2[7] = findViewById(R.id.imageView62);
        img2[8] = findViewById(R.id.imageView63);
        img2[9] = findViewById(R.id.imageView64);
        img2[10] = findViewById(R.id.imageView65);
        img2[11] = findViewById(R.id.imageView66);
        img2[12] = findViewById(R.id.imageView67);
        img2[13] = findViewById(R.id.imageView68);
        img2[14] = findViewById(R.id.imageView69);
        img2[15] = findViewById(R.id.imageView70);
        img2[16] = findViewById(R.id.imageView71);
        img2[17] = findViewById(R.id.imageView72);
        img2[18] = findViewById(R.id.imageView73);
        img2[19] = findViewById(R.id.imageView74);
        img2[20] = findViewById(R.id.imageView75);
        img2[21] = findViewById(R.id.imageView76);
        img2[22] = findViewById(R.id.imageView77);
        img2[23] = findViewById(R.id.imageView78);
        img2[24] = findViewById(R.id.imageView79);
        img2[25] = findViewById(R.id.imageView80);
        i = 0;
        while (true) {
            i2 = 26;
            if (i >= 26) {
                break;
            }
            img[i].setId(i);
            img[i].setTag(cardnames[i]);
            img[i].setClickable(true);
            img[i].setOnClickListener(this.imgclick);
            this.l[i] = (MarginLayoutParams) img[i].getLayoutParams();
            i++;
        }
        i = 0;
        while (i < i2) {
            i3 = i + 26;
            img1[i].setId(i3);
            img1[i].setTag(cardnames[i3]);
            img1[i].setClickable(true);
            img1[i].setOnClickListener(this.imgclick);
            this.l1[i] = (MarginLayoutParams) img1[i].getLayoutParams();
            i++;
            i2 = 26;
        }
        while (i4 < 26) {
            i3 = i4 + 52;
            img2[i4].setId(i3);
            img2[i4].setTag(cardnames[i3]);
            img2[i4].setClickable(true);
            img2[i4].setOnClickListener(this.imgclick);
            this.l2[i4] = (MarginLayoutParams) img2[i4].getLayoutParams();
            i4++;
        }
        adjustMargin();
        shuufelimg = img;
        shuufelimg1 = img1;
        shuufelimg2 = img2;
        animate();
        shuffelcards();
        shuffelcards();
        shuffelcards();
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    private void animate() {
        int i;
        int i2 = 10;
        for (i = 0; i < 26; i++) {
            TranslateAnimation translateAnimation = new TranslateAnimation(5000.0f, 0.0f, 5000.0f, 0.0f);
            translateAnimation.setDuration(200);
            translateAnimation.setStartOffset(i2);
            img[i].startAnimation(translateAnimation);
            i2 += 20;
        }
        for (i = 0; i < 26; i++) {
            TranslateAnimation translateAnimation2 = new TranslateAnimation(5000.0f, 0.0f, 5000.0f, 0.0f);
            translateAnimation2.setDuration(200);
            translateAnimation2.setStartOffset(i2);
            img1[i].startAnimation(translateAnimation2);
            i2 += 20;
        }
        for (int i3 = 0; i3 < 26; i3++) {
            TranslateAnimation translateAnimation3 = new TranslateAnimation(5000.0f, 0.0f, 5000.0f, 0.0f);
            translateAnimation3.setDuration(200);
            translateAnimation3.setStartOffset(i2);
            img2[i3].startAnimation(translateAnimation3);
            i2 += 20;
        }
    }

    private void adjustMargin() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("layout----");
        stringBuilder.append(getResources().getConfiguration().screenLayout);
        Log.e("", stringBuilder.toString());
        Display defaultDisplay;
        Point point;
        int width;
        int height;
        int i;
        int i2;
        int i3;
        LayoutParams layoutParams;
        int i4;
        LayoutParams layoutParams2;
        int i5;
        LayoutParams layoutParams3;
        if ((getResources().getConfiguration().screenLayout & 15) == 1) {
            defaultDisplay = getWindowManager().getDefaultDisplay();
            point = new Point();
            defaultDisplay.getSize(point);
            if (VERSION.SDK_INT <= 11) {
                width = defaultDisplay.getWidth();
                height = defaultDisplay.getHeight();
            } else {
                defaultDisplay.getSize(point);
                width = point.x;
                height = point.y;
            }
            width /= 10;
            height /= 10;
            i = 0;
            i2 = 0;
            for (i3 = 0; i3 < 26; i3++) {
                layoutParams = new LayoutParams(width, height);
                i += width / 5;
                i2 += 2;
                layoutParams.setMargins(i, i2, 0, 0);
                img[i3].setLayoutParams(layoutParams);
                i2++;
                i++;
            }
            i3 = height + 10;
            i4 = i3;
            i2 = 0;
            for (i = 0; i < 26; i++) {
                layoutParams2 = new LayoutParams(width, height);
                i2 += width / 5;
                i4 += 2;
                layoutParams2.setMargins(i2, i4, 0, 0);
                img1[i].setLayoutParams(layoutParams2);
                i4++;
                i2++;
            }
            i3 *= 2;
            i2 = 0;
            for (i = 0; i < 26; i++) {
                layoutParams = new LayoutParams(width, height);
                i2 += width / 5;
                i3 += 2;
                layoutParams.setMargins(i2, i3, 0, 0);
                img2[i].setLayoutParams(layoutParams);
                i3++;
                i2++;
            }
        } else if ((getResources().getConfiguration().screenLayout & 15) == 2) {
            defaultDisplay = getWindowManager().getDefaultDisplay();
            point = new Point();
            if (VERSION.SDK_INT <= 11) {
                width = defaultDisplay.getWidth();
                height = defaultDisplay.getHeight();
            } else {
                defaultDisplay.getSize(point);
                width = point.x;
                height = point.y;
            }
            width /= 8;
            height /= 10;
            i = 0;
            i2 = 0;
            for (i3 = 0; i3 < 26; i3++) {
                layoutParams = new LayoutParams(width, height);
                i += width / 5;
                i2 += 8;
                layoutParams.setMargins(i, i2, 0, 0);
                img[i3].setLayoutParams(layoutParams);
                i2++;
                i++;
            }
            i3 = height + 20;
            i4 = i3;
            i2 = 0;
            for (i = 0; i < 26; i++) {
                layoutParams2 = new LayoutParams(width, height);
                i2 += width / 5;
                i4 += 8;
                layoutParams2.setMargins(i2, i4, 0, 0);
                img1[i].setLayoutParams(layoutParams2);
                i4++;
                i2++;
            }
            i3 *= 2;
            i = 0;
            for (i5 = 0; i5 < 26; i5++) {
                layoutParams3 = new LayoutParams(width, height);
                i += width / 5;
                i3 += 8;
                layoutParams3.setMargins(i, i3, 0, 0);
                img2[i5].setLayoutParams(layoutParams3);
                i3++;
                i++;
            }
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            defaultDisplay = getWindowManager().getDefaultDisplay();
            point = new Point();
            defaultDisplay.getSize(point);
            if (VERSION.SDK_INT <= 11) {
                width = defaultDisplay.getWidth();
                height = defaultDisplay.getHeight();
            } else {
                defaultDisplay.getSize(point);
                width = point.x;
                height = point.y;
            }
            width /= 8;
            height /= 10;
            i = 0;
            i2 = 0;
            for (i3 = 0; i3 < 26; i3++) {
                layoutParams = new LayoutParams(width, height);
                i += width / 5;
                i2 += 8;
                layoutParams.setMargins(i, i2, 0, 0);
                img[i3].setLayoutParams(layoutParams);
                i2++;
                i++;
            }
            i3 = height + 20;
            i4 = i3;
            i2 = 0;
            for (i = 0; i < 26; i++) {
                layoutParams2 = new LayoutParams(width, height);
                i2 += width / 5;
                i4 += 8;
                layoutParams2.setMargins(i2, i4, 0, 0);
                img1[i].setLayoutParams(layoutParams2);
                i4++;
                i2++;
            }
            i3 *= 2;
            i = 0;
            for (i5 = 0; i5 < 26; i5++) {
                layoutParams3 = new LayoutParams(width, height);
                i += width / 5;
                i3 += 8;
                layoutParams3.setMargins(i, i3, 0, 0);
                img2[i5].setLayoutParams(layoutParams3);
                i3++;
                i++;
            }
        } else if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            width = 0;
            i5 = 0;
            for (height = 0; height < 26; height++) {
                layoutParams3 = new LayoutParams(120, 180);
                width += 30;
                i5 += 20;
                layoutParams3.setMargins(width, i5, 0, 0);
                img[height].setLayoutParams(layoutParams3);
                i5++;
                width++;
            }
            height = Callback.DEFAULT_DRAG_ANIMATION_DURATION;
            i5 = 0;
            for (width = 0; width < 26; width++) {
                layoutParams3 = new LayoutParams(120, 180);
                i5 += 30;
                height += 20;
                layoutParams3.setMargins(i5, height, 0, 0);
                img1[width].setLayoutParams(layoutParams3);
                height++;
                i5++;
            }
            height = 400;
            i5 = 0;
            for (width = 0; width < 26; width++) {
                layoutParams3 = new LayoutParams(120, 180);
                i5 += 30;
                height += 20;
                layoutParams3.setMargins(i5, height, 0, 0);
                img2[width].setLayoutParams(layoutParams3);
                height++;
                i5++;
            }
        }
    }

    public boolean shuffelcards() {
        if (this.globflag == 1) {
            newshuffel4();
            this.globflag++;
        }
        if (this.globflag == 2) {
            newshuffel5();
            this.globflag = 1;
        }
        return true;
    }

    public void newshuffel4() {
        int i = 0;
        String str = cardnames[0];
        for (int i2 = 0; i2 < 78; i2++) {
            if (i2 != 77) {
                String[] strArr = cardnames;
                strArr[i2] = strArr[i2 + 1];
            } else {
                cardnames[77] = str;
            }
        }
        while (i < 26) {
            img[i].setTag(cardnames[i]);
            img1[i].setTag(cardnames[i + 26]);
            img2[i].setTag(cardnames[i + 52]);
            i++;
        }
    }

    public void newshuffel5() {
        String[] strArr = cardnames;
        int i = 0;
        String str = strArr[0];
        String str2 = strArr[1];
        for (int i2 = 0; i2 < 78; i2++) {
            if (i2 < 76) {
                String[] strArr2 = cardnames;
                strArr2[i2] = strArr2[i2 + 2];
            } else if (i2 == 76) {
                cardnames[76] = str;
            } else if (i2 == 77) {
                cardnames[77] = str2;
            }
        }
        while (i < 26) {
            img[i].setTag(cardnames[i]);
            img1[i].setTag(cardnames[i + 26]);
            img2[i].setTag(cardnames[i + 52]);
            i++;
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    public void onBackPressed() {
        finish();
        Intent intent = new Intent(this, TaroQuestionsActivity.class);
        startActivity(intent);
    }


    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
