package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class s5 implements View.OnClickListener {
    public final float e;
    public final float f;
    public final FrameEditorNewDesign g;

    public s5(final FrameEditorNewDesign g, final float e, final float f) {
        this.g = g;
        this.e = e;
        this.f = f;
    }

    public void onClick(final View view) {
        FrameEditorNewDesign.j0(this.g);
        final FrameEditorNewDesign g = this.g;
        g.G0(0, g.h1.getStickerPath(), this.e, this.f, this.g.h1.getHeights(), true);
        this.g.m1.dismiss();
    }
}
