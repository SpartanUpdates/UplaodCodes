package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class HDTextStickerViewSideTouchListener implements com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1.a {
    public final  FrameLayout frameLayout;
    public final TextStickerViewNew1 textStickerView;
    public final  HighlightDetailsDetailActivity activity;

    public HDTextStickerViewSideTouchListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity, FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        this.activity = highlightDetailsDetailActivity;
        this.frameLayout = frameLayout;
        this.textStickerView = textStickerViewNew1;
    }

    public void a(TextStickerViewNew1 textStickerViewNew1) {
        activity.svScroll.requestDisallowInterceptTouchEvent(true);
        TextStickerViewNew1 textStickerViewNew12 = this.activity.n0;
        if (textStickerViewNew12 != null) {
            textStickerViewNew12.setInEdit(false);
            this.activity.n0.setShowHelpBox(false);
        }
        this.activity.n0 = textStickerViewNew1;
        textStickerViewNew1.setInEdit(true);
        this.activity.n0.setShowHelpBox(true);
    }

    public void b(TextStickerViewNew1 textStickerViewNew1) {
        this.activity.g0(this.frameLayout, this.textStickerView);
    }

    public void c(TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.n0 != null && textStickerViewNew1.getTag().equals(this.activity.n0.getTag()) && textStickerViewNew1.u) {
            this.frameLayout.removeView(textStickerViewNew1);
        }
    }

    public void d(TextStickerViewNew1 textStickerViewNew1) {
        activity.o0 = true;
        activity.n0 = textStickerViewNew1;
        activity.s0(true);
    }
}
