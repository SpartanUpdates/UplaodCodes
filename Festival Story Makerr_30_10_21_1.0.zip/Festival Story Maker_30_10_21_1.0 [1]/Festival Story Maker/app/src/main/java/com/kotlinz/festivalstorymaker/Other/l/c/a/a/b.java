package com.kotlinz.festivalstorymaker.Other.l.c.a.a;

import android.content.SharedPreferences;
import android.util.Log;

public class b {
    public static b a;
    public static SharedPreferences b;

    public static b b() {
        if (a == null) {
            if (b != null) {
                synchronized (b.class) {
                    if (a == null) {
                        a = new b();
                    }
                }
            } else {
//                throw new a("FastSave Library must be initialized inside your application class by calling FastSave.init(getApplicationContext)");
            }
        }
        return a;
    }

    public boolean a(String str, boolean z) {
        return e(str) ? b.getBoolean(str, z) : z;
    }

    public int c(String str, int i) {
        return e(str) ? b.getInt(str, i) : i;
    }

    public String d(String str, String str2) {
        return e(str) ? b.getString(str, str2) : str2;
    }

    public boolean e(String str) {
        if (b.getAll().containsKey(str)) {
            return true;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No element founded in sharedPrefs with the key ");
        stringBuilder.append(str);

        return false;
    }

    public void f(String str, boolean z) {
        SharedPreferences.Editor edit = b.edit();
        edit.putBoolean(str, z);
        edit.apply();
    }

    public void g(String str, int i) {
        SharedPreferences.Editor edit = b.edit();
        edit.putInt(str, i);
        edit.apply();
    }

    public void h(String str, String str2) {
        SharedPreferences.Editor edit = b.edit();
        edit.putString(str, str2);
        edit.apply();
    }

}
