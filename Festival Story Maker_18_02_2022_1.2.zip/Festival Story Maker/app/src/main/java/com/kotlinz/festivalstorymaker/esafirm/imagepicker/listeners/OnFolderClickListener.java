package com.kotlinz.festivalstorymaker.esafirm.imagepicker.listeners;

import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Folder;

public interface OnFolderClickListener {
    void onFolderClick(Folder bucket);
}
