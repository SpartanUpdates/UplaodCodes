package com.wavymusic.AppUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import com.wavymusic.App.MyApplication;
import com.wavymusic.DashBord.Model.ThemeHomeModel;
import com.wavymusic.DashBord.Model.ThemeHomeModelUv;
import com.wavymusic.Partical.Model.ParticalItemModel;
import com.wavymusic.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Utils {
    public static final Utils INSTANCE;
    public static long mDeleteFileCount;
    public static String SongCropCommanPath;
    public static String AssetPath = "asset_theam";
    public static String PathOfThemeFolder = Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + ".ThemeDownload";
    public static String PathOfMusicFolder = Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + "Online Song";
    public static String PathOfAssetFolder = Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + ".asset_bundle";


    public static String PathOfNotification = Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + ".notification";

    public ArrayList<ParticalItemModel> particalAssetModels = new ArrayList<ParticalItemModel>();

    static {
        INSTANCE = new Utils();
        Utils.SongCropCommanPath = Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + "My Story";
        Utils.mDeleteFileCount = 0L;
    }

    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }


    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/United Videos/";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Utils.INSTANCE.getStoryFolderPath();
        Utils.INSTANCE.getNotification();
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }


    public static float dp2px(final Resources resources, final float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(final Resources resources, final float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }


    public static void AssetFilePath() {
        StringBuilder stringBuilder = new StringBuilder("/data/data/");
        stringBuilder.append(MyApplication.getInstance().getPackageName());
        stringBuilder.append("/");
        stringBuilder.append(AssetPath);
        AssetPathDir(new File(stringBuilder.toString()));
    }

    private static void AssetPathDir(File file) {
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
        }
    }


    public static String WhatsNewJsonWavy(ArrayList<ThemeHomeModel> ThemeListCategoryWise) {
        try {
            JSONObject jsonObj = new JSONObject();
            JSONArray jsonArr = new JSONArray();
            for (ThemeHomeModel pn : ThemeListCategoryWise) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", pn.getThemeid());
                jsonObject.put("theme_name", pn.getThemeName());
                jsonObject.put("category", pn.getCategoryid());
                jsonObject.put("theme_thumbnail", pn.getImage());
                jsonObject.put("small_thumbnail", pn.getSmall_Thumbnail());
                jsonObject.put("sound_file", pn.getAnimsoundurl());
                jsonObject.put("sound_filename", pn.getAnimSoundname());
                jsonObject.put("sound_size", pn.getAnimSoundfilesize());
                jsonObject.put("game_object", pn.getGameobjectName());
                jsonObject.put("downloads", pn.getThemeCounter());
                jsonObject.put("is_release", pn.isNewRealise());
                jsonArr.put(jsonObject);
                jsonObj.put("themes", jsonArr);
            }
            return jsonObj.toString();
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static String WhatsNewJsonUv(ArrayList<ThemeHomeModelUv> ThemeListCategoryWise) {
        try {
            JSONObject jsonObj = new JSONObject();
            JSONArray jsonArr = new JSONArray();
            for (ThemeHomeModelUv pn : ThemeListCategoryWise) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("theme_id", pn.getThemeid());
                jsonObject.put("category", pn.getCategoryid());
                jsonObject.put("video_type", pn.getVideoType());
                jsonObject.put("theme_name", pn.getThemeName());
                jsonObject.put("theme_thumbnail", pn.getImage());
                jsonObject.put("animation_file", pn.getBundelUrl());
                jsonObject.put("animation_file_name", pn.getPrefebName());
                jsonObject.put("animation_file_size", pn.getBundelSize());
                jsonObject.put("sound_file", pn.getAnimsoundurl());
                jsonObject.put("sound_file_name", pn.getAnimSoundname());
                jsonObject.put("sound_file_size", pn.getAnimSoundfilesize());
                jsonObject.put("width", pn.getImageWidht());
                jsonObject.put("height", pn.getImageHeight());
                jsonObject.put("number_of_images", pn.getImg_no_of());
                jsonObject.put("game_object", pn.getGameobjectName());
                jsonObject.put("total_download", pn.getThemeCounter());
                jsonObject.put("is_release", pn.getIsNewRealise());
                jsonArr.put(jsonObject);
                jsonObj.put("themes", jsonArr);
            }
            return jsonObj.toString();
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean SetPermission(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.System.canWrite(context)) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
                final StringBuilder sb = new StringBuilder("package:");
                sb.append(context.getPackageName());
                intent.setData(Uri.parse(sb.toString()));
                context.startActivityForResult(intent, 111);
            }
        }
        return false;
    }

    public final String getAPPFOLDER() {
        return "United Videos";
    }

    public final String getOutputPath() {
        final String path = Environment.getExternalStorageDirectory().toString() + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getCropSongPath() {
        final String path = this.getOutputPath() + "Crop Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getStoryFolderPath() {
        final String path = this.getOutputPath() + "My Story" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getMusicFolderPath() {
        final String path = this.getOutputPath() + "Online Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath() {
        final String path = this.getOutputPath() + ".ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getAssetUnityPath() {
        final String path = this.getOutputPath() + ".asset_bundle" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getNotification() {
        final String path = this.getOutputPath() + ".notification" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public int CatThumb(String str) {
        str = str.toLowerCase();
        return str.contains("telugu") ? R.drawable.icon_language_telugu : str.contains("tamil") ? R.drawable.icon_language_tamil : str.contains("bhojpuri") ? R.drawable.icon_language_bhojpuri : str.contains("english") ? R.drawable.icon_language_english : str.contains("gujarati") ? R.drawable.icon_language_gujarati : str.contains("hindi") ? R.drawable.icon_language_hindi : str.contains("kannada") ? R.drawable.icon_language_kannada : str.contains("malayalam") ? R.drawable.icon_language__malayalam : str.contains("marathi") ? R.drawable.icon_language_marathi : str.contains("islamic") ? R.drawable.icon_language_islamic : str.contains("bengali") ? R.drawable.icon_language_bengali : str.contains("punjabi") ? R.drawable.icon_language_punjabi : str.contains("rajashthahni") ? R.drawable.icon_language_rajashthahni : R.drawable.icon_language_hindi;
    }

    public int ParticalCatThumb(String str) {
        str = str.toLowerCase();
        return str.contains("general") ? R.drawable.icon_general_preview : str.contains("love") ? R.drawable.icon_love_preview : str.contains("birthday") ? R.drawable.icon_birthday_preview : str.contains("god") ? R.drawable.icon_god_preview : str.contains("neon") ? R.drawable.icon_neon_preview : str.contains("smoke") ? R.drawable.icon_smock_preview : str.contains("festival") ? R.drawable.icon_festival : str.contains("baby") ? R.drawable.icon_baby_preview : str.contains("sports") ? R.drawable.icon_general_preview : str.contains("travel") ? R.drawable.icon_travel_preview : str.contains("wish") ? R.drawable.icon_wish_preview : R.drawable.icon_general_preview;
    }

    public int ParticalCatThumbPress(String str) {
        str = str.toLowerCase();
        return str.contains("general") ? R.drawable.icon_general_preview_pressed : str.contains("love") ? R.drawable.icon_love_preview_pressed : str.contains("birthday") ? R.drawable.icon_birthday_preview_pressed : str.contains("god") ? R.drawable.icon_god_preview_pressed : str.contains("neon") ? R.drawable.icon_neon_preview_pressed : str.contains("smoke") ? R.drawable.icon_smock_preview_pressed : str.contains("festival") ? R.drawable.icon_festival_selected : str.contains("baby") ? R.drawable.icon_baby_preview_pressed : str.contains("sports") ? R.drawable.icon_general_preview_pressed : str.contains("travel") ? R.drawable.icon_travel_preview_pressed : str.contains("wish") ? R.drawable.icon_wish_preview_pressed : R.drawable.icon_general_preview_pressed;
    }

    public int ThemHomeCatThum(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love : str.contains("tictok") ? R.drawable.icon_tiktok : str.contains("sad") ? R.drawable.icon_sad : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("birthday") ? R.drawable.icon_birthday : str.contains("wedding") ? R.drawable.icon_wedding : str.contains("god") ? R.drawable.icon_god : str.contains("maha shivratri") ? R.drawable.icon_god: str.contains("friends") ? R.drawable.icon_friendship : str.contains("rockstar") ? R.drawable.icon_rockstar : str.contains("wish") ? R.drawable.icon_wish : str.contains("day events") ? R.drawable.icon_day_events : str.contains("popular") ? R.drawable.icon_popular : str.contains("christmas") ? R.drawable.icon_christmas : str.contains("festival") ? R.drawable.icon_festival : str.contains("patriotic") ? R.drawable.icon_patriotic : str.contains("social") ? R.drawable.icon_social : str.contains("holiday") ? R.drawable.icon_holiday : str.contains("uv special") ? R.drawable.icon_uv_special : str.contains("telugu") ? R.drawable.icon_telugu : str.contains("tamil") ? R.drawable.icon_tamil : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri : str.contains("english") ? R.drawable.icon_english : str.contains("gujarati") ? R.drawable.icon_gujarati : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("kannada") ? R.drawable.icon_kannada : str.contains("malayalam") ? R.drawable.icon_malayalam : str.contains("marathi") ? R.drawable.icon_marathi : str.contains("islamic") ? R.drawable.icon_islamic : str.contains("bengali") ? R.drawable.icon_bengali : str.contains("punjabi") ? R.drawable.icon_punjabi : str.contains("rajashthahni") ? R.drawable.icon_rajashthahni : str.contains("anniversary") ? R.drawable.icon_anniversary : str.contains("baby") ? R.drawable.icon_baby: str.contains("valantine") ? R.drawable.icon_valantine: R.drawable.icon_new;
    }

    public int ThemHomeCatThumSelected(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love_selected : str.contains("tictok") ? R.drawable.icon_tiktok_selected : str.contains("sad") ? R.drawable.icon_sad_selected : str.contains("hindi") ? R.drawable.icon_hindi_selected : str.contains("birthday") ? R.drawable.icon_birthday_selected : str.contains("wedding") ? R.drawable.icon_wedding_selected : str.contains("god") ? R.drawable.icon_god_selected : str.contains("maha shivratri") ? R.drawable.icon_god_selected: str.contains("friends") ? R.drawable.icon_friendship_selected : str.contains("rockstar") ? R.drawable.icon_rockstar_selected : str.contains("wish") ? R.drawable.icon_wish_selected : str.contains("day events") ? R.drawable.icon_day_events_selected : str.contains("popular") ? R.drawable.icon_popular_selected : str.contains("christmas") ? R.drawable.icon_christmas_selected : str.contains("festival") ? R.drawable.icon_festival_selected : str.contains("patriotic") ? R.drawable.icon_patriotic_selected : str.contains("social") ? R.drawable.icon_social_selected : str.contains("holiday") ? R.drawable.icon_holiday_selected : str.contains("uv special") ? R.drawable.icon_uvspecial_selected : str.contains("telugu") ? R.drawable.icon_telugu_selected : str.contains("tamil") ? R.drawable.icon_tamil_selected : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri_selected : str.contains("english") ? R.drawable.icon_english_selected : str.contains("gujarati") ? R.drawable.icon_gujarati_selected : str.contains("hindi") ? R.drawable.icon_hindi_selected : str.contains("kannada") ? R.drawable.icon_kannada_selected : str.contains("malayalam") ? R.drawable.icon_malayalam_selected : str.contains("marathi") ? R.drawable.icon_marathi_selected : str.contains("islamic") ? R.drawable.icon_islamic_selected : str.contains("bengali") ? R.drawable.icon_bengali_selected : str.contains("punjabi") ? R.drawable.icon_punjabi_selected : str.contains("rajashthahni") ? R.drawable.icon_rajashthahni_selected : str.contains("anniversary") ? R.drawable.icon_anniversary_selected : str.contains("baby") ? R.drawable.icon_baby_selected: str.contains("valantine") ? R.drawable.icon_valantine__selected: R.drawable.icon_new_selected;
    }

    public void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                this.deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }


    public void CopyAssets(Context context) {
        AssetManager assetManager = context.getAssets();
        String[] files = null;
        try {
            files = assetManager.list("Partical");
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (String filename : files) {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = assetManager.open("Partical" + "/" + filename);   // if files resides inside the "Files" directory itself
                out = new FileOutputStream(getAssetUnityPath() + filename);
                copyFile(in, out);
                String DestinationFolderName = "";
                if (filename.indexOf(".") > 0) {
                    DestinationFolderName = filename.substring(0, filename.lastIndexOf("."));
                }
                try {
                    unzipTheme(Utils.INSTANCE.getAssetUnityPath() + filename, Utils.INSTANCE.getAssetUnityPath() + DestinationFolderName);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                in.close();
                in = null;
                out.flush();
                out.close();
                out = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }

    public void unzipTheme(String zipFilePath, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdir();
        }
        ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();
        // iterates over entries in the zip filePath
        while (entry != null) {
            String filePath = destDirectory + File.separator + entry.getName();
            if (!entry.isDirectory()) {
                // if the entry is a filePath, extracts it
                extractFile(zipIn, filePath);
            } else {
                // if the entry is a directory, make the directory
                File dir = new File(filePath);
                dir.mkdir();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
    }

    private static final int BUFFER_SIZE = 4096;

    private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }

}
