package com.esc.beautymackupselficlam.permission;

import android.Manifest;
import android.app.Activity;

import androidx.core.app.ActivityCompat;

public class Permission {
    public static final int CAMERA_EXTERNAL_STORAGE_CODE = 26;
    public static final int READ_EXTERNAL_STORAGE_CODE = 23;
    public static final int WRITE_EXTERNAL_STORAGE_CODE = 24;
    Activity mactivity;

    public Permission(Activity activity) {
        mactivity = activity;
    }

    public boolean checkPermissionForReadexternal() {
        if (ActivityCompat.checkSelfPermission(mactivity, Manifest.permission.READ_EXTERNAL_STORAGE) == 0) {
            return true;
        }
        return false;
    }

    public boolean checkPermissionForWriteexternal() {
        if (ActivityCompat.checkSelfPermission(mactivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0) {
            return true;
        }
        return false;
    }

    public boolean checkPermissionForCamera() {
        if (ActivityCompat.checkSelfPermission(mactivity, Manifest.permission.CAMERA) == 0) {
            return true;
        }
        return false;
    }

    public void requestPermissionForReadeexternal() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(mactivity, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(mactivity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 23);
            return;
        }
        ActivityCompat.requestPermissions(mactivity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 23);
    }

    public void requestPermissionForWriteexternal() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(mactivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(mactivity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 24);
            return;
        }
        ActivityCompat.requestPermissions(this.mactivity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 24);
    }


    public void requestPermissionCamera() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this.mactivity, Manifest.permission.CAMERA)) {
            ActivityCompat.requestPermissions(this.mactivity, new String[]{Manifest.permission.CAMERA}, 26);
            return;
        }
        ActivityCompat.requestPermissions(this.mactivity, new String[]{Manifest.permission.CAMERA}, 26);
    }
}
