﻿using UnityEngine;

namespace BallCollect
{
    public class CameraManager : MonoBehaviour
    {
        void Awake()
        {
            if (Mathf.Floor(Camera.main.aspect * 10f) / 10f <= Mathf.Floor(5.625f) / 10f)
            {
                float d = 720f / (float)Screen.width * (float)Screen.height / 1280f;
                this.transform.localPosition *= d;
            }
        }
        private void Start()
        {
                GameController.instance.camStartPos=new Vector3(0,transform.localPosition.y-0.5f,transform.position.z);
        }
    }
}