package com.kotlinz.festivalstorymaker.Model.StoryMaker;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class StoryMakerResponse {

	@SerializedName("data")
	private ArrayList<StoryMainCategory> data;

	@SerializedName("status")
	private String status;

	public ArrayList<StoryMainCategory> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}