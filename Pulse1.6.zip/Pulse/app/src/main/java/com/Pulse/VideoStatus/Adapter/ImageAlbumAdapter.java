package com.Pulse.VideoStatus.Adapter;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.Pulse.VideoStatus.Activity.ImageSelectActivity;
import com.Pulse.VideoStatus.Interface.OnItemClickListner;
import com.Pulse.VideoStatus.Model.ImageInfo;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.application.MyApplication;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class ImageAlbumAdapter extends RecyclerView.Adapter<ImageAlbumAdapter.Holder> {
    private MyApplication application;
    private ArrayList<String> FolderList;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> itemClickListner;
    private ImageSelectActivity activity;


    public ImageAlbumAdapter(final Context activity) {
        this.application = MyApplication.getInstance();
        this.FolderList = new ArrayList<String>(this.application.getAllAlbumList().keySet());
        this.activity = (ImageSelectActivity) activity;
        Collections.sort(this.FolderList, new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return s1.compareToIgnoreCase(s2);
            }
        });
        if (FolderList.size() != 0) {
            this.application.setSelectedFolderId(this.FolderList.get(0));
        } else {
            Toast.makeText(application, "No Image Album Found In Your Phone Please Add Some Image First", Toast.LENGTH_SHORT).show();
        }
        this.inflater = LayoutInflater.from(activity);
    }


    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }

    public int getItemCount() {
        return FolderList == null ? 0 : FolderList.size();
    }

    public String getItem(final int pos) {
        return this.FolderList.get(pos);
    }

    public void onBindViewHolder(@NonNull final Holder holder, final int pos) {
        final String currentFolderId = this.getItem(pos);
        final ImageInfo data = this.application.getImageByAlbum(currentFolderId).get(0);
        holder.tvAlbumName.setSelected(true);

        holder.tvAlbumName.setSelected(true);
        holder.tvAlbumName.setText(data.folderName);

        if (currentFolderId.equals(application.getSelectedFolderId())) {
            holder.tvAlbumName.setSelected(true);
        } else {
            holder.tvAlbumName.setSelected(false);
        }
        holder.tvAlbumName.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                ImageAlbumAdapter.this.application.setSelectedFolderId(currentFolderId);
                if (ImageAlbumAdapter.this.itemClickListner != null) {
                    ImageAlbumAdapter.this.itemClickListner.onItemClick(v, data);
                }
                ImageAlbumAdapter.this.notifyDataSetChanged();
            }
        });
    }


    @NonNull
    public Holder onCreateViewHolder(@NonNull final ViewGroup parent, final int pos) {
        return new Holder(this.inflater.inflate(R.layout.items, parent, false));
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView tvAlbumName;
        View parent;


        public Holder(final View v) {
            super(v);
            this.parent = v;
            this.tvAlbumName = v.findViewById(R.id.textView1);
        }

        public void onItemClick(final View view, final Object item) {
            if (ImageAlbumAdapter.this.itemClickListner != null) {
                ImageAlbumAdapter.this.itemClickListner.onItemClick(view, item);
            }
        }
    }
}
