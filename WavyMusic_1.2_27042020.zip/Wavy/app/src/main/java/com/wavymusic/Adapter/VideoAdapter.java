package com.wavymusic.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.wavymusic.Model.VideoModel;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.bumptech.glide.Glide;
import com.wavymusic.activity.VideoPlayerActivity;

import java.io.File;
import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    private ArrayList<VideoModel> mVideoDatas;

    public VideoAdapter(Context mContext, ArrayList<VideoModel> mVideoDatas) {
        this.mContext = mContext;
        this.mVideoDatas = mVideoDatas;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_video, parent, false);
        return new MyViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final MyViewHolder myViewHolder = (MyViewHolder) holder;
        final StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(myViewHolder.itemView.getLayoutParams());
        layoutParams.setFullSpan(false);
        myViewHolder.itemView.setLayoutParams(layoutParams);

        Glide.with(this.mContext).load(mVideoDatas.get(position).videoFullPath).into(myViewHolder.ivVideoThumb);
        myViewHolder.tvVideoName.setText(mVideoDatas.get(position).videoName);
        myViewHolder.tvVideoName.setSelected(true);
        myViewHolder.ivPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                Intent i = new Intent(mContext, VideoPlayerActivity.class);
                i.putExtra("VideoUrl", mVideoDatas.get(position).videoFullPath);
                i.putExtra("VideoPosition", position);
                i.putExtra("IsVideoFromAndroidList", true);
                i.putExtra("AllVideoList", mVideoDatas);
                mContext.startActivity(i);
            }
        });
        myViewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                try {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(VideoAdapter.this.mContext, R.style.AppDialog);
                    builder.setTitle(R.string.deletetitle);
                    builder.setMessage(String.valueOf(VideoAdapter.this.mContext.getResources().getString(R.string.deleteMessage)) + " " + VideoAdapter.this.mVideoDatas.get(position).videoName + ".mp4" + " ?");
                    builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int which) {
                            try {
                                Utils.deleteFile(new File(VideoAdapter.this.mVideoDatas.get(position).videoFullPath));
                                itemRemoved(position);
                                VideoAdapter.this.notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(mContext.getResources().getColor(R.color.app_main_bg_color));
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(mContext.getResources().getColor(R.color.app_main_bg_color));
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(mContext.getResources().getColor(R.color.app_main_bg_color));
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        myViewHolder.ivShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                final File file = new File(VideoAdapter.this.mVideoDatas.get(position).videoFullPath);
                final Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("video/*");
                shareIntent.putExtra("android.intent.extra.SUBJECT", VideoAdapter.this.mContext.getString(R.string.app_name));
                shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(VideoAdapter.this.mContext.getString(R.string.get_free)) + VideoAdapter.this.mContext.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + VideoAdapter.this.mContext.getPackageName());
                shareIntent.putExtra("android.intent.extra.TITLE", VideoAdapter.this.mVideoDatas.get(position).videoName);
                final Uri ShareUri = FileProvider.getUriForFile(VideoAdapter.this.mContext, String.valueOf(VideoAdapter.this.mContext.getPackageName()) + ".provider", file);
                shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                VideoAdapter.this.mContext.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }


    public void itemRemoved(int pos) {
        if ((mVideoDatas != null) && (mVideoDatas.size() > 0)) {
            mVideoDatas.remove(pos);
        }
    }

    public int getItemCount() {
        return mVideoDatas.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView ivVideoThumb;
        ImageView ivPlay;
        TextView tvVideoName;
        ImageView ivShare;
        ImageView ivDelete;

        public MyViewHolder(View v) {
            super(v);
            ivVideoThumb = v.findViewById(R.id.iv_videoplayer_thumb);
            tvVideoName = v.findViewById(R.id.tv_videoName);
            ivShare = v.findViewById(R.id.ivShare);
            ivDelete = v.findViewById(R.id.ivDelete);
            ivPlay = v.findViewById(R.id.ivPlay_vc);
        }
    }

}
