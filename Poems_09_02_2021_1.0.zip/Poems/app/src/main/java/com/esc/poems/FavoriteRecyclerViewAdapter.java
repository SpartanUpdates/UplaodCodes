package com.esc.poems;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import java.util.ArrayList;

public class FavoriteRecyclerViewAdapter extends Adapter<FavoriteRecyclerViewAdapter.ViewHolder> {
    private String TAG = "FavoriteRecyclerViewAdapter";
    private final Activity context;
    private int f;
    private final ArrayList<String> fav;
    private ViewHolder holder;
    private LayoutInflater inflater = null;
    private final ArrayList<String> mid;
    private final ArrayList<String> msg;
    private String msg2;
    private int nooftimes_resultviewd = 0;
    private Typeface type1;

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public ImageView fimg;
        public ImageView imgmsg;
        public TextView quotetxt;
        public Button sharebtnimg;
        public Button sharebtntxt;

        public ViewHolder(View view) {
            super(view);
            this.quotetxt = (TextView) view.findViewById(R.id.quotestxt);
            this.fimg = (ImageView) view.findViewById(R.id.favimg);
            this.imgmsg = (ImageView) view.findViewById(R.id.imgmsg);
            this.sharebtntxt = (Button) view.findViewById(R.id.sharetxt);
            this.sharebtnimg = (Button) view.findViewById(R.id.sharebtnimg);
        }
    }

    public FavoriteRecyclerViewAdapter(Activity activity, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3) {
        this.type1 = Typeface.createFromAsset(activity.getAssets(), "fonts/roboto_light.ttf");
        this.context = activity;
        this.msg = arrayList;
        this.mid = arrayList2;
        this.fav = arrayList3;
        this.inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.messages_list, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        if (Integer.parseInt(((String) this.fav.get(i)).toString()) == 0) {
            viewHolder.fimg.setImageResource(R.drawable.inactive1);
        } else {
            viewHolder.fimg.setImageResource(R.drawable.stars);
        }
        viewHolder.quotetxt.setTypeface(this.type1);
        viewHolder.quotetxt.setText(Html.fromHtml(((String) this.msg.get(i)).toString()));
        viewHolder.quotetxt.setTag(Integer.valueOf(i));
        viewHolder.fimg.setTag(Integer.valueOf(i));
        viewHolder.sharebtntxt.setTag(Integer.valueOf(i));
        viewHolder.sharebtnimg.setTag(Integer.valueOf(i));
        viewHolder.fimg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ImageView imageView = (ImageView) view.findViewById(R.id.favimg);
                imageView.setTag(viewHolder.fimg.getTag());
                int fav = FavoriteActivity.baseHelper.getFav(Integer.parseInt(((String) FavoriteRecyclerViewAdapter.this.mid.get(i)).toString()));
                if (fav == 0) {
                    imageView.setImageResource(R.drawable.stars);
                    FavoriteActivity.baseHelper.updateFavorite(1, Integer.parseInt(((String) FavoriteRecyclerViewAdapter.this.mid.get(i)).toString()));
                    Toast.makeText(FavoriteRecyclerViewAdapter.this.context, "Marked as a Favorite", Toast.LENGTH_SHORT).show();
                    imageView.invalidate();
                    FavoriteRecyclerViewAdapter.this.fav.set(i, "1");
                    FavoriteRecyclerViewAdapter.this.notifyDataSetChanged();
                } else if (fav == 1) {
                    imageView.setImageResource(R.drawable.inactive1);
                    FavoriteActivity.baseHelper.updateFavorite(0, Integer.parseInt(((String) FavoriteRecyclerViewAdapter.this.mid.get(i)).toString()));
                    Toast.makeText(FavoriteRecyclerViewAdapter.this.context, "Favorite Unmarked", Toast.LENGTH_SHORT).show();
                    imageView.invalidate();
                    FavoriteRecyclerViewAdapter.this.notifyDataSetChanged();
                    FavoriteRecyclerViewAdapter.this.fav.set(i, "0");
                }
            }
        });
        viewHolder.sharebtntxt.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (FavoriteActivity.sharedPreferences.getInt(str, 0) == 0) {
                    FavoriteActivity.editor.putInt(str, 0);
                    FavoriteActivity.editor.commit();
            }
                String str2 = "count";
                FavoriteRecyclerViewAdapter.this.nooftimes_resultviewd = FavoriteActivity.sharedPreferences.getInt(str2, 0);
                FavoriteActivity.editor.putInt(str2, FavoriteRecyclerViewAdapter.this.nooftimes_resultviewd + 1);
                FavoriteActivity.editor.commit();
                String access$400 = FavoriteRecyclerViewAdapter.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker - sharetxt fav ");
                stringBuilder.append((String) FavoriteActivity.cat.get(i));
                Log.e(access$400, stringBuilder.toString());
                Bundle bundle = new Bundle();
                bundle.putString("ShareText_Fav", (String) FavoriteActivity.cat.get(i));
                access$400 = Html.fromHtml((String) FavoriteRecyclerViewAdapter.this.msg.get(i)).toString();
                FavoriteRecyclerViewAdapter favoriteRecyclerViewAdapter = FavoriteRecyclerViewAdapter.this;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(access$400);
                stringBuilder2.append("\n");
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("<br>Do read this poem. I found it at <br>");
                stringBuilder3.append(MyApplication.appLink);
                stringBuilder2.append(Html.fromHtml(stringBuilder3.toString()));
                favoriteRecyclerViewAdapter.msg2 = stringBuilder2.toString();
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Poems For All Occasions");
                intent.putExtra("android.intent.extra.TEXT", FavoriteRecyclerViewAdapter.this.msg2);
                FavoriteRecyclerViewAdapter.this.context.startActivity(Intent.createChooser(intent, "Share via..."));
                FavoriteRecyclerViewAdapter.this.copyText();
            }
        });
        viewHolder.sharebtnimg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "firstvisit";
                if (FavoriteActivity.sharedPreferences.getInt(str, 0) == 0) {
                    FavoriteActivity.editor.putInt(str, 0);
                    FavoriteActivity.editor.commit();
                }
                String str2 = "count";
                FavoriteRecyclerViewAdapter.this.nooftimes_resultviewd = FavoriteActivity.sharedPreferences.getInt(str2, 0);
                FavoriteActivity.editor.putInt(str2, FavoriteRecyclerViewAdapter.this.nooftimes_resultviewd + 1);
                FavoriteActivity.editor.commit();
                String access$400 = FavoriteRecyclerViewAdapter.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tracker - copy fav ");
                stringBuilder.append((String) FavoriteActivity.cat.get(i));
                Log.e(access$400, stringBuilder.toString());
                Bundle bundle = new Bundle();
                bundle.putString("CopyText_Fav", (String) FavoriteActivity.cat.get(i));
                FavoriteRecyclerViewAdapter favoriteRecyclerViewAdapter = FavoriteRecyclerViewAdapter.this;
                stringBuilder = new StringBuilder();
                stringBuilder.append(Html.fromHtml(((String) FavoriteRecyclerViewAdapter.this.msg.get(i)).toString()));
                stringBuilder.append("\n");
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("<br>Do read this poem. I found it at <br>");
                stringBuilder2.append(MyApplication.appLink);
                stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                favoriteRecyclerViewAdapter.msg2 = stringBuilder.toString();
                FavoriteRecyclerViewAdapter.this.copyText();
            }
        });
    }

    public int getItemCount() {
        String str = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("afsadpt.........");
        stringBuilder.append(this.msg.size());
        Log.e(str, stringBuilder.toString());
        return this.msg.size();
    }

    private void copyText() {
        ((ClipboardManager) this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("label", Html.fromHtml(this.msg2)));
        Toast.makeText(this.context, "Copied to Clipboard", Toast.LENGTH_SHORT).show();
    }
}
