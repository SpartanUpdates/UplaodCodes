package com.esc.socialmediacleaner.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.exifinterface.media.ExifInterface;
import com.bumptech.glide.load.Key;
import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.util.AdParentScreen;
import com.esc.socialmediacleaner.util.SavedData;
import com.esc.socialmediacleaner.util.Util;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Pattern;

class ShareAppScreen extends AdParentScreen {
    private int facePosition = 0;
    private int rating = 1;

    private void messageDialog(String str) {
    }

    ShareAppScreen() {
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(getString(R.string.share_text));
        stringBuilder3.append(" ");
        stringBuilder3.append(stringBuilder2);
        intent.putExtra("android.intent.extra.TEXT", stringBuilder3.toString());
        intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.share_text));
        startActivity(Intent.createChooser(intent, "Share"));
    }

    private boolean isIntentAvailable(Context context, Intent intent) {
        return context.getPackageManager().queryIntentActivities(intent, 65536).size() > 0;
    }

    public static String urlEncode(String str) {
        try {
            str = URLEncoder.encode(str, Key.STRING_CHARSET_NAME);
            return str;
        } catch (UnsupportedEncodingException e) {
            Log.wtf("", "UTF-8 should always be supported", e);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("URLEncoder.encode() failed for ");
            stringBuilder.append(str);
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    public void toast(String str) {
        View inflate = getLayoutInflater().inflate(R.layout.toast_layout, (ViewGroup) findViewById(R.id.toast_layout_root));
        ((TextView) inflate.findViewById(R.id.text)).setText(str);
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(80, 0, 0);
        toast.setDuration(1);
        toast.setView(inflate);
        toast.show();
    }

    public void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        View currentFocus = getCurrentFocus();
        if (currentFocus == null) {
            currentFocus = new View(this);
        }
        inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
    }

    public boolean isEmailValid(String str) {
        return Pattern.compile("^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$", 2).matcher(str).matches();
    }

    public int getFacePosition() {
        return this.facePosition;
    }

    private Drawable getADrawable(int i) {
        if (VERSION.SDK_INT >= 21) {
            return getResources().getDrawable(i, getTheme());
        }
        return getResources().getDrawable(i);
    }

    public void setFacePosition(int i) {
        this.facePosition = i;
    }
}
