package com.vidsoft.collagemaker.GridThreeD;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.material.snackbar.Snackbar;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.MaterialDialog.Builder;
import com.afollestad.materialdialogs.MaterialDialog.InputCallback;
import com.afollestad.materialdialogs.MaterialDialog.SingleButtonCallback;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.michael.easydialog.EasyDialog;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.vidsoft.Filters.AllStickerSupports.FontProvider;
import com.vidsoft.Filters.AllStickerSupports.StickerView;
import com.vidsoft.Filters.AllStickerSupports.TextSticker;
import com.vidsoft.Filters.scrollgalleryview.Grid3DFilter.PorterShapeImageView;
import com.vidsoft.Filters.scrollgalleryview.Grid3DFilter.TouchImageView;
import com.vidsoft.collagemaker.Activity.MainActivity;
import com.vidsoft.collagemaker.Activity.PhotoEditingActivity;
import com.vidsoft.collagemaker.Activity.ShareActivity;
import com.vidsoft.collagemaker.Adapters.ColorAdapter;
import com.vidsoft.collagemaker.Adapters.FontStickerAdapter;
import com.vidsoft.collagemaker.Adapters.FontStickerAdapter.FontStickerCallBack;
import com.vidsoft.collagemaker.Adapters.FontsAdapter;
import com.vidsoft.collagemaker.Adapters.FontsPatternAdapter;
import com.vidsoft.collagemaker.Adapters.Grid3DAdapter;
import com.vidsoft.collagemaker.Adapters.Grid3DAdapter.Grid3DCallback;
import com.vidsoft.collagemaker.Model.Grid3D;
import com.vidsoft.collagemaker.Model.StickerData;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Stickers.CustomStckerTextView;
import com.vidsoft.collagemaker.Utils.Stickers.StickerAdapter;
import com.vidsoft.collagemaker.Utils.Stickers.StickerViewnew;
import com.vidsoft.collagemaker.Utils.CompressImage;
import com.vidsoft.collagemaker.Utils.Const;
import com.vidsoft.collagemaker.Utils.DataBinder;
import com.vidsoft.collagemaker.Utils.MyDragShadowBuilder;
import com.vidsoft.collagemaker.Utils.RecyclerItemClickListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import id.zelory.compressor.Compressor;
import me.zhanghai.android.materialprogressbar.BuildConfig;


public class GridEditActivity extends AppCompatActivity implements OnClickListener, Grid3DCallback, FontStickerCallBack {
    SeekBar blurfontSeekbar;
    int blurVal;
    RelativeLayout captureMainrllayout;
    ArrayList<Integer> colors11;
    ArrayList<Integer> colors22;
    ArrayList<Integer> colors33;
    int currentGrid;
    int currentLayout;
    FontProvider fontProvider;
    FontStickerAdapter fontStickerAdapter;
    RecyclerView rc_fontcolor;
    RecyclerView rc_fontcolor1;
    View layoutView;
    int length;
    LinearLayout linearFontView;
    LinearLayoutManager ll_Manager;
    RecyclerView rc_fontlist;
    RecyclerView rc_fontpattern_list;
    int initialColor;
    int initialRadius;
    Activity activity;
    Blur blur;
    int blurEffects;
    ColorAdapter Adapter_fontcolor1;
    List<String> list_fonts;
    FontsAdapter fontsAdapter;
    FontsPatternAdapter fontspatternadapter;
    ColorAdapter Adapter_fontshadow;
    ArrayList<Grid3D> grid3DArrayList;
    Grid3DAdapter gridAdapter;
    ImageView img_Sticker;
    ImageView img_Template;
    ImageView img_Text;
    RecyclerView rc_fontshadow_color;
    float font_size_counter;
    ColorAdapter Adapter_fontcolor;
    LinearLayout ll_text_colorview;
    LinearLayout ll_text_colorview_back;
    LinearLayout ll_text_fontview;
    LinearLayout ll_text_fontview_back;
    LinearLayout ll_text_patternview;
    LinearLayoutManager ll_Manager_font_shadow_color;
    LinearLayoutManager ll_Manager_main;
    ArrayList<String> listImages;
    LinearLayout ll_mainFrameLayout;
    LinearLayout ll_mainLayout;
    int[] patternData;
    int picChangePosition;
    SeekBar seekbarRadius;
    RecyclerView rvMainView;
    RecyclerView recyclerView;
    int[] resourceTouchImageView;
    int[] rotationUnits;
    TextSticker textSticker;
    LinearLayout stickerCheck;
    TextView stickerCount;
    LinearLayout stickerCross;
    LinearLayout stickerFullLayout;
    StickerView stickerView;
    TextSticker tempSticker;
    LinearLayout templateLayoutMain;
    LinearLayout textLayoutMain;
    LinearLayout llTextBlurview;
    LinearLayout llTextBlurviewBack;
    LinearLayoutManager linearLayoutManager;
    LinearLayoutManager llManagerFontColor;
    LinearLayoutManager llManagerFontColor1;
    LinearLayoutManager llManagerFontPatternList;
    LinearLayout llTextPatternviewBack;
    LinearLayout llTextShadowview;
    LinearLayout llTextShadowviewBack;
    PorterShapeImageView[] porterShapeImageViews;
    TextView tvDeboss;
    TextView tvEmboss;
    TextView tvInner;
    TextView tvNormal;
    TextView tvOriginal;
    TextView tvOuter;
    TextView txtSolid;
    ViewPager viewPager;
    SmartTabLayout smartTabLayout;
    ImageView img_save;
    public static Bitmap mBitmap;
    private ArrayList<Integer> stickerlist;
    private StickerAdapter stickerAdapter;
    private ArrayList<View> views;
    private CustomStckerTextView currentTextView;
    private StickerViewnew currentView;
    ImageView img_text;
    private ProgressDialog progressDialog;
    public static String str_urlShareimg;


    private void setStickerList1() {
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_2));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_3));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_10));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_12));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_15));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_17));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_18));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_19));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_20));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_21));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_22));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_23));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_24));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_25));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_27));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_28));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_29));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s29));
        this.stickerlist.add(Integer.valueOf(R.drawable.s30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s31));
        this.stickerlist.add(Integer.valueOf(R.drawable.s32));
        this.stickerlist.add(Integer.valueOf(R.drawable.s33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s34));
        this.stickerlist.add(Integer.valueOf(R.drawable.s35));
        this.stickerlist.add(Integer.valueOf(R.drawable.s36));
        this.stickerlist.add(Integer.valueOf(R.drawable.s37));
        this.stickerlist.add(Integer.valueOf(R.drawable.s38));
        this.stickerlist.add(Integer.valueOf(R.drawable.s39));
        this.stickerlist.add(Integer.valueOf(R.drawable.s40));
        this.stickerlist.add(Integer.valueOf(R.drawable.s41));
        this.stickerlist.add(Integer.valueOf(R.drawable.s42));
        this.stickerlist.add(Integer.valueOf(R.drawable.s43));
        this.stickerlist.add(Integer.valueOf(R.drawable.s44));
        this.stickerlist.add(Integer.valueOf(R.drawable.s45));
        this.stickerlist.add(Integer.valueOf(R.drawable.s46));
        this.stickerlist.add(Integer.valueOf(R.drawable.s47));
        this.stickerlist.add(Integer.valueOf(R.drawable.s48));
        this.stickerlist.add(Integer.valueOf(R.drawable.s49));
        this.stickerlist.add(Integer.valueOf(R.drawable.s50));
        this.stickerlist.add(Integer.valueOf(R.drawable.s51));
        this.stickerlist.add(Integer.valueOf(R.drawable.s52));
        this.stickerlist.add(Integer.valueOf(R.drawable.s53));
        this.stickerlist.add(Integer.valueOf(R.drawable.s54));
        this.stickerlist.add(Integer.valueOf(R.drawable.s55));
    }

    public class fetchSticker extends AsyncTask<String, Void, Void> {
        protected Void doInBackground(String... params) {
            int j = 0;
            while (j <= 391) {
                try {
                    MainActivity.stickerArrayList.add(new StickerData("s" + j, false));
                    j++;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        protected void onPreExecute() {
            MainActivity.stickerArrayList.clear();
            super.onPreExecute();
        }

        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    public class swapImages extends AsyncTask<String, Void, Void> {
        Bitmap bitmap;
        Bitmap bitmap1;
        TouchImageView from;
        String path;
        String path1;
        ProgressDialog progressDialog;
        TouchImageView to;

        public swapImages(String path, String path1, TouchImageView from, TouchImageView to) {
            this.path = path;
            this.path1 = path1;
            this.from = from;
            this.to = to;
        }

        protected Void doInBackground(String... params) {
            try {
                this.bitmap = Compressor.getDefault(GridEditActivity.this.activity).compressToBitmap(new File(this.path));
                this.bitmap1 = Compressor.getDefault(GridEditActivity.this.activity).compressToBitmap(new File(this.path1));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPreExecute() {
            this.progressDialog = new ProgressDialog(GridEditActivity.this.activity);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setMessage("Please wait...");
            this.progressDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(Void aVoid) {
            this.from.setImageBitmap(this.bitmap);
            this.to.setImageBitmap(this.bitmap1);
            this.progressDialog.dismiss();
            super.onPostExecute(aVoid);
        }
    }

    public GridEditActivity() {
        this.activity = this;
        this.listImages = new ArrayList();
        this.grid3DArrayList = new ArrayList();
        this.resourceTouchImageView = new int[]{R.id.touchImageView1, R.id.touchImageView2, R.id.touchImageView3, R.id.touchImageView4, R.id.touchImageView5, R.id.touchImageView6};
        this.tempSticker = null;
        this.initialColor = R.color.BG_Color;
        this.initialRadius = 2;
        this.font_size_counter = 0.0f;
        this.blurEffects = 0;
        this.blurVal = 8;
        this.blur = Blur.NORMAL;
        this.patternData = DataBinder.fetchPatternData();
        this.colors11 = new ArrayList();
        this.colors22 = new ArrayList();
        this.colors33 = new ArrayList();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_gridedit);
        LoadBannerAds();
        loadAd();
        bindToolbar();
        bindControls();
        setupLayout();
        setGrid(this.length);
        openDialog();
        this.views = new ArrayList();
        new fetchSticker().execute();
        textSticker();
    }

    private void setupLayout() {
        this.layoutView = this.getLayoutInflater().inflate(this.currentLayout, this.ll_mainFrameLayout, false);
        this.ll_mainFrameLayout.addView(this.layoutView);
        this.rotationUnits = new int[this.length];
        for (int i = 0; i < this.length; ++i) {
            this.rotationUnits[i] = 0;
        }
        this.porterShapeImageViews = new PorterShapeImageView[this.length];
        for (int j = 0; j < this.length; ++j) {
            this.porterShapeImageViews[j] = layoutView.findViewById(this.resourceTouchImageView[j]);
        }
        for (int k = 0; k < this.length; ++k) {
            this.porterShapeImageViews[k].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.listImages.get(k))));
            this.porterShapeImageViews[k].setTag(this.listImages.get(k));
            this.porterShapeImageViews[k].setOnClickListener(this);
        }
        this.dragdrop();
    }

    public void dragdrop() {
        for (int i = 0; i < this.porterShapeImageViews.length; i++) {
            this.porterShapeImageViews[i].setOnLongClickListener(new OnLongClickListener() {
                public boolean onLongClick(View v) {
                    v.startDrag(ClipData.newPlainText("test", "drag:"), new MyDragShadowBuilder(v), v, 0);
                    return true;
                }
            });
            this.porterShapeImageViews[i].setOnDragListener(new OnDragListener() {

                class AnonymousClass1 implements Runnable {
                    final String val$path;
                    final String val$path1;

                    AnonymousClass1(String str, String str2) {
                        this.val$path = str;
                        this.val$path1 = str2;
                    }

                    public void run() {
                        int i = 0;
                        while (i < GridEditActivity.this.listImages.size()) {
                            if (GridEditActivity.this.listImages.get(i).equals(this.val$path) || GridEditActivity.this.listImages.get(i).equals(this.val$path1)) {
                                GridEditActivity.this.rotationUnits[i] = 0;
                            }
                            i++;
                        }
                    }
                }

                public boolean onDrag(View v, DragEvent event) {
                    TouchImageView from = (TouchImageView) event.getLocalState();
                    TouchImageView to = (TouchImageView) v;
                    switch (event.getAction()) {
                        case 1:
                            return from != to;
                        case 2:
                            return true;
                        case 3:
                            String path = to.getTag().toString();
                            String path1 = from.getTag().toString();
                            to.setTag(path1);
                            from.setTag(path);
                            new swapImages(path, path1, from, to).execute();
                            AsyncTask.execute(new AnonymousClass1(path, path1));
                            return true;
                        case 4:
                            if (!event.getResult()) {
                                from.setImageBitmap(Compressor.getDefault(GridEditActivity.this.activity).compressToBitmap(new File(from.getTag().toString())));
                            }
                            return true;
                        case 5:
                            return true;
                        case 6:
                            return true;
                        default:
                            return false;
                    }
                }
            });
        }
    }

    public void Grid3DMethod(int position) {
        this.ll_mainFrameLayout.removeAllViews();
        this.currentLayout = (this.grid3DArrayList.get(position)).getLayout();
        setupLayout();
    }

    private void bindControls() {
        this.ll_mainFrameLayout = findViewById(R.id.mainFrameLayout);
        this.img_Template = findViewById(R.id.imgTemplate);
        this.img_Sticker = findViewById(R.id.imgSticker);
        this.img_Text = findViewById(R.id.imgText);
        this.captureMainrllayout = findViewById(R.id.rl_MaincaptureLayout);
        this.templateLayoutMain = findViewById(R.id.ll_template);
        this.textLayoutMain = findViewById(R.id.textLayoutMain);
        this.captureMainrllayout = findViewById(R.id.rl_MaincaptureLayout);
        this.recyclerView = findViewById(R.id.recyclerView);
        this.ll_Manager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.recyclerView.setLayoutManager(this.ll_Manager);
        this.stickerCross = findViewById(R.id.stickerCross);
        this.stickerCheck = findViewById(R.id.stickerCheck);
        this.stickerCount = findViewById(R.id.stickerCount);
        this.ll_mainLayout = findViewById(R.id.mainLayout);
        this.ll_mainLayout.setVisibility(View.VISIBLE);
        this.stickerFullLayout = findViewById(R.id.ll_sticker);
        this.stickerFullLayout.setVisibility(View.GONE);
        this.stickerView = findViewById(R.id.stickerview);
        this.stickerView.setBackgroundColor(-1);
        this.stickerView.setLocked(false);
        this.stickerView.setConstrained(true);
        this.rvMainView = findViewById(R.id.recyclerMainView);
        this.ll_Manager_main = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvMainView.setLayoutManager(this.ll_Manager_main);
        this.rc_fontcolor = findViewById(R.id.font_color);
        this.llManagerFontColor = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_fontcolor.setLayoutManager(this.llManagerFontColor);
        this.rc_fontcolor1 = findViewById(R.id.font_color1);
        this.llManagerFontColor1 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_fontcolor1.setLayoutManager(this.llManagerFontColor1);
        this.rc_fontshadow_color = findViewById(R.id.rc_fontshadow);
        this.ll_Manager_font_shadow_color = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_fontshadow_color.setLayoutManager(this.ll_Manager_font_shadow_color);
        this.rc_fontpattern_list = findViewById(R.id.rc_patternlist);
        this.llManagerFontPatternList = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_fontpattern_list.setLayoutManager(this.llManagerFontPatternList);
        this.rc_fontlist = findViewById(R.id.rc_fontlist);
        this.linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_fontlist.setLayoutManager(this.linearLayoutManager);
        this.linearFontView = findViewById(R.id.Font_ll);
        this.ll_text_fontview_back = findViewById(R.id.ll_textfontview_back);
        this.ll_text_fontview = findViewById(R.id.ll_textfont);
        this.ll_text_colorview_back = findViewById(R.id.text_color_view_back);
        this.ll_text_colorview = findViewById(R.id.ll_textcolorview);
        this.llTextShadowviewBack = findViewById(R.id.text_shadow_view_back);
        this.llTextShadowview = findViewById(R.id.ll_textshadow);
        this.seekbarRadius = findViewById(R.id.radiusSeekbar);
        this.blurfontSeekbar = findViewById(R.id.blurFontStickerSeekbar);
        this.llTextBlurview = findViewById(R.id.text_blur_view);
        this.llTextBlurviewBack = findViewById(R.id.text_blur_view_back);
        this.ll_text_patternview = findViewById(R.id.ll_textpattern);
        this.llTextPatternviewBack = findViewById(R.id.textpatternview_back);
        this.tvOriginal = findViewById(R.id.tvOriginal);
        this.tvEmboss = findViewById(R.id.tvEmboss);
        this.tvDeboss = findViewById(R.id.tvDeboss);
        this.tvNormal = findViewById(R.id.tvNormal);
        this.txtSolid = findViewById(R.id.tvSolid);
        this.tvInner = findViewById(R.id.tvInner);
        this.tvOuter = findViewById(R.id.tvOuter);
        this.length = Integer.parseInt(getIntent().getExtras().getString(Const.imgId));
        this.listImages = getIntent().getExtras().getStringArrayList(Const.imgList);
        this.currentLayout = Integer.parseInt(getIntent().getExtras().getString(Const.imgSource));
        this.currentGrid = getIntent().getExtras().getInt(Const.currentGrid);
        img_Template.setImageResource(R.drawable.ic_layout_press);
        img_Template.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                templateLayoutMain.setVisibility(View.VISIBLE);
                textLayoutMain.setVisibility(View.GONE);
                img_Template.setImageResource(R.drawable.ic_layout_press);
                img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                img_Text.setImageResource(R.drawable.ic_text_unpress);
                img_save.setImageResource(R.drawable.ic_save_unpress);
            }
        });
        img_Sticker.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showStickerDialog();
                img_Sticker.setImageResource(R.drawable.ic_sticker_press);
                img_Template.setImageResource(R.drawable.ic_layout_unpress);
                img_Text.setImageResource(R.drawable.ic_text_unpress);
                img_save.setImageResource(R.drawable.ic_save_unpress);
            }
        });

        img_save = findViewById(R.id.imgsave);
        img_save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                img_save.setImageResource(R.drawable.ic_save_press);
                img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                img_Template.setImageResource(R.drawable.ic_layout_unpress);
                img_Text.setImageResource(R.drawable.ic_text_unpress);
                if (currentTextView != null) {
                    currentTextView.setInEdit(false);
                }
                if (currentView != null) {
                    currentView.setInEdit(false);

                }
                if (!stickerView.isLocked()) {
                    stickerView.setLocked(true);
                }
                captureMainrllayout.setDrawingCacheEnabled(true);
                File imgFile = CompressImage.tempImage(getApplicationContext(), captureMainrllayout.getDrawingCache());
                try {
                    File f = new File(imgFile.getAbsolutePath());
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inSampleSize = 10;
                    opts.inMutable = true;
                    mBitmap = BitmapFactory.decodeStream(new FileInputStream(f));
                    mBitmap = mBitmap.copy(Bitmap.Config.ARGB_8888, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                takeScreenshot(mBitmap, getResources().getString(R.string.app_name));
                id = R.id.imgsave;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialogAd.show();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(GridEditActivity.this, ShareActivity.class).putExtra("key", 1));
                    finish();
                }

            }

        });
        img_text = findViewById(R.id.imgText);
        img_text.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                textLayoutMain.setVisibility(View.VISIBLE);
                templateLayoutMain.setVisibility(View.GONE);
                img_Text.setImageResource(R.drawable.ic_text_press);
                img_save.setImageResource(R.drawable.ic_save_unpress);
                img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                img_Template.setImageResource(R.drawable.ic_layout_unpress);
            }
        });

    }

    private void addStickerView(int id) {
        final StickerViewnew stickerView = new StickerViewnew(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerViewnew.OperationListener() {
            public void onDeleteClick() {
                GridEditActivity.this.views.remove(stickerView);
                GridEditActivity.this.captureMainrllayout.removeView(stickerView);
            }

            public void onEdit(StickerViewnew stickerView) {
                if (GridEditActivity.this.currentTextView != null) {
                    GridEditActivity.this.currentTextView.setInEdit(false);
                }
                GridEditActivity.this.currentView.setInEdit(false);
                GridEditActivity.this.currentView = stickerView;
                GridEditActivity.this.currentView.setInEdit(true);
            }

            public void onTop(StickerViewnew stickerView) {
                int position = GridEditActivity.this.views
                        .indexOf(stickerView);
                if (position != GridEditActivity.this.views.size() - 1) {
                    GridEditActivity.this.views.add(
                            GridEditActivity.this.views.size(),
                            GridEditActivity.this.views
                                    .remove(position));
                }
            }
        });
        this.captureMainrllayout.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.views.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerViewnew stickerView) {
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(false);
        }
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

    public void showStickerDialog() {
        final Dialog dial = new Dialog(this, android.R.style.Theme_Translucent);
        dial.requestWindowFeature(1);
        dial.setContentView(R.layout.sticker_dialog);
        dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dial.setCanceledOnTouchOutside(false);
        dial.findViewById(R.id.back_dialog).setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        img_Template.setImageResource(R.drawable.ic_layout_press);
                        img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                        img_Text.setImageResource(R.drawable.ic_text_unpress);
                        img_save.setImageResource(R.drawable.ic_save_unpress);
                        dial.dismiss();
                    }
                });
        dial.setOnKeyListener(new Dialog.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface arg0, int keyCode,
                                 KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e("TAG","Dialog Close");
                    img_Template.setImageResource(R.drawable.ic_layout_press);
                    img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                    img_Text.setImageResource(R.drawable.ic_text_unpress);
                    img_save.setImageResource(R.drawable.ic_save_unpress);
                    dial.dismiss();
                }
                return true;
            }
        });
        this.stickerlist = new ArrayList();
        GridView grid_sticker = dial.findViewById(R.id.gridStickerList);
        setStickerList1();
        this.stickerAdapter = new StickerAdapter(getApplicationContext(),
                this.stickerlist);
        grid_sticker.setAdapter(this.stickerAdapter);
        grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GridEditActivity.this
                        .addStickerView(stickerlist.get(position));
                img_Template.setImageResource(R.drawable.ic_layout_press);
                img_Sticker.setImageResource(R.drawable.ic_sticker_unpress);
                img_Text.setImageResource(R.drawable.ic_text_unpress);
                img_save.setImageResource(R.drawable.ic_save_unpress);
                dial.dismiss();

            }
        });
        dial.show();
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialogAd.dismiss();
            }
        }, 2000);
    }


    private int id;
    private InterstitialAd interstitialAd;
    Dialog dialogAd;

    private AdView adView;

    private void LoadBannerAds() {
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private void loadAd() {
        dialogAd = new Dialog(GridEditActivity.this);
        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogAd.getWindow().setGravity(Gravity.CENTER);
        dialogAd.setContentView(R.layout.dialog_layout_progress);
        dialogAd.setCanceledOnTouchOutside(false);
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialogAd.dismiss();
                switch (id) {
                    case R.id.imgsave:
                        startActivity(new Intent(GridEditActivity.this, ShareActivity.class).putExtra("key", 1));
                        finish();
                        break;

                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();
    }

    private void takeScreenshot(Bitmap bitmap, String storePath) {
        File file = null;
        if (Environment.getExternalStorageState().equals("mounted")) {
            File directory = new File(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(getResources().getString(R.string.app_name)).toString());

            if (!directory.exists()) {
                directory.mkdirs();
            }
            file = new File(directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png");
            str_urlShareimg = directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png";
        }
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));

    }

    private void bindToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_btn_selector);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(getResources().getString(R.string.app_name));
    }

    public void setGrid(int pos) {
        this.grid3DArrayList.clear();
        for (int i = 0; i < DataBinder.fetchGrid3dData().size(); i++) {
            if (DataBinder.fetchGrid3dData().get(i).getImage() == pos) {
                this.grid3DArrayList.add(DataBinder.fetchGrid3dData().get(i));
            }
        }
        this.gridAdapter = new Grid3DAdapter(this.activity, this.grid3DArrayList, this.currentGrid);
        this.recyclerView.setAdapter(this.gridAdapter);
    }


    private void openDialog() {
        ViewGroup tab = findViewById(R.id.frametab);
        tab.addView(LayoutInflater.from(this).inflate(R.layout.demo_custom_tab_icons, tab, false));
        this.viewPager = findViewById(R.id.viewpager);
        this.smartTabLayout = findViewById(R.id.viewpagertab);
    }

    public void stickerLayout() {
        this.stickerFullLayout.setVisibility(View.GONE);
        this.ll_mainLayout.setVisibility(View.VISIBLE);
        this.stickerCount.setText("0");
        MainActivity.stickerValue = 0;
        new fetchSticker().execute();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.touchImageView1:
                openQuickAction(view, 0);
                break;
            case R.id.touchImageView2:
                openQuickAction(view, 1);
                break;
            case R.id.touchImageView3:
                openQuickAction(view, 2);
                break;
            case R.id.touchImageView4:
                openQuickAction(view, 3);
                break;
            case R.id.touchImageView5:
                openQuickAction(view, 4);
                break;
            case R.id.touchImageView6:
                openQuickAction(view, 5);
                break;
            default:
                break;
        }
    }


    public void openQuickAction(final View locationByAttachedView, int screenHeight) {
        this.picChangePosition = screenHeight;
        final EasyDialog easyDialog = new EasyDialog(this.activity);
        easyDialog.setLayoutResourceId(R.layout.popup_quick).setBackgroundColor(this.getResources().getColor(R.color.Popup_Color)).setLocationByAttachedView(locationByAttachedView).setAnimationTranslationShow(1, 1000, -800.0f, 100.0f, -50.0f, 50.0f, 0.0f).setAnimationAlphaDismiss(400, 1.0f, 0.0f).setGravity(0).setTouchOutsideDismiss(true).setMatchParent(false).setMarginLeftAndRight(24, 24).setOutsideColor(Color.parseColor("#66444444"));
        screenHeight = getScreenHeight(this.activity);
        final int statusBarHeight = getStatusBarHeight(this.getApplicationContext());
        if (easyDialog.getDialog() != null) {
            final WindowManager.LayoutParams attributes = easyDialog.getDialog().getWindow().getAttributes();
            attributes.gravity = 48;
            attributes.y = statusBarHeight;
            attributes.width = -1;
            attributes.height = screenHeight - statusBarHeight;
            easyDialog.getDialog().getWindow().setAttributes(attributes);
        }
        easyDialog.show();
        if (easyDialog.getDialog() != null) {
            final LinearLayout linearLayout = easyDialog.getDialog().findViewById(R.id.btnChangePic);
            final LinearLayout linearLayout2 = easyDialog.getDialog().findViewById(R.id.btnClosedialog);
            final LinearLayout linearLayout3 = easyDialog.getDialog().findViewById(R.id.btnEditimage);
            easyDialog.getDialog().findViewById(R.id.btnRotateimage).setOnClickListener(new OnClickListener() {
                public void onClick(final View view) {
                    final Bitmap decodeFile = BitmapFactory.decodeFile(GridEditActivity.this.porterShapeImageViews[GridEditActivity.this.picChangePosition].getTag().toString());
                    final int n = GridEditActivity.this.rotationUnits[GridEditActivity.this.picChangePosition] + 90;
                    GridEditActivity.this.rotationUnits[GridEditActivity.this.picChangePosition] = n;
                    GridEditActivity.this.porterShapeImageViews[GridEditActivity.this.picChangePosition].setImageBitmap(CompressImage.rotateBitmap(decodeFile, n));
                }
            });
            linearLayout3.setOnClickListener(new OnClickListener() {
                public void onClick(final View view) {
                    final Intent intent = new Intent(GridEditActivity.this.getApplicationContext(), PhotoEditingActivity.class);
                    intent.putExtra(Const.editedImg, GridEditActivity.this.porterShapeImageViews[GridEditActivity.this.picChangePosition].getTag().toString());
                    GridEditActivity.this.startActivityForResult(intent, 6);
                    GridEditActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    if (easyDialog.getDialog().isShowing()) {
                        easyDialog.dismiss();
                    }
                }
            });
            linearLayout.setOnClickListener(new OnClickListener() {
                public void onClick(final View view) {
                    final Intent intent = new Intent("android.intent.action.PICK");
                    intent.setType("image/*");
                    GridEditActivity.this.startActivityForResult(intent, 1);
                    if (easyDialog.getDialog().isShowing()) {
                        easyDialog.dismiss();
                    }
                }
            });
            linearLayout2.setOnClickListener(new OnClickListener() {
                public void onClick(final View view) {
                    easyDialog.dismiss();
                }
            });
        }
    }

    private static int getScreenHeight(Activity activity) {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        return displaymetrics.heightPixels;
    }

    private static int getStatusBarHeight(Context context) {
        Resources res = context.getResources();
        int resourceId = res.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return res.getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == -1) {
            switch (requestCode) {
                case 1:
                    this.listImages.set(this.picChangePosition, CompressImage.getPath(getApplicationContext(), data.getData()));
                    this.porterShapeImageViews[this.picChangePosition].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.listImages.get(this.picChangePosition))));
                    this.rotationUnits[this.picChangePosition] = 0;
                    this.porterShapeImageViews[this.picChangePosition].setTag(this.listImages.get(this.picChangePosition));
                    break;
                case 6:
                    if (Const.editedImagePath != null) {
                        this.listImages.set(this.picChangePosition, Const.editedImagePath);
                        this.porterShapeImageViews[this.picChangePosition].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.listImages.get(this.picChangePosition))));
                        this.rotationUnits[this.picChangePosition] = 0;
                        this.porterShapeImageViews[this.picChangePosition].setTag(this.listImages.get(this.picChangePosition));
                    }
                    break;
            }
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    private void textSticker() {
        ArrayList<Integer> integerArrayList = new ArrayList();
        integerArrayList.add(Integer.valueOf(R.drawable.fonttexticon));
        integerArrayList.add(Integer.valueOf(R.drawable.textcoloricon));
        integerArrayList.add(Integer.valueOf(R.drawable.fonts));
        integerArrayList.add(Integer.valueOf(R.drawable.textshadow));
        integerArrayList.add(Integer.valueOf(R.drawable.text_pattern_btn));
        integerArrayList.add(Integer.valueOf(R.drawable.text_bg_btn));
        this.blurfontSeekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                } else if (GridEditActivity.this.blurEffects == 1) {
                    GridEditActivity.this.blurVal = progress + 1;
                    GridEditActivity.this.stickerView.setLayerType(1, null);
                    GridEditActivity.this.tempSticker.applyFilter(GridEditActivity.this.blur, GridEditActivity.this.blurVal);
                    GridEditActivity.this.stickerView.invalidate();
                }
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.seekbarRadius.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (GridEditActivity.this.tempSticker != null) {
                    GridEditActivity.this.initialRadius = progress;
                    GridEditActivity.this.tempSticker.setTextShadowColor(GridEditActivity.this.initialRadius, GridEditActivity.this.initialColor);
                    GridEditActivity.this.stickerView.invalidate();
                }
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.tvEmboss.setLayerType(1, null);
        this.tvEmboss.getPaint().setMaskFilter(new EmbossMaskFilter(new float[]{1.0f, 5.0f, 1.0f}, 0.8f, 8.0f, 7.0f));
        this.tvDeboss.setLayerType(1, null);
        this.tvDeboss.getPaint().setMaskFilter(new EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 13.0f, 7.0f));
        this.tvNormal.setLayerType(1, null);
        this.tvNormal.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.NORMAL));
        this.txtSolid.setLayerType(1, null);
        this.txtSolid.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.SOLID));
        this.tvInner.setLayerType(1, null);
        this.tvInner.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.INNER));
        this.tvOuter.setLayerType(1, null);
        this.tvOuter.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.OUTER));
        for (int h = 0; h <= 360; h += 10) {
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.25f, 1.0f)));
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.5f, 1.0f)));
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.75f, 1.0f)));
        }
        this.colors11 = DataBinder.fetchPrimaryColor();
        this.Adapter_fontcolor = new ColorAdapter(this.activity, this.colors11);
        this.Adapter_fontcolor.setSelection(20);
        this.rc_fontcolor.setAdapter(this.Adapter_fontcolor);
        this.colors33 = DataBinder.fetchSecondaryColor(0);
        this.Adapter_fontcolor1 = new ColorAdapter(this.activity, this.colors33);
        this.rc_fontcolor1.setAdapter(this.Adapter_fontcolor1);
        this.Adapter_fontshadow = new ColorAdapter(this.activity, this.colors22);
        this.rc_fontshadow_color.setAdapter(this.Adapter_fontshadow);
        this.fontStickerAdapter = new FontStickerAdapter(this.activity, integerArrayList);
        this.rvMainView.setAdapter(this.fontStickerAdapter);
        this.fontspatternadapter = new FontsPatternAdapter(this.activity, this.patternData);
        this.rc_fontpattern_list.setAdapter(this.fontspatternadapter);
        this.fontProvider = new FontProvider(getResources());
        this.list_fonts = this.fontProvider.getFontNames();
        this.fontsAdapter = new FontsAdapter(this, this.list_fonts, this.fontProvider);
        this.rc_fontlist.setAdapter(this.fontsAdapter);
        this.rc_fontlist.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridEditActivity.this.tempSticker.setTypeface(GridEditActivity.this.fontProvider.getTypeface(GridEditActivity.this.list_fonts.get(position)));
                GridEditActivity.this.stickerView.invalidate();
                GridEditActivity.this.fontsAdapter.setSelection(position);
            }
        }));
        this.rc_fontcolor1.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridEditActivity.this.tempSticker.setTextColor(GridEditActivity.this.colors33.get(position).intValue());
                GridEditActivity.this.stickerView.invalidate();
                GridEditActivity.this.Adapter_fontcolor1.setSelection(position);
            }
        }));
        this.rc_fontcolor.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridEditActivity.this.tempSticker.setTextColor(GridEditActivity.this.colors11.get(position).intValue());
                GridEditActivity.this.stickerView.invalidate();
                GridEditActivity.this.Adapter_fontcolor.setSelection(position);
                if (GridEditActivity.this.colors11.get(position).intValue() != Color.parseColor("#ffffff") && GridEditActivity.this.colors11.get(position).intValue() != Color.parseColor("#000000")) {
                    GridEditActivity.this.colors33 = DataBinder.fetchSecondaryColor(position);
                    GridEditActivity.this.Adapter_fontcolor1 = new ColorAdapter(GridEditActivity.this.activity, GridEditActivity.this.colors33);
                    GridEditActivity.this.rc_fontcolor1.setAdapter(GridEditActivity.this.Adapter_fontcolor1);
                }
            }
        }));
        this.rc_fontshadow_color.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridEditActivity.this.initialColor = GridEditActivity.this.colors22.get(position).intValue();
                GridEditActivity.this.stickerView.setLayerType(2, null);
                GridEditActivity.this.tempSticker.setTextShadowColor(GridEditActivity.this.initialRadius, GridEditActivity.this.initialColor);
                GridEditActivity.this.stickerView.invalidate();
                GridEditActivity.this.Adapter_fontshadow.setSelection(position);
            }
        }));
        this.rc_fontpattern_list.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridEditActivity.this.tempSticker == null) {
                    Snackbar.make(GridEditActivity.this.captureMainrllayout, GridEditActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridEditActivity.this.tempSticker.setShader(GridEditActivity.this.activity, BitmapFactory.decodeResource(GridEditActivity.this.getResources(), GridEditActivity.this.patternData[position]));
                GridEditActivity.this.stickerView.invalidate();
                GridEditActivity.this.fontspatternadapter.setSelection(position);
            }
        }));
        this.ll_text_colorview_back.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridEditActivity.this.ll_text_colorview.setVisibility(View.GONE);
                GridEditActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.llTextShadowviewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GridEditActivity.this.llTextShadowview.setVisibility(View.GONE);
                GridEditActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.llTextBlurviewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GridEditActivity.this.llTextBlurview.setVisibility(View.GONE);
                GridEditActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.ll_text_fontview_back.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridEditActivity.this.ll_text_fontview.setVisibility(View.GONE);
                GridEditActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.llTextPatternviewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridEditActivity.this.ll_text_patternview.setVisibility(View.GONE);
                GridEditActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
    }

    private void addTextSticker() {
        new Builder(this.activity).title("Set Text").inputType(8289).inputRange(2, 100).onNegative(new SingleButtonCallback() {
            public void onClick(MaterialDialog dialog, DialogAction which) {
                dialog.dismiss();
            }
        }).negativeText("Cancel").positiveText("Set").input(BuildConfig.FLAVOR, BuildConfig.FLAVOR, false, new InputCallback() {
            public void onInput(MaterialDialog dialog, CharSequence input) {
                GridEditActivity.this.loadSticker(input.toString());
            }
        }).show();
    }

    public void shadowFont() {
        this.llTextShadowview.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void patternFont() {
        this.ll_text_patternview.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void blurFont() {
        this.llTextBlurview.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void colorFont() {
        this.ll_text_colorview.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void typeFont() {
        this.ll_text_fontview.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void originalFontSticker(View view) {
        this.blurEffects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(2, null);
            this.tempSticker.originalEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void embossFontSticker(View view) {
        this.blurEffects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(1, null);
            this.tempSticker.embossEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void debossFontSticker(View view) {
        this.blurEffects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(1, null);
            this.tempSticker.debossEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void normalFontSticker(View view) {
        this.blurEffects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.NORMAL;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void solidFontSticker(View view) {
        this.blurEffects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.SOLID;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void innerFontSticker(View view) {
        this.blurEffects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.INNER;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void outerFontSticker(View view) {
        this.blurEffects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.OUTER;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMainrllayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void loadSticker(String string) {
        Drawable bubble = ContextCompat.getDrawable(getApplicationContext(), R.drawable.transparent_background);
        this.textSticker = new TextSticker(getApplicationContext());
        this.textSticker.setDrawable(bubble);
        this.textSticker.setText(string);
        this.textSticker.resizeText();
        this.stickerView.addSticker(this.textSticker);
        this.tempSticker = this.textSticker;
    }

    public void FontStickerMethod(int position) {
        switch (position) {
            case 0:
                addTextSticker();
                break;
            case 1:
                colorFont();
                break;
            case 2:
                typeFont();
                break;
            case 3:
                shadowFont();
                break;
            case 4:
                blurFont();
                break;
            case 5:
                patternFont();
                break;
            default:
                break;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuback, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                if (this.stickerFullLayout.getVisibility() == View.GONE) {
                    AlertDialog.Builder alertDialogbuilder = new AlertDialog.Builder(this.activity);
                    alertDialogbuilder.setMessage("You have unsaved changes, do you want to exit and return to the previous screen?");
                    alertDialogbuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            GridEditActivity.this.finish();
                            GridEditActivity.this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                        }
                    });
                    alertDialogbuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alertDialogbuilder.setCancelable(false);
                    alertDialogbuilder.show();
                }
                stickerLayout();
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onBackPressed() {
        if (this.stickerFullLayout.getVisibility() == View.GONE) {
            AlertDialog.Builder alertDialogbuilder = new AlertDialog.Builder(this.activity);
            alertDialogbuilder.setMessage("You have unsaved changes, do you want to exit and return to the previous screen?");
            alertDialogbuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    GridEditActivity.this.finish();
                    GridEditActivity.this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                }
            });
            alertDialogbuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            alertDialogbuilder.setCancelable(false);
            alertDialogbuilder.show();
            return;
        }
        stickerLayout();

    }
}