package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.DatabaseHelper;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.manager.QuestionManager;
import com.example.knowledgetrivia.models.LevelScore;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;


public class ShowingLevel extends AppCompatActivity {
    Activity activity=ShowingLevel.this;
    private ArrayList<Boolean> levelExist;
    private ArrayList<String> levelNames;
    private ArrayList<LevelScore> storeLevelScore;
    private MediaPlayer tick;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private ImageView img_back;

    public void onCreate(Bundle bundle) {
        Boolean valueOf = Boolean.valueOf(true);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_showing_level);

       BannerAds();

        img_back=findViewById(R.id.img_back);


        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        QuestionManager instance = QuestionManager.getInstance(this);
        this.levelNames = new ArrayList();
        this.levelExist = new ArrayList();
        this.storeLevelScore = new DatabaseHelper(this).getDataOfScoreTable();
        ListView listView = (ListView) findViewById(R.id.lay_sl_list);
        this.levelNames = instance.getLevelString();
        this.tick = MediaPlayer.create(this, R.raw.tick);
        this.levelExist.add(valueOf);
        Object obj = 1;
        for (int i = 1; i < this.levelNames.size(); i++) {
            boolean checkLevelExist = checkLevelExist(Integer.parseInt(((String) this.levelNames.get(i)).split(" ")[1]));
            if (checkLevelExist || obj == null) {
                this.levelExist.add(Boolean.valueOf(checkLevelExist));
            } else {
                obj = null;
                this.levelExist.add(valueOf);
            }
        }
        listView.setAdapter(new SLAdapter(this, this.levelNames, this.levelExist));
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                ShowingLevel.this.tick.start();
                int parseInt = Integer.parseInt(((String) ShowingLevel.this.levelNames.get(i)).split(" ")[1]);
                if (((Boolean) ShowingLevel.this.levelExist.get(i)).booleanValue()) {
                    Intent intent = new Intent(ShowingLevel.this, ShowingQuestion.class);
                    intent.putExtra("level", parseInt);
                    ShowingLevel.this.startActivity(intent);
                    ShowingLevel.this.finish();
                }
            }
        });
    }

    public boolean checkLevelExist(int i) {
        boolean z = false;
        for (int i2 = 0; i2 < this.storeLevelScore.size(); i2++) {
            if (i == ((LevelScore) this.storeLevelScore.get(i2)).getLevel()) {
                z = true;
            }
        }
        return z;
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
