package com.kotlinz.festivalstorymaker.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.Interface.x8;
import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;

public class ColorListAdapter extends RecyclerView.Adapter<ColorListAdapter.MyViewHolder> {

    public Activity activity;
    public ArrayList<Integer> colorList;
    public int SelectedPosition;
    public x8 j;
    public boolean isColor;
    public float l = -1.0f;


    public ColorListAdapter(Activity activity, ArrayList<Integer> arrayList, int position, x8 x8Var, boolean z, int i2) {
        this.activity = activity;
        this.colorList = arrayList;
        this.SelectedPosition = position;
        this.isColor = z;
        this.l = (float) i2;
        this.j = x8Var;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_color_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (this.l != -1.0f) {
            holder.w.getLayoutParams().height = ((int) (this.l / 3.0f)) - 16;
            holder.w.requestLayout();
        }
        holder.t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });
        holder.v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        if (this.colorList.get(SelectedPosition) != null) {
            holder.t.setCardBackgroundColor(((Integer) colorList.get(SelectedPosition)).intValue());
            holder.v.setVisibility(View.GONE);
            SelectedPosition = ((Integer) colorList.get(SelectedPosition)).intValue();
            LinearLayout linearLayout = holder.u;
            if (SelectedPosition == -1) {
                linearLayout.setBackground(activity.getResources().getDrawable(R.drawable.rounded_corner_black_border));
                return;
            } else {
                linearLayout.setBackground(null);
                return;
            }
        }
        holder.u.setBackground(null);
        holder.v.setVisibility(View.VISIBLE);
        holder.t.setCardBackgroundColor(0);

    }

    @Override
    public int getItemCount() {
        return colorList.size();

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public CardView t;
        public LinearLayout u;
        public ImageView v;
        public RelativeLayout w;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.w = (RelativeLayout) itemView.findViewById(R.id.rlMain);
            this.u = (LinearLayout) itemView.findViewById(R.id.cardBgColor);
            this.t = (CardView) itemView.findViewById(R.id.cardColor);
            this.v = (ImageView) itemView.findViewById(R.id.imgPicker);

        }
    }
}
