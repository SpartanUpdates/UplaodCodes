﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace BallCollect
{
    public class PlayerMove : MonoBehaviour
    {
        public static PlayerMove instance;

        public float thrust = 4.2f,intiThrust=0;

        public float forwardSpeed = 4.3f;

        public float roadSize = 2;

        private float zPos = 0, intiSpeed;

        public Rigidbody PRigid;

        private Vector2 lastMousePos;

        private Vector2 deltaPos;

        [HideInInspector]
        public bool isSwapMove = false, isfrontMove = false;

        public Transform cameraTrans;

        private int noCamera = 0;

        bool isBallKick = false;

        public GameObject wing1, wing2, wing3, sizeUpText;

        public int lastPoint = 0;

        private void Awake()
        {
            instance = this;
            isSwapMove = true;
            isfrontMove = false;
            intiSpeed = forwardSpeed;
            PRigid = gameObject.GetComponent<Rigidbody>();
            cameraTrans = Camera.main.transform;
            intiThrust = thrust;
            thrust = 0;
        }
        float maxThrust = 10;
        private void Start()
        {
            maxThrust = 12;
        }
        Vector3 position,position2,eulerAngles,tempCameraPos;

        float num,num2,num3 = 1.8f;
        private void FixedUpdate()
        {
            position = transform.position;
            HandleTouch();
            if (deltaPos != Vector2.zero && isSwapMove && !IsPointerOverUIObject())
            {
                num = Mathf.Abs(100f / (float)Display.main.systemWidth * deltaPos.x * thrust);
                
                if (num > maxThrust)
                {
                    num = maxThrust;
                }

                if (deltaPos.x < 0f)
                {
                    num2 = -num * Time.deltaTime;
                }
                else
                {
                    num2 = num * Time.deltaTime;
                }
               
                if (transform.localScale.x > 0.45f)
                {
                    num3 = roadSize;
                }
                if (-num3 < position.x + num2 && position.x + num2 < num3)
                {
                    position.x += num2;
                }
            }
            
            if (isfrontMove)
            {
                zPos += Time.deltaTime * forwardSpeed;
                position.z = zPos;
                position.z += Time.deltaTime * forwardSpeed;

                cameraTrans.Translate(Vector3.forward * Time.deltaTime * forwardSpeed, Space.World);

                if (noCamera != 0)
                {
                    position2 = cameraTrans.transform.position;
                    eulerAngles = cameraTrans.transform.eulerAngles;

                    if (noCamera < 0 && position2.y > 1.5f)
                    {
                        position2.y += noCamera / 5f;

                        cameraTrans.transform.position = position2;

                        eulerAngles.x = eulerAngles.x + noCamera / 5f;

                        cameraTrans.transform.eulerAngles = eulerAngles;
                    }
                    else if (noCamera > 0 && position2.y < GameController.instance.camStartPos.y + .5f)
                    {
                        position2.y += noCamera / 5f;

                        cameraTrans.transform.position = position2;

                        if(eulerAngles.x <= GameController.instance.camStartRotate.x)
                            eulerAngles.x = eulerAngles.x + noCamera / 4f;

                        cameraTrans.transform.eulerAngles = eulerAngles;
                    }
                    else
                    {
                        if (noCamera > 0)
                        {
                            forwardSpeed = intiSpeed;
                            cameraTrans.transform.eulerAngles = GameController.instance.camStartRotate;
                            tempCameraPos = position;
                            tempCameraPos.x = 0;
                            cameraTrans.transform.position = tempCameraPos + GameController.instance.camStartPos;
                        }
                        noCamera = 0;
                    }
                }
            }

            PRigid.MovePosition(position);

            if (isBallKick)
            {
                KickBalls();
            }
        }
        Vector2 tempMouse;

        List<RaycastResult> results = new List<RaycastResult>();
        private bool IsPointerOverUIObject()
        {
                PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
                tempMouse = Input.mousePosition;
                eventDataCurrentPosition.position = tempMouse;
                EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
                return results.Count > 0;
        }

        [HideInInspector]
        public BallCounter ContiBallCounter;
        private void OnTriggerEnter(Collider other)
        {
            if (!GameController.instance.isGameOver)
            {
                if (other.CompareTag("StageComplete"))
                {
                    other.gameObject.SetActive(false);
                    wing1.SetActive(false);
                    wing2.SetActive(false);
                    wing3.SetActive(false);
                    other.GetComponent<BallCounterCheck>().BallCounter();
                    ContiBallCounter = other.GetComponent<BallCounterCheck>().ballcounter;
                    forwardSpeed = 0;
                    isfrontMove = false;
                    isBallKick = true;
                    Invoke("stopBallKick", 2);
                    GetComponent<Animator>().ResetTrigger("Scale");
                    GetComponent<Animator>().SetTrigger("Reset");
                    return;
                }
                if (other.CompareTag("GoAhead"))
                {
                    other.gameObject.SetActive(false);
                    SoundManger.instance.PlaySound("CheckPoint");
                    Invoke("ContinueLevel", 1);
                    return;
                }
                if (other.name == "InCave")
                {
                    other.gameObject.SetActive(false);
                    forwardSpeed = 20f;
                    noCamera = -1;
                    return;
                }
                if (other.name == "LoadNextLevel")
                {
                    other.gameObject.SetActive(false);
                    GameController.instance.LoadNextLevel();
                    return;
                }
                if (other.name == "OutCave")
                {
                    other.gameObject.SetActive(false);
                    forwardSpeed = intiSpeed;
                    noCamera = 1;
                    return;
                }
                if (other.name == "DestroyLastLevel")
                {
                    other.gameObject.SetActive(false);
                    Destroy(GameController.instance.destroyLevel);
                    return;
                }
                if (other.name == "LevelCompleted")
                {
                    other.gameObject.SetActive(false);
                    GameController.instance.LevelCompleted();
                    Stop();
                    return;
                }
                if (other.CompareTag("Wing"))
                {
                    other.transform.parent.gameObject.SetActive(false);
                    SoundManger.instance.PlaySound("PowerUp");
                    if (GameController.instance.isVibrate)
                        VibrationManager.Haptic(VibrateType.HeavyImpact, false);
                    wing1.SetActive(true);
                    return;
                }
                if (other.CompareTag("Wing2"))
                {
                    other.transform.parent.gameObject.SetActive(false);
                    SoundManger.instance.PlaySound("PowerUp");
                    if (GameController.instance.isVibrate)
                        VibrationManager.Haptic(VibrateType.HeavyImpact, false);
                    wing2.SetActive(true);
                    return;
                }
                if (other.CompareTag("Wing3"))
                {
                    other.transform.parent.gameObject.SetActive(false);
                    SoundManger.instance.PlaySound("PowerUp");
                    if (GameController.instance.isVibrate)
                        VibrationManager.Haptic(VibrateType.HeavyImpact, false);
                    wing3.SetActive(true);
                    return;
                }
                if (other.CompareTag("ScaleUp"))
                {
                    other.transform.parent.gameObject.SetActive(false);
                    SoundManger.instance.PlaySound("PowerUp");
                    if (GameController.instance.isVibrate)
                        VibrationManager.Haptic(VibrateType.HeavyImpact, false);
                    GetComponent<Animator>().SetTrigger("Scale");
                    sizeUpText.SetActive(true);
                    sizeUpText.GetComponent<Animator>().Play("SizeUpText");
                    return;
                }
            }
        }
        public void Stop()
        {
            forwardSpeed = 0;
            isfrontMove = false;
            isSwapMove = false;
            isBallKick = false;
        }

        public void Play()
        {
            forwardSpeed = intiSpeed;
            isfrontMove = true;
            isSwapMove = true;
            isBallKick = false;
            thrust = intiThrust;
        }
        public void stopBallKick()
        {
            isBallKick = false;
        }
        public void ContinueLevel()
        {
            forwardSpeed = intiSpeed;
            isfrontMove = true;
            GameController.instance.pointImage[lastPoint - 1].SetActive(true);
            GetComponent<Animator>().ResetTrigger("Reset");
        }

        Vector2 tempA;
        private void HandleTouch()
        {
            deltaPos = Vector2.zero;
            if (Input.GetMouseButton(0))
            {
                 tempA = Input.mousePosition;
                    if (lastMousePos == Vector2.zero)
                    {
                        lastMousePos = tempA;
                    }
                    deltaPos = tempA - lastMousePos;
                    lastMousePos = tempA;
                    return;
            }
            lastMousePos = Vector2.zero;
        }

        Collider[] array;

        Rigidbody component;
        private void KickBalls()
        {
            float radius = 1.3f;
            array = Physics.OverlapSphere(new Vector3(transform.position.x, 0f, transform.position.z), radius);
            for (int i = 0; i < array.Length; i++)
            {
                component = array[i].GetComponent<Rigidbody>();
                if (component != null)
                {
                    if (component.tag == "Ball")
                    {
                        component.GetComponent<BallControl>().ThrowBall();
                    }
                }
            }
            array = null;
        }
    }
}