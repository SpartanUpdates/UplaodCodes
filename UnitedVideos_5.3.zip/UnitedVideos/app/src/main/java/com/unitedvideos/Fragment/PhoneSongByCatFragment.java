package com.unitedvideos.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.unitedvideos.Adapter.PhoneSongAdapter;
import com.unitedvideos.Model.PhoneSong;
import com.unitedvideos.Model.PhoneSongModel;
import com.unitedvideos.R;
import com.unitedvideos.activity.PhoneSongActivity;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.unitedvideos.activity.PhoneSongActivity.PhoneSongFolders;


public class PhoneSongByCatFragment extends Fragment {

    public List<PhoneSongModel> PhonsSongList;
    public PhoneSong phoneSong;
    Integer Folderid = -1;
    Integer TabIndex = -1;
    RecyclerView rvPhoneSong;
    PhoneSongAdapter mPhonsSongAdp;



    public static Fragment getInstance(int Folderid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        PhoneSongByCatFragment songByCatFragmentent = new PhoneSongByCatFragment();
        songByCatFragmentent.setArguments(bundle);
        return songByCatFragmentent;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phone_song, container, false);
        phoneSong = PhoneSongFolders.getMusicFolders().get(Folderid);
        PhonsSongList = phoneSong.getLocalTracks();
        rvPhoneSong = view.findViewById(R.id.rv_recycler_view);
        mPhonsSongAdp = new PhoneSongAdapter(getContext(), PhonsSongList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvPhoneSong.setLayoutManager(mLayoutManager);
        rvPhoneSong.setItemAnimator(new DefaultItemAnimator());
        this.mPhonsSongAdp.Music(new musicInterface());
        rvPhoneSong.setAdapter(mPhonsSongAdp);
        return view;
    }

    class musicInterface implements PhoneSongAdapter.LocalmusicInterface {

        public void a() {
            ((PhoneSongActivity)getActivity()).Getcontent();

        }

        public void a(PhoneSongModel phoneSongModel, int i) {
            PhoneSongAdapter.FirstSelected = phoneSongModel.a();
            ((PhoneSongActivity)getActivity()).Music(phoneSongModel);
            ((PhoneSongActivity)getActivity()).mediacontroler.f();
            if (rvPhoneSong != null && !rvPhoneSong.isComputingLayout()) {
                mPhonsSongAdp.notifyDataSetChanged();
            }
        }
    }
}
