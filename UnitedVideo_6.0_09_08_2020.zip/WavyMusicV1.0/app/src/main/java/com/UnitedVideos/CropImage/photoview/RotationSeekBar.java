package com.UnitedVideos.CropImage.photoview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.SeekBar;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatSeekBar;


public class RotationSeekBar extends AppCompatSeekBar {
    private static final int DEFAULT_MAX = 3600;
    private static final int DEFAULT_PROGRESS = 1800;
    private OnRotationSeekBarChangeListener mRotationListener;

    public RotationSeekBar(Context context) {
        super(context);
        init();
    }

    public RotationSeekBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RotationSeekBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setMax(3600);
        setProgress(1800);
    }

    public void setOnSeekBarChangeListener(OnSeekBarChangeListener l) {
        if ((l != null) && (!(l instanceof OnRotationSeekBarChangeListener))) {
            throw new IllegalArgumentException("Use OnRotationSeekBarChangeListener");
        }
        mRotationListener = ((OnRotationSeekBarChangeListener) l);
        super.setOnSeekBarChangeListener(l);
    }

    public void setRotationProgress(float rotation) {
        if ((rotation < -180.0F) || (rotation > 180.0F)) {
            throw new IllegalArgumentException("Invalid rotation value");
        }
        if (rotation == 0.0F) {
            reset();
        } else {
            setProgress(fromDegreesToProgress(rotation));
        }
    }

    public float getRotationProgress() {
        return fromProgressToDegrees(getProgress());
    }

    public void reset() {
        init();
        mRotationListener.resetPreviousProgress();
    }

    private static float fromProgressToDegrees(int progress) {
        return (progress - 1800) / 10.0F;
    }

    private static int fromDegreesToProgress(float degrees) {
        return (int) ((degrees + 180.0F) * 10.0F);
    }

    public static abstract class OnRotationSeekBarChangeListener implements OnSeekBarChangeListener {
        private float mPreviousProgress;

        public OnRotationSeekBarChangeListener(@NonNull RotationSeekBar seekBar) {
            mPreviousProgress = seekBar.getProgress();
        }

        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            float angle = RotationSeekBar.fromProgressToDegrees(progress);
            float delta = (progress - mPreviousProgress) / 10.0F;
            onRotationProgressChanged((RotationSeekBar) seekBar, angle, delta, fromUser);
            mPreviousProgress = progress;
        }

        void resetPreviousProgress() {
            mPreviousProgress = 1800.0F;
        }

        public abstract void onRotationProgressChanged(@NonNull RotationSeekBar paramRotationSeekBar, float paramFloat1, float paramFloat2, boolean paramBoolean);

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }
}
