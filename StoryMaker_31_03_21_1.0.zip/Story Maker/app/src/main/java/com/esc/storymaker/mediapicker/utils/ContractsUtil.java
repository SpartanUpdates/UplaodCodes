package com.esc.storymaker.mediapicker.utils;


import com.esc.storymaker.R;

import java.util.LinkedHashMap;

public class ContractsUtil {
    public static LinkedHashMap<Integer, Integer> tabIcons = new LinkedHashMap();

    static {
        tabIcons.put(Integer.valueOf(R.drawable.icon_images_dark_grey), Integer.valueOf(R.drawable.icon_images_grey));
    }
}
