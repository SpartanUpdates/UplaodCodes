package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.ViewTreeObserver;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;

public class CollageMakerFl implements ViewTreeObserver.OnGlobalLayoutListener {
    public final  CollageMakerDetailActivity activity;

    public CollageMakerFl(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.activity = collageMakerDetailActivity;
    }

    public void onGlobalLayout() {
        if (this.activity.flFrameLayout.getViewTreeObserver().isAlive()) {
            this.activity.flFrameLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }
        activity.T = activity.flFrameLayout.getWidth();
        for (int i = 0; i < activity.Images.size(); i++) {
            activity.t0(i);
        }
    }
}
