//package com.mbit.VideoMaker.View;
//
//import android.view.animation.Animation;
//
//public class PopleftInAnimation implements Animation.AnimationListener {
//    public final ExpandableView expandableView;
//
//    public PopleftInAnimation(ExpandableView expandableView) {
//        this.expandableView = expandableView;
//    }
//
//    public void onAnimationEnd(Animation animation) {
//        this.expandableView.n = true;
//        this.expandableView.SetSelectedImage();
//    }
//
//    public void onAnimationRepeat(Animation animation) {
//    }
//
//    public void onAnimationStart(Animation animation) {
//    }
//}