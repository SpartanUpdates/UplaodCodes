package api.natsuite.natcorder;

public abstract class VideoFormat extends MediaFormat1 {
    public static final String MIME_TYPE = "video/avc";
    private static final String KEY_BIT_RATE = "bitrate";
    private static final String KEY_COLOR_FORMAT = "color-format";
    private static final String KEY_FRAME_RATE = "frame-rate";
    private static final String KEY_I_FRAME_INTERVAL = "i-frame-interval";
    public static final String KEY_HEIGHT = "height";
    public static final String KEY_WIDTH = "width";
    private static final String NO_INFO_AVAILABLE = "No info available.";
    private String mimeType;
    private int width;
    private int height;

    public VideoFormat() {
    }

    protected void setVideoCodec(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getVideoCodec() {
        return this.mimeType;
    }

    public void setVideoFrameSize(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public Resolution getVideoFrameSize() {
        return new Resolution(this.width, this.height);
    }

    public int getVideoBitRateInKBytes() {
        try {
            return this.getInteger("bitrate") / 1024;
        } catch (NullPointerException var2) {
            throw new RuntimeException("No info available.");
        }
    }

    public void setVideoBitRateInKBytes(int bitRate) {
        if ((double) (this.width * this.height * 30 * 2) * 7.0E-5D < (double) bitRate) {
            bitRate = (int) ((double) (this.width * this.height * 30 * 2) * 7.0E-5D);
        }

        this.setInteger("bitrate", bitRate * 1024);
    }

    public int getVideoFrameRate() {
        try {
            return this.getInteger("frame-rate");
        } catch (NullPointerException var2) {
            throw new RuntimeException("No info available.");
        }
    }

    public static int setVideoFrameRate(int bitRate) {
        return bitRate;
//        this.setInteger("frame-rate", bitRate);
    }

    public void setVideoIFrameInterval(int iFrameIntervalInSecs) {
        this.setInteger("i-frame-interval", iFrameIntervalInSecs);
    }

    public int getVideoIFrameInterval() {
        try {
            return this.getInteger("i-frame-interval");
        } catch (NullPointerException var2) {
            throw new RuntimeException("No info available.");
        }
    }

    public void setColorFormat(int colorFormat) {
        this.setInteger("color-format", colorFormat);
    }
}
