package com.esc.phoneheart.wrappers;

public class ProcessWrapper {
    public String appname;
    public boolean ischecked;
    public String name;
    public int pid;
    public long size;
    public long sizeshared;
}
