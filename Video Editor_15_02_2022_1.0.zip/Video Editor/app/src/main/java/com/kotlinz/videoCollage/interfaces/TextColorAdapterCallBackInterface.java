package com.kotlinz.videoCollage.interfaces;

public interface TextColorAdapterCallBackInterface {
    void itemClick(int i);
}
