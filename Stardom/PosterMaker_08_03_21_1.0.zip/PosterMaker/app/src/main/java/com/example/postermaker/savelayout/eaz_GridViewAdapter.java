package com.example.postermaker.savelayout;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import com.bumptech.glide.Glide;
import java.io.File;

public class eaz_GridViewAdapter extends BaseAdapter {
    private Context context;
    private File[] fileItems;
    private int[] items;

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    public eaz_GridViewAdapter(Context context, int[] iArr) {
        this.context = context;
        this.items = iArr;
    }

    public eaz_GridViewAdapter(Context context, File[] fileArr) {
        this.context = context;
        this.fileItems = fileArr;
    }

    public int getCount() {
        int[] iArr = this.items;
        if (iArr == null) {
            return this.fileItems.length;
        }
        return iArr.length;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView imageView = new ImageView(this.context);
        imageView.setScaleType(ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new LayoutParams(180, 180));
        RelativeLayout relativeLayout = new RelativeLayout(this.context);
        LayoutParams layoutParams = new LayoutParams(Callback.DEFAULT_DRAG_ANIMATION_DURATION, Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        relativeLayout.setLayoutParams(layoutParams);
        CardView cardView = new CardView(this.context);
        cardView.setLayoutParams(layoutParams);
        cardView.setPadding(5, 5, 5, 5);
        cardView.setForegroundGravity(17);
        cardView.addView(imageView);
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.addView(cardView);
        relativeLayout.setGravity(17);
        if (this.items == null) {
            Glide.with(this.context).load(this.fileItems[i]).into(imageView);
            imageView.setScaleType(ScaleType.CENTER_CROP);
        } else {
            Glide.with(this.context).load(Integer.valueOf(this.items[i])).into(imageView);
        }
        return relativeLayout;
    }
}
