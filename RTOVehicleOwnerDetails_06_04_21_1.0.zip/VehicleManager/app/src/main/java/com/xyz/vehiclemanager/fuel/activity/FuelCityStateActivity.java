package com.xyz.vehiclemanager.fuel.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.activity.MainActivity;
import com.xyz.vehiclemanager.model.CityList;
import com.xyz.vehiclemanager.model.StateList;
import com.xyz.vehiclemanager.model.StateListRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.utils.Utils;

import java.util.ArrayList;

public class FuelCityStateActivity extends AppCompatActivity implements View.OnClickListener {

    private Activity activity = FuelCityStateActivity.this;
    public static String brandId;
    private ImageView iv_back;
    private Button btn_getdetails;
    private Spinner stateListSpinner;
    private Spinner cityListSpinner;
    private ArrayList<String> stateNameList;
    private ArrayList<String> cityNameList;
    private ArrayList<String> cityIdlist;
    private String selectCityId;
    private String cityName;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fuel_city_state);

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        stateNameList = new ArrayList<>();
        cityNameList = new ArrayList<>();
        cityIdlist = new ArrayList<>();

        BindView();
        PutAnalyticsEvent();
        BannerAds();
        DialogAnimation();
        setSpinnerListener();
        if (Utils.isOnline(activity))
        {
            getCarDealerStateList();
        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView()
    {
        iv_back = findViewById(R.id.iv_back);
        stateListSpinner = findViewById(R.id.spinnerstatelist);
        cityListSpinner = findViewById(R.id.spinnercitylist);
        btn_getdetails = findViewById(R.id.btn_get_details);
        iv_back.setOnClickListener(this);
        btn_getdetails.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FuelCityStateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_fuelcitydialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_back:
                onBackPressed();
            break;

            case R.id.btn_get_details:
                Intent intent = new Intent(activity, MainActivity.class);
                intent.putExtra("cityname", cityName);
                intent.putExtra("cityid", selectCityId);
                startActivity(intent);
            break;
        }
    }

    private void setSpinnerListener()
    {
        cityListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectCityId = cityIdlist.get(position);
                cityName = cityNameList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void getCarDealerStateList() {
        Call<StateListRoot> call = rtoDetailsInterface.getCityList();
        call.enqueue(new Callback<StateListRoot>() {
            @Override
            public void onResponse(Call<StateListRoot> call, Response<StateListRoot> response) {
                if (response.isSuccessful())
                {
                    if (dialog !=null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    final ArrayList<StateList> stateLists = response.body().getData();
                    System.out.println(new Gson().toJson(stateLists));
                    for (int i = 0; i < stateLists.size(); i++) {
                        String name = stateLists.get(i).getStateName();
                        stateNameList.add(name);
                    }
                    ArrayAdapter stateAdapter = new ArrayAdapter(activity, R.layout.support_simple_spinner_dropdown_item, stateNameList);
                    stateAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    stateListSpinner.setAdapter(stateAdapter);

                    stateListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            cityNameList.clear();
                            cityIdlist.clear();
                            for (int j = 0; j < stateLists.size(); j++) {
                                ArrayList<CityList> cityLists = stateLists.get(j).getCityLists();
                                for (int k = 0; k < cityLists.size(); k++) {
                                    String stateTwo = cityLists.get(k).getStateName();
                                    String city = cityLists.get(k).getCityName();
                                    String cityid=cityLists.get(k).getCityId();
                                    if (stateTwo.equals(stateListSpinner.getSelectedItem())) {
                                        cityNameList.add(city);
                                        cityIdlist.add(cityid);
                                    }
                                }
                                ArrayAdapter cityAdapter = new ArrayAdapter(activity, R.layout.support_simple_spinner_dropdown_item, cityNameList);
                                cityAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                                cityListSpinner.setAdapter(cityAdapter);
                            }
                        }
                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<StateListRoot> call, Throwable t) {
                if (dialog !=null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed()
    {
       super.onBackPressed();
    }
}