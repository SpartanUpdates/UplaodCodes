package com.esc.uvideostatus.Models;

import java.io.Serializable;

public class VideoData implements Serializable {
    public String catagory;
    public String duration;
    public String likes;
    public String main_url;
    public String real_videopath;
    public String size;
    public String sub_catagory;
    public String thumbnail;
    public String title;
    public String title_search;
    public int type = 1;
    public String url;
    public String vUrl;
    public long video_id;
    public String views;
    public boolean IsNativeAds;

    public VideoData() {
        String str = "";
        this.title = str;
        this.likes = str;
    }

    public String getTitle_search() {
        return this.title_search;
    }

    public void setTitle_search(String str) {
        this.title_search = str;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public String getThumbnail() {
        return this.thumbnail;
    }

    public void setThumbnail(String str) {
        this.thumbnail = str;
    }

    public String getReal_videopath() {
        return this.real_videopath;
    }

    public void setReal_videopath(String str) {
        this.real_videopath = str;
    }

    public String getvUrl() {
        return this.vUrl;
    }

    public void setvUrl(String str) {
        this.vUrl = str;
    }

    public long getVideo_id() {
        return this.video_id;
    }

    public String getMain_url() {
        return this.main_url;
    }

    public void setMain_url(String str) {
        this.main_url = str;
    }

    public void setVideo_id(long j) {
        this.video_id = j;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String str) {
        this.url = str;
    }

    public String getDuration() {
        return this.duration;
    }

    public void setDuration(String str) {
        this.duration = str;
    }

    public String getCatagory() {
        return this.catagory;
    }

    public void setCatagory(String str) {
        this.catagory = str;
    }

    public String getSub_catagory() {
        return this.sub_catagory;
    }

    public void setSub_catagory(String str) {
        this.sub_catagory = str;
    }

    public String getLikes() {
        return this.likes;
    }

    public void setLikes(String str) {
        this.likes = str;
    }

    public String getViews() {
        return this.views;
    }

    public void setViews(String str) {
        this.views = str;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public boolean isNativeAds() {
        return IsNativeAds;
    }

    public void setNativeAds(boolean nativeAds) {
        IsNativeAds = nativeAds;
    }
}
