﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace BallCollect
{
    public class CheckUnlock : MonoBehaviour
    {
        public bool isPlayer = true, isBall = false;

        public int playerNo;

        public GameObject lockImg, unlockImg;

        public bool isFirstPlayer;
        void Start()
        {
            CheckButton();
            if (isPlayer)
            {
                if (playerNo == DataBase.GetPlayer())
                {
                    unlockImg.SetActive(true);
                    PlayerSelection.instance.showPlayer.sprite = transform.GetChild(0).GetComponent<Image>().sprite;
                }
            }
            else if (isBall)
            {
                if (playerNo == DataBase.GetBall())
                {
                    unlockImg.SetActive(true);
                }
            }
        }

        public void CheckButton()
        {
            if (isPlayer)
            {
                if (isFirstPlayer)
                {
                    lockImg.SetActive(false);
                    PlayerPrefs.SetInt("Player1", 1);
                }
                if (PlayerPrefs.GetInt("Player" + playerNo) == 1)
                {
                    lockImg.SetActive(false);
                }
                else
                {
                    lockImg.SetActive(true);
                }
            }
            else if (isBall)
            {
                if (isFirstPlayer)
                {
                    lockImg.SetActive(false);
                    PlayerPrefs.SetInt("Ball1", 1);
                }
                if (PlayerPrefs.GetInt("Ball" + playerNo) == 1)
                {
                    lockImg.SetActive(false);
                }
                else
                {
                    lockImg.SetActive(true);
                }
            }
        }

        public void UnlockImage()
        {
            unlockImg.SetActive(false);
        }
        WaitForSecondsRealtime delay = new WaitForSecondsRealtime(0.1f);
        public IEnumerator UnLockColor()
        {
            lockImg.GetComponent<Image>().color = Color.red;
            yield return delay;
            lockImg.GetComponent<Image>().color = Color.white;
            yield return delay;
            lockImg.GetComponent<Image>().color = Color.red;
            yield return delay;
            lockImg.GetComponent<Image>().color = Color.white;
            yield return delay;
            lockImg.GetComponent<Image>().color = Color.red;
            yield return delay;
            lockImg.GetComponent<Image>().color = Color.white;
            yield return delay;
        }
    }
}