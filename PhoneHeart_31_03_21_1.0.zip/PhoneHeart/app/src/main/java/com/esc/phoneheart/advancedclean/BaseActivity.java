package com.esc.phoneheart.advancedclean;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseActivity extends Activity {
    public static final String TAG = "BaseActivity";
    public List<WeakReference<IPActivityListener>> mActivityResultListeners = new ArrayList();
    public boolean mFirstShow = true;

    public interface IPActivityListener {
        boolean onActivityResult(int i, int i2, Intent intent);

        void onRestart();
    }

    public void addResultListener(IPActivityListener iPActivityListener) {
        ArrayList arrayList = new ArrayList();
        for (WeakReference weakReference : this.mActivityResultListeners) {
            if (weakReference.get() == null) {
                arrayList.add(weakReference);
            } else if (weakReference.get() == iPActivityListener) {
                return;
            }
        }
        arrayList.removeAll(arrayList);
        this.mActivityResultListeners.add(new WeakReference(iPActivityListener));
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        ArrayList arrayList = new ArrayList();
        for (WeakReference weakReference : mActivityResultListeners) {
            if (weakReference.get() == null) {
                arrayList.add(weakReference);
            }
        }
        mActivityResultListeners.removeAll(arrayList);
        for (WeakReference weakReference2 : mActivityResultListeners) {
            IPActivityListener iPActivityListener = (IPActivityListener) weakReference2.get();
            if (iPActivityListener != null) {
                iPActivityListener.onRestart();
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onCreate(Bundle bundle) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreate ");
        stringBuilder.append(getClass().getSimpleName());
        super.onCreate(bundle);
        this.mFirstShow = true;
    }

    public void onRestart() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onRestart ");
        stringBuilder.append(getClass().getSimpleName());
        super.onRestart();
        ArrayList arrayList = new ArrayList();
        for (WeakReference weakReference : this.mActivityResultListeners) {
            if (weakReference.get() == null) {
                arrayList.add(weakReference);
            }
        }
        this.mActivityResultListeners.removeAll(arrayList);
        for (WeakReference weakReference2 : this.mActivityResultListeners) {
            IPActivityListener iPActivityListener = (IPActivityListener) weakReference2.get();
            if (iPActivityListener != null) {
                iPActivityListener.onRestart();
            }
        }
    }
}
