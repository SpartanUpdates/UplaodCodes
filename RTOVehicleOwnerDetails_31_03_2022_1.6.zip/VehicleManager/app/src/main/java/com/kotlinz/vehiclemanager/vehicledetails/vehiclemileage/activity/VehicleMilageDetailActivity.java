package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room.MileageDatabase;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class VehicleMilageDetailActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleMilageDetailActivity.this;
    private ImageView iv_back, iv_home;
    private EditText edt_lastReserve, edt_currentReserve, edt_price, edt_fuel, edt_date;
    private TextInputLayout last_res_lay, current_res_lay, price_lay, fuel_unit_lay;
    private TextView txt_mileageInr, txt_mileageKm, txt_mileageinrLtr, title_tv;
    private Button btn_calculate, btn_save;
    private float getMileageLtr = 0.0f;
    private float getMileageInr = 0.0f;
    private float getMileageinrLtr = 0.0f;
    private String DTmileageKm, DTmileageInr, DTmileageInrLtr;
    private SimpleDateFormat dateFormat;
    private int year;
    private int month;
    private int day;
    private Mileage mileageModel;
    private MileageDatabase mileageDatabase;
    private LinearLayout ll_inputDataLayout;
    private Boolean darkMode = false;


    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_milage_detail);
        LoadNativeAds();
        mileageDatabase = Room.databaseBuilder(VehicleMilageDetailActivity.this, MileageDatabase.class, "MileageDatabase").allowMainThreadQueries().build();
        BindView();
        PutAnalyticsEvent();
        dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        edt_date.setOnClickListener(new DueDateClick(this));
        Calendar instance = Calendar.getInstance();
        day = instance.get(1);
        month = instance.get(Calendar.MONTH);
        year = instance.get(5);
        edt_date.setFocusable(false);
        edt_date.setClickable(true);
        new Handler().postDelayed(new Hndlr(this), 500);
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            darkMode = true;
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(VehicleMilageDetailActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            darkMode = true;
            setupDarkMode();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleMilageDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleMilageDetailActivity.this.nativeAd != null) {
                            VehicleMilageDetailActivity.this.nativeAd.destroy();
                        }
                        VehicleMilageDetailActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }



    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_inputDataLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        edt_currentReserve.setTextColor(Color.parseColor("#FFFFFF"));
        edt_date.setTextColor(Color.parseColor("#FFFFFF"));
        edt_fuel.setTextColor(Color.parseColor("#FFFFFF"));
        edt_lastReserve.setTextColor(Color.parseColor("#FFFFFF"));
        edt_price.setTextColor(Color.parseColor("#FFFFFF"));

        btn_calculate.setTextColor(Color.parseColor("#FFFFFF"));
        btn_save.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        iv_home = findViewById(R.id.iv_home);
        edt_lastReserve = findViewById(R.id.edt_lasrreserve);
        edt_currentReserve = findViewById(R.id.edt_currentreserve);
        edt_price = findViewById(R.id.edt_price);
        edt_fuel = findViewById(R.id.edt_fuel);
        edt_date = findViewById(R.id.edt_date);
        title_tv = findViewById(R.id.title_tv);

        last_res_lay = findViewById(R.id.last_res_lay);
        current_res_lay = findViewById(R.id.current_res_lay);
        price_lay = findViewById(R.id.price_lay);
        fuel_unit_lay = findViewById(R.id.fuel_unit_lay);

        txt_mileageInr = findViewById(R.id.txt_mileageInr);
        txt_mileageKm = findViewById(R.id.txt_mileageKm);
        txt_mileageinrLtr = findViewById(R.id.txt_mileageinrLtr);
        btn_calculate = findViewById(R.id.btn_calculate);
        btn_save = findViewById(R.id.btn_save);

        ll_inputDataLayout = findViewById(R.id.ll_inputDataLayout);

        btn_calculate.setOnClickListener(this);
        btn_save.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        iv_home.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleMilageDetailActivity.this, VehicleMileageActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 37;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleMilageDetailActivity.this, VehicleMileageActivity.class));
                        finish();
                    }
                }
                break;

            case R.id.btn_calculate:
                CalculateData();
                break;

            case R.id.btn_save:
                SaveData();
                break;

            case R.id.iv_home:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleMilageDetailActivity.this, MainActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleMilageDetailActivity.this, MainActivity.class));
                        finish();
                    }
                }
                break;
        }
    }

    private class DueDateClick implements View.OnClickListener {
        VehicleMilageDetailActivity vehicleMilageDetailActivity;

        class DateSet implements DatePickerDialog.OnDateSetListener {
            DueDateClick DueDateClick;

            public DateSet(DueDateClick dueDateClick) {
                DueDateClick = dueDateClick;
            }

            public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                Calendar instance = Calendar.getInstance();
                instance.set(i, i2, i3);
                DueDateClick.vehicleMilageDetailActivity.edt_date.setText(DueDateClick.vehicleMilageDetailActivity.dateFormat.format(instance.getTime()));
            }
        }

        public DueDateClick(VehicleMilageDetailActivity vehicleMilageDetailActivity) {
            this.vehicleMilageDetailActivity = vehicleMilageDetailActivity;
        }

        @SuppressLint({"WrongConstant"})
        public void onClick(View view) {
            Calendar instance = Calendar.getInstance();
            new DatePickerDialog(vehicleMilageDetailActivity, new DateSet(this), instance.get(1), instance.get(2), instance.get(5)).show();
        }
    }

    private void DateFormat(int i, int i2, int i3) {
        Date parse;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d/yyyy");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i2 + 1);
            stringBuilder.append("/");
            stringBuilder.append(i3);
            stringBuilder.append("/");
            stringBuilder.append(i);
            parse = simpleDateFormat.parse(String.valueOf(stringBuilder));
        } catch (ParseException e) {
            e.printStackTrace();
            parse = null;
        }
        edt_date.setText(new SimpleDateFormat("dd-MM-yyyy").format(parse));
    }

    class Hndlr implements Runnable {
        VehicleMilageDetailActivity vehicleMilageDetailActivity;

        public Hndlr(VehicleMilageDetailActivity vehicleMilageDetailActivity) {
            this.vehicleMilageDetailActivity = vehicleMilageDetailActivity;
        }

        public void run() {
            vehicleMilageDetailActivity.DateFormat(day, month, year);
        }
    }

    private void CalculateData() {
        String sLastReserve = edt_lastReserve.getText().toString().trim();
        String sCurrentReserve = edt_currentReserve.getText().toString().trim();
        String sPrice = edt_price.getText().toString().trim();
        String sFuel = edt_fuel.getText().toString().trim();
        String sDate = edt_date.getText().toString().trim();

        if (LstRes() && PrcText() && FuelText() && CurRes() && Value()) {
            btn_save.setEnabled(true);

            getMileageLtr = Float.parseFloat(sCurrentReserve) - Float.parseFloat(sLastReserve);
            getMileageLtr = getMileageLtr / Float.parseFloat(sFuel);
            DecimalFormat df = new DecimalFormat();
            df.setMaximumFractionDigits(2);
            txt_mileageInr.setText(df.format(getMileageLtr) + " Km/ltr");
            DTmileageKm = df.format(getMileageLtr);

            getMileageInr = Float.parseFloat(sCurrentReserve) - Float.parseFloat(sLastReserve);
            getMileageInr = Float.parseFloat(sPrice) / getMileageInr;
            DecimalFormat df2 = new DecimalFormat();
            df2.setMaximumFractionDigits(2);
            txt_mileageKm.setText(df2.format(getMileageInr) + " Rs/km");
            DTmileageInr = df2.format(getMileageInr);

            getMileageinrLtr = Float.parseFloat(sPrice) / Float.parseFloat(sFuel);
            DecimalFormat df3 = new DecimalFormat();
            df3.setMaximumFractionDigits(2);
            txt_mileageinrLtr.setText(df3.format(getMileageinrLtr) + " Rs/ltr");
            DTmileageInrLtr = df3.format(getMileageinrLtr);
        }
    }

    private void SaveData() {
        String sLastReserve = edt_lastReserve.getText().toString().trim();
        String sCurrentReserve = edt_currentReserve.getText().toString().trim();
        String sPrice = edt_price.getText().toString().trim();
        String sFuel = edt_fuel.getText().toString().trim();
        String sDate = edt_date.getText().toString().trim();

        String sMileageKm = String.valueOf(getMileageLtr);
        String sMileageInr = String.valueOf(getMileageInr);
        String sMileageInrLtr = String.valueOf(getMileageinrLtr);

        btn_save.setEnabled(false);

        if ((!sLastReserve.isEmpty() && !sCurrentReserve.isEmpty() && !sPrice.isEmpty() && !sFuel.isEmpty() && !sDate.isEmpty() && !sMileageKm.isEmpty() && !sMileageInr.isEmpty() && !sMileageInrLtr.isEmpty())) {
            Thread thread = new Thread(new Runnable() {
                public void run() {
                    mileageModel = new Mileage(edt_lastReserve.getText().toString(), edt_currentReserve.getText().toString(), edt_price.getText().toString(), edt_fuel.getText().toString(), edt_date.getText().toString(), new DecimalFormat("##.##").format((double) getMileageLtr), new DecimalFormat("##.##").format((double) getMileageInr), new DecimalFormat("##.##").format((double) getMileageinrLtr));
                    mileageDatabase.mileageDao().insertMileageData(mileageModel);
                    startActivity(new Intent(VehicleMilageDetailActivity.this, VehicleMileageActivity.class));
                }
            });
            thread.start();
            Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG);
        } else {
            Toast.makeText(VehicleMilageDetailActivity.this, "First of all you have to calculate the mileage !!", Toast.LENGTH_LONG).show();
        }
    }

    private boolean LstRes() {
        if (this.edt_lastReserve.getText().toString().trim().isEmpty()) {
            TextInputLayout textInputLayout = this.last_res_lay;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.error_last_kms));
            stringBuilder.append(" ");
            stringBuilder.append(getString(R.string.KM_UNIT));
            textInputLayout.setError(stringBuilder.toString());
            SetText(this.edt_lastReserve);
            return false;
        }
        this.current_res_lay.setErrorEnabled(false);
        return true;
    }

    private boolean PrcText() {
        if (this.edt_price.getText().toString().trim().isEmpty()) {
            this.price_lay.setError(getString(R.string.error_price));
            SetText(this.edt_price);
            return false;
        }
        this.price_lay.setErrorEnabled(false);
        return true;
    }

    private boolean FuelText() {
        if (this.edt_fuel.getText().toString().trim().isEmpty()) {
            this.fuel_unit_lay.setError(getString(R.string.error_fuel));
            SetText(this.edt_fuel);
            return false;
        }
        this.fuel_unit_lay.setErrorEnabled(false);
        return true;
    }

    private boolean CurRes() {
        if (this.edt_currentReserve.getText().toString().trim().isEmpty()) {
            TextInputLayout textInputLayout = this.current_res_lay;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.error_current_kms));
            stringBuilder.append(" ");
            stringBuilder.append(getString(R.string.KM_UNIT));
            textInputLayout.setError(stringBuilder.toString());
            SetText(this.edt_currentReserve);
            return false;
        }
        this.current_res_lay.setErrorEnabled(false);
        return true;
    }

    private boolean Value() {
        float parseFloat;
        float f = 0.0f;
        try {
            parseFloat = Float.parseFloat(this.edt_currentReserve.getText().toString().trim());
        } catch (Exception e) {
            e.printStackTrace();
            parseFloat = 0.0f;
        }
        try {
            f = Float.parseFloat(this.edt_lastReserve.getText().toString().trim());
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (f >= parseFloat) {
            this.current_res_lay.setError(getString(R.string.error_current_kms_value));
            SetText(this.edt_currentReserve);
            return false;
        }
        this.current_res_lay.setErrorEnabled(false);
        return true;
    }

    private void SetText(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(5);
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(VehicleMilageDetailActivity.this, VehicleMileageActivity.class));
        finish();
    }
}