package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.HighlightFrameListAdapter;

public class o implements View.OnClickListener {
    public final int n;
    public final HighlightFrameListAdapter o;

    public    o(HighlightFrameListAdapter highlightFrameListAdapter, int i) {
        this.o = highlightFrameListAdapter;
        this.n = i;
    }

    public void onClick(View view) {
        HighlightFrameListAdapter highlightFrameListAdapter = this.o;
        highlightFrameListAdapter.r.a(this.n, highlightFrameListAdapter.s);
    }
}
