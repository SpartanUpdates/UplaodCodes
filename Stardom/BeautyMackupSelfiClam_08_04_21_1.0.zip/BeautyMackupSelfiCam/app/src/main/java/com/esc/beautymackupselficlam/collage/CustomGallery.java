package com.esc.beautymackupselficlam.collage;

public class CustomGallery
{
  public boolean isSeleted;
  public String sdcardPath;

  public CustomGallery() {
    this.isSeleted = false;
  }
}
