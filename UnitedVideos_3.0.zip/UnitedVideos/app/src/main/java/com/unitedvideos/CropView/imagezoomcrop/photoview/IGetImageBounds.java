package com.unitedvideos.CropView.imagezoomcrop.photoview;

import android.graphics.Rect;

public abstract interface IGetImageBounds
{
  public abstract Rect getImageBounds();
}
