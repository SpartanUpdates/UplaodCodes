package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class j5  implements View.OnClickListener {
    public final  FestivalDetailActivity_New n;

    public j5(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    public void onClick(View view) {
        this.n.K0();
    }

}
