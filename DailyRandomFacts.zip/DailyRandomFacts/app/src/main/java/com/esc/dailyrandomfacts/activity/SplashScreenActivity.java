package com.esc.dailyrandomfacts.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.google.gson.Gson;
import com.esc.dailyrandomfacts.util.AppUtils;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.CategoryManager;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.model.Information;
import com.esc.dailyrandomfacts.model.Pref;
import com.esc.dailyrandomfacts.util.Constants;
import com.esc.dailyrandomfacts.util.TrackerEventUtils;
import com.esc.dailyrandomfacts.util.Utils;
import com.esc.dailyrandomfacts.reminders.RemindersUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class SplashScreenActivity extends BaseActivity {


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        checkDate();
        saveLanguage();
        Utils.systemUpgrade(this);
        AppUtils.hasSoftKeys(this);
        showDefaultStart();
    }

    @SuppressLint("WrongConstant")
    private void showDefaultStart() {
        String str = "1";
        if (Pref.getValue(this, Constants.IS_SLIDER_ON, str).equals(str)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                RemindersUtils.setAlarmOnTime(this);
            }
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreenActivity.this, HomeActivity.class));
                finish();
            }
        }, 2000);
    }

    public void onResume() {
        super.onResume();
    }

    private void checkDate() {
        String dateOpen = SettingsManager.getDateOpen();
        if (dateOpen == null) {
            SettingsManager.setDateOpen(getCurrentDate());
            return;
        }
        if (getDaysBetweenDates(dateOpen) > 14) {
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_14_DAY, null, null);
        } else if (getDaysBetweenDates(dateOpen) >= 1) {
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_1_DAY, null, null);
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_1_DAY_MIXPANEL, null, null);
        }
        SettingsManager.setDateOpen(getCurrentDate());
    }

    private String getCurrentDate() {
        return new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
    }

    private int getDaysBetweenDates(String str) {
        try {
            return (int) TimeUnit.DAYS.convert(new Date().getTime() - new SimpleDateFormat("dd-MM-yyyy").parse(str).getTime(), TimeUnit.MILLISECONDS);
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private void saveLanguage() {
        if (SettingsManager.isLanguageFirstTime()) {
            String str = "es";
            String str2 = "_es";
            if (Locale.getDefault().getLanguage().equals(str)) {
                SettingsManager.setLanguage(str);
                if (!CategoryManager.getCategorySelected().contains(str2)) {
                    resetCategory();
                }
            } else {
                SettingsManager.setLanguage("en");
                if (CategoryManager.getCategorySelected().contains(str2)) {
                    resetCategory();
                }
            }
            updateLocale(new Locale(SettingsManager.getLanguage()));
            SettingsManager.setLanguageFirstTime();
        }
    }

    private void resetCategory() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.default_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        CategoryManager.setCategorySelected(stringBuilder.toString());
        Information informationJson = getInformationJson();
        CategoryManager.clearCategoriesReminder();
        CategoryManager.addCategoryReminder(informationJson.getCategories().get(0));
    }

    public Information getInformationJson() {
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("information");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            stringBuilder.append(".json");
            InputStream open = assets.open(stringBuilder.toString());
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                return new Gson().fromJson(new String(bArr, StandardCharsets.UTF_8), Information.class);
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
        return null;
    }
}
