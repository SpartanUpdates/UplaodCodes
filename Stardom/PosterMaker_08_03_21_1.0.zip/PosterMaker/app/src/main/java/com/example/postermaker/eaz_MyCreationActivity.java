package com.example.postermaker;

import android.Manifest;
import android.app.Dialog;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.ArrayList;

public class eaz_MyCreationActivity extends AppCompatActivity {
    public static ArrayList<String> IMAGEALLARY = new ArrayList();
    public static int pos;
    private LinearLayout adView;

    private eaz_GalleryAdapter eazGalleryAdapter;
    private GridView gridView;
    ImageView imageView;


    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView((int) R.layout.eaz_activity_my_creation);
        getWindow().setFlags(1024, 1024);


        ((TextView) findViewById(R.id.toolbar_title)).setText("My Creation");

        imageView=(ImageView) findViewById(R.id.img_back);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        gridView = (GridView) findViewById(R.id.gridview);

        eazGalleryAdapter = new eaz_GalleryAdapter(this, IMAGEALLARY);
        IMAGEALLARY.clear();

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        stringBuilder.append("/Poster Maker");
        listAllImages(new File(stringBuilder.toString()));

        gridView.setAdapter(this.eazGalleryAdapter);

        this.gridView.setOnItemClickListener(new OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                eaz_MyCreationActivity.this.eazGalleryAdapter.getItemId(i);
                eaz_MyCreationActivity.pos = i;
                Dialog dialog = new Dialog(eaz_MyCreationActivity.this);
                DisplayMetrics displayMetrics = new DisplayMetrics();
                eaz_MyCreationActivity.this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                double d = (double) displayMetrics.heightPixels;
                Double.isNaN(d);
                i = (int) (d * 1.0d);
                double d2 = (double) displayMetrics.widthPixels;
                Double.isNaN(d2);
                int i2 = (int) (d2 * 1.0d);
                dialog.requestWindowFeature(1);
                dialog.getWindow().setFlags(1024, 1024);
                dialog.setContentView(R.layout.eaz_activity_full_screen_view);
                dialog.getWindow().setLayout(i2, i);
                dialog.setCanceledOnTouchOutside(true);
                ((ImageView) dialog.findViewById(R.id.iv_image)).setImageURI(Uri.parse((String) eaz_MyCreationActivity.IMAGEALLARY.get(eaz_MyCreationActivity.pos)));
                dialog.show();
            }
        });
    }

    private void listAllImages(File file)
    {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == -1)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 20);
        }
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (int length = listFiles.length - 1; length >= 0; length--)
            {
                String file2 = listFiles[length].toString();
                File file3 = new File(file2);
                StringBuilder stringBuilder = new StringBuilder();
                String str = "";
                stringBuilder.append(str);
                stringBuilder.append(file3.length());
                String stringBuilder2 = stringBuilder.toString();
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str);
                stringBuilder3.append(file3.length());
                Log.d(stringBuilder2, stringBuilder3.toString());
                if (file3.length() <= PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID) {
                    Log.e("Invalid Image", "Delete Image");
                } else if (file3.toString().contains(".jpg") || file3.toString().contains(".png") || file3.toString().contains(".jpeg")) {
                    IMAGEALLARY.add(file2);
                }
                System.out.println(file2);
            }
            return;
        }
        System.out.println("Empty Folder");
    }

    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if (menuItem.getItemId() == 16908332)
        {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private boolean isOnline()
    {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
