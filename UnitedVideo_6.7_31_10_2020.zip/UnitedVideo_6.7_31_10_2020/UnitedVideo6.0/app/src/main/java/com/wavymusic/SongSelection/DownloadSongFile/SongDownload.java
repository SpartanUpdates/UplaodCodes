package com.wavymusic.SongSelection.DownloadSongFile;


import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.SpeedCalculator;
import com.liulishuo.okdownload.StatusUtil;
import com.liulishuo.okdownload.core.Util;
import com.liulishuo.okdownload.core.breakpoint.BlockInfo;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.listener.DownloadListener4WithSpeed;
import com.liulishuo.okdownload.core.listener.assist.Listener4SpeedAssistExtend;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.SongSelection.Model.SongModel;
import com.wavymusic.SongSelection.View.DonutProgress;

import java.io.File;
import java.util.List;
import java.util.Map;


public class SongDownload {
    public static DownloadTask SongDownloadTask;
    private Context context;
    ImageView ivDownload;
    LinearLayout layoutUseSong;
    DonutProgress dpSpongProgress;
    SongModel onlineSongModel;
    private String AudioName;

    public SongDownload(Context context, String AudioUrl, String AudioName, int Audiosize, ImageView ivDownload, DonutProgress dpSongProgress, LinearLayout layoutUseSong, SongModel onlineSongModel) {
        this.context = context;
        this.AudioName = AudioName;
        this.onlineSongModel = onlineSongModel;
        this.ivDownload = ivDownload;
        this.dpSpongProgress = dpSongProgress;
        this.layoutUseSong = layoutUseSong;
//        String filename = AudioUrl.substring(AudioUrl.lastIndexOf('/') + 1);
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + "Online Song" + File.separator + AudioName).exists()) {
            File file = new File(Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + "Online Song" + File.separator + AudioName);
            int filesize = Integer.parseInt(String.valueOf(file.length()));
            if (filesize == Audiosize) {
            } else {
                initTaskSong(AudioUrl);
                initStatusSong();
                initActionSong();
            }
        } else {
            initTaskSong(AudioUrl);
            initStatusSong();
            initActionSong();
        }
    }

    private void initTaskSong(String URL) {
        onlineSongModel.isDownloading = true;
        onlineSongModel.isAvailableOffline = false;
        final File parentFile = new File(Environment.getExternalStorageDirectory() + File.separator + "United Videos" + File.separator + "Online Song");
        SongDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(AudioName)
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();
    }

    private void initStatusSong() {
        final StatusUtil.Status status = StatusUtil.getStatus(SongDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
        }

        final BreakpointInfo info = StatusUtil.getCurrentInfo(SongDownloadTask);
        if (info != null) {
            Log.d("TAG", "Song init status with: " + info.toString());
        }
    }

    private void initActionSong() {
        final boolean started = SongDownloadTask.getTag() != null;
        if (started) {
            SongDownloadTask.cancel();
        } else {
            startTask();
            SongDownloadTask.setTag("mark-SongDownloadTask-started");
        }
    }

    private void startTask() {
        SongDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
                dpSpongProgress.setProgress(percentage);
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    onlineSongModel.isDownloading = false;
                    onlineSongModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    onlineSongModel.isDownloading = false;
                    onlineSongModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + task.getFilename());
                }
                if (AudioName.equals(task.getFilename())) {
                    if (cause == EndCause.COMPLETED) {
                        onlineSongModel.isDownloading = false;
                        onlineSongModel.isAvailableOffline = true;
                        ivDownload.setVisibility(View.GONE);
                        dpSpongProgress.setVisibility(View.GONE);
                        layoutUseSong.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
