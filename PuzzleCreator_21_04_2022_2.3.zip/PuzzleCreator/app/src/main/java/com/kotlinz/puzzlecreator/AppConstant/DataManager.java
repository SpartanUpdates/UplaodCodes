package com.kotlinz.puzzlecreator.AppConstant;

public class DataManager {
    public static final String reviewer = "reviewer";
    public static final String creator = "creator";
    public static final String high_hint_point = "15";
    public static final String medium_hint_point = "10";
    public static final String low_hint_point = "5";

    public static final String high_point = "15";
    public static final String medium_point = "10";
    public static final String low_point = "5";

    public static final String high_ans_point = "15";
    public static final String medium_ans_point = "10";
    public static final String low_ans_point = "5";

    public static final String threshold_point = "2000";
    // public static final String server_url ="shorturl.at/emuC5";
    public static final String server_url = "http://puzzleplatform.trendinganimations.com/";
//    public static final int NoOfNative = 5;
}
