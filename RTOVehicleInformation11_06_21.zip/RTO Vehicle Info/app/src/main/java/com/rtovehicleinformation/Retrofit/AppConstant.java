package com.rtovehicleinformation.Retrofit;

public class AppConstant {
    public static String BASEURL = "https://www.tradetu.com/bus_api/public/api/v1/vaahan/";
}
