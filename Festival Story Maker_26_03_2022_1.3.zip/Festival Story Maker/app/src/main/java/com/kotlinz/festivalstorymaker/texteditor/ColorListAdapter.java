package com.kotlinz.festivalstorymaker.texteditor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ColorListAdapter extends RecyclerView.Adapter<ColorListAdapter.ViewHolder> {

    public String[] colorList;
    public a h;
    public int SelectedPosition;

    public interface a {
        void D(final int p0);
    }

    public ColorListAdapter(final Activity activity, final String[] g, final a h, final int i) {
        this.colorList = g;
        this.h = h;
        this.SelectedPosition = i;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_text_editor_color_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.imgSelected.setVisibility(SelectedPosition == position ? View.VISIBLE : View.GONE);
//        holder.card.setCardBackgroundColor(Color.parseColor(this.g[position]));
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                h.D(position);
                notifyDataSetChanged();
            }
        });


    }

    @Override
    public int getItemCount() {
        return colorList.length;

    }

    public void k(final int i) {
        SelectedPosition = i;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView( R.id.card)
        public CardView card;
        @BindView(R.id.imgSelected)
        public ImageView imgSelected;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
