package com.xyz.vehiclemanager.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.xyz.vehiclemanager.AppUpdate.Constants;
import com.xyz.vehiclemanager.AppUpdate.InAppUpdateManager;
import com.xyz.vehiclemanager.AppUpdate.InAppUpdateStatus;
import com.xyz.vehiclemanager.NativeAds.nativeads;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.activity.BikeBrandActivity;
import com.xyz.vehiclemanager.bikedetails.bikeaccesories.activity.BikeAccessoriesBrandActvity;
import com.xyz.vehiclemanager.bikedetails.bikedealer.activity.BikeDealerActivity;
import com.xyz.vehiclemanager.bikedetails.bikeservice.activity.BikeServiceActivity;
import com.xyz.vehiclemanager.car.activity.CarBrandActivity;
import com.xyz.vehiclemanager.cardetails.caraccessories.activity.CarAccessoriesBrandActivity;
import com.xyz.vehiclemanager.cardetails.cardealer.activity.CarDealerActivity;
import com.xyz.vehiclemanager.cardetails.carservice.activity.CarServiceActivity;
import com.xyz.vehiclemanager.famousperson.activity.FamousPersonListActivity;
import com.xyz.vehiclemanager.fuel.activity.FuelCityStateActivity;
import com.xyz.vehiclemanager.fuel.model.FuelCity;
import com.xyz.vehiclemanager.fuel.model.FuelCityRoot;
import com.xyz.vehiclemanager.history.Activity.HistoryTabLayoutActivity;
import com.xyz.vehiclemanager.kprogresshud.KProgressHUD;
import com.xyz.vehiclemanager.permission.PermissionModel;
import com.xyz.vehiclemanager.preference.EPreferences;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity.RtoOfficeInfoActivity;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoQuestionActivity;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtotrafficsignals.activity.RtoTrafficSignalsActivity;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.activity.RtoOwnerDetailActivity;
import com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.activity.VehicleLicenseActivity;
import com.xyz.vehiclemanager.utils.Utils;
import com.xyz.vehiclemanager.vehicledetails.vehicleexpense.activity.VehicleExpenseActivity;
import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.activity.VehicleMileageActivity;

import static android.os.Build.VERSION.SDK_INT;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, InAppUpdateManager.InAppUpdateHandler {

    Activity activity = MainActivity.this;
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private Toolbar toolbar;
    private TextView tv_city, tv_state, tv_petrolprice, tv_petrodiff, tv_dieselprice, tv_dieseldiff;
    private Button btn_changeCity;
    private LinearLayout ll_ownerInfo, ll_vehicleLicense, ll_carService, ll_carDealer, ll_carAccesories, ll_bikeService,
            ll_bikeDealer, ll_bikeAccesories, ll_rtoQuestion, ll_rtotrafficSignals, ll_rtoofficeInfo,
            ll_vehicleExpense, ll_vehicleMileage, ll_car, ll_bike, ll_fuel;
    private LinearLayout ll_MrPerfect, ll_dancer, ll_actor, ll_politician, ll_sportsmen, ll_actress, ll_singer;
    private String cityId, cityName;
    private RtoDetailsInterface rtoDetailsInterface;
    private LinearLayout ll_progress;

    //App Update
    private static final int REQ_CODE_VERSION_UPDATE = 530;
    private InAppUpdateManager inAppUpdateManager;

    private KProgressHUD hud;
    public InterstitialAd mInterstitialAd;
    private int id;

    private UnifiedNativeAd nativeAd;

    EPreferences ePref;


    class Navigation implements NavigationView.OnNavigationItemSelectedListener {
        Navigation() {

        }

        public boolean onNavigationItemSelected(MenuItem item) {
            drawerLayout.closeDrawers();
            switch (item.getItemId()) {
                case R.id.menu_share:
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.share_msg) + getPackageName());
                    startActivity(Intent.createChooser(share, "Share Via"));
                    return true;
                case R.id.menu_rateus:
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse(getResources().getString(R.string.rate_us_url)
                                        + getPackageName())));
                        return true;
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "You don't have Google Play installed",
                                Toast.LENGTH_SHORT).show();
                        return true;
                    }

                case R.id.menu_feedback:
                    Intent feedback = new Intent(Intent.ACTION_SEND);
                    feedback.setType("message/rfc822");
                    feedback.putExtra(Intent.EXTRA_EMAIL, new String[]{getResources().getString(R.string.feedback_email)});
                    feedback.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                    feedback.setPackage("com.google.android.gm");
                    if (feedback.resolveActivity(getPackageManager()) != null)
                        startActivity(feedback);
                    else
                        Toast.makeText(MainActivity.this, "Gmail App is not installed", Toast.LENGTH_SHORT).show();
                    return true;

                case R.id.menu_privacy:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy_url)));
                        startActivity(intent1);
                        return true;
                    } catch (Exception e) {
                        return true;
                    }

                default:
                    return false;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ePref = EPreferences.getInstance((Context) this);
        Intent intent = getIntent();
        cityName = intent.getStringExtra("cityname");
        cityId = intent.getStringExtra("cityid");

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        inAppUpdateManager = InAppUpdateManager.Builder(this, REQ_CODE_VERSION_UPDATE).resumeUpdates(true).mode(Constants.UpdateMode.FLEXIBLE).handler(this);
        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {

            }
        });

        BindView();
        PutAnalyticsEvent();
        interstitialAd();

        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new Navigation());
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayout);

        drawerToggle = new ActionBarDrawerToggle(this, this.drawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close);
        drawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
        this.drawerLayout.setDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        drawerToggle.setDrawerIndicatorEnabled(false);
        drawerToggle.setHomeAsUpIndicator(R.drawable.ic_drawer_menu);


        if (cityId == null) {
            cityId = "51";
        }

        if (cityName == null) {
            cityName = "Ahmedabad";
        }

        if (Utils.isOnline(MainActivity.this)) {
            getFuelPrice();
        } else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
        requestPermission();
    }


    private void requestPermission() {
        PermissionModel.checkPermission(this);
    }


    private void BindView() {
        ll_progress = findViewById(R.id.ll_progress);
        ll_fuel = findViewById(R.id.ll_fuel);
        btn_changeCity = findViewById(R.id.btn_changecity);
        tv_city = findViewById(R.id.tv_city);
        tv_state = findViewById(R.id.tv_state);
        tv_petrolprice = findViewById(R.id.tv_petrolprice);
        tv_dieselprice = findViewById(R.id.tv_dieselprice);
        tv_petrodiff = findViewById(R.id.tv_petrodiff);
        tv_dieseldiff = findViewById(R.id.tv_dieseldiff);

        ll_ownerInfo = findViewById(R.id.ll_ownerInfo);
        ll_vehicleLicense = findViewById(R.id.ll_vehicleLicense);
        ll_carService = findViewById(R.id.ll_carService);
        ll_carDealer = findViewById(R.id.ll_carDealer);
        ll_carAccesories = findViewById(R.id.ll_carAccesories);
        ll_bikeService = findViewById(R.id.ll_bikeService);
        ll_bikeDealer = findViewById(R.id.ll_bikeDealer);
        ll_bikeAccesories = findViewById(R.id.ll_bikeAccesories);
        ll_rtoQuestion = findViewById(R.id.ll_rtoQuestion);
        ll_rtotrafficSignals = findViewById(R.id.ll_rtotrafficSignals);
        ll_rtoofficeInfo = findViewById(R.id.ll_rtoofficeInfo);
        ll_vehicleExpense = findViewById(R.id.ll_vehicleExpense);
        ll_vehicleMileage = findViewById(R.id.ll_vehicleMileage);
        ll_MrPerfect = findViewById(R.id.ll_MrPerfect);
        ll_dancer = findViewById(R.id.ll_dancer);
        ll_singer = findViewById(R.id.ll_singer);
        ll_actor = findViewById(R.id.ll_actor);
        ll_actress = findViewById(R.id.ll_actress);
        ll_sportsmen = findViewById(R.id.ll_sportsmen);
        ll_politician = findViewById(R.id.ll_politician);
        ll_car = findViewById(R.id.ll_car);
        ll_bike = findViewById(R.id.ll_bike);

        btn_changeCity.setOnClickListener(this);
        ll_ownerInfo.setOnClickListener(this);
        ll_vehicleLicense.setOnClickListener(this);
        ll_carService.setOnClickListener(this);
        ll_carDealer.setOnClickListener(this);
        ll_carAccesories.setOnClickListener(this);
        ll_bikeService.setOnClickListener(this);
        ll_bikeDealer.setOnClickListener(this);
        ll_bikeAccesories.setOnClickListener(this);
        ll_vehicleExpense.setOnClickListener(this);
        ll_vehicleMileage.setOnClickListener(this);
        ll_rtoofficeInfo.setOnClickListener(this);
        ll_rtoQuestion.setOnClickListener(this);
        ll_rtotrafficSignals.setOnClickListener(this);
        ll_bikeAccesories.setOnClickListener(this);
        ll_MrPerfect.setOnClickListener(this);
        ll_singer.setOnClickListener(this);
        ll_dancer.setOnClickListener(this);
        ll_politician.setOnClickListener(this);
        ll_actress.setOnClickListener(this);
        ll_actor.setOnClickListener(this);
        ll_sportsmen.setOnClickListener(this);
        ll_bike.setOnClickListener(this);
        ll_car.setOnClickListener(this);
    }


    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 101:
                        OwnerInfo();
                        break;
                    case 102:
                        VehicleLicense();
                        break;
                    case 103:
                        RtotrafficSignals();
                        break;
                    case 104:
                        RtoQuestion();
                        break;
                    case 105:
                        RtoOfficeInfoA();
                        break;
                    case 106:
                        VehicleExpense();
                        break;
                    case 107:
                        VehicleMileage();
                        break;
                    case 108:
                        CarService();
                        break;
                    case 109:
                        CarDealer();
                        break;
                    case 110:
                        CarAccessories();
                        break;
                    case 111:
                        BikeService();
                        break;
                    case 112:
                        BikeDealer();
                        break;
                    case 113:
                        BikeAccessoriesBrand();
                        break;
                    case 114:
                        FamousPerson("Mr.Perfect");
                        break;
                    case 115:
                        FamousPerson("Dancers");
                        break;
                    case 116:
                        FamousPerson("Singers");
                        break;
                    case 117:
                        FamousPerson("Actors");
                        break;
                    case 118:
                        FamousPerson("Politicians");
                        break;
                    case 119:
                        FamousPerson("Sports Person");
                        break;
                    case 120:
                        FamousPerson("Actresses");
                        break;
                    case 121:
                        CarBrand();
                        break;
                    case 122:
                        BikeBrand();
                        break;
                }
                RequestInterstitial();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_changecity:
                startActivity(new Intent(new Intent(MainActivity.this, FuelCityStateActivity.class)));
                break;

            case R.id.ll_ownerInfo:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    OwnerInfo();
                }
                break;

            case R.id.ll_vehicleLicense:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 102;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    VehicleLicense();
                }
                break;
            case R.id.ll_rtotrafficSignals:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 103;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    RtotrafficSignals();
                }
                break;

            case R.id.ll_rtoQuestion:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 104;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    RtoQuestion();
                }
                break;

            case R.id.ll_rtoofficeInfo:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 105;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    RtoOfficeInfoA();
                }
                break;

            case R.id.ll_vehicleExpense:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 106;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    VehicleExpense();
                }
                break;

            case R.id.ll_vehicleMileage:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 107;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    VehicleMileage();
                }
                break;

            case R.id.ll_carService:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 108;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    CarService();
                }
                break;

            case R.id.ll_carDealer:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 109;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    CarDealer();
                }
                break;

            case R.id.ll_carAccesories:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 110;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    CarAccessories();
                }
                break;

            case R.id.ll_bikeService:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 111;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    BikeService();
                }
                break;

            case R.id.ll_bikeDealer:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 112;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    BikeDealer();
                }
                break;

            case R.id.ll_bikeAccesories:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 113;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    BikeAccessoriesBrand();
                }
                break;

            case R.id.ll_MrPerfect:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 114;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Mr.Perfect");
                }
                break;

            case R.id.ll_dancer:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 115;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Dancers");
                }
                break;

            case R.id.ll_singer:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 116;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Singers");
                }
                break;

            case R.id.ll_actor:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 117;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Actors");
                }
                break;

            case R.id.ll_politician:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 118;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Politicians");
                }
                break;

            case R.id.ll_sportsmen:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 119;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Sports Person");
                }
                break;

            case R.id.ll_actress:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 120;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FamousPerson("Actresses");
                }
                break;

            case R.id.ll_car:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 121;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    CarBrand();
                }
                break;

            case R.id.ll_bike:
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 122;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    BikeBrand();
                }
                break;
        }
    }

    private void OwnerInfo() {
        startActivity(new Intent(MainActivity.this, RtoOwnerDetailActivity.class));
    }

    private void VehicleLicense() {
        startActivity(new Intent(MainActivity.this, VehicleLicenseActivity.class));
    }

    private void RtoQuestion() {
        startActivity(new Intent(MainActivity.this, RtoQuestionActivity.class));
    }

    private void RtotrafficSignals() {
        startActivity(new Intent(MainActivity.this, RtoTrafficSignalsActivity.class));
    }

    private void RtoOfficeInfoA() {
        startActivity(new Intent(MainActivity.this, RtoOfficeInfoActivity.class));
    }

    private void VehicleExpense() {
        startActivity(new Intent(new Intent(MainActivity.this, VehicleExpenseActivity.class)));
    }

    private void VehicleMileage() {
        startActivity(new Intent(MainActivity.this, VehicleMileageActivity.class));
    }

    private void CarService() {
        startActivity(new Intent(MainActivity.this, CarServiceActivity.class));
    }

    private void CarDealer() {
        startActivity(new Intent(MainActivity.this, CarDealerActivity.class));
    }

    private void CarAccessories() {
        startActivity(new Intent(MainActivity.this, CarAccessoriesBrandActivity.class));
    }

    private void BikeService() {
        startActivity(new Intent(MainActivity.this, BikeServiceActivity.class));
    }

    private void BikeDealer() {
        startActivity(new Intent(MainActivity.this, BikeDealerActivity.class));
    }

    private void BikeAccessoriesBrand() {
        startActivity(new Intent(MainActivity.this, BikeAccessoriesBrandActvity.class));
    }

    private void FamousPerson(String FamousPersonName) {
        Intent intent = new Intent(MainActivity.this, FamousPersonListActivity.class);
        intent.putExtra("categoryname", FamousPersonName);
        startActivity(intent);
    }

    private void CarBrand() {
        startActivity(new Intent(MainActivity.this, CarBrandActivity.class));
    }

    private void BikeBrand() {
        startActivity(new Intent(MainActivity.this, BikeBrandActivity.class));
    }

    private void getFuelPrice() {
        String FullUrl = "fuelPrices/" + cityId;
        Call<FuelCityRoot> call = rtoDetailsInterface.getCityPrice(FullUrl);
        call.enqueue(new Callback<FuelCityRoot>() {
            @Override
            public void onResponse(Call<FuelCityRoot> call, Response<FuelCityRoot> response) {
                if (response.isSuccessful()) {
                    ll_progress.setVisibility(View.GONE);
                    ll_fuel.setVisibility(View.VISIBLE);
                    FuelCity fuelCity = response.body().getData();
                    tv_petrolprice.setText(fuelCity.getPetrol());
                    tv_dieselprice.setText(fuelCity.getDiesel());
                    tv_petrodiff.setText(fuelCity.getPetrolPriceDiff());
                    tv_dieseldiff.setText(fuelCity.getDieselPriceDiff());
                    tv_state.setText(fuelCity.getState());
                    tv_city.setText(cityName);
                }
            }

            @Override
            public void onFailure(Call<FuelCityRoot> call, Throwable t) {
                ll_progress.setVisibility(View.GONE);
                ll_fuel.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.history, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_history:
                startActivity(new Intent(MainActivity.this, HistoryTabLayoutActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
      /*  if (requestCode == 2296) {
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    // perform action when allow permission success
                } else {
                    Toast.makeText(this, "Allow permission for storage access!", Toast.LENGTH_SHORT).show();
                }
            }
        } else */if (requestCode == REQ_CODE_VERSION_UPDATE) {
            if (resultCode == Activity.RESULT_CANCELED) {
                // If the update is cancelled by the user,
                // you can request to start the update again.
                inAppUpdateManager.checkForAppUpdate();

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onInAppUpdateError(int code, Throwable error) {
    }


    @Override
    public void onInAppUpdateStatus(InAppUpdateStatus status) {
    }


    public void onBackPressed() {
        if (this.ePref.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_back_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_dialog, null);
                nativeads.populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.show();
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(activity);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_dialog, null);
                nativeads.populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    ePref.putBoolean("pref_key_rate", true);
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                   finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }
}