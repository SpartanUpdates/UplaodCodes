package com.esc.mynameringtonemaker.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.esc.mynameringtonemaker.Activity.RingtonePlayerActivity;
import com.esc.mynameringtonemaker.Model.RingtoneModel;
import com.esc.mynameringtonemaker.R;
import java.util.ArrayList;

public class MyCreationAdapter extends Adapter<ViewHolder> {
    private int ITEM_DATA = 0;
    private Activity activity;
    private ArrayList<RingtoneModel> list;

    public class ItemHolder extends ViewHolder {
        private LinearLayout llMain;
        private TextView tvName;

        public ItemHolder(View view) {
            super(view);
            this.llMain = view.findViewById(R.id.llMain);
            this.tvName = view.findViewById(R.id.tvName);
        }
    }

    public MyCreationAdapter(Activity activity, ArrayList<RingtoneModel> arrayList) {
        this.activity = activity;
        this.list = arrayList;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return i == this.ITEM_DATA ? new ItemHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_my_creation, viewGroup, false)) : null;
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        RingtoneModel ringtoneModel = this.list.get(i);
        if (getItemViewType(i) == this.ITEM_DATA) {
            ItemHolder itemHolder = (ItemHolder) viewHolder;
            itemHolder.tvName.setText(ringtoneModel.getName().replace("%20", " "));
            itemHolder.llMain.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent(MyCreationAdapter.this.activity, RingtonePlayerActivity.class);
                    intent.putExtra("list", MyCreationAdapter.this.list);
                    intent.putExtra("selectedPos", i);
                    MyCreationAdapter.this.activity.startActivity(intent);
                }
            });
        }
    }

    public int getItemCount() {
        return this.list.size();
    }

    public int getItemViewType(int i) {
        return this.ITEM_DATA;
    }
}
