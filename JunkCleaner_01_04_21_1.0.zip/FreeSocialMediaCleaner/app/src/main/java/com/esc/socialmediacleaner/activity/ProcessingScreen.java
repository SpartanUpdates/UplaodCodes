package com.esc.socialmediacleaner.activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.socialmediacleaner.R;
import com.skyfishjy.library.RippleBackground;

public class ProcessingScreen extends AppCompatActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_processing_screen);
        final RippleBackground rippleBackground = (RippleBackground) findViewById(R.id.content);
        ((ImageView) findViewById(R.id.centerImage)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                rippleBackground.startRippleAnimation();
            }
        });
    }
}
