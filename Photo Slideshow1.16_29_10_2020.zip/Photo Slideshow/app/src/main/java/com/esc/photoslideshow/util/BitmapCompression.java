package com.esc.photoslideshow.util;

import android.graphics.Bitmap;
import android.graphics.Matrix;

public class BitmapCompression {

    public static Bitmap resizeImage(final Bitmap bitmap, final int n, final int n2) {
        final int width = bitmap.getWidth();
        final int height = bitmap.getHeight();
        final float n3 = (n + 0.0f) / width;
        final float n4 = (n2 + 0.0f) / height;
        float n5 = n3;
        if (n3 > n4) {
            n5 = n4;
        }
        final Matrix matrix = new Matrix();
        matrix.postScale(n5, n5);
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
    }
}
