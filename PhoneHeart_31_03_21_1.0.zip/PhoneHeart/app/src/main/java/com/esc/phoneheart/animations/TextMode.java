package com.esc.phoneheart.animations;

public enum TextMode {
    TEXT,
    PERCENT,
    VALUE
}
