package com.kotlinz.videoCollage.crop;

import android.content.Context;
import android.util.TypedValue;

public class HandleUtil {

    private static boolean isInCenterTargetZone(float f, float f2, float f3, float f4, float f5, float f6) {
        return f > f3 && f < f5 && f2 > f4 && f2 < f6;
    }

    public static float getTargetRadius(Context context) {
        return TypedValue.applyDimension(1, 24.0f, context.getResources().getDisplayMetrics());
    }

    public static Handle getPressedHandle(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (isInCornerTargetZone(f, f2, f3, f4, f7)) {
            return Handle.TOP_LEFT;
        }
        if (isInCornerTargetZone(f, f2, f5, f4, f7)) {
            return Handle.TOP_RIGHT;
        }
        if (isInCornerTargetZone(f, f2, f3, f6, f7)) {
            return Handle.BOTTOM_LEFT;
        }
        if (isInCornerTargetZone(f, f2, f5, f6, f7)) {
            return Handle.BOTTOM_RIGHT;
        }
        if (isInCenterTargetZone(f, f2, f3, f4, f5, f6) && focusCenter()) {
            return Handle.CENTER;
        }
        if (isInHorizontalTargetZone(f, f2, f3, f5, f4, f7)) {
            return Handle.TOP;
        }
        if (isInHorizontalTargetZone(f, f2, f3, f5, f6, f7)) {
            return Handle.BOTTOM;
        }
        if (isInVerticalTargetZone(f, f2, f3, f4, f6, f7)) {
            return Handle.LEFT;
        }
        if (isInVerticalTargetZone(f, f2, f5, f4, f6, f7)) {
            return Handle.RIGHT;
        }
        return (!isInCenterTargetZone(f, f2, f3, f4, f5, f6) || focusCenter()) ? null : Handle.CENTER;
    }


    public static android.util.Pair<Float, Float> getOffset(Handle r1, float r2, float r3, float r4, float r5, float r6, float r7) {
      return null;
    }

    private static boolean isInCornerTargetZone(float f, float f2, float f3, float f4, float f5) {
        return Math.abs(f - f3) <= f5 && Math.abs(f2 - f4) <= f5;
    }

    private static boolean isInHorizontalTargetZone(float f, float f2, float f3, float f4, float f5, float f6) {
        return f > f3 && f < f4 && Math.abs(f2 - f5) <= f6;
    }

    private static boolean isInVerticalTargetZone(float f, float f2, float f3, float f4, float f5, float f6) {
        return Math.abs(f - f3) <= f6 && f2 > f4 && f2 < f5;
    }

    private static boolean focusCenter() {
        return CropOverlayView.showGuidelines() ^ true;
    }
}
