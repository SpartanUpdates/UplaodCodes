package com.templatemela.camscanner.models;

public enum EditToolType {
    COLORFILTER,
    ADJUST,
    HIGHLIGHT,
    PICTURE,
    SIGNATURE,
    WATERMARK,
    TEXT,
    OVERLAY,
    COLOREFFECT
}
