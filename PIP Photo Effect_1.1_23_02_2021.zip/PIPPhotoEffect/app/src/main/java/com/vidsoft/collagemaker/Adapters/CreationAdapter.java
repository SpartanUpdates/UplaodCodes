package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.io.IOException;
import java.util.ArrayList;

public class CreationAdapter extends BaseAdapter {
    private static LayoutInflater inflater;
    private Activity activity;
    private int imageSize;
    ArrayList<String> arraylisy_imagegallary;
    SparseBooleanArray sparseBooleanArray;
    View view;

    static {
        CreationAdapter.inflater = null;
    }

    public CreationAdapter(final Activity dactivity,
                           final ArrayList<String> imagegallary) {
        this.arraylisy_imagegallary = new ArrayList<String>();
        this.activity = dactivity;
        this.arraylisy_imagegallary = imagegallary;
        CreationAdapter.inflater = (LayoutInflater) this.activity
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.sparseBooleanArray = new SparseBooleanArray(
                this.arraylisy_imagegallary.size());
    }

    private void setWallpaper(final String s, final String s2) {
        final WallpaperManager instance = WallpaperManager
                .getInstance((Context) this.activity);
        final DisplayMetrics displayMetrics = new DisplayMetrics();
        this.activity.getWindowManager().getDefaultDisplay()
                .getMetrics(displayMetrics);
        final int heightPixels = displayMetrics.heightPixels;
        final int widthPixels = displayMetrics.widthPixels;
        try {
            final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
            bitmapFactory$Options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            instance.setBitmap(BitmapFactory.decodeFile(s2,
                    bitmapFactory$Options));
            Toast.makeText((Context) this.activity,
                    (CharSequence) "Wallpaper Set", Toast.LENGTH_SHORT).show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public int getCount() {
        return this.arraylisy_imagegallary.size();
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        View row = convertView;
        int width = this.activity.getResources().getDisplayMetrics().widthPixels;
        if (row == null) {
            row = LayoutInflater.from(this.activity).inflate(R.layout.gallary_list, parent, false);
            holder = new ViewHolder();
            holder.frm = (FrameLayout) row.findViewById(R.id.frame);
            holder.imgIcon = (ImageView) row.findViewById(R.id.imgIcon);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }
        Glide.with(this.activity).load((String) this.arraylisy_imagegallary.get(position)).into(holder.imgIcon);
        System.gc();
        return row;
    }

    static class ViewHolder {
        public FrameLayout frm;
        ImageView imgIcon;
    }
}
