package com.unitedvideosapp.photovideomaker.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideosapp.photovideomaker.MyApplication;
import com.unitedvideosapp.photovideomaker.modelclass.ImageData;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.util.Utils;
import com.unitedvideosapp.photovideomaker.videolib.libffmpeg.FileUtils;
import com.unitedvideosapp.photovideomaker.view.ScrollableViewPager;
import com.uvvideos.photo.video.slideshow.maker.R;

import java.io.File;
import java.util.ArrayList;

public class AddTitleActivity extends AppCompatActivity implements View.OnClickListener {
    Activity activity = AddTitleActivity.this;
    public static ImageView imgGallery;
    public static ImageView imgSticker;
    public static boolean isFrameChanged;
    public static int selectedFramePos;
    private PagerAdapter adapter;
    private MyApplication application;
    private int currentTabPos;
    boolean isDone;
    public static boolean isFromPreview;
    public static boolean isStickerAdded;
    public static boolean isTextAdded;
    public static ImageView imgText;
    boolean isSavePress;
    boolean isStartSaveTemp;
    DialogInterface.OnDismissListener onDismissListener;
    private ScrollableViewPager pager;
    public TabLayout.OnTabSelectedListener tabChangeListener;
    private TabLayout tbLayout;
    public static boolean isFilterApplied;
    public static ImageView imgCamera;
    RelativeLayout rlToolbar;
    ImageView ivback,ivnext;
    ArrayList<String> tabcategorylist = new ArrayList<>();

    public AddTitleActivity() {
        this.currentTabPos = 0;
        this.isStartSaveTemp = true;
        this.isDone = false;
        this.onDismissListener = new DialogInterface.OnDismissListener() {
            public void onDismiss(final DialogInterface dialogInterface) {
                AddTitleActivity.this.tbLayout.setOnTabSelectedListener(null);
                AddTitleActivity.this.tbLayout.getTabAt(AddTitleActivity.this.currentTabPos).select();
                AddTitleActivity.this.tbLayout.setOnTabSelectedListener(AddTitleActivity.this.tabChangeListener);
            }
        };
        this.isSavePress = true;
        /*this.tabChangeListener = new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(final TabLayout.Tab tabLayout$Tab) {
            }

            public void onTabSelected(final TabLayout.Tab tabLayout$Tab) {
                AddTitleActivity.this.isDone = false;
                AddTitleActivity.this.pager.setCurrentItem(tabLayout$Tab.getPosition());
                AddTitleActivity.this.currentTabPos = tabLayout$Tab.getPosition();
                AddTitleActivity.setStartFrameState(R.id.imgEditGallery);
                if (AddTitleActivity.this.currentTabPos == 0) {
                    if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                        Fragment_StartFrame.bottomSheet.setVisibility(View.GONE);
                    }
                    Fragment_StartFrame.getOnSaveStoryTitle().setFrameVisibility(0);
                    return;
                }
                if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Fragment_EndFrame.bottomSheet.setVisibility(View.GONE);
                }
                Fragment_EndFrame.getOnSaveStoryTitle().setFrameVisibility(0);
            }

            public void onTabUnselected(final TabLayout.Tab tabLayout$Tab) {

            }
        };*/
    }

    private void addListener() {
        this.tbLayout.setOnTabSelectedListener(this.tabChangeListener);
        findViewById(R.id.imgEditCamera).setOnClickListener(this);
        imgGallery.setOnClickListener(this);
        findViewById(R.id.imgEditText).setOnClickListener(this);
        findViewById(R.id.imgEditSticker).setOnClickListener(this);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                application.isEditModeEnable = true;
                onBackPressed();
            }
        });
        ivnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    nextCall();
                }
            }
        });
    }

    private void bindView() {
        this.pager = findViewById(R.id.vpPager);
        rlToolbar=findViewById(R.id.rl_toolbar);
        ivback=findViewById(R.id.iv_back);
        ivnext=findViewById(R.id.iv_next);
        this.tbLayout = findViewById(R.id.tblFrames);
        tabcategorylist.add("Start");
        tabcategorylist.add("End");
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AddTitleActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        AddTitleActivity.isFromPreview = this.getIntent().getExtras().getBoolean("ISFROMPREVIEW");
        if (MyApplication.isStoryAdded) {
            MyApplication.isStartSave = false;
            MyApplication.isEndSave = false;
            if (Fragment_StartFrame.lastsaveTempPath != null) {
                MyApplication.isStartRemoved = (this.isStartFrameExist() ^ true);
            } else {
                MyApplication.isStartRemoved = true;
            }
            if (Fragment_EndFrame.lastsaveTempPath != null) {
                MyApplication.isLastRemoved = (this.isEndFrameExist() ^ true);
            } else {
                MyApplication.isLastRemoved = true;
            }
        }
        Utils.setFont(this, R.id.toolbar_title);
        this.application = MyApplication.getInstance();
        this.pager.setCanScroll(false);
        this.tbLayout.addTab(this.tbLayout.newTab().setText(R.string.start));
        this.tbLayout.addTab(this.tbLayout.newTab().setText(R.string.end));
        this.adapter = new PagerAdapter(getSupportFragmentManager());
        this.pager.setAdapter(this.adapter);
        SetTabLayout();
        imgGallery = findViewById(R.id.imgEditGallery);
        imgCamera = findViewById(R.id.imgEditCamera);
        imgText = findViewById(R.id.imgEditText);
        imgSticker = findViewById(R.id.imgEditSticker);
        imgGallery.setSelected(true);
        Utils.setFont(activity, R.id.tv_image);
        Utils.setFont(activity, R.id.tv_frame);
        Utils.setFont(activity, R.id.tv_text);
        Utils.setFont(activity, R.id.tv_emoji);
    }

    private void SetTabLayout() {
        for (int i = 0; i < tbLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tbLayout.getTabAt(i);
            tab.setCustomView(adapter.getTabView(i));
        }
        View customView = tbLayout.getTabAt(tbLayout.getSelectedTabPosition()).getCustomView();
        ImageView ivtab = customView.findViewById(R.id.iv_tab);
        TextView tvCatName = customView.findViewById(R.id.tv_cat_Name);
        tvCatName.setTextColor(getResources().getColor(R.color.tab_selected_color));
        ivtab.setBackground(getResources().getDrawable(R.drawable.ic_tab_start_selected));
        tbLayout.getTabAt(0).getCustomView().setSelected(true);

        this.tabChangeListener = new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(final TabLayout.Tab tabLayout$Tab) {
            }

            public void onTabSelected(final TabLayout.Tab tabLayout$Tab) {
                View customView = tabLayout$Tab.getCustomView();
                ImageView ivtab = customView.findViewById(R.id.iv_tab);
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.tab_selected_color));
                ivtab.setBackground(getResources().getDrawable(R.drawable.ic_tab_start_selected));

                AddTitleActivity.this.isDone = false;
                AddTitleActivity.this.pager.setCurrentItem(tabLayout$Tab.getPosition());
                AddTitleActivity.this.currentTabPos = tabLayout$Tab.getPosition();
                AddTitleActivity.setStartFrameState(R.id.imgEditGallery);
                if (AddTitleActivity.this.currentTabPos == 0) {
                    if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                        Fragment_StartFrame.bottomSheet.setVisibility(View.GONE);
                    }
                    Fragment_StartFrame.getOnSaveStoryTitle().setFrameVisibility(0);
                    return;
                }
                if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Fragment_EndFrame.bottomSheet.setVisibility(View.GONE);
                }
                Fragment_EndFrame.getOnSaveStoryTitle().setFrameVisibility(0);
            }

            public void onTabUnselected(final TabLayout.Tab tabLayout$Tab) {
                View customView = tabLayout$Tab.getCustomView();
                ImageView ivtab = customView.findViewById(R.id.iv_tab);
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.tab_unselected_color));
                ivtab.setBackground(getResources().getDrawable(R.drawable.ic_tab_start_unselected));
            }
        };
    }

    private boolean isEndFrameExist() {
        return Fragment_EndFrame.lastsaveTempPath != null && new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }

    private boolean isStartFrameExist() {
        return Fragment_StartFrame.lastsaveTempPath != null && new File(Fragment_StartFrame.lastsaveTempPath).exists();
    }


    private void resetBool() {
        AddTitleActivity.isFilterApplied = false;
        AddTitleActivity.isStickerAdded = false;
        AddTitleActivity.isFrameChanged = false;
        AddTitleActivity.isTextAdded = false;
    }

    private void setEndFrameVisility() {
        if (Fragment_EndFrame.getOnSaveStoryTitle().getFrameVisibility() != 4 && Fragment_EndFrame.getOnSaveStoryTitle().getFrameVisibility() != 8) {
            Fragment_EndFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditGallery);
            setStartFrameState(0);
            return;
        }
        Fragment_EndFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditGallery);
        setStartFrameState(R.id.imgEditGallery);
    }

    public static void setStartFrameState(final int n) {
       /* AddTitleActivity.imgGallery.setSelected(false);
        AddTitleActivity.imgCamera.setSelected(false);
        AddTitleActivity.imgText.setSelected(false);
        AddTitleActivity.imgSticker.setSelected(false);
        switch (n) {
            default: {
            }
            case R.id.imgEditText: {
                AddTitleActivity.imgText.setSelected(true);
                AddTitleActivity.imgText.invalidate();
            }
            break;
            case R.id.imgEditSticker: {
                AddTitleActivity.imgSticker.setSelected(true);
                AddTitleActivity.imgSticker.invalidate();
            }
            break;
            case R.id.imgEditGallery: {
                AddTitleActivity.imgGallery.setSelected(true);
                AddTitleActivity.imgGallery.invalidate();
            }
            break;
            case R.id.imgEditCamera: {
                AddTitleActivity.imgCamera.setSelected(true);
                AddTitleActivity.imgCamera.invalidate();
            }
            break;
        }*/
    }
    private void setFocus() {
        imgCamera.setSelected(false);
        imgGallery.setSelected(false);
        imgText.setSelected(false);
        imgSticker.setSelected(false);
    }
    private void setStartFrameVisibility() {
        if (Fragment_StartFrame.getOnSaveStoryTitle().getFrameVisibility() != 4 && Fragment_StartFrame.getOnSaveStoryTitle().getFrameVisibility() != 8) {
            Fragment_StartFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditGallery);
            setStartFrameState(0);
            return;
        }
        Fragment_StartFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditGallery);
        setStartFrameState(R.id.imgEditGallery);
    }

    private void updateVideoFramesNew(final boolean b, final boolean b2) {
        final ArrayList<ImageData> list = new ArrayList<ImageData>();
        if (MyApplication.isStoryAdded) {
            if (!MyApplication.isStartRemoved && !MyApplication.isLastRemoved) {
                this.application.removeSelectedImage(0);
                MyApplication.isStartRemoved = true;
                this.application.removeSelectedImage(this.application.selectedImages.size() - 1);
                MyApplication.isLastRemoved = true;
                MyApplication.isStoryAdded = false;
            } else {
                if (!MyApplication.isStartRemoved) {
                    this.application.removeSelectedImage(0);
                    MyApplication.isStartRemoved = true;
                }
                if (!MyApplication.isLastRemoved) {
                    this.application.removeSelectedImage(this.application.selectedImages.size() - 1);
                    MyApplication.isLastRemoved = true;
                }
                MyApplication.isStoryAdded = false;
            }
        }
        final ImageData imageData = new ImageData();
        final ImageData imageData2 = new ImageData();
        imageData.imagePath = new File(Fragment_StartFrame.lastsaveTempPath).getAbsolutePath();
        list.add(imageData);
        list.addAll(this.application.getSelectedImages());
        imageData2.imagePath = new File(Fragment_EndFrame.lastsaveTempPath).getAbsolutePath();
        list.add(imageData2);
        this.application.selectedImages.removeAll(this.application.selectedImages);
        this.application.selectedImages.addAll(list);
        MyApplication.isStoryAdded = true;
        this.application.isEditModeEnable = false;
        if (AddTitleActivity.isFromPreview) {
            PreviewActivity.getmActivity().finish();
        }
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ActivityAnimUtil.startActivitySafely(AddTitleActivity.this.rlToolbar, new Intent(AddTitleActivity.this, PreviewActivity.class));
                AddTitleActivity.this.finish();

            }
        });
    }

    public void onBackPressed() {
        if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
            Utils.slideDown(this, Fragment_StartFrame.bottomSheet);
            this.setStartFrameVisibility();
            return;
        }
        if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
            Utils.slideDown(this, Fragment_EndFrame.bottomSheet);
            this.setEndFrameVisility();
            return;
        }
        super.onBackPressed();
    }

    public void onClick(final View view) {
        switch (view.getId()) {
            default: {
            }
            case R.id.imgEditText: {
                if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_StartFrame.bottomSheet);
                } else if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_EndFrame.bottomSheet);
                }
                setStartFrameState(R.id.imgEditText);
                setFocus();
                imgCamera.setSelected(true);
                switch (this.currentTabPos) {
                    default: {
                        return;
                    }
                    case 1: {
                        Fragment_EndFrame.getOnSaveStoryTitle().onAddTextSticker();
                        return;
                    }
                    case 0: {
                        Fragment_StartFrame.getOnSaveStoryTitle().onAddTextSticker();
                        return;
                    }
                }
            }
            case R.id.imgEditSticker: {
                setFocus();
                imgSticker.setSelected(true);
                switch (this.currentTabPos) {
                    default: {
                        return;
                    }
                    case 1: {
                        Fragment_EndFrame.getOnSaveStoryTitle().onAddImageSticker();
                        return;
                    }
                    case 0: {
                        Fragment_StartFrame.getOnSaveStoryTitle().onAddImageSticker();
                        return;
                    }
                }
            }
            case R.id.imgEditGallery: {
                if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_StartFrame.bottomSheet);
                } else if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_EndFrame.bottomSheet);
                }
                setFocus();
                imgGallery.setSelected(true);
                switch (this.currentTabPos) {
                    default: {
                        return;
                    }
                    case 1: {
                        this.setEndFrameVisility();
                        return;
                    }
                    case 0: {
                        this.setStartFrameVisibility();
                        return;
                    }
                }
            }
            case R.id.imgEditCamera: {
                setStartFrameState(0);
                setFocus();
                imgCamera.setSelected(true);
                if (Fragment_StartFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_StartFrame.bottomSheet);
                } else if (Fragment_EndFrame.bottomSheet.getVisibility() == View.VISIBLE) {
                    Utils.slideDown(this, Fragment_EndFrame.bottomSheet);
                }
                switch (this.currentTabPos) {
                    default: {
                        return;
                    }
                    case 1: {
                        Fragment_EndFrame.getOnSaveStoryTitle().onAddCameraImage();
                        Fragment_EndFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditCamera);
                        return;
                    }
                    case 0: {
                        Fragment_StartFrame.getOnSaveStoryTitle().onAddCameraImage();
                        Fragment_StartFrame.getOnSaveStoryTitle().setFrameVisibility(R.id.imgEditCamera);
                        return;
                    }
                }
            }
        }
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_title);
        if (Utils.checkPermission(this)) {
            this.bindView();
            this.init();
            PutAnalyticsEvent();
//            Log.e("ADSCheck", "==TITTLE==" + Utils.checkAds);
//            if (Utils.checkAds) {
//                Log.e("ADSCheck", "==TITTLE==" + Utils.checkAds);
            loadNextBtnInterstitial();
//            } else {
//                Utils.checkAds = true;
//            }
            this.addListener();
            return;
        }
        final Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        this.startActivity(intent);
    }

    private InterstitialAd mInterstitialAd;

    private void loadNextBtnInterstitial() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                nextCall();
                requestNewInterstitial();
            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        this.getMenuInflater().inflate(R.menu.story_title, menu);
        for (int i = 0; i < menu.size(); ++i) {
            final MenuItem item = menu.getItem(i);
            final SubMenu subMenu = item.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int j = 0; j < subMenu.size(); ++j) {
                    Utils.applyFontToMenuItem(this.getApplicationContext(), subMenu.getItem(j));
                }
            }
            Utils.applyFontToMenuItem(this.getApplicationContext(), item);
        }
        return true;
    }

    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        final int itemId = menuItem.getItemId();
        if (itemId != android.R.id.home) {
            if (itemId != R.id.action_done) {
                if (itemId == R.id.action_skip) {
                    this.application.isEditModeEnable = false;
                    ActivityAnimUtil.startActivitySafely(this.rlToolbar, new Intent(this, PreviewActivity.class));
                    this.finish();

                }
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void nextCall() {
        this.isDone = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                FileUtils.TEMP_IMG_DIRECTORY.mkdirs();
                final long currentTimeMillis = System.currentTimeMillis();
                final StringBuilder sb = new StringBuilder();
                sb.append("NewTitle save start frame ");
                sb.append(currentTimeMillis);
                Fragment_StartFrame.isSavingDone = false;
                Fragment_StartFrame.getOnSaveStoryTitle().onSaveImageNew();
                MyApplication.isStartSave = true;
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("NewTitle save start frame ");
                sb2.append(System.currentTimeMillis() - currentTimeMillis);
                Fragment_EndFrame.isSavingDone = false;
                Fragment_EndFrame.getOnSaveStoryTitle().onSaveImageNew();
                MyApplication.isEndSave = true;
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("NewTitle save end frame ");
                sb3.append(System.currentTimeMillis() - currentTimeMillis);
                AddTitleActivity.this.updateVideoFramesNew(MyApplication.isStartSave, MyApplication.isEndSave);
                final StringBuilder sb4 = new StringBuilder();
                sb4.append("NewTitle save dismiss ");
                sb4.append(System.currentTimeMillis() - currentTimeMillis);
                AddTitleActivity.this.resetBool();
            }
        }).start();
    }


    public class PagerAdapter extends FragmentPagerAdapter {
        public PagerAdapter(final FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public int getCount() {
            return 2;
        }

        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(R.layout.row_custom_tab_item, null);
            TextView tv = tabCatView.findViewById(R.id.tv_cat_Name);
            tv.setText(tabcategorylist.get(position));
            Utils.setFont(activity, tv);
            return tabCatView;
        }

        public Fragment getItem(final int n) {
            switch (n) {
                default: {
                    return null;
                }
                case 1: {
                    return new Fragment_EndFrame();
                }
                case 0: {
                    return new Fragment_StartFrame();
                }
            }
        }
    }
}

