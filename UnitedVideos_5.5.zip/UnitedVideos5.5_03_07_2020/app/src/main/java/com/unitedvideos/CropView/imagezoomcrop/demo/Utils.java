package com.unitedvideos.CropView.imagezoomcrop.demo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.unitedvideos.R;
import com.unitedvideos.activity.ArrangePhotosActivity;
import com.unitedvideos.activity.ImageSelectionActivity;
import com.unitedvideos.application.MyApplication;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Utils {
    public static final String TAG = "autocrop";
    String[] mAllPath_AC;
    ArrayList<String> mAllSavePath_AC;
    String mConcatPath_AC;
    private static ContentResolver mContentResolver_AC;
    private String mImagePath_AC;
    private Uri mImageUri_AC;
    private final Bitmap.CompressFormat mOutputFormat_AC;
    private Uri mSaveUri_AC;
    String save_path_AC;
    Context mContext_AC;
    private MyApplication application;
    public boolean IsUpdateImage;
    public String cut;
    public String isfrom;


    public Utils() {
        this.mOutputFormat_AC = Bitmap.CompressFormat.JPEG;
        application = MyApplication.getInstance();
    }

    public void startAutoCrop(final Context con, final String all_path, boolean update, String iscut, String from) {
        Log.e("All_Path", "" + all_path);
        cut = iscut;
        IsUpdateImage = update;
        isfrom = from;
        this.mContext_AC = con;
        Utils.mContentResolver_AC = this.mContext_AC.getContentResolver();
        this.mConcatPath_AC = "";
        this.mSaveUri_AC = null;
        this.mImageUri_AC = null;
        this.save_path_AC = null;
        this.mAllSavePath_AC = new ArrayList<String>();
        this.setImageBunch(all_path);
    }

    public void setImageBunch(final String allToCrop) {
        Log.e("setImageBunch", "" + allToCrop);
        if (allToCrop.equals("")) {
            Toast.makeText(this.mContext_AC, (CharSequence) "No Img Found", Toast.LENGTH_SHORT).show();
            return;
        }
        this.mAllPath_AC = allToCrop.split("\\" + MyApplication.SPLIT_PATTERN);
        this.mConcatPath_AC = allToCrop;
        new SaveSingleAsynk().execute();

    }

    private static Bitmap rotateImage(final Bitmap source, final float angle) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        final WeakReference<Bitmap> rotateBitmap = new WeakReference<Bitmap>(Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true));
        return rotateBitmap.get();
    }

    public static Bitmap decodeSampledBitmapFromUri(final Uri uri, final int reqWidth, final int reqHeight) {
        InputStream in = null;
        try {
            in = Utils.mContentResolver_AC.openInputStream(uri);
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, (Rect) null, options);
            in.close();
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
            options.inJustDecodeBounds = false;
            in = Utils.mContentResolver_AC.openInputStream(uri);
            WeakReference<Bitmap> wBitmap = new WeakReference<Bitmap>(BitmapFactory.decodeStream(in, (Rect) null, options));
            in.close();
            final ExifInterface ei = new ExifInterface(uri.getPath());
            final int orientation = ei.getAttributeInt("Orientation", 1);
            final Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90.0f);
            } else if (orientation == 3) {
                matrix.postRotate(180.0f);
            } else if (orientation == 8) {
                matrix.postRotate(270.0f);
            }
            wBitmap = new WeakReference<Bitmap>(Bitmap.createBitmap((Bitmap) wBitmap.get(), 0, 0, wBitmap.get().getWidth(), wBitmap.get().getHeight(), matrix, true));
            return wBitmap.get();
        } catch (FileNotFoundException e) {
            Log.e("", "ERR " + e);
        } catch (IOException e2) {
            Log.e("", "ERR " + e2);
        }
        return null;
    }

    public static int calculateInSampleSize(final BitmapFactory.Options options, final int reqWidth, final int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            for (int halfHeight = height / 2, halfWidth = width / 2; halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth; inSampleSize *= 2) {
            }
        }
        return inSampleSize;
    }

    private Bitmap a(String s, final int n, final int n2) {
        Log.d("CPCP", "createImages() called");
        final StringBuilder sb = new StringBuilder("Path = ");
        sb.append(s);
        Log.d("CPCP", sb.toString());
        final StringBuilder sb2 = new StringBuilder("WIDTH = ");
        sb2.append(n);
        Log.d("CPCP", sb2.toString());
        final StringBuilder sb3 = new StringBuilder("HEIGHT = ");
        sb3.append(n2);
        Log.d("CPCP", sb3.toString());
        final Bitmap a = C1721b.m5448a(s);
        final Bitmap a2 = C1721b.m5446a(a, n, n2);
        final Bitmap a3 = C1721b.m5447a(a, a2, n, n2);
        a2.recycle();
        a.recycle();
        System.gc();
        if (a3 == null) {
            s = "newFirstBmp==null";
        } else {
            s = "newFirstBmp!=null";
        }
        Log.d("CPCP", s);
        return a3;
    }

    public boolean saveCropResult(final int idx) {
        if (this.save_path_AC == null) {
            this.save_path_AC = this.getAppTempAudioPath();
        }


        this.mImagePath_AC = this.mAllPath_AC[idx];
        this.mImageUri_AC = getImageUri(this.mImagePath_AC);
        final String file_path = this.getOutFilePath(this.mAllPath_AC[idx], idx);
        Log.d("tag", "index : " + this.mImageUri_AC);
        try {
            final DisplayMetrics displayMetrics = new DisplayMetrics();
            ((ImageSelectionActivity) this.mContext_AC).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            final int height = displayMetrics.heightPixels;
            final int width = displayMetrics.widthPixels;
//      final Bitmap croppedImage = BitmapUtil.centerCrop(decodeSampledBitmapFromUri(this.mImageUri_AC, width, height), width, height);
            final Bitmap croppedImage = BitmapUtil.centerCrop(a(this.mImagePath_AC, width, height), width, height);
            this.mSaveUri_AC = getImageUri(file_path);
            if (this.mSaveUri_AC != null) {
                OutputStream outputStream = null;
                try {
                    outputStream = Utils.mContentResolver_AC.openOutputStream(this.mSaveUri_AC);
                    if (outputStream != null) {
                        croppedImage.compress(this.mOutputFormat_AC, 100, outputStream);
                    }
                    this.mAllSavePath_AC.add(file_path);


                    croppedImage.recycle();
                    return true;
                } catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                } finally {
                    this.closeSilently(outputStream);
                }
            }
            Log.e("tag", "not defined image url");
            return false;
        } catch (IllegalArgumentException e) {
            return false;
        } catch (Exception e2) {
            return false;
        }
    }

    public void closeSilently(final Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Throwable t) {
            }
        }
    }

    public String getOutFilePath(final String inPath, final int count) {
        final String ext = new File(inPath).getName();
        return String.valueOf(this.save_path_AC) + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_" + count + "_" + ext.substring(ext.lastIndexOf("."));
    }

    public static Uri getImageUri(final String path) {
        return Uri.fromFile(new File(path));
    }

    public final String getAPP_FOLDER() {
        return "United Videos";
    }

    public final String getOutputPath() {
        final String path = String.valueOf(Environment.getExternalStorageDirectory().toString()) + File.separator + this.getAPP_FOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getAppTempAudioPath() {
        final String path = String.valueOf(this.getOutputPath()) + ".Crop Image" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public static void copy(final File src, final File dst) throws IOException {
        final InputStream in = new FileInputStream(src);
        try {
            final OutputStream out = new FileOutputStream(dst);
            final byte[] buf = new byte[1024];
            while (true) {
                final int len = in.read(buf);
                if (len <= 0) {
                    break;
                }
                out.write(buf, 0, len);
            }
            out.close();
            in.close();
        } catch (Throwable th) {
            in.close();
        }
    }

    static void close(final OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    static void close(final InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    public void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                this.deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }


    class SaveSingleAsynk extends AsyncTask<Integer, Integer, String> {
        boolean isCropSuccess;
        Dialog alertDialog;
        ImageView iv_circle;
        TextView tvcount;

        SaveSingleAsynk() {
            this.isCropSuccess = false;

        }

        @Override
        protected void onPreExecute() {
            alertDialog = new Dialog(mContext_AC);
            alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            alertDialog.setCancelable(false);
            alertDialog.setContentView(R.layout.custom_progressdialog);
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            iv_circle = alertDialog.findViewById(R.id.iv_circle);
            tvcount = alertDialog.findViewById(R.id.tv_count);
            Animation aniRotateClk = AnimationUtils.loadAnimation(mContext_AC, R.anim.loader_rotation);
            aniRotateClk.setRepeatCount(-1);
            iv_circle.startAnimation(aniRotateClk);
            tvcount.setText("Loading Image....." + 0 + "/" + mAllPath_AC.length);
            alertDialog.show();

        }

        @Override
        protected String doInBackground(Integer... params) {
            for (int i = 0; i < Utils.this.mAllPath_AC.length; ++i) {
                this.isCropSuccess = Utils.this.saveCropResult(i);
                publishProgress(i + 1);
            }
            return "Task Completed.";
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.e(TAG, "onProgressUpdate: " + values[0]);
            tvcount.setText("Loading Image....." + values[0] + "/" + mAllPath_AC.length);
        }

        @Override
        protected void onPostExecute(String result) {
            String imagePath = null;
            if (IsUpdateImage) {
                application.cropimaglist.clear();
            }

            for (int i = 0; i < Utils.this.mAllSavePath_AC.size(); ++i) {
                application.AddCropImages(Utils.this.mAllSavePath_AC.get(i));
            }

            if (this.alertDialog != null && this.alertDialog.isShowing()) {
                this.alertDialog.dismiss();
            }

//            if (MyApplication.IS_EDITIMAGE == 0) {
//                Log.e("Image Path", "==" + imagePath);
//
//            }
            Log.e(TAG, "Utils: " + IsUpdateImage);
            Intent intent = new Intent(mContext_AC, ArrangePhotosActivity.class);
            intent.putExtra("Imageupdate", IsUpdateImage);
            intent.putExtra("isCut", cut);
            intent.putExtra("isfrom", isfrom);
            mContext_AC.startActivity(intent);
            ((Activity) Utils.this.mContext_AC).finish();
            Log.e(TAG, "startResultAct: " + IsUpdateImage);
            Log.e(TAG, "startResultAct: " + cut);
            Log.e(TAG, "startResultAct: " + isfrom);
        }


    }

/*class SaveSingleAsynk extends AsyncTask<String, Integer, String> {
        boolean isCropSuccess;
        int fullLen;
        AlertDialog.Builder builderVal;
        AlertDialog alertDialog;
        ImageView imageView;
        TextView tvtitle;

        SaveSingleAsynk() {
            this.isCropSuccess = false;

        }


        protected void onPreExecute() {
            super.onPreExecute();
            this.fullLen = Utils.this.mAllSavePath_AC.size();
            builderVal = new AlertDialog.Builder(mContext_AC);
            View holder = View.inflate(mContext_AC, R.layout.custom_progressdialog, null);
            builderVal.setView(holder);

            imageView = holder.findViewById(R.id.progressbar);
            tvtitle = holder.findViewById(R.id.text);
            Animation aniRotateClk = AnimationUtils.loadAnimation(mContext_AC, R.anim.rotate);
            imageView.startAnimation(aniRotateClk);


            Log.e(TAG, "onPreExecute: " + countimage);
            tvtitle.setText((CharSequence) (String.valueOf(countimage) + "/" + this.fullLen));
            builderVal.show();


        }


        protected String doInBackground(final String... strings) {
            for (int i = 0; i < Utils.this.mAllPath_AC.length; ++i) {
                this.isCropSuccess = Utils.this.saveCropResult(i);
                countimage = i;

            }

            return null;
        }


        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.e(TAG, "onProgressUpdate: ");
            Log.e("Value", "onProgressUpdate" + (values[0]));
        }

        protected void onPostExecute(final String result) {
            super.onPostExecute(result);
            String imagePath = null;
            if (updateimage == 15) {
                application.cropimaglist.clear();

            }

            for (int i = 0; i < Utils.this.mAllSavePath_AC.size(); ++i) {
                application.AddCropImages(Utils.this.mAllSavePath_AC.get(i));
            }

            if (this.alertDialog != null && this.alertDialog.isShowing()) {
                this.alertDialog.dismiss();
            }

            if (MyApplication.IS_EDITIMAGE == 0) {
                Log.e("Image Path", "==" + imagePath);

            }
            Log.e(TAG, "Utils: " + updateimage);
            Utils.this.mContext_AC.startActivity(new Intent(mContext_AC, arrangePhotosActivity.class));
            ((Activity) Utils.this.mContext_AC).finish();


        }
    }*/
}
