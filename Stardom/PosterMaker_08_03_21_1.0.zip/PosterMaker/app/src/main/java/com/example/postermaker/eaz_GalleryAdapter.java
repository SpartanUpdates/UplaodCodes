package com.example.postermaker;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

public class eaz_GalleryAdapter extends BaseAdapter
{
    private static LayoutInflater inflater;
    private Activity dactivity;
    private int imageSize;
    ArrayList<String> imagegallary;
    SparseBooleanArray mSparseBooleanArray;
    MediaMetadataRetriever metaRetriever;
    View vi;

    static class ViewHolder {
        ImageView imgDelete;
        ImageView imgIcon;
        ImageView imgShare;

        ViewHolder()
        {

        }
    }

    public long getItemId(int i)
    {
        return (long) i;
    }

    public eaz_GalleryAdapter(Activity activity, ArrayList<String> arrayList)
    {
        this.dactivity = activity;
        this.imagegallary = arrayList;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mSparseBooleanArray = new SparseBooleanArray(this.imagegallary.size());
    }

    public int getCount()
    {
        return this.imagegallary.size();
    }

    public Object getItem(int i)
    {
        return Integer.valueOf(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup)
    {
        ViewHolder viewHolder = new ViewHolder();
        if (view == null) {
            view = LayoutInflater.from(this.dactivity).inflate(R.layout.list_gallery, viewGroup, false);
            viewHolder.imgIcon = (ImageView) view.findViewById(R.id.imgIcon);
            viewHolder.imgDelete = (ImageView) view.findViewById(R.id.imgDelete);
            viewHolder.imgShare = (ImageView) view.findViewById(R.id.imgShare);
            view.setTag(viewHolder);
        } else
        {
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.imgShare.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                Builder builder = new Builder(eaz_GalleryAdapter.this.dactivity);
                builder.setTitle("Share");
                String str = "No";
                builder.setMessage("Do You Want to Share ?").
                        setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                eaz_GalleryAdapter eaz_galleryadapter = eaz_GalleryAdapter.this;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(eaz_GalleryAdapter.this.dactivity.getResources().getString(R.string.app_name));
                                stringBuilder.append(" Created By :\"https://play.google.com/store/apps/details?id=com.fippleappzone.postermaker");
                                eaz_galleryadapter.shareImage(stringBuilder.toString(), eaz_GalleryAdapter.this.imagegallary.get(i));

                            }

                }).setNegativeButton(str, new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
            }
        });

        viewHolder.imgDelete.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                Builder builder = new Builder(eaz_GalleryAdapter.this.dactivity);
                builder.setTitle("Delete");
                String str = "No";
                builder.setMessage("Do You Want to Delete ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                File file = new File(imagegallary.get(i));
                                if (file.exists()) {
                                    file.delete();

                                    Log.e("ffffififfi", file.toString());

                                    if (VERSION.SDK_INT >= 19) {
                                        Log.e("ffffififfi", file.toString());
                                        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                                        intent.setData(Uri.fromFile(file));
                                        eaz_GalleryAdapter.this.dactivity.sendBroadcast(intent);
                                    } else {
                                        Activity access$000 = eaz_GalleryAdapter.this.dactivity;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("file://");
                                        stringBuilder.append(Environment.getExternalStorageDirectory());
                                        access$000.sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse(stringBuilder.toString())));
                                    }
                                }
                                eaz_GalleryAdapter.this.imagegallary.remove(i);
                                eaz_GalleryAdapter.this.notifyDataSetChanged();
                                if (eaz_GalleryAdapter.this.imagegallary.size() == 0) {
                                    Toast.makeText(eaz_GalleryAdapter.this.dactivity, "No Image Found..", Toast.LENGTH_LONG).show();
                                }
                            }
                        }).setNegativeButton(str, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
            }
        });

        Glide.with(this.dactivity).load((String) this.imagegallary.get(i)).into(viewHolder.imgIcon);
        System.gc();
        return view;
    }

    public void shareImage(final String str, String str2)
    {
        MediaScannerConnection.scanFile(this.dactivity, new String[]{str2}, null, new OnScanCompletedListener()
        {
            public void onScanCompleted(String str, Uri uri)
            {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_TEXT, str);
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                eaz_GalleryAdapter.this.dactivity.startActivity(Intent.createChooser(intent, "Share Image"));
            }
        });
    }
}
