package com.example.postermaker.utilities;

import android.graphics.drawable.GradientDrawable;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;

public class eaz_GradientDrawable {
    public void manageShape(int i, int i2, int i3, int i4, int i5) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setStroke(i4, i2, (float) i3, 7.0f);
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius((float) i5);
        if (eaz_ConstantValues.bgchoice == 1) {
            eaz_EditActivity.backgroundlayout.setBackground(gradientDrawable);
            eaz_EditActivity.backgroundlayout.invalidate();
        }
        if (eaz_ConstantValues.bgchoice == 2) {
            eaz_EditActivity.foregroundlayout.setBackground(gradientDrawable);
            eaz_EditActivity.foregroundlayout.invalidate();
        }
    }

    public void manageText(int i, int i2, int i3, int i4, int i5) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable.setStroke(i4, i2, (float) i3, 7.0f);
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius((float) i5);
        eaz_EditActivity.logoText.setBackground(gradientDrawable);
        eaz_EditActivity.logoText.invalidate();
    }
}
