package com.esc.storymaker.interfaces;

import android.view.View;

public interface ItemLongClickListener {
    void onItemLongClick(View view, int i);
}
