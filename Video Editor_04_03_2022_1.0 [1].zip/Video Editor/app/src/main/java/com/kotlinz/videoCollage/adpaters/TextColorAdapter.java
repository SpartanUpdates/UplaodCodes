package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.TextColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class TextColorAdapter extends Adapter<TextColorAdapter.ViewHolder> {
    private Context context;
    private TextColorAdapterCallBackInterface listener;
    private int pos = 1;
    private String[] textColorList;

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgTextColor;
        ImageView imgTextColorSelector;

        ViewHolder(View view) {
            super(view);
            this.imgTextColor = (ImageView) view.findViewById(R.id.img_text_color);
            this.imgTextColorSelector = (ImageView) view.findViewById(R.id.img_text_color_selector);
        }
    }

    public TextColorAdapter(String[] strArr, Context context, TextColorAdapterCallBackInterface textColorAdapterCallBackInterface) {
        this.textColorList = strArr;
        this.listener = textColorAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_text_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = this.textColorList[i];
        viewHolder.imgTextColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgTextColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgTextColor.setBackground(gradientDrawable);
        viewHolder.imgTextColor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextColorAdapter.this.pos = i;
                TextColorAdapter.this.listener.itemClick(i);
                TextColorAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgTextColorSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgTextColorSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.textColorList.length;
    }
}
