package com.unitedvideos.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.unitedvideos.Listener.OnItemClickListner;
import com.unitedvideos.R;
import com.unitedvideos.application.MyApplication;

import java.util.ArrayList;
import java.util.Collections;

import androidx.recyclerview.widget.RecyclerView;

public class SwapeImageAdapter extends RecyclerView.Adapter<SwapeImageAdapter.Holder> {
	final int TYPE_BLANK;
	final int TYPE_IMAGE;
	private MyApplication application;
	private OnItemClickListner<Object> clickListner;
	private RequestManager glide;
	private LayoutInflater inflater;
	Context ctx;

	class removeImage implements OnClickListener {
		private final String val$data;
		private final int val$pos;

		removeImage(int i, String imageData) {
			this.val$pos = i;
			this.val$data = imageData;
		}

		public void onClick(View v) {
			SwapeImageAdapter.this.application.min_pos = Math.min(
					SwapeImageAdapter.this.application.min_pos,
					Math.max(0, this.val$pos - 1));
			MyApplication.isBreak = true;
			SwapeImageAdapter.this.application.removecropImage(this.val$pos);
			if (SwapeImageAdapter.this.clickListner != null) {
				SwapeImageAdapter.this.clickListner.onItemClick(v, this.val$data);
			}
			SwapeImageAdapter.this.notifyDataSetChanged();
		}
	}

	public class Holder extends RecyclerView.ViewHolder {
		private ImageView ivRemove;
		private ImageView ivThumb;
		View parent;


		public Holder(View v) {
			super(v);
			this.parent = v;

			this.ivThumb = v.findViewById(R.id.imgV_thumb);
			this.ivRemove = v.findViewById(R.id.imgView_remove);

		}

		public void onItemClick(View view, Object item) {
			if (SwapeImageAdapter.this.clickListner != null) {
				SwapeImageAdapter.this.clickListner.onItemClick(view, item);
			}
		}

	}

	public SwapeImageAdapter(Context activity) {
		ctx = activity;
		this.TYPE_IMAGE = 0;
		this.TYPE_BLANK = 1;
		this.application = MyApplication.getInstance();
		this.inflater = LayoutInflater.from(activity);
		this.glide = Glide.with(activity);
	}

	public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
		this.clickListner = clickListner;
	}

	public int getItemCount() {
		return this.application.getCropImages().size();
	}

	public String getItem(int pos) {
		ArrayList<String> list = this.application.getCropImages();
		if (list.size() <= pos) {
			return new String();
		}
		return  list.get(pos);
	}

	public void onBindViewHolder(final Holder holder, final int pos) {
		holder.parent.setVisibility(View.VISIBLE);
		String data = getItem(pos);
		this.glide.load(data).into(holder.ivThumb);
		if (getItemCount() <= 2) {
			holder.ivRemove.setVisibility(View.GONE);
		} else {
			holder.ivRemove.setVisibility(View.VISIBLE);
		}

		holder.ivRemove.setVisibility(View.VISIBLE);
		holder.ivRemove.setOnClickListener(new removeImage(pos,data));


	}

	public Holder onCreateViewHolder(ViewGroup parent, int pos) {
		View v = this.inflater.inflate(R.layout.selecteditem_grid, parent,
				false);

		Holder holder = new Holder(v);
		if (getItemViewType(pos) == 1) {
			v.setVisibility(View.INVISIBLE);
		} else {
			v.setVisibility(View.VISIBLE);
		}
		return holder;
	}

	public synchronized void swap(int fromPosition, int toPosition) {
		Collections.swap(this.application.getCropImages(), fromPosition,
				toPosition);
		notifyItemMoved(fromPosition, toPosition);
	}
}
