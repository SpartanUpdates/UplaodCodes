package com.imagetovideomoviemaker.photoslideshowwithmusic.util;

import android.annotation.*;
import java.io.*;
import android.os.*;
import android.content.*;


import com.xyz.imagetovideomoviewmaker.R;

import java.util.*;

@SuppressLint({ "DefaultLocale" })
public class FileUtilsLocal
{
    public static long mDeleteFileCount;
    public static File mSdCard;
    static final String rawExternalStorage;
    static String rawSecondaryStoragesStr;

    static {
        rawExternalStorage = System.getenv("EXTERNAL_STORAGE");
        FileUtilsLocal.rawSecondaryStoragesStr = System.getenv("SECONDARY_STORAGE");
        FileUtilsLocal.mSdCard = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
    }

    public FileUtilsLocal() {
        FileUtilsLocal.mDeleteFileCount = 0L;
    }

    public static void createAllDirectories(final Context context) {
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append("/");
        sb.append(context.getString(R.string.app_folder_name));
        final File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(file.getAbsolutePath());
        sb2.append("/tmp");
        final File file2 = new File(sb2.toString());
        if (!file2.exists()) {
            file2.mkdir();
        }
    }

    public static void createImagesDir(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb.append("/");
        sb.append(context.getString(R.string.app_folder_name));
        final File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
            return;
        }
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    final File file2 = listFiles[i];
                    if (file2.getName().endsWith(".jpg")) {
                        file2.delete();
                    }
                }
            }
        }
    }

    public static void deleteEditTempFile(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_folder_name));
        sb.append("/edittmp");
        final File file = new File(sb.toString());
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    listFiles[i].delete();
                }
            }
            file.delete();
        }
    }

    public static void deleteTempFile(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_folder_name));
        sb.append("/tmp");
        final File file = new File(sb.toString());
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    final File file2 = listFiles[i];
                    if ((file2.getName().endsWith(".jpg") || file2.getName().endsWith(".png")) && !file2.getName().startsWith("crop")) {
                        file2.delete();
                    }
                }
            }
            file.delete();
        }
    }

    public static void deleteTempFile(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    listFiles[i].delete();
                }
            }
            file.delete();
        }
    }

    public static void deleteThemes(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_folder_name));
        sb.append("/Themes");
        final File file = new File(sb.toString());
        if (file.exists()) {
            final File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int length = listFiles.length, i = 0; i < length; ++i) {
                    listFiles[i].delete();
                }
            }
            file.delete();
        }
    }

    public static boolean deleteTmpDir(final File file) {
        if (file.isDirectory()) {
            final String[] list = file.list();
            for (int length = list.length, i = 0; i < length; ++i) {
                if (!deleteTmpDir(new File(file, list[i]))) {
                    return false;
                }
            }
        }
        return file.delete();
    }

    public static String getFileExtention(final File file) {
        final String name = file.getName();
        return name.substring(name.lastIndexOf(".") + 1).toLowerCase();
    }

    public static String getPath(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_folder_name));
        return sb.toString();
    }

    public static boolean isPicture(final File file) {
        final String fileExtention = getFileExtention(file);
        return fileExtention.toLowerCase().equals("jpg") || fileExtention.toLowerCase().equals("bmp") || fileExtention.toLowerCase().equals("png") || fileExtention.toLowerCase().equals("jpeg");
    }

    public static void removeFile(final Context context, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append("/SlideShowMaker");
        final File[] listFiles = new File(new File(sb.toString()), "tmp").listFiles();
        String absolutePath;
        String name = absolutePath = null;
        for (int i = 0; i < listFiles.length; ++i) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("compair = ");
            sb2.append(listFiles[i].getAbsolutePath());
            if (listFiles[i].getName().startsWith(s.substring(0, 11))) {
                name = listFiles[i].getName();
            }
            if (listFiles[i].getName().startsWith("frame_00000")) {
                absolutePath = listFiles[i].getAbsolutePath();
            }
        }
        final StringBuilder sb3 = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getPath()));
        sb3.append("/");
        sb3.append(context.getResources().getString(R.string.app_folder_name));
        sb3.append("/tmp/");
        sb3.append(name);
        final File file = new File(sb3.toString());
        if (file.exists()) {
            file.delete();
        }
        final File file2 = new File(absolutePath);
        if (file2.exists()) {
            file2.delete();
        }
    }

    public static File[] sortByNumber(final File[] array) {
        Arrays.sort(array, new Comparator<File>() {
            private int extractNumber(final String s) {
                try {
                    return Integer.parseInt(s.substring(s.indexOf(95) + 1, 11));
                }
                catch (Exception ex) {
                    return 0;
                }
            }

            @Override
            public int compare(final File file, final File file2) {
                return this.extractNumber(file.getName()) - this.extractNumber(file2.getName());
            }
        });
        return array;
    }

    public static ArrayList<String> sortByNumberPath(final ArrayList<String> list) {
        int n;
        for (int i = 0; i < list.size(); i = n) {
            int j;
            for (n = (j = i + 1); j < list.size(); ++j) {
                final String substring = list.get(i).substring(list.get(i).lastIndexOf(47) + 1);
                final String substring2 = substring.substring(substring.indexOf(95) + 1, 11);
                final String substring3 = list.get(j).substring(list.get(j).lastIndexOf(47) + 1);
                if (Integer.parseInt(substring2) > Integer.parseInt(substring3.substring(substring3.indexOf(95) + 1, 11))) {
                    final String s = list.get(i);
                    list.set(i, list.get(j));
                    list.set(j, s);
                }
            }
        }
        return list;
    }
}
