package com.esc.beautymackupselficlam.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.collage.CustomGallery;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import java.util.ArrayList;

public class CustomGalleryAdapter extends BaseAdapter {
  private ArrayList<CustomGallery> data = new ArrayList();
  ImageLoader imageLoader;
  private LayoutInflater infalter;
  private boolean isActionMultiplePick;
  private Context context;

  public class ViewHolder {
    ImageView imgQueue;
    ImageView imgQueueMultiSelected;
  }

  public CustomGalleryAdapter(Context c, ImageLoader imageLoader) {
    this.infalter = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    this.context = c;
    this.imageLoader = imageLoader;
    System.out.println("here");
  }

  public int getCount() {
    System.out.println("data size " + this.data.size());
    return this.data.size();
  }

  public CustomGallery getItem(int position) {
    return (CustomGallery) this.data.get(position);
  }

  public long getItemId(int position) {
    return (long) position;
  }

  public void setMultiplePick(boolean isMultiplePick) {
    this.isActionMultiplePick = isMultiplePick;
    System.out.println("press");
  }

  public void selectAll(boolean selection) {
    for (int i = 0; i < this.data.size(); i++) {
      ((CustomGallery) this.data.get(i)).isSeleted = selection;
    }
    notifyDataSetChanged();
  }

  public ArrayList<CustomGallery> getSelected() {
    ArrayList<CustomGallery> dataList = new ArrayList();
    for (int i = 0; i < this.data.size(); i++) {
      if (((CustomGallery) this.data.get(i)).isSeleted) {
        dataList.add(this.data.get(i));
      }
    }
    return dataList;
  }

  public void addAll(ArrayList<CustomGallery> files) {
    try {
      this.data.clear();
      this.data.addAll(files);
    } catch (Exception e) {
      e.printStackTrace();
    }
    notifyDataSetChanged();
  }

  public void changeSelection(View v, int position) {
    if (((CustomGallery) this.data.get(position)).isSeleted) {
      ((CustomGallery) this.data.get(position)).isSeleted = false;
    } else {
      ((CustomGallery) this.data.get(position)).isSeleted = true;
    }
    ((ViewHolder) v.getTag()).imgQueueMultiSelected.setSelected(((CustomGallery) this.data.get(position)).isSeleted);
  }

  public View getView(int position, View convertView, ViewGroup parent) {
    final ViewHolder holder;
    if (convertView == null) {
      convertView = this.infalter.inflate(R.layout.gallery_item, null);
      holder = new ViewHolder();
      holder.imgQueue = (ImageView) convertView.findViewById(R.id.image);
      holder.imgQueueMultiSelected = (ImageView) convertView.findViewById(R.id.imgQueueMultiSelected);
      if (this.isActionMultiplePick) {
        holder.imgQueueMultiSelected.setVisibility(View.VISIBLE);
      } else {
        holder.imgQueueMultiSelected.setVisibility(View.GONE);
      }
      convertView.setTag(holder);
    } else {
      holder = (ViewHolder) convertView.getTag();
    }
    holder.imgQueue.setTag(Integer.valueOf(position));
    try {
      this.imageLoader.displayImage("file://" + ((CustomGallery) this.data.get(position)).sdcardPath, holder.imgQueue, new SimpleImageLoadingListener() {
        public void onLoadingStarted(String imageUri, View view) {
          holder.imgQueue.setImageResource(R.drawable.empty_photo);
          super.onLoadingStarted(imageUri, view);
        }
      });
      if (this.isActionMultiplePick) {
        holder.imgQueueMultiSelected.setSelected(((CustomGallery) this.data.get(position)).isSeleted);
        System.out.println("press11");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return convertView;
  }

  public void clearCache() {
    this.imageLoader.clearDiscCache();
    this.imageLoader.clearMemoryCache();
  }

  public void clear() {
    this.data.clear();
    notifyDataSetChanged();
  }
}
