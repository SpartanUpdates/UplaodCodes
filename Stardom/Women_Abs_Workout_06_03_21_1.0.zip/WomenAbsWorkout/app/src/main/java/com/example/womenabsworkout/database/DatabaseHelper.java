package com.example.womenabsworkout.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.womenabsworkout.R;

import org.json.JSONException;
import org.json.JSONObject;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static String EXC_DAY_TABLE = "exc_day";
    public static String EXC_DAY_TABLE_ADVANCED = "exc_advanced";
    public static String b = "FitDB";
    public static String c = "day";
    public static String d = "progress";
    public static String e = "counter";
    public static String f = "cycles";
    public static int f883a = 4;
    public static String g;
    public static String h;
    public Context i;
    public int[] j = new int[]{R.array.day1_cycles, R.array.day2_cycles, R.array.day3_cycles, R.array.day4_cycles, R.array.day5_cycles, R.array.day6_cycles, R.array.day7_cycles, R.array.day8_cycles, R.array.day9_cycles, R.array.day10_cycles, R.array.day11_cycles, R.array.day12_cycles, R.array.day13_cycles, R.array.day14_cycles, R.array.day15_cycles, R.array.day16_cycles, R.array.day17_cycles, R.array.day18_cycles, R.array.day19_cycles, R.array.day20_cycles, R.array.day21_cycles, R.array.day22_cycles, R.array.day23_cycles, R.array.day24_cycles, R.array.day25_cycles, R.array.day26_cycles, R.array.day27_cycles, R.array.day28_cycles, R.array.day29_cycles, R.array.day30_cycles};
    public int[] k = new int[]{R.array.adv_day1_cycles, R.array.adv_day2_cycles, R.array.adv_day3_cycles, R.array.adv_day4_cycles, R.array.adv_day5_cycles, R.array.adv_day6_cycles, R.array.adv_day7_cycles, R.array.adv_day8_cycles, R.array.adv_day9_cycles, R.array.adv_day10_cycles, R.array.adv_day11_cycles, R.array.adv_day12_cycles, R.array.adv_day13_cycles, R.array.adv_day14_cycles, R.array.adv_day15_cycles, R.array.adv_day16_cycles, R.array.adv_day17_cycles, R.array.adv_day18_cycles, R.array.adv_day19_cycles, R.array.adv_day20_cycles, R.array.adv_day21_cycles, R.array.adv_day22_cycles, R.array.adv_day23_cycles, R.array.adv_day24_cycles, R.array.adv_day25_cycles, R.array.adv_day26_cycles, R.array.adv_day27_cycles, R.array.adv_day28_cycles, R.array.adv_day29_cycles, R.array.adv_day30_cycles};
    public String l = "'Day ";
    public String n = "0.0";

    static {
        StringBuilder stringBuilder = new StringBuilder();
        String str = "CREATE TABLE ";
        stringBuilder.append(str);
        stringBuilder.append(EXC_DAY_TABLE);
        String str2 = " (";
        stringBuilder.append(str2);
        stringBuilder.append(c);
        String str3 = " TEXT, ";
        stringBuilder.append(str3);
        stringBuilder.append(d);
        String str4 = " REAL, ";
        stringBuilder.append(str4);
        stringBuilder.append(e);
        String str5 = " INTEGER, ";
        stringBuilder.append(str5);
        stringBuilder.append(f);
        String str6 = " TEXT)";
        stringBuilder.append(str6);
        g = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(EXC_DAY_TABLE_ADVANCED);
        stringBuilder.append(str2);
        stringBuilder.append(c);
        stringBuilder.append(str3);
        stringBuilder.append(d);
        stringBuilder.append(str4);
        stringBuilder.append(e);
        stringBuilder.append(str5);
        stringBuilder.append(f);
        stringBuilder.append(str6);
        h = stringBuilder.toString();
    }

    public DatabaseHelper(Context context) {
        super(context, b, (CursorFactory) null, f883a);
        this.i = context;
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        String str = "TAG";
        try {
            sQLiteDatabase.execSQL(g);
            Log.d(str, "table1 created");
            sQLiteDatabase.execSQL(h);
            Log.d(str, "table2 created");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        String str = "json str databs: ";
        String str2 = "TAG";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("path: ");
        stringBuilder.append(sQLiteDatabase.getPath());
        Log.i("dbpath: ", stringBuilder.toString());
        if (i == 3 || i == 4) {
            StringBuilder stringBuilder2 = new StringBuilder();
            String str3 = "ALTER TABLE ";
            stringBuilder2.append(str3);
            stringBuilder2.append(EXC_DAY_TABLE);
            String str4 = " ADD COLUMN ";
            stringBuilder2.append(str4);
            stringBuilder2.append(f);
            String str5 = " TEXT";
            stringBuilder2.append(str5);
            sQLiteDatabase.execSQL(stringBuilder2.toString());
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str3);
            stringBuilder2.append(EXC_DAY_TABLE_ADVANCED);
            stringBuilder2.append(str4);
            stringBuilder2.append(f);
            stringBuilder2.append(str5);
            sQLiteDatabase.execSQL(stringBuilder2.toString());
            try {
                JSONObject jSONObject = new JSONObject();
                JSONObject jSONObject2 = new JSONObject();
                for (int i3 = 1; i3 <= 30; i3++) {
                    String str6;
                    StringBuilder stringBuilder3;
                    int i4 = i3 - 1;
                    int[] intArray = this.i.getResources().getIntArray(this.j[i4]);
                    int[] intArray2 = this.i.getResources().getIntArray(this.k[i4]);
                    int length = intArray.length;
                    int i5 = 0;
                    int i6 = 0;
                    int i7 = i6;
                    while (i6 < length) {
                        try {
                            jSONObject.put(String.valueOf(i7), intArray[i6]);
                            i7++;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        i6++;
                    }
                    int length2 = intArray2.length;
                    length = 0;
                    while (i5 < length2) {
                        try {
                            jSONObject2.put(String.valueOf(length), intArray2[i5]);
                            length++;
                        } catch (JSONException e2) {
                            e2.printStackTrace();
                        }
                        i5++;
                    }
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str);
                    stringBuilder4.append(jSONObject.toString());
                    Log.e(str2, stringBuilder4.toString());
                    stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str);
                    stringBuilder4.append(jSONObject2.toString());
                    Log.e(str2, stringBuilder4.toString());
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(f, jSONObject.toString());
                    String str7 = "res: ";
                    String str8 = "'";
                    String str9 = "='Day ";
                    if (sQLiteDatabase != null) {
                        try {
                            str6 = EXC_DAY_TABLE;
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(c);
                            stringBuilder3.append(str9);
                            stringBuilder3.append(i3);
                            stringBuilder3.append(str8);
                            long update = (long) sQLiteDatabase.update(str6, contentValues, stringBuilder3.toString(), (String[]) null);
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(str7);
                            stringBuilder4.append(update);
                            Log.e(str2, stringBuilder4.toString());
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                    }
                    contentValues = new ContentValues();
                    contentValues.put(f, jSONObject2.toString());
                    if (sQLiteDatabase != null) {
                        try {
                            str6 = EXC_DAY_TABLE_ADVANCED;
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(c);
                            stringBuilder3.append(str9);
                            stringBuilder3.append(i3);
                            stringBuilder3.append(str8);
                            long update2 = (long) sQLiteDatabase.update(str6, contentValues, stringBuilder3.toString(), (String[]) null);
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(str7);
                            stringBuilder4.append(update2);
                            Log.e(str2, stringBuilder4.toString());
                        } catch (Exception e32) {
                            e32.printStackTrace();
                        }
                    }
                }
            } catch (Exception e4) {
                e4.printStackTrace();
            }
            Log.e(str2, "Case 3 db");
        }
    }
}
