package com.esc.phoneheart.batterymanager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.esc.phoneheart.activity.FinalScreen;
import com.esc.phoneheart.R;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.utility.GlobalData;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.Timer;
import java.util.TimerTask;
import androidx.appcompat.widget.Toolbar;

public class BatterySaverActivity extends ParentScreen {
    private Activity activity = BatterySaverActivity.this;
    public RelativeLayout inner_container;
    public boolean isAborted = false;
    public LinearLayout m;
    public LinearLayout n;
    public ProgressBar pbar;
    public int percentage;
    public Timer timer;
    public TextView tvpro;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private void navigateToCommonResultScreen() {
        if (!this.isAborted) {
            Intent intent = new Intent(this, FinalScreen.class);
            intent.putExtra(GlobalData.REDIRECTNOTI, true);
            intent.putExtra("FROMNOTI", true);
            intent.putExtra("DATA", getString(R.string.bat_booster_finish_success));
            intent.putExtra("TYPE", "BOOST");
            finish();
            startActivity(intent);
        }
    }

    private void removeHandler() {
        try {
            this.timer.cancel();
        } catch (Exception unused) {
        }
    }

    private void setAnim() {
        percentage = 100;
        timer = new Timer();
        timer.schedule(new TimerTask()
        {
            public void run() {
                BatterySaverActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        if (percentage >= 1) {
                            percentage = percentage - 1;
                            TextView d = tvpro;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(100 - percentage);
                            stringBuilder.append(" %");
                            d.setText(stringBuilder.toString());
                        } else {
                            timer.cancel();
                            BatterySaverActivity.this.navigateToCommonResultScreen();
                        }
                        BatterySaverActivity.this.pbar.setProgress(100 - percentage);
                    }
                });
            }
        }, 0, 50);
    }

    public void onBackPressed() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.module_bat_booster));
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dialouge_scan_back));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!BatterySaverActivity.this.doubleClicked()) {
                    dialog.dismiss();
                }
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!BatterySaverActivity.this.doubleClicked()) {
                    dialog.dismiss();
                    BatterySaverActivity.this.removeHandler();
                    BatterySaverActivity.this.isAborted = true;
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    BatterySaverActivity.this.finish();
                }
            }
        });
        dialog.show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        GlobalData.SETAPPLAnguage(this);
        setContentView(R.layout.activity_battery_saver);
        setDeviceDimensio();
        initToolbar();

        this.tvpro = findViewById(R.id.tv_pro);
        this.pbar = findViewById(R.id.p_bar);
        this.inner_container = findViewById(R.id.inner_container);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                this.pbar.getProgressDrawable().setColorFilter(getColor(R.color.color_bluedark), Mode.SRC_IN);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        setAnim();
        BannerAds();
    }

    private void initToolbar() {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            Drawable backArrow = getResources().getDrawable(R.drawable.ic_back_selector);
            getSupportActionBar().setHomeAsUpIndicator(backArrow);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle((CharSequence) "");
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return super.onOptionsItemSelected(menuItem);
    }
}
