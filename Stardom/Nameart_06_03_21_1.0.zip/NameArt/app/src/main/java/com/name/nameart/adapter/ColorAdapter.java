package com.name.nameart.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.R;


public class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.ViewHolder> {
    Context context;
    int index = -1;
    public int[] intArray;
    OnSelect onSelect;
    String status;

    public interface OnSelect {
        void onSelectColor(int i);
    }

    public ColorAdapter(Context context2, String str, OnSelect onSelect2) {
        this.context = context2;
        this.status = str;
        this.onSelect = onSelect2;
        this.intArray = context2.getResources().getIntArray(R.array.allcolors);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.color_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        try {
            viewHolder.color_img_row.setImageDrawable(null);
            viewHolder.color_img_row.setBackgroundColor(this.intArray[i]);
            viewHolder.color_img_row.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    ColorAdapter.this.index = i;
                    ColorAdapter.this.onSelect.onSelectColor(ColorAdapter.this.intArray[i]);
                    ColorAdapter.this.notifyDataSetChanged();
                }
            });
            if (this.index == i) {
                viewHolder.row_bg.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.row_bg.setBackgroundColor(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.intArray.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView color_img_row;
        public View parentLayout;
        public ConstraintLayout row_bg;

        public ViewHolder(View view) {
            super(view);
            this.color_img_row = (ImageView) view.findViewById(R.id.color_img_row);
            this.row_bg = (ConstraintLayout) view.findViewById(R.id.row_bg);
        }

        public ImageView getImage() {
            return this.color_img_row;
        }
    }
}
