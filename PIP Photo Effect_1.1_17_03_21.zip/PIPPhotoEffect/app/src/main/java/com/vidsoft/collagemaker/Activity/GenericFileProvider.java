package com.vidsoft.collagemaker.Activity;

import androidx.core.content.FileProvider;
public class GenericFileProvider extends FileProvider {
}
