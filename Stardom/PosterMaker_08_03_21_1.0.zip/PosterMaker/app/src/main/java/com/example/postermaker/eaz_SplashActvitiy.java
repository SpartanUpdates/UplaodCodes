package com.example.postermaker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.os.Build.VERSION_CODES.M;


public class eaz_SplashActvitiy extends AppCompatActivity {

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.eaz_splash);
        getWindow().setFlags(1024, 1024);


        if (Build.VERSION.SDK_INT >= M)
        {
            checkMultiplePermissions();
        } else {
            callfordata();
        }
    }

    @SuppressLint("NewApi")
    private void checkMultiplePermissions() {
        if (Build.VERSION.SDK_INT >= M) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            if (!addPermission(arrayList2, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                arrayList.add("Read Storage");
            }
            if (!addPermission(arrayList2, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            {
                arrayList.add("Write Storage");
            }
           /* if (!addPermission(arrayList2,Manifest.permission.MANAGE_EXTERNAL_STORAGE))
            {
                arrayList.add("Manage Storage");
            }*/
            if (arrayList2.size() > 0) {
                requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 111);
                return;
            }
            callfordata();
        }
    }

    private boolean addPermission(List<String> list, String str) {
        if (Build.VERSION.SDK_INT >= M) {
            if (Build.VERSION.SDK_INT >= M && checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                list.add(str);
                if (!shouldShowRequestPermissionRationale(str)) {
                    return false;
                }
            }
        }
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 111) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        HashMap hashMap = new HashMap();
        int i2 = 0;
        String str = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        hashMap.put(str, Integer.valueOf(0));
        String str2 =Manifest.permission.READ_EXTERNAL_STORAGE;
        hashMap.put(str2, Integer.valueOf(0));
       /* String str3=Manifest.permission.MANAGE_EXTERNAL_STORAGE;
        hashMap.put(str3,Integer.valueOf(0));
        while (i2 < strArr.length)
        {
            hashMap.put(strArr[i2], Integer.valueOf(iArr[i2]));
            i2++;
        }*/
        if (((Integer) hashMap.get(str2)).intValue() == 0 && ((Integer) hashMap.get(str)).intValue() == 0)
        {
            callfordata();
        } else if (Build.VERSION.SDK_INT >= M) {
            Toast.makeText(getApplicationContext(), "My App cannot run without Storage Permissions.\nRelaunch My App or allow permissions in Applications Settings", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void callfordata()
    {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                eaz_SplashActvitiy.this.HomeScreen();
            }
        }, 4000);
    }

    private void HomeScreen() {
        startActivity(new Intent(eaz_SplashActvitiy.this, eaz_MainActivity.class));
        finish();
    }

}
