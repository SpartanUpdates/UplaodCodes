package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;

public class FontSpacingCollageMaker implements SeekBar.OnSeekBarChangeListener {
    public final  CollageMakerDetailActivity e;

    public FontSpacingCollageMaker(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.e = collageMakerDetailActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            this.e.n0.setLineSpacing((float) i);
            this.e.n0.requestLayout();
            CollageMakerDetailActivity collageMakerDetailActivity = this.e;
            com.kotlinz.festivalstorymaker.Models.z.c cVar =  collageMakerDetailActivity.m0.get((Integer) collageMakerDetailActivity.n0.getTag());
            cVar.b = i + 5;
            CollageMakerDetailActivity collageMakerDetailActivity2 = this.e;
            collageMakerDetailActivity2.m0.set((Integer) collageMakerDetailActivity2.n0.getTag(), cVar);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
