package com.wavymusic.videolib.libffmpeg.utils;

import java.io.IOException;

public class StubOutputStream extends java.io.OutputStream
{
  private boolean closed;
  
  public StubOutputStream() {
    closed = false;
  }
  
  public void write(int oneByte)
    throws IOException
  {}
  
  public void close() throws IOException
  {
    super.close();
    closed = true;
  }
  
  public boolean isClosed() {
    return closed;
  }
}
