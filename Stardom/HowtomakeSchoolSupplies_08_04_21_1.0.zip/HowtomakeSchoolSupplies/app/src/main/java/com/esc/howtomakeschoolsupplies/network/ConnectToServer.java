package com.esc.howtomakeschoolsupplies.network;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Locale;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref.ObjectRef;
import com.esc.howtomakeschoolsupplies.pojo.Article;
import com.esc.howtomakeschoolsupplies.pojo.Category;

public class ConnectToServer {
    public static final Companion Companion = new Companion();
    private final long timeReconnect = 5000;

    public static final class Companion {
        private Companion() {
        }

        public final String postOnServer(String str) throws Exception {
            Intrinsics.checkParameterIsNotNull(str, "url");
            URLConnection openConnection = new URL(str).openConnection();
            if (openConnection != null) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(((HttpURLConnection) openConnection).getInputStream()));
                ObjectRef objectRef = new ObjectRef();
                StringBuffer stringBuffer = new StringBuffer();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    objectRef.element = readLine;
                    if (readLine != null) {
                        stringBuffer.append((String) objectRef.element);
                    } else {
                        bufferedReader.close();
                        str = stringBuffer.toString();
                        Intrinsics.checkExpressionValueIsNotNull(str, "response.toString()");
                        return str;
                    }
                }
            }
            throw new TypeCastException("null cannot be cast to non-null type java.net.HttpURLConnection");
        }
    }

    public interface LoadingArticles {
        void initArticles(List<Article> list);
    }

    public interface LoadingCategory {
        void initCategory(List<Category> list);
    }

    public interface LoadingRecommended {
        void initRecommended(List<Recommended> list);
    }

    public final long getTimeReconnect() {
        return this.timeReconnect;
    }

    public final void connectArticle(LoadingArticles loadingArticles) {
        Intrinsics.checkParameterIsNotNull(loadingArticles, "loadingArticles");
        JSONPlaceHolderApi jsonApi = NetworkService.INSTANCE.jsonApi();
        Locale locale = Locale.getDefault();
        Intrinsics.checkExpressionValueIsNotNull(locale, "Locale.getDefault()");
        jsonApi.getPostWithID(locale.getLanguage()).enqueue(new ConnectToServerconnectArticle1(this,loadingArticles));
    }

    public final void connectCategory(LoadingCategory loadingCategory) {
        Intrinsics.checkParameterIsNotNull(loadingCategory, "loadingCategory");
        JSONPlaceHolderApi jsonApi = NetworkService.INSTANCE.jsonApi();
        Locale locale = Locale.getDefault();
        Intrinsics.checkExpressionValueIsNotNull(locale, "Locale.getDefault()");
        jsonApi.getCategoryID(locale.getLanguage()).enqueue(new ConnectToServerconnectCategory1(loadingCategory));
    }
}
