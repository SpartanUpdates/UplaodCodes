package com.vidsoft.uvideostatus.clasees;

public class CustomCategoryItem {
    String CategoryName;
    String ID;

    public CustomCategoryItem(String str, String str2) {
        this.CategoryName = str;
        this.ID = str2;
    }

    public String getCategoryName() {
        return this.CategoryName;
    }

    public void setCategoryName(String str) {
        this.CategoryName = str;
    }

    public String getID() {
        return this.ID;
    }

    public void setID(String str) {
        this.ID = str;
    }
}
