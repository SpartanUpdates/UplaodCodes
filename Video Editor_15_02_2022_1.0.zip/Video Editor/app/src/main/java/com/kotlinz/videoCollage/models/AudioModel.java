package com.kotlinz.videoCollage.models;

import android.graphics.Bitmap;
import android.net.Uri;

public class AudioModel {
    String album;
    Uri albumArtUri;
    Long albumId;
    String artist;
    Bitmap bitmap;
    String data;
    int duration;
    String track;

    public String getTrack() {
        return this.track;
    }

    public void setTrack(String str) {
        this.track = str;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String str) {
        this.data = str;
    }

    public Long getAlbumId() {
        return this.albumId;
    }

    public void setAlbumId(Long l) {
        this.albumId = l;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setDuration(int i) {
        this.duration = i;
    }

    public Uri getAlbumArtUri() {
        return this.albumArtUri;
    }

    public void setAlbumArtUri(Uri uri) {
        this.albumArtUri = uri;
    }

    public Bitmap getBitmap() {
        return this.bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public String getAlbum() {
        return this.album;
    }

    public void setAlbum(String str) {
        this.album = str;
    }

    public String getArtist() {
        return this.artist;
    }

    public void setArtist(String str) {
        this.artist = str;
    }
}
