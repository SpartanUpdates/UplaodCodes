package com.kotlinz.puzzlecreator.Preferance;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.kotlinz.puzzlecreator.login.LoginActivity;

public class SessionManager {
    SharedPreferences pref;

    SharedPreferences.Editor editor;

    Context _context;

    int PRIVATE_MODE = 0;

    private static final String PREF_NAME = "puzzlecreator";

    private static final String IS_LOGIN = "IsLoggedIn";

    private static final String TOKEN = "token";

    private static final String MOBILE = "mobile";

    private static final String USER_MODE = "usermode";

    private static final String USER_ID = "userid";

    private static final String USER_NAME = "username";

    private static final String USER_POINTS = "userpoints";

    private static final String REFERAL_CODE = "referalcode";

    private static final String USER_TYPE = "usertype";

    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";

    private static final String BALANCE = "balance";

    private static final String BACK = "back";

    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }
    public String getToken() {
        return pref.getString(TOKEN, "");
    }

    public void setToken(String token) {
        editor.putString(TOKEN, token);
        editor.commit();
    }
    public Boolean isBack() {
        return pref.getBoolean(BACK, false);
    }

    public void setBack(Boolean back) {
        editor.putBoolean(BACK, back);
        editor.commit();
    }

    public String getBalance() {
        return pref.getString(BALANCE, "");
    }

    public void setBalance(String balance) {
        editor.putString(BALANCE, balance);
        editor.commit();
    }

    public String getUserType() {
        return pref.getString(USER_TYPE, "");
    }

    public void setUserType(String userType) {
        editor.putString(USER_TYPE, userType);
        editor.commit();
    }
    public String getUserName() {
        return pref.getString(USER_NAME, "");
    }

    public void setUserName(String uname) {
        editor.putString(USER_NAME, uname);
        editor.commit();
    }

    public String getUserPoints() {
        return pref.getString(USER_POINTS, "");
    }

    public void setUserPoints(String userPoints) {
        editor.putString(USER_POINTS, userPoints);
        editor.commit();
    }

    public String getUserMode() {
        return pref.getString(USER_MODE, "");
    }

    public void setUserMode(String umode) {
        editor.putString(USER_MODE, umode);
        editor.commit();
    }

    public String getUserId() {
        return pref.getString(USER_ID, "");
    }

    public void setUserId(String uid) {
        editor.putString(USER_ID, uid);
        editor.commit();
    }

    public String getReferalCode() {
        return pref.getString(REFERAL_CODE, "");
    }

    public void setReferalCode(String referalCode) {
        editor.putString(REFERAL_CODE, referalCode);
        editor.commit();
    }


    public String getMobile() {
        return pref.getString(MOBILE, "");
    }

    public void createLoginSession(String mobile) {
        editor.putBoolean(IS_LOGIN, true);
        editor.putString(MOBILE, mobile);
        editor.putBoolean(IS_FIRST_TIME_LAUNCH,false);
        editor.commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGIN, false);
    }

    public void logoutUser() {
        editor.clear();
        editor.commit();

        Intent i = new Intent(_context, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        _context.startActivity(i);
        ((Activity) _context).finish();

    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

}
