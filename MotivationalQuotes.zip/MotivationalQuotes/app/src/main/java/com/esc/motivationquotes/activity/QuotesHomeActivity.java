package com.esc.motivationquotes.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy;

import com.esc.motivationquotes.fragment.QuoteFragment;
import com.esc.motivationquotes.adapter.QuotesViewPagerAdapter;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatDialog;

import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.motivationquotes.R;
import com.google.gson.Gson;
import com.esc.motivationquotes.managers.CategoryManager;
import com.esc.motivationquotes.managers.FavoritesManager;
import com.esc.motivationquotes.managers.OwnQuotesManager;
import com.esc.motivationquotes.managers.QuotesManager;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.managers.ThemeManager;
import com.esc.motivationquotes.model.Information;
import com.esc.motivationquotes.model.Pref;
import com.esc.motivationquotes.model.Quote;
import com.esc.motivationquotes.model.Theme;
import com.esc.motivationquotes.usecases.AddReadQuoteUsecase;
import com.esc.motivationquotes.util.ColorUtils;
import com.esc.motivationquotes.util.Constants;
import com.esc.motivationquotes.util.FileChooserUtils;
import com.esc.motivationquotes.util.JsonUtils;
import com.esc.motivationquotes.util.QuoteUtils;
import com.esc.motivationquotes.util.TrackerEventUtils;
import com.esc.motivationquotes.reminders.RemindersUtils;
import com.esc.motivationquotes.widget.QuotesWidget;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class QuotesHomeActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String EXTRA_CHANGE_MODE = "change_mode";
    public static final String QUOTE_SELECTED = "quote_selected";
    private String appName;
    private AppCompatDialog addQuoteDialog;
    public ImageView iv_bg;
    private int currentTextColor;
    private int dialogStyle = R.style.DialogStyleLight;
    private ViewPager mPager;
    public QuotesViewPagerAdapter mPagerAdapter;
    private View overlay;
    private ArrayList<String> quotesList = new ArrayList();
    private BufferedReader reader;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ActionBarDrawerToggle drawerToggle;
    private Toolbar toolbar;
    private TextView txt_version;
    private ImageView iv_close;
    private ImageView ivFavorite;
    private ImageView iv_Theme;
    private ImageView ivShare;
    private Theme currentTheme;

    class Navigation implements NavigationView.OnNavigationItemSelectedListener {
        Navigation() {
        }

        public boolean onNavigationItemSelected(MenuItem item) {
            QuotesHomeActivity.this.drawerLayout.closeDrawers();

            switch (item.getItemId()) {

                case R.id.menu_category:
                    startActivityForResult(new Intent(QuotesHomeActivity.this, CategoriesActivity.class), 2);
                    return true;

                case R.id.menu_suggest_facts:
                    startActivity(new Intent(getApplicationContext(), AddFactsActivity.class));
                    finish();
                    return true;

                case R.id.menu_favorites:
                    startActivityForResult(new Intent(QuotesHomeActivity.this, FavoritesActivity.class), 4);
                    return true;

                case R.id.menu_reminder:
                    startActivity(new Intent(getApplicationContext(), OnBoardingRemindersActivity.class));
                    finish();
                    return true;

                case R.id.menu_share:
                    Intent share = new Intent("android.intent.action.SEND");
                    share.setType("text/plain");
                    share.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.share_msg) + getPackageName());
                    startActivity(Intent.createChooser(share, "Share Via"));
                    return true;

                case R.id.menu_review:
                    try {
                        startActivity(new Intent(
                                "android.intent.action.VIEW",
                                Uri.parse(getResources().getString(R.string.rate_us_url)
                                        + getPackageName())));
                        return true;
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(QuotesHomeActivity.this, "You don't have Google Play installed",
                                Toast.LENGTH_SHORT).show();
                        return true;
                    }

                case R.id.menu_feedback:
                    Intent feedback = new Intent(Intent.ACTION_SEND);
                    feedback.setType("message/rfc822");
                    feedback.putExtra(Intent.EXTRA_EMAIL, new String[]{getResources().getString(R.string.feedback_email)});
                    feedback.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                    feedback.setPackage("com.google.android.gm");
                    if (feedback.resolveActivity(getPackageManager()) != null)
                        startActivity(feedback);
                    else
                        Toast.makeText(QuotesHomeActivity.this, "Gmail App is not installed", Toast.LENGTH_SHORT).show();
                    return true;

                default:
                    return false;
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.quoteshome_activity);
        getWindow().setFlags(512, 512);

        toolbar = findViewById(R.id.toolbar);
        txt_version = findViewById(R.id.txt_version);
        setSupportActionBar(toolbar);

        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(new Navigation());

        drawerLayout = findViewById(R.id.drawerlayout);
        drawerToggle = new ActionBarDrawerToggle(this, this.drawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close);
        drawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });

        this.drawerLayout.setDrawerListener(drawerToggle);
        drawerToggle.syncState();

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_toggle_select);

        View headerview = navigationView.getHeaderView(0);
        iv_close = headerview.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);

        startAPIs();
        bindUI();
        setListeners();
        loadQuotes(null);
        getVersionInfo();

        if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            clearRemindersCategory();
        }
        onNewIntent(getIntent());
    }

    private void setListeners() {

        this.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareQuote();
            }
        });


        this.iv_Theme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(QuotesHomeActivity.this, ThemeActivity.class), 1);
            }
        });

        this.ivFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                manageFavorite();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                drawerLayout.closeDrawer(GravityCompat.START);
                break;
        }
    }

    private void getVersionInfo() {
        String VersionName = "";

        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            VersionName = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        txt_version.setText("v" + VersionName);
    }

    public void bindUI() {
        overlay = findViewById(R.id.overlay);
        mPager = findViewById(R.id.viewpager);
        iv_bg = findViewById(R.id.iv_bg);
        ivShare = findViewById(R.id.iv_share);
        iv_Theme = findViewById(R.id.iv_theme);
        ivFavorite = findViewById(R.id.iv_favorite);
    }

    public void shareQuote() {
        String text;
        Quote quote = QuoteUtils.getQuote(1, this.quotesList.get(this.mPager.getCurrentItem()), true);
        if (quote.getAuthor() == null || quote.getAuthor().isEmpty()) {
            text = quote.getText();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(quote.getText());
            stringBuilder.append("\n");
            stringBuilder.append(quote.getAuthor());
            text = stringBuilder.toString();
        }
        String str = TrackerEventUtils.KEY_QUOTE;
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SHARE_TOUCHED, str, text);
        TrackerEventUtils.registerActionMixpanel(TrackerEventUtils.ACTION_SHARED_MIXPANEL, text, CategoryManager.getCategorySelected(), ThemeManager.getTheme().getName());
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_FAVORITED_OR_SHARED_MIXPANEL, str, text);
        requestExternalStoragePermission();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_share, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.share:
                Intent share = new Intent("android.intent.action.SEND");
                share.setType("text/plain");
                share.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.share_msg) + getPackageName());
                startActivity(Intent.createChooser(share, "Share Via"));
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void manageFavorite() {
        Quote quote = QuoteUtils.getQuote(1, this.quotesList.get(this.mPager.getCurrentItem()), true);
        String sharequotes = quote.getText();
        if (sharequotes.contains("SHOW AD #")) {
            sharequotes = sharequotes.split("#")[1];
        }
        String str2 = TrackerEventUtils.KEY_QUOTE;
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_FAVORITE_TOUCHED, str2, sharequotes);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_FAVORITE_TOUCHED_MIXPANEL, str2, sharequotes);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_FAVORITED_OR_SHARED_MIXPANEL, str2, sharequotes);
        FavoritesManager.addFavorite(sharequotes);
    }

    public void requestExternalStoragePermission() {
        String str = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, str) == 0) {
            showShareDialog();
        } else if (VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(this, new String[]{str}, 71);
        } else {
            showShareDialog();
        }
    }

    private void showStoragePermissionRationale() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.PermissionsDialog);
        builder.setTitle(getString(R.string.permission_denied_title));
        builder.setMessage(getString(R.string.permission_denied_info));
        builder.setPositiveButton(getString(R.string.permission_denied_sure), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(getString(R.string.permission_denied_retry), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                requestExternalStoragePermission();
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void loadTheme(Theme theme) {
        if (theme == null) {
            theme = getDefaultTheme();
            ThemeManager.saveThemeData(theme);
        }
        if (theme.getName().equals("Default") && SettingsManager.isDarkMode()) {
            theme.setBackground("1A1C1E");
            theme.setColor("FFFFFF");
        }

        StringBuilder stringBuilder = new StringBuilder();
        String str = "#";
        stringBuilder.append(str);
        stringBuilder.append(theme.getBackground());
        Log.e("Background", "Background " + stringBuilder.toString());
        int parseColor = Color.parseColor(stringBuilder.toString());
        if (theme.getColor() != null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(theme.getColor());
            currentTextColor = Color.parseColor(stringBuilder2.toString());
        } else {
            currentTextColor = Color.parseColor("#ffffff");
        }
        if (SettingsManager.getOwnBackground() == null) {
            overlay.setVisibility(View.GONE);
            if (theme.getBackgroundImageName() != null) {
                int identifier = getResources().getIdentifier(theme.getBackgroundImageName(), "drawable", getPackageName());
                iv_bg.setScaleType(ScaleType.CENTER_CROP);
                iv_bg.setImageResource(identifier);
            } else {
                iv_bg.setImageResource(View.VISIBLE);
                iv_bg.setBackgroundColor(parseColor);
            }
        } else {
            iv_bg.setImageResource(View.VISIBLE);
            iv_bg.setBackgroundColor(parseColor);
            iv_bg.setScaleType(ScaleType.CENTER_CROP);
            iv_bg.setImageBitmap(FileChooserUtils.getBitmapOwn());
            overlay.setVisibility(View.VISIBLE);
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(theme.getColor());
            if (ColorUtils.isDarkColor(Color.parseColor(stringBuilder.toString()))) {
                overlay.setBackgroundResource(R.color.white_transparent);
            } else {
                overlay.setBackgroundResource(R.color.black_overlay);
            }
        }
        if (mPagerAdapter.getCurrentFragment() instanceof QuoteFragment) {
            ((QuoteFragment) mPagerAdapter.getCurrentFragment()).setFavoriteStatus();
        }
        updateWidget();
        mPagerAdapter.notifyDataSetChanged();
    }

    public void loadQuotes(String str) {

        this.quotesList = new ArrayList();
        String categorySelected = CategoryManager.getCategorySelected();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.favorites_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        if (categorySelected.equals(stringBuilder.toString())) {
            this.quotesList.addAll(FavoritesManager.getFavorites());
        } else if (categorySelected.equals(getString(R.string.own_quotes_category))) {
            this.quotesList.addAll(OwnQuotesManager.getOwnQuotes());
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.default_category));
            stringBuilder.append(SettingsManager.getLanguageFiles());
            if (categorySelected.equals(stringBuilder.toString())) {
                addQuotesByApp();
            } else {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    addQuotesFromFile(getResources().getIdentifier(categorySelected, "raw", getPackageName()));
                }
            }
            removeReadQuotesAndSort();
        }
        if (!(str == null || str.isEmpty())) {
            this.quotesList.add(0, str);
        }
        loadAdapter();
        loadTheme(ThemeManager.getTheme());
    }

    public void addQuotesFromFile(int i) {
        if (i == 0) {
            Resources resources = getResources();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("quotes");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            i = resources.getIdentifier(stringBuilder.toString(), "raw", getPackageName());
        }
        ArrayList arrayList = new ArrayList();
        try {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                this.reader = new BufferedReader(new InputStreamReader(getResources().openRawResource(i), StandardCharsets.UTF_8));
            }
            while (true) {
                String readLine = this.reader.readLine();
                if (readLine == null) {
                    this.quotesList.addAll(arrayList);
                    return;
                } else if (!(arrayList.contains(readLine) || this.quotesList.contains(readLine))) {
                    arrayList.add(readLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removeReadQuotesAndSort() {
        ArrayList readQuotes = QuotesManager.getReadQuotes();
        if (readQuotes != null) {
            this.quotesList.removeAll(readQuotes);
        }
        readQuotes = new ArrayList();
        ArrayList arrayList = new ArrayList();
        readQuotes.addAll(this.quotesList);
        Iterator it = readQuotes.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            int min = Math.min(10, arrayList.size());
            arrayList.add(Math.max(0, arrayList.size() - (min != 0 ? new Random().nextInt(min) : 0)), str);
        }
        this.quotesList.clear();
        this.quotesList.addAll(arrayList);
    }

    private void loadAdapter() {
        QuotesViewPagerAdapter quotesViewPagerAdapter = new QuotesViewPagerAdapter(getSupportFragmentManager(), this.quotesList, this);
        this.mPagerAdapter = quotesViewPagerAdapter;
        this.mPager.setAdapter(quotesViewPagerAdapter);
        this.mPager.clearOnPageChangeListeners();
        final ViewPager.OnPageChangeListener listener = new ViewPager.OnPageChangeListener() {
            public void onPageScrollStateChanged(int i) {
            }

            public void onPageScrolled(int i, float f, int i2) {
            }

            public void onPageSelected(int i) {
                if (QuotesHomeActivity.this.mPagerAdapter.getCurrentFragment() instanceof QuoteFragment) {
                    ((QuoteFragment) QuotesHomeActivity.this.mPagerAdapter.getCurrentFragment()).setFavoriteStatus();
                }

                TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_READ_QUOTE, TrackerEventUtils.KEY_QUOTE, QuotesHomeActivity.this.quotesList.get(i));
                String categorySelected = CategoryManager.getCategorySelected();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(QuotesHomeActivity.this.getString(R.string.favorites_category));
                stringBuilder.append(SettingsManager.getLanguageFiles());
                if (!categorySelected.equals(stringBuilder.toString()) && !CategoryManager.getCategorySelected().equals(QuotesHomeActivity.this.getString(R.string.own_quotes_category))) {
                    new AddReadQuoteUsecase(QuotesHomeActivity.this.quotesList.get(i)).execute();
                    if (i == QuotesHomeActivity.this.mPagerAdapter.getCount() - 1) {
                        QuotesHomeActivity.this.resetQuotes();
                    }
                }
            }
        };
        this.mPager.addOnPageChangeListener(listener);
        this.mPager.post(new Runnable() {
            @Override
            public void run() {
                if (quotesList.isEmpty()) {
                    resetQuotes();
                } else {
                    listener.onPageSelected(0);
                }
            }
        });
    }

    private void resetQuotes() {
        QuotesManager.removeQuotesRead();
        if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            loadQuotes(null);
        }
    }

    private void showShareDialog() {

        final AppCompatDialog appCompatDialog = new AppCompatDialog(this, this.dialogStyle);
        addQuoteDialog = appCompatDialog;
        appCompatDialog.setContentView(R.layout.dialog_sharequotes);
        addQuoteDialog.setCanceledOnTouchOutside(true);
        Button btn_sharetext = addQuoteDialog.findViewById(R.id.btn_sharetext);
        Button btn_shareimage = addQuoteDialog.findViewById(R.id.btn_shareimage);

        btn_sharetext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareTextUrl();
                addQuoteDialog.dismiss();
            }
        });

        btn_shareimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareImageIntent();
                addQuoteDialog.dismiss();
            }
        });

        if (!addQuoteDialog.isShowing() && !isFinishing()) {
            this.addQuoteDialog.show();
        }
    }

    @SuppressLint("WrongConstant")
    private void shareTextUrl() {
        String text;
        Quote quote = QuoteUtils.getQuote(1, this.quotesList.get(this.mPager.getCurrentItem()), true);
        if (quote.getAuthor() == null || quote.getAuthor().isEmpty()) {
            text = quote.getText();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(quote.getText());
            stringBuilder.append("\n");
            stringBuilder.append(quote.getAuthor());
            text = stringBuilder.toString();
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.addFlags(524288);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(text);
        stringBuilder2.append(getString(R.string.from));
        stringBuilder2.append(" ");
        stringBuilder2.append(getString(R.string.app_name));
        stringBuilder2.append(" app: ");
        stringBuilder2.append(getString(R.string.share_url));
        intent.putExtra("android.intent.extra.TEXT", stringBuilder2.toString());
        startActivity(Intent.createChooser(intent, getString(R.string.share_text)));
    }

    private void shareImageIntent() {
        visibilityIconsToShare(false);
        Bitmap bitmapFromView = getBitmapFromView(findViewById(R.id.linearMain));
        try {
            File file = new File(Constants.DIR_DATA);
            if (!file.exists()) {
                file.mkdirs();
            }
            StrictMode.setVmPolicy(new VmPolicy.Builder().build());
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("image/jpeg");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmapFromView.compress(CompressFormat.JPEG, 100, byteArrayOutputStream);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append(File.separator);
            stringBuilder.append("temporary_file.jpg");
            File file2 = new File(stringBuilder.toString());
            try {
                file2.createNewFile();
                new FileOutputStream(file2).write(byteArrayOutputStream.toByteArray());
            } catch (IOException e) {
                e.printStackTrace();
            }
            intent.putExtra("android.intent.extra.STREAM", Uri.parse("file:///sdcard/temporary_file.jpg"));
            startActivity(Intent.createChooser(intent, "Share Image"));
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        visibilityIconsToShare(true);
    }

    @SuppressLint("WrongConstant")
    private void visibilityIconsToShare(boolean z) {
        if (z) {
            changeIconVisibility(1, 0, this.mPagerAdapter.getCurrentFragment());
            changeIconVisibility(0, 0, this.mPagerAdapter.getCurrentFragment());
            changeIconVisibility(2, 0, this.mPagerAdapter.getCurrentFragment());
            return;
        }
        changeIconVisibility(1, 8, this.mPagerAdapter.getCurrentFragment());
        changeIconVisibility(0, 8, this.mPagerAdapter.getCurrentFragment());
        changeIconVisibility(2, 8, this.mPagerAdapter.getCurrentFragment());
    }

    private Bitmap getBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Drawable background = view.getBackground();
        if (background != null) {
            background.draw(canvas);
        } else {
            canvas.drawColor(-1);
        }
        view.draw(canvas);
        return createBitmap;
    }

    public void showNextQuote() {
        if (this.mPager != null) {
            QuotesViewPagerAdapter quotesViewPagerAdapter = this.mPagerAdapter;
            if (quotesViewPagerAdapter != null && this.mPager.getCurrentItem() < quotesViewPagerAdapter.getCount()) {
                ViewPager viewPager = this.mPager;
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
            }
        }
    }

    private void startAPIs() {
        String packageName = getApplicationContext().getPackageName();
        this.appName = packageName;
        packageName = packageName.substring(8).replace('.', '_');
        this.appName = packageName;
        Log.v("APP", packageName);
        Map hashMap = new HashMap();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.appName);
        stringBuilder.append("_app_rated");
        hashMap.put(stringBuilder.toString(), Long.valueOf(8));
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.appName);
        stringBuilder.append("_app_no_rated");
        hashMap.put(stringBuilder.toString(), Long.valueOf(10));
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.appName);
        stringBuilder.append("app_first_time");
        hashMap.put(stringBuilder.toString(), Long.valueOf(3));
    }

    private Theme getDefaultTheme() {
        Iterator it = JsonUtils.getThemes(this).iterator();
        while (it.hasNext()) {
            Theme theme = (Theme) it.next();
            if (theme.getName().equalsIgnoreCase(getString(R.string.default_th))) {
                return theme;
            }
        }
        return null;
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 1) {
            currentTheme = (Theme) intent.getExtras().getSerializable(Theme.TAG);
            ThemeManager.saveThemeData(currentTheme);
            loadTheme(currentTheme);

        } else if (i == 2) {
            CategoryManager.setCategorySelected(CategoryManager.getCategorySelected());
            loadQuotes(null);
        } else if (i == 4) {
            if (intent == null) {
                return;
            }
            if (intent.hasExtra(EXTRA_CHANGE_MODE)) {
                reloadTheme();
                return;
            }
            loadQuotes(null);
            reloadTheme();
        } else if (i == 3) {
            loadQuotes(null);
        }

        super.onActivityResult(i, i2, intent);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr != null && iArr.length > 0 && iArr[0] == 0) {
            showShareDialog();
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            showStoragePermissionRationale();
        } else {
            @SuppressLint("WrongConstant") Snackbar make = Snackbar.make(findViewById(R.id.linearMain), getString(R.string.permission_bar_title), 0);
            make.getView().setBackgroundColor(ContextCompat.getColor(this, R.color.color_white));
            make.setAction(getString(R.string.permission_go_settings), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.fromParts("package", getPackageName(), null));
                    startActivity(intent);
                }
            });
            make.show();
        }
    }

    public void onStart() {
        super.onStart();
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();
        if (extras != null) {
            boolean containsKey = extras.containsKey(Constants.NOTIFICATION_MESSAGE);
            String str = TrackerEventUtils.KEY_FULL_QUOTE;
            String str2;
            if (containsKey) {
                str2 = (String) extras.get(Constants.NOTIFICATION_MESSAGE);
                if (str2 != null) {
                    TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_LAUNCHED_FROM_REMINDER, str, str2);
                    loadQuotes(str2);
                    return;
                }
                return;
            }
            String str3 = QUOTE_SELECTED;
            if (extras.getString(str3) != null) {
                loadQuotes(extras.getString(str3));
            } else if (extras.containsKey(Constants.WIDGET_MESSAGE)) {
                str2 = (String) extras.get(Constants.WIDGET_MESSAGE);
                if (str2 != null) {
                    TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_LAUNCHED_FROM_WIDGET, str, str2);
                    loadQuotes(str2);
                }
            } else {
                TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_LAUNCHED_FROM_QUOTE_MIXPANEL, null, null);
            }
        }
    }

    private void addQuotesByApp() {
        String languageFiles = SettingsManager.getLanguageFiles();
        Resources resources = getResources();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("quotes");
        stringBuilder.append(languageFiles);
        addQuotesFromFile(resources.getIdentifier(stringBuilder.toString(), "raw", getPackageName()));
    }

    private void clearRemindersCategory() {
        Information informationJson = null;
        if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            informationJson = getInformationJson();
        }
        CategoryManager.clearCategoriesReminder();
        CategoryManager.addCategoryReminder(informationJson.getCategories().get(0));
        String str = "1";
        if (Pref.getValue(this, Constants.IS_SLIDER_ON, str).equals(str)) {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                RemindersUtils.setAlarmOnTime(this);
            }
        }
        SettingsManager.setAppUpdate(false);
    }

    private void updateWidget() {
        Intent intent = new Intent(this, QuotesWidget.class);
        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        intent.putExtra("appWidgetIds", AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), QuotesWidget.class)));
        sendBroadcast(intent);
    }

    private void reloadTheme() {
        recreate();
    }

    public Information getInformationJson() {
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("information");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            stringBuilder.append(".json");
            InputStream open = assets.open(stringBuilder.toString());
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                return new Gson().fromJson(new String(bArr, StandardCharsets.UTF_8), Information.class);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void changeIconVisibility(int i, int i2, Fragment fragment) {
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(QuotesHomeActivity.this, HomeActivity.class));
        finish();
    }
}
