package com.esc.flashlight.flashlight.controller;

import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.util.Log;
import android.view.SurfaceView;

public class BaseFlashController implements BaseFlashControllerInterface {
    protected Camera mCamera;
    final int mCameraId;
    protected boolean toggle;

    /* Access modifiers changed, original: protected */
    public void afterCameraOpen() {
    }

    /* Access modifiers changed, original: protected */
    public void beforeCameraRelease() {
    }

    /* Access modifiers changed, original: protected */
    public void onStartUse() {
    }

    public BaseFlashController(int i) {
        this.mCameraId = i;
    }

    /* Access modifiers changed, original: protected */
    public void initCamera() {
        Log.d(getClass().getSimpleName(), "invoke: initCamera");
        try {
            if (this.mCamera == null) {
                int i = this.mCameraId;
                if (i == -1) {
                    this.mCamera = Camera.open();
                } else {
                    this.mCamera = Camera.open(i);
                }
                afterCameraOpen();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* Access modifiers changed, original: protected */
    public void releaseCamera() {
        Log.d(getClass().getSimpleName(), "invoke: releaseCamera");
        if (this.mCamera != null) {
            try {
                beforeCameraRelease();
                this.mCamera.release();
            } catch (Exception e) {
                e.printStackTrace();
            } catch (Throwable th) {
                this.mCamera = null;
            }
            this.mCamera = null;
        }
    }

    public void useStart(SurfaceView surfaceView) {
        Log.d(getClass().getSimpleName(), "invoke: useStart");
        initCamera();
        onStartUse();
        flashOff();
    }

    public void useStop() {
        Log.d(getClass().getSimpleName(), "invoke: useStop");
        if (this.mCamera != null) {
            flashOff();
            releaseCamera();
        }
    }

    public void flashOn() {
        Log.d(getClass().getSimpleName(), "invoke: flashOn");
        try {
            if (!this.toggle) {
                Parameters parameters = this.mCamera.getParameters();
                parameters.setFlashMode("torch");
                this.mCamera.setParameters(parameters);
                this.toggle = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void flashOff() {
        Log.d(getClass().getSimpleName(), "invoke: flashOff");
        try {
            if (this.toggle) {
                Parameters parameters = this.mCamera.getParameters();
                parameters.setFlashMode("off");
                this.mCamera.setParameters(parameters);
                this.toggle = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
