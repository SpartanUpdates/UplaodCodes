package com.rtovehicleinformation.activity;

import static com.rtovehicleinformation.utils.nativeadsmethod.populateUnifiedNativeAdView;

import android.app.Activity;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.rtovehicleinformation.R;
import butterknife.BindView;
import butterknife.ButterKnife;

public class VehicleExpenseOptionsActivity extends AppCompatActivity {

    Activity activity = VehicleExpenseOptionsActivity.this;
    @BindView(R.id.accessories)
    CardView accessories;
    @BindView(R.id.carfuel)
    CardView carfuel;
    @BindView(R.id.cleanlines)
    CardView cleanlines;
    @BindView(R.id.maintenance)
    CardView maintenance;
    @BindView(R.id.otherexpense)
    CardView otherexpense;
    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.iv_back)
    ImageView ivback;

    private NativeAd nativeAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense_options);
        ButterKnife.bind(this);
        LoadNativeAds();
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.accessories.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VehicleExpenseOptionsActivity.this, ExpenceFormActivity.class);
                intent.putExtra("categoryname", "Accessories & Tuning");
                intent.putExtra("categoryimg", R.drawable.accessories_tuning_ve);
                intent.putExtra("btn", "SAVE");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        });
        this.cleanlines.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VehicleExpenseOptionsActivity.this, ExpenceFormActivity.class);
                intent.putExtra("categoryname", "Cleanlines & comfort");
                intent.putExtra("categoryimg", R.drawable.cleaning_tuning_ve);
                intent.putExtra("btn", "SAVE");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        });
        this.carfuel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VehicleExpenseOptionsActivity.this, ExpenceFormActivity.class);
                intent.putExtra("categoryname", "Car Fuel");
                intent.putExtra("categoryimg", R.drawable.petrol_pump_ve);
                intent.putExtra("btn", "SAVE");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        });
        this.maintenance.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VehicleExpenseOptionsActivity.this, ExpenceFormActivity.class);
                intent.putExtra("categoryname", "Maintenance");
                intent.putExtra("categoryimg", R.drawable.maintenance_ve);
                intent.putExtra("btn", "SAVE");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        });
        this.otherexpense.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VehicleExpenseOptionsActivity.this, ExpenceFormActivity.class);
                intent.putExtra("categoryname", "Other expense");
                intent.putExtra("categoryimg", R.drawable.wallet_ve);
                intent.putExtra("btn", "SAVE");
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        });

    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleExpenseOptionsActivity.this.nativeAd != null) {
                            VehicleExpenseOptionsActivity.this.nativeAd.destroy();
                        }
                        VehicleExpenseOptionsActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }



    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        return true;
    }

    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), VehicleExpenseActivity.class));
        finish();
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }
}
