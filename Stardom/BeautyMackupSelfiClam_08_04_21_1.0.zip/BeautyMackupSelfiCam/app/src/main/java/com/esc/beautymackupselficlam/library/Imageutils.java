package com.esc.beautymackupselficlam.library;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

@SuppressLint({"SdCardPath"})
public class Imageutils {
  Context context;
  private Activity current_activity;
  private Fragment current_fragment;
  private int from = 0;
  private ImageAttachmentListener imageAttachment_callBack;
  private Uri imageUri;
  private boolean isFragment = false;
  private File path = null;
  private String selected_path = "";

  public interface ImageAttachmentListener {
    void image_attachment(int i, String str, Bitmap bitmap, Uri uri);
  }

  public Imageutils(Activity act) {
    this.context = act;
    this.current_activity = act;
    this.imageAttachment_callBack = (ImageAttachmentListener) this.context;
  }

  public Imageutils(Activity act, Fragment fragment, boolean isFragment) {
    this.context = act;
    this.current_activity = act;
    this.imageAttachment_callBack = (ImageAttachmentListener) fragment;
    if (isFragment) {
      this.isFragment = true;
      this.current_fragment = fragment;
    }
  }

  public String getfilename_from_path(String path) {
    return path.substring(path.lastIndexOf(47) + 1, path.length());
  }

  public Uri getImageUri(Context context, Bitmap photo) {
    photo.compress(CompressFormat.PNG, 80, new ByteArrayOutputStream());
    return Uri.parse(Media.insertImage(context.getContentResolver(), photo, "Title", null));
  }

  public String getPath(Uri uri) {
    Cursor cursor = this.context.getContentResolver().query(uri, new String[]{"_data"}, null, null, null);
    if (cursor == null) {
      return uri.getPath();
    }
    int column_index = cursor.getColumnIndexOrThrow("_data");
    cursor.moveToFirst();
    String path = cursor.getString(column_index);
    cursor.close();
    return path;
  }

  public Bitmap StringToBitMap(String encodedString) {
    try {
      byte[] encodeByte = Base64.decode(encodedString, 0);
      return BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
    } catch (Exception e) {
      e.getMessage();
      return null;
    }
  }

  public String BitMapToString(Bitmap bitmap) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    bitmap.compress(CompressFormat.PNG, 80, baos);
    return Base64.encodeToString(baos.toByteArray(), 0);
  }

  public boolean isDeviceSupportCamera() {
    if (this.context.getPackageManager().hasSystemFeature("android.hardware.camera")) {
      return true;
    }
    return false;
  }

  public Bitmap compressImage(String imageUri, float height, float width) {
    String filePath = getRealPathFromURI(imageUri);
    Bitmap scaledBitmap = null;
    Options options = new Options();
    options.inJustDecodeBounds = true;
    Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
    int actualHeight = options.outHeight;
    int actualWidth = options.outWidth;
    float maxHeight = height;
    float maxWidth = width;
    float imgRatio = (float) (actualWidth / actualHeight);
    float maxRatio = maxWidth / maxHeight;
    if (((float) actualHeight) > maxHeight || ((float) actualWidth) > maxWidth) {
      if (imgRatio < maxRatio) {
        actualWidth = (int) (((float) actualWidth) * (maxHeight / ((float) actualHeight)));
        actualHeight = (int) maxHeight;
      } else if (imgRatio > maxRatio) {
        actualHeight = (int) (((float) actualHeight) * (maxWidth / ((float) actualWidth)));
        actualWidth = (int) maxWidth;
      } else {
        actualHeight = (int) maxHeight;
        actualWidth = (int) maxWidth;
      }
    }
    options.inSampleSize = calculateInSampleSize(options, actualWidth, actualHeight);
    options.inJustDecodeBounds = false;
    options.inPurgeable = true;
    options.inInputShareable = true;
    options.inTempStorage = new byte[16384];
    try {
      bmp = BitmapFactory.decodeFile(filePath, options);
    } catch (OutOfMemoryError exception) {
      exception.printStackTrace();
    }
    try {
      scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight, Config.ARGB_8888);
    } catch (OutOfMemoryError exception2) {
      exception2.printStackTrace();
    }
    float ratioX = ((float) actualWidth) / ((float) options.outWidth);
    float ratioY = ((float) actualHeight) / ((float) options.outHeight);
    float middleX = ((float) actualWidth) / 2.0f;
    float middleY = ((float) actualHeight) / 2.0f;
    Matrix scaleMatrix = new Matrix();
    scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
    Canvas canvas = new Canvas(scaledBitmap);
    canvas.setMatrix(scaleMatrix);
    canvas.drawBitmap(bmp, middleX - ((float) (bmp.getWidth() / 2)), middleY - ((float) (bmp.getHeight() / 2)), new Paint(2));
    try {
      int orientation = new ExifInterface(filePath).getAttributeInt("Orientation", 0);
      Log.d("EXIF", "Exif: " + orientation);
      Matrix matrix = new Matrix();
      if (orientation == 6) {
        matrix.postRotate(90.0f);
        Log.d("EXIF", "Exif: " + orientation);
      } else if (orientation == 3) {
        matrix.postRotate(180.0f);
        Log.d("EXIF", "Exif: " + orientation);
      } else if (orientation == 8) {
        matrix.postRotate(270.0f);
        Log.d("EXIF", "Exif: " + orientation);
      }
      return Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }

  private String getRealPathFromURI(String contentURI) {
    Uri contentUri = Uri.parse(contentURI);
    Cursor cursor = this.context.getContentResolver().query(contentUri, null, null, null, null);
    if (cursor == null) {
      return contentUri.getPath();
    }
    cursor.moveToFirst();
    return cursor.getString(cursor.getColumnIndex("_data"));
  }

  public int calculateInSampleSize(Options options, int reqWidth, int reqHeight) {
    int height = options.outHeight;
    int width = options.outWidth;
    int inSampleSize = 1;
    if (height > reqHeight || width > reqWidth) {
      int heightRatio = Math.round(((float) height) / ((float) reqHeight));
      int widthRatio = Math.round(((float) width) / ((float) reqWidth));
      if (heightRatio < widthRatio) {
        inSampleSize = heightRatio;
      } else {
        inSampleSize = widthRatio;
      }
    }
    while (((float) (width * height)) / ((float) (inSampleSize * inSampleSize)) > ((float) ((reqWidth * reqHeight) * 2))) {
      inSampleSize++;
    }
    return inSampleSize;
  }

  public void launchCamera(int from) {
    this.from = from;
    if (VERSION.SDK_INT < 23) {
      camera_call();
    } else if (this.isFragment) {
      permission_check_fragment(1);
    } else {
      permission_check(1);
    }
  }

  public void launchGallery(int from) {
    this.from = from;
    if (VERSION.SDK_INT < 23) {
      galley_call();
    } else if (this.isFragment) {
      permission_check_fragment(2);
    } else {
      permission_check(2);
    }
  }

  public void imagepicker(final int from) {
    this.from = from;
    final CharSequence[] items = isDeviceSupportCamera() ? new CharSequence[]{"Camera", "Gallery"} : new CharSequence[]{"Gallery"};
    Builder alertdialog = new Builder(this.current_activity);
    alertdialog.setTitle("Add Image");
    alertdialog.setItems(items, new OnClickListener() {
      public void onClick(DialogInterface dialog, int item) {
        if (items[item].equals("Camera")) {
          Imageutils.this.launchCamera(from);
        } else if (items[item].equals("Gallery")) {
          Imageutils.this.launchGallery(from);
        }
      }
    });
    alertdialog.show();
  }

  public void permission_check(final int code) {
    if (ContextCompat.checkSelfPermission(this.current_activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != 0) {
      if (ActivityCompat.shouldShowRequestPermissionRationale(this.current_activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
        ActivityCompat.requestPermissions(this.current_activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, code);
        return;
      }
      showMessageOKCancel("For adding images , You need to provide permission to access your files", new OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
          ActivityCompat.requestPermissions(Imageutils.this.current_activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, code);
        }
      });
    } else if (code == 1) {
      camera_call();
    } else if (code == 2) {
      galley_call();
    }
  }

  public void permission_check_fragment(final int code) {
    Log.d("ContentValues", "permission_check_fragment: " + code);
    if (ContextCompat.checkSelfPermission(this.current_activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != 0) {
      if (ActivityCompat.shouldShowRequestPermissionRationale(this.current_activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
        this.current_fragment.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, code);
        return;
      }
      showMessageOKCancel("For adding images , You need to provide permission to access your files", new OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
          Imageutils.this.current_fragment.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, code);
        }
      });
    } else if (code == 1) {
      camera_call();
    } else if (code == 2) {
      galley_call();
    }
  }

  private void showMessageOKCancel(String message, OnClickListener okListener) {
    new AlertDialog.Builder(this.current_activity).setMessage((CharSequence) message).setPositiveButton((CharSequence) "OK", okListener).setNegativeButton((CharSequence) "Cancel", null).create().show();
  }

  public void camera_call() {
    this.imageUri = this.current_activity.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, new ContentValues());
    Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    intent1.putExtra("output", this.imageUri);
    if (this.isFragment) {
      this.current_fragment.startActivityForResult(intent1, 0);
    } else {
      this.current_activity.startActivityForResult(intent1, 0);
    }
  }

  public void galley_call() {
    Log.d("ContentValues", "galley_call: ");
    Intent intent2 = new Intent(Intent.ACTION_PICK, Media.EXTERNAL_CONTENT_URI);
    intent2.setType("image/*");
    if (this.isFragment) {
      this.current_fragment.startActivityForResult(intent2, 1);
    } else {
      this.current_activity.startActivityForResult(intent2, 1);
    }
  }

  public void request_permission_result(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    switch (requestCode) {
      case 1:
        if (grantResults.length <= 0 || grantResults[0] != 0) {
          Toast.makeText(this.current_activity, "Permission denied", Toast.LENGTH_SHORT).show();
          return;
        } else {
          camera_call();
          return;
        }
      case 2:
        if (grantResults.length <= 0 || grantResults[0] != 0) {
          Toast.makeText(this.current_activity, "Permission denied", Toast.LENGTH_SHORT).show();
          return;
        } else {
          galley_call();
          return;
        }
      default:
        return;
    }
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    Activity activity;
    switch (requestCode) {
      case 0:
        activity = this.current_activity;
        if (resultCode == -1) {
          Log.i("Camera Selected", "Photo");
          try {
            this.selected_path = null;
            this.selected_path = getPath(this.imageUri);
            this.imageAttachment_callBack.image_attachment(this.from, this.selected_path.substring(this.selected_path.lastIndexOf("/") + 1), compressImage(this.imageUri.toString(), 816.0f, 612.0f), this.imageUri);
            return;
          } catch (Exception e) {
            e.printStackTrace();
            return;
          }
        }
        return;
      case 1:
        activity = this.current_activity;
        if (resultCode == -1) {
          Log.i("Gallery", "Photo");
          Uri selectedImage = data.getData();
          try {
            this.selected_path = null;
            this.selected_path = getPath(selectedImage);
            this.imageAttachment_callBack.image_attachment(this.from, this.selected_path.substring(this.selected_path.lastIndexOf("/") + 1), compressImage(selectedImage.toString(), 816.0f, 612.0f), selectedImage);
            return;
          } catch (Exception e2) {
            e2.printStackTrace();
            return;
          }
        }
        return;
      default:
        return;
    }
  }

  public Bitmap getImage_FromUri(Uri uri, float height, float width) {
    Bitmap bitmap = null;
    try {
      bitmap = compressImage(uri.toString(), height, width);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return bitmap;
  }

  public String getFileName_from_Uri(Uri uri) {
    try {
      String path = getRealPathFromURI(uri.getPath());
      return path.substring(path.lastIndexOf("/") + 1);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public boolean checkimage(String file_name, String file_path) {
    this.path = new File(file_path);
    if (new File(this.path, file_name).exists()) {
      Log.i("file", "exists");
      return true;
    }
    Log.i("file", "not exist");
    return false;
  }

  public Bitmap getImage(String file_name, String file_path) {
    this.path = new File(file_path);
    File file = new File(this.path, file_name);
    Options options = new Options();
    options.inPreferredConfig = Config.ARGB_8888;
    options.inSampleSize = 2;
    options.inTempStorage = new byte[16384];
    Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    return bitmap != null ? bitmap : null;
  }

  public void createImage(Bitmap bitmap, String file_name, String filepath, boolean file_replace) {
    this.path = new File(filepath);
    if (!this.path.exists()) {
      this.path.mkdirs();
    }
    File file = new File(this.path, file_name);
    if (!file.exists()) {
      store_image(file, bitmap);
    } else if (file_replace) {
      file.delete();
      store_image(new File(this.path, file_name), bitmap);
      Log.i("file", "replaced");
    }
  }

  public void store_image(File file, Bitmap bmp) {
    try {
      FileOutputStream out = new FileOutputStream(file);
      bmp.compress(CompressFormat.PNG, 80, out);
      out.flush();
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
