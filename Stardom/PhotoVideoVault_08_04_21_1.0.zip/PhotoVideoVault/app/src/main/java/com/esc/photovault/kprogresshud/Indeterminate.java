
package com.esc.photovault.kprogresshud;

public interface Indeterminate {
    void setAnimationSpeed(float scale);
}
