package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;


public class u6 implements OnTouchListener {
    public final  GestureDetector e;

    public u6(HighlightDetailsDetailActivity highlightDetailsDetailActivity, GestureDetector gestureDetector) {
        this.e = gestureDetector;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        boolean onTouchEvent = this.e.onTouchEvent(motionEvent);
        return true;
    }
}
