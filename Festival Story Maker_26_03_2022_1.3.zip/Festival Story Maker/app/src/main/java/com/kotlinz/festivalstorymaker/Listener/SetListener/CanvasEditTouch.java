package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class CanvasEditTouch extends GestureDetector.SimpleOnGestureListener
{
    public final  TextView textView;
    public final  com.kotlinz.festivalstorymaker.Models.g editModel;
    public final  FrameLayout frameLayout;
    public final CanvasEditorActivity activity;

    public CanvasEditTouch(final CanvasEditorActivity h, final TextView e, final com.kotlinz.festivalstorymaker.Models.g f, final FrameLayout g) {
        this.activity = h;
        this.textView = e;
        this.editModel = f;
        this.frameLayout = g;
    }

    public void onLongPress(final MotionEvent motionEvent) {
        activity.f1 = true;
        activity.g1 = (View)this.textView;
        activity.b0 = this.frameLayout;
        activity.B0(true);
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        this.activity.w0();
        TextInputDilaog.q0((Context)this.activity, textView.getText().toString(), true, this.editModel.x).m0 = (TextInputDilaog.d)new TextInputDilaog.d() {
            @Override
            public void a(final String text, final int n) {
                CanvasEditTouch.this.textView.setText((CharSequence)text);
            }

            @Override
            public void b(final String s) {
            }
        };
        return true;
    }
}
