package com.esc.phoneheart.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore.Files;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.phoneheart.R;
import com.esc.phoneheart.adapter.FilesDownloadAdapter;
import com.esc.phoneheart.interfaceclass.DialogListners;
import com.esc.phoneheart.model.DownloadsData;
import com.esc.phoneheart.pref.MySharedPreference;
import com.esc.phoneheart.utility.FileUtil;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.MountPoints;
import com.esc.phoneheart.utility.PermitionActivity;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.DownloadWrapper;

import java.io.File;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DownloadsScreen extends PermitionActivity implements DialogListners {
    public static final int REQUEST_CODE_STORAGE_ACCESS_INPUT = 4422;
    public static final int REQUEST_PERMISSIONS = 660;
    public PhoneCleaner appInstance;
    public Button btnClean;
    public ProgressDialog displayProgress;
    public ArrayList<DownloadWrapper> downloadDeletionList;
    public RelativeLayout hiddenPermissionLayout;
    public int notDeleted = 0;
    public RecyclerView recyclerView;

    public static class AnonymousClass7 {
        public static final int[] a;

        static {
            int[] iArr = new int[DELETION.values().length];
            a = iArr;
            iArr[DELETION.ERROR.ordinal()] = 1;
            a[DELETION.PERMISSION.ordinal()] = 2;
            try {
                a[DELETION.SUCCESS.ordinal()] = 3;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    public enum DELETION {
        SUCCESS,
        ERROR,
        PERMISSION,
        SELECTION,
        FINISH,
        NOTDELETION
    }

    private boolean deleteImageFile(DownloadWrapper downloadWrapper) {
        boolean exists;
        File file = new File(downloadWrapper.path);
        if (file.exists()) {
            delete(file);
            exists = file.exists();
            if (exists) {
                updateMediaScannerPath(file);
            } else {
                boolean isKitKat = FileUtil.isKitKat();
            }
        } else {
            updateMediaScannerPath(file);
            exists = true;
        }
        if (VERSION.SDK_INT == 21) {
            return true;
        }
        return exists;
    }

    private void deletion(final int i, final int i2, final Intent intent) {
        try {
            new AsyncTask<Void, Integer, DELETION>() {
                public void onPreExecute() {
                    DownloadsScreen.this.displayProgress = new ProgressDialog(DownloadsScreen.this);
                    DownloadsScreen.this.getWindow().addFlags(2097280);
                    ProgressDialog d = DownloadsScreen.this.displayProgress;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(DownloadsScreen.this.getResources().getString(R.string.cleaning));
                    d.setTitle(stringBuilder.toString());
                    DownloadsScreen.this.displayProgress.setCanceledOnTouchOutside(false);
                    DownloadsScreen.this.displayProgress.setProgressStyle(1);
                    DownloadsScreen.this.displayProgress.setCancelable(false);
                    DownloadsScreen.this.displayProgress.setMax(DownloadsScreen.this.downloadDeletionList.size());
                    DownloadsScreen.this.displayProgress.show();
                }

                public DELETION doInBackground(Void... voidArr) {
                    if (FileUtil.isSystemAndroid5()) {
                        DownloadsScreen.onActivityResultLollipop(DownloadsScreen.this, i, i2, intent);
                    }
                    return DownloadsScreen.this.permissionBasedDeletion();
                }

                public void onPostExecute(DELETION deletion) {
                    if (DownloadsScreen.this.displayProgress != null) {
                        DownloadsScreen.this.displayProgress.dismiss();
                    }
                    try {
                        DownloadsScreen.this.getWindow().clearFlags(2097280);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    int i = AnonymousClass7.a[deletion.ordinal()];
                    if (i == 1) {
                        Toast.makeText(DownloadsScreen.this, "", Toast.LENGTH_LONG).show();
                    } else if (i == 2) {
                        DownloadsScreen.this.permissionAlert();
                    } else if (i == 3) {
                        DownloadsScreen.this.successDeletion();
                    }
                }

                public void onProgressUpdate(Integer... numArr) {
                    super.onProgressUpdate(numArr);
                    DownloadsScreen.this.displayProgress.setProgress(numArr[0].intValue());
                }
            }.execute(new Void[0]);
        } catch (Exception unused) {
        }
    }

    public static Uri getSharedPreferenceUri(int i, Context context) {
        String string = getSharedPreferences(context).getString(context.getString(i), null);
        if (string == null) {
            return null;
        }
        return Uri.parse(string);
    }

    public static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    private void initIds() {
        this.hiddenPermissionLayout = (RelativeLayout) findViewById(R.id.hiddenpermissionlayout);
        this.recyclerView = (RecyclerView) findViewById(R.id.recycler_view_download);
        this.btnClean = (Button) findViewById(R.id.downloadclean_btn);
        findViewById(R.id.rl_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DownloadsScreen.this.doubleClicked()) {
                    DownloadsScreen.this.finish();
                }
            }
        });
    }


    private DELETION normalDeletion() {
        int i = 0;
        while (true) {
            if (i >= this.downloadDeletionList.size()) {
                return DELETION.SUCCESS;
            }
            if (deleteImageFile((DownloadWrapper) this.downloadDeletionList.get(i))) {
                this.appInstance.downloadsData.a += ((DownloadWrapper) this.downloadDeletionList.get(i)).size;
            }
            i++;
        }
    }

    public static void onActivityResultLollipop(Context context, int i, int i2, @NonNull Intent intent) {
        if (i == REQUEST_CODE_STORAGE_ACCESS_INPUT) {
            if (getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_input, context) == null) {
                getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_photos, context);
            }
            Uri uri = null;
            if (i2 == -1) {
                uri = intent.getData();
                setSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_input, uri, context);
            }
            if (i2 != -1) {
                System.out.println("File is not writable");
                return;
            }
            i = intent.getFlags() & 3;
            if (uri != null) {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    context.getContentResolver().takePersistableUriPermission(uri, i);
                }
            }
        }
    }

    private void permissionAlert() {
        SplashScreen.showdialog_sdcard(this, this);
    }

    private DELETION permissionBasedDeletion() {
        int i = 0;
        while (true) {
            if (i >= this.downloadDeletionList.size()) {
                return DELETION.SUCCESS;
            }
            if (deleteImageFile((DownloadWrapper) this.downloadDeletionList.get(i))) {
                this.appInstance.downloadsData.a += ((DownloadWrapper) this.downloadDeletionList.get(i)).size;
            }
            i++;
        }
    }

    private void setAdapter() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(getString(R.string.dialouge_no));
            stringBuilder.append(" ");
            stringBuilder.append(getString(R.string.file_manage_downloads));
            String stringBuilder2 = stringBuilder.toString();
            if (MySharedPreference.getLngIndex(this) == 0) {
                stringBuilder2 = "No Downloads Found";
            }
            if (PhoneCleaner.getInstance().downloadsData.downloadsList != null) {
                if (PhoneCleaner.getInstance().downloadsData.downloadsList.size() != 0) {
                    FilesDownloadAdapter filesDownloadAdapter = new FilesDownloadAdapter(this, this.btnClean);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
                    RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view_download);
                    this.recyclerView = recyclerView;
                    recyclerView.setLayoutManager(linearLayoutManager);
                    this.recyclerView.setItemAnimator(new DefaultItemAnimator());
                    this.recyclerView.setAdapter(filesDownloadAdapter);
                    try {
                        this.recyclerView.addItemDecoration(new DividerItemDecoration(this.recyclerView.getContext(), 1));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }
            }
            Intent intent = new Intent(this, FinalScreen.class);
            intent.putExtra("DATA", stringBuilder2);
            intent.putExtra("TYPE", "NODOWNLOAD");
            intent.putExtra("FROMLARGE", true);
            intent.putExtra("not_deleted", this.notDeleted);
            finish();
            startActivity(intent);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static void setSharedPreferenceUri(int i, @Nullable Uri uri, Context context) {
        Editor edit = getSharedPreferences(context).edit();
        if (uri == null) {
            edit.putString(context.getString(i), null);
        } else {
            edit.putString(context.getString(i), uri.toString());
        }
        edit.apply();
    }

    private void showAdsFullDialog() {
        try {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
            }
            dialog.setContentView(R.layout.new_dialog_junk_cancel);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
            ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.module_file_manager));
            ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.dup_photo_cleanconfirm_message));
            dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (!DownloadsScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner("DownloadsScreen", "method showAdsFullDialog calling cancel press", GlobalData.FILE_NAME);
                        dialog.dismiss();
                    }
                }
            });
            dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (!DownloadsScreen.this.doubleClicked()) {
                        Util.appendLogphonecleaner("DownloadsScreen", "method showAdsFullDialog calling continue press", GlobalData.FILE_NAME);
                        DownloadsScreen downloadsScreen = DownloadsScreen.this;
                        downloadsScreen.downloadDeletionList = downloadsScreen.appInstance.downloadsData.a();
                        new AsyncTask<String, Integer, DELETION>() {
                            private boolean isBothStorageCanDelete(ArrayList<String> arrayList) {
                                for (int i = 0; i < arrayList.size(); i++) {
                                    if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                        if (!FileUtil.isWritableNormalOrSaf(DownloadsScreen.this, new File((String) arrayList.get(i)))) {
                                            return false;
                                        }
                                    }
                                }
                                return true;
                            }

                            public void onPreExecute() {
                                DownloadsScreen.this.displayProgress = new ProgressDialog(DownloadsScreen.this);
                                DownloadsScreen.this.getWindow().addFlags(2097280);
                                DownloadsScreen.this.displayProgress.setTitle(R.string.cleaning);
                                DownloadsScreen.this.displayProgress.setCanceledOnTouchOutside(false);
                                DownloadsScreen.this.displayProgress.setProgressStyle(1);
                                DownloadsScreen.this.displayProgress.setCancelable(false);
                                DownloadsScreen.this.displayProgress.setMax(DownloadsScreen.this.downloadDeletionList.size());
                                DownloadsScreen.this.displayProgress.show();
                                super.onPreExecute();
                            }

                            public DELETION doInBackground(String... strArr) {
                                if (FileUtil.IsDeletionBelow6()) {
                                    return DownloadsScreen.this.normalDeletion();
                                }
                                ArrayList returnMountPOints = MountPoints.returnMountPOints(DownloadsScreen.this);
                                if (returnMountPOints == null) {
                                    return DownloadsScreen.this.normalDeletion();
                                }
                                if (returnMountPOints.size() == 1) {
                                    return DownloadsScreen.this.normalDeletion();
                                }
                                File file = new File((String) returnMountPOints.get(1));
                                if (file.listFiles() == null || file.listFiles().length == 0) {
                                    return DownloadsScreen.this.normalDeletion();
                                }
                                if (VERSION.SDK_INT <= 21) {
                                    return DELETION.SUCCESS;
                                }
                                if (isBothStorageCanDelete(returnMountPOints)) {
                                    return DownloadsScreen.this.permissionBasedDeletion();
                                }
                                return DELETION.PERMISSION;
                            }

                            public void onPostExecute(DELETION deletion) {
                                if (DownloadsScreen.this.displayProgress != null && DownloadsScreen.this.displayProgress.isShowing()) {
                                    DownloadsScreen.this.displayProgress.dismiss();
                                }
                                try {
                                    DownloadsScreen.this.getWindow().clearFlags(2097280);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                int i = AnonymousClass7.a[deletion.ordinal()];
                                if (i == 1) {
                                    Toast.makeText(DownloadsScreen.this, "Error", Toast.LENGTH_LONG).show();
                                } else if (i == 2) {
                                    DownloadsScreen.this.permissionAlert();
                                } else if (i == 3) {
                                    DownloadsScreen.this.successDeletion();
                                }
                                super.onPostExecute(deletion);
                            }

                            public void onProgressUpdate(Integer... numArr) {
                                super.onProgressUpdate(numArr);
                                DownloadsScreen.this.displayProgress.setProgress(numArr[0].intValue());
                            }
                        }.execute(new String[0]);
                        dialog.dismiss();
                    }
                }
            });
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void successDeletion() {
        Intent intent = new Intent(this, FinalScreen.class);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(Util.convertBytes(this.appInstance.downloadsData.a));
        intent.putExtra("DATA", stringBuilder.toString());
        intent.putExtra("TYPE", "Recovered");
        intent.putExtra("FROMLARGE", true);
        intent.putExtra("not_deleted", this.notDeleted);
        finish();
        startActivity(intent);
    }

    private void updateMediaScannerPath(File file) {
        if (VERSION.SDK_INT >= 19) {
            MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, null, new OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            return;
        }
        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
    }

    public void clickOK() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(64);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        intent.addFlags(1);
        startActivityForResult(intent, REQUEST_CODE_STORAGE_ACCESS_INPUT);
    }

    public boolean delete(File file) {
        file.delete();
        if (file.exists()) {
            String[] strArr = new String[]{file.getAbsolutePath()};
            ContentResolver contentResolver = getContentResolver();
            Uri contentUri = Files.getContentUri("external");
            String str = "_data=?";
            contentResolver.delete(contentUri, str, strArr);
            if (file.exists()) {
                contentResolver.delete(contentUri, str, strArr);
            }
        }
        return true;
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == REQUEST_CODE_STORAGE_ACCESS_INPUT && i2 == -1) {
            deletion(i, i2, intent);
        }
    }

    public void onBackPressed() {
        DownloadsData downloadsData = this.appInstance.downloadsData;
        downloadsData.totalSelectedsize = 0;
        downloadsData.totalSelected = 0;
        super.onBackPressed();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_downloads_screen);
        this.appInstance = PhoneCleaner.getInstance();
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle((CharSequence) "");
        }
        super.requestAppPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, R.string.pcl_sdcard_permission, REQUEST_PERMISSIONS);
        initIds();
        if (Util.checkStorageAccessPermissions(this)) {
            setAdapter();
        }
        this.btnClean.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DownloadsScreen.this.appInstance.downloadsData.totalSelected == 0) {
                    DownloadsScreen downloadsScreen = DownloadsScreen.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(DownloadsScreen.this.getString(R.string.pcl_pleaseselect));
                    Toast.makeText(downloadsScreen, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                    return;
                }
                DownloadsScreen.this.showAdsFullDialog();
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        finish();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPermissionsGranted(int i) {
        RelativeLayout relativeLayout = this.hiddenPermissionLayout;
        if (relativeLayout != null) {
            relativeLayout.setVisibility(View.GONE);
            setAdapter();
        }
    }
}
