package com.unitedvideos.NativeAds;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.unitedvideos.R;

public class NativeAdvanceAds {

    public static void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
//        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
//        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
//        if (nativeAd.getStore() == null) {
//            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
//            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
//        } else {
//            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
//            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
//            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
//        }
//        if (nativeAd.getStarRating() == null) {
//            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
//        } else {
//            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
//            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
//        }
        unifiedNativeAdView.setNativeAd(nativeAd);
    }
}
