package com.esc.uvideostatus.Fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnScrollListener;

import com.esc.uvideostatus.Activity.MainActivity;
import com.esc.uvideostatus.Activity.VideoPlayActivity;
import com.esc.uvideostatus.Adapters.CatogoryAdapter;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.Utility;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdsManager;
import com.facebook.ads.NativeBannerAd;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;

import cz.msebera.android.httpclient.Header;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CatogoryFragment extends Fragment {
    RecyclerView album_recyclerview;
    String cateoryid;
    String catogory;
    int counterlimit = 0;
    public boolean isLastPage = false;
    public CatogoryAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    public int totalCount = 1;
    public ArrayList<VideoData> videoData = new ArrayList<>();
    private MainActivity mainActivity;

    class dataCatogoryHandler extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataCatogoryHandler() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            String str2 = new String(bArr);
            try {
                JSONArray jSONArray = new JSONArray(str2);
                Log.e("JArry", "" + jSONArray);
                StringBuilder sb = new StringBuilder();
                sb.append("getcatogoryvideo:catfirst ");
                sb.append(str2);
                Log.d("ContentValues", sb.toString());
                videoData = new ArrayList<>();
                try {
                    if (jSONArray.length() != 0) {
                        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                            Log.e("JArrylength", "" + jSONArray.length());
                            JSONObject jSONObject = jSONArray.getJSONObject(i2);
                            VideoData videoDataobj = new VideoData();
                            videoDataobj.setVideo_id(jSONObject.getLong(TtmlNode.ATTR_ID));
                            videoDataobj.setTitle(jSONObject.getString("title"));
                            videoDataobj.setUrl(jSONObject.getString(str));
                            videoDataobj.setReal_videopath(jSONObject.getString(str));
                            videoDataobj.setThumbnail(jSONObject.getString(TtmlNode.TAG_IMAGE));
                            videoDataobj.setCatagory(jSONObject.getString("cname"));
                            videoDataobj.setViews(jSONObject.getString("downloads"));
                            if ((videoData.size() + 1) % 3 == 0) {
                                videoDataobj.IsNativeAds = true;
                                videoData.add(videoDataobj);
                            } else {
                                videoData.add(videoDataobj);
                            }
                        }
                        SetAdapter();
                        totalCount = totalCount + 1;
                        if (videoData.size() < 20) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }
                    } else {
                        isLastPage = true;
                    }
                    mAdapter.setLoaded();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (Exception unused) {
            }
        }
    }

    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.trending_fragment, viewGroup, false);
        if (getArguments() != null) {
            this.cateoryid = getArguments().getString(TtmlNode.ATTR_ID);
            this.catogory = getArguments().getString("catogory");
        }
        Log.e("Categoryid", "" + cateoryid);
        initViews(inflate);
        initNativeAds();
        return inflate;
    }

    private void initViews(View view) {
        this.album_recyclerview = (RecyclerView) view.findViewById(R.id.album_recyclerview);
        this.album_recyclerview.addOnScrollListener(new OnScrollListener() {
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }

            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (i2 > 0) {
                    if (CatogoryFragment.this.mLayoutManager.getChildCount() + CatogoryFragment.this.mLayoutManager.findFirstVisibleItemPosition() >= CatogoryFragment.this.mLayoutManager.getItemCount() && !CatogoryFragment.this.isLastPage) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(CatogoryFragment.this.counterlimit);
                        Log.e("=>>>>>", sb.toString());
                        CatogoryFragment catogoryFragment = CatogoryFragment.this;
                        catogoryFragment.getcatogoryvideo(catogoryFragment.counterlimit);
                    }
                }
            }
        });
        getcatogoryvideo(this.counterlimit);
    }

    public void SetAdapter() {
        mLayoutManager = new LinearLayoutManager(getActivity());
        album_recyclerview.setLayoutManager(this.mLayoutManager);
        album_recyclerview.setItemAnimator(new DefaultItemAnimator());
        album_recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), 0));
        mAdapter = new CatogoryAdapter(getActivity(), this.videoData, this, this.album_recyclerview);
        album_recyclerview.setAdapter(this.mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    public NativeBannerAd mNativeBannerAd;

    public void initNativeAds() {

        mNativeBannerAd = new NativeBannerAd(getActivity(), getString(R.string.fb_nativebanner_Home));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();

    }

    public void getcatogoryvideo(int i) {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        try {
            jSONObject.put("cid", this.cateoryid);
            jSONObject2.put("_id", -1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestParams requestParams = new RequestParams();
        requestParams.put("q", jSONObject.toString());
        Log.e("CatIdQ", "" + jSONObject.toString());
        requestParams.put("sk", i);
        Log.e("CatSK", "" + i);
        requestParams.put("l", 20);
        requestParams.put("s", jSONObject2.toString());
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append(Utility.baseUrl);
        sb.append("collections/tbl_video?apiKey=");
        sb.append(Utility.apiKey);
        asyncHttpClient.get(sb.toString(), requestParams, (ResponseHandlerInterface) new dataCatogoryHandler());
        this.counterlimit += 3;
    }

    public void playVideo(VideoData videoData2) {
        mainActivity = (MainActivity) getActivity();
        Intent intent = new Intent(getActivity(), VideoPlayActivity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("cid", this.cateoryid);
        intent.putExtra("list", videoData2);
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        mainActivity.intent = intent;
        mainActivity.id = 101;
        if (mainActivity.fbinterstitialAd != null && mainActivity.fbinterstitialAd.isAdLoaded()) {
            mainActivity.fbinterstitialAd.show();
        } else {
            startActivity(intent);
            mainActivity.finish();
        }

    }
}
