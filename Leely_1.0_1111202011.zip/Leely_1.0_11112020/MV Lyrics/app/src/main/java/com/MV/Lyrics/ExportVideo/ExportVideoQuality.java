package com.MV.Lyrics.ExportVideo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import androidx.appcompat.app.AppCompatActivity;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.R;
import com.google.firebase.analytics.FirebaseAnalytics;

public class ExportVideoQuality extends AppCompatActivity {

    Activity activity = ExportVideoQuality.this;
    ImageView ivback;
    RadioButton rbHd;
    RadioButton rbStandard;
    String VideoQuality;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export_video_quality);
        VideoQuality = LanguagePref.a(this).a("pref_key_export_quality", "High");
        PutAnalyticsEvent();
        BindView();
        SetListener();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExportVideoQuality");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        rbHd = findViewById(R.id.rbHigh);
        rbStandard = findViewById(R.id.rbMedium);
        if (VideoQuality.equalsIgnoreCase("High")) {
            rbHd.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Medium")) {
            rbStandard.setChecked(true);
        }
    }

    private void SetListener() {
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        rbHd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "High");
                    onBackPressed();
                }
            }
        });
        rbStandard.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Medium");
                    onBackPressed();
                }
            }
        });

    }

    public void onBackPressed() {
        finish();
    }
}
