package com.kotlinz.festivalstorymaker.Listener.SetListener;


import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class y5 implements ImageStickerViewNew.c {
    public final FrameEditorNewDesign.y a;

    public y5(final FrameEditorNewDesign.y a) {
        this.a = a;
    }

    @Override
    public void a(final ImageStickerViewNew imageStickerViewNew) {
        imageStickerViewNew.setInEdit(false);
        imageStickerViewNew.setInEdit(true);
    }

    @Override
    public void b(final ImageStickerViewNew imageStickerViewNew) {
      /*  FrameEditorNewDesign.j0(this.a.c);
        final FrameEditorNewDesign c = this.a.c;
        c.v0.get(c.d0).removeView((View)imageStickerViewNew);*/
    }

    @Override
    public void c(final Boolean b) {
        /*this.a.c.scroll.requestDisallowInterceptTouchEvent((boolean)b);*/
    }

    @Override
    public void d(final ImageStickerViewNew imageStickerViewNew) {
    }
}
