package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Download.CollageThemeDownload;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.CollageMakerActivity;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CollageMakeFrameListAdapter extends RecyclerView.Adapter<CollageMakeFrameListAdapter.Viewholder> {
    public CollageMakerActivity collageMakerActivity;
    public ArrayList<CollageCategoryWiseData> categoryWiseCollageList;
    String DataFileName;
    String[] SplitName;

    public CollageMakeFrameListAdapter(Context activity, ArrayList<CollageCategoryWiseData> arrayList) {
        this.collageMakerActivity = (CollageMakerActivity) activity;
        this.categoryWiseCollageList = arrayList;
    }


    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_collage_maker_list_item, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, @SuppressLint("RecyclerView") int position) {
        CollageCategoryWiseData collageCategoryWiseData = categoryWiseCollageList.get(position);
        if (categoryWiseCollageList.get(position).getThemeThumbnail().length() > 0) {
            Glide.with(collageMakerActivity).load(categoryWiseCollageList.get(position).getThemeThumbnail()).placeholder(R.drawable.ic_placehoder).into(holder.img);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                collageMakerActivity.Position = position;
                DownloadFile(position, collageCategoryWiseData);
            }
        });
    }

    private void DownloadFile(int Position, CollageCategoryWiseData categoryWiseData) {
        DataFileName = categoryWiseData.getDatafile().substring(categoryWiseData.getDatafile().lastIndexOf('/') + 1);
        if (DataFileName.indexOf(".") > 0)
            DataFileName = DataFileName.substring(0, DataFileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        SplitName = DataFileName.split("Theme");
        String SplitFileName = "Theme" + " " + SplitName[1];
        String TextFileName = "Theme" + "_" + SplitName[1];

        Constant.TextFilePath = Utils.INSTANCE.getThemeFolderPath(collageMakerActivity) + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName + File.separator + TextFileName + ".txt";
        Constant.FolderPath = Utils.INSTANCE.getThemeFolderPath(collageMakerActivity) + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName;

        if (new File(Utils.INSTANCE.getThemeFolderPath(collageMakerActivity) + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + DataFileName).exists()) {
            Constant.NoofImage = Integer.parseInt(categoryWiseCollageList.get(Position).getIsImageCount());
            Constant.ImageFrame = categoryWiseCollageList.get(Position).getThemeThumbnail();
            collageMakerActivity.OpenGallery();
            MyApplication.getInstance().CatItemPosition = Position;
        } else {
            if (Utils.checkConnectivity(collageMakerActivity, false)) {
                new CollageThemeDownload(collageMakerActivity, categoryWiseCollageList.get(Position).getDatafile(), DataFileName, categoryWiseData);
            }
        }
    }

    @Override
    public int getItemCount() {
        return categoryWiseCollageList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgBg)
        public ImageView img;
        @BindView(R.id.imgLock)
        public ImageView imgLock;


        public Viewholder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
