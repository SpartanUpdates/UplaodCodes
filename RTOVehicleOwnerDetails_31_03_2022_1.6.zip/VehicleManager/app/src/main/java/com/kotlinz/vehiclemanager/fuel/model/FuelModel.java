package com.kotlinz.vehiclemanager.fuel.model;

public class FuelModel {
    String code,status;
    public Response response;

    public String getCode() {
        return code;
    }

    public String getStatus() {
        return status;
    }

    public Response getResponse() {
        return response;
    }

    public class Response{
        public String name;
        public double petrolPrice;
        public String petrolChange;
        public double dieselPrice;
        public String dieselChange;
        public String priceDate;
        public String citystate;
        public String type;
        public String code;

        public String getName() {
            return name;
        }

        public double getPetrolPrice() {
            return petrolPrice;
        }

        public String getPetrolChange() {
            return petrolChange;
        }

        public double getDieselPrice() {
            return dieselPrice;
        }

        public String getDieselChange() {
            return dieselChange;
        }

        public String getPriceDate() {
            return priceDate;
        }

        public String getCitystate() {
            return citystate;
        }

        public String getType() {
            return type;
        }

        public String getCode() {
            return code;
        }
    }
}
