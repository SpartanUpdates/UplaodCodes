package com.wavymusic.MoreApp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.R;

public class MoreAppActivity extends AppCompatActivity {

    Activity activity = MoreAppActivity.this;
    ImageView ivback;

    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_app);
        PutAnalyticsEvent();
        BindView();
        BannerAds();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MoreAppActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        findViewById(R.id.adWavyBanner).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ShareApp(activity, "com.uv.photoslideshow.photovideomaker.fogg.wavymusic");
            }
        });
        findViewById(R.id.adPhotoBanner).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ShareApp(activity, "com.uvvideos.photo.video.slideshow.maker");
            }
        });
    }

    private void BannerAds(){
        adView = new AdView(this, getResources().getString(R.string.fb_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }


    public static void ShareApp(Context context, String str) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=".concat(String.valueOf(str))));
        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(context, context.getString(R.string.google_play_msg), Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(activity, DashbordActivity.class);
        startActivity(intent);
        finish();
    }


}