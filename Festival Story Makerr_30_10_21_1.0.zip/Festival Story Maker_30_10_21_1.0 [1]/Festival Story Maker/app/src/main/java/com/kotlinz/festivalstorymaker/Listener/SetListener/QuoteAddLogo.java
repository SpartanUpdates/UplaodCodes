package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.FrameLayout;

import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.activity.SelectLogoActivity;
import java.io.ByteArrayOutputStream;

public class QuoteAddLogo implements View.OnClickListener {
    public final  FrameLayout e;
    public final  QuoteMakerDetailActivity activity;

    public QuoteAddLogo(QuoteMakerDetailActivity quoteMakerDetailActivity, FrameLayout frameLayout) {
        this.activity = quoteMakerDetailActivity;
        this.e = frameLayout;
    }

    public void onClick(View view) {
        activity.flStickerView = this.e;
        if (activity != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            Utils.z(activity).compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            Intent putExtra = new Intent(activity.getApplicationContext(), SelectLogoActivity.class).putExtra("image", byteArrayOutputStream.toByteArray());
            int i = AppConstant.H;
            activity.startActivityForResult(putExtra, 7924);
            return;
        }
        throw null;
    }
}
