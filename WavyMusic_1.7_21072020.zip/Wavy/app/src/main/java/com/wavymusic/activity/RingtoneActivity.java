package com.wavymusic.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;

import androidx.annotation.RequiresApi;

import com.google.android.gms.ads.AdSize;
import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Fragment.RingtoneByCatFragment;
import com.wavymusic.Model.SongCatModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.Utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.wavymusic.application.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RingtoneActivity extends AppCompatActivity {

    public static LanguagePref sharedpreferences;
    public int id;
    public String FinalSongPath;
    //    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    Activity activity = RingtoneActivity.this;
    PagerAdapter adp;
    ArrayList<SongCatModel> SongList = new ArrayList<>();
    //    Long timestamps;
    String offlienResopnseData;
    SharedPreferences pref;
    String MY_PREF = "Song_pref";
    RelativeLayout rlLoadingTheme;
    Button btnRetry;
    ImageView ivBack;
    LinearLayout llRetry;
    APIInterface apiInterface;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ringtone);
        pref = getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        sharedpreferences = LanguagePref.a(this);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ivBack = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song_online);
        viewPager = findViewById(R.id.vp_song_online);
        rlLoadingTheme = findViewById(R.id.rl_load_song_online);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RingtoneActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        BannerAds();
//        InterstitialAd();
        adListener();
        getOfflineCategory(activity, "offlineResponse");
        if (offlienResopnseData != null) {
            new LoadOfflineData().execute();
        } else {
            rlLoadingTheme.setVisibility(View.GONE);
            llRetry.setVisibility(View.VISIBLE);
        }
    }


    private void BannerAds() {
//        adView = findViewById(R.id.adView);
//        AdRequest adRequest= new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//    private void InterstitialAd() {
//        mInterstitialAd = new InterstitialAd(activity);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                GoBack();
//            }
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//
//            }
//
//            @Override
//            public void onAdFailedToLoad(int i) {
//                super.onAdFailedToLoad(i);
//
//            }
//        });
//    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        if (MyApplication.fbinterstitialAd != null) {
            MyApplication.fbinterstitialAd.destroy();
        }
        super.onDestroy();
    }

    private void adListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetSongCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }


    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
                StopSong();
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });


    }

    private void StopSong() {
        try {
            if (RingtoneByCatFragment.mediaPlayer != null) {
                RingtoneByCatFragment.mediaPlayer.stop();
                RingtoneByCatFragment.mediaPlayer.release();
                RingtoneByCatFragment.mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerNew() {
        adp = new PagerAdapter(getSupportFragmentManager());
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }


    private void getOfflineCategory(Context ctx, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
    }

    private void GetSongCategory() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId, AppConstant.DefaultCategoryId + LanguagePref.a(this).a("pref_key_language_list", "22"));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject songJSONObject = jsonArray.getJSONObject(i);
                            SongCatModel songCatModel = new SongCatModel();
                            songCatModel.setSongCatId(songJSONObject.getString("id"));
                            songCatModel.setSongCatName(songJSONObject.getString("name"));
                            SongList.add(songCatModel);
                        }
                        setUpPagerNew();
                        SetTabLayout();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void GoBack() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }

    public void onBackPressed() {
        if (MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
            MyApplication.AdsId = 4;
            MyApplication.AdsShowContext = activity;
            MyApplication.fbinterstitialAd.show();
           /* try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    }
                }
            }, 2000);*/
        } else {
            GoBack();
        }
    }


    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject songJSONObject = jsonArray.getJSONObject(i);
                    SongCatModel songCatModel = new SongCatModel();
                    songCatModel.setSongCatId(songJSONObject.getString("id"));
                    songCatModel.setSongCatName(songJSONObject.getString("name"));
                    SongList.add(songCatModel);
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            setUpPagerNew();
            SetTabLayout();
            rlLoadingTheme.setVisibility(View.GONE);
        }
    }

    public class PagerAdapter extends FragmentPagerAdapter {

        public PagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return (RingtoneByCatFragment.getInstance(Integer.parseInt(SongList.get(position).getSongCatId())));
        }

        @Override
        public int getCount() {
            return SongList.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.row_song_cat, null);
            TextView tv = tab.findViewById(R.id.custom_text);
            tv.setText(SongList.get(position).getSongCatName());
            return tab;
        }
    }
}
