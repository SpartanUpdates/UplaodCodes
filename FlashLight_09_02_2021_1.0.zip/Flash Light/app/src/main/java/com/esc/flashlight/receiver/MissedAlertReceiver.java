package com.esc.flashlight.receiver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.SystemClock;
import android.provider.CallLog.Calls;
import androidx.core.app.NotificationCompat;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.config.Config;
import com.esc.flashlight.flashlight.FlashService;
import com.esc.flashlight.util.FALib;
import com.esc.flashlight.util.FlashAlertUtil;
import com.esc.flashlight.util.PrefManager;


public class MissedAlertReceiver extends BroadcastReceiver {
    public static final String ACTION_CALL = "flash.light.shine.missed.CALL";
    public static final String ACTION_CALL_PREPARE = "flash.light.shine.missed.CALL_PREPARE";

    public void onReceive(Context context, Intent intent) {
        if (ACTION_CALL_PREPARE.equals(intent.getAction())) {
            setAlarm(context, true);
            return;
        }
        if (ACTION_CALL.equals(intent.getAction())) {
            Cursor query = context.getContentResolver().query(Calls.CONTENT_URI, null, "type = ? AND new = ?", new String[]{Integer.toString(3), "1"}, "date DESC ");
            if (query.getCount() <= 0) {
                setAlarm(context, false);
            } else if (isUseMissedCall()) {
                if (FlashAlertUtil.isEnableAlert(context, APP.getPrefManager())) {
                    FALib.sendBroadcastFlashActionIntent(context.getApplicationContext(), FlashService.ACTION_MISSED_CALL);
                }
                setAlarm(context, true);
            } else {
                return;
            }
            query.close();
        }
    }

    private boolean isUseMissedCall() {
        PrefManager prefManager = APP.getPrefManager();
        return prefManager.getUseTotally() && prefManager.getUseCall() && prefManager.getUseMissedCall();
    }

    private void setAlarm(Context context, boolean z) {
        PrefManager prefManager = APP.getPrefManager();
        Intent intent = new Intent(context, MissedAlertReceiver.class);
        intent.setAction(ACTION_CALL);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
        if (z) {
            alarmManager.set(3, SystemClock.elapsedRealtime() + (((long) prefManager.getIntervalMissedCall()) * Config.MISSED_MSEC_MIN), PendingIntent.getBroadcast(context, 99, intent, 134217728));
        } else {
            alarmManager.cancel(PendingIntent.getBroadcast(context, 99, intent, 134217728));
        }
    }
}
