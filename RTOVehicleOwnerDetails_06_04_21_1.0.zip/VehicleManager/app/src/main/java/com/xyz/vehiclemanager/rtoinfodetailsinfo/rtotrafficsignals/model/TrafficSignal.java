package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtotrafficsignals.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class TrafficSignal
{
    @SerializedName("data")
    public ArrayList<TrafficSignal> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("name")
    public String name;
    @SerializedName("description")
    public String description;
    @SerializedName("imageUrl")
    public String imageUrl;

    public TrafficSignal() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public ArrayList<TrafficSignal> getData() {
        return data;
    }

    public void setData(ArrayList<TrafficSignal> data) {
        this.data = data;
    }
}
