package com.kotlinz.puzzlecreator.model;

public class Credentials {
    public String mobile_number;
    public String password;

    public String name, user_type, referal_code,puzzle_id,status,reason,points;

    public Credentials() {

    }

}
