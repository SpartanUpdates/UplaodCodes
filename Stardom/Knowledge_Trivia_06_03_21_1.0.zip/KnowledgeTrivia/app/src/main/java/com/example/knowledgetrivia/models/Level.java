package com.example.knowledgetrivia.models;

import java.util.ArrayList;

public class Level {
    private int level;
    private ArrayList<Question> questionlist;

    public Level(int i) {
        this.level = i;
        this.questionlist = new ArrayList();
    }

    public Level(int i, ArrayList<Question> arrayList) {
        this.level = i;
        this.questionlist = arrayList;
    }

    public int getLevel() {
        return this.level;
    }

    public void setLevel(int i) {
        this.level = i;
    }

    public ArrayList<Question> getQuestionlist() {
        return this.questionlist;
    }

    public void addQuestion(Question question) {
        this.questionlist.add(question);
    }
}
