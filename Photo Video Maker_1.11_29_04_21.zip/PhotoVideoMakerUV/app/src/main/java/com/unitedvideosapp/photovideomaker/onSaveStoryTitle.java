package com.unitedvideosapp.photovideomaker;

public interface onSaveStoryTitle {
    int getFrameVisibility();

    void onAddCameraImage();

    void onAddImageSticker();

    void onAddTextSticker();

    void onSaveImageNew();

    void setFrame();

    void setFrameVisibility(int i);
}
