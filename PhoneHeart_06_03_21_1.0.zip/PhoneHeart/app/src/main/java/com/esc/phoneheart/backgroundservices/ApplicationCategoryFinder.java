package com.esc.phoneheart.backgroundservices;

import android.app.IntentService;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.Nullable;

public class ApplicationCategoryFinder extends IntentService {
    public ApplicationCategoryFinder(String str) {
        super(str);
    }

    private boolean checkIsaGame(String str) {
        String[] strArr = new String[]{"Action", "Adventure", "Arcade", "Board", "Casual", "Educational", "GAME_MUSIC", "Music", "Puzzle", "Racing", "Role Playing", "Simulation", "Sports", "GAME_PUZZLE", "GAME_WORD", "GAME_CASUAL"};
        if (str.toLowerCase().contains("game")) {
            return true;
        }
        for (int i = 0; i < 16; i++) {
            if (str.equalsIgnoreCase(strArr[i])) {
                return true;
            }
        }
        return false;
    }

    public void onHandleIntent(@Nullable Intent intent) {
        String stringExtra;
        String str = "";
        String str2 = "PKG";
        String str3 = null;
        if (intent != null) {
            try {
                stringExtra = intent.getStringExtra(str2);
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
        stringExtra = null;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(stringExtra);
        URLConnection openConnection = null;
        try {
            openConnection = new URL(stringBuilder.toString()).openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(openConnection.getInputStream(), (String) Arrays.asList(((String) Arrays.asList(openConnection.getContentType().split(";")).get(1)).split("=")).get(1)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            String readLine = null;
            try {
                readLine = bufferedReader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (readLine == null) {
                break;
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(readLine);
            stringBuilder2.append("\n");
            stringBuffer.append(stringBuilder2.toString());
        }
        try {
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Matcher matcher = Pattern.compile("<a class=\"document-subtitle category\" href=\"/store/apps/category/([^\"]+)\"", 2).matcher(stringBuffer.toString());
        if (matcher.find()) {
            str3 = matcher.group(1);
        }
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(str3);
        if (checkIsaGame(stringBuilder3.toString())) {
            Intent intent2 = new Intent("game.app.installed");
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(str);
            stringBuilder3.append(stringExtra);
            intent2.putExtra(str2, stringBuilder3.toString());
            getBaseContext().sendBroadcast(intent2);
        }
    }

    public ApplicationCategoryFinder() {
        super("ApplicationCategoryFinder");
    }
}
