package com.unitedvideos.application;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAdListener;
import com.google.gson.JsonObject;
import com.root.unity.AndroidUnityCall;
import com.unitedvideos.Model.ImageModel;
import com.unitedvideos.R;
import com.unitedvideos.UnityPlayerActivity;
import com.unitedvideos.activity.ArrangePhotosActivity;
import com.unitedvideos.activity.DynamicTextFieldActivity;
import com.unitedvideos.activity.ExitActivity;
import com.unitedvideos.activity.HomeActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.unitedvideos.activity.MyVideoActivity;
import com.unitedvideos.activity.VideoPlayerActivity;
import com.unity3d.player.UnityPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;

public class MyApplication extends android.app.Application {

    public static Context mContext;
    public static String AppName = "United Videos";
    public static int TotalSelectedImage;
    private static MyApplication instance;
    public int min_pos;
    public static boolean IsSelectImageFrom;
    public static boolean IsHomeAdsDisplay = false;
    public static String SPLIT_PATTERN;
    public final ArrayList<ImageModel> selectedImages;
    //    public final ArrayList<CropImage> cropimaglist;
    public final ArrayList<String> cropimaglist;
    public HashMap<String, ArrayList<ImageModel>> allAlbum;
    private ArrayList<String> allFolder;
    private String selectedFolderId;
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;
    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;
    public static String VidoePath;


    public static boolean SkipAll;
    public static boolean isBreak;
    public boolean isEditModeEnable;
    public boolean IsBack = false;

    public static boolean isEditCall = false;
    public static Call<JsonObject> Tempcall;

    public int posForAddMusicDialog;

    public static com.facebook.ads.InterstitialAd fbinterstitialAd;
    public static int AdsId;
    public static Activity AdsShowContext;

    //    public boolean Preview;
//    private boolean IsUpdateImage;
//    private boolean IsArrangeImage;
    private String AllFilePath;
    private String AllFileData;
    String result_conc = "";

    static {
        MyApplication.TotalSelectedImage = 5;
        MyApplication.SPLIT_PATTERN = "?";
        MyApplication.isBreak = false;
        MyApplication.SkipAll = false;
    }

    public MyApplication() {
        this.selectedImages = new ArrayList<ImageModel>();
//        this.cropimaglist = new ArrayList<CropImage>();
        this.cropimaglist = new ArrayList<String>();
        this.min_pos = Integer.MAX_VALUE;
        this.posForAddMusicDialog = 0;
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    String[] string;

    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(MyApplication.mContext, MyApplication.mContext.getResources().getString(R.string.admob_app_id));
        AudienceNetworkAds.initialize(this);
//        AdSettings.addTestDevice("1731a666-5535-4545-a148-7aa1ac5abe16");
//        AdSettings.addTestDevice("33de70e2-5a8d-46ef-9630-bd0056eddae6");
        LoadfbInterstitialAds();
        string = new String[]{"UVideos",
                "UV Videos",
                "U Videos",
                "U Video",
                "Vigo Video",
                "Tiktok",
                "Xender",
                "UVideo",
                "Viva Video"};
    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new com.facebook.ads.InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed..." + AdsId);
                switch (AdsId) {
                    case 1:
                        //HomeActivity On Backpress
                        GoToExit();
                        break;
                    case 2:
                        // Theme Category  Adapter
                        GoToPreview();
                        break;
                    case 3:
                        //TextActivity
                        GetJsonResponse();
                        break;
                    case 4:
                        //ArrangePhotosActivity
                        done();
                        break;
                    case 5:
                        //VideoPlayerActivity OnBackPress
                        CloseVideoPlayer();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG", "AdError..." + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("TAG", "AdsLoaded...");
                // Interstitial ad is loaded and ready to be displayed
                // Show the ad
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Ad clicked callback
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        if (fbinterstitialAd != null) {
            fbinterstitialAd.loadAd();
        } else {
            fbinterstitialAd = new com.facebook.ads.InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
            fbinterstitialAd.loadAd();
        }
    }

    private void GoToExit() {
        Intent intent = new Intent(AdsShowContext, ExitActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        AdsShowContext.finish();
    }

    public void GoToPreview() {
        HideShowUnityBannerAds();
        AndroidUnityCall.ImageSelectionForFbAdsClose(AdsShowContext, AndroidUnityCall.ImageWidth, AndroidUnityCall.ImageHeight, AndroidUnityCall.NoofImage, AndroidUnityCall.VideoType, false, "android");
        AdsShowContext.finish();
    }

    private void HideShowUnityBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void GetJsonResponse() {
        String a = DynamicTextFieldActivity.a(DynamicTextFieldActivity.a);
        UnityPlayer.UnitySendMessage("UserData", "EditedTextResponce", a);
        AdsShowContext.finish();
    }

    private void done() {
        isEditModeEnable = false;
        if (ArrangePhotosActivity.Preview) {
            AdsShowContext.setResult(-1);
            AdsShowContext.finish();
        } else {
            loadPreview();
        }
    }

    private void loadPreview() {
        AllFilePath = AndroidUnityCall.BundelPath + MyApplication.SPLIT_PATTERN + AndroidUnityCall.PrefebName + MyApplication.SPLIT_PATTERN + AndroidUnityCall.AudioPath;
        AllFileData = AndroidUnityCall.VideoType + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageWidth + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageHeight + MyApplication.SPLIT_PATTERN + AndroidUnityCall.NoofImage;

        for (int i = 0; i < this.getCropImages().size(); ++i) {
            if (i == 0) {
                result_conc = this.getCropImages().get(i);
            } else {
                result_conc = result_conc + MyApplication.SPLIT_PATTERN + this.getCropImages().get(i);
            }
        }
        if (ArrangePhotosActivity.IsArrangeImage) {
            UnityPlayer.UnitySendMessage("UserData", "ArrangeImages", result_conc);
            Log.e("TAG", "loadPreview Arranges Images: " + result_conc);
            AdsShowContext.finish();
        } else if (ArrangePhotosActivity.IsUpdateImage) {
            UnityPlayer.UnitySendMessage("UserData", "SpritePathString", result_conc);
            AdsShowContext.finish();
        } else {
            SendDataToUnity();
        }
    }

    public void SendDataToUnity() {
//        Log.e("TAG", "IsAudioResponce" + AllFilePath);
//        Log.e("TAG", "GetDataOfAnimation" + AllFileData);
//        Log.e("TAG", "SpritePathString" + result_conc);
        UnityPlayer.UnitySendMessage("UserData", "IsAudioResponce", AllFilePath);
        UnityPlayer.UnitySendMessage("UserData", "GetDataOfAnimation", AllFileData);
        UnityPlayer.UnitySendMessage("ContentCreater", "SpritePathString", result_conc);
        Log.e("TAG", "GoTounityFinishCalled...");
        AdsShowContext.finish();
    }

    private void CloseVideoPlayer() {
        if (VideoPlayerActivity.IsFromAndroidlist) {
            AdsShowContext.finish();
        } else {
            AndroidUnityCall.ScanVideoList(AdsShowContext, MyApplication.VidoePath);
            UnityPlayer.UnitySendMessage("StackManager", "ResetEveryThing", "");
            Intent intent = new Intent(this, MyVideoActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            AdsShowContext.finish();
        }
    }

    public void init() {
        this.getFolderList();
    }

    public static String getFileName(String str) {
        return str.substring(str.lastIndexOf("/") + 1);
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageModel>> getAllAlbum() {
        return this.allAlbum;
    }

    public ArrayList<ImageModel> getImageByAlbum(final String folderId) {
        ArrayList<ImageModel> imageDatas = this.getAllAlbum().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageModel>();
        }
        return imageDatas;
    }

    public ArrayList<ImageModel> getSelectedImages() {
        return this.selectedImages;
    }

    public void addSelectedImage(final ImageModel imageData) {
        this.selectedImages.add(imageData);
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= this.selectedImages.size()) {
            final ImageModel imageData2 = this.selectedImages.remove(imageData);
            --imageData2.imageCount;
        }
    }

    public void ReplaceSelectedImage(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

//    public ArrayList<CropImage> getCropImages() {
//        return this.cropimaglist;
//    }
//
//    public void AddCropImages(CropImage imageData) {
//        this.cropimaglist.add(imageData);
//
//    }

    public ArrayList<String> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(String imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageModel imageData, int pos) {
        this.selectedImages.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }


    public void getFolderList() {
        this.allFolder = new ArrayList<String>();
        this.allAlbum = new HashMap<String, ArrayList<ImageModel>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        final Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, (String) null, (String[]) null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumn = cur.getColumnIndex("bucket_id");
            ImageModel data = null;
            this.setSelectedFolderId(cur.getString(bucketIdColumn));
            do {
                data = new ImageModel();
                data.imagePath = cur.getString(cur.getColumnIndex("_data"));
                data.imageThumbnail = cur.getString(cur.getColumnIndex("_data"));
                if (!data.imagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumn);
                    final String folderId = cur.getString(bucketIdColumn);
                    if (!this.allFolder.contains(folderId)) {
                        this.allFolder.add(folderId);
                    }
                    ArrayList<ImageModel> imagePath = this.allAlbum.get(folderName);
                    if (imagePath == null) {
                        imagePath = new ArrayList<ImageModel>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    this.allAlbum.put(folderName, imagePath);
                }
            } while (cur.moveToNext());
        }
    }
}
