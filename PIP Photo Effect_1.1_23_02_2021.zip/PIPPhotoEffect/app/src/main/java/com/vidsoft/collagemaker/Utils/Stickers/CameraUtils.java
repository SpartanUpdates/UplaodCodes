package com.vidsoft.collagemaker.Utils.Stickers;

import android.graphics.Bitmap;
import android.graphics.Matrix;

public class CameraUtils {
	public static int MEDIA_TYPE_IMAGE;
	public static int intAdz;
	static {
		CameraUtils.MEDIA_TYPE_IMAGE = 1;
		CameraUtils.intAdz = 0;
	}
	public static Bitmap getResizedBitmap(final Bitmap bitmap, final int n,
			final int n2) {
		return Bitmap.createScaledBitmap(bitmap, n, n2, true);
	}

	public static Bitmap rotate(final Bitmap bitmap, final float n) {
		final Matrix matrix = new Matrix();
		matrix.postRotate(n);
		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
				bitmap.getHeight(), matrix, true);
	}

}
