package com.rtovehicleinformation.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database(entities = {OwnerHistoryPaidModel.class},version = 1 ,exportSchema = false)
public abstract class HistoryDatabase extends RoomDatabase {
    public abstract OwnerHistoryDao ownerHistoryDao();
    public static HistoryDatabase historyDatabase;
    public static HistoryDatabase getDatabase(final Context context) {
        if (historyDatabase == null) {
            synchronized (HistoryDatabase.class) {
                if (historyDatabase == null) {
                    historyDatabase = Room.databaseBuilder(context,
                            HistoryDatabase.class, "VehicleDetailsHistory")
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return historyDatabase;
    }
}
