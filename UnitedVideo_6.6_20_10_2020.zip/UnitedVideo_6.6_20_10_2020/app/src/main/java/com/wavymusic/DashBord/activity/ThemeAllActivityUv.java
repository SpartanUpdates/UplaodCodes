package com.wavymusic.DashBord.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.Fragment.ThemeViewAllFragmentUv;
import com.wavymusic.DashBord.Model.CategoryModel;
import com.wavymusic.DashBord.View.ViewPager.CustomViewPager;
import com.wavymusic.MoreApp.MoreAppActivity;
import com.wavymusic.MyCreationVideo.activity.YourVideoActivity;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.Setting.SettingActivity;
import com.wavymusic.UnityPlayerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeAllActivityUv extends AppCompatActivity implements View.OnClickListener {
    Activity activity = ThemeAllActivityUv.this;
    public int id;
    ArrayList<CategoryModel> tabcategorylistUv = new ArrayList<>();
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    Button btnRetry;
    TextView tvtitle;
    Toolbar toolbar;
    TextView tv_prg_msg;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView ivback, ivMoreApp;
    private ImageView ivSetting, ivMyCreation, ivRate;
    APIInterface apiInterfaceUv;
    ViewPagerAdapter adp;
    public SharedPreferences pref;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public boolean IsFromLanguage;

    boolean isSetupReadyUv = false;
    public static boolean isApiRunningUv = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme_all_uv);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        apiInterfaceUv = APIClient.getClientUv().create(APIInterface.class);
        IsFromLanguage = getIntent().getBooleanExtra("IsFromLanguage", false);
        PutAnalyticsEvent();
        BindView();
        SetUvThemeJsonData();
        VerifyToSetOfflineThemeDataUv();
        BannerAds();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ThemeAllActivityUv");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        toolbar = findViewById(R.id.toolbar);
        tvtitle = findViewById(R.id.tv_app_name);
        rlLoading = findViewById(R.id.rl_loading);
        tabLayout = findViewById(R.id.tab_viewall_wavy);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        tv_prg_msg = findViewById(R.id.tv_prg_msg);
        tv_prg_msg.setText("Please wait…");
        ivback = findViewById(R.id.iv_back);
        ivMoreApp = findViewById(R.id.iv_more_app);
        ivSetting = findViewById(R.id.iv_setting);
        ivMyCreation = findViewById(R.id.iv_my_creation);
        ivRate = findViewById(R.id.iv_rate);
        ivback.setOnClickListener(this);
        ivMoreApp.setOnClickListener(this);
        ivSetting.setOnClickListener(this);
        ivMyCreation.setOnClickListener(this);
        ivRate.setOnClickListener(this);

    }

    private void GoToMoreApp() {
        startActivity(new Intent(activity, MoreAppActivity.class));
        finish();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetUvThemeJsonData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (pref.getString("offlineResponseUV", "").equalsIgnoreCase("")) {
                if (!isApiRunningUv) {
                    isApiRunningUv = true;
                    GetCategoryUv();
                } else if (IsFromLanguage && MyApplication.TempcallUv != null) {
                    MyApplication.TempcallUv.cancel();
                    isApiRunningUv = true;
                    GetCategoryUv();
                }
            } else if (((new Date().getTime() - pref.getLong("offlineResponseTimeUv", 1588598205L)) >= AppConstant.ApiUpdateTime)) {
                if (!isApiRunningUv) {
                    isApiRunningUv = true;
                    GetCategoryUv();
                }
            } else if (IsFromLanguage) {
                if (!isApiRunningUv) {
                    isApiRunningUv = true;
                    GetCategoryUv();
                } else if (MyApplication.TempcallUv != null) {
                    MyApplication.TempcallUv.cancel();
                    isApiRunningUv = true;
                    GetCategoryUv();
                }
            }
        } else if (pref.getString("offlineResponseUV", "").equalsIgnoreCase("")) {
            Log.e("HomeActivity", "No Internet");
        }
    }

    private void VerifyToSetOfflineThemeDataUv() {
        if (pref.getString("offlineResponseUV", "").equalsIgnoreCase("")) {
            isSetupReadyUv = true;
        } else if (!IsFromLanguage) {
            SetupDataInLayoutUv(pref.getString("offlineResponseUV", ""));
        } else {
            isSetupReadyUv = true;
        }
    }

    private void GetCategoryUv() {
        final Handler handler = new Handler();
        if (pref.getString("offlineResponseUV", "").equalsIgnoreCase("")) {
            handler.postDelayed(new Runnable() {
                public void run() {
                    tv_prg_msg.setText("Slow Internet Connection");
                }
            }, 10000);
        }
        llRetry.setVisibility(View.GONE);
        rlLoading.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterfaceUv.GetAllThemeUv(AppConstant.Token, AppConstant.ApplicationId, "1", "1");
        MyApplication.TempcallUv = call;
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        if (handler != null) {
                            handler.removeCallbacksAndMessages(null);
                        }
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineCategory(activity, jsonObj.toString(), "offlineResponseUV");
                        //Set Response Time
                        SetOfflineResponseTime(activity, new Date(), "offlineResponseTimeUV");
                        isApiRunningUv = false;
                        if (isSetupReadyUv) {
                            isSetupReadyUv = false;
                            SetupDataInLayoutUv(jsonObj.toString());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                isApiRunningUv = false;
                rlLoading.setVisibility(View.GONE);
                if (pref.getString("offlineResponseUV", "").equalsIgnoreCase("")) {
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetupDataInLayoutUv(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray tabcategory = jsonObj.getJSONArray("category");
            for (int i = 0; i < tabcategory.length(); i++) {
                JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                String CategoryId = tabcategoryJSONObject.getString("id");
                SetOfflineCategory(activity, tabcategoryJSONObject.toString(), "Uv" + CategoryId);
                CategoryModel categoryModel = new CategoryModel();
                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                tabcategorylistUv.add(categoryModel);
            }
            setUpPagerUv();
            SetTabLayoutUv();
            rlLoading.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerUv() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        int i;
        viewPager.setAdapter(adp);
        if (MyApplication.CatSelectedPositionUv != -1) {
            i = MyApplication.CatSelectedPositionUv;
        } else {
            i = 0;
        }
        viewPager.setCurrentItem(i);
        tabLayout.setupWithViewPager(viewPager);
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayoutUv() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
        }

        ImageView ivCat = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.iv_cat);
        ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistUv.get(tabLayout.getSelectedTabPosition()).getName()));
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout llIndictor = customView.findViewById(R.id.ll_indictor);
                llIndictor.setVisibility(View.VISIBLE);
                ImageView ivCat = customView.findViewById(R.id.iv_cat);
                ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistUv.get(tab.getPosition()).getName()));
                MyApplication.ThemePositionUv = 0;
                MyApplication.CatSelectedPositionUv = tab.getPosition();

            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout llIndictor = customView.findViewById(R.id.ll_indictor);
                llIndictor.setVisibility(View.GONE);
                ImageView ivCat = customView.findViewById(R.id.iv_cat);
                ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThum(tabcategorylistUv.get(tab.getPosition()).getName()));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ImageView ivCat = customView.findViewById(R.id.iv_cat);
                    ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThumSelected(tabcategorylistUv.get(tab.getPosition()).getName()));
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_setting:
                GoToSetting();
                break;
            case R.id.iv_my_creation:
                GoToMyCreation();
                break;
            case R.id.iv_rate:
                RateApp();
                break;
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_more_app:
                GoToMoreApp();
                break;
        }
    }

    private void GoToSetting() {
        startActivity(new Intent(activity, SettingActivity.class));
        finish();
    }

    private void GoToMyCreation() {
        startActivity(new Intent(activity, YourVideoActivity.class));
        finish();
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "United Videos");
            String shareMessage = "\nGet free United Videos at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return ThemeViewAllFragmentUv.newInstance(Integer.parseInt(tabcategorylistUv.get(position).getCategoryId()));
        }


        @Override
        public int getCount() {
            return tabcategorylistUv.size();
        }


        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tvCategoryName);
            ImageView ivCat = tabCatView.findViewById(R.id.iv_cat);
            tv.setText(tabcategorylistUv.get(position).getName());
            ivCat.setImageResource(Utils.INSTANCE.ThemHomeCatThum(tabcategorylistUv.get(position).getName()));
            return tabCatView;
        }
    }

    private void SetOfflineCategory(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineResponseTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}