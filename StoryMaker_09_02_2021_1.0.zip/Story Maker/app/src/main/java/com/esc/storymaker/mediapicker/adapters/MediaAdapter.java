package com.esc.storymaker.mediapicker.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.esc.storymaker.R;
import com.esc.storymaker.mediapicker.utils.AppUtil;
import com.esc.storymaker.mediapicker.utils.ScreenUtil;

import java.util.List;

public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.MyViewHolder> {
    private Activity activity;
    private boolean isVideo;
    private List<String> mediaList;
    private List<Boolean> selected;

    public class MyViewHolder extends ViewHolder {
        public TextView duration;
        public ImageView thumbnail;

        public MyViewHolder(View view) {
            super(view);
            this.thumbnail = (ImageView) view.findViewById(R.id.iv_thumb);
            this.duration = (TextView) view.findViewById(R.id.tv_duration);
        }
    }

    public MediaAdapter(Activity activity, List<String> list, List<Boolean> list2, boolean z) {
        this.mediaList = list;
        this.activity = activity;
        this.selected = list2;
        this.isVideo = z;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_image, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.thumbnail.getLayoutParams().width = ScreenUtil.getScreenWidth(this.activity) / 3;
        myViewHolder.thumbnail.getLayoutParams().height = ScreenUtil.getScreenWidth(this.activity) / 3;
        RequestManager with = Glide.with(this.activity);
        StringBuilder stringBuilder = new StringBuilder();
        String str = "file://";
        stringBuilder.append(str);
        stringBuilder.append((String) this.mediaList.get(i));
        with.load(stringBuilder.toString()).into(myViewHolder.thumbnail);
        if (this.isVideo) {
            myViewHolder.duration.setVisibility(View.VISIBLE);
            TextView textView = myViewHolder.duration;
            Activity activity = this.activity;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append((String) this.mediaList.get(i));
            textView.setText(AppUtil.getVideoDuration(activity, stringBuilder.toString()));
        }
    }

    public int getItemCount() {
        return this.mediaList.size();
    }
}
