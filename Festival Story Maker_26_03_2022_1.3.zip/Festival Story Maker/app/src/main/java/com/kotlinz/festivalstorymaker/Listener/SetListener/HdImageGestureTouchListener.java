package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;


public class HdImageGestureTouchListener extends SimpleOnGestureListener {
    public final  int e;
    public final  int f;
    public final  HighlightDetailsDetailActivity activity;

    public HdImageGestureTouchListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity, int i, int i2) {
        this.activity = highlightDetailsDetailActivity;
        this.e = i;
        this.f = i2;
    }

    public boolean onDoubleTap(MotionEvent motionEvent) {
        activity.i0(activity, activity.O, this.e, this.f);
        return super.onDoubleTap(motionEvent);
    }

    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        HighlightDetailsDetailActivity highlightDetailsDetailActivity = this.activity;
        if (highlightDetailsDetailActivity.o0) {
            highlightDetailsDetailActivity.o0 = false;
        } else {
            highlightDetailsDetailActivity.n0();
            com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity.e eVar = new com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity.e();
           /* eVar.p0(this.g.U(), eVar.B);*/
        }
        return true;
    }
}
