package com.kotlinz.festivalstorymaker.esafirm.imagepicker.listeners;

import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import java.util.List;

public interface OnImageSelectedListener {
    void onSelectionUpdate(List<Image> selectedImage);
}
