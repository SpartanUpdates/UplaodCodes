package com.esc.flashlight.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.esc.flashlight.flashlight.FlashService;
import com.esc.flashlight.util.FlashAlertUtil;

public class SmsBroadcastReceiver extends BroadcastReceiver {
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";


    public void onReceive(Context context, Intent intent) {
        if (SMS_RECEIVED.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            if (extras != null && ((Object[]) extras.get("pdus")).length > 0) {
                handleReceiveMsg(context, intent);
            }
        }
    }

    private void handleReceiveMsg(Context context, Intent intent) {
        if (FlashAlertUtil.checkedReceiveMsg(context, intent)) {
            FlashService.runIntentInService(context, intent);
            setResult(-1, null, null);
        }
    }
}
