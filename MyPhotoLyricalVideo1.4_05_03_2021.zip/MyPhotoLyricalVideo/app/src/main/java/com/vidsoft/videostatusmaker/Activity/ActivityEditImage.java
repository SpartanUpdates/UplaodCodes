package com.vidsoft.videostatusmaker.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.MaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.Xfermode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import java.util.ArrayList;

import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.adapter.EffectAdapter;
import com.vidsoft.videostatusmaker.adapter.FrameAdapter;
import com.vidsoft.videostatusmaker.Utils.StickerView;

public class ActivityEditImage extends AppCompatActivity {
    float bri;
    LinearLayout darkLay;
    SeekBar darkSeek;
    TextView tvDone;
    ImageView ivDrawImg;
    ImageView ivEffectBtn;
    ImageView ivEffectImg;
    RecyclerView effect_list;
    ImageView ivBrightBtn;
    ImageView ivBrightDone;
    RecyclerView.LayoutManager layoutManager1;
    StickerView stickerView;
    ArrayList<View> arrayList;
    ImageView ivPaint;
    ImageView ivRotate;
    ImageView ivSaturation;
    ImageView saturation_done;
    LinearLayout linearLayout;
    SeekBar saturation_seek;
    RelativeLayout savelay;
    ImageView sharp_btn;
    ImageView sticker_btn;
    Bitmap temp;
    ImageView text_btn;
    static float BITMAP_SCALE = 0.05f;
    static float BLUR_RADIUS = 7.5f;
    public static Bitmap birmapDraw;
    public static Bitmap birmapSticker;
    int DRAW;
    int GET_STICKER;
    FrameAdapter frameAdapter;
    EffectAdapter effectAdapter;
    ImageView ivBack;
    TextView title;
    ImageView user_image;
    int w;
    LinearLayout BrightLayout;
    SeekBar brightSeek;
    float con;
    ImageView darkDone;
    String[] effects;
    ImageView flipBtn;
    ImageView flipUdBtn;
    Typeface typeface;
    FrameLayout frame;
    ImageView frameBtn;
    ImageView frameImg;
    RecyclerView frameList;
    String[] frames;
    int height;
    RecyclerView.LayoutManager layoutManager;

    public ActivityEditImage() {
        this.DRAW = 1111;
        this.GET_STICKER = 2222;
        this.arrayList = new ArrayList<View>();
        this.bri = 0.0f;
        this.con = 1.0f;
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_edit_image);
        this.getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        PutAnalyticsEvent();
        bindView();
        init();
        this.ClickEvents();
        this.setLayout();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityEditImage");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void addStickerView() {
        final StickerView currentEdit = new StickerView((Context) this);
        currentEdit.setBitmap(ActivityEditImage.birmapSticker);
        currentEdit.setOperationListener((StickerView.OperationListener) new StickerView.OperationListener() {
            @Override
            public void onDeleteClick() {
                ActivityEditImage.this.arrayList.remove(currentEdit);
                ActivityEditImage.this.frame.removeView((View) currentEdit);
            }

            @Override
            public void onEdit(final StickerView mCurrentView) {
                ActivityEditImage.this.stickerView.setInEdit(false);
                (ActivityEditImage.this.stickerView = mCurrentView).setInEdit(true);
            }

            @Override
            public void onTop(StickerView stickerView) {
                final int index = ActivityEditImage.this.arrayList.indexOf(stickerView);
                if (index == ActivityEditImage.this.arrayList.size() - 1) {
                    return;
                }
                stickerView = (StickerView) ActivityEditImage.this.arrayList.remove(index);
                ActivityEditImage.this.arrayList.add(ActivityEditImage.this.arrayList.size(), (View) stickerView);
            }
        });
        this.frame.addView((View) currentEdit, (ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(-1, -1));
        this.arrayList.add((View) currentEdit);
        this.setCurrentEdit(currentEdit);
    }

    public static Bitmap blur(final Context context, Bitmap bitmap) {
        final Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * ActivityEditImage.BITMAP_SCALE), Math.round(bitmap.getHeight() * ActivityEditImage.BITMAP_SCALE), false);
        bitmap = Bitmap.createBitmap(scaledBitmap);
        final RenderScript create = RenderScript.create(context);
        final ScriptIntrinsicBlur create2 = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        final Allocation fromBitmap = Allocation.createFromBitmap(create, scaledBitmap);
        final Allocation fromBitmap2 = Allocation.createFromBitmap(create, bitmap);
        create2.setRadius(ActivityEditImage.BLUR_RADIUS);
        create2.setInput(fromBitmap);
        create2.forEach(fromBitmap2);
        fromBitmap2.copyTo(bitmap);
        return bitmap;
    }

    private void setCurrentEdit(final StickerView mCurrentView) {
        if (this.stickerView != null) {
            this.stickerView.setInEdit(false);
        }
        (this.stickerView = mCurrentView).setInEdit(true);
    }

    public static Bitmap sideBlurt(final Bitmap bitmap, final int n) {
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint();
        paint.setAntiAlias(true);
        final float n2 = n;
        paint.setMaskFilter((MaskFilter) new BlurMaskFilter(n2, BlurMaskFilter.Blur.NORMAL));
        final Path path = new Path();
        path.moveTo(n2, n2);
        path.lineTo((float) (canvas.getWidth() - n), n2);
        path.lineTo((float) (canvas.getWidth() - n), (float) (canvas.getHeight() - n));
        path.lineTo(n2, (float) (canvas.getHeight() - n));
        path.lineTo(n2, n2);
        path.close();
        canvas.drawPath(path, paint);
        paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        return bitmap2;
    }

    private Bitmap updateSat(final Bitmap bitmap, final float saturation) {
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint();
        final ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(saturation);
        paint.setColorFilter((ColorFilter) new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        return bitmap2;
    }

    void ClickEvents() {
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.onBackPressed();
            }
        });
        this.tvDone.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.user_image.performClick();
                ActivityEditImage.this.savelay.setDrawingCacheEnabled(false);
                ActivityEditImage.this.savelay.setDrawingCacheEnabled(true);
                ActivityEditImage.this.savelay.buildDrawingCache();
                Utils.save = ActivityEditImage.this.savelay.getDrawingCache();
                ActivityEditImage.this.setResult(-1);
                ActivityEditImage.this.finish();

            }
        });
        this.brightSeek.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                ActivityEditImage.this.bri = n - 200;
                ActivityEditImage.this.temp = ActivityEditImage.this.enhanceImage(Utils.selected_Bitmap, ActivityEditImage.this.con, ActivityEditImage.this.bri);
                ActivityEditImage.this.user_image.setImageBitmap(ActivityEditImage.this.temp);
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        this.saturation_seek.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                ActivityEditImage.this.temp = ActivityEditImage.this.updateSat(Utils.selected_Bitmap, n / 100.0f);
                ActivityEditImage.this.user_image.setImageBitmap(ActivityEditImage.this.temp);
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        this.darkSeek.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                if (n > 0) {
                    ActivityEditImage.this.temp = ActivityEditImage.sideBlurt(Utils.selected_Bitmap, n);
                    ActivityEditImage.this.user_image.setImageBitmap(ActivityEditImage.this.temp);
                }
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        this.ivBrightBtn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.frameList.setVisibility(View.GONE);
                ActivityEditImage.this.effect_list.setVisibility(View.GONE);
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
                if (ActivityEditImage.this.BrightLayout.getVisibility() == View.GONE) {
                    ActivityEditImage.this.BrightLayout.setVisibility(View.VISIBLE);
                    ActivityEditImage.this.ivBrightBtn.setImageResource(R.drawable.ic_brightness_pressed);
                    return;
                }
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
            }
        });
        this.ivSaturation.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.frameList.setVisibility(View.GONE);
                ActivityEditImage.this.effect_list.setVisibility(View.GONE);
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
                if (ActivityEditImage.this.linearLayout.getVisibility() == View.GONE) {
                    ActivityEditImage.this.linearLayout.setVisibility(View.VISIBLE);
                    ActivityEditImage.this.ivSaturation.setImageResource(R.drawable.saturation_pressed);
                    return;
                }
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
            }
        });
        this.frameBtn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.effect_list.setVisibility(View.GONE);
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
                if (ActivityEditImage.this.frameList.getVisibility() == View.GONE) {
                    ActivityEditImage.this.frameList.setVisibility(View.VISIBLE);
                    ActivityEditImage.this.frameBtn.setImageResource(R.drawable.frames_pressed);
                    return;
                }
                ActivityEditImage.this.frameList.setVisibility(View.GONE);
            }
        });
        this.sharp_btn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.effect_list.setVisibility(View.GONE);
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
                ActivityEditImage.this.frameList.setVisibility(View.GONE);
                if (ActivityEditImage.this.darkLay.getVisibility() == View.GONE) {
                    ActivityEditImage.this.darkLay.setVisibility(View.VISIBLE);
                    ActivityEditImage.this.sharp_btn.setImageResource(R.drawable.ic_blend_pressed);
                    return;
                }
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
            }
        });
        this.ivEffectBtn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.frameList.setVisibility(View.GONE);
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
                if (ActivityEditImage.this.effect_list.getVisibility() == View.GONE) {
                    ActivityEditImage.this.effect_list.setVisibility(View.VISIBLE);
                    ActivityEditImage.this.ivEffectBtn.setImageResource(R.drawable.effect_pressed);
                    return;
                }
                ActivityEditImage.this.effect_list.setVisibility(View.GONE);
            }
        });
        this.ivBrightDone.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.this.temp;
                ActivityEditImage.this.BrightLayout.setVisibility(View.GONE);
            }
        });
        this.saturation_done.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.this.temp;
                ActivityEditImage.this.linearLayout.setVisibility(View.GONE);
            }
        });
        this.darkDone.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.this.temp;
                ActivityEditImage.this.darkLay.setVisibility(View.GONE);
            }
        });
        this.user_image.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                if (ActivityEditImage.this.stickerView != null) {
                    ActivityEditImage.this.stickerView.setInEdit(false);
                }
            }
        });
        this.ivPaint.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.startActivityForResult(new Intent(ActivityEditImage.this.getApplicationContext(), (Class) ActivityDrawImage.class), ActivityEditImage.this.DRAW);
            }
        });
        this.ivRotate.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.RotateBitmap(Utils.selected_Bitmap, 90.0f);
                ActivityEditImage.this.user_image.setImageBitmap(Utils.selected_Bitmap);
            }
        });
        this.flipBtn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.LRBitmap(Utils.selected_Bitmap);
                ActivityEditImage.this.user_image.setImageBitmap(Utils.selected_Bitmap);
            }
        });
        this.flipUdBtn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                Utils.selected_Bitmap = ActivityEditImage.UDBitmap(Utils.selected_Bitmap);
                ActivityEditImage.this.user_image.setImageBitmap(Utils.selected_Bitmap);
            }
        });
        this.sticker_btn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.startActivityForResult(new Intent(ActivityEditImage.this.getApplicationContext(), (Class) ActivityStickerSelect.class), ActivityEditImage.this.GET_STICKER);
            }
        });
        this.text_btn.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.this.setUnpress();
                ActivityEditImage.this.startActivityForResult(new Intent(ActivityEditImage.this.getApplicationContext(), (Class) ActivityAddText.class), ActivityEditImage.this.GET_STICKER);
            }
        });
    }

    Bitmap enhanceImage(final Bitmap bitmap, final float n, final float n2) {
        final ColorMatrix colorMatrix = new ColorMatrix(new float[]{n, 0.0f, 0.0f, 0.0f, n2, 0.0f, n, 0.0f, 0.0f, n2, 0.0f, 0.0f, n, 0.0f, n2, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f});
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint();
        paint.setColorFilter((ColorFilter) new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        return bitmap2;
    }

    @Override
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == this.DRAW && n2 == -1) {
            this.ivDrawImg.setImageBitmap(ActivityEditImage.birmapDraw);
        }
        if (n == this.GET_STICKER && n2 == -1) {
            this.addStickerView();
        }
    }


    private void init() {
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.brightSeek.setMax(400);
        this.brightSeek.setProgress(200);
        this.saturation_seek.setMax(200);
        this.saturation_seek.setProgress(100);
        this.darkSeek.setMax(100);
        this.darkSeek.setProgress(0);
        try {
            this.frames = this.getResources().getAssets().list("image_frame");
            this.effects = this.getResources().getAssets().list("effect");
            this.frameAdapter = new FrameAdapter((Context) this, this.frames);
            this.frameList.setAdapter(frameAdapter);
            this.layoutManager = new LinearLayoutManager((Context) this, 0, false);
            this.frameList.setLayoutManager(this.layoutManager);
            this.effectAdapter = new EffectAdapter((Context) this, this.effects, Utils.selected_Bitmap);
            this.effect_list.setAdapter((RecyclerView.Adapter) this.effectAdapter);
            this.layoutManager1 = new LinearLayoutManager((Context) this, 0, false);
            this.effect_list.setLayoutManager(this.layoutManager1);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.user_image.setImageBitmap(Utils.selected_Bitmap);
        this.temp = Utils.selected_Bitmap;
        this.user_image.setBackgroundDrawable((Drawable) new BitmapDrawable(this.getResources(), blur((Context) this, Utils.selected_Bitmap)));
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.w, this.w);
        layoutParams.addRule(13);
        this.savelay.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
    }

    private void bindView() {
        this.title = (TextView) findViewById(R.id.title);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.tvDone = (TextView) findViewById(R.id.done);
        this.frame = (FrameLayout) findViewById(R.id.frame);
        this.savelay = (RelativeLayout) findViewById(R.id.savelay);
        this.user_image = (ImageView) findViewById(R.id.user_image);
        this.frameImg = (ImageView) findViewById(R.id.frame_img);
        this.ivEffectImg = (ImageView) findViewById(R.id.effect_img);
        this.ivDrawImg = (ImageView) findViewById(R.id.draw_img);
        this.frameList = (RecyclerView) findViewById(R.id.frame_list);
        this.effect_list = (RecyclerView) findViewById(R.id.effect_list);
        this.frameBtn = (ImageView) findViewById(R.id.frame_btn);
        this.ivEffectBtn = (ImageView) findViewById(R.id.effect_btn);
        this.sticker_btn = (ImageView) findViewById(R.id.sticker_btn);
        this.text_btn = (ImageView) findViewById(R.id.text_btn);
        this.ivRotate = (ImageView) findViewById(R.id.rotate_btn);
        this.flipBtn = (ImageView) findViewById(R.id.flip_btn);
        this.ivPaint = (ImageView) findViewById(R.id.paint_btn);
        this.flipUdBtn = (ImageView) findViewById(R.id.flip_ud_btn);
        this.ivBrightBtn = (ImageView) findViewById(R.id.bright_btn);
        this.ivSaturation = (ImageView) findViewById(R.id.saturation_btn);
        this.sharp_btn = (ImageView) findViewById(R.id.sharp_btn);
        this.brightSeek = (SeekBar) findViewById(R.id.bright_seek);
        this.saturation_seek = (SeekBar) findViewById(R.id.saturation_seek);
        this.darkSeek = (SeekBar) findViewById(R.id.dark_seek);
        this.BrightLayout = (LinearLayout) findViewById(R.id.bright_lay);
        this.linearLayout = (LinearLayout) findViewById(R.id.saturation_lay);
        this.darkLay = (LinearLayout) findViewById(R.id.dark_lay);
        this.ivBrightDone = (ImageView) findViewById(R.id.bright_done);
        this.saturation_done = (ImageView) findViewById(R.id.saturation_done);
        this.darkDone = (ImageView) findViewById(R.id.dark_done);
    }


    public void setEffect(final int n) {
        if (n == 0) {
            this.ivEffectImg.setImageDrawable((Drawable) null);
            return;
        }
        try {
            final AssetManager assets = this.getAssets();
            final StringBuilder sb = new StringBuilder();
            sb.append("effect/");
            sb.append(this.effects[n]);
            this.ivEffectImg.setImageDrawable(Drawable.createFromStream(assets.open(sb.toString()), (String) null));
        } catch (Exception ex) {
        }
    }

    public void setFrame(final int n) {
        if (n == 0) {
            this.frameImg.setImageDrawable((Drawable) null);
            return;
        }
        try {
            final AssetManager assets = this.getAssets();
            final StringBuilder sb = new StringBuilder();
            sb.append("image_frame/");
            sb.append(this.frames[n]);
            this.frameImg.setImageDrawable(Drawable.createFromStream(assets.open(sb.toString()), (String) null));
        } catch (Exception ex) {
        }
    }

    void setLayout() {
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.w * 70 / 1080, this.height * 70 / 1920);
        layoutParams.addRule(15);
        final int n = this.w * 40 / 1080;
        layoutParams.setMargins(n, 0, 0, 0);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(this.w * 70 / 1080, this.height * 70 / 1920);
        layoutParams2.addRule(15);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(0, 0, n, 0);
        final LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(this.w * 178 / 1080, this.height * 134 / 1920);
        layoutParams3.setMargins(n, 0, 0, 0);
        this.frameBtn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.ivEffectBtn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.sticker_btn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.text_btn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.ivRotate.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.flipBtn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.ivPaint.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.flipUdBtn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.ivBrightBtn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.ivSaturation.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.sharp_btn.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        final RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-1, this.height * 150 / 1920);
        this.BrightLayout.setLayoutParams((ViewGroup.LayoutParams) layoutParams4);
        this.linearLayout.setLayoutParams((ViewGroup.LayoutParams) layoutParams4);
        this.darkLay.setLayoutParams((ViewGroup.LayoutParams) layoutParams4);
        final RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(this.w * 141 / 1080, this.height * 150 / 1920);
        layoutParams5.setMargins(this.w * 15 / 1080, 0, 0, 0);
        this.ivBrightDone.setLayoutParams((ViewGroup.LayoutParams) layoutParams5);
        this.saturation_done.setLayoutParams((ViewGroup.LayoutParams) layoutParams5);
        this.darkDone.setLayoutParams((ViewGroup.LayoutParams) layoutParams5);
        final Bitmap decodeResource = BitmapFactory.decodeResource(this.getResources(), R.drawable.thumb);
        final Bitmap scaledBitmap = Bitmap.createScaledBitmap(decodeResource, this.w * decodeResource.getWidth() / 1080, this.height * decodeResource.getHeight() / 1920, true);
        this.brightSeek.setThumb((Drawable) new BitmapDrawable(this.getResources(), scaledBitmap));
        this.saturation_seek.setThumb((Drawable) new BitmapDrawable(this.getResources(), scaledBitmap));
        this.darkSeek.setThumb((Drawable) new BitmapDrawable(this.getResources(), scaledBitmap));
    }


    void setUnpress() {
        this.frameBtn.setImageResource(R.drawable.frames_unpressed);
        this.ivEffectBtn.setImageResource(R.drawable.effect_unpressed);
        this.ivBrightBtn.setImageResource(R.drawable.ic_brightness_unpressed);
        this.ivSaturation.setImageResource(R.drawable.saturation_unpressed);
        this.sharp_btn.setImageResource(R.drawable.ic_blend_unpressed);
    }

    public static Bitmap LRBitmap(final Bitmap bitmap) {
        final Matrix matrix = new Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap RotateBitmap(final Bitmap bitmap, final float n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap UDBitmap(final Bitmap bitmap) {
        final Matrix matrix = new Matrix();
        matrix.preScale(1.0f, -1.0f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

}
