package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.larswerkman.holocolorpicker.ColorPicker;
import com.larswerkman.holocolorpicker.OpacityBar;
import com.larswerkman.holocolorpicker.SVBar;

import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.Utils.DrawingView;

public class ActivityDrawImage extends Activity {

    SeekBar seekBar;
    LinearLayout bottomLayout;
    ImageView ivColor;
    TextView tvDone;
    DrawingView drawingView;
    private SVBar bar;
    TextView textView;
    ImageView ivBack;
    ImageView imageView;
    private OpacityBar opacityBar;
    int pickColor;
    private ColorPicker colorPicker;
    ImageView ivReset;
    Typeface typeface;
    private static final float BITMAP_SCALE = 0.05f;
    private static final float BLUR_RADIUS = 7.5f;
    public ActivityDrawImage() {
        this.pickColor = -8323328;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static Bitmap blur(final Context context, Bitmap bitmap) {
        final Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * 0.05f), Math.round(bitmap.getHeight() * 0.05f), false);
        bitmap = Bitmap.createBitmap(scaledBitmap);
        final RenderScript create = RenderScript.create(context);
        final ScriptIntrinsicBlur create2 = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        final Allocation fromBitmap = Allocation.createFromBitmap(create, scaledBitmap);
        final Allocation fromBitmap2 = Allocation.createFromBitmap(create, bitmap);
        create2.setRadius(7.5f);
        create2.setInput(fromBitmap);
        create2.forEach(fromBitmap2);
        fromBitmap2.copyTo(bitmap);
        return bitmap;
    }


    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.drawlay);
        this.getWindow().addFlags(1024);
        bindView();
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        PutAnalyticsEvent();
        init();
        this.setLayout();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityDrawImage");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void init() {
        this.textView.setTypeface(this.typeface);
        this.seekBar.setMax(50);
        this.seekBar.setProgress(0);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels, widthPixels);
        relativeLayout$LayoutParams.addRule(13);
        this.imageView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
        this.drawingView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
        this.imageView.setImageBitmap(Utils.selected_Bitmap);
        this.imageView.setBackgroundDrawable((Drawable) new BitmapDrawable(this.getResources(), blur((Context) this, Utils.selected_Bitmap)));
        this.ivReset.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityDrawImage.this.drawingView.clear();
            }
        });
        this.ivColor.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityDrawImage.this.DialogColor();
            }
        });
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityDrawImage.this.onBackPressed();
            }
        });
        this.tvDone.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityEditImage.birmapDraw = ActivityDrawImage.this.drawingView.getBitmap();
                ActivityDrawImage.this.setResult(-1);
                ActivityDrawImage.this.finish();
            }
        });
        this.seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                DrawingView.paint.setStrokeWidth((float) (n + 10));
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
    }

    private void bindView() {

        this.drawingView = (DrawingView) findViewById(R.id.draw);
        this.seekBar = (SeekBar) findViewById(R.id.seek);
        this.imageView = (ImageView) findViewById(R.id.img);
        this.ivReset = (ImageView) findViewById(R.id.reset);
        this.ivColor = (ImageView) findViewById(R.id.color);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.tvDone = (TextView) findViewById(R.id.done);
        this.textView = (TextView) findViewById(R.id.title);
        this.bottomLayout = (LinearLayout) findViewById(R.id.bot_lay);
    }

    void setLayout() {
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        final int n = widthPixels * 70 / 1080;
        final int n2 = heightPixels * 70 / 1920;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n, n2);
        layoutParams.addRule(15);
        final int n3 = widthPixels * 30 / 1080;
        layoutParams.setMargins(n3, 0, 0, 0);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(n, n2);
        layoutParams2.addRule(15);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(0, 0, n3, 0);
        final int n4 = heightPixels * 150 / 1920;
        this.bottomLayout.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(-1, n4));
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 141 / 1080, n4);
        this.ivReset.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
        final Bitmap decodeResource = BitmapFactory.decodeResource(this.getResources(), R.drawable.thumb);
        this.seekBar.setThumb((Drawable) new BitmapDrawable(this.getResources(), Bitmap.createScaledBitmap(decodeResource, widthPixels * decodeResource.getWidth() / 1080, heightPixels * decodeResource.getHeight() / 1920, true)));
    }


    void DialogColor() {
        final Dialog dialog = new Dialog((Context) this);
        dialog.getWindow().setBackgroundDrawable((Drawable) new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        final LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.mainLay);
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.getResources().getDisplayMetrics().heightPixels;
        linearLayout.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(widthPixels * 900 / 1080, heightPixels * 1310 / 1920));

        TextView textView = (TextView) dialog.findViewById(R.id.title);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView imageView2 = (ImageView) dialog.findViewById(R.id.ok);
        ImageView imageView3 = (ImageView) dialog.findViewById(R.id.close);
        final RelativeLayout.LayoutParams relativeLayout$LayoutParams = new RelativeLayout.LayoutParams(widthPixels * 310 / 1080, heightPixels * 100 / 1920);
        relativeLayout$LayoutParams.addRule(13);
        imageView.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
        imageView2.setLayoutParams((ViewGroup.LayoutParams) relativeLayout$LayoutParams);
        final int n = widthPixels * 40 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 65 / 1080, heightPixels * 65 / 1920);
        layoutParams.addRule(15);
        layoutParams.addRule(11);
        layoutParams.setMargins(0, 0, n, 0);
        imageView3.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        this.colorPicker = (ColorPicker) dialog.findViewById(R.id.picker);
        this.bar = (SVBar) dialog.findViewById(R.id.svbar);
        this.opacityBar = (OpacityBar) dialog.findViewById(R.id.opacitybar);
        final LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(widthPixels * 650 / 1080, heightPixels * 650 / 1920);
        layoutParams2.gravity = 17;
        this.colorPicker.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        this.colorPicker.addSVBar(this.bar);
        this.colorPicker.addOpacityBar(this.opacityBar);
        this.colorPicker.setOldCenterColor(this.pickColor);
        this.colorPicker.setColor(this.pickColor);
        this.bar.setColor(this.pickColor);
        this.opacityBar.setColor(this.pickColor);
        imageView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        imageView2.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivityDrawImage.this.pickColor = ActivityDrawImage.this.colorPicker.getColor();
                ActivityDrawImage.this.drawingView.setPathColor(ActivityDrawImage.this.pickColor);
                dialog.dismiss();
            }
        });
        imageView3.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
