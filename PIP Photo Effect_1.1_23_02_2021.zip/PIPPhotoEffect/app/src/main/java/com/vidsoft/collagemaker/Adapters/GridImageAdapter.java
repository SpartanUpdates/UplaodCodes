package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.afollestad.sectionedrecyclerview.SectionedRecyclerViewAdapter;
import com.afollestad.sectionedrecyclerview.SectionedViewHolder;
import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.GridThreeD.ImageSelectionthreeDActivity;
import com.vidsoft.collagemaker.Model.Grid3D;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.util.ArrayList;

public class GridImageAdapter extends SectionedRecyclerViewAdapter<GridImageAdapter.MainVH> {
    Activity activity;
    ArrayList<Grid3D> list;
    int temp_section;

    public static class MainVH extends SectionedViewHolder {
        ImageView imageView;
        final TextView title;
        View v;

        public MainVH(View itemView) {
            super(itemView);
            this.title = (TextView) itemView.findViewById(R.id.title);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);

        }
    }

    public GridImageAdapter(Activity activity, ArrayList<Grid3D> list) {
        this.list = list;
        this.activity = activity;
    }

    public int getSectionCount() {
        return 6;
    }

    public int getItemCount(int section) {
        switch (section) {
            case 0:
            case 2:
            case 3:
                return 6;
            case 1:
                return 3;
            case 4:
                return 3;
            case 5:
                return 3;
            default:
                return 0;
        }
    }

    @Override
    public void onBindHeaderViewHolder(MainVH holder, int section, boolean expanded) {
        holder.title.setText((section + 1) + " Frame");
    }

    @Override
    public void onBindFooterViewHolder(MainVH holder, int section) {

    }

    public void onBindViewHolder(MainVH holder, final int section, final int relativePosition, final int absolutePosition) {
        holder.v = new View(this.activity);
        Glide.with(this.activity).load(Integer.valueOf(((Grid3D) this.list.get(absolutePosition - (section + 1))).getThumb())).into(holder.imageView);
        holder.imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GridImageAdapter.this.activity, ImageSelectionthreeDActivity.class);
                intent.putExtra(Const.currentGrid, relativePosition);
                intent.putExtra(Const.imgId, String.valueOf(((Grid3D) GridImageAdapter.this.list.get(absolutePosition - (section + 1))).getImage()));
                intent.putExtra(Const.imgSource, String.valueOf(((Grid3D) GridImageAdapter.this.list.get(absolutePosition - (section + 1))).getLayout()));
                intent.setFlags(268435456);
                GridImageAdapter.this.activity.startActivity(intent);
                GridImageAdapter.this.activity.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
            }
        });
        if (section == 2) {
            Log.e("22", "22");
        } else if (section == 3) {
            Log.e("33", "33");
        }
    }

    public int getItemViewType(int section, int relativePosition, int absolutePosition) {
        if (section == 1) {
            return 0;
        }
        return super.getItemViewType(section, relativePosition, absolutePosition);
    }

    @Override
    public MainVH onCreateViewHolder(final ViewGroup viewGroup, int n) {
        switch (n) {
            default: {
                n = R.layout.gridimage_adapter;
                break;
            }
            case -2: {
                n = R.layout.header_grid_adapter;
                break;
            }
            case -1: {
                n = R.layout.gridimage_adapter;
                break;
            }
        }
        return new MainVH(LayoutInflater.from(viewGroup.getContext()).inflate(n, viewGroup, false));
    }
}