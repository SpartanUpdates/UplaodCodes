package com.example.postermaker.editorsclasses.choseitems;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;

import com.example.postermaker.R;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;
import com.xiaopo.flying.sticker.DrawableSticker;

public class eaz_ChooseItems implements OnClickListener {
    Context context;

    public eaz_ChooseItems(Context context) {
        this.context = context;
    }

    public void loadItemsChoser() {
        eaz_EditActivity.choseitemslayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.sale.setOnClickListener(this);
        eaz_EditActivity.offer.setOnClickListener(this);
        eaz_EditActivity.ribbon.setOnClickListener(this);
        eaz_EditActivity.amazing.setOnClickListener(this);
        eaz_EditActivity.birthday.setOnClickListener(this);
        eaz_EditActivity.border.setOnClickListener(this);
        eaz_EditActivity.cars.setOnClickListener(this);
        eaz_EditActivity.circles.setOnClickListener(this);
        eaz_EditActivity.coffe.setOnClickListener(this);
        eaz_EditActivity.education.setOnClickListener(this);
        eaz_EditActivity.exercise.setOnClickListener(this);
        eaz_EditActivity.fruites.setOnClickListener(this);
        eaz_EditActivity.festival.setOnClickListener(this);
        eaz_EditActivity.love.setOnClickListener(this);
        eaz_EditActivity.music.setOnClickListener(this);
        eaz_EditActivity.nature.setOnClickListener(this);
        eaz_EditActivity.shapes.setOnClickListener(this);
        eaz_EditActivity.tea.setOnClickListener(this);
        eaz_EditActivity.animal.setOnClickListener(this);
        eaz_EditActivity.cartoon.setOnClickListener(this);
        eaz_EditActivity.flat.setOnClickListener(this);
        saleItemsLayout();
    }

    public void saleItemsLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.pink));
        for (int i = 0; i < eaz_ConstantValues.sale.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

           // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);

            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.sale[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.sale[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void offerIteLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();

        for (int i = 0; i < eaz_ConstantValues.offer.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.offer[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.offer[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void ribbonItemLayout() {

        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.ribbons.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.ribbons[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.ribbons[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void amazingItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.amazing.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.amazing[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.amazing[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void bithdayItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.birthday.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.birthday[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.birthday[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void borderItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.border.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.border[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.border[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void carItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.cars.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.cars[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.cars[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void circleItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.circles.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.circles[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.circles[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void coffieItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.coffee.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.coffee[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.coffee[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void educationItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.education.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.education[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.education[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void exerciseItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.excersise.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.excersise[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.excersise[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void fruitesItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.fruites.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.fruites[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.fruites[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void holiItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.holi.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.holi[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.holi[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void loveTextItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.loveText.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.loveText[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.loveText[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void musicItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.music.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.music[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.music[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void natureItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.nature.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.nature[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.nature[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void shapesItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.shapes.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.shapes[i])).into(imageView);
            imageView.setColorFilter(-16777216);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.shapes[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void teaCupItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.teacup.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.teacup[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.teacup[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void animalItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.animals.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.animals[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.animals[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void cartoonItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.cartoons.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

            marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.cartoons[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.cartoons[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void flatItemLayout() {
        eaz_EditActivity.itemsLoader.removeAllViews();
        for (int i = 0; i < eaz_ConstantValues.flatribbons.length; i++) {
            ImageView imageView = new ImageView(this.context);

            ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                    ViewGroup.MarginLayoutParams.MATCH_PARENT,
                    ViewGroup.MarginLayoutParams.WRAP_CONTENT
            );

              marginLayoutParams.setMargins(20, 20, 20, 20);
            imageView.setLayoutParams(marginLayoutParams);
            imageView.setBackground(context.getResources().getDrawable(R.drawable.stickrbg));

            // imageView.setLayoutParams(new LayoutParams(60, 60));

            imageView.setPadding(10, 10, 10, 10);
            Glide.with(this.context).load(Integer.valueOf(eaz_ConstantValues.flatribbons[i])).into(imageView);
            imageView.setColorFilter(-16777216);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_EditActivity.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(eaz_ChooseItems.this.context, eaz_ConstantValues.flatribbons[finalI])));
                    eaz_EditActivity.choseitemslayout.setVisibility(View.GONE);
                }
            });
            eaz_EditActivity.itemsLoader.addView(imageView);
        }
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.sale)) {
            saleItemsLayout();
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));


        } else if (view.equals(eaz_EditActivity.offer)) {
            offerIteLayout();

            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.ribbon)) {
            ribbonItemLayout();
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.amazing)) {
            amazingItemLayout();
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.birthday)) {
            bithdayItemLayout();
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.border)) {
            borderItemLayout();
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.cars)) {
            carItemLayout();
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.circles)) {
            circleItemLayout();
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.coffe)) {
            coffieItemLayout();

            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.education)) {
            educationItemLayout();
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.exercise)) {
            exerciseItemLayout();
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.fruites)) {
            fruitesItemLayout();
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.festival)) {
            holiItemLayout();
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.love)) {
            loveTextItemLayout();
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.music)) {
            musicItemLayout();

            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.nature)) {
            natureItemLayout();

            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));

        } else if (view.equals(eaz_EditActivity.shapes)) {
            shapesItemLayout();
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));
        } else if (view.equals(eaz_EditActivity.tea)) {

            teaCupItemLayout();

            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));
        } else if (view.equals(eaz_EditActivity.animal)) {
            animalItemLayout();
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));
        } else if (view.equals(eaz_EditActivity.cartoon)) {
            cartoonItemLayout();
            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.gray));
        } else if (view.equals(eaz_EditActivity.flat)) {
            flatItemLayout();
            eaz_EditActivity.flat.setTextColor(context.getResources().getColor(R.color.pink));

            eaz_EditActivity.cartoon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.animal.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.tea.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.shapes.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.nature.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.music.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.love.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.festival.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.fruites.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.exercise.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.education.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.coffe.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.circles.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.cars.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.border.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.sale.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.offer.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.ribbon.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.amazing.setTextColor(context.getResources().getColor(R.color.gray));
            eaz_EditActivity.birthday.setTextColor(context.getResources().getColor(R.color.gray));
        }
    }
}
