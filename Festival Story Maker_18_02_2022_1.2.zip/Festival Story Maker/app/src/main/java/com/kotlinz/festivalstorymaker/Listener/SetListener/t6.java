package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;


public class t6 extends SimpleOnGestureListener {
    public final int e;
    public final  int f;
    public final HighlightDetailsDetailActivity activity;

    public t6(HighlightDetailsDetailActivity highlightDetailsDetailActivity, int i, int i2) {
        this.activity = highlightDetailsDetailActivity;
        this.e = i;
        this.f = i2;
    }

    public boolean onDoubleTap(MotionEvent motionEvent) {
        activity.h0 = true;
        HighlightDetailsDetailActivity.i0(activity, activity.O, this.e, this.f);
        return super.onDoubleTap(motionEvent);
    }
}
