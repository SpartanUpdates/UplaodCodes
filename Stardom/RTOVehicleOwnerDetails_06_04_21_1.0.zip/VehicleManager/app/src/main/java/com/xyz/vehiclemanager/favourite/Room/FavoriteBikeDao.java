package com.xyz.vehiclemanager.favourite.Room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.xyz.vehiclemanager.favourite.model.FavoriteBikeModel;
import com.xyz.vehiclemanager.favourite.model.FavoriteCarModel;

import java.util.List;
@Dao
public interface FavoriteBikeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertBikeFavorite(FavoriteBikeModel favoriteBikeModel);

    @Query("select * from FavoriteBike")
    List<FavoriteBikeModel> getFavoriteBikeList();

    @Query(" Delete from FavoriteBike where modelId=:modelId")
    void deleteBikeFavorite(String modelId);
}
