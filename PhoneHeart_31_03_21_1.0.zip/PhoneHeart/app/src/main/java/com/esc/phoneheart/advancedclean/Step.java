package com.esc.phoneheart.advancedclean;

public abstract class Step {
    public Step mNext;

    public abstract void doAction();

    public void doNext() {
        Step step = this.mNext;
        if (step != null) {
            step.doAction();
        }
    }

    public Step setNext(Step step) {
        this.mNext = step;
        return this;
    }
}
