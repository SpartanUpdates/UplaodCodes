package com.kotlinz.festivalstorymaker.Listener.festival;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.yalantis.ucrop.UCropActivity;

import java.io.File;

public class g5 implements ViewTreeObserver.OnPreDrawListener {
    public final FestivalDetailActivity_New n;

    /*public class a extends GestureDetector.SimpleOnGestureListener {
        public boolean onDoubleTap(MotionEvent motionEvent) {
            FestivalDetailActivity_New festivalDetailActivity_New = g5.this.n;
            if (festivalDetailActivity_New.S) {
                festivalDetailActivity_New.S = false;
            } else {
                festivalDetailActivity_New.K0();
                festivalDetailActivity_New = g5.this.n;
                String str = festivalDetailActivity_New.k0;
                if (festivalDetailActivity_New != null) {
                    Bundle d =new Bundle();
                    Utils.U(Bitmap.CompressFormat.JPEG, d, "com.yalantis.ucrop.CompressionFormatName", "com.yalantis.ucrop.CompressionQuality", 100);
                    d.putString("com.yalantis.ucrop.UcropToolbarTitleText", "Crop");
                    d.putBoolean("com.yalantis.ucrop.HideBottomControls", true);
                    d.putBoolean("com.yalantis.ucrop.FreeStyleCrop", false);
                    Uri c = Utils.cf(str);
                    Uri fromFile = Uri.fromFile(new File(festivalDetailActivity_New.getCacheDir(),Utils.A(new StringBuilder(), ".png")));
                    Intent intent = new Intent();
                    Bundle e = Utils.e("com.yalantis.ucrop.InputUri", c, "com.yalantis.ucrop.OutputUri", fromFile);
                    float height = (float) festivalDetailActivity_New.imgFestival.getHeight();
                    e.putFloat("com.yalantis.ucrop.AspectRatioX", (float) festivalDetailActivity_New.imgFestival.getWidth());
                    e.putFloat("com.yalantis.ucrop.AspectRatioY", height);
                    int width = festivalDetailActivity_New.imgFestival.getWidth();
                    int height2 = festivalDetailActivity_New.imgFestival.getHeight();
                    if (width < 10) {
                        width = 10;
                    }
                    if (height2 < 10) {
                        height2 = 10;
                    }
                    e.putInt("com.yalantis.ucrop.MaxSizeX", width);
                    e.putInt("com.yalantis.ucrop.MaxSizeY", height2);
                    e.putAll(d);
                    intent.setClass(festivalDetailActivity_New, UCropActivity.class);
                    intent.putExtras(e);
                    festivalDetailActivity_New.startActivityForResult(intent, 69);
                }
            }
            return super.onDoubleTap(motionEvent);
        }

        public void onLongPress(MotionEvent motionEvent) {
        }

        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            FestivalDetailActivity_New festivalDetailActivity_New = g5.this.n;
            if (festivalDetailActivity_New.S) {
                festivalDetailActivity_New.S = false;
            } else {
                festivalDetailActivity_New.K0();
                FestivalDetailActivity_New.x xVar = new FestivalDetailActivity_New.x();
                xVar.show(g5.this.n.getSupportFragmentManager(), "");
            }
            return true;
        }
    }

    public class b implements View.OnTouchListener {
        public final GestureDetector gestureDetector;

        public b(g5 g5Var, GestureDetector gestureDetector) {
            this.gestureDetector = gestureDetector;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            this.gestureDetector.onTouchEvent(motionEvent);
            return true;
        }
    }
*/
    public g5(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    @SuppressLint("ClickableViewAccessibility")
    public boolean onPreDraw() {
        this.n.cardEditor.getViewTreeObserver().removeOnPreDrawListener(this);
        FestivalDetailActivity_New festivalDetailActivity_New = this.n;
        if (festivalDetailActivity_New.m0 == -1) {
            festivalDetailActivity_New.m0 = (festivalDetailActivity_New.cardEditor.getWidth() * 1350) / 1080;
            festivalDetailActivity_New = this.n;
            festivalDetailActivity_New.n0 = festivalDetailActivity_New.cardEditor.getWidth();
            if (this.n.B0.size() > 2) {
                festivalDetailActivity_New = this.n;
                festivalDetailActivity_New.imgFrame.setImageURI(Uri.parse((String) festivalDetailActivity_New.B0.get(2)));
                festivalDetailActivity_New.imgFrame.setScaleType(ImageView.ScaleType.CENTER_CROP);
            }
        }
        ViewGroup.LayoutParams layoutParams = n.cardEditor.getLayoutParams();
        FestivalDetailActivity_New festivalDetailActivity_New2 = this.n;
        layoutParams.height = festivalDetailActivity_New2.m0;
        festivalDetailActivity_New2.cardEditor.requestLayout();
        festivalDetailActivity_New = this.n;
        Glide.with(festivalDetailActivity_New).load(n.k0).placeholder(n.getResources().getDrawable(R.drawable.ic_placehoder)).centerCrop().into(n.imgFestival);
        /* n.imgFestival.setOnTouchListener(new b(this, new GestureDetector(new a())));*/
        return false;
    }


}
