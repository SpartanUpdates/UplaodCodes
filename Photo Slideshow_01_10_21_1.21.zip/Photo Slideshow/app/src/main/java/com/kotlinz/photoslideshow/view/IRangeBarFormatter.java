package com.kotlinz.photoslideshow.view;

public interface IRangeBarFormatter {
    String format(String str);
}
