package com.UnitedVideos.SongSelection.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.models.general.AdErrors;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.R;
import org.jetbrains.annotations.NotNull;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DefaultSongActivityUv extends AppCompatActivity {
    Activity activity = DefaultSongActivityUv.this;

    final int[] SongList = new int[]
            {R.raw.birthday_music,
                    R.raw.color_party_music,
                    R.raw.dubstep_music,
                    R.raw.energy_beat_music,
                    R.raw.funday_music,
            };
    public MediaPlayer Mplayer;
    public DefaultSongtAdapter defaultSongtAdapter;
    LinearLayout layoutSongSdCard;
    ListView lvDefaultSong;
    ImageView ivBack;
    TextView tvDone;
    String SongPath;
    ArrayList<String> songNameList;
    private MyApplication application;


    GGAdview gg_banner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_default_song);
        PutAnalyticsEvent();
        bindView();
        init();
        BannerAds();
        SetDefaultSongAdapter();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "DefaultSongActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        gg_banner= findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback(){
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void init() {
        application = MyApplication.getInstance();
        songNameList = new ArrayList<>();
        songNameList.add("Birthday Music");
        songNameList.add("Color Party Music");
        songNameList.add("Dubstep Music");
        songNameList.add("Energy Beat Music");
        songNameList.add("Funday Music");
    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        tvDone = findViewById(R.id.tv_done);
        lvDefaultSong = findViewById(R.id.lv_default_song);
        layoutSongSdCard = findViewById(R.id.ll_from_storage);
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying(Mplayer);
                new SelectSong().start();
            }
        });
        layoutSongSdCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, PhoneSongActivityUv.class), 101);
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void SetDefaultSongAdapter() {
        defaultSongtAdapter = new DefaultSongtAdapter(activity, songNameList);
        lvDefaultSong.setAdapter(this.defaultSongtAdapter);
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(Mplayer);
    }

    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setMusic(int pos) {
        this.SongPath = "android.resource://" + getPackageName() + "/" + this.SongList[pos];
        this.application.posForAddMusicDialog = pos;
        stopPlaying(this.Mplayer);
        this.Mplayer = MediaPlayer.create(DefaultSongActivityUv.this, this.SongList[pos]);
        this.Mplayer.start();
    }


    public void SetMusic() {
        try {
            String path = Utils.INSTANCE.getMusicFolderPath();
            File dir = new File(path);
            if (dir.mkdirs() || dir.isDirectory()) {
                String str_song_name = songNameList.get(this.application.posForAddMusicDialog) + ".mp3";
                CopyRAWtoSDCard(SongList[this.application.posForAddMusicDialog], path + File.separator + str_song_name);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void CopyRAWtoSDCard(int id, String path) throws IOException {
        InputStream in = getResources().openRawResource(id);
        FileOutputStream out = new FileOutputStream(path);
        UnityPlayer.UnitySendMessage("UVThemeData", "LoadMusic", path);
        byte[] buff = new byte[1024];
        int read = 0;
        try {
            while ((read = in.read(buff)) > 0) {
                out.write(buff, 0, read);
            }
        } finally {
            in.close();
            out.close();
        }
    }


    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            intent.getExtras().getString("audio_path");
            UnityPlayer.UnitySendMessage("UVThemeData", "LoadMusic", intent.getExtras().getString("audio_path"));
            this.setResult(-1);
            this.finish();
        }
    }

    public class SelectSong extends Thread {
        public void run() {
            runOnUiThread(new Runnable() {
                public void run() {
                    SetMusic();
                    finish();
                }
            });
        }
    }

    public class DefaultSongtAdapter extends BaseAdapter {
        Context context;
        ArrayList<String> songName;
        public int SelectedPosition = -1;

        public DefaultSongtAdapter(Context cnx, ArrayList<String> name) {
            this.context = cnx;
            this.songName = name;
        }

        public int getCount() {
            return this.songName.size();
        }

        public Object getItem(int arg0) {
            return this.songName.get(arg0);
        }

        public long getItemId(int arg0) {
            return (long) arg0;
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(this.context).inflate(R.layout.row_default_song, parent, false);
            }
            LinearLayout layoutSongSelect = convertView.findViewById(R.id.layout_songselect);
            TextView tvUseMusic = convertView.findViewById(R.id.tvUseMusic);
            final CheckBox cbSelectSong = convertView.findViewById(R.id.ivImageSong);
            if (SelectedPosition != position) {
                tvUseMusic.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
            } else {
                tvUseMusic.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
            }
            cbSelectSong.setText(songName.get(position));
            layoutSongSelect.setOnClickListener(new View.OnClickListener() {
                public void onClick(final View arg0) {
                    SelectedPosition = position;
                    setMusic(SelectedPosition);
                    notifyDataSetChanged();
                }
            });
            return convertView;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        UnityPlayer.UnitySendMessage("UVThemeData", "BackFromGallery", "");
        finish();
    }
}