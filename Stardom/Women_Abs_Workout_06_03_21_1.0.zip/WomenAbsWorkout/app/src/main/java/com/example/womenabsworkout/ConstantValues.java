package com.example.womenabsworkout;

public class ConstantValues {
    public static final String PREFS_NAME = "ArmWorkout";
}
