package com.wavymusic.ContentLanguage.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.ContentLanguage.Adapter.LanguageSelectAdapter;
import com.wavymusic.ContentLanguage.Model.SongLanguageModel;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class LanguageSelectActivity extends AppCompatActivity {

    Activity activity = LanguageSelectActivity.this;
    TextView tvDone;
    RecyclerView rvlanguage;
    LinearLayout layoutRetry;
    GridLayoutManager gridLayoutManager;
    LanguageSelectAdapter languageAdapter;
    SharedPreferences pref;
    APIInterface apiInterface;
    private ArrayList<SongLanguageModel> languageDataList = new ArrayList<>();

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_select);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        PutAnalyticsEvent();
        BindView();
        PutLanguageList();
        BannerAds();
        SetAdapter();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LanguageSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void PutLanguageList() {
        languageDataList.add(0, new SongLanguageModel("35", "Rajashthahni"));
        languageDataList.add(1, new SongLanguageModel("27", "Malayalam"));
        languageDataList.add(2, new SongLanguageModel("34", "Marathi"));
        languageDataList.add(3, new SongLanguageModel("33", "Tamil"));
        languageDataList.add(4, new SongLanguageModel("29", "kannada"));
        languageDataList.add(5, new SongLanguageModel("32", "Telugu"));
        languageDataList.add(6, new SongLanguageModel("30", "Bengali"));
        languageDataList.add(7, new SongLanguageModel("31", "Bhojpuri"));
        languageDataList.add(8, new SongLanguageModel("28", "Islamic"));
        languageDataList.add(9, new SongLanguageModel("24", "English"));
        languageDataList.add(10, new SongLanguageModel("22", "Hindi"));
            languageDataList.add(11, new SongLanguageModel("25", "Gujarati"));
        languageDataList.add(12, new SongLanguageModel("36", "Punjabi"));
        SaveLanInPref(LanguageSelectActivity.this, languageDataList);
    }

    private void BindView() {
        tvDone = findViewById(R.id.tv_lan_select_done);
        rvlanguage = findViewById(R.id.rvLanguageList);
        layoutRetry = findViewById(R.id.llRetry);
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (languageDataList != null) {
                        final StringBuilder sb = new StringBuilder();
                        for (final SongLanguageModel SongLanguageModel : languageDataList) {
                            if (SongLanguageModel.IsLanguageSelected) {
                                sb.append(SongLanguageModel.LanId);
                                sb.append(",");
                            }
                        }
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(sb.length());
                        if (sb.length() != 0) {
                            if (!LanguagePref.a(activity).a("pref_key_language_list", "22").equals(sb.substring(0, sb.length() - 1))) {
                                Utils.AssetFilePath();
                            }
                            LanguagePref.a(activity).c("pref_key_language_list", sb.substring(0, sb.length() - 1));
                            LanguagePref.a(activity).b("pref_key_is_language_set", true);
                            Intent intent = new Intent(activity, DashbordActivity.class);
                            intent.putExtra("IsFromLanguage", true);
                            intent.putExtra("IsFromMain", true);
                            startActivity(intent);
                            finish();
                            return;
                        }
                        Toast.makeText(activity, "Please Select any language", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void SaveLanInPref(LanguageSelectActivity selectCountryAndLanguage, final ArrayList<SongLanguageModel> list) {
        final String[] split = LanguagePref.a(selectCountryAndLanguage).a("pref_key_language_list", "22").split(",");
        languageDataList = new ArrayList<>();
        for (final SongLanguageModel SongLanguageModel : list) {
            SongLanguageModel.IsLanguageSelected = Arrays.asList(split).contains(String.valueOf(SongLanguageModel.LanId));
            languageDataList.add(SongLanguageModel);
        }
        Collections.sort(languageDataList, new Comparator<SongLanguageModel>() {

            @Override
            public int compare(SongLanguageModel obj, SongLanguageModel obj2) {
                return Boolean.compare(obj2.IsLanguageSelected, obj.IsLanguageSelected);
            }
        });
    }

    private void SetAdapter() {
        gridLayoutManager = new GridLayoutManager(activity, 3);
        languageAdapter = new LanguageSelectAdapter(activity, languageDataList);
        rvlanguage.setLayoutManager(gridLayoutManager);
        rvlanguage.setAdapter(languageAdapter);
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}