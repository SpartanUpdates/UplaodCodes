package com.esc.beautymackupselficlam.library;

import android.graphics.PointF;

public class Vector2D
  extends PointF
{
  public Vector2D() {}
  
  public Vector2D(float paramFloat1, float paramFloat2)
  {
    super(paramFloat1, paramFloat2);
  }
  
  public static float getAngle(Vector2D paramVector2D1, Vector2D paramVector2D2)
  {
    paramVector2D1.normalize();
    paramVector2D2.normalize();
    return (float)(57.29577951308232D * (Math.atan2(paramVector2D2.y, paramVector2D2.x) - Math.atan2(paramVector2D1.y, paramVector2D1.x)));
  }
  
  public void normalize()
  {
    float f = (float)Math.sqrt(this.x * this.x + this.y * this.y);
    this.x /= f;
    this.y /= f;
  }
}
