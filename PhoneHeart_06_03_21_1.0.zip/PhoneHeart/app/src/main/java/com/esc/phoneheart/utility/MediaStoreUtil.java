package com.esc.phoneheart.utility;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.MediaStore.Audio.Media;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.Thumbnails;

import java.io.File;

import androidx.annotation.NonNull;

public class MediaStoreUtil {

    public static final class ImageNotFoundException extends Exception {
        public static final long serialVersionUID = 1;

        public ImageNotFoundException() {
        }

        public ImageNotFoundException(Throwable th) {
            super(th);
        }
    }

    public MediaStoreUtil() {
        throw new UnsupportedOperationException();
    }

    public static int getImageId(Context context, String str) throws ImageNotFoundException {
        String str2 = "_id";
        try {
            Cursor query = context.getContentResolver().query(Images.Media.EXTERNAL_CONTENT_URI, new String[]{str2}, "_data = ?", new String[]{str}, "date_added desc");
            if (query != null) {
                query.moveToFirst();
                if (query.isAfterLast()) {
                    query.close();
                    throw new ImageNotFoundException();
                }
                int i = query.getInt(query.getColumnIndex(str2));
                query.close();
                return i;
            }
            throw new ImageNotFoundException();
        } catch (Exception e) {
            throw new ImageNotFoundException(e);
        }
    }

    public static Uri getUriFromFile(Context context, String str) {
        ContentResolver contentResolver = context.getContentResolver();
        String str2 = "external";
        String str3 = "_id";
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(Files.getContentUri(str2), new String[]{str3}, "_data = ?", new String[]{str}, "date_added desc");
        if (query == null) {
            return null;
        }
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(Files.getContentUri(str2), contentValues);
        }
        Uri build = Files.getContentUri(str2).buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex(str3)))).build();
        query.close();
        return build;
    }
}
