package com.kotlinz.festivalstorymaker.Model.CollageMaker.Background;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class BackgroundResponse {

	@SerializedName("data")
	private ArrayList<BackgroundMainResponse> data;

	@SerializedName("status")
	private String status;

	public ArrayList<BackgroundMainResponse> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}