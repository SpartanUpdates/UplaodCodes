package com.kotlinz.festivalstorymaker.Adapter;

import android.app.Activity;
import android.content.res.Resources;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.Listener.CardMainListener;
import com.kotlinz.festivalstorymaker.Listener.DefaultListener;
import com.kotlinz.festivalstorymaker.Listener.DeleteListener;
import com.kotlinz.festivalstorymaker.Listener.MakeDefaultListener;
import com.kotlinz.festivalstorymaker.R;

import java.util.List;

  public class SelectLogoAdapter extends RecyclerView.Adapter<SelectLogoAdapter.ViewHolder> {

    public LogoInterface logoInterface;
    public List<String> logoList;
    public Activity activity;

    public SelectLogoAdapter(final Activity activity, final List<String> logoList, final LogoInterface g) {
        this.activity = activity;
        this.logoInterface = g;
        this.logoList = logoList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.logo_list_adapter_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.ivThumb.setImageURI(Uri.parse((String) logoList.get(position)));
        holder.ivThumb.setTag((Object) logoList.get(position));
        Resources resources;
        int n2;
        if (logoList.get(position).contains("Festival Story Maker/0_")) {
            resources = activity.getResources();
            n2 = R.color.black;
        } else {
            resources = activity.getResources();
            n2 = R.color.white;
        }
        holder.cvCard.setCardBackgroundColor(resources.getColor(n2));
        int visibility;
        if (position == 0) {
            visibility = View.VISIBLE;
        } else {
            visibility =  View.GONE;
        }
        holder.tvDefault.setVisibility(visibility);
        int visibility2;
        if (position == 0) {
            visibility2 = View.GONE;
        } else {
            visibility2 = View.VISIBLE;
        }
        holder.tvMakeDefault.setVisibility(visibility2);
        holder.tvDefault.setOnClickListener((View.OnClickListener) new DefaultListener(this));
        holder.icDelete.setOnClickListener((View.OnClickListener) new DeleteListener(this, position));
        holder.cvCard.setOnClickListener((View.OnClickListener) new CardMainListener(this, holder));
        holder.tvMakeDefault.setOnClickListener((View.OnClickListener) new MakeDefaultListener(this, position));
    }

    @Override
    public int getItemCount() {
        return this.logoList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView icDelete;
        public ImageView ivThumb;
        public CardView cvCard;
        public TextView tvMakeDefault;
        public TextView tvDefault;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivThumb = itemView.findViewById(R.id.img);
            icDelete = itemView.findViewById(R.id.imgDelete);
            cvCard = itemView.findViewById(R.id.card);
            tvMakeDefault = itemView.findViewById(R.id.txtMakeDefault);
            tvDefault = itemView.findViewById(R.id.txtDefaultLogo);
        }
    }


    public interface LogoInterface {
        void K(final String p0, final boolean p1);

        void u(final int p0, final int p1);
    }
}
