package com.kotlinz.photoslideshow.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;

import androidx.cardview.widget.CardView;

import com.kotlinz.photoslideshow.*;
import com.kotlinz.photoslideshow.R;

public class ScaleCardLayout extends CardView {
    public int mAspectRatioHeight;
    public int mAspectRatioWidth;

    public ScaleCardLayout(final Context context) {
        super(context);
        this.mAspectRatioWidth = 640;
        this.mAspectRatioHeight = 360;
    }

    public ScaleCardLayout(final Context context, final AttributeSet set) {
        super(context, set);
        this.mAspectRatioWidth = 640;
        this.mAspectRatioHeight = 360;
        this.Init(context, set);
    }

    public ScaleCardLayout(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.mAspectRatioWidth = 640;
        this.mAspectRatioHeight = 360;
        this.Init(context, set);
    }

    private void Init(final Context context, final AttributeSet set) {
        final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, R.styleable.PreviewImageView);
        this.mAspectRatioWidth = obtainStyledAttributes.getInt(R.styleable.PreviewImageView_aspectRatioWidth, MyApplication.VIDEO_WIDTH);
        this.mAspectRatioHeight = obtainStyledAttributes.getInt(R.styleable.PreviewImageView_aspectRatioHeight, MyApplication.VIDEO_HEIGHT);
        obtainStyledAttributes.recycle();
    }

    protected void onMeasure(int size, int size2) {
        if (this.mAspectRatioHeight == this.mAspectRatioWidth) {
            super.onMeasure(size, size);
        }
        size = View.MeasureSpec.getSize(size);
        size2 = View.MeasureSpec.getSize(size2);
        final int n = this.mAspectRatioHeight * size / this.mAspectRatioWidth;
        if (n > size2) {
            size = this.mAspectRatioWidth * size2 / this.mAspectRatioHeight;
        } else {
            size2 = n;
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(size2, View.MeasureSpec.EXACTLY));
    }
}
