package com.example.womenabsworkout.activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.womenabsworkout.ConstantValues;
import com.example.womenabsworkout.R;

public class SplashActivity extends AppCompatActivity {
    public Boolean logg;
    boolean status = false;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);

        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));

        this.logg = Boolean.valueOf(getSharedPreferences(ConstantValues.PREFS_NAME, 0).getBoolean("logged", false));
        if (!isWorkingInternetPersent()) {
            showAlertDialog(this, "No Internet Connection!", "Please Connect to internet and\n try Again..", Boolean.valueOf(false));
        } else if (this.logg.booleanValue()) {
            splash();
        } else {
            startActivity(new Intent(this, UserDetailsActivity.class));
            finish();
        }
    }

    public void splash() {
        new Thread() {
            public void run() {
                Intent intent =new Intent();
                try {
                    sleep(4000);
                    intent = new Intent(SplashActivity.this.getApplicationContext(), After_Main_Activity.class);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    intent = new Intent(SplashActivity.this.getApplicationContext(), After_Main_Activity.class);
                } catch (Throwable th) {
                    Intent intent2 = new Intent(SplashActivity.this.getApplicationContext(), After_Main_Activity.class);
                    intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    SplashActivity.this.startActivity(intent2);
                    SplashActivity.this.finish();
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                SplashActivity.this.startActivity(intent);
                SplashActivity.this.finish();
            }
        }.start();
    }

    public boolean isWorkingInternetPersent() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getBaseContext().getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            @SuppressLint("MissingPermission") NetworkInfo[] allNetworkInfo = connectivityManager.getAllNetworkInfo();
            if (allNetworkInfo != null) {
                for (NetworkInfo state : allNetworkInfo) {
                    if (state.getState() == State.CONNECTED) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void showAlertDialog(Context context, String str, String str2, Boolean bool) {
        AlertDialog create = new Builder(context).create();
        create.setTitle(str);
        create.setMessage(str2);
        boolean booleanValue = bool.booleanValue();
        create.setIcon(R.mipmap.logo);
        create.setButton("OK", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                SplashActivity.this.finish();
                System.exit(0);
            }
        });
        create.show();
    }
}
