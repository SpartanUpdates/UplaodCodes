package com.MV.Lyrics.SelectImage.Interface;

import android.view.View;


public abstract interface OnItemClickListner<T> {
    public abstract void onItemClick(View view, int position);
}