package com.example.knowledgetrivia.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.knowledgetrivia.models.LevelScore;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABSE_NAME = "generalKnowlege";
    private static final String SCORE_COL_SCORE = "Score";
    private static final String SCORE_COL_lEVEL = "level";
    private static final String SCORE_TABLE_NAME = "levelScore";
    private SQLiteDatabase sqLiteDatabase = getReadableDatabase();

    public DatabaseHelper(Context context) {
        super(context, DATABSE_NAME, null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS levelScore ( level INTEGER PRIMARY KEY,Score INTEGER )");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS levelScore");
        onCreate(sQLiteDatabase);
    }

    public void insertDataInScoreTable(LevelScore levelScore) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(SCORE_COL_lEVEL, Integer.valueOf(levelScore.getLevel()));
        contentValues.put(SCORE_COL_SCORE, Integer.valueOf(levelScore.getScore()));
        if (this.sqLiteDatabase.insert(SCORE_TABLE_NAME, null, contentValues) == -1) {
            updateInScoreTable(levelScore);
        }
    }

    private void updateInScoreTable(LevelScore levelScore) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(SCORE_COL_SCORE, Integer.valueOf(levelScore.getScore()));
        SQLiteDatabase sQLiteDatabase = this.sqLiteDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("level=");
        stringBuilder.append(levelScore.getLevel());
        sQLiteDatabase.update(SCORE_TABLE_NAME, contentValues, stringBuilder.toString(), null);
    }

    public ArrayList<LevelScore> getDataOfScoreTable() {
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = this.sqLiteDatabase.rawQuery("select * from levelScore", null);
        if (rawQuery.moveToFirst()) {
            do {
                arrayList.add(new LevelScore(rawQuery.getInt(0), rawQuery.getInt(1)));
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }
}
