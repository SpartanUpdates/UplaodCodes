class FuelModel {
  static List<StateList> fuelDataList = [];
  static List<StateList> tempList = [];
}

class StateList {
  late String name;
  late List<dynamic> rto_list;

  StateList({required this.name, required this.rto_list});

  factory StateList.fromJson(Map<String, dynamic> map) {
    return StateList(name: map["name"], rto_list: map["rtoList"]);
  }

  toMap() => {"name": name, "rtoList": rto_list};
}
