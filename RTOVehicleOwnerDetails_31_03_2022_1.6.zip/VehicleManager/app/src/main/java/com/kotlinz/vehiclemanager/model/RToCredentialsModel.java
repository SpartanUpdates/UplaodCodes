package com.kotlinz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

public class RToCredentialsModel {

	@SerializedName("api_key")
	private String apiKey;

	@SerializedName("extra_data")
	private String extraData;

	@SerializedName("refer_key")
	private String referKey;

	public String getApiKey(){
		return apiKey;
	}

	public String getExtraData(){
		return extraData;
	}

	public String getReferKey(){
		return referKey;
	}
}