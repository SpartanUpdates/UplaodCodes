package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Adapter.ExpandableListViewAdapter;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model.RtoCityList;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model.RtoOfficeDetail;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model.RtoOfficeRoot;
import com.xyz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RtoOfficeInfoActivity extends AppCompatActivity
{
    private Activity activity = RtoOfficeInfoActivity.this;
    private ArrayList<String> stateList = new ArrayList<>();
    private List<List<String>> cityList = new ArrayList<>();
    private ExpandableListView expandableListView;
    private HashMap<String, List<String>> bindingList = new HashMap();
    private ImageView iv_back;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo);

        rtoDetailsInterface = RtoDetailsApiClient.getOwnerDetails().create(RtoDetailsInterface.class);
        expandableListView = findViewById(R.id.expandListView);
        iv_back = findViewById(R.id.iv_back);
        Setlistener();
        DialogAnimation();
        PutAnalyticsEvent();
        BannerAds();
        if(Utils.isOnline(activity))
        {
            getRtoOfficeData();
        }else
        {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_dialog_search);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void Setlistener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        expandableListView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                expandableListView.setIndicatorBounds(expandableListView.getMeasuredWidth() - 100, expandableListView.getMeasuredWidth());
            }
        });

        final int[] prevExpandPosition = {-1};

        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                if (prevExpandPosition[0] >= 0 && prevExpandPosition[0] != groupPosition) {
                    expandableListView.collapseGroup(prevExpandPosition[0]);
                }
                prevExpandPosition[0] = groupPosition;
            }
        });
    }

    private void getRtoOfficeData()
    {
        Call<RtoOfficeRoot> call = rtoDetailsInterface.getRtoOffice();
        call.enqueue(new Callback<RtoOfficeRoot>() {
            @Override
            public void onResponse(Call<RtoOfficeRoot> call, Response<RtoOfficeRoot> response) {
                if (response.isSuccessful())
                {
                    if (dialog !=null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }

                    ArrayList<RtoCityList> rtoOfficeInfoDetaillist = response.body().getCityList();

                    for (int i = 0; i < rtoOfficeInfoDetaillist.size(); i++) {
                        String stateNamelist = rtoOfficeInfoDetaillist.get(i).getStateName();
                        stateList.add(stateNamelist);
                        List<String> CityNamelist = new ArrayList<>();
                        ArrayList<RtoOfficeDetail> rtolist = rtoOfficeInfoDetaillist.get(i).getCityName();
                        for (int k = 0; k < rtolist.size(); k++) {
                            String stateName = rtolist.get(k).getStateName();
                            if (stateName.equals(stateNamelist))
                            {
                                String cityName = rtolist.get(k).getDistrict();
                                String rtoCode = rtolist.get(k).getRtoCode();
                                String state = rtolist.get(k).getStateName();
                                String address = rtolist.get(k).getAddress();
                                String contact = rtolist.get(k).getPhone();
                                String website = rtolist.get(k).getWebsite();
                                CityNamelist.add(rtoCode + ">" + cityName+">"+state+">"+address+">"+contact+">"+website);
                            }
                        }
                        cityList.add(CityNamelist);
                        bindingList.put(stateList.get(i), cityList.get(i));
                    }
                    System.out.println("cities "+cityList.get(0));
                    ExpandableListAdapter expandableListAdapter = new ExpandableListViewAdapter(activity, stateList,bindingList);
                    expandableListView.setAdapter(expandableListAdapter);
                }
            }

            @Override
            public void onFailure(Call<RtoOfficeRoot> call, Throwable t) {
                if (dialog !=null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}