package com.wavymusic.DashBord.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.UnitedVideos.AppConstant.UvConstant;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.Download.ThemeDownloadUv;
import com.wavymusic.DashBord.Download.ThemeDownloadWavy;
import com.wavymusic.DashBord.Model.ThemeHomeModelUv;
import com.wavymusic.DashBord.View.AVLoadingView.AVLoadingIndicatorView;
import com.wavymusic.DashBord.activity.ThemeAllActivityUv;
import com.wavymusic.Favourite.Database.DatabaseHelper;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;

import java.io.File;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeViewAllAdapterUv extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    public int e = -1;
    public int f = -1;
    private Context mContext;
    private ArrayList<ThemeHomeModelUv> themeCategoryList;
    private ThemeAllActivityUv ActivityOfTheme;
    DatabaseHelper databaseHelper;

    public ThemeViewAllAdapterUv(Context mContext, ArrayList<ThemeHomeModelUv> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (ThemeAllActivityUv) mContext;
        this.themeCategoryList = themeCategoryList;
        databaseHelper = new DatabaseHelper(mContext);
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item_viewall_uv, viewGroup, false);
        return new ThemeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof ThemeViewHolder) {
            final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
            final ThemeHomeModelUv themelModel = themeCategoryList.get(position);
            Glide.with(mContext).load(themelModel.getImage()).diskCacheStrategy(DiskCacheStrategy.ALL).into(viewHolder.iv_thumb);
            if (!themelModel.isAvailableOffline) {
                if (themelModel.isDownloading) {
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    viewHolder.ivUseTheme.setVisibility(View.GONE);
                    viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.VISIBLE);
                    viewHolder.ivUseTheme.setVisibility(View.GONE);
                }
            } else {
                viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                viewHolder.ivDownload.setVisibility(View.GONE);
                viewHolder.ivUseTheme.setVisibility(View.VISIBLE);
            }
            if (databaseHelper.RecordExistsUv(themelModel.getThemeName())) {
                viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_select);
            } else {
                viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_unselect);
            }

            /*if (themelModel.getIsNewRealise().equals("1")){
                int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
                String BundelName = themelModel.getBundelName();
                File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
                int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));
                if (BundelFileSize == UnityBundeldSize) {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                }
            }*/
            viewHolder.tvThemeName.setText(themelModel.getThemeName());
            viewHolder.tvThemeName.setSelected(true);
            viewHolder.iv_thumb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DownloadThemeFiles(position, viewHolder.ivDownload, viewHolder.ivUseTheme, viewHolder.ThemeDownProgress, viewHolder.indicatorThemeProgress, viewHolder.tvThemeDownProgress, themelModel);
                }
            });

            viewHolder.ivLikeTheme.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (databaseHelper.RecordExistsUv(themelModel.getThemeName())) {
                        databaseHelper.deleteThemeUv(themelModel.getThemeName());
                        viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_unselect);
                    } else {
                        if (Utils.checkConnectivity(mContext, true)) {
                            int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
                            String BundelName = themelModel.getBundelName();
                            File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
                            int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));
                            databaseHelper.insertdataUV(themelModel.getThemeName(), themelModel.getVideoType(), themelModel.getImage(), themelModel.getImageWidht(), themelModel.getImageHeight(), themelModel.getImg_no_of(), themelModel.getGameobjectName(), themelModel.getAnimSoundname(), themelModel.getPrefebName(), themelModel.getAnimSoundPath(), themelModel.getAnimSoundfilesize(), themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getBundelSize(), themelModel.getIsNewRealise());
                            Log.e("TAG", "Prefebname" + themelModel.getPrefebName());
                            if (new File(Utils.INSTANCE.getThemeFolderPath() + BundelName).exists()) {
                                if (BundelFileSize == UnityBundeldSize) {
                                    viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_select);
                                } else {
                                    new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), viewHolder.ivDownload, viewHolder.ivUseTheme, viewHolder.ThemeDownProgress, viewHolder.indicatorThemeProgress, viewHolder.tvThemeDownProgress, themelModel);
                                    viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_select);
                                    viewHolder.ivDownload.setVisibility(View.GONE);
                                    viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                                }
                            } else {
                                new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), viewHolder.ivDownload, viewHolder.ivUseTheme, viewHolder.ThemeDownProgress, viewHolder.indicatorThemeProgress, viewHolder.tvThemeDownProgress, themelModel);
                                viewHolder.ivLikeTheme.setImageResource(R.drawable.ic_favourite_select);
                                viewHolder.ivDownload.setVisibility(View.GONE);
                                viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                            }
                        } else {
                            Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return ITEM_TYPE_DATA;
    }


    private void DownloadThemeFiles(int position, ImageView ivDownload, ImageView ivuseTheme, LinearLayout themeDownProgress, AVLoadingIndicatorView avLoadingIndicatorView, TextView tvThemeDownprogress, ThemeHomeModelUv themelModel) {
        int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
        String BundelName = themelModel.getBundelName();
        File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
        int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));

        UvConstant.BundelPath = themelModel.getBundelPath();
        UvConstant.PrefebName = themelModel.getPrefebName();
        UvConstant.AudioPath = themelModel.getAnimSoundPath();

        UvConstant.VideoType = themelModel.getVideoType();
        UvConstant.ImageWidth = themelModel.getImageWidht();
        UvConstant.ImageHeight = themelModel.getImageHeight();
        UvConstant.NoofImage = themelModel.getImg_no_of();
        if (new File(Utils.INSTANCE.getThemeFolderPath() + BundelName).exists()) {
            if (BundelFileSize == UnityBundeldSize) {
                if (!themelModel.isDownloading) {
                    MyApplication.AllFilePathUv = themelModel.getBundelPath() + MyApplication.SPLIT_PATTERN + themelModel.getPrefebName() + MyApplication.SPLIT_PATTERN + themelModel.getAnimSoundPath() + MyApplication.SPLIT_PATTERN + themelModel.getVideoType() + MyApplication.SPLIT_PATTERN + AppConstant.ThemeViewAll;
                    if (MyApplication.fbinterstitialAdUv != null && MyApplication.fbinterstitialAdUv.isAdLoaded()) {
                        MyApplication.AdsIdUv = 5;
                        MyApplication.AdsShowContext = ActivityOfTheme;
                        MyApplication.fbinterstitialAdUv.show();
                    } else {
                        ActivityOfTheme.ShowBannerAds();
                        UnityPlayer.UnitySendMessage("AndroidManager", "GoUVPreview", MyApplication.AllFilePathUv);
                        ActivityOfTheme.finish();
                    }
                } else {
                    Toast.makeText(mContext, "Please Wait Theme Download Process Running", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    avLoadingIndicatorView.smoothToShow();
                    DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                    new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, ivuseTheme, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                avLoadingIndicatorView.smoothToShow();
                DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, ivuseTheme, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void DownloadIncrement(String CatId, String ThemeId) {
        APIInterface apiInterface = APIClient.getClientUv().create(APIInterface.class);
        Call<JsonObject> call = apiInterface.DownloadIncrementUv(AppConstant.Token, AppConstant.ApplicationId, CatId, ThemeId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {

            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }


    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload;
        TextView tvThemeName, tvThemeCounter, tvThemeDownProgress;
        ImageView ivUseTheme;
        AVLoadingIndicatorView indicatorThemeProgress;
        LinearLayout ThemeDownProgress;
        LinearLayout layoutDownloadMask;
        LinearLayout layoutBottomPanel;
        ImageView ivLikeTheme;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeCounter = itemView.findViewById(R.id.tvLike_counter);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
            ivUseTheme = itemView.findViewById(R.id.ivUseTheme);
            layoutDownloadMask = itemView.findViewById(R.id.downloadMask);
            layoutBottomPanel = itemView.findViewById(R.id.ll_bootom_panel);
            ivLikeTheme = itemView.findViewById(R.id.iv_like_theme);
        }
    }

}
