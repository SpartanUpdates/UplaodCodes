package com.esc.flashlight.App;

import android.app.Application;
import com.esc.flashlight.util.PrefManager;

public class APP extends Application {

    public static String AAID = "";
    public static volatile APP APP;
    private volatile PrefManager sPref;

    public void onCreate() {
        super.onCreate();
        APP = this;
    }

    public static PrefManager getPrefManager() {
        if (APP.sPref == null) {
            APP.sPref = new PrefManager(APP);
        }
        return APP.sPref;
    }
}
