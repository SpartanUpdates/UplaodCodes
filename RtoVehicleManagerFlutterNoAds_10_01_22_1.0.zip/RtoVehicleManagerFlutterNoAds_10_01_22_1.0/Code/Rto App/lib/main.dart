import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';

//import 'package:native_admob_flutter/native_admob_flutter.dart';
import 'package:rto_app/Famous%20Person%20Screen/view/famous_person_screen.dart';
import 'package:rto_app/History%20Screen/view/history_screen.dart';
import 'package:rto_app/Home%20Screen/controller/ThemeController.dart';
import 'package:rto_app/Loan%20Calculator%20Screen/view/loan_calculator.dart';
import 'package:rto_app/Owner%20Info%20Screen/controllers/controllers.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/view/rto_preparation..dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/VehicleExpense/view/vehicle_expense.dart';
import 'package:rto_app/VehicleMileage/view/vehicle_mileage.dart';
import 'package:rto_app/test_screen.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:lottie/lottie.dart';
import 'Home Screen/my_drawer.dart';
import 'Home Screen/themes.dart';
import 'Owner Info Screen/view/owner_info.dart';
import 'Rto Office Screen/view/rto_office.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  /*await MobileAds.initialize();
  MobileAds.setTestDeviceIds(['6149ef500f566fc5']);*/
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  ThemeController themeController = Get.put(ThemeController());
  late AnimationController controller;
  bool isDrawerOpen = false;
  late bool darkModeOn = false;

  @override
  void initState() {
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    themeController.tempThemeMode(context);
    themeController.getThemeMode(context);
    themeController.changeTheme(context, ThemeMode.system);
    super.initState();
    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 400));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(milliseconds: 3000), () {
      themeController.updateScreen();
    });
    return GetBuilder<ThemeController>(builder: (themeController) {
      String mode = themeController.mode;
      var splash = mode == "dark"
          ? SplashScreen()
          : mode == "light"
              ? DarkSplashScreen()
              : Container();
      return GetMaterialApp(
          themeMode: themeController.themeMode,
          debugShowCheckedModeBanner: false,
          theme: MyThemes.lightTheme(context),
          darkTheme: MyThemes.darkTheme(context),
          title: 'Rto Vehicle Manager',
          routingCallback: (value) {
            if (mode == "dark") {
              ScreenStart.mode = Colors.white;
            } else {
              ScreenStart.mode = MyThemes.fulldark;
            }
            SystemChrome.setSystemUIOverlayStyle(
                SystemUiOverlayStyle(statusBarColor: Colors.transparent));
            /*Future.delayed(const Duration(milliseconds: 350), () {
              print("StatusBar color  ${themeController.statusBarColor}");
              SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
                  statusBarColor: themeController.statusBarColor));
            });*/
          },
          home: themeController.endSplash
              ? ScreenStart(controller, themeController, isDrawerOpen,
                  _scaffoldKey, darkModeOn)
              : splash);
    });
  }
}

class DarkSplashScreen extends StatelessWidget {
  const DarkSplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Image.asset("assets/images/dark_splash.png", fit: BoxFit.cover);
  }
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Image.asset("assets/images/splash.png", fit: BoxFit.cover);
  }
}

class ScreenStart extends StatelessWidget {
  static var mode;
  AnimationController controller;
  bool isDrawerOpen;
  var _scaffoldKey;
  bool darkModeOn = false;
  ThemeController themeController;

  ScreenStart(this.controller, this.themeController, this.isDrawerOpen,
      this._scaffoldKey, this.darkModeOn);

  @override
  Widget build(BuildContext context) {
    Color tempColor;
    if (themeController.mode == "dark") ;
    {
      tempColor = Colors.white;
    }
    if (themeController.mode == "light") {
      tempColor = MyThemes.fulldark;
    }

    mode = tempColor;
    DateTime pre_backpress = DateTime.now();

    return WillPopScope(
      onWillPop: () async {
        final timegap = DateTime.now().difference(pre_backpress);
        final cantExit = timegap >= Duration(seconds: 2);
        pre_backpress = DateTime.now();
        if (cantExit) {
          //show snackbar
          /*final snack = SnackBar(
            content: Text('Press Back button again to Exit'),
            duration: Duration(seconds: 2),
          );
          ScaffoldMessenger.of(context).showSnackBar(snack);*/
          Fluttertoast.showToast(
              msg: "Press again to exit",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
          resizeToAvoidBottomInset: true,
          backgroundColor: context.primaryColor,
          key: _scaffoldKey,
          drawer: MyDrawer(),
          onDrawerChanged: (isOpen) {
            if (isOpen) {
              controller.forward();
            } else {
              controller.reverse();
            }
          },
          body: NestedScrollView(
            physics: BouncingScrollPhysics(),
            floatHeaderSlivers: true,
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SilverAppBar(controller, isDrawerOpen, _scaffoldKey)
              ];
            },
            body: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: AllWidget(darkModeOn, tempColor)),
                )
              ],
            ),
          )),
    );
  }
}

class SilverAppBar extends StatelessWidget {
  AnimationController controller;
  bool isDrawerOpen;
  var _scaffoldKey;

  SilverAppBar(this.controller, this.isDrawerOpen, this._scaffoldKey);

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      backgroundColor: context.primaryColor,
      title: Text(
        "Rto Vehicle Manager",
        style: TextStyle(
            fontSize: 16.5,
            color: context.accentColor,
            fontFamily: "Circular Bold"),
      ).centered(),
      leading: IconButton(
        icon: AnimatedIcon(
          icon: AnimatedIcons.menu_close,
          color: context.accentColor,
          progress: controller,
        ),
        onPressed: () {
          controller.forward();
          _scaffoldKey.currentState.openDrawer();
          isDrawerOpen = !isDrawerOpen;
          if (!isDrawerOpen) {}
        },
      ).pOnly(left: 10),
      actions: [
        IconButton(
            onPressed: () {
              Get.to(HistoryScreen());
            },
            icon: Icon(
              Icons.history,
              color: context.accentColor,
            )).pOnly(right: 10),
      ],
    );
  }
}

class AllWidget extends StatefulWidget {
  bool darkModeOn;
  Color tempColor;
  AllWidget(this.darkModeOn, this.tempColor);

  @override
  State<AllWidget> createState() => _AllWidgetState();
}

class _AllWidgetState extends State<AllWidget> {
  MainControllers mainControllers = Get.put(MainControllers());

  @override
  Widget build(BuildContext context) {
    int? _currIndex;
    return Container(
      color: context.primaryColor,
      child: Container(
          decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(25.0),
                  topRight: Radius.circular(25.0))),
          child: Column(
            children: [
              MyFuel(),
              //getNativeAds(mainControllers),
              FamousPerson(context),
              VehicleOwnerInfo(),
              RtoDetails(),
              VehicleDetails(widget.darkModeOn),
              Other(),
            ],
          )),
    );
  }

  /*getNativeAds(MainControllers mainControllers) {
    return GetBuilder<MainControllers>(builder: (mainControllers) {
      return Container(
        height: 180,
        child: NativeAd(
            loading: Center(
              child: Text("Loading ads..."),
            ),
            error: getErrorMessage(mainControllers),
            icon: AdImageView(size: 50),
            headline: AdTextView(
                maxLines: 1,
                style: TextStyle(fontSize: 15, color: Colors.black)),
            advertiser: AdTextView(),
            ratingBar: AdRatingBarView(starsColor: Colors.blue),
            body: AdTextView(
              maxLines: 1,
              style: TextStyle(fontSize: 8, color: Colors.black),
            ),
            media: AdMediaView(height: 80, width: MATCH_PARENT),
            attribution: AdTextView(
              width: WRAP_CONTENT,
              text: "Ad",
              decoration: AdDecoration(
                  border: BorderSide(color: Colors.blue, width: 1),
                  borderRadius: AdBorderRadius.all(8)),
              style: TextStyle(color: Colors.black),
              padding: EdgeInsets.symmetric(horizontal: 4.0, vertical: 1.0),
            ),
            button: AdButtonView(
              decoration: AdDecoration(
                borderRadius: AdBorderRadius.all(6),
                backgroundColor: Colors.blue,
              ),
              elevation: 0,
              textStyle: TextStyle(color: Colors.white),
              height: 36,
            ),
            buildLayout: fullBuilder),
      );
    }).px(15).pOnly(top: 5);
  }

  AdLayoutBuilder get fullBuilder => (ratingBar, media, icon, headline,
          advertiser, body, price, store, attribuition, button) {
        return AdLinearLayout(
          decoration: AdDecoration(
            backgroundColor: Colors.white,
          ),
          padding: EdgeInsets.all(2),
          width: MATCH_PARENT,
          children: [
            AdLinearLayout(orientation: HORIZONTAL, children: [
              attribuition,
              media,
            ]),
            AdLinearLayout(
              children: [
                icon,
                AdLinearLayout(
                    orientation: VERTICAL,
                    children: [
                      headline,
                      body,
                      ratingBar,
                    ],
                    margin: EdgeInsets.only(left: 4)),
              ],
              //gravity: LayoutGravity.center_horizontal,
              width: MATCH_PARENT,
              orientation: HORIZONTAL,
            ),
            AdLinearLayout(
              children: [button],
              orientation: HORIZONTAL,
            ),
          ],
        );
      };*/

  getErrorMessage(MainControllers mainControllers) {
    mainControllers.changeHeight();
    return Container();
  }
}

class Other extends StatelessWidget {
  List<Map> otherList = [
    {
      'name': 'Loan Calculator',
      'iconPath': 'assets/images/loan_calculator.png',
    },
    {
      'name': 'Near Petrol Pump',
      'iconPath': 'assets/images/near_pertol.png',
    },
    {
      'name': 'Near CNG gas',
      'iconPath': 'assets/images/near_autogas.png',
    },
    {
      'name': 'Near EV Station',
      'iconPath': 'assets/images/near_ev_station.png',
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Other", style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(left: 17),
        ),
        Container(
          margin: EdgeInsets.all(1),
          child: SizedBox(
            height: 150,
            child: ListView.builder(
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              itemCount: otherList.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    SizedBox(
                      child: Card(
                        color: Theme.of(context).splashColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        child: InkWell(
                          customBorder: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          onTap: () {
                            if (otherList[index]['name'] == "Loan Calculator") {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Get.to(LoanCalculator());
                              });
                            }
                            if (otherList[index]['name'] ==
                                "Near Petrol Pump") {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                MapsLauncher.launchQuery('nearby Petrol Pump');
                              });
                            }
                            if (otherList[index]['name'] == "Near CNG gas") {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                MapsLauncher.launchQuery(
                                    'nearby CNG Gas Station');
                              });
                            }
                            if (otherList[index]['name'] == "Near EV Station") {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                MapsLauncher.launchQuery(
                                    'nearby EV Charging Station');
                              });
                            }
                          },
                          splashColor: Theme.of(context).hoverColor,
                          child: Stack(
                            children: [
                              Container(
                                padding: EdgeInsets.all(15),
                                height: 100,
                                width: 100,
                                child: Opacity(
                                    opacity: 0.7,
                                    child: Hero(
                                      transitionOnUserGestures: true,
                                      tag: "loan",
                                      child: Image.asset(
                                          otherList[index]['iconPath']),
                                    )),
                              ),
                            ],
                          ),
                        ),
                      ).px(5),
                    ),
                    Text(otherList[index]['name'],
                            style: TextStyle(fontFamily: "Circular Medium"))
                        .text
                        .color(Colors.blueGrey)
                        .size(12)
                        .make()
                        .py(7)
                        .px(7)
                  ],
                );
              },
            ),
          ).px(5).py(10),
        )
      ],
    );
  }
}

class VehicleDetails extends StatelessWidget {
  bool darkModeOn;

  VehicleDetails(this.darkModeOn);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Vehicle Details",
                  style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(
                top: 8,
                left: 20,
              ),
        ),
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 150,
                  width: double.infinity,
                  child: Card(
                    color: context.canvasColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      onTap: () {
                        Future.delayed(Duration(milliseconds: 350), () {
                          Get.to(VehicleExpense());
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: SizedBox(
                        height: 130,
                        width: double.infinity,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Text(
                                  "Track your\nvehicle expense\nby categories",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 8.5,
                                      color: Colors.blueGrey,
                                      fontFamily: "Circular Medium"),
                                ).px(10).py(25),
                                Opacity(
                                  opacity: 0.7,
                                  child: Image.asset(
                                      'assets/images/expense.png',
                                      height: 65,
                                      width: 65),
                                ),
                              ],
                            ),
                            Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Card(
                                        color: context.backgroundColor,
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Text(
                                          "Vehicle Expense",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 11,
                                              color:
                                                  Theme.of(context).cursorColor,
                                              fontFamily: "Circular Medium"),
                                        ).px(10).py(2)))
                                .pOnly(left: 10)
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 20, left: 10, right: 2.5),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 150,
                  width: double.infinity,
                  child: Card(
                    color: context.canvasColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Get.to(VehicleMileage());
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: SizedBox(
                        height: 130,
                        width: double.infinity,
                        child: Column(
                          children: [
                            Align(
                                    alignment: Alignment.topLeft,
                                    child: Card(
                                        color: context.backgroundColor,
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Text(
                                          "Vehicle Mileage",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 11,
                                              color:
                                                  Theme.of(context).cursorColor,
                                              fontFamily: "Circular Medium"),
                                        ).px(10).py(2)))
                                .pOnly(left: 10, top: 4),
                            Row(
                              children: [
                                Text(
                                  "Track your\nvehicle expense\nby categories",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 8.5,
                                      color: Colors.blueGrey,
                                      fontFamily: "Circular Medium"),
                                ).px(10).py(25),
                                Opacity(
                                  opacity: 0.7,
                                  child: Image.asset(
                                      'assets/images/mileage.png',
                                      height: 65,
                                      width: 65),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 20, left: 5, right: 10),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class RtoDetails extends StatelessWidget {
  const RtoDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Rto Details",
                  style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(
                left: 20,
              ),
        ),
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 135,
                  width: double.infinity,
                  child: Card(
                    color: context.cardColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Get.to(RtoOfficeInfo("RtoOffice"));
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: SizedBox(
                        height: 130,
                        width: double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Align(
                                alignment: Alignment.center,
                                child: Opacity(
                                  opacity: 1,
                                  child: Opacity(
                                    opacity: 0.8,
                                    child: Image.asset(
                                        'assets/images/rto_office.png',
                                        height: 80,
                                        width: 80),
                                  ),
                                )),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  width: double.infinity,
                                  child: Card(
                                    color: context.backgroundColor,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Text(
                                      "Rto Office",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 10,
                                          color: Theme.of(context).cursorColor,
                                          fontFamily: "Circular Medium"),
                                    ).px(10).py(2),
                                  ).px(3),
                                ).px(5))
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 5, left: 10),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 135,
                  width: double.infinity,
                  child: Card(
                    color: context.cardColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Get.to(RtoPreperation(true));
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: SizedBox(
                        height: 130,
                        width: double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Align(
                                alignment: Alignment.center,
                                child: Opacity(
                                  opacity: 1,
                                  child: Opacity(
                                    opacity: 0.7,
                                    child: Image.asset(
                                        'assets/images/rto_preparation.png',
                                        height: 70,
                                        width: 70),
                                  ),
                                )).pOnly(top: 5),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  width: double.infinity,
                                  child: Card(
                                    color: context.backgroundColor,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Text(
                                      "Rto Prep.",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 10,
                                          color: Theme.of(context).cursorColor,
                                          fontFamily: "Circular Medium"),
                                    ).px(10).py(2),
                                  ).px(3),
                                ).px(5).py(5))
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 5, left: 5, right: 5),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 135,
                  width: double.infinity,
                  child: Card(
                    color: context.cardColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Get.to(RtoPreperation(false));
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: SizedBox(
                        height: 130,
                        width: double.infinity,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Align(
                                alignment: Alignment.center,
                                child: Opacity(
                                  opacity: 1,
                                  child: Opacity(
                                    opacity: 0.7,
                                    child: Image.asset(
                                        'assets/images/rto_exam.png',
                                        height: 80,
                                        width: 80),
                                  ),
                                )).pOnly(top: 5),
                            Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                      width: double.infinity,
                                      child: Card(
                                        color: context.backgroundColor,
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        child: Text(
                                          "Rto Exam",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 10,
                                              color:
                                                  Theme.of(context).cursorColor,
                                              fontFamily: "Circular Medium"),
                                        ).px(10).py(1),
                                      ).px(3),
                                    ).px(5))
                                .pOnly(bottom: 5)
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 5, right: 10),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class VehicleOwnerInfo extends StatelessWidget {
  VehicleOwnerInfo({Key? key}) : super(key: key);
  ThemeController themeController = Get.put(ThemeController());
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Owner Details",
                  style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(
                left: 20,
              ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: SizedBox(
                  height: 270,
                  width: double.infinity,
                  child: Card(
                    color: Theme.of(context).buttonColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onTap: () {
                        Future.delayed(const Duration(milliseconds: 350), () {
                          Get.to(OwnerInfo(true, ""));
                        });
                      },
                      splashColor: Theme.of(context).hoverColor,
                      child: Container(
                        height: 175,
                        width: double.infinity,
                        child: Column(
                          children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Card(
                                  color: context.backgroundColor,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Text(
                                    "Owner Info",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Theme.of(context).cursorColor,
                                        fontFamily: "Circular Medium"),
                                  ).px(10).py(2),
                                )).py(5).pOnly(left: 5),
                            Hero(
                              tag: "ownerinfo",
                              transitionOnUserGestures: true,
                              child: Opacity(
                                opacity: 0.75,
                                child: Image.asset(
                                    'assets/images/owner_info.png',
                                    height: 130,
                                    width: 130),
                              ),
                            ),
                            Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Card(
                                      color: context.backgroundColor,
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15)),
                                      child: Text(
                                        "Get RC information and owner details of any vehicle",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 9,
                                            color: Colors.blueGrey,
                                            fontFamily: "Circular Medium"),
                                      ).px(10).py(10),
                                    ).px(3))
                                .pOnly(top: 10)
                          ],
                        ),
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 20, left: 10, right: 2.5),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(0),
                child: Container(
                  height: 270,
                  width: double.infinity,
                  child: Card(
                    color: Theme.of(context).buttonColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: InkWell(
                      customBorder: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onTap: () {},
                      splashColor: Theme.of(context).hoverColor,
                      child: Container(
                        height: 175,
                        width: double.infinity,
                      ),
                    ),
                  ).pOnly(top: 8, bottom: 20, left: 5, right: 10),
                ),
              ),
            )
          ],
        ),
      ],
    );
  }
}

class FamousPerson extends StatelessWidget {
  List<Map> famousPersonList = [
    {
      'name': 'Actresses',
      'iconPath': 'assets/images/casting.png',
    },
    {
      'name': 'Dancer',
      'iconPath': 'assets/images/dancing.png',
    },
    {
      'name': 'Singer',
      'iconPath': 'assets/images/singer.png',
    },
    {
      'name': 'Actor',
      'iconPath': 'assets/images/actor.png',
    },
    {
      'name': 'Politician',
      'iconPath': 'assets/images/politician.png',
    },
    {
      'name': 'Sports Man',
      'iconPath': 'assets/images/running.png',
    },
    {
      'name': 'Business Man',
      'iconPath': 'assets/images/businessman.png',
    }
  ];

  List<BoxShadow> shadowList = [
    BoxShadow(color: Colors.grey, blurRadius: 1, offset: Offset(2, 2))
  ];
  BuildContext context;

  FamousPerson(this.context);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Famous Person's Vehicle Details",
                  style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(left: 20, top: 13),
        ),
        Container(
            margin: EdgeInsets.all(10),
            child: SizedBox(
              height: 90,
              child: ListView.builder(
                shrinkWrap: true,
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: famousPersonList.length,
                itemBuilder: (context, index) {
                  double newIndex = double.parse(index.toString());
                  return Column(
                    children: [
                      SizedBox(
                        child: Card(
                          color: newIndex.floor().isEven
                              ? context.cardColor
                              : newIndex.floor().isOdd
                                  ? Theme.of(context).buttonColor
                                  : context.cardColor,
                          elevation: 1,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: InkWell(
                            customBorder: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            onTap: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Get.to(FamousPersonScreen(
                                    famousPersonList[index]['name']));
                              });
                            },
                            splashColor: Theme.of(context).hoverColor,
                            child: Stack(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(8),
                                  height: 55,
                                  width: 55,
                                  child: Opacity(
                                    opacity: 0.8,
                                    child: Image.asset(
                                        famousPersonList[index]['iconPath']),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ).px(10),
                      ),
                      Text(famousPersonList[index]['name'],
                              style: TextStyle(fontFamily: "Circular Medium"))
                          .text
                          .color(Colors.blueGrey)
                          .size(12)
                          .make()
                          .pOnly(top: 7)
                          .px(7)
                    ],
                  );
                },
              ),
            ))
      ],
    );
  }
}

class MyFuel extends StatelessWidget {
  static bool isResponseAvailable = false;
  MainControllers mainControllers = Get.put(MainControllers());

  @override
  Widget build(BuildContext context) {
    mainControllers.fetchFuelData(context, "ahmedabad", "default");
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text("Today's Fuel Price",
                  style: TextStyle(fontFamily: "Circular Medium"))
              .text
              .size(15)
              .make()
              .pOnly(left: 20, top: 13),
        ),
        SizedBox(
          child: Card(
            color: context.cardColor,
            elevation: 0,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: InkWell(
              customBorder: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              onTap: () {
                Future.delayed(const Duration(milliseconds: 350), () {
                  Get.to(RtoOfficeInfo("Fuel"));
                });
              },
              splashColor: Theme.of(context).hoverColor,
              child: GetBuilder<MainControllers>(
                builder: (mainControllers) {
                  return SizedBox(
                    height: 175,
                    width: double.infinity,
                    child: isResponseAvailable
                        ? Stack(
                            children: [
                              Positioned(
                                  top: 16,
                                  left: 17,
                                  child: Container(
                                    color: Colors.grey,
                                    height: 40,
                                    width: 1,
                                  )),
                              Positioned(
                                top: 17,
                                left: 27,
                                child: Text("Petrol",
                                        style: TextStyle(
                                            fontFamily: "Circular Medium"))
                                    .text
                                    .size(15)
                                    .color(Colors.blueGrey)
                                    .make(),
                              ),
                              Positioned(
                                top: 37,
                                left: 27,
                                child: MyFuel.isResponseAvailable
                                    ? Text(
                                        "₹ ${mainControllers.fuelData.response.petrolPrice}",
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: context.accentColor))
                                    : Text("₹ 0.0",
                                            style: TextStyle(
                                                fontFamily: "Circular Medium"))
                                        .text
                                        .size(15)
                                        .color(context.accentColor)
                                        .make(),
                              ),
                              Positioned(
                                  top: 70,
                                  left: 17,
                                  child: Container(
                                    color: Colors.grey,
                                    height: 40,
                                    width: 1,
                                  )),
                              Positioned(
                                top: 70,
                                left: 27,
                                child: Text("Diesel",
                                        style: TextStyle(
                                            fontFamily: "Circular Medium"))
                                    .text
                                    .size(15)
                                    .color(Colors.blueGrey)
                                    .make(),
                              ),
                              Positioned(
                                top: 90,
                                left: 27,
                                child: MyFuel.isResponseAvailable
                                    ? Text(
                                        "₹ ${mainControllers.fuelData.response.dieselPrice}",
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: context.accentColor))
                                    : Text("₹ 0.0",
                                            style: TextStyle(
                                                fontFamily: "Circular Medium"))
                                        .text
                                        .size(15)
                                        .color(context.accentColor)
                                        .make(),
                              ),
                              Positioned(
                                  left: 13,
                                  right: 13,
                                  bottom: 50,
                                  child: Container(
                                    color: MyThemes.creamColor,
                                    height: 0.1,
                                    width: 200,
                                  )),
                              Positioned(
                                  left: 15,
                                  bottom: 10,
                                  child: VxContinuousRectangle(
                                    width: 270,
                                    height: 30,
                                    radius: 20,
                                    backgroundColor: context.backgroundColor,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        IconButton(
                                            padding: EdgeInsets.zero,
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.location_city,
                                              color: Colors.blueGrey,
                                            )),
                                        MyFuel.isResponseAvailable
                                            ? Text(
                                                "city : ${mainControllers.fuelData.response.code}",
                                                style: TextStyle(
                                                    fontFamily:
                                                        "Circular Medium"))
                                            : Text("Data not available for this city",
                                                    style: TextStyle(
                                                        fontFamily:
                                                            "Circular Medium"))
                                                .text
                                                .size(13)
                                                .color(Colors.blueGrey)
                                                .make()
                                      ],
                                    ),
                                  )),
                              Positioned(
                                  right: 2,
                                  bottom: 2.5,
                                  child: Material(
                                    color: Colors.transparent,
                                    shape: CircleBorder(),
                                    clipBehavior: Clip.antiAlias,
                                    child: IconButton(
                                        padding: EdgeInsets.zero,
                                        onPressed: () {
                                          Future.delayed(
                                              const Duration(milliseconds: 350),
                                              () {
                                            Get.to(RtoOfficeInfo("Fuel"));
                                          });
                                        },
                                        icon: Icon(
                                          Icons.edit_location,
                                          color: Colors.blueGrey,
                                          size: 30,
                                        )),
                                  )),
                              Positioned(
                                top: -10,
                                right: 20,
                                height: 150,
                                width: 190,
                                child: Hero(
                                  tag: "photo",
                                  transitionOnUserGestures: true,
                                  child: Opacity(
                                      opacity: 0.8,
                                      child: Image.asset(
                                          'assets/images/fuel.png')),
                                ),
                              )
                            ],
                          )
                        : Center(
                            child: CircularProgressIndicator(),
                          ),
                  );
                },
              ),
            ),
          ),
        ).px(10).pOnly(top: 5)
      ],
    );
  }
}

noInternet() {
  return Container(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Lottie.asset(
          "assets/lottie/no_internet.json",
          height: 200,
          width: 200,
        ),
        Text("Please add check your internet !",
                style: TextStyle(
                    fontFamily: "Circular Medium",
                    fontSize: 12,
                    color: Colors.grey))
            .py(15)
      ],
    ),
  ).pOnly(top: 230);
}
