package com.wavymusic.RetrofitApiCall;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIInterface {
    /*Dashbord Api*/
    @POST("getBeatsUv")
    @FormUrlEncoded
    Call<JsonObject> GetDashbordTheme(@Field("token") String token, @Field("application_id") String applicationId);

    /*Wavy Music Start*/
    @POST("getallthemes")
    @FormUrlEncoded
    Call<JsonObject> GetAllTheme(@Field("token") String token, @Field("application_id") String applicationId);

    /* @POST("get_themes_v2")
     @FormUrlEncoded
     Call<JsonObject> GetAllTheme(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CategoryId);*/
    @POST("setdowncount")
    @FormUrlEncoded
    Call<JsonObject> DownloadIncrement(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CatId, @Field("theme_id") String ThemeId);

    /*Wavy Music End*/

    /*United Video Start*/
    @POST("getallthemes")
    @FormUrlEncoded
    Call<JsonObject> GetAllThemeUv(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CategoryId, @Field("page_no") String PageId);

    @POST("get_morethemes")
    @FormUrlEncoded
    Call<JsonObject> GetMoreThemeUV(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CategoryId, @Field("page_no") String PageId);

    @POST("add_download")
    @FormUrlEncoded
    Call<JsonObject> DownloadIncrementUv(@Field("token") String token, @Field("application_id") String applicationId, @Field("cat_id") String CatId, @Field("theme_id") String ThemeId);

    /*United Video End*/

    /*Partical Api Wavy*/
    @POST("getPartical")
    @FormUrlEncoded
    Call<JsonObject> ParticalWavy(@Field("token") String token, @Field("application_id") String applicationId);
}
