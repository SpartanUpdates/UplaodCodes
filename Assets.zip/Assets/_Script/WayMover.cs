﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayMover : MonoBehaviour
{
    int current = 0;

    [Header("Speed Of Pencil Move")]
    public float speed;
    
    float WPradius = 1;

    [Space(2)]
    [Header("Trail particles")]
    public ParticleSystem[] lineParticle;
        
    public int tempLengh;

    GameObject PlayerDPoint, EnemyDPoint;
    
    float distance,startSpeed;

    bool isFinishPoint = false;

    Vector3 targetPos;


    void Awake()
    {
        startSpeed = speed;
    }

    void Start()
    {
        PlayerDPoint = GameObject.FindGameObjectWithTag("PlayerDistance");
        EnemyDPoint = GameObject.FindGameObjectWithTag("EnemyDistance");
        lineParticle[0].trigger.SetCollider(0, PlayerDPoint.transform.parent.transform);
        lineParticle[1].trigger.SetCollider(0, PlayerDPoint.transform.parent.transform);
        GameManager.instance.waypoints1 = GameManager.instance.wayPointsContainer[0].GetPathPoints();
        int colora = UnityEngine.Random.Range(0, GameManager.instance.particleColors.Length);
        lineParticle[0].startColor = GameManager.instance.particleColors[colora];
        lineParticle[1].startColor = GameManager.instance.particleColors[colora];

    }
    void FixedUpdate()
    {
        if (!GameManager.instance.isGameOver && !isFinishPoint)
        {
            if (Vector3.Distance(GameManager.instance.waypoints1[current].transform.position, transform.position) < WPradius)
            {
                current++;
                if (current >= GameManager.instance.waypoints1.Count)
                {
                    this.enabled = false;
                    current = 0;
                }
            }

            distance = Vector3.Distance(EnemyDPoint.transform.position, PlayerDPoint.transform.position);

            if (distance < 20)
            {
                speed += 3;
            }
            else{
                speed = startSpeed;
            }
            
            transform.position = Vector3.MoveTowards(transform.position, GameManager.instance.waypoints1[current].transform.position, Time.deltaTime * speed);
        }
        if (isFinishPoint)
        {
            if (Vector3.Distance(transform.position, targetPos) > 1)
                transform.position = Vector3.MoveTowards(transform.position, targetPos, Time.deltaTime * 10);
        }
    }
    
    void OnCollisionEnter(Collision target)
    {
        if (target.gameObject.CompareTag("Finish") && !isFinishPoint)
        {
            var emission = lineParticle[0].emission;
            emission.enabled = false;
            emission = lineParticle[1].emission;
            emission.enabled = false;

            isFinishPoint = true;
            targetPos.x = transform.position.x > 0 ? -8 : 8;
            targetPos.y = transform.position.y;
            targetPos.z = target.gameObject.transform.position.z + 30;
        }
    }
}