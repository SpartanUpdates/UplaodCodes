package com.kotlinz.festivalstorymaker.Other;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ImageView;

public class gestureListener extends GestureDetector.SimpleOnGestureListener {
    public OnTouch e;
    public int f;
    public int g;
    public ImageView h;

    public gestureListener(OnTouch aVar, int i, int i2, ImageView imageView) {
        this.f = i;
        this.g = i2;
        this.h = imageView;
        this.e = aVar;
    }

    public boolean onDoubleTap(MotionEvent motionEvent) {
        OnTouch aVar = this.e;
        if (aVar != null) {
            aVar.n(this.g, this.f, this.h);
        }
        return true;
    }

    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return super.onDoubleTapEvent(motionEvent);
    }

    public boolean onDown(MotionEvent motionEvent) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(motionEvent.getAction());
        stringBuilder.append("");
        return true;
    }

    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        OnTouch aVar = this.e;
        if (aVar != null) {
            aVar.m(this.g, this.f, this.h);
        }
        return super.onSingleTapConfirmed(motionEvent);
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(motionEvent.getAction());
        stringBuilder.append("");
        return super.onSingleTapUp(motionEvent);
    }
}
