package com.esc.socialmediacleaner.loader;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import com.esc.socialmediacleaner.R;
import androidx.collection.SparseArrayCompat;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.VelocityTrackerCompat;
import androidx.core.view.ViewCompat;
import androidx.core.widget.EdgeEffectCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class StaggeredGridView extends ViewGroup {
    private static final int INVALID_POSITION = -1;
    private static final String TAG = "StaggeredGridView";
    private static final int TOUCH_MODE_DOWN = 3;
    private static final int TOUCH_MODE_IDLE = 0;
    private int mActivePointerId;
    private ListAdapter mAdapter;
    private boolean mBeginClick;
    private final EdgeEffectCompat mBottomEdge;
    private int mColCount;
    private int mColCountSetting;
    private ArrayList<ArrayList<Integer>> mColMappings;
    private int mColWidth;
    private ContextMenuInfo mContextMenuInfo;
    private boolean mDataChanged;
    boolean mDrawSelectorOnTop;
    private boolean mFastChildLayout;
    private long mFirstAdapterId;
    private int mFirstPosition;
    private int mFlingVelocity;
    private boolean mHasStableIds;
    private boolean mInLayout;
    private boolean mIsChildViewEnabled;
    private int[] mItemBottoms;
    private int mItemCount;
    private int mItemMargin;
    private int[] mItemTops;
    private float mLastTouchX;
    private float mLastTouchY;
    private final SparseArrayCompat<LayoutRecord> mLayoutRecords;
    private int mMaximumVelocity;
    private int mMinColWidth;
    private int mMotionPosition;
    private final AdapterDataSetObserver mObserver;
    OnItemClickListener mOnItemClickListener;
    OnItemLongClickListener mOnItemLongClickListener;
    private CheckForLongPress mPendingCheckForLongPress;
    private Runnable mPendingCheckForTap;
    private PerformClick mPerformClick;
    private boolean mPopulating;
    private final RecycleBin mRecycler;
    private int[] mRestoreOffsets;
    private final ScrollerCompat mScroller;
    int mSelectionBottomPadding;
    int mSelectionLeftPadding;
    int mSelectionRightPadding;
    int mSelectionTopPadding;
    Drawable mSelector;
    int mSelectorPosition;
    Rect mSelectorRect;
    private final EdgeEffectCompat mTopEdge;
    private Rect mTouchFrame;
    private int mTouchMode;
    private Runnable mTouchModeReset;
    private float mTouchRemainderY;
    private int mTouchSlop;
    private final VelocityTracker mVelocityTracker;

    public static class AdapterContextMenuInfo implements ContextMenuInfo {
        public long id;
        public int position;
        public View targetView;

        public AdapterContextMenuInfo(View view, int i, long j) {
            this.targetView = view;
            this.position = i;
            this.id = j;
        }
    }

    private class AdapterDataSetObserver extends DataSetObserver {
        public void onInvalidated() {
        }

        private AdapterDataSetObserver() {
        }

        public void onChanged() {
            StaggeredGridView.this.mDataChanged = true;
            StaggeredGridView staggeredGridView = StaggeredGridView.this;
            staggeredGridView.mItemCount = staggeredGridView.mAdapter.getCount();
            StaggeredGridView.this.mRecycler.clearTransientViews();
            if (!StaggeredGridView.this.mHasStableIds) {
                StaggeredGridView.this.mLayoutRecords.clear();
                StaggeredGridView.this.recycleAllViews();
                int access$1300 = StaggeredGridView.this.mColCount;
                for (int i = 0; i < access$1300; i++) {
                    StaggeredGridView.this.mItemBottoms[i] = StaggeredGridView.this.mItemTops[i];
                }
            }
            if (StaggeredGridView.this.mFirstPosition > StaggeredGridView.this.mItemCount - 1 || StaggeredGridView.this.mAdapter.getItemId(StaggeredGridView.this.mFirstPosition) != StaggeredGridView.this.mFirstAdapterId) {
                StaggeredGridView.this.mFirstPosition = 0;
                Arrays.fill(StaggeredGridView.this.mItemTops, 0);
                Arrays.fill(StaggeredGridView.this.mItemBottoms, 0);
                if (StaggeredGridView.this.mRestoreOffsets != null) {
                    Arrays.fill(StaggeredGridView.this.mRestoreOffsets, 0);
                }
            }
            StaggeredGridView.this.requestLayout();
        }
    }

    final class CheckForTap implements Runnable {
        CheckForTap() {
        }

        public void run() {
            if (StaggeredGridView.this.mTouchMode == 3) {
                StaggeredGridView.this.mTouchMode = 4;
                StaggeredGridView staggeredGridView = StaggeredGridView.this;
                View childAt = staggeredGridView.getChildAt(staggeredGridView.mMotionPosition - StaggeredGridView.this.mFirstPosition);
                if (childAt != null && !childAt.hasFocusable()) {
                    if (StaggeredGridView.this.mDataChanged) {
                        StaggeredGridView.this.mTouchMode = 5;
                        return;
                    }
                    childAt.setSelected(true);
                    childAt.setPressed(true);
                    StaggeredGridView.this.setPressed(true);
                    StaggeredGridView.this.layoutChildren(true);
                    StaggeredGridView staggeredGridView2 = StaggeredGridView.this;
                    staggeredGridView2.positionSelector(staggeredGridView2.mMotionPosition, childAt);
                    StaggeredGridView.this.refreshDrawableState();
                    int longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    boolean isLongClickable = StaggeredGridView.this.isLongClickable();
                    if (StaggeredGridView.this.mSelector != null) {
                        Drawable current = StaggeredGridView.this.mSelector.getCurrent();
                        if (current instanceof TransitionDrawable) {
                            if (isLongClickable) {
                                ((TransitionDrawable) current).startTransition(longPressTimeout);
                            } else {
                                ((TransitionDrawable) current).resetTransition();
                            }
                        }
                    }
                    if (isLongClickable) {
                        if (StaggeredGridView.this.mPendingCheckForLongPress == null) {
                            StaggeredGridView.this.mPendingCheckForLongPress = new CheckForLongPress();
                        }
                        StaggeredGridView.this.mPendingCheckForLongPress.rememberWindowAttachCount();
                        staggeredGridView2 = StaggeredGridView.this;
                        staggeredGridView2.postDelayed(staggeredGridView2.mPendingCheckForLongPress, (long) longPressTimeout);
                    } else {
                        StaggeredGridView.this.mTouchMode = 5;
                    }
                    StaggeredGridView.this.postInvalidate();
                }
            }
        }
    }

    static class ColMap implements Parcelable {
        public static final Creator<ColMap> CREATOR = new Creator<ColMap>() {
            public ColMap createFromParcel(Parcel parcel) {
                return new ColMap(parcel);
            }

            public ColMap[] newArray(int i) {
                return new ColMap[i];
            }
        };
        int[] tempMap;
        private ArrayList<Integer> values;

        public int describeContents() {
            return 0;
        }


        public ColMap(ArrayList<Integer> arrayList) {
            this.values = arrayList;
        }

        private ColMap(Parcel parcel) {
            parcel.readIntArray(this.tempMap);
            this.values = new ArrayList();
            int i = 0;
            while (true) {
                int[] iArr = this.tempMap;
                if (i < iArr.length) {
                    this.values.add(Integer.valueOf(iArr[i]));
                    i++;
                } else {
                    return;
                }
            }
        }

        public void writeToParcel(Parcel parcel, int i) {
            int[] toIntArray = toIntArray(this.values);
            this.tempMap = toIntArray;
            parcel.writeIntArray(toIntArray);
        }

        public int[] toIntArray(ArrayList<Integer> arrayList) {
            int size = arrayList.size();
            int[] iArr = new int[size];
            for (int i = 0; i < size; i++) {
                iArr[i] = ((Integer) arrayList.get(i)).intValue();
            }
            return iArr;
        }
    }

    public static class LayoutParams extends ViewGroup.LayoutParams {
        private static final int[] LAYOUT_ATTRS = new int[]{16843085};
        private static final int SPAN_INDEX = 0;
        int column;
        long id = -1;
        int position;
        public int span = 1;
        int viewType;

        public LayoutParams(int i) {
            super(-1, i);
            if (this.height == -1) {
                Log.w(StaggeredGridView.TAG, "Constructing LayoutParams with height FILL_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            int i = this.width;
            String str = StaggeredGridView.TAG;
            if (i != -1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Inflation setting LayoutParams width to ");
                stringBuilder.append(this.width);
                stringBuilder.append(" - must be MATCH_PARENT");
                Log.w(str, stringBuilder.toString());
                this.width = -1;
            }
            if (this.height == -1) {
                Log.w(str, "Inflation setting LayoutParams height to MATCH_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, LAYOUT_ATTRS);
            this.span = obtainStyledAttributes.getInteger(0, 1);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            int i = this.width;
            String str = StaggeredGridView.TAG;
            if (i != -1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Constructing LayoutParams with width ");
                stringBuilder.append(this.width);
                stringBuilder.append(" - must be MATCH_PARENT");
                Log.w(str, stringBuilder.toString());
                this.width = -1;
            }
            if (this.height == -1) {
                Log.w(str, "Constructing LayoutParams with height MATCH_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
        }
    }

    private static final class LayoutRecord {
        public int column;
        public int height;
        public long id;
        private int[] mMargins;
        public int span;

        private LayoutRecord() {
            this.id = -1;
        }

        private final void ensureMargins() {
            if (this.mMargins == null) {
                this.mMargins = new int[(this.span * 2)];
            }
        }

        public final int getMarginAbove(int i) {
            int[] iArr = this.mMargins;
            if (iArr == null) {
                return 0;
            }
            return iArr[i * 2];
        }

        public final int getMarginBelow(int i) {
            int[] iArr = this.mMargins;
            if (iArr == null) {
                return 0;
            }
            return iArr[(i * 2) + 1];
        }

        public final void setMarginAbove(int i, int i2) {
            if (this.mMargins != null || i2 != 0) {
                ensureMargins();
                this.mMargins[i * 2] = i2;
            }
        }

        public final void setMarginBelow(int i, int i2) {
            if (this.mMargins != null || i2 != 0) {
                ensureMargins();
                this.mMargins[(i * 2) + 1] = i2;
            }
        }

        public String toString() {
            StringBuilder stringBuilder;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("LayoutRecord{c=");
            stringBuilder2.append(this.column);
            stringBuilder2.append(", id=");
            stringBuilder2.append(this.id);
            stringBuilder2.append(" h=");
            stringBuilder2.append(this.height);
            stringBuilder2.append(" s=");
            stringBuilder2.append(this.span);
            String stringBuilder3 = stringBuilder2.toString();
            if (this.mMargins != null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(" margins[above, below](");
                stringBuilder3 = stringBuilder.toString();
                for (int i = 0; i < this.mMargins.length; i += 2) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(stringBuilder3);
                    stringBuilder4.append("[");
                    stringBuilder4.append(this.mMargins[i]);
                    stringBuilder4.append(", ");
                    stringBuilder4.append(this.mMargins[i + 1]);
                    stringBuilder4.append("]");
                    stringBuilder3 = stringBuilder4.toString();
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(")");
                stringBuilder3 = stringBuilder.toString();
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append(stringBuilder3);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public interface OnItemClickListener {
        void onItemClick(StaggeredGridView staggeredGridView, View view, int i, long j);
    }

    public interface OnItemLongClickListener {
        boolean onItemLongClick(StaggeredGridView staggeredGridView, View view, int i, long j);
    }

    private class RecycleBin {
        private int mMaxScrap;
        private ArrayList<View>[] mScrapViews;
        private SparseArray<View> mTransientStateViews;
        private int mViewTypeCount;

        private RecycleBin() {
        }

        public void setViewTypeCount(int i) {
            if (i < 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Must have at least one view type (");
                stringBuilder.append(i);
                stringBuilder.append(" types reported)");
                throw new IllegalArgumentException(stringBuilder.toString());
            } else if (i != this.mViewTypeCount) {
                ArrayList[] arrayListArr = new ArrayList[i];
                for (int i2 = 0; i2 < i; i2++) {
                    arrayListArr[i2] = new ArrayList();
                }
                this.mViewTypeCount = i;
                this.mScrapViews = arrayListArr;
            }
        }

        public void clear() {
            int i = this.mViewTypeCount;
            for (int i2 = 0; i2 < i; i2++) {
                this.mScrapViews[i2].clear();
            }
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray != null) {
                sparseArray.clear();
            }
        }

        public void clearTransientViews() {
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray != null) {
                sparseArray.clear();
            }
        }

        public void addScrap(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (ViewCompat.hasTransientState(view)) {
                if (this.mTransientStateViews == null) {
                    this.mTransientStateViews = new SparseArray();
                }
                this.mTransientStateViews.put(layoutParams.position, view);
                return;
            }
            int childCount = StaggeredGridView.this.getChildCount();
            if (childCount > this.mMaxScrap) {
                this.mMaxScrap = childCount;
            }
            ArrayList arrayList = this.mScrapViews[layoutParams.viewType];
            if (arrayList.size() < this.mMaxScrap) {
                arrayList.add(view);
            }
        }

        public View getTransientStateView(int i) {
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray == null) {
                return null;
            }
            View view = (View) sparseArray.get(i);
            if (view != null) {
                this.mTransientStateViews.remove(i);
            }
            return view;
        }

        public View getScrapView(int i) {
            ArrayList arrayList = this.mScrapViews[i];
            if (arrayList.isEmpty()) {
                return null;
            }
            int size = arrayList.size() - 1;
            View view = (View) arrayList.get(size);
            arrayList.remove(size);
            return view;
        }
    }

    static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public SavedState[] newArray(int i) {
                return new SavedState[i];
            }
        };
        long firstId;
        ArrayList<ColMap> mapping;
        int position;
        int[] topOffsets;


        SavedState(Parcelable parcelable) {
            super(parcelable);
            this.firstId = -1;
        }

        private SavedState(Parcel parcel) {
            super(parcel);
            this.firstId = -1;
            this.firstId = parcel.readLong();
            this.position = parcel.readInt();
            parcel.readIntArray(this.topOffsets);
            parcel.readTypedList(this.mapping, ColMap.CREATOR);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeLong(this.firstId);
            parcel.writeInt(this.position);
            parcel.writeIntArray(this.topOffsets);
            parcel.writeTypedList(this.mapping);
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("StaggereGridView.SavedState{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" firstId=");
            stringBuilder.append(this.firstId);
            stringBuilder.append(" position=");
            stringBuilder.append(this.position);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public interface SelectionBoundsAdjuster {
        void adjustListItemSelectionBounds(Rect rect);
    }

    private class WindowRunnnable {
        private int mOriginalAttachCount;

        private WindowRunnnable() {
        }

        public void rememberWindowAttachCount() {
            this.mOriginalAttachCount = StaggeredGridView.this.getWindowAttachCount();
        }

        public boolean sameWindow() {
            return StaggeredGridView.this.hasWindowFocus() && StaggeredGridView.this.getWindowAttachCount() == this.mOriginalAttachCount;
        }
    }

    private class CheckForLongPress extends WindowRunnnable implements Runnable {
        private CheckForLongPress() {
            super();
        }

        public void run() {
            int access$2300 = StaggeredGridView.this.mMotionPosition;
            StaggeredGridView staggeredGridView = StaggeredGridView.this;
            View childAt = staggeredGridView.getChildAt(access$2300 - staggeredGridView.mFirstPosition);
            if (childAt != null) {
                boolean performLongPress = (!sameWindow() || StaggeredGridView.this.mDataChanged) ? false : StaggeredGridView.this.performLongPress(childAt, StaggeredGridView.this.mMotionPosition, StaggeredGridView.this.mAdapter.getItemId(StaggeredGridView.this.mMotionPosition));
                if (performLongPress) {
                    StaggeredGridView.this.mTouchMode = 6;
                    StaggeredGridView.this.setPressed(false);
                    childAt.setPressed(false);
                    return;
                }
                StaggeredGridView.this.mTouchMode = 5;
            }
        }
    }

    private class PerformClick extends WindowRunnnable implements Runnable {
        int mClickMotionPosition;

        private PerformClick() {
            super();
        }

        public void run() {
            if (!StaggeredGridView.this.mDataChanged) {
                ListAdapter access$800 = StaggeredGridView.this.mAdapter;
                int i = this.mClickMotionPosition;
                if (access$800 != null && StaggeredGridView.this.mItemCount > 0 && i != -1 && i < access$800.getCount() && sameWindow()) {
                    StaggeredGridView staggeredGridView = StaggeredGridView.this;
                    View childAt = staggeredGridView.getChildAt(i - staggeredGridView.mFirstPosition);
                    if (childAt != null) {
                        StaggeredGridView.this.performItemClick(childAt, i, access$800.getItemId(i));
                    }
                }
            }
        }
    }

    public void hideSelector() {
    }

    public StaggeredGridView(Context context) {
        this(context, null);
    }

    public StaggeredGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public StaggeredGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mColCountSetting = 2;
        this.mColCount = 2;
        this.mMinColWidth = 0;
        this.mRecycler = new RecycleBin();
        this.mObserver = new AdapterDataSetObserver();
        this.mVelocityTracker = VelocityTracker.obtain();
        this.mColMappings = new ArrayList();
        this.mContextMenuInfo = null;
        this.mDrawSelectorOnTop = false;
        this.mSelectionLeftPadding = 0;
        this.mSelectionTopPadding = 0;
        this.mSelectionRightPadding = 0;
        this.mSelectionBottomPadding = 0;
        this.mSelectorRect = new Rect();
        this.mSelectorPosition = -1;
        this.mLayoutRecords = new SparseArrayCompat();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.StaggeredGridView);
            this.mColCount = obtainStyledAttributes.getInteger(R.styleable.StaggeredGridView_numColumns, 2);
            this.mDrawSelectorOnTop = obtainStyledAttributes.getBoolean(R.styleable.StaggeredGridView_drawSelectorOnTop, false);
        } else {
            this.mColCount = 2;
            this.mDrawSelectorOnTop = false;
        }
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        this.mFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mScroller = ScrollerCompat.from(context);
        this.mTopEdge = new EdgeEffectCompat(context);
        this.mBottomEdge = new EdgeEffectCompat(context);
        setWillNotDraw(false);
        setClipToPadding(false);
        setFocusableInTouchMode(false);
        if (this.mSelector == null) {
            useDefaultSelector();
        }
    }

    public void setColumnCount(int i) {
        Object obj = 1;
        if (i >= 1 || i == -1) {
            if (i == this.mColCount) {
                obj = null;
            }
            this.mColCountSetting = i;
            this.mColCount = i;
            if (obj != null) {
                populate(false);
                return;
            }
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Column count must be at least 1 - received ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public int getColumnCount() {
        return this.mColCount;
    }

    public void setMinColumnWidth(int i) {
        this.mMinColWidth = i;
        setColumnCount(-1);
    }

    public void setItemMargin(int i) {
        Object obj = i != this.mItemMargin ? 1 : null;
        this.mItemMargin = i;
        if (obj != null) {
            populate(false);
        }
    }

    public int getFirstPosition() {
        return this.mFirstPosition;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        this.mVelocityTracker.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.mVelocityTracker.clear();
            this.mScroller.abortAnimation();
            this.mLastTouchY = motionEvent.getY();
            this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent, 0);
            this.mTouchRemainderY = 0.0f;
            if (this.mTouchMode == 2) {
                this.mTouchMode = 1;
                return true;
            }
        } else if (action == 2) {
            action = MotionEventCompat.findPointerIndex(motionEvent, this.mActivePointerId);
            if (action < 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onInterceptTouchEvent could not find pointer with id ");
                stringBuilder.append(this.mActivePointerId);
                stringBuilder.append(" - did StaggeredGridView receive an inconsistent event stream?");
                Log.e(TAG, stringBuilder.toString());
                return false;
            }
            float y = (MotionEventCompat.getY(motionEvent, action) - this.mLastTouchY) + this.mTouchRemainderY;
            this.mTouchRemainderY = y - ((float) ((int) y));
            if (Math.abs(y) > ((float) this.mTouchSlop)) {
                this.mTouchMode = 1;
                return true;
            }
        }
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        this.mVelocityTracker.addMovement(motionEvent2);
        int action = motionEvent.getAction() & 255;
        int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        float x;
        float x2;
        if (action == 0) {
            this.mVelocityTracker.clear();
            this.mScroller.abortAnimation();
            this.mLastTouchY = motionEvent.getY();
            x = motionEvent.getX();
            this.mLastTouchX = x;
            action = pointToPosition((int) x, (int) this.mLastTouchY);
            this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent2, 0);
            this.mTouchRemainderY = 0.0f;
            if (this.mTouchMode != 2 && !this.mDataChanged && action >= 0 && getAdapter().isEnabled(action)) {
                this.mTouchMode = 3;
                this.mBeginClick = true;
                if (this.mPendingCheckForTap == null) {
                    this.mPendingCheckForTap = new CheckForTap();
                }
                postDelayed(this.mPendingCheckForTap, (long) ViewConfiguration.getTapTimeout());
            }
            this.mMotionPosition = action;
            invalidate();
        } else if (action == 1) {
            this.mVelocityTracker.computeCurrentVelocity(1000, (float) this.mMaximumVelocity);
            x = VelocityTrackerCompat.getYVelocity(this.mVelocityTracker, this.mActivePointerId);
            int i = this.mTouchMode;
            if (Math.abs(x) > ((float) this.mFlingVelocity)) {
                this.mTouchMode = 2;
                this.mScroller.fling(0, 0, 0, (int) x, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
                this.mLastTouchY = 0.0f;
                invalidate();
            } else {
                this.mTouchMode = 0;
            }
            if (this.mDataChanged || !this.mAdapter.isEnabled(pointToPosition)) {
                this.mTouchMode = 6;
            } else {
                this.mTouchMode = 4;
            }
            if (i == 3 || i == 4 || i == 5) {
                final View childAt = getChildAt(pointToPosition - this.mFirstPosition);
                x2 = motionEvent.getX();
                Object obj = (x2 <= ((float) getPaddingLeft()) || x2 >= ((float) (getWidth() - getPaddingRight()))) ? null : 1;
                if (!(childAt == null || childAt.hasFocusable() || obj == null)) {
                    if (this.mTouchMode != 3) {
                        childAt.setPressed(false);
                    }
                    if (this.mPerformClick == null) {
                        invalidate();
                        this.mPerformClick = new PerformClick();
                    }
                    final PerformClick performClick = this.mPerformClick;
                    performClick.mClickMotionPosition = pointToPosition;
                    performClick.rememberWindowAttachCount();
                    i = this.mTouchMode;
                    if (i == 3 || i == 4) {
                        Handler handler = getHandler();
                        if (handler != null) {
                            handler.removeCallbacks(this.mTouchMode == 3 ? this.mPendingCheckForTap : this.mPendingCheckForLongPress);
                        }
                        if (this.mDataChanged || !this.mAdapter.isEnabled(pointToPosition)) {
                            this.mTouchMode = 6;
                        } else {
                            this.mTouchMode = 4;
                            layoutChildren(this.mDataChanged);
                            childAt.setPressed(true);
                            positionSelector(this.mMotionPosition, childAt);
                            setPressed(true);
                            Drawable drawable = this.mSelector;
                            if (drawable != null) {
                                drawable = drawable.getCurrent();
                                if (drawable != null && (drawable instanceof TransitionDrawable)) {
                                    ((TransitionDrawable) drawable).resetTransition();
                                }
                            }
                            Runnable runnable = this.mTouchModeReset;
                            if (runnable != null) {
                                removeCallbacks(runnable);
                            }
                            Runnable run = new Runnable() {
                                public void run() {
                                    StaggeredGridView.this.mTouchMode = 6;
                                    childAt.setPressed(false);
                                    StaggeredGridView.this.setPressed(false);
                                    if (!StaggeredGridView.this.mDataChanged) {
                                        performClick.run();
                                    }
                                }
                            };
                            this.mTouchModeReset = run;
                            postDelayed(run, (long) ViewConfiguration.getPressedStateDuration());
                        }
                        return true;
                    } else if (!this.mDataChanged && this.mAdapter.isEnabled(pointToPosition)) {
                        performClick.run();
                    }
                }
                this.mTouchMode = 6;
            }
            this.mBeginClick = false;
            updateSelectorState();
        } else if (action == 2) {
            action = MotionEventCompat.findPointerIndex(motionEvent2, this.mActivePointerId);
            if (action < 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onInterceptTouchEvent could not find pointer with id ");
                stringBuilder.append(this.mActivePointerId);
                stringBuilder.append(" - did StaggeredGridView receive an inconsistent event stream?");
                Log.e(TAG, stringBuilder.toString());
                return false;
            }
            x2 = MotionEventCompat.getY(motionEvent2, action);
            x = (x2 - this.mLastTouchY) + this.mTouchRemainderY;
            pointToPosition = (int) x;
            this.mTouchRemainderY = x - ((float) pointToPosition);
            if (Math.abs(x) > ((float) this.mTouchSlop)) {
                this.mTouchMode = 1;
            }
            if (this.mTouchMode == 1) {
                this.mLastTouchY = x2;
                if (!trackMotionScroll(pointToPosition, true)) {
                    this.mVelocityTracker.clear();
                }
            }
            updateSelectorState();
        } else if (action == 3) {
            this.mTouchMode = 0;
            updateSelectorState();
            setPressed(false);
            View childAt2 = getChildAt(this.mMotionPosition - this.mFirstPosition);
            if (childAt2 != null) {
                childAt2.setPressed(false);
            }
            Handler handler2 = getHandler();
            if (handler2 != null) {
                handler2.removeCallbacks(this.mPendingCheckForLongPress);
            }
            EdgeEffectCompat edgeEffectCompat = this.mTopEdge;
            if (edgeEffectCompat != null) {
                edgeEffectCompat.onRelease();
                this.mBottomEdge.onRelease();
            }
            this.mTouchMode = 0;
        }
        return true;
    }

    private boolean trackMotionScroll(int i, boolean z) {
        int overScrollMode;
        boolean contentFits = contentFits();
        int abs = Math.abs(i);
        int i2;
        if (contentFits) {
            i2 = 0;
        } else {
            int fillUp;
            Object obj;
            this.mPopulating = true;
            if (i > 0) {
                fillUp = fillUp(this.mFirstPosition - 1, abs) + this.mItemMargin;
                obj = 1;
            } else {
                fillUp = fillDown(this.mFirstPosition + getChildCount(), abs) + this.mItemMargin;
                obj = null;
            }
            i2 = Math.min(fillUp, abs);
            offsetChildren(obj != null ? i2 : -i2);
            recycleOffscreenViews();
            this.mPopulating = false;
            abs -= fillUp;
        }
        if (z) {
            overScrollMode = ViewCompat.getOverScrollMode(this);
            if ((overScrollMode == 0 || (overScrollMode == 1 && !contentFits)) && abs > 0) {
                (i > 0 ? this.mTopEdge : this.mBottomEdge).onPull(((float) Math.abs(i)) / ((float) getHeight()));
                invalidate();
            }
        }
        overScrollMode = this.mSelectorPosition;
        if (overScrollMode != -1) {
            overScrollMode -= this.mFirstPosition;
            if (overScrollMode >= 0 && overScrollMode < getChildCount()) {
                positionSelector(-1, getChildAt(overScrollMode));
            }
        } else {
            this.mSelectorRect.setEmpty();
        }
        if (i == 0 || i2 != 0) {
            return true;
        }
        return false;
    }

    private final boolean contentFits() {
        if (this.mFirstPosition != 0 || getChildCount() != this.mItemCount) {
            return false;
        }
        int i = Integer.MAX_VALUE;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = 0; i3 < this.mColCount; i3++) {
            int[] iArr = this.mItemTops;
            if (iArr[i3] < i) {
                i = iArr[i3];
            }
            iArr = this.mItemBottoms;
            if (iArr[i3] > i2) {
                i2 = iArr[i3];
            }
        }
        if (i < getPaddingTop() || i2 > getHeight() - getPaddingBottom()) {
            return false;
        }
        return true;
    }

    private void recycleAllViews() {
        for (int i = 0; i < getChildCount(); i++) {
            this.mRecycler.addScrap(getChildAt(i));
        }
        if (this.mInLayout) {
            removeAllViewsInLayout();
        } else {
            removeAllViews();
        }
    }

    private void recycleOffscreenViews() {
        View childAt;
        int height = getHeight();
        int i = this.mItemMargin;
        int i2 = -i;
        height += i;
        for (i = getChildCount() - 1; i >= 0; i--) {
            childAt = getChildAt(i);
            if (childAt.getTop() <= height) {
                break;
            }
            if (this.mInLayout) {
                removeViewsInLayout(i, 1);
            } else {
                removeViewAt(i);
            }
            this.mRecycler.addScrap(childAt);
        }
        while (getChildCount() > 0) {
            View childAt2 = getChildAt(0);
            if (childAt2.getBottom() >= i2) {
                break;
            }
            if (this.mInLayout) {
                removeViewsInLayout(0, 1);
            } else {
                removeViewAt(0);
            }
            this.mRecycler.addScrap(childAt2);
            this.mFirstPosition++;
        }
        height = getChildCount();
        if (height > 0) {
            Arrays.fill(this.mItemTops, Integer.MAX_VALUE);
            Arrays.fill(this.mItemBottoms, Integer.MIN_VALUE);
            for (i2 = 0; i2 < height; i2++) {
                childAt = getChildAt(i2);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int top = childAt.getTop() - this.mItemMargin;
                int bottom = childAt.getBottom();
                LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(this.mFirstPosition + i2);
                int min = layoutParams.column + Math.min(this.mColCount, layoutParams.span);
                for (int i3 = layoutParams.column; i3 < min; i3++) {
                    int marginAbove = top - layoutRecord.getMarginAbove(i3 - layoutParams.column);
                    int marginBelow = layoutRecord.getMarginBelow(i3 - layoutParams.column) + bottom;
                    int[] iArr = this.mItemTops;
                    if (marginAbove < iArr[i3]) {
                        iArr[i3] = marginAbove;
                    }
                    int[] iArr2 = this.mItemBottoms;
                    if (marginBelow > iArr2[i3]) {
                        iArr2[i3] = marginBelow;
                    }
                }
            }
            for (height = 0; height < this.mColCount; height++) {
                int[] iArr3 = this.mItemTops;
                if (iArr3[height] == Integer.MAX_VALUE) {
                    iArr3[height] = 0;
                    this.mItemBottoms[height] = 0;
                }
            }
        }
    }

    public void computeScroll() {
        if (mScroller.computeScrollOffset()) {
            final int y = mScroller.getCurrY();
            final int dy = (int) (y - mLastTouchY);
            mLastTouchY = y;
            final boolean stopped = !trackMotionScroll(dy, false);

            if (!stopped && !mScroller.isFinished()) {
                postInvalidate();
            } else {
                if (stopped) {
                    final int overScrollMode = ViewCompat.getOverScrollMode(this);
                    if (overScrollMode != ViewCompat.OVER_SCROLL_NEVER) {
                        final EdgeEffectCompat edge;
                        if (dy > 0) {
                            edge = mTopEdge;
                        } else {
                            edge = mBottomEdge;
                        }
                        edge.onAbsorb(Math.abs((int) mScroller.getCurrVelocity()));
                        postInvalidate();
                    }
                    mScroller.abortAnimation();
                }
                mTouchMode = TOUCH_MODE_IDLE;
            }
        }
    }

    public void dispatchDraw(Canvas canvas) {
        boolean z = this.mDrawSelectorOnTop;
        if (!z) {
            drawSelector(canvas);
        }
        super.dispatchDraw(canvas);
        if (z) {
            drawSelector(canvas);
        }
    }

    private void drawSelector(Canvas canvas) {
        if (!this.mSelectorRect.isEmpty()) {
            Drawable drawable = this.mSelector;
            if (drawable != null && this.mBeginClick) {
                drawable.setBounds(this.mSelectorRect);
                drawable.draw(canvas);
            }
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        EdgeEffectCompat edgeEffectCompat = this.mTopEdge;
        if (edgeEffectCompat != null) {
            Object obj = null;
            Object obj2 = 1;
            if (!edgeEffectCompat.isFinished()) {
                this.mTopEdge.draw(canvas);
                obj = 1;
            }
            if (this.mBottomEdge.isFinished()) {
                obj2 = obj;
            } else {
                int save = canvas.save();
                int width = getWidth();
                canvas.translate((float) (-width), (float) getHeight());
                canvas.rotate(180.0f, (float) width, 0.0f);
                this.mBottomEdge.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (obj2 != null) {
                invalidate();
            }
        }
    }

    public void beginFastChildLayout() {
        this.mFastChildLayout = true;
    }

    public void endFastChildLayout() {
        this.mFastChildLayout = false;
        populate(false);
    }

    public void requestLayout() {
        if (!this.mPopulating && !this.mFastChildLayout) {
            super.requestLayout();
        }
    }

    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        i = MeasureSpec.getSize(i);
        setMeasuredDimension(i, MeasureSpec.getSize(i2));
        if (this.mColCountSetting == -1) {
            i /= this.mMinColWidth;
            if (i != this.mColCount) {
                this.mColCount = i;
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.mInLayout = true;
        populate(false);
        this.mInLayout = false;
        i3 -= i;
        i4 -= i2;
        this.mTopEdge.setSize(i3, i4);
        this.mBottomEdge.setSize(i3, i4);
    }

    private void populate(boolean z) {
        if (getWidth() != 0 && getHeight() != 0) {
            int width;
            int i;
            if (this.mColCount == -1) {
                width = getWidth() / this.mMinColWidth;
                if (width != this.mColCount) {
                    this.mColCount = width;
                }
            }
            width = this.mColCount;
            if (this.mColMappings.size() != this.mColCount) {
                this.mColMappings.clear();
                for (i = 0; i < this.mColCount; i++) {
                    this.mColMappings.add(new ArrayList());
                }
            }
            int[] iArr = this.mItemTops;
            if (iArr == null || iArr.length != width) {
                this.mItemTops = new int[width];
                this.mItemBottoms = new int[width];
                this.mLayoutRecords.clear();
                if (this.mInLayout) {
                    removeAllViewsInLayout();
                } else {
                    removeAllViews();
                }
            }
            i = getPaddingTop();
            int i2 = 0;
            while (i2 < width) {
                int[] iArr2 = this.mRestoreOffsets;
                int min = (iArr2 != null ? Math.min(iArr2[i2], 0) : 0) + i;
                int[] iArr3 = this.mItemTops;
                iArr3[i2] = min == 0 ? iArr3[i2] : min;
                iArr3 = this.mItemBottoms;
                if (min == 0) {
                    min = iArr3[i2];
                }
                iArr3[i2] = min;
                i2++;
            }
            this.mPopulating = true;
            layoutChildren(this.mDataChanged);
            fillDown(this.mFirstPosition + getChildCount(), 0);
            fillUp(this.mFirstPosition - 1, 0);
            this.mPopulating = false;
            this.mDataChanged = false;
            if (z) {
                int[] iArr4 = this.mRestoreOffsets;
                if (iArr4 != null) {
                    Arrays.fill(iArr4, 0);
                }
            }
        }
    }

    public final void offsetChildren(int i) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            childAt.layout(childAt.getLeft(), childAt.getTop() + i, childAt.getRight(), childAt.getBottom() + i);
        }
        childCount = this.mColCount;
        for (int i3 = 0; i3 < childCount; i3++) {
            int[] iArr = this.mItemTops;
            iArr[i3] = iArr[i3] + i;
            iArr = this.mItemBottoms;
            iArr[i3] = iArr[i3] + i;
        }
    }

    public final void layoutChildren(boolean queryAdapter) {
        final int paddingLeft = getPaddingLeft();
        final int paddingRight = getPaddingRight();
        final int itemMargin = mItemMargin;
        final int colWidth = (getWidth() - paddingLeft - paddingRight - itemMargin * (mColCount - 1)) / mColCount;
        mColWidth = colWidth;
        int rebuildLayoutRecordsBefore = -1;
        int rebuildLayoutRecordsAfter = -1;

        Arrays.fill(mItemBottoms, Integer.MIN_VALUE);

        final int childCount = getChildCount();
        int amountRemoved = 0;

        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            LayoutParams lp = (LayoutParams) child.getLayoutParams();
            final int col = lp.column;
            final int position = mFirstPosition + i;
            final boolean needsLayout = queryAdapter || child.isLayoutRequested();

            if (queryAdapter) {

                View newView = obtainView(position, child);
                if(newView == null){
                    // child has been removed
                    removeViewAt(i);
                    if(i-1>=0) invalidateLayoutRecordsAfterPosition(i-1);
                    amountRemoved++;
                    continue;
                }else if (newView != child) {
                    removeViewAt(i);
                    addView(newView, i);
                    child = newView;
                }
                lp = (LayoutParams) child.getLayoutParams(); // Might have changed
            }

            final int span = Math.min(mColCount, lp.span);
            final int widthSize = colWidth * span + itemMargin * (span - 1);

            if (needsLayout) {
                final int widthSpec = MeasureSpec.makeMeasureSpec(widthSize, MeasureSpec.EXACTLY);

                final int heightSpec;
                if (lp.height == LayoutParams.WRAP_CONTENT) {
                    heightSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
                } else {
                    heightSpec = MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY);
                }

                child.measure(widthSpec, heightSpec);
            }

            int childTop = mItemBottoms[col] > Integer.MIN_VALUE ? mItemBottoms[col] + mItemMargin : child.getTop();

            if (span > 1) {
                int lowest = childTop;
                for (int j = col + 1; j < col + span; j++) {
                    final int bottom = mItemBottoms[j] + mItemMargin;
                    if (bottom > lowest) {
                        lowest = bottom;
                    }
                }
                childTop = lowest;
            }
            final int childHeight = child.getMeasuredHeight();
            final int childBottom = childTop + childHeight;
            final int childLeft = paddingLeft + col * (colWidth + itemMargin);
            final int childRight = childLeft + child.getMeasuredWidth();
            child.layout(childLeft, childTop, childRight, childBottom);

            for (int j = col; j < col + span; j++) {
                mItemBottoms[j] = childBottom;
            }

            final LayoutRecord rec = mLayoutRecords.get(position);
            if (rec != null && rec.height != childHeight) {
                rec.height = childHeight;
                rebuildLayoutRecordsBefore = position;
            }

            if (rec != null && rec.span != span) {
                rec.span = span;
                rebuildLayoutRecordsAfter = position;
            }
        }

        for (int i = 0; i < mColCount; i++) {
            if (mItemBottoms[i] == Integer.MIN_VALUE) {
                mItemBottoms[i] = mItemTops[i];
            }
        }

        if (rebuildLayoutRecordsBefore >= 0 || rebuildLayoutRecordsAfter >= 0) {
            if (rebuildLayoutRecordsBefore >= 0) {
                invalidateLayoutRecordsBeforePosition(rebuildLayoutRecordsBefore);
            }
            if (rebuildLayoutRecordsAfter >= 0) {
                invalidateLayoutRecordsAfterPosition(rebuildLayoutRecordsAfter);
            }
            for (int i = 0; i < (childCount - amountRemoved); i++) {
                final int position = mFirstPosition + i;
                final View child = getChildAt(i);
                final LayoutParams lp = (LayoutParams) child.getLayoutParams();
                LayoutRecord rec = mLayoutRecords.get(position);
                if (rec == null) {
                    rec = new LayoutRecord();
                    mLayoutRecords.put(position, rec);
                }
                rec.column = lp.column;
                rec.height = child.getHeight();
                rec.id = lp.id;
                rec.span = Math.min(mColCount, lp.span);
            }
        }

        if(this.mSelectorPosition != INVALID_POSITION){
            View child = getChildAt(mMotionPosition - mFirstPosition);
            if (child != null) positionSelector(mMotionPosition, child);
        } else if (mTouchMode > TOUCH_MODE_DOWN) {
            View child = getChildAt(mMotionPosition - mFirstPosition);
            if (child != null) positionSelector(mMotionPosition, child);
        } else {
            mSelectorRect.setEmpty();
        }
    }

    public final void invalidateLayoutRecordsBeforePosition(int i) {
        int i2 = 0;
        while (i2 < this.mLayoutRecords.size() && this.mLayoutRecords.keyAt(i2) < i) {
            i2++;
        }
        this.mLayoutRecords.removeAtRange(0, i2);
    }

    public final void invalidateLayoutRecordsAfterPosition(int i) {
        int size = this.mLayoutRecords.size() - 1;
        while (size >= 0 && this.mLayoutRecords.keyAt(size) > i) {
            size--;
        }
        size++;
        SparseArrayCompat sparseArrayCompat = this.mLayoutRecords;
        sparseArrayCompat.removeAtRange(size + 1, sparseArrayCompat.size() - size);
    }

    public final int fillUp(int fromPosition, int overhang) {
        final int paddingLeft = getPaddingLeft();
        final int paddingRight = getPaddingRight();
        final int itemMargin = mItemMargin;
        final int colWidth =
                (getWidth() - paddingLeft - paddingRight - itemMargin * (mColCount - 1)) / mColCount;
        mColWidth = colWidth;
        final int gridTop = getPaddingTop();
        final int fillTo = gridTop - overhang;
        int nextCol = getNextColumnUp();
        int position = fromPosition;

        while (nextCol >= 0 && mItemTops[nextCol] > fillTo && position >= 0) {

            if(!mColMappings.get(nextCol).contains((Integer) position)){
                for(int i=0; i < mColMappings.size(); i++){
                    if(mColMappings.get(i).contains((Integer) position)){
                        nextCol = i;
                        break;
                    }
                }
            }

//        	displayMapping();

            final View child = obtainView(position, null);

            if(child == null) continue;

            LayoutParams lp = (LayoutParams) child.getLayoutParams();

            if(lp == null){
                lp = this.generateDefaultLayoutParams();
                child.setLayoutParams(lp);
            }

            if (child.getParent() != this) {
                if (mInLayout) {
                    addViewInLayout(child, 0, lp);
                } else {
                    addView(child, 0);
                }
            }

            final int span = Math.min(mColCount, lp.span);
            final int widthSize = colWidth * span + itemMargin * (span - 1);
            final int widthSpec = MeasureSpec.makeMeasureSpec(widthSize, MeasureSpec.EXACTLY);

            LayoutRecord rec;
            if (span > 1) {
                rec = getNextRecordUp(position, span);
//                nextCol = rec.column;
            } else {
                rec = mLayoutRecords.get(position);
            }

            boolean invalidateBefore = false;
            if (rec == null) {
                rec = new LayoutRecord();
                mLayoutRecords.put(position, rec);
                rec.column = nextCol;
                rec.span = span;
            } else if (span != rec.span) {
                rec.span = span;
                rec.column = nextCol;
                invalidateBefore = true;
            } else {
//                nextCol = rec.column;
            }

            if (mHasStableIds) {
                final long id = mAdapter.getItemId(position);
                rec.id = id;
                lp.id = id;
            }

            lp.column = nextCol;

            final int heightSpec;
            if (lp.height == LayoutParams.WRAP_CONTENT) {
                heightSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
            } else {
                heightSpec = MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY);
            }
            child.measure(widthSpec, heightSpec);

            final int childHeight = child.getMeasuredHeight();
            if (invalidateBefore || (childHeight != rec.height && rec.height > 0)) {
                invalidateLayoutRecordsBeforePosition(position);
            }
            rec.height = childHeight;

            int itemTop = mItemTops[nextCol];

            final int startFrom;
            if (span > 1) {
                int highest = mItemTops[nextCol];
                for (int i = nextCol + 1; i < nextCol + span; i++) {
                    final int top = mItemTops[i];
                    if (top < highest) {
                        highest = top;
                    }
                }
                startFrom = highest;
            } else {
                startFrom = mItemTops[nextCol];
            }


            int childBottom = startFrom;
            int childTop = childBottom - childHeight;
            final int childLeft = paddingLeft + nextCol * (colWidth + itemMargin);
            final int childRight = childLeft + child.getMeasuredWidth();

//            if(position == 0){
//            	if(this.getChildCount()>1 && this.mColCount>1){
//            		childTop = this.getChildAt(1).getTop();
//            		childBottom = childTop + childHeight;
//            	}
//            }

            child.layout(childLeft, childTop, childRight, childBottom);


            for (int i = nextCol; i < nextCol + span; i++) {
                mItemTops[i] = childTop - rec.getMarginAbove(i-nextCol) - itemMargin;
            }

            nextCol = getNextColumnUp();
            mFirstPosition = position--;
        }

        int highestView = getHeight();

        for (int i = 0; i < mColCount; i++) {
            final View child = getFirstChildAtColumn(i);
            if(child == null){
                highestView = 0;
                break;
            }
            final int top = child.getTop();

            if (top < highestView) {
                highestView = top;
            }
        }

        return gridTop - highestView;
    }

    private View getFirstChildAtColumn(int i) {
        if (getChildCount() > i) {
            for (int i2 = 0; i2 < this.mColCount; i2++) {
                View childAt = getChildAt(i2);
                int left = childAt.getLeft();
                if (childAt != null) {
                    int i3 = 0;
                    while (left > ((this.mColWidth + (this.mItemMargin * 2)) * i3) + getPaddingLeft()) {
                        i3++;
                    }
                    if (i3 == i) {
                        return childAt;
                    }
                }
            }
        }
        return null;
    }

    public final int fillDown(int fromPosition, int overhang) {

        final int paddingLeft = getPaddingLeft();
        final int paddingRight = getPaddingRight();
        final int itemMargin = mItemMargin;
        final int colWidth = (getWidth() - paddingLeft - paddingRight - itemMargin * (mColCount - 1)) / mColCount;
        final int gridBottom = getHeight() - getPaddingBottom();
        final int fillTo = gridBottom + overhang;
        int nextCol = getNextColumnDown(fromPosition);
        int position = fromPosition;

        while (nextCol >= 0 && mItemBottoms[nextCol] < fillTo && position < mItemCount) {

            final View child = obtainView(position, null);

            if(child == null) continue;

            LayoutParams lp = (LayoutParams) child.getLayoutParams();
            if(lp == null){
                lp = this.generateDefaultLayoutParams();
                child.setLayoutParams(lp);
            }
            if (child.getParent() != this) {
                if (mInLayout) {
                    addViewInLayout(child, -1, lp);
                } else {
                    addView(child);
                }
            }

            final int span = Math.min(mColCount, lp.span);
            final int widthSize = colWidth * span + itemMargin * (span - 1);
            final int widthSpec = MeasureSpec.makeMeasureSpec(widthSize, MeasureSpec.EXACTLY);

            LayoutRecord rec;
            if (span > 1) {
                rec = getNextRecordDown(position, span);
//                nextCol = rec.column;
            } else {
                rec = mLayoutRecords.get(position);
            }

            boolean invalidateAfter = false;
            if (rec == null) {
                rec = new LayoutRecord();
                mLayoutRecords.put(position, rec);
                rec.column = nextCol;
                rec.span = span;
            } else if (span != rec.span) {
                rec.span = span;
                rec.column = nextCol;
                invalidateAfter = true;
            } else {
//                nextCol = rec.column;
            }

            if (mHasStableIds) {
                final long id = mAdapter.getItemId(position);
                rec.id = id;
                lp.id = id;
            }

            lp.column = nextCol;

            final int heightSpec;
            if (lp.height == LayoutParams.WRAP_CONTENT) {
                heightSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
            } else {
                heightSpec = MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY);
            }
            child.measure(widthSpec, heightSpec);

            final int childHeight = child.getMeasuredHeight();
            if (invalidateAfter || (childHeight != rec.height && rec.height > 0)) {
                invalidateLayoutRecordsAfterPosition(position);
            }
            rec.height = childHeight;

            final int startFrom;
            if (span > 1) {
                int lowest = mItemBottoms[nextCol];
                for (int i = nextCol + 1; i < nextCol + span; i++) {
                    final int bottom = mItemBottoms[i];
                    if (bottom > lowest) {
                        lowest = bottom;
                    }
                }
                startFrom = lowest;
            } else {
                startFrom = mItemBottoms[nextCol];
            }



            final int childTop = startFrom + itemMargin;
            final int childBottom = childTop + childHeight;
            final int childLeft = paddingLeft + nextCol * (colWidth + itemMargin);
            final int childRight = childLeft + child.getMeasuredWidth();
            child.layout(childLeft, childTop, childRight, childBottom);


            if(!mColMappings.get(nextCol).contains(position)){

                for(ArrayList<Integer> list : mColMappings){
                    if(list.contains(position)){
                        list.remove((Integer) position);
                    }
                }

                mColMappings.get(nextCol).add(position);

            }


            for (int i = nextCol; i < nextCol + span; i++) {
                mItemBottoms[i] = childBottom + rec.getMarginBelow(i - nextCol);
            }


            position++;
            nextCol = getNextColumnDown(position);
        }

        int lowestView = 0;
        for (int i = 0; i < mColCount; i++) {
            if (mItemBottoms[i] > lowestView) {
                lowestView = mItemBottoms[i];
            }
        }
        return lowestView - gridBottom;
    }

    private void displayMapping() {
        String str = "DISPLAY";
        StringBuilder stringBuilder = new StringBuilder();
        Iterator it = this.mColMappings.iterator();
        int i = 0;
        while (it.hasNext()) {
            ArrayList arrayList = (ArrayList) it.next();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("COL");
            stringBuilder2.append(i);
            stringBuilder2.append(":");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(' ');
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                stringBuilder.append((Integer) it2.next());
                stringBuilder.append(" , ");
            }
            Log.w(str, stringBuilder.toString());
            stringBuilder = new StringBuilder();
            i++;
        }
    }

    public final int getNextColumnUp() {
        int i = -1;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = this.mColCount - 1; i3 >= 0; i3--) {
            int i4 = this.mItemTops[i3];
            if (i4 > i2) {
                i = i3;
                i2 = i4;
            }
        }
        return i;
    }

    public final LayoutRecord getNextRecordUp(int i, int i2) {
        int i3;
        LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(i);
        if (layoutRecord == null) {
            layoutRecord = new LayoutRecord();
            layoutRecord.span = i2;
            this.mLayoutRecords.put(i, layoutRecord);
        } else if (layoutRecord.span != i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid LayoutRecord! Record had span=");
            stringBuilder.append(layoutRecord.span);
            stringBuilder.append(" but caller requested span=");
            stringBuilder.append(i2);
            stringBuilder.append(" for position=");
            stringBuilder.append(i);
            throw new IllegalStateException(stringBuilder.toString());
        }
        i = Integer.MIN_VALUE;
        int i4 = -1;
        for (i3 = this.mColCount - i2; i3 >= 0; i3--) {
            int i5 = Integer.MAX_VALUE;
            for (int i6 = i3; i6 < i3 + i2; i6++) {
                int i7 = this.mItemTops[i6];
                if (i7 < i5) {
                    i5 = i7;
                }
            }
            if (i5 > i) {
                i4 = i3;
                i = i5;
            }
        }
        layoutRecord.column = i4;
        for (i3 = 0; i3 < i2; i3++) {
            layoutRecord.setMarginBelow(i3, this.mItemTops[i3 + i4] - i);
        }
        return layoutRecord;
    }

    public final int getNextColumnDown(int i) {
        i = this.mColCount;
        int i2 = -1;
        int i3 = Integer.MAX_VALUE;
        for (int i4 = 0; i4 < i; i4++) {
            int i5 = this.mItemBottoms[i4];
            if (i5 < i3) {
                i2 = i4;
                i3 = i5;
            }
        }
        return i2;
    }

    public final LayoutRecord getNextRecordDown(int i, int i2) {
        LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(i);
        if (layoutRecord == null) {
            layoutRecord = new LayoutRecord();
            layoutRecord.span = i2;
            this.mLayoutRecords.put(i, layoutRecord);
        } else if (layoutRecord.span != i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid LayoutRecord! Record had span=");
            stringBuilder.append(layoutRecord.span);
            stringBuilder.append(" but caller requested span=");
            stringBuilder.append(i2);
            stringBuilder.append(" for position=");
            stringBuilder.append(i);
            throw new IllegalStateException(stringBuilder.toString());
        }
        i = -1;
        int i3 = Integer.MAX_VALUE;
        int i4 = this.mColCount;
        for (int i5 = 0; i5 <= i4 - i2; i5++) {
            int i6 = Integer.MIN_VALUE;
            for (int i7 = i5; i7 < i5 + i2; i7++) {
                int i8 = this.mItemBottoms[i7];
                if (i8 > i6) {
                    i6 = i8;
                }
            }
            if (i6 < i3) {
                i = i5;
                i3 = i6;
            }
        }
        layoutRecord.column = i;
        for (int i9 = 0; i9 < i2; i9++) {
            layoutRecord.setMarginAbove(i9, i3 - this.mItemBottoms[i9 + i]);
        }
        return layoutRecord;
    }

    public final View obtainView(int i, View view) {
        View transientStateView = this.mRecycler.getTransientStateView(i);
        if (transientStateView != null) {
            return transientStateView;
        }
        if (i >= this.mAdapter.getCount()) {
            return null;
        }
        int i2 = view != null ? ((LayoutParams) view.getLayoutParams()).viewType : -1;
        int itemViewType = this.mAdapter.getItemViewType(i);
        if (i2 != itemViewType) {
            view = this.mRecycler.getScrapView(itemViewType);
        }
        transientStateView = this.mAdapter.getView(i, view, this);
        if (!(transientStateView == view || view == null)) {
            this.mRecycler.addScrap(view);
        }
        ViewGroup.LayoutParams layoutParams = transientStateView.getLayoutParams();
        if (transientStateView.getParent() != this) {
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
            } else if (!checkLayoutParams(layoutParams)) {
                layoutParams = generateLayoutParams(layoutParams);
            }
        }
        LayoutParams layoutParams2 = (LayoutParams) layoutParams;
        layoutParams2.position = i;
        layoutParams2.viewType = itemViewType;
        return transientStateView;
    }

    public ListAdapter getAdapter() {
        return this.mAdapter;
    }

    public void setAdapter(ListAdapter listAdapter) {
        ListAdapter listAdapter2 = this.mAdapter;
        if (listAdapter2 != null) {
            listAdapter2.unregisterDataSetObserver(this.mObserver);
        }
        clearAllState();
        this.mAdapter = listAdapter;
        boolean z = true;
        this.mDataChanged = true;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.mObserver);
            this.mRecycler.setViewTypeCount(listAdapter.getViewTypeCount());
            this.mHasStableIds = listAdapter.hasStableIds();
        } else {
            this.mHasStableIds = false;
        }
        if (listAdapter == null) {
            z = false;
        }
        populate(z);
    }

    private void clearAllState() {
        this.mLayoutRecords.clear();
        removeAllViews();
        resetStateForGridTop();
        this.mRecycler.clear();
        this.mSelectorRect.setEmpty();
        this.mSelectorPosition = -1;
    }

    private void resetStateForGridTop() {
        int i = this.mColCount;
        int[] iArr = this.mItemTops;
        if (iArr == null || iArr.length != i) {
            this.mItemTops = new int[i];
            this.mItemBottoms = new int[i];
        }
        i = getPaddingTop();
        Arrays.fill(this.mItemTops, i);
        Arrays.fill(this.mItemBottoms, i);
        this.mFirstPosition = 0;
        iArr = this.mRestoreOffsets;
        if (iArr != null) {
            Arrays.fill(iArr, 0);
        }
    }

    public void setSelectionToTop() {
        removeAllViews();
        resetStateForGridTop();
        populate(false);
    }

    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2);
    }

    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        int i = this.mFirstPosition;
        savedState.position = i;
        if (i >= 0) {
            ListAdapter listAdapter = this.mAdapter;
            if (listAdapter != null && i < listAdapter.getCount()) {
                savedState.firstId = this.mAdapter.getItemId(i);
            }
        }
        if (getChildCount() > 0) {
            int[] iArr = new int[this.mColCount];
            if (this.mColWidth > 0) {
                for (int i2 = 0; i2 < this.mColCount; i2++) {
                    if (getChildAt(i2) != null) {
                        int left = getChildAt(i2).getLeft();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(this.mColWidth);
                        stringBuilder.append(" ");
                        stringBuilder.append(left);
                        Log.w("mColWidth", stringBuilder.toString());
                        int i3 = 0;
                        while (left > ((this.mColWidth + (this.mItemMargin * 2)) * i3) + getPaddingLeft()) {
                            i3++;
                        }
                        iArr[i3] = (getChildAt(i2).getTop() - this.mItemMargin) - getPaddingTop();
                    }
                }
            }
            savedState.topOffsets = iArr;
            ArrayList arrayList = new ArrayList();
            Iterator it = this.mColMappings.iterator();
            while (it.hasNext()) {
                arrayList.add(new ColMap((ArrayList) it.next()));
            }
            savedState.mapping = arrayList;
        }
        return savedState;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.mDataChanged = true;
        this.mFirstPosition = savedState.position;
        this.mRestoreOffsets = savedState.topOffsets;
        ArrayList arrayList = savedState.mapping;
        if (arrayList != null) {
            this.mColMappings.clear();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                this.mColMappings.add(((ColMap) it.next()).values);
            }
        }
        if (savedState.firstId >= 0) {
            this.mFirstAdapterId = savedState.firstId;
            this.mSelectorPosition = -1;
        }
        requestLayout();
    }
    private void useDefaultSelector() {
        setSelector(getResources().getDrawable(android.R.drawable.list_selector_background));
    }

    public void positionSelector(int i, View view) {
        if (i != -1) {
            this.mSelectorPosition = i;
        }
        Rect rect = this.mSelectorRect;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        if (view instanceof SelectionBoundsAdjuster) {
            ((SelectionBoundsAdjuster) view).adjustListItemSelectionBounds(rect);
        }
        positionSelector(rect.left, rect.top, rect.right, rect.bottom);
        boolean z = this.mIsChildViewEnabled;
        if (view.isEnabled() != z) {
            this.mIsChildViewEnabled = z;
            if (getSelectedItemPosition() != -1) {
                refreshDrawableState();
            }
        }
    }

    private int getSelectedItemPosition() {
        return this.mSelectorPosition;
    }

    public int[] onCreateDrawableState(int i) {
        if (this.mIsChildViewEnabled) {
            return super.onCreateDrawableState(i);
        }
        int i2 = ENABLED_STATE_SET[0];
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        int length = onCreateDrawableState.length - 1;
        while (length >= 0) {
            if (onCreateDrawableState[length] == i2) {
                break;
            }
            length--;
        }
        length = -1;
        if (length >= 0) {
            System.arraycopy(onCreateDrawableState, length + 1, onCreateDrawableState, length, (onCreateDrawableState.length - length) - 1);
        }
        return onCreateDrawableState;
    }

    private void positionSelector(int i, int i2, int i3, int i4) {
        this.mSelectorRect.set(i - this.mSelectionLeftPadding, i2 - this.mSelectionTopPadding, i3 + this.mSelectionRightPadding, i4 + this.mSelectionBottomPadding);
    }

    public boolean performItemClick(View view, int i, long j) {
        if (this.mOnItemClickListener == null) {
            return false;
        }
        playSoundEffect(0);
        if (view != null) {
            view.sendAccessibilityEvent(1);
        }
        this.mOnItemClickListener.onItemClick(this, view, i, j);
        return true;
    }

    public boolean performLongPress(View view, int i, long j) {
        OnItemLongClickListener onItemLongClickListener = this.mOnItemLongClickListener;
        boolean onItemLongClick = onItemLongClickListener != null ? onItemLongClickListener.onItemLongClick(this, view, i, j) : false;
        if (!onItemLongClick) {
            this.mContextMenuInfo = createContextMenuInfo(view, i, j);
            onItemLongClick = super.showContextMenuForChild(this);
        }
        if (onItemLongClick) {
            performHapticFeedback(0);
        }
        return onItemLongClick;
    }

    public ContextMenuInfo getContextMenuInfo() {
        return this.mContextMenuInfo;
    }

    public ContextMenuInfo createContextMenuInfo(View view, int i, long j) {
        return new AdapterContextMenuInfo(view, i, j);
    }

    public Drawable getSelector() {
        return this.mSelector;
    }

    public void setSelector(int i) {
        setSelector(getResources().getDrawable(i));
    }

    public boolean verifyDrawable(Drawable drawable) {
        return this.mSelector == drawable || super.verifyDrawable(drawable);
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.mSelector;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public void setSelector(Drawable drawable) {
        Drawable drawable2 = this.mSelector;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.mSelector);
        }
        this.mSelector = drawable;
        if (drawable != null) {
            Rect rect = new Rect();
            drawable.getPadding(rect);
            this.mSelectionLeftPadding = rect.left;
            this.mSelectionTopPadding = rect.top;
            this.mSelectionRightPadding = rect.right;
            this.mSelectionBottomPadding = rect.bottom;
            drawable.setCallback(this);
            updateSelectorState();
        }
    }

    public void updateSelectorState() {
        if (this.mSelector == null) {
            return;
        }
        if (shouldShowSelector()) {
            this.mSelector.setState(getDrawableState());
            return;
        }
        this.mSelector.setState(new int[]{0});
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        updateSelectorState();
    }

    public boolean shouldShowSelector() {
        return ((hasFocus() && !isInTouchMode()) || touchModeDrawsInPressedState()) && this.mBeginClick;
    }

    public boolean touchModeDrawsInPressedState() {
        int i = this.mTouchMode;
        return i == 4 || i == 5;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public final OnItemClickListener getOnItemClickListener() {
        return this.mOnItemClickListener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener onItemLongClickListener) {
        if (!isLongClickable()) {
            setLongClickable(true);
        }
        this.mOnItemLongClickListener = onItemLongClickListener;
    }

    public final OnItemLongClickListener getOnItemLongClickListener() {
        return this.mOnItemLongClickListener;
    }

    public int pointToPosition(int i, int i2) {
        Rect rect = this.mTouchFrame;
        if (rect == null) {
            rect = new Rect();
            this.mTouchFrame = rect;
        }
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (childAt.getVisibility() == VISIBLE) {
                childAt.getHitRect(rect);
                if (rect.contains(i, i2)) {
                    return this.mFirstPosition + childCount;
                }
            }
        }
        return -1;
    }

    public boolean isDrawSelectorOnTop() {
        return this.mDrawSelectorOnTop;
    }

    public void setDrawSelectorOnTop(boolean z) {
        this.mDrawSelectorOnTop = z;
    }
}
