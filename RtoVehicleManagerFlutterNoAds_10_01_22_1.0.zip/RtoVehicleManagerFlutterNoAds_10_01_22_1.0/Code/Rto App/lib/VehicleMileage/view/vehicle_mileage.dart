import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:lottie/lottie.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/VehicleMileage/controller/vehicle_mileage_controller.dart';
import 'package:rto_app/VehicleMileage/view/vehicle_mileage_calculation.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';

class VehicleMileage extends StatelessWidget {
  VehicleMileageController controller = Get.put(VehicleMileageController());
  @override
  Widget build(BuildContext context) {
    controller.getAllData();
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).primaryColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Vehicle Mileage",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ).centered(),
                    leading: Container(
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Future.delayed(const Duration(milliseconds: 350),
                                  () {
                                Navigator.pop(context);
                              });
                            },
                            icon: Hero(
                              tag: "vehicleexpense",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).dividerColor,
                                size: 20,
                              ).pOnly(left: 5),
                            )),
                      ),
                    ),
                    actions: [
                      IconButton(
                        onPressed: () {
                          Get.to(VehicleMileageCalculation());
                        },
                        icon: Hero(
                            tag: "mileage",
                            transitionOnUserGestures: true,
                            child: (Icon(
                              CupertinoIcons.add_circled,
                              color: Theme.of(context).dividerColor,
                              size: 24,
                            ))),
                        iconSize: 30,
                      ).pOnly(right: 8),
                    ],
                  )
                ];
              },
              body: Column(
                children: [
                  Expanded(
                    child: GetBuilder<VehicleMileageController>(
                      builder: (controller) {
                        return controller.mileageDataList.isEmpty
                            ? Center(
                                child: Container(
                                  color: Theme.of(context).primaryColor,
                                  child: Center(
                                    child: noExpenseMethod(),
                                  ),
                                ),
                              )
                            : Container(
                                color: Theme.of(context).primaryColor,
                                child: ListView.builder(
                                    physics: BouncingScrollPhysics(),
                                    itemCount:
                                        controller.mileageDataList.length,
                                    itemBuilder: (context, index) {
                                      return Container(
                                          child: SingleChildScrollView(
                                        physics: BouncingScrollPhysics(),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              child: Card(
                                                color: Theme.of(context)
                                                    .canvasColor,
                                                elevation: 0,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10)),
                                                child: SizedBox(
                                                  child: Column(
                                                    children: [
                                                      Card(
                                                        color: Theme.of(context)
                                                            .primaryColor,
                                                        elevation: 0,
                                                        shape:
                                                            RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8)),
                                                        child: Align(
                                                          alignment: Alignment
                                                              .topCenter,
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Text(
                                                                controller
                                                                    .mileageDataList[
                                                                        index]
                                                                    .date,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        20,
                                                                    color: Theme.of(
                                                                            context)
                                                                        .accentColor,
                                                                    fontFamily:
                                                                        "Circular Medium"),
                                                              ),
                                                              IconButton(
                                                                  onPressed:
                                                                      () {
                                                                    CommanDialog.deleteMileageDataDialog(
                                                                        context,
                                                                        "Are you sure want to delete ?",
                                                                        controller,
                                                                        controller
                                                                            .mileageDataList[index]
                                                                            .randomId,
                                                                        "mileage");
                                                                  },
                                                                  icon: Icon(
                                                                    CupertinoIcons
                                                                        .delete,
                                                                    size: 20,
                                                                  ))
                                                            ],
                                                          ),
                                                        ).py(5).px(10),
                                                      ).px(10).py(5),
                                                      Align(
                                                        alignment:
                                                            Alignment.topCenter,
                                                        child: Text(
                                                          "You spend ${controller.mileageDataList[index].totalprice} for ${controller.mileageDataList[index].totalfuel} liter fuel",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              color: Colors
                                                                  .redAccent,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ).py(5).px(10),
                                                      Align(
                                                        alignment:
                                                            Alignment.topCenter,
                                                        child: Text(
                                                          "${controller.mileageDataList[index].currentreserve} - ${controller.mileageDataList[index].lastreserve} = ${double.parse(controller.mileageDataList[index].currentreserve) - double.parse(controller.mileageDataList[index].lastreserve)} Km you travelled",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              color:
                                                                  Colors.grey,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ).py(5).px(10),
                                                      Card(
                                                        color: Theme.of(context)
                                                            .primaryColor,
                                                        elevation: 0,
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10)),
                                                        child: Align(
                                                          alignment:
                                                              Alignment.topLeft,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                  child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets.all(
                                                                              10),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              controller.mileageDataList[index].kmperltr,
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 20, color: Theme.of(context).hintColor, fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              "Km / Ltr",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 10, color: Color(0xff757381), fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ).pOnly(
                                                                              top: 5)
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child:
                                                                        Container(
                                                                      color: Colors
                                                                          .blueGrey,
                                                                      height:
                                                                          50,
                                                                      width:
                                                                          0.2,
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets.all(
                                                                              10),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              controller.mileageDataList[index].rsperltr,
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 20, color: Theme.of(context).hintColor, fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              "Rs / Ltr",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 10, color: Color(0xff757381), fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ).pOnly(
                                                                              top: 5)
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child:
                                                                        Container(
                                                                      color: Colors
                                                                          .blueGrey,
                                                                      height:
                                                                          50,
                                                                      width:
                                                                          0.2,
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets.all(
                                                                              10),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              controller.mileageDataList[index].rsperkm,
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 20, color: Theme.of(context).hintColor, fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            child:
                                                                                Text(
                                                                              "Rs / Km",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 10, color: Color(0xff757381), fontFamily: "Circular Medium"),
                                                                            ),
                                                                          ).pOnly(
                                                                              top: 5)
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              )),
                                                            ],
                                                          ),
                                                        ),
                                                      ).px(5).py(5),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ).py(2),
                                          ],
                                        ),
                                      ));
                                    }).px(10).py(10),
                              );
                      },
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

noExpenseMethod() {
  return Container(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Lottie.asset(
          "assets/lottie/add_data.json",
          height: 200,
          width: 200,
        ),
        Text("Please add vehicle mileage data",
            style: TextStyle(
                fontFamily: "Circular Medium",
                fontSize: 12,
                color: Colors.grey))
      ],
    ).pOnly(bottom: 80),
  );
}
