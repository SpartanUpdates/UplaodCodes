package com.kotlinz.videoCollage.puzzleview;

import android.content.Intent;
import android.graphics.Bitmap.Config;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoCollage.flying.puzzle.PuzzleLayout;
import com.kotlinz.videoCollage.flying.puzzle.slant.SlantPuzzleLayout;
import com.kotlinz.videoeditor.R;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

public class PlaygroundActivity extends AppCompatActivity {

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_playground);
        initView();
        prefetchResPhoto();
    }

    private void prefetchResPhoto() {
        int[] iArr = new int[]{R.drawable.demo1, R.drawable.demo2, R.drawable.demo3, R.drawable.demo4, R.drawable.demo5, R.drawable.demo6, R.drawable.demo7, R.drawable.demo8, R.drawable.demo9};
        for (int i = 0; i < 9; i++) {
            Picasso.get().load(iArr[i]).memoryPolicy(MemoryPolicy.NO_CACHE, new MemoryPolicy[0]).config(Config.RGB_565).fetch();
        }
    }

    private void initView() {
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.puzzle_list);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        PuzzleAdapter puzzleAdapter = new PuzzleAdapter(this, "more");
        recyclerView.setAdapter(puzzleAdapter);
        puzzleAdapter.refreshData(PuzzleUtils.getAllPuzzleLayouts(), null);
        puzzleAdapter.setOnItemClickListener(new PuzzleAdapter.OnItemClickListener() {
            public void onItemClick(PuzzleLayout puzzleLayout, int i) {
                Intent intent = new Intent(PlaygroundActivity.this, GridActivity.class);
                String str = "type";
                if (puzzleLayout instanceof SlantPuzzleLayout) {
                    intent.putExtra(str, 0);
                } else {
                    intent.putExtra(str, 1);
                }
                intent.putExtra("piece_size", puzzleLayout.getAreaCount());
                intent.putExtra("theme_id", i);
                PlaygroundActivity.this.startActivity(intent);
            }
        });
        ((ImageView) findViewById(R.id.btn_cancel)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PlaygroundActivity.this.onBackPressed();
            }
        });
    }
}
