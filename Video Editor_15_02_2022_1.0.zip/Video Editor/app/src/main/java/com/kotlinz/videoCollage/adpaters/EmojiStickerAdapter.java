package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.kotlinz.videoCollage.interfaces.EmojiStickerAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class EmojiStickerAdapter extends Adapter<EmojiStickerAdapter.ViewHolder> {
    private Context context;
    private int height;
    private ArrayList<String> listImage;
    private EmojiStickerAdapterCallBackInterface listener;
    private int pos = -1;
    private int width;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgBgImage;
        ImageView imgBgImageSelector;
        LinearLayout mainView;
        TextView txtName;

        ViewHolder(View view) {
            super(view);
            this.imgBgImage = (ImageView) view.findViewById(R.id.img_bg_image);
            this.imgBgImageSelector = (ImageView) view.findViewById(R.id.img_bg_image_selector);
            this.txtName = (TextView) view.findViewById(R.id.bg_image_text);
            this.mainView = (LinearLayout) view.findViewById(R.id.main_sticker_lin);
        }
    }

    public EmojiStickerAdapter(ArrayList<String> arrayList, Context context, EmojiStickerAdapterCallBackInterface emojiStickerAdapterCallBackInterface) {
        this.listImage = arrayList;
        this.listener = emojiStickerAdapterCallBackInterface;
        this.context = context;
        Display defaultDisplay = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.width = point.x;
        this.height = point.y;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_sticker_cate_one, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = (String) this.listImage.get(i);
        RequestManager with = Glide.with(this.context);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///android_asset/stickers/emoji/");
        stringBuilder.append(str);
        ((RequestBuilder) with.load(Uri.parse(stringBuilder.toString())).diskCacheStrategy(DiskCacheStrategy.NONE)).into(viewHolder.imgBgImage);
        viewHolder.imgBgImage.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EmojiStickerAdapter.this.pos = i;
                EmojiStickerAdapter.this.listener.itemClick(i);
                EmojiStickerAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgBgImageSelector.setBackgroundResource(R.drawable.bg_round_selector_sticker);
        } else {
            viewHolder.imgBgImageSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
        notifyDataSetChanged();
    }

    public int getItemCount() {
        return this.listImage.size();
    }
}
