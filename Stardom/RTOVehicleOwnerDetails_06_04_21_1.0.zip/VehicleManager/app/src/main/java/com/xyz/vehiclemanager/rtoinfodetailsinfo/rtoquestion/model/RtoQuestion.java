package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RtoQuestion
{
    @SerializedName("data")
    public ArrayList<RtoQuestion> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("question")
    public String question;
    @SerializedName("answer")
    public String answer;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public ArrayList<RtoQuestion> getData() {
        return data;
    }

    public void setData(ArrayList<RtoQuestion> data) {
        this.data = data;
    }
}
