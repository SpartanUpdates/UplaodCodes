package com.kotlinz.festivalstorymaker.Download;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadTemplateImage {
    private FestivalDetailActivity_New activity;
    ImageView ivFestival;
    private String TemplateImagePath;
    private String TemplateImageName;
    com.kotlinz.festivalstorymaker.Other.Utils utils;

    public DownloadTemplateImage(FestivalDetailActivity_New activity,ImageView ivfestival, String templateImagePath, String templateImageName, com.kotlinz.festivalstorymaker.Other.Utils utils) {
        this.activity = activity;
        this.ivFestival=ivfestival;
        this.TemplateImagePath = templateImagePath;
        this.TemplateImageName = templateImageName;
        this.utils = utils;
        //Download Template
        new DownloadingTemplateImageTask().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingTemplateImageTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            utils.c(activity.getString(com.kotlinz.festivalstorymaker.R.string.loading));
            utils.m();
        }

        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                    activity.k0 = com.kotlinz.festivalstorymaker.Other.Utils.n0(TemplateImagePath);
                    ivFestival.setImageURI(Uri.parse(activity.k0));
                    activity.R0(activity.k0);
                    utils.u();
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getTemplateImage() + File.separator + TemplateImageName);
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getTemplateImage() + File.separator + TemplateImageName);
            }
            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(TemplateImagePath);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e("TAG", "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                //Get File if SD card is present
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getTemplateImage());
                } else
                    Toast.makeText(activity, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }

                outputFile = new File(apkStorage, TemplateImageName);
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }

                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();
            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
