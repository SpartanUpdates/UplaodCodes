﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;

namespace BallCollect
{
    public class RewardAddShow : MonoBehaviour
    {
        public static RewardAddShow instance;
        
        [HideInInspector]
        public RewardBasedVideoAd rewardBasedVideo;

        public void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            RequestRewardBasedVideo();
        }
        private void OnEnable()
        {
            this.rewardBasedVideo.OnAdLoaded += RewardBasedVideoLoaded;
            this.rewardBasedVideo.OnAdFailedToLoad += RewardBasedVideoFailedToLoad;
            this.rewardBasedVideo.OnAdOpening += RewardBasedVideoOpened;
            this.rewardBasedVideo.OnAdStarted += RewardBasedVideoStarted;
            this.rewardBasedVideo.OnAdRewarded += RewardBasedVideoRewarded;
            this.rewardBasedVideo.OnAdClosed += RewardBasedVideoClosed;
            this.rewardBasedVideo.OnAdLeavingApplication += RewardBasedVideoLeftApplication;
        }
        private void OnDisable()
        {
            this.rewardBasedVideo.OnAdLoaded -= RewardBasedVideoLoaded;
            this.rewardBasedVideo.OnAdFailedToLoad -= RewardBasedVideoFailedToLoad;
            this.rewardBasedVideo.OnAdOpening -= RewardBasedVideoOpened;
            this.rewardBasedVideo.OnAdStarted -= RewardBasedVideoStarted;
            this.rewardBasedVideo.OnAdRewarded -= RewardBasedVideoRewarded;
            this.rewardBasedVideo.OnAdClosed -= RewardBasedVideoClosed;
            this.rewardBasedVideo.OnAdLeavingApplication -= RewardBasedVideoLeftApplication;
        }

        public void RequestRewardBasedVideo()
        {
            rewardBasedVideo = RewardBasedVideoAd.Instance;

            AdRequest request = new AdRequest.Builder().Build();

            rewardBasedVideo.LoadAd(request, Manager.instance.RewardID);
        }

        public void ShowVideo()
        {
            if (rewardBasedVideo.IsLoaded())
            {
                rewardBasedVideo.Show();
            }
            else
            {
                RequestRewardBasedVideo();
            }
        }
       
        bool isVideoSkip = true;

        public void RewardBasedVideoLoaded(object sender, EventArgs args)
        {

        }

        public void RewardBasedVideoFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            
        }

        public void RewardBasedVideoOpened(object sender, EventArgs args)
        {
            GameController.instance.noAddPanel.SetActive(true);
        }

        public void RewardBasedVideoStarted(object sender, EventArgs args)
        {
        }

        public void RewardBasedVideoClosed(object sender, EventArgs args)
        {
            if (!isVideoSkip)
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = true;
                    MainMenu.instance.RewardDone();
                }
                else
                {
                    GameController.instance.SaveMe();
                }
            }
            else
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = false;
                    MainMenu.instance.RewardDone();
                }
                else
                {
                    GameController.instance.SkipVideoAdd();
                }
            }
            isVideoSkip = true;
            RequestRewardBasedVideo();
        }

        public void RewardBasedVideoRewarded(object sender, Reward args)
        {
            isVideoSkip = false;
        }

        public void RewardBasedVideoLeftApplication(object sender, EventArgs args)
        {
        }
    }
}