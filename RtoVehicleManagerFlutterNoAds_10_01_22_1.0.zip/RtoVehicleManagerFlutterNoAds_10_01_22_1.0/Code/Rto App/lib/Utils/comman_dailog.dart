import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:open_file/open_file.dart';
import 'package:rto_app/History%20Screen/controller/history_controller.dart';
import 'package:rto_app/Home%20Screen/themes.dart';
import 'package:rto_app/Rto%20Office%20Screen/controllers/rto_office_controller.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/controller/rto_question_controller.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/view/rto_preparation..dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:velocity_x/velocity_x.dart';

class CommanDialog {
  static showLoading(BuildContext context, {String title = "Searching..."}) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).dialogBackgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Container(
            color: Theme.of(context).dialogBackgroundColor,
            height: 340,
            child: Column(
              children: [
                SizedBox(
                  width: 20,
                ),
                Center(
                  child: Lottie.asset(
                    "assets/lottie/searching.json",
                  ),
                ).px(5),
                SizedBox(
                  width: 20,
                ),
                Text(
                  title,
                ),
              ],
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static showRatingDialog(BuildContext context, {String title = "Rate Us"}) {
    double star = 0.0;
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).highlightColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).highlightColor,
            height: 180,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("How was the experience ?",
                    style: TextStyle(
                        fontSize: 17,
                        color: Theme.of(context).accentColor,
                        fontFamily: "Circular Medium")),
                SmoothStarRating(
                  color: Theme.of(context).accentColor,
                  isReadOnly: false,
                  rating: 0,
                  size: 35,
                  borderColor: Theme.of(context).accentColor,
                  defaultIconData: Icons.star_border,
                  filledIconData: Icons.star,
                  halfFilledIconData: Icons.star_half,
                  starCount: 5,
                  allowHalfRating: false,
                  spacing: 5.0,
                  onRated: (count) {
                    star = count;
                  },
                ).px(5).py(15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 35,
                      width: 95,
                      child: Material(
                        color: Theme.of(context).dialogTheme.backgroundColor,
                        child: Ink(
                          decoration: BoxDecoration(),
                          child: InkWell(
                            customBorder: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20))),
                            splashColor: Theme.of(context).hoverColor,
                            onTap: () {
                              if (star == 0) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Row(
                                      children: <Widget>[
                                        Text(
                                          "Please select the stars",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ],
                                    ),
                                    duration: Duration(seconds: 2),
                                    backgroundColor: Colors.black,
                                  ),
                                );
                              } else if (star > 3) {
                                launch(
                                  "https://play.google.com/store/apps/details?id=",
                                  webOnlyWindowName: '_self',
                                );
                                if (Get.isDialogOpen!) Get.back();
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Row(
                                      children: <Widget>[
                                        Text(
                                          "Thank for rating",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ],
                                    ),
                                    duration: Duration(seconds: 2),
                                    backgroundColor: Colors.black,
                                  ),
                                );
                                if (Get.isDialogOpen!) Get.back();
                              }
                            },
                            child: Center(
                              child: Text(
                                "Rate Us",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: "Circular Medium"),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ).cornerRadius(25).px(20).pOnly(top: 15),
                    Container(
                      height: 35,
                      width: 100,
                      child: Material(
                        color: Theme.of(context).dialogTheme.backgroundColor,
                        child: Ink(
                          decoration: BoxDecoration(),
                          child: InkWell(
                            customBorder: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20))),
                            splashColor: Theme.of(context).hoverColor,
                            onTap: () {
                              if (Get.isDialogOpen!) Get.back();
                            },
                            child: Center(
                              child: Text(
                                "Cancel",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: "Circular Medium"),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ).cornerRadius(25).px(20).pOnly(top: 15)
                  ],
                )
              ],
            ),
          ).cornerRadius(15),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static hideLoading() {
    Get.back();
  }

  static loadingDialog(BuildContext context) {
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).disabledColor,
            height: 130,
            child: Center(
              child: Container(
                  height: 50,
                  width: 50,
                  child: Lottie.asset("assets/lottie/loading.json")),
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static exitDialog(BuildContext context, String title) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).disabledColor,
            height: 85,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: 17,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ),
                  ).px(15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                          Navigator.pop(context);
                        },
                        child: Text("Exit"),
                      ),
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                        },
                        child: Text("Cancel"),
                      ).pOnly(right: 10)
                    ],
                  )
                ],
              ),
            ).pOnly(top: 5),
          ).cornerRadius(15),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static pdfOpenDialog(BuildContext context, String title, String path) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).disabledColor,
            height: 85,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: 17,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ),
                  ).px(15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                          Navigator.pop(context);
                          OpenFile.open(path);
                        },
                        child: Text("Open"),
                      ).paddingOnly(right: 5),
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                        },
                        child: Text("later"),
                      )
                    ],
                  )
                ],
              ),
            ).pOnly(top: 5),
          ).cornerRadius(15),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static restartDialog(
      RtoQuestionController rtoQuestionController,
      BuildContext context,
      String title,
      bool isAcorrect,
      bool isBcorrect,
      bool isCcorrect,
      bool isNoSelected,
      clickA,
      clickB,
      clickC,
      CountDownController countDownController,
      RtoQuestionController controller,
      bool isRtoPreperation) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).disabledColor,
            height: 85,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: 17,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ),
                  ).px(15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          isAcorrect = false;
                          isBcorrect = false;
                          isCcorrect = false;
                          isNoSelected = true;
                          clickA = true;
                          clickB = true;
                          clickC = true;
                          countDownController.restart(duration: 45);
                          countDownController.pause();
                          rtoQuestionController.currentIndexA = 0;
                          rtoQuestionController.currentIndexB = 0;
                          rtoQuestionController.currentIndexC = 0;
                          //controller.fetchRandomQuestion();
                          controller.resetAll();
                          if (Get.isDialogOpen!) Get.back();
                          CommanDialog.showRtoPreparationDialog(
                              context, isRtoPreperation);
                        },
                        child: Text("Restart"),
                      ).paddingOnly(right: 5),
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                        },
                        child: Text("Cancel"),
                      ),
                    ],
                  )
                ],
              ),
            ).pOnly(top: 5),
          ).cornerRadius(15),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static deleteMileageDataDialog(BuildContext context, String title,
      var controller, String randomId, String type) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            color: Theme.of(context).disabledColor,
            height: 85,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: 17,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ),
                  ).px(15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          controller.delete(randomId);
                          controller.getAllData();
                          if (type != "mileage") {
                            controller.getDateWiseData();
                          }
                          if (Get.isDialogOpen!) Get.back();
                        },
                        child: Text("Delete"),
                      ).paddingOnly(right: 5),
                      TextButton(
                        onPressed: () {
                          if (Get.isDialogOpen!) Get.back();
                        },
                        child: Text("Cancel"),
                      )
                    ],
                  )
                ],
              ),
            ).pOnly(top: 5),
          ).cornerRadius(15),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static showRtoPreparationDialog(BuildContext context, bool isRtoPreparation) {
    RtoQuestionController controller =
        Get.put(RtoQuestionController(context, isRtoPreparation));
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).dialogBackgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: EdgeInsets.all(5),
          child: Container(
            color: Theme.of(context).dialogBackgroundColor,
            height: 350,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Positioned(
                    top: -70,
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Image.asset(
                        "assets/images/start_rto_preparation.png",
                        height: 300,
                      ),
                    )),
                Positioned.fill(
                    top: 180,
                    child: isRtoPreparation
                        ? Text(
                            "You will get a total of 25 questions,you will get 5 marks for each correct answers, you will get 45 seconds for each question and you will have to get 75 marks for excellent performance in exam",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.blueGrey,
                                fontFamily: "Circular Medium"),
                          ).px(10)
                        : Text(
                            "You will get a total of 13 questions,you will get 5 marks for each correct answers, you will get 45 seconds for each question and you will have to get 55 marks for passing the exam",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.blueGrey,
                                fontFamily: "Circular Medium"),
                          ).px(10)),
                Positioned(
                  bottom: 1,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 35,
                        width: 220,
                        child: Material(
                          color: Theme.of(context).dialogTheme.backgroundColor,
                          child: Ink(
                            decoration: BoxDecoration(),
                            child: InkWell(
                              customBorder: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(25),
                                      bottomRight: Radius.circular(25))),
                              splashColor: MyThemes.skyBlue,
                              onTap: () {
                                ScoreCard.clickA = true;
                                ScoreCard.clickB = true;
                                ScoreCard.clickC = true;
                                ScoreCard.isAcorrect = false;
                                ScoreCard.isBcorrect = false;
                                ScoreCard.isCcorrect = false;
                                ScoreCard.isNoSelected = true;
                                controller.resetAll();
                                controller.restartGame();
                                controller.currentQue = 1;
                                ScoreCard.countController.start();
                                if (Get.isDialogOpen!) Get.back();
                              },
                              child: Center(
                                  child: isRtoPreparation
                                      ? Text(
                                          "Start RTO Preparation Quiz",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontFamily: "Circular Medium"),
                                        )
                                      : Text(
                                          "Start Exam",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontFamily: "Circular Medium"),
                                        )),
                            ),
                          ),
                        ),
                      ).cornerRadius(25),
                      Container(
                        height: 35,
                        width: 220,
                        child: Material(
                          color: Theme.of(context).dialogBackgroundColor,
                          child: Ink(
                            decoration: BoxDecoration(),
                            child: InkWell(
                              customBorder: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(25),
                                      bottomRight: Radius.circular(25))),
                              splashColor: MyThemes.skyBlue,
                              onTap: () {
                                if (Get.isDialogOpen!) Get.back();
                                Navigator.pop(context);
                              },
                              child: Center(
                                child: Text(
                                  "I'll try it later",
                                  style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey,
                                      fontFamily: "Circular Medium"),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ).cornerRadius(25).paddingOnly(top: 5)
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static showResultDialog(
      BuildContext context,
      RtoQuestionController controller,
      CountDownController countController,
      String result,
      int yourScore,
      int highScore,
      int rightAns,
      int wrongAns,
      int maxQuestion,
      bool isRtoPreperation,
      bool isAcorrect,
      bool isBcorrect,
      bool isCcorrect,
      bool isNoSelected,
      clickA,
      clickB,
      clickC) {
    int maxMarks;
    int compareAns;
    if (maxQuestion == 25) {
      maxMarks = 75;
      compareAns = 15;
    } else {
      maxMarks = 55;
      compareAns = 11;
    }
    Get.dialog(
      WillPopScope(
          child: Dialog(
            backgroundColor: Theme.of(context).dialogBackgroundColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Container(
                color: Theme.of(context).dialogBackgroundColor,
                height: 430,
                child: Column(
                  children: [
                    Text(
                      result,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ).px(10).py(10),
                    Card(
                      margin: EdgeInsets.zero,
                      elevation: 0,
                      color: Theme.of(context).cardColor,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 0.0, vertical: 0.0),
                            visualDensity:
                                VisualDensity(horizontal: 2, vertical: -2),
                            leading: Card(
                              color: context.backgroundColor,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(
                                      width: 0.3, color: Colors.grey)),
                              child: Container(
                                padding: EdgeInsets.all(3),
                                height: 33,
                                width: 33,
                                child: Icon(Icons.trending_up),
                              ),
                            ).px(5).pOnly(bottom: 2),
                            title: Text("Your Score",
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Theme.of(context).hintColor))
                                .text
                                .size(14)
                                .make(),
                            subtitle: Text(yourScore.toString(),
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Colors.blueGrey))
                                .text
                                .size(17)
                                .make()
                                .pOnly(bottom: 2.2),
                          ).px(15).pOnly(top: 5),
                          ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 0.0, vertical: 0.0),
                            visualDensity:
                                VisualDensity(horizontal: 2, vertical: -2),
                            leading: Card(
                              color: context.backgroundColor,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(
                                      width: 0.3, color: Colors.grey)),
                              child: Container(
                                padding: EdgeInsets.all(3),
                                height: 33,
                                width: 33,
                                child: Icon(Icons.score),
                              ),
                            ).px(5).pOnly(bottom: 2),
                            title: Text("High Score",
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Theme.of(context).hintColor))
                                .text
                                .size(14)
                                .make(),
                            subtitle: Text(highScore.toString(),
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Colors.blueGrey))
                                .text
                                .size(17)
                                .make()
                                .pOnly(bottom: 2.2),
                          ).px(15).pOnly(top: 5),
                          ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 0.0, vertical: 0.0),
                            visualDensity:
                                VisualDensity(horizontal: 2, vertical: -2),
                            leading: Card(
                              color: context.backgroundColor,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(
                                      width: 0.3, color: Colors.grey)),
                              child: Container(
                                padding: EdgeInsets.all(3),
                                height: 33,
                                width: 33,
                                child: Icon(CupertinoIcons.checkmark_alt),
                              ),
                            ).px(5).pOnly(bottom: 2),
                            title: Text("Right Answer",
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Theme.of(context).hintColor))
                                .text
                                .size(14)
                                .make(),
                            subtitle: Text(rightAns.toString(),
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Colors.blueGrey))
                                .text
                                .size(17)
                                .make()
                                .pOnly(bottom: 2.2),
                          ).px(15).pOnly(top: 5),
                          ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 0.0, vertical: 0.0),
                            visualDensity:
                                VisualDensity(horizontal: 2, vertical: -2),
                            leading: Card(
                              color: context.backgroundColor,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  side: BorderSide(
                                      width: 0.3, color: Colors.grey)),
                              child: Container(
                                padding: EdgeInsets.all(3),
                                height: 33,
                                width: 33,
                                child: Icon(CupertinoIcons.clear),
                              ),
                            ).px(5).pOnly(bottom: 2),
                            title: Text("Wrong Answer",
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Theme.of(context).hintColor))
                                .text
                                .size(14)
                                .make(),
                            subtitle: Text(wrongAns.toString(),
                                    style: TextStyle(
                                        fontFamily: "Circular Medium",
                                        color: Colors.blueGrey))
                                .text
                                .size(17)
                                .make()
                                .pOnly(bottom: 2.2),
                          ).px(15).pOnly(top: 5, bottom: 5),
                          rightAns <= compareAns
                              ? ListTile(
                                  dense: true,
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 0.0, vertical: 0.0),
                                  visualDensity: VisualDensity(
                                      horizontal: 2, vertical: -2),
                                  leading: Card(
                                    color: context.backgroundColor,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        side: BorderSide(
                                            width: 0.3, color: Colors.grey)),
                                    child: Container(
                                      padding: EdgeInsets.all(3),
                                      height: 33,
                                      width: 33,
                                      child: Icon(CupertinoIcons.flag),
                                    ),
                                  ).px(5).pOnly(bottom: 2),
                                  title: Text("Required Marks",
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              color:
                                                  Theme.of(context).hintColor))
                                      .text
                                      .size(14)
                                      .make(),
                                  subtitle: Text(
                                          (maxMarks - yourScore).toString(),
                                          style: TextStyle(
                                              fontFamily: "Circular Medium",
                                              color: Colors.blueGrey))
                                      .text
                                      .size(17)
                                      .make()
                                      .pOnly(bottom: 2.2),
                                ).px(15).pOnly(top: 5)
                              : Container(),
                        ],
                      ),
                    ).px(20).pOnly(top: 5),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          height: 35,
                          width: 220,
                          child: Material(
                            color:
                                Theme.of(context).dialogTheme.backgroundColor,
                            child: Ink(
                              decoration: BoxDecoration(),
                              child: InkWell(
                                customBorder: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(25),
                                        bottomRight: Radius.circular(25))),
                                splashColor: MyThemes.skyBlue,
                                onTap: () {
                                  if (Get.isDialogOpen!) Get.back();
                                  if (Links.rateDialog) {
                                    Links.rateDialog = false;
                                    CommanDialog.showRatingDialog(context);
                                  }
                                  isAcorrect = false;
                                  isBcorrect = false;
                                  isCcorrect = false;
                                  isNoSelected = true;
                                  clickA = true;
                                  clickB = true;
                                  clickC = true;
                                  countController.restart(duration: 45);
                                  countController.pause();
                                  controller.currentIndexA = 0;
                                  controller.currentIndexB = 0;
                                  controller.currentIndexC = 0;
                                  //controller.fetchRandomQuestion();
                                  controller.resetAll();
                                  CommanDialog.showRtoPreparationDialog(
                                      context, isRtoPreperation);
                                },
                                child: Center(
                                  child: Text(
                                    "Restart",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: "Circular Medium"),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ).cornerRadius(25),
                        Container(
                          height: 35,
                          width: 220,
                          child: Material(
                            color: Theme.of(context).dialogBackgroundColor,
                            child: Ink(
                              decoration: BoxDecoration(),
                              child: InkWell(
                                customBorder: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(25),
                                        bottomRight: Radius.circular(25))),
                                splashColor: MyThemes.skyBlue,
                                onTap: () {
                                  if (Get.isDialogOpen!) Get.back();
                                  Navigator.pop(context);
                                },
                                child: Center(
                                  child: Text(
                                    "I'll do it later",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.grey,
                                        fontFamily: "Circular Medium"),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ).cornerRadius(25).paddingOnly(top: 5)
                      ],
                    ).pOnly(top: 20)
                  ],
                ),
              ),
            ),
          ),
          onWillPop: () => Future.value(false)),
      barrierDismissible: false,
    );
  }

  static deleteDialog(
      BuildContext context, HistoryController controller, index) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(1.0),
          child: Container(
            height: 130,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Are you sure want to delete ?",
                    style: TextStyle(
                        color: Theme.of(context).accentColor,
                        fontFamily: "Circular Medium",
                        fontSize: 18),
                  ).py(10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                              onPressed: () {
                                controller.delete(controller
                                    .ownerInfoList[index].licensePlate);
                                controller.getAllData();
                                if (Get.isDialogOpen!) Get.back();
                              },
                              child: Text("Delete"))
                          .px(15),
                      ElevatedButton(
                              onPressed: () {
                                if (Get.isDialogOpen!) Get.back();
                              },
                              child: Text("Cancel"))
                          .px(15)
                    ],
                  ).py(10)
                ],
              ),
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static showErrorDialog(BuildContext context, String title) {
    RtoOfficeController rtoOfficeController = Get.put(RtoOfficeController());
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        child: Padding(
          padding: EdgeInsets.zero,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 2,
              ),
              Lottie.asset("assets/lottie/alertno.json",
                  height: 120, width: 120),
              Text(
                title,
                style: TextStyle(
                    fontSize: 14,
                    color: Theme.of(context).accentColor,
                    fontFamily: "Circular Medium"),
              ).px(10).pOnly(top: 5),
              ElevatedButton(
                onPressed: () {
                  if (Get.isDialogOpen!) Get.back();
                },
                child: Text("Ok"),
              ).py(7),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  static showNoInternetDialog(BuildContext context, String title) {
    Get.dialog(
      Dialog(
        backgroundColor: Theme.of(context).disabledColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        child: Padding(
          padding: EdgeInsets.zero,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 2,
              ),
              Lottie.asset("assets/lottie/no_internet.json",
                  height: 120, width: 120),
              Text(
                title,
                style: TextStyle(
                    fontSize: 14,
                    color: Theme.of(context).accentColor,
                    fontFamily: "Circular Medium"),
              ).px(10).pOnly(top: 5),
              ElevatedButton(
                onPressed: () {
                  if (Get.isDialogOpen!) Get.back();
                },
                child: Text("Ok"),
              ).py(7),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }
}
