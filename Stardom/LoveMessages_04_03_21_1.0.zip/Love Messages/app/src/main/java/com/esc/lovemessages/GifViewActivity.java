package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.sdk.constants.Constants.ParametersKeys;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GifViewActivity extends AppCompatActivity  {
    static ConsentInformation consentInformation = null;
    private static Context context = null;
    static Dialog dialogR = null;
    private static Editor editor = null;
    protected static Editor editorgif = null;
    private static final int gifID_toshow = 0;
    public static RewardedVideoAd mAd = null;
    public static boolean rewardads_gif = false;
    private static SharedPreferences sharedPreferences = null;
    protected static SharedPreferences sharedPreferencesgif = null;
    public static boolean show_gif = false;
    protected static String subcategory;
    Activity activity = this;
    private Adapter adapter;
    int currentVisiblePosition = 0;
    private GifDataBaseHelper db;
    private ArrayList<Integer> favorite;
    private TextView heading;
    private LayoutManager layoutManager;
    ReviewManager manager;
    private ArrayList<String> messages;
    private ArrayList<Integer> mid;
    private RecyclerView recyclerView;
    ReviewInfo reviewInfo;
    private int reward_loadcnt;
    private Typeface typeface;
    private ArrayList<String> url;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_gifview);
        context = this;
        this.typeface = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        View inflate = LayoutInflater.from(this).inflate(R.layout.action_bar_title, null);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText(R.string.appname);
        textView.setTypeface(this.typeface);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        sharedPreferencesgif = getSharedPreferences("MYPREFERENCE_GIF", 0);
        editorgif = sharedPreferencesgif.edit();
        sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        editor = sharedPreferences.edit();
        String str = "inappreview";
        editor.putInt(str, sharedPreferences.getInt(str, 0) + 1).apply();
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview1(getApplicationContext());
        }
        subcategory = getIntent().getExtras().getString("subcategory");
        this.db = new GifDataBaseHelper(this);
        int GetSubSectionId = this.db.GetSubSectionId(subcategory);
        this.messages = new ArrayList();
        this.url = new ArrayList();
        this.mid = new ArrayList();
        this.favorite = new ArrayList();
        this.messages = this.db.GetAllGifText(GetSubSectionId);
        this.mid = this.db.GetAllGifID(GetSubSectionId);
        this.favorite = this.db.GetAllFavoriteGif(GetSubSectionId);
        String GetURL = this.db.GetURL(GetSubSectionId);
        String GetsectionIdForURL = this.db.GetsectionIdForURL(GetSubSectionId);
        this.reward_loadcnt = 0;
        int i = 0;
        while (i < this.mid.size()) {
            ArrayList arrayList = this.url;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("https://www.wishafriend.com/");
            stringBuilder.append(GetsectionIdForURL);
            stringBuilder.append("/uploads/");
            stringBuilder.append(this.mid.get(i));
            stringBuilder.append("-");
            stringBuilder.append(GetURL);
            stringBuilder.append(".gif");
            arrayList.add(stringBuilder.toString());
            SharedPreferences sharedPreferences = sharedPreferencesgif;
            stringBuilder = new StringBuilder();
            String str2 = "gif_";
            stringBuilder.append(str2);
            stringBuilder.append(this.mid.get(i));
            if (!sharedPreferences.getBoolean(stringBuilder.toString(), false)) {
                this.reward_loadcnt++;
            }
            int i2 = i + 1;
            Editor editor;
            StringBuilder stringBuilder2;
            if (i2 % 4 != 0) {
                editor = editorgif;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mid.get(i));
                editor.putBoolean(stringBuilder2.toString(), true);
                editorgif.commit();
            } else {
                SharedPreferences sharedPreferences2 = sharedPreferencesgif;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str2);
                stringBuilder2.append(this.mid.get(i));
                if (!sharedPreferences2.getBoolean(stringBuilder2.toString(), false)) {
                    editor = editorgif;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str2);
                    stringBuilder2.append(this.mid.get(i));
                    editor.putBoolean(stringBuilder2.toString(), false);
                    editorgif.commit();
                }
            }
            i = i2;
        }
        this.recyclerView = findViewById(R.id.gifview_recyclerview);
        this.layoutManager = new LinearLayoutManager(this);
        this.recyclerView.setLayoutManager(this.layoutManager);
        this.adapter = new GifViewAdapter(this, this.messages, this.url, this.mid, this.favorite, this.activity);
        this.recyclerView.setAdapter(this.adapter);
        this.heading = findViewById(R.id.subcategory_headingtextview);
        this.heading.setText(subcategory);
        this.heading.setTypeface(this.typeface);
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            startActivity(new Intent(this, GifFavoriteActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }

      public void RateAndReview1(Context context) {
        this.manager = ReviewManagerFactory.create(context);
        this.manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            public void onComplete(Task<ReviewInfo> task) {
                String str = "inapp reivew";
                if (task.isSuccessful()) {
                    GifViewActivity.this.reviewInfo = task.getResult();
                    Log.e(str, "In-app REVIEW SUCCESSFUL");
                    return;
                }
                Log.e(str, "In-app REVIEW ERROR or FAILED or LIMIT COMPLETED");
            }
        });
    }

    public void RateAndReview() {
        String str = "inapp reivew";
        String str2 = "inappreview";
        if (sharedPreferences.getInt(str2, 0) > 6) {
            editor.putInt(str2, 1).apply();
        }
        try {
            if (this.manager != null) {
                if (this.reviewInfo != null) {
                    this.manager.launchReviewFlow(this, this.reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(Task<Void> task) {
                            Log.e("inapp reivew", "In-app REVIEW SUCCESSFUL");
                            GifViewActivity.this.finish();
                        }
                    });
                    return;
                }
            }
            RATE_DIALOG();
            Log.e(str, "In-app REVIEW SUCCESSFUL NULL");
        } catch (Exception unused) {
            Log.e(str, "In-app REVIEW SUCCESSFUL ERROR");
            RATE_DIALOG();
        }
    }

    public void onBackPressed() {
        String str = "inappreview";
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview();
            return;
        }
        str = "rateagain";
        if (sharedPreferences.getInt(str, 0) > 12 || sharedPreferences.getInt("applaunched", 0) == 0) {
            editor.putInt(str, 0);
            editor.commit();
            RATE_DIALOG();
            return;
        }
        super.onBackPressed();
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        dialogR = new Dialog(this);
        Dialog dialog = dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        dialogR.setContentView(inflate);
        dialogR.setCancelable(false);
        TextView textView = dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        textView.setTypeface(this.typeface);
        Button button = dialogR.findViewById(R.id.btn_yes);
        Button button2 = dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                GifViewActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                GifViewActivity.this.finish();
                GifViewActivity.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                GifViewActivity.this.finish();
                GifViewActivity.dialogR.cancel();
            }
        });
        textView.setTypeface(this.typeface);
        button.setTypeface(this.typeface);
        button2.setTypeface(this.typeface);
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(30.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(26.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(18.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            dialogR.show();
        }
    }


    public void onResume() {
        this.favorite = this.db.GetAllFavoriteGif(this.db.GetSubSectionId(subcategory));
        this.adapter = new GifViewAdapter(this, this.messages, this.url, this.mid, this.favorite, this.activity);
        this.recyclerView.getLayoutManager().scrollToPosition(this.currentVisiblePosition);
        this.recyclerView.setAdapter(this.adapter);
        this.currentVisiblePosition = 0;
        super.onResume();
        RewardedVideoAd rewardedVideoAd = mAd;
        if (rewardedVideoAd != null) {
            rewardedVideoAd.resume(this);
        }
        if (show_gif) {
            Editor editor = editorgif;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("gif_");
            stringBuilder.append(gifID_toshow);
            editor.putBoolean(stringBuilder.toString(), true);
            editorgif.commit();
            this.adapter.notifyDataSetChanged();
            show_gif = false;
            return;
        }
        this.adapter.notifyDataSetChanged();
    }

    public void onPause() {
        this.currentVisiblePosition = ((LinearLayoutManager) this.recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
        RewardedVideoAd rewardedVideoAd = mAd;
        if (rewardedVideoAd != null) {
            rewardedVideoAd.pause(this);
        }
        super.onPause();
        IronSource.onPause(this);
    }

    public void onDestroy() {
        RewardedVideoAd rewardedVideoAd = mAd;
        if (rewardedVideoAd != null) {
            rewardedVideoAd.destroy(this);
        }
        super.onDestroy();
    }

    public static void AddRateClicks() {
        String str = "rateagain";
        if (sharedPreferences.getInt(str, 0) < 13) {
            int i = sharedPreferences.getInt(str, 0) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
        }
    }

}
