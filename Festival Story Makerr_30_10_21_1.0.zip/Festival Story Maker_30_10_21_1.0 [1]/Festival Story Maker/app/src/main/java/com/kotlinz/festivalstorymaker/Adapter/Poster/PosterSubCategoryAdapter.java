package com.kotlinz.festivalstorymaker.Adapter.Poster;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.AppUtils.View.AVLoadingView.AVLoadingIndicatorView;
import com.kotlinz.festivalstorymaker.Download.PosterThemeDownload;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.CategoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.PosterMakerActivity;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PosterSubCategoryAdapter extends RecyclerView.Adapter<PosterSubCategoryAdapter.MyViewHolder> {

    public PosterMakerActivity PosterActivity;
    public int position = -1;
    public ArrayList<CategoryWiseData> postersubCategoryList;
    String DataFileName;
    String[] SplitName;

    public PosterSubCategoryAdapter(Context context, ArrayList<CategoryWiseData> postersubCategoryList) {
        this.PosterActivity = (PosterMakerActivity) context;
        this.postersubCategoryList = postersubCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_poster_subcategory, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final CategoryWiseData categoryWiseData = postersubCategoryList.get(position);
        String FileName = "";
        if (categoryWiseData.getDatafile() != null) {
            FileName = categoryWiseData.getDatafile().substring(categoryWiseData.getDatafile().lastIndexOf('/') + 1);
        }
        if (FileName.indexOf(".") > 0)
            FileName = Utils.INSTANCE.getThemeFolderPath() + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + FileName.substring(0, FileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        if (new File(FileName).exists()) {
            holder.ThemeDownProgress.setVisibility(View.GONE);
            holder.ivDownload.setVisibility(View.GONE);
        } else {
            holder.ThemeDownProgress.setVisibility(View.GONE);
            holder.ivDownload.setVisibility(View.VISIBLE);
        }

        Glide.with(PosterActivity).load(postersubCategoryList.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DownloadFile(position, holder.ivDownload, holder.ThemeDownProgress, holder.indicatorThemeProgress, holder.tvThemeDownProgress, categoryWiseData);
            }
        });
    }

    private void DownloadFile(int Position, ImageView ivDownload, LinearLayout themeDownProgress, AVLoadingIndicatorView avLoadingIndicatorView, TextView tvThemeDownprogress, CategoryWiseData categoryWiseData) {
        if (categoryWiseData.getDatafile() != null) {
            DataFileName = categoryWiseData.getDatafile().substring(categoryWiseData.getDatafile().lastIndexOf('/') + 1);
        }
        if (DataFileName.indexOf(".") > 0)
            DataFileName = DataFileName.substring(0, DataFileName.lastIndexOf(".")).replaceAll("[0-9]+", "");
        SplitName = DataFileName.split("Theme");
        String SplitFileName = "Theme" + " " + SplitName[1];

        Constant.TextFilePath = Utils.INSTANCE.getThemeFolderPath() + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName + File.separator + SplitFileName + ".txt";
        Constant.FolderPath = Utils.INSTANCE.getThemeFolderPath() + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + SplitFileName;

        if (new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + categoryWiseData.getModuleName() + File.separator + categoryWiseData.getParentCategory() + File.separator + categoryWiseData.getChildCategory() + File.separator + DataFileName).exists()) {
            if (MyApplication.isShowAd == 1) {
                Constant.NoofImage = Integer.parseInt(postersubCategoryList.get(Position).getIsImageCount());
                Constant.ImageFrame = postersubCategoryList.get(Position).getThemeThumbnail();
                PosterActivity.ShowImageDialog("ImageSelect");
                MyApplication.getInstance().CatItemPosition = Position;
                MyApplication.isShowAd = 0;
            } else {
                if (MyApplication.mInterstitialAd != null) {
                    MyApplication.activity = PosterActivity;
                    MyApplication.AdsId = 27;
                    Constant.NoofImage = Integer.parseInt(postersubCategoryList.get(Position).getIsImageCount());
                    Constant.ImageFrame = postersubCategoryList.get(Position).getThemeThumbnail();
                    MyApplication.getInstance().CatItemPosition = Position;
                    MyApplication.mInterstitialAd.show(PosterActivity);
                    MyApplication.isShowAd = 1;
                } else {
                    Constant.NoofImage = Integer.parseInt(postersubCategoryList.get(Position).getIsImageCount());
                    Constant.ImageFrame = postersubCategoryList.get(Position).getThemeThumbnail();
                    PosterActivity.ShowImageDialog("ImageSelect");
                    MyApplication.getInstance().CatItemPosition = Position;
                }
            }

        } else {
            if (Utils.checkConnectivity(PosterActivity, false)) {

                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                avLoadingIndicatorView.smoothToShow();
                new PosterThemeDownload(PosterActivity, postersubCategoryList.get(Position).getDatafile(), DataFileName, ivDownload, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, categoryWiseData);
            }
        }
    }

    @Override
    public int getItemCount() {
        return postersubCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.llMain)
        public CardView llMain;

        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;

        @BindView(R.id.ivThumbDownload)
        ImageView ivDownload;

        @BindView(R.id.indicator)
        AVLoadingIndicatorView indicatorThemeProgress;

        @BindView(R.id.ll_theme_down_progress)
        LinearLayout ThemeDownProgress;

        @BindView(R.id.tvCounter)
        TextView tvThemeDownProgress;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
