package com.esc.phoneheart.model;

import android.content.Context;
import android.os.Environment;

import com.esc.phoneheart.interfaceclass.DownloadDataFetchedListener;
import com.esc.phoneheart.wrappers.DownloadWrapper;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

public class DownloadsData {
    public long a = 0;
    public ArrayList<DownloadWrapper> downloadsList = new ArrayList();
    public int totalDeleted;
    public int totalSelected;
    public int totalSelectedsize;

    public DownloadsData(Context context) {
    }

    private boolean isMediaAvailable(String str) {
        return "mounted".equals(str);
    }

    public ArrayList<DownloadWrapper> a() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.downloadsList.iterator();
        while (it.hasNext()) {
            DownloadWrapper downloadWrapper = (DownloadWrapper) it.next();
            if (downloadWrapper.checked) {
                arrayList.add(downloadWrapper);
            }
        }
        return arrayList;
    }

    public void getDownloadedFiles(Context context, DownloadDataFetchedListener downloadDataFetchedListener) {
        this.downloadsList = null;
        this.downloadsList = new ArrayList();
        long j = 0;
        if (isMediaAvailable(Environment.getExternalStorageState())) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory().toString());
            stringBuilder.append(File.separator);
            stringBuilder.append(Environment.DIRECTORY_DOWNLOADS);
            File[] listFiles = new File(stringBuilder.toString()).listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    DownloadWrapper downloadWrapper = new DownloadWrapper();
                    if (!(file == null || file.isDirectory() || file.isHidden())) {
                        String absolutePath = file.getAbsolutePath();
                        downloadWrapper.isFolder = file.isDirectory();
                        downloadWrapper.path = absolutePath;
                        long length = file.length();
                        downloadWrapper.size = length;
                        j += length;
                        downloadWrapper.ext = FilenameUtils.getExtension(absolutePath);
                        downloadWrapper.name = FilenameUtils.getName(absolutePath);
                        this.downloadsList.add(downloadWrapper);
                    }
                }
            }
        }
        downloadDataFetchedListener.onFetched(this.downloadsList.size(), j);
    }
}
