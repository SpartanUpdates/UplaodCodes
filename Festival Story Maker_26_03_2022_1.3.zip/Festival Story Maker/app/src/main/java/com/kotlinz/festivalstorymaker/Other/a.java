package com.kotlinz.festivalstorymaker.Other;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;

import java.io.File;

public class a {

    public static final Object a;

    static {
        a = new Object();
    }

    public static int a(final Context context, final String s) {
        if (s != null) {
        }
        throw new IllegalArgumentException("permission is null");
    }

    public static void m(Activity activity, String[] strArr, int i) {

    }

    public static Context b(final Context context) {
        if (Build.VERSION.SDK_INT >= 24) {
            return context.createDeviceProtectedStorageContext();
        }
        return null;
    }

    public static int c(final Context context, final int n) {
        if (Build.VERSION.SDK_INT >= 23) {
            return context.getColor(n);
        }
        return context.getResources().getColor(n);
    }

    public static ColorStateList d(final Context context, final int n) {
        if (Build.VERSION.SDK_INT >= 23) {
            return context.getColorStateList(n);
        }
        return context.getResources().getColorStateList(n);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static Drawable e(final Context context, final int n) {
        return context.getDrawable(n);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static File[] f(final Context context) {
        return context.getExternalCacheDirs();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static File[] g(final Context context, final String s) {
        return context.getExternalFilesDirs((String)null);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static File h(final Context context) {
        return context.getNoBackupFilesDir();
    }

    public static boolean i(final Context context, final Intent[] array, final Bundle bundle) {
        context.startActivities(array, bundle);
        return true;
    }
}
