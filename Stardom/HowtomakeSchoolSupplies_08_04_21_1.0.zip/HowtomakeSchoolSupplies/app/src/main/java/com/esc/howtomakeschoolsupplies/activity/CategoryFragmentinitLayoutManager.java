package com.esc.howtomakeschoolsupplies.activity;

import com.esc.howtomakeschoolsupplies.fragment.CategoryFragment;
import androidx.recyclerview.widget.GridLayoutManager;

public class CategoryFragmentinitLayoutManager extends GridLayoutManager.SpanSizeLookup {
    final CategoryFragment categoryfragment;

   public CategoryFragmentinitLayoutManager(CategoryFragment categoryFragment) {
        this.categoryfragment = categoryFragment;
    }

    public int getSpanSize(int i) {
        return CategoryFragment.accessgetAdapterp(this.categoryfragment).getItemViewType(i) != 1 ? 1 : 2;
    }
}