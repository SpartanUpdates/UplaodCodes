package com.kotlinz.festivalstorymaker.Model.FestivalPoster;

import java.util.ArrayList;
import com.google.gson.annotations.SerializedName;

public class FestivalPosterMain {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private ArrayList<FestivalData> response;

	public String getSuccess(){
		return success;
	}

	public ArrayList<FestivalData> getResponse(){
		return response;
	}
}