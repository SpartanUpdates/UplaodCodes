package com.xyz.vehiclemanager.bikedetails.bikeservice.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeService {
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("data")
    public ArrayList<BikeService> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("name")
    public String name;
    @SerializedName("address")
    public String address;
    @SerializedName("contactNo")
    public String contactNo;

    public BikeService() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public ArrayList<BikeService> getData() {
        return data;
    }

    public void setData(ArrayList<BikeService> data) {
        this.data = data;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
