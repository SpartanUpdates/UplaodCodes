package com.kotlinz.festivalstorymaker.Models;

import java.io.Serializable;

public class b implements Serializable {
    public String e;
    public String f;
    public String g;
    public String h;
}
