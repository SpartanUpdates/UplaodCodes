package com.kotlinz.festivalstorymaker.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalCategoryAdapter;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalSubCategoryAdapter;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.FestivalDataItem;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.FestivalResponseMain;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FestivalTemplateActivity extends AppCompatActivity {

    Activity activity = FestivalTemplateActivity.this;

    @BindView(R.id.tv_title)
    TextView tvtitle;

    @BindView(R.id.rv_festival_category)
    RecyclerView rvFestivalCategory;

    @BindView(R.id.rv_festival_subcategory)
    public RecyclerView rvFestivalSubCategory;

    @BindView(R.id.rl_main_data)
    public RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    public LinearLayout llRetry;

    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    ArrayList<FestivalDataItem> festivalCategoriesListDuplicate;
    ArrayList<FestivalDataItem> festivalCategoriesList;
    FestivalCategoryAdapter festivalCategoryAdapter;

    public ArrayList<CategoryWiseData> festivalSubCategoryList;
    public FestivalSubCategoryAdapter festivalSubCategoryAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    private int ModuleId;

    public String FestivalCategoryId;
    Gson gson = new Gson();

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_festival_template);
        ButterKnife.bind(this);
        festivalCategoriesList = new ArrayList<>();
        festivalCategoriesListDuplicate = new ArrayList<>();
        festivalSubCategoryList = new ArrayList<>();
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        PutAnalyticsEvent();
        InitProgressDialog();
        BannerAds();
        SetStoryMainCategoryData();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FestivalTemplateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetStoryMainCategoryData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker).equalsIgnoreCase("")) {
                GetFestivalCategory(ModuleId);

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.FestivalMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetFestivalCategory(ModuleId);

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker).equalsIgnoreCase("")) {

                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker));
            }
        }
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetFestivalCategory(ModuleId);
        } else {
            Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }

    private void GetFestivalCategory(int ModuleId) {
        progressDialog.show();
        Call<FestivalResponseMain> call = apiInterface.getFestivalCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<FestivalResponseMain>() {
            @Override
            public void onResponse(Call<FestivalResponseMain> call, Response<FestivalResponseMain> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.FestivalMaker);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.FestivalMakerResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));

                }
            }

            @Override
            public void onFailure(Call<FestivalResponseMain> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void SetOfflineDataMainCategory(String response) {
        FestivalResponseMain festivalMakerResponse = gson.fromJson(response, FestivalResponseMain.class);
        festivalCategoriesListDuplicate = festivalMakerResponse.getData();
        //Remove Business Template Category From Main Festival Category
        for (int i = 0; i < festivalCategoriesListDuplicate.size(); i++) {
            if (!festivalCategoriesListDuplicate.get(i).getFestivalName().equals("Business Template")) {
                FestivalDataItem festivalDataItem=new FestivalDataItem();
                festivalDataItem.setFestivalId(festivalCategoriesListDuplicate.get(i).getFestivalId());
                festivalDataItem.setFestivalName(festivalCategoriesListDuplicate.get(i).getFestivalName());
                festivalDataItem.setThemeThumbnail(festivalCategoriesListDuplicate.get(i).getThemeThumbnail());
                festivalDataItem.setUpdatedAt(festivalCategoriesListDuplicate.get(i).getUpdatedAt());
                festivalDataItem.setFestivalDate(festivalCategoriesListDuplicate.get(i).getFestivalDate());
                festivalDataItem.setCreatedAt(festivalCategoriesListDuplicate.get(i).getCreatedAt());
                festivalDataItem.setModuleName(festivalCategoriesListDuplicate.get(i).getModuleName());
                festivalDataItem.setApplicationId(festivalCategoriesListDuplicate.get(i).getApplicationId());
                festivalCategoriesList.add(festivalDataItem);
                FestivalCategoryId = String.valueOf(festivalCategoriesList.get(0).getFestivalId());
                festivalCategoryAdapter = new FestivalCategoryAdapter(activity, festivalCategoriesList);
                mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
                rvFestivalCategory.setLayoutManager(mLayoutManager);
                rvFestivalCategory.setAdapter(festivalCategoryAdapter);
                SetFestivalThemeData(0, festivalCategoriesList);
            }

        }

        progressDialog.dismiss();

    }

    public void SetFestivalThemeData(int Position, ArrayList<FestivalDataItem> storyCategoryList) {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker + storyCategoryList.get(Position).getFestivalId()).equalsIgnoreCase("")) {
                GetFestivalCategoryDataByID(String.valueOf(storyCategoryList.get(Position).getFestivalId()));
            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.FestivalMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetFestivalCategoryDataByID(String.valueOf(storyCategoryList.get(Position).getFestivalId()));
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker + storyCategoryList.get(Position).getFestivalId()).equalsIgnoreCase("")) {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker + storyCategoryList.get(Position).getFestivalId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker + storyCategoryList.get(Position).getFestivalId()).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);
            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker + storyCategoryList.get(Position).getFestivalId()));
            }
        }
    }

    public void GetFestivalCategoryDataByID(String festivalId) {
        progressDialog.show();
        Call<CategoryWiseResponse> call = apiInterface.getFestivalCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, festivalId, "1");
        call.enqueue(new Callback<CategoryWiseResponse>() {
            @Override
            public void onResponse(Call<CategoryWiseResponse> call, Response<CategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.FestivalMaker + festivalId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.FestivalMakerResponseTime);
                    SetOfflineThemeData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<CategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.FestivalMaker).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineThemeData(String response) {
        CategoryWiseResponse festivalCategoryWiseResponse = gson.fromJson(response, CategoryWiseResponse.class);
        festivalSubCategoryList = festivalCategoryWiseResponse.getData();
        festivalSubCategoryAdapter = new FestivalSubCategoryAdapter(activity, festivalSubCategoryList);
        rvFestivalSubCategory.setLayoutManager(new GridLayoutManager(activity, 2));
        rvFestivalSubCategory.setAdapter(festivalSubCategoryAdapter);
        progressDialog.dismiss();
    }


    @OnClick(R.id.iv_back)
    public void GoToBack() {
        onBackPressed();
    }

    @OnClick(R.id.iv_my_creation)
    public void GoToMyCreation() {
        startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom", "Festival"));
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}