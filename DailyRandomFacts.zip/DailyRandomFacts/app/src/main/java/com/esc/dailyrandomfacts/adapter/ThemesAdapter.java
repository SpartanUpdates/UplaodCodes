package com.esc.dailyrandomfacts.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.model.Theme;
import com.esc.dailyrandomfacts.util.ColorUtils;
import com.esc.dailyrandomfacts.util.FileChooserUtils;
import com.esc.dailyrandomfacts.util.FontCache;

import java.util.ArrayList;

public class ThemesAdapter extends RecyclerView.Adapter {
    public static RecyclerViewClickListener itemListener;
    private Bitmap bitmap = null;
    private Context context;
    private ArrayList<Object> mThemesItemes;

    public interface RecyclerViewClickListener {

        void recyclerViewListClicked(View view, int i);
    }

    public class ThemeItemHolder extends RecyclerView.ViewHolder implements OnClickListener {
        private ImageView background;
        private View overlay;
        private TextView text;

        public ThemeItemHolder(View view) {
            super(view);
            this.background = (ImageView) view.findViewById(R.id.ivBackground);
            this.text = (TextView) view.findViewById(R.id.txtText);
            this.overlay = view.findViewById(R.id.overlay);
            view.setOnClickListener(this);
        }

        public void onClick(View view) {
            ThemesAdapter.itemListener.recyclerViewListClicked(view, getLayoutPosition());
        }
    }

    public ThemesAdapter(ArrayList<Object> arrayList, Activity activity, RecyclerViewClickListener recyclerViewClickListener) {
        this.mThemesItemes = arrayList;
        this.context = activity;
        itemListener = recyclerViewClickListener;
        if (SettingsManager.getOwnBackground() != null) {
            this.bitmap = FileChooserUtils.getBitmapOwn();
        }
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(this.context);
        return new ThemeItemHolder(from.inflate(R.layout.item_list_theme, viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder.getItemViewType() == 0) {
            StringBuilder stringBuilder;
            StringBuilder stringBuilder2;
            final Theme theme = (Theme) this.mThemesItemes.get(i);
            final ThemeItemHolder themeItemHolder = (ThemeItemHolder) viewHolder;
            if (theme.getName().equals("Default") && SettingsManager.isDarkMode().booleanValue()) {
                theme.setBackground("1A1C1E");
                theme.setColor("FFFFFF");
            }
            if (theme.getFont() != null) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        TextView access$000 = themeItemHolder.text;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(theme.getFont());
                        stringBuilder.append(".ttf");
                        access$000.setTypeface(FontCache.get(stringBuilder.toString(), context));
                        themeItemHolder.text.animate().alpha(1.0f);
                    }
                });
            }
            if (theme.getCapital() != 0) {
                themeItemHolder.text.setText("ABCD");
            } else {
                themeItemHolder.text.setText("abcd");
            }
            String str = "#";
            if (theme.getColor() != null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(theme.getColor());
                themeItemHolder.text.setTextColor(Color.parseColor(stringBuilder.toString()));
            } else {
                themeItemHolder.text.setTextColor(ContextCompat.getColor(this.context, R.color.textColorDark));
            }
            if (theme.getLeftAligned() != 0) {
                themeItemHolder.text.setGravity(3);
            } else {
                themeItemHolder.text.setGravity(17);
            }
            if (theme.getShadowColor() != null) {
                float textSize = themeItemHolder.text.getTextSize() / 8.0f;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(theme.getShadowColor());
                themeItemHolder.text.setShadowLayer(textSize, 0.0f, 0.0f, Color.parseColor(stringBuilder2.toString()));
            } else {
                themeItemHolder.text.setShadowLayer(0.0f, 0.0f, 0.0f, R.color.transparent);
            }
            if (SettingsManager.getOwnBackground() == null) {
                if (theme.getBackgroundImageName() != null) {
                    Resources resources = this.context.getResources();
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(theme.getBackgroundImageName());
                    stringBuilder3.append("_thumbnail");
                    String str2 = "drawable";
                    i = resources.getIdentifier(stringBuilder3.toString(), str2, this.context.getPackageName());
                    if (i == 0) {
                        i = this.context.getResources().getIdentifier("girl_thumbnail", str2, this.context.getPackageName());
                    }
                    themeItemHolder.background.setImageResource(i);
                } else {
                    themeItemHolder.background.setImageResource(0);
                    ImageView access$100 = themeItemHolder.background;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str);
                    stringBuilder2.append(theme.getBackground());
                    access$100.setBackgroundColor(Color.parseColor(stringBuilder2.toString()));
                }
                if (VERSION.SDK_INT >= 23) {
                    themeItemHolder.background.setForeground(new ColorDrawable(this.context.getResources().getColor(R.color.transparent)));
                    return;
                }
                return;
            }
            themeItemHolder.background.setImageResource(0);
            themeItemHolder.background.setBackgroundColor(0);
            themeItemHolder.background.setImageBitmap(this.bitmap);
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(theme.getColor());
            i = Color.parseColor(stringBuilder.toString());
            int color = this.context.getResources().getColor(R.color.black_overlay);
            int color2 = this.context.getResources().getColor(R.color.white_transparent);
            if (VERSION.SDK_INT < 23) {
                return;
            }
            if (ColorUtils.isDarkColor(i)) {
                themeItemHolder.background.setForeground(new ColorDrawable(color2));
                return;
            }
            themeItemHolder.background.setForeground(new ColorDrawable(color));
        }
    }

    public int getItemCount() {
        return this.mThemesItemes.size();
    }

    public void setThemes(ArrayList<Object> arrayList) {
        this.mThemesItemes = arrayList;
        notifyDataSetChanged();
    }

    public int getItemViewType(int i) {
        return getItem(i) instanceof Theme ? 0 : 1;
    }

    public Object getItem(int i) {
        return this.mThemesItemes.get(i);
    }

    public void updateBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
