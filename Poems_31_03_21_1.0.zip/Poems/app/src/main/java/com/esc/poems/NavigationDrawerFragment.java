package com.esc.poems;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.drawerlayout.widget.DrawerLayout.LayoutParams;
import androidx.fragment.app.Fragment;
import androidx.legacy.app.ActionBarDrawerToggle;

import java.util.ArrayList;

public class NavigationDrawerFragment extends Fragment {

    private static final String PREF_USER_LEARNED_DRAWER = "navigation_drawer_learned";
    private static final String STATE_SELECTED_POSITION = "selected_navigation_drawer_position";
    static String[] catt = new String[]{"Home", "Top Poems", "Top Users Poems", "Submit Your Poems", "Missing You", "Friendship", "Love", "Poems", "Good Morning", "Good Night", "Anniversary", "Birthday", "Get Well Soon", "Sympathy", "Sorry", "Baby", "Easter", "Mother's Day", "Father's Day", "Valentine's Day", "Good Luck", "Graduation", "Wedding", "Halloween", "Thanks Giving", "Women's Day", "Christmas", "New Year"};
    private DataBaseHelper DBhelper;
    private ArrayList<String> cc = new ArrayList();
    private Intent intent;
    private NavigationDrawerCallbacks mCallbacks;
    private int mCurrentSelectedPosition = 0;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerListView;
    private ActionBarDrawerToggle mDrawerToggle;
    private View mFragmentContainerView;
    private boolean mFromSavedInstanceState;
    private boolean mUserLearnedDrawer;
    public int sw;

    public interface NavigationDrawerCallbacks {
        void onNavigationDrawerItemSelected(int i, String str);
    }

    public class listAdapter extends BaseAdapter {
        Activity a;
        ArrayList<String> siteNames;

        public long getItemId(int i) {
            return i;
        }

        public listAdapter(Activity activity, ArrayList<String> arrayList) {
            this.a = activity;
            this.siteNames = arrayList;
        }

        public int getCount() {
            return this.siteNames.size();
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            view = this.a.getLayoutInflater().inflate(R.layout.n_list_items, viewGroup, false);
            Typeface createFromAsset = Typeface.createFromAsset(this.a.getAssets(), "fonts/roboto_thin.ttf");
            TextView textView = view.findViewById(R.id.textView1);
            ImageView imageView = view.findViewById(R.id.rateusimg);
            textView.setText(this.siteNames.get(i));
            textView.setTypeface(createFromAsset);
            return view;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getActivity());
        this.DBhelper = dataBaseHelper;
        try {
            dataBaseHelper.createDataBase();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        this.mUserLearnedDrawer = PreferenceManager.getDefaultSharedPreferences(getActivity()).getBoolean(PREF_USER_LEARNED_DRAWER, false);
        if (bundle != null) {
            this.mCurrentSelectedPosition = bundle.getInt(STATE_SELECTED_POSITION);
            this.mFromSavedInstanceState = true;
        }
        selectItem(this.mCurrentSelectedPosition);
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        setHasOptionsMenu(true);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i = 0;
        this.mDrawerListView = (ListView) layoutInflater.inflate(R.layout.fragment_navigation_drawer, viewGroup, false);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.sw = displayMetrics.widthPixels;
        this.mDrawerListView.post(new Runnable() {
            public void run() {
                LayoutParams layoutParams = (LayoutParams) NavigationDrawerFragment.this.mDrawerListView.getLayoutParams();
                double d = NavigationDrawerFragment.this.sw;
                Double.isNaN(d);
                layoutParams.width = (int) (d * 0.6d);
                NavigationDrawerFragment.this.mDrawerListView.setLayoutParams(layoutParams);
            }
        });
        this.mDrawerListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                NavigationDrawerFragment.this.selectItem(i);
            }
        });
        while (true) {
            String[] strArr = catt;
            if (i < strArr.length) {
                this.cc.add(i, strArr[i]);
                i++;
            } else {
                this.mDrawerListView.setAdapter(new listAdapter(getActivity(), this.cc));
                this.mDrawerListView.setItemChecked(this.mCurrentSelectedPosition, true);
                return this.mDrawerListView;
            }
        }
    }


    public boolean isDrawerOpen() {
        DrawerLayout drawerLayout = this.mDrawerLayout;
        return drawerLayout != null && drawerLayout.isDrawerOpen(this.mFragmentContainerView);
    }

    public void setUp(int i, DrawerLayout drawerLayout) {
        this.mFragmentContainerView = getActivity().findViewById(i);
        this.mDrawerLayout = drawerLayout;
        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setHomeButtonEnabled(true);
        getActionBar().setDisplayShowHomeEnabled(true);
        getActionBar().setHomeAsUpIndicator(R.drawable.ic_drawer);
        this.mDrawerToggle = new ActionBarDrawerToggle(getActivity(), this.mDrawerLayout, R.drawable.ic_drawer, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                if (NavigationDrawerFragment.this.isAdded()) {
                    NavigationDrawerFragment.this.getActivity().supportInvalidateOptionsMenu();
                }
            }

            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
                if (NavigationDrawerFragment.this.isAdded()) {
                    if (!NavigationDrawerFragment.this.mUserLearnedDrawer) {
                        NavigationDrawerFragment.this.mUserLearnedDrawer = true;
                        PreferenceManager.getDefaultSharedPreferences(NavigationDrawerFragment.this.getActivity()).edit().putBoolean(NavigationDrawerFragment.PREF_USER_LEARNED_DRAWER, true).apply();
                    }
                    NavigationDrawerFragment.this.getActivity().supportInvalidateOptionsMenu();
                }
            }

            public void onDrawerSlide(View view, float f) {
                super.onDrawerSlide(view, f);
            }
        };
        if (!(this.mUserLearnedDrawer || this.mFromSavedInstanceState)) {
            this.mDrawerLayout.openDrawer(this.mFragmentContainerView);
        }
        this.mDrawerLayout.post(new Runnable() {
            public void run() {
                NavigationDrawerFragment.this.mDrawerToggle.syncState();
            }
        });
        this.mDrawerLayout.setDrawerListener(this.mDrawerToggle);
    }

    private void selectItem(int i) {
        this.mCurrentSelectedPosition = i;
        ListView listView = this.mDrawerListView;
        if (listView != null) {
            listView.setItemChecked(i, true);
        }
        DrawerLayout drawerLayout = this.mDrawerLayout;
        if (drawerLayout != null) {
            drawerLayout.closeDrawer(this.mFragmentContainerView);
        }
        NavigationDrawerCallbacks navigationDrawerCallbacks = this.mCallbacks;
        if (navigationDrawerCallbacks != null) {
            navigationDrawerCallbacks.onNavigationDrawerItemSelected(i, "list");
        }
    }

    public void onResume() {
        super.onResume();
        this.mDrawerListView.setAdapter(new listAdapter(getActivity(), this.cc));
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.mCallbacks = (NavigationDrawerCallbacks) activity;
        } catch (ClassCastException unused) {
            throw new ClassCastException("Activity must implement NavigationDrawerCallbacks.");
        }
    }

    public void onDetach() {
        super.onDetach();
        this.mCallbacks = null;
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(STATE_SELECTED_POSITION, this.mCurrentSelectedPosition);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.mDrawerToggle.onConfigurationChanged(configuration);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        if (this.mDrawerLayout != null && isDrawerOpen()) {
            menuInflater.inflate(R.menu.main, menu);
            showGlobalContextActionBar();
        }
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (this.mDrawerToggle.onOptionsItemSelected(menuItem)) {
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void showGlobalContextActionBar() {
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>Poems</font>"));
    }

    private ActionBar getActionBar() {
        return ((AppCompatActivity) getActivity()).getSupportActionBar();
    }
}
