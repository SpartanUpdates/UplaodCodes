package com.esc.howtomakeschoolsupplies.network;

import kotlin.jvm.internal.Intrinsics;

public class Recommended {
    private final String appLink;
    private final String description;
    private final int id;
    private final String imageName;

    public final int component1() {
        return this.id;
    }

    public final String component2() {
        return this.description;
    }

    public final String component3() {
        return this.appLink;
    }

    public final String component4() {
        return this.imageName;
    }

    public final Recommended copy(int i, String str, String str2, String str3) {
        Intrinsics.checkParameterIsNotNull(str, "description");
        Intrinsics.checkParameterIsNotNull(str2, "appLink");
        Intrinsics.checkParameterIsNotNull(str3, "imageName");
        return new Recommended(i, str, str2, str3);
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof Recommended) {
                Recommended recommended = (Recommended) obj;
                if (!((this.id == recommended.id ? 1 : null) != null && Intrinsics.areEqual(this.description, recommended.description) && Intrinsics.areEqual(this.appLink, recommended.appLink) && Intrinsics.areEqual(this.imageName, recommended.imageName))) {
                    return false;
                }
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i = this.id * 31;
        String str = this.description;
        int i2 = 0;
        i = (i + (str != null ? str.hashCode() : 0)) * 31;
        str = this.appLink;
        i = (i + (str != null ? str.hashCode() : 0)) * 31;
        str = this.imageName;
        if (str != null) {
            i2 = str.hashCode();
        }
        return i + i2;
    }

    public String toString() {
        return "Recommended(id=" + this.id + ", description=" + this.description + ", appLink=" + this.appLink + ", imageName=" + this.imageName + ")";
    }

    public Recommended(int i, String str, String str2, String str3) {
        Intrinsics.checkParameterIsNotNull(str, "description");
        Intrinsics.checkParameterIsNotNull(str2, "appLink");
        Intrinsics.checkParameterIsNotNull(str3, "imageName");
        this.id = i;
        this.description = str;
        this.appLink = str2;
        this.imageName = str3;
    }

    public final int getId() {
        return this.id;
    }

    public final String getDescription() {
        return this.description;
    }

    public final String getAppLink() {
        return this.appLink;
    }

    public final String getImageName() {
        return this.imageName;
    }
}
