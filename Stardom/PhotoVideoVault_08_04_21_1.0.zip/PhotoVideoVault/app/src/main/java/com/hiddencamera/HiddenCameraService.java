package com.hiddencamera;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.annotation.RequiresPermission;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

public abstract class HiddenCameraService extends Service implements CameraCallbacks {
    private CameraPreview mCameraPreview;
    private WindowManager mWindowManager;

    private CameraPreview addPreView() {
        final CameraPreview cameraPreview = new CameraPreview((Context) this, this);
        cameraPreview.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.mWindowManager = (WindowManager) this.getSystemService("window");
        int n;
        if (Build.VERSION.SDK_INT < 26) {
            n = 2006;
        } else {
            n = 2038;
        }
        this.mWindowManager.addView((View) cameraPreview, (ViewGroup.LayoutParams) new WindowManager.LayoutParams(1, 1, n, 262144, -3));
        return cameraPreview;
    }

    public void onDestroy() {
        super.onDestroy();
        this.stopCamera();
    }

    public void onTaskRemoved(final Intent intent) {
        super.onTaskRemoved(intent);
        this.stopCamera();
    }

    @RequiresPermission(allOf = {"android.permission.CAMERA", "android.permission.SYSTEM_ALERT_WINDOW"})
    public void startCamera(final CameraConfig cameraConfig) {
        if (!HiddenCameraUtils.canOverDrawOtherApps((Context) this)) {
            this.onCameraError(3136);
            return;
        }
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(), "android.permission.CAMERA") != 0) {
            this.onCameraError(5472);
            return;
        }
        if (cameraConfig.getFacing() == 1 && !HiddenCameraUtils.isFrontCameraAvailable((Context) this)) {
            this.onCameraError(8722);
            return;
        }
        if (this.mCameraPreview == null) {
            this.mCameraPreview = this.addPreView();
        }
        this.mCameraPreview.startCameraInternal(cameraConfig);
    }

    public void stopCamera() {
        if (this.mCameraPreview != null) {
            this.mWindowManager.removeView((View) this.mCameraPreview);
            this.mCameraPreview.stopPreviewAndFreeCamera();
        }
    }

    public void takePicture() {
        if (this.mCameraPreview != null) {
            if (this.mCameraPreview.isSafeToTakePictureInternal()) {
                this.mCameraPreview.takePictureInternal();
            }
            return;
        }
        throw new RuntimeException("Background camera not initialized. Call startCamera() to initialize the camera.");
    }
}
