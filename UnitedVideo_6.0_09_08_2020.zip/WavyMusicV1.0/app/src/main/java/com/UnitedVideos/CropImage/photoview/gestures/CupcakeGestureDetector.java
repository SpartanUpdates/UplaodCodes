package com.UnitedVideos.CropImage.photoview.gestures;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;


public class CupcakeGestureDetector
  implements GestureDetector
{
  protected OnGestureListener mListener;
  private static final String LOG_TAG = "CupcakeGestureDetector";
  float mLastTouchX;
  float mLastTouchY;
  final float mTouchSlop;
  final float mMinimumVelocity;
  private VelocityTracker mVelocityTracker;
  private boolean mIsDragging;
  
  public void setOnGestureListener(OnGestureListener listener)
  {
    mListener = listener;
  }
  
  public CupcakeGestureDetector(Context context) {
    ViewConfiguration configuration = 
      ViewConfiguration.get(context);
    mMinimumVelocity = configuration.getScaledMinimumFlingVelocity();
    mTouchSlop = configuration.getScaledTouchSlop();
  }
  


  float getActiveX(MotionEvent ev)
  {
    return ev.getX();
  }
  
  float getActiveY(MotionEvent ev) {
    return ev.getY();
  }
  
  public boolean isScaling() {
    return false;
  }
  
  public boolean onTouchEvent(MotionEvent ev)
  {
    switch (ev.getAction()) {
    case 0: 
      mVelocityTracker = VelocityTracker.obtain();
      if (mVelocityTracker != null) {
        mVelocityTracker.addMovement(ev);
      } else {
        Log.i("CupcakeGestureDetector", "Velocity tracker is null");
      }
      
      mLastTouchX = getActiveX(ev);
      mLastTouchY = getActiveY(ev);
      mIsDragging = false;
      break;
    

    case 2: 
      float x = getActiveX(ev);
      float y = getActiveY(ev);
      float dx = x - mLastTouchX;float dy = y - mLastTouchY;
      
      if (!mIsDragging)
      {

        mIsDragging = (Math.sqrt(dx * dx + dy * dy) >= mTouchSlop);
      }
      
      if (mIsDragging) {
        mListener.onDrag(dx, dy);
        mLastTouchX = x;
        mLastTouchY = y;
        
        if (mVelocityTracker != null) {
          mVelocityTracker.addMovement(ev);
        }
      }
      break;
    


    case 3: 
      if (mVelocityTracker != null) {
        mVelocityTracker.recycle();
        mVelocityTracker = null;
      }
      break;
    

    case 1: 
      if ((mIsDragging) && 
        (mVelocityTracker != null)) {
        mLastTouchX = getActiveX(ev);
        mLastTouchY = getActiveY(ev);
        mVelocityTracker.addMovement(ev);
        mVelocityTracker.computeCurrentVelocity(1000);
        
        float vX = mVelocityTracker.getXVelocity();
        float vY = mVelocityTracker.getYVelocity();

        if (Math.max(Math.abs(vX), Math.abs(vY)) >= mMinimumVelocity) {
          mListener.onFling(mLastTouchX, mLastTouchY, -vX, 
            -vY);
        }
      }
      


      if (mVelocityTracker != null) {
        mVelocityTracker.recycle();
        mVelocityTracker = null;
      }
      
      break;
    }
    
    return true;
  }
}
