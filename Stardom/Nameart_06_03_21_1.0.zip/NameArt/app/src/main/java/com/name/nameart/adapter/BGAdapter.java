package com.name.nameart.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.name.nameart.FavDesign.NameEditing;
import com.name.nameart.R;

import java.util.ArrayList;


public class BGAdapter extends RecyclerView.Adapter<BGAdapter.ViewHolder> {
    public int[] bgarray = {R.drawable.ic_add_image_bg, R.drawable.bg_36, R.drawable.bg_25, R.drawable.bg_26, R.drawable.bg_21, R.drawable.bg_22, R.drawable.bg_23, R.drawable.bg_24, R.drawable.bg_27, R.drawable.bg_28, R.drawable.bg_29, R.drawable.bg_30, R.drawable.bg_31, R.drawable.bg_32, R.drawable.bg_33, R.drawable.bg_34, R.drawable.bg_35, R.drawable.bg_37, R.drawable.bg_38, R.drawable.bg_39, R.drawable.bg_40, R.drawable.bg_11, R.drawable.bg_12, R.drawable.bg_13, R.drawable.bg_14, R.drawable.bg_15, R.drawable.bg_16, R.drawable.bg_17, R.drawable.bg_18, R.drawable.bg_19, R.drawable.bg_20, R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4, R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7, R.drawable.bg_8, R.drawable.bg_9, R.drawable.bg_10, R.drawable.gradient_bg_1, R.drawable.gradient_bg_2, R.drawable.gradient_bg_3, R.drawable.gradient_bg_4, R.drawable.gradient_bg_5, R.drawable.gradient_bg_6, R.drawable.gradient_bg_7, R.drawable.gradient_bg_8, R.drawable.gradient_bg_9, R.drawable.gradient_bg_10, R.drawable.gradient_bg_11, R.drawable.gradient_bg_12, R.drawable.gradient_bg_13, R.drawable.gradient_bg_14, R.drawable.gradient_bg_15, R.drawable.gradient_bg_16};
    public ArrayList<Integer> coloe_array;
    Context context;
    int[] finalarray;
    int i = 0;
    int i2 = 0;
    int i3 = 0;
    int index = -1;
    public int[] intArray;
    OnSelect onSelect;
    public final int pick = 2;
    String status;

    public interface OnSelect {
        void onSelectbg(int i, int i2);
    }

    public BGAdapter(Context context2, String str, OnSelect onSelect2) {
        this.context = context2;
        this.status = str;
        this.onSelect = onSelect2;
        int[] intArray2 = context2.getResources().getIntArray(R.array.allcolors);
        this.intArray = intArray2;
        this.finalarray = new int[(this.bgarray.length + intArray2.length)];
        while (true) {
            int i4 = this.i2;
            int[] iArr = this.bgarray;
            if (i4 >= iArr.length) {
                break;
            }
            this.finalarray[i4] = iArr[i4];
            this.i3++;
            this.i2 = i4 + 1;
        }
        while (true) {
            int i5 = this.i;
            int[] iArr2 = this.intArray;
            if (i5 < iArr2.length) {
                int[] iArr3 = this.finalarray;
                int i6 = this.i3;
                iArr3[i6] = iArr2[i5];
                this.i = i5 + 1;
                this.i3 = i6 + 1;
            } else {
                return;
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i4) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.color_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i4) {
        try {
            if (!this.status.equals("bg")) {
                viewHolder.color_img_row.setImageDrawable(null);
                viewHolder.color_img_row.setBackgroundColor(this.finalarray[i4]);
            } else if (i4 <= 56) {
                if (i4 == 0) {
                    try {
                        viewHolder.color_img_row.setPadding(this.context.getResources().getDimensionPixelSize(R.dimen._8sdp), this.context.getResources().getDimensionPixelSize(R.dimen._10sdp), this.context.getResources().getDimensionPixelSize(R.dimen._8sdp), this.context.getResources().getDimensionPixelSize(R.dimen._8sdp));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    viewHolder.color_img_row.setPadding(0, 0, 0, 0);
                }
                Glide.with(this.context).load(Integer.valueOf(this.finalarray[i4])).into(viewHolder.color_img_row);
                viewHolder.color_img_row.setBackgroundColor(Color.parseColor("#3B4144"));
            } else {
                viewHolder.color_img_row.setImageDrawable(null);
                viewHolder.color_img_row.setBackgroundColor(this.finalarray[i4]);
            }
            viewHolder.color_img_row.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    BGAdapter.this.index = i4;
                    BGAdapter.this.notifyDataSetChanged();
                    if (BGAdapter.this.status.equals("bg")) {
                        OnSelect onSelect = BGAdapter.this.onSelect;
                        int[] iArr = BGAdapter.this.finalarray;
                        int i = i4;
                        onSelect.onSelectbg(iArr[i], i);
                    }
                }
            });
            if (this.index == i4) {
                viewHolder.row_bg.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.row_bg.setBackgroundColor(0);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.finalarray.length;
    }

    public void pickImageFromSource() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction("android.intent.action.GET_CONTENT");
        ((NameEditing) this.context).startActivityForResult(Intent.createChooser(intent, "Select Picture"), 2);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView color_img_row;
        public View parentLayout;
        public ConstraintLayout row_bg;

        public ViewHolder(View view) {
            super(view);
            this.color_img_row = (ImageView) view.findViewById(R.id.color_img_row);
            this.row_bg = (ConstraintLayout) view.findViewById(R.id.row_bg);
        }

        public ImageView getImage() {
            return this.color_img_row;
        }
    }
}
