package com.kotlinz.videoeditor.editvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.edmodo.cropper.CropImageView;
import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.audiovideomixer.activity.AudioVideoMixerActivity;
import com.kotlinz.videoeditor.cropvideo.activity.VideoCropActivity;
import com.kotlinz.videoeditor.editvideo.Utils.FileUtils;
import com.kotlinz.videoeditor.fastmotionvideo.activity.FastMotionVideoActivity;
import com.kotlinz.videoeditor.slowmotionvideo.activity.SlowMotionVideoActivity;
import com.kotlinz.videoeditor.videocompress.VideoCompressorActivity;
import com.kotlinz.videoeditor.videoreverse.VideoReverseActivity;
import com.kotlinz.videoeditor.videorotate.VideoRotateActivity;
import com.kotlinz.videoeditor.videotoimg.VideoToImageActivity;
import com.kotlinz.videoeditor.videotomp3.activity.VideoToMP3ConverterActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;


@SuppressLint({"WrongConstant"})
public class EditActivity extends AppCompatActivity {
    Activity activity = EditActivity.this;
    TextView leftponter;
    static final boolean af = true;
    String videofilename;
    String left = "00";

    ImageButton slowmotion;
    ImageButton fastmotion;
    ImageButton reversemotion;
    ImageButton addaudio;
    ImageButton videotomp3;
    ImageButton snapshot;
    ImageButton compress;
    ImageButton crop;
    ImageButton rotation;

    TextView rightpointer;
    Bitmap U;
    View V;
    VideoPlayerState videoPlayerState = new VideoPlayerState();
    VideoSliceSeekBar videoSliceSeekBar;
    a Y = new a();
    VideoView videoView;
    CropImageView cropImageView;

    String right;

    ImageView iv_back, iv_done;
    int q;
    int r;

    int w;
    int x;

    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            b = false;
            c = new Runnable() {
                public void run() {
                    a.this.a();
                }
            };
        }


        public void a() {
            if (!b) {
                b = EditActivity.af;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            b = false;
            videoSliceSeekBar.videoPlayingProgress(videoView.getCurrentPosition());
            if (!videoView.isPlaying() || videoView.getCurrentPosition() >= videoSliceSeekBar.getRightProgress()) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    V.setBackgroundResource(R.drawable.ic_play_upress);
                    videoView.seekTo(100);
                }
                videoSliceSeekBar.setSliceBlocked(false);
                videoSliceSeekBar.removeVideoStatusThumb();
                return;
            }
            postDelayed(c, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.editactivity);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        PutAnalyticsEvent();
        slowmotion = findViewById(R.id.imb_slow);
        fastmotion = findViewById(R.id.ibm_fast);
        reversemotion = findViewById(R.id.ibm_reverse);
        snapshot = findViewById(R.id.ibm_snapshot);
        compress = findViewById(R.id.ibm_compress);
        addaudio = findViewById(R.id.ibm_addaudio);
        rotation = findViewById(R.id.ibm_roatation);
        videotomp3 = findViewById(R.id.ibm_mp3);
        crop = findViewById(R.id.ibm_crop);
        iv_done = findViewById(R.id.iv_done);
        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        iv_done.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TrimVideoPrivewActivity.class);
                intent.putExtra("videofilename", EditActivity.this.videofilename);
                startActivity(intent);
                finish();
            }
        });

        videofilename = getIntent().getStringExtra("videofilename");

        crop.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                // now visible in gallery
                            }
                        });
                Intent intent = new Intent(getApplicationContext(), VideoCropActivity.class);
                intent.setFlags(67108864);
                intent.putExtra("videofilename", EditActivity.this.videofilename);

                startActivity(intent);
                finish();
            }
        });

        slowmotion.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                            }
                        });
                Intent intent = new Intent(getApplicationContext(), SlowMotionVideoActivity.class);
                intent.setFlags(67108864);
                intent.putExtra("videofilename", EditActivity.this.videofilename);

                startActivity(intent);
                finish();
            }
        });
        fastmotion.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                            }
                        });
                Intent intent = new Intent(getApplicationContext(), FastMotionVideoActivity.class);
                intent.setFlags(67108864);
                intent.putExtra("videofilename", EditActivity.this.videofilename);

                startActivity(intent);
                finish();
            }
        });
        reversemotion.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                // now visible in gallery
                            }
                        });
                Intent intent = new Intent(getApplicationContext(), VideoReverseActivity.class);
                intent.setFlags(67108864);
                intent.putExtra("videouri", EditActivity.this.videofilename);

                startActivity(intent);
                finish();
            }
        });

        snapshot.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                Intent intent = new Intent(activity, VideoToImageActivity.class);
                intent.putExtra("videouri", videofilename);
                startActivity(intent);
                finish();
            }
        });

        compress.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                Intent intent = new Intent(activity, VideoCompressorActivity.class);
                intent.putExtra("videouri", EditActivity.this.videofilename);
                startActivity(intent);
                finish();
            }
        });
        videotomp3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                Intent intent = new Intent(getApplicationContext(), VideoToMP3ConverterActivity.class);
                intent.putExtra("videopath", EditActivity.this.videofilename);
                startActivity(intent);
                finish();
            }
        });

        addaudio.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                Intent intent = new Intent(getApplicationContext(), AudioVideoMixerActivity.class);
                intent.putExtra("song", EditActivity.this.videofilename);
                startActivity(intent);
                finish();
            }
        });

        rotation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                File file = new File(videofilename);
                MediaScannerConnection.scanFile(EditActivity.this, new String[]{file.getPath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                Intent intent = new Intent(getApplicationContext(), VideoRotateActivity.class);
                intent.putExtra("videoPath", EditActivity.this.videofilename);
                startActivity(intent);
                finish();
            }
        });
        if (videofilename != null) {
            U = ThumbnailUtils.createVideoThumbnail(videofilename, 1);
        }
        FrameLayout frameLayout = findViewById(R.id.rl_container);
        LayoutParams layoutParams = (LayoutParams) frameLayout.getLayoutParams();
        x = FileUtils.getScreenWidth();
        layoutParams.width = x;
        layoutParams.height = x;
        frameLayout.setLayoutParams(layoutParams);
        cropImageView = findViewById(R.id.cropperView);
        d();
        e();
        return;
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "EditActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    @Override
    public void onResume() {
        videoView.seekTo(videoPlayerState.getCurrentTime());
        super.onResume();
    }


    @Override
    public void onPause() {
        super.onPause();
        videoPlayerState.setCurrentTime(videoView.getCurrentPosition());
    }

    private void d() {
        leftponter = findViewById(R.id.left_pointer);
        rightpointer = findViewById(R.id.right_pointer);
        videoSliceSeekBar = findViewById(R.id.seek_bar);
        V = findViewById(R.id.buttonply);
        V.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView == null || !videoView.isPlaying()) {
                    V.setBackgroundResource(R.drawable.ic_pause_unpresss);
                } else {
                    V.setBackgroundResource(R.drawable.ic_play_upress);
                }
                g();
            }
        });
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            videoPlayerState = (VideoPlayerState) lastNonConfigurationInstance;
        } else {
            videoPlayerState.setFilename(videofilename);
        }

    }

    @SuppressLint({"NewApi"})
    private void e() {
        videoView = findViewById(R.id.videoview);
        videoView.setVideoPath(videofilename);
        right = getTimeForTrackFormat(videoView.getDuration(), af);
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        mediaMetadataRetriever.setDataSource(videofilename);
        r = Integer.valueOf(mediaMetadataRetriever.extractMetadata(18)).intValue();
        q = Integer.valueOf(mediaMetadataRetriever.extractMetadata(19)).intValue();
        if (VERSION.SDK_INT > 16) {
            w = Integer.valueOf(mediaMetadataRetriever.extractMetadata(24)).intValue();
        } else {
            w = 0;
        }
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                V.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                videoSliceSeekBar.setSeekBarChangeListener(new SeekBarChangeListener() {

                    public void SeekBarValueChanged(int i, int i2) {
                        if (videoSliceSeekBar.getSelectedThumb() == 1) {
                            videoView.seekTo(videoSliceSeekBar.getLeftProgress());
                        }
                        leftponter.setText(getTimeForTrackFormat(i, af));
                        rightpointer.setText(getTimeForTrackFormat(i2, af));
                        left = getTimeForTrackFormat(i, af);
                        videoPlayerState.setStart(i);
                        right = getTimeForTrackFormat(i2, af);
                        videoPlayerState.setStop(i2);
                    }
                });
                right = getTimeForTrackFormat(mediaPlayer.getDuration(), af);
                videoSliceSeekBar.setMaxValue(mediaPlayer.getDuration());
                videoSliceSeekBar.setLeftProgress(0);
                videoSliceSeekBar.setRightProgress(mediaPlayer.getDuration());
                videoSliceSeekBar.setProgressMinDiff(0);
                videoView.seekTo(100);
            }
        });
    }

    public void g() {
        if (videoView.isPlaying()) {
            videoView.pause();
            videoSliceSeekBar.setSliceBlocked(false);
            videoSliceSeekBar.removeVideoStatusThumb();
            return;
        }
        videoView.seekTo(videoSliceSeekBar.getLeftProgress());
        videoView.start();
        videoSliceSeekBar.videoPlayingProgress(videoSliceSeekBar.getLeftProgress());
        Y.a();
    }

    public static String getTimeForTrackFormat(int i2, boolean z2) {
        String str;
        int i3 = i2 / 60000;
        int i4 = (i2 - ((i3 * 60) * 1000)) / 1000;
        StringBuilder sb = new StringBuilder((!z2 || i3 >= 10) ? "" : "0");
        sb.append(i3 % 60);
        sb.append(":");
        String sb2 = sb.toString();
        if (i4 < 10) {
            StringBuilder sb3 = new StringBuilder(sb2);
            sb3.append("0");
            sb3.append(i4);
            str = sb3.toString();
        } else {
            StringBuilder sb4 = new StringBuilder(sb2);
            sb4.append(i4);
            str = sb4.toString();
        }
        StringBuilder sb5 = new StringBuilder();
        sb5.append("Display Result");
        sb5.append(str);
        Log.e("", sb5.toString());
        return str;
    }


    @SuppressLint("ResourceType")
    public void j() {
        new AlertDialog.Builder(this).setIcon(17301543).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                EditActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Images.Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    private void ExitConfirmation() {
        new AlertDialog.Builder(this).setMessage("All changes will be discarded.").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(activity, StartActivity.class);
                startActivity(intent);
                finish();;
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }


    public void onBackPressed() {
        ExitConfirmation();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_picker, menu);
        MenuItem item = menu.findItem(R.id.Done);
        item.setVisible(false);
        this.invalidateOptionsMenu();
        return af;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return af;
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
