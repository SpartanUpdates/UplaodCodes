package com.xyz.vehiclemanager.bike.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.activity.BikeVariantTabActivity;
import com.xyz.vehiclemanager.bike.model.BikeDetailsRoot;

import java.util.ArrayList;

public class BikeVariantAdapter extends RecyclerView.Adapter<BikeVariantAdapter.ViewHolder> {
    Context context;
    ArrayList<BikeDetailsRoot.Details.Variant> bikeVariantlist;

    public BikeVariantAdapter(Context context, ArrayList<BikeDetailsRoot.Details.Variant> bikeVariantlist) {
        this.context = context;
        this.bikeVariantlist = bikeVariantlist;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_variantName, tv_variantSpecs, tv_engineDisplacement, tv_maxPower, tv_kerbWeight, tv_variantPrice;
        LinearLayout ll_main;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_variantName = itemView.findViewById(R.id.tv_variantName);
            tv_variantSpecs = itemView.findViewById(R.id.tv_varientsSpecs);
            tv_engineDisplacement = itemView.findViewById(R.id.tv_engineDisplacement);
            tv_maxPower = itemView.findViewById(R.id.tv_maxPower);
            tv_kerbWeight = itemView.findViewById(R.id.kerbWeight);
            tv_variantPrice = itemView.findViewById(R.id.tv_variantPrice);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.layout_bikevariant, parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final BikeDetailsRoot.Details.Variant bikeVarient = bikeVariantlist.get(position);
        holder.tv_variantName.setText(bikeVarient.getVariantName());
        holder.tv_variantSpecs.setText(bikeVarient.getVariantSpecs());
        holder.tv_engineDisplacement.setText(bikeVarient.getEngineDisplacement());
        holder.tv_maxPower.setText(bikeVarient.getMaxPower());
        holder.tv_kerbWeight.setText(bikeVarient.getKerbWeight());
        holder.tv_variantPrice.setText(bikeVarient.getVariantPrice());

        final String id= String.valueOf(bikeVarient.getId());

        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context, BikeVariantTabActivity.class);
                i.putExtra("VarientId",id);
                i.putExtra("VarientName",bikeVarient.getVariantName());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bikeVariantlist.size();
    }
}
