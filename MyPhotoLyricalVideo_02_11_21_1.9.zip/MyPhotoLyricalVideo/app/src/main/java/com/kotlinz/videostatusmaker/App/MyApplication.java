package com.kotlinz.videostatusmaker.App;

import android.app.Activity;
import android.app.Application;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.Activity.ActivityArrangePhoto;
import com.kotlinz.videostatusmaker.Activity.ActivityMyCreations;
import com.kotlinz.videostatusmaker.Activity.ActivitySelectLyrics;
import com.kotlinz.videostatusmaker.Activity.ActivityVideoSave;
import com.kotlinz.videostatusmaker.Activity.ActivityViewAlImages;
import com.kotlinz.videostatusmaker.Activity.FirstActivity;
import com.kotlinz.videostatusmaker.Activity.MainActivity;
import com.kotlinz.videostatusmaker.OpenAppAds.AppOpenAdManager;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityImageFolder;
import com.kotlinz.videostatusmaker.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MyApplication extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {


    private static MyApplication instance;

    public static int Variable_VIDEO_HEIGHT = 720;
    public static int Variable_VIDEO_WIDTH = 720;

    public static Activity activity;

    public static InterstitialAd mInterstitialAd;
    public static int isShowAd = 0;
    public static int AdsId;

    public static String OutPutPath;

    FirebaseAnalytics mFirebaseAnalytics;

    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    private void CustomAnalyticsEvent(String ActivityName, String AdsShowName) {
        Bundle params = new Bundle();
        params.putString("ActivityName", ActivityName);
        params.putString("AdsShowName", AdsShowName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, params);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        this.registerActivityLifecycleCallbacks(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        appOpenAdManager = new AppOpenAdManager();
        interstitialAd();
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (AdsId) {
                                            case 1:
                                                activity.startActivity(new Intent(activity, ActivitySelectLyrics.class));
                                                break;
                                            case 2:
                                                GoToSave();
                                                break;
                                            case 3:
                                                activity.startActivity(new Intent(activity, MainActivity.class));
                                                break;
                                            case 4:
                                                activity.startActivity(new Intent(activity, ActivityMyCreations.class));
                                                break;
                                            case 5:
                                                activity.startActivity(new Intent(activity, ActivityViewAlImages.class));
                                                break;
                                            case 6:
                                                activity.setResult(-1);
                                                activity.finish();
                                                break;
                                            case 7:
                                                activity.onBackPressed();
                                                break;
                                            case 8:
                                                activity.onBackPressed();
                                                break;
                                            case 9:
                                                activity.setResult(-1);
                                                activity.finish();
                                                break;
                                            case 10:
                                                activity.onBackPressed();
                                                break;
                                            case 11:
                                                activity.setResult(-1);
                                                activity.finish();
                                                break;
                                            case 12:
                                                activity.onBackPressed();
                                                break;
                                            case 13:
                                                activity.startActivity(new Intent(activity, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                                                activity.finish();
                                                break;
                                            case 15:
                                                activity.startActivity(new Intent(activity, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                                                activity.finish();
                                                break;
                                            case 16:
                                                activity.onBackPressed();
                                                break;
                                            case 17:
                                                activity.onBackPressed();
                                                break;
                                            case 18:
                                                activity.onBackPressed();
                                                break;
                                            case 19:
                                                activity.onBackPressed();
                                                break;
                                            case 20:
                                                activity.onBackPressed();
                                                break;
                                            case 21:
                                                activity.onBackPressed();
                                                break;
                                            case 22:
                                                activity.startActivity(new Intent(activity, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                                                activity.finish();
                                                break;
                                            case 23:
                                                activity.onBackPressed();
                                                break;
                                            case 24:
                                                activity.startActivity(new Intent(activity, ActivityArrangePhoto.class));
                                                break;
                                            case 25:
                                                activity.startActivity(new Intent(activity, ActivityImageFolder.class));
                                                break;
                                            case 26:
                                                activity.startActivity(new Intent(activity, ActivityImageFolder.class));
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                                        switch (AdsId) {
                                            case 1:
                                                CustomAnalyticsEvent("ArrangeActivity", "DoneButton");
                                                break;
                                            case 2:
                                                CustomAnalyticsEvent("ActivityPreview", "SaveDialogButton");
                                                break;
                                            case 3:
                                                CustomAnalyticsEvent("FirstActivity", "StartButton");
                                                break;
                                            case 4:
                                                CustomAnalyticsEvent("FirstActivity", "MyCreationButton");
                                                break;
                                            case 5:
                                                CustomAnalyticsEvent("ActivityAllPhotos", "DoneButton");
                                                break;
                                            case 6:
                                                CustomAnalyticsEvent("ActivityAddText", "DoneButton");
                                                break;
                                            case 7:
                                                CustomAnalyticsEvent("ActivityAddText", "BackButton");
                                                break;
                                            case 8:
                                                CustomAnalyticsEvent("ActivityArrangePhoto", "BackButton");
                                                break;
                                            case 9:
                                                CustomAnalyticsEvent("ActivityDrawImage", "DoneButton");
                                                break;
                                            case 10:
                                                CustomAnalyticsEvent("ActivityDrawImage", "BackButton");
                                                break;
                                            case 11:
                                                CustomAnalyticsEvent("ActivityEditImage", "DoneButton");
                                                break;
                                            case 12:
                                                CustomAnalyticsEvent("ActivityEditImage", "BackButton");
                                                break;
                                            case 13:
                                                CustomAnalyticsEvent("ActivityMyCreations", "BackButton");
                                                break;
                                            case 15:
                                                CustomAnalyticsEvent("ActivityMyCreationVideoPlay", "BackButton");
                                                break;
                                            case 16:
                                                CustomAnalyticsEvent("ActivityPreview", "BackButton");
                                                break;
                                            case 17:
                                                CustomAnalyticsEvent("ActivitySelectLyrics", "BackButton");
                                                break;
                                            case 18:
                                                CustomAnalyticsEvent("ActivitySelectText", "BackButton");
                                                break;
                                            case 19:
                                                CustomAnalyticsEvent("ActivitySelectTheme", "BackButton");
                                                break;
                                            case 20:
                                                CustomAnalyticsEvent("ActivitySetting", "BackButton");
                                                break;
                                            case 21:
                                                CustomAnalyticsEvent("ActivityStickerSelect", "BackButton");
                                                break;
                                            case 22:
                                                CustomAnalyticsEvent("ActivityVideo", "BackButton");
                                                break;
                                            case 23:
                                                CustomAnalyticsEvent("ActivityViewAllImage", "BackButton");
                                                break;
                                            case 24:
                                                CustomAnalyticsEvent("ActivityViewAllImage", "BackButton");
                                                break;
                                            case 25:
                                                CustomAnalyticsEvent("MainActivity", "SquareButton");
                                                break;
                                            case 26:
                                                CustomAnalyticsEvent("MainActivity", "FullScreenButton");
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    private void GoToSave() {
        Intent intent = new Intent(activity, ActivityVideoSave.class);
        intent.putExtra("outpath", MyApplication.OutPutPath);
        activity.startActivity(intent);
        activity.finish();
    }

    /*AppOpenAds Start*/
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    /**
     * Shows an app open ad.
     *
     * @param activity                 the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    /*AppOpenAds End*/

}
