package com.hiddencamera;

import android.content.Context;
import androidx.annotation.NonNull;

import java.io.File;

public final class CameraConfig {
    private Context mContext;
    private int mFacing;
    private File mImageFile;
    private int mImageFormat;
    private int mImageRotation;
    private int mResolution;

    public CameraConfig() {
        super();
        this.mResolution = 7895;
        this.mFacing = 0;
        this.mImageFormat = 849;
        this.mImageRotation = 0;
    }

    public Builder getBuilder(final Context mContext) {
        this.mContext = mContext;
        return new Builder();
    }

    int getFacing() {
        return this.mFacing;
    }

    File getImageFile() {
        return this.mImageFile;
    }

    int getImageFormat() {
        return this.mImageFormat;
    }

    int getResolution() {
        return this.mResolution;
    }

    int getmImageRotation() {
        return this.mImageRotation;
    }

    public class Builder {
        @NonNull
        private File getDefaultStorageFile() {
            final StringBuilder append = new StringBuilder().append(HiddenCameraUtils.getCacheDir(CameraConfig.this.mContext).getAbsolutePath()).append(File.pathSeparator).append("IMG_").append(System.currentTimeMillis());
            String s;
            if (CameraConfig.this.mImageFormat == 849) {
                s = ".jpeg";
            } else {
                s = ".png";
            }
            return new File(append.append(s).toString());
        }

        public CameraConfig build() {
            if (CameraConfig.this.mImageFile == null) {
                CameraConfig.this.mImageFile = this.getDefaultStorageFile();
            }
            return CameraConfig.this;
        }

        public Builder setCameraFacing(final int n) {
            if (n != 0 && n != 1) {
                throw new RuntimeException("Invalid camera facing value.");
            }
            CameraConfig.this.mFacing = n;
            return this;
        }

        public Builder setCameraResolution(final int n) {
            if (n != 2006 && n != 7895 && n != 7821) {
                throw new RuntimeException("Invalid camera resolution.");
            }
            CameraConfig.this.mResolution = n;
            return this;
        }

        public Builder setImageFile(final File file) {
            CameraConfig.this.mImageFile = file;
            return this;
        }

        public Builder setImageFormat(final int n) {
            if (n != 849 && n != 545) {
                throw new RuntimeException("Invalid output image format.");
            }
            CameraConfig.this.mImageFormat = n;
            return this;
        }

        public Builder setImageRotation(final int n) {
            if (n != 0 && n != 90 && n != 180 && n != 270) {
                throw new RuntimeException("Invalid image rotation.");
            }
            CameraConfig.this.mImageRotation = n;
            return this;
        }
    }
}
