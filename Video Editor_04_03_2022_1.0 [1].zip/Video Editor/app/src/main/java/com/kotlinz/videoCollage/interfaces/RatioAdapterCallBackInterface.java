package com.kotlinz.videoCollage.interfaces;

public interface RatioAdapterCallBackInterface {
    void itemClick(int i);
}
