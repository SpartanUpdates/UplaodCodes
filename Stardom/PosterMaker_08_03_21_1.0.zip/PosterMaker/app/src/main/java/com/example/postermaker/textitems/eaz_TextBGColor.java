package com.example.postermaker.textitems;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import com.example.postermaker.R;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.utilities.eaz_GradientDrawable;

public class eaz_TextBGColor implements OnClickListener
{
    int[] allcolors;
    int colorselection = 0;
    Context context;

    public eaz_TextBGColor(int i, Context context)
    {
        this.colorselection = i;
        this.context = context;
    }

    public void applyTextBGColor()
    {
        eaz_EditActivity.textbgcoloritemlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.oktextbgcolor.setOnClickListener(this);
        eaz_EditActivity.canceltextbgcolor.setOnClickListener(this);
        this.allcolors = this.context.getResources().getIntArray(R.array.allcolors);
        loadColors();
    }

    public void loadColors() {
        eaz_EditActivity.textbgcolorlayout.removeAllViews();
        for (int i = 0; i < this.allcolors.length; i++) {
            ImageView imageView = new ImageView(this.context);
            circularImageView(imageView, this.allcolors[i]);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (eaz_TextBGColor.this.colorselection == 0) {
                        eaz_TextShapeStaticValues.textbgcolor = eaz_TextBGColor.this.allcolors[finalI];
                        new eaz_GradientDrawable().manageText(eaz_TextShapeStaticValues.textbgcolor, eaz_TextShapeStaticValues.bordercolor, eaz_TextShapeStaticValues.textbgbordersize, eaz_TextShapeStaticValues.textbgborderspace, eaz_TextShapeStaticValues.textbgradius);
                    }
                    if (eaz_TextBGColor.this.colorselection == 1) {
                        eaz_EditActivity.logoText.setTextColor(eaz_TextBGColor.this.allcolors[finalI]);
                    }
                }
            });
            eaz_EditActivity.textbgcolorlayout.addView(imageView);
        }
    }

    public void circularImageView(ImageView imageView, int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.OVAL);
        gradientDrawable.setColor(i);
        imageView.setBackground(gradientDrawable);

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                ViewGroup.MarginLayoutParams.MATCH_PARENT,
                ViewGroup.MarginLayoutParams.WRAP_CONTENT
        );
        marginLayoutParams.setMargins(5, 5, 5, 5);
        imageView.setPadding(40, 40, 40, 40);
        imageView.setLayoutParams(marginLayoutParams);
        //imageView.setLayoutParams(new LayoutParams(45, 45));
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.oktextbgcolor)) {
            eaz_EditActivity.textbgcoloritemlayout.setVisibility(View.INVISIBLE);
        } else if (view.equals(eaz_EditActivity.canceltextbgcolor)) {
            eaz_EditActivity.logoText.setBackgroundColor(0);
            eaz_EditActivity.textbgcoloritemlayout.setVisibility(View.INVISIBLE);
        }
    }
}
