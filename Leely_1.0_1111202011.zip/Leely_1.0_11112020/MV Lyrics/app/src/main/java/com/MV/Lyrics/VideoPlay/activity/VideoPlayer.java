package com.MV.Lyrics.VideoPlay.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.VideoView;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.MyStudio.activity.YourVideoActivity;
import com.MV.Lyrics.R;
import com.MV.Lyrics.SelectImage.Model.VideoModel;
import com.MV.Lyrics.VideoPlay.Preference.VideoPlayerPreference;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.root.UnitySendValue.AndroidUnityCall;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import static com.MV.Lyrics.NativeAds.NativeAdvanceAds.populateNativeAdView;

public class VideoPlayer extends AppCompatActivity implements MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener, SurfaceHolder.Callback, View.OnClickListener{

    Activity activity = VideoPlayer.this;

    public static boolean IsSurfaceCreated = false;
    private boolean IsSurfaceContainer = true;
    private int VideoWidth = 0;
    private int VideoHeight = 0;
    private boolean isOnMediaonPrepared;
    MediaPlayer mediaPlayer;
    SurfaceView surfaceView;
    ArrayList<VideoModel> AllVideolist;
    private View view;
    ImageButton ibVideoplayPause;
    ImageView ivShareWhatsApp;
    ImageView ivshareFb;
    ImageView ivShareInsta;
    ImageView ivShareYoutube;
    ImageView ivshareMore;

    private String VideoUrl;
    public int videoCurrentposition;
    public static boolean IsFromAndroidlist;

    private LinearLayout llVideoplayerContent;
    private RelativeLayout rlVideoSurfaceContainer;

    private UnifiedNativeAd nativeAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        IsSurfaceCreated = false;

        rlVideoSurfaceContainer = findViewById(R.id.videoSurfaceContainer);

        llVideoplayerContent = findViewById(R.id.llCenter);
        surfaceView = findViewById(R.id.videoSurface);
        view = findViewById(R.id.loading);
        ibVideoplayPause = findViewById(R.id.ibPlayPauseVideo);


        ivShareWhatsApp = findViewById(R.id.ivVideoShareWhatsApp);
        ivshareFb = findViewById(R.id.ivVideoShareFb);
        ivShareInsta = findViewById(R.id.ivVideoShareInsta);
        ivShareYoutube = findViewById(R.id.ivVideoShareYoutube);
        ivshareMore = findViewById(R.id.ivVideoShareMore);
        loadNativeAds();
        AllVideolist = new ArrayList();
        AllVideolist.clear();
        ((RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams()).addRule(2, R.id.llInfo);

        Display defaultDisplay2 = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay2.getSize(point);
        int i = point.x;
        int i2 = point.y;

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        final int width = displayMetrics.widthPixels;
        final int height = displayMetrics.heightPixels;

        rlVideoSurfaceContainer.setLayoutParams(new RelativeLayout.LayoutParams(i, -2));
        ((RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams()).addRule(2, R.id.llInfo);
        this.surfaceView.setMinimumHeight(i2);
        this.surfaceView.setMinimumWidth(i);
        findViewById(R.id.rlTest);

        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams();
        layoutParams2.width = width;
        layoutParams2.height = height;
        rlVideoSurfaceContainer.setLayoutParams(layoutParams2);
        rlVideoSurfaceContainer.setGravity(17);

        ViewGroup.LayoutParams layoutParams3 = surfaceView.getLayoutParams();
        layoutParams3.width = width;
        layoutParams3.height = height;
        surfaceView.setLayoutParams(layoutParams3);
        getAllVideo();
        if (AllVideolist.size() > 0) {
            VideoUrl = getIntent().getStringExtra("VideoUrl");
            videoCurrentposition = getIntent().getIntExtra("VideoPosition", 0);
            IsFromAndroidlist = getIntent().getBooleanExtra("IsVideoFromAndroidList", false);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Video Not Found");
            builder.setMessage("No videos found on storage");
            builder.setPositiveButton("Go back", new DialogInterface.OnClickListener() {
                public final void onClick(DialogInterface dialogInterface, int i) {
                    if (!getIntent().getBooleanExtra("IsVideoFromAndroidList", false)) {
                        startActivity(new Intent(activity, YourVideoActivity.class));
                        finish();
                    }
                    finish();
                }
            });
            builder.show();
        }

        if (this.AllVideolist.size() > 0) {
            ivShareWhatsApp.setOnClickListener(this);
            ivshareFb.setOnClickListener(this);
            ivShareInsta.setOnClickListener(this);
            ivShareYoutube.setOnClickListener(this);
            ivshareMore.setOnClickListener(this);
            ibVideoplayPause.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    VideoPlaypause(ibVideoplayPause);
                }
            });
            surfaceView.getHolder().addCallback(this);
        }
    }

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        view.setVisibility(View.GONE);
        int i = 0;
        surfaceView.setVisibility(View.VISIBLE);
        this.isOnMediaonPrepared = false;
        int i2 = 1;
        if (mediaPlayer.getVideoWidth() > mediaPlayer.getVideoHeight()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(this);
        ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        int i3 = AllVideolist != null ? 1 : 0;
        if (AllVideolist.size() <= 0) {
            i2 = 0;
        }
        if ((i3 & i2) != 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(AllVideolist.get(this.videoCurrentposition).videoDuration);
            String stringBuilder2 = stringBuilder.toString();
            VideoPlayerPreference.a = getSharedPreferences("VIDEOPLAYERS", 0);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("lptrack");
            stringBuilder3.append(stringBuilder2);
            long j = VideoPlayerPreference.a.getLong(stringBuilder3.toString(), -1);
            stringBuilder3 = new StringBuilder(".");
            stringBuilder3.append(VideoPlayerPreference.a(this));
            if (!(j == -1 || j == 0 || mediaPlayer.getDuration() < 1000)) {
                VideoPlayerPreference.a(this);
            }
        }
        try {
            MediaPlayer.TrackInfo[] trackInfo = mediaPlayer.getTrackInfo();
            while (i < trackInfo.length) {
                trackInfo[i].getTrackType();
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SetVisibility();
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i1) {

    }

    private void getAllVideo() {
        AllVideolist.clear();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = activity.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPPFOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoInfo = new VideoModel();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    AllVideolist.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
    }

    private void VideoPlaypause(final ImageButton imageButton) {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
            }
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    imageButton.setImageResource(R.drawable.icon_player_pause);
                    return;
                }
                imageButton.setImageResource(R.drawable.icon_player_play);
            }
        }
    }

    private void ShareVideo(String str, String str2) {
        File file = new File(this.VideoUrl);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.get_free));
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.putExtra("android.intent.extra.TITLE", "United Videos : Particle.ly Video Status Maker");
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (str != null) {
            if (getPackageInfo(str, activity)) {
                intent.setPackage(str);
            } else {
                Context applicationContext = getApplicationContext();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(getString(R.string.please_install));
                stringBuilder2.append(str2);
                Toast.makeText(applicationContext, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
                return;
            }
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_video)));
    }

    private static boolean getPackageInfo(String str, Context context) {
        try {
            context.getPackageManager().getPackageInfo(str, PackageManager.GET_META_DATA);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    private void SetVisibility() {
        try {
            if (Build.VERSION.SDK_INT <= 11 || Build.VERSION.SDK_INT >= 19) {
                if (Build.VERSION.SDK_INT >= 19) {
                    getWindow().getDecorView().setSystemUiVisibility(4096);
                }
                return;
            }
            getWindow().getDecorView().setSystemUiVisibility(8);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetVideoWithSurface() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        getWindow().addFlags(128);
        mediaPlayer = new MediaPlayer();
        this.mediaPlayer = mediaPlayer;
        mediaPlayer.setOnVideoSizeChangedListener(this);
        this.view.setVisibility(View.VISIBLE);
        StringBuilder stringBuilder;
        try {
            stringBuilder = new StringBuilder();
            stringBuilder.append(Uri.parse(this.VideoUrl));
            this.mediaPlayer.setDataSource(this, Uri.parse(this.VideoUrl));
            this.mediaPlayer.prepare();
            this.mediaPlayer.setOnPreparedListener(this);
            long duration = (long) this.mediaPlayer.getDuration();
            StringBuilder stringBuilder2 = new StringBuilder("Val : ");
            stringBuilder2.append(this.mediaPlayer.getDuration() / 10);
        } catch (NullPointerException e) {
            stringBuilder = new StringBuilder(" NullPointerException ");
            stringBuilder.append(e.getMessage());
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        } catch (IllegalStateException e3) {
            e3.printStackTrace();
        } catch (SecurityException e4) {
            e4.printStackTrace();
        } catch (IllegalArgumentException e5) {
            e5.printStackTrace();
        }
        try {
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        } catch (Exception e6) {
            e6.printStackTrace();
            return;
        }
        this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
    }

    public void playPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
            }
        }
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        this.isOnMediaonPrepared = true;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (!IsSurfaceCreated) {
            if (mediaPlayer == null) {
                SetVideoWithSurface();
                mediaPlayer.setDisplay(surfaceView.getHolder());
                return;
            }
            mediaPlayer.setDisplay(surfaceView.getHolder());
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        if (mediaPlayer != null) {
            mediaPlayer.pause();
            mediaPlayer.setDisplay(null);
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case R.id.ivVideoShareYoutube: {
                ShareVideo(getResources().getString(R.string.youtube_package), getResources().getString(R.string.youtube));
                break;
            }
            case R.id.ivVideoShareWhatsApp: {
                ShareVideo(getResources().getString(R.string.whatsapp_package), getResources().getString(R.string.whatsapp));
                break;
            }
            case R.id.ivVideoShareMore: {
                File file = new File(this.VideoUrl);
                final Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/*");
                final StringBuilder sb = new StringBuilder();
                sb.append(this.getResources().getString(R.string.app_name));
                sb.append(": ");
                sb.append(this.getString(R.string.get_free));
                sb.append(this.getString(R.string.app_name));
                sb.append(" Music at here : https://play.google.com/store/apps/details?id=");
                sb.append(this.getPackageName());
                final Uri ShareUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
                intent.putExtra("android.intent.extra.TEXT", sb.toString());
                intent.putExtra("android.intent.extra.STREAM", ShareUri);
                this.startActivity(Intent.createChooser(intent, (CharSequence) this.getString(R.string.share_video)));
                return;
            }
            case R.id.ivVideoShareInsta: {
                ShareVideo(getResources().getString(R.string.instagram_package), getResources().getString(R.string.instagram));
                break;
            }
            case R.id.ivVideoShareFb: {
                ShareVideo(getResources().getString(R.string.facebook_package), getResources().getString(R.string.facebook));
                break;
            }
        }
    }

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.native_adview);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void onBackPressed() {
        super.onBackPressed();
        if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
            MyApplication.AdsId = 3;
            MyApplication.AdsShowContext = activity;
            MyApplication.mInterstitialAd.show();
        } else {
            GoBack();
        }
    }


    private void GoBack() {
        if (IsFromAndroidlist) {
            Intent intent = new Intent(activity, YourVideoActivity.class);
            startActivity(intent);
            finish();
        } else {
            AndroidUnityCall.ScanVideoList(activity, MyApplication.VideoPath);
            Intent intent = new Intent(activity, YourVideoActivity.class);
            startActivity(intent);
            finish();
        }
    }
}