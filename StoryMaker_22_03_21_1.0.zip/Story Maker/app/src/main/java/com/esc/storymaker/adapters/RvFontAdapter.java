package com.esc.storymaker.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.esc.storymaker.EditorActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.interfaces.ItemClickListener;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.FontProvider;

import java.util.ArrayList;
import java.util.List;

public class RvFontAdapter extends RecyclerView.Adapter<RvFontAdapter.ViewHolderCollagePattern> {
    private String category;
    private FontProvider fontProvider;
    private List<String> fonts;
    private boolean isLocked;
    private ArrayList<String> lockedNumbers = new ArrayList();
    private Context mContext;
    private SharedPreferences prefs;
    private int screenWidth;
    private String selectedFont;

    static class ViewHolderCollagePattern extends ViewHolder implements OnClickListener {
        TextView font;
        ItemClickListener itemClickListener;
        View vSelected;

        public ViewHolderCollagePattern(View view) {
            super(view);
            this.font = (TextView) view.findViewById(R.id.tv_font);
            this.vSelected = view.findViewById(R.id.v_selected);
            view.setOnClickListener(this);
        }

        public void setItemClickListener(ItemClickListener itemClickListener) {
            this.itemClickListener = itemClickListener;
        }

        public void onClick(View view) {
            this.itemClickListener.onItemClick(view, getLayoutPosition());
        }
    }

    public RvFontAdapter(Context context, String str, List<String> list, FontProvider fontProvider, String str2, int i) {
        this.mContext = context;
        this.category = str;
        this.fonts = list;
        this.fontProvider = fontProvider;
        this.screenWidth = i;
        this.selectedFont = str2;
        this.prefs = context.getSharedPreferences("prefs", 0);
        this.isLocked = AppUtil.isLocked(this.prefs, "fontsAddTime");
        this.lockedNumbers.addAll(AppUtil.getLockedNumbers(this.prefs));
    }

    public ViewHolderCollagePattern onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolderCollagePattern(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_fonts, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolderCollagePattern viewHolderCollagePattern, int i) {
        viewHolderCollagePattern.font.setText((CharSequence) this.fonts.get(i));
        viewHolderCollagePattern.font.setTypeface(this.fontProvider.getTypeface(this.category, (String) this.fonts.get(i)));
        LayoutParams layoutParams = viewHolderCollagePattern.font.getLayoutParams();
        double d = (double) this.screenWidth;
        Double.isNaN(d);
        Double.isNaN(d);
        layoutParams.width = (int) (d / 3.5d);
        viewHolderCollagePattern.setItemClickListener(new ItemClickListener() {
            public void onItemClick(View view, int i) {
                if (RvFontAdapter.this.mContext instanceof EditorActivity) {
                    ((EditorActivity) RvFontAdapter.this.mContext).changeTextEntityFont(RvFontAdapter.this.category, (String) RvFontAdapter.this.fonts.get(i));
                    RvFontAdapter rvFontAdapter = RvFontAdapter.this;
                    rvFontAdapter.selectedFont = (String) rvFontAdapter.fonts.get(i);
                    RvFontAdapter.this.notifyDataSetChanged();
                }
            }
        });
        if (((String) this.fonts.get(i)).equals(this.selectedFont)) {
            viewHolderCollagePattern.vSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolderCollagePattern.vSelected.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        List list = this.fonts;
        return list != null ? list.size() : 0;
    }

    public void refreshList() {
        this.isLocked = AppUtil.isLocked(this.prefs, "fontsAddTime");
        notifyDataSetChanged();
    }
}
