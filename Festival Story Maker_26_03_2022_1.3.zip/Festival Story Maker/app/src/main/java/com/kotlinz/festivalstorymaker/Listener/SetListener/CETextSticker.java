package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;


public class CETextSticker implements TextStickerViewNew1.a {
    public final  FrameLayout frameLayout;
    public final TextStickerViewNew1 textStickerView;
    public final CanvasEditorActivity activity;

    public CETextSticker(final CanvasEditorActivity c, final FrameLayout a, final TextStickerViewNew1 b) {
        this.activity = c;
        this.frameLayout = a;
        this.textStickerView = b;
    }

    @Override
    public void a(final TextStickerViewNew1 t1) {
        this.activity.scroll.requestDisallowInterceptTouchEvent(true);
        final TextStickerViewNew1 t2 = this.activity.t1;
        if (t2 != null) {
            t2.setInEdit(false);
            this.activity.t1.setShowHelpBox(false);
        }
        (this.activity.t1 = t1).setInEdit(true);
        this.activity.t1.setShowHelpBox(true);
    }

    @Override
    public void b(final TextStickerViewNew1 textStickerViewNew1) {
        this.activity.g0(this.frameLayout, this.textStickerView);

    }

    @Override
    public void c(final TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.t1 != null && textStickerViewNew1.getTag().equals(this.activity.t1.getTag()) && textStickerViewNew1.u) {
            this.frameLayout.removeView((View) textStickerViewNew1);
        }
    }

    @Override
    public void d(final TextStickerViewNew1 t1) {
        activity.u1 = true;
        activity.t1 = t1;
        activity.D0(true);
    }
}
