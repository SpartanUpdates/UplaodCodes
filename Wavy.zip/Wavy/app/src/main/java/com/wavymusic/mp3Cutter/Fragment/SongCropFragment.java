package com.wavymusic.mp3Cutter.Fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.wavymusic.mp3Cutter.Adapter.SongCropAdapter;
import com.wavymusic.mp3Cutter.Model.PhoneSong;
import com.wavymusic.mp3Cutter.Model.SongCropModel;
import com.wavymusic.mp3Cutter.activity.SongCropActivity;
import com.wavymusic.R;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import static com.wavymusic.mp3Cutter.activity.SongCropActivity.PhoneSongFolders;

public class SongCropFragment extends Fragment {
    public static SongCropActivity ActivityofAudioList;
    int Folderid = -1;
    int TabIndex = -1;
    public RecyclerView rvSongCrop;
    public SongCropAdapter songCropAdapter;
    RelativeLayout rlSongProgress;
    public List<SongCropModel> songCroplList;
    public PhoneSong phoneSong;

    public SongCropFragment() {
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }


    public static Fragment getInstance(int Folderid, int TabIndex, SongCropActivity songCropActivity) {
        ActivityofAudioList = songCropActivity;
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        SongCropFragment songCropFragment = new SongCropFragment();
        songCropFragment.setArguments(bundle);
        return songCropFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }

    public int getFolderid() {
        return this.Folderid;
    }

    public int getTabIndex() {
        return this.TabIndex;
    }

    public void setAdapter() {
        songCropAdapter = new com.wavymusic.mp3Cutter.Adapter.SongCropAdapter(this, getContext(), songCroplList);
        this.rvSongCrop.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        this.rvSongCrop.setAdapter(songCropAdapter);
        songCropAdapter.notifyDataSetChanged();
        rlSongProgress.setVisibility(View.GONE);
    }


    @SuppressLint({"NewApi"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_song_folder, viewGroup, false);
        rlSongProgress = inflate.findViewById(R.id.rl_load_sound_blank);
        rvSongCrop = inflate.findViewById(R.id.rv_recycler_view);

        phoneSong = PhoneSongFolders.getMusicFolders().get(Folderid);
        songCroplList = phoneSong.getLocalTracks();
        rvSongCrop.setHasFixedSize(true);
        rvSongCrop.setVisibility(View.VISIBLE);
        ((Activity) viewGroup.getContext()).runOnUiThread(new Runnable() {

            public void run() {
                try {
                    SongCropFragment.this.setAdapter();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        return inflate;
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
