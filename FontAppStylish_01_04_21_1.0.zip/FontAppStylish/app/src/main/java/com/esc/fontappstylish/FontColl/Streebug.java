package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Streebug implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"ꍏ", "ꌃ", "ꏳ", "ꀷ", "ꏂ", "ꎇ", "ꁅ", "ꀍ", "ꀤ", "꒻", "ꀘ", "꒒", "ꎭ", "ꈤ", "ꂦ", "ᖘ", "ꆰ", "ꋪ", "ꌚ", "꓄", "ꀎ", "꒦", "ꅐ", "ꉧ", "ꌩ", "ꁴ"};
    }

    public String getName() {
        return "ꍏꌃꏳ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"ꍏ", "ꌃ", "ꏳ", "ꀷ", "ꏂ", "ꎇ", "ꁅ", "ꀍ", "ꀤ", "꒻", "ꀘ", "꒒", "ꎭ", "ꈤ", "ꂦ", "ᖘ", "ꆰ", "ꋪ", "ꌚ", "꓄", "ꀎ", "꒦", "ꅐ", "ꉧ", "ꌩ", "ꁴ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
