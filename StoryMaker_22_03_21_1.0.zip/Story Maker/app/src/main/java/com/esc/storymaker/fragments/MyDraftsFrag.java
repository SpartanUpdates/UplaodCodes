package com.esc.storymaker.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.storymaker.LaunchScreenActivity;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.RvDraftAdapter;
import com.esc.storymaker.models.Draft;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.ScreenUtil;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MyDraftsFrag extends Fragment {
    RelativeLayout btn_cancel;
    RelativeLayout btn_delete;
    private ArrayList<Draft> drafts;
    FloatingActionButton fab_add;
    LinearLayout llAddBtn;
    public ProgressBar loader;
    private MainActivity mainActivity;
    private View rootView;
    private RvDraftAdapter rvDraftAdapter;
    public RecyclerView rvDrafts;
    View wgCheckedList;

    public static MyDraftsFrag getInstance(MainActivity mainActivity) {
        MyDraftsFrag myDraftsFrag = new MyDraftsFrag();
        myDraftsFrag.mainActivity = mainActivity;
        return myDraftsFrag;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_my_drafts, viewGroup, false);
        this.llAddBtn = (LinearLayout) this.rootView.findViewById(R.id.ll_add_btn);
        this.loader = (ProgressBar) this.rootView.findViewById(R.id.loader);
        this.rvDrafts = (RecyclerView) this.rootView.findViewById(R.id.rv_drafts);
        this.wgCheckedList = this.rootView.findViewById(R.id.wg_checked_list);
        this.fab_add = (FloatingActionButton) this.rootView.findViewById(R.id.fab_add);
        this.btn_cancel = (RelativeLayout) this.rootView.findViewById(R.id.btn_cancel);
        this.btn_delete = (RelativeLayout) this.rootView.findViewById(R.id.btn_delete);
        this.fab_add.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyDraftsFrag.this.onAdd();
            }
        });
        this.btn_cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyDraftsFrag.this.onCancel();
            }
        });
        this.btn_delete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyDraftsFrag.this.onDelete();
            }
        });
        return this.rootView;
    }

    public void onStart() {
        super.onStart();
        setDraftList();
    }

    public void onResume() {
        super.onResume();
        this.rvDrafts.setVisibility(View.VISIBLE);
        this.loader.setVisibility(View.GONE);
    }

    private void setDraftList() {
        if (this.mainActivity == null) {
            Intent intent = new Intent(getActivity(), LaunchScreenActivity.class);
            startActivity(intent);
            return;
        }
        this.drafts = new ArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory().getPath());
        stringBuilder.append("/Android/data/");
        stringBuilder.append(getActivity().getPackageName());
        stringBuilder.append("/drafts/Json/");
        File file = new File(stringBuilder.toString());
        if (file.exists()) {
            File absoluteFile = file.getAbsoluteFile();
            if (absoluteFile.list().length > 0) {
                this.llAddBtn.setVisibility(View.GONE);
                for (String file2 : absoluteFile.list()) {
                    try {
                        this.drafts.add(new Gson().fromJson(AppUtil.inputStreamToString(new FileInputStream(new File(file, file2))), Draft.class));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        this.rvDraftAdapter = new RvDraftAdapter(this.mainActivity, this.drafts, ScreenUtil.getScreenWidth(getActivity()), this);
        this.rvDrafts.setLayoutManager(new GridLayoutManager(getContext(), 2));
        this.rvDrafts.setAdapter(this.rvDraftAdapter);
    }

    public void setWgCheckedList(boolean z) {
        if (z) {
            this.wgCheckedList.setVisibility(View.VISIBLE);
        } else {
            this.wgCheckedList.setVisibility(View.GONE);
        }
    }

    public int getWgCheckedList() {
        return this.wgCheckedList.getVisibility();
    }

    public void onCancel() {
        this.rvDraftAdapter.setCheckedDrafts(new ArrayList());
        setWgCheckedList(false);
    }

    public void onDelete() {
        ArrayList checkedDrafts = this.rvDraftAdapter.getCheckedDrafts();
        setWgCheckedList(false);
        AppUtil.removeDrafts(checkedDrafts);
        setDraftList();
    }

    public void onAdd() {
        ((MainActivity) getContext()).swipeVP(0);
    }
}
