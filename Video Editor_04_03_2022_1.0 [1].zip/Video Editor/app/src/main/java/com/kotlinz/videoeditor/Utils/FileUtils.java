package com.kotlinz.videoeditor.Utils;

import android.content.Context;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class FileUtils {
    public static int Title_index = 0;

    public static final FileUtils INSTANCE;
    public static long mDeleteFileCount;

    static {
        INSTANCE = new FileUtils();
        FileUtils.mDeleteFileCount = 0L;
    }

    public static String strArr(String[] string) {
        String[] s = string;
        String os = "";

        for (int i = 0; i < s.length; i++) {
            os = os + s[i] + " ";
        }
        return os;
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        FileUtils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                FileUtils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                FileUtils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }

    public static final String makeShortTimeString(long j) {
        int i = (int) j;
        int i2 = i % 60;
        int i3 = (i / 60) % 60;
        int i4 = i / 3600;
        if (i4 > 0) {
            return String.format("%02d:%02d:%02d", Integer.valueOf(i4), Integer.valueOf(i3), Integer.valueOf(i2));
        }
        return String.format("%02d:%02d", Integer.valueOf(i3), Integer.valueOf(i2));
    }

    public String milliSecondsToTimer(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        // Add hours if there
        if (hours > 0) {
            finalTimerString = hours + ":";
        }

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }

        finalTimerString = finalTimerString + minutes + ":" + secondsString;

        // return timer string
        return finalTimerString;
    }

}
