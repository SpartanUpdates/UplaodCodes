package com.esc.socialmediacleaner.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.esc.socialmediacleaner.util.SavedData;
import com.esc.socialmediacleaner.util.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import androidx.appcompat.widget.Toolbar;

public class AboutUsScreen extends ShareAppScreen implements OnClickListener {
    public long lastClickedTime = 0;
    private ImageView iv_back;

    public int getFacePosition() {
        return super.getFacePosition();
    }

    public void hideKeyboard() {
        super.hideKeyboard();
    }

    public boolean isEmailValid(String str) {
        return super.isEmailValid(str);
    }

    public void setFacePosition(int i) {
        super.setFacePosition(i);
    }

    public void shareApp() {
        super.shareApp();
    }

    public void toast(String str) {
        super.toast(str);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_about_screen);
        initialize();
        loadAd();
    }

    private void initialize() {
        iv_back = findViewById(R.id.iv_back);
        TextView textView = (TextView) findViewById(R.id.tv_pp);
        TextView textView2 = (TextView) findViewById(R.id.tvmoreapps);
        TextView textView3 = (TextView) findViewById(R.id.tv_rate);
        TextView textView4 = (TextView) findViewById(R.id.tv_version);
        ((TextView) findViewById(R.id.tv_share)).setOnClickListener(this);
        textView.setOnClickListener(this);
        textView3.setOnClickListener(this);
        textView2.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(getString(R.string.IDS_app_version_txt).replace("DO_NOT_TRANSLATE", ""));
        textView4.setText(stringBuilder.toString());
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_pp:
                if (!doubleClicked()) {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                    startActivity(intent1);
                    break;
                }
                return;
            case R.id.tv_rate:
                try {
                    startActivity(new Intent(
                            "android.intent.action.VIEW",
                            Uri.parse(getResources().getString(R.string.rate_us)
                                    + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(AboutUsScreen.this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            case R.id.tv_share:
                if (!doubleClicked()) {
                    shareApp();
                    break;
                }
                return;
            case R.id.tvmoreapps:
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri
                            .parse("https://play.google.com/store/apps/developer?id="
                                    + getString(R.string.more_url))));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(AboutUsScreen.this, "Google play store not install", Toast.LENGTH_SHORT).show();
                }
                return;

            case R.id.iv_back:
                id = 100;
                if (interstitial !=null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(AboutUsScreen.this, HomeScreen.class));
                    finish();
                }
        }
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;
    private void loadAd() {

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(AboutUsScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id)
                {
                    case 100:
                        startActivity(new Intent(AboutUsScreen.this, HomeScreen.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(AboutUsScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        finish();
        return super.onOptionsItemSelected(menuItem);
    }
}
