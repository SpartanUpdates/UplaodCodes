package com.name.nameart.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.name.nameart.R;

import java.util.ArrayList;

public final class MyCreationAdapter extends RecyclerView.Adapter<MyCreationAdapter.ViewHolder> {
    private final Context context;
    private final ArrayList<String> items;
    private OnMyCreationClick onMyCreationClick;

    public interface OnMyCreationClick {
        void onClick(int i);
    }

    public MyCreationAdapter(Context context2, ArrayList<String> arrayList) {
        this.context = context2;
        this.items = arrayList;
    }

    public final Context getContext() {
        return this.context;
    }

    public final ArrayList<String> getItems() {
        return this.items;
    }

    public final OnMyCreationClick getOnMyCreationClick() {
        return this.onMyCreationClick;
    }

    public final void setOnMyCreationClick(OnMyCreationClick onMyCreationClick2) {
        this.onMyCreationClick = onMyCreationClick2;
    }

    public final void setClickListener(OnMyCreationClick onMyCreationClick2) {
        this.onMyCreationClick = onMyCreationClick2;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.creation_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        Glide.with(this.context).load(this.items.get(position)).into((ImageView) viewHolder.itemView.findViewById(R.id.ivThumb));


        viewHolder.itemView.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                OnMyCreationClick onMyCreationClick = MyCreationAdapter.this.getOnMyCreationClick();
                if (onMyCreationClick != null) {
                    onMyCreationClick.onClick(position);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder
    {
        public ViewHolder(View view) {
            super(view);
        }
    }
}
