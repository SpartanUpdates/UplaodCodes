package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.tmall.ultraviewpager.UltraViewPager;
import com.tmall.ultraviewpager.transformer.UltraDepthScaleTransformer;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import com.kotlinz.videostatusmaker.Utils.Utils;
import com.kotlinz.videostatusmaker.adapter.PreviewImagePagerAdapter;
import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class ActivityViewAlImages extends AppCompatActivity {

    int totalImg;
    int width;
    int EDIT;
    ImageView ivBack;
    int currentImg;
    String currentPath;
    TextView tvDone;
    String strfolderName;
    int height;
    Handler handler;
    public static Activity activity;
    public static UltraViewPager viewPager;
    int CROP;
    ProgressDialog progress;
    ImageView selected_image;
    RelativeLayout setLay;
    ImageLoader imageLoader;
    File[] listFile;
    PreviewImagePagerAdapter myCustomPreviewImagePagerAdapter;
    DisplayImageOptions displayImageOptions;
    ArrayList<String> photo;
    int pos;

    private NativeAd nativeAd;


//    public static FFmpeg ffmpeg;

    public ActivityViewAlImages() {
        this.CROP = 1111;
        this.EDIT = 2222;
        this.handler = new Handler();
        this.listFile = null;
        this.photo = new ArrayList<String>();
    }

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }


    void SaveEditImage() {
        final File file = new File(this.currentPath);
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file);
            Utils.save.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            this.setViewPager();
            return;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void click_edit() {
        this.currentImg = ActivityViewAlImages.viewPager.getCurrentItem();
        this.currentPath = this.photo.get(this.currentImg);
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(this.currentPath);
        Utils.uri = Uri.parse(sb.toString());
        this.startActivityForResult(new Intent(this.getApplicationContext(), ActivityImageCrop.class), this.CROP);
    }

    /*void define_ffmpeg() {
        ffmpeg = FFmpeg.getInstance(this);
        try {
            ffmpeg.loadBinary(new LoadBinaryResponseHandler() {
                @Override
                public void onFailure() {
                    Log.e("TAG", "onFailure");
                }

                @Override
                public void onSuccess() {
                    super.onSuccess();
                    Log.e("TAG", "onSuccess");
                }
            });
        } catch (FFmpegNotSupportedException e) {
            Log.e("TAG", "FFmpegNotSupportedException");
        }
    }*/

    public void getFromSdcard() {
        this.photo.clear();
        final File externalStorageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        final StringBuilder sb = new StringBuilder();
        sb.append(this.strfolderName);
        sb.append("/");
        sb.append(this.getString(R.string.temp_folder));
        final File file = new File(externalStorageDirectory, sb.toString());
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            for (int i = 0; i < this.listFile.length; ++i) {
                if (this.listFile[i].getName().contains("zim")) {
                    this.photo.add(this.listFile[i].getAbsolutePath());
                }
            }
        }
    }

    @Override
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == this.CROP && n2 == -1) {
            this.startActivityForResult(new Intent(this.getApplicationContext(), ActivityEditImage.class), this.EDIT);
        }
        if (n == this.EDIT && n2 == -1) {
            this.SaveEditImage();
        }
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.viewall_image_viewpager);
        this.getWindow().addFlags(1024);
        LoadNativeAds();
        this.width = this.getResources().getDisplayMetrics().widthPixels;
        this.height = this.getResources().getDisplayMetrics().heightPixels;
        this.strfolderName = this.getResources().getString(R.string.app_name);
        (this.progress = new ProgressDialog(this)).setMessage("Loading...");
        this.progress.setCancelable(false);
        ActivityViewAlImages.activity = this;
        this.currentImg = 0;
        this.pos = 1;
        this.totalImg = Utils.photos.size();
        PutAnalyticsEvent();
        bindView();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityViewAlImages");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        this.selected_image = findViewById(R.id.selected_image);
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 23;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }

            }
        });
        this.tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(activity, ActivityArrangePhoto.class));
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 24;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        startActivity(new Intent(activity, ActivityArrangePhoto.class));
                    }
                }
            }
        });
        ActivityViewAlImages.viewPager.setInfiniteLoop(true);
        ActivityViewAlImages.viewPager.setMultiScreen(0.65f);
        ActivityViewAlImages.viewPager.setPageTransformer(false, new UltraDepthScaleTransformer());
        this.initImageLoader();
        new ImageSave().execute();
        this.selected_image.setVisibility(View.INVISIBLE);
//        this.define_ffmpeg();
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ActivityViewAlImages.this.nativeAd != null) {
                            ActivityViewAlImages.this.nativeAd.destroy();
                        }
                        ActivityViewAlImages.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void bindView() {
        this.setLay = findViewById(R.id.setLay);
        this.ivBack = findViewById(R.id.back);
        this.tvDone = findViewById(R.id.done);
        this.setLay = findViewById(R.id.setLay);
        ActivityViewAlImages.viewPager = findViewById(R.id.viewPager);
    }


    public void saveImage() {
        try {
            this.displayImageOptions = new DisplayImageOptions.Builder().build();
            final ImageLoader imageLoader = this.imageLoader;
            final StringBuilder sb1 = new StringBuilder();
            sb1.append("file:///");
            sb1.append(Utils.photos.get(pos - 1));
            imageLoader.displayImage(sb1.toString(), this.selected_image, this.displayImageOptions, new ImageLoadingListener() {
                @Override
                public void onLoadingCancelled(final String s, final View view) {

                }

                @Override
                public void onLoadingComplete(String string, final View view, final Bitmap bitmap) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("complete");
                    sb.append(ActivityViewAlImages.this.pos);
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
                    sb2.append("/");
                    sb2.append(ActivityViewAlImages.this.getResources().getString(R.string.app_name));
                    string = sb2.toString();
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("zim");
                    sb3.append(pos);
                    sb3.append(".jpg");
                    final String string2 = sb3.toString();
                    final StringBuilder sb4 = new StringBuilder();
                    sb4.append(string);
                    sb4.append(File.separator);
                    sb4.append(ActivityViewAlImages.this.getString(R.string.temp_folder));
                    final File file = new File(sb4.toString());
                    file.mkdirs();
                    final File file2 = new File(file, string2);
                    if (file2.exists()) {
                        file2.delete();
                    }
                    try {
                        final FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                        fileOutputStream.flush();
                        fileOutputStream.close();
                        ++pos;
                        if (pos == totalImg + 1) {
                            selected_image.setVisibility(View.INVISIBLE);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    progress.cancel();
                                    setViewPager();
                                }
                            }, 100L);
                            return;
                        }
                        saveImage();
                        return;
                    } catch (Exception ex) {
                        Log.e("TAG","Exception"+ex.getMessage());
                    }
                }

                @Override
                public void onLoadingFailed(final String s, final View view, final FailReason failReason) {
                    progress.cancel();
                }

                @Override
                public void onLoadingStarted(final String s, final View view) {
                }
            });
        } catch (Exception ex) {
            Log.e("TAG", "All Exe" + ex.getMessage());
            ex.toString();
        }

    }


    @Override
    protected void onStop() {
        super.onStop();

    }

    void setLayout() {
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.width * 70 / 1080, this.height * 70 / 1920);
        layoutParams.addRule(15);
        final int n = this.width * 40 / 1080;
        layoutParams.setMargins(n, 0, 0, 0);
        this.ivBack.setLayoutParams(layoutParams);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(this.width * 70 / 1080, this.height * 70 / 1920);
        layoutParams2.addRule(15);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(0, 0, 0, 0);
        this.tvDone.setLayoutParams(layoutParams2);
    }

    void setViewPager() {
        this.getFromSdcard();
        this.myCustomPreviewImagePagerAdapter = new PreviewImagePagerAdapter(this, this.photo);
        ActivityViewAlImages.viewPager.setAdapter(this.myCustomPreviewImagePagerAdapter);
        ActivityViewAlImages.viewPager.setCurrentItem(this.currentImg);
    }

    public class ImageSave extends AsyncTask<String, String, String> {
        protected String doInBackground(final String... array) {
            ActivityViewAlImages.this.saveImage();
            return null;
        }

        protected void onPostExecute(final String s) {
            super.onPostExecute(s);
        }

        protected void onPreExecute() {
            ActivityViewAlImages.this.progress.show();
            super.onPreExecute();
        }
    }
}
