package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GifFavoriteActivity extends AppCompatActivity {
    private static Editor editor = null;
    public static Editor editorgif = null;
    private static int gifID_toshow = 0;
    public static boolean rewardads_gifF = false;
    private static SharedPreferences sharedPreferences = null;
    public static SharedPreferences sharedPreferencesgif = null;
    public static boolean show_gifF = false;
    Activity activity = this;
    private Adapter adapter;
    private GifDataBaseHelper db;
    Dialog dialogR;
    private ArrayList<Integer> favorite;
    private LayoutManager layoutManager;
    private ArrayList<String> messages;
    private ArrayList<Integer> mid;
    private RecyclerView recyclerView;
    private Typeface typeface;
    private ArrayList<String> url;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_giffavorite);
        this.typeface = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        View inflate = LayoutInflater.from(this).inflate(R.layout.action_bar_title, null);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        textView.setText(R.string.appname);
        textView.setTypeface(this.typeface);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        sharedPreferencesgif = getSharedPreferences("MYPREFERENCE_GIF", 0);
        editorgif = sharedPreferencesgif.edit();
        sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        editor = sharedPreferences.edit();
        TextView textView2 = (TextView) findViewById(R.id.giffavorite_headingtextview);
        textView2.setText(getResources().getString(R.string.favorites));
        textView2.setTypeface(this.typeface);
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        this.db = new GifDataBaseHelper(this);
        this.messages = new ArrayList();
        this.url = new ArrayList();
        this.mid = new ArrayList();
        this.favorite = new ArrayList();
        this.messages = this.db.GetAllFavoriteGifText();
        this.mid = this.db.GetAllFavoriteGifID();
        this.favorite = this.db.GetAllFavoriteGifF();
        ArrayList arrayList = new ArrayList();
        arrayList = this.db.GetAllFavoriteURL();
        ArrayList arrayList2 = new ArrayList();
        arrayList2 = this.db.GetsectionIdForFavoriteURL();
        BannerAds();
        int i = 0;
        for (int i2 = 0; i2 < this.mid.size(); i2++) {
            ArrayList arrayList3 = this.url;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("https://www.wishafriend.com/");
            stringBuilder.append((String) arrayList2.get(i2));
            stringBuilder.append("/uploads/");
            stringBuilder.append(this.mid.get(i2));
            stringBuilder.append("-");
            stringBuilder.append((String) arrayList.get(i2));
            stringBuilder.append(".gif");
            arrayList3.add(stringBuilder.toString());
            SharedPreferences sharedPreferences = sharedPreferencesgif;
            stringBuilder = new StringBuilder();
            stringBuilder.append("gif_");
            stringBuilder.append(this.mid.get(i2));
            if (!sharedPreferences.getBoolean(stringBuilder.toString(), false)) {
                i++;
            }
        }
        this.recyclerView = (RecyclerView) findViewById(R.id.gifview_recyclerview);
        this.layoutManager = new LinearLayoutManager(this);
        this.recyclerView.setLayoutManager(this.layoutManager);
        this.adapter = new GifFavoriteViewAdapter(this, this.messages, this.url, this.mid, this.favorite, this.activity);
        this.recyclerView.setAdapter(this.adapter);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        super.onBackPressed();
        String str = "rateagain";
        if (sharedPreferences.getInt(str, 8) == 8) {
            editor.putInt(str, 0);
            editor.commit();
            RATE_DIALOG();
            return;
        }
        super.onBackPressed();
    }

    public void onResume() {
        super.onResume();
        if (show_gifF) {
            Editor editor = editorgif;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("gif_");
            stringBuilder.append(gifID_toshow);
            editor.putBoolean(stringBuilder.toString(), true);
            editorgif.commit();
            this.adapter.notifyDataSetChanged();
            show_gifF = false;
        }
    }

    public static void AddRateClicks() {
        String str = "rateagain";
        if (sharedPreferences.getInt(str, 8) < 8) {
            int i = sharedPreferences.getInt(str, 8) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            Log.e("Clicks: ", stringBuilder.toString());
        }
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = (TextView) this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        textView.setTypeface(this.typeface);
        Button button = (Button) this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = (Button) this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                GifFavoriteActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                GifFavoriteActivity.this.finish();
                GifFavoriteActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                GifFavoriteActivity.this.finish();
                GifFavoriteActivity.this.dialogR.cancel();
            }
        });
        textView.setTypeface(this.typeface);
        button.setTypeface(this.typeface);
        button2.setTypeface(this.typeface);
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
