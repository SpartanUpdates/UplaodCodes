package com.esc.fontappstylish.utils;

import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings.Secure;
import android.text.TextUtils;
import java.util.Arrays;
import java.util.List;

public class FontSet {
    public static final FontSet INSTANCE = new FontSet();

    private FontSet() {
    }

    public final boolean isThisKeyboardSetAsDefaultIME(Context context) {
        String string = Secure.getString(context.getContentResolver(), "default_input_method");
        String packageName = context.getPackageName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" : ");
        stringBuilder.append(packageName);
        return isThisKeyboardSetAsDefaultIME(string, packageName);
    }

    public final boolean isThisKeyboardSetAsDefaultIME(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        ComponentName unflattenFromString = ComponentName.unflattenFromString(str);
        if (unflattenFromString != null) {
            return unflattenFromString.getPackageName().equals(str2);
        }
        throw new NullPointerException(unflattenFromString.getClassName());
    }

    public final boolean isThisKeyboardEnabled(Context context) {
        return isThisKeyboardEnabled(Secure.getString(context.getContentResolver(), "enabled_input_methods"), context.getPackageName());
    }

    private final boolean isThisKeyboardEnabled(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        List asList = Arrays.asList(str.toString().split(":"));
        if (asList != null) {
            Object[] toArray = asList.toArray(new String[0]);
            if (toArray != null) {
                for (String unflattenFromString : (String[]) toArray) {
                    ComponentName unflattenFromString2 = ComponentName.unflattenFromString(unflattenFromString);
                    if (unflattenFromString2 != null && unflattenFromString2.getPackageName().equals(str2)) {
                        return true;
                    }
                }
                return false;
            }
            throw new ClassCastException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        throw new ClassCastException("null cannot be cast to non-null type java.util.Collection<T>");
    }
}
