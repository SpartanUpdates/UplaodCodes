package com.kotlinz.festivalstorymaker.Model.DashBord;

import com.google.gson.annotations.SerializedName;

public class AllModule {

	@SerializedName("module_id")
	private int moduleId;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public int getModuleId(){
		return moduleId;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}
}