package com.name.nameart.motionview;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import androidx.core.view.MotionEventCompat;

import com.name.nameart.FavDesign.NameEditing;


public class MyTouchMation implements OnTouchListener {
    private static final int INVALID_POINTER_ID = -1;
    private Context cntx;
    public boolean isRotateEnabled = true;
    public boolean isScaleEnabled = true;
    public boolean isTranslateEnabled = true;
    private int mActivePointerId = -1;
    private DetectorMotion mDetectorMotion = new DetectorMotion(new ScaleGestureListener());
    private float mPrevX;
    private float mPrevY;
    public float maximumScale = 10.0f;
    public float minimumScale = 0.5f;
    boolean shouldClick = true;
    private String tag;

    public interface CallBackCutom {
        void onSelected();

        void onUnSelected();
    }

    private class TransformInfo {
        public float deltaAngle;
        public float deltaScale;
        public float deltaX;
        public float deltaY;
        public float maximumScale;
        public float minimumScale;
        public float pivotX;
        public float pivotY;

        private TransformInfo() {
        }
    }

    private class ScaleGestureListener extends DetectorMotion.SimpleOnScaleGestureListener {
        private float mPivotX;
        private float mPivotY;
        private Vector4DMotion mPrevSpanVector;

        private ScaleGestureListener() {
            this.mPrevSpanVector = new Vector4DMotion();
        }

        public boolean onScaleBegin(View view, DetectorMotion detectorMotion) {
            this.mPivotX = detectorMotion.getFocusX();
            this.mPivotY = detectorMotion.getFocusY();
            this.mPrevSpanVector.set(detectorMotion.getCurrentSpanVector());
            return true;
        }

        public boolean onScale(View view, DetectorMotion detectorMotion) {
            TransformInfo transformInfo = new TransformInfo();
            transformInfo.deltaScale = MyTouchMation.this.isScaleEnabled ? detectorMotion.getScaleFactor() : 1.0f;
            float f = 0.0f;
            transformInfo.deltaAngle = MyTouchMation.this.isRotateEnabled ? Vector4DMotion.getAngle(this.mPrevSpanVector, detectorMotion.getCurrentSpanVector()) : 0.0f;
            transformInfo.deltaX = MyTouchMation.this.isTranslateEnabled ? detectorMotion.getFocusX() - this.mPivotX : 0.0f;
            if (MyTouchMation.this.isTranslateEnabled) {
                f = detectorMotion.getFocusY() - this.mPivotY;
            }
            transformInfo.deltaY = f;
            transformInfo.pivotX = this.mPivotX;
            transformInfo.pivotY = this.mPivotY;
            transformInfo.minimumScale = MyTouchMation.this.minimumScale;
            transformInfo.maximumScale = MyTouchMation.this.maximumScale;
            MyTouchMation.move(view, transformInfo);
            return false;
        }
    }

    private static float adjustAngle(float f) {
        return f > 180.0f ? f - 360.0f : f < -180.0f ? f + 360.0f : f;
    }

    public MyTouchMation(Context context, String str) {
        this.tag = str;
        this.cntx = context;
    }

    public static void move(View view, TransformInfo transformInfo) {
        computeRenderOffset(view, transformInfo.pivotX, transformInfo.pivotY);
        adjustTranslation(view, transformInfo.deltaX, transformInfo.deltaY);
        float max = Math.max(transformInfo.minimumScale, Math.min(transformInfo.maximumScale, view.getScaleX() * transformInfo.deltaScale));
        view.setScaleX(max);
        view.setScaleY(max);
        view.setRotation(adjustAngle(view.getRotation() + transformInfo.deltaAngle));
    }

    private static void adjustTranslation(View view, float f, float f2) {
        float[] fArr = new float[]{f, f2};
        view.getMatrix().mapVectors(fArr);
        view.setTranslationX(view.getTranslationX() + fArr[0]);
        view.setTranslationY(view.getTranslationY() + fArr[1]);
    }

    private static void computeRenderOffset(View view, float f, float f2) {
        if (view.getPivotX() != f || view.getPivotY() != f2) {
            float[] fArr = new float[]{0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr);
            view.setPivotX(f);
            view.setPivotY(f2);
            float[] fArr2 = new float[]{0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr2);
            float f3 = fArr2[0] - fArr[0];
            f = fArr2[1] - fArr[1];
            view.setTranslationX(view.getTranslationX() - f3);
            view.setTranslationY(view.getTranslationY() - f);
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        this.mDetectorMotion.onTouchEvent(view, motionEvent);
        if (!this.isTranslateEnabled) {
            return true;
        }
        int action = motionEvent.getAction();
        int actionMasked = motionEvent.getActionMasked() & action;
        int i = 0;
        if (actionMasked == 0) {
            this.shouldClick = true;
            this.mPrevX = motionEvent.getX();
            this.mPrevY = motionEvent.getY();
            this.mActivePointerId = motionEvent.getPointerId(0);
            Context context = this.cntx;
            if (context instanceof NameEditing) {
                ((NameEditing) context).setStickerSelectedByTag(this.tag);
            }
            ((NameEditing) this.cntx).invisibleeditlayouts(Boolean.valueOf(true));
            View view2 = (View) null;
            ((NameEditing) this.cntx).selectedViewBackground(view2);
            ((NameEditing) this.cntx).showSelectedRecycle(view2);
        } else if (actionMasked == 1) {
            if (this.shouldClick) {
                view.performClick();
            }
            this.mActivePointerId = -1;
        } else if (actionMasked == 2) {
            this.shouldClick = false;
            action = motionEvent.findPointerIndex(this.mActivePointerId);
            if (action != -1) {
                float x = motionEvent.getX(action);
                float y = motionEvent.getY(action);
                if (!this.mDetectorMotion.isInProgress()) {
                    adjustTranslation(view, x - this.mPrevX, y - this.mPrevY);
                }
            }
        } else if (actionMasked == 3) {
            this.mActivePointerId = -1;
        } else if (actionMasked == 6) {
            int i2 = (MotionEventCompat.ACTION_POINTER_INDEX_MASK & action) >> 8;
            if (motionEvent.getPointerId(i2) == this.mActivePointerId) {
                if (i2 == 0) {
                    i = 1;
                }
                this.mPrevX = motionEvent.getX(i);
                this.mPrevY = motionEvent.getY(i);
                this.mActivePointerId = motionEvent.getPointerId(i);
            }
        }
        return true;
    }
}
