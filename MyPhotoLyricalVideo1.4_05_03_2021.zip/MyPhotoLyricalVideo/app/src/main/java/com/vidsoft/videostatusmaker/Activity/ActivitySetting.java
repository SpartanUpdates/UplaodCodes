package com.vidsoft.videostatusmaker.Activity;

import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import com.vidsoft.videostatusmaker.Utils.AppPreferences;

public class ActivitySetting extends AppCompatActivity {
    ImageView ivBack;
    ImageView imgAllCap;
    LinearLayout linearLayout;
    AppPreferences appPreferences;
    TextView tvTitle;
    TextView txtAllcap;
    int width;
    Typeface typeface;
    int height;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_setting);
        this.appPreferences = new AppPreferences(this);
        getWindow().addFlags(1024);
        PutAnalyticsEvent();
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        this.linearLayout = (LinearLayout) findViewById(R.id.lay1);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.imgAllCap = (ImageView) findViewById(R.id.img_all_cap);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.txtAllcap = (TextView) findViewById(R.id.txt_allcap);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.txtAllcap.setTypeface(this.typeface);
        check();
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivitySetting.this.onBackPressed();
            }
        });
        this.linearLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityPreview.complete = false;
                if (ActivitySetting.this.appPreferences.get_ALL_CAPS()) {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(false);
                } else {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(true);
                }
                ActivitySetting.this.check();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySetting");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    void check() {
        if (this.appPreferences.get_ALL_CAPS()) {
            this.imgAllCap.setImageResource(R.drawable.toggle1_on);
        } else {
            this.imgAllCap.setImageResource(R.drawable.toggle1_off);
        }
    }
}
