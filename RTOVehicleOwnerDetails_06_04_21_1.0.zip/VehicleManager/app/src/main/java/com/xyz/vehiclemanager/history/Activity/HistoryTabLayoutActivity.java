package com.xyz.vehiclemanager.history.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.adapter.HomeFragmentPageAdapter;
import com.xyz.vehiclemanager.history.Fragment.LicenseInfoFragment;
import com.xyz.vehiclemanager.history.Fragment.OwnerInfoFragment;

public class HistoryTabLayoutActivity extends AppCompatActivity {

    Activity activity = HistoryTabLayoutActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView iv_back;
    private HomeFragmentPageAdapter homePageAdapter;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_tab_layout);
        iv_back = findViewById(R.id.iv_back);
        viewPager = findViewById(R.id.viewPager);
        setViewPager();
        PutAnalyticsEvent();
        BannerAds();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void setViewPager() {
        homePageAdapter = new HomeFragmentPageAdapter(getSupportFragmentManager());
        homePageAdapter.addFragment(new OwnerInfoFragment(), "Owner Info");
        homePageAdapter.addFragment(new LicenseInfoFragment(), "License Info");
        viewPager.setAdapter(homePageAdapter);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HistoryTabLayoutActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void CreateTab() {
        TextView OwnerInfo = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        OwnerInfo.setText("Owner Info");
        tabLayout.getTabAt(0).setCustomView(OwnerInfo);

        TextView LicenseInfo = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        LicenseInfo.setText("License Info");
        tabLayout.getTabAt(1).setCustomView(LicenseInfo);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}