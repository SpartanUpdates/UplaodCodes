package com.kotlinz.festivalstorymaker.coustomSticker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;

import com.kotlinz.festivalstorymaker.TypeFace.Font;

public class TextStickerViewNew1 extends View
{
    public float A;
    public int B;
    public Bitmap C;
    public RectF D;
    public Rect E;
    public Bitmap F;
    public RectF G;
    public Rect H;
    public RectF I;
    public Paint J;
    public Bitmap K;
    public RectF L;
    public Rect M;
    public Bitmap N;
    public RectF O;
    public Rect P;
    public Rect Q;
    public int R;
    public a S;
    public b T;
    public int U;
    public int V;
    public float W;
    public float a0;
    public StaticLayout b0;
    public boolean c0;
    public String d0;
    public int e;
    public TextPaint e0;
    public int f;
    public int f0;
    public Layout.Alignment g;
    public int g0;
    public int h;
    public boolean h0;
    public int i;
    public ScrollView i0;
    public Context j;
    public boolean j0;
    public long k;
    public TextStickerViewNew1 k0;
    public Paint l;
    public GestureDetector l0;
    public float m;
    public Paint m0;
    public float n;
    public Paint n0;
    public boolean o;
    public Matrix o0;
    public int p;
    public int q;
    public Font r;
    public boolean s;
    public boolean t;
    public boolean u;
    public float v;
    public float w;
    public int x;
    public int y;
    public float z;

    public TextStickerViewNew1(final Context context, final AttributeSet set) {
        super(context, set);
        this.g = Layout.Alignment.ALIGN_CENTER;
        this.l = new Paint();
        this.o = true;
        this.s = true;
        this.t = true;
        this.u = true;
        this.v = 0.0f;
        this.w = 0.0f;
        this.z = 0.0f;
        this.A = 10.0f;
        this.B = 2;
        this.D = new RectF();
        this.E = new Rect();
        this.G = new RectF();
        this.H = new Rect();
        this.I = new RectF();
        this.J = new Paint();
        this.L = new RectF();
        this.M = new Rect();
        this.O = new RectF();
        this.P = new Rect();
        this.Q = new Rect();
        new Rect();
        new Rect();
        this.R = 255;
        this.U = 0;
        this.V = 0;
        this.c0 = false;
        this.e0 = new TextPaint();
        this.h0 = false;
        this.j0 = false;
        this.o0 = new Matrix();
        this.l0 = new GestureDetector(this.j, (GestureDetector.OnGestureListener)new c());
        this.b(context);
    }

    public TextStickerViewNew1(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.g = Layout.Alignment.ALIGN_CENTER;
        this.l = new Paint();
        this.o = true;
        this.s = true;
        this.t = true;
        this.u = true;
        this.v = 0.0f;
        this.w = 0.0f;
        this.z = 0.0f;
        this.A = 10.0f;
        this.B = 2;
        this.D = new RectF();
        this.E = new Rect();
        this.G = new RectF();
        this.H = new Rect();
        this.I = new RectF();
        this.J = new Paint();
        this.L = new RectF();
        this.M = new Rect();
        this.O = new RectF();
        this.P = new Rect();
        this.Q = new Rect();
        new Rect();
        new Rect();
        this.R = 255;
        this.U = 0;
        this.V = 0;
        this.c0 = false;
        this.e0 = new TextPaint();
        this.h0 = false;
        this.j0 = false;
        this.o0 = new Matrix();
        this.l0 = new GestureDetector(this.j, (GestureDetector.OnGestureListener)new c());
        this.b(context);
    }

    public TextStickerViewNew1(final Context j, final ScrollView i0, final int k, final int h) {
        super(j);
        this.g = Layout.Alignment.ALIGN_CENTER;
        this.l = new Paint();
        this.o = true;
        this.s = true;
        this.t = true;
        this.u = true;
        this.v = 0.0f;
        this.w = 0.0f;
        this.z = 0.0f;
        this.A = 10.0f;
        this.B = 2;
        this.D = new RectF();
        this.E = new Rect();
        this.G = new RectF();
        this.H = new Rect();
        this.I = new RectF();
        this.J = new Paint();
        this.L = new RectF();
        this.M = new Rect();
        this.O = new RectF();
        this.P = new Rect();
        this.Q = new Rect();
        new Rect();
        new Rect();
        this.R = 255;
        this.U = 0;
        this.V = 0;
        this.c0 = false;
        this.e0 = new TextPaint();
        this.h0 = false;
        this.j0 = false;
        this.o0 = new Matrix();
        this.l0 = new GestureDetector(this.j, (GestureDetector.OnGestureListener)new c());
        this.j = j;
        this.i0 = i0;
        this.i = k;
        this.h = h;
        this.b(j);
        this.m0 = this.c();
        this.n0 = this.c();
    }

    /*public final void a() {
        this.e0.setShader((Shader)null);
        this.e0.setStyle(Paint.Style.FILL);
        *//*this.e0.setTextSize(this.r.b);
        this.e0.setColor(this.r.a);
        this.e0.setTypeface(this.r.c);*//*
        this.e0.setTextSize(com.esc.kotlinz.R.dimen.ayp_8dp);
        this.e0.setColor(getResources().getColor(com.esc.kotlinz.R.color.black));
//        this.e0.setTypeface(this.r.c);
        this.e0.setLetterSpacing(this.getLetterSpacing() / 10.0f);
        this.e0.setUnderlineText(this.h0);
        this.e0.setAlpha(this.R);
        this.e0.setStrikeThruText(this.c0);
        this.J.setColor(this.getResources().getColor(com.esc.kotlinz.R.color.black));
        this.J.setStyle(Paint.Style.STROKE);
        this.J.setAntiAlias(true);
        this.J.setStrokeWidth(2.0f);
        this.J.setPathEffect((PathEffect)new DashPathEffect(new float[] { 10.0f, 15.0f }, 0.0f));
        final TextPaint e0 = this.e0;
        final String d0 = this.d0;
        e0.getTextBounds(d0, 0, d0.length(), this.Q);
        this.Q.offset(this.x, this.y);
        final int width = this.Q.width();
        this.f0 = width;
        final int e2 = this.e;
        final int n = e2 * 4;
        final int i = this.i;
        int n4;
        int n5;
        if (n + width > i) {
            final int n2 = (i - n) / 2;
            this.p = this.U * n2 / 100;
            this.q = n2 * this.V / 100;
            final Rect q = this.Q;
            final int left = q.left;
            final int n3 = (width - i) / 2;
            n4 = left + e2 + n3;
            n5 = q.right - e2 - n3;
        }
        else {
            final int n6 = width / 2;
            this.p = this.U * n6 / 100;
            this.q = n6 * this.V / 100;
            final Rect q2 = this.Q;
            n4 = q2.left - e2;
            n5 = q2.right + e2;
        }
        final int g0 = this.p + this.q;
        this.g0 = g0;
        final int n7 = n5 - n4;
        if (this.e * 2 + g0 >= n7) {
            this.g0 = g0 - (this.f0 / this.d0.length() - this.e);
        }
        final String d2 = this.d0;
        final TextPaint e3 = this.e0;
        int n8 = n7 - this.g0 - this.e;
        if (n8 < 0) {
            n8 = 0;
        }
        final StaticLayout b0 = new StaticLayout((CharSequence)d2, e3, n8, this.g, this.A / 10.0f, 1.0f, true);
        this.b0 = b0;
        if (this.r != null) {
            this.I.set((float)this.Q.left, (float)(this.y - b0.getHeight() / 2 - 5), (float)this.Q.right, this.b0.getHeight() / 2 + this.y + 5.0f);
            t0(this.I, this.a0);
            ;
            return;
        }
        *//*else {
            throw null;
        }*//*

    }*/
    public final void a() {
        this.e0.setShader((Shader)null);
        this.e0.setStyle(Paint.Style.FILL);
        this.e0.setTextSize(12);
//        this.e0.setColor(this.r.a);
//        this.e0.setTypeface(this.r.c)
        this.e0.setTextSize(com.kotlinz.festivalstorymaker.R.dimen.ayp_8dp);
        this.e0.setColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.black));
        this.e0.setLetterSpacing(this.getLetterSpacing() / 10.0F);
        this.e0.setUnderlineText(this.h0);
        this.e0.setAlpha(this.R);
        this.e0.setStrikeThruText(this.c0);
        this.J.setColor(this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.red));
        this.J.setStyle(Paint.Style.STROKE);
        this.J.setAntiAlias(true);
        this.J.setStrokeWidth(2.0F);
        this.J.setPathEffect(new DashPathEffect(new float[]{10.0F, 15.0F}, 0.0F));
        TextPaint var1 = this.e0;
        String var2 = this.d0;
        var1.getTextBounds(var2, 0, var2.length(), this.Q);
        this.Q.offset(this.x, this.y);
        int var3 = this.Q.width();
        this.f0 = var3;
        int var4 = this.e;
        int var5 = var4 * 4;
        int var6 = this.i;
        Rect var11;
        if (var5 + var3 > var6) {
            var5 = (var6 - var5) / 2;
            this.p = this.U * var5 / 100;
            this.q = var5 * this.V / 100;
            var11 = this.Q;
            var5 = var11.left;
            var6 = (var3 - var6) / 2;
            var3 = var5 + var4 + var6;
            var4 = var11.right - var4 - var6;
        } else {
            var3 /= 2;
            this.p = this.U * var3 / 100;
            this.q = var3 * this.V / 100;
            var11 = this.Q;
            var3 = var11.left - var4;
            var4 += var11.right;
        }

        var6 = this.p + this.q;
        this.g0 = var6;
        var4 -= var3;
        if (this.e * 2 + var6 >= var4) {
            this.g0 = var6 - (this.f0 / this.d0.length() - this.e);
        }

        var2 = this.d0;
        var1 = this.e0;
        var4 = var4 - this.g0 - this.e;
        if (var4 < 0) {
            var4 = 0;
        }

        StaticLayout var12 = new StaticLayout(var2, var1, var4, this.g, this.A / 10.0F, 1.0F, true);
        this.b0 = var12;
        if (this.r != null) {
            RectF var10 = this.I;
            float var7 = (float) this.Q.left;
            float var8 = (float) (this.y - var12.getHeight() / 2 - 5);
            float var9 = (float) this.Q.right;
            var4 = this.y;
            var10.set(var7, var8, var9, (float) (this.b0.getHeight() / 2 + var4) + 5.0F);
            t0(this.I, this.a0);
        }/*else {
            throw null;
        }*/
    }


    public static void t0(final RectF rectF, float n) {
        final float width = rectF.width();
        final float height = rectF.height();
        final float n2 = (n * width - width) / 2.0f;
        n = (n * height - height) / 2.0f;
        rectF.left -= n2;
        rectF.top -= n;
        rectF.right += n2;
        rectF.bottom += n;
    }

    public final void b(final Context context) {
        this.l.setColor(Color.parseColor("#66ff0000"));
        this.C = BitmapFactory.decodeResource(context.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_delete_sticker);
        this.F = BitmapFactory.decodeResource(context.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_edit_sticker);
        this.K = BitmapFactory.decodeResource(context.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_rotate_sticker);
        this.N = BitmapFactory.decodeResource(context.getResources(), com.kotlinz.festivalstorymaker.R.drawable.ic_resize_sticker);
        this.f = 40;
        this.e = 30;
        this.E.set(0, 0, this.C.getWidth(), this.C.getHeight());
        this.H.set(0, 0, this.F.getWidth(), this.F.getHeight());
        this.M.set(0, 0, this.K.getWidth(), this.K.getHeight());
        this.P.set(0, 0, this.N.getWidth(), this.N.getHeight());
        final float n = (float)(this.f << 1);
        this.D = new RectF(0.0f, 0.0f, n, n);
        final float n2 = (float)(this.f << 1);
        this.G = new RectF(0.0f, 0.0f, n2, n2);
        final float n3 = (float)(this.f << 1);
        this.L = new RectF(0.0f, 0.0f, n3, n3);
        final float n4 = (float)(this.f << 1);
        this.O = new RectF(0.0f, 0.0f, n4, n4);
    }

    public final Paint c() {
        final Paint paint = new Paint();
        paint.setColor(0);
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.0f);
        paint.setPathEffect((PathEffect)new DashPathEffect(new float[] { 10.0f, 15.0f }, 1.0f));
        return paint;
    }

    public void d(float a0, float n, final boolean b) {
        float n2 = n;
        if (b) {
            n2 = -n;
        }
        final float centerX = this.I.centerX();
        final float centerY = this.I.centerY();
        final float centerX2 = this.L.centerX();
        final float centerY2 = this.L.centerY();
        n = centerX2 - centerX;
        final float n3 = centerY2 - centerY;
        a0 = a0 + centerX2 - centerX;
        final float n4 = n2 + centerY2 - centerY;
        final float n5 = (float)Math.sqrt(n3 * n3 + n * n);
        final float n6 = (float)Math.sqrt(n4 * n4 + a0 * a0);
        if (b) {
            a0 = n6 / n5;
            this.a0 *= a0;
            this.I.width();
            a0 = this.a0;
            a0 = (float)(this.i * 10 / 100);
            return;
        }
        final double n7 = (n3 * n4 + n * a0) / (n5 * n6);
        if (n7 <= 1.0 && n7 >= -1.0) {
            final float w = this.W;
            int n8;
            if (n * n4 - a0 * n3 > 0.0f) {
                n8 = 1;
            }
            else {
                n8 = -1;
            }
            this.W = n8 * (float)Math.toDegrees(Math.acos(n7)) + w;
        }
        final int n9 = (int)this.W;
        Paint paint;
        int color;
        if (n9 != 0 && n9 != 45 && n9 != 135 && n9 != 90 && n9 != 225 && n9 != 180 && n9 != 270 && n9 != 315 && n9 != -45 && n9 != -135 && n9 != -90 && n9 != -225 && n9 != -180 && n9 != -270 && n9 != -315) {
            paint = this.m0;
            color = 0;
        }
        else {
            paint = this.m0;
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.red);
        }
        paint.setColor(color);
        this.invalidate();
    }

    public Layout.Alignment getAlign() {
        return this.g;
    }

    public Font getFont() {
        return this.r;
    }

    public int getLayoutX() {
        return this.x;
    }

    public int getLayoutY() {
        return this.y;
    }

    public float getLetterSpacing() {
        return this.z;
    }

    public float getLineSpacing() {
        return this.A;
    }

    public int getOpacity() {
        return this.R;
    }

    public int getPaddingLeft() {
        return this.U;
    }

    public int getPaddingRight() {
        return this.V;
    }

    public float getRotateAngle() {
        return this.W;
    }

    public float getScale() {
        return this.a0;
    }

    public String getText() {
        return this.d0;
    }

    public float getTextCenterY() {
        this.a();
        return this.I.centerY();
    }

    public int getTextHeight() {
        this.a();
        return this.e * 2 + this.b0.getHeight();
    }

    public void onDraw(final Canvas canvas) {
        if (!TextUtils.isEmpty((CharSequence)this.getText())) {
            this.a();
            canvas.save();
            final float a0 = this.a0;
            canvas.scale(a0, a0, this.I.centerX(), this.I.centerY());
            canvas.rotate(this.W, this.I.centerX(), this.I.centerY());
            canvas.translate(this.I.centerX() - this.b0.getWidth() / 2 + this.p / 2 - this.q / 2, this.I.centerY() - this.b0.getHeight() / 2);
            this.b0.draw(canvas);
            canvas.restore();
            super.onDraw(canvas);
            final float n = (float)((int)this.D.width() >> 1);
            final RectF d = this.D;
            final RectF i = this.I;
            d.offsetTo(i.left - n, i.top - n);
            final RectF g = this.G;
            final RectF j = this.I;
            g.offsetTo(j.left - n, j.bottom - n);
            final RectF l = this.L;
            final RectF k = this.I;
            l.offsetTo(k.right - n, k.top - n);
            final RectF o = this.O;
            final RectF m = this.I;
            o.offsetTo(m.right - n, m.bottom - n);
            final float top = this.O.top;
            final RectF d2 = this.D;
            final float top2 = d2.top;

            s0(d2, this.I.centerX(), this.I.centerY(), this.W);
            s0(this.G, this.I.centerX(), this.I.centerY(), this.W);
            s0(this.L, this.I.centerX(), this.I.centerY(), this.W);
            s0(this.O, this.I.centerX(), this.I.centerY(), this.W);
            if (this.u && this.s) {
                canvas.save();
                canvas.rotate(this.W, this.I.centerX(), this.I.centerY());
                canvas.drawRoundRect(this.I, 10.0f, 10.0f, this.J);
                canvas.drawLine(this.I.centerX(), this.I.height() / 2.0f - 3000.0f, this.I.centerX(), this.I.height() / 2.0f + 3000.0f, this.m0);
                canvas.drawLine(this.I.width() / 2.0f - 3000.0f, this.I.centerY(), this.I.width() / 2.0f + 3000.0f, this.I.centerY(), this.n0);
                canvas.restore();
                canvas.drawBitmap(this.C, this.E, this.D, (Paint)null);
                canvas.drawBitmap(this.F, this.H, this.G, (Paint)null);
                canvas.drawBitmap(this.K, this.M, this.L, (Paint)null);
                canvas.drawBitmap(this.N, this.P, this.O, (Paint)null);
            }
        }
    }
    public static void s0(final RectF rectF, final float n, final float n2, float n3) {
        final float centerX = rectF.centerX();
        final float centerY = rectF.centerY();
        final double n4 = n3;
        n3 = (float)Math.sin(Math.toRadians(n4));
        final float n5 = (float)Math.cos(Math.toRadians(n4));
        final float n6 = centerX - n;
        final float n7 = centerY - n2;
        rectF.offset(n6 * n5 + n - n7 * n3 - centerX, n6 * n3 + (n7 * n5 + n2) - centerY);
    }
    public void onMeasure(final int n, final int n2) {
        super.onMeasure(n, n2);
        if (this.t && !this.o) {
            this.t = false;
        }
    }

    public boolean onTouchEvent(final MotionEvent motionEvent) {
        this.k0 = this;
        final boolean onTouchEvent = this.l0.onTouchEvent(motionEvent);
        boolean b = true;
        if (onTouchEvent) {
            return true;
        }
        final ScrollView i0 = this.i0;
        final int n = 0;
        Label_0108: {
            if (i0 != null) {
                final int action = motionEvent.getAction();
                Label_0100: {
                    if (action != 0) {
                        if (action != 1) {
                            if (action != 5) {
                                if (action != 6) {
                                    break Label_0108;
                                }
                            }
                            else {
                                if (this.s) {
                                    break Label_0100;
                                }
                                break Label_0108;
                            }
                        }
                        this.i0.requestDisallowInterceptTouchEvent(false);
                        break Label_0108;
                    }
                    if (!this.s) {
                        break Label_0108;
                    }
                }
                this.i0.requestDisallowInterceptTouchEvent(true);
            }
        }
        final boolean onTouchEvent2 = super.onTouchEvent(motionEvent);
        final int action2 = motionEvent.getAction();
        final float x = motionEvent.getX();
        final float y = motionEvent.getY();
        final Matrix matrix = new Matrix();
        matrix.setRotate(this.W, this.I.centerX(), this.I.centerY());
        matrix.mapRect(this.I);
        Label_1688: {
            Label_0828: {
                Label_0727: {
                    if (action2 != 0) {
                        this.setInEdit(true);
                        this.m0.setColor(0);
                        this.invalidate();
                        if (action2 != 1) {
                            if (action2 == 2) {
                                final int b2 = this.B;
                                if (b2 == 3) {
                                    this.B = 3;
                                    final float m = x - this.v;
                                    this.m = m;
                                    final float n2 = y - this.w;
                                    this.n = n2;
                                    this.x += (int)m;
                                    this.y += (int)n2;
                                    if (this.j0) {
                                        final Paint m2 = this.m0;
                                        int color;
                                        if (this.i / 2 == this.I.centerX()) {
                                            color = -65536;
                                        }
                                        else {
                                            color = 0;
                                        }
                                        m2.setColor(color);
                                        final Paint n3 = this.n0;
                                        int color2 = n;
                                        if (this.I.centerX() == this.h / 2) {
                                            color2 = -65536;
                                        }
                                        n3.setColor(color2);
                                    }
                                }
                                else if (b2 == 4) {
                                    this.B = 4;
                                    this.d(this.m = x - this.v, this.n = y - this.w, false);
                                }
                                else if (b2 == 7) {
                                    this.B = 7;
                                    this.d(this.m = x - this.v, this.n = y - this.w, true);
                                }
                                else if (b2 == 100) {
                                    this.B = 9;
                                    this.d(this.m = x - this.v, this.n, true);
                                    this.i = Math.max((int)(this.i - (this.v - x)), 40);
                                    this.a();
                                }
                                else {
                                    if (b2 == 9) {
                                        this.B = 9;
                                        final float v = this.v;
                                        this.m = x - v;
                                        this.n = y - this.w;
                                        this.i = Math.max((int)(this.i - (v - x)), 40);
                                        this.v = x;
                                        this.w = y;
                                        this.a();
                                        this.invalidate();
                                        break Label_0727;
                                    }
                                    break Label_0828;
                                }
                                this.invalidate();
                                this.v = x;
                                this.w = y;
                                break Label_0727;
                            }
                            if (action2 != 3) {
                                break Label_0828;
                            }
                        }
                        if (System.currentTimeMillis() - this.k <= 10L && (this.m <= 20.0f || this.n <= 20.0f)) {
                            this.u = false;
                            this.invalidate();
                            return true;
                        }
                        this.B = 2;
                        this.m0.setColor(0);
                        this.n0.setColor(0);
                        b = false;
                    }
                    else if (this.D.contains(x, y)) {
                        this.setInEdit(true);
                        this.u = true;
                        this.B = 5;
                        final a s = this.S;
                        if (s != null) {
                            s.c(this);
                        }
                        break Label_0828;
                    }
                    else {
                        if (this.G.contains(x, y)) {
                            this.setInEdit(true);
                            this.u = true;
                            this.B = 6;
                            final a s2 = this.S;
                            if (s2 != null) {
                                s2.d(this);
                            }
                            this.invalidate();
                            break Label_0828;
                        }
                        RectF rectF;
                        if (this.L.contains(x, y)) {
                            this.setInEdit(true);
                            this.u = true;
                            this.B = 4;
                            this.v = this.L.centerX();
                            rectF = this.L;
                        }
                        else if (this.O.contains(x, y)) {
                            this.setInEdit(true);
                            this.u = true;
                            this.B = 7;
                            this.v = this.O.centerX();
                            rectF = this.O;
                        }
                        else {
                            if (this.I.contains(x, y)) {
                                this.setInEdit(true);
                                this.u = true;
                                this.B = 3;
                                this.v = x;
                                this.w = y;
                                this.k = System.currentTimeMillis();
                                break Label_0727;
                            }
                            final float[] array = new float[9];
                            this.o0.getValues(array);
                            final float n4 = array[0];
                            final float n5 = array[1];
                            final float n6 = array[2];
                            final float n7 = array[3];
                            final float n8 = array[4];
                            final float n9 = array[5];
                            final float n10 = array[0];
                            final float n11 = (float)this.getWidth();
                            final float n12 = array[1];
                            final float n13 = array[2];
                            final float n14 = array[3];
                            final float n15 = array[4];
                            final float n16 = array[5];
                            final float n17 = array[0];
                            final float n18 = array[1];
                            final float n19 = (float)this.getHeight();
                            final float n20 = array[2];
                            final float n21 = array[3];
                            final float n22 = array[4];
                            final float n23 = array[5];
                            final float n24 = array[0];
                            final float n25 = array[1];
                            final float n26 = array[2];
                            final float n27 = array[3];
                            final float n28 = array[4];
                            final float n29 = array[5];
                            final float x2 = motionEvent.getX(0);
                            final float y2 = motionEvent.getY(0);
                            final float[] array2 = { com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n5, 0.0f, n4 * 0.0f, n6), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n12, 0.0f, n10 * n11, n13),  com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n25, n19, n24 * n11, n26),  com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n18, n19, n17 * 0.0f, n20) };
                            final float[] array3 = {  com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n8, 0.0f, n7 * 0.0f, n9), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n15, 0.0f, n14 * n11, n16), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n28, n19, n27 * n11, n29), com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.m(n22, n19, n21 * 0.0f, n23) };
                            final double hypot = Math.hypot(array2[0] - array2[1], array3[0] - array3[1]);
                            final double hypot2 = Math.hypot(array2[1] - array2[2], array3[1] - array3[2]);
                            final double hypot3 = Math.hypot(array2[3] - array2[2], array3[3] - array3[2]);
                            final double hypot4 = Math.hypot(array2[0] - array2[3], array3[0] - array3[3]);
                            final double hypot5 = Math.hypot(x2 - array2[0], y2 - array3[0]);
                            final double hypot6 = Math.hypot(x2 - array2[1], y2 - array3[1]);
                            final double hypot7 = Math.hypot(x2 - array2[2], y2 - array3[2]);
                            final double hypot8 = Math.hypot(x2 - array2[3], y2 - array3[3]);
                            final double a = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot, hypot5, hypot6, 2.0);
                            final double a2 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot2, hypot6, hypot7, 2.0);
                            final double a3 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot3, hypot7, hypot8, 2.0);
                            final double a4 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.a(hypot4, hypot8, hypot5, 2.0);
                            if (Math.abs(hypot * hypot2 - (Math.sqrt((a4 - hypot5) * ((a4 - hypot8) * ((a4 - hypot4) * a4))) + (Math.sqrt((a3 - hypot8) * ((a3 - hypot7) * ((a3 - hypot3) * a3))) + (Math.sqrt((a2 - hypot7) * ((a2 - hypot6) * ((a2 - hypot2) * a2))) + Math.sqrt((a - hypot6) * ((a - hypot5) * ((a - hypot) * a))))))) < 0.5) {
                                this.setInEdit(false);
                            }
                            break Label_0828;
                        }
                        this.w = rectF.centerY();
                    }
                }
                break Label_1688;
            }
            b = onTouchEvent2;
        }
        if (b) {
            final a s3 = this.S;
            if (s3 != null) {
                s3.a(this);
            }
        }
        return b;
    }

    public void setAlign(final Layout.Alignment g) {
        this.g = g;
        this.invalidate();
    }

    public void setEditText(final boolean o) {
        this.o = o;
        this.invalidate();
    }

    public void setFont(final Font r) {
        this.r = r;
        this.invalidate();
    }

    public void setHeightWidth(final Context context, final int i) {
        this.i = i;
        this.a();
        this.b(context);
        this.invalidate();
    }

    public void setInEdit(final boolean s) {
        this.s = s;
        final b t = this.T;
        if (t != null) {
            t.a(s, this);
        }
        this.invalidate();
    }

    public void setLayoutX(final int x) {
        this.x = x;
        this.invalidate();
    }

    public void setLayoutY(final int y) {
        this.y = y;
        this.invalidate();
    }

    public void setLetterSpacing(final float z) {
        this.z = z;
        this.invalidate();
    }

    public void setLineSpacing(final float a) {
        this.A = a;
        this.invalidate();
    }

    public void setOnOutSideTouchListner(final b t) {
        this.T = t;
    }

    public void setOpacity(final int r) {
        this.R = r;
        this.invalidate();
    }

    public void setOperationListener(final a s) {
        this.S = s;
    }

    public void setPaddingLeft(final int u) {
        this.U = u;
        this.invalidate();
    }

    public void setPaddingRight(final int v) {
        this.V = v;
        this.invalidate();
    }

    public void setRotateAngle(final float w) {
        this.W = w;
        this.invalidate();
    }

    public void setScale(final float a0) {
        this.a0 = a0;
        this.invalidate();
    }

    public void setShowHelpBox(final boolean u) {
        this.u = u;
        this.invalidate();
    }

    public void setStrikethrough(final boolean c0) {
        this.c0 = c0;
        this.invalidate();
    }

    public void setText(final String d0) {
        this.d0 = d0;
        this.invalidate();
    }

    public void setUnderLine(final boolean h0) {
        this.h0 = h0;
        this.invalidate();
    }

    public interface a
    {
        void a(final TextStickerViewNew1 p0);

        void b(final TextStickerViewNew1 p0);

        void c(final TextStickerViewNew1 p0);

        void d(final TextStickerViewNew1 p0);
    }

    public interface b
    {
        void a(final boolean p0, final TextStickerViewNew1 p1);
    }

    public class c extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onDoubleTap(final MotionEvent motionEvent) {
            final TextStickerViewNew1 e = TextStickerViewNew1.this;
            e.S.b(e.k0);
            return false;
        }

        public boolean onDoubleTapEvent(final MotionEvent motionEvent) {
            return false;
        }

        public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
            final ScrollView i0 = TextStickerViewNew1.this.i0;
            if (i0 != null) {
                i0.requestDisallowInterceptTouchEvent(true);
            }
            return false;
        }
    }
}
