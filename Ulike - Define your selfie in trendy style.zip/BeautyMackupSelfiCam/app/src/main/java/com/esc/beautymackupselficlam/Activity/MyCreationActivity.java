package com.esc.beautymackupselficlam.Activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;

import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.utils.Utils;
import com.esc.beautymackupselficlam.adapter.CreationAdapter;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.Collections;

import androidx.annotation.NonNull;

public class MyCreationActivity extends Activity {
    private static final String IMAGE_DIRECTORY_NAME = "SweetSelfie";
    private static final int MY_REQUEST_CODE = 5;
    private ImageView iv_back;
    private CreationAdapter galleryAdapter;
    private GridView gridview_imagelist;
    private ImageView noImage;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation);
    }

    protected void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {
        this.noImage = (ImageView) findViewById(R.id.novideoimg);
        this.gridview_imagelist = (GridView) findViewById(R.id.grid_imgLst);
        getImages();
        loadAd();
        if (Utils.Glob.IMAGEALLARY.size() <= 0) {
            this.noImage.setVisibility(View.VISIBLE);
            this.gridview_imagelist.setVisibility(View.GONE);
        } else {
            this.noImage.setVisibility(View.GONE);
            this.gridview_imagelist.setVisibility(View.VISIBLE);
        }
        this.iv_back = (ImageView) findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(MyCreationActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });
        Collections.sort(Utils.Glob.IMAGEALLARY);
        Collections.reverse(Utils.Glob.IMAGEALLARY);

        this.galleryAdapter = new CreationAdapter(this, Utils.Glob.IMAGEALLARY);
        this.gridview_imagelist.setAdapter(this.galleryAdapter);
        gridview_imagelist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                Intent i = new Intent(MyCreationActivity.this,
                        ActivityShowImage.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });
    }

    private void getImages() {
        if (VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    5);
        }
    }

    private void fetchImage() {
        Utils.Glob.IMAGEALLARY.clear();
        Utils.Glob.listAllImages(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME + "/"));
        Log.e("path", "" + (new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME + "/")));
    }

    public void onBackPressed() {
        startActivity(new Intent(MyCreationActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 5:
                if (grantResults[0] == 0) {
                    fetchImage();
                    return;
                } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            5);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitial;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(MyCreationActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        startActivity(new Intent(MyCreationActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(MyCreationActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
