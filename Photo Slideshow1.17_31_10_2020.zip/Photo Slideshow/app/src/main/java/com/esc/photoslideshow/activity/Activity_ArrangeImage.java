package com.esc.photoslideshow.activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.esc.photoslideshow.MyApplication;
import com.esc.photoslideshow.R;
import com.esc.photoslideshow.adapters.ImageEditAdapter;
import com.esc.photoslideshow.adapters.OnItemClickListner;
import com.esc.photoslideshow.data.ImageData;
import com.esc.photoslideshow.util.ActivityAnimUtil;
import com.esc.photoslideshow.util.ImageEditor;
import com.esc.photoslideshow.util.Utils;
import com.esc.photoslideshow.view.EmptyRecyclerView;
import java.io.File;

import static com.esc.photoslideshow.view.CustomNativeAd.populateUnifiedNativeAdView;

public class Activity_ArrangeImage extends AppCompatActivity {
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isEdit = false;
    RelativeLayout rlToolbar;
    ImageView ivback,ivnext;

    Callback callback = new Callback() {
        @Override
        public boolean onMove(RecyclerView recyclerView, ViewHolder viewHolder, ViewHolder viewHolder2) {
            return true;
        }

        @Override
        public void onSwiped(ViewHolder viewHolder, int i) {
        }


        @Override
        public void onSelectedChanged(ViewHolder viewHolder, int i) {
            if (i == 0) {
                Activity_ArrangeImage.this.imageEditAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onMoved(final RecyclerView recyclerView, final ViewHolder recyclerView$ViewHolder, final int n, final ViewHolder recyclerView$ViewHolder2, final int n2, final int n3, final int n4) {
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n2 == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n2 == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            Activity_ArrangeImage.this.imageEditAdapter.swap(recyclerView$ViewHolder.getAdapterPosition(), recyclerView$ViewHolder2.getAdapterPosition());
            Activity_ArrangeImage.this.application.min_pos = Math.min(Activity_ArrangeImage.this.application.min_pos, Math.min(n, n2));
            MyApplication.isBreak = true;
        }

        public int getMovementFlags(RecyclerView recyclerView, ViewHolder viewHolder) {
            return makeFlag(2, 51);
        }
    };
    private MyApplication application;
    private ImageEditAdapter imageEditAdapter;
    private boolean isFromCameraNotification;
    public boolean isFromPreview = false;
    private EmptyRecyclerView rvSelectedImages;
    String tempImgPath;




    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_arrange_images);
        if (Utils.checkPermission(this)) {
            this.isFromPreview = getIntent().hasExtra("extra_from_preview");
            this.application = MyApplication.getInstance();
            this.application.isEditModeEnable = true;
            bindView();
            init();
            addListener();
            loadAd();
            return;
        }
        PutAnalyticsEvent();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);


    }

    private void bindView() {
        rvSelectedImages = findViewById(R.id.rvVideoAlbum);
        rlToolbar=findViewById(R.id.rl_toolbar);
        ivback=findViewById(R.id.iv_back);
        ivnext=findViewById(R.id.iv_next);

    }
    private void addListener() {
        ivback.setOnClickListener(v -> onBackPressed());
        ivnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    addTitle();
                }
            }
        });
    }
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "Activity_ArrangeImage");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        setupAdapter();
        new ItemTouchHelper(this.callback).attachToRecyclerView(this.rvSelectedImages);
        Utils.setFont(this, R.id.toolbar_title);
        this.isFromCameraNotification = getIntent().getExtras().getBoolean("isFromCameraNotification");
        if (getIntent().getExtras().getString("KEY").equals("FromImageSelection") || getIntent().getExtras().getString("KEY").equals("FromCameraService") || getIntent().getExtras().getString("KEY").equals("FromPreview")) {
            isEdit = true;
        }
    }

    private void setupAdapter() {
        LayoutManager gridLayoutManager = new GridLayoutManager(this, 2, RecyclerView.VERTICAL, false);
        this.imageEditAdapter = new ImageEditAdapter(Activity_ArrangeImage.this);
        this.rvSelectedImages.setLayoutManager(gridLayoutManager);
        this.rvSelectedImages.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImages.setEmptyView(findViewById(R.id.list_empty));
        this.rvSelectedImages.setAdapter(this.imageEditAdapter);
        this.imageEditAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                Integer.parseInt((String) view.getTag());
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == ImageEditor.IMAGE_EDIT_ACTIVITY_TEXT_AND_STICKER && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData idata = new ImageData();
            idata.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, idata);
            setupAdapter();
        }
    }

    protected void onResume() {
        super.onResume();
        if (Utils.checkPermission(this)) {
            this.application.isEditModeEnable = true;
            if (this.imageEditAdapter != null) {
                this.imageEditAdapter.notifyDataSetChanged();
                return;
            }
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private boolean isEndFrameExist() {
        return Fragment_EndFrame.lastsaveTempPath != null && new File(Fragment_EndFrame.lastsaveTempPath).exists();
    }

    private boolean isStartFrameExist() {
        return new File(Fragment_StartFrame.lastsaveTempPath).exists();
    }


    private void done() {
        this.application.isEditModeEnable = false;
        if (this.isFromPreview) {
            setResult(-1);
            finish();
            return;
        }
        ActivityAnimUtil.startActivitySafely(this.rlToolbar, new Intent(this, PreviewActivity.class));
    }

    private void addTitle() {
        Intent intent = new Intent(this, AddTitleActivity.class);
        intent.putExtra("ISFROMPREVIEW", this.isFromPreview);
        ActivityAnimUtil.startActivitySafely(this.rlToolbar, intent);
        if (this.isFromPreview) {
            finish();
        }
    }

    public void onBackPressed() {
        isEdit = false;
        if (this.isFromPreview && !this.isFromCameraNotification) {
            addTitleAlert();
        }
        if (this.isFromCameraNotification) {
            Intent intent = new Intent(this, PhotoselectActivity.class);
            intent.putExtra("isFromImageEditActivity", true);
            startActivity(intent);
            finish();
            return;
        }
        onBackDialog();
    }

    private void addTitleAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppAlertDialog);
        builder.setTitle(R.string.add_story_title);
        builder.setMessage(R.string.do_you_want_to_add_title_frame_);
        builder.setPositiveButton(R.string.yes, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Activity_ArrangeImage.this.application.isEditModeEnable = false;
                final Intent intent = new Intent(Activity_ArrangeImage.this, AddTitleActivity.class);
                intent.putExtra("ISFROMPREVIEW", Activity_ArrangeImage.this.isFromPreview);
                ActivityAnimUtil.startActivitySafely(Activity_ArrangeImage.this.rlToolbar, intent);
                if (Activity_ArrangeImage.this.isFromPreview) {
                    Activity_ArrangeImage.this.finish();
                }
            }
        });
        builder.setNegativeButton(R.string.skip, new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Activity_ArrangeImage.this.done();
            }
        });
        builder.show();
    }

    private void onBackDialog() {
        new AlertDialog.Builder(this, R.style.Theme_MovieMaker_AlertDialog).setTitle(R.string.app_name).setMessage(R.string.your_changes_on_images_will_be_removed_are_you_sure_to_go_back_).setPositiveButton(R.string.go_back, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                if (Activity_ArrangeImage.this.isFromPreview && !Activity_ArrangeImage.this.isFromCameraNotification) {
                    Activity_ArrangeImage.this.done();
                    return;
                }
                final Intent intent = new Intent(Activity_ArrangeImage.this, PhotoselectActivity.class);
                intent.putExtra("isFromImageEditActivity", true);
                Activity_ArrangeImage.this.startActivity(intent);
                Activity_ArrangeImage.this.finish();
            }
        }).setNegativeButton(R.string.stay_here, null).create().show();
    }

    //    public void AdsDialogShow() {
//        Handler mHandler = new Handler();
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                interstitial.show();
//                dialog.dismiss();
//            }
//        }, 2000);
//    }
    private UnifiedNativeAd nativeAd;
    private InterstitialAd mInterstitialAd;

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(this.getString(R.string.admob_inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().addTestDevice("A82A510A487DC76124317D6A70B3E4DD").build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                addTitle();
            }
        });
    }

}
