package com.wavymusic.notification.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;

public class SplashActivity extends AppCompatActivity {

    Activity activity = SplashActivity.this;
    public  boolean IsNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        IsNotification = getIntent().getBooleanExtra("IsFromNotification", false);
        Intent intent = new Intent(activity, UnityPlayerActivity.class);
        intent.putExtra("IsFromNotification", IsNotification);
        startActivity(intent);
        finish();
    }
}