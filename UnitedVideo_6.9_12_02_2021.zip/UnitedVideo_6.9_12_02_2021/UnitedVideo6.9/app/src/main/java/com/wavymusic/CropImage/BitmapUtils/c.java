package com.wavymusic.CropImage.BitmapUtils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.media.ExifInterface;

import java.io.IOException;

public class c {
    public static Bitmap as(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width == i && height == i2) {
            return bitmap;
        }
        float f = (float) i;
        float f2 = (float) width;
        float f3 = (float) i2;
        float f4 = (float) height;
        float max = Math.max(f / f2, f3 / f4);
        f2 *= max;
        max *= f4;
        f = (f - f2) / 2.0f;
        f3 = (f3 - max) / 2.0f;
        RectF rectF = new RectF(f, f3, f2 + f, max + f3);
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, bitmap.getConfig());
        new Canvas(createBitmap).drawBitmap(bitmap, null, rectF, null);
        return createBitmap;
    }

    public static Bitmap a(String str) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        int int1 = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        Bitmap decodeFile = BitmapFactory.decodeFile(str, new BitmapFactory.Options());
        try {
            str = new ExifInterface(str).getAttribute("Orientation");
            if (str != null) {
                int1 = Integer.parseInt(str);
            }
            int n = 0;
            if (int1 == 6) {
                n = 90;
            }
            if (int1 == 3) {
                n = 180;
            }
            if (int1 == 8) {
                n = 270;

            }

            Matrix matrix = new Matrix();
            matrix.setRotate((float) int1, ((float) decodeFile.getWidth()) / 2.0f, ((float) decodeFile.getHeight()) / 2.0f);
            return Bitmap.createBitmap(decodeFile, 0, 0, options.outWidth, options.outHeight, matrix, true);
        } catch (IOException e) {
            e.printStackTrace();
            return null;

        }

    }
}
