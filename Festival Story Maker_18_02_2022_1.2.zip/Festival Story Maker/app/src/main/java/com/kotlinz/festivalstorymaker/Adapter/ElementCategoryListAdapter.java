package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.Model.CollageMaker.Element.ElementMainResponse;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.ElementsActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ElementCategoryListAdapter extends RecyclerView.Adapter<ElementCategoryListAdapter.Viewholder> {

    public ElementsActivity elementsActivity;
    public ArrayList<ElementMainResponse> elementCategoryItems;
    public int SelectedPosition = 0;

    public ElementCategoryListAdapter(Activity activity, ArrayList<ElementMainResponse> arrayList) {
        this.elementsActivity = (ElementsActivity) activity;
        this.elementCategoryItems = arrayList;
    }

    public interface a {
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_background_category_list_item, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, @SuppressLint("RecyclerView") int position) {
        holder.txt.setText(elementCategoryItems.get(position).getElementCategoryName());
        holder.txt.setTextColor(position == SelectedPosition ? elementsActivity.getResources().getColor(R.color.element_press) : elementsActivity.getResources().getColor(R.color.element_unpress));
        if (position == SelectedPosition) {
            holder.txt.setBackgroundColor(elementsActivity.getResources().getColor(R.color.element_round));
        } else {
            holder.txt.setBackgroundColor(elementsActivity.getResources().getColor(R.color.transparent));
        }

        holder.rlMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                elementsActivity.GetCategoryWiseElementData(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.elementCategoryItems.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        @BindView(R.id.rlMain)
        public RelativeLayout rlMain;

        @BindView(R.id.txt)
        public TextView txt;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
