package com.esc.poems;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Second1 extends AppCompatActivity {
    protected static DataBaseHelper baseHelper = null;
    protected static Editor editor1 = null;
    public static Boolean s_popupads = Boolean.valueOf(false);
    private static int sh = 0;
    protected static SharedPreferences sharedPreferences1 = null;
    private static int sw;
    private int[] AD_NATIVE;
    private int[] MORE_APPS;
    private String TAG = "Second1";
    public ArrayList<String> a;
    private Activity activity;
    public ArrayList<String> cat_name;
    private SecondRecyclerViewAdapter customAdapter;
    private Dialog dialogD;
    public ArrayList<Integer> f;
    private Typeface face3;
    private List<Object> mRecyclerViewItems = new ArrayList();
    public ArrayList<String> mid;
    public ArrayList<String> q;
    public ArrayList<Integer> r = new ArrayList();
    private RecyclerView recyclerView;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_second1);
        this.activity = this;
        int i = 0;
        this.MORE_APPS = new int[0];
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.mRecyclerViewItems.clear();
        this.recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        SharedPreferences sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        sharedPreferences1 = sharedPreferences;
        editor1 = sharedPreferences.edit();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        sw = displayMetrics.widthPixels;
        sh = displayMetrics.heightPixels;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#ffffff'>Poems</font>"));
        this.q = new ArrayList();
        this.mid = new ArrayList();
        this.f = new ArrayList();
        this.a = new ArrayList();
        this.cat_name = new ArrayList();
        Bundle extras = getIntent().getExtras();
        String string = extras.getString("subcatname");
        String string2 = extras.getString("subcatid");
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getApplicationContext());
        baseHelper = dataBaseHelper;
        try {
            dataBaseHelper.createDataBase();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        Typeface createFromAsset = Typeface.createFromAsset(getAssets(), "fonts/roboto_thin.ttf");
        this.face3 = Typeface.createFromAsset(getAssets(), "fonts/roboto_medium.ttf");
        TextView textView = (TextView) findViewById(R.id.heading);
        textView.setText(string);
        textView.setTypeface(createFromAsset, Typeface.BOLD);
        this.q = baseHelper.getMessages(Integer.parseInt(string2));
        this.mid = baseHelper.getMessagesId(Integer.parseInt(string2));
        this.f = baseHelper.getFavorite(Integer.parseInt(string2));
        while (i < this.mid.size()) {
            this.cat_name.add(i, extras.getString("categroy"));
            i++;
        }
        insertAdsInMenuItems();
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void insertAdsInMenuItems() {
        if (!this.activity.isFinishing()) {
            if (this.mRecyclerViewItems.size() > 0) {
                this.mRecyclerViewItems.clear();
            }
            String str = "ListView Item ***5***#";
            int i = 0;
            if (this.q.size() <= 3) {
                this.AD_NATIVE = new int[0];
                this.MORE_APPS = new int[0];
                while (i < this.q.size()) {
                    List list = this.mRecyclerViewItems;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(i);
                    list.add(i, stringBuilder.toString());
                    i++;
                }
            } else {
                int i2 = 0;
                int i3 = 0;
                while (i2 < this.q.size()) {
                    List list2 = this.mRecyclerViewItems;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str);
                    stringBuilder2.append(i2);
                    list2.add(i2, stringBuilder2.toString());
                    if (i2 != 0 && i2 % 12 == 0) {
                        i3++;
                    }
                    i2++;
                }
                String str2 = this.TAG;
                StringBuilder stringBuilder3 = new StringBuilder();
                String str3 = "*****VALUE--->";
                stringBuilder3.append(str3);
                stringBuilder3.append(i3);
                Log.e(str2, stringBuilder3.toString());
                str2 = this.TAG;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str3);
                stringBuilder3.append(this.q.size());
                Log.e(str2, stringBuilder3.toString());
                if (this.q.size() < 10) {
                    this.MORE_APPS = new int[0];
                } else if (i3 > 2 && this.q.size() >= 24) {
                    this.MORE_APPS = new int[3];
                } else if (i3 > 1 && this.q.size() >= 14) {
                    this.MORE_APPS = new int[2];
                } else if (i3 == 1) {
                    this.MORE_APPS = new int[i3];
                }
                this.AD_NATIVE = new int[(i3 + 1)];
                i2 = 0;
                while (i < this.q.size()) {
                    str = "**** value   ";
                    String str4 = "    ";
                    int[] iArr;
                    String str5;
                    StringBuilder stringBuilder4;
                    if (i2 == 0) {
                        this.AD_NATIVE[i2] = 2;
                        iArr = this.MORE_APPS;
                        if (i2 < iArr.length) {
                            iArr[i2] = 5;
                        }
                        str5 = this.TAG;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(str);
                        stringBuilder4.append(i);
                        stringBuilder4.append(str4);
                        stringBuilder4.append(this.AD_NATIVE[i2]);
                        stringBuilder4.append(str4);
                        stringBuilder4.append(i2);
                        Log.e(str5, stringBuilder4.toString());
                    } else if (i % 12 != 0) {
                        i++;
                    } else {
                        if (i2 == 1 || i2 == 2) {
                            iArr = this.MORE_APPS;
                            if (i2 < iArr.length) {
                                iArr[i2] = i + 5;
                            }
                        }
                        this.AD_NATIVE[i2] = i;
                        str5 = this.TAG;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(str);
                        stringBuilder4.append(i);
                        stringBuilder4.append(str4);
                        stringBuilder4.append(this.AD_NATIVE[i2]);
                        stringBuilder4.append(str4);
                        stringBuilder4.append(i2);
                        Log.e(str5, stringBuilder4.toString());
                    }
                    i2++;
                    i++;
                }
            }
            loadQuotes();
        }
    }

    public void loadQuotes() {
        if (!this.activity.isFinishing()) {
            if (this.mRecyclerViewItems.size() == 0) {
                for (int i = 0; i < this.q.size(); i++) {
                    List list = this.mRecyclerViewItems;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("ListView Item ***5***#");
                    stringBuilder.append(i);
                    list.add(i, stringBuilder.toString());
                }
            }
            SecondRecyclerViewAdapter secondRecyclerViewAdapter = new SecondRecyclerViewAdapter(this.activity, sh, sw, this.q, this.mid, this.f, this.a, this.cat_name, this.mRecyclerViewItems);
            this.customAdapter = secondRecyclerViewAdapter;
            this.recyclerView.setAdapter(secondRecyclerViewAdapter);
        }
    }

    public void showRateUsdialog() {
        String str = "firstvisit";
        if (sharedPreferences1.getInt(str, 0) == 0) {
            editor1.putInt(str, sharedPreferences1.getInt(str, 0) + 1);
            editor1.commit();
        }
        Dialog dialog = this.dialogD;
        if (dialog == null || !dialog.isShowing()) {
            View inflate = View.inflate(this, R.layout.rateusdialog, null);
            Dialog dialog2 = new Dialog(this);
            this.dialogD = dialog2;
            dialog2.getWindow();
            dialog2.requestWindowFeature(1);
            this.dialogD.setContentView(inflate);
            this.dialogD.setCancelable(false);
            TextView textView = (TextView) this.dialogD.findViewById(R.id.displayads_text);
            textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            Button button = (Button) this.dialogD.findViewById(R.id.btnlater);
            button.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Second1.editor1.putInt("count", 1);
                    Second1.editor1.commit();
                    Second1.s_popupads = Boolean.valueOf(false);
                    Second1.this.dialogD.cancel();
                    Map hashMap = new HashMap();
                    String str = "Rate";
                    hashMap.put(str, "Ask Later Clicked");
                    Bundle bundle = new Bundle();
                    bundle.putString("BtnClicked", "Ask_Later");
                    Second1.this.finish();
                }
            });
            Button button2 = (Button) this.dialogD.findViewById(R.id.btnrateus);
            button2.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Second1.this.dialogD.cancel();
                    Second1.editor1.putInt("count", 1);
                    Second1.editor1.commit();
                    Second1.s_popupads = Boolean.valueOf(false);
                    Second1.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MyApplication.appLink + getPackageName())));
                    Map hashMap = new HashMap();
                    String str = "Rate";
                    hashMap.put(str, "Yes I will Clicked");
                    Bundle bundle = new Bundle();
                    bundle.putString("BtnClicked", "Yes_I_will");
                    Second1.this.finish();
                }
            });
            button.setTypeface(this.face3);
            button2.setTypeface(this.face3);
            if (!isFinishing()) {
                this.dialogD.show();
            }
            if ((getResources().getConfiguration().screenLayout & 15) == 4) {
                textView.setTypeface(this.face3);
                textView.setTextSize(32.0f);
                button.setTextSize(30.0f);
                button2.setTextSize(30.0f);
            } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
                textView.setTypeface(this.face3);
                textView.setTextSize(28.0f);
                button.setTextSize(26.0f);
                button2.setTextSize(26.0f);
            } else {
                textView.setTypeface(this.face3);
                textView.setTextSize(20.0f);
                button.setTextSize(18.0f);
                button2.setTextSize(18.0f);
            }
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            System.gc();
            startActivity(new Intent(this, FavoriteActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }


    public void onBackPressed() {
        if (sharedPreferences1.getInt("count", 0) > 8 || sharedPreferences1.getInt("firstvisit", 0) == 0) {
            showRateUsdialog();
            return;
        }
        s_popupads = Boolean.valueOf(false);
        super.onBackPressed();
    }
}
