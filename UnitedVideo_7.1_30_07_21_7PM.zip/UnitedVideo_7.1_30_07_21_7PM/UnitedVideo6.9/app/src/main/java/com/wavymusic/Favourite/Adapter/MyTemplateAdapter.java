package com.wavymusic.Favourite.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.Favourite.Activity.FavouriteActivity;
import com.wavymusic.Favourite.Database.DatabaseHelper;
import com.wavymusic.Favourite.Model.MytemplateModel;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.AppConstant;
import java.util.List;


public class MyTemplateAdapter extends RecyclerView.Adapter<MyTemplateAdapter.Myholder> {
    private List<MytemplateModel> mytemplateModelList;
    private Context mContext;
    DatabaseHelper databaseHelper;
    private FavouriteActivity ActivityOfTheme;

    public MyTemplateAdapter(Context mContext, List<MytemplateModel> dataModelArrayList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (FavouriteActivity) mContext;
        databaseHelper = new DatabaseHelper(mContext);
        this.mytemplateModelList = dataModelArrayList;
    }

    @NonNull
    @Override
    public Myholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_my_template, null);
        return new Myholder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull final Myholder holder, @SuppressLint("RecyclerView") final int position) {
        final MytemplateModel templatemodel = mytemplateModelList.get(position);

        Glide.with(mContext).load(mytemplateModelList.get(position).getImage()).into(holder.iv_thumb);
        holder.tvThemeName.setText(templatemodel.getThemeName());
        holder.tvThemeName.setSelected(true);
        holder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityOfTheme.IsMian.equals("Home")){
                    MyApplication.AllFilePathUv = templatemodel.getBundelPath() + MyApplication.SPLIT_PATTERN + templatemodel.getPrefebName() + MyApplication.SPLIT_PATTERN + templatemodel.getAnimSoundPath() + MyApplication.SPLIT_PATTERN + templatemodel.getVideoType() + MyApplication.SPLIT_PATTERN + AppConstant.ThemeHome;
                }else {
                    MyApplication.AllFilePathUv = templatemodel.getBundelPath() + MyApplication.SPLIT_PATTERN + templatemodel.getPrefebName() + MyApplication.SPLIT_PATTERN + templatemodel.getAnimSoundPath() + MyApplication.SPLIT_PATTERN + templatemodel.getVideoType() + MyApplication.SPLIT_PATTERN + AppConstant.ThemeViewAll;
                }
                Log.e("TAG","IsMianAdpUv"+ActivityOfTheme.IsMian);
                ActivityOfTheme.ShowBannerAds();
                UnityPlayer.UnitySendMessage("AndroidManager", "GoUVPreview", MyApplication.AllFilePathUv);
                ActivityOfTheme.finish();
            }
        });
        holder.ivDeleteFavTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppDialog);
                builder.setTitle("Unfavorite Theme");
                builder.setMessage(String.valueOf(mContext.getResources().getString(R.string.deleteMessage)) + templatemodel.getThemeName() + "?");
                builder.setPositiveButton("Unfavorite", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int which) {
                        databaseHelper.deleteThemeUv(templatemodel.getThemeName());
                        itemRemoved(position);
                        MyTemplateAdapter.this.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Cancel", null);
                builder.show();
            }
        });
    }

    public void itemRemoved(int pos) {
        if ((mytemplateModelList != null) && (mytemplateModelList.size() > 0)) {
            mytemplateModelList.remove(pos);
        }
    }

    @Override
    public int getItemCount() {
        return mytemplateModelList.size();
    }

    class Myholder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDeleteFavTheme;
        TextView tvThemeName;
        ImageView ivUseTheme;

        Myholder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_mytemplate);
            iv_thumb = itemView.findViewById(R.id.iv_thumb_mytemplate);
            ivDeleteFavTheme = itemView.findViewById(R.id.iv_delete_fav);
            tvThemeName = itemView.findViewById(R.id.tv_name_mytemplate);
            ivUseTheme = itemView.findViewById(R.id.iv_use_mytemplate);
        }
    }
}
