package com.kotlinz.vehiclemanager.history.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.history.Adapter.HomeFragmentPageAdapter;
import com.kotlinz.vehiclemanager.history.Fragment.OwnerInfoFragment;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import org.jetbrains.annotations.NotNull;

public class HistoryTabLayoutActivity extends AppCompatActivity {
    private Activity activity = HistoryTabLayoutActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView iv_back;
    private HomeFragmentPageAdapter homePageAdapter;
    private LinearLayout linearLayout;
    private TextView title_tv;

    GGAdview gg_native;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_tab_layout);
        PutAnalyticsEvent();
        CallNativeAds();
        InterAds();
        iv_back = findViewById(R.id.iv_back);
        viewPager = findViewById(R.id.viewPager);
        linearLayout = findViewById(R.id.ll_tab);
        title_tv = findViewById(R.id.tv_title);
        setViewPager();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(HistoryTabLayoutActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HistoryTabLayoutActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void CallNativeAds(){
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback()
                         {
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(HistoryTabLayoutActivity.this, MainActivity.class));
                        finish();
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    private void setupDarkMode() {
        linearLayout.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void setViewPager() {
        homePageAdapter = new HomeFragmentPageAdapter(getSupportFragmentManager());
        homePageAdapter.addFragment(new OwnerInfoFragment(), "Owner Info");
        viewPager.setAdapter(homePageAdapter);
    }

    private void CreateTab() {
        TextView OwnerInfo = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        OwnerInfo.setText("Owner Info");
        tabLayout.getTabAt(0).setCustomView(OwnerInfo);

    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(HistoryTabLayoutActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}