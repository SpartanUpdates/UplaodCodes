package com.esc.dailyrandomfacts.managers;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.esc.dailyrandomfacts.util.Quotes;

public class SettingsManager {
    private static final String PREF_APP_UPDATE = "pref_app_updatecom.esc.dailyrandomfacts.facts";
    private static final String PREF_DARK_MODE = "pref_dark_modecom.esc.dailyrandomfacts.facts";
    private static final String PREF_DATE_OPEN = "pref_date_opencom.esc.dailyrandomfacts.facts";
    private static final String PREF_FIRST_TIME = "pref_first_time_com.esc.dailyrandomfacts.facts";
    private static final String PREF_INFO_LANGUAGE_SHOWED = "pref_info_language_showedcom.esc.dailyrandomfacts.facts";
    private static final String PREF_LANGUAGE = "pref_languagecom.esc.dailyrandomfacts.facts";
    private static final String PREF_LANGUAGE_FIRST_TIME = "pref_language_firstcom.esc.dailyrandomfacts.facts";
    private static final String PREF_OWN_BACKGROUND = "pref_own_backgroundcom.esc.dailyrandomfacts.facts";
    private static final String PREF_RATE_DONE = "pref_rate_down_com.esc.dailyrandomfacts.facts";
    private static final String PREF_RATE_SHOWED = "pref_rate_showed_com.esc.dailyrandomfacts.facts";
    private static final String PREMIUM = "premium_com.esc.dailyrandomfacts.facts";

    public static boolean isPremium() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREMIUM, false);
    }

    public static void setPremium(boolean z) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREMIUM, z);
        edit.commit();
    }

    public static boolean isFirstTime() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_FIRST_TIME, true);
    }

    public static void setFirstTime(boolean z) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_FIRST_TIME, z);
        edit.commit();
    }

    public static Context getContext() {
        return Quotes.getInstance();
    }

    public static void setOwnBackground(String str) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putString(PREF_OWN_BACKGROUND, str);
        edit.commit();
    }

    public static String getOwnBackground() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_OWN_BACKGROUND, null);
    }

    public static String getDateOpen() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_DATE_OPEN, null);
    }

    public static void setDateOpen(String str) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putString(PREF_DATE_OPEN, str);
        edit.commit();
    }

    public static boolean isRateShowed() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_RATE_SHOWED, false);
    }

    public static void setRateShowed() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_RATE_SHOWED, true);
        edit.commit();
    }

    public static boolean isInfoLanguageShowed() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_INFO_LANGUAGE_SHOWED, false);
    }

    public static void setInfoLanguageShowed() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_INFO_LANGUAGE_SHOWED, true);
        edit.commit();
    }

    public static boolean isRateDone() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_RATE_DONE, false);
    }

    public static void setRateDone() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_RATE_DONE, true);
        edit.commit();
    }

    public static void setLanguage(String str) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putString(PREF_LANGUAGE, str);
        edit.commit();
    }

    public static String getLanguageFiles() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String str = PREF_LANGUAGE;
        String str2 = "";
        if (!defaultSharedPreferences.getString(str, str2).equals("es")) {
            return str2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(defaultSharedPreferences.getString(str, str2));
        return stringBuilder.toString();
    }

    public static String getLanguage() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_LANGUAGE, "en");
    }

    public static boolean isLanguageFirstTime() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_LANGUAGE_FIRST_TIME, true);
    }

    public static void setLanguageFirstTime() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_LANGUAGE_FIRST_TIME, false);
        edit.commit();
    }

    public static Boolean isDarkMode() {
        return Boolean.valueOf(PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_DARK_MODE, false));
    }

    public static void setDarkMode(boolean z) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_DARK_MODE, z);
        edit.commit();
    }

    public static Boolean isAppUpdate() {
        return Boolean.valueOf(PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_APP_UPDATE, true));
    }

    public static void setAppUpdate(boolean z) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putBoolean(PREF_APP_UPDATE, z);
        edit.commit();
    }
}
