package game.kidspop.gk.quiz.info;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class mClassDBHelper {
  private Context ctx;
  private String mDBName;
  private String mDBName_Old;
  private String mDBPathSuffix;
  private int mDBVersion = 1;

  public mClassDBHelper(Context context) {
    String str = "";
    this.mDBName = str;
    this.mDBName_Old = str;
    this.mDBPathSuffix = "/databases/";
    this.ctx = context;
    this.mDBName = this.ctx.getString(R.string.dbName);
    this.mDBName_Old = this.ctx.getString(R.string.dbName_Old);
  }

  private String getDatabasePath() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.ctx.getApplicationInfo().dataDir);
    stringBuilder.append(this.mDBPathSuffix);
    stringBuilder.append(this.mDBName);
    return stringBuilder.toString();
  }

  public void CopyDBFile_FromAsset() throws IOException {
    InputStream open = this.ctx.getAssets().open(this.mDBName);
    String databasePath = getDatabasePath();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.ctx.getApplicationInfo().dataDir);
    stringBuilder.append(this.mDBPathSuffix);
    File file = new File(stringBuilder.toString());
    if (!file.exists()) {
      file.mkdir();
    }
    FileOutputStream fileOutputStream = new FileOutputStream(databasePath);
    byte[] bArr = new byte[1024];
    while (true) {
      int read = open.read(bArr);
      if (read > 0) {
        fileOutputStream.write(bArr, 0, read);
      } else {
        fileOutputStream.flush();
        fileOutputStream.close();
        open.close();
        return;
      }
    }
  }

  public void prcCreateDatabase() {
    File databasePath = this.ctx.getDatabasePath(this.mDBName);
    if (Integer.valueOf(Integer.parseInt(mClassUtil.getspv_DatabseVer(this.ctx))).intValue() != this.mDBVersion && databasePath.exists()) {
      File databasePath2 = this.ctx.getDatabasePath(this.mDBName_Old);
      if (databasePath2.exists()) {
        databasePath2.delete();
      }
      databasePath.renameTo(databasePath2);
      mClassUtil.setspv_DbUpdateQSeenFlag(this.ctx, "Y");
      databasePath.delete();
    }
    if (!databasePath.exists()) {
      try {
        CopyDBFile_FromAsset();
        mClassUtil.setspv_DatabseVer(this.ctx, Integer.toString(this.mDBVersion));
      } catch (IOException e) {
        throw new RuntimeException("Error DbH :", e);
      }
    }
  }
}