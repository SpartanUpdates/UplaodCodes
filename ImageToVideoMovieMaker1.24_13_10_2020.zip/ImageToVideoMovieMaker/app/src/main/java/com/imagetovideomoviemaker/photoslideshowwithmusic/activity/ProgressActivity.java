package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.xyz.imagetovideomoviewmaker.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.OnProgressReceiver;
import com.imagetovideomoviemaker.photoslideshowwithmusic.service.CreateVideoService;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.jpardogo.android.googleprogressbar.library.ChromeFloatingCirclesDrawable;

import java.util.ArrayList;
import java.util.List;


public class ProgressActivity extends AppCompatActivity implements OnProgressReceiver {
    Activity activity = ProgressActivity.this;
    private MyApplication application;
    final float[] from;
    final float[] hsv;
    boolean isComplate;
    float lastProg;
    final float[] to;
    private TextView tvProgress;
    LinearLayout lyWatchAds;
    ProgressBar mProgressBar;

    private NativeBannerAd nativeBannerAd;

    public ProgressActivity() {
        this.from = new float[3];
        this.to = new float[3];
        this.hsv = new float[3];
        this.lastProg = 0.0f;
        this.isComplate = true;
    }


    private void bindView() {
        this.tvProgress = this.findViewById(R.id.tvProgress);
//        ivAppIcon1 = (ImageView) findViewById(R.id.imgApp1);
//        ivAppIcon2 = (ImageView) findViewById(R.id.imgApp2);
//        ivAppIcon3 = (ImageView) findViewById(R.id.imgApp3);
//        ivAppIcon4 = (ImageView) findViewById(R.id.imgApp4);
//        Animation animation = AnimationUtils.loadAnimation((Context) this, R.anim.rotate_my);
//        ivAppIcon1.startAnimation(animation);
//        ivAppIcon2.startAnimation(animation);
//        ivAppIcon3.startAnimation(animation);
//        ivAppIcon4.startAnimation(animation);
        lyWatchAds = (findViewById(R.id.lyWatchAds));
        lyWatchAds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    interstitialAd.show();
//                } else {
//                    interstitialAd.loadAd();
                Toast.makeText(getApplicationContext(), "Loading Ad...", Toast.LENGTH_SHORT).show();
//                }
            }
        });
        mProgressBar = findViewById(R.id.google_progress);
        mProgressBar.setProgress(0);
        mProgressBar.setSecondaryProgress(100);
        mProgressBar.setMax(100);
        mProgressBar.setProgressDrawable(getResources().getDrawable(R.drawable.circular));
//        Rect bounds = mProgressBar.getIndeterminateDrawable().getBounds();
//        mProgressBar.setIndeterminateDrawable(getProgressDrawable());
//        mProgressBar.getIndeterminateDrawable().setBounds(bounds);
    }



    private Drawable getProgressDrawable() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        int value = Integer.parseInt(prefs.getString(getString(R.string.progressBar_pref_key), getString(R.string.progressBar_pref_defValue)));
        Drawable progressDrawable = null;
        progressDrawable = new ChromeFloatingCirclesDrawable.Builder(this)
                .colors(getProgressDrawableColors())
                .build();

        return progressDrawable;
    }

    private int[] getProgressDrawableColors() {
        int[] colors = new int[4];
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        colors[0] = prefs.getInt(getString(R.string.firstcolor_pref_key), getResources().getColor(R.color.red));
        colors[1] = prefs.getInt(getString(R.string.secondcolor_pref_key), getResources().getColor(R.color.blue));
        colors[2] = prefs.getInt(getString(R.string.thirdcolor_pref_key), getResources().getColor(R.color.yellow));
        colors[3] = prefs.getInt(getString(R.string.fourthcolor_pref_key), getResources().getColor(R.color.green));
        return colors;
    }


    public void openApp(View v) {
        try {
            startActivity(new Intent(
                    "android.intent.action.VIEW",
                    Uri.parse(v.getTag().toString())));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getApplicationContext(), "You don't have Google Play installed",
                    Toast.LENGTH_SHORT).show();
        }
    }


    private void changePercentageOnText(final float lastProg) {
        synchronized (this) {
            if (this.isComplate) {
                final ValueAnimator ofFloat = ValueAnimator.ofFloat(this.lastProg, lastProg);
                ofFloat.setDuration(300L);
                ofFloat.setInterpolator(new LinearInterpolator());
                ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                        ProgressActivity.this.hsv[0] = ProgressActivity.this.from[0] + (ProgressActivity.this.to[0] - ProgressActivity.this.from[0]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[1] = ProgressActivity.this.from[1] + (ProgressActivity.this.to[1] - ProgressActivity.this.from[1]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[2] = ProgressActivity.this.from[2] + (ProgressActivity.this.to[2] - ProgressActivity.this.from[2]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        mProgressBar.setProgress(Math.round(lastProg));
                        ProgressActivity.this.tvProgress.setText(String.format(" %05.2f%%", valueAnimator.getAnimatedValue()));
                    }
                });
                ofFloat.addListener(new Animator.AnimatorListener() {
                    public void onAnimationCancel(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationEnd(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationRepeat(final Animator animator) {
                    }

                    public void onAnimationStart(final Animator animator) {
                        ProgressActivity.this.isComplate = false;
                    }
                });
                ofFloat.start();
                this.lastProg = lastProg;
            }
        }
    }

    public void onBackPressed() {
    }

    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_progress);

        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ProgressActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        this.getWindow().addFlags(128);
        this.application = MyApplication.getInstance();
        this.bindView();
        LoadNativeAds();
        Utils.setFont(this, findViewById(R.id.tvMakingVideo));
        Utils.setFont(this, findViewById(R.id.tvStayHere));
        Utils.setFont(this, findViewById(R.id.tvOr));
    }

    private void LoadNativeAds() {
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
    }



    public void onImageProgressFrameUpdate(final float n) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 25.0f / 100.0f);
            }
        });
    }

    public void onOverlayingFinish(final String s) {
    }

    public void onProgressFinish(final String s) {
        Utils.isVideoCreationRunning = false;
        Utils.watchadCheck = true;
        final Intent intent = new Intent(this, Activity_VideoPlay.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("android.intent.extra.TEXT", s);
        intent.putExtra("KEY", "FromProgress");
        this.application.isFristTimeTheme = true;
        ActivityAnimUtil.startActivitySafely(this.tvProgress, intent);
        super.onBackPressed();
    }

    protected void onResume() {
        super.onResume();
        this.application.setOnProgressReceiver(this);
    }

    protected void onStop() {
        super.onStop();
        this.application.setOnProgressReceiver(null);
        if (MyApplication.isMyServiceRunning(this, CreateVideoService.class)) {
//            this.finish();
        }
    }

    public void onVideoProgressFrameUpdate(final float n) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 75.0f / 100.0f + 25.0f);
            }
        });
    }
}
