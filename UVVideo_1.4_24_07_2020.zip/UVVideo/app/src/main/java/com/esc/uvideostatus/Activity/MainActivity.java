package com.esc.uvideostatus.Activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.PopupMenu.OnMenuItemClickListener;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.airbnb.lottie.LottieAnimationView;
import com.esc.uvideostatus.Fragments.CatogoryFragment;
import com.esc.uvideostatus.kprogresshud.KProgressHUD;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.github.ybq.android.spinkit.SpriteFactory;
import com.github.ybq.android.spinkit.Style;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.android.material.tabs.TabLayout.Tab;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.esc.uvideostatus.Fragments.DownloadFragment;
import com.esc.uvideostatus.Fragments.HomeFragment;
import com.esc.uvideostatus.Fragments.TrendingFragment;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.FontTextView;
import com.esc.uvideostatus.Utility.Utility;
import com.esc.uvideostatus.Models.CustomCategoryItem;

import cz.msebera.android.httpclient.Header;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    public static EditText searchView;
    SimpleFragmentPagerAdapter adapter;
    public boolean isback = false;
    private LottieAnimationView lottieAnimationView;
    String main_url;
    private ImageView more;
    FontTextView no_internet;
    String response = "";
    Tab tab;
    public TabLayout tabLayout;
    VideoData videoData1;
    ViewPager viewPager;
    public static Intent intent;

    public class GenerateResponse extends AsyncHttpResponseHandler {
        public GenerateResponse() {
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            MainActivity.this.response = new String(bArr);
        }

        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
            StringBuilder sb = new StringBuilder();
            sb.append(i);
            sb.append(" <<====");
            Log.e("onFailure: ", sb.toString());
        }
    }

    public class SimpleFragmentPagerAdapter extends FragmentStatePagerAdapter {
        public final int PAGE_COUNT = 3;
        private Context mContext;

        public void addFragment(Fragment fragment, String str) {
        }

        public int getCount() {
            return 3;
        }

        public SimpleFragmentPagerAdapter(Context context, FragmentManager fragmentManager) {
            super(fragmentManager);
            this.mContext = context;
        }

        public View getTabView(int i) {
            return LayoutInflater.from(MainActivity.this).inflate(R.layout.custom_tab, null);
        }

        public Fragment getItem(int i) {
            StringBuilder sb = new StringBuilder();
            sb.append("getItem11: ");
            sb.append(i);
            Log.d("TAG", sb.toString());
            Bundle bundle = new Bundle();
            if (i == 0) {
                HomeFragment homeFragment = new HomeFragment();
                homeFragment.setArguments(bundle);
                return homeFragment;
            } else if (i == 1) {
                TrendingFragment trendingFragment = new TrendingFragment();
                trendingFragment.setArguments(bundle);
                return trendingFragment;
            } else if (i != 2) {
                return null;
            } else {
                return new DownloadFragment();
            }
        }
    }

    public class dataResponseHandler extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataResponseHandler() {
        }

        public void onStart() {
            SpriteFactory.create(Style.values()[7]);
            StringBuilder sb = new StringBuilder();
            sb.append("onSuccess: ");
            sb.append(MainActivity.this.main_url);
            Log.d("TAG", sb.toString());
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = TtmlNode.ATTR_ID;
            String str2 = "name";
            String str3 = new String(bArr);
            StringBuilder sb = new StringBuilder();
            sb.append("getcatogoryvideo:catmain ");
            sb.append(str3);
            Log.e("ContentValues", sb.toString());

            try {
                JSONArray jSONArray = new JSONArray(str3);
                Utility.CATEGORYLIST = new ArrayList<>();
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i2);
                    Utility.CATEGORYLIST.add(new CustomCategoryItem(jSONObject.getString(str2), jSONObject.getString(str)));
                    PrintStream printStream = System.out;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("===");
                    sb2.append(jSONObject.getString(str2));
                    sb2.append("=======");
                    sb2.append(jSONObject.getString(str));
                    printStream.println(sb2.toString());
                }
                adapter = new SimpleFragmentPagerAdapter(MainActivity.this, getSupportFragmentManager());
                viewPager.setAdapter(adapter);
                viewPager.setOffscreenPageLimit(4);
                tabLayout = MainActivity.this.findViewById(R.id.tabs);
                tabLayout.setupWithViewPager(viewPager);
                setupTabIcons1();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean isNetworkStatusAvialable(Context context) {
        @SuppressLint("WrongConstant") ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        intializeAdData();
        if (isStoragePermissionGranted()) {
            initview();
        }
        LoadAds();
    }

    @SuppressLint("WrongConstant")
    private void initview() {
        this.more = findViewById(R.id.more);
        this.lottieAnimationView = findViewById(R.id.lottieAnimationView);
        this.no_internet = findViewById(R.id.no_internet);
        this.viewPager = findViewById(R.id.viewpager);
        this.videoData1 = new VideoData();
        if (isNetworkStatusAvialable(this)) {
            getDatasearch();
        } else {
            this.no_internet.setVisibility(0);
        }
        this.lottieAnimationView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                id = 100;
                if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(MainActivity.this, MoreActivity.class));
                }
            }
        });
        searchView = findViewById(R.id.serachview);
        ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(searchView.getWindowToken(), 0);
        searchView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                intent.putExtra("url", MainActivity.this.videoData1.getMain_url());
                intent.putExtra("vurl", MainActivity.this.videoData1.getvUrl());
                MainActivity.this.startActivity(intent);
            }
        });
        this.more.setOnClickListener(this);
    }

    public void setupTabIcons1() {
        final TextView textview1 = (TextView) LayoutInflater.from(this).inflate(R.layout.tab_layout, null);
        textview1.setText("Home");
        textview1.setCompoundDrawablePadding(5);
        textview1.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_home2, 0, 0);
        this.tabLayout.getTabAt(0).setCustomView(textview1);

        final TextView textview2 = (TextView) LayoutInflater.from(this).inflate(R.layout.tab_layout, null);
        textview2.setText("Trending");
        textview2.setCompoundDrawablePadding(5);
        textview2.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_trend1, 0, 0);
        this.tabLayout.getTabAt(1).setCustomView(textview2);

        final TextView textview4 = (TextView) LayoutInflater.from(this).inflate(R.layout.tab_layout, null);
        textview4.setText("Downloads");
        textview4.setCompoundDrawablePadding(5);
        textview4.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_dow1, 0, 0);
        this.tabLayout.getTabAt(2).setCustomView(textview4);

        this.tabLayout.setTabTextColors(Color.parseColor("#727272"), Color.parseColor("#000000"));
        this.tabLayout.setOnTabSelectedListener(new OnTabSelectedListener() {
            private int mActivePointerId;

            public void onTabReselected(Tab tab) {
            }

            public void onTabSelected(Tab tab) {
                MainActivity.this.viewPager.setCurrentItem(tab.getPosition());
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onTabSelected: ");
                stringBuilder.append(MainActivity.this.tabLayout.getTabAt(2));
                Log.d("TAG", stringBuilder.toString());
                if (tab.getPosition() == 0) {
                    MainActivity.this.tabLayout.setSelectedTabIndicatorColor(MainActivity.this.getResources().getColor(R.color.tab));
                    textview1.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_home2, 0, 0);
                    textview1.setTextColor(MainActivity.this.getResources().getColor(R.color.tab));
                }
                if (tab.getPosition() == 1) {
                    MainActivity.this.tabLayout.setSelectedTabIndicatorColor(MainActivity.this.getResources().getColor(R.color.tab));
                    if (VERSION.SDK_INT >= 21) {
                        textview2.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_trend2, 0, 0);
                        textview2.setTextColor(MainActivity.this.getResources().getColor(R.color.tab));
                    }
                }

                if (tab.getPosition() == 2) {
                    MainActivity.this.tabLayout.setSelectedTabIndicatorColor(MainActivity.this.getResources().getColor(R.color.tab));
                    if (VERSION.SDK_INT >= 21) {
                        textview4.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_dow2, 0, 0);
                        textview4.setTextColor(MainActivity.this.getResources().getColor(R.color.tab));
                    }
                }
            }

            public void onTabUnselected(Tab tab) {
                if (tab.getPosition() == 0) {
                    textview1.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_home1, 0, 0);
                    textview1.setTextColor(MainActivity.this.getResources().getColor(R.color.txt_color));
                }
                if (tab.getPosition() == 1) {
                    if (VERSION.SDK_INT >= 21) {
                        textview2.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_trend1, 0, 0);
                        textview2.setTextColor(MainActivity.this.getResources().getColor(R.color.txt_color));
                    }
                }

                if (tab.getPosition() == 2) {
                    if (VERSION.SDK_INT >= 21) {
                        textview4.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_dow1, 0, 0);
                        textview4.setTextColor(MainActivity.this.getResources().getColor(R.color.txt_color));
                    }
                }
            }
        });
    }

    public void getDatasearch() {
        RequestParams requestParams = new RequestParams();
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append("getDatasearch: ");
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Utility.baseUrl);
        sb2.append("collections/tbl_category?apiKey=");
        sb2.append(Utility.apiKey);
        sb.append(asyncHttpClient.get(sb2.toString(), requestParams, new dataResponseHandler()));
        Log.d("TAG", sb.toString());
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_, menu);
        return true;
    }

    public void onClick(View view) {
        if (view.getId() == R.id.more) {
            PopupMenu popupMenu = new PopupMenu(this, this.more);
            getMenuInflater().inflate(R.menu.menu_, popupMenu.getMenu());
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem menuItem) {
                    int itemId = menuItem.getItemId();
                    if (itemId != R.id.download) {
                        if (itemId == R.id.rate) {
                            MainActivity mainActivity = MainActivity.this;
                            mainActivity.isback = false;
                            try {
                                startActivity(new Intent(
                                        "android.intent.action.VIEW",
                                        Uri.parse(getResources().getString(R.string.rate_us_url)
                                                + getPackageName())));
                            } catch (ActivityNotFoundException e) {
                                Toast.makeText(MainActivity.this, "You don't have Google Play installed",
                                        Toast.LENGTH_SHORT).show();
                            }
                        } else if (itemId == R.id.share) {
                            Intent share = new Intent("android.intent.action.SEND");
                            share.setType("text/plain");
                            share.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.share_msg) + getPackageName());
                            startActivity(Intent.createChooser(share, "Share Via"));
                        }
                    } else if (MainActivity.this.tabLayout != null) {
                        MainActivity mainActivity2 = MainActivity.this;
                        mainActivity2.tab = mainActivity2.tabLayout.getTabAt(2);
                        MainActivity.this.tab.select();
                    } else {
                        Toast.makeText(MainActivity.this, "Wait to connect", Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
            });
            popupMenu.show();
        }
    }

    private void Get_CameraAndStorage_Permission() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (!addPermission(arrayList2, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            arrayList.add("Read Storage");
        }
        if (arrayList2.size() > 0) {
            if (arrayList.size() > 0) {
                for (int i = 0; i < 1; i++) {
                    if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 1);
                    }
                }
                return;
            }
            if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 1);
            }
        }
    }

    @SuppressLint("WrongConstant")
    private boolean addPermission(List<String> list, String str) {
        if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(str) != 0) {
                list.add(str);
                return shouldShowRequestPermissionRationale(str);
            }
        }
        return true;
    }

    public boolean isStoragePermissionGranted() {
        if (VERSION.SDK_INT < 23 || ActivityCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        Get_CameraAndStorage_Permission();
        return false;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr[0] == 0) {
            initview();
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(MainActivity.this, HomeActivity.class));
        finish();
    }

    public void intializeAdData() {
        int nextInt = new Random().nextInt(2);
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        if (nextInt == 1) {
            asyncHttpClient.get("https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=892bdb8d0e6519769124a90c84643290&photoset_id=72157673029373387&extras=description%2C+url_m%2C+url_o%2C+url_l&per_page=20&page=1&format=json&nojsoncallback=1", new GenerateResponse());
        } else if (nextInt == 2) {
            asyncHttpClient.get("https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=892bdb8d0e6519769124a90c84643290&photoset_id=72157702999028884&extras=description%2C+url_m%2C+url_o%2C+url_l&per_page=20&page=1&format=json&nojsoncallback=1", new GenerateResponse());
        } else {
            asyncHttpClient.get("https://api.flickr.com/services/rest/?method=flickr.photosets.getPhotos&api_key=892bdb8d0e6519769124a90c84643290&photoset_id=72157701606138301&extras=description%2C+url_m%2C+url_o%2C+url_l&per_page=20&page=1&format=json&nojsoncallback=1", new GenerateResponse());
        }
    }

    public static InterstitialAd fbinterstitialAd;
    private KProgressHUD hud;
    public static int id;

    public void LoadAds() {

        //FaceBookInterstitialAd
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                Log.e("TAG", "Interstitial ad displayed.");
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed to MainActivity");
                switch (id) {
                    case 100:
                        startActivity(new Intent(MainActivity.this, MoreActivity.class));
                        break;

                    case 101:
                        startActivity(intent);
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG", "Interstitial ad failed to load: " + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("TAG", "Interstitial ad is load MainActivity");
            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.e("TAG", "Interstitial ad clicked!");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.e("TAG", "Interstitial ad impression logged!");
            }
        });
        fbinterstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.loadAd();
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(MainActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                fbinterstitialAd.show();
            }
        }, 1000);
    }
}
