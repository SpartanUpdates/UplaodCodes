package com.esc.fontappstylish.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.fontappstylish.kprogresshud.KProgressHUD;
import com.esc.fontappstylish.utils.FontSet;
import com.esc.fontappstylish.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class FontKeyboardTestingActivity extends AppCompatActivity {
    public static Activity activity;
    private Context context;
    private ImageView iv_back;
    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_fonttesting);
        context = this;
        EditText editText = findViewById(R.id.editText);
        showSoftKeyboard(editText);
        loadAd();

        if (!(FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(this) && FontSet.INSTANCE.isThisKeyboardEnabled(this))) {
            Intent intent = new Intent(this, FirstActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                if (interstitialAd !=null && interstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(FontKeyboardTestingActivity.this, FirstActivity.class));
                    finish();
                }
            }
        });
    }

    private void loadAd()
    {
        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(FontKeyboardTestingActivity.this, FirstActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(activity);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void showSoftKeyboard(View view) {
        if (view.requestFocus()) {
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(view, 1);
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(FontKeyboardTestingActivity.this, FirstActivity.class));
        finish();
    }
}
