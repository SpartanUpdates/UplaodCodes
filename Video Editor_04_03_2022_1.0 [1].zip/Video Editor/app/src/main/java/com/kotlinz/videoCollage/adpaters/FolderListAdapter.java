package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class FolderListAdapter extends Adapter<FolderListAdapter.ViewHolder> {
    private Context context;
    private ArrayList<String> dataList;
    private int pos = 0;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        LinearLayout linMain;
        LinearLayout linSelector;
        TextView txtName;

        ViewHolder(View view) {
            super(view);
            this.txtName = (TextView) view.findViewById(R.id.txt_name);
            this.linMain = (LinearLayout) view.findViewById(R.id.line_name);
            this.linSelector = (LinearLayout) view.findViewById(R.id.lin_selector);
        }
    }

    public FolderListAdapter(ArrayList<String> arrayList, Context context) {
        this.dataList = arrayList;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_folder_item_layout, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = (String) this.dataList.get(i);
        viewHolder.txtName.setText(str);
        if (str.equalsIgnoreCase(this.context.getResources().getString(R.string.app_name))) {
            this.pos = i;
        }
        viewHolder.linMain.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                FolderListAdapter.this.pos = i;
                FolderListAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.linSelector.setVisibility(View.VISIBLE);
        } else {
            viewHolder.linSelector.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        return this.dataList.size();
    }
}
