package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class QuoteDownload implements View.OnClickListener {
    public final  FrameLayout frameLayout;
    public final  QuoteMakerDetailActivity activity;

    public QuoteDownload(QuoteMakerDetailActivity quoteMakerDetailActivity, FrameLayout frameLayout) {
        this.activity = quoteMakerDetailActivity;
        this.frameLayout = frameLayout;
    }

    public void onClick(View view) {
        activity.flStickerView = this.frameLayout;
        for (int i = 0; i < this.activity.flStickerView.getChildCount(); i++) {
            if (activity.flStickerView.getChildAt(i) instanceof ImageStickerViewNew) {
                ((ImageStickerViewNew) this.activity.flStickerView.getChildAt(i)).setInEdit(false);
            }
        }
        ImageStickerViewNew imageStickerViewNew = this.activity.imageStickerViewNew;
        if (imageStickerViewNew != null) {
            imageStickerViewNew.setInEdit(false);
        }
        TextStickerViewNew1 textStickerViewNew1 = this.activity.stickerViewNew1;
        if (textStickerViewNew1 != null) {
            textStickerViewNew1.setInEdit(false);
        }
        activity.new d(false).execute();
    }
}
