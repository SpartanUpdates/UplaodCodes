package com.esc.dailyrandomfacts.model;

public class ViewMode {
    private String mode;
}
