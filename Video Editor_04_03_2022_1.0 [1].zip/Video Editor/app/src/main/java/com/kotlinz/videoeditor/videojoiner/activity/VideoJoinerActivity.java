package com.kotlinz.videoeditor.videojoiner.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.ParseException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Statistics;
import com.arthenica.mobileffmpeg.StatisticsCallback;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.videojoiner.model.VideoPlayerState;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;


@SuppressLint({"WrongConstant"})
public class VideoJoinerActivity extends AppCompatActivity implements OnClickListener {

    Activity activity = VideoJoinerActivity.this;
    static final boolean r = true;
    int a = 0;
    int b = 0;
    Handler c = new Handler();
    String d;
    ImageView e;
    ImageView f;
    TextView g;
    TextView h;
    TextView i;
    TextView j;
    VideoSliceSeekBar k;
    VideoSliceSeekBar l;
    int m = 0;
    int n = 0;
    VideoView o;
    VideoView p;
    ImageView iv_back;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    int status = 0;
    Handler handler = new Handler();

    Runnable q = new Runnable() {
        public void run() {
            VideoJoinerActivity.this.c();
        }
    };

    public VideoPlayerState s = new VideoPlayerState();

    public VideoPlayerState t = new VideoPlayerState();
    private final a u = new a();
    private final b v = new b();

    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            this.b = false;
            this.c = new Runnable() {
                public void run() {
                    VideoJoinerActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.b) {
                this.b = VideoJoinerActivity.r;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            k.videoPlayingProgress(o.getCurrentPosition());
            if (!o.isPlaying() || o.getCurrentPosition() >= k.getRightProgress()) {
                if (o.isPlaying()) {
                    o.pause();
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                k.setSliceBlocked(false);
                k.removeVideoStatusThumb();
                return;
            }
            postDelayed(c, 50);
        }
    }

    private class b extends Handler {
        private boolean b;
        private final Runnable c;

        private b() {
            this.b = false;
            this.c = new Runnable() {
                public void run() {
                    VideoJoinerActivity.b.this.a();
                }
            };
        }

        public void a() {
            if (!b) {
                b = r;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            l.videoPlayingProgress(p.getCurrentPosition());
            if (!p.isPlaying() || p.getCurrentPosition() >= l.getRightProgress()) {
                if (p.isPlaying()) {
                    p.pause();
                    f.setBackgroundResource(R.drawable.ic_play_upress);
                }
                l.setSliceBlocked(false);
                l.removeVideoStatusThumb();
                return;
            }
            postDelayed(c, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videojoineractivity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText("Video Joiner");
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        MyApplication.getInstance().KeepScreenOn(activity);
        PutAnalyticsEvent();
        BannerAds();
        if (r || supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(r);
            supportActionBar.setDisplayShowTitleEnabled(false);
            i();
            o.setVideoPath(MyApplication.getInstance().getSelectedVideo().get(0).getImagePath());
            p.setVideoPath(MyApplication.getInstance().getSelectedVideo().get(1).getImagePath());
            o.seekTo(100);
            p.seekTo(100);
            d();
            f();
            o.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
            });
            p.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    f.setBackgroundResource(R.drawable.ic_play_upress);
                }
            });
            return;
        }
        throw new AssertionError();
    }


    //Firebase AnalyticsEvent
    @SuppressLint("MissingPermission")
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoJoinerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(activity, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(activity);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @SuppressLint("MissingPermission")
    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void c() {
        Intent intent = new Intent(activity, AddAudioActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("song", this.d);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public static String formatTimeUnit(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    private void d() {
        this.o.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                VideoJoinerActivity.this.k.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (VideoJoinerActivity.this.k.getSelectedThumb() == 1) {
                            VideoJoinerActivity.this.o.seekTo(VideoJoinerActivity.this.k.getLeftProgress());
                        }
                        VideoJoinerActivity.this.i.setText(VideoJoinerActivity.formatTimeUnit(i));
                        VideoJoinerActivity.this.g.setText(VideoJoinerActivity.formatTimeUnit(i2));
                        VideoJoinerActivity.this.s.setStart(i);
                        VideoJoinerActivity.this.s.setStop(i2);
                        VideoJoinerActivity.this.m = i / 1000;
                        VideoJoinerActivity.this.a = i2 / 1000;
                        mediaPlayer.setLooping(true);
                    }
                });
                VideoJoinerActivity.this.k.setMaxValue(mediaPlayer.getDuration());
                VideoJoinerActivity.this.k.setLeftProgress(0);
                VideoJoinerActivity.this.k.setRightProgress(mediaPlayer.getDuration());
                VideoJoinerActivity.this.k.setProgressMinDiff(0);
            }
        });
    }

    private void e() {
        if (this.p.isPlaying()) {
            this.p.pause();
            this.f.setBackgroundResource(R.drawable.ic_play_upress);
        }
        if (this.o.isPlaying()) {
            this.o.pause();
            this.k.setSliceBlocked(false);
            this.e.setBackgroundResource(R.drawable.ic_play_upress);
            this.k.removeVideoStatusThumb();
            return;
        }
        this.o.seekTo(this.k.getLeftProgress());
        this.o.start();
        this.k.videoPlayingProgress(this.k.getLeftProgress());
        this.e.setBackgroundResource(R.drawable.ic_pause_unpresss);
        this.u.a();
    }

    private void f() {
        this.p.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                l.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (l.getSelectedThumb() == 1) {
                            p.seekTo(VideoJoinerActivity.this.l.getLeftProgress());
                        }
                        j.setText(formatTimeUnit(i));
                        h.setText(formatTimeUnit(i2));
                        t.setStart(i);
                        t.setStop(i2);
                        n = i / 1000;
                        b = i2 / 1000;
                    }
                });
                l.setMaxValue(mediaPlayer.getDuration());
                l.setLeftProgress(0);
                l.setRightProgress(mediaPlayer.getDuration());
                l.setProgressMinDiff(0);
            }
        });
    }

    private void g() {
        if (o.isPlaying()) {
            o.pause();
            e.setBackgroundResource(R.drawable.ic_play_upress);
        }
        if (p.isPlaying()) {
            p.pause();
            l.setSliceBlocked(false);
            f.setBackgroundResource(R.drawable.ic_play_upress);
            l.removeVideoStatusThumb();
            return;
        }
        p.seekTo(l.getLeftProgress());
        p.start();
        l.videoPlayingProgress(this.l.getLeftProgress());
        f.setBackgroundResource(R.drawable.ic_pause_unpresss);
        v.a();
    }

    @Override
    public void onClick(View view) {
        if (view == this.e) {
            e();
        }
        if (view == this.f) {
            g();
        }
    }

    private void h() {
        String format = new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.VideoJoiner));
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.VideoJoiner));
        sb2.append("/videojoiner");
        sb2.append(format);
        sb2.append(".mp4");
        this.d = sb2.toString();

        a(new String[]{"-y", "-ss", String.valueOf(this.m), "-t", String.valueOf(this.a), "-i", MyApplication.getInstance().getSelectedVideo().get(0).getImagePath(), "-ss", String.valueOf(this.n), "-t", String.valueOf(this.b), "-i", MyApplication.getInstance().getSelectedVideo().get(1).getImagePath(), "-strict", "experimental", "-filter_complex", "[0:v]scale=720x1280,setsar=1:1[v0];[1:v]scale=720x1280,setsar=1:1[v1];[v0][v1] concat=n=2:v=1", "-ab", "48000", "-ac", "2", "-ar", "22050", "-s", "720x1280", "-r", "15", "-b", "2097k", "-vcodec", "mpeg4", this.d}, this.d);


    }

    int progressStatus = 0;
    int completePercentage;

    private void a(String[] strArr, final String str) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);
        dialog.setCancelable(false);
        Uri pathhh = Uri.parse(MyApplication.getInstance().getSelectedVideo().get(0).getImagePath());
        Uri pathhhnew = Uri.parse(MyApplication.getInstance().getSelectedVideo().get(1).getImagePath());
        MediaPlayer mp = MediaPlayer.create(this, pathhh);
        MediaPlayer mediaPlayer = MediaPlayer.create(this, pathhhnew);

        int duration = mp.getDuration();
        int durationnew = mediaPlayer.getDuration();

        int toatalduration = duration + durationnew;

        final TextView text2 = dialog.findViewById(R.id.value123);
        dialog.show();

        String ffmpegCommand = UtilCommand.main(strArr);

        Config.enableStatisticsCallback(new StatisticsCallback() {
            @Override
            public void apply(Statistics newStatistics) {

                if (newStatistics == null) {
                    return;
                }
                int timeInMilliseconds = newStatistics.getTime();
                if (timeInMilliseconds > 0) {
                    float totalVideoDuration = toatalduration;
                    completePercentage = Integer.parseInt(new BigDecimal(timeInMilliseconds).multiply(new BigDecimal(100)).divide(new BigDecimal(totalVideoDuration), 0, BigDecimal.ROUND_HALF_UP).toString());
                }
                new Thread(new Runnable() {
                    public void run() {
                        while (progressStatus < completePercentage) {
                            progressStatus += 1;
                            handler.post(new Runnable() {
                                public void run() {
                                    text2.setText(String.valueOf(progressStatus));
                                }
                            });
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
        });

        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                Config.printLastCommandOutput(Log.INFO);
                if (returnCode == RETURN_CODE_SUCCESS) {
                    dialog.dismiss();
                    Toast.makeText(getApplicationContext(), "Video Merge Success", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(VideoJoinerActivity.this.d)));
                    VideoJoinerActivity.this.sendBroadcast(intent);
                    try {
                        MediaScannerConnection.scanFile(VideoJoinerActivity.this, new String[]{VideoJoinerActivity.this.d}, null, new OnScanCompletedListener() {
                            public void onScanCompleted(String str, Uri uri) {
                                c.postDelayed(VideoJoinerActivity.this.q, 100);

                            }
                        });
                    } catch (Exception unused) {
                        c.postDelayed(VideoJoinerActivity.this.q, 100);
                    }

                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(VideoJoinerActivity.this, "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {

                    try {
                        new File(str).delete();
                        VideoJoinerActivity.this.deleteFromGallery(str);
                        Toast.makeText(VideoJoinerActivity.this, "Error Creating Video", 0).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
                refreshGallery(str);
            }
        });
        getWindow().clearFlags(16);
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    private void i() {
        e = findViewById(R.id.buttonply1);
        f = findViewById(R.id.buttonply2);
        k = findViewById(R.id.seek_bar1);
        l = findViewById(R.id.seek_bar2);
        i = findViewById(R.id.left_pointer1);
        j = findViewById(R.id.left_pointer2);
        g = findViewById(R.id.right_pointer1);
        h = findViewById(R.id.right_pointer2);
        o = findViewById(R.id.videoView1);
        p = findViewById(R.id.videoView2);
        e.setOnClickListener(this);
        f.setOnClickListener(this);
    }

    @SuppressLint("ResourceType")
    public void k() {
        new AlertDialog.Builder(activity).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                VideoJoinerActivity.this.finish();
            }
        }).create().show();
    }


    public void onPause() {
        super.onPause();
        if (this.o.isPlaying()) {
            this.o.pause();
            this.e.setBackgroundResource(R.drawable.ic_play_upress);
        } else if (this.p.isPlaying()) {
            this.p.pause();
            this.f.setBackgroundResource(R.drawable.ic_play_upress);
        }
    }

    private void ExitConfirmation() {
        new AlertDialog.Builder(this).setMessage("All changes will be discarded.").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                MyApplication.getInstance().selectedVideo.clear();
                Intent intent = new Intent(activity, StartActivity.class);
                startActivity(intent);
                finish();
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    public void onBackPressed() {
        ExitConfirmation();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_picker, menu);
        return r;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return r;
        }
        if (menuItem.getItemId() == R.id.Done) {
            if (o.isPlaying()) {
                o.pause();
                e.setBackgroundResource(R.drawable.ic_play_upress);
            } else if (p.isPlaying()) {
                p.pause();
                f.setBackgroundResource(R.drawable.ic_play_upress);
            }
            h();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status = 0;
    }
}
