package com.example.postermaker.editorsclasses.designitems;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import com.example.postermaker.R;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.utilities.eaz_GradientDrawable;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_BackgroundBorder implements OnClickListener, OnProgressChangeListener {
    int[] allcolors;
    Context context;
    Bitmap mbitmap;

    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public eaz_BackgroundBorder(Context context) {
        this.context = context;
    }

    public void loadBorderItems() {
        this.allcolors = this.context.getResources().getIntArray(R.array.allcolors);
        eaz_EditActivity.backgroundborderlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.okborder.setOnClickListener(this);
        eaz_EditActivity.cancelBorder.setOnClickListener(this);
        eaz_EditActivity.borderradious.setOnProgressChangeListener(this);
        eaz_EditActivity.bordersize.setOnProgressChangeListener(this);
        eaz_EditActivity.borderwidth.setOnProgressChangeListener(this);
        if (eaz_ConstantValues.bgchoice == 1) {
            eaz_EditActivity.backgroundimage.buildDrawingCache();
            this.mbitmap = eaz_EditActivity.backgroundimage.getDrawingCache();
        } else if (eaz_ConstantValues.bgchoice == 2) {
            eaz_EditActivity.forgroundimage.buildDrawingCache();
            this.mbitmap = eaz_EditActivity.forgroundimage.getDrawingCache();
        }
        loadColors();
    }

    public void loadColors() {
        eaz_EditActivity.bordercolorlayout.removeAllViews();
        for (int i = 0; i < this.allcolors.length; i++) {
            ImageView imageView = new ImageView(this.context);
            circularImageView(imageView, this.allcolors[i]);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_ConstantValues.bordercolor = eaz_BackgroundBorder.this.allcolors[finalI];
                    new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
                }
            });
            eaz_EditActivity.bordercolorlayout.addView(imageView);
        }
    }

    public void circularImageView(ImageView imageView, int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.OVAL);
        gradientDrawable.setColor(i);
        imageView.setBackground(gradientDrawable);

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                ViewGroup.MarginLayoutParams.MATCH_PARENT,
                ViewGroup.MarginLayoutParams.WRAP_CONTENT
        );
        marginLayoutParams.setMargins(5, 5, 5, 5);
         imageView.setPadding(40, 40, 40, 40);
        imageView.setLayoutParams(marginLayoutParams);

        //imageView.setLayoutParams(new LayoutParams(45, 45));
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.okborder)) {
            eaz_EditActivity.backgroundborderlayout.setVisibility(View.GONE);
        } else if (view.equals(eaz_EditActivity.cancelBorder)) {
            new eaz_GradientDrawable().manageShape(0, 0, 0, 0, 0);
            eaz_EditActivity.backgroundborderlayout.setVisibility(View.GONE);
        }
    }

    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z)
    {
        if (discreteSeekBar.equals(eaz_EditActivity.bordersize))
        {
            eaz_ConstantValues.bordersize = i;
            new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
        } else if (discreteSeekBar.equals(eaz_EditActivity.borderwidth)) {
            eaz_ConstantValues.borderspace = i;
            new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
        } else if (discreteSeekBar.equals(eaz_EditActivity.borderradious)) {
            eaz_ConstantValues.radious = i;
            new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
            if (eaz_ConstantValues.bgchoice == 1) {
                roundImageView(eaz_EditActivity.backgroundimage, i);
                eaz_EditActivity.backgroundimage.invalidate();
            } else if (eaz_ConstantValues.bgchoice == 2) {
                roundImageView(eaz_EditActivity.forgroundimage, i);
                eaz_EditActivity.forgroundimage.invalidate();
            }
        }
    }

    public void roundImageView(ImageView imageView, int i) {
        Bitmap createBitmap = Bitmap.createBitmap(this.mbitmap.getWidth(), this.mbitmap.getHeight(), this.mbitmap.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(new BitmapShader(this.mbitmap, TileMode.CLAMP, TileMode.CLAMP));
        float f = (float) i;
        canvas.drawRoundRect(new RectF(0.0f, 0.0f, (float) this.mbitmap.getWidth(), (float) this.mbitmap.getHeight()), f, f, paint);
        imageView.setImageBitmap(createBitmap);
    }
}
