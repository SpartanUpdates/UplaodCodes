package com.esc.motivationquotes.usecases;

public interface Usecase {
    void execute();
}
