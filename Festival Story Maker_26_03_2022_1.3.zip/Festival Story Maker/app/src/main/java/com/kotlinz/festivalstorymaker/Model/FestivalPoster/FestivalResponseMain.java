package com.kotlinz.festivalstorymaker.Model.FestivalPoster;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.SerializedName;

public class FestivalResponseMain {

	@SerializedName("data")
	private ArrayList<FestivalDataItem> data;

	@SerializedName("status")
	private String status;

	public void setData(ArrayList<FestivalDataItem> data){
		this.data = data;
	}

	public ArrayList<FestivalDataItem> getData(){
		return data;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}
}