package com.wavymusic.SongSelection.videolib.libffmpeg.utils;

import java.io.InputStream;

public class StubInputStream extends InputStream {
    private boolean closed;

    public StubInputStream() {
        closed = false;
    }

    public int read() throws java.io.IOException {
        return 0;
    }

    public void close() throws java.io.IOException {
        super.close();
        closed = true;
    }

    public boolean isClosed() {
        return closed;
    }
}
