package com.xyz.vehiclemanager.vehicledetails.vehiclemileage.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import androidx.annotation.Nullable;

import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;

public class MileageDbHelper extends SQLiteOpenHelper {
    SQLiteDatabase database;
    public MileageDbHelper(@Nullable Context context) {
        super(context, "Mileage.db", null, 1);
        this.database = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE mileage (id INTEGER PRIMARY KEY autoincrement, lreserve INTEGER, creserve INTEGER, price INTEGER, fuel INTEGER, date TEXT, km TEXT, IntLtr TEXT, inr TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists mileage");
    }

    private Mileage setmileage(final Cursor cursor) {
        final Mileage mileage = new Mileage();
        mileage.setId((int) cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        mileage.setLastReserve(cursor.getString(cursor.getColumnIndexOrThrow("lreserve")));
        mileage.setCurrentReserve(cursor.getString(cursor.getColumnIndexOrThrow("creserve")));
        mileage.setPrice(cursor.getString(cursor.getColumnIndexOrThrow("price")));
        mileage.setFuel(cursor.getString(cursor.getColumnIndexOrThrow("fuel")));
        mileage.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
        mileage.setMileageKm(cursor.getString(cursor.getColumnIndexOrThrow("km")));
        mileage.setMileageInrLtr(cursor.getString(cursor.getColumnIndexOrThrow("IntLtr")));
        mileage.setMileageInrKm(cursor.getString(cursor.getColumnIndexOrThrow("inr")));
        return mileage;
    }

    public long insrtMileage(final Mileage mileage) {
        final ContentValues contentValues = new ContentValues();
        contentValues.put("lreserve", mileage.getLastReserve());
        contentValues.put("creserve", mileage.getCurrentReserve());
        contentValues.put("price", mileage.getPrice());
        contentValues.put("fuel", mileage.getFuel());
        contentValues.put("date", mileage.getDate());
        contentValues.put("km", mileage.getMileageKm());
        contentValues.put("IntLtr", mileage.getMileageInrLtr());
        contentValues.put("inr", mileage.getMileageInrKm());
        return this.database.insert("mileage", null, contentValues);
    }

    public ArrayList<Mileage> listmileage() {
        final Cursor query = this.database.query("mileage", new String[]{"id", "lreserve", "creserve", "price", "fuel", "date", "km", "IntLtr", "inr"}, null, null, "date", null, null);
        final ArrayList<Mileage> list = new ArrayList<Mileage>();
        if (query.moveToFirst()) {
            do {
                list.add(this.setmileage(query));
            } while (query.moveToNext());
        }
        return list;
    }

    public int dltmileage(final int n) {
        return this.database.delete("mileage", "Id = ?", new String[] { String.valueOf(n) });
    }
}
