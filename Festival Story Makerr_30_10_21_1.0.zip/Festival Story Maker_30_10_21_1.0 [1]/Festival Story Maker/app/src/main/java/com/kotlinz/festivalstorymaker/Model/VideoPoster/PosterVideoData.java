package com.kotlinz.festivalstorymaker.Model.VideoPoster;

import com.google.gson.annotations.SerializedName;

public class PosterVideoData {

	@SerializedName("frame_name")
	private String frameName;

	@SerializedName("image")
	private String image;

	@SerializedName("mask_image")
	private String maskImage;

	@SerializedName("is_image_count")
	private String isImageCount;

	@SerializedName("thumb")
	private String thumb;

	@SerializedName("content_id")
	private String contentId;

	@SerializedName("type_id")
	private String typeId;

	@SerializedName("subcategory_id")
	private String subcategoryId;

	@SerializedName("maincategory_id")
	private String maincategoryId;

	@SerializedName("design_id")
	private String designId;

	@SerializedName("is_free")
	private String isFree;

	@SerializedName("is_mask")
	private String isMask;

	@SerializedName("id")
	private String id;

	public String getFrameName(){
		return frameName;
	}

	public String getImage(){
		return image;
	}

	public String getMaskImage(){
		return maskImage;
	}

	public String getIsImageCount(){
		return isImageCount;
	}

	public String getThumb(){
		return thumb;
	}

	public String getContentId(){
		return contentId;
	}

	public String getTypeId(){
		return typeId;
	}

	public String getSubcategoryId(){
		return subcategoryId;
	}

	public String getMaincategoryId(){
		return maincategoryId;
	}

	public String getDesignId(){
		return designId;
	}

	public String getIsFree(){
		return isFree;
	}

	public String getIsMask(){
		return isMask;
	}

	public String getId(){
		return id;
	}
}