package com.esc.socialmediacleaner.datastructure;

import java.util.ArrayList;

public class AppData {
    public ArrayList<MediaTypeList> list = new ArrayList();
    public SocialAppType socialApp;

    public AppData(SocialAppType socialAppType) {
        this.socialApp = socialAppType;
    }
}
