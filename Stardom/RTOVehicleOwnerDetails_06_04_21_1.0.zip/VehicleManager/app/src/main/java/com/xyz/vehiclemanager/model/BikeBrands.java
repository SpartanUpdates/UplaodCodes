package com.xyz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class BikeBrands
{
    @SerializedName("data")
    public ArrayList<BikeBrands> data = null;
    @SerializedName("id")
    public String id;
    @SerializedName("brandName")
    public String brandName;
    @SerializedName("imageUrl")
    public String imageUrl;

    public BikeBrands() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public ArrayList<BikeBrands> getData() {
        return data;
    }

    public void setData(ArrayList<BikeBrands> data) {
        this.data = data;
    }
}
