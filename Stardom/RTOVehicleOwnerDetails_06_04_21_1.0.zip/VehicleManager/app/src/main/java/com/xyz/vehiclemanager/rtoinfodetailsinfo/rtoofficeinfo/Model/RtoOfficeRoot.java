package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RtoOfficeRoot {
    @SerializedName("details")
    public ArrayList<RtoCityList> cityList;

    public ArrayList<RtoCityList> getCityList() {
        return cityList;
    }

    public void setCityList(ArrayList<RtoCityList> cityList) {
        this.cityList = cityList;
    }
}
