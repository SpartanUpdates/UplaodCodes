package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

public class StickerAdapter extends BaseAdapter {
    String str_folder;
    LayoutInflater layoutInflater;
    private Context context;
    private String[] strings;

    public StickerAdapter(final Context context, final String[] strings, final String str_folder) {
        this.layoutInflater = null;
        this.context = context;
        this.strings = strings;
        this.str_folder = str_folder;

        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.strings.length;
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(final int n, final View view, final ViewGroup viewGroup) {
        View inflate = view;
        if (view == null) {
            inflate = this.layoutInflater.inflate(R.layout.sticker_adapter, (ViewGroup) null);
        }
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.bg_img);
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        imageView2.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(widthPixels * 327 / 1080, heightPixels * 348 / 1920));
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 275 / 1080, heightPixels * 275 / 1920);
        layoutParams.addRule(13);
        imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);

        final RequestManager with = Glide.with(this.context);
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///android_asset/");
        sb.append(this.str_folder);
        sb.append("/");
        sb.append(this.strings[n]);

        with.load(Uri.parse(sb.toString())).into(imageView);
        return inflate;
    }
}
