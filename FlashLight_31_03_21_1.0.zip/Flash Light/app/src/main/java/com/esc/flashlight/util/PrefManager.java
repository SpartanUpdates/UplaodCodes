package com.esc.flashlight.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.Log;

import com.esc.flashlight.config.Config;

public class PrefManager {
    public static final int AVAILABLE = 1;
    public static final int BASIC = 0;
    public static final int EXCEPT_APPLICATION = 3;
    public static final int EXCEPT_PHONE_NUMBER = 1;
    public static final int FRONT_DISABLE = 0;
    public static final int FRONT_ENABLE = 1;
    public static final int FRONT_UNCHECKED = -1;
    public static final int IGNORE_INDEX_HOUR = 0;
    public static final int IGNORE_INDEX_MIN = 1;
    public static final int INCLUDE_APPLICATION = 2;
    public static final int INCLUDE_PHONE_NUMBER = 0;
    public static final int INIT_FAILED = 0;
    public static final int NOT_AVAILABLE = 3;
    public static final int NOT_TORCH = 2;
    public static final int POSITION_BACK = 2;
    public static final int POSITION_BOTH = 0;
    public static final int POSITION_FRONT = 1;
    public static final int SURFACE_TEXTURE = 2;
    public static final int SURFACE_VIEW = 1;
    private int mFilterModeApplication;
    private int mFlashController;
    private int mFlashPosition;
    private int mFlashSupportValue;
    private int mFrontCameraId;
    private int mFrontFlashable;
    private int[] mIgnoreTimeBegin;
    private int[] mIgnoreTimeEnd;
    private String mImei;
    private int mIntervalMissedCall;
    private boolean mIsInitialized;
    private int mOffIntervalCall;
    private int mOffIntervalMessage;
    private int mOffIntervalMissedCall;
    private int mOffIntervalStatusBar;
    private int mOnIntervalCall;
    private int mOnIntervalMessage;
    private int mOnIntervalMissedCall;
    private int mOnIntervalStatusBar;
    private long mScreenOnTime;
    private int mStrobeCountMessage;
    private int mStrobeCountMissedCall;
    private int mStrobeCountStatusBar;
    private boolean mUseCall;
    private boolean mUseMessage;
    private boolean mUseMissedCall;
    private boolean mUseModeIgnore;
    private boolean mUseModeNormal;
    private boolean mUseModeSilent;
    private boolean mUseModeVibrate;
    private boolean mUseScreenOn;
    private boolean mUseStatusBar;
    private boolean mUseTotally;
    String option = "torch";
    private SharedPreferences pref;

    public PrefManager(Context context) {
        this.pref = context.getSharedPreferences(Config.PREF_NAME, 0);
        init();
    }

    private void init() {
        this.mScreenOnTime = this.pref.getLong("screen_on_time", SystemClock.elapsedRealtime());
        this.mIsInitialized = this.pref.getBoolean(IPref.INITIALIZED, false);
        Log.e("TAG", "init: " + this.mIsInitialized);
        this.mFlashController = this.pref.getInt(IPref.FLASH_CONTROLLER, 0);
        this.mFlashPosition = this.pref.getInt(IPref.FLASH_POSITION, 2);
        this.mFrontCameraId = this.pref.getInt(IPref.FRONT_CAMERA_ID, 1);
        this.mFlashSupportValue = this.pref.getInt(IPref.FLASH_SUPPORT_VALUE, 0);
        this.mFrontFlashable = this.pref.getInt(IPref.FRONT_FLASHABLE, -1);
        this.mUseTotally = this.pref.getBoolean(IPref.USE_TOTALLY, true);
        this.mUseCall = this.pref.getBoolean(IPref.USE_CALL, true);
        this.mUseMessage = this.pref.getBoolean(IPref.USE_MESSAGE, true);
        this.mUseStatusBar = this.pref.getBoolean(IPref.USE_STATUS_BAR, false);
        this.mUseModeNormal = this.pref.getBoolean(IPref.USE_MODE_NORMAL, true);
        this.mUseModeVibrate = this.pref.getBoolean(IPref.USE_MODE_VIBRATE, true);
        this.mUseModeSilent = this.pref.getBoolean(IPref.USE_MODE_SILENT, true);
        this.mUseModeIgnore = this.pref.getBoolean(IPref.USE_MODE_IGNORE, false);
        this.mUseScreenOn = this.pref.getBoolean(IPref.USE_SCREEN_ON, true);
        this.mIgnoreTimeBegin = new int[]{this.pref.getInt(IPref.IGNORE_TIME_BEGIN_H, 0), this.pref.getInt(IPref.IGNORE_TIME_BEGIN_M, 0)};
        this.mIgnoreTimeEnd = new int[]{this.pref.getInt(IPref.IGNORE_TIME_END_H, 0), this.pref.getInt(IPref.IGNORE_TIME_END_M, 0)};
        this.mFilterModeApplication = this.pref.getInt(IPref.FILTERING_APPLICATION_MODE, 2);
        this.mOnIntervalCall = this.pref.getInt(IPref.ON_INTERVAL_CALL, 10);
        this.mOffIntervalCall = this.pref.getInt(IPref.OFF_INTERVAL_CALL, 10);
        this.mOnIntervalMessage = this.pref.getInt(IPref.ON_INTERVAL_MESSAGE, 10);
        this.mOffIntervalMessage = this.pref.getInt(IPref.OFF_INTERVAL_MESSAGE, 10);
        this.mStrobeCountMessage = this.pref.getInt(IPref.STROBE_COUNT_MESSAGE, 3);
        this.mOnIntervalStatusBar = this.pref.getInt(IPref.ON_INTERVAL_STATUS_BAR, 10);
        this.mOffIntervalStatusBar = this.pref.getInt(IPref.OFF_INTERVAL_STATUS_BAR, 10);
        this.mStrobeCountStatusBar = this.pref.getInt(IPref.STROBE_COUNT_STATUS_BAR, 3);
        this.mOnIntervalMissedCall = this.pref.getInt(IPref.ON_INTERVAL_MISSED_CALL, 10);
        this.mOffIntervalMissedCall = this.pref.getInt(IPref.OFF_INTERVAL_MISSED_CALL, 10);
        this.mStrobeCountMissedCall = this.pref.getInt(IPref.STROBE_COUNT_MISSED_CALL, 3);
        this.mIntervalMissedCall = this.pref.getInt(IPref.INTERVAL_MISSED_CALL, 30);
    }

    private void commit(Editor editor) {
        if (VERSION.SDK_INT > 8) {
            apply(editor);
        } else {
            editor.commit();
        }
    }

    private void apply(Editor editor) {
        editor.apply();
    }

    public void setLightOption(String str) {
        this.option = str;
        commit(this.pref.edit().putString("selectOption", str));
    }

    public String getLightOption() {
        return this.option;
    }

    public void setScreenOnTime(long j) {
        this.mScreenOnTime = j;
        commit(this.pref.edit().putLong("screen_on_time", j));
    }

    public long getScreenOnTime() {
        return this.mScreenOnTime;
    }

    public boolean isInitialized() {
        return this.mIsInitialized;
    }

    public void setInitialized() {
        this.mIsInitialized = true;
        commit(this.pref.edit().putBoolean(IPref.INITIALIZED, true));
    }

    public int getFlashController() {
        return this.mFlashController;
    }

    public void setFlashController(int i) {
        this.mFlashController = i;
        commit(this.pref.edit().putInt(IPref.FLASH_CONTROLLER, i));
        Log.d(getClass().getSimpleName(), "플래시 모듈 설정: " + i);
    }

    public int getFlashPosition() {
        return this.mFlashPosition;
    }

    public void setFlashPosition(int i) {
        this.mFlashPosition = i;
        commit(this.pref.edit().putInt(IPref.FLASH_POSITION, i));
        Log.d(getClass().getSimpleName(), "플래시 위치 설정: " + i);
    }

    public int getFrontCameraId() {
        return this.mFrontCameraId;
    }

    public void setFrontCameraId(int i) {
        commit(this.pref.edit().putInt(IPref.FRONT_CAMERA_ID, i));
    }

    public int getFlashSupportValue() {
        return this.mFlashSupportValue;
    }

    public void setFlashSupportValue(int i) {
        commit(this.pref.edit().putInt(IPref.FLASH_SUPPORT_VALUE, i));
    }

    public int getFrontFlashable() {
        return this.mFrontFlashable;
    }

    public void setFrontFlashable(int i) {
        commit(this.pref.edit().putInt(IPref.FRONT_FLASHABLE, i));
    }

    public boolean getUseTotally() {
        return this.mUseTotally;
    }

    public boolean getUseCall() {
        return this.mUseCall;
    }

    public boolean getUseMessage() {
        return this.mUseMessage;
    }

    public boolean getUseStatusBar() {
        return this.mUseStatusBar;
    }

    public boolean getUseMissedCall() {
        return this.mUseMissedCall;
    }

    public boolean getUseModeNormal() {
        return this.mUseModeNormal;
    }

    public boolean getUseModeVibrate() {
        return this.mUseModeVibrate;
    }

    public boolean getUseModeSilent() {
        return this.mUseModeSilent;
    }

    public boolean getUseModeIgnore() {
        return this.mUseModeIgnore;
    }

    public boolean getUseScreenOn() {
        return this.mUseScreenOn;
    }

    public void setUseTotally(boolean z) {
        this.mUseTotally = z;
        commit(this.pref.edit().putBoolean(IPref.USE_TOTALLY, z));
    }

    public void setUseCall(boolean z) {
        this.mUseCall = z;
        commit(this.pref.edit().putBoolean(IPref.USE_CALL, z));
    }

    public void setUseMessage(boolean z) {
        this.mUseMessage = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MESSAGE, z));
    }

    public boolean setUseStatusBar(boolean z) {
        this.mUseStatusBar = z;
        commit(this.pref.edit().putBoolean(IPref.USE_STATUS_BAR, z));
        return true;
    }

    public boolean setUseMissedCall(boolean z) {
        this.mUseMissedCall = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MISSED_CALL, z));
        return false;
    }

    public boolean setUseModeNormal(boolean z) {
        this.mUseModeNormal = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MODE_NORMAL, z));
        return true;
    }

    public boolean setUseModeVibrate(boolean z) {
        this.mUseModeVibrate = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MODE_VIBRATE, z));
        return true;
    }

    public boolean setUseModeSilent(boolean z) {
        this.mUseModeSilent = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MODE_SILENT, z));
        return true;
    }

    public boolean setUseModeIgnore(boolean z) {
        this.mUseModeIgnore = z;
        commit(this.pref.edit().putBoolean(IPref.USE_MODE_IGNORE, z));
        return true;
    }

    public boolean setUseScreenOn(boolean z) {
        this.mUseScreenOn = z;
        commit(this.pref.edit().putBoolean(IPref.USE_SCREEN_ON, z));
        return true;
    }

    public void setIgnoreTimeBegin(int i, int i2) {
        int[] iArr = this.mIgnoreTimeBegin;
        iArr[0] = i;
        iArr[1] = i2;
        commit(this.pref.edit().putInt(IPref.IGNORE_TIME_BEGIN_H, i).putInt(IPref.IGNORE_TIME_BEGIN_M, i2));
    }

    public void setIgnoreTimeEnd(int i, int i2) {
        int[] iArr = this.mIgnoreTimeEnd;
        iArr[0] = i;
        iArr[1] = i2;
        commit(this.pref.edit().putInt(IPref.IGNORE_TIME_END_H, i).putInt(IPref.IGNORE_TIME_END_M, i2));
    }

    public int[] getIgnoreTimeBegin() {
        return this.mIgnoreTimeBegin;
    }

    public int[] getIgnoreTimeEnd() {
        return this.mIgnoreTimeEnd;
    }

    public int getFilterModeApplication() {
        return this.mFilterModeApplication;
    }

    public void setFilterModeApplication(int i) {
        this.mFilterModeApplication = i;
        commit(this.pref.edit().putInt(IPref.FILTERING_APPLICATION_MODE, i));
    }

    public int getOnIntervalCall() {
        return this.mOnIntervalCall;
    }

    public int getOffIntervalCall() {
        return this.mOffIntervalCall;
    }

    public void setOnIntervalCall(int i) {
        this.mOnIntervalCall = i;
        commit(this.pref.edit().putInt(IPref.ON_INTERVAL_CALL, i));
    }

    public void setOffIntervalCall(int i) {
        this.mOffIntervalCall = i;
        commit(this.pref.edit().putInt(IPref.OFF_INTERVAL_CALL, i));
    }

    public int getOnIntervalMessage() {
        return this.mOnIntervalMessage;
    }

    public int getOffIntervalMessage() {
        return this.mOffIntervalMessage;
    }

    public void setOnIntervalMessage(int i) {
        this.mOnIntervalMessage = i;
        commit(this.pref.edit().putInt(IPref.ON_INTERVAL_MESSAGE, i));
    }

    public void setOffIntervalMessage(int i) {
        this.mOffIntervalMessage = i;
        commit(this.pref.edit().putInt(IPref.OFF_INTERVAL_MESSAGE, i));
    }

    public void setStrobeCountMessage(int i) {
        this.mStrobeCountMessage = i;
        commit(this.pref.edit().putInt(IPref.STROBE_COUNT_MESSAGE, i));
    }

    public int getStrobeCountMessage() {
        return this.mStrobeCountMessage;
    }

    public int getOnIntervalStatusBar() {
        return this.mOnIntervalStatusBar;
    }

    public int getOffIntervalStatusBar() {
        return this.mOffIntervalStatusBar;
    }

    public int getStrobeCountStatusBar() {
        return this.mStrobeCountStatusBar;
    }

    public void setOnIntervalStatusBar(int i) {
        this.mOnIntervalStatusBar = i;
        commit(this.pref.edit().putInt(IPref.ON_INTERVAL_STATUS_BAR, i));
    }

    public void setOffIntervalStatusBar(int i) {
        this.mOffIntervalStatusBar = i;
        commit(this.pref.edit().putInt(IPref.OFF_INTERVAL_STATUS_BAR, i));
    }

    public void setStrobeCountStatusBar(int i) {
        this.mStrobeCountStatusBar = i;
        commit(this.pref.edit().putInt(IPref.STROBE_COUNT_STATUS_BAR, i));
    }

    public int getOnIntervalMissedCall() {
        return this.mOnIntervalMissedCall;
    }

    public int getOffIntervalMissedCall() {
        return this.mOffIntervalMissedCall;
    }

    public void setOnIntervalMissedCall(int i) {
        this.mOnIntervalMissedCall = i;
        commit(this.pref.edit().putInt(IPref.ON_INTERVAL_MISSED_CALL, i));
    }

    public void setOffIntervalMissedCall(int i) {
        this.mOffIntervalMissedCall = i;
        commit(this.pref.edit().putInt(IPref.OFF_INTERVAL_MISSED_CALL, i));
    }

    public void setStrobeCountMissedCall(int i) {
        this.mStrobeCountMissedCall = i;
        commit(this.pref.edit().putInt(IPref.STROBE_COUNT_MISSED_CALL, i));
    }

    public int getStrobeCountMissedCall() {
        return this.mStrobeCountMissedCall;
    }

    public int getIntervalMissedCall() {
        return this.mIntervalMissedCall;
    }

    public void setIntervalMissedCall(int i) {
        this.mIntervalMissedCall = i;
        commit(this.pref.edit().putInt(IPref.INTERVAL_MISSED_CALL, i));
    }
}
