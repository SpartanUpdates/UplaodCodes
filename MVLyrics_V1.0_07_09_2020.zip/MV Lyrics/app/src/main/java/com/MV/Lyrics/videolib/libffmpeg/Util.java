package com.MV.Lyrics.videolib.libffmpeg;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class Util
{
  public static boolean isDebug(final Context context) {
    final ApplicationInfo applicationInfo = context.getApplicationContext().getApplicationInfo();
    final int i = applicationInfo.flags & 0x2;
    applicationInfo.flags = i;
    return i != 0;
  }

  public static void close(final InputStream inputStream) {
    if (inputStream != null) {
      try {
        inputStream.close();
      }
      catch (IOException ex) {}
    }
  }

  public static void close(final OutputStream outputStream) {
    if (outputStream != null) {
      try {
        outputStream.flush();
        outputStream.close();
      }
      catch (IOException ex) {}
    }
  }

  public static String convertInputStreamToString(final InputStream inputStream) {
    try {
      final BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));
      final StringBuilder sb = new StringBuilder();
      while (true) {
        final String str = r.readLine();
        if (str == null) {
          break;
        }
        sb.append(str);
      }
      return sb.toString();
    }
    catch (IOException e) {
      return null;
    }
  }

  public static void destroyProcess(final Process process) {
    if (process != null) {
      process.destroy();
    }
  }

  public static boolean killAsync(final AsyncTask<?, ?, ?> asyncTask) {
    return asyncTask != null && !asyncTask.isCancelled() && asyncTask.cancel(true);
  }

  public static boolean isProcessCompleted(final Process process) {
    if (process == null) {
      return true;
    }
    try {
      process.exitValue();
      return true;
    }
    catch (IllegalThreadStateException e) {
      return false;
    }
  }
}
