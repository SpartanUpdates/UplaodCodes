package com.kotlinz.videoCollage.puzzleview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.flying.puzzle.PuzzleLayout;
import com.kotlinz.videoCollage.flying.puzzle.SquarePuzzleView;
import com.kotlinz.videoCollage.puzzleview.slant.NumberSlantLayout;
import com.kotlinz.videoCollage.puzzleview.straight.NumberStraightLayout;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;
import java.util.List;

public class PuzzleAdapter extends RecyclerView.Adapter<PuzzleAdapter.PuzzleViewHolder> {

    public Context context;
    private String from;
    private List<PuzzleLayout> layoutData = new ArrayList();
    public OnItemClickListener onItemClickListener;
    public int pos = -1;
    private List<View> viewPieces = new ArrayList();

    public interface OnItemClickListener {
        void onItemClick(PuzzleLayout puzzleLayout, int i);
    }

    public PuzzleAdapter(Context context2, String str) {
        this.context = context2;
        this.from = str;
    }

    public PuzzleViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new PuzzleViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_puzzle, viewGroup, false));
    }

    public void onBindViewHolder(PuzzleViewHolder puzzleViewHolder, @SuppressLint("RecyclerView") final int i) {
        final PuzzleLayout puzzleLayout = this.layoutData.get(i);
        if (this.from.equalsIgnoreCase("grid")) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) puzzleViewHolder.puzzleView.getLayoutParams();
            layoutParams.width = (int) this.context.getResources().getDimension(R.dimen._50sdp);
            layoutParams.height = (int) this.context.getResources().getDimension(R.dimen._50sdp);
            puzzleViewHolder.puzzleView.setLayoutParams(layoutParams);
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) puzzleViewHolder.morePuzzle.getLayoutParams();
            layoutParams2.width = (int) this.context.getResources().getDimension(R.dimen._50sdp);
            layoutParams2.height = (int) this.context.getResources().getDimension(R.dimen._50sdp);
            puzzleViewHolder.morePuzzle.setLayoutParams(layoutParams2);
        } else {
            LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) puzzleViewHolder.puzzleView.getLayoutParams();
            layoutParams3.width = (int) this.context.getResources().getDimension(R.dimen._100sdp);
            layoutParams3.height = (int) this.context.getResources().getDimension(R.dimen._100sdp);
            puzzleViewHolder.puzzleView.setLayoutParams(layoutParams3);
            LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) puzzleViewHolder.morePuzzle.getLayoutParams();
            layoutParams4.width = (int) this.context.getResources().getDimension(R.dimen._100sdp);
            layoutParams4.height = (int) this.context.getResources().getDimension(R.dimen._100sdp);
            puzzleViewHolder.morePuzzle.setLayoutParams(layoutParams4);
        }
        puzzleViewHolder.puzzleView.setNeedDrawLine(true);
        puzzleViewHolder.puzzleView.setNeedDrawOuterLine(true);
        puzzleViewHolder.puzzleView.setTouchEnable(false);
        puzzleViewHolder.puzzleView.setPuzzleLayout(puzzleLayout);
        puzzleViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                pos = i;
                if (PuzzleAdapter.this.onItemClickListener != null) {
                    int i = 0;
                    if (puzzleLayout instanceof NumberSlantLayout) {
                        i = ((NumberSlantLayout) puzzleLayout).getTheme();
                    } else if (puzzleLayout instanceof NumberStraightLayout) {
                        i = ((NumberStraightLayout) puzzleLayout).getTheme();
                    }
                    onItemClickListener.onItemClick(puzzleLayout, i);
                    notifyDataSetChanged();
                }
                notifyDataSetChanged();
            }
        });
        puzzleViewHolder.morePuzzle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                context.startActivity(new Intent(context, PlaygroundActivity.class));
            }
        });
        if (this.from.equalsIgnoreCase("grid")) {
            if (this.pos == i) {
                puzzleViewHolder.puzzleView.setLineColor(this.context.getResources().getColor(R.color.gradint_center));
            } else {
                puzzleViewHolder.puzzleView.setLineColor(this.context.getResources().getColor(R.color.colorGreyLt));
            }
        }
        List<View> list = this.viewPieces;
        if (list != null) {
            int size = list.size();
            if (puzzleLayout.getAreaCount() > size) {
                for (int i2 = 0; i2 < puzzleLayout.getAreaCount(); i2++) {
                    puzzleViewHolder.puzzleView.addPiece(this.viewPieces.get(i2 % size));
                }
                return;
            }
            puzzleViewHolder.puzzleView.addPieces(this.viewPieces);
        }
    }

    public void setPos(int i) {
        this.pos = i;
        notifyDataSetChanged();
    }

    public int getItemCount() {
        List<PuzzleLayout> list = this.layoutData;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public void refreshData(List<PuzzleLayout> list, List<View> list2) {
        this.layoutData = list;
        this.viewPieces = list2;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener2) {
        this.onItemClickListener = onItemClickListener2;
    }

    public static class PuzzleViewHolder extends RecyclerView.ViewHolder {
        TextView morePuzzle;
        SquarePuzzleView puzzleView;

        public PuzzleViewHolder(View view) {
            super(view);
            this.puzzleView = (SquarePuzzleView) view.findViewById(R.id.puzzle);
            this.morePuzzle = (TextView) view.findViewById(R.id.more_puzzle);
        }
    }
}
