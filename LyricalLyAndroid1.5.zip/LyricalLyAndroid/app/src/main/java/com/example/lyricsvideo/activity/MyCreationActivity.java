package com.example.lyricsvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.lyricsvideo.Adapter.VideoAlbumAdapter;
import com.example.lyricsvideo.Model.MycreationInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.application.App;
import com.facebook.ads.AdSettings;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.ArrayList;

public class MyCreationActivity extends AppCompatActivity {
    Activity activity = MyCreationActivity.this;
    public ArrayList<MycreationInfo> videoInfos;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    Button btncreatevideo;
    RecyclerView rvVideoList;
    VideoAlbumAdapter videoListAdapter;
    String from = "";
    private App application;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyCreationActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        try {
            App.IS_EDITIMAGE = 0;
            application = App.getInstance();
            application.clearAllSelection();

        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Utils util = new Utils();
            String path = util.getOutputPath() + ".Crop Image" + File.separator;
            File folder = new File(path);
            util.deleteRecursive(folder);
        } catch (Exception e) {
            e.printStackTrace();
        }
        from = getIntent().getStringExtra("from");
        init();
        SetAllVideoAdapter();
    }


    private void init() {
        llcreatevideo = findViewById(R.id.ll_create_viedeo_now);
        ivBack = findViewById(R.id.ivBack);
        btncreatevideo = findViewById(R.id.btn_create_video_now);
        rvVideoList = findViewById(R.id.rv__all_video_list);
        txtMainTitle = findViewById(R.id.txtMainTitle);
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        btncreatevideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(activity, MainActivity.class));
                finish();
            }
        });
        AppFont.Textfont(activity,txtMainTitle);
        getVideoList();
        setStatusBarColor();
        if (videoInfos.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }

    protected void onResume() {
        super.onResume();
    }

    private void getVideoList() {
        this.videoInfos = new ArrayList<MycreationInfo>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = this.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getOutputPath() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final MycreationInfo videoInfo = new MycreationInfo();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    this.videoInfos.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
    }

    @SuppressLint({"InlinedApi", "NewApi"})
    public void setStatusBarColor() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.clearFlags(67108864);
            window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, MainActivity.class));
        finish();
        application.cropimaglist.clear();
    }

    private void SetAllVideoAdapter() {
        if (videoInfos.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        videoListAdapter = new VideoAlbumAdapter(this);
        StaggeredGridLayoutManager gridLayoutManager = new StaggeredGridLayoutManager(1, 1);
        gridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gridLayoutManager);
        rvVideoList.setAdapter(videoListAdapter);
        RvDecoration();
        videoListAdapter.notifyDataSetChanged();
    }

    private void RvDecoration() {
        rvVideoList.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
                int position = parent.getChildAdapterPosition(view);
                int spanCount = 2;
                int spacing = 5;

                if (position >= 0) {
                    int column = position % spanCount;
                    outRect.left = spacing - column * spacing / spanCount;
                    outRect.right = (column + 1) * spacing / spanCount;
                    if (position < spanCount) {
                        outRect.top = spacing;
                    }
                    outRect.bottom = spacing;
                } else {
                    outRect.left = 0;
                    outRect.right = 0;
                    outRect.top = 0;
                    outRect.bottom = 0;
                }
            }
        });
    }

    public void RemoveVideoFromList(int pos) {
        if ((videoInfos != null) && (videoInfos.size() > 0)) {
            videoInfos.remove(pos);
        }
    }


}
