package com.Pulse.VideoStatus.videolib.libffmpeg;

import android.content.Context;
import android.text.TextUtils;

import com.Pulse.VideoStatus.videolib.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.Pulse.VideoStatus.videolib.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.lang.reflect.Array;
import java.util.Map;

public class FFmpeg implements FFmpegInterface
{
  private static int[] $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch;
  private static final long MINIMUM_TIMEOUT = 10000L;
  private static FFmpeg instance;
  private final Context context;
  private FFmpegExecuteAsyncTask ffmpegExecuteAsyncTask;
  private FFmpegLoadLibraryAsyncTask ffmpegLoadLibraryAsyncTask;
  private long timeout;

  static {
    FFmpeg.$SWITCH_TABLE$com$videolib$libffmpeg$CpuArch = null;
    FFmpeg.instance = null;
  }

  static int[] $SWITCH_TABLE$com$videolib$libffmpeg$CpuArch() {
    int[] iArr = FFmpeg.$SWITCH_TABLE$com$videolib$libffmpeg$CpuArch;
    if (iArr == null) {
      iArr = new int[CpuArch.values().length];
      try {
        iArr[CpuArch.ARMv7.ordinal()] = 2;
      }
      catch (NoSuchFieldError noSuchFieldError) {}
      try {
        iArr[CpuArch.NONE.ordinal()] = 3;
      }
      catch (NoSuchFieldError noSuchFieldError2) {}
      try {
        iArr[CpuArch.x86.ordinal()] = 1;
      }
      catch (NoSuchFieldError noSuchFieldError3) {}
      FFmpeg.$SWITCH_TABLE$com$videolib$libffmpeg$CpuArch = iArr;
    }
    return iArr;
  }

  private FFmpeg(final Context context) {
    this.timeout = Long.MAX_VALUE;
    this.context = context.getApplicationContext();
    Log.setDEBUG(Util.isDebug(this.context));
  }

  public static FFmpeg getInstance(final Context context) {
    if (FFmpeg.instance == null) {
      FFmpeg.instance = new FFmpeg(context);
    }
    return FFmpeg.instance;
  }

  @Override
  public void loadBinary(final FFmpegLoadBinaryResponseHandler ffmpegLoadBinaryResponseHandler) throws FFmpegNotSupportedException {
    String cpuArchNameFromAssets = null;
    switch ($SWITCH_TABLE$com$videolib$libffmpeg$CpuArch()[CpuArchHelper.getCpuArch().ordinal()]) {
      case 1: {
        cpuArchNameFromAssets = "x86";
        break;
      }
      case 2: {
        cpuArchNameFromAssets = "armeabi-v7a";
        break;
      }
      case 3: {
        throw new FFmpegNotSupportedException("Device not supported");
      }
    }
    if (TextUtils.isEmpty((CharSequence)cpuArchNameFromAssets)) {
      throw new FFmpegNotSupportedException("Device not supported");
    }
    (this.ffmpegLoadLibraryAsyncTask = new FFmpegLoadLibraryAsyncTask(this.context, cpuArchNameFromAssets, ffmpegLoadBinaryResponseHandler)).execute(new Void[0]);
  }

  @Override
  public void execute(final Map<String, String> environvenmentVars, final String[] cmd, final FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler) throws FFmpegCommandAlreadyRunningException {
    if (this.ffmpegExecuteAsyncTask != null && !this.ffmpegExecuteAsyncTask.isProcessCompleted()) {
      throw new FFmpegCommandAlreadyRunningException("FFmpeg command is already running, you are only allowed to run single command at NotificationUtils time");
    }
    if (cmd.length != 0) {
      (this.ffmpegExecuteAsyncTask = new FFmpegExecuteAsyncTask(this.concatenate(new String[] { FileUtils.getFFmpeg(this.context, environvenmentVars) }, cmd), this.timeout, ffmpegExecuteResponseHandler)).execute(new Void[0]);
      return;
    }
    throw new IllegalArgumentException("shell command cannot be empty");
  }

  public <T> T[] concatenate(final T[] a, final T[] b) {
    final int aLen = a.length;
    final int bLen = b.length;
    final Object[] c = (Object[])Array.newInstance(a.getClass().getComponentType(), aLen + bLen);
    System.arraycopy(a, 0, c, 0, aLen);
    System.arraycopy(b, 0, c, aLen, bLen);
    return (T[])c;
  }

  @Override
  public void execute(final String[] cmd, final FFmpegExecuteResponseHandler ffmpegExecuteResponseHandler) throws FFmpegCommandAlreadyRunningException {
    this.execute(null, cmd, ffmpegExecuteResponseHandler);
  }

  @Override
  public String getDeviceFFmpegVersion() throws FFmpegCommandAlreadyRunningException {
    final CommandResult commandResult = new ShellCommand().runWaitFor(new String[] { FileUtils.getFFmpeg(this.context), "-version" });
    if (commandResult.success) {
      return commandResult.output.split(" ")[2];
    }
    return "";
  }

  @Override
  public String getLibraryFFmpegVersion() {
    return "n2.4.2";
  }

  @Override
  public boolean isFFmpegCommandRunning() {
    return this.ffmpegExecuteAsyncTask != null && !this.ffmpegExecuteAsyncTask.isProcessCompleted();
  }

  @Override
  public boolean killRunningProcesses() {
    return Util.killAsync(this.ffmpegLoadLibraryAsyncTask) || Util.killAsync(this.ffmpegExecuteAsyncTask);
  }

  @Override
  public void setTimeout(final long timeout) {
    if (timeout >= 10000L) {
      this.timeout = timeout;
    }
  }
}
