package com.esc.photovault.model;

public class Model {
    String image_name;
    boolean isselected;
    String path;

    public boolean isselected() {
        return this.isselected;
    }

    public void setIsselected(boolean isselected) {
        this.isselected = isselected;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getImage_name() {
        return this.image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }
}
