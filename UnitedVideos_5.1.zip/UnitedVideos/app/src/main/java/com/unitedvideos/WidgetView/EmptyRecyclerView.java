package com.unitedvideos.WidgetView;

import android.content.Context;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class EmptyRecyclerView extends RecyclerView {
    private View emptyView;
    private AdapterDataObserver dataObserver = new AdapterDataObserver() {
        public void onChanged() {
            Adapter<?> adapter = getAdapter();
            if ((adapter != null) && (emptyView != null)) {
                if (adapter.getItemCount() == 0) {
                    emptyView.setVisibility(View.VISIBLE);
                    setVisibility(View.GONE);
                } else {
                    emptyView.setVisibility(View.GONE);
                    setVisibility(View.VISIBLE);
                }
            }
        }
    };

    public EmptyRecyclerView(Context context) {
        this(context, null);
    }

    public EmptyRecyclerView(Context context, android.util.AttributeSet attr) {
        this(context, attr, 0);
    }

    public EmptyRecyclerView(Context context, android.util.AttributeSet attr, int defStyle) {
        super(context, attr, defStyle);
    }


    public void setAdapter(Adapter adapter) {
        super.setAdapter(adapter);
        if (adapter != null) {
            adapter.registerAdapterDataObserver(dataObserver);
        }
        dataObserver.onChanged();
    }

    public void setEmptyView(View emptyView) {
        this.emptyView = emptyView;
    }
}
