package com.root.bridge;

import android.content.Context;
import android.opengl.GLES20;
import android.util.Log;
import com.intel.inde.mp.IProgressListener;
import com.intel.inde.mp.android.graphics.FullFrameTexture;
import com.Pulse.VideoStatus.Extra.Utils;
import java.io.File;
import java.io.IOException;

public class Capturing {
    private static final String TAG = "Capturing";
    private static FullFrameTexture texture;
    private VideoCapture videoCapture;
    private int width;
    private int height;
    private int videoWidth;
    private int videoHeight;
    private int videoFrameRate;
    private long nextCaptureTime;
    private long startTime;
    private static Capturing instance;
    private SharedContext sharedContext;
    private EncodeThread encodeThread;
    private boolean finalizeFrame;
    private boolean isRunning;
    private IProgressListener progressListener;

    static {
        Capturing.instance = null;
    }

    public Capturing(final Context context, final int width, final int height) {
        this.width = 0;
        this.height = 0;
        this.videoWidth = 0;
        this.videoHeight = 0;
        this.videoFrameRate = 0;
        this.nextCaptureTime = 0L;
        this.startTime = 0L;
        this.sharedContext = null;
        this.encodeThread = null;
        this.finalizeFrame = false;
        this.isRunning = false;
        this.progressListener = (IProgressListener) new IProgressListener() {
            public void onMediaStart() {
                Capturing.access$0(Capturing.this, System.nanoTime());
                Capturing.access$1(Capturing.this, 0L);
                Capturing.this.encodeThread.start();
                Capturing.access$3(Capturing.this, true);
            }

            public void onMediaProgress(final float progress) {
            }

            public void onMediaDone() {
            }

            public void onMediaPause() {
            }

            public void onMediaStop() {
            }

            public void onError(final Exception exception) {
            }
        };
        try {
            this.videoCapture = new VideoCapture(context, this.progressListener);
            this.width = width;
            this.height = height;
            Capturing.texture = new FullFrameTexture();
            this.sharedContext = new SharedContext();
            Capturing.instance = this;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Capturing getInstance() {
        return Capturing.instance;
    }

    public static String getDirectoryDCIM() {
        return String.valueOf(Utils.SongCropCommanPath) + File.separator;
    }

    public void initCapturing(final int width, final int height, final int frameRate, final int bitRate) {
        try {
            VideoCapture.init(width, height, this.videoFrameRate = frameRate, bitRate);
            this.videoWidth = width;
            this.videoHeight = height;
            this.encodeThread = new EncodeThread(this.sharedContext);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void deleteFile(final String DeleteVideoPath) {
        try {
            this.isRunning = false;
            if (this.finalizeFrame) {
                this.finalizeFrame = false;
            }
            this.encodeThread.queryStop();
        } catch (Exception e) {
            e.printStackTrace();
        }
        File file = new File(DeleteVideoPath);
        if (file != null && file.exists()) {
            if (file.delete()) {
                Log.e("File Delete", "===========  Success");
            } else {
                Log.e("File Delete", "===========Failed");
            }
        }
    }

    public void startCapturing(final String videoPath) {
        try {
            if (this.videoCapture == null) {
                return;
            }
            new Thread() {
                @Override
                public void run() {
                    synchronized (Capturing.this.videoCapture) {
                        try {
                            Capturing.this.videoCapture.start(videoPath);
                        } catch (IOException ex) {
                        }
                    }
                    // monitorexit(Capturing.access$4(this.this$0))
                }
            }.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void captureFrame(final int textureID) {
        try {
            this.encodeThread.pushFrame(textureID);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopCapturing() {
        try {
            this.isRunning = false;
            if (this.finalizeFrame) {
                this.finalizeFrame = false;
            }
            this.encodeThread.queryStop();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    static /* synthetic */ void access$0(final Capturing capturing, final long startTime) {
        capturing.startTime = startTime;
    }

    static /* synthetic */ void access$1(final Capturing capturing, final long nextCaptureTime) {
        capturing.nextCaptureTime = nextCaptureTime;
    }

    static /* synthetic */ void access$3(final Capturing capturing, final boolean isRunning) {
        capturing.isRunning = isRunning;
    }

    private class EncodeThread extends Thread {
        private static final String TAG = "EncodeThread";
        private SharedContext sharedContext;
        private boolean isStopped;
        private int textureID;
        private boolean newFrameIsAvailable;

        EncodeThread(final SharedContext sharedContext) {
            this.isStopped = false;
            this.newFrameIsAvailable = false;
            this.sharedContext = sharedContext;
        }

        @Override
        public void run() {
            try {
                while (!this.isStopped) {
                    if (this.newFrameIsAvailable) {
                        synchronized (Capturing.this.videoCapture) {
                            this.sharedContext.makeCurrent();
                            Capturing.this.videoCapture.beginCaptureFrame();
                            GLES20.glViewport(0, 0, Capturing.this.videoWidth, Capturing.this.videoHeight);
                            Capturing.texture.draw(this.textureID);
                            Capturing.this.videoCapture.endCaptureFrame();
                            this.newFrameIsAvailable = false;
                            this.sharedContext.doneCurrent();
                        }
                        // monitorexit(Capturing.access$4(this.this$0))
                    }
                }
                this.isStopped = false;
                synchronized (Capturing.this.videoCapture) {
                    Capturing.this.videoCapture.stop();
                }
                // monitorexit(Capturing.access$4(this.this$0))
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void queryStop() {
            this.isStopped = true;
        }

        public void pushFrame(final int textureID) {
            this.textureID = textureID;
            this.newFrameIsAvailable = true;
        }
    }
}
