package com.esc.storymaker.models;

public class Glob_Sticker {
    public static String SelectedTattooName = "";
}
