package com.esc.flashlight.activity;

import android.database.Cursor;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.SearchView.OnCloseListener;
import androidx.appcompat.widget.SearchView.OnQueryTextListener;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.MenuItemCompat;

import com.esc.flashlight.R;
import com.esc.flashlight.database.DBAdapterFilteredPackages;
import com.esc.flashlight.fragment.FilterModeDialogFragment;
import com.esc.flashlight.util.AppIconProvider;
import com.esc.flashlight.util.PackageData;
import com.esc.flashlight.util.RakeInstalledPackage;
import com.esc.flashlight.util.SoundSearcher;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class AppFilterActivity extends BaseActivity {
    private static final String TAG = "AppFilterActivity";
    private static int[] f9x92f2159a;

    public boolean activate;

    public MyAdapter adapter;
    private DBAdapterFilteredPackages dbAdapter;

    public TextView ibSort;

    public LinkedList<PackageData> mCurrentPackageList;

    public LinkedList<PackageData> mDisplayPackageList;

    public FilteredOption mFilteredOption = FilteredOption.ALL;

    public ArrayList<String> mFilteredPackages;

    public String mKeyword;

    public ListView mListView;

    public PackageData[] mPackageListAll;

    public ProgressBar mProgressBar;
    private SearchView mSearchView;

    ImageView ivback;

    class C01731 implements OnClickListener {
        public void onClick(View view) {
        }

        C01731() {
        }
    }

    class C02422 implements OnCloseListener {
        public boolean onClose() {
            return false;
        }

        C02422() {
        }
    }

    class C02433 implements OnQueryTextListener {
        public boolean onQueryTextSubmit(String str) {
            return true;
        }

        C02433() {
        }

        public boolean onQueryTextChange(String str) {
            AppFilterActivity.this.mKeyword = str;
            AppFilterActivity.this.initDisplayPackageSearchedList();
            AppFilterActivity.this.adapter.notifyDataSetChanged();
            return false;
        }
    }

    class C02444 implements RakeInstalledPackage.RakeInstalledPackageListener {
        C02444() {
        }

        public void onStart() {
            if (AppFilterActivity.this.activate) {
                try {
                    Toast.makeText(AppFilterActivity.this.getApplicationContext(), "Extracting...", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void onComplete(PackageData[] packageDataArr) {
            if (!AppFilterActivity.this.isFinishing()) {
                try {
                    AppFilterActivity.this.mProgressBar.setVisibility(View.INVISIBLE);
                    Toast.makeText(AppFilterActivity.this.getApplicationContext(), "Complete.", Toast.LENGTH_SHORT).show();
                    AppFilterActivity.this.mPackageListAll = packageDataArr;
                    AppFilterActivity.this.mCurrentPackageList = new LinkedList();
                    AppFilterActivity.this.ibSort.setText(AppFilterActivity.this.getString(R.string.all));
                    AppFilterActivity.this.initDisplayPackageList();
                    AppFilterActivity.this.adapter = new MyAdapter();
                    AppFilterActivity.this.mListView.setAdapter(AppFilterActivity.this.adapter);
                    AppFilterActivity.this.ibSort.setEnabled(true);
                    AppFilterActivity.this.ibSort.setClickable(true);
                    AppFilterActivity.this.ibSort.setFocusable(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class CheckListener implements OnCheckedChangeListener {
        private CheckListener() {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            AppFilterActivity.this.onCheckedChange(((Integer) compoundButton.getTag()).intValue(), z);
        }
    }

    public enum FilteredOption {
        ALL,
        SELECTED,
        DOWNLOADED,
        PRELOAD,
        IN_INTERNAL_STORAGE,
        IN_EXTERNAL_STORAGE
    }

    private class MyAdapter extends BaseAdapter {
        private CheckListener checkListener;
        private AppIconProvider lruCache;

        private class Wrapper {
            CompoundButton cbSelected;
            View f3v;
            ImageView ivIcon;
            TextView tvName;

            public Wrapper(View view) {
                this.f3v = view;
            }


            public void setLabel(String str) {
                if (this.tvName == null) {
                    this.tvName = this.f3v.findViewById(R.id.tv_application_name);
                }
                this.tvName.setText(str);
                this.tvName.setTypeface(ResourcesCompat.getFont(AppFilterActivity.this, R.font.my_font_bold));
            }


            public ImageView getImageVIew() {
                if (this.ivIcon == null) {
                    this.ivIcon = this.f3v.findViewById(R.id.iv_application_icon);
                }
                return this.ivIcon;
            }


            public void setCheckedChangeListener(CheckListener checkListener) {
                if (this.cbSelected == null) {
                    this.cbSelected = this.f3v.findViewById(R.id.cb_selected);
                }
                this.cbSelected.setOnCheckedChangeListener(checkListener);
            }


            public void setCheckBoxPosition(int i) {
                if (this.cbSelected == null) {
                    this.cbSelected = this.f3v.findViewById(R.id.cb_selected);
                }
                this.cbSelected.setTag(Integer.valueOf(i));
            }


            public void setSelected(boolean z) {
                if (this.cbSelected == null) {
                    this.cbSelected = this.f3v.findViewById(R.id.cb_selected);
                }
                this.cbSelected.setChecked(z);
            }
        }

        public long getItemId(int i) {
            return i;
        }

        public MyAdapter() {
            this.checkListener = new CheckListener();
            this.lruCache = new AppIconProvider(AppFilterActivity.this, 100, 0, 0);
        }

        public int getCount() {
            return AppFilterActivity.this.mDisplayPackageList.size();
        }

        public PackageData getItem(int i) {
            return AppFilterActivity.this.mDisplayPackageList.get(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            Wrapper wrapper;
            if (view == null) {
                view = LayoutInflater.from(AppFilterActivity.this.getApplicationContext()).inflate(R.layout.listitem_installed_applicaion, null);
                wrapper = new Wrapper(view);
                wrapper.setCheckedChangeListener(this.checkListener);
                view.setTag(wrapper);
            } else {
                wrapper = (Wrapper) view.getTag();
            }
            PackageData item = getItem(i);
            if (item != null) {
                wrapper.setLabel(item.label);
                wrapper.setCheckBoxPosition(i);
                this.lruCache.load(item.packageName, wrapper.getImageVIew());
                if (AppFilterActivity.this.mFilteredPackages == null || !AppFilterActivity.this.mFilteredPackages.contains(item.packageName)) {
                    wrapper.setSelected(false);
                } else {
                    wrapper.setSelected(true);
                }
            }
            return view;
        }
    }

    private class MyButtonClickListener implements OnClickListener {

        class C02451 implements FilterModeDialogFragment.OnSelectListener {
            C02451() {
            }

            public void onSelected(FilteredOption filteredOption, String str) {
                AppFilterActivity.this.mFilteredOption = filteredOption;
                AppFilterActivity.this.ibSort.setText(str);
                AppFilterActivity.this.initDisplayPackageList();
                AppFilterActivity.this.adapter.notifyDataSetChanged();
            }
        }

        private MyButtonClickListener() {
        }

        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.btn_deselect_all) {
                AppFilterActivity.this.performDeselectAll();
            } else if (id == R.id.btn_select_all) {
                AppFilterActivity.this.performSelectAll();
            } else if (id == R.id.ib_sort) {
                showFilterOptionSelectDialog();
            }
        }

        private void showFilterOptionSelectDialog() {
            String str = "select_dialog";
            FilterModeDialogFragment filterModeDialogFragment = (FilterModeDialogFragment) AppFilterActivity.this.getSupportFragmentManager().findFragmentByTag(str);
            if (filterModeDialogFragment == null) {
                filterModeDialogFragment = new FilterModeDialogFragment();
            }
            filterModeDialogFragment.setOnSelectListener(new C02451());
            filterModeDialogFragment.show(AppFilterActivity.this.getSupportFragmentManager(), str);
        }
    }

    private class MyListItemClickListener implements OnItemClickListener {
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        }

        private MyListItemClickListener() {
        }
    }


    static int[] m14x92f2159a() {
        int[] iArr = f9x92f2159a;
        if (iArr == null) {
            iArr = new int[FilteredOption.values().length];
            iArr[FilteredOption.ALL.ordinal()] = 1;
            iArr[FilteredOption.DOWNLOADED.ordinal()] = 3;
            iArr[FilteredOption.IN_EXTERNAL_STORAGE.ordinal()] = 6;
            iArr[FilteredOption.IN_INTERNAL_STORAGE.ordinal()] = 5;
            iArr[FilteredOption.PRELOAD.ordinal()] = 4;
            iArr[FilteredOption.SELECTED.ordinal()] = 2;
            f9x92f2159a = iArr;
        }
        return iArr;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.av_filter_setting_application);
        initDatas();
        initViews();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 82) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_filter, menu);
        MenuItem findItem = menu.findItem(R.id.action_search);
        if (VERSION.SDK_INT < 14) {
            MenuItemCompat.setShowAsAction(findItem, 10);
        }
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(findItem);
        this.mSearchView = searchView;
        EditText editText = searchView.findViewById(R.id.search_src_text);
        editText.setHint(getString(R.string.action_search));
        editText.setHintTextColor(getResources().getColor(R.color.search_hint_color));
        editText.setTextColor(getResources().getColor(R.color.white));
        editText.setTypeface(ResourcesCompat.getFont(this, R.font.my_font_bold));
        this.mSearchView.setOnSearchClickListener(new C01731());
        this.mSearchView.setOnCloseListener(new C02422());
        this.mSearchView.setOnQueryTextListener(new C02433());
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            if (VERSION.SDK_INT < 14) {
                finish();
            } else if (!this.mSearchView.isIconified()) {
                this.mSearchView.onActionViewCollapsed();
                this.mSearchView.setIconified(true);
            } else {
                finish();
            }
        }
        return true;
    }


    public void onResume() {
        super.onResume();
        this.activate = true;
    }


    public void onPause() {
        super.onPause();
        this.activate = false;
    }

    private void initDatas() {
        this.dbAdapter = new DBAdapterFilteredPackages(getApplicationContext());
        initFilteredPackageList();
        RakeInstalledPackage rakeInstalledPackage = new RakeInstalledPackage(this);
        rakeInstalledPackage.setRakeInstalledPackageListener(new C02444());
        rakeInstalledPackage.rakeUp();
    }

    private void initFilteredPackageList() {
        this.dbAdapter.open();
        Cursor fetchAll = this.dbAdapter.fetchAll();
        if (fetchAll != null) {
            int count = fetchAll.getCount();
            if (count > 0) {
                this.mFilteredPackages = new ArrayList<>(count);
                for (int i = 0; i < count && fetchAll.moveToNext(); i++) {
                    String string = fetchAll.getString(1);
                    this.mFilteredPackages.add(string);
                    Log.d(TAG, "filtered package: " + string);
                }
            } else {
                this.mFilteredPackages = new ArrayList<>();
            }
        }
        fetchAll.close();
        this.dbAdapter.close();
    }

    private void initViews() {
        ivback=findViewById(R.id.iv_back);
        this.mProgressBar = findViewById(R.id.progressBar);
        ListView listView = findViewById(R.id.listView);
        this.mListView = listView;
        listView.setOnItemClickListener(new MyListItemClickListener());
        MyButtonClickListener myButtonClickListener = new MyButtonClickListener();
        TextView textView = findViewById(R.id.ib_sort);
        this.ibSort = textView;
        textView.setEnabled(false);
        this.ibSort.setClickable(false);
        this.ibSort.setFocusable(false);
        this.ibSort.setOnClickListener(myButtonClickListener);
        findViewById(R.id.btn_select_all).setOnClickListener(myButtonClickListener);
        findViewById(R.id.btn_deselect_all).setOnClickListener(myButtonClickListener);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    public void performSelectAll() {
        LinkedList<PackageData> linkedList = this.mCurrentPackageList;
        if (linkedList != null && linkedList.size() != 0) {
            this.dbAdapter.open();
            Iterator it = this.mCurrentPackageList.iterator();
            while (it.hasNext()) {
                PackageData packageData = (PackageData) it.next();
                if (!this.mFilteredPackages.contains(packageData.packageName)) {
                    this.dbAdapter.insert(packageData.packageName);
                    this.mFilteredPackages.add(packageData.packageName);
                }
            }
            this.dbAdapter.close();
            this.adapter.notifyDataSetChanged();
        }
    }


    public void performDeselectAll() {
        LinkedList<PackageData> linkedList = this.mCurrentPackageList;
        if (linkedList != null && linkedList.size() != 0) {
            this.dbAdapter.open();
            Iterator it = this.mCurrentPackageList.iterator();
            while (it.hasNext()) {
                PackageData packageData = (PackageData) it.next();
                if (this.mFilteredPackages.contains(packageData.packageName)) {
                    Cursor fetch = this.dbAdapter.fetch(packageData.packageName);
                    if (fetch != null && fetch.getCount() > 0) {
                        this.dbAdapter.delete(fetch.getLong(0));
                        this.mFilteredPackages.remove(packageData.packageName);
                    }
                }
            }
            this.dbAdapter.close();
            this.adapter.notifyDataSetChanged();
        }
    }


    public void onCheckedChange(int i, boolean z) {
        String str = this.mDisplayPackageList.get(i).packageName;
        this.dbAdapter.open();
        Cursor fetch = this.dbAdapter.fetch(str);
        if (z) {
            if (fetch != null && fetch.getCount() < 1) {
                this.dbAdapter.insert(str);
            }
            if (!this.mFilteredPackages.contains(str)) {
                this.mFilteredPackages.add(str);
            }
        } else {
            if (fetch != null && fetch.getCount() > 0) {
                this.dbAdapter.delete(fetch.getLong(0));
            }
            this.mFilteredPackages.remove(str);
        }
        fetch.close();
        this.dbAdapter.close();
    }


    public void initDisplayPackageSearchedList() {
        String str = this.mKeyword;
        if (str == null || str.length() == 0) {
            this.mDisplayPackageList = this.mCurrentPackageList;
            return;
        }
        LinkedList<PackageData> linkedList = this.mDisplayPackageList;
        if (linkedList == null || linkedList == this.mCurrentPackageList) {
            this.mDisplayPackageList = new LinkedList<>();
        } else {
            linkedList.clear();
        }
        Iterator it = this.mCurrentPackageList.iterator();
        while (it.hasNext()) {
            PackageData packageData = (PackageData) it.next();
            if (SoundSearcher.matchString(packageData.label, this.mKeyword)) {
                this.mDisplayPackageList.add(packageData);
            }
        }
    }


    public void initDisplayPackageList() {
        PackageData[] packageDataArr;
        LinkedList<PackageData> linkedList = this.mCurrentPackageList;
        if (linkedList == null) {
            this.mCurrentPackageList = new LinkedList<>();
        } else {
            linkedList.clear();
        }
        for (PackageData packageData : this.mPackageListAll) {
            int i = m14x92f2159a()[this.mFilteredOption.ordinal()];
            boolean z = true;
            if (i == 2) {
                ArrayList<String> arrayList = this.mFilteredPackages;
                if (arrayList == null || arrayList.size() == 0) {
                    initDisplayPackageSearchedList();
                    return;
                } else if (this.mCurrentPackageList.size() != this.mFilteredPackages.size()) {
                    ArrayList<String> arrayList2 = this.mFilteredPackages;
                    if (arrayList2 == null || !arrayList2.contains(packageData.packageName)) {
                        z = false;
                    }
                } else {
                    initDisplayPackageSearchedList();
                    return;
                }
            } else if (i == 3) {
                z = packageData.thirdParty;
            } else if (i == 4) {
                z = true ^ packageData.thirdParty;
            }
            if (z) {
                this.mCurrentPackageList.add(packageData);
            }
        }
        initDisplayPackageSearchedList();
    }

    public void onBackPressed() {
        if (VERSION.SDK_INT < 14) {
            super.onBackPressed();
        } else if (this.mSearchView.isIconified()) {
            super.onBackPressed();
        } else {
            this.mSearchView.onActionViewCollapsed();
            this.mSearchView.setIconified(true);
        }
    }
}
