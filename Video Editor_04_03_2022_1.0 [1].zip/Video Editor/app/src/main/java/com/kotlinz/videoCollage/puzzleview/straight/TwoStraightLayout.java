package com.kotlinz.videoCollage.puzzleview.straight;

import android.util.Log;

import com.kotlinz.videoCollage.flying.puzzle.Line;

public class TwoStraightLayout extends NumberStraightLayout {
    private float mRadio = 0.5f;

    public int getThemeCount() {
        return 6;
    }

    public TwoStraightLayout(int i) {
        super(i);
    }

    public TwoStraightLayout(float f, int i) {
        super(i);
        if (0.5f > 1.0f) {
            Log.e("NumberStraightLayout", "CrossLayout: the radio can not greater than 1f");
            this.mRadio = 1.0f;
        }
        this.mRadio = f;
    }

    public void layout() {
        int i = this.theme;
        if (i == 0) {
            addLine(0, Line.Direction.HORIZONTAL, this.mRadio);
        } else if (i == 1) {
            addLine(0, Line.Direction.VERTICAL, this.mRadio);
        } else if (i == 2) {
            addLine(0, Line.Direction.HORIZONTAL, 0.33333334f);
        } else if (i == 3) {
            addLine(0, Line.Direction.HORIZONTAL, 0.6666667f);
        } else if (i == 4) {
            addLine(0, Line.Direction.VERTICAL, 0.33333334f);
        } else if (i != 5) {
            addLine(0, Line.Direction.HORIZONTAL, this.mRadio);
        } else {
            addLine(0, Line.Direction.VERTICAL, 0.6666667f);
        }
    }
}
