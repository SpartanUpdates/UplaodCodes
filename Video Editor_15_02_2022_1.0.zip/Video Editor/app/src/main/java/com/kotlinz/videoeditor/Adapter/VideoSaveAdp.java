package com.kotlinz.videoeditor.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.IntentData;
import com.kotlinz.videoeditor.activity.PreviewImageActivity;
import com.kotlinz.videoeditor.activity.ShareVideoActivity;


import java.io.File;
import java.util.ArrayList;

public class VideoSaveAdp extends Adapter<VideoSaveAdp.MyViewHolder> {
    private final Activity context;
    private final ArrayList<String> listFile;
    public setOnItemClickListener sClickListener;

    public interface setOnItemClickListener {
        void onItemClick(int i);
    }

    public class MyViewHolder extends ViewHolder /*implements OnClickListener*/ {
        private final AppCompatImageView ImgC_Video;
        private final AppCompatImageView ImgC_videoDelete;
        private final AppCompatTextView TVC_videoNm;
        private final AppCompatImageView videoshare;

        public MyViewHolder(View view) {
            super(view);
            TVC_videoNm = view.findViewById(R.id.TVC_videoNm);
            ImgC_Video = view.findViewById(R.id.ImgC_Video);
            ImgC_videoDelete = view.findViewById(R.id.ImgC_videoDelete);
            videoshare = view.findViewById(R.id.ImgC_videoshare);
        }
    }

    public VideoSaveAdp(Activity activity, ArrayList<String> arrayList) {
        this.context = activity;
        this.listFile = arrayList;
    }

    public void setOnItemClickListener(setOnItemClickListener setonitemclicklistener) {
        this.sClickListener = setonitemclicklistener;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.photo_video_creation, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") int i) {
        String str = listFile.get(i);
        myViewHolder.TVC_videoNm.setText(str.substring(str.lastIndexOf(47) + 1));
        final String str2 = listFile.get(i);
        Glide.with(context).load(Uri.fromFile(new File(str2))).apply(new RequestOptions().transform(new RoundedCorners(10)).error(R.drawable.ic_back).skipMemoryCache(true).diskCacheStrategy(DiskCacheStrategy.NONE)).into(myViewHolder.ImgC_Video);

        myViewHolder.ImgC_Video.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String ImageExtension = listFile.get(i).substring(listFile.get(i).lastIndexOf("."));
                if (ImageExtension.equals(".jpg")) {
                    Intent intent = new Intent(context, PreviewImageActivity.class);
                    intent.putExtra("ImagePath", listFile.get(i));
                    context.startActivity(intent);
                    context.finish();
                } else {
                    IntentData intentData = new IntentData();
                    intentData.setDataBoln(false);
                    intentData.setDataStr(str2);

                    Intent intent = new Intent(context, ShareVideoActivity.class);
                    intent.putExtra("mIntentData", intentData);
                    context.startActivity(intent);
                    context.finish();
                }
            }
        });

        /*myViewHolder.ImgC_videoDelete.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AppDialog);
                AlertDialog dialog = builder.create();
                if (dialog != null && !dialog.isShowing()) {
                    try {
                        builder.setTitle(R.string.deletetitle);
                        builder.setMessage(String.valueOf(context.getResources().getString(R.string.deleteMessage)) + " " + " ?");
                        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int which) {
                                Log.e("TAG", "Delete Called");
                                try {
                                    itemRemoved(i);
                                    FileUtils.deleteFile(new File(listFile.get(i)));
                                    notifyDataSetChanged();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        final AlertDialog finalDialog = dialog;
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finalDialog.dismiss();
                            }
                        });
                        dialog = builder.create();
                        dialog.show();
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(context.getResources().getColor(R.color.bg_main_color));
                        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(context.getResources().getColor(R.color.bg_main_color));
                        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(context.getResources().getColor(R.color.bg_main_color));
                    } catch (Resources.NotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        });*/

        myViewHolder.videoshare.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  Intent intent = new Intent();
                intent.setType("video/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Complete action using"), 1);*/
            }
        });
    }

    public void itemRemoved(int pos) {
        if ((listFile != null) && (listFile.size() > 0)) {
            listFile.remove(pos);
        }
    }

    public int getItemCount() {
        return this.listFile.size();
    }
}
