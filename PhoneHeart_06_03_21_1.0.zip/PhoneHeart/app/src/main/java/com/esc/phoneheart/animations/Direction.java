package com.esc.phoneheart.animations;

public enum Direction {
    CW,
    CCW
}
