package com.UnitedVideos.CropImage.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.UnitedVideos.ArrangeImages.activity.ArrangePhotosActivityUv;
import com.UnitedVideos.CropImage.bitmapUtil.Utils;
import com.UnitedVideos.CropImage.cropoverlay.CropOverlayView;
import com.UnitedVideos.CropImage.photoview.IGetImageBounds;
import com.UnitedVideos.CropImage.photoview.PhotoView;
import com.UnitedVideos.CropImage.photoview.RotationSeekBar;
import com.UnitedVideos.ImageSelection.activity.SelectImageActivityUv;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.App.MyApplication;
import com.wavymusic.R;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ImageCropActivityUv extends AppCompatActivity {

    public static final String TAG = "ImageCropActivity";
    private static final int ANCHOR_CENTER_DELTA = 10;
    PhotoView mImageView;
    CropOverlayView mCropOverlayView;
    RotationSeekBar mRotationBar;
    private ContentResolver mContentResolver;
    private final int IMAGE_MAX_SIZE = 1024;
    private final Bitmap.CompressFormat mOutputFormat;
    private String mImagePath;
    private Uri mSaveUri;
    private Uri mImageUri;
    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    public static final int REQUEST_CODE_PICK_GALLERY = 1;
    public static final int REQUEST_CODE_TAKE_PICTURE = 2;
    public static final int REQUEST_CODE_CROPPED_PICTURE = 3;
    public static final String ERROR_MSG = "error_msg";
    public static final String ERROR = "error";
    String[] mAllPath;
    String mConcatPath;
    int last_crop_idx;
    Utils mUtils;
    String save_path;
    ArrayList<String> mAllSavePath;
    int pera_h;
    int pera_w;
    public static int flag;
    RelativeLayout rl_skip;
    RelativeLayout rl_undo;
    RelativeLayout rl_crop;
    TextView tvtitle;
    TextView tv_skip;
    TextView tv_instruct_line_one;
    TextView tv_instruct_line_two;
    ImageView ivback;
    Toolbar toolbar;
    SeekBar sb_skipall;
    RelativeLayout rl_progress;
    public int SkipAllPercent;
    public boolean IsSkipAllEnable;
    TextView tv_skipall_prg;
    RelativeLayout rl_skipall_root, rl_AutoCrop;
    private View.OnClickListener btnDoneListerner;
    private View.OnClickListener btnResetListerner;
    private View.OnClickListener btnSkipListener;
    private View.OnClickListener btnSkipAllListener;
    private MyApplication application;
    String iscut;
    String isfrom;

    public ImageCropActivityUv() {
        this.mOutputFormat = Bitmap.CompressFormat.JPEG;
        this.mSaveUri = null;
        this.mImageUri = null;
        this.mConcatPath = "";
        this.last_crop_idx = -1;
        this.save_path = null;
        this.mAllSavePath = new ArrayList<String>();
        this.pera_h = -1;
        this.pera_w = -1;
        this.SkipAllPercent = 0;
        this.IsSkipAllEnable = false;
        this.btnDoneListerner = new View.OnClickListener() {
            public void onClick(final View v) {
                new SaveSingleAsynk().execute();
            }
        };
        this.btnResetListerner = new View.OnClickListener() {
            public void onClick(final View v) {
                ImageCropActivityUv.this.mRotationBar.reset();
                ImageCropActivityUv.this.mImageView.reset();
            }
        };
        this.btnSkipListener = new View.OnClickListener() {
            public void onClick(final View v) {
                ImageCropActivityUv.this.makeSingleSkip();
            }
        };

        this.btnSkipAllListener = new View.OnClickListener() {
            public void onClick(final View v) {
                MyApplication.SkipAll = true;
                ImageCropActivityUv.this.rl_skipall_root.setVisibility(View.VISIBLE);
                ImageCropActivityUv.this.slideUpDown();
                ImageCropActivityUv.this.IsSkipAllEnable = true;
                final Handler mAnimHandler = new Handler();
                mAnimHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        new SaveSingleAsynk().execute();
                    }
                }, 600L);
            }
        };

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_crop);
        application = MyApplication.getInstance();
        MyApplication.SkipAll = false;
        ImageCropActivityUv.flag = 0;
        this.mUtils = new Utils();
        iscut = getIntent().getStringExtra("isCut");
        isfrom = getIntent().getStringExtra("isfrom");
        PutAnalyticsEvent();
        bindView();
        SetListener();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageCropActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void bindView() {
        mContentResolver = this.getContentResolver();
        mImageView = this.findViewById(R.id.iv_photo);
        mCropOverlayView = this.findViewById(R.id.crop_overlay);
        final int[] hw = this.getIntent().getIntArrayExtra("hw");
        pera_h = hw[0];
        pera_w = hw[1];
        CropOverlayView.setHW(this.pera_h, this.pera_w);
        mCropOverlayView.init(this);
        rl_skip = this.findViewById(R.id.rlSkipSingleForActivityCrop);
        rl_undo = this.findViewById(R.id.rlUndoForImageCrop);
        rl_crop = this.findViewById(R.id.rlCropForImgCrop);
        rl_AutoCrop = findViewById(R.id.rlAutocrop);
        tvtitle = findViewById(R.id.tool_title);
        ivback = findViewById(R.id.ivBack);
        mRotationBar = this.findViewById(R.id.slider_view_seek_bar);
        rl_skip.setOnClickListener(this.btnSkipListener);
        rl_AutoCrop.setOnClickListener(this.btnSkipAllListener);
        rl_crop.setOnClickListener(this.btnDoneListerner);
        rl_undo.setOnClickListener(this.btnResetListerner);
        toolbar = this.findViewById(R.id.toolbar);
        tv_skip = this.findViewById(R.id.tv_skip);
        tv_instruct_line_one = this.findViewById(R.id.tv_instruct_line_one);
        tv_instruct_line_two = this.findViewById(R.id.tv_instruct_line_two);
        rl_progress = this.findViewById(R.id.rl_progress);
        (sb_skipall = this.findViewById(R.id.sb_skipall)).setEnabled(false);
        tv_skipall_prg = this.findViewById(R.id.tv_skipall_prg);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void SetListener() {
        (rl_skipall_root = this.findViewById(R.id.rl_skipall_root)).setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(final View arg0, final MotionEvent arg1) {
                return true;
            }
        });
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        mImageView.setImageBoundsListener(new IGetImageBounds() {
            @Override
            public Rect getImageBounds() {
                return ImageCropActivityUv.this.mCropOverlayView.getImageBounds();
            }
        });
        mRotationBar.setOnSeekBarChangeListener(new RotationSeekBar.OnRotationSeekBarChangeListener(this.mRotationBar) {
            private float mLastAngle;

            @Override
            public void onRotationProgressChanged(@NonNull final RotationSeekBar seekBar, final float angle, final float delta, final boolean fromUser) {
                mLastAngle = angle;
                if (fromUser) {
                    ImageCropActivityUv.this.mImageView.setRotationBy(delta, false);
                }
            }

            @Override
            public void onStopTrackingTouch(final SeekBar seekBar) {
                super.onStopTrackingTouch(seekBar);
                if (Math.abs(mLastAngle) < 10.0f) {
                    ImageCropActivityUv.this.mRotationBar.reset();
                    ImageCropActivityUv.this.mImageView.setRotationBy(0.0f, true);
                }
            }
        });
        setImageBunch();
    }


    protected void onStart() {
        super.onStart();
    }

    private void init() {
        final Bitmap bitmap = this.getBitmap(this.mImageUri);
        final Drawable drawable = new BitmapDrawable(this.getResources(), bitmap);
        final float minScale = this.mImageView.setMinimumScaleToFit(drawable);
        this.mImageView.setMaximumScale(minScale * 3.0f);
        this.mImageView.setMediumScale(minScale * 2.0f);
        this.mImageView.setScale(minScale);
        this.mImageView.setImageDrawable(drawable);
        if (this.IsSkipAllEnable) {
            final Handler mLayoutHandler = new Handler();
            mLayoutHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    new SaveSingleAsynk().execute();
                }
            }, 500L);
        }
    }

    public boolean saveCropResult() {
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        final String file_path = this.getOutFilePath(this.mAllPath[this.last_crop_idx], this.last_crop_idx);
        Bitmap croppedImage = null;
        try {
            croppedImage = this.mImageView.getCroppedImage();
            this.mSaveUri = Utils.getImageUri(file_path);
            if (this.mSaveUri != null) {
                OutputStream outputStream = null;
                try {
                    outputStream = this.mContentResolver.openOutputStream(this.mSaveUri);
                    if (outputStream != null) {
                        croppedImage.compress(this.mOutputFormat, 90, outputStream);
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                } finally {
                    this.closeSilently(outputStream);
                }
                this.closeSilently(outputStream);
                this.mAllSavePath.add(file_path);
                croppedImage.recycle();
                return true;
            }
            return false;
        } catch (IllegalArgumentException e) {
            return false;
        } catch (Exception e2) {
            return false;
        }
    }

    public void slideUpDown() {
        if (!this.isPanelShown()) {
            final Animation bottomUp = AnimationUtils.loadAnimation(this, R.anim.player_bottom_up);
            this.rl_progress.setVisibility(View.VISIBLE);
            this.rl_progress.startAnimation(bottomUp);
        } else {
            final Animation bottomDown = AnimationUtils.loadAnimation(this, R.anim.player_bottom_down);
            this.rl_progress.startAnimation(bottomDown);
            this.rl_progress.setVisibility(View.GONE);
        }
    }

    private boolean isPanelShown() {
        return this.rl_progress.getVisibility() == View.VISIBLE;
    }

    public void makeSingleSkip() {
        final File src = new File(this.mAllPath[this.last_crop_idx]);
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        final String file_path = this.getOutFilePath(this.mAllPath[this.last_crop_idx], this.last_crop_idx);
        final File dst = new File(file_path);
        try {
            Utils.copy(src, dst);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.mAllSavePath.add(file_path);
        this.startCropFor();
    }

    public void saveSkipAll() {
        final int startIdx = this.mAllSavePath.size();
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        for (int i = startIdx; i < this.mAllPath.length; ++i) {
            final File src = new File(this.mAllPath[i]);
            final String file_path = this.getOutFilePath(this.mAllPath[i], i);
            final File dst = new File(file_path);
            try {
                Utils.copy(src, dst);
                this.mAllSavePath.add(file_path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void setImageBunch() {
        String ConcatPath = null;
        ConcatPath = this.getIntent().getStringExtra("path");
        if (!ConcatPath.equals("")) {
            final String[] allPath = ConcatPath.split("\\" + MyApplication.SPLIT_PATTERN);
            mAllPath = allPath;
            mConcatPath = ConcatPath;
            startCropFor();
        } else {
            Toast.makeText(this, "No Img Found", Toast.LENGTH_SHORT).show();
        }
    }

    public void startCropFor() {
        ++this.last_crop_idx;
        if (this.last_crop_idx < this.mAllPath.length) {
            this.mImagePath = this.mAllPath[this.last_crop_idx];
            this.mSaveUri = Utils.getImageUri(this.mImagePath);
            this.mImageUri = Utils.getImageUri(this.mImagePath);
            init();
        } else {
            this.last_crop_idx = this.mAllPath.length - 1;
            this.startResultAct();
        }
    }

    public void startResultAct() {
        if (this.mAllSavePath.size() > 0) {
            String result_conc = "";
            result_conc = this.mAllSavePath.get(0);
            for (int i = 0; i < this.mAllSavePath.size(); ++i) {
                result_conc = result_conc + MyApplication.SPLIT_PATTERN + this.mAllSavePath.get(i);
                application.AddCropImagesUV(mAllSavePath.get(i));
            }

            Intent intent = new Intent(ImageCropActivityUv.this, ArrangePhotosActivityUv.class);
            intent.putExtra("hight", pera_h);
            intent.putExtra("width", pera_w);
            intent.putExtra("isCut", iscut);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            ImageCropActivityUv.this.finish();
        } else {
            Toast.makeText(this, "No Img Found", Toast.LENGTH_SHORT).show();
        }
    }

    public String getOutFilePath(final String inPath, final int count) {
        final File forname = new File(inPath);
        String ext = forname.getName();
        ext = ext.substring(ext.lastIndexOf("."));
        final String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        final String file_path = this.save_path + timeStamp + "_" + count + "_" + ext;
        return file_path;
    }

    public void onSaveInstanceState(final Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putBoolean("restoreState", true);
    }

    private Bitmap getBitmap(final Uri uri) {
        InputStream in = null;
        Bitmap returnedBitmap = null;
        try {
            in = this.mContentResolver.openInputStream(uri);
            final BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int scale = 1;
            if (o.outHeight > 1024 || o.outWidth > 1024) {
                scale = (int) Math.pow(2.0, (int) Math.round(Math.log(1024.0 / Math.max(o.outHeight, o.outWidth)) / Math.log(0.5)));
            }
            final BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            in = this.mContentResolver.openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            final ExifInterface ei = new ExifInterface(uri.getPath());
            final int orientation = ei.getAttributeInt("Orientation", 1);
            switch (orientation) {
                case 6: {
                    returnedBitmap = this.rotateImage(bitmap, 90.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                case 3: {
                    returnedBitmap = this.rotateImage(bitmap, 180.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                case 8: {
                    returnedBitmap = this.rotateImage(bitmap, 270.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                default: {
                    returnedBitmap = bitmap;
                    break;
                }
            }
            return returnedBitmap;
        } catch (FileNotFoundException e) {
            Log.e("", "ERR " + e);
        } catch (IOException e2) {
            Log.e("", "ERR " + e2);
        }
        return null;
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(final MenuItem item) {
        final int itmId = item.getItemId();
        if (itmId == 16908332) {
//            super.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void closeSilently(final Closeable c) {
        if (c == null) {
            return;
        }
        try {
            c.close();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private Bitmap rotateImage(final Bitmap source, final float angle) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    class SaveSingleAsynk extends AsyncTask<Void, Void, Void> {
        ProgressDialog pDialog;
        boolean isCropSuccess;
        int fullLen;

        SaveSingleAsynk() {
            this.isCropSuccess = false;
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.fullLen = ImageCropActivityUv.this.mAllPath.length;
            ImageCropActivityUv.this.rl_crop.setEnabled(false);
            ImageCropActivityUv.this.tv_skipall_prg.setText((last_crop_idx + 1) + "/" + this.fullLen);
            ImageCropActivityUv.this.SkipAllPercent = (ImageCropActivityUv.this.last_crop_idx + 1) * 100 / this.fullLen;
            ImageCropActivityUv.this.sb_skipall.setProgress(ImageCropActivityUv.this.SkipAllPercent);
        }

        protected Void doInBackground(final Void... arg0) {
            this.isCropSuccess = ImageCropActivityUv.this.saveCropResult();
            return null;
        }

        protected void onPostExecute(final Void result) {
            super.onPostExecute(result);
            ImageCropActivityUv.this.mRotationBar.reset();
            ImageCropActivityUv.this.mImageView.reset();
            ImageCropActivityUv.this.rl_crop.setEnabled(true);
            if (this.pDialog != null && this.pDialog.isShowing()) {
                this.pDialog.dismiss();
            }
            ImageCropActivityUv.this.tv_skipall_prg.setText((last_crop_idx + 1) + "/" + this.fullLen);
            ImageCropActivityUv.this.SkipAllPercent = (ImageCropActivityUv.this.last_crop_idx + 1) * 100 / this.fullLen;
            ImageCropActivityUv.this.sb_skipall.setProgress(ImageCropActivityUv.this.SkipAllPercent);
            if (this.isCropSuccess) {
                ImageCropActivityUv.this.startCropFor();
            } else {
                ImageCropActivityUv.this.makeSingleSkip();
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        application.IsBack = true;
        Intent intent = new Intent(ImageCropActivityUv.this, SelectImageActivityUv.class);
        intent.putExtra("hight", pera_h);
        intent.putExtra("width", pera_w);
        intent.putExtra("isCut", iscut);
        intent.putExtra("isfrom", isfrom);
        startActivity(intent);
        finish();
    }
}