package com.example.lyricsvideo.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.RequestManager;
import com.example.lyricsvideo.activity.SelectImageActivity;
import com.example.lyricsvideo.Interface.OnItemClickListner;
import com.example.lyricsvideo.Model.ImageInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.application.App;

public class AlbumWiseImageAdapter extends RecyclerView.Adapter<AlbumWiseImageAdapter.Holder> {
    private App application;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> itemClickListner;
    private RequestManager glidemanager;
    private SelectImageActivity activity;

    public AlbumWiseImageAdapter(Context context) {
        application = App.getInstance();
        inflater = LayoutInflater.from(context);
        glidemanager = com.bumptech.glide.Glide.with(context);
        activity = ((SelectImageActivity) context);
    }

    public void setOnItemClickListner(OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }


    public int getItemCount() {
        return application.getImageByAlbum(application.getSelectedFolderId()).size();
    }

    public ImageInfo getItem(int pos) {
        return application.getImageByAlbum(application.getSelectedFolderId()).get(pos);
    }


    public void onBindViewHolder(@NonNull final Holder holder, @SuppressLint("RecyclerView") final int pos) {
        final ImageInfo data = this.getItem(pos);
        holder.tvImageCount.setSelected(true);
        holder.tvImageCount.setText((data.NoOfImage == 0) ? "" : String.format("%02d", data.NoOfImage));
//        Font.SetTextFont(this.ActivityOfTheme, holder.tvImageCount);
        this.glidemanager.load(data.ImagePath).into(holder.ivThumbline);
        holder.tvImageCount.setBackgroundColor((data.NoOfImage == 0) ? 0 : this.activity.getResources().getColor(R.color.counter_color));

        holder.ViewImageSelect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (holder.ivThumbline.getDrawable() == null) {
                    Toast.makeText(application, "Image currpted or not support.", Toast.LENGTH_LONG).show();
                    return;
                }
                if (application.getSelectedImageslist().size() < App.TotalSelectedImage) {
                    application.addSelectedImage(data);
                    notifyItemChanged(pos);
                } else {
                    Toast.makeText(application, "Please Select only " + App.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                }
                if (itemClickListner != null) {
                    itemClickListner.onItemClick(v, data);
                }
            }
        });
    }
    public class Holder extends RecyclerView.ViewHolder {
        ImageView ivThumbline;
        TextView tvImageCount;
        View view;
        View ViewImageSelect;

        public Holder(View v) {
            super(v);
            view = v;
            ivThumbline = v.findViewById(R.id.ivImagethumbline);
            tvImageCount = v.findViewById(R.id.tv_image_count);
            ViewImageSelect = v.findViewById(R.id.Clickview);
        }

        public void onItemClick(View view, Object item) {
            if (itemClickListner != null) {
                itemClickListner.onItemClick(view, item);
            }
        }
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int pos) {
        return new Holder(inflater.inflate(R.layout.row_items_by_album_wise, parent,
                false));
    }
}
