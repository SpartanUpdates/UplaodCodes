package com.kotlinz.videoeditor.Interface;

import android.view.View;

public abstract interface OnItemClickListner<T> {
    public abstract void onItemClick(View paramView, T paramT);
}