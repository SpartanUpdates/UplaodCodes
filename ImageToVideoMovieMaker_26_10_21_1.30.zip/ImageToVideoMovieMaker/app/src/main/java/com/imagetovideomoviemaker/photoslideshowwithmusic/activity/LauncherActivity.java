package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.AppUpdate.Constants;
import com.imagetovideomoviemaker.AppUpdate.InAppUpdateManager;
import com.imagetovideomoviemaker.AppUpdate.InAppUpdateStatus;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.service.CreateVideoService;
import com.imagetovideomoviemaker.photoslideshowwithmusic.service.ImageCreatorService;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.EPreferences;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.PermissionModelUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.org.codechimp.apprater.AppRater;
import com.xyz.imagetovideomoviewmaker.R;
import static com.imagetovideomoviemaker.photoslideshowwithmusic.NativeAds.nativeads.populateUnifiedNativeAdView;

public class LauncherActivity extends AppCompatActivity implements OnClickListener,InAppUpdateManager.InAppUpdateHandler {
    Activity activity = LauncherActivity.this;
    static int f37i;
    public static LauncherActivity MainActivity;
    ComponentName SecurityComponentName = null;
    EPreferences ePref;
    PermissionModelUtil modelUtil;
    View view;
    Toolbar toolbar;
    TextView tvToolbarTitle;

    //App Update
    private static final int REQ_CODE_VERSION_UPDATE = 530;
    private InAppUpdateManager inAppUpdateManager;

    private NativeAd nativeAd;



    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isVideoInprocess()) {
            startActivity(new Intent(this, ProgressActivity.class));
            overridePendingTransition(0, 0);
            finish();
            return;
        }
        setContentView(R.layout.activity_home_main);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LauncherActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        ePref = EPreferences.getInstance(this);
        inAppUpdateManager = InAppUpdateManager.Builder(this, REQ_CODE_VERSION_UPDATE).resumeUpdates(true).mode(Constants.UpdateMode.FLEXIBLE).handler(this);
        setActionBar();
        init();
        addListener();
        LoadNativeAds();
        MyApplication.getInstance().setAutostartAppName();
        if (MyApplication.getInstance().runApp(Utils.autostart_app_name, 0) && !this.check_permission()) {
            this.permissionDialog();
        }
        AppRater.setPackageName(this.getPackageName());
        AppRater.app_launched(this);
    }


    public boolean check_permission() {
        return this.ePref.getBoolean("HasAutoStartPermission", false);
    }


    private void permissionDialog() {
        String str = Build.MANUFACTURER;
        if (str.equals("Xiaomi")) {
            SecurityComponentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
            Utils.autostart_app_name = "Security";
        } else if (str.equals("asus")) {
            SecurityComponentName = new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity");
            Utils.autostart_app_name = "Auto-start Manager";
        }
        Intent intent = new Intent(this, CustomPermissionActivity.class);
        intent.putExtra("PACKAGE", this.SecurityComponentName);
        intent.putExtra("APPNAME", Utils.autostart_app_name);
        startActivity(intent);
    }


    private boolean isVideoInprocess() {
        return MyApplication.isMyServiceRunning(this, CreateVideoService.class) || MyApplication.isMyServiceRunning(this, ImageCreatorService.class);
    }

    private void init() {
        MainActivity = this;
        Utils.isVideoCreationRunning = true;
        if (Utils.checkPermission(this)) {
            MyApplication.getInstance().getFolderList();
        } else {
            Utils.requestPermission(this);
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(307);
    }

    protected void onResume() {
        super.onResume();
        if (f37i == 1) {
            f37i = 0;
            if (Utils.checkPermission(this)) {
                onStart();
            } else {
                Utils.requestPermission(this);
            }
        }
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int n, @NonNull final String[] array, @NonNull final int[] array2) {
        if (n != 222) {
            return;
        }
        if (array2.length > 0) {
            boolean b = false;
            if (array2[0] == 0) {
                n = 1;
            } else {
                n = 0;
            }
            if (array2[1] == 0) {
                b = true;
            }
            if (n != 0 && b) {
                MyApplication.getInstance().getFolderList();
                return;
            }
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE") && !ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                Utils.permissionDailog(this);
                return;
            }
            Utils.requestPermission(this);
        }
    }

    private void addListener() {
        findViewById(R.id.btnCreateVideo).setOnClickListener(this);
        findViewById(R.id.btnViewVideo).setOnClickListener(this);
        findViewById(R.id.btnChangeLang).setOnClickListener(this);
        findViewById(R.id.llRateus).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri
                            .parse("market://details?id=" + getApplicationContext().getPackageName())));
                } catch (ActivityNotFoundException ex) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri
                            .parse("http://play.google.com/store/apps/details?id="
                                    + getApplicationContext().getPackageName())));
                }
            }
        });
        findViewById(R.id.llshare).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ShareAPP();
            }
        });
        findViewById(R.id.llPolicy).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Intent.ACTION_VIEW);
                intent1.setData(Uri.parse("https://sites.google.com/site/slideshowsolutionpolicy/home"));
                startActivity(intent1);
            }
        });

    }


    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Wavy Music");
            String shareMessage = "\nGet free Image To Video Movie Maker at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }


    public void onClick(View view) {
        this.view = view;
        int id = view.getId();
        if (id != R.id.btnChangeLang) {
            if (id != R.id.btnCreateVideo) {
                if (id == R.id.btnViewVideo) {
                    if (Utils.checkPermission(this)) {
                        if (MyApplication.isShowAd == 0) {
                            if (MyApplication.mInterstitialAd != null) {
                                MyApplication.activity = activity;
                                MyApplication.AdsId = 101;
                                MyApplication.mInterstitialAd.show(activity);
                                MyApplication.isShowAd = 1;
                            } else {
                                ActivityAnimUtil.startActivitySafely(view, new Intent(this, VideoAlbumActivity.class));
                            }
                        } else {
                            ActivityAnimUtil.startActivitySafely(view, new Intent(this, VideoAlbumActivity.class));
                            MyApplication.isShowAd = 0;
                        }
                    }
                    Utils.requestPermission(this);
                }
            } else if (Utils.checkPermission(this)) {
                init();
                MyApplication.getInstance().getFolderList();
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    if (MyApplication.isShowAd == 0) {
                        if (MyApplication.mInterstitialAd != null) {
                            MyApplication.activity = activity;
                            MyApplication.AdsId = 101;
                            MyApplication.mInterstitialAd.show(activity);
                            MyApplication.isShowAd = 1;
                        } else {
                            ActivityAnimUtil.startActivitySafely(view, new Intent(activity, ImageSelectionActivity.class));
                        }
                    } else {
                        ActivityAnimUtil.startActivitySafely(view, new Intent(activity, ImageSelectionActivity.class));
                        MyApplication.isShowAd = 0;
                    }
                } else {
                    Toast.makeText(getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
                }
            } else {
                Utils.requestPermission(this);
            }
        } else if (Utils.checkPermission(this)) {
            loadLanguage(view);
        } else {
            this.modelUtil.showPermissionExplanationThenAuthorization();
        }
    }

    private void loadLanguage(View view) {
        ActivityAnimUtil.startActivitySafely(view, new Intent(this, LanguageActivity.class));
    }

    public void onBackPressed() {
        if (this.ePref.getBoolean("pref_key_rate", false)) {
            BackDialog();
        } else {
            RateDialog();
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(LauncherActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        TextView tvMessage;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (LauncherActivity.this.nativeAd != null) {
                            LauncherActivity.this.nativeAd.destroy();
                        }
                        LauncherActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        tvMessage = dialog.findViewById(R.id.tvPro);
        Utils.setFont(activity, tvMessage);
        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePref.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }


    public void BackDialog() {
        final Dialog dialog = new Dialog(LauncherActivity.this);
        TextView tvMessage;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_back);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (LauncherActivity.this.nativeAd != null) {
                            LauncherActivity.this.nativeAd.destroy();
                        }
                        LauncherActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        tvMessage = dialog.findViewById(R.id.tvPro);
        Utils.setFont(activity, tvMessage);
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.show();
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (LauncherActivity.this.nativeAd != null) {
                            LauncherActivity.this.nativeAd.destroy();
                        }
                        LauncherActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void setActionBar() {
        toolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        tvToolbarTitle.setText(getString(R.string.app_name));
        Utils.setFont(activity, tvToolbarTitle);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQ_CODE_VERSION_UPDATE) {
            if (resultCode == Activity.RESULT_CANCELED) {
                // If the update is cancelled by the user,
                // you can request to start the update again.
                inAppUpdateManager.checkForAppUpdate();

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onInAppUpdateError(int code, Throwable error) {
        Log.e("TAG", "code: " + code, error);
    }


    @Override
    public void onInAppUpdateStatus(InAppUpdateStatus status) {
        Log.e("TAG", "OnInAppUpdateStatus" + status.toString());
    }

}
