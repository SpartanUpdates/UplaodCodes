package com.kotlinz.festivalstorymaker.sticker;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;

public abstract class e {
    public final float[] a;
    public final float[] b;
    public final float[] c;
    public final float[] d;
    public final float[] e;
    public final RectF f;
    public final Matrix g;
    public boolean h;
    public boolean i;

    public e() {
        this.a = new float[9];
        this.b = new float[8];
        this.c = new float[2];
        this.d = new float[8];
        this.e = new float[8];
        this.f = new RectF();
        this.g = new Matrix();
    }

    public boolean d(final float[] array) {
        final Matrix matrix = new Matrix();
        final Matrix g = this.g;
        g.getValues(this.a);
        final float[] a = this.a;
        final double n = a[1];
        g.getValues(a);
        matrix.setRotate(-(float)Math.toDegrees(-Math.atan2(n, this.a[0])));
        this.e(this.d);
        this.g.mapPoints(this.e, this.d);
        matrix.mapPoints(this.b, this.e);
        matrix.mapPoints(this.c, array);
        final RectF f = this.f;
        final float[] b = this.b;
        f.set(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
        for (int i = 1; i < b.length; i += 2) {
            float right = Math.round(b[i - 1] * 10.0f) / 10.0f;
            float bottom = Math.round(b[i] * 10.0f) / 10.0f;
            float left;
            if (right < (left = f.left)) {
                left = right;
            }
            f.left = left;
            float top;
            if (bottom < (top = f.top)) {
                top = bottom;
            }
            f.top = top;
            final float right2 = f.right;
            if (right <= right2) {
                right = right2;
            }
            f.right = right;
            final float bottom2 = f.bottom;
            if (bottom <= bottom2) {
                bottom = bottom2;
            }
            f.bottom = bottom;
        }
        f.sort();
        final RectF f2 = this.f;
        final float[] c = this.c;
        return f2.contains(c[0], c[1]);
    }

    public void e(final float[] array) {
        if (!this.h) {
            if (!this.i) {
                array[1] = (array[0] = 0.0f);
                array[2] = (float)this.i();
                array[4] = (array[3] = 0.0f);
                array[5] = (float)this.g();
                array[6] = (float)this.i();
                array[7] = (float)this.g();
                return;
            }
            array[0] = 0.0f;
            array[1] = (float)this.g();
            array[2] = (float)this.i();
            array[3] = (float)this.g();
            array[5] = (array[4] = 0.0f);
            array[6] = (float)this.i();
            array[7] = 0.0f;
        }
        else {
            if (!this.i) {
                array[0] = (float)this.i();
                array[1] = 0.0f;
                array[3] = (array[2] = 0.0f);
                array[4] = (float)this.i();
                array[5] = (float)this.g();
                array[6] = 0.0f;
                array[7] = (float)this.g();
                return;
            }
            array[0] = (float)this.i();
            array[1] = (float)this.g();
            array[2] = 0.0f;
            array[3] = (float)this.g();
            array[4] = (float)this.i();
            array[5] = 0.0f;
            array[7] = (array[6] = 0.0f);
        }
    }

    public void f(final PointF pointF) {
        pointF.set(this.i() * 1.0f / 2.0f, this.g() * 1.0f / 2.0f);
    }

    public abstract int g();

    public void h(final PointF pointF, final float[] array, final float[] array2) {
        this.f(pointF);
        array2[0] = pointF.x;
        array2[1] = pointF.y;
        this.g.mapPoints(array, array2);
        pointF.set(array[0], array[1]);
    }

    public abstract int i();
}
