package com.xyz.vehiclemanager.bike.adapter;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.activity.BikeVariantActivity;
import com.xyz.vehiclemanager.bike.model.BikeBrandCategory;
import com.xyz.vehiclemanager.favourite.Room.FavoriteDatabase;
import com.xyz.vehiclemanager.favourite.model.FavoriteBikeModel;

import java.util.ArrayList;
import java.util.List;

public class BikeCategoryAdapter extends RecyclerView.Adapter<BikeCategoryAdapter.ViewHolder> {
    Context context;
    ArrayList<BikeBrandCategory> favoriteBikeModelList;

    public BikeCategoryAdapter(Context context, ArrayList<BikeBrandCategory> favoriteBikeModelList) {
        this.context = context;
        this.favoriteBikeModelList = favoriteBikeModelList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView bikeModelImage;
        TextView bikeModelName;
        TextView bikePrice;
        LikeButton likeButton;
        LinearLayout ll_main;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bikeModelImage = itemView.findViewById(R.id.iv_category);
            bikeModelName = itemView.findViewById(R.id.tv_carname);
            bikePrice = itemView.findViewById(R.id.tv_modelprice);
            likeButton = itemView.findViewById(R.id.likeButton);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_category,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final BikeBrandCategory favoriteBikeModel=favoriteBikeModelList.get(position);
        final String id=favoriteBikeModel.getId();
        holder.bikeModelName.setText(favoriteBikeModel.getBikeModelName());
        holder.bikePrice.setText(favoriteBikeModel.getExShowroomPrice());
        Glide.with(context).load(favoriteBikeModel.getImageUrl()).placeholder(R.drawable.ic_bike).into(holder.bikeModelImage);

        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, BikeVariantActivity.class);
                intent.putExtra("modelId", id);
                intent.putExtra("modelName",favoriteBikeModel.getBikeModelName());
                intent.putExtra("imageUrl", favoriteBikeModel.getImageUrl());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        holder.setIsRecyclable(false);
        List<FavoriteBikeModel>  favoriteBikeModelList=FavoriteDatabase.getFavoriteDatabase(context).favoriteBikeDao().getFavoriteBikeList();
        for(int i=0;i<favoriteBikeModelList.size();i++)
        {
            if(favoriteBikeModelList.get(i).getModelId().equals(id))
            {
                holder.likeButton.setLiked(true);
            }
        }
        holder.likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteBikeModel favoriteBikeModel1=new FavoriteBikeModel(id,favoriteBikeModel.getBikeModelName(),favoriteBikeModel.getExShowroomPrice(),favoriteBikeModel.getImageUrl());
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteBikeDao().insertBikeFavorite(favoriteBikeModel1);
                    }
                });
                thread.start();
            }
            @Override
            public void unLiked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteBikeDao().deleteBikeFavorite(id);
                    }
                });
                thread.start();

            }
        });
    }
    @Override
    public int getItemCount() {
        return favoriteBikeModelList.size();
    }
}
