package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;

public class FontHeight implements SeekBar.OnSeekBarChangeListener {
    public final  CollageMakerDetailActivity activity;

    public FontHeight(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.activity = collageMakerDetailActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            this.activity.n0.setLetterSpacing((float) i);
            this.activity.n0.requestLayout();
            com.kotlinz.festivalstorymaker.Models.z.c cVar =  activity.m0.get(((Integer) activity.n0.getTag()).intValue());
            cVar.a = i;
            CollageMakerDetailActivity collageMakerDetailActivity2 = this.activity;
            collageMakerDetailActivity2.m0.set(((Integer) collageMakerDetailActivity2.n0.getTag()).intValue(), cVar);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
