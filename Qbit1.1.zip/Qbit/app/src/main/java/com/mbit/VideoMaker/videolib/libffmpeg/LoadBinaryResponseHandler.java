package com.mbit.VideoMaker.videolib.libffmpeg;

public class LoadBinaryResponseHandler
  implements FFmpegLoadBinaryResponseHandler
{
  public LoadBinaryResponseHandler() {}
  
  public void onFailure() {}
  
  public void onSuccess() {}
  
  public void onStart() {}
  
  public void onFinish() {}
  
  public void onFailure(String cpuType) {}
  
  public void onSuccess(String cpuType) {}
}
