package com.kotlinz.videoCollage.puzzleview;


import com.kotlinz.videoCollage.flying.puzzle.PuzzleLayout;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.slant.OneSlantLayout;
import com.kotlinz.videoCollage.puzzleview.slant.SlantLayoutHelper;
import com.kotlinz.videoCollage.puzzleview.slant.ThreeSlantLayout;
import com.kotlinz.videoCollage.puzzleview.slant.TwoSlantLayout;
import com.kotlinz.videoCollage.puzzleview.straight.EightStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.FiveStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.FourStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.NineStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.OneStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.SevenStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.SixStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.StraightLayoutHelper;
import com.kotlinz.videoCollage.puzzleview.straight.ThreeStraightLayout;
import com.kotlinz.videoCollage.puzzleview.straight.TwoStraightLayout;

import java.util.ArrayList;
import java.util.List;

public class PuzzleUtils {
    private static final String TAG = "PuzzleUtils";

    private PuzzleUtils() {
    }

    public static PuzzleLayout getPuzzleLayout(int i, int i2, int i3) {
        if (i != 0) {
            switch (i2) {
                case 1:
                    return new OneStraightLayout(i3);
                case 2:
                    return new TwoStraightLayout(i3);
                case 3:
                    return new ThreeStraightLayout(i3);
                case 4:
                    return new FourStraightLayout(i3);
                case 5:
                    return new FiveStraightLayout(i3);
                case 6:
                    return new SixStraightLayout(i3);
                case 7:
                    return new SevenStraightLayout(i3);
                case 8:
                    return new EightStraightLayout(i3);
                case 9:
                    return new NineStraightLayout(i3);
                default:
                    return new OneStraightLayout(i3);
            }
        } else if (i2 == 1) {
            return new OneSlantLayout(i3);
        } else {
            if (i2 == 2) {
                return new TwoSlantLayout(i3);
            }
            if (i2 != 3) {
                return new OneSlantLayout(i3);
            }
            return new ThreeSlantLayout(i3);
        }
    }

    public static List<PuzzleLayout> getAllPuzzleLayouts() {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(SlantLayoutHelper.getAllThemeLayout(2));
        arrayList.addAll(SlantLayoutHelper.getAllThemeLayout(3));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(2));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(3));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(4));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(5));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(6));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(7));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(8));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(9));
        return arrayList;
    }

    public static List<PuzzleLayout> getPuzzleLayouts(int i) {
        ArrayList arrayList = new ArrayList();
        if (Util.selectedVid >= 1) {
            arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(i));
        } else {
            arrayList.addAll(SlantLayoutHelper.getAllThemeLayout(i));
            arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(i));
        }
        return arrayList;
    }
}
