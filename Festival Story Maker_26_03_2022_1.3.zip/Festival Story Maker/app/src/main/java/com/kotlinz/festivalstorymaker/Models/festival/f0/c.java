package com.kotlinz.festivalstorymaker.Models.festival.f0;

public class c {
    public int a;
    public int b;
    public int c;
    public int d;
    public int e = -1;
    public int f;

}
