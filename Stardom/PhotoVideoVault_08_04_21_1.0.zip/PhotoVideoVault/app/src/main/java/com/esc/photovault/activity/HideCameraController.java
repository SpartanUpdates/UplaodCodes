package com.esc.photovault.activity;

import android.app.Activity;
import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;

class HideCameraController extends Activity {

    private int cameraId;
    private Context context;
    private boolean hasCamera;

    public HideCameraController(Context c) {
        this.context = c.getApplicationContext();
        if (this.context.getPackageManager().hasSystemFeature("android.hardware.camera")) {
            this.cameraId = getFrontCameraId();
            if (this.cameraId != -1) {
                this.hasCamera = true;
                return;
            } else {
                this.hasCamera = false;
                return;
            }
        }
        this.hasCamera = false;
    }

    private int getFrontCameraId() {
        int camId = -1;
        int numberOfCameras = Camera.getNumberOfCameras();
        CameraInfo ci = new CameraInfo();
        for (int i = 0; i < numberOfCameras; i++) {
            Camera.getCameraInfo(i, ci);
            if (ci.facing == 1) {
                camId = i;
            }
        }
        return camId;
    }
}
