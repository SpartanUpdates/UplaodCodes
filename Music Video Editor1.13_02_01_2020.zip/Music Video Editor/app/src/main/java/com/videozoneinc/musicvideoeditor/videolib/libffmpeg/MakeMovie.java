package com.videozoneinc.musicvideoeditor.videolib.libffmpeg;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeoutException;

public class MakeMovie extends Service {
    private long timeout;

    class TaskCreateSingleImageVideo extends AsyncTask<Void, String, Void> {
        String[] cmd;
        private String output;
        private Process process;
        private ShellCommand ShellCommand;
        private long start_Time;

        public TaskCreateSingleImageVideo(int imgNo) {
            this.ShellCommand = new ShellCommand();
            this.cmd = new String[0];
        }

        protected void onPreExecute() {
            this.start_Time = System.currentTimeMillis();
        }

        protected Void doInBackground(Void... params) {
            this.process = this.ShellCommand.run(this.cmd);
            if (this.process != null) {
                try {
                    checkAndUpdateProcess();
                } catch (TimeoutException e) {
                    e.printStackTrace();
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
            return null;
        }

        private void checkAndUpdateProcess() throws TimeoutException,
                InterruptedException {
            while (!Util.isProcessCompleted(this.process)
                    && !Util.isProcessCompleted(this.process)) {
                if (MakeMovie.this.timeout == Long.MAX_VALUE
                        || System.currentTimeMillis() <= this.start_Time
                        + MakeMovie.this.timeout) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(
                                        this.process.getErrorStream()));
                        String line = reader.readLine();
                        if (line == null) {
                        } else if (!isCancelled()) {
                            this.output = String.valueOf(this.output) + line
                                    + "\n";
                            publishProgress(new String[] { line });
                        } else {
                            return;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    throw new TimeoutException("FFmpeg timed out");
                }
            }
        }
    }

    public MakeMovie() {
        this.timeout = Long.MAX_VALUE;
    }

    public IBinder onBind(Intent arg0) {
        return null;
    }
}
