package com.esc.dailyrandomfacts.model;

import android.content.Context;
import android.util.AttributeSet;
import com.esc.dailyrandomfacts.util.Utils;
import androidx.appcompat.widget.AppCompatTextView;

public class HrdTextView extends AppCompatTextView {
    public HrdTextView(Context context) {
        super(context);
        setTypeface(Utils.getFont(context, Integer.parseInt(getTag().toString())));
    }

    public HrdTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setTypeface(Utils.getFont(context, Integer.parseInt(getTag().toString())));
    }

    public HrdTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setTypeface(Utils.getFont(context, Integer.parseInt(getTag().toString())));
    }
}
