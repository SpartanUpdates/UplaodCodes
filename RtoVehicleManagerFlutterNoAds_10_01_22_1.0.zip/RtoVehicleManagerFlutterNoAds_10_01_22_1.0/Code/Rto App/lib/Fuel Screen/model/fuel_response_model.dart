import 'dart:convert';

FuelResponseModel FuelResponseModelFromJson(String str) =>
    FuelResponseModel.fromJson(json.decode(str));

String FuelResponseModelToJson(FuelResponseModel data) =>
    json.encode(data.toJson());

class FuelResponseModel {
  FuelResponseModel({
    required this.code,
    required this.status,
    required this.response,
  });

  int code;
  String status;
  Response response;

  factory FuelResponseModel.fromJson(Map<String, dynamic> json) =>
      FuelResponseModel(
        code: json["code"],
        status: json["status"],
        response: Response.fromJson(json["response"]),
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "status": status,
        "response": response.toJson(),
      };
}

class Response {
  Response({
    required this.name,
    required this.petrolPrice,
    required this.petrolChange,
    required this.dieselPrice,
    required this.dieselChange,
    required this.priceDate,
    required this.citystate,
    required this.type,
    required this.code,
  });

  String name;
  double petrolPrice;
  String petrolChange;
  double dieselPrice;
  String dieselChange;
  DateTime priceDate;
  String citystate;
  String type;
  String code;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
        name: json["name"],
        petrolPrice: json["petrolPrice"].toDouble(),
        petrolChange: json["petrolChange"],
        dieselPrice: json["dieselPrice"].toDouble(),
        dieselChange: json["dieselChange"],
        priceDate: DateTime.parse(json["priceDate"]),
        citystate: json["citystate"],
        type: json["type"],
        code: json["code"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "petrolPrice": petrolPrice,
        "petrolChange": petrolChange,
        "dieselPrice": dieselPrice,
        "dieselChange": dieselChange,
        "priceDate": priceDate.toString(),
        "citystate": citystate,
        "type": type,
        "code": code,
      };
}
