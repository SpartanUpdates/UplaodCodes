package com.name.nameart.MyUtils;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.name.nameart.R;
import com.name.nameart.ThropicalData.ThropicalDataList;

import java.util.ArrayList;


public class AppCommon {
    public static ArrayList<ThropicalDataList> appDataArrayList = new ArrayList();
    public static String company_policy_about_use = "";
    public static String google_play_account_link = "https://play.google.com/store/apps/developer?id=Thropical+Tools";

    public static Boolean CheckNet(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        boolean z = activeNetworkInfo != null && activeNetworkInfo.isConnected();
        return Boolean.valueOf(z);
    }

    public static void setPrefBoolean(Context context, String str, boolean z) {
        Editor edit = context.getSharedPreferences(context.getString(R.string.app_name), 0).edit();
        edit.putBoolean(str, z);
        edit.commit();
    }

    public static boolean getPrefBoolean(Context context, String str) {
        if (context != null) {
            return context.getSharedPreferences(context.getString(R.string.app_name), 0).getBoolean(str, false);
        }
        return false;
    }
}
