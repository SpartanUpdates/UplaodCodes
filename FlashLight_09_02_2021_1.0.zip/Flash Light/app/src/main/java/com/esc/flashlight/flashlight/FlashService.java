package com.esc.flashlight.flashlight;

import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

import androidx.core.app.NotificationCompat.Builder;
import androidx.core.content.ContextCompat;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.config.Config;
import com.esc.flashlight.flashlight.controller.BaseFlashControllerInterface;
import com.esc.flashlight.flashlight.controller.BasicFlashController;
import com.esc.flashlight.flashlight.controller.BasicFlashController23;
import com.esc.flashlight.flashlight.controller.UseSurfaceTextureFlashController;
import com.esc.flashlight.flashlight.controller.UseSurfaceViewFlashController;
import com.esc.flashlight.util.PrefManager;

import java.util.EventListener;
import java.util.Iterator;
import java.util.LinkedList;

public class FlashService extends IntentService {
    public static final String ACTION_CHANGED_STATUS_BAR = "flash.light.shine.statusbar";
    public static final String ACTION_COMING_MSG = "flash.light.shine.comingmsg";
    public static final String ACTION_MISSED_CALL = "flash.light.shine.missedcall";
    public static final String ACTION_OFF = "flash.light.shine.off";
    public static final String ACTION_RINGING = "flash.light.shine.ringing";
    public static final String ACTION_TEST = "flash.light.shine.test";
    private static final long SAFE_DELAY_MILLIS = 1000;
    private static final String TAG = "FlashService";
    private static int flashController;
    private static Handler handler;
    private static boolean isRun;
    private static LinkedList<OnFlashServiceListener> onFlashServiceListeners;
    private static SurfaceView sSurfaceView;
    private static WakeLock sWakeLock;
    private BaseFlashControllerInterface[] controller;
    private PrefManager mPref;
    boolean toggle;

    static class C01851 extends Handler {
        C01851() {
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
        }
    }

    class C01862 implements Runnable {
        C01862() {
        }

        public void run() {
            if (FlashService.onFlashServiceListeners != null) {
                FlashService.notifyFlashEnd();
                if (FlashService.sWakeLock != null && FlashService.sWakeLock.isHeld()) {
                    FlashService.sWakeLock.release();
                    FlashService.sWakeLock = null;
                }
            }
        }
    }

    public interface OnFlashServiceListener extends EventListener {
        void onEnd();

        void onIgnore();

        void onStart();
    }

    public FlashService() {
        super(TAG);
    }

    public static void addOnFlashServiceListener(OnFlashServiceListener onFlashServiceListener) {
        if (onFlashServiceListeners == null) {
            onFlashServiceListeners = new LinkedList();
        }
        if (!onFlashServiceListeners.contains(onFlashServiceListener)) {
            onFlashServiceListeners.add(onFlashServiceListener);
        }
    }

    public static void removeOnFlashServiceListener(OnFlashServiceListener onFlashServiceListener) {
        LinkedList linkedList = onFlashServiceListeners;
        if (linkedList != null && linkedList.contains(onFlashServiceListener)) {
            onFlashServiceListeners.remove(onFlashServiceListener);
        }
    }

    public static synchronized void runIntentInService(Context context, Intent intent) {
        Class cls = FlashService.class;
        synchronized (cls) {
            synchronized (cls) {
                if (sWakeLock == null) {
                    sWakeLock = ((PowerManager) context.getSystemService(POWER_SERVICE)).newWakeLock(1, context.getPackageName());
                }
                if (checkOffAction(intent.getAction())) {
                    isRun = false;
                } else if (isRun) {
                    Log.d("MyIntentService", " * invoke:   runIntentService... but ignore");
                    notifyFlashIgnore();
                } else {
                    Log.d("MyIntentService", " * invoke:   runIntentService");
                    if (handler == null) {
                        handler = new C01851();
                    }
                    isRun = true;
                    WakeLock wakeLock = sWakeLock;
                    if (!(wakeLock == null || wakeLock.isHeld())) {
                        sWakeLock.acquire();
                    }
                    if (VERSION.SDK_INT < 23) {
                        int flashController = APP.getPrefManager().getFlashController();
                        flashController = flashController;
                        if (flashController == 1) {
                            Log.e("Its_me!!!", "127");
                            addSurfaceView(context);
                        }
                        Log.e("Its_me!!!", "130");
                    } else {
                        flashController = 3;
                    }
                    notifyFlashStart();
                    intent.setClassName(context, cls.getName());
                    if (VERSION.SDK_INT >= 26) {
                        ContextCompat.startForegroundService(context, intent);
                    } else {
                        context.startService(new Intent(context, cls));
                    }
                }
            }
        }
    }

    public void onCreate() {
        super.onCreate();
        String str = TAG;
        Log.d(str, "FlashService onCreate");
        PrefManager prefManager = APP.getPrefManager();
        this.mPref = prefManager;
        int flashPosition = prefManager.getFlashPosition();
        String str2 = "Its_me!!!";
        Log.e(str2, "id" + this.mPref.getFrontCameraId());
        Log.e(str2, "front" + flashPosition);
        Log.e(str2, "flashController " + flashController);
        int i = flashController;
        if (i == 0) {
            if (flashPosition == 1) {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController.getInstanceFront(i)};
            } else if (flashPosition != 2) {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController.getInstanceBack(), BasicFlashController.getInstanceFront(i)};
            } else {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController.getInstanceBack()};
            }
            Log.i(str, "getting flash controll: basic");
        } else if (i == 1) {
            if (flashPosition == 1) {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceViewFlashController.getInstanceFront(i)};
            } else if (flashPosition != 2) {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceViewFlashController.getInstanceBack(), UseSurfaceViewFlashController.getInstanceFront(i)};
            } else {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceViewFlashController.getInstanceBack()};
            }
            Log.i(str, "getting flash controll: surface view");
        } else if (i == 2) {
            if (flashPosition == 1) {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceTextureFlashController.getInstanceFront(i)};
            } else if (flashPosition != 2) {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceTextureFlashController.getInstanceBack(), UseSurfaceTextureFlashController.getInstanceFront(i)};
            } else {
                this.controller = new BaseFlashControllerInterface[]{UseSurfaceTextureFlashController.getInstanceBack()};
            }
            Log.i(str, "getting flash controll: surface texture");
        } else if (i == 3) {
            if (flashPosition == 1) {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController23.getInstanceFront(i)};
            } else if (flashPosition != 2) {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController23.getInstanceBack(), BasicFlashController23.getInstanceFront(i)};
            } else {
                this.controller = new BaseFlashControllerInterface[]{BasicFlashController23.getInstanceBack()};
            }
            Log.i(str, "getting flash controll: basic23");
        }
        if (VERSION.SDK_INT >= 26) {
            str = "my_channel_01";
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel(str, "Channel title", NotificationManager.IMPORTANCE_DEFAULT));
            startForeground(1, new Builder(this, str).build());
        }
    }

    public void onDestroy() {
        super.onDestroy();
        if (isRun) {
            BaseFlashControllerInterface[] baseFlashControllerInterfaceArr = this.controller;
            if (baseFlashControllerInterfaceArr != null) {
                for (BaseFlashControllerInterface useStop : baseFlashControllerInterfaceArr) {
                    useStop.useStop();
                }
            }
            if (onFlashServiceListeners != null) {
                notifyFlashEnd();
            }
        }
        if (sSurfaceView != null) {
            removeSurfaceView(getApplicationContext());
        }
        WakeLock wakeLock = sWakeLock;
        if (wakeLock != null) {
            if (wakeLock.isHeld()) {
                Log.d(TAG, "wakelock release");
                sWakeLock.release();
            }
            sWakeLock = null;
        }
        Log.w(TAG, "****** destroy service");
    }

    /* Access modifiers changed, original: protected */
    public void onHandleIntent(Intent intent) {
        int offIntervalCall;
        int i;
        String str = "onHandleIntent: ";
        String action = intent.getAction();
        String str2 = TAG;
        Log.d(str2, "수신된 액션: " + action);
        int i2 = 5;
        if ("flash.light.shine.ringing".equals(action)) {
            i2 = this.mPref.getOnIntervalCall();
            offIntervalCall = this.mPref.getOffIntervalCall();
            i = 0;
        } else if ("flash.light.shine.comingmsg".equals(action)) {
            i2 = this.mPref.getOnIntervalMessage();
            offIntervalCall = this.mPref.getOffIntervalMessage();
            i = this.mPref.getStrobeCountMessage();
        } else if ("flash.light.shine.statusbar".equals(action)) {
            i2 = this.mPref.getOnIntervalStatusBar();
            offIntervalCall = this.mPref.getOffIntervalStatusBar();
            i = this.mPref.getStrobeCountStatusBar();
        } else if (ACTION_MISSED_CALL.equals(action)) {
            i2 = this.mPref.getOnIntervalMissedCall();
            offIntervalCall = this.mPref.getOffIntervalMissedCall();
            i = this.mPref.getStrobeCountMissedCall();
        } else {
            offIntervalCall = 5;
            i = 5;
        }
        if (!(i2 == 0 || offIntervalCall == 0)) {
            Log.w(str2, " ****** 시작");
            int i3 = (int) (((long) i2) * 50);
            offIntervalCall = (int) (((long) offIntervalCall) * 50);
            i *= 2;
            int i4;
            try {
                for (BaseFlashControllerInterface useStart : this.controller) {
                    useStart.useStart(sSurfaceView);
                }
                Log.e("times", str + i);
                if (i < 1) {
                    long currentTimeMillis = System.currentTimeMillis();
                    while (isRun) {
                        toggle(i3, offIntervalCall);
                        if (System.currentTimeMillis() - currentTimeMillis > Config.MISSED_MSEC_MIN) {
                            break;
                        }
                    }
                    Log.e("start time", str + currentTimeMillis);
                }
                Log.e("on off", str + i3 + " " + offIntervalCall);
                for (i4 = 0; i4 < i && isRun; i4++) {
                    toggle(i3, offIntervalCall);
                }
                for (BaseFlashControllerInterface useStop : this.controller) {
                    useStop.useStop();
                }
            } catch (Exception e) {
                e.printStackTrace();
                for (BaseFlashControllerInterface useStop2 : this.controller) {
                    useStop2.useStop();
                }
            } catch (Throwable unused) {
                for (BaseFlashControllerInterface useStop22 : this.controller) {
                    useStop22.useStop();
                }
            }
            Log.w(TAG, " ****** 리얼 중지");
        }
        if (flashController == 1) {
            removeSurfaceView(getApplicationContext());
        }
        isRun = false;
        handler.postDelayed(new C01862(), SAFE_DELAY_MILLIS);
    }

    private static void notifyFlashEnd() {
        LinkedList linkedList = onFlashServiceListeners;
        if (linkedList != null) {
            Iterator it = linkedList.iterator();
            while (it.hasNext()) {
                ((OnFlashServiceListener) it.next()).onEnd();
            }
        }
    }

    private static void notifyFlashIgnore() {
        LinkedList linkedList = onFlashServiceListeners;
        if (linkedList != null) {
            Iterator it = linkedList.iterator();
            while (it.hasNext()) {
                ((OnFlashServiceListener) it.next()).onIgnore();
            }
        }
    }

    private static void notifyFlashStart() {
        LinkedList linkedList = onFlashServiceListeners;
        if (linkedList != null) {
            Iterator it = linkedList.iterator();
            while (it.hasNext()) {
                ((OnFlashServiceListener) it.next()).onStart();
            }
        }
    }

    private void toggle(int i, int i2) {
        try {
            int i3 = 0;
            boolean z = !this.toggle;
            this.toggle = z;
            String str = " ";
            String str2 = "toggle: ";
            int length;
            if (z) {
                BaseFlashControllerInterface[] baseFlashControllerInterfaceArr = this.controller;
                length = baseFlashControllerInterfaceArr.length;
                Log.e("lenght", str2 + length + str + 0);
                while (i3 < length) {
                    baseFlashControllerInterfaceArr[i3].flashOn();
                    i3++;
                }
                Thread.sleep((long) i);
                return;
            }
            BaseFlashControllerInterface[] baseFlashControllerInterfaceArr2 = this.controller;
            length = baseFlashControllerInterfaceArr2.length;
            Log.e("lenght off", str2 + length + str + 0);
            while (i3 < length) {
                baseFlashControllerInterfaceArr2[i3].flashOff();
                i3++;
            }
            Thread.sleep((long) i2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static boolean checkOnAction(String str) {
        return str.equals("flash.light.shine.ringing") || str.equals("flash.light.shine.comingmsg") || str.equals("flash.light.shine.statusbar");
    }

    private static boolean checkOffAction(String str) {
        return str.equals("flash.light.shine.off");
    }

    private static void addSurfaceView(Context context) {
        if (sSurfaceView == null) {
            sSurfaceView = new SurfaceView(context);
        }
        LayoutParams layoutParams = new LayoutParams(1, 1, 0, 0, 2006, 16, -2);
        layoutParams.gravity = 85;
        try {
            ((WindowManager) context.getSystemService(WINDOW_SERVICE)).addView(sSurfaceView, layoutParams);
        } catch (Exception e) {
            e.printStackTrace();
            sSurfaceView = null;
        }
    }

    private static void removeSurfaceView(Context context) {
        if (sSurfaceView != null) {
            try {
                ((WindowManager) context.getSystemService(WINDOW_SERVICE)).removeView(sSurfaceView);
            } catch (Exception e) {
                e.printStackTrace();
            }
            sSurfaceView = null;
        }
    }
}
