package com.kotlinz.festivalstorymaker.Other.o.u.a;

public interface hb {
    void j(boolean z, boolean z2, int i, int i2);

}
