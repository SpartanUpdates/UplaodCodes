package com.example.funnyjokesandshayari.mainquotes;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.example.funnyjokesandshayari.R;
import com.example.funnyjokesandshayari.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.measurement.api.AppMeasurementSdk.ConditionalUserProperty;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    Activity activity = MainActivity.this;
    private final String TAG = MainActivity.class.getSimpleName();

    ViewPager viewPager;
    ImageView left_arrow, right_arrow, img_back;
    TextView txt_title;
    String title;
    //   public static String shayri;
    private int currentPage = 0;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

        getWindow().setStatusBarColor(getResources().getColor(R.color.actionbarcolor));

        img_back = findViewById(R.id.img_back);
        txt_title = findViewById(R.id.txt_title);

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        txt_title.setText(getIntent().getExtras().getString(ConditionalUserProperty.NAME));

        interstitialAd();


        this.viewPager = (ViewPager) findViewById(R.id.viewpager);

        left_arrow = findViewById(R.id.left_arrow);
        right_arrow = findViewById(R.id.right_arrow);

        left_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(viewPager.getCurrentItem() - 1, true);
            }
        });
        right_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true);
            }
        });


        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                currentPage++;
                if (currentPage % 5 == 0) {
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        try {
                            hud = KProgressHUD.create(activity)
                                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                    .setLabel("Showing Ads")
                                    .setDetailsLabel("Please Wait...");
                            hud.show();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    hud.dismiss();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();

                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                    id = 100;
                                    mInterstitialAd.show();
                                }
                            }
                        }, 2000);
                    } else {
                        viewPager.setCurrentItem(viewPager.getCurrentItem() + 0, true);
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        // setTitle(getIntent().getExtras().getString(ConditionalUserProperty.NAME));

        ArrayList arrayList = new ArrayList();
        getAssets();
        String string = getIntent().getExtras().getString("data");
        try {
            JSONObject jSONObject = new JSONObject(loadJSONFromAsset());
            String str = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("nahar");
            stringBuilder.append(string);
            Log.d(str, stringBuilder.toString());
            JSONArray jSONArray = jSONObject.getJSONArray(string);
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                ArrayList arrayList2 = new ArrayList();
                Iterator keys = jSONObject2.keys();
                while (keys.hasNext()) {
                    arrayList.add(new Quote((String) jSONObject2.get((String) keys.next())));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.viewPager.setAdapter(new QuotePageAdapter(arrayList, this, this));
    }

    public String loadJSONFromAsset() {
        try {
            InputStream open = getAssets().open("audience_network.json");
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void callCopyClipboard(String str) {
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("Download App : " + "\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
        clipboardManager.setPrimaryClip(ClipData.newPlainText("text", stringBuilder.toString()));
        Toast.makeText(getApplicationContext(), "Quote Copied to Clipboard", Toast.LENGTH_SHORT).show();
        Toast.makeText(MainActivity.this, "Quote Copied to Clipboard", Toast.LENGTH_SHORT).show();
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        viewPager.setCurrentItem(viewPager.getCurrentItem() + 0, true);
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
