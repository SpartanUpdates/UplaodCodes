package com.example.knowledgetrivia.controller;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.helper.Option;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.manager.QuestionManager;
import com.example.knowledgetrivia.models.Question;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.muddzdev.styleabletoast.StyleableToast;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class TwoPlayerShowingQuestion extends AppCompatActivity {
    Activity activity=TwoPlayerShowingQuestion.this;
    private boolean adTimerControl = true;
    private ConstraintLayout alert_msg_layout;
    private TextView alert_text;
    private LinearLayout alpha_layout;
    private Option answeKey;
    private RelativeLayout bodyLayout;
    private Builder builder;
    private CircularProgressBar circularProgressBar;
    private String[] colorArray;
    private MediaPlayer correctSound;
    private CountDownTimer countDownTimer;
    private Question currentQuestion;
    private boolean first = true;
    private int index;
    private QuestionManager manager;
    private int milliSecondsRemaining = 31000;
    private String name1;
    private String name2;
    private Button okButton;
    private TextView optionA;
    private TextView optionB;
    private TextView optionC;
    private TextView optionD;
    private TextView question_Text;
    private ArrayList<Question> questions;
    private TextView questiontext;
    private Random random;
    private double score1;
    private double score2;
    private TextView scoreText;
    private TextView score_text;
    private MediaPlayer tick;
    private TextView timeRemainingLabel;
    private int timecount = 0;
    private TextView totalQuestion;
    private TextView turn_name;
    private MediaPlayer wrongSound;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle)
    {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_two_player_showing_question);
        this.tick = MediaPlayer.create(this, R.raw.tick);



        Intent intent = getIntent();
        this.name1 = intent.getStringExtra("name1");
        this.name2 = intent.getStringExtra("name2");

        BannerAds();
        interstitialAd();

        init();
        listeners();
        executeQuestions();
    }

    private void executeQuestions() {
        this.manager = QuestionManager.getInstance(this);
        this.questions = this.manager.getTenRandomQuestion();
        Collections.shuffle(this.questions);
        showQuestion();
        String str = "";
        TextView textView;
        StringBuilder stringBuilder;
        if (this.first) {
            textView = this.score_text;
            stringBuilder = new StringBuilder();
            stringBuilder.append(this.score1);
            stringBuilder.append(str);
            textView.setText(stringBuilder.toString());
            return;
        }
        textView = this.score_text;
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.score2);
        stringBuilder.append(str);
        textView.setText(stringBuilder.toString());
    }

    private void startingCountDownTimer(int i)
    {
        this.countDownTimer = new CountDownTimer((long) i, 100)
        {
            public void onTick(long j)
            {
                int i = (int) j;
                TwoPlayerShowingQuestion.this.milliSecondsRemaining = i;
                float f = (100.0f - (((float) j) / 310.0f)) + 1.0f;
                TwoPlayerShowingQuestion.this.timecount = i / 1000;
                TwoPlayerShowingQuestion.this.circularProgressBar.setProgress(f);
                TextView access = TwoPlayerShowingQuestion.this.timeRemainingLabel;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(TwoPlayerShowingQuestion.this.timecount);
                stringBuilder.append("s");
                access.setText(stringBuilder.toString());
            }

            public void onFinish()
            {
                new StyleableToast.Builder(TwoPlayerShowingQuestion.this.getApplicationContext()).text("Time's up").backgroundColor(ContextCompat.getColor(TwoPlayerShowingQuestion.this.getApplicationContext(), R.color.sad_color)).textColor(-1).length(0).iconStart(R.drawable.sad).solidBackground().show();
                TwoPlayerShowingQuestion.this.execute(Option.Z);
            }
        }.start();
    }

    private void init() {
        this.okButton = (Button) findViewById(R.id.alert_button);
        this.alert_text = (TextView) findViewById(R.id.alert_text);
        this.alert_msg_layout = (ConstraintLayout) findViewById(R.id.alert_msg_layout);
        this.alpha_layout = (LinearLayout) findViewById(R.id.alpha_layout);
        this.turn_name = (TextView) findViewById(R.id.turn_name);
        this.turn_name.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake_animation));
        TextView textView = this.turn_name;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.name1);
        stringBuilder.append("'s turn");
        textView.setText(stringBuilder.toString());
        this.manager = QuestionManager.getInstance(this);
        this.questiontext = (TextView) findViewById(R.id.ly_sq_question2);
        this.optionA = (TextView) findViewById(R.id.ly_sq_optionA2);
        this.optionB = (TextView) findViewById(R.id.ly_sq_optionB2);
        this.optionC = (TextView) findViewById(R.id.ly_sq_optionC2);
        this.optionD = (TextView) findViewById(R.id.ly_sq_optionD2);
        this.bodyLayout = (RelativeLayout) findViewById(R.id.lay_sq_body);
        this.score_text = (TextView) findViewById(R.id.lay_sq_score);
        this.totalQuestion = (TextView) findViewById(R.id.lay_sq_totalQuestion);
        this.question_Text = (TextView) findViewById(R.id.lay_sq_title_questions);
        this.scoreText = (TextView) findViewById(R.id.lay_sq_score_title);
        this.builder = new Builder(this);
        this.circularProgressBar = (CircularProgressBar) findViewById(R.id.circularProgressBar);
        this.timeRemainingLabel = (TextView) findViewById(R.id.shwoingQuestion_seconds);
        this.colorArray = getResources().getStringArray(R.array.bgcolors);
        this.random = new Random();
        this.correctSound = MediaPlayer.create(this, R.raw.correct);
        this.wrongSound = MediaPlayer.create(this, R.raw.wrong);

        this.optionA.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                execute(Option.A);
            }
        });
        this.optionB.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                execute(Option.B);
            }
        });
        this.optionC.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v) {
                execute(Option.C);
            }
        });
        this.optionD.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                execute(Option.D);
            }
        });
    }


    private void listeners()
    {
        this.okButton.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {

                int nextInt = TwoPlayerShowingQuestion.this.random.nextInt(TwoPlayerShowingQuestion.this.colorArray.length);

                TwoPlayerShowingQuestion.this.bodyLayout.setBackgroundColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));

                TwoPlayerShowingQuestion.this.optionA.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                TwoPlayerShowingQuestion.this.optionB.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                TwoPlayerShowingQuestion.this.optionC.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                TwoPlayerShowingQuestion.this.optionD.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));

                TwoPlayerShowingQuestion.this.optionA.setTypeface(Typeface.DEFAULT);
                TwoPlayerShowingQuestion.this.optionB.setTypeface(Typeface.DEFAULT);
                TwoPlayerShowingQuestion.this.optionC.setTypeface(Typeface.DEFAULT);
                TwoPlayerShowingQuestion.this.optionD.setTypeface(Typeface.DEFAULT);


                TwoPlayerShowingQuestion.this.question_Text.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                TwoPlayerShowingQuestion.this.scoreText.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));


                TwoPlayerShowingQuestion.this.milliSecondsRemaining = 31000;
                TwoPlayerShowingQuestion twoPlayerShowingQuestion = TwoPlayerShowingQuestion.this;
                twoPlayerShowingQuestion.startingCountDownTimer(twoPlayerShowingQuestion.milliSecondsRemaining);
                TwoPlayerShowingQuestion.this.clickableTextviews(true);

                TwoPlayerShowingQuestion.this.executeQuestions();

                TwoPlayerShowingQuestion.this.adTimerControl = true;
                TwoPlayerShowingQuestion.this.alpha_layout.setVisibility(View.GONE);
                TwoPlayerShowingQuestion.this.alert_msg_layout.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("Range")
    private void execute(Option option)
    {
        this.countDownTimer.cancel();
        String str = "";
        if (option == this.answeKey) {
            this.correctSound.start();
            TextView textView;
            StringBuilder stringBuilder;
            if (this.first) {
                this.score1 += 1.0d;
                textView = this.score_text;
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.score1);
                stringBuilder.append(str);
                textView.setText(stringBuilder.toString());
            } else {
                this.score2 += 1.0d;
                textView = this.score_text;
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.score2);
                stringBuilder.append(str);
                textView.setText(stringBuilder.toString());
            }
        } else {
            TextView textView2;
            StringBuilder stringBuilder2;
            if (this.first) {
                this.score1 -= 0.25d;
                textView2 = this.score_text;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.score1);
                stringBuilder2.append(str);
                textView2.setText(stringBuilder2.toString());
            } else {
                this.score2 -= 0.25d;
                textView2 = this.score_text;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.score2);
                stringBuilder2.append(str);
                textView2.setText(stringBuilder2.toString());
            }
            this.wrongSound.start();
            str = "#D8000C";
            if (option == Option.A) {
                this.optionA.setTextColor(Color.parseColor(str));
                this.optionA.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.B) {
                this.optionB.setTextColor(Color.parseColor(str));
                this.optionB.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.C) {
                this.optionC.setTextColor(Color.parseColor(str));
                this.optionC.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.D) {
                this.optionD.setTextColor(Color.parseColor(str));
                this.optionD.setTypeface(Typeface.DEFAULT_BOLD);
            }
        }
        str = "#228B22";
        if (this.answeKey == Option.A) {
            this.optionA.setTextColor(Color.parseColor(str));
            this.optionA.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.B) {
            this.optionB.setTextColor(Color.parseColor(str));
            this.optionB.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.C) {
            this.optionC.setTextColor(Color.parseColor(str));
            this.optionC.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.D) {
            this.optionD.setTextColor(Color.parseColor(str));
            this.optionD.setTypeface(Typeface.DEFAULT_BOLD);
        }
        clickableTextviews(false);
        new Thread()
        {
            public void run()
            {
                try
                {
                    Thread.sleep(1250);
                    TwoPlayerShowingQuestion.this.runOnUiThread(new Runnable()
                    {
                        public void run()
                        {
                            TwoPlayerShowingQuestion.this.index = TwoPlayerShowingQuestion.this.index + 1;
                            if (TwoPlayerShowingQuestion.this.index < TwoPlayerShowingQuestion.this.questions.size())
                            {
                                int nextInt = TwoPlayerShowingQuestion.this.random.nextInt(TwoPlayerShowingQuestion.this.colorArray.length);

                                TwoPlayerShowingQuestion.this.bodyLayout.setBackgroundColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));

                                TwoPlayerShowingQuestion.this.optionA.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                                TwoPlayerShowingQuestion.this.optionB.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                                TwoPlayerShowingQuestion.this.optionC.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                                TwoPlayerShowingQuestion.this.optionD.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));

                                TwoPlayerShowingQuestion.this.optionA.setTypeface(Typeface.DEFAULT);
                                TwoPlayerShowingQuestion.this.optionB.setTypeface(Typeface.DEFAULT);
                                TwoPlayerShowingQuestion.this.optionC.setTypeface(Typeface.DEFAULT);
                                TwoPlayerShowingQuestion.this.optionD.setTypeface(Typeface.DEFAULT);

                                TwoPlayerShowingQuestion.this.question_Text.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));
                                TwoPlayerShowingQuestion.this.scoreText.setTextColor(Color.parseColor(TwoPlayerShowingQuestion.this.colorArray[nextInt]));

                                TwoPlayerShowingQuestion.this.countDownTimer.cancel();
                                TwoPlayerShowingQuestion.this.milliSecondsRemaining = 31000;
                                TwoPlayerShowingQuestion.this.startingCountDownTimer(TwoPlayerShowingQuestion.this.milliSecondsRemaining);
                                TwoPlayerShowingQuestion.this.clickableTextviews(true);
                            }
                            TwoPlayerShowingQuestion.this.showQuestion();
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    public void showQuestion() {
        if (this.index < this.questions.size())
        {
            this.currentQuestion = (Question) this.questions.get(this.index);
            this.questiontext.setText(this.currentQuestion.getQuestion());
            ArrayList options = this.currentQuestion.getOptions();
            this.optionA.setText((CharSequence) options.get(0));
            this.optionB.setText((CharSequence) options.get(1));
            this.optionC.setText((CharSequence) options.get(2));
            this.optionD.setText((CharSequence) options.get(3));
            int solutionIndex = this.currentQuestion.getSolutionIndex();
            if (solutionIndex == 1) {
                this.answeKey = Option.A;
            }
            if (solutionIndex == 2) {
                this.answeKey = Option.B;
            }
            if (solutionIndex == 3) {
                this.answeKey = Option.C;
            }
            if (solutionIndex == 4) {
                this.answeKey = Option.D;
            }
            TextView textView = this.totalQuestion;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.index + 1);
            stringBuilder.append(" / ");
            stringBuilder.append(String.valueOf(this.questions.size()));
            textView.setText(stringBuilder.toString());
            return;
        }

        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 100;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        } else {
            this.countDownTimer.cancel();
            this.adTimerControl = false;
            if (this.first)
            {
                changePlayer();
            } else {
                showScores();
            }
        }

    }

    private void showScores()
    {
        Intent intent = new Intent(TwoPlayerShowingQuestion.this, TwoPlayerScore.class);
        intent.putExtra("name1", this.name1);
        intent.putExtra("name2", this.name2);
        intent.putExtra("score1", this.score1);
        intent.putExtra("score2", this.score2);
        startActivity(intent);
        finish();
    }

    private void changePlayer()
    {
        this.first = false;
        this.index = 0;
        TextView textView = this.turn_name;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.name2);
        stringBuilder.append("'s turn");
        textView.setText(stringBuilder.toString());
        this.alert_text.setText("Turn Changed");
        this.alpha_layout.setVisibility(View.VISIBLE);
        this.alert_msg_layout.setVisibility(View.VISIBLE);
    }

    public void onStop() {
        super.onStop();
        this.countDownTimer.cancel();
    }

    public void onDestroy() {
        super.onDestroy();
        this.countDownTimer.cancel();
    }

    public void onBackPressed()
    {
        new FancyAlertDialog.Builder(this).setTitle("Do you really want to Exit?").setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.sad_color))
                .setMessage("You will lose your progress by quitting this level.").setNegativeBtnText("No")
                .setPositiveBtnBackground(ContextCompat.getColor(getApplicationContext(), R.color.sad_color)).setPositiveBtnText("Quit")
                .setNegativeBtnBackground(Color.parseColor("#FFA9A7A8")).setAnimation(Animation.POP).isCancellable(false)
                .setIcon(R.drawable.cross, Icon.Visible).OnPositiveClicked(new FancyAlertDialogListener()
        {
            public void OnClick()
            {
                TwoPlayerShowingQuestion.this.tick.start();
                TwoPlayerShowingQuestion.this.finish();
            }
        }).OnNegativeClicked(new FancyAlertDialogListener()
        {
            public void OnClick()
            {
                TwoPlayerShowingQuestion.this.tick.start();
            }
        }).build();
    }

    public void clickableTextviews(boolean z)
    {
        this.optionA.setClickable(z);
        this.optionB.setClickable(z);
        this.optionC.setClickable(z);
        this.optionD.setClickable(z);
    }

    public void onPause() {
        super.onPause();
        this.countDownTimer.cancel();
    }

    public void onResume() {
        super.onResume();
        if (this.adTimerControl) {
            startingCountDownTimer(this.milliSecondsRemaining);
        }
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }



    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                       countDownTimer.cancel();
                       adTimerControl = false;
                        if (first)
                        {
                            changePlayer();
                        } else {
                            showScores();
                        }
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
