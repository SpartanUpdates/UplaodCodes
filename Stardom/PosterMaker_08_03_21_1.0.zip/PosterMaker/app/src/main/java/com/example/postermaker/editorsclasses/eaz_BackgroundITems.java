package com.example.postermaker.editorsclasses;

import android.view.View;
import android.view.View.OnClickListener;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.editorsclasses.designitems.eaz_BackgroundBorder;
import com.example.postermaker.editorsclasses.designitems.eaz_BackgroundColor;
import com.example.postermaker.editorsclasses.designitems.eaz_BackgroundImages;
import com.example.postermaker.editorsclasses.designitems.eaz_BackgroundSize;

public class eaz_BackgroundITems implements OnClickListener {
    public void loadBackgroundItems() {
        eaz_EditActivity.backgrounditemslayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.backgroundcolor.setOnClickListener(this);
        eaz_EditActivity.backgroundimages.setOnClickListener(this);
        eaz_EditActivity.backgroundsize.setOnClickListener(this);
        eaz_EditActivity.backgroundborder.setOnClickListener(this);
        eaz_EditActivity.backgroundok.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.backgroundcolor)) {
            new eaz_BackgroundColor(view.getContext()).loadBackgroundColors();
        } else if (view.equals(eaz_EditActivity.backgroundimages)) {
            new eaz_BackgroundImages(view.getContext()).loadBackgroundImagesItems();
        } else if (view.equals(eaz_EditActivity.backgroundsize)) {
            new eaz_BackgroundSize().loadBackgroundSizeItems();
        } else if (view.equals(eaz_EditActivity.backgroundborder)) {
            new eaz_BackgroundBorder(view.getContext()).loadBorderItems();
        } else if (view.equals(eaz_EditActivity.backgroundok)) {
            eaz_ConstantValues.bgchoice = 0;
            eaz_EditActivity.backgrounditemslayout.setVisibility(View.GONE);
        }
    }
}
