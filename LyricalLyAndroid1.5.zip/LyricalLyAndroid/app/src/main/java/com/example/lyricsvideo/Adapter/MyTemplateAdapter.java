package com.example.lyricsvideo.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.lyricsvideo.CallFromUnity;
import com.example.lyricsvideo.Model.MytemplateModel;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.activity.FullVideoPlayActivity;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.List;


public class MyTemplateAdapter extends RecyclerView.Adapter<MyTemplateAdapter.Myholder> {
    List<MytemplateModel> mytemplateModelList;
    private Context mContext;
    private String UnityXmlPath, TransparantVideoPath;


    public MyTemplateAdapter(Context mContext, List<MytemplateModel> dataModelArrayList) {
        this.mContext = mContext;
        this.mytemplateModelList = dataModelArrayList;
    }

    @NonNull
    @Override
    public Myholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_my_template, null);
        return new Myholder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull Myholder holder, final int position) {
        final MytemplateModel templatemodel = mytemplateModelList.get(position);

        Picasso.with(mContext).load(mytemplateModelList.get(position).getSmallThemeImage())
                .into(holder.ivVideoThumbnail);
        holder.tvSongName.setText(templatemodel.getVideoName());
        AppFont.Textfont(mContext, holder.tvSongName);

        holder.ivPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mContext, FullVideoPlayActivity.class);
                i.putExtra("Url", templatemodel.getPreviewVideoUrl());
                i.putExtra("Name", templatemodel.getVideoName());
                i.putExtra("videoThumbImage", templatemodel.getSmallThemeImage());
                i.putExtra("IsPlayVidoeFromHome", true);
                i.putExtra("IsVideoFromList", true);
                mContext.startActivity(i);
            }
        });
        holder.btnUseNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityXmlPath = String.valueOf(new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + mytemplateModelList.get(position).getContentZipFolderName() + File.separator + mytemplateModelList.get(position).getVideoName() + ".xml"));
                TransparantVideoPath = String.valueOf(new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + mytemplateModelList.get(position).getContentZipFolderName() + File.separator + mytemplateModelList.get(position).getVideoName() + ".mp4"));
                CallFromUnity.TransparantVideoPath = TransparantVideoPath;
                CallFromUnity.UnityXmlPath = UnityXmlPath;
                CallFromUnity.ImageSelection(mContext, 720, 1280, templatemodel.getNoOfImages(),true);
                ((Activity) mContext).finish();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mytemplateModelList.size();
    }

    class Myholder extends RecyclerView.ViewHolder {
        RelativeLayout rlProgress, rlProgressShare;
        ImageView ivPlay, ivShare, ivDownload;
        ImageView ivVideoThumbnail;
        TextView tvSongName, tvprogress, tvProgressShare;
        AppCompatButton btnUseNow, btnUseNowShare;
        ProgressBar pbDownload, pbShare;

        public Myholder(View itemView) {
            super(itemView);

            ivVideoThumbnail = itemView.findViewById(R.id.imgVideoThumbnail);
            ivDownload = itemView.findViewById(R.id.imgDownload);
            rlProgress = itemView.findViewById(R.id.layoutProgress);
            tvprogress = itemView.findViewById(R.id.txtProgress);
            btnUseNow = itemView.findViewById(R.id.txtUseNow);
            pbDownload = itemView.findViewById(R.id.progressDownload);
            ivShare = itemView.findViewById(R.id.imgShare);
            rlProgressShare = itemView.findViewById(R.id.layoutProgressShare);
            tvProgressShare = itemView.findViewById(R.id.txtProgressShare);
            btnUseNowShare = itemView.findViewById(R.id.txtShareNow);
            pbShare = itemView.findViewById(R.id.progressShare);
            ivPlay = itemView.findViewById(R.id.imgPlay);
            tvSongName = itemView.findViewById(R.id.txtSongName);
        }
    }
}
