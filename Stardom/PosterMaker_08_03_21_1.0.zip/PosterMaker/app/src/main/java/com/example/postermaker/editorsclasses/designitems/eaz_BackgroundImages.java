package com.example.postermaker.editorsclasses.designitems;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.example.postermaker.R;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;

import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;

public class eaz_BackgroundImages implements View.OnClickListener, DiscreteSeekBar.OnProgressChangeListener {
    Context context;
    public int[] images = {R.drawable.a1, R.drawable.a2, R.drawable.a3, R.drawable.a4, R.drawable.a5, R.drawable.a6, R.drawable.a7, R.drawable.a8, R.drawable.a9, R.drawable.a10, R.drawable.a11, R.drawable.a12, R.drawable.a13, R.drawable.a14, R.drawable.a15, R.drawable.a16, R.drawable.a17, R.drawable.a18, R.drawable.a19, R.drawable.a20, R.drawable.a21, R.drawable.a22, R.drawable.a23, R.drawable.a24, R.drawable.a25, R.drawable.a26, R.drawable.a27, R.drawable.a28, R.drawable.a29, R.drawable.a30, R.drawable.a31, R.drawable.a32, R.drawable.a33, R.drawable.a34, R.drawable.a35, R.drawable.a36, R.drawable.a37, R.drawable.a38, R.drawable.a39, R.drawable.a40, R.drawable.a41, R.drawable.a42, R.drawable.a43, R.drawable.a44, R.drawable.a45, R.drawable.a46, R.drawable.a47, R.drawable.a48, R.drawable.a49, R.drawable.a50};
    Bitmap mbitmap;

    @Override // org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener
    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    @Override // org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener
    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public eaz_BackgroundImages(Context context2) {
        this.context = context2;
    }

    public void loadBackgroundImagesItems() {
        eaz_EditActivity.backgroundcolorlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.ok.setOnClickListener(this);
        eaz_EditActivity.cancel.setOnClickListener(this);
        eaz_EditActivity.backgroundbirghtness.setOnProgressChangeListener(this);
        loadImages();
    }

    public void loadImages() {
        eaz_EditActivity.backgroundcolorcontainer.removeAllViews();
        for (int i = 0; i < this.images.length; i++) {
            ImageView imageView = new ImageView(this.context);
            imageView.setLayoutParams(new RelativeLayout.LayoutParams(60, 60));
            Glide.with(this.context).load(this.images[i]).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    if (eaz_ConstantValues.bgchoice == 1) {
                        eaz_EditActivity.backgroundimage.setImageBitmap(BitmapFactory.decodeResource(eaz_BackgroundImages.this.context.getResources(), eaz_BackgroundImages.this.images[finalI]));
                        eaz_EditActivity.backgroundimage.buildDrawingCache();
                        eaz_BackgroundImages.this.mbitmap = eaz_EditActivity.backgroundimage.getDrawingCache();
                        eaz_BackgroundImages.this.roundImageView(eaz_EditActivity.backgroundimage, eaz_ConstantValues.radious);
                    } else if (eaz_ConstantValues.bgchoice == 2) {
                        eaz_EditActivity.forgroundimage.setImageBitmap(BitmapFactory.decodeResource(eaz_BackgroundImages.this.context.getResources(), eaz_BackgroundImages.this.images[finalI]));
                        eaz_EditActivity.forgroundimage.buildDrawingCache();
                        eaz_BackgroundImages.this.mbitmap = eaz_EditActivity.forgroundimage.getDrawingCache();
                        Log.e("TAG","Image");
                        eaz_BackgroundImages.this.roundImageView(eaz_EditActivity.forgroundimage, eaz_ConstantValues.radious);
                        Log.e("TAG", "Postion" + finalI);
                    }
                }
            });
            eaz_EditActivity.backgroundcolorcontainer.addView(imageView);
        }
    }

    public void roundImageView(ImageView imageView, int i) {
        Bitmap createBitmap = Bitmap.createBitmap(this.mbitmap.getWidth(), this.mbitmap.getHeight(), this.mbitmap.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(new BitmapShader(this.mbitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        float f = (float) i;
        canvas.drawRoundRect(new RectF(0.0f, 0.0f, (float) this.mbitmap.getWidth(), (float) this.mbitmap.getHeight()), f, f, paint);
        imageView.setImageBitmap(createBitmap);
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.ok)) {
            eaz_EditActivity.backgroundcolorlayout.setVisibility(View.GONE);
        } else if (view.equals(eaz_EditActivity.cancel)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                eaz_EditActivity.backgroundimage.setBackgroundResource(0);
            } else if (eaz_ConstantValues.bgchoice == 2) {
                eaz_EditActivity.forgroundimage.setBackgroundResource(0);
            }
            eaz_EditActivity.backgroundcolorlayout.setVisibility(View.GONE);
        }
    }

    @Override // org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener
    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z) {
        if (eaz_ConstantValues.bgchoice == 1) {
            eaz_EditActivity.backgroundimage.setAlpha(i);
        } else if (eaz_ConstantValues.bgchoice == 2) {
            eaz_EditActivity.forgroundimage.setAlpha(i);
        }
    }
}
