package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;

public class CollageImage implements View.OnClickListener {
    public CollageImage(CollageMakerDetailActivity collageMakerDetailActivity) {
    }

    public void onClick(View view) {
    }
}

