package com.jenilcreation.photomusicvideo.activity;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.jenilcreation.photomusicvideo.MyApplication;
import com.jenilcreation.photomusicvideo.R;
import com.jenilcreation.photomusicvideo.adapters.ImageByAlbumAdapter;
import com.jenilcreation.photomusicvideo.adapters.OnItemClickListner;
import com.jenilcreation.photomusicvideo.adapters.SelectedImageAdapter;
import com.jenilcreation.photomusicvideo.data.ImageData;


public class FragmentOne extends Fragment {
    private RecyclerView rvAlbumImages;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private SelectedImageAdapter selectedImageAdapter;
    public static CheckBox chbAllSelect;
    ImageView ivDownarrow;
    Button btnDoneFregment;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_one, viewGroup, false);
        rvAlbumImages = (RecyclerView) view.findViewById(R.id.rvImageAlbum);
        this.chbAllSelect = (CheckBox) view.findViewById(R.id.chbAllSelect);
        this.chbAllSelect.setChecked(false);
        this.ivDownarrow = (ImageView) view.findViewById(R.id.ivDownarrow);
        btnDoneFregment = (Button) view.findViewById(R.id.btnDoneFregment);
        btnDoneFregment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhotoselectActivity.fregmentLayouts.setVisibility(View.GONE);
            }
        });
        chbAllSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean bb) {
                if (chbAllSelect.isChecked()) {
                    Allselect();
                    ivDownarrow.setVisibility(View.VISIBLE);
                }
            }
        });
        albumImagesAdapter = new ImageByAlbumAdapter(getContext());
        this.selectedImageAdapter = new SelectedImageAdapter(getContext());
        this.application = MyApplication.getInstance();
        rvAlbumImages.setLayoutManager(new GridLayoutManager(getContext(), 3));
        rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumImages.setAdapter(this.albumImagesAdapter);
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                PhotoselectActivity.tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
                selectedImageAdapter.notifyDataSetChanged();
            }
        });
        return view;
    }

    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }

    private void Allselect() {
        int ii = 0;
        while (getItemCount() != ii) {
            final ImageData item = this.getItem(ii);
            this.application.addSelectedImage(item);
            PhotoselectActivity.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            albumImagesAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
            ++ii;
        }

        Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.bottom_down_slow);
        ivDownarrow.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ivDownarrow.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
