﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ShowToast : MonoBehaviour
{
    public static ShowToast instance;
    
    void Awake()
    {
        instance = this;
    }

    public void ShowToastString(string name="Test ok..")
    {
         AndroidJavaClass toastClass = 
                    new AndroidJavaClass("android.widget.Toast");
 
         object[] toastParams = new object[3];
         AndroidJavaClass unityActivity = 
           new AndroidJavaClass ("com.unity3d.player.UnityPlayer");
         toastParams[0] = 
                      unityActivity.GetStatic<AndroidJavaObject>
                                ("currentActivity");
         toastParams[1] = name;
         toastParams[2] = toastClass.GetStatic<int>
                                ("LENGTH_LONG");
 
         AndroidJavaObject toastObject = 
                         toastClass.CallStatic<AndroidJavaObject>
                                       ("makeText", toastParams);
         toastObject.Call ("show");
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.L))
        {
            PlayerPrefs.DeleteAll();
        }
    }
}
