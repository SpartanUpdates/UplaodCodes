import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:lottie/lottie.dart';
import 'package:rto_app/History%20Screen/controller/history_controller.dart';
import 'package:rto_app/Owner%20Info%20Screen/controllers/controllers.dart';
import 'package:rto_app/Owner%20Info%20Screen/view/owner_info.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/text.dart';

class HistoryScreen extends StatelessWidget {
  HistoryController historyController = Get.put(HistoryController());
  static bool isDataAvailable = false;
  @override
  Widget build(BuildContext context) {
    historyController.getAllData();
    return WillPopScope(
      onWillPop: () {
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).primaryColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "Owner Info History",
                      style: TextStyle(
                          fontSize: 16.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ),
                    leading: Card(
                      color: Theme.of(context).primaryColor,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                          side: BorderSide(
                              width: 0.3,
                              color: Theme.of(context).primaryColor)),
                      child: InkWell(
                        customBorder: new CircleBorder(),
                        onTap: () {
                          Future.delayed(const Duration(milliseconds: 350), () {
                            Navigator.pop(context);
                          });
                        },
                        splashColor: Colors.black54,
                        child: Padding(
                          padding: EdgeInsets.all(10),
                          child: new Icon(
                            Icons.arrow_back_ios,
                            size: 22,
                            color: Theme.of(context).accentColor,
                          ),
                        ),
                      ),
                    ).pOnly(left: 10),
                  )
                ];
              },
              body: Column(
                children: [
                  Expanded(
                    child: Container(
                      color: Theme.of(context).primaryColor,
                      child: GetBuilder<HistoryController>(
                        builder: (controller) {
                          return isDataAvailable
                              ? getData(controller)
                              : Center(
                                  child: CircularProgressIndicator(),
                                );
                        },
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

getData(HistoryController controller) {
  MainControllers mainControllers = Get.put(MainControllers());
  return controller.ownerInfoList.length == 0
      ? Center(
          child: noDataMethod(),
        ).pOnly(bottom: 50)
      : GetBuilder<HistoryController>(builder: (controller) {
          return ListView.builder(
              physics: BouncingScrollPhysics(),
              itemCount: controller.ownerInfoList.length,
              itemBuilder: (context, index) {
                return Container(
                  child: Row(
                    children: [
                      Expanded(
                        child: Card(
                          elevation: 0,
                          color: Theme.of(context).cardColor,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: InkWell(
                            splashColor: Theme.of(context).hoverColor,
                            onTap: () {
                              Get.to(OwnerInfo(
                                  false,
                                  controller
                                      .ownerInfoList[index].licensePlate));
                              mainControllers.fetchOwnerData(context,
                                  controller.ownerInfoList[index].licensePlate);
                            },
                            child: ListTile(
                                visualDensity: VisualDensity(vertical: -2),
                                contentPadding: EdgeInsets.symmetric(
                                    vertical: 3, horizontal: 5),
                                dense: true,
                                leading: Icon(
                                  Icons.car_rental,
                                  size: 40,
                                ),
                                title: Text(
                                        controller
                                            .ownerInfoList[index].ownerName,
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: Theme.of(context).hintColor))
                                    .text
                                    .size(15)
                                    .make()
                                    .pOnly(bottom: 7.5, top: 3),
                                subtitle: Text(
                                        controller
                                            .ownerInfoList[index].licensePlate,
                                        style: TextStyle(
                                            fontFamily: "Circular Medium",
                                            color: Colors.grey))
                                    .text
                                    .size(13)
                                    .make()),
                          ),
                        ),
                      ),
                      Card(
                        color: Theme.of(context).cardColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25),
                            side: BorderSide(
                                width: 0.3,
                                color: Theme.of(context).primaryColor)),
                        child: InkWell(
                          customBorder: new CircleBorder(),
                          onTap: () {
                            CommanDialog.deleteDialog(
                                context, controller, index);
                          },
                          splashColor: Colors.red,
                          child: Padding(
                            padding: EdgeInsets.all(5),
                            child: new Icon(
                              Icons.clear,
                              size: 30,
                              color: Colors.blueGrey,
                            ),
                          ),
                        ),
                      )
                    ],
                  ).px(10).py(2),
                );
              }).pOnly(top: 10);
        });
}

noDataMethod() {
  return Lottie.asset(
    "assets/lottie/alertno.json",
    height: 200,
    width: 200,
  );
}
