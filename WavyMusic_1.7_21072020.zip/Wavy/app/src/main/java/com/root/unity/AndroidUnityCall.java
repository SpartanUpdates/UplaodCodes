package com.root.unity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.Utils.AppGeneral;
import com.wavymusic.Utils.Utils;
import com.wavymusic.activity.HomeActivity;
import com.wavymusic.activity.LanguageSelectActivity;
import com.wavymusic.activity.SelectImageActivity;
import com.wavymusic.activity.ShareActivity;
import com.wavymusic.activity.SongSelectActivity;
import com.wavymusic.activity.TextEditActivity;
import com.wavymusic.application.MyApplication;
import java.io.File;

public class AndroidUnityCall {

    public static KProgressHUD hud;

    public static void HomeActivity(Context context) {
        if (LanguagePref.a(context).a("pref_key_is_language_set", false)) {
            if (MyApplication.IsHomeAdsDisplay) {
                loadHomeActivityWithAds(context);
            } else {
                loadHomeActivity(context);
            }
        } else {
            Intent intent = new Intent(context, LanguageSelectActivity.class);
            context.startActivity(intent);
        }
    }

    private static void loadHomeActivityWithAds(final Context context) {
        MyApplication.AppLaunchContex = context;
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                if (MyApplication.IsHomeAdsDisplay && MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
                    try {
                        hud = KProgressHUD.create(context)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
                                MyApplication.IsHomeAdsDisplay = true;
                                MyApplication.fbinterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadHomeActivity(context);
                }
            }
        });
    }

    public static void loadHomeActivity(Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.putExtra("IsFromLanguage", false);
        intent.putExtra("IsFromMain", true);
        context.startActivity(intent);
    }

    public static void OpenGallery(Context context) {
        MyApplication.IsSelectImageFrom = false;
        MyApplication.TotalSelectedImage = 6;
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, SelectImageActivity.class);
        intent.putExtra("NoofImage", 6);
        context.startActivity(intent);
    }

    public static void SelectSong(Context context) {
        context.startActivity(new Intent(context, SongSelectActivity.class));
    }

    public static void ChangeName(Context context, String str) {
        Intent intent = new Intent(context, TextEditActivity.class);
        intent.putExtra("JsonStr", str);
        context.startActivity(intent);
    }

    public static void PlayVideo(Context context, String VideoPath) {
        UnityPlayerActivity.unityPlayeractivity.particalCatAdapter.selectedPosition = -1;
        UnityPlayerActivity.unityPlayeractivity.particalItemAdapter.selectedPosition = -1;
//        Intent intent = new Intent(context, VideoPlayerActivity.class);
        Intent intent = new Intent(context, ShareActivity.class);
        MyApplication.VidoePath = VideoPath.substring(VideoPath.lastIndexOf("/") + 1);
        intent.putExtra("VideoUrl", VideoPath);
        intent.putExtra("VideoPosition", 0);
//        intent.putExtra("AllVideoList", Utils.getAllCreatedVideoList(context));
        intent.putExtra("IsVideoFromAndroidList", false);
        context.startActivity(intent);
        ScanVideoList(context, Utils.INSTANCE.getStoryFolderPath() + File.separator + MyApplication.VidoePath);
        ClearSelection(context);
        DeleteCropImages();
    }

    public static void HideBannerAds(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void createVideo(final Context context, final String videoInputName, final String VideoOutputName) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                AppGeneral.AudioVideoShort(context, videoInputName, VideoOutputName);
            }
        }, 100);
        Log.e("createVideo", "Video Mute Name" + videoInputName);
        Log.e("createVideo", "From SdCard" + VideoOutputName);
    }

    public static void prepareSongForCreateVideo(Context context, String VideoOutNameMute, String fromSdcard, String AudioInputpath, String VideoInputNameUnited) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Log.e("AndUnityCall", "Video Mute Name" + VideoOutNameMute);
        Log.e("AndUnityCall", "From SdCard" + fromSdcard);
        Log.e("AndUnityCall", "Audio Song Path" + AudioInputpath);
//      Log.e("AndUnityCall", "Video Final Name" + VideoInputNameUnited);
        AppGeneral.AddSongTOVideo(context, VideoOutNameMute, fromSdcard, AudioInputpath, VideoInputNameUnited);
    }


    public static void ClearSelection(Context context) {
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImages().clear();
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + "CropTempImg" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void ScanVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void BackToMain(final Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                ((Activity) context).runOnUiThread(new Runnable() {
                    public final void run() {
                        UnityPlayerActivity.unityPlayeractivity.HidePartical();
                        UnityPlayerActivity.unityPlayeractivity.hideBottom();
                    }
                });
                AndroidUnityCall.showClose(context);
                UnityPlayerActivity.unityPlayeractivity.particalCatAdapter.selectedPosition = -1;
                UnityPlayerActivity.unityPlayeractivity.particalItemAdapter.selectedPosition = -1;
                AndroidUnityCall.ClearSelection(context);
            }
        });
    }

    private static void showClose(final Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void CloseFilterPanel(Context context) {
        Log.e("TAG", "CloseFiterPanel");
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HideFilterPanel();
            }
        });
    }

    public static void GoToPreview(Context context) {
//        Log.e("TAG","GoToPreview");
        try {
            ((Activity) context).runOnUiThread(new Runnable() {
                public final void run() {
                    UnityPlayerActivity.unityPlayeractivity.showBottom();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   /* public static void ShowBottomData(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.showBottom();
            }
        });
    }

    public static void HidePartical(Context context) {
        Log.e("TAG", "HidePartical");
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.HidePartical();
            }
        });
    }

    public static void HideBottomData(Context context) {
        Log.e("TAG", "HideBottomData");
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.hideBottom();
            }
        });
    }*/

    public static void HideLyricStyles(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.StyleGoneWithoutAnimation();
                UnityPlayerActivity.unityPlayeractivity.HidePartical();
                UnityPlayerActivity.unityPlayeractivity.hideBottom();
                UnityPlayerActivity.unityPlayeractivity.SetSelection(false, false);
            }
        });
    }
}
