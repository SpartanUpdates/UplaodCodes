package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity.RtoOfficeInfoDetailActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {

    private Context context;
    private ArrayList<String> listGroup;
    private HashMap<String, List<String>> bindList;
    private String StateName;
    private DarkTheame darkTheame;

    public ExpandableListViewAdapter(Context context, ArrayList<String> listGroup, HashMap<String, List<String>> bindList) {
        this.context = context;
        this.listGroup = listGroup;
        this.bindList = bindList;
        this.darkTheame=new DarkTheame(context);
    }

    @Override
    public int getGroupCount() {
        return listGroup.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return bindList.get(listGroup.get(groupPosition)).size();
    }
    @Override
    public Object getGroup(int groupPosition) {
        return listGroup.get(groupPosition);
    }
    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return bindList.get(listGroup.get(groupPosition)).get(childPosition);
    }
    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        StateName = (String) getGroup(groupPosition).toString();
        if(convertView==null)
        {
            LayoutInflater layoutInflater=(LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=layoutInflater.inflate(R.layout.layout_liststatename,null);
        }
        TextView stateName=convertView.findViewById(R.id.stateName);
        RelativeLayout rl_state_layout=convertView.findViewById(R.id.rl_state);
        if(darkTheame.modeData().equals("nightMode"))
        {
            rl_state_layout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        }
        stateName.setText(StateName);
        return convertView;
    }
    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final String childText = (String) getChild(groupPosition, childPosition);
        if(convertView==null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.layout_listcity_group, null);
        }
        TextView tv_cityName = convertView.findViewById(R.id.tv_cityName);
        LinearLayout ll_click = convertView.findViewById(R.id.ll_click);
        if(darkTheame.modeData().equals("nightMode"))
        {
            ll_click.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        }
        final String[] code = childText.split(">");
        tv_cityName.setText(code[0]+"    "+code[1]);
        final String state=code[2];
        final String address=code[3];
        final String contact=code[4];
        final String website=code[5];
        ll_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RtoOfficeInfoDetailActivity.class);
                intent.putExtra("cityCode", code[0]);
                intent.putExtra("cityName", code[1]);
                intent.putExtra("StateName", state);
                intent.putExtra("address", address);
                intent.putExtra("contact", contact);
                intent.putExtra("website", website);
                context.startActivity(intent);
            }
        });
        return convertView;
    }
    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }
}
