package com.esc.motivationquotes.model;

public class ViewMode {
    private String mode;
}
