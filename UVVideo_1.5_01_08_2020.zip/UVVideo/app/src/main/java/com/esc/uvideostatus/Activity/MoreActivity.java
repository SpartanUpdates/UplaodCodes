package com.esc.uvideostatus.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.esc.uvideostatus.Adapters.MoreAppAdapter;
import com.esc.uvideostatus.Models.App_data;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.MyApplication;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MoreActivity extends AppCompatActivity {

    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);

        array_appdata = new ArrayList<>();
        makeJsonRequest(getResources().getString(R.string.more_appurl));
        recyclerView = (RecyclerView) findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(MoreActivity.this, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(MoreActivity.this, array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

}
