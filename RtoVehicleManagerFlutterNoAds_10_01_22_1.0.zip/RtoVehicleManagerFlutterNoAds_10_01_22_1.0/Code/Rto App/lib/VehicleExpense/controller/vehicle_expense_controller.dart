import 'package:get/get.dart';
import 'package:rto_app/VehicleExpense/model/vehicle_expense_model.dart';
import 'package:rto_app/VehicleExpense/view/vehicle_expense.dart';
import 'package:rto_app/VehicleExpense/view/vehicle_expense_category.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'dart:io' as io;

class VehicleExpenseController extends GetxController {
  int selectedType = 1;
  List<VehicleExpenseModel> allDataList = [];
  List<VehicleExpenseModel> dateList = [];
  List<VehicleExpenseModel> searchedData = [];
  int total = 0;
  String? itemError = null;
  String? noteError = null;
  String? amountError = null;

  static Database? _db;
  Future<Database?> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDatabase();
    return _db;
  }

  @override
  void onReady() {
    super.onReady();
  }

  initDatabase() async {
    io.Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, 'vehicleexpense.db');
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute(
        "CREATE TABLE vehicle (id INTEGER PRIMARY KEY AUTOINCREMENT,randomId TEXT NOT NULL,date TEXT NOT NULL,itemName TEXT NOT NULL,note TEXT NOT NULL,amount TEXT NOT NULL,type TEXT NOT NULL)");
  }

  Future<int> delete(String randomId) async {
    try {
      var dbClient = await db;
      return await dbClient!
          .delete('vehicle', where: 'randomId=?', whereArgs: [randomId]);
    } on Exception catch (_) {
      throw Exception("error");
    }
    update();
  }

  Future<void> itemValidation(bool empty) async {
    if (empty) {
      itemError = "This should not be empty";
    } else {
      itemError = null;
    }
    update();
  }

  Future<void> noteValidation(bool empty) async {
    if (empty) {
      noteError = "This should not be empty";
    } else {
      noteError = null;
    }
    update();
  }

  Future<void> amountValidation(bool empty) async {
    if (empty) {
      amountError = "This should not be empty";
    } else {
      amountError = null;
    }
    update();
  }

  Future<void> insert(VehicleExpenseModel notesModel) async {
    try {
      var dbClient = await db;
      await dbClient!.insert('vehicle', notesModel.toMap());
    } on Exception catch (e) {
      throw Exception(e.toString());
    }
  }

  Future<void> getDateWiseData() async {
    var dbClient = await db;
    final List<Map<String, Object?>> queryResult =
        await dbClient!.rawQuery('select * from vehicle group by date');
    dateList = queryResult.map((e) => VehicleExpenseModel.fromMap(e)).toList();
    VehicleExpense.isDataAvailable = true;
    update();
  }

  Future<void> getAllData() async {
    try {
      var dbClient = await db;
      final List<Map<String, Object?>> queryResult =
          await dbClient!.rawQuery('select * from vehicle');
      allDataList =
          queryResult.map((e) => VehicleExpenseModel.fromMap(e)).toList();
      VehicleExpense.isDataAvailable = true;
    } on Exception catch (_) {
      VehicleExpense.isDataAvailable = false;
      throw Exception("error");
    }
    getTotal();
    update();
  }

  Future<void> getDataByDate(String date) async {
    try {
      var dbClient = await db;
      final List<Map<String, Object?>> queryResult = await dbClient!
          .rawQuery('select * from vehicle where date=?', [date]);
      allDataList =
          queryResult.map((e) => VehicleExpenseModel.fromMap(e)).toList();
    } on Exception catch (_) {
      throw Exception("Error on server");
    }
    update();
  }

  Future<void> getTotal() async {
    int temp = 0;
    for (int i = 0; i < allDataList.length; i++) {
      temp = temp + int.parse(allDataList[i].amount);
      total = temp;
    }
    print("total ${temp}");
    update();
  }

  Future<void> selectionMethod(int number) async {
    if (number == 1) {
      VehicleExpenseCategory.assesoriesSelected = true;
      VehicleExpenseCategory.cleaningSelected = false;
      VehicleExpenseCategory.carFuleSelected = false;
      VehicleExpenseCategory.maintenanceSelected = false;
      VehicleExpenseCategory.otherSelected = false;
      selectedType = 1;
    }
    if (number == 2) {
      VehicleExpenseCategory.assesoriesSelected = false;
      VehicleExpenseCategory.cleaningSelected = true;
      VehicleExpenseCategory.carFuleSelected = false;
      VehicleExpenseCategory.maintenanceSelected = false;
      VehicleExpenseCategory.otherSelected = false;
      selectedType = 2;
    }
    if (number == 3) {
      VehicleExpenseCategory.assesoriesSelected = false;
      VehicleExpenseCategory.cleaningSelected = false;
      VehicleExpenseCategory.carFuleSelected = true;
      VehicleExpenseCategory.maintenanceSelected = false;
      VehicleExpenseCategory.otherSelected = false;
      selectedType = 3;
    }
    if (number == 4) {
      VehicleExpenseCategory.assesoriesSelected = false;
      VehicleExpenseCategory.cleaningSelected = false;
      VehicleExpenseCategory.carFuleSelected = false;
      VehicleExpenseCategory.maintenanceSelected = true;
      VehicleExpenseCategory.otherSelected = false;
      selectedType = 4;
    }
    if (number == 5) {
      VehicleExpenseCategory.assesoriesSelected = false;
      VehicleExpenseCategory.cleaningSelected = false;
      VehicleExpenseCategory.carFuleSelected = false;
      VehicleExpenseCategory.maintenanceSelected = false;
      VehicleExpenseCategory.otherSelected = true;
      selectedType = 5;
    }
    update();
  }
}
