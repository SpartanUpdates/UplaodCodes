package com.kotlinz.videostatusmaker.Utils;

import android.graphics.Bitmap;
import android.net.Uri;

import java.util.ArrayList;

public class Utils {
    public static boolean complete;
    public static int count;
    public static ArrayList<String> photos;
    public static Bitmap save;
    public static Bitmap selected_Bitmap;
    public static Uri uri;
    public static String video_url;

    static {
        Utils.photos = new ArrayList<String>();
        Utils.complete = false;
        Utils.count = 0;
    }
}
