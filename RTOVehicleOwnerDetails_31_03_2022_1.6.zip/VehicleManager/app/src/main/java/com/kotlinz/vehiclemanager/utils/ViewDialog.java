package com.kotlinz.vehiclemanager.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoPreperationActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity.RtoQuestionActivity;

public class ViewDialog {

    public void showDialog(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.custom_dialog_layout);
        dialog.show();

        Button start = dialog.findViewById(R.id.start);
        Button cancel = dialog.findViewById(R.id.cancle);
        TextView correctAndTxt = dialog.findViewById(R.id.correctAnsTxt);
        TextView timeTxt = dialog.findViewById(R.id.timeTxt);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            correctAndTxt.setTextColor(Color.parseColor("#FFFFFF"));
            timeTxt.setTextColor(Color.parseColor("#FFFFFF"));
            start.setTextColor(Color.parseColor("#FFFFFF"));
            cancel.setTextColor(Color.parseColor("#FFFFFF"));
            mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        }

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RtoPreperationActivity.activity.startGame();
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                activity.startActivity(new Intent(RtoPreperationActivity.activity, MainActivity.class));
            }
        });
    }

    public void showDialogForExam(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.custom_dialog_layout);
        dialog.show();

        Button start = dialog.findViewById(R.id.start);
        Button cancel = dialog.findViewById(R.id.cancle);
        TextView correctAndTxt = dialog.findViewById(R.id.correctAnsTxt);
        TextView timeTxt = dialog.findViewById(R.id.timeTxt);
        TextView totalQue = dialog.findViewById(R.id.totalQue);
        TextView correct = dialog.findViewById(R.id.correct);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            correctAndTxt.setTextColor(Color.parseColor("#FFFFFF"));
            timeTxt.setTextColor(Color.parseColor("#FFFFFF"));
            correct.setTextColor(Color.parseColor("#FFFFFF"));
            start.setTextColor(Color.parseColor("#FFFFFF"));
            cancel.setTextColor(Color.parseColor("#FFFFFF"));
            mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        }

        totalQue.setText("Total Questions : 15");
        correct.setVisibility(View.VISIBLE);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RtoQuestionActivity.activity.startGame(activity);
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                activity.startActivity(new Intent(RtoQuestionActivity.activity, MainActivity.class));
            }
        });
    }


    public void showDialogForUpdate(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.update_dialog);
        dialog.show();

        Button update = dialog.findViewById(R.id.update);
        TextView updateTxt = dialog.findViewById(R.id.updateTxt);
        TextView updateTxt2 = dialog.findViewById(R.id.updateTxt2);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            updateTxt.setTextColor(Color.parseColor("#FFFFFF"));
            updateTxt2.setTextColor(Color.parseColor("#FFFFFF"));
        }
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(activity.getString(R.string.rate_us_url) + activity.getPackageName())));
                    ;
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
    }

    public void showDialogForMaintenance(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.update_dialog);
        dialog.show();

        Button update = dialog.findViewById(R.id.update);
        TextView updateTxt = dialog.findViewById(R.id.updateTxt);
        TextView updateTxt2 = dialog.findViewById(R.id.updateTxt2);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            updateTxt.setTextColor(Color.parseColor("#FFFFFF"));
            updateTxt2.setTextColor(Color.parseColor("#FFFFFF"));
            update.setTextColor(Color.parseColor("#FFFFFF"));
        }

        updateTxt.setText("Coming Soon in update...");
        updateTxt2.setText("Stay tuned with us.");
        update.setText("Back to home");
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.startActivity(new Intent(activity, MainActivity.class));
            }
        });
    }


    public void showDialogForPreperationResult(Activity activity, int correct, int wrong, int high) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.preperation_result_dialog_layout);
        dialog.show();


        Button restart = dialog.findViewById(R.id.restart);
        Button home = dialog.findViewById(R.id.home);
        TextView correctAndTxt = dialog.findViewById(R.id.correctAnsTxt);
        TextView wrongAns = dialog.findViewById(R.id.wrongAndTxt);
        TextView attendedQuestions = dialog.findViewById(R.id.attendedQuestion);
        TextView highScore = dialog.findViewById(R.id.highScore);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        DarkTheame darkTheame = new DarkTheame(activity);
        if (darkTheame.modeData().equals("nightMode")) {
            correctAndTxt.setTextColor(Color.parseColor("#FFFFFF"));
            wrongAns.setTextColor(Color.parseColor("#FFFFFF"));
            attendedQuestions.setTextColor(Color.parseColor("#FFFFFF"));
            restart.setTextColor(Color.parseColor("#FFFFFF"));
            home.setTextColor(Color.parseColor("#FFFFFF"));
            highScore.setTextColor(Color.parseColor("#FFFFFF"));
            mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        }

        correctAndTxt.setText(String.valueOf("Correct Ans : " + correct));
        wrongAns.setText(String.valueOf("Wrong Ans : " + wrong));
        highScore.setText("Score : " + high + "  ,  Total Q : " + (correct + wrong));

        if (correct < 8) {
            attendedQuestions.setText("More Preparation Required");
        }
        if (correct < 15 && correct > 7) {
            attendedQuestions.setText("Good");
        }
        if (correct > 20) {
            attendedQuestions.setText("Excellent");
        }

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.startActivity(new Intent(RtoPreperationActivity.activity, RtoPreperationActivity.class));
                activity.finish();
                dialog.dismiss();
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                activity.startActivity(new Intent(RtoPreperationActivity.activity, MainActivity.class));
                activity.finish();
            }
        });
    }
}