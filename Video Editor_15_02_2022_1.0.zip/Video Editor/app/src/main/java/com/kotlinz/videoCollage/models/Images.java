package com.kotlinz.videoCollage.models;

import java.util.ArrayList;

public class Images {
    ArrayList<String> al_imagepath;
    private boolean isChecked = false;
    private String path;
    String str_folder;

    public boolean isChecked() {
        return this.isChecked;
    }

    public void setChecked(boolean z) {
        this.isChecked = z;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public String getStr_folder() {
        return this.str_folder;
    }

    public void setStr_folder(String str) {
        this.str_folder = str;
    }

    public ArrayList<String> getAl_imagepath() {
        return this.al_imagepath;
    }

    public void setAl_imagepath(ArrayList<String> arrayList) {
        this.al_imagepath = arrayList;
    }
}
