package com.root.unity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import com.unitedvideos.UnityPlayerActivity;
import com.unitedvideos.Utils.Utils;
import com.unitedvideos.activity.ArrangePhotosActivity;
import com.unitedvideos.activity.DynamicTextFieldActivity;
import com.unitedvideos.activity.HomeActivity;
import com.unitedvideos.activity.ImageSelectionActivity;
import com.unitedvideos.activity.ShareActivity;
import com.unitedvideos.activity.SongSelectActivity;
import com.unitedvideos.activity.VideoPlayerActivity;
import com.unitedvideos.application.MyApplication;
import com.unitedvideos.videolib.libffmpeg.Util;

import java.io.File;

public class AndroidUnityCall {
    public static String BundelPath;
    public static String PrefebName;
    public static String AudioPath;

    public static String VideoType;
    public static int ImageWidth;
    public static int ImageHeight;
    public static int NoofImage;

    public static void HomeActivity(final Context cntx) {
        Intent i = new Intent(cntx, HomeActivity.class);
        cntx.startActivity(i);
    }

    public static void ImageSelection(Context cntx, int width, int hight, int numOfImages, String isCut, boolean imageupdate, String IsFrom) {
        MyApplication.TotalSelectedImage = numOfImages;
        Intent intent = new Intent(cntx, ImageSelectionActivity.class);
        intent.putExtra("hight", hight);
        intent.putExtra("width", width);
        intent.putExtra("isCut", isCut);
        intent.putExtra("Imageupdate", imageupdate);
        intent.putExtra("isfrom", IsFrom);
        cntx.startActivity(intent);
    }

//    public static void ImageSelectionUpdate(Context cntx, int width, int hight, int numOfImages, String isCut, String imageupdate) {
//        MyApplication.TotalSelectedImage = numOfImages;
//        Intent i = new Intent(cntx, ImageSelectionActivity.class);
//        i.putExtra("hight", hight);
//        i.putExtra("width", width);
//        i.putExtra("isCut", isCut);
//        i.putExtra("Imageupdate", imageupdate);
//        i.putExtra("isfrom","unity");
//        cntx.startActivity(i);
//    }

    public static void ArrangeActivity(Context context, boolean arrange) {
        Intent i = new Intent(context, ArrangePhotosActivity.class);
        i.putExtra("Imagearrange", arrange);
        context.startActivity(i);
    }

    public static void SongSelection(Context cntx) {
        Intent i = new Intent(cntx, SongSelectActivity.class);
        cntx.startActivity(i);
    }


    public static void ChangeName(Context context, String JsonData) {
        Intent intent = new Intent(context, DynamicTextFieldActivity.class);
        intent.putExtra("JsonStr", JsonData);
        Log.e("TAG", "ChangeName: " + JsonData);
        context.startActivity(intent);
    }


    public static void VideoPlayActivity(Context context, String VideoPath) {
        String path = Utils.INSTANCE.getStoryFolderPath() + VideoPath;
        MyApplication.VidoePath = path.substring(path.lastIndexOf("/") + 1);
//        Intent intent = new Intent(context, VideoPlayerActivity.class);
        Intent intent = new Intent(context, ShareActivity.class);
        intent.putExtra("VideoUrl", path);
        intent.putExtra("VideoPosition", 0);
        intent.putExtra("AllVideoList", Utils.getAllCreatedVideoList(context));
        intent.putExtra("IsVideoFromAndroidList", false);
        context.startActivity(intent);
        ScanVideoList(context, Utils.INSTANCE.getStoryFolderPath() + File.separator + MyApplication.VidoePath);
        AndroidUnityCall.ClearSelection(context);
        DeleteCropImages();
    }


    public static void ClearSelection(Context context) {
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImages().clear();
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + ".Crop Image" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void ScanVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void GoToPreview(Context context) {
        Log.e("TAG","GoToPreview");
        try {
            ((Activity) context).runOnUiThread(new Runnable() {
                public final void run() {
                    UnityPlayerActivity.unityPlayeractivity.showBottom();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public static void ShowBottomData(Context context) {
//        ((Activity) context).runOnUiThread(new Runnable() {
//            public final void run() {
//                UnityPlayerActivity.unityPlayeractivity.showBottom();
//            }
//        });
//    }

    public static void HideBottomData(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.hideBottom();
            }
        });
    }

    public static void HideBannerAds(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void BackToMain(final Context context) {
        Log.e("TAG","BackToMain");
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.hideBottom();
                AndroidUnityCall.showClose(context);
//                AndroidUnityCall.ClearSelection(context);
            }

        });
    }

    private static void showClose(final Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void SaveVideo(Context context){
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.SaveVideo();
            }
        });
    }
    public static void createVideo(final Context context, final String VideoMuteName, final String VideoFinalName) {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                AppUsages.AudioVideoShort(context, VideoMuteName, VideoFinalName);
            }
        }, 3000);
//        AppUsages.AudioVideoShort(context, VideoMuteName, VideoFinalName);
        Log.e("TAG", "createVideo VideoMuteName" + VideoMuteName);
        Log.e("TAG", "createVideo VideoFinalName" + VideoFinalName);
    }

    public static void prepareSongForCreateVideo(final Context context, String AudioTime, String VideoMuteName, String FromSdCard, String AudioInputPath, String VideoFinalName) {
        Log.e("TAG", "AudioTime" + AudioTime);
        Log.e("TAG", "VideoMuteName" + VideoMuteName);
        Log.e("TAG", "FromSdCard" + FromSdCard);
        Log.e("TAG", "AudioInputPath" + AudioInputPath);
        Log.e("TAG", "VideoFinalName" + VideoFinalName);
        AppUsages.AddSongTOVideo(context, AudioTime, VideoMuteName, FromSdCard, AudioInputPath, VideoFinalName);
    }
}
