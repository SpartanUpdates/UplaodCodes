package com.esc.socialmediacleaner.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.adapter.FilesAdapter;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.activity.FileTabsScreen;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;

import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DocFragment extends Fragment {
    private final AppCompatCheckBox cheSlectAll;
    private final Context context;
    private final ArrayList<FileDataWrapper> dataList;
    private FilesAdapter mAdapter;
    private RecyclerView recyclerView;
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (context != null) {
                if (intent.getBooleanExtra("REFRESH", false)) {
                    DocFragment.this.recyclerView.removeAllViews();
                }
                int intExtra = intent.getIntExtra("SORT", 0);
                if (intExtra == 1) {
                    DocFragment.this.sortByDate();
                } else if (intExtra == 2) {
                    DocFragment.this.sortBySize();
                }
                try {
                    DocFragment.this.mAdapter.notifyDataSetChanged();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    };

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onResume() {
        super.onResume();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.dataList.size());
        String str = "";
        stringBuilder.append(str);
        String str2 = "SIZE";
        Log.d(str2, stringBuilder.toString());
        if (MyApplication.getInstance().allData.dataDeleted) {
            int size = this.dataList.size();
            int i = 0;
            while (i < size) {
                if (new File(((FileDataWrapper) this.dataList.get(i)).path).exists()) {
                    i++;
                } else {
                    this.dataList.remove(i);
                    size--;
                }
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append(this.dataList.size());
            stringBuilder.append(str);
            Log.d(str2, stringBuilder.toString());
            FilesAdapter filesAdapter = this.mAdapter;
            if (filesAdapter != null) {
                filesAdapter.notifyDataSetChanged();
            }
        }
    }

    public DocFragment(Context context, ArrayList<FileDataWrapper> arrayList, AppCompatCheckBox appCompatCheckBox) {
        this.context = context;
        this.dataList = arrayList;
        this.cheSlectAll = appCompatCheckBox;
        sortBySize();
    }

    private void sortBySize() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.size, fileDataWrapper.size);
            }
        });
    }

    private void sortByDate() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.lastModified, fileDataWrapper.lastModified);
            }
        });
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.doc_file_fragment, viewGroup, false);
        ((FileTabsScreen) this.context).findViewById(R.id.tv_select_toggle).setVisibility(View.GONE);
        this.mAdapter = new FilesAdapter(this.context, this.dataList, this.cheSlectAll);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.context);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.list_view);
        this.recyclerView = recyclerView;
        recyclerView.setLayoutManager(linearLayoutManager);
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setAdapter(this.mAdapter);
        LocalBroadcastManager.getInstance(this.context).registerReceiver(this.mMessageReceiver, new IntentFilter("back.pressed.selecting"));
        return inflate;
    }
}
