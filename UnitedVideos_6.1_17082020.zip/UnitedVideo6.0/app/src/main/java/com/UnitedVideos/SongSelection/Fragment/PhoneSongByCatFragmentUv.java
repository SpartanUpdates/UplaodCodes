package com.UnitedVideos.SongSelection.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.UnitedVideos.SongSelection.Adapter.PhoneSongAdapterUv;
import com.wavymusic.R;
import com.wavymusic.SongSelection.Model.PhoneSong;
import com.wavymusic.SongSelection.Model.PhoneSongModel;
import java.util.List;
import static com.UnitedVideos.SongSelection.activity.PhoneSongActivityUv.PhoneSongFolders;

public class PhoneSongByCatFragmentUv extends Fragment {

    public List<PhoneSongModel> PhonsSongList;
    public PhoneSong phoneSong;
    Integer Folderid = -1;
    Integer TabIndex = -1;
    RecyclerView rvPhoneSong;
    PhoneSongAdapterUv mPhonsSongAdp;



    public static Fragment getInstance(int Folderid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        PhoneSongByCatFragmentUv songByCatFragmentent = new PhoneSongByCatFragmentUv();
        songByCatFragmentent.setArguments(bundle);
        return songByCatFragmentent;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }

    public int getFolderid() {
        return this.Folderid;
    }

    public int getTabIndex() {
        return this.TabIndex;
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phone_song, container, false);
        phoneSong = PhoneSongFolders.getMusicFolders().get(Folderid);
        PhonsSongList = phoneSong.getLocalTracks();
        rvPhoneSong = view.findViewById(R.id.rv_recycler_view);
        mPhonsSongAdp = new PhoneSongAdapterUv(this,getContext(), PhonsSongList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvPhoneSong.setLayoutManager(mLayoutManager);
        rvPhoneSong.setItemAnimator(new DefaultItemAnimator());
        rvPhoneSong.setAdapter(mPhonsSongAdp);
        return view;
    }

}
