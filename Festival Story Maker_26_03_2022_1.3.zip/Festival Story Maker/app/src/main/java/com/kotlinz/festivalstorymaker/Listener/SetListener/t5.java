package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class t5 implements SeekBar.OnSeekBarChangeListener {
    public final FrameEditorNewDesign e;

    public t5(final FrameEditorNewDesign e) {
        this.e = e;
    }

    public void onProgressChanged(final SeekBar seekBar, final int a, final boolean b) {
        if (b) {
            this.e.s1.setLetterSpacing((float) a);
            this.e.s1.requestLayout();
            final FrameEditorNewDesign e = this.e;
            final com.kotlinz.festivalstorymaker.Models.z.c c = e.r1.get((int) e.s1.getTag());
            c.a = a;
            final FrameEditorNewDesign e2 = this.e;
            e2.r1.set((int) e2.s1.getTag(), c);
        }
    }

    public void onStartTrackingTouch(final SeekBar seekBar) {
    }

    public void onStopTrackingTouch(final SeekBar seekBar) {
    }
}
