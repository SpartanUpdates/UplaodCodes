package com.esc.storymaker.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import com.esc.storymaker.R;
import java.io.InputStream;

public class ImageStickerView extends AppCompatImageView {
    private static final float BITMAP_SCALE = 0.53f;
    private static final int DEFAULT_MOVIE_DURATION = 1000;
    private static final String TAG = "StickerView";
    private float MAX_SCALE;
    private float MIN_SCALE;
    private Bitmap deleteBitmap;
    private int deleteBitmapHeight;
    private int deleteBitmapWidth;
    private DisplayMetrics dm;
    private Rect dst_delete;
    private Rect dst_flipV;
    private Rect dst_resize;
    private Rect dst_top;
    private Bitmap flipVBitmap;
    private int flipVBitmapHeight;
    private int flipVBitmapWidth;
    private InputStream gifInputStream;
    private Movie gifMovie;
    private double halfDiagonalLength;
    private boolean isGif;
    private boolean isHorizonMirror;
    private boolean isInEdit;
    private boolean isInResize;
    private boolean isInSide;
    private boolean isPointerDown;
    private float lastLength;
    private float lastRotateDegree;
    private float lastX;
    private float lastY;
    private float layoutX;
    private float layoutY;
    private Paint localPaint;
    private Bitmap mBitmap;
    private int mCurrentAnimationTime;
    private long mMovieStart;
    private int mScreenHeight;
    private int mScreenWidth;
    private Matrix matrix;
    private PointF mid;
    private float oldDis;
    private OperationListener operationListener;
    private float originWidth;
    private final float pointerLimitDis;
    private final float pointerZoomOff;
    private Bitmap resizeBitmap;
    private int resizeBitmapHeight;
    private int resizeBitmapWidth;
    private int resourceHeight;
    private int resourceWidth;
    private float rotate;
    private float scale;
    private int stickerId;
    private String stickerPath;
    private Bitmap topBitmap;
    private int topBitmapHeight;
    private int topBitmapWidth;

    public interface OperationListener {
        void onDeleteClick();

        void onEdit(ImageStickerView imageStickerView);

        void onTop(ImageStickerView imageStickerView);
    }

    public ImageStickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mid = new PointF();
        this.isPointerDown = false;
        this.pointerLimitDis = 20.0f;
        this.pointerZoomOff = 0.09f;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.originWidth = 0.0f;
        this.scale = 0.3f;
        this.rotate = 0.0f;
        this.mMovieStart = 0;
        this.mCurrentAnimationTime = 0;
        this.stickerId = 0;
        init();
    }

    public ImageStickerView(Context context, String str, float f, float f2, float f3, float f4, int i) {
        super(context);
        this.mid = new PointF();
        this.isPointerDown = false;
        this.pointerLimitDis = 20.0f;
        this.pointerZoomOff = 0.09f;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.originWidth = 0.0f;
        this.scale = 0.3f;
        this.rotate = 0.0f;
        this.mMovieStart = 0;
        this.mCurrentAnimationTime = 0;
        this.stickerPath = str;
        this.layoutX = f;
        this.layoutY = f2;
        this.scale = f3;
        this.rotate = f4;
        this.stickerId = i;
        init();
    }

    public ImageStickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mid = new PointF();
        this.isPointerDown = false;
        this.pointerLimitDis = 20.0f;
        this.pointerZoomOff = 0.09f;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.originWidth = 0.0f;
        this.scale = 0.3f;
        this.rotate = 0.0f;
        this.mMovieStart = 0;
        this.mCurrentAnimationTime = 0;
        this.stickerId = 0;
        init();
    }

    private void init() {
        this.dst_delete = new Rect();
        this.dst_resize = new Rect();
        this.dst_flipV = new Rect();
        this.dst_top = new Rect();
        this.localPaint = new Paint();
        this.localPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
        this.localPaint.setAntiAlias(true);
        this.localPaint.setDither(true);
        this.localPaint.setStyle(Style.STROKE);
        this.localPaint.setStrokeWidth(1.0f);
        this.dm = getResources().getDisplayMetrics();
        this.mScreenWidth = this.dm.widthPixels;
        this.mScreenHeight = this.dm.heightPixels;
    }


    public void onDraw(Canvas canvas) {
        Canvas canvas2 = canvas;
        if (this.mBitmap != null || this.gifMovie != null) {
            float[] fArr = new float[9];
            this.matrix.getValues(fArr);
            float f = ((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2];
            float f2 = (fArr[4] * 0.0f) + (fArr[5] + (fArr[3] * 0.0f));
            float f3 = fArr[0];
            float f4 = (float) this.resourceWidth;
            float f5 = (fArr[2] + (f3 * f4)) + (fArr[1] * 0.0f);
            float f6 = (fArr[4] * 0.0f) + (fArr[5] + (fArr[3] * f4));
            float f7 = (float) this.resourceHeight;
            float f8 = ((fArr[0] * 0.0f) + (fArr[1] * f7)) + fArr[2];
            float f9 = ((fArr[3] * 0.0f) + (fArr[4] * f7)) + fArr[5];
            float f10 = ((fArr[0] * f4) + (fArr[1] * f7)) + fArr[2];
            float f11 = ((fArr[3] * f4) + (fArr[4] * f7)) + fArr[5];
            canvas.save();
            Rect rect = this.dst_delete;
            float f12 = (float) (this.deleteBitmapWidth / 3);
            rect.left = (int) (f5 - f12);
            rect.right = (int) (f12 + f5);
            f12 = (float) (this.deleteBitmapHeight / 3);
            rect.top = (int) (f6 - f12);
            rect.bottom = (int) (f12 + f6);
            rect = this.dst_resize;
            f12 = (float) (this.resizeBitmapWidth / 3);
            rect.left = (int) (f10 - f12);
            rect.right = (int) (f12 + f10);
            f12 = (float) (this.resizeBitmapHeight / 3);
            rect.top = (int) (f11 - f12);
            rect.bottom = (int) (f12 + f11);
            rect = this.dst_top;
            f12 = (float) (this.flipVBitmapWidth / 3);
            rect.left = (int) (f - f12);
            rect.right = (int) (f12 + f);
            f12 = (float) (this.flipVBitmapHeight / 3);
            rect.top = (int) (f2 - f12);
            rect.bottom = (int) (f12 + f2);
            rect = this.dst_flipV;
            f12 = (float) (this.topBitmapWidth / 3);
            rect.left = (int) (f8 - f12);
            rect.right = (int) (f8 + f12);
            f12 = (float) (this.topBitmapHeight / 3);
            rect.top = (int) (f9 - f12);
            rect.bottom = (int) (f12 + f9);
            if (this.isInEdit) {
                Canvas canvas3 = canvas;
                canvas3.drawLine(f, f2, f5, f6, this.localPaint);
                f7 = f10;
                float f13 = f11;
                canvas3.drawLine(f5, f6, f7, f13, this.localPaint);
                f12 = f8;
                float f14 = f9;
                canvas3.drawLine(f12, f14, f7, f13, this.localPaint);
                canvas3.drawLine(f12, f14, f, f2, this.localPaint);
                canvas2.drawBitmap(this.deleteBitmap, null, this.dst_delete, null);
                canvas2.drawBitmap(this.resizeBitmap, null, this.dst_resize, null);
                canvas2.drawBitmap(this.flipVBitmap, null, this.dst_flipV, null);
                canvas2.drawBitmap(this.topBitmap, null, this.dst_top, null);
            }
            if (this.isGif) {
                canvas2.setMatrix(this.matrix);
                updateAnimationTime();
                this.gifMovie.setTime(this.mCurrentAnimationTime);
                this.gifMovie.draw(canvas2, 0.0f, 0.0f);
                invalidate();
            } else {
                canvas2.drawBitmap(this.mBitmap, this.matrix, null);
            }
            canvas.restore();
        }
    }

    private void updateAnimationTime() {
        long uptimeMillis = SystemClock.uptimeMillis();
        if (this.mMovieStart == 0) {
            this.mMovieStart = uptimeMillis;
        }
        int duration = this.gifMovie.duration();
        if (duration == 0) {
            duration = 1000;
        }
        this.mCurrentAnimationTime = (int) ((uptimeMillis - this.mMovieStart) % ((long) duration));
    }

    public void setImageResource(int i) {
        setBitmap(BitmapFactory.decodeResource(getResources(), i));
    }

    public void setGifInputStream(InputStream inputStream) {
        this.matrix.reset();
        this.gifInputStream = inputStream;
        this.gifMovie = Movie.decodeStream(this.gifInputStream);
        this.resourceWidth = this.gifMovie.width();
        this.resourceHeight = this.gifMovie.height();
        setDiagonalLength();
        initBitmaps();
        this.originWidth = (float) this.resourceWidth;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("scale = ");
        stringBuilder.append(this.scale);
        stringBuilder.append(" rotate = ");
        stringBuilder.append(this.rotate);
        stringBuilder.append(" x ");
        stringBuilder.append(this.layoutX);
        stringBuilder.append(" y ");
        stringBuilder.append(this.layoutY);
        this.matrix.setRotate(this.rotate, (float) (this.resourceWidth / 2), (float) (this.resourceHeight / 2));
        Matrix matrix = this.matrix;
        float f = this.scale;
        matrix.postScale(f, f, (float) (this.resourceWidth / 2), (float) (this.resourceHeight / 2));
        this.matrix.postTranslate(this.layoutX - ((float) (this.resourceWidth / 2)), this.layoutY - ((float) (this.resourceHeight / 2)));
        invalidate();
    }

    public void setBitmap(Bitmap bitmap) {
        this.matrix.reset();
        this.mBitmap = bitmap;
        this.resourceWidth = this.mBitmap.getWidth();
        this.resourceHeight = this.mBitmap.getHeight();
        setDiagonalLength();
        initBitmaps();
        this.originWidth = (float) this.resourceWidth;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("scale = ");
        stringBuilder.append(this.scale);
        stringBuilder.append(" rotate = ");
        stringBuilder.append(this.rotate);
        stringBuilder.append(" x ");
        stringBuilder.append(this.layoutX);
        stringBuilder.append(" y ");
        stringBuilder.append(this.layoutY);
        this.matrix.setRotate(this.rotate, (float) (this.resourceWidth / 2), (float) (this.resourceHeight / 2));
        Matrix matrix = this.matrix;
        float f = this.scale;
        matrix.postScale(f, f, (float) (this.resourceWidth / 2), (float) (this.resourceHeight / 2));
        this.matrix.postTranslate(this.layoutX - ((float) (this.resourceWidth / 2)), this.layoutY - ((float) (this.resourceHeight / 2)));
        invalidate();
    }

    private void setDiagonalLength() {
        this.halfDiagonalLength = Math.hypot((double) this.resourceWidth, (double) this.resourceHeight) / 2.0d;
    }

    private void initBitmaps() {
        int i = this.resourceWidth;
        int i2 = this.resourceHeight;
        float f;
        float f2;
        if (i >= i2) {
            f = (float) ((this.mScreenWidth * 10) / 100);
            f2 = (float) i;
            if (f2 < f) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (f * 1.0f) / f2;
            }
            i = this.resourceWidth;
            i2 = this.mScreenWidth;
            if (i > i2) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (((float) i2) * 1.0f) / ((float) i);
            }
        } else {
            f2 = (float) ((this.mScreenWidth * 10) / 100);
            f = (float) i2;
            if (f < f2) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (f2 * 1.0f) / f;
            }
            i = this.resourceHeight;
            i2 = this.mScreenWidth;
            if (i > i2) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (((float) i2) * 1.0f) / ((float) i);
            }
        }
        this.topBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_top_enable);
        this.deleteBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_delete);
        this.flipVBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_flip);
        this.resizeBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_resize);
        this.deleteBitmapWidth = (int) (((float) this.deleteBitmap.getWidth()) * BITMAP_SCALE);
        this.deleteBitmapHeight = (int) (((float) this.deleteBitmap.getHeight()) * BITMAP_SCALE);
        this.resizeBitmapWidth = (int) (((float) this.resizeBitmap.getWidth()) * BITMAP_SCALE);
        this.resizeBitmapHeight = (int) (((float) this.resizeBitmap.getHeight()) * BITMAP_SCALE);
        this.flipVBitmapWidth = (int) (((float) this.flipVBitmap.getWidth()) * BITMAP_SCALE);
        this.flipVBitmapHeight = (int) (((float) this.flipVBitmap.getHeight()) * BITMAP_SCALE);
        this.topBitmapWidth = (int) (((float) this.topBitmap.getWidth()) * BITMAP_SCALE);
        this.topBitmapHeight = (int) (((float) this.topBitmap.getHeight()) * BITMAP_SCALE);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        OperationListener operationListener;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        boolean z = true;
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                float spacing;
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked == 5) {
                            if (spacing(motionEvent) > this.pointerLimitDis) {
                                this.oldDis = spacing(motionEvent);
                                this.isPointerDown = true;
                                midPointToStartPoint(motionEvent);
                            } else {
                                this.isPointerDown = false;
                            }
                            this.isInSide = false;
                            this.isInResize = false;
                        }
                    }
                } else if (this.isPointerDown) {
                    spacing = spacing(motionEvent);
                    spacing = (spacing == 0.0f || spacing < this.pointerLimitDis) ? 1.0f : (((spacing / this.oldDis) - 1.0f) * this.pointerZoomOff) + 1.0f;
                    float abs = (((float) Math.abs(this.dst_flipV.left - this.dst_resize.left)) * spacing) / this.originWidth;
                    if ((abs > this.MIN_SCALE || spacing >= 1.0f) && (abs < this.MAX_SCALE || spacing <= 1.0f)) {
                        this.lastLength = diagonalLength(motionEvent);
                    } else {
                        spacing = 1.0f;
                    }
                    this.matrix.postScale(spacing, spacing, this.mid.x, this.mid.y);
                    invalidate();
                } else if (this.isInResize) {
                    this.matrix.postRotate((rotationToStartPoint(motionEvent) - this.lastRotateDegree) * 2.0f, this.mid.x, this.mid.y);
                    this.lastRotateDegree = rotationToStartPoint(motionEvent);
                    spacing = diagonalLength(motionEvent) / this.lastLength;
                    double diagonalLength = (double) diagonalLength(motionEvent);
                    double d = this.halfDiagonalLength;
                    Double.isNaN(diagonalLength);
                    if (diagonalLength / d > ((double) this.MIN_SCALE) || spacing >= 1.0f) {
                        diagonalLength = (double) diagonalLength(motionEvent);
                        d = this.halfDiagonalLength;
                        Double.isNaN(diagonalLength);
                        if (diagonalLength / d < ((double) this.MAX_SCALE) || spacing <= 1.0f) {
                            this.lastLength = diagonalLength(motionEvent);
                            this.matrix.postScale(spacing, spacing, this.mid.x, this.mid.y);
                            invalidate();
                        }
                    }
                    if (!isInResize(motionEvent)) {
                        this.isInResize = false;
                    }
                    spacing = 1.0f;
                    this.matrix.postScale(spacing, spacing, this.mid.x, this.mid.y);
                    invalidate();
                } else if (this.isInSide) {
                    spacing = motionEvent.getX(0);
                    float y = motionEvent.getY(0);
                    this.matrix.postTranslate(spacing - this.lastX, y - this.lastY);
                    this.lastX = spacing;
                    this.lastY = y;
                    invalidate();
                }
            }
            this.isInResize = false;
            this.isInSide = false;
            this.isPointerDown = false;
        } else if (isInButton(motionEvent, this.dst_delete)) {
            operationListener = this.operationListener;
            if (operationListener != null) {
                operationListener.onDeleteClick();
            }
        } else if (isInResize(motionEvent)) {
            this.isInResize = true;
            this.lastRotateDegree = rotationToStartPoint(motionEvent);
            midPointToStartPoint(motionEvent);
            this.lastLength = diagonalLength(motionEvent);
        } else if (isInButton(motionEvent, this.dst_flipV)) {
            PointF pointF = new PointF();
            midDiagonalPoint(pointF);
            this.matrix.postScale(-1.0f, 1.0f, pointF.x, pointF.y);
            this.isHorizonMirror = true;
            invalidate();
        } else if (isInButton(motionEvent, this.dst_top)) {
            bringToFront();
            operationListener = this.operationListener;
            if (operationListener != null) {
                operationListener.onTop(this);
            }
        } else if (isInBitmap(motionEvent)) {
            this.isInSide = true;
            this.lastX = motionEvent.getX(0);
            this.lastY = motionEvent.getY(0);
        } else {
            z = false;
        }
        if (z) {
            operationListener = this.operationListener;
            if (operationListener != null) {
                operationListener.onEdit(this);
            }
        }
        return z;
    }

    public void calculate() {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[2];
        float f2 = fArr[5];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("tx : ");
        stringBuilder.append(f);
        stringBuilder.append(" ty : ");
        stringBuilder.append(f2);
        stringBuilder.toString();
        f2 = fArr[0];
        float f3 = fArr[3];
        f2 = (float) Math.sqrt((double) ((f2 * f2) + (f3 * f3)));
        stringBuilder = new StringBuilder();
        stringBuilder.append("rScale : ");
        stringBuilder.append(f2);
        float round = (float) Math.round(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("rAngle : ");
        stringBuilder2.append(round);
        PointF pointF = new PointF();
        midDiagonalPoint(pointF);
        stringBuilder = new StringBuilder();
        stringBuilder.append(" width  : ");
        stringBuilder.append(((float) this.resourceWidth) * f2);
        stringBuilder.append(" height ");
        stringBuilder.append(((float) this.resourceHeight) * f2);
        f3 = pointF.x;
        f = pointF.y;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("midX : ");
        stringBuilder3.append(f3);
        stringBuilder3.append(" midY : ");
        stringBuilder3.append(f);
        this.rotate = round * -1.0f;
        int i = this.resourceWidth;
        i = this.mScreenWidth;
        this.scale = f2;
        this.layoutX = f3;
        this.layoutY = f;
    }

    private boolean isInBitmap(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = ((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2];
        float f2 = ((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5];
        float f3 = (float) this.resourceWidth;
        float f4 = ((fArr[0] * f3) + (fArr[1] * 0.0f)) + fArr[2];
        float f5 = ((fArr[3] * f3) + (fArr[4] * 0.0f)) + fArr[5];
        float f6 = fArr[0] * 0.0f;
        float f7 = fArr[1];
        float f8 = (float) this.resourceHeight;
        float f9 = ((fArr[3] * 0.0f) + (fArr[4] * f8)) + fArr[5];
        float f10 = ((fArr[0] * f3) + (fArr[1] * f8)) + fArr[2];
        float f11 = ((fArr[3] * f3) + (fArr[4] * f8)) + fArr[5];
        return pointInRect(new float[]{f, f4, f10, (f6 + (f7 * f8)) + fArr[2]}, new float[]{f2, f5, f11, f9}, motionEvent2.getX(0), motionEvent2.getY(0));
    }

    private boolean pointInRect(float[] fArr, float[] fArr2, float f, float f2) {
        double hypot = Math.hypot((double) (fArr[0] - fArr[1]), (double) (fArr2[0] - fArr2[1]));
        double hypot2 = Math.hypot((double) (fArr[1] - fArr[2]), (double) (fArr2[1] - fArr2[2]));
        double hypot3 = Math.hypot((double) (fArr[3] - fArr[2]), (double) (fArr2[3] - fArr2[2]));
        double hypot4 = Math.hypot((double) (fArr[0] - fArr[3]), (double) (fArr2[0] - fArr2[3]));
        double hypot5 = Math.hypot((double) (f - fArr[0]), (double) (f2 - fArr2[0]));
        double d = hypot;
        double hypot6 = Math.hypot((double) (f - fArr[1]), (double) (f2 - fArr2[1]));
        double hypot7 = Math.hypot((double) (f - fArr[2]), (double) (f2 - fArr2[2]));
        double hypot8 = Math.hypot((double) (f - fArr[3]), (double) (f2 - fArr2[3]));
        double d2 = ((d + hypot5) + hypot6) / 2.0d;
        double d3 = ((hypot2 + hypot6) + hypot7) / 2.0d;
        double d4 = ((hypot3 + hypot7) + hypot8) / 2.0d;
        double d5 = ((hypot4 + hypot8) + hypot5) / 2.0d;
        return Math.abs((d * hypot2) - (((Math.sqrt((((d2 - d) * d2) * (d2 - hypot5)) * (d2 - hypot6)) + Math.sqrt((((d3 - hypot2) * d3) * (d3 - hypot6)) * (d3 - hypot7))) + Math.sqrt((((d4 - hypot3) * d4) * (d4 - hypot7)) * (d4 - hypot8))) + Math.sqrt((((d5 - hypot4) * d5) * (d5 - hypot8)) * (d5 - hypot5)))) < 0.5d;
    }

    private boolean isInButton(MotionEvent motionEvent, Rect rect) {
        int i = rect.left;
        int i2 = rect.right;
        int i3 = rect.top;
        int i4 = rect.bottom;
        if (motionEvent.getX(0) < ((float) i) || motionEvent.getX(0) > ((float) i2) || motionEvent.getY(0) < ((float) i3) || motionEvent.getY(0) > ((float) i4)) {
            return false;
        }
        return true;
    }

    private boolean isInResize(MotionEvent motionEvent) {
        int i = this.dst_resize.top - 20;
        int i2 = this.dst_resize.right + 20;
        int i3 = this.dst_resize.bottom + 20;
        if (motionEvent.getX(0) < ((float) (this.dst_resize.left - 20)) || motionEvent.getX(0) > ((float) i2) || motionEvent.getY(0) < ((float) i) || motionEvent.getY(0) > ((float) i3)) {
            return false;
        }
        return true;
    }

    private void midPointToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        this.mid.set(((((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]) + motionEvent.getX(0)) / 2.0f, ((((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5]) + motionEvent.getY(0)) / 2.0f);
    }

    private void midDiagonalPoint(PointF pointF) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = ((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5];
        float f2 = (float) this.resourceWidth;
        float f3 = (float) this.resourceHeight;
        pointF.set(((((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]) + (((fArr[0] * f2) + (fArr[1] * f3)) + fArr[2])) / 2.0f, (f + (((fArr[3] * f2) + (fArr[4] * f3)) + fArr[5])) / 2.0f);
    }

    private float rotationToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        return (float) Math.toDegrees(Math.atan2((double) (motionEvent.getY(0) - (((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5])), (double) (motionEvent.getX(0) - (((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]))));
    }

    private float diagonalLength(MotionEvent motionEvent) {
        return (float) Math.hypot((double) (motionEvent.getX(0) - this.mid.x), (double) (motionEvent.getY(0) - this.mid.y));
    }

    private float spacing(MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() != 2) {
            return 0.0f;
        }
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    public void setOperationListener(OperationListener operationListener) {
        this.operationListener = operationListener;
    }

    public void setInEdit(boolean z) {
        this.isInEdit = z;
        invalidate();
    }

    public int getStickerId() {
        return this.stickerId;
    }

    public String getStickerPath() {
        return this.stickerPath;
    }

    public float getLayoutX() {
        return this.layoutX;
    }

    public float getLayoutY() {
        return this.layoutY;
    }

    public float getScale() {
        return this.scale;
    }

    public float getRotate() {
        return this.rotate;
    }

    public boolean isGif() {
        return this.isGif;
    }

    public void setGif(boolean z) {
        this.isGif = z;
    }
}
