package com.wavymusic.ImageSelection.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.wavymusic.App.MyApplication;
import com.wavymusic.ImageSelection.Interface.OnItemClickListner;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.ImageSelection.activity.SelectImageActivity;
import com.wavymusic.R;
import java.util.ArrayList;

public class SelectedImageAdapter extends RecyclerView.Adapter<SelectedImageAdapter.Holder> {
    final int TYPE_IMAGE = 0;
    final int TYPE_BLANK = 1;
    public boolean isExpanded;
    SelectImageActivity activity;
    Context mContext;
    private MyApplication application;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> clickListner;
    private RequestManager glide;

    public SelectedImageAdapter(final Context activity) {
        this.isExpanded = false;
        this.mContext = activity;
        this.activity = (SelectImageActivity) activity;
        this.application = MyApplication.getInstance();
        this.inflater = LayoutInflater.from(activity);
        this.glide = Glide.with(activity);
    }

    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    public int getItemCount() {
        final ArrayList<ImageModel> list = this.application.getSelectedImages();
        if (!this.isExpanded) {
            return list.size() + 20;
        }
        return list.size();
    }

    public int getItemViewType(final int position) {
        super.getItemViewType(position);
        if (this.isExpanded) {
            return 0;
        }
        final ArrayList<ImageModel> list = this.application.getSelectedImages();
        if (position >= list.size()) {
            return 1;
        }
        return 0;
    }

    private boolean hideRemoveBtn() {
        return this.application.getSelectedImages().size() <= 3 && this.activity.isFromPreview;
    }

    public ImageModel getItem(final int pos) {
        final ArrayList<ImageModel> list = this.application.getSelectedImages();
        if (list.size() <= pos) {
            return new ImageModel();
        }
        return list.get(pos);
    }

    public void onBindViewHolder(final Holder holder, final int pos) {
        if (this.getItemViewType(pos) == 1) {
            holder.parent.setVisibility(View.INVISIBLE);
            return;
        }
        holder.parent.setVisibility(View.VISIBLE);
        final ImageModel data = this.getItem(pos);
        this.glide.load(data.imagePath).into(holder.ivThumb);
        if (this.hideRemoveBtn()) {
            holder.ivRemove.setVisibility(View.GONE);
        } else {
            holder.ivRemove.setVisibility(View.VISIBLE);
        }
        holder.ivRemove.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (SelectedImageAdapter.this.activity.isFromPreview) {
                    SelectedImageAdapter.this.application.min_pos = Math.min(SelectedImageAdapter.this.application.min_pos, Math.max(0, pos - 1));
                }
                if (SelectImageActivity.isForFirst && pos <= SelectImageActivity.tempImage.size() && SelectedImageAdapter.this.application.getSelectedImages().contains(SelectImageActivity.tempImage.get(pos).imagePath)) {
                    SelectImageActivity.tempImage.remove(pos);
                }
                SelectedImageAdapter.this.application.removeSelectedImage(pos);
                if (SelectedImageAdapter.this.clickListner != null) {
                    SelectedImageAdapter.this.clickListner.onItemClick(v, data);
                }
                if (SelectedImageAdapter.this.hideRemoveBtn()) {
                    Toast.makeText(SelectedImageAdapter.this.activity, R.string.at_least_3_images_require_if_you_want_to_remove_this_images_than_add_more_images_, Toast.LENGTH_LONG).show();
                }
                SelectedImageAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull final ViewGroup parent, final int pos) {
        final View v = this.inflater.inflate(R.layout.row_image_selected, parent, false);
        final Holder holder = new Holder(v);
        if (this.getItemViewType(pos) == 1) {
            v.setVisibility(View.INVISIBLE);
        } else {
            v.setVisibility(View.VISIBLE);
        }
        return holder;
    }

    public class Holder extends RecyclerView.ViewHolder {
        View parent;
        private ImageView ivRemove;
        private ImageView ivThumb;

        public Holder(final View v) {
            super(v);
            this.parent = v;
            this.ivThumb = v.findViewById(R.id.ivThumb);
            this.ivRemove = v.findViewById(R.id.ivRemove);
        }

        public void onItemClick(final View view, final Object item) {
            if (SelectedImageAdapter.this.clickListner != null) {
                SelectedImageAdapter.this.clickListner.onItemClick(view, item);
            }
        }
    }
}
