package com.esc.howtomakeschoolsupplies.network;

import java.util.TimerTask;

public class ConnectToServerconnectCategory1onFailureinlinedschedule1 extends TimerTask {
    final ConnectToServerconnectCategory1 this$0;

    public ConnectToServerconnectCategory1onFailureinlinedschedule1(ConnectToServerconnectCategory1 connectToServer$connectCategory$1) {
        this.this$0 = connectToServer$connectCategory$1;
    }

    public void run() {
        TimerTask timerTask = this;
        new ConnectToServer().connectCategory(this.this$0.$loadingCategory);
    }
}
