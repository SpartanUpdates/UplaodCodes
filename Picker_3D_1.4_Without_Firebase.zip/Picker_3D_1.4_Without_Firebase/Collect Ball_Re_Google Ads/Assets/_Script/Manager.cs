﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace BallCollect
{
    public class Manager : MonoBehaviour
    {
        public static Manager instance;

        [HideInInspector]
        public int levelFinishCount=0, restartCount=0;
        [HideInInspector]
        public int isLastColor=0,colorNo=0,oceneNo=0;
        [HideInInspector]
        public int setIsGameRestart = 0;
        [HideInInspector]
        public bool isNetWorkOn = false;

        public string strLike="market://details?id=com.example.android";

        public string strRateUs = "market://details?id=com.example.android";

        public string strMoreApp = "market://details?id=com.example.android";

        public string strPrivacyPolicy = "http://google.com/";

        public string strShareApp = "http://google.com/";

        public string interstitialId = "ca-app-pub-3940256099942544/1033173712";

        public string bannerID = "ca-app-pub-3940256099942544/6300978111";

        public string RewardID = "ca-app-pub-3940256099942544/5224354917";

        public bool isBannerAdsShow = false, isAdaptiveAds = false, isSmartAdsShow = false;

        void Awake()
        {
            if (instance == null)
            {
                instance = this;
                DontDestroyOnLoad(this.gameObject);
            }
            else
            {
                Destroy(this.gameObject);
            }

            if (Application.internetReachability != NetworkReachability.NotReachable)
            {
                isNetWorkOn = true;
            }
            else
            {
                isNetWorkOn = false;
            }
        }
    }
}