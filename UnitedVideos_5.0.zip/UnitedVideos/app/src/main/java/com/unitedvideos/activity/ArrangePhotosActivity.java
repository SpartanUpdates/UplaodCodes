package com.unitedvideos.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.Adapter.SwapeImageAdapter;
import com.unitedvideos.Model.ImageModel;
import com.unitedvideos.R;
import com.unitedvideos.WidgetView.EmptyRecyclerView;
import com.unitedvideos.application.MyApplication;
import com.root.unity.AndroidUnityCall;
import com.unitedvideos.kprogresshud.KProgressHUD;
import com.unity3d.player.UnityPlayer;

import java.util.ArrayList;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class ArrangePhotosActivity extends Activity {

    Activity activity = ArrangePhotosActivity.this;
    ItemTouchHelper.Callback backCall;
    private MyApplication application;
    private SwapeImageAdapter swapeImageAdapterAdapter;

    public boolean Preview;
    private EmptyRecyclerView emptyRecyclerview;
    private Toolbar toolbar;
    String result_conc = "";
    String iscut;
    private boolean IsUpdateImage;
    private boolean IsArrangeImage;
    String isfrom;
    ImageView ivback;
    TextView tvdone;
    private String AllFilePath;
    private String AllFileData;

    KProgressHUD hud;
    private UnifiedNativeAd nativeAd;
    InterstitialAd mInterstitialAd;

    public View onCreateView(View view, String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public ImageModel getItem(int pos) {
        ArrayList<ImageModel> list = this.application.getSelectedImages();
        if (list.size() <= pos) {
            return new ImageModel();
        }
        return (ImageModel) list.get(pos);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == 1001) {
            String i = data.getExtras().get("uri_new").toString();
            ImageModel imgs = new ImageModel();
            imgs.setImagePath(i);
            this.application.ReplaceSelectedImage(imgs, data.getExtras().getInt("position"));

            if (swapeImageAdapterAdapter != null) {
                swapeImageAdapterAdapter.notifyItemChanged(data.getExtras().getInt(
                        "position"));
            }
        }
    }

    public View onCreateView(String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public ArrangePhotosActivity() {
        this.Preview = false;
        this.backCall = new ItemTouchHelper.Callback() {
            @Override
            public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState) {
                if (actionState == 0) {
                    ArrangePhotosActivity.this.swapeImageAdapterAdapter
                            .notifyDataSetChanged();
                }
            }

            @Override
            public void onMoved(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                                int fromPos, RecyclerView.ViewHolder target, int toPos, int x, int y) {
                ArrangePhotosActivity.this.swapeImageAdapterAdapter.swap(
                        viewHolder.getAdapterPosition(),
                        target.getAdapterPosition());
                ArrangePhotosActivity.this.application.min_pos = Math.min(
                        ArrangePhotosActivity.this.application.min_pos,
                        Math.min(fromPos, toPos));
                MyApplication.isBreak = true;
            }

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                                  RecyclerView.ViewHolder target) {
                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            }

            @Override
            public int getMovementFlags(RecyclerView recyclerView,
                                        RecyclerView.ViewHolder viewHolder) {
                return ItemTouchHelper.Callback.makeFlag(2, 51);
            }
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrange_photos);
        this.Preview = getIntent().hasExtra(
                ImageSelectionActivity.EXTRA_FROM_PREVIEW);
        this.application = MyApplication.getInstance();
        this.application.isEditModeEnable = true;
        IsUpdateImage = getIntent().getBooleanExtra("Imageupdate", false);
        IsArrangeImage = getIntent().getBooleanExtra("Imagearrange", false);
        iscut = getIntent().getStringExtra("isCut");
        isfrom = getIntent().getStringExtra("isfrom");
        Log.e("TAG", "update: " + IsUpdateImage);
        Log.e("TAG", "arrange: " + IsArrangeImage);
        Log.e("TAG", "iscut: " + iscut);
        Log.e("TAG", "arrang activity isfrom: " + isfrom);
        bindView();
        init();
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ArrangePhotosActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        CallNativeAds();
        CallInterstitialAd();
    }

    private void bindView() {
        this.emptyRecyclerview = findViewById(R.id.relativeL_AlbumVideo);
        this.tvdone = (TextView) this.findViewById(R.id.tv_done);
        ivback = findViewById(R.id.ivBack);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tvdone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
//                    try {
//                        hud = KProgressHUD.create(activity)
//                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
//                                .setLabel("Showing Ads")
//                                .setDetailsLabel("Please Wait...");
//                        hud.show();
//                    } catch (IllegalArgumentException e) {
//                        e.printStackTrace();
//                    } catch (NullPointerException e2) {
//                        e2.printStackTrace();
//                    } catch (Exception e3) {
//                        e3.printStackTrace();
//                    }
//                    Handler handler = new Handler();
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            try {
//                                hud.dismiss();
//                            } catch (IllegalArgumentException e) {
//                                e.printStackTrace();
//
//                            } catch (NullPointerException e2) {
//                                e2.printStackTrace();
//                            } catch (Exception e3) {
//                                e3.printStackTrace();
//                            }
//                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
//                                mInterstitialAd.show();
//                            }
//                        }
//                    }, 2000);
                } else {
                    done();
                }
            }
        });
    }


    private void init() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(
                (Context) this, 2, RecyclerView.VERTICAL, false);
        this.swapeImageAdapterAdapter = new SwapeImageAdapter(this);
        this.emptyRecyclerview.setLayoutManager(gridLayoutManager);
        this.emptyRecyclerview.setItemAnimator(new DefaultItemAnimator());
        this.emptyRecyclerview.setEmptyView(findViewById(R.id.emptylist));
        this.emptyRecyclerview.setAdapter(this.swapeImageAdapterAdapter);
        new ItemTouchHelper(this.backCall).attachToRecyclerView(this.emptyRecyclerview);
        toolbar = findViewById(R.id.toolbar);
    }

    private void CallNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(nativeAd);
    }

    private void CallInterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                done();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    @SuppressLint("MissingSuperCall")
    protected void onResume() {
        super.onRestart();
        if (this.swapeImageAdapterAdapter != null) {
            this.swapeImageAdapterAdapter.notifyDataSetChanged();
        }
    }


    public boolean onCreateOptionsMenu(final Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(final MenuItem item) {
        final int itmId = item.getItemId();
        if (itmId == 16908332) {
            super.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void done() {
        this.application.isEditModeEnable = false;
        if (this.Preview) {
            setResult(-1);
            finish();
        } else {
            loadPreview();
        }

    }

    private void loadPreview() {
        AllFilePath = AndroidUnityCall.BundelPath + MyApplication.SPLIT_PATTERN + AndroidUnityCall.PrefebName + MyApplication.SPLIT_PATTERN + AndroidUnityCall.AudioPath;
        AllFileData = AndroidUnityCall.VideoType + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageWidth + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageHeight + MyApplication.SPLIT_PATTERN + AndroidUnityCall.NoofImage;
//        AllFileData = "3D" + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageWidth + MyApplication.SPLIT_PATTERN + AndroidUnityCall.ImageHeight + MyApplication.SPLIT_PATTERN + AndroidUnityCall.NoofImage;

        for (int i = 0; i < this.application.getCropImages().size(); ++i) {
            if (i == 0) {
                result_conc = this.application.getCropImages().get(i);
            } else {
                result_conc = String.valueOf(result_conc) + MyApplication.SPLIT_PATTERN + this.application.getCropImages().get(i);
            }
        }
        if (IsArrangeImage) {
            UnityPlayer.UnitySendMessage("UserData", "ArrangeImages", result_conc);
            Log.e("TAG", "loadPreview Arranges Images: " + result_conc);
            finish();
        } else if (IsUpdateImage) {
            UnityPlayer.UnitySendMessage("UserData", "SpritePathString", result_conc);
            finish();
        } else {
            SendDataToUnity();
//            finish();
        }
    }

    public void SendDataToUnity() {
        Log.e("TAG", "IsAudioResponce" + AllFilePath);
        Log.e("TAG", "GetDataOfAnimation" + AllFileData);
        Log.e("TAG", "SpritePathString" + result_conc);
        AndroidUnityCall.HideBottomData(activity);
        AndroidUnityCall.ShowBottomData(activity);
        Log.e("TAG", "GoToUnityCalled...");
        UnityPlayer.UnitySendMessage("UserData", "IsAudioResponce", AllFilePath);
        UnityPlayer.UnitySendMessage("UserData", "GetDataOfAnimation", AllFileData);
        UnityPlayer.UnitySendMessage("ContentCreater", "SpritePathString", result_conc);
        Log.e("TAG", "GoTounityFinishCalled...");
        finish();
    }

    public void onBackPressed() {
        if (IsArrangeImage) {
            UnityPlayer.UnitySendMessage("UserData", "ResumeUnity", "");
            finish();
        } else if (iscut.equals("3D")) {
            application.IsBack = true;
            Intent intent = new Intent(ArrangePhotosActivity.this, ImageSelectionActivity.class);
            intent.putExtra("isCut", iscut);
            intent.putExtra("Imageupdate", IsUpdateImage);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        } else {
            application.IsBack = true;
            Intent intent = new Intent(ArrangePhotosActivity.this, ImageSelectionActivity.class);
            intent.putExtra("isCut", iscut);
            intent.putExtra("Imageupdate", IsUpdateImage);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        }
    }
}
