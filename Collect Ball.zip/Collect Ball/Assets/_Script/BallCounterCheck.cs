﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BallCollect
{
    public class BallCounterCheck : MonoBehaviour
    {
        public BallCounter ballcounter;
        public void BallCounter()
        {
            ballcounter.isCounterStart=true;
        }
    }
}