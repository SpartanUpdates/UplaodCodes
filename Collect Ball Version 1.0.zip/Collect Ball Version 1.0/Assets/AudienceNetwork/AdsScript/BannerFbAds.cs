﻿using UnityEngine;
using AudienceNetwork;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using AudienceNetwork.Utility;
using UnityEngine.Advertisements;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class BannerFbAds : MonoBehaviour
    {
        public static BannerFbAds instance;

        private AdView adView;

        public bool isLoad = false;

        private void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        void Start()
        {
            AudienceNetworkAds.Initialize();
            LoadBanner();
        }
        int CalculateBannerHeight()
        {
            if (Screen.height <= 400 * Screen.dpi / 160)
            {
                return 1;
            }
            else if (Screen.height <= 720 * Screen.dpi / 160)
            {
                return 2;
            }
            else
            {
                return 1;
            }
        }
        public void LoadBanner()
        {
            if (adView)
            {
                adView.Dispose();
            }
            Analytics.CustomEvent("FbBannerAdRequestCome");

            if(CalculateBannerHeight()==2)
                adView = new AdView(Manager.instance.fbBannerId, AdSize.BANNER_HEIGHT_50);
            else
                adView = new AdView(Manager.instance.fbBannerId, AdSize.BANNER_HEIGHT_90);

            adView.Register(gameObject);

            adView.AdViewDidLoad = delegate ()
            {
                isLoad = true;
                Analytics.CustomEvent("FbBannerAdLoad");

                if (!Manager.instance.isUnityAdsShow && !MainMenu.instance.shopPanel.activeSelf)
                {
                    adView.Show(AdPosition.BOTTOM);
                    Manager.instance.isFbAdsShow = true;
                    Analytics.CustomEvent("FbBannerAdShow");
                }
            };

            adView.AdViewDidFailWithError = delegate (string error)
            {
                isLoad = false;
                Analytics.CustomEvent("FbBannerAdLoadFail");
                if (!Manager.instance.isFbAdsShow)
                    StartCoroutine(BannerUnityAds.instance.ShowBannerWhenReady());
                Manager.instance.isFbAdsShow = false;
            };

            adView.AdViewWillLogImpression = delegate ()
            {
            };

            adView.AdViewDidClick = delegate ()
            {
            };
            adView.LoadAd();
        }

        public void ShowBannerAds()
        {
            if(isLoad)
                adView.Show(AdPosition.BOTTOM);
        }

        public void HideBannerAds()
        {
            adView.Show(-2000);
        }

        void OnDestroy()
        {
            if (adView)
            {
                adView.Dispose();
            }
        }
    }
}