package com.kotlinz.videoCollage;

import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore.Audio.Media;
import android.provider.MediaStore.Images;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.adpaters.AudioAdapter;
import com.kotlinz.videoCollage.interfaces.SetOnAudioItemClickListener;
import com.kotlinz.videoCollage.models.AudioModel;
import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class MusicActivity extends AppCompatActivity {

    ArrayList<AudioModel> audioArrayList;
    MediaPlayer mediaPlayer;
    RecyclerView recyclerView;
    ImageView iv_done;

    private class GetAudioListAsyncTask extends AsyncTask<Void, Void, Boolean> {
        private ProgressDialog progressDialog;

        private GetAudioListAsyncTask() {

        }


        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog progressDialog = new ProgressDialog(MusicActivity.this);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please wait...");
            this.progressDialog.setIndeterminate(false);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setCanceledOnTouchOutside(false);
            this.progressDialog.show();
        }


        public Boolean doInBackground(Void... voidArr) {
            try {
                MusicActivity.this.getAllAudioFromDevice();
                return Boolean.valueOf(true);
            } catch (Exception unused) {
                return Boolean.valueOf(false);
            }
        }


        public void onPostExecute(Boolean bool) {
            this.progressDialog.dismiss();
            MusicActivity musicActivity = MusicActivity.this;
            MusicActivity.this.recyclerView.setAdapter(new AudioAdapter(musicActivity, musicActivity.audioArrayList, new SetOnAudioItemClickListener() {
                public void onItemClick(int i, String str) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" pos :: ");
                    stringBuilder.append(i);
                    String str2 = "music";
                    Log.e(str2, stringBuilder.toString());
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" from :: ");
                    stringBuilder.append(str);
                    Log.e(str2, stringBuilder.toString());
                    if (!str.equals("pause")) {
                        MusicActivity.this.playAudio(i);
                    } else if (MusicActivity.this.mediaPlayer.isPlaying()) {
                        MusicActivity.this.setPause();
                    } else {
                        MusicActivity.this.playAudio(i);
                    }
                }

                public void onAddClick(int i) {
                    Intent intent = new Intent();
                    intent.putExtra("music_path", MusicActivity.this.audioArrayList.get(i).getData());
                    intent.putExtra("music_name", MusicActivity.this.audioArrayList.get(i).getTrack());
                    MusicActivity.this.setResult(-1, intent);

                }
            }));
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_music);
        PutAnalyticsEvent();
        RecyclerView recyclerView = findViewById(R.id.music_recycler);
        this.recyclerView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.audioArrayList = new ArrayList();
        this.mediaPlayer = new MediaPlayer();
        new GetAudioListAsyncTask().execute();
        iv_done=findViewById(R.id.iv_done);
        iv_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MusicActivity.this.finish();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MusicActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void getAllAudioFromDevice() {
        Cursor query = getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "artist", "album", "title", "_data", "album_id", "duration"}, null, null, null);
        while (query.moveToNext()) {
            String string = query.getString(query.getColumnIndexOrThrow("artist"));
            String string2 = query.getString(query.getColumnIndexOrThrow("album"));
            String string3 = query.getString(query.getColumnIndexOrThrow("title"));
            String string4 = query.getString(query.getColumnIndexOrThrow("_data"));
            Long valueOf = Long.valueOf(query.getLong(query.getColumnIndexOrThrow("album_id")));
            int i = query.getInt(query.getColumnIndexOrThrow("duration"));
            Uri withAppendedId = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), valueOf.longValue());
            Bitmap bitmap = null;
            try {
                bitmap = Bitmap.createScaledBitmap(Images.Media.getBitmap(getContentResolver(), withAppendedId), 50, 50, true);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_music_unselect);
            } catch (IOException e2) {
                e2.printStackTrace();
            }
            AudioModel audioModel = new AudioModel();
            audioModel.setArtist(string);
            audioModel.setBitmap(bitmap);
            audioModel.setAlbum(string2);
            audioModel.setTrack(string3);
            audioModel.setData(string4);
            audioModel.setAlbumId(valueOf);
            audioModel.setDuration(i);
            audioModel.setAlbumArtUri(withAppendedId);
            this.audioArrayList.add(audioModel);
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    public void onPause() {
        super.onPause();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        }
    }

    public void onBackPressed() {
        setResult(0, new Intent());
        finish();
    }


    public void onDestroy() {
        super.onDestroy();
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            this.mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
    }

    public void playAudio(int i) {
        try {
            this.mediaPlayer.reset();
            this.mediaPlayer.setDataSource(this, Uri.parse(this.audioArrayList.get(i).getData()));
            this.mediaPlayer.prepare();
            this.mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setPause() {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        } else {
            this.mediaPlayer.start();
        }
    }
}
