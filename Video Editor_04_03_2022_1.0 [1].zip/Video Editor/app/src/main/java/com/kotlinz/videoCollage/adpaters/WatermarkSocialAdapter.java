package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.kotlinz.videoCollage.interfaces.SocVidWatermarkAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class WatermarkSocialAdapter extends Adapter<WatermarkSocialAdapter.FontAdapterViewHolder> {
    private Context context;
    private int height;
    private ArrayList<String> listWatermark;
    private SocVidWatermarkAdapterCallBackInterface listener;
    private int pos = -1;
    private int width;

    public static class FontAdapterViewHolder extends ViewHolder {
        ImageView imgSocialWatermark;
        LinearLayout mMain;

        public FontAdapterViewHolder(View view) {
            super(view);
            this.mMain = (LinearLayout) view.findViewById(R.id.main_watermark_social);
            this.imgSocialWatermark = (ImageView) view.findViewById(R.id.img_watermark_social);
        }
    }

    public WatermarkSocialAdapter(ArrayList<String> arrayList, Context context, SocVidWatermarkAdapterCallBackInterface socVidWatermarkAdapterCallBackInterface) {
        this.context = context;
        this.listWatermark = arrayList;
        this.listener = socVidWatermarkAdapterCallBackInterface;
        Display defaultDisplay = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.width = point.x;
        this.height = point.y;
    }

    public FontAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new FontAdapterViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_watermark_social, viewGroup, false));
    }

    public void onBindViewHolder(FontAdapterViewHolder fontAdapterViewHolder, final int i) {
        String str = (String) this.listWatermark.get(i);
        RequestManager with = Glide.with(this.context);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///android_asset/WatermarkSoc/");
        stringBuilder.append(str);
        ((RequestBuilder) with.load(Uri.parse(stringBuilder.toString())).diskCacheStrategy(DiskCacheStrategy.NONE)).into(fontAdapterViewHolder.imgSocialWatermark);
        fontAdapterViewHolder.imgSocialWatermark.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                WatermarkSocialAdapter.this.pos = i;
                WatermarkSocialAdapter.this.listener.itemClick(i);
                WatermarkSocialAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            fontAdapterViewHolder.imgSocialWatermark.setBackgroundResource(R.drawable.watermark_selected);
        } else {
            fontAdapterViewHolder.imgSocialWatermark.setBackgroundResource(R.drawable.watermark_un_selected);
        }
    }

    public int getItemCount() {
        return this.listWatermark.size();
    }
}
