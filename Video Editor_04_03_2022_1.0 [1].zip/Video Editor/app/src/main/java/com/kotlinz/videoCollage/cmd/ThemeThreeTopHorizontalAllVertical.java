package com.kotlinz.videoCollage.cmd;

import android.util.Log;

import java.util.ArrayList;

public class ThemeThreeTopHorizontalAllVertical {
    public static StringBuilder getOrderString(boolean z, ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2, int i) {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2;
        if (z) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale0][scale1] hstack [hori]; [hori]format=rgba,scale=");
            stringBuilder2.append(i);
            stringBuilder2.append(":-2[horizontal];[horizontal][scale2] vstack [vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else if (arrayList2.size() == 3) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale1]split[scale1_1][scale1_2]; [scale3]split[scale3_1][scale3_2]; [scale5]split[scale5_1][scale5_2]; [scale0][scale3_1] hstack [hori1]; [hori1]format=rgba,scale=");
            stringBuilder2.append(i);
            stringBuilder2.append(":-2[horizontal1];[horizontal1][scale5_1] vstack [imgVidCombine1]; [scale1_1][scale2] hstack [hori2]; [hori2]format=rgba,scale=");
            stringBuilder2.append(i);
            stringBuilder2.append(":-2[horizontal2];[horizontal2][scale5_2] vstack [imgVidCombine2]; [scale1_2][scale3_2] hstack [hori3]; [hori3]format=rgba,scale=");
            stringBuilder2.append(i);
            stringBuilder2.append(":-2[horizontal3];[horizontal3][scale4] vstack [imgVidCombine3]; [imgVidCombine1][imgVidCombine2][imgVidCombine3] concat=n=3 [vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else {
            int i2 = 0;
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("stackCount.get(i) :: ");
                stringBuilder3.append(arrayList.get(i3));
                String str = "save";
                Log.e(str, stringBuilder3.toString());
                if (!arrayList2.contains(arrayList.get(i3))) {
                    i2 = ((Integer) arrayList.get(i3)).intValue();
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("IMAGE stackCount.get(i) :: ");
                    stringBuilder3.append(arrayList.get(i3));
                    Log.e(str, stringBuilder3.toString());
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("imagePos :: ");
                    stringBuilder3.append(i2);
                    Log.e(str, stringBuilder3.toString());
                }
            }
            if (i2 == 0) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale0]split[scale0_1][scale0_2];[scale0_1][scale1] hstack=inputs=2 [imgVidCombine1]; [imgVidCombine1]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal1];[horizontal1][scale4] vstack=inputs=2 [imgVidCombine2]; [scale0_2][scale2] hstack=inputs=2 [imgVidCombine3]; [imgVidCombine3]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal2];[horizontal2][scale3] vstack=inputs=2 [imgVidCombine4];[imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            } else if (i2 == 2) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale2]split[scale2_1][scale2_2]; [scale0][scale2_1] hstack=inputs=2 [imgVidCombine1]; [imgVidCombine1]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal1];[horizontal1][scale4] vstack=inputs=2 [imgVidCombine2]; [scale1][scale2_2] hstack=inputs=2 [imgVidCombine3]; [imgVidCombine3]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal2];[horizontal2][scale3] vstack=inputs=2 [imgVidCombine4]; [imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale4]split[scale4_1][scale4_2];[scale0][scale3] hstack [imgVidCombine1];[imgVidCombine1]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal1];[horizontal1][scale4_1] vstack [imgVidCombine2]; [scale1][scale2] hstack [imgVidCombine3];[imgVidCombine3]format=rgba,scale=");
                stringBuilder2.append(i);
                stringBuilder2.append(":-2[horizontal2];[horizontal2][scale4_2] vstack[imgVidCombine4]; [imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            }
        }
        return stringBuilder;
    }
}
