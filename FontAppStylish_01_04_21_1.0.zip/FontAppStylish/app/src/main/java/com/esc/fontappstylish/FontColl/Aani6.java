package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Aani6 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"𝚊", "𝚋", "𝚌", "𝚍", "𝚎", "𝚏", "𝚐", "𝚑", "𝚒", "𝚓", "𝚔", "𝚕", "𝚖", "𝚗", "𝚘", "𝚙", "𝚚", "𝚛", "𝚜", "𝚝", "𝚞", "𝚟", "𝚠", "𝚡", "𝚢", "𝚣"};
    }

    public String getName() {
        return "Calligraphica";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"𝙰", "𝙱", "𝙲", "𝙳", "𝙴", "𝙵", "𝙶", "𝙷", "𝙸", "𝙹", "𝙺", "𝙻", "𝙼", "𝙽", "𝙾", "𝙿", "𝚀", "𝚁", "𝚂", "𝚃", "𝚄", "𝚅", "𝚆", "𝚇", "𝚈", "𝚉"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
