package com.esc.phoneheart.wrappers;

import com.esc.phoneheart.activity.ImageFileFilter;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

public class MediaJunkData {
    public updateProgress a;
    public String b;
    public ArrayList<BigSizeFilesWrapper> dataList = new ArrayList();
    public String mediaName;
    public int mediaType;
    public long totCount = 0;
    public long totSelectedCount;
    public long totSelectedSize;
    public long totSize = 0;

    public interface updateProgress {
        void update(String str);
    }

    public MediaJunkData(int i, String str) {
        this.mediaName = str;
        this.mediaType = i;
    }

    private void addChild(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totSize += bigSizeFilesWrapper.size;
        this.totCount++;
        this.dataList.add(bigSizeFilesWrapper);
    }

    public void getFiles(ArrayList<String> arrayList, updateProgress updateprogress, String str) {
        this.b = str;
        this.a = updateprogress;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            getFiles(new File((String) it.next()));
        }
    }

    public void select(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totSelectedCount++;
        this.totSelectedSize += bigSizeFilesWrapper.size;
    }

    public void selectAll() {
        this.totSelectedSize = 0;
        this.totSelectedCount = (long) this.dataList.size();
        for (int i = 0; i < this.dataList.size(); i++) {
            this.totSelectedSize += ((BigSizeFilesWrapper) this.dataList.get(i)).size;
            ((BigSizeFilesWrapper) this.dataList.get(i)).ischecked = true;
        }
    }

    public void unselect(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totSelectedCount--;
        this.totSelectedSize -= bigSizeFilesWrapper.size;
    }

    public void unselectAll() {
        this.totSelectedSize = 0;
        this.totSelectedCount = 0;
        for (int i = 0; i < this.dataList.size(); i++) {
            ((BigSizeFilesWrapper) this.dataList.get(i)).ischecked = false;
        }
    }

    private void getFiles(File file) {
        if (file != null && file.exists()) {
            File[] listFiles = file.listFiles(new ImageFileFilter(this.mediaType));
            if (listFiles != null) {
                for (File file2 : listFiles) {
                    if (file2.isDirectory()) {
                        getFiles(file2);
                    }
                    addChild(new BigSizeFilesWrapper(file2));
                    if (this.a != null) {
                        this.a.update(this.b);
                    }
                }
            }
        }
    }
}
