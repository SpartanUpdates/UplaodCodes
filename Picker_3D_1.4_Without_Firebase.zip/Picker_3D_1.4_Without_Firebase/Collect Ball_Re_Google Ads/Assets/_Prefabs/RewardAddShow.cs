﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class RewardAddShow : MonoBehaviour
    {
        public static RewardAddShow instance;
        
        [HideInInspector]
        public RewardBasedVideoAd rewardBasedVideo;

        public void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
            RequestRewardBasedVideo();            
        }

        private void OnEnable()
        {
            this.rewardBasedVideo.OnAdLoaded += RewardBasedVideoLoaded;
            this.rewardBasedVideo.OnAdFailedToLoad += RewardBasedVideoFailedToLoad;
            this.rewardBasedVideo.OnAdOpening += RewardBasedVideoOpened;
            this.rewardBasedVideo.OnAdStarted += RewardBasedVideoStarted;
            this.rewardBasedVideo.OnAdRewarded += RewardBasedVideoRewarded;
            this.rewardBasedVideo.OnAdClosed += RewardBasedVideoClosed;
            this.rewardBasedVideo.OnAdLeavingApplication += RewardBasedVideoLeftApplication;
        }
        private void OnDisable()
        {
            this.rewardBasedVideo.OnAdLoaded -= RewardBasedVideoLoaded;
            this.rewardBasedVideo.OnAdFailedToLoad -= RewardBasedVideoFailedToLoad;
            this.rewardBasedVideo.OnAdOpening -= RewardBasedVideoOpened;
            this.rewardBasedVideo.OnAdStarted -= RewardBasedVideoStarted;
            this.rewardBasedVideo.OnAdRewarded -= RewardBasedVideoRewarded;
            this.rewardBasedVideo.OnAdClosed -= RewardBasedVideoClosed;
            this.rewardBasedVideo.OnAdLeavingApplication -= RewardBasedVideoLeftApplication;
        }

        public void RequestRewardBasedVideo()
        {
            rewardBasedVideo = RewardBasedVideoAd.Instance;

            AdRequest request = new AdRequest.Builder().Build();

            rewardBasedVideo.LoadAd(request, Manager.instance.RewardID);

            Analytics.CustomEvent("Rewared_Ads_Request_Fire");
        }

        public void ShowVideo()
        {
            rewardBasedVideo.Show();
            Analytics.CustomEvent("Rewared_Ads_Video_Show");
        }
       
        bool isVideoSkip = true;

        public void RewardBasedVideoLoaded(object sender, EventArgs args)
        {

        }

        public void RewardBasedVideoFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            Analytics.CustomEvent("Rewared_Ads_Request_Fail");
        }

        public void RewardBasedVideoOpened(object sender, EventArgs args)
        {
            GameController.instance.noAddPanel.SetActive(true);
        }

        public void RewardBasedVideoStarted(object sender, EventArgs args)
        {
        }

        public void RewardBasedVideoClosed(object sender, EventArgs args)
        {
            if (!isVideoSkip)
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = true;
                    MainMenu.instance.RewardDone();
                    Analytics.CustomEvent("Rewared_Ads_Coins_Done");
                }
                else
                {
                    GameController.instance.SaveMe();
                    Analytics.CustomEvent("Rewared_Ads_Save_Me_Done");
                }
            }
            else
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = false;
                    MainMenu.instance.RewardDone();
                    Analytics.CustomEvent("Rewared_Ads_Coins_Skip");
                }
                else
                {
                    GameController.instance.SkipVideoAdd();
                    Analytics.CustomEvent("Rewared_Ads_Save_Me_Skip");
                }
            }
            Analytics.CustomEvent("Rewared_Ads_Close");
            isVideoSkip = true;
            RequestRewardBasedVideo();
        }

        public void RewardBasedVideoRewarded(object sender, Reward args)
        {
            isVideoSkip = false;
        }

        public void RewardBasedVideoLeftApplication(object sender, EventArgs args)
        {
        }
    }
}