package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.mbit.VideoMaker.Activity.HomeActivity;
import com.mbit.VideoMaker.Download.ThemeDownload;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Model.ThemelModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.View.Indicator;
import com.mbit.VideoMaker.application.MyApplication;
import com.unity3d.player.UnityPlayer;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

public class ThemeCategoryWiseAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    public int e = -1;
    public int f = -1;
//    protected int c;
    private Context mContext;
    private ArrayList<ThemelModel> themeCategoryList;
    private HomeActivity ActivityOfTheme;
    private int Adsindex = 0;

    public ThemeCategoryWiseAdapter(Context mContext, ArrayList<ThemelModel> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (HomeActivity) mContext;
        this.themeCategoryList = themeCategoryList;
    }

    public void RingTonePtah(final String str, final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                try {
                    if (str != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(Utils.d);
                        stringBuilder.append(File.separator);
                        stringBuilder.append("Ringtone");
                        stringBuilder.append(File.separator);
                        stringBuilder.append("ringtone.mp3");
                        String stringBuilder2 = stringBuilder.toString();
                        File file = new File(stringBuilder2);
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(Utils.d);
                        stringBuilder3.append(File.separator);
                        stringBuilder3.append("Ringtone");
                        CopyFileToStorage(str, stringBuilder2, stringBuilder3.toString());
                        stringBuilder3 = new StringBuilder("path : ");
                        stringBuilder3.append(str);
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_data", file.getAbsolutePath());
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(file.getName());
                        contentValues.put("title", stringBuilder4.toString());
                        contentValues.put("is_ringtone", Boolean.TRUE);
                        contentValues.put("mime_type", "audio/mp3");
                        stringBuilder3 = new StringBuilder("file://");
                        stringBuilder3.append(file.getAbsolutePath());
                        Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(stringBuilder3.toString());
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder stringBuilder5 = new StringBuilder("_data=\"");
                        stringBuilder5.append(file.getAbsolutePath());
                        stringBuilder5.append("\"");
                        contentResolver.delete(contentUriForPath, stringBuilder5.toString(), null);
                        Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                        ((Activity) context).runOnUiThread(new Runnable() {
                            public final void run() {
                                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        if (viewType == ITEM_TYPE_AD) {
            return new NativeAdViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.ad_unified_cat_item, viewGroup, false));

        } else {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_video_item, viewGroup, false);
            return new ThemeViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (getItemViewType(position) == ITEM_TYPE_AD) {
            final NativeAdViewHolder viewHolder = (NativeAdViewHolder) holder;
            final UnifiedNativeAdView unifiedNativeAdView = (UnifiedNativeAdView) viewHolder.adview;
            if (ActivityOfTheme.mNativeAds != null) {
                if (position <= ActivityOfTheme.mNativeAds.size()) {
                    UnifiedNativeAd nativeAd = ActivityOfTheme.mNativeAds.get(position);
                    if (nativeAd != null) {
                        populateNativeAdView(nativeAd, unifiedNativeAdView);
                    }
                } else {
                    if (Adsindex < ActivityOfTheme.mNativeAds.size()) {
                        UnifiedNativeAd nativeAd = ActivityOfTheme.mNativeAds.get(Adsindex);
                        populateNativeAdView(nativeAd, unifiedNativeAdView);
                        Adsindex++;
                    } else {
                        Adsindex = 0;
                    }
                }
            }
        } else {
            if (holder instanceof ThemeViewHolder) {
                final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
                final ThemelModel themelModel = themeCategoryList.get(position);
                Glide.with(this.mContext).load(themelModel.getImage()).into(viewHolder.iv_thumb);
                if (!themelModel.isAvailableOffline) {
                    if (themelModel.isDownloading) {
                        viewHolder.ivDownload.setVisibility(View.GONE);
                        viewHolder.tvUseTheme.setVisibility(View.GONE);
                        viewHolder.layoutInfo.setVisibility(View.GONE);
                        viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);

                    } else {
                        viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                        viewHolder.ivDownload.setVisibility(View.VISIBLE);
                        viewHolder.tvUseTheme.setVisibility(View.GONE);
                        viewHolder.layoutInfo.setVisibility(View.GONE);
                    }
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    viewHolder.tvUseTheme.setVisibility(View.VISIBLE);
                    viewHolder.layoutInfo.setVisibility(View.VISIBLE);
                }
                if (themelModel.o) {
                    viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_pause_ringtone);
                } else {
                    viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_play_ringtone);
                }
                if (themelModel.p) {
                    viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                    viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                    viewHolder.layoutThemeInfo.bringToFront();
                } else {
                    viewHolder.layoutThemeInfo.setVisibility(View.GONE);
                    viewHolder.ivInfo.setImageResource(R.drawable.menu_dots);
                }

                viewHolder.tvThemeName.setText(themelModel.getThemeName());
                viewHolder.tvThemeName.setSelected(true);
                viewHolder.tvThemeSize.setText(readableFileSize(themelModel.getAnimSoundfilesize()));
                viewHolder.tvThemeCounter.setText(String.valueOf(themelModel.getThemeCounter()));
                viewHolder.ivInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (themelModel.p) {
                            viewHolder.layoutThemeInfo.setVisibility(View.GONE);
                            viewHolder.ivInfo.setImageResource(R.drawable.menu_dots);
                            themelModel.p = false;
                        } else {
                            if (f == -1) {
                                viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                                viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                                viewHolder.layoutThemeInfo.bringToFront();
                            } else {
                                viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                                viewHolder.layoutThemeInfo.bringToFront();
                                viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                                if (f != -1) {
                                    themelModel.p = false;
                                }
                            }
                            themelModel.p = true;
                            f = position;
                            for (ThemelModel aThemeCategoryList : themeCategoryList) {
                                aThemeCategoryList.p = false;
                            }
                            themeCategoryList.get(position).p = true;
                        }
                        notifyDataSetChanged();
                    }
                });
                viewHolder.ivSetasRingtone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (themelModel.getAnimSoundname() != null) {
                                final String SoundPath = Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getAnimSoundname();
                                SetAsRingTone(mContext, SoundPath, themelModel);
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                });
                viewHolder.ivSetasWallpaper.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppImageAlertDialog);
                        final AlertDialog alertdialog = builder.create();
                        LayoutInflater inflater = ActivityOfTheme.getLayoutInflater();
                        final View dialogView = inflater.inflate(R.layout.set_confirmation_dialog, null);
                        alertdialog.setView(dialogView);
                        alertdialog.show();
                        TextView tvYes = dialogView.findViewById(R.id.tvYes);
                        TextView tvNo = dialogView.findViewById(R.id.tvNo);
                        dialogView.findViewById(R.id.ivCloseDialog).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                themelModel.p = true;
                                alertdialog.dismiss();
                                notifyDataSetChanged();
                            }
                        });

                        tvYes.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    if (themelModel.getThemeName() != null) {
                                        themelModel.p = false;
                                        alertdialog.dismiss();
                                        String path = Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getThemeName() + ".png";
                                        SetAsWallPapper(mContext, path);
                                        notifyDataSetChanged();
//                                        viewHolder.layoutThemeInfo.setVisibility(View.GONE);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        tvNo.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                themelModel.p = true;
                                alertdialog.dismiss();
                                notifyDataSetChanged();
                            }
                        });
                    }

                });
                viewHolder.ivPlayRingtone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (themelModel.getAnimSoundPath() != null) {
                                if (!themelModel.o) {
                                    if (e != -1) {
                                        final StringBuilder sb = new StringBuilder();
                                        sb.append(themelModel.getAnimSoundPath());
                                        Log.e("lastPlayPosition", sb.toString());
                                        themeCategoryList.get(e).o = false;
                                    }
                                    e = position;
                                    final StringBuilder sb2 = new StringBuilder("last    ");
                                    sb2.append(e);
                                    Log.e("lastPlayPosition", sb2.toString());
                                    PlayPause(themelModel.getAnimSoundPath(), true);
                                    if (e != -1) {
                                        themeCategoryList.get(e).o = false;
                                    }
                                    e = position;
                                    themelModel.o = true;
                                    for (ThemelModel aThemeCategoryList : themeCategoryList) {
                                        aThemeCategoryList.o = false;
                                    }
                                    themeCategoryList.get(position).o = true;
                                    notifyDataSetChanged();
                                    return;
                                }
                                PlayPause(themelModel.getAnimSoundPath(), false);
                                themelModel.o = false;
                                viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_play_ringtone);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                viewHolder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                        boolean isAllGrant = true;
//                        for (int i = 0; i < ActivityOfTheme.NECESSARY_PERMISSIONS.length; i++) {
//                            if (ContextCompat.checkSelfPermission(mContext,
//                                    ActivityOfTheme.NECESSARY_PERMISSIONS[i]) == PackageManager.PERMISSION_DENIED) {
//                                isAllGrant = false;
//                            }
//                        }
//                        if (isAllGrant) {
//                            DownloadFiles(position, viewHolder.ivDownload, viewHolder.ThemeDownProgress, viewHolder.tvThemeDownProgress, themelModel);
//                        } else {
//                            Toast.makeText(mContext, "Please Allow All Permission First", Toast.LENGTH_LONG).show();
//                            ActivityOfTheme.RequiredPermission("Sorry! we need all permission for make experience batter, Go to Setting And Allow Us.");
//                        }
                        DownloadFiles(position, viewHolder.ivDownload, viewHolder.tvUseTheme, viewHolder.layoutInfo, viewHolder.ThemeDownProgress, viewHolder.tvThemeDownProgress, themelModel);
                    }
                });
            }
        }
    }

    public final void PlayPause(final String dataSource, final boolean b) {
        if (b) {
            if (dataSource == null) {
                return;
            }
            final MediaPlayer w = ActivityOfTheme.mediaPlayer;
            if (w != null) {
                try {
                    w.stop();
                    w.release();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    final StringBuilder sb = new StringBuilder("stopPlaying() = ");
                    sb.append(ex.getMessage());
                    Log.e("ERR", sb.toString());
                }
            }
            ActivityOfTheme.mediaPlayer = new MediaPlayer();
            try {
                ActivityOfTheme.mediaPlayer.setDataSource(dataSource);
                ActivityOfTheme.mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    public final void onPrepared(final MediaPlayer mediaPlayer) {
                        mediaPlayer.start();
                    }
                });
                ActivityOfTheme.mediaPlayer.prepareAsync();
                return;
            } catch (IOException ex2) {
                ex2.printStackTrace();
                return;
            }
        }
        try {
            ActivityOfTheme.mediaPlayer.pause();
        } catch (IllegalStateException ex3) {
            ex3.printStackTrace();
        }
    }


    private void SetAsRingTone(final Context context, final String str, final ThemelModel themelModel) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppImageAlertDialog);
        final AlertDialog alertdialog = builder.create();
        LayoutInflater inflater = ActivityOfTheme.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.set_confirmation_dialog, null);
        alertdialog.setView(dialogView);
        alertdialog.show();
        final TextView textView = dialogView.findViewById(R.id.tvMsg);
        TextView tvYes = dialogView.findViewById(R.id.tvYes);
        TextView tvNo = dialogView.findViewById(R.id.tvNo);
        textView.setText(R.string.set_ring);
        dialogView.findViewById(R.id.ivCloseDialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                themelModel.p = true;
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                        themelModel.p = false;
                        RingTonePtah(str, context);
                        alertdialog.dismiss();
                        notifyDataSetChanged();
                    } else if (!SetPermission(ActivityOfTheme)) {
                        Toast.makeText(mContext, context.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                    } else if (!(str == null || context == null)) {
                        RingTonePtah(str, context);
                        themelModel.p = false;
                        notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, context.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                }
                alertdialog.dismiss();

            }
        });
        tvNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                themelModel.p = true;
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
    }

    private boolean SetPermission(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.System.canWrite(context)) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
                final StringBuilder sb = new StringBuilder("package:");
                sb.append(context.getPackageName());
                intent.setData(Uri.parse(sb.toString()));
                context.startActivityForResult(intent, 111);
            }
        }
        return false;
    }

    private void SetAsWallPapper(Context context, String str) {
        if (!(context == null || str == null)) {
            WallpaperManager instance = WallpaperManager.getInstance(context);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            int i = displayMetrics.heightPixels;
            int i2 = displayMetrics.widthPixels;
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                instance.setBitmap(BitmapFactory.decodeFile(str, options));
                instance.suggestDesiredDimensions(i2 / 2, i / 2);
                Toast.makeText(context, context.getString(R.string.wallpaper_done), Toast.LENGTH_LONG).show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    private void CopyFileToStorage(final String s, final String s2, final String s3) {
        try {
            final File file = new File(s3);
            if (!file.exists()) {
                file.mkdirs();
            }
            final FileInputStream fileInputStream = new FileInputStream(s);
            final FileOutputStream fileOutputStream = new FileOutputStream(s2);
            final byte[] array = new byte[1024];
            while (true) {
                final int read = fileInputStream.read(array);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException ex2) {
            ex2.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ((position > 0) && ((position + 1) % 5 == 0) && MyApplication.getInstance().IsNativeAdsLoaded) {
            return ITEM_TYPE_AD;
        } else {
            return ITEM_TYPE_DATA;
        }

    }


    private String readableFileSize(long size) {
        if (size <= 0) return "0";
        final String[] units = new String[]{"B", "kB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);

    }

    private void DownloadFiles(int position, ImageView ivDownload, TextView tvuseTheme, RelativeLayout layoutInfo, LinearLayout themeDownProgress, TextView tvThemeDownprogress, ThemelModel themelModel) {
        int UnitySoundSize = themelModel.getAnimSoundfilesize();
        String SongName = themelModel.getAnimSoundname();
        File SongPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        ActivityOfTheme.AllPath = themelModel.getAnimSoundPath() + "?" + Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getThemeName() + ".png" + "?" + themelModel.getGameobjectName();
        if (new File(Utils.INSTANCE.getThemeFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
               /* if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                    ActivityOfTheme.id = 100;
                    ActivityOfTheme.mInterstitialAd.show();
                } else {
                    UnityPlayer.UnitySendMessage("CategoryManagement", "OnLoadUserData", ActivityOfTheme.AllPath);
                    HideShowUnityBannerAds();
                    ActivityOfTheme.finish();
                }*/

                if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                    try {
                        ActivityOfTheme.hud = KProgressHUD.create(mContext)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        ActivityOfTheme.hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ActivityOfTheme.hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                                ActivityOfTheme.id = 100;
                                ActivityOfTheme.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    UnityPlayer.UnitySendMessage("CategoryManagement", "OnLoadUserData", ActivityOfTheme.AllPath);
                    HideShowUnityBannerAds();
                    ActivityOfTheme.finish();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    new DownloadTask().execute(ActivityOfTheme.DownloadCountUrl, themelModel.getThemeid());
                    new ThemeDownload(mContext, themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), themelModel.getImage(), themelModel.getThemeName() + ".png", ivDownload, tvuseTheme, layoutInfo, themeDownProgress, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                new DownloadTask().execute(ActivityOfTheme.DownloadCountUrl, themelModel.getThemeid());
                new ThemeDownload(mContext, themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), themelModel.getImage(), themelModel.getThemeName() + ".png", ivDownload, tvuseTheme, layoutInfo, themeDownProgress, tvThemeDownprogress, themelModel);

            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    /*   public class NativeAdViewHolder extends RecyclerView.ViewHolder {
           LinearLayout llAdContainer;
           NativeAdLayout nativeAd;
           MediaView admedia;
           MediaView adicon;
           TextView adtitle;
           TextView adbody;
           TextView adsocial;
           TextView adsponsored;
           Button btnAdAction;
           LinearLayout adchoicescontainer;


           NativeAdViewHolder(NativeAdLayout nativeAdLayout) {
               super(nativeAdLayout);
               nativeAd = nativeAdLayout;
               llAdContainer = nativeAdLayout.findViewById(R.id.llNativeAdContainer);
               admedia = nativeAdLayout.findViewById(R.id.native_ad_media);
               adtitle = nativeAdLayout.findViewById(R.id.native_ad_title);
               adbody = nativeAdLayout.findViewById(R.id.native_ad_body);
               adsocial = nativeAdLayout.findViewById(R.id.native_ad_social_context);
               adsponsored = nativeAdLayout.findViewById(R.id.native_ad_sponsored_label);
               btnAdAction = nativeAdLayout.findViewById(R.id.native_ad_call_to_action);
               adicon = nativeAdLayout.findViewById(R.id.native_ad_icon);
               adchoicescontainer = nativeAdLayout.findViewById(R.id.ad_choices_container);

           }
       }*/
    private void populateNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(nativeAd);

    }

    public class NativeAdViewHolder extends RecyclerView.ViewHolder {
        private View adview;

        public NativeAdViewHolder(View view) {
            super(view);
            this.adview = view;
        }
    }

    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload, ivLikeTheme;
        TextView tvThemeName, tvThemeSize, tvThemeCounter, tvThemeDownProgress, tvUseTheme;
        Indicator indicatorThemeProgress;
        LinearLayout ThemeDownProgress;
        LinearLayout layoutDownloadMask;
        RelativeLayout layoutInfo;
        RelativeLayout layoutThemeInfo;
        ImageView ivSetasWallpaper;
        ImageView ivSetasRingtone;
        ImageView ivPlayRingtone;
        ImageView ivInfo;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            ivLikeTheme = itemView.findViewById(R.id.iv_like_theme);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeCounter = itemView.findViewById(R.id.tvLike_counter);
            tvThemeSize = itemView.findViewById(R.id.tvVideoSize);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
            tvUseTheme = itemView.findViewById(R.id.tvUseTheme);
            layoutDownloadMask = itemView.findViewById(R.id.downloadMask);
            layoutInfo = itemView.findViewById(R.id.layout_info);
            ivInfo = itemView.findViewById(R.id.ivInfo);
            layoutThemeInfo = itemView.findViewById(R.id.rlThemeInfo);
            ivPlayRingtone = itemView.findViewById(R.id.ivPlayRingtone);
            ivSetasWallpaper = itemView.findViewById(R.id.ivSetasWallpaper);
            ivSetasRingtone = itemView.findViewById(R.id.ivSetasRingtone);
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class DownloadTask extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("theme_id", arg0[1]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }
}
