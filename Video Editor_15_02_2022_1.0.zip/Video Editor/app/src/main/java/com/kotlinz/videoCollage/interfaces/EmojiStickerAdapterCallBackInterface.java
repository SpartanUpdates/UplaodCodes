package com.kotlinz.videoCollage.interfaces;

public interface EmojiStickerAdapterCallBackInterface {
    void itemClick(int i);
}
