package com.esc.storymaker.interfaces;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int i);
}
