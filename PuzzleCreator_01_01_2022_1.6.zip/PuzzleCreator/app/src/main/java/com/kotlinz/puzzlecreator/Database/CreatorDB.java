package com.kotlinz.puzzlecreator.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.kotlinz.puzzlecreator.model.DB_Pojo;

import java.util.ArrayList;
import java.util.List;

public class CreatorDB extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "creator_data";
    private static final String TABLE_Points = "table_points";
    private static final String TABLE_HINT = "hint_points";

    private static final String KEY_ID = "id";
    private static final String KEY_PUZZLE_ID = "puzzle_id";
    private static final String KEY_IS_NEW = "is_new";
    private static final String KEY_VIEW_BY = "viewby";
    private static final String KEY_SOLVE_BY = "solveby";

    public CreatorDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE = "CREATE TABLE " + TABLE_Points + " ("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_PUZZLE_ID + " TEXT,"
                + KEY_VIEW_BY + " TEXT,"
                + KEY_SOLVE_BY + " TEXT,"
                + KEY_IS_NEW + " TEXT)";
        Log.e("TAble", "......." + CREATE_TABLE);

        String CREATE_HINT_TABLE = "CREATE TABLE " + TABLE_HINT + " ("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_PUZZLE_ID + " TEXT )";

        Log.e("TAble", "......." + CREATE_HINT_TABLE);
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_HINT_TABLE);
    }

    public List<DB_Pojo> viewData(String Pid) {
        List<DB_Pojo> list = new ArrayList<>();

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor;

        String query = "Select " + KEY_VIEW_BY + " , " + KEY_SOLVE_BY + " from " + TABLE_Points + " WHERE " + KEY_PUZZLE_ID + "='" + Pid + "'";
        cursor = sqLiteDatabase.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                DB_Pojo contact = new DB_Pojo();
                contact.setSolveby(cursor.getString(cursor.getColumnIndex(KEY_SOLVE_BY)));
                contact.setViewby(cursor.getString(cursor.getColumnIndex(KEY_VIEW_BY)));
                list.add(contact);
            } while (cursor.moveToNext());
        }
        return list;
    }
    public void addData(DB_Pojo data) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_PUZZLE_ID, data.getPuzzleId());
        values.put(KEY_VIEW_BY, data.getViewby());
        values.put(KEY_SOLVE_BY, data.getSolveby());
        values.put(KEY_IS_NEW, data.getIsnew());

        db.insert(TABLE_Points, null, values);
        db.close();
    }
    public void addHintData(DB_Pojo data) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_PUZZLE_ID, data.getPuzzleId());

        db.insert(TABLE_HINT, null, values);
        Log.e("TAG","HINT"+db.toString());
        db.close();
    }
    public boolean IfHintView(String pid) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_HINT + " WHERE " + KEY_PUZZLE_ID + "='" + pid + "'", null);
            if (cursor.moveToFirst()) {
                db.close();
                return true;
            }
            db.close();
        } catch (Exception errorException) {
            //db.close();
        }
        return false;
    }
    public boolean IfRecordExist(String pid) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_Points + " WHERE " + KEY_PUZZLE_ID + "='" + pid + "'", null);
            if (cursor.moveToFirst()) {
                db.close();
                return true;
            }
            db.close();
        } catch (Exception errorException) {
            //db.close();
        }
        return false;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Points);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HINT);

        onCreate(db);
    }
}
