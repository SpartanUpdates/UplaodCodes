package com.esc.dailyrandomfacts.adapter;

import android.util.SparseArray;
import android.view.ViewGroup;

import com.esc.dailyrandomfacts.fragment.QuoteFragment;
import com.esc.dailyrandomfacts.activity.QuotesHomeActivity;

import java.util.ArrayList;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class QuotesViewPagerAdapter extends FragmentStatePagerAdapter {
    private QuotesHomeActivity activity;
    private Fragment mCurrentFragment;
    private ArrayList<String> quotes;
    private SparseArray<Fragment> registeredFragments = new SparseArray();

    public int getItemPosition(Object obj) {
        return -2;
    }

    public QuotesViewPagerAdapter(FragmentManager fragmentManager, ArrayList<String> arrayList, QuotesHomeActivity quotesHomeActivity) {
        super(fragmentManager);
        this.quotes = arrayList;
        this.activity = quotesHomeActivity;
    }

    public Fragment getItem(int i) {
        return QuoteFragment.newInstance((String) this.quotes.get(i));
    }

    public Object instantiateItem(ViewGroup viewGroup, int i) {
        Fragment fragment = (Fragment) super.instantiateItem(viewGroup, i);
        this.registeredFragments.put(i, fragment);
        return fragment;
    }

    public int getCount() {
        return this.quotes.size();
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        this.registeredFragments.remove(i);
        super.destroyItem(viewGroup, i, obj);
    }

    public Fragment getCurrentFragment() {
        return this.mCurrentFragment;
    }

    public void setPrimaryItem(ViewGroup viewGroup, int i, Object obj) {
        if (getCurrentFragment() != obj) {
            this.mCurrentFragment = (Fragment) obj;
        }
        super.setPrimaryItem(viewGroup, i, obj);
    }
}
