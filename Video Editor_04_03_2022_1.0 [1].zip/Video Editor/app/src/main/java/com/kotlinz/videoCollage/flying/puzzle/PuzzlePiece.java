package com.kotlinz.videoCollage.flying.puzzle;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;


public class PuzzlePiece {
    private static final Xfermode SRC_IN = new PorterDuffXfermode(Mode.SRC_IN);
    private ValueAnimator animator;
    private Area area;
    private final PointF centerPoint;
    private Rect drawableBounds;
    private float[] drawablePoints;
    private int duration = 300;
    private final RectF mappedBounds;
    private final PointF mappedCenterPoint;
    private float[] mappedDrawablePoints;
    private Matrix matrix;
    private String path = "";
    private int position = 0;
    private Matrix previousMatrix;
    private float previousMoveX;
    private float previousMoveY;
    private Matrix tempMatrix;
    private View view;

    PuzzlePiece(View view, Area area, Matrix matrix) {
        this.view = view;
        this.area = area;
        this.matrix = matrix;
        this.previousMatrix = new Matrix();
        this.drawableBounds = new Rect(0, 0, getWidth(), getHeight());
        this.drawablePoints = new float[]{0.0f, 0.0f, (float) getWidth(), 0.0f, (float) getWidth(), (float) getHeight(), 0.0f, (float) getHeight()};
        this.mappedDrawablePoints = new float[8];
        this.mappedBounds = new RectF();
        this.centerPoint = new PointF(area.centerX(), area.centerY());
        this.mappedCenterPoint = new PointF();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        this.animator = ofFloat;
        ofFloat.setInterpolator(new DecelerateInterpolator());
        this.tempMatrix = new Matrix();
    }

    /* Access modifiers changed, original: 0000 */
    public void draw(Canvas canvas, boolean z) {
        draw(canvas, 255, true, z);
    }

    /* Access modifiers changed, original: 0000 */
    public void draw(Canvas canvas, int i, boolean z) {
        draw(canvas, i, false, z);
    }

    private void draw(Canvas canvas, int i, boolean z, boolean z2) {
        canvas.save();
        if (z) {
            canvas.clipPath(this.area.getAreaPath());
        }
        canvas.concat(this.matrix);
        this.view.setClipBounds(this.drawableBounds);
        this.view.setAlpha((float) i);
        this.view.draw(canvas);
        canvas.restore();
    }

    public Area getArea() {
        return this.area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public View getView() {
        return this.view;
    }

    public void setView(View view) {
        this.view = view;
        this.drawableBounds = new Rect(0, 0, getWidth(), getHeight());
        this.drawablePoints = new float[]{0.0f, 0.0f, (float) getWidth(), 0.0f, (float) getWidth(), (float) getHeight(), 0.0f, (float) getHeight()};
    }

    public int getWidth() {
        return this.view.getMeasuredWidth();
    }

    public int getHeight() {
        return this.view.getMeasuredHeight();
    }

    public boolean contains(float f, float f2) {
        return this.area.contains(f, f2);
    }

    public boolean contains(Line line) {
        return this.area.contains(line);
    }

    public Rect getDrawableBounds() {
        return this.drawableBounds;
    }

    /* Access modifiers changed, original: 0000 */
    public void setPreviousMoveX(float f) {
        this.previousMoveX = f;
    }

    /* Access modifiers changed, original: 0000 */
    public void setPreviousMoveY(float f) {
        this.previousMoveY = f;
    }

    public RectF getCurrentDrawableBounds() {
        this.matrix.mapRect(this.mappedBounds, new RectF(this.drawableBounds));
        return this.mappedBounds;
    }

    private PointF getCurrentDrawableCenterPoint() {
        getCurrentDrawableBounds();
        this.mappedCenterPoint.x = this.mappedBounds.centerX();
        this.mappedCenterPoint.y = this.mappedBounds.centerY();
        return this.mappedCenterPoint;
    }

    public PointF getAreaCenterPoint() {
        this.centerPoint.x = this.area.centerX();
        this.centerPoint.y = this.area.centerY();
        return this.centerPoint;
    }

    private float getMatrixScale() {
        return MatrixUtils.getMatrixScale(this.matrix);
    }

    public float getMatrixAngle() {
        return MatrixUtils.getMatrixAngle(this.matrix);
    }

    /* Access modifiers changed, original: 0000 */
    public float[] getCurrentDrawablePoints() {
        this.matrix.mapPoints(this.mappedDrawablePoints, this.drawablePoints);
        return this.mappedDrawablePoints;
    }

    /* Access modifiers changed, original: 0000 */
    public boolean isFilledArea() {
        RectF currentDrawableBounds = getCurrentDrawableBounds();
        return currentDrawableBounds.left <= this.area.left() && currentDrawableBounds.top <= this.area.top() && currentDrawableBounds.right >= this.area.right() && currentDrawableBounds.bottom >= this.area.bottom();
    }

    /* Access modifiers changed, original: 0000 */
    public boolean canFilledArea() {
        return MatrixUtils.getMatrixScale(this.matrix) >= MatrixUtils.getMinMatrixScale(this);
    }

    /* Access modifiers changed, original: 0000 */
    public void record() {
        this.previousMatrix.set(this.matrix);
    }

    /* Access modifiers changed, original: 0000 */
    public void translate(float f, float f2) {
        this.matrix.set(this.previousMatrix);
        postTranslate(f, f2);
    }

    private void zoom(float f, float f2, PointF pointF) {
        this.matrix.set(this.previousMatrix);
        postScale(f, f2, pointF);
    }

    /* Access modifiers changed, original: 0000 */
    public void zoomAndTranslate(float f, float f2, PointF pointF, float f3, float f4) {
        this.matrix.set(this.previousMatrix);
        postTranslate(f3, f4);
        postScale(f, f2, pointF);
    }

    /* Access modifiers changed, original: 0000 */
    public void set(Matrix matrix) {
        this.matrix.set(matrix);
        moveToFillArea(null);
    }

    /* Access modifiers changed, original: 0000 */
    public void postTranslate(float f, float f2) {
        this.matrix.postTranslate(f, f2);
    }

    /* Access modifiers changed, original: 0000 */
    public void postScale(float f, float f2, PointF pointF) {
        this.matrix.postScale(f, f2, pointF.x, pointF.y);
    }

    /* Access modifiers changed, original: 0000 */
    public void postFlipVertically() {
        this.matrix.postScale(1.0f, -1.0f, this.area.centerX(), this.area.centerY());
    }

    /* Access modifiers changed, original: 0000 */
    public void postFlipHorizontally() {
        this.matrix.postScale(-1.0f, 1.0f, this.area.centerX(), this.area.centerY());
    }

    /* Access modifiers changed, original: 0000 */
    public void postRotate(float f) {
        this.matrix.postRotate(f, this.area.centerX(), this.area.centerY());
        f = MatrixUtils.getMinMatrixScale(this);
        if (getMatrixScale() < f) {
            PointF pointF = new PointF();
            pointF.set(getCurrentDrawableCenterPoint());
            postScale(f / getMatrixScale(), f / getMatrixScale(), pointF);
        }
        if (!MatrixUtils.judgeIsImageContainsBorder(this, getMatrixAngle())) {
            float[] calculateImageIndents = MatrixUtils.calculateImageIndents(this);
            postTranslate(-(calculateImageIndents[0] + calculateImageIndents[2]), -(calculateImageIndents[1] + calculateImageIndents[3]));
        }
    }

    private void animateTranslate(final View view, final float f, final float f2) {
        this.animator.end();
        this.animator.removeAllUpdateListeners();
        this.animator.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                PuzzlePiece.this.translate(f * ((Float) valueAnimator.getAnimatedValue()).floatValue(), f2 * ((Float) valueAnimator.getAnimatedValue()).floatValue());
                view.invalidate();
            }
        });
        this.animator.setDuration((long) this.duration);
        this.animator.start();
    }

    /* Access modifiers changed, original: 0000 */
    public void moveToFillArea(View view) {
        if (!isFilledArea()) {
            record();
            RectF currentDrawableBounds = getCurrentDrawableBounds();
            float f = 0.0f;
            float left = currentDrawableBounds.left > this.area.left() ? this.area.left() - currentDrawableBounds.left : 0.0f;
            if (currentDrawableBounds.top > this.area.top()) {
                f = this.area.top() - currentDrawableBounds.top;
            }
            if (currentDrawableBounds.right < this.area.right()) {
                left = this.area.right() - currentDrawableBounds.right;
            }
            if (currentDrawableBounds.bottom < this.area.bottom()) {
                f = this.area.bottom() - currentDrawableBounds.bottom;
            }
            if (view == null) {
                postTranslate(left, f);
            } else {
                animateTranslate(view, left, f);
            }
        }
    }

    /* Access modifiers changed, original: 0000 */
    public void fillArea(View view, boolean z) {
        if (!isFilledArea()) {
            record();
            final float matrixScale = getMatrixScale();
            final float minMatrixScale = MatrixUtils.getMinMatrixScale(this);
            final PointF pointF = new PointF();
            pointF.set(getCurrentDrawableCenterPoint());
            this.tempMatrix.set(this.matrix);
            float f = minMatrixScale / matrixScale;
            this.tempMatrix.postScale(f, f, pointF.x, pointF.y);
            RectF rectF = new RectF(this.drawableBounds);
            this.tempMatrix.mapRect(rectF);
            float f2 = 0.0f;
            f = rectF.left > this.area.left() ? this.area.left() - rectF.left : 0.0f;
            if (rectF.top > this.area.top()) {
                f2 = this.area.top() - rectF.top;
            }
            if (rectF.right < this.area.right()) {
                f = this.area.right() - rectF.right;
            }
            float f3 = f;
            float bottom = rectF.bottom < this.area.bottom() ? this.area.bottom() - rectF.bottom : f2;
            this.animator.end();
            this.animator.removeAllUpdateListeners();
            f2 = f3;
            f3 = bottom;
            final View view2 = view;
            this.animator.addUpdateListener(new AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    float f = matrixScale;
                    float f2 = (((minMatrixScale - f) * floatValue) + f) / f;
                    f = f2 * floatValue;
                    float f3 = 0;
                    f3 = f3 * floatValue;
                    PuzzlePiece.this.zoom(f2, f2, pointF);
                    PuzzlePiece.this.postTranslate(f, f3);
                    view2.invalidate();
                }
            });
            if (z) {
                this.animator.setDuration(0);
            } else {
                this.animator.setDuration((long) this.duration);
            }
            this.animator.start();
        }
    }


    public void updateWith(MotionEvent motionEvent, Line line) {
        float x = (motionEvent.getX() - this.previousMoveX) / 2.0f;
        float y = (motionEvent.getY() - this.previousMoveY) / 2.0f;
        if (!canFilledArea()) {
            float minMatrixScale = MatrixUtils.getMinMatrixScale(this) / getMatrixScale();
            postScale(minMatrixScale, minMatrixScale, getArea().getCenterPoint());
            record();
            this.previousMoveX = motionEvent.getX();
            this.previousMoveY = motionEvent.getY();
        }
        if (line.direction() == Line.Direction.HORIZONTAL) {
            translate(0.0f, y);
        } else if (line.direction() == Line.Direction.VERTICAL) {
            translate(x, 0.0f);
        }
        RectF currentDrawableBounds = getCurrentDrawableBounds();
        Area area = getArea();
        float top = currentDrawableBounds.top > area.top() ? area.top() - currentDrawableBounds.top : 0.0f;
        if (currentDrawableBounds.bottom < area.bottom()) {
            top = area.bottom() - currentDrawableBounds.bottom;
        }
        y = currentDrawableBounds.left > area.left() ? area.left() - currentDrawableBounds.left : 0.0f;
        if (currentDrawableBounds.right < area.right()) {
            y = area.right() - currentDrawableBounds.right;
        }
        if (y != 0.0f || top != 0.0f) {
            this.previousMoveX = motionEvent.getX();
            this.previousMoveY = motionEvent.getY();
            postTranslate(y, top);
            record();
        }
    }

    /* Access modifiers changed, original: 0000 */
    public boolean isAnimateRunning() {
        return this.animator.isRunning();
    }

    /* Access modifiers changed, original: 0000 */
    public void setAnimateDuration(int i) {
        this.duration = i;
    }

    public Matrix getMatrix() {
        return this.matrix;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }
}
