package com.example.womenabsworkout.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.womenabsworkout.R;
import com.travijuu.numberpicker.library.Enums.ActionEnum;
import com.travijuu.numberpicker.library.Interface.ValueChangedListener;
import com.travijuu.numberpicker.library.NumberPicker;
import java.util.Locale;
import kr.pe.burt.android.lib.faimageview.FAImageView;

public class ExcDetailsActivity extends AppCompatActivity {
    private LinearLayout adView;
    private boolean adloaded = false;
    private FAImageView animImageFull;
    public int editCycle;
    public boolean editedValue = false;
    int i;
    TextView l;
    Context m;
    private SharedPreferences mSharedPreferences;
    LayoutInflater n;

    private LinearLayout nativeAdContainer;
    int o;
    int p;
    int q = 0;
    String r;

    public static int dpToPx() {
        return (int) (Resources.getSystem().getDisplayMetrics().density * 50.0f);
    }

    private void getScreenHeightWidth() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.o = displayMetrics.heightPixels;
        this.p = displayMetrics.widthPixels;
    }

    private boolean isConnectedToInternet() {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (connectivityManager != null) {
                @SuppressLint("MissingPermission") NetworkInfo[] allNetworkInfo = connectivityManager.getAllNetworkInfo();
                if (allNetworkInfo != null) {
                    for (NetworkInfo state : allNetworkInfo) {
                        if (state.getState() == State.CONNECTED) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
        return false;
    }

    private void updateLocale(String str) {
        Locale locale = new Locale(str);
        Resources resources = getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        resources.updateConfiguration(configuration, displayMetrics);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.mSharedPreferences = defaultSharedPreferences;
        String string = defaultSharedPreferences.getString("languageToLoad", "");
        this.r = string;
        updateLocale(string);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.exc_details_layout);
        this.m = this;
        Bundle extras = getIntent().getExtras();
        int[] intArray = extras.getIntArray("framesIdArray");
        String string2 = extras.getString("excName");
        String str = "excCycle";
        extras.getInt(str);
        int i = extras.getInt(str);
        this.i = extras.getInt("excNameDescResId");
        String toUpperCase = string2.replace("_", " ").toUpperCase();
        Toolbar toolbar = (Toolbar) findViewById(R.id.exc_details_layout_mtoolbar);
        ((TextView) toolbar.findViewById(R.id.exc_details_layout_toolbar_title)).setText(toUpperCase);

        toolbar.setNavigationOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ExcDetailsActivity.this.finish();
            }
        });
        NumberPicker numberPicker = (NumberPicker) findViewById(R.id.number_picker);
        numberPicker.setMax(100);
        numberPicker.setMin(5);
        numberPicker.setValue(i);
        this.editCycle = i;
        numberPicker.setValueChangedListener(new ValueChangedListener() {
            public void valueChanged(int i, ActionEnum actionEnum) {
                ExcDetailsActivity.this.editCycle = i;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Np val ");
                stringBuilder.append(i);
                Log.e("TAG", stringBuilder.toString());
                ExcDetailsActivity.this.editedValue = true;
            }
        });
        this.l = (TextView) findViewById(R.id.description_exDetail);
        FAImageView fAImageView = (FAImageView) findViewById(R.id.animation_exDetail);
        this.animImageFull = fAImageView;
        fAImageView.setInterval(1000);
        this.animImageFull.setLoop(true);
        this.animImageFull.reset();
        for (int addImageFrame : intArray) {
            this.animImageFull.addImageFrame(addImageFrame);
        }
        this.animImageFull.startAnimation();
        this.l.setText(this.i);
        getScreenHeightWidth();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
