package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;


public class SecondActivity extends AppCompatActivity {

    Activity activity = SecondActivity.this;
    public static Editor editor;
    public static SharedPreferences sharedpreferences;
    static ArrayList<String> tarosubcat = new ArrayList();
    static ArrayList<String> tarosubcat2 = new ArrayList();

    CustomList_Subcat adp2;
    Typeface face;
    TextView headernote1;
    TextView headernote2;
    String menu;
    String menu2;
    String name;
    ListView subcatlist;
    String subtype;
    String subtype_eng;
    TextView titleview;
    String type;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private class CustomList_Subcat extends ArrayAdapter<String> {
        private final Activity context;
        private final ArrayList<String> dlist;

        public CustomList_Subcat(Activity activity, ArrayList<String> arrayList) {
            super(activity, R.layout.list_item1, arrayList);
            this.context = activity;
            this.dlist = arrayList;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            view = this.context.getLayoutInflater().inflate(R.layout.list_item1, null, true);
            TextView textView = view.findViewById(R.id.txtcatview);
            textView.setTypeface(SecondActivity.this.face);
            textView.setText(this.dlist.get(i));
            textView.setTextColor(-1);
            return view;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public SecondActivity() {
        String str = "";
        this.subtype = str;
        this.subtype_eng = str;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_second);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
        sharedpreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this.face = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, null);
        this.titleview = inflate.findViewById(R.id.title);
        getSupportActionBar().setCustomView(inflate);
        this.titleview.setTypeface(this.face);
        Bundle extras = getIntent().getExtras();
        this.menu = extras.getString("menu");
        this.name = extras.getString("name");
        this.subtype = extras.getString("subtype");
        this.subtype_eng = extras.getString("subtype_eng");
        this.headernote1 = findViewById(R.id.headernote1);
        this.headernote2 = findViewById(R.id.headernote2);
        this.headernote1.setTypeface(this.face);
        this.headernote2.setTypeface(this.face);
        TextView textView = this.headernote1;
        StringBuilder stringBuilder = new StringBuilder();
        String str = "";
        stringBuilder.append(str);
        stringBuilder.append(this.menu);
        textView.setText(stringBuilder.toString());
        textView = this.titleview;
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(this.menu);
        textView.setText(stringBuilder.toString());
        this.subcatlist = findViewById(R.id.listView1);
        String str2 = this.name;
        this.menu2 = str2;
        ArrayList arrayList;
        if (str2.equals("Pentacles")) {
            arrayList = tarosubcat;
            arrayList.removeAll(arrayList);
            arrayList = tarosubcat2;
            arrayList.removeAll(arrayList);
            fill_for_minor_subcat(this.menu2);
            tarosubcat2.add(getResources().getString(R.string.aceofpentacles));
            tarosubcat2.add(getResources().getString(R.string.twoofpentacles));
            tarosubcat2.add(getResources().getString(R.string.threeofpentacles));
            tarosubcat2.add(getResources().getString(R.string.fourofpentacles));
            tarosubcat2.add(getResources().getString(R.string.fiveofpentacles));
            tarosubcat2.add(getResources().getString(R.string.sixofpentacles));
            tarosubcat2.add(getResources().getString(R.string.sevenofpentacles));
            tarosubcat2.add(getResources().getString(R.string.eightofpentacles));
            tarosubcat2.add(getResources().getString(R.string.nineofpentacles));
            tarosubcat2.add(getResources().getString(R.string.tenofpentacles));
            tarosubcat2.add(getResources().getString(R.string.pageofpentacles));
            tarosubcat2.add(getResources().getString(R.string.knightofpentacles));
            tarosubcat2.add(getResources().getString(R.string.queenofpentacles));
            tarosubcat2.add(getResources().getString(R.string.kingofpentacles));
        } else if (this.menu2.equals("Cups")) {
            arrayList = tarosubcat;
            arrayList.removeAll(arrayList);
            arrayList = tarosubcat2;
            arrayList.removeAll(arrayList);
            fill_for_minor_subcat(this.menu2);
            tarosubcat2.add(getResources().getString(R.string.aceofcups));
            tarosubcat2.add(getResources().getString(R.string.twoofcups));
            tarosubcat2.add(getResources().getString(R.string.threeofcups));
            tarosubcat2.add(getResources().getString(R.string.fourofcups));
            tarosubcat2.add(getResources().getString(R.string.fiveofcups));
            tarosubcat2.add(getResources().getString(R.string.sixofcups));
            tarosubcat2.add(getResources().getString(R.string.sevenofcups));
            tarosubcat2.add(getResources().getString(R.string.eightofcups));
            tarosubcat2.add(getResources().getString(R.string.nineofcups));
            tarosubcat2.add(getResources().getString(R.string.tenofcups));
            tarosubcat2.add(getResources().getString(R.string.pageofcups));
            tarosubcat2.add(getResources().getString(R.string.knightofcups));
            tarosubcat2.add(getResources().getString(R.string.queenofcups));
            tarosubcat2.add(getResources().getString(R.string.kingofcups));
        } else if (this.menu2.equals("Swords")) {
            arrayList = tarosubcat;
            arrayList.removeAll(arrayList);
            arrayList = tarosubcat2;
            arrayList.removeAll(arrayList);
            fill_for_minor_subcat(this.menu2);
            tarosubcat2.add(getResources().getString(R.string.aceofswords));
            tarosubcat2.add(getResources().getString(R.string.twoofswords));
            tarosubcat2.add(getResources().getString(R.string.threeofswords));
            tarosubcat2.add(getResources().getString(R.string.fourofswords));
            tarosubcat2.add(getResources().getString(R.string.fiveofswords));
            tarosubcat2.add(getResources().getString(R.string.sixofswords));
            tarosubcat2.add(getResources().getString(R.string.sevenofswords));
            tarosubcat2.add(getResources().getString(R.string.eightofswords));
            tarosubcat2.add(getResources().getString(R.string.nineofswords));
            tarosubcat2.add(getResources().getString(R.string.tenofswords));
            tarosubcat2.add(getResources().getString(R.string.pageofswords));
            tarosubcat2.add(getResources().getString(R.string.knightofswords));
            tarosubcat2.add(getResources().getString(R.string.queenofswords));
            tarosubcat2.add(getResources().getString(R.string.kingofswords));
        } else if (this.menu2.equals("Wands")) {
            arrayList = tarosubcat;
            arrayList.removeAll(arrayList);
            arrayList = tarosubcat2;
            arrayList.removeAll(arrayList);
            fill_for_minor_subcat(this.menu2);
            tarosubcat2.add(getResources().getString(R.string.aceofwands));
            tarosubcat2.add(getResources().getString(R.string.twoofwands));
            tarosubcat2.add(getResources().getString(R.string.threeofwands));
            tarosubcat2.add(getResources().getString(R.string.fourofwands));
            tarosubcat2.add(getResources().getString(R.string.fiveofwands));
            tarosubcat2.add(getResources().getString(R.string.sixofwands));
            tarosubcat2.add(getResources().getString(R.string.sevenofwands));
            tarosubcat2.add(getResources().getString(R.string.eightofwands));
            tarosubcat2.add(getResources().getString(R.string.nineofwands));
            tarosubcat2.add(getResources().getString(R.string.tenofwands));
            tarosubcat2.add(getResources().getString(R.string.pageofwands));
            tarosubcat2.add(getResources().getString(R.string.knightofwands));
            tarosubcat2.add(getResources().getString(R.string.queenofwands));
            tarosubcat2.add(getResources().getString(R.string.kingofwands));
        }
        this.subcatlist.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                SecondActivity.this.type = "one";
                String str = SecondActivity.tarosubcat.get(i);
                Bundle bundle = new Bundle();
                bundle.putString("ques", SecondActivity.this.menu);
                bundle.putString("name", str);
                bundle.putString("name2", SecondActivity.tarosubcat2.get(i));
                bundle.putString("type", SecondActivity.this.type);
                bundle.putString("subtype", SecondActivity.this.subtype);
                bundle.putString("subtype_eng", SecondActivity.this.subtype_eng);
                bundle.putString("ccc", "Meanings Of All Tarot Cards");
                Intent intent = new Intent(view.getContext(), TaroResultActivity.class);
                intent.putExtras(bundle);
                SecondActivity.this.startActivityForResult(intent, 0);
                SecondActivity.this.adp2.notifyDataSetChanged();
            }
        });
        BannerAds();
    }


    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fill_for_minor_subcat(String str) {
        if (tarosubcat.size() == 0) {
            ArrayList arrayList = tarosubcat;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Ace of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Two of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Three of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Four of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Five of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Six of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Seven of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Eight of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Nine of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Ten of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Page of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Knight of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("Queen of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
            arrayList = tarosubcat;
            stringBuilder = new StringBuilder();
            stringBuilder.append("King of ");
            stringBuilder.append(str);
            arrayList.add(stringBuilder.toString());
        }
        this.headernote2.setText(getResources().getString(R.string.chooseacard));
        CustomList_Subcat customList_Subcat = new CustomList_Subcat(this, tarosubcat2);
        this.adp2 = customList_Subcat;
        this.subcatlist.setAdapter(customList_Subcat);
    }


    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    public void onBackPressed() {
        finish();
        Intent intent = new Intent(this, TaroQuestionsActivity.class);
        startActivity(intent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
