package com.rtovehicleinformation.Room;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "OwnerHistoryPaid",indices = @Index(value = {"registrationNo"},unique = true))
public class OwnerHistoryPaidModel {

    @PrimaryKey(autoGenerate = true)
    public int id;
    public String ownerName;
    public String registrationNo;
    public String registrationDate;
    public String fuelType;
    public String engineNumber;
    public String insuranceUpto;
    public String vehicleClass;
    public String city;
    public String state;

    public OwnerHistoryPaidModel(String ownerName, String registrationNo, String registrationDate, String fuelType, String engineNumber, String insuranceUpto, String vehicleClass, String city, String state) {
        this.ownerName = ownerName;
        this.registrationNo = registrationNo;
        this.registrationDate = registrationDate;
        this.fuelType = fuelType;
        this.engineNumber = engineNumber;
        this.insuranceUpto = insuranceUpto;
        this.vehicleClass = vehicleClass;
        this.city = city;
        this.state = state;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public void setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
    }

    public String getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getEngineNumber() {
        return engineNumber;
    }

    public void setEngineNumber(String engineNumber) {
        this.engineNumber = engineNumber;
    }

    public String getInsuranceUpto() {
        return insuranceUpto;
    }

    public void setInsuranceUpto(String insuranceUpto) {
        this.insuranceUpto = insuranceUpto;
    }

    public String getVehicleClass() {
        return vehicleClass;
    }

    public void setVehicleClass(String vehicleClass) {
        this.vehicleClass = vehicleClass;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
