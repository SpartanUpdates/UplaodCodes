package com.xyz.vehiclemanager.vehicledetails.vehiclemileage.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.database.MileageDbHelper;
import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.adapter.VehicleMileageAdapter;
import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class VehicleMileageActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = VehicleMileageActivity.this;
    private ImageView iv_addmileage;
    private LinearLayout ll_empty;
    private RecyclerView rvmileage;
    private ImageView iv_back;
    private VehicleMileageAdapter vehicleMileageAdapter;
    private ArrayList<Mileage> mileagelist;
    private MileageDbHelper mileageDbHelper;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_mileage);
        mileagelist = new ArrayList<>();
        mileageDbHelper = new MileageDbHelper(this);
        this.mileagelist = this.mileageDbHelper.listmileage();
        BindView();
        PutAnalyticsEvent();
        BannerAds();
        SetData();
    }

    private void SetData() {
        vehicleMileageAdapter = new VehicleMileageAdapter(VehicleMileageActivity.this, mileagelist, new VehicleMileageAdapter.OnItemClickListener() {
            public void onItemClick(final int n) {
                if (!VehicleMileageActivity.this.isFinishing()) {
                    View view = ((LayoutInflater) VehicleMileageActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_delete_itemdialog, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(VehicleMileageActivity.this);
                    builder.setView(view);
                    builder.setCancelable(true);
                    final AlertDialog dialog = builder.create();
                    dialog.show();

                    TextView tv_delete = view.findViewById(R.id.tv_delete);
                    TextView tv_cancel = view.findViewById(R.id.tv_cancel);

                    tv_delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mileageDbHelper.dltmileage(mileagelist.get(n).getId()) > 0) {
                                mileagelist.remove(n);
                            }
                            if (mileagelist != null && !mileagelist.isEmpty()) {
                                ll_empty.setVisibility(View.GONE);
                                rvmileage.setVisibility(View.VISIBLE);
                            } else {
                                rvmileage.setVisibility(View.GONE);
                                ll_empty.setVisibility(View.VISIBLE);
                            }
                            rvmileage.setLayoutManager(new GridLayoutManager(VehicleMileageActivity.this, 1));
                            rvmileage.setAdapter(vehicleMileageAdapter);
                            dialog.dismiss();
                        }
                    });

                    tv_cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                }
            }
        });
        rvmileage.setLayoutManager(new GridLayoutManager(this, 1));
        rvmileage.setAdapter(vehicleMileageAdapter);
        if (mileagelist != null && !mileagelist.isEmpty()) {
            ll_empty.setVisibility(View.GONE);
            rvmileage.setVisibility(View.VISIBLE);
        } else {
            rvmileage.setVisibility(View.GONE);
            ll_empty.setVisibility(View.VISIBLE);
        }
    }

    private void BindView() {
        iv_addmileage = findViewById(R.id.iv_addmileage);
        ll_empty = findViewById(R.id.ll_emptyLayout);
        rvmileage = findViewById(R.id.recyclerview_mileage);
        iv_back = findViewById(R.id.iv_back);

        iv_addmileage.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleMileageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_addmileage:
                startActivity(new Intent(VehicleMileageActivity.this, VehicleMilageDetailActivity.class));
                break;

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}