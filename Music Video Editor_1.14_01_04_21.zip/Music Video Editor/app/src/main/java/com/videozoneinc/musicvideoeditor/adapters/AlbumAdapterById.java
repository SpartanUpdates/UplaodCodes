package com.videozoneinc.musicvideoeditor.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.videozoneinc.musicvideoeditor.MyApplication;
import com.videozoneinc.musicvideoeditor.R;
import com.videozoneinc.musicvideoeditor.activity.FragmentOne;
import com.videozoneinc.musicvideoeditor.activity.PhotoselectActivity;
import com.videozoneinc.musicvideoeditor.modelclass.ImageData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AlbumAdapterById extends RecyclerView.Adapter<AlbumAdapterById.Holder> {
    private PhotoselectActivity activity;
    private MyApplication application;
    private OnItemClickListner<Object> clickListner;
    private ArrayList<String> folderId;
    RequestManager glide;
    private LayoutInflater inflater;

    public AlbumAdapterById(final Context context) {
        this.glide = Glide.with(context);
        this.application = MyApplication.getInstance();
        this.folderId = new ArrayList<String>(this.application.getAllAlbum().keySet());
        this.activity = (PhotoselectActivity) context;
        Collections.sort(this.folderId, new Comparator<String>() {
            @Override
            public int compare(final String s, final String s2) {
                return s.compareToIgnoreCase(s2);
            }
        });
        this.inflater = LayoutInflater.from(context);
    }

    public String getItem(final int n) {
        return this.folderId.get(n);
    }

    public int getItemCount() {
        return this.folderId.size();
    }

    public void onBindViewHolder(final Holder holder, final int n) {
        final String item = this.getItem(n);
        final ImageData imageData = this.application.getImageByAlbum(item).get(0);
        holder.textView.setSelected(true);
        holder.textView.setText((CharSequence) imageData.folderName);
        this.glide.load(imageData.imagePath).into(holder.imageView);
        if (holder.cbSelect.isChecked()) {
            holder.rlItemParent.setBackgroundColor(this.activity.getResources().getColor(R.color.app_theme_color));
            holder.cbSelect.setVisibility(View.VISIBLE);
        } else {
            holder.rlItemParent.setBackgroundColor(this.activity.getResources().getColor(R.color.transparent));
            holder.cbSelect.setVisibility(View.GONE);
        }
        holder.clickableView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                AlbumAdapterById.this.application.setSelectedFolderId(item);

                PhotoselectActivity.fregmentLayouts.setVisibility(View.VISIBLE);
                FragmentManager manager = activity.getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.setCustomAnimations(R.anim.enter_anim, R.anim.anim_scale_out);
                transaction.replace(R.id.fregmentspace, new FragmentOne());
                transaction.commit();
                if (AlbumAdapterById.this.clickListner != null) {
                    AlbumAdapterById.this.clickListner.onItemClick(view, imageData);
                }
                AlbumAdapterById.this.notifyDataSetChanged();
            }
        });
    }

    public Holder onCreateViewHolder(final ViewGroup viewGroup, final int n) {
        return new Holder(this.inflater.inflate(R.layout.items, viewGroup, false));
    }
    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    public class Holder extends RecyclerView.ViewHolder {
        CheckBox cbSelect;
        private View clickableView;
        ImageView imageView;
        View parent;
        RelativeLayout rlItemParent;
        TextView textView;

        public Holder(final View parent) {
            super(parent);
            this.parent = parent;

            this.cbSelect = (CheckBox) parent.findViewById(R.id.cbSelect);
            this.imageView = (ImageView) parent.findViewById(R.id.imageView1);
            this.textView = (TextView) parent.findViewById(R.id.textView1);
            this.clickableView = parent.findViewById(R.id.clickableView);
            this.rlItemParent = (RelativeLayout) parent.findViewById(R.id.rlItemParent);
        }

        public void onItemClick(final View view, final Object o) {
            if (AlbumAdapterById.this.clickListner != null) {
                AlbumAdapterById.this.clickListner.onItemClick(view, o);
            }
        }
    }
}
