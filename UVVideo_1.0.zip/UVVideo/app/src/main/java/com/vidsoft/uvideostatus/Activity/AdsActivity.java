package com.vidsoft.uvideostatus.Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.vidsoft.uvideostatus.R;

public class AdsActivity extends AppCompatActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_ads);
        findViewById(R.id.skipAd).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AdsActivity.this.onBackPressed();
            }
        });
//        Glide.with((FragmentActivity) this).load(getIntent().getStringExtra("AppBanner")).apply(new RequestOptions().placeholder((int) R.drawable.video_placeholder)).into((ImageView) findViewById(R.id.bannerImg));
//        Glide.with((FragmentActivity) this).load(getIntent().getStringExtra("AppIcon")).into((ImageView) findViewById(R.id.logoImg));
        ((TextView) findViewById(R.id.appTxt)).setText(getIntent().getStringExtra("AppName"));
        ((TextView) findViewById(R.id.desTxt)).setText(getIntent().getStringExtra("AppDes"));
        findViewById(R.id.installBtn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AdsActivity adsActivity = AdsActivity.this;
                StringBuilder sb = new StringBuilder();
                sb.append("https://play.google.com/store/apps/details?id=");
                sb.append(AdsActivity.this.getIntent().getStringExtra("AppPack"));
                adsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(sb.toString())));
            }
        });
    }

    public void onBackPressed() {
        finish();
    }
}
