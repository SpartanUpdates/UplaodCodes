package flash.light.shine.com.config;

public class Config {
    public static final int DEFAULT_COUNT_FOR_INSTANCE = 3;
    public static final int DEFAULT_INTERVAL_FOR_INSTANCE = 30;
    public static final String[] IGNORE_PACKAGE = new String[]{"android", "com.android.systemui", "com.android.settings"};
    public static final int MAX_COUNT_FOR_MSG = 10;
    public static final int[] MISSED_ALERT_INTERVALS = new int[]{1, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60};
    public static final long MISSED_MSEC_MIN = 60000;
    public static final String PREF_NAME = "flash.light.shine.pref";
}
