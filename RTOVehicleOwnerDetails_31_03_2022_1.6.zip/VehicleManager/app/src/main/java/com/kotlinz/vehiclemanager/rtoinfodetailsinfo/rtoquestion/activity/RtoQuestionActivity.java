package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.Room.QuestionModel;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.Room.RtoDatabase;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.ViewDialog;
import java.util.ArrayList;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import ticker.views.com.ticker.widgets.circular.timer.callbacks.CircularViewCallback;
import ticker.views.com.ticker.widgets.circular.timer.view.CircularView;

public class RtoQuestionActivity extends AppCompatActivity implements View.OnClickListener {
    private RtoDatabase rtoDatabase;
    private List<QuestionModel> questionModelList = new ArrayList<>();
    private List<QuestionModel> questionModelListUnique = new ArrayList<>();
    private TextView question;
    private TextView optionA;
    private TextView optionB;
    private TextView optionC;
    private static TextView yourScore;
    private static TextView highScore;
    private static TextView questionCounter;
    private TextView correctAns;
    private TextView wrongAns;
    private TextView question_tv;
    private TextView correctAns_tv;
    private TextView wrongAns_tv;
    private ImageView restart;
    private RelativeLayout optionALayout, optionBLayout, optionCLayout;
    public static int questionCount = 0;
    private static int questionC = 1;
    private static int score = 0;
    private static int hScore = 0;
    private static int correctAnswer = 0;
    private static int wrongAnswer = 0;
    public static CircularView circularView;
    private static CircularView.OptionsBuilder builderWithTimer;
    private static SharedPreferences sharedPreferences;
    private ImageView iv_back, correct_iv1, correct_iv2, correct_iv3;
    public static ProgressBar progressBar;
    private TextView title_tv;
    private LinearLayout ll_score_layout;
    private Boolean darkModeorNot = false;
    public static RtoQuestionActivity activity;


    private NativeAd nativeAd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rto_question);
        activity = RtoQuestionActivity.this;
        LoadNativeAds();
        question = findViewById(R.id.question);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        restart = findViewById(R.id.restart);
        optionALayout = findViewById(R.id.optionALayout);
        optionBLayout = findViewById(R.id.optionBLayout);
        optionCLayout = findViewById(R.id.optionCLayout);
        circularView = findViewById(R.id.circular_view);
        yourScore = findViewById(R.id.yourScore);
        highScore = findViewById(R.id.highScore);
        progressBar = findViewById(R.id.progressBar);
        questionCounter = findViewById(R.id.questionCounter);
        correctAns = findViewById(R.id.correctAns);
        wrongAns = findViewById(R.id.wrongAns);
        iv_back = findViewById(R.id.iv_back);
        correct_iv1 = findViewById(R.id.correct_iv1);
        correct_iv2 = findViewById(R.id.correct_iv2);
        correct_iv3 = findViewById(R.id.correct_iv3);
        title_tv = findViewById(R.id.title_tv);
        ll_score_layout = findViewById(R.id.ll_score_layout);
        question_tv = findViewById(R.id.question_tv);
        correctAns_tv = findViewById(R.id.correctAns_tv);
        wrongAns_tv = findViewById(R.id.wrongAnd_tv);

        rtoDatabase = (RtoDatabase) RtoDatabase.getInstance(RtoQuestionActivity.this);
        sharedPreferences = getSharedPreferences("HighScoreRto", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPreferences.edit();

        ViewDialog viewDialog = new ViewDialog();
        viewDialog.showDialogForExam(RtoQuestionActivity.this);
        DarkTheame darkTheame = new DarkTheame(RtoQuestionActivity.this);
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            darkModeorNot = true;
            setupDarkMode();
        }
        if (darkTheame.modeData().equals("nightMode")) {
            darkModeorNot = true;
            setupDarkMode();
        }

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                restartGame();
                onBackPressed();
                circularView.stopTimer();
            }
        });

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        questionModelList = rtoDatabase.rtoQuestionDao().getQuestionsList();
                    }
                });
            }
        });
        thread.start();

        if (questionModelList.size() != 0) {
            question.setText(questionModelList.get(questionCount).getQuestion());
            optionA.setText("A. " + questionModelList.get(questionCount).getOptionA());
            optionB.setText("B. " + questionModelList.get(questionCount).getOptionB());
            optionC.setText("C. " + questionModelList.get(questionCount).getOptionC());
        } else {
            insertQuestionsData();
        }

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartGame();
            }
        });

        optionALayout.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                circularView.stopTimer();
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                optionALayout.startAnimation(AnimationUtils.loadAnimation(RtoQuestionActivity.this, R.anim.shake));
                                optionALayout.setClickable(false);
                                optionBLayout.setClickable(false);
                                optionCLayout.setClickable(false);
                                if (questionModelList.get(questionCount).getOptionA().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionALayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));
                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.check);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);
                                    score = score + 5;
                                    if (score > hScore) {
                                        editor.putInt("highScore", score);
                                        editor.commit();
                                        highScore.setText(String.valueOf(score));
                                    }
                                    yourScore.setText(String.valueOf(score));
                                    correctAnswer = correctAnswer + 1;
                                    correctAns.setText(String.valueOf(correctAnswer));

                                } else if (questionModelList.get(questionCount).getOptionB().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));

                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.check);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else if (questionModelList.get(questionCount).getOptionC().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);
                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                }
                            }
                        });
                    }
                });
                thread.start();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        newQuestion();
                    }
                }, 2800);

            }
        });
        optionBLayout.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                circularView.stopTimer();
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                optionBLayout.startAnimation(AnimationUtils.loadAnimation(RtoQuestionActivity.this, R.anim.shake));
                                optionALayout.setClickable(false);
                                optionBLayout.setClickable(false);
                                optionCLayout.setClickable(false);
                                if (questionModelList.get(questionCount).getOptionA().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionALayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));
                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.check);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else if (questionModelList.get(questionCount).getOptionB().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));

                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.check);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);

                                    score = score + 5;
                                    if (score > hScore) {
                                        editor.putInt("highScore", score);
                                        editor.commit();
                                        highScore.setText(String.valueOf(score));
                                    }
                                    yourScore.setText(String.valueOf(score));
                                    correctAnswer = correctAnswer + 1;
                                    correctAns.setText(String.valueOf(correctAnswer));
                                } else if (questionModelList.get(questionCount).getOptionC().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);
                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                }
                            }
                        });
                    }
                });
                thread.start();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        newQuestion();
                    }
                }, 2800);

            }
        });
        optionCLayout.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                circularView.stopTimer();
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                optionCLayout.startAnimation(AnimationUtils.loadAnimation(RtoQuestionActivity.this, R.anim.shake));
                                optionALayout.setClickable(false);
                                optionBLayout.setClickable(false);
                                optionCLayout.setClickable(false);
                                if (questionModelList.get(questionCount).getOptionA().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionALayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));
                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.check);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else if (questionModelList.get(questionCount).getOptionB().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));

                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.check);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.uncheck);

                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                } else if (questionModelList.get(questionCount).getOptionC().equals(questionModelList.get(questionCount).getAnswer())) {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);

                                    score = score + 5;
                                    if (score > hScore) {
                                        editor.putInt("highScore", score);
                                        editor.commit();
                                        highScore.setText(String.valueOf(score));
                                    }
                                    yourScore.setText(String.valueOf(score));
                                    correctAnswer = correctAnswer + 1;
                                    correctAns.setText(String.valueOf(correctAnswer));
                                } else {
                                    if (darkModeorNot) {
                                        setDarkLayoutAndText();
                                    } else {
                                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                                    }
                                    optionBLayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionALayout.setBackgroundResource(R.drawable.ic_wrong_ans_layout);
                                    optionCLayout.setBackgroundResource(R.drawable.ic_answer_new_layout);
                                    optionA.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionB.setTextColor(Color.parseColor("#FFFFFF"));
                                    optionC.setTextColor(Color.parseColor("#FFFFFF"));

                                    correct_iv1.setVisibility(View.VISIBLE);
                                    correct_iv1.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv2.setVisibility(View.VISIBLE);
                                    correct_iv2.setBackgroundResource(R.drawable.uncheck);
                                    correct_iv3.setVisibility(View.VISIBLE);
                                    correct_iv3.setBackgroundResource(R.drawable.check);
                                    wrongAnswer = wrongAnswer + 1;
                                    wrongAns.setText(String.valueOf(wrongAnswer));
                                }
                            }
                        });
                    }
                });
                thread.start();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        newQuestion();
                    }
                }, 2800);
            }
        });
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (RtoQuestionActivity.this.nativeAd != null) {
                            RtoQuestionActivity.this.nativeAd.destroy();
                        }
                        RtoQuestionActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public static void resetData() {
        progressBar.setProgress(1);
        questionCount = 0;
        questionC = 1;
        score = 0;
        hScore = 0;
        correctAnswer = 0;
        wrongAnswer = 0;
        questionCounter.setText(String.valueOf(questionC) + "/15");
        yourScore.setText("0");
    }


    public void newQuestion() {
        if (questionC >= 15) {

            if (correctAnswer >= 11) {
                circularView.stopTimer();
                Intent intent = new Intent(RtoQuestionActivity.this, ExamPassActivity.class);
                intent.putExtra("yourScore", String.valueOf(score));
                intent.putExtra("rightAns", String.valueOf(correctAnswer));
                intent.putExtra("wrongAns", String.valueOf(wrongAnswer));
                startActivity(intent);
                resetData();
                finish();
            } else {
                circularView.stopTimer();
                Intent intent = new Intent(RtoQuestionActivity.this, ExamFailActivity.class);
                intent.putExtra("yourScore", String.valueOf(score));
                intent.putExtra("rightAns", String.valueOf(correctAnswer));
                intent.putExtra("wrongAns", String.valueOf(wrongAnswer));
                startActivity(intent);
                resetData();
                finish();
            }

        } else {
            optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
            optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
            optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
            if (darkModeorNot) {
                setDarkLayoutAndText();
            } else {
                optionA.setTextColor(Color.parseColor("#000000"));
                optionB.setTextColor(Color.parseColor("#000000"));
                optionC.setTextColor(Color.parseColor("#000000"));
            }
            correct_iv1.setVisibility(View.GONE);
            correct_iv2.setVisibility(View.GONE);
            correct_iv3.setVisibility(View.GONE);

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            questionC = questionC + 1;
                            questionCounter.setText(questionC + "/15");
                            progressBar.setProgress(questionC);
                            circularView.setOptions(builderWithTimer);
                            circularView.startTimer();
                            optionALayout.setClickable(true);
                            optionBLayout.setClickable(true);
                            optionCLayout.setClickable(true);
                            questionModelList = rtoDatabase.rtoQuestionDao().getQuestionsList();
                            question.setText(questionModelList.get(questionCount).getQuestion());
                            optionA.setText("A. " + questionModelList.get(questionCount).getOptionA());
                            optionB.setText("B. " + questionModelList.get(questionCount).getOptionB());
                            optionC.setText("C. " + questionModelList.get(questionCount).getOptionC());
                        }
                    });
                }
            });
            thread.start();
        }
    }

    public void startGame(Activity activity) {
        builderWithTimer =
                new CircularView.OptionsBuilder()
                        .shouldDisplayText(true)
                        .setCounterInSeconds(45)
                        .setCircularViewCallback(new CircularViewCallback() {
                            @Override
                            public void onTimerFinish() {

                                wrongAnswer = wrongAnswer + 1;
                                wrongAns.setText(String.valueOf(wrongAnswer));
                                newQuestion();
                                /*Toast.makeText(RtoQuestionActivity.this, "Time is up, you can restart the exam", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(RtoQuestionActivity.this,MainActivity.class));
                                finish();*/
                                /*Intent intent=new Intent(activity,ExamFailActivity.class);
                                intent.putExtra("yourScore", String.valueOf(score));
                                intent.putExtra("rightAns",String.valueOf(correctAnswer));
                                intent.putExtra("wrongAns",String.valueOf(wrongAnswer));
                                activity.startActivity(intent);*/
                            }

                            @Override
                            public void onTimerCancelled() {
                            }
                        });
        circularView.setOptions(builderWithTimer);
        circularView.startTimer();
        questionCounter.setText(questionC + "/15");

        hScore = sharedPreferences.getInt("highScore", 0);
        System.out.println(hScore);
        highScore.setText(String.valueOf(hScore));
        yourScore.setText(String.valueOf(score));
    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_score_layout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        question.setTextColor(Color.parseColor("#FFFFFF"));
        optionALayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);
        optionBLayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);
        optionCLayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);
        question_tv.setTextColor(Color.parseColor("#c1c1c1"));
        questionCounter.setTextColor(Color.parseColor("#c1c1c1"));
        wrongAns.setTextColor(Color.parseColor("#FFFFFF"));
        wrongAns_tv.setTextColor(Color.parseColor("#c1c1c1"));
        correctAns.setTextColor(Color.parseColor("#FFFFFF"));
        correctAns_tv.setTextColor(Color.parseColor("#c1c1c1"));
        progressBar.getProgressDrawable().setColorFilter(ContextCompat.getColor(RtoQuestionActivity.this, R.color.color_greylight), PorterDuff.Mode.SRC_IN);
    }

    private void setDarkLayoutAndText() {
        optionA.setTextColor(Color.parseColor("#FFFFFF"));
        optionB.setTextColor(Color.parseColor("#FFFFFF"));
        optionC.setTextColor(Color.parseColor("#FFFFFF"));
        question.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void restartGame() {
        circularView.stopTimer();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (darkModeorNot) {
                            setDarkLayoutAndText();
                        } else {
                            optionA.setTextColor(Color.parseColor("#000000"));
                            optionB.setTextColor(Color.parseColor("#000000"));
                            optionC.setTextColor(Color.parseColor("#000000"));
                        }
                        correct_iv1.setVisibility(View.GONE);
                        correct_iv2.setVisibility(View.GONE);
                        correct_iv3.setVisibility(View.GONE);

                        optionALayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);
                        optionBLayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);
                        optionCLayout.setBackgroundResource(R.drawable.ic_option_box_bg_dark);

                        builderWithTimer =
                                new CircularView.OptionsBuilder()
                                        .shouldDisplayText(true)
                                        .setCounterInSeconds(45)
                                        .setCircularViewCallback(new CircularViewCallback() {
                                            @Override
                                            public void onTimerFinish() {
                                                //restartGame();
                                                wrongAnswer = wrongAnswer + 1;
                                                wrongAns.setText(String.valueOf(wrongAnswer));
                                                newQuestion();
                                                /*Toast.makeText(RtoQuestionActivity.this, "Time is up, you can restart the exam", Toast.LENGTH_LONG).show();
                                                startActivity(new Intent(RtoQuestionActivity.this,MainActivity.class));
                                                finish();*/
                                            }

                                            @Override
                                            public void onTimerCancelled() {
                                            }
                                        });
                        circularView.setOptions(builderWithTimer);
                        circularView.startTimer();
                        questionC = 1;
                        correctAnswer = 0;
                        wrongAnswer = 0;
                        correctAns.setText("");
                        wrongAns.setText("");
                        score = 0;
                        yourScore.setText("0");
                        progressBar.setProgress(1);
                        questionCounter.setText(questionC + "/15");
                        optionALayout.setClickable(true);
                        optionBLayout.setClickable(true);
                        optionCLayout.setClickable(true);

                        questionModelList = rtoDatabase.rtoQuestionDao().getQuestionsList();
                        optionALayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                        optionBLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                        optionCLayout.setBackgroundResource(R.drawable.ic_option_new_layout);
                        question.setText(questionModelList.get(questionCount).getQuestion());
                        optionA.setText("A. " + questionModelList.get(questionCount).getOptionA());
                        optionB.setText("B. " + questionModelList.get(questionCount).getOptionB());
                        optionC.setText("C. " + questionModelList.get(questionCount).getOptionC());
                    }
                });
            }
        });
        thread.start();
    }

    private void insertQuestionsData() {

        QuestionModel questionModel = new QuestionModel("If you are near a pedestrian crossing and there are people waiting to cross the road, you should", "Slow down, press horn and proceed", "Press horn and proceed", "Stop the vehicle, wait until pedestrians cross and then move forward", "Stop the vehicle, wait until pedestrians cross and then move forward");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel);

        QuestionModel questionModel1 = new QuestionModel("You are coming towards a narrow bridge and another vehicle is about to enter the bridge from the other side. What should you do?", "Wait until the other vehicle crosses the bridge before proceeding", "Switch on headlight and the cross the bridge", "Increase speed of the vehicle and try to cross the bridge quickly", "Wait until the other vehicle crosses the bridge before proceeding");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel1);

        QuestionModel questionModel2 = new QuestionModel("On a road that has been designated as one way", "You should not drive in reverse gear", "You should not overtake", "You should not park", "You should not drive in reverse gear");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel2);

        QuestionModel questionModel3 = new QuestionModel("You can overtake a vehicle that is in the front", "Through the left side of the vehicle ahead", "Through the right side of the vehicle ahead", "If the road is wide enough", "Through the right side of the vehicle ahead");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel3);

        QuestionModel questionModel4 = new QuestionModel("If a vehicle approaches a railway crossing that is not guarded and the vehicle wants to proceed, the driver should", "Wait until the train passes", "Press horn and cross the track at the earliest", "Stop the vehicle on left hand side of the road, approach the track and ensure that there is no train or trolley coming from any side prior to crossing", "Stop the vehicle on left hand side of the road, approach the track and ensure that there is no train or trolley coming from any side prior to crossing");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel4);

        QuestionModel questionModel5 = new QuestionModel("Transport vehicles can be distinguished by", "The colour of the vehicle", "Number plate of the vehicle", "Tyre size of the vehicle", "Number plate of the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel5);

        QuestionModel questionModel6 = new QuestionModel("A learner’s license is valid for a period of", "30 days", "6 months", "Until a driving licence is availed", "6 months");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel6);

        QuestionModel questionModel7 = new QuestionModel("In case a road does not have a footpath, pedestrians will have to", "Walk on the right side of the road", "Walk on the left side of the road", "Walk on any side of the road", "Walk on the right side of the road");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel7);

        QuestionModel questionModel8 = new QuestionModel("Free passage should be provided to the following vehicles", "Express buses", "Police vehicles", "Fire service vehicles and ambulance", "Fire service vehicles and ambulance");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel8);

        QuestionModel questionModel9 = new QuestionModel("Vehicles that come from the opposite side should be allowed to proceed through the", "Left side", "Right side", "Any convenient side", "Right side");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel9);

        QuestionModel questionModel10 = new QuestionModel("Driver of a vehicle can overtake when", "The driver of the vehicle ahead gives the signal to overtake", "Road is wide enough", "Driving down a hill", "The driver of the vehicle ahead gives the signal to overtake");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel10);

        QuestionModel questionModel11 = new QuestionModel("Driver of a vehicle shall drive through the", "Left side of the road", "Right side of the road", "Center of the road", "Left side of the road");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel11);

        QuestionModel questionModel12 = new QuestionModel("If a vehicle is parked on the side of a road at night", "The vehicle should be locked", "Park light should remain on", "All of the above", "All of the above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel12);

        QuestionModel questionModel13 = new QuestionModel("Fog lamps should be used when", "There is mist", "At night", "When the vehicle opposite is not using the dim light", "There is mist");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel13);

        QuestionModel questionModel14 = new QuestionModel("Zebra lines are meant for", "Crossing of pedestrians", "Stopping vehicles", "Overtaking", "Crossing of pedestrians");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel14);

        QuestionModel questionModel15 = new QuestionModel("If an ambulance is approaching", "No preference should be given", "Provide passage if there are no vehicles on the other side", "Allow free passage by moving to the side of the road", "Allow free passage by moving to the side of the road");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel15);

        QuestionModel questionModel16 = new QuestionModel("Red traffic light is an sign to", "Slow the vehicle", "Stop the vehicle", "Proceed with caution", "Stop the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel16);

        QuestionModel questionModel17 = new QuestionModel("Parking in front of a hospital is", "Not correct", "Correct", "Depends on the situation", "Not correct");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel17);

        QuestionModel questionModel18 = new QuestionModel("If a driver sees the sign for ‘slippery road ahead’, he/she must", "Drive faster", "Change gear and reduce speed", "Apply brake but proceed in the same speed", "Change gear and reduce speed");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel18);

        QuestionModel questionModel19 = new QuestionModel("Overtaking is prohibited when", "Roads are slippery", "Poses danger to oncoming traffic", "All of the above", "All of the above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel19);

        QuestionModel questionModel20 = new QuestionModel("Overtaking when the vehicle approaches a bend is", "Not allowed", "Allowed", "Allowed with caution", "Not allowed");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel20);

        QuestionModel questionModel21 = new QuestionModel("Drunken driving is", "Allowed at night", "Allowed during the day", "Prohibited at all times", "Prohibited at all times");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel21);

        QuestionModel questionModel22 = new QuestionModel("Honking is prohibited near", "Places of religious worship such as Temple, Mosque and Churches", "Hospitals, Court of Law", "Near Police Stations", "Hospitals, Court of Law");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel22);

        QuestionModel questionModel23 = new QuestionModel("Rear view mirror is utilized for", "Watching traffic that is approaching from behind", "Watching back seat passengers", "Car decor", "Watching traffic that is approaching from behind");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel23);

        QuestionModel questionModel24 = new QuestionModel("Boarding in and alighting from vehicles when it is in motion is", "Allowed in autos", "Allowed in buses", "Prohibited in all vehicles", "Prohibited in all vehicles");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel24);

        QuestionModel questionModel25 = new QuestionModel("Mobile phones should not be used", "At home", "In office", "While driving a vehicle", "While driving a vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel25);

        QuestionModel questionModel26 = new QuestionModel("Overtaking is not allowed when", "When the road is wide enough", "When the road ahead is not visible clearly", "The road has no potholes", "When the road ahead is not visible clearly");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel26);

        QuestionModel questionModel27 = new QuestionModel("Pedestrians are not allowed to cross the road close to stopped vehicles or near sharp bends because", "It is an inconvenience to oncoming vehicles", "It is inconvenient to other pedestrians", "Drivers of approaching vehicles may not be able to see them", "Drivers of approaching vehicles may not be able to see them");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel27);

        QuestionModel questionModel28 = new QuestionModel("Records needed for private vehicles are", "G.C.R, Insurance Certificate, Registration Certificate", "Insurance Certificate, Registration Certificate, Driving License and Tax Token", "Permit, Trip Sheet, Registration Certificate", "Insurance Certificate, Registration Certificate, Driving License and Tax Token");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel28);

        QuestionModel questionModel29 = new QuestionModel("Validity of Pollution Under Control Certificate is", "1 year", "6 months", "2 years", "6 months");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel29);

        QuestionModel questionModel30 = new QuestionModel("Minimum age for availing a license to drive a motor vehicle without gear is", "16 years", "21 years", "18 years", "16 years");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel30);

        QuestionModel questionModel31 = new QuestionModel("When you see the sign for ‘School nearby’, you should", "Slow down and go ahead with caution", "Press horn and proceed in the same speed", "Stop the vehicle", "Slow down and go ahead with caution");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel31);

        QuestionModel questionModel32 = new QuestionModel("If a driver of a two wheeler is turning to the left, he/she should", "Extend the right hand and give the left turn signal", "Not give any signal", "Extend the left hand and give the left turn signal", "Extend the right hand and give the left turn signal");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel32);


        QuestionModel questionModel33 = new QuestionModel("One time tax for a new car is", "5 years", "15 years", "Until registration is cancelled", "15 years");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel33);

        QuestionModel questionModel34 = new QuestionModel("Prior to overtaking a vehicle, driver should ensure that", "The road ahead is visible clearly and is safe to overtake", "There are no vehicles ahead", "The road is not safe", "The road ahead is visible clearly and is safe to overtake");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel34);

        QuestionModel questionModel35 = new QuestionModel("Parking is prohibited on", "A foot path", "On a one-way road", "On a main road", "A foot path");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel35);

        QuestionModel questionModel36 = new QuestionModel("Hand brake should be used to", "Park a vehicle", "Apply brake suddenly", "Reduce speed", "Park a vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel36);

        QuestionModel questionModel37 = new QuestionModel("Using unregistered vehicles in public spaces is", "Illegal", "Legal", "Legal if necessary", "Illegal");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel37);

        QuestionModel questionModel38 = new QuestionModel("Minimum age to avail driving license for transport vehicles is", "16 years", "20 years", "45 years", "20 years");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel38);

        QuestionModel questionModel39 = new QuestionModel("A circular blue sign with a red border and two red diagonal lines crossing it means what ?", "Give way", "No Overtaking", "No Stopping", "No Stopping");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel39);

        QuestionModel questionModel40 = new QuestionModel("When you change houses, you must inform your nearest RTO about the change in your address within:", "90 days", "30 days", "1 year", "30 days");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel40);

        QuestionModel questionModel41 = new QuestionModel("n a one-way road, you should not:", "Over-speed", "Park on the way", "Drive in the reverse gear", "Drive in the reverse gear");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel41);

        QuestionModel questionModel42 = new QuestionModel("How do you know that a vehicle is a transport vehicle?", "By the make of the vehicle", "By the driver’s license", "By seeing the number plate of the vehicle", "By seeing the number plate of the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel42);

        QuestionModel questionModel43 = new QuestionModel("Overtaking is allowed only:", "From the right side", "From the left side", "After honking 3 times", "From the right side");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel43);

        QuestionModel questionModel44 = new QuestionModel("While travelling uphill, which vehicle has the right-of-way over others?", "Largest vehicle", "Any vehicle travelling uphill", "The vehicle which came first", "Any vehicle travelling uphill");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel44);

        QuestionModel questionModel45 = new QuestionModel("The driver of any vehicle is allowed to overtake", "When the driver in front gives the right indication to overtake", "When there is a broad road", "Driving on a hilly road", "When the driver in front gives the right indication to overtake");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel45);

        QuestionModel questionModel46 = new QuestionModel("Red signal in traffic implies:", "Please slow down your vehicle", "Please stop your vehicle", "Move with caution", "Please stop your vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel46);

        QuestionModel questionModel47 = new QuestionModel("Overtaking will be forbidden in case", "Roads look greasy", "Dangerous to approaching traffic", "All mentioned as above", "All mentioned as above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel47);

        QuestionModel questionModel48 = new QuestionModel("When your car is halted on one side of the road at night, then", "The vehicle must be under lock and key", "Parking signal must be used", "All as mentioned above", "All as mentioned above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel48);

        QuestionModel questionModel49 = new QuestionModel("The driver of a vehicle must drive on the", "Road’s Left side", "Road’s right side", "in the middle", "Road’s Left side");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel49);

        QuestionModel questionModel50 = new QuestionModel("A road not having a footpath, walkers must", "Walk on road’s right side", "Walk on the road’s middle side", "Walk as per your wish", "Walk on road’s right side");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel50);

        QuestionModel questionModel51 = new QuestionModel("Vehicles used for transport can be differentiated through", "Vehicle’s colour", "Vehicle’ number plate", "Vehicle’s tyre size", "Vehicle’ number plate");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel51);

        QuestionModel questionModel52 = new QuestionModel("Pollution Under Control Certificate or PUC is valid for", "One year", "180 days", "24 months", "180 days");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel52);

        QuestionModel questionModel53 = new QuestionModel("The minimum eligibility for getting a driving license for driving a vehicle lacking gear is", "16 years of age", "15 years", "25 years", "16 years of age");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel53);

        QuestionModel questionModel54 = new QuestionModel("Rearmost mirror is used for the purpose of", "Observing traffic that is coming from behind", "Viewing passengers who are seated at the back", "Decorations of the vehicle", "Observing traffic that is coming from behind");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel54);

        QuestionModel questionModel55 = new QuestionModel("You must use lamps used for fog when:", "You can see fog", "During night", "When you notice that the opposite side vehicle’s dim light is not on", "You can see fog");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel55);

        QuestionModel questionModel56 = new QuestionModel("If your driver sees the sign for ‘greasy road in front, the driver must", "You will drive faster", "Change your gear and lessen your vehicle’s speed", "Put brake but move in the similar swiftness", "Change your gear and lessen your vehicle’s speed");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel56);

        QuestionModel questionModel57 = new QuestionModel("The tax for a new car is to be paid once in", "10 years", "15 years", "Till the cancellation of the vehicle’s", "15 years");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel57);

        QuestionModel questionModel58 = new QuestionModel("Overhauling is not permissible if:", "The road is broad", "The road in front is not noticeable evidently", "The road does not have holes", "The road in front is not noticeable evidently");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel58);

        QuestionModel questionModel59 = new QuestionModel("The Parking hand-brake must be in use to", "Stop and park your vehicle", "Fast apply of the brake", "Reduce the speediness", "Stop and park your vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel59);

        QuestionModel questionModel60 = new QuestionModel("What is the minimum age for driving a motorcycle without gear?", "16 years", "18 years", "21 years", "16 years");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel60);

        QuestionModel questionModel61 = new QuestionModel("What should you do when you see a traffic sign of a school nearby?", "Stop the vehicle", "Slow down and proceed carefully ", "Press horn and proceed in the same speed", "Slow down and proceed carefully ");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel61);

        QuestionModel questionModel62 = new QuestionModel(" Before you overtake a vehicle what should you keep in mind?", "The road ahead should be clearly visible and overtaking should be safe", "The road is not safe", "There are no vehicles ahead", "The road ahead should be clearly visible and overtaking should be safe");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel62);

        QuestionModel questionModel63 = new QuestionModel(" If a driver sees the sign for ‘slippery road ahead’, he/she must", "Drive faster", "Change gear and reduce speed", "Apply brake but proceed in the same speed", "Change gear and reduce speed");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel63);

        QuestionModel questionModel64 = new QuestionModel("Overspeeding is", "Not an offence and can be neglected", "Is an offence but no charges are pressed against you", "an offence that could lead to your driving licence being cancelled or suspended", "an offence that could lead to your driving licence being cancelled or suspended");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel64);

        QuestionModel questionModel65 = new QuestionModel("The only vehicle which is allowed to drive at a speed of 60km/ hour is", "Motor car", "Heavy bus/trucks", "All of the above", "Motor car");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel65);

        QuestionModel questionModel66 = new QuestionModel("f you see a yellow light at the traffic signal, you should", "Reduce your vehicle speed and proceed with caution", "Slow the vehicle", "Stop the vehicle", "Reduce your vehicle speed and proceed with caution");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel66);

        QuestionModel questionModel67 = new QuestionModel("Be careful while overtaking vehicles marked with ‘L’( learner driver) because", "You might crash into them", "You might crash into people on the road", "The learner driver might get nervous and make a mistake", "The learner driver might get nervous and make a mistake");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel67);

        QuestionModel questionModel68 = new QuestionModel("If a vehicle is parked on the side of a road at night", "The vehicle should be locked", "Park light should remain on", "All of the above", "All of the above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel68);

        QuestionModel questionModel69 = new QuestionModel("You should never try to overtake a cyclist when", "Driving on a narrow road and just before you are about to turn left", "On a crowded street", "All of the above", "Driving on a narrow road and just before you are about to turn left");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel69);

        QuestionModel questionModel70 = new QuestionModel(" When near a pedestrian crossing, as the pedestrians are waiting to cross the road, what should you do?", "Sound horn and proceed", "Slow down, sound horn and pass", "Stop the vehicle and wait till the pedestrians cross the road and then proceed", "Stop the vehicle and wait till the pedestrians cross the road and then proceed");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel70);

        QuestionModel questionModel71 = new QuestionModel(" A person driving a vehicle in a public place without a licence, is liable for:", "Penalty only", "Penalty only", "A warning", "Penalty for the driver and the owner and/ or seizure of vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel71);

        QuestionModel questionModel72 = new QuestionModel("While parking your vehicle on a downward gradient, in addition to the application of hand brake, the gear engaged should be:", "In neutral", "In first", "In reverse", "In reverse");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel72);

        QuestionModel questionModel73 = new QuestionModel(" When a vehicle is involved in an accident causing injury to any person, what should you do?", "Take the vehicle to the nearest police station and report the accident", "Stop the vehicle and report to the police station", "Take all reasonable steps to secure medical attention to the injured and report to the nearest police station within 24 hours", "Take all reasonable steps to secure medical attention to the injured and report to the nearest police station within 24 hours");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel73);

        QuestionModel questionModel74 = new QuestionModel("On a road designated as one way, which of the following holds true?", "Parking is prohibited", "Overtaking is prohibited", "Should not drive in reverse gear", "Should not drive in reverse gear");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel74);

        QuestionModel questionModel75 = new QuestionModel("When a blind person is crossing the road holding a white cane, the driver should:", "Consider the white cane as a traffic sign to stop the vehicle", "Blow the horn and proceed", "Slow down and proceed with caution", "Consider the white cane as a traffic sign to stop the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel75);

        QuestionModel questionModel76 = new QuestionModel("What happens if you are carrying overload in goods carriages?", "It is not a punishable offence", "Only attracts a fine", "Driving licence can be suspended or cancelled", "Driving licence can be suspended or cancelled");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel76);

        QuestionModel questionModel77 = new QuestionModel("When you reach an intersection where there is no signal light or a traffic police man, you should:", "Give way to traffic approaching the intersection from other roads", "Give proper signal, sound the horn and then proceed", "Give way to the traffic approaching the intersection on your right side and proceed after giving necessary signals", "Give way to the traffic approaching the intersection on your right side and proceed after giving necessary signals");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel77);

        QuestionModel questionModel78 = new QuestionModel("When is overtaking is prohibited?", "When the road is marked with a broken center line in the colour white", "When the vehicle is being driven on a steep hill", "When the road is marked with a continuous center line in the colour yellow", "When the vehicle is being driven on a steep hill");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel78);

        QuestionModel questionModel79 = new QuestionModel("If the road is marked with broken white lines, you:", "shall not change track", "can change track, if required", "shall stop the vehicle", "can change track, if required");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel79);

        QuestionModel questionModel80 = new QuestionModel("What is the meaning of a blinking red traffic light?", "Stop the vehicle till green light glows", "Stop the vehicle and proceed if safe", "Reduce speed and proceed", "Stop the vehicle and proceed if safe");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel80);

        QuestionModel questionModel81 = new QuestionModel(" Maximum permitted speed of a motor car on national highway is:", "60 km/hr", "70 km/hr", "80 km/hr", "70 km/h");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel81);

        QuestionModel questionModel82 = new QuestionModel(" Where is the number of passengers permitted to be taken in a private vehicle recorded?", "Registration Certificate", "Tax Token", "Permit", "Registration Certificate");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel82);

        QuestionModel questionModel83 = new QuestionModel("Before starting the engine of a vehicle, you should:", "Check radiator water level and engine oil level", "Check headlight", "Check the brakes", "Check radiator water level and engine oil level");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel83);

        QuestionModel questionModel84 = new QuestionModel(" The maximum permissible speed of a light motor vehicle is:", "60 km/hr", "70 km/hr", "No limit", "60 km/hr");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel84);

        QuestionModel questionModel85 = new QuestionModel("According to Section 113 of the Motor Vehicle Act 1988, a driver should not drive a vehicle:", "After consuming alcohol", "Exceeding the speed limit", "Exceeding the weight permitted to carry", "Exceeding the weight permitted to carry");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel85);

        QuestionModel questionModel86 = new QuestionModel("You are behind a bus that has stopped to pick up or drop off passengers. What should you do?", "Patiently wait behind", "Overtake from the left", "Overtake from the right", "Patiently wait behind");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel86);

        QuestionModel questionModel87 = new QuestionModel("The middle lane is for:", "Overtaking", "Traffic driving at 40km/hr", "Two wheelers", "Traffic driving at 40km/hr");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel87);

        QuestionModel questionModel88 = new QuestionModel("A flashing yellow signal is used when:", "Traffic lights are not working", "You should slow down and proceed with caution", "There is construction going on nearby", "You should slow down and proceed with caution");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel88);

        QuestionModel questionModel89 = new QuestionModel("Where, out of the following, are you allowed to park?", "A footpath", "On top of a hill", "Neither of the options above", "Neither of the options above");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel89);

        QuestionModel questionModel90 = new QuestionModel("A high beam in foggy conditions:", "Is good because you can see more clearly", "Is bad because it reflects back and can dazzle", "Makes sure that others can see you", "Is bad because it reflects back and can dazzle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel90);

        QuestionModel questionModel91 = new QuestionModel("When should you switch on your hazard warning lights?", "When you are moving straight", "When your vehicle is parked and the same is causing inconvenience to other road users", "When your vehicle parked in a no parking area", "When your vehicle is parked and the same is causing inconvenience to other road users");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel91);

        QuestionModel questionModel92 = new QuestionModel(" You can overtake a vehicle in the front:", "From the right side of the vehicle", "From the left side of the vehicle", "From the left side of the vehicle, if the road is wide", "From the right side of the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel92);

        QuestionModel questionModel93 = new QuestionModel("How can you distinguish a transport vehicle?", "By looking at the tyre size", "By the colour of the vehicle", "By looking at the number plate of the vehicle", "By looking at the number plate of the vehicle");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel93);

        QuestionModel questionModel94 = new QuestionModel(" What is the validity of the learner’s licence?", "3 months", "6 months", "9 months", "6 months");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel94);

        QuestionModel questionModel95 = new QuestionModel("Free passage should be given to which of the following types of vehicles?", "Police vehicles", "Emergency vehicles (Ambulances and fire service vehicles)", "Buses", "Emergency vehicles (Ambulances and fire service vehicles)");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel95);

        QuestionModel questionModel96 = new QuestionModel("Driver of a motor vehicle shall drive through:", "The right side of the road", "The left side of the road", "The centre of the road", "The left side of the road");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel96);

        QuestionModel questionModel97 = new QuestionModel("When are fog lamps used?", "During the night", "During the night", "When the opposite vehicle is not using dim lights", "When there is mist");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel97);

        QuestionModel questionModel98 = new QuestionModel("A red traffic light indicates?", "Stop", "Slow down", "Go", "Stop");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel98);

        QuestionModel questionModel99 = new QuestionModel("Can you park your vehicle in front of the entrance to a hospital?", "Yes", "No", "Yes, but only if a NO PARKING sign is not there", "No");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel99);

        QuestionModel questionModel100 = new QuestionModel("Where the slippery road sign is seen on the road, the driver shall:", "Apply the brake", "Proceed at the same speed", "Reduce speed by changing gears", "Reduce speed by changing gears");
        rtoDatabase.rtoQuestionDao().insertQuestion(questionModel100);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        questionModelList = rtoDatabase.rtoQuestionDao().getQuestionsList();
                        question.setText(questionModelList.get(questionCount).getQuestion());
                        optionA.setText("A. " + questionModelList.get(questionCount).getOptionA());
                        optionB.setText("B. " + questionModelList.get(questionCount).getOptionB());
                        optionC.setText("C. " + questionModelList.get(questionCount).getOptionC());
                    }
                });
            }
        });
        thread.start();


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }


    @Override
    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            circularView.stopTimer();
            resetData();
            startActivity(new Intent(RtoQuestionActivity.this, MainActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 36;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                circularView.stopTimer();
                resetData();
                startActivity(new Intent(RtoQuestionActivity.this, MainActivity.class));
                finish();
            }
        }
    }
}