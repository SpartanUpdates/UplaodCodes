package com.kotlinz.videoCollage.interfaces;

public interface DrawColorAdapterCallBackInterface {
    void itemClick(int i);
}
