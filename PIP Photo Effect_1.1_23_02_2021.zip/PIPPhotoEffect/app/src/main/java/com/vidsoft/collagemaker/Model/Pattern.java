package com.vidsoft.collagemaker.Model;

public class Pattern
{
  int image;
  String title;

  public Pattern(String paramString, int paramInt)
  {
    this.title = paramString;
    this.image = paramInt;
  }

  public int getImage()
  {
    return this.image;
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setImage(int paramInt)
  {
    this.image = paramInt;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
}
