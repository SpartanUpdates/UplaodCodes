package com.kotlinz.vehiclemanager.model;

import com.google.gson.annotations.SerializedName;

public class Item
{
    @SerializedName("attrName")
    public String attrName;
    @SerializedName("attrValue")
    public String attrValue;

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrValue() {
        return attrValue;
    }

    public void setAttrValue(String attrValue) {
        this.attrValue = attrValue;
    }
}
