package com.vidsoft.videostatusmaker.Utils.async;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.File;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.vidsoft.videostatusmaker.Activity.ActivityPreview;
import com.vidsoft.videostatusmaker.Activity.ActivityViewAlImages;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

public class VideoCreate extends AsyncTask<Void, Void, Boolean> {
    String folderPath;
    String string;
    Context context;
    String strOutputPath;


    public VideoCreate(final Context context, final String string) {
        this.context = context;
        this.string = string;
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_name));
        this.folderPath = sb.toString();
    }


    protected Boolean doInBackground(Void... voidArr) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.folderPath);
        stringBuilder.append("/Video");
        File absoluteFile = new File(stringBuilder.toString()).getAbsoluteFile();
        if (!absoluteFile.exists()) {
            absoluteFile.mkdir();
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(absoluteFile);
        stringBuilder.append(File.separator);
        stringBuilder.append("temp.mp4");
        this.strOutputPath = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.folderPath);
        stringBuilder2.append("/");
        stringBuilder2.append(this.context.getString(R.string.temp_folder));
        stringBuilder2.append("/temp/anim%d.jpg");
        String stringBuilder3 = stringBuilder2.toString();
        String[] strArr = new String[]{"-y", "-r", this.string, "-i", stringBuilder3, "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-preset", "ultrafast", this.strOutputPath};
        execFFmpegBinary(strArr);
        return Boolean.TRUE;
    }

    protected void onPostExecute(final Boolean b) {
        super.onPostExecute(b);
    }

    protected void onPreExecute() {
        super.onPreExecute();
    }


    public void execFFmpegBinary(final String[] command) {
        try {
            ActivityViewAlImages.ffmpeg.execute(command, new ExecuteBinaryResponseHandler() {

                @Override
                public void onFailure(String s) {
                    Log.e("TAG", "onFailure video ffmpeg" + s);
                }

                @Override
                public void onSuccess(String s) {
                    Log.e("TAG", "onSuccess video ffmpeg");
                }

                @Override
                public void onProgress(String progress) {
                    Log.e("TAG", "Started command :video  ffmpeg " + progress);
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFinish() {
                    Log.e("TAG", "Finished command :video ffmpeg ");
                    ((ActivityPreview) context).addMusic(strOutputPath);
                }
            });
        } catch (FFmpegCommandAlreadyRunningException e) {
            e.printStackTrace();
        }
    }
}
