package com.esc.howtomakeschoolsupplies.activity;


import com.esc.howtomakeschoolsupplies.data.LikesContract;

public class ContentFragmentOnCreateViewLiked implements Runnable {
    final ContentFragmentOnCreateView2 this$0;

    ContentFragmentOnCreateViewLiked(ContentFragmentOnCreateView2 contentFragment$onCreateView$3) {
        this.this$0 = contentFragment$onCreateView$3;
    }

    public final void run() {
        this.this$0.this$0.insertLine(LikesContract.DBEntry.TABLE_NAME_FAVORITES, this.this$0.$numberArticle);
    }
}
