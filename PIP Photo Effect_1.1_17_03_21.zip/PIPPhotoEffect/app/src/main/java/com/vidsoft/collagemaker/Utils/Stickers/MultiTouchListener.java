package com.vidsoft.collagemaker.Utils.Stickers;

import android.graphics.PointF;
import android.view.MotionEvent;
import android.view.View;

public class MultiTouchListener implements View.OnTouchListener {
	private static final int INVALID_POINTER_ID = -1;
	public boolean isRotateEnabled;
	public boolean isScaleEnabled;
	public boolean isTranslateEnabled;
	private int mActivePointerId;
	private float mPrevX;
	private float mPrevY;
	private ScaleGestureDetector mScaleGestureDetector;
	public float maximumScale;
	public float minimumScale;

	public MultiTouchListener() {
		super();
		this.isRotateEnabled = true;
		this.isTranslateEnabled = true;
		this.isScaleEnabled = true;
		this.minimumScale = 0.5f;
		this.maximumScale = 10.0f;
		this.mActivePointerId = -1;
		this.mScaleGestureDetector = new ScaleGestureDetector(
				(ScaleGestureDetector.OnScaleGestureListener) new ScaleGestureListener());
	}

	private static float adjustAngle(final float n) {
		float n2;
		if (n > 180.0f) {
			n2 = n - 360.0f;
		} else {
			n2 = n;
			if (n < -180.0f) {
				return n + 360.0f;
			}
		}
		return n2;
	}

	private static void adjustTranslation(final View view, final float n,
			final float n2) {
		final float[] array = { n, n2 };
		view.getMatrix().mapVectors(array);
		view.setTranslationX(view.getTranslationX() + array[0]);
		view.setTranslationY(view.getTranslationY() + array[1]);
	}

	private static void computeRenderOffset(final View view, float pivotX,
			float pivotY) {
		if (view.getPivotX() == pivotX && view.getPivotY() == pivotY) {
			return;
		}
		final float[] array2;
		final float[] array = array2 = new float[2];
		array2[1] = (array2[0] = 0.0f);
		view.getMatrix().mapPoints(array);
		view.setPivotX(pivotX);
		view.setPivotY(pivotY);
		final float[] array4;
		final float[] array3 = array4 = new float[2];
		array4[1] = (array4[0] = 0.0f);
		view.getMatrix().mapPoints(array3);
		pivotX = array3[0];
		pivotY = array[0];
		final float n = array3[1];
		final float n2 = array[1];
		view.setTranslationX(view.getTranslationX() - (pivotX - pivotY));
		view.setTranslationY(view.getTranslationY() - (n - n2));
	}

	private static void move(final View view, final TransformInfo transformInfo) {
		computeRenderOffset(view, transformInfo.pivotX, transformInfo.pivotY);
		adjustTranslation(view, transformInfo.deltaX, transformInfo.deltaY);
		final float max = Math.max(
				transformInfo.minimumScale,
				Math.min(transformInfo.maximumScale, view.getScaleX()
						* transformInfo.deltaScale));
		view.setScaleX(max);
		view.setScaleY(max);
		view.setRotation(adjustAngle(view.getRotation()
				+ transformInfo.deltaAngle));
	}

	public boolean onTouch(final View view, final MotionEvent motionEvent) {
		boolean b = false;
		this.mScaleGestureDetector.onTouchEvent(view, motionEvent);
		if (this.isTranslateEnabled) {
			final int action = motionEvent.getAction();
			switch (motionEvent.getActionMasked() & action) {
			default: {
				return true;
			}
			case 0: {
				this.mPrevX = motionEvent.getX();
				this.mPrevY = motionEvent.getY();
				this.mActivePointerId = motionEvent.getPointerId(0);
				return true;
			}
			case 2: {
				final int pointerIndex = motionEvent
						.findPointerIndex(this.mActivePointerId);
				if (pointerIndex == -1) {
					break;
				}
				final float x = motionEvent.getX(pointerIndex);
				final float y = motionEvent.getY(pointerIndex);
				if (!this.mScaleGestureDetector.isInProgress()) {
					adjustTranslation(view, x - this.mPrevX, y - this.mPrevY);
					return true;
				}
				break;
			}
			case 3: {
				this.mActivePointerId = -1;
				return true;
			}
			case 1: {
				this.mActivePointerId = -1;
				return true;
			}
			case 6: {
				final int n = (0xFF00 & action) >> 8;
				if (motionEvent.getPointerId(n) == this.mActivePointerId) {
					if (n == 0) {
						b = true;
					}
					this.mPrevX = motionEvent.getX((int) (b ? 1 : 0));
					this.mPrevY = motionEvent.getY((int) (b ? 1 : 0));
					this.mActivePointerId = motionEvent
							.getPointerId((int) (b ? 1 : 0));
					return true;
				}
				break;
			}
			}
		}
		return true;
	}

	private class ScaleGestureListener extends
			ScaleGestureDetector.SimpleOnScaleGestureListener {
		private float mPivotX;
		private float mPivotY;
		private Vector2D mPrevSpanVector;

		private ScaleGestureListener() {
			super();
			this.mPrevSpanVector = new Vector2D();
		}

		@Override
		public boolean onScale(final View view,
				final ScaleGestureDetector scaleGestureDetector) {
			final float n = 0.0f;
			final TransformInfo transformInfo = new TransformInfo();
			float scaleFactor;
			if (MultiTouchListener.this.isScaleEnabled) {
				scaleFactor = scaleGestureDetector.getScaleFactor();
			} else {
				scaleFactor = 1.0f;
			}
			transformInfo.deltaScale = scaleFactor;
			float angle;
			if (MultiTouchListener.this.isRotateEnabled) {
				angle = Vector2D.getAngle(this.mPrevSpanVector,
						scaleGestureDetector.getCurrentSpanVector());
			} else {
				angle = 0.0f;
			}
			transformInfo.deltaAngle = angle;
			float deltaX;
			if (MultiTouchListener.this.isTranslateEnabled) {
				deltaX = scaleGestureDetector.getFocusX() - this.mPivotX;
			} else {
				deltaX = 0.0f;
			}
			transformInfo.deltaX = deltaX;
			float deltaY = n;
			if (MultiTouchListener.this.isTranslateEnabled) {
				deltaY = scaleGestureDetector.getFocusY() - this.mPivotY;
			}
			transformInfo.deltaY = deltaY;
			transformInfo.pivotX = this.mPivotX;
			transformInfo.pivotY = this.mPivotY;
			transformInfo.minimumScale = MultiTouchListener.this.minimumScale;
			transformInfo.maximumScale = MultiTouchListener.this.maximumScale;
			move(view, transformInfo);
			return false;
		}

		@Override
		public boolean onScaleBegin(final View view,
				final ScaleGestureDetector scaleGestureDetector) {
			this.mPivotX = scaleGestureDetector.getFocusX();
			this.mPivotY = scaleGestureDetector.getFocusY();
			this.mPrevSpanVector.set((PointF) scaleGestureDetector
					.getCurrentSpanVector());
			return true;
		}
	}

	private class TransformInfo {
		public float deltaAngle;
		public float deltaScale;
		public float deltaX;
		public float deltaY;
		public float maximumScale;
		public float minimumScale;
		public float pivotX;
		public float pivotY;
	}
}
