package com.esc.phoneheart.advancedclean;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Process;

import com.esc.phoneheart.activity.FinalScreen;

public class SystemUtils {
    public static final String TAG = "SystemUtils";

    public static void backToHome(Context context) {
        try {
            Intent intent = new Intent(context, FinalScreen.class);
            intent.setFlags(268435456);
            context.startActivity(intent);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public static MemoryInfo getMemoryInfo(Context context) {
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        MemoryInfo memoryInfo = new MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return memoryInfo;
    }

    public static void killProcess(Context context) {
        System.exit(0);
        Process.killProcess(Process.myPid());
        context.startActivity(new Intent(context, FinalScreen.class));
    }
}
