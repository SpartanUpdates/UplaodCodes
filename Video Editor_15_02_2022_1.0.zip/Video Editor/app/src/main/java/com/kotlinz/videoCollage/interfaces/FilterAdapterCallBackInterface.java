package com.kotlinz.videoCollage.interfaces;

public interface FilterAdapterCallBackInterface {
    void itemClick(int i);
}
