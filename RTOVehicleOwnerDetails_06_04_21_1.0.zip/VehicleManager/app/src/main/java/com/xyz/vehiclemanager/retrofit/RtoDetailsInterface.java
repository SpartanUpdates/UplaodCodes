package com.xyz.vehiclemanager.retrofit;

import com.xyz.vehiclemanager.bike.model.BikeBrandCategory;
import com.xyz.vehiclemanager.bike.model.BikeDetailsRoot;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeVariantRoot;
import com.xyz.vehiclemanager.bikedetails.bikeaccesories.model.BikeAccessories;
import com.xyz.vehiclemanager.bikedetails.bikedealer.model.BikeDealer;
import com.xyz.vehiclemanager.bikedetails.bikeservice.model.BikeService;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarVariantRoot;
import com.xyz.vehiclemanager.car.model.CarBrandCategory;
import com.xyz.vehiclemanager.car.model.CarDetailsRoot;
import com.xyz.vehiclemanager.cardetails.caraccessories.model.CarAccessories;
import com.xyz.vehiclemanager.cardetails.cardealer.model.CarDealers;
import com.xyz.vehiclemanager.cardetails.carservice.model.CarServiceRoot;
import com.xyz.vehiclemanager.fuel.model.FuelCityRoot;
import com.xyz.vehiclemanager.model.StateListRoot;
import com.xyz.vehiclemanager.model.BikeBrands;
import com.xyz.vehiclemanager.model.CarBrands;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model.RtoOfficeRoot;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.model.RtoQuestion;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtotrafficsignals.model.TrafficSignal;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.model.OwnerRoot;
import com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.model.VehicleLicenseRoot;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface RtoDetailsInterface
{
    @GET("fuelCities")
    Call<StateListRoot> getCityList();

    @GET
    Call<FuelCityRoot> getCityPrice(@Url String url);

    @POST("searchVehicleDetails")
    Call<OwnerRoot> getOwnerDetail(@Query("registrationNo") String VehicleNo);

    @POST("searchLicenseDetails")
    Call<VehicleLicenseRoot> getLicenseDetail(@Query("licenseNo") String licenseNo, @Query("dob") String dob);

    @GET("bike_brands")
    Call<BikeBrands> getBikeBrands();

    @GET("bike_models")
    Call<BikeBrandCategory> getBikeCategory(@Query("brandId") String brandId);

    @GET("bike_model")
    Call<BikeDetailsRoot> getbikevariantdata(@Query("modelId") String modelId);

    @GET("bike_variant")
    Call<BikeVariantRoot> getBikeVariantDetails(@Query("variantId") String varientId);

    @GET("bike_accessories")
    Call<BikeAccessories> getBikeDetailAccessories(@Query("brandId") String brandId);

    @GET("bike_dealers")
    Call<BikeDealer> getBikeDealerDetails(@Query("brandId") String brandId, @Query("cityId") String cityId);

    @GET("bike_service_centers")
    Call<BikeService> getBikeServiceDetails(@Query("brandId") String brandId, @Query("cityId") String cityId);

    @GET("car_brands")
    Call<CarBrands> getCarBrands();

    @GET("car_models")
    Call<CarBrandCategory> getCatCategory(@Query("brandId") String brandId);

    @GET("car_model")
    Call<CarDetailsRoot> getCarVariantsData(@Query("modelId") String modelId);

    @GET("car_variant")
    Call<CarVariantRoot> getCarVariantsDetail(@Query("variantId") String variantId);

    @GET("car_service_centers")
    Call<CarServiceRoot> getCarServiceDetails(@Query("brandId") String brandId, @Query("cityId") String cityId);

    @GET("car_accessories")
    Call<CarAccessories> getCarDetailAccessories(@Query("brandId") String brandId);

    @GET("car_dealers")
    Call<CarDealers> getCarDelersDetail(@Query("brandId") String brandId, @Query("cityId") String cityId);

    @GET("rtoQuestions")
    Call<RtoQuestion> getRtoQuestion(@Query("lang") String language);

    @GET("trafficSignals")
    Call<TrafficSignal> getTrafficSignalData(@Query("lang") String language);

    @GET("rtoInformation")
    Call<RtoOfficeRoot> getRtoOffice();
}
