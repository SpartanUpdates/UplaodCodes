package com.kotlinz.videoCollage.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import com.kotlinz.videoeditor.R;


public class FixedAspectRatioFrameLayout extends FrameLayout {
    private int mAspectRatioHeight;
    private int mAspectRatioWidth;

    public FixedAspectRatioFrameLayout(Context context) {
        super(context);
    }

    public FixedAspectRatioFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet);
    }

    public FixedAspectRatioFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.FixedAspectRatioFrameLayout);
        this.mAspectRatioWidth = obtainStyledAttributes.getInt(1, 4);
        this.mAspectRatioHeight = obtainStyledAttributes.getInt(0, 3);
        obtainStyledAttributes.recycle();
    }


    public void onMeasure(int i, int i2) {
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        int i3 = this.mAspectRatioHeight;
        int i4 = this.mAspectRatioWidth;
        int i5 = (size * i3) / i4;
        if (i5 > size2) {
            size = (i4 * size2) / i3;
        } else {
            size2 = i5;
        }
        if (size % 2 != 0) {
            size++;
        }
        if (size2 % 2 != 0) {
            size2++;
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    public void setRatioWidthAndHeight(int i, int i2) {
        this.mAspectRatioWidth = i;
        this.mAspectRatioHeight = i2;
        invalidate();
    }
}
