package com.esc.beautymackupselficlam.Activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.utils.Utils;
import com.bumptech.glide.Glide;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class shareActivity extends Activity implements View.OnClickListener {
    private ImageView finalimg;
    private ImageView home;
    private ImageView imageview_back;
    private ImageView imageview_Share;
    private ImageView imageview_facebook;
    private ImageView imageview_instagram;
    private ImageView imageview_whatsapp;
    Uri uri;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        bindview();
        loadAd();
    }

    private void bindview() {
        this.imageview_back = (ImageView) findViewById(R.id.imgview_back);
        this.imageview_back.setOnClickListener(this);
        if (Build.VERSION.SDK_INT >= 21) {
            this.finalimg = (ImageView) findViewById(R.id.finalimg);
            findViewById(R.id.simpleFrame).setVisibility(View.GONE);
            findViewById(R.id.roundFrame).setVisibility(View.VISIBLE);
        } else {
            this.finalimg = (ImageView) findViewById(R.id.img);
            findViewById(R.id.roundFrame).setVisibility(View.GONE);
            findViewById(R.id.simpleFrame).setVisibility(View.VISIBLE);
        }
        i = getIntent().getIntExtra("key", 1);
        if (i == 1) {
            uri = CollagePhotoEdiotrActivity.contentUri;
        } else if (i == 2) {
            uri = PixelEffectEditorActivity.contentUri;
        } else if (i == 3) {
            uri = WaterEffectEditorActivity.contentUri;
        } else if (i == 4) {
            uri = PIPPhotoEditor.contentUri;
        } else if (i == 5) {
            uri = PipPhotoMagazineEditor.contentUri;
        } else if (i == 6) {
            uri = PipPhotoPakistanEditor.contentUri;
        } else if (i == 7) {
            uri = PipphotoIndiaEditor.contentUri;
        }
        Glide.with((Activity) this).load(uri)
                .into(this.finalimg);
        BindView();
    }

    private void BindView() {
        this.home = (ImageView) findViewById(R.id.home);
        this.home.setOnClickListener(this);
        this.imageview_whatsapp = (ImageView) findViewById(R.id.imgview_whatsapp);
        this.imageview_whatsapp.setOnClickListener(this);
        this.imageview_instagram = (ImageView) findViewById(R.id.imgview_instagram);
        this.imageview_instagram.setOnClickListener(this);
        this.imageview_facebook = (ImageView) findViewById(R.id.imgview_facebook);
        this.imageview_facebook.setOnClickListener(this);
        this.imageview_Share = (ImageView) findViewById(R.id.imgview_Share);
        this.imageview_Share.setOnClickListener(this);
    }


    public void onClick(View view) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        shareIntent.putExtra("android.intent.extra.TEXT", R.string.app_name
                + " Created By : " + Utils.Glob.app_link);
        shareIntent.putExtra("android.intent.extra.STREAM",
                uri);
        switch (view.getId()) {
            case R.id.home:
                id = R.id.home;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("ToHome", true);
                    startActivity(intent);
                    finish();
                }
                return;
            case R.id.imgview_back:
                id = R.id.imgview_back;
                if (interstitial != null && interstitial.isLoaded()) {
                   DialogShow();
                   AdsDialogShow();
                } else {
                    Intent intent1 = new Intent(this, MyCreationActivity.class);
                    intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent1.putExtra("ToHome", true);
                    startActivity(intent1);
                }
                return;
            case R.id.imgview_whatsapp:
                try {
                    shareIntent.setPackage("com.whatsapp");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e) {
                    Toast.makeText(this, "WhatsApp doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.imgview_facebook:
                try {
                    shareIntent.setPackage("com.facebook.katana");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e2) {
                    Toast.makeText(this, "Facebook doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.imgview_instagram:
                try {
                    shareIntent.setPackage("com.instagram.android");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e3) {
                    Toast.makeText(this, "Instagram doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.imgview_Share:
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("image/*");
                sharingIntent.putExtra("android.intent.extra.TEXT", R.string.app_name
                        + " Create By : " + getPackageName());
                sharingIntent.putExtra("android.intent.extra.STREAM", uri);
                startActivity(Intent.createChooser(sharingIntent,
                        "Share Image using"));
                return;
            default:
                return;
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent1 = new Intent(this, MyCreationActivity.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent1.putExtra("ToHome", true);
        startActivity(intent1);
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitial;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(shareActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.home:
                        Intent intent = new Intent(shareActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("ToHome", true);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.imgview_back:
                        Intent intent1 = new Intent(shareActivity.this, MyCreationActivity.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent1.putExtra("ToHome", true);
                        startActivity(intent1);
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(shareActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}