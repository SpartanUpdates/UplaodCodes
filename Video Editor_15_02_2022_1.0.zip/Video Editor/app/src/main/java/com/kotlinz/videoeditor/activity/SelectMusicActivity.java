package com.kotlinz.videoeditor.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Audio.Media;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoeditor.Adapter.MusicAdapter;
import com.kotlinz.videoeditor.Interface.ItemClickListener;
import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

@SuppressLint({"WrongConstant"})
public class SelectMusicActivity extends AppCompatActivity implements ItemClickListener {
    private static final String[] i;
    private static final String[] j;
    MusicAdapter musicAdapter1;
    String[] c;
    RecyclerView recyclerView;
    ImageView e, img_done;
    private boolean k;
    public Cursor cursor;
    private ArrayList<File> MyfileList;
    private final ArrayList<FileModel> myfileModelArrayList = new ArrayList<>();


    static {
        StringBuilder sb = new StringBuilder();
        sb.append("\"");
        sb.append(Media.EXTERNAL_CONTENT_URI);
        sb.append("\"");
        i = new String[]{"_id", "_data", "title", "artist", "album", "duration", "_size", "is_ringtone", "is_alarm", "is_notification", "is_music", sb.toString()};
        StringBuilder sb2 = new StringBuilder();
        sb2.append("\"");
        sb2.append(Media.INTERNAL_CONTENT_URI);
        sb2.append("\"");
        j = new String[]{"_id", "_data", "title", "artist", "album", "duration", "_size", "is_ringtone", "is_alarm", "is_notification", "is_music", sb2.toString()};
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.k = false;

        String externalStorageState = Environment.getExternalStorageState();
        if (externalStorageState.equals("mounted_ro")) {
            try {
                a(getResources().getText(R.string.sdcard_readonly));
            } catch (NotFoundException e2) {
                e2.printStackTrace();
            }
        } else if (externalStorageState.equals("shared")) {
            try {
                a(getResources().getText(R.string.sdcard_shared));
            } catch (NotFoundException e3) {
                e3.printStackTrace();
            }
        } else if (externalStorageState.equals("mounted")) {
            try {
                setContentView(R.layout.selectmusic);
                recyclerView = findViewById(R.id.recyclerview1);
                MyfileList = new ArrayList<>();
                fetchFiles();

                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                recyclerView.setLayoutManager(layoutManager);
                musicAdapter1 = new MusicAdapter(getApplicationContext(), this.myfileModelArrayList);
                recyclerView.setAdapter(musicAdapter1);

                musicAdapter1.setClickListener(this);

                e = (ImageView) findViewById(R.id.imageViewBack);
                e.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finish();
                    }
                });
                img_done = findViewById(R.id.img_done);

                img_done.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SelectMusicActivity.this.finish();
                    }
                });

            } catch (OutOfMemoryError e4) {
                e4.printStackTrace();
            } catch (ArrayIndexOutOfBoundsException e5) {
                e5.printStackTrace();
            } catch (ActivityNotFoundException e6) {
                e6.printStackTrace();
            } catch (NotFoundException e7) {
                e7.printStackTrace();
            } catch (NullPointerException e8) {
                e8.printStackTrace();
            } catch (StackOverflowError e9) {
                e9.printStackTrace();
            }
        } else {
            a(getResources().getText(R.string.no_sdcard));
        }
        PutAnalyticsEvent();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectMusicActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public boolean isOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting();
    }

    @Override
    public void onActivityResult(int i2, int i3, Intent intent) {
        super.onActivityResult(i2, i3, intent);
        if (i2 == 1) {
            if (i3 != -1) {
                try {
                    setResult(0);
                    finish();
                } catch (Exception e2) {
                    try {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                        return;
                    }
                }
            }
            setResult(-1, intent);
            finish();
        }
    }

    private void a(CharSequence charSequence) {
        new AlertDialog.Builder(this).setTitle(getResources().getText(R.string.alert_title_failure)).setMessage(charSequence).setPositiveButton(R.string.alert_ok_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                SelectMusicActivity.this.finish();
            }
        }).setCancelable(false).show();
    }

    private Cursor a(String str, String[] strArr) {
        return managedQuery(Media.INTERNAL_CONTENT_URI, j, str, strArr, "title_key");
    }

    private Cursor b(String str, String[] strArr) {
        return managedQuery(Media.EXTERNAL_CONTENT_URI, i, str, strArr, "title_key");
    }


    private void fetchFiles() {
        this.MyfileList = getfile(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()));
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.MyfileList.size(); i++) {
            String substring = this.MyfileList.get(i).getName().substring(0, this.MyfileList.get(i).getName().lastIndexOf("."));
            new Date(this.MyfileList.get(i).lastModified());
            arrayList.add(new FileModel(substring, this.MyfileList.get(i).getAbsolutePath(), false));
        }
        this.myfileModelArrayList.clear();
        this.myfileModelArrayList.addAll(arrayList);
        this.MyfileList.clear();
    }

    private ArrayList<File> getfile(File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null && listFiles.length > 0) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    getfile(file2);
                } else if (file2.getName().endsWith(".mp3") || file2.getName().endsWith(".m4a") || file2.getName().endsWith(".acc")) {
                    this.MyfileList.add(file2);
                }
            }
        }
        return this.MyfileList;
    }


    @Override
    public void onBackPressed() {
        setResult(0);
        getWindow().clearFlags(128);
        finish();
    }


    @Override
    public void onDestroy() {
        getWindow().clearFlags(128);
        super.onDestroy();
    }


    @Override
    public void onClick(View view, int position) {

    }
}
