package com.MV.Lyrics;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.NativeAds.NativeAdvanceAds;
import com.MV.Lyrics.Partical.Adapter.ParticalAdapter;
import com.MV.Lyrics.Partical.Model.ParticalModel;
import com.MV.Lyrics.Preferance.AppPreference;
import com.MV.Lyrics.bottomSheet.BottomSheetFragment;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.root.UnitySendValue.AndroidUnityCall;
import com.root.UnitySendValue.AppGeneral;
import com.unity3d.player.*;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UnityPlayerActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    Activity activity = UnityPlayerActivity.this;
    public static UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code
    @SuppressLint("StaticFieldLeak")
    public static UnityPlayerActivity unityPlayeractivity;

    public AlertDialog alertDialog;

    LinearLayout llBottomViewLyrics;
    LinearLayout layoutLyricsGallery, layoutLyricsSetting, layoutLyricsRatio, layoutLyricsStyle, layoutLyricsSong/*, layoutLyricsTag*/;
    TextView tvGalllary, tvSetting, tvScreenRatio, tvLyricsStyle, tvLyricsSong/*, tvTag*/;
    LinearLayout layoutStyleBar, layoutRatioBar, layoutSettingBar;
    LinearLayout layoutRemoveBg;
    SeekBar sbOpacity, sbGracyScale;
    LinearLayout layoutInsta, layoutStatus, layoutYoutube;
    @SuppressLint("StaticFieldLeak")
    public static FrameLayout layoutAdView;

    RelativeLayout layoutToolbar;
    ImageView ivBack;
    TextView tvExportVideo;

    //Style
    public ArrayList<ParticalModel> particalModels;
    public RecyclerView rvPartical;
    public ParticalAdapter particalAdapter;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        unityPlayeractivity = this;
        mUnityPlayer = new UnityPlayer(this);
        setContentView(R.layout.unity_ui);
        ((FrameLayout) findViewById(R.id.layout_unity_main)).addView(mUnityPlayer, 0);
        mUnityPlayer.requestFocus();
        if (Build.VERSION.SDK_INT < 23) {
            UnityPlayer.UnitySendMessage("AppManager", "IsCallHomeActivity", "ok");
            Utils.CreateDirectory();
            AppGeneral.loadFFMpeg(activity);
        } else {
            RequestPermission(false, true);
        }
        PutAnalyticsEvent();
        BindView();
        BannerAds();
        SetDefaultRatio();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "UnityPlayerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        layoutToolbar = findViewById(R.id.rl_toolbar);
        ivBack = findViewById(R.id.ivBack);
        tvExportVideo = findViewById(R.id.tv_export_video);
        tvExportVideo.setOnClickListener(this);

        llBottomViewLyrics = findViewById(R.id.llBottomView_lyrics);


        layoutLyricsGallery = findViewById(R.id.llLyricsGallery);
        layoutLyricsSetting = findViewById(R.id.llLyricsSetting);
        layoutLyricsRatio = findViewById(R.id.llLyricsRatio);
        layoutLyricsStyle = findViewById(R.id.llLyricsStyle);
        layoutLyricsSong = findViewById(R.id.llLyricsSong);
//        layoutLyricsTag = findViewById(R.id.llLyricsTag);

        tvGalllary = findViewById(R.id.tv_gallary);
        tvSetting = findViewById(R.id.tv_setting);
        tvScreenRatio = findViewById(R.id.tv_ScreenRatio);
        tvLyricsStyle = findViewById(R.id.tvstyle);
        tvLyricsSong = findViewById(R.id.tvLyricsSong);
//        tvTag = findViewById(R.id.tv_tag);
        layoutAdView = findViewById(R.id.llBanner_unity);

        layoutLyricsGallery.setOnClickListener(this);
        layoutLyricsSetting.setOnClickListener(this);
        layoutLyricsRatio.setOnClickListener(this);
        layoutLyricsStyle.setOnClickListener(this);
        layoutLyricsSong.setOnClickListener(this);
//        layoutLyricsTag.setOnClickListener(this);

        layoutStyleBar = findViewById(R.id.llStylebar);
        layoutRatioBar = findViewById(R.id.llRatiobar);
        layoutSettingBar = findViewById(R.id.llSettingbar);


        layoutRemoveBg = findViewById(R.id.ll_remove_bg);
        sbOpacity = findViewById(R.id.sbopacity);
        sbGracyScale = findViewById(R.id.sbgrayscale);

        ivBack.setOnClickListener(this);

        layoutRemoveBg.setOnClickListener(this);


        layoutInsta = findViewById(R.id.llInsta);
        layoutStatus = findViewById(R.id.llStatus);
        layoutYoutube = findViewById(R.id.llYoutube);

        layoutInsta.setOnClickListener(this);
        layoutStatus.setOnClickListener(this);
        layoutYoutube.setOnClickListener(this);

        rvPartical = findViewById(R.id.rvParticalStyle);
        SetParticalAdapter();
        sbOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                UnityPlayer.UnitySendMessage("AppManager", "ApplyOpacity", String.valueOf(seekBar.getProgress()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sbGracyScale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                UnityPlayer.UnitySendMessage("AppManager", "ApplyGrayScale", String.valueOf(seekBar.getProgress()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetParticalAdapter() {
        particalModels = new ArrayList<>();
        rvPartical.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        particalAdapter = new ParticalAdapter(activity);
        rvPartical.setAdapter(particalAdapter);
    }

    public void SetDefaultRatio() {
        AppPreference.b(this).f("pref_key_crop_ratio", "1:1");
        findViewById(R.id.llInsta).setSelected(true);
        findViewById(R.id.llStatus).setSelected(false);
        findViewById(R.id.llYoutube).setSelected(false);
    }

    private void RequestPermission(boolean z, boolean isFromFirst) {
        if ((ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            if (isFromFirst) {
                UnityPlayer.UnitySendMessage("AppManager", "IsCallHomeActivity", "ok");
                Utils.CreateDirectory();
                AppGeneral.loadFFMpeg(activity);
            }
        } else if (z) {
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
            alertDialogBuilder.setTitle("Necessary permission");
            alertDialogBuilder.setMessage("Allow Required Permission");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Settings",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            PremissionFromSetting();
                        }
                    });

            alertDialogBuilder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                UnityPlayer.UnitySendMessage("AppManager", "IsCallHomeActivity", "ok");
                Utils.CreateDirectory();
                AppGeneral.loadFFMpeg(activity);
            } else {
                RequestPermission(true, true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    UnityPlayer.UnitySendMessage("AppManager", "IsCallHomeActivity", "ok");
                    Utils.CreateDirectory();
                    AppGeneral.loadFFMpeg(activity);
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    RequestPermission(true, true);
                }
            }
        }
    }

    public void PremissionFromSetting() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }

    public void ShowBottomViewLyrics() {
        if (llBottomViewLyrics != null) {
            llBottomViewLyrics.setVisibility(View.VISIBLE);
        }
        if (layoutToolbar != null) {
            layoutToolbar.setVisibility(View.VISIBLE);
        }
    }

    public void HidebottomViewLyrics() {
        if (llBottomViewLyrics != null) {
            llBottomViewLyrics.setVisibility(View.GONE);
        }
        if (layoutToolbar != null) {
            layoutToolbar.setVisibility(View.GONE);
        }
    }

    public void ShowLyricsStyle() {
        tvLyricsStyle.setSelected(true);
        tvSetting.setSelected(false);
        tvScreenRatio.setSelected(false);

        layoutStyleBar.setVisibility(View.VISIBLE);
        layoutRatioBar.setVisibility(View.GONE);
        layoutSettingBar.setVisibility(View.GONE);
    }

    public void HideLyricsStyle() {
        layoutStyleBar.setVisibility(View.GONE);
        layoutStyleBar.setSelected(false);
    }


    @Override
    protected void onDestroy() {
        mUnityPlayer.destroy();
        super.onDestroy();
    }


    @Override
    protected void onPause() {
        super.onPause();
        mUnityPlayer.pause();
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < 23) {
            Utils.CreateDirectory();
            AppGeneral.loadFFMpeg(activity);
        } else {
            RequestPermission(false, false);
        }
        mUnityPlayer.resume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mUnityPlayer.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mUnityPlayer.stop();
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mUnityPlayer.lowMemory();
    }


    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level == TRIM_MEMORY_RUNNING_CRITICAL) {
            mUnityPlayer.lowMemory();
        }
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mUnityPlayer.configurationChanged(newConfig);
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mUnityPlayer.windowFocusChanged(hasFocus);
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayer.injectEvent(event);
        return super.dispatchKeyEvent(event);
    }


    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }


    public boolean onGenericMotionEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                AndroidUnityCall.PreviewBack(activity);
                break;
            case R.id.tv_export_video:
                String VideoQuality;
                if (LanguagePref.a(this).a("pref_last_load_time_ads", "1").equals("1")) {
                    SaveDilaog();
                } else {
                    VideoQuality = LanguagePref.a(this).a("pref_key_export_quality", "Medium");
                    AndroidUnityCall.HideBannerAds(activity);
                    HidebottomViewLyrics();
                    HideLyricsStyle();
                    SetDefaultRatio();
                    if (VideoQuality.equals("Medium")) {
                        UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "0");
                        return;
                    } else if (VideoQuality.equals("High")) {
                        UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "1");
                        return;
                    } else {
                        UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "0");
                        return;
                    }
                }
                break;
            case R.id.llLyricsGallery:
                UnityPlayer.UnitySendMessage("AppManager", "OpenWaitPanel", "");
                AppPreference appPreference;
                String ScreenRatio;
                if (layoutInsta.isSelected()) {
                    appPreference = AppPreference.b(activity);
                    ScreenRatio = "1:1";
                } else if (layoutYoutube.isSelected()) {
                    appPreference = AppPreference.b(activity);
                    ScreenRatio = "16:9";
                } else {
                    appPreference = AppPreference.b(activity);
                    ScreenRatio = "9:16";
                }
                appPreference.f("pref_key_crop_ratio", ScreenRatio);
                MyApplication.getInstance().getSelectedImages().clear();
                AndroidUnityCall.ShowGallaryActivity(activity);
                break;
            case R.id.llLyricsSetting:
                if (MyApplication.getInstance().isSettingEnable) {
                    tvScreenRatio.setSelected(false);
                    tvLyricsStyle.setSelected(false);
                    tvSetting.setSelected(true);
                    layoutStyleBar.setVisibility(View.GONE);
                    layoutRatioBar.setVisibility(View.GONE);
                    layoutSettingBar.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(activity, "Please Select Background First", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.llLyricsRatio:
                tvScreenRatio.setSelected(true);
                tvLyricsStyle.setSelected(false);
                tvSetting.setSelected(false);
                layoutStyleBar.setVisibility(View.GONE);
                layoutRatioBar.setVisibility(View.VISIBLE);
                layoutSettingBar.setVisibility(View.GONE);
                break;
            case R.id.llLyricsStyle:
                ShowLyricsStyle();
                break;
            case R.id.llLyricsSong:
                AndroidUnityCall.ShowLyrics(activity);
                break;
          /*  case R.id.llLyricsTag:
                ShowTagDialog();
                break;*/
            case R.id.ll_remove_bg:
                RemoveBackground();
                break;
            case R.id.llInsta:
                if (!layoutInsta.isSelected()) {
                    layoutInsta.setSelected(true);
                    layoutYoutube.setSelected(false);
                    layoutStatus.setSelected(false);
                }
                UnityPlayer.UnitySendMessage("AppManager", "ChangeScreenSize", "0");
                break;
            case R.id.llStatus:
                if (!layoutStatus.isSelected()) {
                    layoutInsta.setSelected(false);
                    layoutYoutube.setSelected(false);
                    layoutStatus.setSelected(true);
                }
                UnityPlayer.UnitySendMessage("AppManager", "ChangeScreenSize", "1");
                break;
            case R.id.llYoutube:
                if (!layoutYoutube.isSelected()) {
                    layoutInsta.setSelected(false);
                    layoutYoutube.setSelected(true);
                    layoutStatus.setSelected(false);
                }
                UnityPlayer.UnitySendMessage("AppManager", "ChangeScreenSize", "2");
                break;
        }
    }


    public void ShowLyriscSetting() {
        tvScreenRatio.setSelected(false);
        tvLyricsStyle.setSelected(false);
        tvSetting.setSelected(true);
        layoutLyricsStyle.setVisibility(View.VISIBLE);
        layoutStyleBar.setVisibility(View.GONE);
        layoutRatioBar.setVisibility(View.GONE);
        layoutSettingBar.setVisibility(View.VISIBLE);

    }

    private void RemoveBackground() {
        MyApplication.getInstance().isSettingEnable = false;
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImages().clear();
        layoutStyleBar.setVisibility(View.VISIBLE);
        layoutRatioBar.setVisibility(View.GONE);
        layoutSettingBar.setVisibility(View.GONE);

        tvScreenRatio.setSelected(false);
        tvLyricsStyle.setSelected(true);
        tvSetting.setSelected(false);
        sbOpacity.setProgress(0);
        sbGracyScale.setProgress(0);
        UnityPlayer.UnitySendMessage("AppManager", "RemoveBG", "");
    }

    public void ClearSetting() {
        sbOpacity.setProgress(0);
        sbGracyScale.setProgress(0);
    }


    /*private void ShowTagDialog() {
        final AlertDialog alertDialog = new AlertDialog.Builder(activity, R.style.TagDialog).create();
        View inflate = getLayoutInflater().inflate(R.layout.layout_tag_dialog, null);
        final EditText etTag = inflate.findViewById(R.id.et_tag);
        Button btnDone = inflate.findViewById(R.id.btnDone);
        Button btnClear = inflate.findViewById(R.id.btnClear);
        etTag.requestFocus();
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(2, 1);
        etTag.setText(TagValue);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etTag.getText().clear();
            }
        });
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TagValue = etTag.getText().toString();
                UnityPlayer.UnitySendMessage("AppManager", "ChangeTagLine", TagValue);
                ((InputMethodManager) UnityPlayerActivity.this.getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(etTag.getWindowToken(), 0);
                alertDialog.dismiss();
            }
        });
        etTag.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        alertDialog.setView(inflate);
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }
*/
    private void SaveDilaog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.SaveDialog);
        final View inflate = LayoutInflater.from(this).inflate(R.layout.export_dialog, null);
        builder.setView(inflate);
        final AlertDialog dialog = builder.create();
        AdLoader.Builder Adbuilder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        Adbuilder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                FrameLayout frameLayout = inflate.findViewById(R.id.native_adview);
                inflate.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        Adbuilder.withNativeAdOptions(adOptions);
        AdLoader adLoader = Adbuilder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        inflate.findViewById(R.id.btnHd).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "0");
                AndroidUnityCall.HideBannerAds(activity);
                HidebottomViewLyrics();
                HideLyricsStyle();
                SetDefaultRatio();
                LanguagePref.a(UnityPlayerActivity.this).b("pref_key_export_quality", "Medium");
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btnFullHd).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "1");
                AndroidUnityCall.HideBannerAds(activity);
                HidebottomViewLyrics();
                HideLyricsStyle();
                SetDefaultRatio();
                LanguagePref.a(UnityPlayerActivity.this).b("pref_key_export_quality", "High");
                dialog.dismiss();
            }
        });

        ((CheckBox) inflate.findViewById(R.id.cbDoNotAsk)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                LanguagePref languagePref;
                String str;
                String str2;
                if (z) {
                    languagePref = LanguagePref.a(UnityPlayerActivity.this);
                    str = "pref_last_load_time_ads";
                    str2 = "0";
                } else {
                    languagePref = LanguagePref.a(UnityPlayerActivity.this);
                    str = "pref_last_load_time_ads";
                    str2 = "1";
                }
                languagePref.b(str, str2);
            }
        });
        dialog.show();
    }

    public void GoToHome() {
        BottomSheetFragment bottomSheetDialog = BottomSheetFragment.newInstance();
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.show(getSupportFragmentManager(), "Preview");
    }
}
