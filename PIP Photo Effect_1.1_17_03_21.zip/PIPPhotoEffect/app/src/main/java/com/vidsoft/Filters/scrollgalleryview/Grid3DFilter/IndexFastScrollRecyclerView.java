package com.vidsoft.Filters.scrollgalleryview.Grid3DFilter;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Typeface;
import androidx.recyclerview.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;

import com.vidsoft.collagemaker.pipphotoeffect.R;

public class IndexFastScrollRecyclerView extends RecyclerView {
    public static int mIndexBarCornerRadius;
    public static float mIndexBarTransparentValue;
    public static String mIndexbarBackgroudColor;
    public static float mIndexbarMargin;
    public static String mIndexbarTextColor;
    public static float mIndexbarWidth;
    public static int mPreviewPadding;
    public static int setIndexTextSize;
    private GestureDetector mGestureDetector;
    private IndexFastScrollRecyclerSection mScroller;

    static {
        setIndexTextSize = 12;
        mIndexbarWidth = 20.0f;
        mIndexbarMargin = 5.0f;
        mPreviewPadding = 5;
        mIndexBarCornerRadius = 5;
        mIndexBarTransparentValue = 0.6f;
        mIndexbarBackgroudColor = "#000000";
        mIndexbarTextColor = "#FFFFFF";
    }

    public IndexFastScrollRecyclerView(Context context) {
        super(context);
        this.mScroller = null;
        this.mGestureDetector = null;
    }

    public IndexFastScrollRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mScroller = null;
        this.mGestureDetector = null;
        init(context, attrs);
    }

    public IndexFastScrollRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mScroller = null;
        this.mGestureDetector = null;
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        this.mScroller = new IndexFastScrollRecyclerSection(context, this);
        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.IndexFastScrollRecyclerView, 0, 0);
            if (typedArray != null) {
                try {
                    setIndexTextSize = typedArray.getInt(R.styleable.IndexFastScrollRecyclerView_setIndexTextSize, setIndexTextSize);
                    mIndexbarWidth = typedArray.getFloat(R.styleable.IndexFastScrollRecyclerView_setIndexbarWidth, mIndexbarWidth);
                    mIndexbarMargin = typedArray.getFloat(R.styleable.IndexFastScrollRecyclerView_setIndexbarMargin, mIndexbarMargin);
                    mPreviewPadding = typedArray.getInt(R.styleable.IndexFastScrollRecyclerView_setPreviewPadding, mPreviewPadding);
                    mIndexBarCornerRadius = typedArray.getInt(R.styleable.IndexFastScrollRecyclerView_setIndexBarCornerRadius, mIndexBarCornerRadius);
                    mIndexBarTransparentValue = typedArray.getFloat(R.styleable.IndexFastScrollRecyclerView_setIndexBarTransparentValue, mIndexBarTransparentValue);
                    if (typedArray.getString(R.styleable.IndexFastScrollRecyclerView_setIndexBarColor) != null) {
                        mIndexbarBackgroudColor = typedArray.getString(R.styleable.IndexFastScrollRecyclerView_setIndexBarColor);
                    }
                    if (typedArray.getString(R.styleable.IndexFastScrollRecyclerView_setIndexBarTextColor) != null) {
                        mIndexbarTextColor = typedArray.getString(R.styleable.IndexFastScrollRecyclerView_setIndexBarTextColor);
                    }
                    typedArray.recycle();
                } catch (Throwable th) {
                    typedArray.recycle();
                }
            }
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.mScroller != null) {
            this.mScroller.draw(canvas);
        }
    }

    public boolean onTouchEvent(MotionEvent ev) {
        if (this.mScroller != null && this.mScroller.onTouchEvent(ev)) {
            return true;
        }
        if (this.mGestureDetector == null) {
            this.mGestureDetector = new GestureDetector(getContext(), new SimpleOnGestureListener() {
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    return super.onFling(e1, e2, velocityX, velocityY);
                }
            });
        }
        this.mGestureDetector.onTouchEvent(ev);
        return super.onTouchEvent(ev);
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (this.mScroller.contains(ev.getX(), ev.getY())) {
            return true;
        }
        return super.onInterceptTouchEvent(ev);
    }

    public void setAdapter(Adapter adapter) {
        super.setAdapter(adapter);
        if (this.mScroller != null) {
            this.mScroller.setAdapter(adapter);
        }
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (this.mScroller != null) {
            this.mScroller.onSizeChanged(w, h, oldw, oldh);
        }
    }

    public void setIndexTextSize(int value) {
        this.mScroller.setIndexTextSize(value);
    }

    public void setIndexbarWidth(float value) {
        this.mScroller.setIndexbarWidth(value);
    }

    public void setIndexbarMargin(float value) {
        this.mScroller.setIndexbarMargin(value);
    }

    public void setPreviewPadding(int value) {
        this.mScroller.setPreviewPadding(value);
    }

    public void setIndexBarCornerRadius(int value) {
        this.mScroller.setIndexBarCornerRadius(value);
    }

    public void setIndexBarTransparentValue(float value) {
        this.mScroller.setIndexBarTransparentValue(value);
    }

    public void setTypeface(Typeface typeface) {
        this.mScroller.setTypeface(typeface);
    }

    public void setIndexBarColor(String color) {
        this.mScroller.setIndexBarColor(color);
    }

    public void setIndexBarTextColor(String color) {
        this.mScroller.setIndexBarTextColor(color);
    }
}
