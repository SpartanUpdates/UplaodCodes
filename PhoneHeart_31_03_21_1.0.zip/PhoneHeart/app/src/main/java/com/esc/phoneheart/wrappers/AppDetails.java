package com.esc.phoneheart.wrappers;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.util.Log;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class AppDetails {
    public Context a;
    public ListView list;
    public ArrayList<PackageData> res = new ArrayList();

    public AppDetails(Context context) {
        this.a = context;
    }

    public ArrayList<PackageData> getInstalledSystemApps() {
        try {
            int i = 0;
            List installedPackages = this.a.getPackageManager().getInstalledPackages(0);
            while (i < installedPackages.size()) {
                PackageInfo packageInfo = (PackageInfo) installedPackages.get(i);
                if (packageInfo.versionName != null) {
                    PackageData packageData = new PackageData();
                    if ((packageInfo.applicationInfo.flags & 1) != 0) {
                        packageData.appname = packageInfo.applicationInfo.loadLabel(this.a.getPackageManager()).toString();
                        String str = packageInfo.packageName;
                        packageData.pname = str;
                        packageData.datadir = packageInfo.applicationInfo.dataDir;
                        packageData.saurcedir = packageInfo.applicationInfo.sourceDir;
                        packageData.apkPath = packageInfo.applicationInfo.publicSourceDir;
                        packageData.versionName = packageInfo.versionName;
                        packageData.versionCode = packageInfo.versionCode;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            packageData.installLocation = packageInfo.installLocation;
                        }
                        if (!str.equalsIgnoreCase("")) {
                            this.res.add(packageData);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(packageData.appname);
                            stringBuilder.append("  ");
                            stringBuilder.append(packageData.pname);
                            Log.d("PackageInfoStruct", stringBuilder.toString());
                        }
                    }
                }
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this.res;
    }
}
