package com.kotlinz.festivalstorymaker.Other.g;

public interface c {
    void L(int i, String str);

    void z(int i, String str);

}
