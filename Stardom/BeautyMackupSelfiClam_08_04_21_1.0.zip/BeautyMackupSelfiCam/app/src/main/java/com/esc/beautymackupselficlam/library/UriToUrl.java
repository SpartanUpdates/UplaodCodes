package com.esc.beautymackupselficlam.library;

import android.annotation.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.database.*;
import android.content.*;

@SuppressLint({ "NewApi" })
public class UriToUrl
{
  public static void deleteUri(final Context context, final Uri uri) {
    try {
      context.getContentResolver().delete(uri, (String)null, (String[])null);
    }
    catch (Exception ex) {}
  }

  public static String get(final Context context, Uri uri) {
    String documentId = null;
    boolean b;
    if (Build.VERSION.SDK_INT >= 19) {
      b = true;
    }
    else {
      b = false;
    }
    if (b && DocumentsContract.isDocumentUri(context, uri)) {
      if (isLocalStorageDocument(uri)) {
        documentId = DocumentsContract.getDocumentId(uri);
      }
      else if (isExternalStorageDocument(uri)) {
        final String[] split = DocumentsContract.getDocumentId(uri).split(":");
        if ("primary".equalsIgnoreCase(split[0])) {
          return Environment.getExternalStorageDirectory() + "/" + split[1];
        }
      }
      else {
        if (isDownloadsDocument(uri)) {
          return getDataColumn(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), (long)Long.valueOf(DocumentsContract.getDocumentId(uri))), null, null);
        }
        if (isMediaDocument(uri)) {
          final String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
          final String s = split2[0];
          uri = null;
          if ("image".equals(s)) {
            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
          }
          else if ("video".equals(s)) {
            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
          }
          else if ("audio".equals(s)) {
            uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
          }
          return getDataColumn(context, uri, "_id=?", new String[] { split2[1] });
        }
      }
    }
    else if ("content".equalsIgnoreCase(uri.getScheme())) {
      if (isGooglePhotosUri(uri)) {
        return uri.getLastPathSegment();
      }
      return getDataColumn(context, uri, null, null);
    }
    else if ("file".equalsIgnoreCase(uri.getScheme())) {
      return uri.getPath();
    }
    return documentId;
  }

  public static String getDataColumn(final Context context, final Uri uri, final String s, final String[] array) {
    Cursor cursor = null;
    try {
      final Cursor query = context.getContentResolver().query(uri, new String[] { "_data" }, s, array, (String)null);
      if (query != null) {
        cursor = query;
        if (query.moveToFirst()) {
          cursor = query;
          return query.getString(query.getColumnIndexOrThrow("_data"));
        }
      }
      return null;
    }
    finally {
      if (cursor != null) {
        cursor.close();
      }
    }
  }

  public static boolean isDownloadsDocument(final Uri uri) {
    return "com.android.providers.downloads.documents".equals(uri.getAuthority());
  }

  public static boolean isExternalStorageDocument(final Uri uri) {
    return "com.android.externalstorage.documents".equals(uri.getAuthority());
  }

  public static boolean isGooglePhotosUri(final Uri uri) {
    return "com.google.android.apps.photos.content".equals(uri.getAuthority());
  }

  public static boolean isLocalStorageDocument(final Uri uri) {
    return "com.ianhanniballake.localstorage.documents".equals(uri.getAuthority());
  }

  public static boolean isMediaDocument(final Uri uri) {
    return "com.android.providers.media.documents".equals(uri.getAuthority());
  }

}
