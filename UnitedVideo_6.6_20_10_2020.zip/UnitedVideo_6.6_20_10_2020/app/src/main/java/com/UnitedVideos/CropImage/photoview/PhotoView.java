package com.UnitedVideos.CropImage.photoview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.GestureDetector;

import androidx.appcompat.widget.AppCompatImageView;

public class PhotoView extends AppCompatImageView implements IPhotoView {
    private final PhotoViewAttacher mAttacher;
    private ScaleType mPendingScaleType;

    public PhotoView(final Context context) {
        this(context, null);
    }

    public PhotoView(final Context context, final AttributeSet attr) {
        this(context, attr, 0);
    }

    public PhotoView(final Context context, final AttributeSet attr, final int defStyle) {
        super(context, attr, defStyle);
        super.setScaleType(ScaleType.MATRIX);
        this.mAttacher = new PhotoViewAttacher(this);
        if (this.mPendingScaleType != null) {
            this.setScaleType(this.mPendingScaleType);
            this.mPendingScaleType = null;
        }
    }

    public void setPhotoViewRotation(final float rotationDegree) {
        this.mAttacher.setRotationTo(rotationDegree);
    }

    public void setRotationTo(final float rotationDegree) {
        this.mAttacher.setRotationTo(rotationDegree);
    }

    public void setRotationBy(final float rotationDegree) {
        this.mAttacher.setRotationBy(rotationDegree);
    }

    public void setRotationBy(final float rotationDegree, final boolean animate) {
        this.mAttacher.setRotationBy(rotationDegree, animate);
    }

    public boolean canZoom() {
        return this.mAttacher.canZoom();
    }

    public RectF getDisplayRect() {
        return this.mAttacher.getDisplayRect();
    }

    public Matrix getDisplayMatrix() {
        return this.mAttacher.getDrawMatrix();
    }

    public boolean setDisplayMatrix(final Matrix finalRectangle) {
        return this.mAttacher.setDisplayMatrix(finalRectangle);
    }

    @Deprecated
    public float getMinScale() {
        return this.getMinimumScale();
    }

    public float getMinimumScale() {
        return this.mAttacher.getMinimumScale();
    }

    @Deprecated
    public float getMidScale() {
        return this.getMediumScale();
    }

    public float getMediumScale() {
        return this.mAttacher.getMediumScale();
    }

    @Deprecated
    public float getMaxScale() {
        return this.getMaximumScale();
    }

    public float getMaximumScale() {
        return this.mAttacher.getMaximumScale();
    }

    public float getScale() {
        return this.mAttacher.getScale();
    }

    public ScaleType getScaleType() {
        return this.mAttacher.getScaleType();
    }

    public void setAllowParentInterceptOnEdge(final boolean allow) {
        this.mAttacher.setAllowParentInterceptOnEdge(allow);
    }

    @Deprecated
    public void setMinScale(final float minScale) {
        this.setMinimumScale(minScale);
    }

    public void setMinimumScale(final float minimumScale) {
        this.mAttacher.setMinimumScale(minimumScale);
    }

    @Deprecated
    public void setMidScale(final float midScale) {
        this.setMediumScale(midScale);
    }

    public void setMediumScale(final float mediumScale) {
        this.mAttacher.setMediumScale(mediumScale);
    }

    @Deprecated
    public void setMaxScale(final float maxScale) {
        this.setMaximumScale(maxScale);
    }

    public void setMaximumScale(final float maximumScale) {
        this.mAttacher.setMaximumScale(maximumScale);
    }

    public void setImageDrawable(final Drawable drawable) {
        super.setImageDrawable(drawable);
        this.postUpdate();
    }

    public void setImageResource(final int resId) {
        super.setImageResource(resId);
        this.postUpdate();
    }

    public void setImageURI(final Uri uri) {
        super.setImageURI(uri);
        this.postUpdate();
    }

    private void postUpdate() {
        this.post((Runnable) new Runnable() {
            @Override
            public void run() {
                if (PhotoView.this.mAttacher != null) {
                    PhotoView.this.mAttacher.update();
                }
            }
        });
    }

    public float setMinimumScaleToFit(final Drawable drawable) {
        return this.mAttacher.setMinimumScaleToFit(drawable);
    }

    public void setOnMatrixChangeListener(final PhotoViewAttacher.OnMatrixChangedListener listener) {
        this.mAttacher.setOnMatrixChangeListener(listener);
    }

    public void setOnLongClickListener(final OnLongClickListener l) {
        this.mAttacher.setOnLongClickListener(l);
    }

    public void setOnPhotoTapListener(final PhotoViewAttacher.OnPhotoTapListener listener) {
        this.mAttacher.setOnPhotoTapListener(listener);
    }

    public PhotoViewAttacher.OnPhotoTapListener getOnPhotoTapListener() {
        return this.mAttacher.getOnPhotoTapListener();
    }

    public void setOnViewTapListener(final PhotoViewAttacher.OnViewTapListener listener) {
        this.mAttacher.setOnViewTapListener(listener);
    }

    public PhotoViewAttacher.OnViewTapListener getOnViewTapListener() {
        return this.mAttacher.getOnViewTapListener();
    }

    public void setScale(final float scale) {
        this.mAttacher.setScale(scale);
    }

    public void setScale(final float scale, final boolean animate) {
        this.mAttacher.setScale(scale, animate);
    }

    public void setScale(final float scale, final float focalX, final float focalY, final boolean animate) {
        this.mAttacher.setScale(scale, focalX, focalY, animate);
    }

    public void setScaleType(final ScaleType scaleType) {
        if (this.mAttacher != null) {
            this.mAttacher.setScaleType(scaleType);
        } else {
            this.mPendingScaleType = scaleType;
        }
    }

    public void setZoomable(final boolean zoomable) {
        this.mAttacher.setZoomable(zoomable);
    }

    public Bitmap getVisibleRectangleBitmap() {
        return this.mAttacher.getVisibleRectangleBitmap();
    }

    public void setZoomTransitionDuration(final int milliseconds) {
        this.mAttacher.setZoomTransitionDuration(milliseconds);
    }

    public IPhotoView getIPhotoViewImplementation() {
        return this.mAttacher;
    }

    public Bitmap getCroppedImage() {
        return this.mAttacher.getCroppedImage();
    }

    public void setOnDoubleTapListener(final GestureDetector.OnDoubleTapListener newOnDoubleTapListener) {
        this.mAttacher.setOnDoubleTapListener(newOnDoubleTapListener);
    }

    public void update() {
        this.mAttacher.update();
    }

    public void reset() {
        this.mAttacher.reset();
    }

    protected void onDetachedFromWindow() {
        this.mAttacher.cleanup();
        super.onDetachedFromWindow();
    }

    public void setImageBoundsListener(final IGetImageBounds listener) {
        this.mAttacher.setImageBoundsListener(listener);
    }
}
