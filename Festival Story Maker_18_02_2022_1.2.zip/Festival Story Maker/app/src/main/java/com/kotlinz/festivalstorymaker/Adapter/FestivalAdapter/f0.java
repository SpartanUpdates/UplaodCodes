package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.kotlinz.festivalstorymaker.Listener.festival.d0;
import com.kotlinz.festivalstorymaker.Listener.festival.e0;
import com.kotlinz.festivalstorymaker.Other.o.u.a.hb;
import com.kotlinz.festivalstorymaker.R;
import java.util.ArrayList;

public class f0 extends RecyclerView.Adapter<f0.MyViewHolder> {

    public Activity p;
    public ArrayList<Integer> q;
    public int r;
    public hb s;
    public boolean t;
    public float u = -1.0f;

    public f0(Activity activity, ArrayList<Integer> arrayList, int i, hb hbVar, boolean z, int i2) {
        this.p = activity;
        this.q = arrayList;
        this.r = i;
        this.t = z;
        this.u = (float) i2;
        this.s = hbVar;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_color_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (this.u != -1.0f) {
            holder.d.getLayoutParams().height = ((int) (this.u / 3.0f)) - 16;
            holder.d.requestLayout();
        }
        holder.a.setOnClickListener(new d0(this, position));
        holder.c.setOnClickListener(new e0(this));
        if (this.q.get(position) != null) {
            holder.a.setCardBackgroundColor(((Integer) q.get(position)).intValue());
            holder.c.setVisibility(View.GONE);
            position = ((Integer) q.get(position)).intValue();
            LinearLayout linearLayout = holder.b;
            if (position == -1) {
                linearLayout.setBackground(this.p.getResources().getDrawable(R.drawable.rounded_corner_black_border));
                return;
            } else {
                linearLayout.setBackground(null);
                return;
            }
        }
        holder.b.setBackground(null);
        holder.c.setVisibility(View.VISIBLE);
        holder.a.setCardBackgroundColor(0);
    }

    @Override
    public int getItemCount() {
        return q.size();

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public CardView a;
        public LinearLayout b;
        public ImageView c;
        public RelativeLayout d;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.d = (RelativeLayout) itemView.findViewById(R.id.rlMain);
            this.b = (LinearLayout) itemView.findViewById(R.id.cardBgColor);
            this.a = (CardView) itemView.findViewById(R.id.cardColor);
            this.c = (ImageView) itemView.findViewById(R.id.imgPicker);

        }
    }
}
