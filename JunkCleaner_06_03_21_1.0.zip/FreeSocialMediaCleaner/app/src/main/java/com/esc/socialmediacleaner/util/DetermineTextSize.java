package com.esc.socialmediacleaner.util;

import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.graphics.Typeface;

public class DetermineTextSize {
    public static int determineTextSize(Typeface typeface, float f) {
        Paint paint = new Paint();
        paint.setTypeface(typeface);
        int i = (int) f;
        paint.setTextSize((float) i);
        float calculateHeight = calculateHeight(paint.getFontMetrics());
        int i2 = i;
        while (i2 != 0 && calculateHeight > f) {
            int i3 = i2 - 1;
            paint.setTextSize((float) i2);
            i2 = i3;
            calculateHeight = calculateHeight(paint.getFontMetrics());
        }
        return i2 == 0 ? i : i2;
    }

    public static float calculateHeight(FontMetrics fontMetrics) {
        return fontMetrics.bottom - fontMetrics.top;
    }
}
