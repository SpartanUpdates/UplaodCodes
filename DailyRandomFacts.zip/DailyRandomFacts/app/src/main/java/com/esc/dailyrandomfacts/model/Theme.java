package com.esc.dailyrandomfacts.model;

import android.graphics.Bitmap;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Theme implements Serializable {
    public static final String TAG = "theme";
    @SerializedName("background")
    private String background;
    @SerializedName("backgroundImageName")
    private String backgroundImageName;
    @SerializedName("bigfont")
    private int bigfont;
    @SerializedName("bitmap")
    private Bitmap bitmap;
    @SerializedName("capital")
    private int capital;
    @SerializedName("color")
    private String color;
    @SerializedName("font")
    private String font;
    @SerializedName("leftAligned")
    private int leftAligned;
    @SerializedName("name")
    private String name;
    @SerializedName("shadowColor")
    private String shadowColor;
    @SerializedName("textColor")
    private String textColor;

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getFont() {
        return this.font;
    }

    public void setFont(String str) {
        this.font = str;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String str) {
        this.color = str;
    }

    public String getBackground() {
        return this.background;
    }

    public void setBackground(String str) {
        this.background = str;
    }

    public String getBackgroundImageName() {
        return this.backgroundImageName;
    }

    public void setBackgroundImageName(String str) {
        this.backgroundImageName = str;
    }

    public String getShadowColor() {
        return this.shadowColor;
    }

    public void setShadowColor(String str) {
        this.shadowColor = str;
    }

    public String getTextColor() {
        return this.textColor;
    }

    public void setTextColor(String str) {
        this.textColor = str;
    }

    public int getLeftAligned() {
        return this.leftAligned;
    }

    public void setLeftAligned(int i) {
        this.leftAligned = i;
    }

    public int getCapital() {
        return this.capital;
    }

    public void setCapital(int i) {
        this.capital = i;
    }

    public int getBigfont() {
        return this.bigfont;
    }

    public void setBigfont(int i) {
        this.bigfont = i;
    }

    public Bitmap getBitmap() {
        return this.bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
