package com.wavymusic.mp3Cutter.mycreation.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.mp3Cutter.Model.SongCropModel;
import com.wavymusic.mp3Cutter.mycreation.adapter.MycropSongAdapter;
import com.wavymusic.mp3Cutter.Services.SongMediaPlayer;
import com.wavymusic.mp3Cutter.activity.SongCropActivity;
import com.wavymusic.R;
import com.wavymusic.SongCrop.view.EmptyRecyclerView;
import com.wavymusic.Utils.Utils;
import com.wavymusic.application.MyApplication;
import java.io.File;
import java.util.ArrayList;

public class SongCropMycreationActivity extends AppCompatActivity {

    EmptyRecyclerView rvVideo;
    RelativeLayout rlSongProgress;
    public ArrayList<SongCropModel> songList;
    public SongMediaPlayer service;
    private Handler handler = new Handler();
    private long p;
    private MycropSongAdapter songcropAdapter;
    ImageView ivback;
    private boolean s = true;
    private String FolderName;
    private String PageTitle;
    private LinearLayout layoutNoVideo;

    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_creation);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SongCropMycreationActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        Intent intent;
        try {
            File file = new File(MyApplication.f.getAbsolutePath() + File.separator + FolderName);
            Log.e("FolderPath", file.getAbsolutePath());
            if (Build.VERSION.SDK_INT >= 19) {
                intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                intent.setData(Uri.fromFile(file));
            } else {
                intent = new Intent("android.intent.action.MEDIA_MOUNTED", Uri.fromFile(file));
            }
            sendBroadcast(intent);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        BindView();
        SetData();
        SetListener();
        BannerAds();

    }

    private void BannerAds() {
        adView = new AdView(this, getResources().getString(R.string.fb_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private SongCropModel a(int i, String str, String str2, String str3, long j, String str4) {
        SongCropModel aVar = new SongCropModel();
        Log.e("audioName", str);
        aVar.a(i);
        aVar.b(str);
        aVar.c(str2);
        aVar.a(str3);
        aVar.a(j);
        aVar.d(str4);
        aVar.b(false);
        return aVar;
    }

    public ArrayList<SongCropModel> getAudioList() {
        String[] strArr = new String[]{"_id", "title", "artist", "_data", "duration", "_size", "is_music", "album_id"};
        ArrayList<SongCropModel> arrayList = new ArrayList();
        try {
            ContentResolver contentResolver = getContentResolver();
            Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("_data like '%");
            stringBuilder.append(MyApplication.f.getAbsolutePath());
            stringBuilder.append(File.separator);
            stringBuilder.append(FolderName);
            stringBuilder.append("%'");
            Cursor query = contentResolver.query(uri, strArr, stringBuilder.toString(), null, null);
            if (query == null) {
                return arrayList;
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(query.getCount());
            stringBuilder2.append(BuildConfig.FLAVOR);
            Log.e("cursor", stringBuilder2.toString());
            if (query.getCount() == 0) {
                query.close();
                return null;
            }
            while (query.moveToNext()) {
                int i = query.getInt(query.getColumnIndexOrThrow("_id"));
                String string = query.getString(query.getColumnIndexOrThrow("title"));
                String string2 = query.getString(query.getColumnIndexOrThrow("artist"));
                String string3 = query.getString(query.getColumnIndexOrThrow("_data"));
                long j = (long) query.getInt(query.getColumnIndexOrThrow("duration"));
                query.getLong(query.getColumnIndexOrThrow("_size"));
                int i2 = query.getInt(query.getColumnIndex("is_music"));
                String uri2 = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), query.getLong(query.getColumnIndex("album_id"))).toString();
                if (i2 != 0) {
                    String str;
                    if (string.equals("<unknown>") || string.equals(BuildConfig.FLAVOR)) {
                        string = "unknown";
                    }
                    String str2 = string;
                    if (!"<unknown>".equals(string2)) {
                        if (!BuildConfig.FLAVOR.equals(string2)) {
                            str = string2;
                            if (string3.endsWith(".mp3")) {
                                arrayList.add(a(i, str2, str, string3, j, uri2));
                            }
                        }
                    }
                    str = "unknown";
                    if (string3.endsWith(".mp3")) {
                        arrayList.add(a(i, str2, str, string3, j, uri2));
                    }
                }
            }
            Log.e("getAllAudio", "close");
            query.close();
            return arrayList;
        } catch (Exception e) {
            e.printStackTrace();
            return arrayList;
        }
    }

    private void a(final SongCropModel aVar) {
        handler.post(new Runnable() {

            public void run() {
                SongCropMycreationActivity.this.service.a(aVar.e());
                SongCropMycreationActivity.this.service.b();
                SongCropMycreationActivity.this.x();
            }
        });
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        layoutNoVideo = findViewById(R.id.rl_novideo);
        rlSongProgress = findViewById(R.id.rl_load_sound_blank);
        this.rvVideo = findViewById(R.id.rv_recycler_view);
    }

    private void SetData() {
        try {
            FolderName = getIntent().getStringExtra("FolderName");
            PageTitle = getIntent().getStringExtra("PageTitle");
        } catch (Exception e2) {
            FolderName = Utils.f5847e;
            FolderName = "My Creation";
            e2.printStackTrace();
        }
        songList = getAudioList();
        rvVideo.setEmptyView(layoutNoVideo);
        rvVideo.setHasFixedSize(true);
        SetAdapter();
    }

    private void SetListener() {
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void w() {
        service.d();
        this.p = (long) service.c();
    }

    public void x() {
        service.f();
        service.a(this.p);
    }

//    public void a(Context context, TextView textView) {
//        textView.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/OpenSans_Regular.ttf"));
//    }

    public void a(SongCropModel aVar, int i) {
        this.p = 0;
        a(aVar);
        service.f();
    }


    public void SetAdapter() {
        songcropAdapter = new MycropSongAdapter(this);
        rvVideo.setLayoutManager(new LinearLayoutManager(this));
        rvVideo.setAdapter(songcropAdapter);
        rlSongProgress.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("Ondestroy", "destroy");
        SongCropActivity.l = false;
        SongMediaPlayer aVar = service;
        if (aVar != null) {
            aVar.g();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        SetuiVisibility();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (this.s) {
            service = new SongMediaPlayer(this);
            this.s = false;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (service.e()) {
            w();
        }
    }

    public void p() {
        if (service.e()) {
            w();
        } else {
            x();
        }
    }

    public boolean q() {
        if (service.e()) {
            return true;
        }
        service.e();
        return false;
    }

    public void SetuiVisibility() {
        try {
            if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
                getWindow().getDecorView().setSystemUiVisibility(8);
            } else if (Build.VERSION.SDK_INT >= 19) {
                getWindow().getDecorView().setSystemUiVisibility(4096);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void s() {
        service.g();
        this.p = 0;
    }
}
