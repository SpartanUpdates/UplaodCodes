package com.esc.socialmediacleaner.util;

import android.os.Bundle;
import android.os.PersistableBundle;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest.Builder;
import com.esc.socialmediacleaner.R;
import com.google.android.gms.ads.InterstitialAd;

public class FullAdScreen extends AdParentScreen {
    private int attempt = 1;
    private OnAdClosed onAdClosed;

    public void onCreate(Bundle bundle, PersistableBundle persistableBundle) {
        super.onCreate(bundle, persistableBundle);
        this.attempt = 1;
    }

    private void anotherAttempt() {
        int i = this.attempt + 1;
        this.attempt = i;
        if (i <= 3) {
            loadFullScreenAd(this.onAdClosed);
        }
    }

    public void loadFullScreenAd(OnAdClosed onAdClosed) {
        this.onAdClosed = onAdClosed;
        if (Util.isConnectingToInternet(this)) {
            int adType = new AdsToShow(this).getAdType(this.attempt);
            if (adType != 10) {
                if (adType == 1) {
//                    loadFullAdmobAd(onAdClosed);
                } else if (adType == 2) {
//                    loadFANAd(onAdClosed);
                }
            }
        }
    }

//    private void loadFANAd(final OnAdClosed onAdClosed) {
//        InterstitialAd interstitialAd = new InterstitialAd(this, getString(R.string.full_fb));
//        this.interstitialAdFB = interstitialAd;
//        interstitialAd.setAdListener(new InterstitialAdListener() {
//            public void onAdClicked(Ad ad) {
//            }
//
//            public void onInterstitialDisplayed(Ad ad) {
//            }
//
//            public void onInterstitialDismissed(Ad ad) {
//                onAdClosed.adClosed();
//            }
//
//            public void onError(Ad ad, AdError adError) {
//                FullAdScreen fullAdScreen = FullAdScreen.this;
//                StringBuilder stringBuilder = new StringBuilder();
//                stringBuilder.append("FULL_FAN_ERROR_");
//                stringBuilder.append(adError.getErrorMessage());
//                fullAdScreen.track(stringBuilder.toString());
//                onAdClosed.adLoadedOrFailed(false);
//                FullAdScreen.this.anotherAttempt();
//            }
//
//            public void onAdLoaded(Ad ad) {
//                FullAdScreen.this.track("FULL_FAN_LOAD");
//                onAdClosed.adLoadedOrFailed(true);
//            }
//
//            public void onLoggingImpression(Ad ad) {
//                FullAdScreen.this.track("FULL_FAN_IMP");
//            }
//        });
//        this.interstitialAdFB.loadAd();
//    }

//    private void loadFullAdmobAd(final OnAdClosed onAdClosed) {
//        com.google.android.gms.ads.InterstitialAd interstitialAd = new com.google.android.gms.ads.InterstitialAd(this);
//        this.mInterstitialAd = interstitialAd;
//        interstitialAd.setAdUnitId(getString(R.string.full_ad_admob));
//        this.mInterstitialAd.setAdListener(new AdListener() {
//            public void onAdClosed() {
//                super.onAdClosed();
//                onAdClosed.adClosed();
//            }
//
//            public void onAdLoaded() {
//                super.onAdLoaded();
//                onAdClosed.adLoadedOrFailed(true);
//                FullAdScreen.this.track("FULL_ADMOB_LOAD");
//            }
//
//            public void onAdFailedToLoad(LoadAdError loadAdError) {
//                super.onAdFailedToLoad(loadAdError);
//                onAdClosed.adLoadedOrFailed(false);
//                FullAdScreen.this.track("FULL_ADMOB_FAIL");
//            }
//        });
//    }

//    public void showAd() {
//        com.google.android.gms.ads.InterstitialAd interstitialAd = this.mInterstitialAd;
//        if (interstitialAd != null && interstitialAd.isLoaded()) {
//            this.mInterstitialAd.show();
//        }
//        InterstitialAd interstitialAd2 = this.interstitialAdFB;
//        if (interstitialAd2 != null && interstitialAd2.isAdLoaded()) {
//            this.interstitialAdFB.show();
//        }
//    }

//    public boolean isLoaded() {
//        com.google.android.gms.ads.InterstitialAd interstitialAd = this.mInterstitialAd;
//        if (interstitialAd != null && interstitialAd.isLoaded()) {
//            return true;
//        }
//        InterstitialAd interstitialAd2 = this.interstitialAdFB;
//        if (interstitialAd2 == null || !interstitialAd2.isAdLoaded()) {
//            return false;
//        }
//        return true;
//    }
}
