package com.kotlinz.festivalstorymaker.Utils.a;

public enum i {
    e,
    f;
}
