package com.kotlinz.videoCollage.interfaces;

public interface TextBGImageAdapterCallBackInterface {
    void itemClick(int i);
}
