package com.kotlinz.festivalstorymaker.Model.VideoPoster;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class PosterResponse {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private PosterResponse posterResponse;

	@SerializedName("data")
	private ArrayList<PosterVideoData> data;

	@SerializedName("total_records")
	private String totalRecords;

	@SerializedName("total_pages")
	private String totalPages;

	@SerializedName("current_page_number")
	private String currentPageNumber;

	public String getSuccess(){
		return success;
	}

	public PosterResponse getPosterResponse(){
		return posterResponse;
	}

	public ArrayList<PosterVideoData> getData(){
		return data;
	}

	public String getTotalRecords(){
		return totalRecords;
	}

	public String getTotalPages(){
		return totalPages;
	}

	public String getCurrentPageNumber(){
		return currentPageNumber;
	}
}