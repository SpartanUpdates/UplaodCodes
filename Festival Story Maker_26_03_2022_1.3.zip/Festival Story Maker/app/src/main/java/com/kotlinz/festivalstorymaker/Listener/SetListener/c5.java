package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class c5 implements View.OnLongClickListener {
    public final FrameLayout e;
    public final ImageView f;
    public final FrameEditorNewDesign g;

    public c5(final FrameEditorNewDesign g, final FrameLayout e, final ImageView f) {
        this.g = g;
        this.e = e;
        this.f = f;
    }

    public boolean onLongClick(final View view) {
        final FrameEditorNewDesign g = this.g;
        g.W0 = true;
        g.u0();
        final FrameEditorNewDesign g2 = this.g;
        g2.a0 = this.e;
        FrameEditorNewDesign.F1 = this.f;
        g2.z0(true);
        return false;
    }
}
