package com.vidsoft.videostatusmaker.Utils.gridview;

import android.widget.*;
import java.util.*;

public abstract class AbstractDynamicGridAdapter extends BaseAdapter implements DynamicGridAdapterInterface
{
  public static final int INVALID_ID = -1;
  private HashMap<Object, Integer> mIdMap;
  private int nextStableId;

  public AbstractDynamicGridAdapter() {
    this.nextStableId = 0;
    this.mIdMap = new HashMap<Object, Integer>();
  }

  protected void addAllStableId(final List<?> list) {
    final Iterator<?> iterator = list.iterator();
    while (iterator.hasNext()) {
      this.addStableId(iterator.next());
    }
  }

  protected void addStableId(final Object o) {
    this.mIdMap.put(o, this.nextStableId++);
  }

  protected void clearStableIdMap() {
    this.mIdMap.clear();
  }

  public final long getItemId(final int n) {
    if (n >= 0 && n < this.mIdMap.size()) {
      return this.mIdMap.get(this.getItem(n));
    }
    return -1L;
  }

  public final boolean hasStableIds() {
    return true;
  }

  protected void removeStableID(final Object o) {
    this.mIdMap.remove(o);
  }
}
