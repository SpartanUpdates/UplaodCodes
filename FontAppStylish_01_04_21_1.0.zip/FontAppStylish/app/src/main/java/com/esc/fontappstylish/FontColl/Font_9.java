package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Font_9 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"Λ", "Ϧ", "ㄈ", "Ð", "Ɛ", "F", "Ɠ", "н", "ɪ", "ﾌ", "Қ", "Ł", "௱", "Л", "Ø", "þ", "Ҩ", "尺", "ら", "Ť", "Ц", "Ɣ", "Ɯ", "χ", "Ϥ", "Ẕ"};
    }

    public String getName() {
        return "ΛϦㄈ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"Λ", "Ϧ", "ㄈ", "Ð", "Ɛ", "F", "Ɠ", "н", "ɪ", "ﾌ", "Қ", "Ł", "௱", "Л", "Ø", "þ", "Ҩ", "尺", "ら", "Ť", "Ц", "Ɣ", "Ɯ", "χ", "Ϥ", "Ẕ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
