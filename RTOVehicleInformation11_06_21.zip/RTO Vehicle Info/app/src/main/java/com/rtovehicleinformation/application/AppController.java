package com.rtovehicleinformation.application;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rtovehicleinformation.OpenAds.AppOpenManager;


public class AppController extends Application {

    public static final String TAG = AppController.class.getSimpleName();



    private static AppController mInstance;
    private static Context context;

    public static String key;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    AppOpenManager appOpenManager;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        appOpenManager = new AppOpenManager(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        sharedPreferences = getApplicationContext().getSharedPreferences("key", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        key=sharedPreferences.getString("keyString","");
        if(key==null || key.equals(""))
        {
            fetchKey();
        }
    }

    private void fetchKey() {
        System.out.println("key fetched");
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("key");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                key=snapshot.getValue().toString();
                editor.putString("keyString",snapshot.getValue().toString());
                editor.commit();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    public static Context getContext() {
        return context;
    }
    public static synchronized AppController getInstance() {
        return mInstance;
    }

}
