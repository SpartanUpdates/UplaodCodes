package api.natsuite.natcorder;

import java.nio.*;

public interface MediaRecorder
{
    void startRecording(final String p0, final Callback p1);
    
    void stopRecording();
    
    void encodeFrame(final ByteBuffer p0, final long p1);
    
    void encodeFrame(final long p0, final long p1);
    
    void encodeSamples(final float[] p0, final long p1);
    
    public interface Callback
    {
        void onRecording(final String p0);
    }
}
