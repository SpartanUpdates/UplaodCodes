package com.esc.flashlight.flashlight.controller;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.util.Log;
import android.view.SurfaceView;

import com.esc.flashlight.App.APP;

public class BasicFlashController23 implements BaseFlashControllerInterface {
    private static BasicFlashController23 mBack;
    private static BasicFlashController23 mFront;
    private String mCameraId;
    private CameraManager mCameraManager;

    public static BasicFlashController23 getInstanceBack() {
        BasicFlashController23 basicFlashController23 = mBack;
        if (basicFlashController23 == null && basicFlashController23 == null) {
            mBack = new BasicFlashController23(0);
        }
        return mBack;
    }

    public static BasicFlashController23 getInstanceFront(int i) {
        BasicFlashController23 basicFlashController23 = mFront;
        if (basicFlashController23 == null && basicFlashController23 == null) {
            mFront = new BasicFlashController23(i);
        }
        return mFront;
    }

    private BasicFlashController23(int i) {
        this.mCameraId = String.valueOf(i);
    }

    public void useStart(SurfaceView surfaceView) {
        this.mCameraManager = (CameraManager) APP.APP.getSystemService("camera");
    }

    public void useStop() {
        if (this.mCameraManager != null) {
            flashOff();
        }
    }

    public void flashOn() {
        try {
            Log.d(getClass().getSimpleName(), this.mCameraId + " / " + true);
            this.mCameraManager.setTorchMode(this.mCameraId, true);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void flashOff() {
        try {
            Log.d(getClass().getSimpleName(), this.mCameraId + " / " + false);
            this.mCameraManager.setTorchMode(this.mCameraId, false);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
}
