package com.kotlinz.festivalstorymaker.Listener.SetListener;


import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class HDTextStickerViewTouchListener implements com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1.b {
    public final  HighlightDetailsDetailActivity activity;

    public HDTextStickerViewTouchListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
        this.activity = highlightDetailsDetailActivity;
    }

    public void a(boolean z, TextStickerViewNew1 textStickerViewNew1) {
        if (activity.llTextEditor.isShown() && !z) {
            TextStickerViewNew1 textStickerViewNew12 = activity.n0;
            if (textStickerViewNew12 == null || textStickerViewNew12 == textStickerViewNew1) {
                activity.s0(z);
            }
        }
    }
}
