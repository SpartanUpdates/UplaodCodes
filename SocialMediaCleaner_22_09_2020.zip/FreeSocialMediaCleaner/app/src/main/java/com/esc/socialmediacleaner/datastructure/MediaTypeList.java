package com.esc.socialmediacleaner.datastructure;

import com.esc.socialmediacleaner.util.Util;

import java.io.File;
import java.util.ArrayList;
import org.apache.commons.io.FilenameUtils;

class MediaTypeList {
    public ArrayList<FileDataWrapper> list = new ArrayList();
    public MediaType mediaType;
    public ArrayList<PathData> pathData;
    public SocialAppType socialAppType;

    public MediaTypeList(MediaType mediaType, ArrayList<PathData> arrayList, SocialAppType socialAppType) {
        this.pathData = arrayList;
        this.mediaType = mediaType;
        this.socialAppType = socialAppType;
    }

    public void getData() {
        for (int i = 0; i < this.pathData.size(); i++) {
            listFiles(new File(((PathData) this.pathData.get(i)).path), ((PathData) this.pathData.get(i)).pathType);
        }
    }

    private void listFiles(File file, PathType pathType) {
        if (file != null && file.exists()) {
            File[] listFiles = file.listFiles(new FileFilterUtil(this.mediaType.ordinal()));
            if (listFiles != null) {
                for (File file2 : listFiles) {
                    if (file2.isDirectory()) {
                        listFiles(file2, pathType);
                    }
                    FileDataWrapper fileDataWrapper = new FileDataWrapper();
                    fileDataWrapper.lastModified = file2.lastModified();
                    fileDataWrapper.path = file2.getPath();
                    if (!fileDataWrapper.path.contains("WhatsApp Images/Sent") || Util.checkTimeDifference(file2.lastModified()) / 1000 >= 86400) {
                        fileDataWrapper.size = file2.length();
                        fileDataWrapper.type = this.mediaType;
                        fileDataWrapper.pathType = pathType;
                        fileDataWrapper.socialAppType = this.socialAppType;
                        fileDataWrapper.ext = FilenameUtils.getExtension(file2.getPath());
                        fileDataWrapper.name = FilenameUtils.getName(file2.getPath());
                        this.list.add(fileDataWrapper);
                    }
                }
            }
        }
    }
}
