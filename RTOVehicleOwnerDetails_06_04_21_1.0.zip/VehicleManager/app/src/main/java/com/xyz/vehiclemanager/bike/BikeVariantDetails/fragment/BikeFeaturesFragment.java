package com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.activity.BikeVariantTabActivity;
import com.xyz.vehiclemanager.adapter.VariantItemAttrAdapter;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeFeatures;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeVariantRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeFeaturesFragment extends Fragment
{
    private View view;
    private TextView tv_title;
    private RecyclerView rv_variantdetails;
    private ArrayList<Item> featuresList = new ArrayList<>();
    private VariantItemAttrAdapter variantItemAttrAdapter;
    private RtoDetailsInterface rtoDetailsInterface;

    public BikeFeaturesFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        view = inflater.inflate(R.layout.fragment_variant_details, container, false);

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        rv_variantdetails = view.findViewById(R.id.rv_variantdetails);
        tv_title = view.findViewById(R.id.tv_title);
        getFeaturesVariantData();
        return view;
    }

    private void getFeaturesVariantData()
    {
        Call<BikeVariantRoot> call = rtoDetailsInterface.getBikeVariantDetails(BikeVariantTabActivity.varientId);
        call.enqueue(new Callback<BikeVariantRoot>() {
            @Override
            public void onResponse(Call<BikeVariantRoot> call, Response<BikeVariantRoot> response) {
                if (response.isSuccessful())
                {
                    tv_title.setText("Features");
                    ArrayList<BikeFeatures> variantlist = response.body().getDetails().getFeatures();
                    for (int i = 0; i < variantlist.size(); i++) {
                        String key = variantlist.get(i).getKey();
                        ArrayList<Item> itemlist = response.body().getDetails().getSpecifications().get(i).getItems();
                        for (int j = 0; j < itemlist.size(); j++)
                        {

                            Item item = new Item();
                            String sAttrName = itemlist.get(j).getAttrName();
                            String sAttrValue = itemlist.get(j).getAttrValue();
                            item.setAttrName(sAttrName);
                            item.setAttrValue(sAttrValue);
                            featuresList.add(item);
                        }
                        variantItemAttrAdapter = new VariantItemAttrAdapter(getActivity(), featuresList);
                        rv_variantdetails.setAdapter(variantItemAttrAdapter);
                        rv_variantdetails.setLayoutManager(new LinearLayoutManager(getActivity()));
                    }
                }
            }

            @Override
            public void onFailure(Call<BikeVariantRoot> call, Throwable t) {
            }
        });
    }
}