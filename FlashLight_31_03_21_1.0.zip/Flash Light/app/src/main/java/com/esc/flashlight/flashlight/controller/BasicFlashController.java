package com.esc.flashlight.flashlight.controller;

public class BasicFlashController extends BaseFlashController {
    private static BasicFlashController mBack;
    private static BasicFlashController mFront;


    public void afterCameraOpen() {
    }


    public void beforeCameraRelease() {
    }


    public void onStartUse() {
    }

    public static BasicFlashController getInstanceBack() {
        BasicFlashController basicFlashController = mBack;
        if (basicFlashController == null && basicFlashController == null) {
            mBack = new BasicFlashController(-1);
        }
        return mBack;
    }

    public static BasicFlashController getInstanceFront(int i) {
        BasicFlashController basicFlashController = mFront;
        if (basicFlashController == null && basicFlashController == null) {
            mFront = new BasicFlashController(i);
        }
        return mFront;
    }

    private BasicFlashController(int i) {
        super(i);
    }
}
