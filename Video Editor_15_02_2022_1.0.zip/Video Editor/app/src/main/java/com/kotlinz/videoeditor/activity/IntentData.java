package com.kotlinz.videoeditor.activity;

import java.io.Serializable;

public class IntentData implements Serializable {
    private boolean DataBoln;
    private int dataInt;
    private String dataStr;

    public String getDataStr() {
        return this.dataStr;
    }

    public void setDataStr(String str) {
        this.dataStr = str;
    }

    public boolean isDataBoln() {
        return this.DataBoln;
    }

    public void setDataBoln(boolean z) {
        this.DataBoln = z;
    }
}
