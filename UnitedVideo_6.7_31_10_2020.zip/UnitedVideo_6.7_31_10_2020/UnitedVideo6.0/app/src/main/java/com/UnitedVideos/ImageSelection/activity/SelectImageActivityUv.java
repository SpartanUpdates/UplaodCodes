package com.UnitedVideos.ImageSelection.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.UnitedVideos.CropImage.activity.ImageCropActivityUv;
import com.UnitedVideos.CropImage.bitmapUtil.Utils;
import com.UnitedVideos.ImageSelection.Adapter.AlbumAdapterById;
import com.UnitedVideos.ImageSelection.Adapter.ImageByAlbumAdapter;
import com.UnitedVideos.ImageSelection.Adapter.SelectedImageAdapter;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.ImageSelection.Interface.OnItemClickListner;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.ImageSelection.View.EmptyRecyclerView;
import com.wavymusic.ImageSelection.View.ExpandIconView;
import com.wavymusic.ImageSelection.View.VerticalSlidingPanel;
import com.wavymusic.R;

import java.io.File;
import java.util.ArrayList;

public class SelectImageActivityUv extends AppCompatActivity implements VerticalSlidingPanel.PanelSlideListener {

    Activity activity = SelectImageActivityUv.this;
    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    public static ArrayList<ImageModel> tempImage = new ArrayList();
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private SelectedImageAdapter selectedImageAdapterUv;
    private VerticalSlidingPanel panel;
    private View parent;
    private ExpandIconView expandIcon;
    private Button btnClear;
    Button Done;
    private TextView tvImageCount;
    private MyApplication application;
    public boolean isFromPreview = false;
    public static boolean isForFirst = false;
    private EmptyRecyclerView rvSelectedImage;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    int hight;
    int width;
    String isCut;
    ArrayList<String> arrayList;
    String path = "";
    String imageOrientation;
    public static String imagePath;

    String isfrom;
    boolean isPause = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_image);
        application = MyApplication.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        hight = getIntent().getIntExtra("hight", 640);
        width = getIntent().getIntExtra("width", 520);
        isCut = getIntent().getStringExtra("isCut");
        isfrom = getIntent().getStringExtra("isfrom");
        PutAnalyticsEvent();
        if (application.IsBack) {
            application.IsBack = false;
            application.cropimaglistUV.clear();
        } else {
            if (application.getSelectedImages().size() > 0) {
                IsFinish("Do you want to used previously selected images ?");
            }
        }
        application.init();
        bindView();
        init();
        addListner();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectImageActivityUv");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void IsFinish(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        application.cropimaglistUV.clear();
                        dialog.dismiss();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        if (application.getSelectedImages().size() != 0) {
                            imagePath = "";
                            application.selectedImages.clear();
                            application.cropimaglistUV.clear();
                            clearData();
                        }
                        dialog.dismiss();
                        break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(R.string.exit);
        builder.setMessage(alertmessage)
                .setCancelable(false)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void bindView() {
        Done = findViewById(R.id.btnDone);
        tvImageCount = findViewById(R.id.tvCounter);
        expandIcon = findViewById(R.id.settings_drag_arrow);
        rvAlbum = findViewById(R.id.rvAlbum);
        rvAlbumImages = findViewById(R.id.rvImageAlbum);
        rvSelectedImage = findViewById(R.id.rvSelectedImagesList);
        panel = findViewById(R.id.overview_panel);
        panel.setEnableDragViewTouchEvents(true);
        panel.setDragView(findViewById(R.id.settings_pane_header));
        panel.setPanelSlideListener(this);
        parent = findViewById(R.id.default_home_screen_panel);
        btnClear = findViewById(R.id.btnClear);
    }

    @SuppressLint({"NewApi"})
    private void init() {
        albumAdapter = new AlbumAdapterById(this);
        albumImagesAdapter = new ImageByAlbumAdapter(this);
        selectedImageAdapterUv = new SelectedImageAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(
                getApplicationContext(), RecyclerView.VERTICAL, false);
        rvAlbum.setLayoutManager(mLayoutManager);
        rvAlbum.setItemAnimator(new DefaultItemAnimator());
        rvAlbum.setAdapter(albumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(
                getApplicationContext(), 3);
        rvAlbumImages.setLayoutManager(gridLayputManager);
        rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumImages.setAdapter(albumImagesAdapter);

        RecyclerView.LayoutManager gridLayputManager1 = new GridLayoutManager(
                getApplicationContext(), 4);
        rvSelectedImage.setLayoutManager(gridLayputManager1);
        rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        rvSelectedImage.setAdapter(selectedImageAdapterUv);
        rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
        } else {
            tvImageCount.setText(String.valueOf(application.getSelectedImages().size()) + "/" + MyApplication.TotalSelectedImage);
        }
    }

    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }

    private void addListner() {
        this.arrayList = new ArrayList<String>();
        this.Done.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (application.getSelectedImages().size() != 0) {
                    Log.e("TAG", "SelectedImagese" + application.getSelectedImages().size());
                    Log.e("TAG", "TotalImages" + MyApplication.TotalSelectedImage);
                    if (application.getSelectedImages().size() <= MyApplication.TotalSelectedImage) {
                        int i = 0;
                        for (final ImageModel d : application.getSelectedImages()) {
                            final String isLandOrPort = getDropboxIMGSize(d.getImagePath());
                            if (i == 0) {
                                imagePath = d.getImagePath();
                                imageOrientation = isLandOrPort;
                            } else {
                                imagePath = String.valueOf(String.valueOf(imagePath)) + MyApplication.SPLIT_PATTERN + d.getImagePath();
                                imageOrientation = String.valueOf(String.valueOf(imageOrientation)) + "$" + isLandOrPort;
                            }
                            ++i;
                        }
                        if (isCut.equals("3D")) {
                            final Intent intent_audio = new Intent(activity, ImageCropActivityUv.class);
                            intent_audio.putExtra("path", imagePath);
                            intent_audio.putExtra("hw", new int[]{hight, width});
                            intent_audio.putExtra("isCut", isCut);
                            intent_audio.putExtra("isfrom", isfrom);
                            startActivity(intent_audio);
                            finish();
                        } else {
                            new Utils().startAutoCrop(activity, imagePath, isCut, isfrom);
                        }
                    } else if (application.getSelectedImages().size() > MyApplication.TotalSelectedImage) {
                        new StringBuilder("Please Remove ").append(application.getSelectedImages().size() - MyApplication.TotalSelectedImage).append(" Images").toString();
                        Toast.makeText(activity,  new StringBuilder("Please Remove ").append(application.getSelectedImages().size() - MyApplication.TotalSelectedImage).append(" Images").toString(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(activity, "Selected : " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.btnClear.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (application.getSelectedImages().size() != 0) {
                    clearData();
                } else {
                    Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        this.albumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
                } else {
                    tvImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImages().size())) + "/" + MyApplication.TotalSelectedImage);
                }
                selectedImageAdapterUv.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapterUv.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    tvImageCount.setText(String.valueOf(application.getSelectedImages().size()));
                } else {
                    tvImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImages().size())) + "/" + MyApplication.TotalSelectedImage);
                }
                albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        if (isFromPreview)
            menu.removeItem(R.id.menu_clear);
        return super.onCreateOptionsMenu(menu);
    }


    public void onBackPressed() {
        super.onBackPressed();
        if (panel.isExpanded()) {
            panel.collapsePane();
//            return;
        }
        if (isfrom.equalsIgnoreCase("android")) {
            Intent i = new Intent(activity, DashbordActivity.class);
            startActivity(i);
            finish();
        } else if (isfrom.equalsIgnoreCase("unity")) {
            UnityPlayer.UnitySendMessage("UVThemeData", "BackFromGallery", "");
            finish();
        }

    }

    public void onPanelSlide(View panel, final float slideOffset) {
        if (expandIcon != null)
            expandIcon.setFraction(slideOffset, false);
        if (slideOffset >= 0.005f) {
            if ((parent != null) && (parent.getVisibility() != View.VISIBLE)) {
                parent.setVisibility(View.VISIBLE);
            }
        } else if ((parent != null) && (parent.getVisibility() == View.VISIBLE)) {
            parent.setVisibility(View.GONE);
        }
    }


    public void onPanelCollapsed(View panel) {
        if (parent != null) {
            parent.setVisibility(View.VISIBLE);
        }
        selectedImageAdapterUv.isExpanded = false;
        selectedImageAdapterUv.notifyDataSetChanged();
    }

    public void onPanelExpanded(View panel) {
        if (parent != null) {
            parent.setVisibility(View.GONE);
        }
        selectedImageAdapterUv.isExpanded = true;
        selectedImageAdapterUv.notifyDataSetChanged();
    }


    public void onPanelAnchored(View panel) {
    }


    public void onPanelShown(View panel) {
    }


    private void clearData() {
        ArrayList<ImageModel> selectedImages = application.getSelectedImages();
        for (int i = selectedImages.size() - 1; i >= 0; i--) {
            application.removeSelectedImage(i);
        }
        if (MyApplication.TotalSelectedImage >= 50) {
            tvImageCount.setText("0");
        } else {
            tvImageCount.setText("0/" + MyApplication.TotalSelectedImage);
        }

        selectedImageAdapterUv.notifyDataSetChanged();
        albumImagesAdapter.notifyDataSetChanged();
    }

}