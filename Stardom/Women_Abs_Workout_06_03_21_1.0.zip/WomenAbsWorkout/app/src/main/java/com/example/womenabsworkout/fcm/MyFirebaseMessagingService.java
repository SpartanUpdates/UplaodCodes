package com.example.womenabsworkout.fcm;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build.VERSION;
import android.util.Log;
import androidx.core.app.NotificationCompat.Builder;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.Start_Activity;
import com.example.womenabsworkout.utils.Constants;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;


public class MyFirebaseMessagingService extends FirebaseMessagingService {
    public static final String TAG = "Weightlossformen";

    @SuppressLint("NewApi")
    private void sendNotification(String str, String str2, String str3, String str4) {
        Intent intent = new Intent(this, Start_Activity.class);
        intent.putExtra(Constants.APP_PACKAGE_NAME, str);
        intent.putExtra(Constants.APP_BANNER_URL, str2);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        String string = getString(R.string.default_notification_channel_id);
        Builder contentIntent = new Builder(this, string).setSmallIcon(R.mipmap.icon_notification).setContentTitle(str4).setContentText(str3).setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(2)).setContentIntent(activity);
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (VERSION.SDK_INT >= 23 && VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel(string, "Channel human readable title", NotificationManager.IMPORTANCE_DEFAULT));
        }
        notificationManager.notify(0, contentIntent.build());
    }

    public void onMessageReceived(RemoteMessage remoteMessage) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("From: ");
        stringBuilder.append(remoteMessage.getFrom());
        String stringBuilder2 = stringBuilder.toString();
        String str2 = TAG;
        Log.d(str2, stringBuilder2);
        if (remoteMessage.getData().size() > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Message data payload: ");
            stringBuilder.append(remoteMessage.getData());
            Log.d(str2, stringBuilder.toString());
            Map data = remoteMessage.getData();
            if (data.containsKey(Constants.APP_PACKAGE_NAME)) {
                str = (String) data.get(Constants.APP_PACKAGE_NAME);
                stringBuilder2 = (String) data.get(Constants.APP_BANNER_URL);
                if (remoteMessage.getNotification() != null) {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("Message Notification Body: ");
                    stringBuilder3.append(remoteMessage.getNotification().getBody());
                    Log.d(str2, stringBuilder3.toString());
                }
                sendNotification(str, stringBuilder2, remoteMessage.getNotification().getBody(), remoteMessage.getNotification().getTitle());
                remoteMessage.getNotification();
                sendNotification(str, null, remoteMessage.getNotification().getBody(), remoteMessage.getNotification().getTitle());
            }
        }
        str = null;
        remoteMessage.getNotification();
        sendNotification(str, null, remoteMessage.getNotification().getBody(), remoteMessage.getNotification().getTitle());
    }

    public void onNewToken(String str) {
        super.onNewToken(str);
        Log.d("NEW_TOKEN", str);
    }
}
