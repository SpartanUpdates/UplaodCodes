package com.unitedvideosapp.photovideomaker.activity;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.appnext.banners.BannerAdRequest;
import com.appnext.banners.BannerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.race604.drawable.wave.WaveDrawable;
import com.unitedvideosapp.photovideomaker.MyApplication;
import com.unitedvideosapp.photovideomaker.OnProgressReceiver;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.util.Utils;
import com.uvvideos.photo.video.slideshow.maker.R;
import static com.unitedvideosapp.photovideomaker.view.CustomNativeAd.populateUnifiedNativeAdView;


public class ProgressActivity extends AppCompatActivity implements OnProgressReceiver {
    private MyApplication application;
    final float[] from;
    final float[] hsv;
    boolean isComplate;
    float lastProg;
    final float[] to;
    private TextView tvProgress;
    private WaveDrawable mWaveDrawable;
    private UnifiedNativeAd nativeAd;

    private void loadAd() {

        BannerView bannerView = findViewById(R.id.banner);
        bannerView.loadAd(new BannerAdRequest());

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void bindView() {
        this.tvProgress = this.findViewById(R.id.tvProgress);
    }

    public void onOverlayingFinish(final String s) {
    }

    public void onProgressFinish(final String s) {
        if (MyApplication.IsVideo) {
            Utils.isVideoCreationRunning = false;
            final Intent intent = new Intent(this, videoPlay.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("android.intent.extra.TEXT", s);
            intent.putExtra("KEY", "FromProgress");
            this.application.isFristTimeTheme = true;
            ActivityAnimUtil.startActivitySafely(this.tvProgress, intent);
            finish();
        }
    }

    public ProgressActivity() {
        this.from = new float[3];
        this.to = new float[3];
        this.hsv = new float[3];
        this.lastProg = 0.0f;
        this.isComplate = true;
    }

    private void changePercentageOnText(final float lastProg) {
        synchronized (this) {
            if (this.isComplate) {
                final ValueAnimator ofFloat = ValueAnimator.ofFloat(this.lastProg, lastProg);
                ofFloat.setDuration(300L);
                ofFloat.setInterpolator(new LinearInterpolator());
                ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                        ProgressActivity.this.hsv[0] = ProgressActivity.this.from[0] + (ProgressActivity.this.to[0] - ProgressActivity.this.from[0]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[1] = ProgressActivity.this.from[1] + (ProgressActivity.this.to[1] - ProgressActivity.this.from[1]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[2] = ProgressActivity.this.from[2] + (ProgressActivity.this.to[2] - ProgressActivity.this.from[2]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.tvProgress.setText(String.format(" %05.2f%%", valueAnimator.getAnimatedValue()));
                        float p = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    }
                });
                ofFloat.addListener(new Animator.AnimatorListener() {
                    public void onAnimationCancel(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationEnd(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationRepeat(final Animator animator) {
                    }

                    public void onAnimationStart(final Animator animator) {
                        ProgressActivity.this.isComplate = false;
                    }
                });
                ofFloat.start();
                this.lastProg = lastProg;
            }
        }
    }

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_progress);
        this.getWindow().addFlags(128);
        this.application = MyApplication.getInstance();
        this.bindView();
        loadAd();
        ImageView imageView2 = findViewById(R.id.image2);
        mWaveDrawable = new WaveDrawable(this, R.drawable.progressicon);
        imageView2.setImageDrawable(mWaveDrawable);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_my);
        imageView2.startAnimation(animation);
        mWaveDrawable.setIndeterminate(true);
        mWaveDrawable.setWaveAmplitude(4);
        mWaveDrawable.setWaveLength(80);
        mWaveDrawable.setWaveSpeed(4);
        mWaveDrawable.setIndeterminate(true);
        mWaveDrawable.setLevel(100);
        PutAnalyticsEvent();
    }

    public void onImageProgressFrameUpdate(final float n) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 25.0f / 100.0f);

            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ProgressActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    protected void onResume() {
        super.onResume();
        this.application.setOnProgressReceiver(this);
        application.getOnProgressReceiver();
    }

    protected void onStop() {
        super.onStop();
        this.application.setOnProgressReceiver(this);
    }

    public void onBackPressed() {
    }

    public void onVideoProgressFrameUpdate(final float n) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 75.0f / 100.0f + 25.0f);
            }
        });
    }
}
