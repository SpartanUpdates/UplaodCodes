package com.kotlinz.videoCollage.interfaces;

public interface PicVidWatermarkAdapterCallBackInterface {
    void itemClick(int i);
}
