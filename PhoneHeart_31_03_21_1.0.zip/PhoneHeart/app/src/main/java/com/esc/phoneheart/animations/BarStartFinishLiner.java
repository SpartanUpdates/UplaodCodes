package com.esc.phoneheart.animations;

public enum BarStartFinishLiner {
    NONE,
    START,
    END,
    BOTH
}
