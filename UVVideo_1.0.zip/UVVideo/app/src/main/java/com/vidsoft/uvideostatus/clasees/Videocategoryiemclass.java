package com.vidsoft.uvideostatus.clasees;

public class Videocategoryiemclass {
    private String status;
    private String videos;

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public String getVideos() {
        return this.videos;
    }

    public void setVideos(String str) {
        this.videos = str;
    }
}
