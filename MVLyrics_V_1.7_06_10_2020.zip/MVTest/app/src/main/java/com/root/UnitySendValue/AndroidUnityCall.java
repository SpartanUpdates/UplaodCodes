package com.root.UnitySendValue;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.CropImage.activity.CropImageActivity;
import com.MV.Lyrics.Home.activity.HomeActivity;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.LyricsSelect.activity.SelectLyricsActivity;
import com.MV.Lyrics.Preferance.AppPreference;
import com.MV.Lyrics.SelectImage.activity.SelectImageActivity;
import com.MV.Lyrics.ThemeLanguage.activity.LanguageActivity;
import com.MV.Lyrics.UnityPlayerActivity;
import com.MV.Lyrics.VideoPlay.activity.ShareActivity;
import java.io.File;

public class AndroidUnityCall {


    public static void HomeActivity(Context context) {
        if (LanguagePref.a(context).a("pref_key_is_language_set", false)) {
            ShowHomeActivity(context);
        } else {
            Intent intent = new Intent(context, LanguageActivity.class);
            context.startActivity(intent);
        }
    }

    public static void ShowHomeActivity(Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.putExtra("IsFromLanguage", false);
        context.startActivity(intent);
    }

    public static void ShowGallaryActivity(Context context) {
        MyApplication.IsSelectImageFrom = true;
        MyApplication.TotalSelectedImage = 1;
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, SelectImageActivity.class);
        intent.putExtra("NoofImage", 1);
        intent.putExtra("IsFrom", "Image");
        context.startActivity(intent);
    }

    public static void ShowLyrics(Context context) {
        context.startActivity(new Intent(context, SelectLyricsActivity.class));
    }

    public static void CropImageActivity(Context context, String ScreenRatio, String ImagePath) {
        MyApplication.IsCropedImageFrom = false;
        MyApplication.IsCropedExists = true;
        AppPreference preference;
        String ScreenRatioStoreIntoPreferance;
        MyApplication.getInstance().getCropImages().clear();
        Intent intent = new Intent(context, CropImageActivity.class);
        boolean equals = ScreenRatio.equals("0");
        String ScreenRatioOne = "1";
        if (equals) {
            preference = AppPreference.b(context);
            ScreenRatioStoreIntoPreferance = "9:16";
        } else if (ScreenRatio.equals(ScreenRatioOne)) {
            preference = AppPreference.b(context);
            ScreenRatioStoreIntoPreferance = "16:9";
        } else {
            preference = AppPreference.b(context);
            ScreenRatioStoreIntoPreferance = "1:1";
        }
        preference.f("pref_key_crop_ratio", ScreenRatioStoreIntoPreferance);
        intent.putExtra("path", ImagePath);
        intent.putExtra("NoofImage", MyApplication.TotalSelectedImage);
        intent.putExtra("IsNew", "1");
        context.startActivity(intent);
    }


    public static void ShowSetting(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.ShowLyriscSetting();
            }
        });
    }

    public static void RemoveSetting(Context context) {
        ((Activity) context).runOnUiThread(new Runnable() {
            public final void run() {
                UnityPlayerActivity.unityPlayeractivity.ClearSetting();
            }
        });
    }

    public static void GoToPreview(Context context) {
        try {
            ((Activity) context).runOnUiThread(new Runnable() {
                public final void run() {
                    UnityPlayerActivity.unityPlayeractivity.ShowBottomViewLyrics();
                    UnityPlayerActivity.unityPlayeractivity.ShowLyricsStyle();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void HideBannerAds(Context context) {
        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
            public final void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void VideoPlayActivity(final Context context, final String VideoName) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                String path = Utils.INSTANCE.getStoryFolderPath() + VideoName;
                MyApplication.VideoPath = path.substring(path.lastIndexOf("/") + 1);
                Intent intent = new Intent(context, ShareActivity.class);
                intent.putExtra("VideoUrl", path);
                intent.putExtra("VideoName", VideoName);
                intent.putExtra("VideoPosition", 0);
                intent.putExtra("IsVideoFromAndroidList", false);
                AppGeneral.LastTime=0.0f;
                AppGeneral.Progress = 0.0f;
                context.startActivity(intent);
                ScanVideoList(context, Utils.INSTANCE.getStoryFolderPath() + File.separator + MyApplication.VideoPath);
                AndroidUnityCall.ClearSelection(context);
                DeleteCropImages();
            }
        }, 100);
    }

    public static void PreviewBack(final Context context) {
        MyApplication.PreviewContext = context;
        ((Activity) context).runOnUiThread(new Runnable() {
            public void run() {
                UnityPlayerActivity.unityPlayeractivity.GoToHome();
            }
        });

    }

    public static void BackToMain(final Context context) {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ((Activity) context).runOnUiThread(new Runnable() {
                    public final void run() {
                        MyApplication.getInstance().isSettingEnable = false;
                        UnityPlayerActivity.unityPlayeractivity.HidebottomViewLyrics();
                        UnityPlayerActivity.unityPlayeractivity.HideLyricsStyle();
                        UnityPlayerActivity.unityPlayeractivity.SetDefaultRatio();
                        AndroidUnityCall.showClose(context);
                    }
                });
            }
        }, 50);
    }

    private static void showClose(final Context context) {
        Intent intent = new Intent(context, HomeActivity.class);
        context.startActivity(intent);
    }

    public static void createVideo(final Context context, final String videoInputName, final String VideoOutputName) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                AppGeneral.AudioVideoShort(context, videoInputName, VideoOutputName);
            }
        }, 100);
    }

    public static void prepareSongForCreateVideo(final Context context, String AudioTime, String VideoMuteName, String FromSdCard, String AudioInputPath, String VideoFinalName) {
        HideBannerAds(context);
        AppGeneral.AddSongTOVideo(context, AudioTime, VideoMuteName, FromSdCard, AudioInputPath, VideoFinalName);
    }

    public static void ScanVideoList(Context cntx, String path) {
        try {
            android.media.MediaScannerConnection.scanFile(cntx,
                    new String[]{path},
                    new String[]{"video/mp4"},
                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void ClearSelection(Context context) {
        MyApplication.getInstance().getSelectedImages().clear();
        MyApplication.getInstance().getCropImages().clear();
    }

    public static void DeleteCropImages() {
        Utils util = new Utils();
        String path = util.getOutputPath() + "CropTempImg" + File.separator;
        File folder = new File(path);
        util.deleteRecursive(folder);
    }

    public static void PutLog(Context context, String value) {
        Log.e("TAG", "TextValue" + value);
    }
}
