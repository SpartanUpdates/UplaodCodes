package com.esc.photovault.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.AuthenticationResult;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.CancellationSignal;
import android.util.Log;
import android.view.View;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import com.esc.photovault.activity.LockScreenActivity;
import com.esc.photovault.activity.Vault_folder;

@RequiresApi(api = 23)
public class FingerprintHandler extends AuthenticationCallback {
    private Context context;

    public FingerprintHandler(Context mContext) {
        this.context = mContext;
    }

    public void startAuth(FingerprintManager manager, CryptoObject cryptoObject) {
        CancellationSignal cancellationSignal = new CancellationSignal();
        if (ActivityCompat.checkSelfPermission(this.context, "android.permission.USE_FINGERPRINT") == 0) {
            manager.authenticate(cryptoObject, cancellationSignal, 0, this, null);
        }
    }

    public void onAuthenticationError(int errMsgId, CharSequence errString) {
        update("Fingerprint Authentication error\n" + errString);
    }

    public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
        update("Fingerprint Authentication help\n" + helpString);
    }

    public void onAuthenticationFailed() {
        update("Fingerprint Authentication failed.");
    }

    public void onAuthenticationSucceeded(AuthenticationResult result) {
        Vault_folder.first_time = true;
        String nn = ((Activity) this.context).getLocalClassName();
        Log.e("class", nn);
        if (nn.equals("Vault_folder")) {
            Vault_folder.lock_rel.setVisibility(View.GONE);
            return;
        }
        LockScreenActivity.lock_status = true;
        ((Activity) this.context).finish();
        this.context.startActivity(new Intent(this.context, Vault_folder.class));
    }

    private void update(String e) {
    }
}
