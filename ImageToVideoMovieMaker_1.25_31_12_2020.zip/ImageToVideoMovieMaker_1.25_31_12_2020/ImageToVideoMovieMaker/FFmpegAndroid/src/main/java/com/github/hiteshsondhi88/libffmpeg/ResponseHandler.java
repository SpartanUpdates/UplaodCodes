package com.github.hiteshsondhi88.libffmpeg;

abstract interface ResponseHandler {


    public void onStart();


    public void onFinish();

}
