package com.kotlinz.videoCollage.flying.poiphoto;

import android.os.Parcel;
import android.os.Parcelable;

import com.kotlinz.videoeditor.R;

public class Configure implements Parcelable {
    public static final Creator<Configure> CREATOR = new Creator<Configure>() {
        public Configure createFromParcel(Parcel parcel) {
            return new Configure(parcel);
        }

        public Configure[] newArray(int i) {
            return new Configure[i];
        }
    };
    private String mAlbumTitle;
    private int mMaxCount;
    private String mMaxNotice;
    private int mNavIcon;
    private String mPhotoTitle;
    private int mStatusBarColor;
    private int mToolbarColor;
    private int mToolbarTitleColor;
    private String mVideoTitle;

    public int describeContents() {
        return 0;
    }

    public Configure() {
        this.mNavIcon = R.drawable.ic_arrow_back_white_24dp;
        this.mAlbumTitle = Define.DEFAULT_ALBUM_TITLE;
        this.mPhotoTitle = Define.DEFAULT_PHOTO_TITLE;
        this.mVideoTitle = Define.DEFAULT_VIDEO_TITLE;
        this.mToolbarColor = 0;
        this.mToolbarTitleColor = -1;
        this.mStatusBarColor = -16777216;
        this.mMaxCount = 10;
        this.mMaxNotice = Define.DEFAULT_MAX_NOTICE;
    }

    protected Configure(Parcel parcel) {
        this.mToolbarColor = parcel.readInt();
        this.mAlbumTitle = parcel.readString();
        this.mPhotoTitle = parcel.readString();
        this.mVideoTitle = parcel.readString();
        this.mToolbarTitleColor = parcel.readInt();
        this.mNavIcon = parcel.readInt();
        this.mStatusBarColor = parcel.readInt();
        this.mMaxCount = parcel.readInt();
        this.mMaxNotice = parcel.readString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.mToolbarColor);
        parcel.writeString(this.mAlbumTitle);
        parcel.writeString(this.mPhotoTitle);
        parcel.writeString(this.mVideoTitle);
        parcel.writeInt(this.mToolbarTitleColor);
        parcel.writeInt(this.mNavIcon);
        parcel.writeInt(this.mStatusBarColor);
        parcel.writeInt(this.mMaxCount);
        parcel.writeString(this.mMaxNotice);
    }

    public String getMaxNotice() {
        return this.mMaxNotice;
    }

    public void setMaxNotice(String str) {
        this.mMaxNotice = str;
    }

    public int getMaxCount() {
        return this.mMaxCount;
    }

    public void setMaxCount(int i) {
        this.mMaxCount = i;
    }

    public int getStatusBarColor() {
        return this.mStatusBarColor;
    }

    public void setStatusBarColor(int i) {
        this.mStatusBarColor = i;
    }

    public int getToolbarColor() {
        return this.mToolbarColor;
    }

    public void setToolbarColor(int i) {
        this.mToolbarColor = i;
    }

    public String getAlbumTitle() {
        return this.mAlbumTitle;
    }

    public void setAlbumTitle(String str) {
        this.mAlbumTitle = str;
    }

    public String getPhotoTitle() {
        return this.mPhotoTitle;
    }

    public void setPhotoTitle(String str) {
        this.mPhotoTitle = str;
    }

    public String getVideoTitle() {
        return this.mVideoTitle;
    }

    public void setVideoTitle(String str) {
        this.mVideoTitle = str;
    }

    public int getToolbarTitleColor() {
        return this.mToolbarTitleColor;
    }

    public void setToolbarTitleColor(int i) {
        this.mToolbarTitleColor = i;
    }

    public int getNavIcon() {
        return this.mNavIcon;
    }

    public void setNavIcon(int i) {
        this.mNavIcon = i;
    }
}
