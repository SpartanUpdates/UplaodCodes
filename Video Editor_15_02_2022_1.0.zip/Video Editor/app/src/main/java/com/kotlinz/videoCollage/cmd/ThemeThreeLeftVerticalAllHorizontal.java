package com.kotlinz.videoCollage.cmd;

import android.util.Log;

import java.util.ArrayList;

public class ThemeThreeLeftVerticalAllHorizontal {
    public static StringBuilder getOrderString(boolean z, ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2, int i) {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2;
        if (z) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale0][scale2] vstack [verti]; [verti]format=rgba, scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[vertical]; [vertical][scale1] hstack [vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else if (arrayList2.size() == 3) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("[scale1]split[scale1_1][scale1_2]; [scale3]split[scale3_1][scale3_2]; [scale5]split[scale5_1][scale5_2]; [scale0][scale5_1] vstack [h1]; [h1]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[h11];[h11][scale3_1] hstack [imgVidCombine1]; [scale1_1][scale5_2] vstack [h2]; [h2]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[h22];[h22][scale2] hstack [imgVidCombine2]; [scale1_2][scale4] vstack [h3]; [h3]format=rgba,scale=-2:");
            stringBuilder2.append(i);
            stringBuilder2.append("[h33];[h33][scale3_2] hstack [imgVidCombine3]; [imgVidCombine1][imgVidCombine2][imgVidCombine3] concat=n=3 [vidCombine];");
            stringBuilder.append(stringBuilder2.toString());
        } else {
            int i2 = 0;
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("stackCount.get(i) :: ");
                stringBuilder3.append(arrayList.get(i3));
                String str = "save";
                Log.e(str, stringBuilder3.toString());
                if (!arrayList2.contains(arrayList.get(i3))) {
                    i2 = ((Integer) arrayList.get(i3)).intValue();
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("IMAGE stackCount.get(i) :: ");
                    stringBuilder3.append(arrayList.get(i3));
                    Log.e(str, stringBuilder3.toString());
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("imagePos :: ");
                    stringBuilder3.append(i2);
                    Log.e(str, stringBuilder3.toString());
                }
            }
            if (i2 == 0) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale0]split[scale0_1][scale0_2];[scale0_1][scale4] vstack [imgVidCombine1]; [imgVidCombine1]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v11];[v11][scale1] hstack=inputs=2 [imgVidCombine2]; [scale0_2][scale3] vstack [imgVidCombine3]; [imgVidCombine3]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v22];[v22][scale2] hstack=inputs=2 [imgVidCombine4];[imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            } else if (i2 == 2) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale2]split[scale2_1][scale2_2]; [scale0][scale4] vstack [imgVidCombine1]; [imgVidCombine1]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v11];[v11][scale2_1] hstack=inputs=2 [imgVidCombine2]; [scale1][scale3] vstack [imgVidCombine3]; [imgVidCombine3]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v22];[v22][scale2_2] hstack=inputs=2 [imgVidCombine4]; [imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("[scale4]split[scale4_1][scale4_2];[scale0][scale4_1] vstack [imgVidCombine1]; [imgVidCombine1]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v11];[v11][scale3] hstack [imgVidCombine2]; [scale1][scale4_2] vstack [imgVidCombine3]; [imgVidCombine3]format=rgba,scale=-2:");
                stringBuilder2.append(i);
                stringBuilder2.append("[v22];[v22][scale2] hstack [imgVidCombine4]; [imgVidCombine2][imgVidCombine4] concat=n=2 [vidCombine];");
                stringBuilder.append(stringBuilder2.toString());
            }
        }
        return stringBuilder;
    }
}
