package com.kotlinz.festivalstorymaker.Utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.RelativeLayout;

public class MagnifierView extends View {
    public static RelativeLayout z;
    public float e = 0.0f;
    public float f = 0.0f;
    public float g = 0.0f;
    public float h = 0.0f;
    public Bitmap i;
    public Activity j;
    public ViewTreeObserver k = null;
    public BitmapShader l;
    public ViewGroup m;
    public int n;
    public int o;
    public int p;
    public int q;
    public float r;
    public float s;
    public int t;
    public int u;
    public float v;
    public Bitmap w;
    public c x;
    public int y;

    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            MagnifierView magnifierView = MagnifierView.this;
            if (magnifierView.i == null) {
                magnifierView.setX((float) magnifierView.n);
                magnifierView = MagnifierView.this;
                magnifierView.setY((float) magnifierView.o);
                magnifierView = MagnifierView.this;
                ViewGroup viewGroup = magnifierView.m;
                viewGroup.setDrawingCacheEnabled(true);
                viewGroup.buildDrawingCache();
                magnifierView.i = viewGroup.getDrawingCache();
                magnifierView = MagnifierView.this;
                Bitmap bitmap = MagnifierView.this.i;
                Shader.TileMode tileMode = Shader.TileMode.MIRROR;
                magnifierView.l = new BitmapShader(bitmap, tileMode, tileMode);
                MagnifierView.this.invalidate();
            }
        }
    }

    public static class b {
        public Context a;
        public int b = 0;
        public int c = 0;
        public int d = 100;
        public int e = 100;
        public float f = 1.5f;
        public float g = 1.5f;
        public int h = 16777215;
        public int i = 100;

        public b(Context context, RelativeLayout relativeLayout) {
            this.a = context;
            MagnifierView.z = relativeLayout;
        }

        public b a(int i) {
            if (i >= 200) {
                this.i = 200;
            } else {
                if (i < 0) {
                    i = 0;
                }
                this.i = i;
            }
            return this;
        }

        public MagnifierView b() {
            return new MagnifierView(this, this.a);
        }

        public b c(int i, int i2) {
            if (i > 0) {
                this.b = i;
            }
            if (i2 > 0) {
                this.c = i2;
            }
            return this;
        }
    }

    public interface c {
        void P(float f);
    }

    public MagnifierView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public MagnifierView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public MagnifierView(b bVar, Context context) {
        super(context);
        Activity activity = (Activity) context;
        this.j = activity;
        this.m = null;
        this.m = (ViewGroup) activity.findViewById(16908290);
        this.q = bVar.e;
        this.p = bVar.d;
        this.r = bVar.f;
        this.s = bVar.g;
        this.t = bVar.h;
        this.u = bVar.i;
        this.n = bVar.b;
        this.o = bVar.c;
        setLayoutParams(new ViewGroup.LayoutParams(this.p + 30, this.q + 30));
        int i = this.q;
        int i2 = this.p;
        this.v = i > i2 ? (float) i2 : (float) i;
    }

    public void a() {
        if (this.j != null && this.m != null && getParent() == null) {
            this.m.addView(this);
            ViewTreeObserver viewTreeObserver = this.m.getViewTreeObserver();
            this.k = viewTreeObserver;
            viewTreeObserver.addOnGlobalLayoutListener(new a());
        }
    }

    public void onDraw(Canvas canvas) {
        if (this.i != null) {
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(Color.parseColor("#ffffff"));
            float f = this.v;
            canvas.drawCircle((f / 2.0f) + 15.0f, (f / 2.0f) + 15.0f, f / 2.0f, paint);
            paint = new Paint();
            paint.setAntiAlias(true);
            paint.setShader(this.l);
            Matrix matrix = new Matrix();
            matrix.setScale(this.r, this.s);
            matrix.postTranslate(-((((this.r - 1.0f) * this.v) / 2.0f) + (getX() * this.r)), -((((this.s - 1.0f) * this.v) / 2.0f) + (getY() * this.s)));
            this.l.setLocalMatrix(matrix);
            f = this.v;
            canvas.drawCircle((f / 2.0f) + 15.0f, (f / 2.0f) + 15.0f, f / 2.0f, paint);
            paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(this.t);
            paint.setAlpha(this.u);
            f = this.v;
            canvas.drawCircle((f / 2.0f) + 15.0f, (f / 2.0f) + 15.0f, f / 2.0f, paint);
            paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(30.0f);
            if (this.w == null) {
                z.setDrawingCacheEnabled(true);
                this.w = Bitmap.createBitmap(z.getDrawingCache());
                z.setDrawingCacheEnabled(false);
            }
            Point point = new Point(canvas.getWidth() / 2, canvas.getHeight() / 2);
            int i = point.x;
            int i2 = i - 16;
            int i3 = point.y;
            Rect rect = new Rect(i2, i3 - 16, i + 16, i3 + 16);
            point = new Point(canvas.getWidth() / 2, canvas.getHeight() / 2);
            i = point.x;
            i2 = i - 15;
            i3 = point.y;
            Rect rect2 = new Rect(i2, i3 - 15, i + 15, i3 + 15);
            try {
                i3 = this.w.getPixel((int) ((this.r / 2.0f) + ((this.v / 2.0f) + getX())), (int) ((this.s / 2.0f) + ((this.v / 2.0f) + getY())));
                this.y = i3;
                paint.setColor(i3);
                canvas.drawCircle((this.v / 2.0f) + 15.0f, (this.v / 2.0f) + 15.0f, (this.v / 2.0f) + 0.2f, paint);
                paint = new Paint();
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.0f);
                paint.setAntiAlias(true);
                paint.setColor(getResources().getColor(17170444));
                canvas.drawRect(rect, paint);
                paint = new Paint();
                paint.setAntiAlias(true);
                paint.setColor(this.y);
                canvas.drawRect(rect2, paint);
            } catch (Exception unused) {
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.e = getX();
            this.f = getY();
            this.g = motionEvent.getRawX();
            this.h = motionEvent.getRawY();
        } else if (action == 1) {
            this.x.P((float) this.y);
            if (!(this.m == null || getParent() == null)) {
                this.m.removeView(this);
            }
        } else if (action == 2) {
            setX((motionEvent.getRawX() - this.g) + this.e);
            setY((motionEvent.getRawY() - this.h) + this.f);
            invalidate();
        }
        return true;
    }

    public void setListner(c cVar) {
        this.x = cVar;
    }

    public void setMagnifierColor(int i) {
        this.t = i;
    }

}
