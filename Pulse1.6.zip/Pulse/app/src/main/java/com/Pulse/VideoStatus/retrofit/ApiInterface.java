package com.Pulse.VideoStatus.retrofit;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @POST("getallthemes")
    @FormUrlEncoded
    Call<JsonObject> GetAllTheme(@Field("token") String token, @Field("application_id") String applicationId);

//    @POST("GetAllSoundCategory")
//    @FormUrlEncoded
//    Call<JsonObject> GetAllSoundCategory(@Field("token") String token, @Field("application_id") String application_id);
//
//    @POST("GetSoundOfCategory")
//    @FormUrlEncoded
//    Call<JsonObject> GetSongByCategory(@Field("token") String token, @Field("application_id") String application_id, @Field("cat_id") String Category_id);
}
