package com.hiddencamera;

import androidx.annotation.NonNull;

import java.io.File;

interface CameraCallbacks {
    void onCameraError(int p0);

    void onImageCapture(@NonNull File p0);
}
