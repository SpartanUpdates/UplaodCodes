package com.esc.phoneheart.utility;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore.Files;

public class MediaStoreUtil {

    public MediaStoreUtil() {
        throw new UnsupportedOperationException();
    }

    public static Uri getUriFromFile(Context context, String str) {
        ContentResolver contentResolver = context.getContentResolver();
        String str2 = "external";
        String str3 = "_id";
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(Files.getContentUri(str2), new String[]{str3}, "_data = ?", new String[]{str}, "date_added desc");
        if (query == null) {
            return null;
        }
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(Files.getContentUri(str2), contentValues);
        }
        Uri build = Files.getContentUri(str2).buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex(str3)))).build();
        query.close();
        return build;
    }
}
