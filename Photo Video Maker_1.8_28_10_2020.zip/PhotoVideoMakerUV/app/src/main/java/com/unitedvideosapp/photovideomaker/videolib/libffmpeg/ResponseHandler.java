package com.unitedvideosapp.photovideomaker.videolib.libffmpeg;

interface ResponseHandler {
    void onFinish();

    void onStart();
}
