package com.esc.socialmediacleaner.activity;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.adapter.HomeGridAdapter;
import com.esc.socialmediacleaner.datastructure.AllData;
import com.esc.socialmediacleaner.datastructure.FetchData;
import com.esc.socialmediacleaner.datastructure.MediaType;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.pref.EPreferences;
import com.esc.socialmediacleaner.util.DetermineTextSize;
import com.esc.socialmediacleaner.util.PermitionActivity;
import com.esc.socialmediacleaner.util.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HomeScreen extends PermitionActivity implements OnClickListener {
    LinearLayout audLayout;
    private int deviceHeight;
    LinearLayout docLayout;
    LinearLayout gifLayout;
    private Handler handler;
    private View hiddenPermissionLayout;
    LinearLayout imgLayout;
    private boolean isExecuting = false;
    private long lastClickedTime = 0;
    private ImageView refresh_home;
    private volatile boolean stopScrolling = false;
    TextView tvAud;
    private TextView tvAudTitle;
    private TextView tvAudTitleMain;
    TextView tvCount;
    TextView tvDoc;
    private TextView tvDocTitle;
    private TextView tvDocTitleMain;
    TextView tvGif;
    private TextView tvGifTitle;
    private TextView tvGifTitleMain;
    TextView tvImg;
    private TextView tvImgTitle;
    private TextView tvImgTitleMain;
    TextView tvSize;
    TextView tvVid;
    private TextView tvVidTitle;
    private TextView tvVidTitleMain;
    TextView tv_view_result;
    LinearLayout vidLayout;

    public void onResume() {
        super.onResume();
        if (MyApplication.getInstance().allData != null && MyApplication.getInstance().allData.dataDeleted) {
            this.imgLayout.setOnClickListener(null);
            this.vidLayout.setOnClickListener(null);
            this.audLayout.setOnClickListener(null);
            this.gifLayout.setOnClickListener(null);
            this.docLayout.setOnClickListener(null);
            this.refresh_home.setOnClickListener(null);
            findViewById(R.id.settings_home).setOnClickListener(null);
            fetchData();
            MyApplication.getInstance().allData.dataDeleted = false;
        }
        if (permissionGranted()) {
            View view = this.hiddenPermissionLayout;
            if (view != null && view.getVisibility() == View.VISIBLE) {
                this.hiddenPermissionLayout.setVisibility(View.GONE);
                fetchData();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home_screen);
        this.ePreferences = EPreferences.getInstance((Context) this);
        init();
//        fontSize();
        if (permissionGranted()) {
            fetchData();
        } else {
            new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                public void run() {
                    HomeScreen.this.requestAppPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, R.string.permission_grant, 3000);
                }
            }, 100);
        }
    }

    private Drawable getADrawable(int i) {
        if (VERSION.SDK_INT >= 21) {
            return getResources().getDrawable(i, getTheme());
        }
        return getResources().getDrawable(i);
    }

    private void fetchData() {
        getHomeGridItems();
        new FetchData() {
            public void onPreExecute() {
                super.onPreExecute();
                HomeScreen.this.isExecuting = true;
                HomeScreen.this.tvImg.setVisibility(View.GONE);
                HomeScreen.this.tvDoc.setVisibility(View.GONE);
                HomeScreen.this.tvGif.setVisibility(View.GONE);
                HomeScreen.this.tvVid.setVisibility(View.GONE);
                HomeScreen.this.tvAud.setVisibility(View.GONE);
                HomeScreen.this.tvSize.setVisibility(View.GONE);
                String str = "";
                HomeScreen.this.tvImgTitle.setText(str);
                HomeScreen.this.tvDocTitle.setText(str);
                HomeScreen.this.tvGifTitle.setText(str);
                HomeScreen.this.tvVidTitle.setText(str);
                HomeScreen.this.tvAudTitle.setText(str);
                ValueAnimator valueAnimator = new ValueAnimator();
                valueAnimator.setObjectValues(new Object[]{Integer.valueOf(0), Integer.valueOf(1000)});
                valueAnimator.addUpdateListener(new AnimatorUpdateListener() {
                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        HomeScreen.this.tvCount.setText(String.valueOf(valueAnimator.getAnimatedValue()));
                    }
                });
                valueAnimator.setEvaluator(new TypeEvaluator<Integer>() {
                    public Integer evaluate(float f, Integer num, Integer num2) {
                        return Integer.valueOf(Math.round(((float) (num2.intValue() - num.intValue())) * f));
                    }
                });
                valueAnimator.addListener(new AnimatorListener() {
                    public void onAnimationCancel(Animator animator) {
                    }

                    public void onAnimationRepeat(Animator animator) {
                    }

                    public void onAnimationStart(Animator animator) {
                    }

                    public void onAnimationEnd(Animator animator) {
                        try {
                            TextView textView;
                            StringBuilder stringBuilder;
                            HomeScreen.this.tvSize.setVisibility(View.VISIBLE);
                            AllData allData = MyApplication.getInstance().allData;
                            String str = ")";
                            String str2 = "(";
                            String str3 = " ";
                            String str4 = "";
                            if (allData.imgSize == 0) {
                                HomeScreen.this.tvImg.setText(str4);
                                HomeScreen.this.tvImgTitleMain.setText(HomeScreen.this.getString(R.string.noimages));
                            } else {
                                HomeScreen.this.tvImg.setVisibility(View.VISIBLE);
                                textView = HomeScreen.this.tvImg;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(HomeScreen.this.getString(R.string.save));
                                stringBuilder.append(str3);
                                stringBuilder.append(Util.convertBytes(allData.imgSize));
                                textView.setText(stringBuilder.toString());
                                textView = HomeScreen.this.tvImgTitle;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(str2);
                                stringBuilder.append(allData.imgList.size());
                                stringBuilder.append(str);
                                textView.setText(stringBuilder.toString());
                                HomeScreen.this.tvImgTitleMain.setText(HomeScreen.this.getString(R.string.str_images));
                            }
                            if (allData.vidSize == 0) {
                                HomeScreen.this.tvVid.setText(str4);
                                HomeScreen.this.tvVidTitleMain.setText(HomeScreen.this.getString(R.string.novideos));
                            } else {
                                HomeScreen.this.tvVid.setVisibility(View.VISIBLE);
                                textView = HomeScreen.this.tvVid;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(HomeScreen.this.getString(R.string.save));
                                stringBuilder.append(str3);
                                stringBuilder.append(Util.convertBytes(allData.vidSize));
                                textView.setText(stringBuilder.toString());
                                textView = HomeScreen.this.tvVidTitle;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(str2);
                                stringBuilder.append(allData.vidList.size());
                                stringBuilder.append(str);
                                textView.setText(stringBuilder.toString());
                                HomeScreen.this.tvVidTitleMain.setText(HomeScreen.this.getString(R.string.str_videos));
                            }
                            if (allData.docSize == 0) {
                                HomeScreen.this.tvDoc.setText(str4);
                                HomeScreen.this.tvDocTitleMain.setText(HomeScreen.this.getString(R.string.nodocs));
                            } else {
                                HomeScreen.this.tvDoc.setVisibility(View.VISIBLE);
                                textView = HomeScreen.this.tvDoc;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(HomeScreen.this.getString(R.string.save));
                                stringBuilder.append(str3);
                                stringBuilder.append(Util.convertBytes(allData.docSize));
                                textView.setText(stringBuilder.toString());
                                textView = HomeScreen.this.tvDocTitle;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(str2);
                                stringBuilder.append(allData.docList.size());
                                stringBuilder.append(str);
                                textView.setText(stringBuilder.toString());
                                HomeScreen.this.tvDocTitleMain.setText(HomeScreen.this.getString(R.string.str_docs));
                            }
                            if (allData.gifSize == 0) {
                                HomeScreen.this.tvGif.setText(str4);
                                HomeScreen.this.tvGifTitleMain.setText(HomeScreen.this.getString(R.string.nogifs));
                            } else {
                                HomeScreen.this.tvGif.setVisibility(View.VISIBLE);
                                textView = HomeScreen.this.tvGif;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(HomeScreen.this.getString(R.string.save));
                                stringBuilder.append(str3);
                                stringBuilder.append(Util.convertBytes(allData.gifSize));
                                textView.setText(stringBuilder.toString());
                                textView = HomeScreen.this.tvGifTitle;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(str2);
                                stringBuilder.append(allData.gifList.size());
                                stringBuilder.append(str);
                                textView.setText(stringBuilder.toString());
                                HomeScreen.this.tvGifTitleMain.setText(HomeScreen.this.getString(R.string.str_gif));
                            }
                            if (allData.audSize == 0) {
                                HomeScreen.this.tvAud.setText(str4);
                                HomeScreen.this.tvAudTitleMain.setText(HomeScreen.this.getString(R.string.noaud));
                            } else {
                                HomeScreen.this.tvAud.setVisibility(View.VISIBLE);
                                textView = HomeScreen.this.tvAud;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(HomeScreen.this.getString(R.string.save));
                                stringBuilder.append(str3);
                                stringBuilder.append(Util.convertBytes(allData.audSize));
                                textView.setText(stringBuilder.toString());
                                textView = HomeScreen.this.tvAudTitle;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append(str2);
                                stringBuilder.append(allData.audList.size());
                                stringBuilder.append(str);
                                textView.setText(stringBuilder.toString());
                                HomeScreen.this.tvAudTitleMain.setText(HomeScreen.this.getString(R.string.str_audio));
                            }
                            TextView textView2 = HomeScreen.this.tvCount;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str4);
                            stringBuilder2.append(MyApplication.getInstance().allData.totFiles);
                            textView2.setText(stringBuilder2.toString());
                            textView2 = HomeScreen.this.tvSize;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(HomeScreen.this.getString(R.string.save));
                            stringBuilder2.append(str3);
                            stringBuilder2.append(Util.convertBytes(MyApplication.getInstance().allData.totSize));
                            textView2.setText(stringBuilder2.toString());
                            HomeScreen.this.setListners();
                            HomeScreen.this.stopScrolling = true;
                            if (!MyApplication.getInstance().view_enlarged && MyApplication.getInstance().allData.totFiles > 0) {
                                HomeScreen.this.tv_view_result.setVisibility(View.VISIBLE);
                                MyApplication.getInstance().view_enlarged = true;
                            }
                            HomeScreen.this.findViewById(R.id.layout_bottom).setVisibility(View.VISIBLE);
                            HomeScreen.this.isExecuting = false;
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                valueAnimator.setDuration(5000);
                valueAnimator.start();
            }

            public void onPostExecute(String str) {
                super.onPostExecute(str);
                try {
                    HomeScreen.this.stopScrolling = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[0]);
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    private void getHomeGridItems() {
        final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.home_grid);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        ArrayList rawPics = FetchData.getRawPics(this);
        if (rawPics.size() >= 30) {
            findViewById(R.id.layout_top).setBackground(null);
            recyclerView.setAdapter(new HomeGridAdapter(this, rawPics));
            try {
                Handler handler = new Handler(Looper.myLooper());
                this.handler = handler;
                handler.postDelayed(new Runnable() {
                    public void run() {
                        try {
                            if (HomeScreen.this.stopScrolling) {
                                HomeScreen.this.handler.sendEmptyMessage(0);
                                return;
                            }
                            recyclerView.scrollBy(10, 10);
                            HomeScreen.this.handler.postDelayed(this, 50);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, 50);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void setListners() {
        this.imgLayout.setOnClickListener(this);
        this.vidLayout.setOnClickListener(this);
        this.audLayout.setOnClickListener(this);
        this.gifLayout.setOnClickListener(this);
        this.docLayout.setOnClickListener(this);
        this.refresh_home.setOnClickListener(this);
        findViewById(R.id.settings_home).setOnClickListener(this);
        findViewById(R.id.tv_view_result).setOnClickListener(this);
    }

    private void init() {
        this.tvImg = (TextView) findViewById(R.id.tv_img_size);
        this.tvAud = (TextView) findViewById(R.id.tv_aud_size);
        this.tvVid = (TextView) findViewById(R.id.tv_vid_size);
        this.tvGif = (TextView) findViewById(R.id.tv_gif_size);
        this.tvDoc = (TextView) findViewById(R.id.tv_doc_size);
        this.tvImgTitle = (TextView) findViewById(R.id.tv_img);
        this.tvAudTitle = (TextView) findViewById(R.id.tv_aud);
        this.tvVidTitle = (TextView) findViewById(R.id.tv_vid);
        this.tvGifTitle = (TextView) findViewById(R.id.tv_gif);
        this.tvDocTitle = (TextView) findViewById(R.id.tv_doc);
        this.tvImgTitleMain = (TextView) findViewById(R.id.tv_img_title);
        this.tvAudTitleMain = (TextView) findViewById(R.id.tv_aud_title);
        this.tvVidTitleMain = (TextView) findViewById(R.id.tv_vid_title);
        this.tvGifTitleMain = (TextView) findViewById(R.id.tv_gif_title);
        this.tvDocTitleMain = (TextView) findViewById(R.id.tv_doc_title);
        this.tvCount = (TextView) findViewById(R.id.tv_count);
        this.tvSize = (TextView) findViewById(R.id.tv_size);
        this.tv_view_result = (TextView) findViewById(R.id.tv_view_result);
        this.imgLayout = (LinearLayout) findViewById(R.id.layout_img);
        this.vidLayout = (LinearLayout) findViewById(R.id.layout_vid);
        this.audLayout = (LinearLayout) findViewById(R.id.layout_aud);
        this.gifLayout = (LinearLayout) findViewById(R.id.layout_gif);
        this.docLayout = (LinearLayout) findViewById(R.id.layout_doc);
        this.hiddenPermissionLayout = findViewById(R.id.hiddenpermissionlayout);
        this.refresh_home = (ImageView) findViewById(R.id.refresh_home);
    }

    public void onClick(View view) {
        MyApplication.getInstance().allData.redirectHome = false;
        AllData allData = MyApplication.getInstance().allData;
        String str = "TYPE";
        Intent intent;
        switch (view.getId()) {
            case R.id.layout_aud:
                if (!doubleClicked()) {
                    MyApplication.getInstance().allData.total_filetype = allData.audList.size();
                    if (allData.audList.size() != 0) {
                        intent = new Intent(this, FileTabsScreen.class);
                        intent.putExtra(str, MediaType.AUDIOS.ordinal());
                        startActivity(intent);
                        return;
                    }
                }
                break;
            case R.id.layout_doc:
                if (!doubleClicked()) {
                    MyApplication.getInstance().allData.total_filetype = allData.docList.size();
                    if (allData.docList.size() != 0) {
                        intent = new Intent(this, FileTabsScreen.class);
                        intent.putExtra(str, MediaType.DOCUMENTS.ordinal());
                        startActivity(intent);
                        return;
                    }
                }
                break;
            case R.id.layout_gif :
                if (!doubleClicked()) {
                    MyApplication.getInstance().allData.total_filetype = allData.gifList.size();
                    if (allData.gifList.size() != 0) {
                        intent = new Intent(this, FileTabsScreen.class);
                        intent.putExtra(str, MediaType.GIFS.ordinal());
                        startActivity(intent);
                        return;
                    }
                }
                break;
            case R.id.layout_img:
                if (!doubleClicked()) {
                    MyApplication.getInstance().allData.total_filetype = allData.imgList.size();
                    if (allData.imgList.size() != 0) {
                        intent = new Intent(this, FileTabsScreen.class);
                        intent.putExtra(str, MediaType.IMAGES.ordinal());
                        startActivity(intent);
                        return;
                    }
                }
                break;
            case R.id.layout_vid:
                if (!doubleClicked()) {
                    MyApplication.getInstance().allData.total_filetype = allData.vidList.size();
                    if (allData.vidList.size() != 0) {
                        intent = new Intent(this, FileTabsScreen.class);
                        intent.putExtra(str, MediaType.VIDEOS.ordinal());
                        startActivity(intent);
                        return;
                    }
                }
                break;
            case R.id.refresh_home:
                if (!(doubleClicked() || this.isExecuting)) {
                    fetchData();
                    break;
                }
            case R.id.settings_home:
                if (!doubleClicked()) {
                    startActivity(new Intent(this, AboutUsScreen.class));
                    return;
                }
                return;
            case R.id.tv_view_result:
                if (!doubleClicked()) {
                    view.setVisibility(View.GONE);
                    LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layout_bottom);
                    LayoutParams layoutParams = (LayoutParams) linearLayout.getLayoutParams();
                    layoutParams.height = -1;
                    linearLayout.setLayoutParams(layoutParams);
                    return;
                }
                break;
        }
    }

    public void onPause() {
        super.onPause();
        Handler handler = this.handler;
        if (handler != null) {
            handler.sendEmptyMessage(0);
            this.handler = null;
        }
    }

    public void onPermissionsGranted(int i) {
        View view = this.hiddenPermissionLayout;
        if (view != null) {
            view.setVisibility(View.GONE);
            fetchData();
        }
    }

    private boolean permissionGranted() {
        return ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    private UnifiedNativeAd nativeAd;
    private EPreferences ePreferences;

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(HomeScreen.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startActivity(new Intent(HomeScreen.this, BackActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }


    public void ExitDialog() {
        final Dialog dialog = new Dialog(HomeScreen.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeScreen.this, BackActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    protected void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }
}
