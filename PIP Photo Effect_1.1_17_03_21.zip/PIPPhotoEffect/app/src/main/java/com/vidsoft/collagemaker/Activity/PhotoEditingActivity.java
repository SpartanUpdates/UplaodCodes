package com.vidsoft.collagemaker.Activity;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.vidsoft.collagemaker.Adapters.FilterAdapter;
import com.vidsoft.collagemaker.Adapters.FilterAdapter.FilterCallback;
import com.vidsoft.collagemaker.Model.Filter;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.CompressImage;
import com.vidsoft.collagemaker.Utils.Const;
import com.vidsoft.collagemaker.Utils.DataBinder;
import com.vidsoft.collagemaker.Utils.SaveImage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import jp.co.cyberagent.android.gpuimage.GPUImage.ScaleType;
import jp.co.cyberagent.android.gpuimage.GPUImageBrightnessFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageContrastFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageGaussianBlurFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHueFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSaturationFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageView;
import jp.co.cyberagent.android.gpuimage.GPUImageView.OnPictureSavedListener;
import me.zhanghai.android.materialprogressbar.BuildConfig;

public class PhotoEditingActivity extends AppCompatActivity implements FilterCallback, OnSeekBarChangeListener, OnPictureSavedListener {
    Activity activity;
    LinearLayout llBrightness;
    SeekBar seekbarBrightness;
    LinearLayout llContrast;
    SeekBar contrastSeekbar;
    float end;
    String filename;
    FilterAdapter filterAdapter;
    ArrayList<Filter> filterArrayList;
    LinearLayout ll_filter;
    String str_finalPath;
    String folder;
    float start;
    TextView tvbrightness;
    TextView tvContrast;
    TextView tvSaturation;
    TextView tvSharp;
    TextView tvVignette;
    float value;
    GPUImageView gpuImageView;
    ImageView ivBrightness;
    ImageView ivContrast;
    ImageView ivFilter;
    ImageView ivSaturation;
    ImageView ivSharp;
    ImageView ivVignette;
    LinearLayoutManager linearLayoutManager;
    RecyclerView rcFilter;
    LinearLayout llSaturation;
    SeekBar seekbarSaturation;
    LinearLayout llSharp;
    SeekBar seekbarSharp;
    LinearLayout llVignettelayout;
    SeekBar seekbarVignette;

    private AdView adView;

    public PhotoEditingActivity() {
        this.activity = this;
        this.filterArrayList = new ArrayList();
        this.folder = BuildConfig.FLAVOR;
        this.str_finalPath = BuildConfig.FLAVOR;
        this.filename = BuildConfig.FLAVOR;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_photo_edit);
        bindToolbar();
        bindControls();
        loadAd();
        initView();
        fetchFilterData();
    }

    private void initView() {
        Const.editedImagePath = getIntent().getExtras().getString(Const.editedImg);
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(Const.editedImagePath, options);
        int imageHeight = options.outHeight;
        int imageWidth = options.outWidth;
        if (imageHeight > 1000 && imageWidth > 1000 && imageHeight < 2000 && imageWidth < 2000) {
            imageHeight /= 2;
            imageWidth /= 2;
        } else if (imageHeight > 2000 || imageWidth > 2000) {
            if (imageHeight < 3000 || imageWidth < 3000) {
                imageHeight /= 3;
                imageWidth /= 3;
            } else if (imageHeight > 3000 || imageWidth > 3000) {
                if (imageHeight < 4000 || imageWidth < 4000) {
                    imageHeight /= 4;
                    imageWidth /= 4;
                } else if (imageHeight > 4000 || imageWidth > 4000) {
                    imageHeight /= 5;
                    imageWidth /= 5;
                }
            }
        } else if (imageHeight > 1000 || imageWidth > 1000) {
            imageHeight = (int) (((double) imageHeight) / 1.6d);
            imageWidth = (int) (((double) imageWidth) / 1.6d);
        }
        LayoutParams layoutParams = new LayoutParams(imageWidth, imageHeight);
        layoutParams.gravity = Gravity.CENTER;
        this.gpuImageView.setLayoutParams(layoutParams);
        this.gpuImageView.setImage(CompressImage.originalBitmap(BitmapFactory.decodeFile(Const.editedImagePath)));
        changeColor(Const.selectedColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor);
        changeVisibility(Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
    }

    private void loadAd() {
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private void fetchFilterData() {
        this.filterArrayList.clear();
        this.filterArrayList = DataBinder.fetchFilters();
        this.filterAdapter = new FilterAdapter(this.activity, this.filterArrayList);
        this.rcFilter.setAdapter(this.filterAdapter);
    }

    private void bindControls() {
        this.rcFilter = findViewById(R.id.rc_ViewFilter);
        this.linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rcFilter.setLayoutManager(this.linearLayoutManager);
        this.gpuImageView = findViewById(R.id.imageView);
        this.gpuImageView.setScaleType(ScaleType.CENTER_CROP);
        this.ivFilter = findViewById(R.id.imgFilter);
        this.ivBrightness = findViewById(R.id.imgBrightness);
        this.ivContrast = findViewById(R.id.imgContrast);
        this.ivVignette = findViewById(R.id.imgVignette);
        this.ivSaturation = findViewById(R.id.imgSaturation);
        this.ivSharp = findViewById(R.id.imgSharp);
        this.ll_filter = findViewById(R.id.ll_filterLayout);
        this.llBrightness = findViewById(R.id.brightnessLayout);
        this.llContrast = findViewById(R.id.contrastLayout);
        this.llVignettelayout = findViewById(R.id.blrLayout);
        this.llSaturation = findViewById(R.id.saturationLayout);
        this.llSharp = findViewById(R.id.ll_sharp);
        this.tvbrightness = findViewById(R.id.txtBrightness);
        this.tvContrast = findViewById(R.id.txtContrast);
        this.tvVignette = findViewById(R.id.txtVignette);
        this.tvSaturation = findViewById(R.id.tvSaturation);
        this.tvSharp = findViewById(R.id.tvSharp);
        this.seekbarBrightness = findViewById(R.id.brightnessSeekbar);
        this.contrastSeekbar = findViewById(R.id.contrastSeekbar);
        this.seekbarVignette = findViewById(R.id.vignetteSeekbar);
        this.seekbarSaturation = findViewById(R.id.saturation_Seekbar);
        this.seekbarSharp = findViewById(R.id.sharpSeekbar);
        this.seekbarBrightness.setOnSeekBarChangeListener(this);
        this.contrastSeekbar.setOnSeekBarChangeListener(this);
        this.seekbarVignette.setOnSeekBarChangeListener(this);
        this.seekbarSaturation.setOnSeekBarChangeListener(this);
        this.seekbarSharp.setOnSeekBarChangeListener(this);
    }

    private void bindToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_btn_selector);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(getResources().getString(R.string.PhotoEditingActivity_Title));
    }

    public void btnFilter(View view) {
        changeColor(Const.selectedColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor);
        changeVisibility(Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
    }

    public void btnBrightness(View view) {
        changeColor(Const.normalColor, Const.selectedColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor);
        changeVisibility(Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
    }

    public void btnContrast(View view) {
        changeColor(Const.normalColor, Const.normalColor, Const.selectedColor, Const.normalColor, Const.normalColor, Const.normalColor);
        changeVisibility(Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
    }

    public void btnVignette(View view) {
        changeColor(Const.normalColor, Const.normalColor, Const.normalColor, Const.selectedColor, Const.normalColor, Const.normalColor);
        changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout);
    }

    public void btnSaturation(View view) {
        changeColor(Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.selectedColor, Const.normalColor);
        changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout);
    }

    public void btnSharp(View view) {
        changeColor(Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.normalColor, Const.selectedColor);
        changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout);
    }

    public void changeColor(int filter, int brightness, int contrast, int vignette, int saturation, int sharp) {
        this.ivFilter.setColorFilter(ContextCompat.getColor(getApplicationContext(), filter));
        this.ivBrightness.setColorFilter(ContextCompat.getColor(getApplicationContext(), brightness));
        this.ivContrast.setColorFilter(ContextCompat.getColor(getApplicationContext(), contrast));
        this.ivVignette.setColorFilter(ContextCompat.getColor(getApplicationContext(), vignette));
        this.ivSaturation.setColorFilter(ContextCompat.getColor(getApplicationContext(), saturation));
        this.ivSharp.setColorFilter(ContextCompat.getColor(getApplicationContext(), sharp));
    }

    public void changeVisibility(int filter, int brightness, int contrast, int vignette, int saturation, int sharp) {
        this.ll_filter.setVisibility(filter);
        this.llBrightness.setVisibility(brightness);
        this.llContrast.setVisibility(contrast);
        this.llVignettelayout.setVisibility(vignette);
        this.llSaturation.setVisibility(saturation);
        this.llSharp.setVisibility(sharp);
    }

    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
        switch (seekBar.getId()) {
            case R.id.brightnessSeekbar:
                this.start = -0.5f;
                this.end = 0.5f;
                this.value = (((this.end - this.start) * ((float) progress)) / 100.0f) + this.start;
                this.gpuImageView.setFilter(new GPUImageBrightnessFilter(this.value));
                this.tvbrightness.setText(String.valueOf(progress));
                break;
            case R.id.vignetteSeekbar:
                this.start = 0.0f;
                this.end = 1.0f;
                this.value = (((this.end - this.start) * ((float) progress)) / 100.0f) + this.start;
                this.gpuImageView.setFilter(new GPUImageGaussianBlurFilter(this.value));
                this.tvVignette.setText(String.valueOf(progress));
                break;
            case R.id.contrastSeekbar:
                this.start = CompressImage.BITMAP_SCALE;
                this.end = 2.0f;
                this.value = (((this.end - this.start) * ((float) progress)) / 100.0f) + this.start;
                this.gpuImageView.setFilter(new GPUImageContrastFilter(this.value));
                this.tvContrast.setText(String.valueOf(progress));
                break;
            case R.id.saturation_Seekbar:
                this.start = 0.0f;
                this.end = 2.0f;
                this.value = (((this.end - this.start) * ((float) progress)) / 100.0f) + this.start;
                this.gpuImageView.setFilter(new GPUImageSaturationFilter(this.value));
                this.tvSaturation.setText(String.valueOf(progress));
                break;
            case R.id.sharpSeekbar:
                this.start = 0.0f;
                this.end = 360.0f;
                this.value = (((this.end - this.start) * ((float) progress)) / 100.0f) + this.start;
                this.gpuImageView.setFilter(new GPUImageHueFilter(this.value));
                this.tvSharp.setText(String.valueOf(progress));
                break;
            default:
                break;
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    public void FilterMethod(int position) {
        this.gpuImageView.setFilter(DataBinder.applyFilter(position, this.activity));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_done, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                onBackPressed();
                return true;
            case R.id.menu_done:
                File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                this.folder = "temp";
                this.filename = System.currentTimeMillis() + ".jpg";
                this.str_finalPath = String.valueOf(new File(path, this.folder + "/" + this.filename));
                this.gpuImageView.saveToPictures(this.folder, this.filename, this);
                return true;
            default:
                return false;
        }
    }

    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
        super.onBackPressed();
    }

    public void onPictureSaved(Uri uri) {
        File from = new File(this.str_finalPath);
        File to = new File(getBaseContext().getCacheDir(), "temp/" + System.currentTimeMillis() + ".jpg");
        to.getParentFile().mkdirs();
        try {
            SaveImage.copyDirectoryOneLocationToAnotherLocation(from, to);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (from.exists()) {
            SaveImage.deleteFileFromMediaStore(getContentResolver(), from);
        }
        Const.editedImagePath = String.valueOf(to);
        setResult(-1);
        finish();
        overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
    }
}