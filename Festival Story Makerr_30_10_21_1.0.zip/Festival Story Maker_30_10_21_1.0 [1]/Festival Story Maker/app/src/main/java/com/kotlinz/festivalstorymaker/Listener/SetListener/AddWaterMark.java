package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class AddWaterMark implements View.OnLongClickListener
{
    public final  FrameLayout e;
    public final  ImageView f;
    public final CanvasEditorActivity g;

    public AddWaterMark(final CanvasEditorActivity g, final FrameLayout e, final ImageView f) {
        this.g = g;
        this.e = e;
        this.f = f;
    }

    public boolean onLongClick(final View view) {
        final CanvasEditorActivity g = this.g;
        g.X0 = true;
        g.w0();
        final CanvasEditorActivity g2 = this.g;
        g2.b0 = this.e;
        CanvasEditorActivity.I1 = this.f;
        g2.B0(true);
        return false;
    }
}
