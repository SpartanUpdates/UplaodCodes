package com.kotlinz.videoCollage.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class GridVideoView extends RelativeLayout {
    public GridVideoView(Context context) {
        super(context);
    }

    public GridVideoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public GridVideoView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }
}
