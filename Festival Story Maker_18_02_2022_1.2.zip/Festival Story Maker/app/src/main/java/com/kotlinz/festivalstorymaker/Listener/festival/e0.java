package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;

import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.f0;

public class e0 implements View.OnClickListener {
    public final f0 n;

    public e0(f0 f0Var) {
        this.n = f0Var;
    }

    public void onClick(View view) {
        f0 f0Var = this.n;
        f0Var.s.j(true, f0Var.t, f0Var.r, 0);
    }

}
