package com.esc.photovault.pref;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;


public class SharedPreference {

    private static SharedPreferences prefs;

    public static void storeSecurity(Context context, String key, String value) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = context.getSharedPreferences(key, Context.MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getSecurity(Context context, String key) {
        prefs = context.getSharedPreferences(key, Context.MODE_PRIVATE);
        String restoredText = prefs.getString(key, "0000");
        return restoredText;
    }

    //Store Password
    public static void storePassword(Context context, String key, String value) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = context.getSharedPreferences(key, Context.MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getPassword(Context context, String key) {
        prefs = context.getSharedPreferences(key, Context.MODE_PRIVATE);
        String restoredText = prefs.getString(key, "");
        return restoredText;
    }

    public static void clearData(Context context, String key) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(key);
        editor.apply();
    }

    public static void storeFirstTime(Context context, String key, boolean value) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = context.getSharedPreferences(key, Context.MODE_PRIVATE).edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static boolean getFirstTime(Context context, String key) {
        prefs = context.getSharedPreferences(key, Context.MODE_PRIVATE);
        boolean restoredText = prefs.getBoolean(key, true);
        return restoredText;
    }

    public static void setValue(Context context, String key, String value) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = context.getSharedPreferences(key, Context.MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getValue(Context context, String key) {
        prefs = context.getSharedPreferences(key, Context.MODE_PRIVATE);
        String restoredText = prefs.getString(key, "");
        return restoredText;
    }

}
