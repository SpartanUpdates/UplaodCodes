package com.esc.phoneheart.activity;

import android.Manifest;
import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore.Files;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.esc.phoneheart.R;
import com.esc.phoneheart.duplicatefiles.DupFileHomeScreen;
import com.esc.phoneheart.duplicatefiles.DuplicateFileMediaData;
import com.esc.phoneheart.duplicatefiles.DuplicateFilesData;
import com.esc.phoneheart.promo.ParentScreen;
import com.esc.phoneheart.adapter.SectionsPagerAdapter;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

public class DupFileScanScreen extends ParentScreen {
    public TextView boostsize;
    public ImageView[] imageViews;
    public boolean isAborted = false;
    public ImageView iv_fb;
    public ImageView iv_google;
    public ImageView iv_yahoo;
    public ImageView iv_youtube;
    public ArrayList<String> l = new ArrayList();
    public HashMap<String, ArrayList<BigSizeFilesWrapper>> m = new HashMap();
    public HashMap<Long, ArrayList<String>> n = new HashMap();
    public ProgressBar o;
    public ArrayList<ObjectAnimator> p = new ArrayList();
    public int[] q = new int[]{R.drawable.ic_documents, R.drawable.ic_audio, R.drawable.ic_video, R.drawable.ic_documents, R.drawable.ic_photo, R.drawable.ic_phone};

    private void animate() {
        ImageView imageView = (ImageView) findViewById(R.id.img_rotate);
        ImageView imageView2 = (ImageView) findViewById(R.id.img_still);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.layoutimg_media);
        setDeviceDimensio();
        LayoutParams layoutParams = (LayoutParams) imageView.getLayoutParams();
        layoutParams.width = (getWidth() * 65) / 100;
        layoutParams.height = (getWidth() * 65) / 100;
        imageView.setLayoutParams(layoutParams);
        layoutParams = (LayoutParams) imageView2.getLayoutParams();
        layoutParams.width = (getWidth() * 60) / 100;
        layoutParams.height = (getWidth() * 60) / 100;
        imageView2.setLayoutParams(layoutParams);
        LayoutParams layoutParams2 = (LayoutParams) relativeLayout.getLayoutParams();
        layoutParams2.width = (getWidth() * 40) / 100;
        layoutParams2.height = (getWidth() * 40) / 100;
        relativeLayout.setLayoutParams(layoutParams2);
        imageView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotation));
        appScanningAnimation();
    }

    private void appScanningAnimation() {
        clearAnimation();
        for (final ImageView imageView : this.imageViews) {
            imageView.setImageResource(getRandomInstalledApp());
            fadeInOutAnimApps(imageView, new AnimatorListener() {
                public void onAnimationCancel(Animator animator) {
                }

                public void onAnimationEnd(Animator animator) {
                }

                public void onAnimationRepeat(Animator animator) {
                    if (((double) imageView.getAlpha()) < 0.1d) {
                        imageView.setImageResource(DupFileScanScreen.this.getRandomInstalledApp());
                    }
                }

                public void onAnimationStart(Animator animator) {
                }
            });
        }
    }

    private void clearAnimation() {
        Iterator it = this.p.iterator();
        while (it.hasNext()) {
            ObjectAnimator objectAnimator = (ObjectAnimator) it.next();
            if (objectAnimator.isRunning()) {
                objectAnimator.cancel();
            }
        }
    }

    private void fadeInOutAnimApps(ImageView imageView, @Nullable AnimatorListener animatorListener) {
        imageView.setAnimation(null);
        int nextInt = new Random().nextInt(1300) + 700;
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(imageView, View.ALPHA, new float[]{0.0f, 1.0f});
        ofFloat.setDuration((long) nextInt);
        ofFloat.setRepeatMode(ValueAnimator.REVERSE);
        ofFloat.setRepeatCount(-1);
        if (animatorListener != null) {
            ofFloat.addListener(animatorListener);
        }
        ofFloat.start();
        this.p.add(ofFloat);
    }

    private int getRandomInstalledApp() {
        return this.q[new Random().nextInt(this.q.length)];
    }

    private void initToolbar() {
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle((CharSequence) "");
        }
        if (getIntent().getBooleanExtra("TITLE", false)) {
            ((TextView) findViewById(R.id.toolbar_title)).setText(getString(R.string.app_name));
        }
    }

    private void initializeViews() {
        this.iv_fb = (ImageView) findViewById(R.id.iv_fb);
        this.iv_google = (ImageView) findViewById(R.id.iv_google);
        this.iv_yahoo = (ImageView) findViewById(R.id.iv_yahoo);
        ImageView imageView = (ImageView) findViewById(R.id.iv_youtube);
        this.iv_youtube = imageView;
        ImageView imageView2 = this.iv_fb;
        this.imageViews = new ImageView[]{imageView2, this.iv_google, this.iv_yahoo, imageView};
        LayoutParams layoutParams = (LayoutParams) imageView2.getLayoutParams();
        getWidth();
        getHeight();
        this.iv_fb.setLayoutParams(layoutParams);
        this.iv_google.setLayoutParams((LayoutParams) this.iv_google.getLayoutParams());
        this.iv_yahoo.setLayoutParams((LayoutParams) this.iv_yahoo.getLayoutParams());
        this.iv_youtube.setLayoutParams((LayoutParams) this.iv_youtube.getLayoutParams());
    }

    private void scan() {
        new AsyncTask<String, String, String>() {
            private void hashCheck() {
                int size = DupFileScanScreen.this.l.size();
                int i = 0;
                while (true) {
                    String str = "APPPPPPP";
                    if (i >= size) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("in hash check ");
                        stringBuilder.append(DupFileScanScreen.this.m.size());
                        Log.e(str, stringBuilder.toString());
                        return;
                    } else if (!DupFileScanScreen.this.isAborted) {
                        String str2 = (String) DupFileScanScreen.this.l.get(i);
                        String str3 = null;
                        if (DupFileHomeScreen.all || DupFileHomeScreen.extToScan.contains(FilenameUtils.getExtension(str2))) {
                            String str4;
                            StringBuilder stringBuilder2;
                            int i2 = 0;
                            str4 = " ";
                            if (str3 != null || i2 >= 50) {
                                stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(size);
                                stringBuilder2.append(" > ");
                                stringBuilder2.append(i);
                                stringBuilder2.append(" = hash = ");
                                stringBuilder2.append(str3);
                                stringBuilder2.append(str4);
                                stringBuilder2.append(str2);
                                Log.e(str, stringBuilder2.toString());

                            } else {
                                str3 = calculateMD5(str2);
                                i2++;
                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("while........... ");
                                stringBuilder3.append(i);
                                stringBuilder3.append(str4);
                                stringBuilder3.append(str2);
                                Log.e(str, stringBuilder3.toString());
                                ArrayList arrayList;
                                if (DupFileScanScreen.this.m.get(str3) == null) {
                                    arrayList = new ArrayList();
                                    arrayList.add(new BigSizeFilesWrapper(str2, str3, false));
                                    DupFileScanScreen.this.m.put(str3, arrayList);
                                } else {
                                    arrayList = (ArrayList) DupFileScanScreen.this.m.get(str3);
                                    arrayList.add(new BigSizeFilesWrapper(str2, str3, false));
                                    DupFileScanScreen.this.m.put(str3, arrayList);
                                }
                                int i3 = (int) (((((float) i) / ((float) size)) * 90.0f) + 10.0f);
                                String[] strArr = new String[1];
                                StringBuilder stringBuilder4 = new StringBuilder();
                                stringBuilder4.append("");
                                stringBuilder4.append(i3);
                                strArr[0] = stringBuilder4.toString();
                                publishProgress(strArr);
                            }
                        }
                        i++;
                    } else {
                        return;
                    }
                }
            }

            public String calculateMD5(String str) {
                String str2 = "Exception on closing MD5 input stream";
                String str3 = "calculateMD5";
                FileInputStream fileInputStream;
                MessageDigest instance;
                String bigInteger = null;

                try {
                    fileInputStream = new FileInputStream(new File(str));

                    try {
                        instance = MessageDigest.getInstance("MD5");
                    } catch (NoSuchAlgorithmException e) {
                        Log.e(str3, "Exception while getting Digest", e);
                        instance = null;
                    }
                    byte[] bArr = new byte[8192];

                    int read = fileInputStream.read(bArr);
                    instance.update(bArr, 0, read);
                    bigInteger = new BigInteger(1, instance.digest()).toString(16);
                    bigInteger = String.format("%32s", new Object[]{bigInteger}).replace(' ', '0');
                    try {
                        fileInputStream.close();
                    } catch (IOException e2) {
                        Log.e(str3, str2, e2);
                    }
                    
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                    Log.e("Unable to process file","Unable to process file for MD5==> "+ex.getMessage());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return bigInteger;
            }
            
            public void fetchLargeSizeImages(Context context) {
                String str = "external";
                String str2 = "_size";
                String str3 = "_data";
                String str4 = "APPPPPPP";
                Log.e(str4, "fetch img start");
                StringBuilder stringBuilder;
                try {
                    int columnIndex;
                    String[] strArr = new String[]{"_id", str3, "_display_name", str2};
                    context.getContentResolver().query(Files.getContentUri(str), strArr, null, null, "_display_name DESC");
                    Cursor query = context.getContentResolver().query(Files.getContentUri(str), strArr, null, null, "_display_name");
                    if (query != null) {
                        columnIndex = query.getColumnIndex(str3);
                        int columnIndex2 = query.getColumnIndex(str2);
                        for (int i = 0; i < query.getCount(); i++) {
                            query.moveToPosition(i);
                            long j = query.getLong(columnIndex2);
                            if (j >= PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM) {
                                if (j != 0) {
                                    ArrayList arrayList;
                                    if (DupFileScanScreen.this.n.get(Long.valueOf(j)) == null) {
                                        arrayList = new ArrayList();
                                        arrayList.add(query.getString(columnIndex));
                                        DupFileScanScreen.this.n.put(Long.valueOf(j), arrayList);
                                    } else {
                                        arrayList = (ArrayList) DupFileScanScreen.this.n.get(Long.valueOf(j));
                                        arrayList.add(query.getString(columnIndex));
                                        DupFileScanScreen.this.n.put(Long.valueOf(j), arrayList);
                                    }
                                }
                            }
                        }
                    }
                    for (Object obj : DupFileScanScreen.this.n.keySet()) {
                        ArrayList<String> arrayList2 = (ArrayList) DupFileScanScreen.this.n.get(obj);
                        if (arrayList2.size() > 1) {
                            columnIndex = 0;
                            while (columnIndex < arrayList2.size()) {
                                if (!new File((String) arrayList2.get(columnIndex)).isDirectory()) {
                                    try {
                                        if (!((String) arrayList2.get(columnIndex)).contains("usercache")) {
                                            if (!DupFileHomeScreen.scanHidden && ((String) arrayList2.get(columnIndex)).contains("/.")) {
                                            }
                                            DupFileScanScreen.this.l.add(arrayList2.get(columnIndex));
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                                columnIndex++;
                            }
                        }
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(DupFileScanScreen.this.l.size());
                    Log.d("exxxxxxxxxxxxxxxxx ", stringBuilder.toString());
                } catch (Exception e2) {
                    e2.printStackTrace();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("fetch img exce ");
                    stringBuilder.append(e2.getMessage());
                    Log.e(str4, stringBuilder.toString());
                }
            }

            public void onPreExecute() {
                super.onPreExecute();
                Log.e("APPPPPPP", "preexec");
            }

            public String doInBackground(String[] strArr) {
                String str = "APPPPPPP";
                Log.e(str, "do in start");
                publishProgress(new String[]{"5"});
                fetchLargeSizeImages(DupFileScanScreen.this);
                Log.e(str, "after fetch ");
                if (DupFileScanScreen.this.isAborted) {
                    return null;
                }
                publishProgress(new String[]{"10"});
                Log.e(str, "bfor hash check ");
                hashCheck();
                Log.e(str, "after hash check ");
                if (DupFileScanScreen.this.isAborted) {
                    return null;
                }
                int size;
                Set<String> keySet = DupFileScanScreen.this.m.keySet();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("set size ");
                stringBuilder.append(keySet.size());
                Log.e(str, stringBuilder.toString());
                HashMap hashMap = new HashMap();
                int i = 0;
                for (Object obj : keySet) {
                    if (DupFileScanScreen.this.isAborted) {
                        return null;
                    }
                    ArrayList arrayList = (ArrayList) DupFileScanScreen.this.m.get(obj);
                    i++;
                    size = (i * 50) / keySet.size();
                    size = arrayList.size();
                    if (size > 1) {
                        if (DupFileScanScreen.this.isAborted) {
                            return null;
                        }
                        for (int i2 = 0; i2 < size; i2++) {
                            if (DupFileScanScreen.this.isAborted) {
                                return null;
                            }
                            BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) arrayList.get(i2);
                            String str2 = bigSizeFilesWrapper.type;
                            if (!(str2 == null || bigSizeFilesWrapper.size == 0)) {
                                if (hashMap.get(str2) != null) {
                                    ((ArrayList) hashMap.get(bigSizeFilesWrapper.type)).add(bigSizeFilesWrapper);
                                } else {
                                    ArrayList arrayList2 = new ArrayList();
                                    arrayList2.add(bigSizeFilesWrapper);
                                    hashMap.put(bigSizeFilesWrapper.type, arrayList2);
                                }
                            }
                        }
                    }
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("allfilesmap ");
                stringBuilder2.append(hashMap.size());
                Log.e(str, stringBuilder2.toString());
                publishProgress(new String[]{"100"});
                PhoneCleaner.getInstance().duplicateFilesData = new DuplicateFilesData();
                for (Object str3 : hashMap.keySet()) {
                    PhoneCleaner.getInstance().duplicateFilesData.addMediaData(new DuplicateFileMediaData((String) str3, (ArrayList) hashMap.get(str3)));
                }
                stringBuilder2 = new StringBuilder();
                String str32 = "duplicateFilesMediaDataList  size ";
                stringBuilder2.append(str32);
                stringBuilder2.append(PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.size());
                Log.e(str, stringBuilder2.toString());
                ArrayList arrayList3 = PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList;
                int i3 = 0;
                while (i3 < arrayList3.size()) {
                    try {
                        i = 0;
                        while (i < (arrayList3.size() - i3) - 1) {
                            size = i + 1;
                            if (((DuplicateFileMediaData) arrayList3.get(i)).fileTypeDataList.size() < ((DuplicateFileMediaData) arrayList3.get(size)).fileTypeDataList.size()) {
                                Collections.swap(arrayList3, i, size);
                            }
                            i = size;
                        }
                        i3++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str32);
                stringBuilder2.append(PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.size());
                Log.e(str, stringBuilder2.toString());
                for (int i4 = 0; i4 < PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.size(); i4++) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("duplicateFilesMediaData ");
                    stringBuilder2.append(((DuplicateFileMediaData) PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList.get(i4)).mediaName);
                    Log.e(str, stringBuilder2.toString());
                }
                return null;
            }

            public void onPostExecute(String str) {
                super.onPostExecute(str);
                if (DupFileScanScreen.this.isAborted) {
                    DupFileScanScreen.this.finish();
                    return;
                }
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = PhoneCleaner.getInstance().duplicateFilesData.duplicateFilesMediaDataList;
                for (int i = 0; i < arrayList2.size(); i++) {
                    String str2 = ((DuplicateFileMediaData) arrayList2.get(i)).mediaName;
                    if (str2.equalsIgnoreCase(DupFileScanScreen.this.getString(R.string.images))) {
                        if (DupFileHomeScreen.img) {
                            arrayList.add(Integer.valueOf(R.string.images));
                        }
                    } else if (str2.equalsIgnoreCase(DupFileScanScreen.this.getString(R.string.videos))) {
                        if (DupFileHomeScreen.vid) {
                            arrayList.add(Integer.valueOf(R.string.videos));
                        }
                    } else if (str2.equalsIgnoreCase(DupFileScanScreen.this.getString(R.string.documents))) {
                        if (DupFileHomeScreen.doc) {
                            arrayList.add(Integer.valueOf(R.string.documents));
                        }
                    } else if (str2.equalsIgnoreCase(DupFileScanScreen.this.getString(R.string.audios)) && DupFileHomeScreen.aud) {
                        arrayList.add(Integer.valueOf(R.string.audios));
                    }
                }
                Object[] toArray = arrayList.toArray();
                SectionsPagerAdapter.TAB_TITLES = new int[toArray.length];
                for (int i2 = 0; i2 < toArray.length; i2++) {
                    SectionsPagerAdapter.TAB_TITLES[i2] = ((Integer) toArray[i2]).intValue();
                }
                DupFileScanScreen.this.finish();
                if (toArray.length > 0) {
                    Log.e("FileTabScree", "TabScreen");
                    DupFileScanScreen.this.startActivity(new Intent(DupFileScanScreen.this, DuplicatesFileTabScreen.class));
                    return;
                }
                Intent intent = new Intent(DupFileScanScreen.this, FinalScreen.class);
                intent.putExtra(GlobalData.REDIRECTNOTI, true);
                intent.putExtra("TYPE", "DUP");
                intent.putExtra("DATA", DupFileScanScreen.this.getResources().getString(R.string.nodup_files));
                DupFileScanScreen.this.startActivity(intent);
                Log.e("Final", "FinalScreen");
            }

            public void onProgressUpdate(String... strArr) {
                super.onProgressUpdate(strArr);
                DupFileScanScreen.this.o.setProgress(Integer.parseInt(strArr[0]));
                TextView c = DupFileScanScreen.this.boostsize;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(strArr[0]);
                stringBuilder.append(" %");
                c.setText(stringBuilder.toString());
            }
        }.

                execute(new String[0]);

    }

    @SuppressLint("StringFormatInvalid")
    public void onBackPressed() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
        }
        dialog.setContentView(R.layout.new_dialog_junk_cancel);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -1);
        dialog.getWindow().setGravity(17);
        ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.dup_files_title));
        ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(String.format(getResources().getString(R.string.dialouge_scan_back), new Object[]{""}));
        dialog.findViewById(R.id.ll_no).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DupFileScanScreen.this.doubleClicked()) {
                    dialog.dismiss();
                }
            }
        });
        dialog.findViewById(R.id.ll_yes).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!DupFileScanScreen.this.doubleClicked()) {
                    dialog.dismiss();
                    DupFileScanScreen.this.isAborted = true;
                    if (dialog.isShowing()) {
                        dialog.dismiss();
                    }
                }
            }
        });
        dialog.show();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.duplicates_file);
        getWindow().addFlags(2097280);
        setDeviceDimensio();
        initializeViews();
        initToolbar();
        o = (ProgressBar) findViewById(R.id.progressBar);
        boostsize = (TextView) findViewById(R.id.boostsize);
        o.getProgressDrawable().setColorFilter(-1, Mode.SRC_IN);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 888);
        Log.e("APPPPPPP", "beforescan");
        scan();
        animate();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return super.onOptionsItemSelected(menuItem);
    }
}
