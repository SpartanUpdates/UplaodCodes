package com.wavymusic.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Download.RingtoneSongDownload;
import com.wavymusic.Download.SongDownload;
import com.wavymusic.Fragment.RingtoneByCatFragment;
import com.wavymusic.Model.SongModel;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.wavymusic.WidgetView.CircleImageView;
import com.wavymusic.WidgetView.DonutProgress;
import com.wavymusic.activity.RingtoneActivity;
import java.io.File;
import java.util.List;

public class RingtoneAdapter extends RecyclerView.Adapter<RingtoneAdapter.SongViewHolder> {

    RingtoneByCatFragment ringtoneSetCatFragment;
    public int selectedPosition = -1;
    private List<SongModel> songList;
    private Context mContext;
    private RingtoneActivity ActivityOfsong;


    public RingtoneAdapter(Context mContext, List<SongModel> songList, RingtoneByCatFragment ringtoneSetCatFragment) {
        this.songList = songList;
        this.mContext = mContext;
        this.ActivityOfsong = (RingtoneActivity) mContext;
        this.ringtoneSetCatFragment = ringtoneSetCatFragment;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_ringtone_item, null);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SongViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final SongModel songModel = songList.get(position);
        holder.tvSongName.setText(songList.get(position).getSongName());
        holder.cbSong.setChecked(selectedPosition == position);
        if (!songList.get(position).isAvailableOffline) {
            if (songList.get(position).isDownloading) {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.GONE);
                holder.dpDownSong.setVisibility(View.VISIBLE);
            } else {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.VISIBLE);
                holder.dpDownSong.setVisibility(View.GONE);
            }
        } else {
            holder.layoutUseSong.setVisibility(View.VISIBLE);
            holder.ivDownload.setVisibility(View.GONE);
            holder.dpDownSong.setVisibility(View.GONE);
        }
        if (selectedPosition != position) {
            holder.cvThumb.setSelected(false);
            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
            holder.cvThumb.setBackgroundResource(R.drawable.ic_song_select);
        } else {
            holder.cvThumb.setSelected(true);
            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_pause_selected);
            holder.cvThumb.setBackgroundResource(R.drawable.ic_song_select_press);
        }

        holder.tvUseSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityOfsong.FinalSongPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(position).getSongUrl();
                if (songModel.getSongUrl() != null) {
                    final String SoundPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songModel.getSongUrl();
                    SetAsRingToneDialog(mContext,SoundPath);
                }
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadSongFiles(position, holder.ivDownload, holder.dpDownSong, holder.layoutUseSong, holder.ivPalayPause, songModel,holder);
            }
        });
        ActivityOfsong.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
            }
        });
    }


    private void SetAsRingToneDialog(final Context context, final String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppImageAlertDialog);
        final AlertDialog alertdialog = builder.create();
        LayoutInflater inflater = ActivityOfsong.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.set_confirmation_dialog, null);
        alertdialog.setView(dialogView);
        alertdialog.show();
        final TextView textView = dialogView.findViewById(R.id.tvMsg);
        TextView tvYes = dialogView.findViewById(R.id.tvYes);
        TextView tvNo = dialogView.findViewById(R.id.tvNo);
        textView.setText(R.string.set_ring);
        dialogView.findViewById(R.id.ivCloseDialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                        SetRingTone(str, context);
                        alertdialog.dismiss();
                        notifyDataSetChanged();
                    } else if (!SetPermission(ActivityOfsong)) {
                        Toast.makeText(mContext, context.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                    } else if (!(str == null || context == null)) {
                        SetRingTone(str, context);
                        notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, context.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                }
                alertdialog.dismiss();
            }
        });
        tvNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
        try {
            stopPlaying(ActivityOfsong.mediaPlayer);
        } catch (IllegalStateException ex3) {
            ex3.printStackTrace();
        }
    }

    public void SetRingTone(final String SongfilePath, final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Log.e("TAG", "RingTone If");
                    try {
                        if (SongfilePath != null) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(Utils.INSTANCE.getOutputPath());
                            stringBuilder.append(File.separator);
                            stringBuilder.append("Ringtone");
                            stringBuilder.append(File.separator);
                            stringBuilder.append("ringtone.mp3");
                            String stringBuilder2 = stringBuilder.toString();
                            File file = new File(stringBuilder2);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(Utils.INSTANCE.getOutputPath());
                            stringBuilder3.append(File.separator);
                            stringBuilder3.append("Ringtone");
                            Utils.INSTANCE.CopyFileToStorage(SongfilePath, stringBuilder2, stringBuilder3.toString());
                            stringBuilder3 = new StringBuilder("path : ");
                            stringBuilder3.append(SongfilePath);
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("_data", file.getAbsolutePath());
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(file.getName());
                            RingtoneManager.setActualDefaultRingtoneUri(ActivityOfsong, 1, Uri.fromFile(file.getAbsoluteFile()));
                            ((Activity) context).runOnUiThread(new Runnable() {
                                public final void run() {
                                    Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        if (SongfilePath != null) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(Utils.INSTANCE.getOutputPath());
                            stringBuilder.append(File.separator);
                            stringBuilder.append("Ringtone");
                            stringBuilder.append(File.separator);
                            stringBuilder.append("ringtone.mp3");
                            String stringBuilder2 = stringBuilder.toString();
                            File file = new File(stringBuilder2);
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(Utils.INSTANCE.getOutputPath());
                            stringBuilder3.append(File.separator);
                            stringBuilder3.append("Ringtone");
                            Utils.INSTANCE.CopyFileToStorage(SongfilePath, stringBuilder2, stringBuilder3.toString());
                            stringBuilder3 = new StringBuilder("path : ");
                            stringBuilder3.append(SongfilePath);
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("_data", file.getAbsolutePath());
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(file.getName());
                            contentValues.put("title", stringBuilder4.toString());
                            contentValues.put("is_ringtone", Boolean.TRUE);
                            contentValues.put("mime_type", "audio/mp3");
                            stringBuilder3 = new StringBuilder("file://");
                            stringBuilder3.append(file.getAbsolutePath());
                            Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(stringBuilder3.toString());
                            ContentResolver contentResolver = context.getContentResolver();
                            StringBuilder stringBuilder5 = new StringBuilder("_data=\"");
                            stringBuilder5.append(file.getAbsolutePath());
                            stringBuilder5.append("\"");
                            contentResolver.delete(contentUriForPath, stringBuilder5.toString(), null);
                            Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                            RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                            ((Activity) context).runOnUiThread(new Runnable() {
                                public final void run() {
                                    Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    private boolean SetPermission(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.System.canWrite(context)) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
                final StringBuilder sb = new StringBuilder("package:");
                sb.append(context.getPackageName());
                intent.setData(Uri.parse(sb.toString()));
                context.startActivityForResult(intent, 111);
            }
        }
        return false;
    }

    private void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DownloadSongFiles(int position, ImageView ivDonload, DonutProgress dpSongProgress, LinearLayout layoutUseSong, ImageView ivplapause, SongModel songModel, RingtoneAdapter.SongViewHolder holder) {
        int UnitySoundSize = Integer.parseInt(songList.get(position).getSongSize());
        String SongName = songList.get(position).getSongUrl();
        File SongPath = new File(Utils.INSTANCE.getMusicFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        if (new File(Utils.INSTANCE.getMusicFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
                if (holder.cvThumb.isSelected()) {
                    ActivityOfsong.SongPlayPause();
                    if (ActivityOfsong.isSongPlay()) {
                        holder.ivPalayPause.setImageResource(R.drawable.icon_player_pause_selected);
                        holder.cvThumb.setImageResource(R.drawable.icon_song_thumb);
                    } else {
                        holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
                        holder.cvThumb.setImageResource(R.drawable.icon_song_thumb);
                    }
                } else {
                    holder.cvThumb.setSelected(true);
                    if (ActivityOfsong.SelectedTabPosition == ringtoneSetCatFragment.getTabIndex()) {
                        if (selectedPosition == position) {
                            holder.cvThumb.setSelected(true);
                            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                            holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
                            holder.cvThumb.setImageResource(R.drawable.ic_song_select_press);
                            return;
                        }
                    }
                    selectedPosition = position;
                    ActivityOfsong.SetSong(songList.get(position), position);
                    notifyDataSetChanged();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDonload.setVisibility(View.GONE);
                    dpSongProgress.setVisibility(View.VISIBLE);
                    new RingtoneSongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, songModel, ActivityOfsong.mediaPlayer, this, position);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDonload.setVisibility(View.GONE);
                dpSongProgress.setVisibility(View.VISIBLE);
                new RingtoneSongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, songModel, ActivityOfsong.mediaPlayer, this, position);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }


    public class SongViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutMain;
        CircleImageView cvThumb;
        ImageView ivPalayPause;
        TextView tvSongName, tvSongTime;
        LinearLayout layoutUseSong;
        TextView tvUseSong;
        LinearLayout layoutDownSong;
        ImageView ivDownload;
        DonutProgress dpDownSong;
        CheckBox cbSong;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutMain = itemView.findViewById(R.id.image_layout);
            cvThumb = itemView.findViewById(R.id.image_content);
            ivPalayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            tvSongName = itemView.findViewById(R.id.tvMusicName);
            tvSongTime = itemView.findViewById(R.id.tvMusicEndTime);
            layoutUseSong = itemView.findViewById(R.id.llUseMusic);
            tvUseSong = itemView.findViewById(R.id.tvUseMusic);
            layoutDownSong = itemView.findViewById(R.id.ll_download);
            ivDownload = itemView.findViewById(R.id.iv_dowload);
            dpDownSong = itemView.findViewById(R.id.donut_progress);
            cbSong = itemView.findViewById(R.id.cb_music);

        }
    }
}
