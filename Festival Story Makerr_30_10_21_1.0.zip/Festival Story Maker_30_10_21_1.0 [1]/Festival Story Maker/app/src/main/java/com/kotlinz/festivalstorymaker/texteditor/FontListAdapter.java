package com.kotlinz.festivalstorymaker.texteditor;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.R;

import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;

public class FontListAdapter extends RecyclerView.Adapter<FontListAdapter.ViewHolder> {

    public Activity activity;
    public List<String> fontList;
    public a i;
    public int SelectedPosition;


    public interface a {
        void B(Typeface typeface, int i);
    }


    public FontListAdapter(Activity activity, List<String> list, a aVar, int i) {
        this.activity = activity;
        this.fontList = list;
        this.i = aVar;
        this.SelectedPosition = i;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_font_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AssetManager assets = activity.getAssets();

        StringBuilder v = v("fonts/");
        v.append((String) fontList.get(position));
        Typeface createFromAsset = Typeface.createFromAsset(assets, v.toString());
        holder.imgSelected.setVisibility(SelectedPosition == position ? View.VISIBLE : View.INVISIBLE);
        holder.txt.setTypeface(createFromAsset);
        holder.txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             /*   j = this.e;
                e.b();
                this.g.i.B(this.f, this.e);*/

            }
        });
    }

    public void k(final int j) {
        SelectedPosition = j;
        notifyDataSetChanged();
    }

    public static StringBuilder v(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        return stringBuilder;
    }


    @Override
    public int getItemCount() {
        return fontList.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgSelected)
        public ImageView imgSelected;
        @BindView(R.id.txt)
        public TextView txt;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
