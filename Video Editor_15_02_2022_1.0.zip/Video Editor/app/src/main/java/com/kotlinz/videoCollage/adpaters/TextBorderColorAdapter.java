package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.TextBorderColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class TextBorderColorAdapter extends Adapter<TextBorderColorAdapter.ViewHolder> {
    private Context context;
    private TextBorderColorAdapterCallBackInterface listener;
    private int pos = 1;
    private String[] textColorList;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgTextBorderColor;
        ImageView imgTextBorderColorSelector;

        ViewHolder(View view) {
            super(view);
            this.imgTextBorderColor = (ImageView) view.findViewById(R.id.img_text_border_color);
            this.imgTextBorderColorSelector = (ImageView) view.findViewById(R.id.img_text_border_color_selector);
        }
    }

    public TextBorderColorAdapter(String[] strArr, Context context, TextBorderColorAdapterCallBackInterface textBorderColorAdapterCallBackInterface) {
        this.textColorList = strArr;
        this.listener = textBorderColorAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_text_border_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = this.textColorList[i];
        viewHolder.imgTextBorderColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgTextBorderColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgTextBorderColor.setBackground(gradientDrawable);
        viewHolder.imgTextBorderColor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextBorderColorAdapter.this.pos = i;
                TextBorderColorAdapter.this.listener.itemClick(i);
                TextBorderColorAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgTextBorderColorSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgTextBorderColorSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.textColorList.length;
    }
}
