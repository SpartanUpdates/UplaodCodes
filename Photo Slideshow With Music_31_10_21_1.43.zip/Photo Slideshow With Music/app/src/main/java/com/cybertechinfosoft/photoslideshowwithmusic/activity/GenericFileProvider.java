package com.cybertechinfosoft.photoslideshowwithmusic.activity;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
