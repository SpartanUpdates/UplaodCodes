package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMainCategory;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Utils;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QuoteMakerCatAdapter extends RecyclerView.Adapter<QuoteMakerCatAdapter.ViewHolder> {

    public QuoteMakerDetailActivity quoteMakerActivity;
    public int SelectedPosition = 0;
    public ArrayList<QuoteMainCategory> quoteMainCategories;

    public QuoteMakerCatAdapter(Context context, ArrayList<QuoteMainCategory> quoteMainCategories) {
        this.quoteMakerActivity = (QuoteMakerDetailActivity) context;
        this.quoteMainCategories = quoteMainCategories;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_quote_category_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.tvCategoryName.setText(quoteMainCategories.get(position).getCatName());
        if (SelectedPosition == position) {
            holder.tvCategoryName.setTextColor(quoteMakerActivity.getResources().getColor(R.color.child_cat_text_press));
            Glide.with(quoteMakerActivity).load(Utils.StoryMakerCategoryPress(quoteMainCategories.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.imgQuote);
        } else {
            holder.tvCategoryName.setTextColor(quoteMakerActivity.getResources().getColor(R.color.child_cat_text_unpress));
            Glide.with(quoteMakerActivity).load(Utils.StoryMakerCategory(quoteMainCategories.get(position).getCatName())).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.imgQuote);
        }
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                quoteMakerActivity.h0(quoteMakerActivity, position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.quoteMainCategories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.rlMain)
        public LinearLayout llMain;

        @BindView(R.id.imgQuote)
        public ImageView imgQuote;

        @BindView(R.id.tvCategoryName)
        public TextView tvCategoryName;

        @BindView(R.id.tv_subCat_name)
        public TextView tvSubCatName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
