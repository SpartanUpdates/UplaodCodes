package com.kotlinz.videoCollage.flying.poiphoto;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import com.kotlinz.videoCollage.flying.poiphoto.datatype.Photo;
import com.kotlinz.videoCollage.flying.poiphoto.ui.PickImageActivity;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.PhotoAdapter;

import java.util.List;

public class PhotoPicker {
    private Configure mConfigure;

    private PhotoPicker() {
        this.mConfigure = new Configure();
    }

    private PhotoPicker(Configure configure) {
        this.mConfigure = configure;
    }

    public static PhotoPicker newInstance() {
        return new PhotoPicker();
    }

    public static PhotoPicker newInstance(Configure configure) {
        return new PhotoPicker(configure);
    }

    public PhotoPicker setToolbarColor(int i) {
        this.mConfigure.setToolbarColor(i);
        return this;
    }

    public PhotoPicker setToolbarTitleColor(int i) {
        this.mConfigure.setToolbarTitleColor(i);
        return this;
    }

    public PhotoPicker setAlbumTitle(String str) {
        this.mConfigure.setAlbumTitle(str);
        return this;
    }

    public PhotoPicker setPhotoTitle(String str) {
        this.mConfigure.setPhotoTitle(str);
        return this;
    }

    public PhotoPicker setNavIcon(int i) {
        this.mConfigure.setNavIcon(i);
        return this;
    }

    public PhotoPicker setStatusBarColor(int i) {
        this.mConfigure.setStatusBarColor(i);
        return this;
    }

    public PhotoPicker setMaxNotice(String str) {
        this.mConfigure.setMaxNotice(str);
        return this;
    }

    public PhotoPicker setMaxCount(int i) {
        this.mConfigure.setMaxCount(i);
        return this;
    }

    public void pickImage(Context context) {
        Intent intent = new Intent(context, PickImageActivity.class);
        intent.putExtra(Define.CONFIGURE, this.mConfigure);
        if (context instanceof Activity) {
            ((Activity) context).startActivityForResult(intent, 94);
            return;
        }
        throw new IllegalStateException("the context need to use activity");
    }

    public void inflate(RecyclerView recyclerView, LayoutManager layoutManager) {
        final PhotoAdapter photoAdapter = new PhotoAdapter();
        recyclerView.setAdapter(photoAdapter);
        recyclerView.setLayoutManager(layoutManager);
        PhotoManager photoManager = new PhotoManager(recyclerView.getContext());
        new GetAllPhotoTask() {
            public void onPostExecute(List<Photo> list) {
                super.onPostExecute(list);
                photoAdapter.refreshData(list);
            }
        }.execute(new PhotoManager[]{photoManager});
    }
}
