package com.vidsoft.uvideostatus.Activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.exoplayer2.C;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.PrefManager;
import com.vidsoft.uvideostatus.Utility.Utility;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class SplshScreenActivity extends AppCompatActivity {
    TextView PRIVACY;
    public Button btnSkip;
    CheckBox checkbox;
    private PrefManager prefManager;

    public class GetBaseUrl extends AsyncHttpResponseHandler {
        public GetBaseUrl() {
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            try {
                Utility.baseUrl = new JSONObject(new String(bArr)).getString("baseUrl");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
            Utility.baseUrl = "https://api.mlab.com/api/1/databases/dp_status/";
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LoardUrl();
        this.prefManager = new PrefManager(this);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_splsh_screen);
        if (isStoragePermissionGranted()) {
            init();
        }
    }

    @SuppressLint("WrongConstant")
    public void init() {
        if (this.prefManager.isFirstTimeLaunch()) {
            LinearLayout linearLayout = findViewById(R.id.lnt_text);
            this.btnSkip = findViewById(R.id.btn_skip);
            this.PRIVACY = findViewById(R.id.PRIVACY_txt);
            this.checkbox = findViewById(R.id.checkbox);
            this.btnSkip.setVisibility(0);
            this.PRIVACY.setVisibility(0);
            this.checkbox.setVisibility(0);
            linearLayout.setVisibility(0);
            this.btnSkip.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent(SplshScreenActivity.this.getApplicationContext(), MainActivity.class);
                    intent.setFlags(C.ENCODING_PCM_MU_LAW);
                    SplshScreenActivity.this.startActivity(intent);
                    SplshScreenActivity.this.finish();
                }
            });
            this.PRIVACY.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    SplshScreenActivity.this.privacy();
                }
            });
            this.btnSkip.setBackgroundResource(R.drawable.background_rate);
            this.btnSkip.setClickable(false);
            this.btnSkip.setEnabled(false);
            this.checkbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        SplshScreenActivity.this.btnSkip.setBackgroundResource(R.drawable.background_rate1);
                        SplshScreenActivity.this.btnSkip.setClickable(true);
                        SplshScreenActivity.this.btnSkip.setEnabled(true);
                        return;
                    }
                    SplshScreenActivity.this.btnSkip.setBackgroundResource(R.drawable.background_rate);
                    SplshScreenActivity.this.btnSkip.setClickable(false);
                    SplshScreenActivity.this.btnSkip.setEnabled(false);
                }
            });
            this.btnSkip.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    SplshScreenActivity.this.launchHomeScreen();
                }
            });
            return;
        }
        LinearLayout linearLayout2 = findViewById(R.id.lnt_text);
        this.btnSkip = findViewById(R.id.btn_skip);
        this.PRIVACY = findViewById(R.id.PRIVACY_txt);
        this.checkbox = findViewById(R.id.checkbox);
        this.btnSkip.setVisibility(8);
        this.PRIVACY.setVisibility(8);
        this.checkbox.setVisibility(8);
        linearLayout2.setVisibility(8);
        launchHomeScreen();
    }

    @TargetApi(23)
    public void Get_CameraAndStorage_Permission() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (!addPermission(arrayList2, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            arrayList.add("Storage");
        }
        if (arrayList2.size() > 0) {
            if (arrayList.size() > 0) {
                for (int i = 0; i < 1; i++) {
                    requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 1);
                }
                return;
            }
            requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 1);
        }
    }

    @SuppressLint("WrongConstant")
    @TargetApi(23)
    private boolean addPermission(List<String> list, String str) {
        if (checkSelfPermission(str) != 0) {
            list.add(str);
            return shouldShowRequestPermissionRationale(str);
        }
        return true;
    }

    public boolean isStoragePermissionGranted() {
        if (VERSION.SDK_INT < 23 || ActivityCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        Get_CameraAndStorage_Permission();
        return false;
    }

    public void privacy() {
        String str = getResources().getString(R.string.privacy_policy);
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str));
            startActivity(intent);
        } catch (Exception unused) {
        }
    }

    public void launchHomeScreen() {
        this.prefManager.setFirstTimeLaunch(false);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                Intent intent = new Intent(SplshScreenActivity.this.getApplicationContext(), MainActivity.class);
                intent.setFlags(C.ENCODING_PCM_MU_LAW);
                SplshScreenActivity.this.startActivity(intent);
                SplshScreenActivity.this.finish();
            }
        }, 3000);
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr.length > 0 && iArr[0] == 0) {
            init();
        }
    }

    public void LoardUrl() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        asyncHttpClient.get("https://www.dropbox.com/s/lw1s7yn2bco0dm5/config.json?dl=1", new GetBaseUrl());
    }
}
