package com.example.funnyjokesandshayari.dashboard;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.funnyjokesandshayari.BackActivity;
import com.example.funnyjokesandshayari.R;
import com.example.funnyjokesandshayari.kprogresshud.KProgressHUD;
import com.example.funnyjokesandshayari.mainquotes.MainActivity;
import com.example.funnyjokesandshayari.pref.EPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.measurement.api.AppMeasurementSdk.ConditionalUserProperty;


public class DashboardActivity extends AppCompatActivity {
    Activity activity = DashboardActivity.this;
    private final String TAG = MainActivity.class.getSimpleName();
    EPreferences ePreferences;

    ImageView img_back;
    RelativeLayout good_morning, good_night, festival, birthday, romantic, friendship, attitude, sad_quotes, heart_touching, motivation,
            funny, jokes, santa_banta, husband_wife, gf_bf, teacher_student, father_son;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_dashboard);

        ePreferences = EPreferences.getInstance((Context) this);
        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        img_back = findViewById(R.id.img_back);

        img_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        initializeComponents();

        interstitialAd();
        BannerAds();
    }

    private void initializeComponents() {
        good_morning = (RelativeLayout) findViewById(R.id.good_morning);
        good_night = (RelativeLayout) findViewById(R.id.good_night);
        festival = (RelativeLayout) findViewById(R.id.festival);
        birthday = (RelativeLayout) findViewById(R.id.birthday);
        romantic = (RelativeLayout) findViewById(R.id.romantic);
        friendship = (RelativeLayout) findViewById(R.id.friendship);
        attitude = (RelativeLayout) findViewById(R.id.attitude);
        sad_quotes = (RelativeLayout) findViewById(R.id.sad_quotes);
        heart_touching = (RelativeLayout) findViewById(R.id.heart_touching);
        motivation = (RelativeLayout) findViewById(R.id.motivation);
        funny = (RelativeLayout) findViewById(R.id.funny);
        jokes = (RelativeLayout) findViewById(R.id.jokes);
        santa_banta = (RelativeLayout) findViewById(R.id.santa_banta);
        husband_wife = (RelativeLayout) findViewById(R.id.husband_wife);
        gf_bf = (RelativeLayout) findViewById(R.id.gf_bf);
        teacher_student = (RelativeLayout) findViewById(R.id.teacher_student);
        father_son = (RelativeLayout) findViewById(R.id.father_son);

        father_son.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    FatherAndSon();
                }
            }
        });

        gf_bf.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    GFBF();
                }
            }
        });

        husband_wife.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 102;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    HusbanWife();
                }
            }
        });

        santa_banta.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 103;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    SantaBanta();
                }
            }
        });

        attitude.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 104;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Attitude();
                }
            }
        });

        birthday.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 105;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Birthday();
                }

            }
        });

        sad_quotes.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 106;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    SadShayri();
                }
            }
        });

        friendship.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 107;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Friendship();
                }

            }
        });

        festival.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 108;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Festival();
                }

            }
        });

        funny.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 109;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Funny();
                }
            }
        });

        good_morning.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 110;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    GoodMorning();
                }
            }
        });

        good_night.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 111;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    GoodNight();
                }
            }
        });

        heart_touching.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 112;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    HeartTouching();
                }
            }
        });

        jokes.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 113;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Joks();
                }
            }
        });

        motivation.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 114;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    MotiVational();
                }
            }
        });

        romantic.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 115;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Romentic();
                }
            }
        });

        teacher_student.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 115;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    StudentTeacher();
                }
            }
        });

    }

    private void FatherAndSon() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "fathers").putExtra(ConditionalUserProperty.NAME, "Father and Son Jokes"));
    }

    private void GFBF() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gfbf").putExtra(ConditionalUserProperty.NAME, "Girlfriend Boyfriend Jokes"));
    }

    private void HusbanWife() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "husbwife").putExtra(ConditionalUserProperty.NAME, "Husband Wife Jokes"));
    }

    private void SantaBanta() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "santa").putExtra(ConditionalUserProperty.NAME, "Santa Banta Jokes"));
    }

    private void Attitude() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "attitude").putExtra(ConditionalUserProperty.NAME, "Attitude Status"));
    }

    private void Birthday() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "hbd").putExtra(ConditionalUserProperty.NAME, "Birthday Wishes"));
    }

    private void SadShayri() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "sad").putExtra(ConditionalUserProperty.NAME, "Sad Shayari"));
    }

    private void Friendship() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "friend").putExtra(ConditionalUserProperty.NAME, "Friendship Shayari"));
    }

    private void Festival() {
        String str = "festival";
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", str).putExtra(ConditionalUserProperty.NAME, str));
    }

    private void Funny() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "funny").putExtra(ConditionalUserProperty.NAME, "Funny Quotes"));
    }

    private void GoodMorning() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gdmorning").putExtra(ConditionalUserProperty.NAME, "Good Morning Shayari "));
    }

    private void GoodNight() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gdnight").putExtra(ConditionalUserProperty.NAME, "Good Night Shayari"));
    }

    private void HeartTouching() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "heart").putExtra(ConditionalUserProperty.NAME, "Heart Touching Shayari"));
    }

    private void Joks() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "jokes").putExtra(ConditionalUserProperty.NAME, "Jokes"));
    }

    private void MotiVational() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "motivational").putExtra(ConditionalUserProperty.NAME, "Motivationl Quotes"));
    }

    private void Romentic() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "romantic").putExtra(ConditionalUserProperty.NAME, "Romantic Shayari"));
    }

    private void StudentTeacher() {
        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "teacher").putExtra(ConditionalUserProperty.NAME, "Teacher Student Jokes"));
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        FatherAndSon();
                        break;
                    case 101:
                        GFBF();
                        break;
                    case 102:
                        HusbanWife();
                        break;

                    case 103:
                        SantaBanta();
                        break;
                    case 104:
                        Attitude();
                        break;
                    case 105:
                        Birthday();
                        break;
                    case 106:
                        SadShayri();
                        break;
                    case 107:
                        Friendship();
                        break;
                    case 108:
                        Festival();
                        break;
                    case 109:
                        Funny();
                        break;
                    case 110:
                        GoodMorning();
                        break;
                    case 111:
                        GoodNight();
                        break;
                    case 112:
                        HeartTouching();
                        break;
                    case 113:
                        Joks();
                        break;
                    case 114:
                        MotiVational();
                        break;
                    case 115:
                        Romentic();
                        break;
                    case 116:
                        StudentTeacher();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


   /* public void loadAd() {

        //banner
        adView = findViewById(R.id.ad_View);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(DashboardActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdmobInterstitial));
        interstitial.loadAd(adRequestfull);

        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (idd) {
                    case 100:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "fathers").putExtra(ConditionalUserProperty.NAME, "Father and Son Jokes"));
                        break;
                    case 101:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gfbf").putExtra(ConditionalUserProperty.NAME, "Girlfriend Boyfriend Jokes"));
                        break;
                    case 102:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "husbwife").putExtra(ConditionalUserProperty.NAME, "Husband Wife Jokes"));
                        break;
                    case 103:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "santa").putExtra(ConditionalUserProperty.NAME, "Santa Banta Jokes"));
                        break;
                    case 104:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "attitude").putExtra(ConditionalUserProperty.NAME, "Attitude Status"));
                        break;
                    case 105:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "hbd").putExtra(ConditionalUserProperty.NAME, "Birthday Wishes"));
                        break;
                    case 106:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "sad").putExtra(ConditionalUserProperty.NAME, "Sad Shayari"));
                        break;
                    case 107:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "friend").putExtra(ConditionalUserProperty.NAME, "Friendship Shayari"));
                        break;
                    case 108:
                        String str = "festival";
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", str).putExtra(ConditionalUserProperty.NAME, str));
                        break;
                    case 109:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "funny").putExtra(ConditionalUserProperty.NAME, "Funny Quotes"));
                        break;
                    case 110:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gdmorning").putExtra(ConditionalUserProperty.NAME, "Good Morning Shayari "));
                        break;
                    case 111:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "gdnight").putExtra(ConditionalUserProperty.NAME, "Good Night Shayari"));
                        break;
                    case 112:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "heart").putExtra(ConditionalUserProperty.NAME, "Heart Touching Shayari"));
                        break;
                    case 113:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "jokes").putExtra(ConditionalUserProperty.NAME, "Jokes"));
                        break;
                    case 114:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "motivational").putExtra(ConditionalUserProperty.NAME, "Motivationl Quotes"));
                        break;
                    case 115:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "romantic").putExtra(ConditionalUserProperty.NAME, "Romantic Shayari"));
                        break;
                    case 116:
                        DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MainActivity.class).putExtra("data", "teacher").putExtra(ConditionalUserProperty.NAME, "Teacher Student Jokes"));
                        break;
                }

                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(DashboardActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();

        } catch (NullPointerException e2) {
            e2.printStackTrace();

        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }*/

    private UnifiedNativeAd nativeAd;

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(DashboardActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdmobNativeAdvanced));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();

                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
                /*startActivity(new Intent(DashboardActivity.this, BackActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));*/
                finish();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        Log.e("ePreferences", ePreferences.toString());
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(DashboardActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdmobNativeAdvanced));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);

            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

}
