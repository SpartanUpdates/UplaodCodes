package com.kotlinz.festivalstorymaker.Interface;

public interface x8 {
    void h(final boolean p0, final boolean p1, final int p2, final int p3);
}
