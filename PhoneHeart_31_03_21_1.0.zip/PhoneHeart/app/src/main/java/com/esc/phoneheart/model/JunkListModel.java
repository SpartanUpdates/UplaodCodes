package com.esc.phoneheart.model;

import java.io.Serializable;
import java.util.ArrayList;

public class JunkListModel implements Serializable {
    public String appname;
    public ArrayList<String> fileslist = new ArrayList();
    public boolean ischecked = true;
    public String name;
    public String path;
    public String pkg;
    public long size;
    public String type;
}
