package com.esc.dailyrandomfacts.customviews;

import android.content.Context;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;

public class RectangularImageView extends AppCompatImageView {
    public RectangularImageView(Context context) {
        super(context);
    }

    public RectangularImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public RectangularImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = getMeasuredWidth();
        setMeasuredDimension(i, i);
    }
}
