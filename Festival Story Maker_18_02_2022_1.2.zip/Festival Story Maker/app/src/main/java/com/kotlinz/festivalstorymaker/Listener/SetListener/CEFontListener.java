package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.Typeface;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;

public class CEFontListener implements FontListAdapter.a
{
    @Override
    public final void B(final Typeface typeface, final int n) {
        B(typeface, n);
    }
}
