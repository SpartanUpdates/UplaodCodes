package com.claptoflashlightonoff.permission;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.os.Build.VERSION;

import com.example.speaktourchtight.R;

@SuppressLint({"NewApi"})
public class PermissionModelUtil {
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    public static final String[] NECESSARY_PERMISSIONS = new String[]{"android.permission.ACCESS_NETWORK_STATE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", "android.permission.INTERNET", "android.permission.WAKE_LOCK", "android.permission.CAMERA"};
    private static Context context;

    public static void requestPermissions()
    {
        ((Activity) context).requestPermissions(NECESSARY_PERMISSIONS, 1);
    }

    @TargetApi(16)
    public static boolean checkPermission(final Context context) {
        if (VERSION.SDK_INT < 23) {
            return true;
        }
        if (((Activity) context).checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        if (((Activity) context).shouldShowRequestPermissionRationale("android.permission.READ_EXTERNAL_STORAGE")) {
            Builder alertBuilder = new Builder(context);
            alertBuilder.setCancelable(true);
            alertBuilder.setTitle(R.string.permission_necessary);
            alertBuilder.setMessage(R.string.external_storage_and_camera_permission_are_necessary);
            alertBuilder.setPositiveButton(17039379, new OnClickListener() {
                @TargetApi(16)
                public void onClick(DialogInterface dialog, int which) {
                    ((Activity) context).requestPermissions(PermissionModelUtil.NECESSARY_PERMISSIONS, PermissionModelUtil.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                }
            });
            alertBuilder.create().show();
        } else {
            ((Activity) context).requestPermissions(NECESSARY_PERMISSIONS, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        }
        return false;
    }
}
