package com.esc.lovemessages;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.ads.consent.ConsentInformation;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Activity activity = MainActivity.this;
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 111;
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (MainActivity.i == 0) {
                MainActivity.i++;
                MainActivity.startbool = true;
                MainActivity.handler.postDelayed(MainActivity.changeAdBool, i);
                return;
            }
            MainActivity.showbool = true;
            MainActivity.i = 0;
            MainActivity.stopbool = true;
            MainActivity.stopRunnable();
        }
    };
    public static boolean check_paused = false;
    static Context context = null;
    public static Date date = null;
    public static Editor editor = null;
    public static Boolean exitbool = null;
    public static String gridtitle = "";
    public static Handler handler = new Handler();
    static int height = 0;
    static int i = 0;
    public static String image_url = "";
    public static boolean isFirst = true;
    public static boolean isFirst2 = true;
    public static int lockCounter2 = 0;
    public static SharedPreferences sharedPreferences = null;
    public static boolean showbool = false;
    public static boolean startbool = false;
    public static boolean stopbool = false;
    public static Boolean unlocked;
    public static Boolean unlocked2;
    static int width;
    public GridAdapter adapter1;
    DataBaseHelper basehelper;
    TextView cattext;
    public Typeface face1;
    public Typeface face2;
    GifDataBaseHelper gifbaseHelper;
    RelativeLayout gridparent;
    GridView gridview;
    ArrayList<String> pg_id = new ArrayList();
    ArrayList<String> pg_title = new ArrayList();
    private int[] pg_title_extra = new int[]{R.string.gifstext, R.string.bestmessages, R.string.namecake};
    RecyclerView recyclerview;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    private class Async extends AsyncTask<Void, Void, Void> {
        private Async() {
        }

        Async(MainActivity mainActivity) {
            this();
        }


        public Void doInBackground(Void... voidArr) {
            MainActivity.image_url = "http://www.wishafriend.com/";
            MainActivity.this.ImageUrlString();
            return null;
        }
    }

    private class GridAdapter extends BaseAdapter {
        Context context;
        private ArrayList<String> gimg;
        ViewHolder holder;
        private LayoutInflater inflater = null;

        class ViewHolder {
            public ImageView image;
            public RelativeLayout imgRel;
            public TextView imgtext;

            ViewHolder() {
            }
        }

        public long getItemId(int i) {
            return i;
        }

        public GridAdapter(Context context, ArrayList<String> arrayList) {
            this.gimg = arrayList;
            this.inflater = LayoutInflater.from(context);
            this.context = context;
        }

        public int getCount() {
            return this.gimg.size();
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                this.holder = new ViewHolder();
                view = ((LayoutInflater) this.context.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.griditem, null);
                this.holder.image = view.findViewById(R.id.gridimage);
                this.holder.imgtext = view.findViewById(R.id.title);
                this.holder.imgRel = view.findViewById(R.id.imgRel);
                this.holder.imgtext.setTag(Integer.valueOf(i));
                this.holder.imgRel.setTag(Integer.valueOf(i));
                view.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) view.getTag();
            }
            this.holder.imgtext.setTypeface(MainActivity.this.face1);
            LayoutParams layoutParams = this.holder.image.getLayoutParams();
            double d = MainActivity.height;
            Double.isNaN(d);
            layoutParams.height = (int) (d * 0.2d);
            layoutParams = this.holder.imgRel.getLayoutParams();
            d = MainActivity.height;
            Double.isNaN(d);
            layoutParams.height = (int) (d * 0.2d);
            String str = " ";
            int identifier = MainActivity.this.getResources().getIdentifier(this.gimg.get(i).replace(str, "_").toLowerCase(), MainActivity.this.getApplicationContext().getResources().getString(R.string.drawable), MainActivity.this.getPackageName());
            String charSequence = MainActivity.this.pg_title.get(i);
            String str2 = "For Wife";
            if (charSequence.contains(str2)) {
                charSequence = charSequence.replace(str2, str);
            }
            if (i == 0) {
                Glide.with(this.context).asGif().load(Integer.valueOf(R.drawable.love_gifs)).into(this.holder.image);
            } else {
                Glide.with(this.context).load(Integer.valueOf(identifier)).into(this.holder.image);
            }
            this.holder.imgtext.setText(charSequence);
            if (charSequence.equals("Name On Birthday Cake") && MainActivity.sharedPreferences.getBoolean("lock2", true)) {
                this.holder.imgRel.setVisibility(View.VISIBLE);
            } else {
                this.holder.imgRel.setVisibility(View.GONE);
            }
            return view;
        }
    }

    static {
        Boolean valueOf = Boolean.valueOf(false);
        exitbool = valueOf;
        unlocked = valueOf;
        unlocked2 = valueOf;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.face1 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        this.face2 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Regular.ttf");
        context = this;
        String charSequence = "";
        getSupportActionBar().setTitle(charSequence);
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText(getResources().getString(R.string.appname));
        textView.setTypeface(this.face1);
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        editor = sharedPreferences.edit();
        lockCounter2 = sharedPreferences.getInt("lockcounter2", 0);
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(charSequence);
            stringBuilder.append(Calendar.getInstance().getTime());
            date = simpleDateFormat.parse(sharedPreferences.getString("date", stringBuilder.toString()));
        } catch (ParseException unused) {
            unused.printStackTrace();
        }
        this.basehelper = new DataBaseHelper(getApplicationContext());
        this.gifbaseHelper = new GifDataBaseHelper(getApplicationContext());
        try {
            this.basehelper.createDataBase();
            this.gifbaseHelper.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
        BannerAds();
        new Async(this).execute();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        width = displayMetrics.widthPixels;
        height = displayMetrics.heightPixels;
        for (int string : this.pg_title_extra) {
            this.pg_title.add(getResources().getString(string));
            this.pg_id.add(charSequence);
        }
        this.pg_id.addAll(this.basehelper.getPg_Id());
        this.pg_title.addAll(this.basehelper.getPg_Title());
        Log.e("Titles", String.valueOf(this.pg_title));
        this.gridparent = findViewById(R.id.gridparent);
        this.cattext = findViewById(R.id.categorytext);
        this.recyclerview = findViewById(R.id.recylerview);
        this.gridview = findViewById(R.id.gridview);
        this.adapter1 = new GridAdapter(getApplicationContext(), this.pg_title);
        this.gridview.setAdapter(this.adapter1);
        this.gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String str = "dd/M/yyyy hh:mm:ss";
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("GridView   ");
                stringBuilder.append(MainActivity.this.pg_title.get(i));
                Log.e("Flurry", stringBuilder.toString());
                Intent intent;
                if (MainActivity.this.pg_title.get(i).equals("Name On Birthday Cake")) {
                    String str2 = "control";
                    Log.e(str2, "control1");
                    try {
                        String string = MainActivity.sharedPreferences.getString("date", new SimpleDateFormat(str, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
                        Date time = Calendar.getInstance().getTime();
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str, Locale.ENGLISH);
                        i = MainActivity.getDifference(simpleDateFormat.parse(string), simpleDateFormat.parse(simpleDateFormat.format(time)));
                        String str3 = "unlocked2";
                        if (!MainActivity.sharedPreferences.getBoolean("lock2", true)) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("control3 ");
                            stringBuilder2.append(i);
                            Log.e(str2, stringBuilder2.toString());
                            if (i < 5) {
                                MainActivity.editor.putBoolean(str3, false);
                                if (MainActivity.isFirst2) {
                                    MainActivity.isFirst2 = false;
                                }
                                MainActivity.editor.commit();
                                MainActivity.this.startActivity(new Intent(MainActivity.this, NameCakeActivity.class));
                            }
                        } else if (!MainActivity.this.isNetworkAvailable()) {
                            Toast.makeText(MainActivity.this.getApplicationContext(), "Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                        } else if (MainActivity.lockCounter2 >= 7) {
                            MainActivity.unlocked2 = Boolean.valueOf(true);
                            str = new SimpleDateFormat(str, Locale.ENGLISH).format(Calendar.getInstance().getTime());
                            MainActivity.editor.putBoolean(str3, true);
                            MainActivity.editor.putString("date2", str);
                            MainActivity.editor.commit();
                            MainActivity.this.checkRewardAds();
                        } else {
                            MainActivity.lockCounter2++;
                            Toast.makeText(MainActivity.this.getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                        }
                    } catch (ParseException unused) {
                        unused.printStackTrace();
                    }
                } else if (MainActivity.this.pg_title.get(i).equals(MainActivity.this.getResources().getString(R.string.gifstext))) {
                    str = MainActivity.this.getResources().getString(R.string.gifstext);
                    Intent intent2 = new Intent(MainActivity.this, GifSubCategoryActivity.class);
                    intent2.putExtra("subcategory", str);
                    MainActivity.this.startActivityForResult(intent2, 0);
                } else if (MainActivity.this.pg_title.get(i).equals(MainActivity.this.getResources().getString(R.string.bestmessages))) {
                    intent = new Intent(MainActivity.this, PremiumMessagesActivity.class);
                    intent.putExtra("cat_id", 659);
                    intent.putExtra("cat_name", MainActivity.this.pg_title.get(i));
                    MainActivity.this.startActivityForResult(intent, 0);
                } else {
                    intent = new Intent(MainActivity.this, MessagesActivity.class);
                    intent.putExtra("pg_id", MainActivity.this.pg_id.get(i));
                    intent.putExtra("pg_title", MainActivity.this.pg_title.get(i));
                    MainActivity.this.startActivityForResult(intent, 0);
                }
            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void stopRunnable() {
        if (stopbool) {
            handler.removeCallbacks(changeAdBool);
        }
    }


    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 111 && iArr.length > 0) {
            i = iArr[0];
        }
    }


    public void checkRewardAds() {
        String str = "lock2";
        String str2 = "unlocked2";
        String str3 = " ";
        String str4 = "dd/M/yyyy hh:mm:ss";
        try {
            String string = sharedPreferences.getString("date", new SimpleDateFormat(str4, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
            Date time = Calendar.getInstance().getTime();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str4, Locale.ENGLISH);
            String format = simpleDateFormat.format(time);
            Date parse = simpleDateFormat.parse(string);
            time = simpleDateFormat.parse(format);
            getDifference(parse, time);
            str4 = sharedPreferences.getString("date2", new SimpleDateFormat(str4, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
            String format2 = simpleDateFormat.format(Calendar.getInstance().getTime());
            Date parse2 = simpleDateFormat.parse(str4);
            Date parse3 = simpleDateFormat.parse(format2);
            int difference = getDifference(parse2, parse3);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(parse);
            stringBuilder.append(str3);
            stringBuilder.append(time);
            stringBuilder.append(str3);
            stringBuilder.append(parse2);
            stringBuilder.append(str3);
            stringBuilder.append(parse3);
            if (difference >= 5) {
                isFirst2 = true;
                editor.putBoolean(str2, false);
                editor.putBoolean(str, true);
                editor.commit();
                this.gridview.setAdapter(this.adapter1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (unlocked2.booleanValue() && sharedPreferences.getBoolean(str2, false)) {
            startActivity(new Intent(this, NameCakeActivity.class));
            unlocked2 = Boolean.valueOf(false);
            lockCounter2 = 0;
            editor.putInt("lockcounter2", 0);
            editor.putBoolean(str, false);
            editor.commit();
            Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.unlocked), Toast.LENGTH_LONG).show();
        }
    }


    public void onStop() {
        super.onStop();
        editor.putInt("lockcounter2", lockCounter2);
        editor.commit();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            Intent intent = new Intent(this, FavoriteActivity.class);
            startActivity(intent);
            Log.e("Intent", String.valueOf(intent));
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        exitbool = Boolean.valueOf(true);
        super.onBackPressed();
    }


    public void ImageUrlString() {
    }

    private String readStream(InputStream inputStream) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int read = inputStream.read();
            while (read != -1) {
                byteArrayOutputStream.write(read);
                read = inputStream.read();
            }
            return byteArrayOutputStream.toString();
        } catch (IOException unused) {
            unused.printStackTrace();
            return "error";
        }
    }


    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public static int getDifference(Date date, Date date2) {
        return (int) ((date2.getTime() - date.getTime()) / 86400000);
    }

}
