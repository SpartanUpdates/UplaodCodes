package com.Pulse.VideoStatus.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.Pulse.VideoStatus.Adapter.ChangeMessageAdapter;
import com.Pulse.VideoStatus.R;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CustomizeTextActivity extends Activity {

    public RecyclerView rvdynamictext;
    Activity activity = CustomizeTextActivity.this;
    ArrayList<String> DynamicTextList = new ArrayList();
    ArrayList<String> DynamicTextJsonList = new ArrayList();
    ChangeMessageAdapter ChangeTextAdapter;
    String JsonResponse;
    ImageView ivInfoMessage;
    AlertDialog alertDialog;
    TextView tvtitle, tvchangemessage;
    ImageView ivBack;
    TextView tvDone;
    InterstitialAd mInterstitialAd;
    private Toolbar toolbar;
    private LinearLayout adContainer;
    private AdView adView;
//    private NativeBannerAd nativeBannerAd;

    public String GetJsonArray(ArrayList<String> arrayList) {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < arrayList.size()) {
                jSONArray.put(arrayList.get(i).equals("") ? DynamicTextJsonList.get(i) : arrayList.get(i));
                i++;
            }
            jSONObject.put("data", jSONArray);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FINAL Down Json:");
            stringBuilder.append(jSONObject.toString());
            return jSONObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    public void Init() {
        toolbar = findViewById(R.id.toolbar);
        rvdynamictext = findViewById(R.id.rv_edit_Message);
        ivInfoMessage = findViewById(R.id.iv_message_info);
        ivInfoMessage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Aleartdialog("This messages will appear in video.");
            }
        });
    }

    private void loadAd() {
        adContainer = findViewById(R.id.templateContainer);
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        adContainer.addView(adView);
        adView.loadAd();
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                GetJsonResponse();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

//    private void InterstitialAd() {
//        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
//        mInterstitialAd.setAdListener(new InterstitialAdListener() {
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//                GetJsonResponse();
//
//
//            }
//        });
//        mInterstitialAd.loadAd();
//    }

//    private void loadNativeAds() {
//        nativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_nativebanner));
//        nativeBannerAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onMediaDownloaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                findViewById(R.id.banner_container).setVisibility(View.GONE);
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
//                LinearLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
//                nativeBannerAdContainer.addView(adView);
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        });
//        if (Utils.checkConnectivity(activity, false)) {
//            nativeBannerAd.loadAd();
//        } else {
//            findViewById(R.id.banner_container).setVisibility(View.GONE);
//        }
//    }

    public void Aleartdialog(String str) {
        Builder builder = new Builder(activity);
        builder.setMessage(str);
        builder.setPositiveButton("OK", new AleartDialog(this));
        alertDialog = builder.create();
        alertDialog.show();
        alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent));
    }

    public ArrayList<String> Calender(String str) {
        ArrayList<String> arrayList = new ArrayList();
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                for (int i = 0; i < jSONArray.length(); i++) {
                    arrayList.add(jSONArray.getString(i));
                }
                return arrayList;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void Calender() {
        EditTextInputResponse();
        ChangeTextAdapter = new ChangeMessageAdapter(DynamicTextList, this);
        GridLayoutManager manager = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rvdynamictext.setLayoutManager(manager);
        rvdynamictext.setHasFixedSize(true);
        rvdynamictext.setAdapter(ChangeTextAdapter);
    }


    public void GetJsonResponse() {
        String ChangeTextResponse = GetJsonArray(this.DynamicTextList);
        UnityPlayer.UnitySendMessage("GameManager", "ReturnTextResponce", ChangeTextResponse);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FinalJson =");
        stringBuilder.append(ChangeTextResponse);
        finish();
    }

    public void EditTextInputResponse() {
        JsonResponse = getIntent().getStringExtra("JsonStr");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InputJson = ");
        stringBuilder.append(JsonResponse);
        DynamicTextList.addAll(Calender(JsonResponse));
        DynamicTextJsonList.addAll(DynamicTextList);
    }
    @Override
    protected void onDestroy() {
        this.adContainer.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_change_text);
        tvtitle = findViewById(R.id.tv_edit_message);
        tvDone = findViewById(R.id.tv_done);
        tvchangemessage = findViewById(R.id.tv_change_message);
        ivBack = findViewById(R.id.ivBack);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CustomizeTextActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
//        loadNativeAds();
        loadAd();
        InterstitialAd();
        Init();
        Calender();
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    GetJsonResponse();
                }
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    class AleartDialog implements DialogInterface.OnClickListener {

        final CustomizeTextActivity context;

        AleartDialog(CustomizeTextActivity customizeTextActivity) {
            context = customizeTextActivity;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            context.alertDialog.dismiss();
        }
    }
}