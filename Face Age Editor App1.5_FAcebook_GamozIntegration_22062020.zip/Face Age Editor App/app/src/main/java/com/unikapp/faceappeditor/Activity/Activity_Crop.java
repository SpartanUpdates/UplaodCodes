package com.unikapp.faceappeditor.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.theartofdev.edmodo.cropper.CropImageView;
import com.theartofdev.edmodo.cropper.CropImageView.CropShape;
import com.unikapp.faceage.editorapp.R;
import java.io.IOException;
import androidx.appcompat.app.AppCompatActivity;

public class Activity_Crop extends AppCompatActivity {
    private Bitmap bitmap;
    private CropImageView cropImageView;
    public static Bitmap bitmap_cropped;
    ImageView Img_backcreation;
    private int angle = 0;
    public ImageView img_rotate;
    ImageView img_save;

    public InterstitialAd fbinterstitialAd;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        try {
            this.bitmap = Media.getBitmap(getContentResolver(),
                    MainActivity.image_uri);
        } catch (IOException e) {
            e.printStackTrace();
        }
        initView();
        LoadfbInterstitialAds();
    }

    private void initView() {
        this.cropImageView = (CropImageView) findViewById(R.id.cropImageView);
        this.cropImageView.setImageUriAsync(MainActivity.image_uri);
        this.cropImageView.setCropShape(CropShape.RECTANGLE);
        this.img_save = (ImageView) findViewById(R.id.img_save);
        this.Img_backcreation = (ImageView) findViewById(R.id.Img_back_creation);
        this.img_rotate = (ImageView) findViewById(R.id.img_Rotate);
        this.img_rotate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity_Crop.this.angle = 90;
                Activity_Crop.this.bitmap = Activity_Crop.this.rotateImage(
                        Activity_Crop.this.bitmap, (float) Activity_Crop.this.angle);
                Activity_Crop.this.cropImageView
                        .setImageBitmap(Activity_Crop.this.bitmap);
            }
        });
        this.Img_backcreation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity_Crop.this.finish();
            }
        });
        this.img_save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                    fbinterstitialAd.show();
                }else {
                    SaveImage();
                }
            }
        });

    }

    private void SaveImage() {
        Activity_Crop.bitmap_cropped = Activity_Crop.this.cropImageView
                .getCroppedImage();
        Activity_Crop.this.startActivity(new Intent(Activity_Crop.this,
                Activity_imageEdit.class));
        finish();
    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed...");
                SaveImage();
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG", "AdError..." + adError.getErrorMessage());
                // Ad error callback
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("TAG", "AdsLoaded...");
                // Interstitial ad is loaded and ready to be displayed
                // Show the ad
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Ad clicked callback
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.loadAd();
    }

    public Bitmap rotateImage(Bitmap src, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(),
                matrix, true);
    }

    protected void onResume() {
        super.onResume();
    }

}
