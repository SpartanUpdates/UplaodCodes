package com.esc.beautymackupselficlam.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.esc.beautymackupselficlam.R;

import java.util.ArrayList;

public class StickerAdapter extends BaseAdapter {
	Context context;
	ImageView img_editing;
	private LayoutInflater inflater;
	ArrayList<Integer> stickers;
	private ViewHolder viewholder;

	public StickerAdapter(final Context context,
                          final ArrayList<Integer> stickers) {
		this.context = context;
		this.stickers = stickers;
		this.inflater = (LayoutInflater) this.context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public int getCount() {
		return this.stickers.size();
	}

	public Object getItem(final int n) {
		return this.stickers.get(n);
	}

	public long getItemId(final int n) {
		return n;
	}

	public View getView(int intValue, final View view, final ViewGroup viewGroup) {
		View inflate = view;
		if (view == null) {
			inflate = this.inflater.inflate(R.layout.sticker_item,
					(ViewGroup) null);
		}
		this.img_editing = (ImageView) inflate.findViewById(R.id.img_editing);
		intValue = this.stickers.get(intValue);
		Glide.with(this.context).load(Integer.valueOf(intValue))
				.into(this.img_editing);
		System.gc();
		return inflate;
	}

	public class ViewHolder {
		ResizableImageView img_gallery;
	}
}
