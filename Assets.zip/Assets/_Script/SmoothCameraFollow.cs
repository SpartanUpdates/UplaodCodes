﻿using UnityEngine;
using System.Collections;

public class SmoothCameraFollow : MonoBehaviour
{
	Transform player;

	public float smoothSpeed = 0.125f;
	
	public Vector3 offset;

	Vector3 desiredPosition;

	Vector3 smoothedPosition;
	protected void Start()
	{
		player = GameObject.FindGameObjectWithTag("Player").transform;
	}
	void FixedUpdate()
	{
		 desiredPosition = player.position + offset;
		 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
			transform.position = smoothedPosition;
	}
}