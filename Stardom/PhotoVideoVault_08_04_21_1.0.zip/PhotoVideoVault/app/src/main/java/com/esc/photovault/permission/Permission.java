package com.esc.photovault.permission;

import android.app.Activity;

import androidx.core.app.ActivityCompat;

import com.esc.photovault.util.Utils.permission;

public class Permission {
    Activity mactivity;

    public Permission(Activity activity) {
        mactivity = activity;
    }

    public boolean checkPermissionForReadexternal() {
        if (ActivityCompat.checkSelfPermission(mactivity, permission.READ_EXTERNAL_STORAGE) == 0) {
            return true;
        }
        return false;
    }

    public boolean checkPermissionForWriteexternal() {
        if (ActivityCompat.checkSelfPermission(mactivity, permission.WRITE_EXTERNAL_STORAGE) == 0) {
            return true;
        }
        return false;
    }

    public boolean checkPermissionForCamera() {
        if (ActivityCompat.checkSelfPermission(mactivity, permission.CAMERA) == 0) {
            return true;
        }
        return false;
    }

    public boolean checkPermissionForfinger() {
        if (ActivityCompat.checkSelfPermission(mactivity, "android.permission.USE_FINGERPRINT") == 0) {
            return true;
        }
        return false;
    }

    public void requestPermissionForReadeexternal() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(mactivity, permission.READ_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(mactivity, new String[]{permission.READ_EXTERNAL_STORAGE}, 23);
            return;
        }
        ActivityCompat.requestPermissions(mactivity, new String[]{permission.READ_EXTERNAL_STORAGE}, 23);
    }

    public void requestPermissionForWriteexternal() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(mactivity, permission.WRITE_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(mactivity, new String[]{permission.WRITE_EXTERNAL_STORAGE}, 24);
            return;
        }
        ActivityCompat.requestPermissions(this.mactivity, new String[]{permission.WRITE_EXTERNAL_STORAGE}, 24);
    }

    public void requestPermissionForfinger() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this.mactivity, "android.permission.USE_FINGERPRINT")) {
            ActivityCompat.requestPermissions(this.mactivity, new String[]{"android.permission.USE_FINGERPRINT"}, 25);
            return;
        }
        ActivityCompat.requestPermissions(this.mactivity, new String[]{"android.permission.USE_FINGERPRINT"}, 25);
    }

    public void requestPermissionCamera() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this.mactivity, permission.CAMERA)) {
            ActivityCompat.requestPermissions(this.mactivity, new String[]{permission.CAMERA}, 26);
            return;
        }
        ActivityCompat.requestPermissions(this.mactivity, new String[]{permission.CAMERA}, 26);
    }
}
