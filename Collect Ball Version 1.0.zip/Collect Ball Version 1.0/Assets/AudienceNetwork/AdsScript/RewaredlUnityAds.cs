﻿using UnityEngine;
using UnityEngine.Advertisements;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class RewaredlUnityAds : MonoBehaviour, IUnityAdsListener
    {
        public static RewaredlUnityAds instance;

        bool testMode = true;

        [HideInInspector]
        public bool isVideoUnityLoad = false;

        void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        void Start()
        {
            Advertisement.AddListener(this);
            Advertisement.Initialize(Manager.instance.unityGameId, testMode);
            isVideoUnityLoad = false;
        }

        public void OnUnityAdsDidFinish(string placementId, ShowResult showResult)
        {
            if (placementId == Manager.instance.unityRewaredId)
            {
                isVideoUnityLoad = false;

            if (showResult == ShowResult.Finished)
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = true;
                    MainMenu.instance.RewardDone();
                    Analytics.CustomEvent("UnityRewaredCoinDone");
                }
                else
                {
                    GameController.instance.SaveMe();
                    Analytics.CustomEvent("UnityRewaredSaveMeDone");
                }
            }
            else if (showResult == ShowResult.Skipped)
            {
                if (MainMenu.instance.isRewardSetting)
                {
                    MainMenu.instance.isRewardDone = false;
                    MainMenu.instance.RewardDone();
                        Analytics.CustomEvent("UnityRewaredCoinSkip");
                    }
                else
                {
                    GameController.instance.SkipVideoAdd();
                        Analytics.CustomEvent("UnityRewaredSaveMeSkips");

                    }
                }
            else if (showResult == ShowResult.Failed)
            {
            }
            }
        }

        public void OnUnityAdsReady(string placementId)
        {
            if (placementId == Manager.instance.unityRewaredId)
            {
                isVideoUnityLoad = true;
                Analytics.CustomEvent("UnityRewaredLoad");
            }
        }

        public void OnUnityAdsDidError(string message)
        {
        }

        public void OnUnityAdsDidStart(string placementId)
        {
        }

        public void ShowRewaredVideo()
        {
            Advertisement.Show(Manager.instance.unityRewaredId);
        }

        public void OnDestroy()
        {
            Advertisement.RemoveListener(this);
        }
    }
}