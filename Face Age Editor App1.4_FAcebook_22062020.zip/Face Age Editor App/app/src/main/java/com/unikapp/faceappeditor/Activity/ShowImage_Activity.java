package com.unikapp.faceappeditor.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
//import android.support.v4.content.FileProvider;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.unikapp.faceappeditor.Utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.unikapp.faceage.editorapp.R;
import java.io.File;
import java.io.IOException;
import androidx.core.content.FileProvider;

public class ShowImage_Activity extends Activity {
    ImageView img;
    ImageView delete;
    int pos;
    ImageView set_as;
    ImageView share;
    ImageView img_back;

    private int id;
    public InterstitialAd fbinterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image_);
        pos = getIntent().getIntExtra("position", 0);
        BindView();
//        loadAd();
        LoadfbInterstitialAds();
        img.setImageURI(Uri.parse(Utils.Constant.IMAGEALLARY.get(pos)));
        initView();
    }

    private void initView() {
        img_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        delete.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                final Dialog dial = new Dialog(ShowImage_Activity.this);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                dial.findViewById(R.id.delete_yes)
                        .setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                File fD = new File(Utils.Constant.IMAGEALLARY
                                        .get(pos));
                                if (fD.exists()) {
                                    fD.delete();
                                }
                                Utils.Constant.IMAGEALLARY.remove(pos);
                                ShowImage_Activity.this
                                        .sendBroadcast(new Intent(
                                                "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                                                Uri.fromFile(new File(String
                                                        .valueOf(fD)))));

                                if (Utils.Constant.IMAGEALLARY.size() == 0) {
                                    Toast.makeText(ShowImage_Activity.this,
                                            "No Image Found..", Toast.LENGTH_SHORT).show();
                                }
                                dial.dismiss();
                                finish();

                            }
                        });
                dial.findViewById(R.id.delete_no)
                        .setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                dial.show();

            }
        });
        set_as.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                    id = R.id.img_setaswalpaper;
                    fbinterstitialAd.show();
                } else {
                    ShowImage_Activity.this.setWallpaper(
                            "Boy Photo Editore created by",
                            Utils.Constant.IMAGEALLARY.get(pos));
                }
            }
        });
        share.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                    id = R.id.img_sharee_show;
                    fbinterstitialAd.show();
                } else {
                    Parcelable fromFile;
                    if (Build.VERSION.SDK_INT <= 19) {
                        fromFile = Uri.fromFile(new File(Utils.Constant.IMAGEALLARY.get(pos)));
                    } else {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(getPackageName());
                        stringBuilder.append(".provider");
                        fromFile = FileProvider.getUriForFile(ShowImage_Activity.this, stringBuilder.toString(), new File(Utils.Constant.IMAGEALLARY.get(pos)));
                    }
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("image/*");
                    intent.putExtra("android.intent.extra.STREAM", fromFile);
                    intent.putExtra("android.intent.extra.TEXT",
                            "Boy Photo Editore created by : "
                                    + ShowImage_Activity.this.getPackageName());
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    ShowImage_Activity.this.startActivity(Intent.createChooser(
                            intent, "Share image File"));

                }
            }
        });
    }

    private void BindView() {
        img = findViewById(R.id.final_img);
        img_back = findViewById(R.id.img_back);
        set_as = findViewById(R.id.img_setaswalpaper);
        delete = findViewById(R.id.img_delete);
        share = findViewById(R.id.img_sharee_show);
    }


//    private int id;
//    private InterstitialAd mInterstitialAd;

//    private void loadAd() {
//        mInterstitialAd = new InterstitialAd(this);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_inter));
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                switch (id) {
//                    case R.id.img_setaswalpaper:
//                        ShowImage_Activity.this.setWallpaper("Boy Photo Editore created by",
//                                Utils.Constant.IMAGEALLARY.get(pos));
//                        break;
//                    case R.id.img_sharee_show:
//                        Parcelable fromFile;
//                        if (Build.VERSION.SDK_INT <= 19) {
//                            fromFile = Uri.fromFile(new File(Utils.Constant.IMAGEALLARY.get(pos)));
//                        } else {
//                            StringBuilder stringBuilder = new StringBuilder();
//                            stringBuilder.append(getPackageName());
//                            stringBuilder.append(".provider");
//                            fromFile = FileProvider.getUriForFile(ShowImage_Activity.this, stringBuilder.toString(), new File(Utils.Constant.IMAGEALLARY.get(pos)));
//                        }
//                        Intent intent = new Intent("android.intent.action.SEND");
//                        intent.setType("image/*");
//                        intent.putExtra("android.intent.extra.STREAM", fromFile);
//                        intent.putExtra("android.intent.extra.TEXT",
//                                "Boy Photo Editore created by : "
//                                        + ShowImage_Activity.this.getPackageName());
//                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                        ShowImage_Activity.this.startActivity(Intent.createChooser(
//                                intent, "Share image File"));
//
//                        break;
//                    case 100:
//                        startActivity(new Intent(ShowImage_Activity.this, Activity_Creation.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
//                        finish();
//                        break;
//                }
//                requestNewInterstitial();
//            }
//        });
//    }
//
//    private void requestNewInterstitial() {
//        this.mInterstitialAd.loadAd(new AdRequest.Builder().build());
//    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed..." + id);
                switch (id) {
                    case R.id.img_setaswalpaper:
                        ShowImage_Activity.this.setWallpaper("Boy Photo Editore created by",
                                Utils.Constant.IMAGEALLARY.get(pos));
                        break;
                    case R.id.img_sharee_show:
                        Parcelable fromFile;
                        if (Build.VERSION.SDK_INT <= 19) {
                            fromFile = Uri.fromFile(new File(Utils.Constant.IMAGEALLARY.get(pos)));
                        } else {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(getPackageName());
                            stringBuilder.append(".provider");
                            fromFile = FileProvider.getUriForFile(ShowImage_Activity.this, stringBuilder.toString(), new File(Utils.Constant.IMAGEALLARY.get(pos)));
                        }
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.setType("image/*");
                        intent.putExtra("android.intent.extra.STREAM", fromFile);
                        intent.putExtra("android.intent.extra.TEXT",
                                "Boy Photo Editore created by : "
                                        + ShowImage_Activity.this.getPackageName());
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        ShowImage_Activity.this.startActivity(Intent.createChooser(
                                intent, "Share image File"));

                        break;
                    case 100:
                        startActivity(new Intent(ShowImage_Activity.this, Activity_Creation.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.loadAd();
    }

    @Override
    public void onBackPressed() {
        if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
            id = 100;
            fbinterstitialAd.show();
        } else {
            startActivity(new Intent(ShowImage_Activity.this, Activity_Creation.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
        }
    }

    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            Options options = new Options();
            options.inPreferredConfig = Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this, "Wallpaper Set Sucessfully", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
