package com.natsuite.natrender;

import android.opengl.*;
import android.util.*;
import java.nio.*;

public final class GLBlitEncoder
{
    private final int target;
    private int[] framebuffer;
    private int attachment;
    private int[] dataBuffer;
    private int program;
    private int positionAttribute;
    private int uvAttribute;
    private int textureUniform;
    private int transformUniform;
    private static final float[] TRANSFORM_IDENTITY;
    private static final String vShader = "#version 100                                       \nprecision lowp float;                              \nattribute vec2 a_position;                         \nattribute lowp vec2 a_texcoord;                    \nvarying lowp vec2 v_texcoord;                      \nuniform lowp mat4 orientation;                     \nvoid main() {                                      \n   gl_Position = vec4(a_position, 0.0, 1.0);       \n   v_texcoord = (orientation * vec4(a_texcoord, 0.0, 1.0)).xy;     \n}                                                  \n";
    private static final String fShader = "#version 100                                       \nprecision lowp float;                              \nuniform sampler2D sTexture;                        \nvarying lowp vec2 v_texcoord;                      \nvoid main () {                                     \n   gl_FragColor = texture2D(sTexture, v_texcoord); \n}                                                  \n";
    private static final String fShaderExternal = "#version 100                                       \n#extension GL_OES_EGL_image_external : require     \nprecision lowp float;                              \nuniform samplerExternalOES sTexture;               \nvarying lowp vec2 v_texcoord;                      \nvoid main () {                                     \n   gl_FragColor = texture2D(sTexture, v_texcoord); \n}                                                  \n";
    private static final float[] vertexData;
    private static final float[] textureData;
    private static final FloatBuffer vData;
    private static final FloatBuffer tData;
    
    public static GLBlitEncoder blitEncoder() {
        return new GLBlitEncoder(3553);
    }
    
    public static GLBlitEncoder externalBlitEncoder() {
        return new GLBlitEncoder(36197);
    }
    
    public static int getTexture() {
        final int[] texture = { 0 };
        GLES20.glGenTextures(1, texture, 0);
        GLES20.glBindTexture(3553, texture[0]);
        GLES20.glTexParameteri(3553, 10241, 9729);
        GLES20.glTexParameteri(3553, 10240, 9729);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        return texture[0];
    }
    
    public static int getExternalTexture() {
        final int[] texture = { 0 };
        GLES20.glGenTextures(1, texture, 0);
        GLES20.glBindTexture(36197, texture[0]);
        GLES20.glTexParameteri(36197, 10241, 9729);
        GLES20.glTexParameteri(36197, 10240, 9729);
        GLES20.glTexParameteri(36197, 10242, 33071);
        GLES20.glTexParameteri(36197, 10243, 33071);
        return texture[0];
    }
    
    public static void releaseTexture(final int textureID) {
        GLES20.glDeleteTextures(1, new int[] { textureID }, 0);
    }
    
    private GLBlitEncoder(final int target) {
        this.framebuffer = new int[1];
        this.target = target;
        this.generateResources();
        GLES20.glGenFramebuffers(1, this.framebuffer, 0);
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        GLES20.glUseProgram(this.program);
        GLES20.glActiveTexture(33984);
        GLES20.glUniform1i(this.textureUniform, 0);
    }
    
    public void blit(final int src) {
        this.blit(src, GLBlitEncoder.TRANSFORM_IDENTITY);
    }
    
    public void blit(final int src, final int dst) {
        this.blit(src, dst, GLBlitEncoder.TRANSFORM_IDENTITY);
    }
    
    public void blit(final int src, final float[] transform) {
        GLES20.glBindFramebuffer(36160, 0);
        this.render(src, transform);
    }
    
    public void blit(final int src, final int dst, final float[] transform) {
        GLES20.glBindFramebuffer(36160, this.framebuffer[0]);
        if (this.attachment != dst) {
            GLES20.glBindTexture(3553, dst);
            GLES20.glFramebufferTexture2D(36160, 36064, 3553, dst, 0);
            this.attachment = dst;
        }
        this.render(src, transform);
    }
    
    public void schedule() {
        GLES20.glFlush();
    }
    
    public void complete() {
        GLES20.glFinish();
    }
    
    public void release() {
        GLES20.glBindFramebuffer(36160, 0);
        GLES20.glDeleteFramebuffers(1, this.framebuffer, 0);
        this.releaseResources();
    }
    
    private void render(final int tex, final float[] transform) {
        GLES20.glClear(16384);
        GLES20.glBindTexture(this.target, tex);
        GLES20.glBindBuffer(34962, this.dataBuffer[0]);
        GLES20.glEnableVertexAttribArray(this.positionAttribute);
        GLES20.glVertexAttribPointer(this.positionAttribute, 2, 5126, false, 0, 0);
        GLES20.glBindBuffer(34962, this.dataBuffer[1]);
        GLES20.glEnableVertexAttribArray(this.uvAttribute);
        GLES20.glVertexAttribPointer(this.uvAttribute, 2, 5126, false, 0, 0);
        GLES20.glUniformMatrix4fv(this.transformUniform, 1, false, transform, 0);
        GLES20.glDrawArrays(5, 0, 4);
        logErrorGL("Performed blit");
    }
    
    private void generateResources() {
        GLES20.glGenBuffers(2, this.dataBuffer = new int[2], 0);
        logErrorGL("Drawing resource generation failed");
        GLES20.glBindBuffer(34962, this.dataBuffer[0]);
        GLES20.glBufferData(34962, GLBlitEncoder.vData.capacity() * 4, (Buffer)GLBlitEncoder.vData, 35044);
        logErrorGL("Texture resource generation failed");
        GLES20.glBindBuffer(34962, this.dataBuffer[1]);
        GLES20.glBufferData(34962, GLBlitEncoder.tData.capacity() * 4, (Buffer)GLBlitEncoder.tData, 35044);
        GLES20.glBindBuffer(34962, 0);
        this.program = this.loadProgram();
    }
    
    private void releaseResources() {
        GLES20.glDeleteBuffers(2, this.dataBuffer, 0);
        GLES20.glDeleteProgram(this.program);
        logErrorGL("Failed to release resources");
    }
    
    protected static void logErrorGL(final String log) {
        final int error = GLES20.glGetError();
        if (error != 0) {
            Log.e("Unity", "NatRender Error: " + log + " with error " + error);
        }
    }
    
    private static int loadShader(final int type, final String shaderSrc) {
        final int[] compiled = { 0 };
        final int shader = GLES20.glCreateShader(type);
        logErrorGL("Unable to create shader object");
        if (shader == 0) {
            return 0;
        }
        GLES20.glShaderSource(shader, shaderSrc);
        GLES20.glCompileShader(shader);
        GLES20.glGetShaderiv(shader, 35713, compiled, 0);
        if (compiled[0] == 0) {
            logErrorGL("Failed to compile shader with type: " + type);
            GLES20.glDeleteShader(shader);
            return 0;
        }
        return shader;
    }
    
    private int loadProgram() {
        final int[] linked = { 0 };
        final int vertexShad = loadShader(35633, "#version 100                                       \nprecision lowp float;                              \nattribute vec2 a_position;                         \nattribute lowp vec2 a_texcoord;                    \nvarying lowp vec2 v_texcoord;                      \nuniform lowp mat4 orientation;                     \nvoid main() {                                      \n   gl_Position = vec4(a_position, 0.0, 1.0);       \n   v_texcoord = (orientation * vec4(a_texcoord, 0.0, 1.0)).xy;     \n}                                                  \n");
        if (vertexShad == 0) {
            logErrorGL("Failed to load vertex shader");
            return 0;
        }
        final int fragmentShad = loadShader(35632, (this.target == 36197) ? "#version 100                                       \n#extension GL_OES_EGL_image_external : require     \nprecision lowp float;                              \nuniform samplerExternalOES sTexture;               \nvarying lowp vec2 v_texcoord;                      \nvoid main () {                                     \n   gl_FragColor = texture2D(sTexture, v_texcoord); \n}                                                  \n" : "#version 100                                       \nprecision lowp float;                              \nuniform sampler2D sTexture;                        \nvarying lowp vec2 v_texcoord;                      \nvoid main () {                                     \n   gl_FragColor = texture2D(sTexture, v_texcoord); \n}                                                  \n");
        if (fragmentShad == 0) {
            logErrorGL("Failed to load fragment shader");
            GLES20.glDeleteShader(vertexShad);
            return 0;
        }
        final int programObject = GLES20.glCreateProgram();
        logErrorGL("Failed to create program");
        if (programObject == 0) {
            return 0;
        }
        GLES20.glAttachShader(programObject, vertexShad);
        GLES20.glAttachShader(programObject, fragmentShad);
        GLES20.glLinkProgram(programObject);
        logErrorGL("Failed to link program");
        GLES20.glGetProgramiv(programObject, 35714, linked, 0);
        if (linked[0] == 0) {
            logErrorGL("Failed to link program");
            GLES20.glDeleteProgram(programObject);
            return 0;
        }
        this.positionAttribute = GLES20.glGetAttribLocation(programObject, "a_position");
        this.uvAttribute = GLES20.glGetAttribLocation(programObject, "a_texcoord");
        this.transformUniform = GLES20.glGetUniformLocation(programObject, "orientation");
        this.textureUniform = GLES20.glGetUniformLocation(programObject, "sTexture");
        GLES20.glDeleteShader(vertexShad);
        GLES20.glDeleteShader(fragmentShad);
        return programObject;
    }
    
    static {
        TRANSFORM_IDENTITY = new float[] { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };
        vertexData = new float[] { -1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, 1.0f };
        textureData = new float[] { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f };
        vData = (FloatBuffer)ByteBuffer.allocateDirect(GLBlitEncoder.vertexData.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(GLBlitEncoder.vertexData).position(0);
        tData = (FloatBuffer)ByteBuffer.allocateDirect(GLBlitEncoder.textureData.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(GLBlitEncoder.textureData).position(0);
    }
}
