package com.kotlinz.festivalstorymaker.Model.CollageMaker;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class CollageMainCategory {

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("cat_name")
	private String catName;

	@SerializedName("cat_id")
	private int catId;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	@SerializedName("child_category")
	private List<CollageChildCategory> childCategory;

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getCatName(){
		return catName;
	}

	public int getCatId(){
		return catId;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}

	public List<CollageChildCategory> getChildCategory(){
		return childCategory;
	}
}