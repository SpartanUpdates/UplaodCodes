package com.kotlinz.videostatusmaker.App;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;

import com.facebook.ads.AudienceNetworkAds;
//import com.greedygame.core.AppConfig;
//import com.greedygame.core.GreedyGameAds;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.AppConfig;
import com.greedygame.core.GreedyGameAds;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.videostatusmaker.Activity.ActivityArrangePhoto;
import com.kotlinz.videostatusmaker.Activity.ActivityMyCreations;
import com.kotlinz.videostatusmaker.Activity.ActivitySelectLyrics;
import com.kotlinz.videostatusmaker.Activity.ActivityVideoSave;
import com.kotlinz.videostatusmaker.Activity.ActivityViewAlImages;
import com.kotlinz.videostatusmaker.Activity.FirstActivity;
import com.kotlinz.videostatusmaker.Activity.MainActivity;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityImageFolder;
import com.kotlinz.videostatusmaker.R;

public class MyApplication extends Application {

    private static MyApplication instance;

    public static int Variable_VIDEO_HEIGHT = 720;
    public static int Variable_VIDEO_WIDTH = 720;

    public static Activity activity;

    public static int isShowAd = 0;
    public static int AdsId;
    public static GGInterstitialAd interstitialAd;

    public static String OutPutPath;

    FirebaseAnalytics mFirebaseAnalytics;

    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        AppConfig appConfig = new AppConfig.Builder(this)
                .withAppId(getResources().getString(R.string.gg_app_id))
                .enableFacebookAds(true)
                .build();
        GreedyGameAds.initWith(appConfig, null);
        AudienceNetworkAds.initialize(this);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        InterAds();
    }

    private void CustomAnalyticsEvent(String ActivityName, String AdsShowName) {
        Bundle params = new Bundle();
        params.putString("ActivityName", ActivityName);
        params.putString("AdsShowName", AdsShowName);
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, params);
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(this, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                requestNewInterAds();
                switch (AdsId) {
                    case 1:
                        activity.startActivity(new Intent(activity, ActivitySelectLyrics.class));
                        break;
                    case 2:
                        GoToSave();
                        break;
                    case 3:
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;
                    case 4:
                        activity.startActivity(new Intent(activity, ActivityMyCreations.class));
                        break;
                    case 5:
                        activity.startActivity(new Intent(activity, ActivityViewAlImages.class));
                        break;
                    case 6:
                        activity.setResult(-1);
                        activity.finish();
                        break;
                    case 7:
                        activity.onBackPressed();
                        break;
                    case 8:
                        activity.onBackPressed();
                        break;
                    case 9:
                        activity.setResult(-1);
                        activity.finish();
                        break;
                    case 10:
                        activity.onBackPressed();
                        break;
                    case 11:
                        activity.setResult(-1);
                        activity.finish();
                        break;
                    case 12:
                        activity.onBackPressed();
                        break;
                    case 13:
                        activity.startActivity(new Intent(activity, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                        activity.finish();
                        break;
                    case 15:
                        activity.startActivity(new Intent(activity, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                        activity.finish();
                        break;
                    case 16:
                        activity.onBackPressed();
                        break;
                    case 17:
                        activity.onBackPressed();
                        break;
                    case 18:
                        activity.onBackPressed();
                        break;
                    case 19:
                        activity.onBackPressed();
                        break;
                    case 20:
                        activity.onBackPressed();
                        break;
                    case 21:
                        activity.onBackPressed();
                        break;
                    case 22:
                        activity.startActivity(new Intent(activity, ActivityMyCreations.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                        activity.finish();
                        break;
                    case 23:
                        activity.onBackPressed();
                        break;
                    case 24:
                        activity.startActivity(new Intent(activity, ActivityArrangePhoto.class));
                        break;
                    case 25:
                        activity.startActivity(new Intent(activity, ActivityImageFolder.class));
                        break;
                    case 26:
                        activity.startActivity(new Intent(activity, ActivityImageFolder.class));
                        break;

                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {
                switch (AdsId) {
                    case 1:
                        CustomAnalyticsEvent("ArrangeActivity", "DoneButton");
                        break;
                    case 2:
                        CustomAnalyticsEvent("ActivityPreview", "SaveDialogButton");
                        break;
                    case 3:
                        CustomAnalyticsEvent("FirstActivity", "StartButton");
                        break;
                    case 4:
                        CustomAnalyticsEvent("FirstActivity", "MyCreationButton");
                        break;
                    case 5:
                        CustomAnalyticsEvent("ActivityAllPhotos", "DoneButton");
                        break;
                    case 6:
                        CustomAnalyticsEvent("ActivityAddText", "DoneButton");
                        break;
                    case 7:
                        CustomAnalyticsEvent("ActivityAddText", "BackButton");
                        break;
                    case 8:
                        CustomAnalyticsEvent("ActivityArrangePhoto", "BackButton");
                        break;
                    case 9:
                        CustomAnalyticsEvent("ActivityDrawImage", "DoneButton");
                        break;
                    case 10:
                        CustomAnalyticsEvent("ActivityDrawImage", "BackButton");
                        break;
                    case 11:
                        CustomAnalyticsEvent("ActivityEditImage", "DoneButton");
                        break;
                    case 12:
                        CustomAnalyticsEvent("ActivityEditImage", "BackButton");
                        break;
                    case 13:
                        CustomAnalyticsEvent("ActivityMyCreations", "BackButton");
                        break;
                    case 15:
                        CustomAnalyticsEvent("ActivityMyCreationVideoPlay", "BackButton");
                        break;
                    case 16:
                        CustomAnalyticsEvent("ActivityPreview", "BackButton");
                        break;
                    case 17:
                        CustomAnalyticsEvent("ActivitySelectLyrics", "BackButton");
                        break;
                    case 18:
                        CustomAnalyticsEvent("ActivitySelectText", "BackButton");
                        break;
                    case 19:
                        CustomAnalyticsEvent("ActivitySelectTheme", "BackButton");
                        break;
                    case 20:
                        CustomAnalyticsEvent("ActivitySetting", "BackButton");
                        break;
                    case 21:
                        CustomAnalyticsEvent("ActivityStickerSelect", "BackButton");
                        break;
                    case 22:
                        CustomAnalyticsEvent("ActivityVideo", "BackButton");
                        break;
                    case 23:
                        CustomAnalyticsEvent("ActivityViewAllImage", "BackButton");
                        break;
                    case 24:
                        CustomAnalyticsEvent("ActivityViewAllImage", "BackButton");
                        break;
                    case 25:
                        CustomAnalyticsEvent("MainActivity", "SquareButton");
                        break;
                    case 26:
                        CustomAnalyticsEvent("MainActivity", "FullScreenButton");
                        break;
                }
            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void requestNewInterAds() {
        interstitialAd.loadAd();
    }

    private void GoToSave() {
        Intent intent = new Intent(activity, ActivityVideoSave.class);
        intent.putExtra("outpath", MyApplication.OutPutPath);
        activity.startActivity(intent);
        activity.finish();
    }


}

