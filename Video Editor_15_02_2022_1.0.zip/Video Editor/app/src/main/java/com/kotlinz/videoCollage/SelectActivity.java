package com.kotlinz.videoCollage;


import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.flying.puzzle.PuzzleLayout;
import com.kotlinz.videoCollage.flying.puzzle.slant.SlantPuzzleLayout;
import com.kotlinz.videoCollage.fragments.VideosFragmentNew;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.PuzzleAdapter;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SelectActivity extends AppCompatActivity {
    Activity activity = SelectActivity.this;
    public static LinearLayout mainLin;
    public static PuzzleAdapter puzzleAdapter;
    public static RecyclerView puzzleList;
    public static ArrayList<String> selectedPath = new ArrayList();
    public static List<View> viewPieces = new ArrayList();
    private MenuItem okMenuItem;
    private TextView tempMsgTextView;
    private TextView titleTextView;
    private TextView txtSelectedImgVid;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select);
        Toolbar toolbar = findViewById(R.id.sel_toolbar);
        titleTextView = toolbar.findViewById(R.id.sel_title_txt_view);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        PutAnalyticsEvent();
        selectedPath.clear();
        viewPieces.clear();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getCacheDir());
        stringBuilder.append("/temp");
        Util.deleteTempDir(new File(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append(getCacheDir());
        stringBuilder.append("/tempdraw");
        Util.deleteTempDir(new File(stringBuilder.toString()));
        Util.deleteTempDir(getCacheDir());
        Util.selectedVid = 0;
        com.kotlinz.videoCollage.flying.poiphoto.Util.selectedItemsCount = 0;
        mainLin = findViewById(R.id.main_layout_sel);
        txtSelectedImgVid = findViewById(R.id.txt_selected_img_vid);
        tempMsgTextView = findViewById(R.id.temp_msg);
        txtSelectedImgVid.setVisibility(View.GONE);
        setFragment(new VideosFragmentNew(activity));
        puzzleAdapter = new PuzzleAdapter(this, "select");
        RecyclerView recyclerView = findViewById(R.id.puzzle_list);
        puzzleList = recyclerView;
        recyclerView.setAdapter(puzzleAdapter);
        puzzleList.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        puzzleList.setHasFixedSize(true);
        puzzleAdapter.setOnItemClickListener(new PuzzleAdapter.OnItemClickListener() {
            public void onItemClick(PuzzleLayout puzzleLayout, int i) {
                Intent intent = new Intent(activity, GridActivity.class);
                intent.putStringArrayListExtra("photo_path", selectedPath);
                String str = "type";
                if (puzzleLayout instanceof SlantPuzzleLayout) {
                    intent.putExtra(str, 0);
                } else {
                    intent.putExtra(str, 1);
                }
                intent.putExtra("piece_size", SelectActivity.selectedPath.size());
                intent.putExtra("theme_id", i);
                SelectActivity.this.startActivity(intent);
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    protected void setFragment(Fragment fragment) {
        FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        t.replace(R.id.frame_video, fragment);
        t.commit();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.select_menu, menu);
        MenuItem findItem = menu.findItem(R.id.action_ok);
        this.okMenuItem = findItem;
        findItem.setVisible(false);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        } else if (menuItem.getItemId() != R.id.action_ok) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            startActivity(new Intent(activity, GridActivity.class));
            finish();
            return true;
        }
    }

    public void onBackPressed() {
        if (selectedPath.size() > 0) {
            backConfirmationDialog();
            return;
        }
        selectedPath.clear();
        viewPieces.clear();
        startActivity(new Intent(activity, StartActivity.class));
        finish();
    }

    private void backConfirmationDialog() {
        String str = "Cancel";
        new Builder(this).setMessage("All changes will be discarded.").setCancelable(false).setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                selectedPath.clear();
                viewPieces.clear();
                startActivity(new Intent(activity, StartActivity.class));
                finish();
            }
        }).setNegativeButton(str, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    public void setSelectedVidImg() {
        if (selectedPath.size() > 0) {
            TextView textView = this.titleTextView;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Select Layout (");
            stringBuilder.append(selectedPath.size());
            stringBuilder.append(")");
            textView.setText(stringBuilder.toString());
            if (selectedPath.size() >= 2) {
                puzzleList.setVisibility(View.VISIBLE);
                this.tempMsgTextView.setVisibility(View.GONE);
                return;
            }
            this.tempMsgTextView.setVisibility(View.VISIBLE);
            puzzleList.setVisibility(View.GONE);
            return;
        }
        this.titleTextView.setText("Select Layout");
        this.tempMsgTextView.setVisibility(View.VISIBLE);
        puzzleList.setVisibility(View.GONE);
    }
}
