package com.wavymusic.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.root.unity.AndroidUnityCall;
import com.wavymusic.Model.VideoModel;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.wavymusic.VideoPlayer.Preference.VideoPlayerPreference;
import com.wavymusic.application.MyApplication;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MyCreationPlayer extends AppCompatActivity implements MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener, SurfaceHolder.Callback, View.OnClickListener {

    Activity activity = MyCreationPlayer.this;
    private Runnable runnable = new Runnable() {
        public final void run() {
            if (mediaPlayer == null || !mediaPlayer.isPlaying()) {
                tvCounterStart.removeCallbacks(this);
                return;
            }
            getCurrentDuration(mediaPlayer.getCurrentPosition());
            tvCounterStart.postDelayed(this, 1000);
        }
    };

    public static boolean IsSurfaceCreated = false;
    private boolean IsSurfaceContainer = true;
    private int VideoWidth = 0;
    private int VideoHeight = 0;
    private boolean isOnMediaonPrepared;
    MediaPlayer mediaPlayer;
    SurfaceView surfaceView;
    ArrayList<VideoModel> AllVideolist;
    private View view;
    private LinearLayout llInfo;
    private TextView tvCounterStart;
    private TextView tvCounterEnd;
    ImageButton ibVideoplayPause;
    ImageView ivPlayerPlayPause;
    ImageView ivback;
    ImageView ivShareWhatsApp;
    ImageView ivshareFb;
    ImageView ivShareInsta;
    ImageView ivShareYoutube;
    ImageView ivshareMore;
    Handler handler = new Handler();

  /*  private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;*/

    private String VideoUrl;
    public int videoCurrentposition;
    public static boolean IsFromAndroidlist;

    Runnable runnableprogress = new Runnable() {
        public final void run() {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                seekBar.setProgress(((mediaPlayer.getCurrentPosition() / 1000) * 100));
                handler.postDelayed(this, 100);
            }
        }
    };
    private SeekBar seekBar;
    private ImageView ivNext;
    private ImageView ivprevious;
    private ImageView ivFullScreen;
    private LinearLayout llToolbar;
    private LinearLayout llVideoplayerContent;
    private RelativeLayout rlVideoSurfaceContainer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation_player);
        IsSurfaceCreated = false;
//        adContainerView = findViewById(R.id.banner_ad_view_container);
        rlVideoSurfaceContainer = findViewById(R.id.videoSurfaceContainer);
        llInfo = findViewById(R.id.llInfo);
        llVideoplayerContent = findViewById(R.id.llCenter);
        llToolbar = findViewById(R.id.llRight);
        tvCounterStart = findViewById(R.id.tvVideoStartCounter);
        tvCounterEnd = findViewById(R.id.tvVideoEndCounter);
        surfaceView = findViewById(R.id.videoSurface);
        view = findViewById(R.id.loading);
        ibVideoplayPause = findViewById(R.id.ibPlayPauseVideo);
        ivPlayerPlayPause = findViewById(R.id.ivPlayerPlayPause);
        seekBar = findViewById(R.id.bottom_seekbar);
        ivprevious = findViewById(R.id.ivPlayerPrev);
        ivNext = findViewById(R.id.ivPlayerNext);
        ivFullScreen = findViewById(R.id.ivFullScreen);
        ivback = findViewById(R.id.ivIconBackFromMyCreation);
        ivShareWhatsApp = findViewById(R.id.ivVideoShareWhatsApp);
        ivshareFb = findViewById(R.id.ivVideoShareFb);
        ivShareInsta = findViewById(R.id.ivVideoShareInsta);
        ivShareYoutube = findViewById(R.id.ivVideoShareYoutube);
        ivshareMore = findViewById(R.id.ivVideoShareMore);
        AllVideolist = new ArrayList();
        AllVideolist.clear();
        ((RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams()).addRule(2, R.id.llInfo);
        Display defaultDisplay2 = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay2.getSize(point);
        int i = point.x;
        int i2 = point.y;

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        final int width = displayMetrics.widthPixels;
        final int height = displayMetrics.heightPixels;

        rlVideoSurfaceContainer.setLayoutParams(new RelativeLayout.LayoutParams(i, -2));
        this.llInfo.setBackgroundColor(getResources().getColor(R.color.music_player_bg_bootom));
        ((RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams()).addRule(2, R.id.llInfo);
        this.surfaceView.setMinimumHeight(i2);
        this.surfaceView.setMinimumWidth(i);
        findViewById(R.id.rlTest);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams();
        layoutParams2.width = 720;
        layoutParams2.height = 1280;
        rlVideoSurfaceContainer.setLayoutParams(layoutParams2);
        rlVideoSurfaceContainer.setGravity(17);
        ViewGroup.LayoutParams layoutParams3 = surfaceView.getLayoutParams();
        layoutParams3.width = 720;
        layoutParams3.height = 1280;
        surfaceView.setLayoutParams(layoutParams3);
//        BannerAds();
        getAllVideo();
        if (AllVideolist.size() > 0) {
            VideoUrl = getIntent().getStringExtra("VideoUrl");
            videoCurrentposition = getIntent().getIntExtra("VideoPosition", 0);
            IsFromAndroidlist = getIntent().getBooleanExtra("IsVideoFromAndroidList", false);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Video Not Found");
            builder.setMessage("No videos found on storage");
            builder.setPositiveButton("Go back", new DialogInterface.OnClickListener() {
                public final void onClick(DialogInterface dialogInterface, int i) {
                    if (!getIntent().getBooleanExtra("IsVideoFromAndroidList", false)) {
                        startActivity(new Intent(activity, YourVideoActivity.class));
                        finish();
                    }
                    finish();
                }
            });
            builder.show();
        }

        if (this.AllVideolist.size() > 0) {
            ivback.setOnClickListener(this);
            ivShareWhatsApp.setOnClickListener(this);
            ivshareFb.setOnClickListener(this);
            ivShareInsta.setOnClickListener(this);
            ivShareYoutube.setOnClickListener(this);
            ivshareMore.setOnClickListener(this);
            ivNext.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    VideoNext();
                }
            });
            ivprevious.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    VideoPrevious();
                }
            });
            ivFullScreen.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    int i;
                    LinearLayout.LayoutParams layoutParams;
                    if (/*adContainerView.getVisibility() == View.VISIBLE && */llToolbar.getVisibility() == View.VISIBLE) {
                        ivFullScreen.setImageResource(R.drawable.icon_player_small);
//                        adContainerView.setVisibility(View.GONE);
                        llToolbar.setVisibility(View.GONE);
                        llInfo.setBackgroundColor(getResources().getColor(R.color.music_player_bg_bootom));
                        rlVideoSurfaceContainer.setPadding(0, 0, 0, 0);
                        getWindowManager().getDefaultDisplay().getSize(new Point());
                        DisplayMetrics displayMetrics = new DisplayMetrics();
                        MyCreationPlayer.this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                        int i2 = displayMetrics.heightPixels;
                        i = displayMetrics.widthPixels;
                        if (i2 < 1920 || i < 1080) {
                            VideoWidth = width;
                            VideoHeight = height;
                        } else {
                            VideoWidth = 1080;
                            VideoHeight = 1920;
                        }

                        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(MyCreationPlayer.this.VideoWidth, VideoHeight);
                        layoutParams2.addRule(15, -1);
                        rlVideoSurfaceContainer.setLayoutParams(layoutParams2);
                        rlVideoSurfaceContainer.setMinimumHeight(VideoHeight);
                        rlVideoSurfaceContainer.setMinimumWidth(MyCreationPlayer.this.VideoWidth);
                        surfaceView.setLayoutParams(layoutParams2);
                        layoutParams = new LinearLayout.LayoutParams(-1, -1);
                        layoutParams.setMargins(0, 0, 0, 0);
                        llVideoplayerContent.setLayoutParams(layoutParams);
                        llVideoplayerContent.setGravity(17);
                        llVideoplayerContent.setBackgroundColor(getResources().getColor(R.color.black));
                        return;
                    }
                    ivFullScreen.setImageResource(R.drawable.icon_player_fullscreen);
//                    adContainerView.setVisibility(View.VISIBLE);
                    llToolbar.setVisibility(View.VISIBLE);
                    Display defaultDisplay = MyCreationPlayer.this.getWindowManager().getDefaultDisplay();
                    Point point = new Point();
                    defaultDisplay.getSize(point);
                    i = point.x;
                    int i3 = point.y;
                    rlVideoSurfaceContainer.setLayoutParams(new RelativeLayout.LayoutParams(i, -2));
                    llInfo.setBackgroundColor(getResources().getColor(R.color.music_player_bg_bootom));
                    llVideoplayerContent.setBackgroundColor(getResources().getColor(R.color.white));
                    ((RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams()).addRule(2, R.id.llInfo);
                    surfaceView.setMinimumHeight(i3);
                    surfaceView.setMinimumWidth(i);
                    layoutParams = new LinearLayout.LayoutParams(-1, -1);
                    ViewGroup.LayoutParams layoutParams3 = surfaceView.getLayoutParams();
                    layoutParams3.width = width;
                    layoutParams3.height = height;
                    surfaceView.setLayoutParams(layoutParams3);
                    RelativeLayout.LayoutParams layoutParams4 = (RelativeLayout.LayoutParams) rlVideoSurfaceContainer.getLayoutParams();
                    layoutParams4.width = width;
                    layoutParams4.height = height;
                    rlVideoSurfaceContainer.setLayoutParams(layoutParams4);
                    rlVideoSurfaceContainer.setGravity(17);
                    rlVideoSurfaceContainer.setPadding(10, 10, 10, 10);
                    layoutParams.setMargins(size(), size(), size(), size());
                    llVideoplayerContent.setLayoutParams(layoutParams);
                }
            });
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                int a = 0;

                public final void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    this.a = i;

                    handler.postDelayed(runnableprogress, 100);
                }

                public final void onStartTrackingTouch(SeekBar seekBar) {
                    handler.removeCallbacks(runnableprogress);
                }

                public final void onStopTrackingTouch(SeekBar seekBar) {
                    mediaPlayer.seekTo(this.a * 10);
                    seekBar.setProgress((this.a / 1000) * 100);
                    tvCounterStart.post(runnable);
                }
            });
            rlVideoSurfaceContainer.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    if (/*MyCreationPlayer.this.adContainerView.getVisibility() == View.GONE &&*/ llToolbar.getVisibility() == View.GONE) {
                        Animation loadAnimation;
                        if (IsSurfaceContainer) {
                            IsSurfaceContainer = false;
                            seekBar.setVisibility(View.GONE);
                            loadAnimation = AnimationUtils.loadAnimation(MyCreationPlayer.this.getApplicationContext(), R.anim.slide_out_bottom);
                            llInfo.startAnimation(loadAnimation);
                            loadAnimation.setAnimationListener(new Animation.AnimationListener() {
                                public final void onAnimationEnd(Animation animation) {
                                    llInfo.setVisibility(View.GONE);
                                }

                                public final void onAnimationRepeat(Animation animation) {
                                }

                                public final void onAnimationStart(Animation animation) {
                                }
                            });
                            return;
                        }
                        IsSurfaceContainer = true;
                        loadAnimation = AnimationUtils.loadAnimation(MyCreationPlayer.this.getApplicationContext(), R.anim.slide_in_bottom);
                        llInfo.startAnimation(loadAnimation);
                        loadAnimation.setAnimationListener(new Animation.AnimationListener() {
                            public final void onAnimationEnd(Animation animation) {
                                llInfo.setVisibility(View.VISIBLE);
                                seekBar.setVisibility(View.VISIBLE);
                            }

                            public final void onAnimationRepeat(Animation animation) {
                            }

                            public final void onAnimationStart(Animation animation) {
                            }
                        });
                    }
                }
            });
            ibVideoplayPause.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    VideoPlaypause(ibVideoplayPause);
                }
            });
            ivPlayerPlayPause.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    playPause();
                }
            });
            surfaceView.getHolder().addCallback(this);
        }

    }

    public int size() {
        return (int) (Resources.getSystem().getDisplayMetrics().density * 32.0f);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (!((Build.VERSION.SDK_INT >= 20 ? powerManager.isInteractive() : powerManager.isScreenOn()) || mediaPlayer == null)) {
                mediaPlayer.pause();
                ivPlayerPlayPause.setImageResource(R.drawable.icon_player_play);
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        view.setVisibility(View.GONE);
        int i = 0;
        surfaceView.setVisibility(View.VISIBLE);
        this.isOnMediaonPrepared = false;
        int i2 = 1;
        if (mediaPlayer.getVideoWidth() > mediaPlayer.getVideoHeight()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(this);
        ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        int i3 = AllVideolist != null ? 1 : 0;
        if (AllVideolist.size() <= 0) {
            i2 = 0;
        }
        if ((i3 & i2) != 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(AllVideolist.get(this.videoCurrentposition).videoDuration);
            String stringBuilder2 = stringBuilder.toString();
            VideoPlayerPreference.a = getSharedPreferences("VIDEOPLAYERS", 0);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("lptrack");
            stringBuilder3.append(stringBuilder2);
            long j = VideoPlayerPreference.a.getLong(stringBuilder3.toString(), -1);
            stringBuilder3 = new StringBuilder(".");
            stringBuilder3.append(VideoPlayerPreference.a(this));
            if (!(j == -1 || j == 0 || mediaPlayer.getDuration() < 1000)) {
                VideoPlayerPreference.a(this);
            }
        }
        try {
            MediaPlayer.TrackInfo[] trackInfo = mediaPlayer.getTrackInfo();
            while (i < trackInfo.length) {
                trackInfo[i].getTrackType();
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SetVisibility();
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
            }
            if (ivPlayerPlayPause != null && ivPlayerPlayPause.getVisibility() == View.GONE) {
                ivPlayerPlayPause.setVisibility(View.VISIBLE);
            }
            if (!(mediaPlayer == null || mediaPlayer.isPlaying())) {
                ivPlayerPlayPause.setImageResource(R.drawable.icon_player_play);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i1) {

    }

    private void getAllVideo() {
        AllVideolist.clear();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = activity.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPPFOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoInfo = new VideoModel();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    AllVideolist.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
    }

    private void getCurrentDuration(int n) {
        final StringBuilder sb = new StringBuilder();
        final long n2 = n;
        String string = "";
        n = (int) (n2 / 3600000L);
        final long n3 = n2 % 3600000L;
        final int n4 = (int) n3 / 60000;
        final int n5 = (int) (n3 % 60000L / 1000L);
        if (n > 0) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(n);
            sb2.append(".");
            string = sb2.toString();
        }
        String s;
        if (n5 < 10) {
            s = "0".concat(String.valueOf(n5));
        } else {
            s = String.valueOf(n5);
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(string);
        sb3.append(n4);
        sb3.append(".");
        sb3.append(s);
        sb.append(sb3.toString());
        tvCounterStart.setText(sb.toString());
    }

    private void VideoPlaypause(final ImageButton imageButton) {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
            }
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    imageButton.setImageResource(R.drawable.icon_player_pause);
                    return;
                }
                imageButton.setImageResource(R.drawable.icon_player_play);
            }
        }
    }

    private void ShareVideo(String str, String str2) {
        File file = new File(this.VideoUrl);
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.get_free));
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" Music at here : https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        intent.putExtra("android.intent.extra.TITLE", "United Videos : Particle.ly Video Status Maker");
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (str != null) {
            if (getPackageInfo(str, activity)) {
                intent.setPackage(str);
            } else {
                Context applicationContext = getApplicationContext();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(getString(R.string.please_install));
                stringBuilder2.append(str2);
                Toast.makeText(applicationContext, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
                return;
            }
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_video)));
    }

    private static boolean getPackageInfo(String str, Context context) {
        try {
            context.getPackageManager().getPackageInfo(str, PackageManager.GET_META_DATA);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    private void SetVisibility() {
        try {
            if (Build.VERSION.SDK_INT <= 11 || Build.VERSION.SDK_INT >= 19) {
                if (Build.VERSION.SDK_INT >= 19) {
                    getWindow().getDecorView().setSystemUiVisibility(4096);
                }
                return;
            }
            getWindow().getDecorView().setSystemUiVisibility(8);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetVideoWithSurface() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.reset();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        getWindow().addFlags(128);
        mediaPlayer = new MediaPlayer();
        this.mediaPlayer = mediaPlayer;
        mediaPlayer.setOnVideoSizeChangedListener(this);
        this.view.setVisibility(View.VISIBLE);
        StringBuilder stringBuilder;
        try {
            stringBuilder = new StringBuilder();
            stringBuilder.append(Uri.parse(this.VideoUrl));
            this.mediaPlayer.setDataSource(this, Uri.parse(this.VideoUrl));
            this.mediaPlayer.prepare();
            this.mediaPlayer.setOnPreparedListener(this);
            long duration = (long) this.mediaPlayer.getDuration();
            this.tvCounterEnd.setText(String.format("%02d.%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(duration)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)))}));
            this.tvCounterStart.post(this.runnable);
            StringBuilder stringBuilder2 = new StringBuilder("Val : ");
            stringBuilder2.append(this.mediaPlayer.getDuration() / 10);
            this.seekBar.setMax(this.mediaPlayer.getDuration() / 10);
            this.seekBar.setProgress((this.mediaPlayer.getCurrentPosition() / 1000) * 100);
        } catch (NullPointerException e) {
            stringBuilder = new StringBuilder(" NullPointerException ");
            stringBuilder.append(e.getMessage());
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        } catch (IllegalStateException e3) {
            e3.printStackTrace();
        } catch (SecurityException e4) {
            e4.printStackTrace();
        } catch (IllegalArgumentException e5) {
            e5.printStackTrace();
        }
        try {
            this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
            this.ibVideoplayPause.setImageResource(R.drawable.icon_player_pause);
        } catch (Exception e6) {
            e6.printStackTrace();
            return;
        }
        this.mediaPlayer.setDisplay(this.surfaceView.getHolder());
    }

   /* private void BannerAds() {
        try {
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }

    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    public void playPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
                tvCounterStart.post(runnable);
                runOnUiThread(new Runnable() {
                    public final void run() {
                        handler.postDelayed(this, 100);
                        try {
                            if (seekBar != null) {
                                seekBar.setProgress((mediaPlayer.getCurrentPosition() / 1000) * 100);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
            ImageView imageView = ivPlayerPlayPause;
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    imageView.setImageResource(R.drawable.icon_player_pause);
                    return;
                }
                imageView.setImageResource(R.drawable.icon_player_play);
            }
        }
    }

    public final void getVideoPath() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(AllVideolist.get(videoCurrentposition).videoDuration);
        VideoPlayerPreference.a(this, Boolean.TRUE, stringBuilder.toString());
        this.VideoUrl = AllVideolist.get(videoCurrentposition).videoFullPath;
        SetVideoWithSurface();
    }

    private void VideoNext() throws IllegalStateException {
        if (!(videoCurrentposition + 1 < AllVideolist.size())) {
            startActivity(new Intent(activity, YourVideoActivity.class));
            finish();
            return;
        }
        videoCurrentposition++;
        getVideoPath();
    }

    private void VideoPrevious() throws IllegalStateException {
        if ((videoCurrentposition - 1 == -1)) {
            startActivity(new Intent(activity, YourVideoActivity.class));
            finish();
            return;
        }
        videoCurrentposition--;
        getVideoPath();
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        this.isOnMediaonPrepared = true;
        VideoNext();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (!IsSurfaceCreated) {
            if (mediaPlayer == null) {
                SetVideoWithSurface();
                mediaPlayer.setDisplay(surfaceView.getHolder());
                return;
            }
            mediaPlayer.setDisplay(surfaceView.getHolder());
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        if (mediaPlayer != null) {
            mediaPlayer.pause();
            mediaPlayer.setDisplay(null);
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case R.id.ivVideoShareYoutube: {
                ShareVideo(getResources().getString(R.string.youtube_package), getResources().getString(R.string.youtube));
                break;
            }
            case R.id.ivVideoShareWhatsApp: {
                ShareVideo(getResources().getString(R.string.whatsapp_package), getResources().getString(R.string.whatsapp));
                break;
            }
            case R.id.ivVideoShareMore: {
                try {
                    if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
                        ivPlayerPlayPause.setImageResource(R.drawable.icon_player_play);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                File file = new File(this.VideoUrl);
                final Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/*");
                final StringBuilder sb = new StringBuilder();
                sb.append(this.getResources().getString(R.string.app_name));
                sb.append(": ");
                sb.append(this.getString(R.string.get_free));
                sb.append(this.getString(R.string.app_name));
                sb.append(" Music at here : https://play.google.com/store/apps/details?id=");
                sb.append(this.getPackageName());
                final Uri ShareUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file);
                intent.putExtra("android.intent.extra.TEXT", sb.toString());
                intent.putExtra("android.intent.extra.STREAM", ShareUri);
                this.startActivity(Intent.createChooser(intent, (CharSequence) this.getString(R.string.share_video)));
                return;
            }
            case R.id.ivVideoShareInsta: {
                ShareVideo(getResources().getString(R.string.instagram_package), getResources().getString(R.string.instagram));
                break;
            }
            case R.id.ivVideoShareFb: {
                ShareVideo(getResources().getString(R.string.facebook_package), getResources().getString(R.string.facebook));
                break;
            }
            case R.id.ivIconBackFromMyCreation: {
                onBackPressed();
                break;
            }
        }
    }

    private void GoBack() {
        if (IsFromAndroidlist) {
            Intent intent = new Intent(activity, YourVideoActivity.class);
            startActivity(intent);
            finish();
        } else {
            AndroidUnityCall.ScanVideoList(activity, MyApplication.VideoPath);
            Intent intent = new Intent(activity, YourVideoActivity.class);
            startActivity(intent);
            finish();
        }
    }

    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        if (MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
            stopPlaying(mediaPlayer);
            MyApplication.AdsId = 7;
            MyApplication.AdsShowContext = activity;
            MyApplication.fbinterstitialAd.show();
        } else {
            List list = AllVideolist;
            if (list != null) {
                int i = videoCurrentposition;
                if (i >= 0 && i < list.size()) {
                    if (mediaPlayer != null) {
                        long currentPosition = mediaPlayer.getCurrentPosition();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(AllVideolist.get(videoCurrentposition).videoDuration);
                        VideoPlayerPreference.a(this, currentPosition, stringBuilder.toString());
                    }
                }
            }
            stopPlaying(mediaPlayer);
            IsSurfaceCreated = true;
            GoBack();
        }
    }
}
