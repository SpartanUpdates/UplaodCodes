package com.example.lyricsvideo.Model;

public class VideoInfo {
    public boolean isAvailableOfflineShareVideo = false;
    public boolean isDownloadingshareVideo = false;
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
    private String Category_id;
    private String VideoId;
    private String CategoryName;
    private String VideoName;
    private String SmallThemeImage;
    private String LargeThemeImage;
    private String PreviewVideoUrl;
    private String PreviewVideoName;
    private String ContentZipFilePath;
    private String ContentZipFolderName;
    private String ContentZipFileName;
    private String ThemeVersion;
    private String DownloadCount;
    private String ShareCount;
    private String ViewCount;
    private String VideoCreateDate;
    private int PreviewVideoSize;
    private int ContentZipFileSize;
    private int NoOfImages;
    private int Height;
    private int Width;
    public boolean IsNativeAds = false;
    public String getCategory_id() {
        return Category_id;
    }

    public void setCategory_id(String category_id) {
        Category_id = category_id;
    }

    public String getVideoId() {
        return VideoId;
    }

    public void setVideoId(String videoId) {
        VideoId = videoId;
    }

    public String getVideoName() {
        return VideoName;
    }

    public void setVideoName(String videoName) {
        VideoName = videoName;
    }

    public String getCategoryName() {
        return CategoryName;
    }

    public void setCategoryName(String categoryName) {
        CategoryName = categoryName;
    }

    public String getSmallThemeImage() {
        return SmallThemeImage;
    }

    public void setSmallThemeImage(String smallThemeImage) {
        SmallThemeImage = smallThemeImage;
    }

    public String getLargeThemeImage() {
        return LargeThemeImage;
    }

    public void setLargeThemeImage(String largeThemeImage) {
        LargeThemeImage = largeThemeImage;
    }

    public String getPreviewVideoUrl() {
        return PreviewVideoUrl;
    }

    public void setPreviewVideoUrl(String previewVideoUrl) {
        PreviewVideoUrl = previewVideoUrl;
    }

    public String getPreviewVideoName() {
        return PreviewVideoName;
    }

    public void setPreviewVideoName(String previewVideoName) {
        PreviewVideoName = previewVideoName;
    }

    public String getContentZipFilePath() {
        return ContentZipFilePath;
    }

    public void setContentZipFilePath(String contentZipFilePath) {
        ContentZipFilePath = contentZipFilePath;
    }

    public String getContentZipFolderName() {
        return ContentZipFolderName;
    }

    public void setContentZipFolderName(String contentZipFolderName) {
        ContentZipFolderName = contentZipFolderName;
    }

    public String getContentZipFileName() {
        return ContentZipFileName;
    }

    public void setContentZipFileName(String contentZipFileName) {
        ContentZipFileName = contentZipFileName;
    }

    public String getThemeVersion() {
        return ThemeVersion;
    }

    public void setThemeVersion(String themeVersion) {
        ThemeVersion = themeVersion;
    }

    public String getDownloadCount() {
        return DownloadCount;
    }

    public void setDownloadCount(String downloadCount) {
        DownloadCount = downloadCount;
    }

    public String getShareCount() {
        return ShareCount;
    }

    public void setShareCount(String shareCount) {
        ShareCount = shareCount;
    }

    public String getViewCount() {
        return ViewCount;
    }

    public void setViewCount(String viewCount) {
        ViewCount = viewCount;
    }

    public String getVideoCreateDate() {
        return VideoCreateDate;
    }

    public void setVideoCreateDate(String videoCreateDate) {
        VideoCreateDate = videoCreateDate;
    }

    public int getPreviewVideoSize() {
        return PreviewVideoSize;
    }

    public void setPreviewVideoSize(int previewVideoSize) {
        PreviewVideoSize = previewVideoSize;
    }

    public int getContentZipFileSize() {
        return ContentZipFileSize;
    }

    public void setContentZipFileSize(int contentZipFileSize) {
        ContentZipFileSize = contentZipFileSize;
    }

    public int getNoOfImages() {
        return NoOfImages;
    }

    public void setNoOfImages(int noOfImages) {
        NoOfImages = noOfImages;
    }

    public int getHeight() {
        return Height;
    }

    public void setHeight(int height) {
        Height = height;
    }

    public int getWidth() {
        return Width;
    }

    public void setWidth(int width) {
        Width = width;
    }

    public boolean isNativeAds() {
        return IsNativeAds;
    }

    public void setNativeAds(boolean nativeAds) {
        IsNativeAds = nativeAds;
    }
}
