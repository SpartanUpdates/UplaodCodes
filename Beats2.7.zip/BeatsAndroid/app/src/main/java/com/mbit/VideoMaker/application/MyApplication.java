package com.mbit.VideoMaker.application;

import android.app.Application;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Model.ImageInfo;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.cropImage.CropImage;
import com.root.bridge.AndroidPluginClass;

import java.util.ArrayList;
import java.util.HashMap;


public class MyApplication extends Application {

    public static String b = "Beats";
    public static Context mContext;
    public static int IS_EDITIMAGE;
    public static int TotalSelectedImage;
    public static String APP_SPLIT_PATTERN;
    public static ArrayList<ImageInfo> selectedImageslist = new ArrayList<>();
    public static boolean IsSongCuttingready = false;
    public static boolean IsVideoready = false;
    public static boolean IsAudioVideoMearge = false;
    public static String CutSongPath;
    public static boolean isBreak;
    public static boolean IsSelectImageFrom;
    public static KProgressHUD hud;
    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;
    public static ArrayList<String> stringArrayList = new ArrayList<String>();
    public static boolean aa = false;
    public static String e = "Beats";
    public static InterstitialAd mInterstitialAd;
    private static MyApplication instance;

    static {
        MyApplication.IS_EDITIMAGE = 0;
        MyApplication.isBreak = false;
        MyApplication.TotalSelectedImage = 5;
        MyApplication.APP_SPLIT_PATTERN = "?";

    }

    public int posForAddMusicDialog;
    public boolean isEditModeEnable;
    public boolean isFromSdCardAudio;
    public HashMap<String, ArrayList<ImageInfo>> AllAlbumList;
    public ArrayList<String> videoImages;
    public ArrayList<String> welcomeImages;
    public int MinimumPosition;
    public ArrayList<CropImage> cropimaglist = new ArrayList<>();
    public int min_pos;
    public boolean IsNativeAdsLoaded = false;
    String SongDirPath;

    private String selectedFolderId;
    private ArrayList<String> AllFolderList;

    public MyApplication() {
        this.posForAddMusicDialog = 0;
        this.isEditModeEnable = false;
        this.isFromSdCardAudio = false;
        this.videoImages = new ArrayList<String>();
        this.welcomeImages = new ArrayList<String>();
        selectedImageslist = new ArrayList<ImageInfo>();
        cropimaglist = new ArrayList<CropImage>();
        this.selectedFolderId = "";
        this.MinimumPosition = Integer.MAX_VALUE;
        this.SongDirPath = "";
        this.min_pos = Integer.MAX_VALUE;
        this.posForAddMusicDialog = 0;
        this.videoImages = new ArrayList<String>();
        this.welcomeImages = new ArrayList<String>();


    }

    public static MyApplication e() {
        return instance;
    }

    public static MyApplication getInstance() {
        return MyApplication.instance;

    }

    public void init() {
        this.getFolderList();
    }

    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MyApplication.mContext = this.getApplicationContext();
        MobileAds.initialize(MyApplication.mContext, MyApplication.mContext.getResources().getString(R.string.admob_app_id));
        LoadAdsForUnity(MyApplication.mContext);
        getArrayOfApp();
    }


    public void LoadAdsForUnity(final Context context) {
        mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(context.getResources().getString(R.string.interstitial_BackFromPreviewHome));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                AndroidPluginClass.loadMainActivity(context);
                if (mInterstitialAd != null) {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                if (mInterstitialAd != null) {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }
            }
        });
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageInfo>> getAllAlbumList() {
        return this.AllAlbumList;
    }

    public ArrayList<ImageInfo> getImageByAlbum(final String folderId) {
        ArrayList<ImageInfo> imageDatas = this.getAllAlbumList().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageInfo>();
        }
        return imageDatas;
    }

    public ArrayList<ImageInfo> getSelectedImageslist() {
        return selectedImageslist;
    }

    public void addSelectedImage(final ImageInfo imageData) {
        selectedImageslist.add(imageData);
        ++imageData.NoOfImage;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= selectedImageslist.size()) {
            final ImageInfo imageData2 = selectedImageslist.remove(imageData);
            --imageData2.NoOfImage;
        }
    }

    public void ReplaceSelectedImage(ImageInfo imageData, int pos) {
        selectedImageslist.set(pos, imageData);
    }

    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void getArrayOfApp() {
        String[] stringsArry = {
                "Photo Slideshow with Music: Video Status Maker",
                "Music Video Maker: Slideshow",
                "Photo Video Editor",
                "MBit Music : Particle.ly Video Status Maker",
                "MBit",
                "Particle.ly",
                "Video Editor",
                "Tiktok Video Maker",
                "Photo Video Maker",
                "Video Status Maker",
                "Image to Video Maker",
                "bits video maker",
                "bits",
                "Particle.ly : bits",
                "Bets : Video Status Maker",
                "Beats"
        };
    }

    public void getFolderList() {
        this.AllFolderList = new ArrayList<String>();
        this.AllAlbumList = new HashMap<String, ArrayList<ImageInfo>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"};
        final Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, null, null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumn = cur.getColumnIndex("bucket_id");

            ImageInfo data = null;
            this.setSelectedFolderId(cur.getString(bucketIdColumn));
            do {
                data = new ImageInfo();
                data.ImagePath = cur.getString(cur.getColumnIndex("_data"));
                data.ThumbbailImage = cur.getString(cur.getColumnIndex("_data"));
                if (!data.ImagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumn);
                    final String folderId = cur.getString(bucketIdColumn);
                    if (!this.AllFolderList.contains(folderId)) {
                        this.AllFolderList.add(folderId);
                    }
                    ArrayList<ImageInfo> imagePath = this.AllAlbumList.get(folderId);
                    if (imagePath == null) {
                        imagePath = new ArrayList<ImageInfo>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    this.AllAlbumList.put(folderId, imagePath);


                }
            } while (cur.moveToNext());
        }
    }

}
