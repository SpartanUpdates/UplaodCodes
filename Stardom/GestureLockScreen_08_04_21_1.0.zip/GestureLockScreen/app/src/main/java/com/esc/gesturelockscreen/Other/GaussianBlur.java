package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.renderscript.Allocation;
import android.renderscript.Allocation.MipmapControl;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.widget.ImageView;
import androidx.annotation.FloatRange;
import androidx.annotation.IntRange;
import androidx.annotation.UiThread;
import androidx.annotation.WorkerThread;
import java.lang.ref.WeakReference;

public class GaussianBlur {
    private Context context;
    private int radius;
    private float size;

    class BitmapGaussianAsync extends GaussianAsync<Bitmap> {
        public BitmapGaussianAsync(ImageView imageView) {
            super(imageView);
        }

        public Bitmap doInBackground(Bitmap... bitmapArr) {
            return GaussianBlur.this.render(bitmapArr[0]);
        }
    }

    abstract class GaussianAsync<T> extends AsyncTask<T, Void, Bitmap> {
        private final WeakReference<ImageView> imageViewReference;

        public GaussianAsync(ImageView imageView) {
            this.imageViewReference = new WeakReference<>(imageView);
        }

        public void onPostExecute(Bitmap bitmap) {
            WeakReference<ImageView> weakReference = this.imageViewReference;
            if (weakReference != null && bitmap != null) {
                ImageView imageView = (ImageView) weakReference.get();
                if (imageView != null) {
                    imageView.setImageBitmap(bitmap);
                }
            }
        }
    }

    class ResourceGaussianAsync extends GaussianAsync<Integer> {
        public ResourceGaussianAsync(ImageView imageView) {
            super(imageView);
        }

        public Bitmap doInBackground(Integer... numArr) {
            return GaussianBlur.this.render(numArr[0].intValue());
        }
    }

    private GaussianBlur(Context context2) {
        this.context = context2;
        radius(25);
        size(800.0f);
    }

    public static GaussianBlur with(Context context2) {
        return new GaussianBlur(context2);
    }

    @WorkerThread
    public Bitmap render(int i) {
        return render(BitmapFactory.decodeResource(this.context.getResources(), i));
    }

    @WorkerThread
    public Bitmap render(Drawable drawable) {
        return render(((BitmapDrawable) drawable).getBitmap());
    }

    @WorkerThread
    public Bitmap render(Bitmap bitmap) {
        RenderScript create = RenderScript.create(this.context);
        if (getSize() > 0.0f) {
            bitmap = scaleDown(bitmap);
        }
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
        Allocation createFromBitmap = Allocation.createFromBitmap(create, bitmap, MipmapControl.MIPMAP_NONE, 2);
        Allocation createFromBitmap2 = Allocation.createFromBitmap(create, createBitmap);
        ScriptIntrinsicBlur create2 = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
            create2 = ScriptIntrinsicBlur.create(create, createFromBitmap.getElement());
            create2.setRadius((float) getRadius());
            create2.setInput(createFromBitmap);
            create2.forEach(createFromBitmap2);
        }
        createFromBitmap2.copyTo(createBitmap);
        create.destroy();
        return createBitmap;
    }

    @UiThread
    public void put(Drawable drawable, ImageView imageView) {
        new BitmapGaussianAsync(imageView).execute(new Bitmap[]{((BitmapDrawable) drawable).getBitmap()});
    }

    @UiThread
    public void put(Bitmap bitmap, ImageView imageView) {
        new BitmapGaussianAsync(imageView).execute(new Bitmap[]{bitmap});
    }

    @UiThread
    public void put(int i, ImageView imageView) {
        new ResourceGaussianAsync(imageView).execute(new Integer[]{Integer.valueOf(i)});
    }

    @WorkerThread
    public Bitmap scaleDown(int i) {
        return scaleDown(BitmapFactory.decodeResource(this.context.getResources(), i));
    }

    @WorkerThread
    public Bitmap scaleDown(Bitmap bitmap) {
        float min = Math.min(getSize() / ((float) bitmap.getWidth()), getSize() / ((float) bitmap.getHeight()));
        return Bitmap.createScaledBitmap(bitmap, Math.round(((float) bitmap.getWidth()) * min), Math.round(((float) bitmap.getHeight()) * min), true);
    }

    public int getRadius() {
        return this.radius;
    }

    public GaussianBlur radius(@IntRange(from = 0, to = 25) int i) {
        this.radius = i;
        return this;
    }

    public float getSize() {
        return this.size;
    }

    public GaussianBlur size(@FloatRange(from = 0.0d, to = 800.0d) float f) {
        this.size = f;
        return this;
    }
}
