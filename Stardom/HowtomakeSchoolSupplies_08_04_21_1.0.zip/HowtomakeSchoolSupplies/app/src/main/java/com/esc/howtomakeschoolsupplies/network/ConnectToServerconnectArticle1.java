package com.esc.howtomakeschoolsupplies.network;

import android.util.Log;

import androidx.core.app.NotificationCompat;
import java.util.List;
import java.util.Timer;
import kotlin.jvm.internal.Intrinsics;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer.LoadingArticles;
import com.esc.howtomakeschoolsupplies.pojo.Article;

public class ConnectToServerconnectArticle1 implements Callback<List<Article>> {
    final LoadingArticles $loadingArticles;
    final ConnectToServer this$0;

   public ConnectToServerconnectArticle1(ConnectToServer connectToServer, LoadingArticles loadingArticles) {
        this.this$0 = connectToServer;
        this.$loadingArticles = loadingArticles;
   }

   public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
        Intrinsics.checkParameterIsNotNull(call, NotificationCompat.CATEGORY_CALL);
        Intrinsics.checkParameterIsNotNull(response, "response");
        if (response.isSuccessful()) {
            List list = response.body();
            if (list != null) {
                LoadingArticles loadingArticles = this.$loadingArticles;
                Intrinsics.checkExpressionValueIsNotNull(list, "it");
                loadingArticles.initArticles(list);
            }
        }
   }

   public void onFailure(Call<List<Article>> call, Throwable th) {
        Intrinsics.checkParameterIsNotNull(call, NotificationCompat.CATEGORY_CALL);
        Intrinsics.checkParameterIsNotNull(th, "t");
        th.printStackTrace();
        new Timer("connectArticle", false).schedule(new ConnectToServerconnectArticle1onFailureinlinedschedule1(this), this.this$0.getTimeReconnect());
   }
}
