package com.esc.phoneheart.model;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore.Audio.Media;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Video;
import android.text.TextUtils;
import android.util.Log;

import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import com.esc.phoneheart.model.FileType.FileTypes;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class MediaList {
    public String TAG;
    public ArrayList<BigSizeFilesWrapper> arrContents = new ArrayList();
    public Context cntx;
    public ArrayList<BigSizeFilesWrapper> filesList = new ArrayList();
    public FileTypes mediaType;
    public int recoveredCount;
    public long recoveredSize;
    public int selectedCount;
    public long selectedSize;
    public String title;
    public int totalCount;
    public long totalSize;

    public interface updateProgress {
        void update(String str);
    }

    public MediaList(Context context, String str, FileTypes fileTypes) {
        String str2 = "MediaList";
        this.TAG = str2;
        Util.appendLogphonecleaner(str2, " Constractor  MediaList with 5 perameter  ", GlobalData.FILE_NAME);
        this.title = str;
        this.cntx = context;
        this.mediaType = fileTypes;
    }

    private void addChild(BigSizeFilesWrapper bigSizeFilesWrapper) {
        this.totalCount++;
        this.totalSize += bigSizeFilesWrapper.size;
        this.arrContents.add(bigSizeFilesWrapper);
    }

    public void deleteNode(BigSizeFilesWrapper bigSizeFilesWrapper) {
        Util.appendLogphonecleaner(this.TAG, " method deleteNode  ", GlobalData.FILE_NAME);
        this.selectedCount--;
        long j = this.selectedSize;
        long j2 = bigSizeFilesWrapper.size;
        this.selectedSize = j - j2;
        this.totalCount--;
        this.totalSize -= j2;
        this.recoveredCount++;
        this.recoveredSize += j2;
    }

    public void fetchAPK(long j, HashMap<String, Boolean> hashMap) {
        String str = "date_added";
        String str2 = "_display_name";
        String str3 = "_data";
        String str4 = "_id";
        String str5 = "_size";
        try {
            String[] strArr = new String[]{str4, str3, str2, str5, str};
            ContentResolver contentResolver = this.cntx.getContentResolver();
            Uri contentUri = Files.getContentUri("external");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str5);
            stringBuilder.append(" DESC");
            Cursor query = contentResolver.query(contentUri, strArr, null, null, stringBuilder.toString());
            if (query != null) {
                int columnIndex = query.getColumnIndex(str3);
                int columnIndex2 = query.getColumnIndex(str5);
                query.getColumnIndex(str2);
                int columnIndex3 = query.getColumnIndex(str4);
                int columnIndex4 = query.getColumnIndex(str);
                for (int i = 0; i < query.getCount(); i++) {
                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(GlobalData.backuppath);
                    if (!string.contains(stringBuilder2.toString())) {
                        long j2 = query.getLong(columnIndex2);
                        int i2 = query.getInt(columnIndex3);
                        long j3 = query.getLong(columnIndex4);
                        String substring = string.substring(string.lastIndexOf("/") + 1);
                        if (TextUtils.isEmpty(substring)) {
                            substring = new File(string).getName();
                        }
                        if (j2 >= j) {
                            BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                            str4 = FilenameUtils.getExtension(string);
                            bigSizeFilesWrapper.ext = str4;
                            bigSizeFilesWrapper.name = substring;
                            bigSizeFilesWrapper.id = i2;
                            bigSizeFilesWrapper.path = string;
                            bigSizeFilesWrapper.size = j2;
                            bigSizeFilesWrapper.dateTaken = j3;
                            Boolean bool = (Boolean) hashMap.get(str4.toLowerCase());
                            if (bool == null) {
                                bool = Boolean.valueOf(false);
                            }
                            if (bool.booleanValue()) {
                                File file = new File(string);
                                if (!(!file.exists() || file.isDirectory() || file.isHidden() || file.getPath().contains("/."))) {
                                    addChild(bigSizeFilesWrapper);
                                }
                            }
                        }
                    }
                    HashMap<String, Boolean> hashMap2 = hashMap;
                }
            }
            if (query != null) {
                query.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchAllFiles(ArrayList<BigSizeFilesWrapper> arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            addChild((BigSizeFilesWrapper) arrayList.get(i));
        }
    }

    public void fetchAudio() {
        String str = "date_added";
        String str2 = "_size";
        String str3 = "_display_name";
        String str4 = "_data";
        String str5 = "_id";
        try {
            int columnIndex;
            int columnIndex2;
            int columnIndex3;
            int columnIndex4;
            int columnIndex5;
            Cursor query = this.cntx.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{str5, str4, str3, str2, str}, null, null, "_size DESC");
            int i = 0;
            if (query != null) {
                columnIndex = query.getColumnIndex(str4);
                columnIndex2 = query.getColumnIndex(str2);
                columnIndex3 = query.getColumnIndex(str3);
                columnIndex4 = query.getColumnIndex(str5);
                columnIndex5 = query.getColumnIndex(str);
            } else {
                columnIndex5 = 0;
                columnIndex2 = 0;
                columnIndex3 = 0;
                columnIndex = 0;
                columnIndex4 = 0;
            }
            long j = 0;
            if (query != null) {
                while (i < query.getCount()) {
                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    long j2 = query.getLong(columnIndex2);
                    String string2 = query.getString(columnIndex3);
                    if (TextUtils.isEmpty(string2)) {
                        string2 = new File(string).getName();
                    }
                    int i2 = query.getInt(columnIndex4);
                    int i3 = columnIndex2;
                    int i4 = columnIndex3;
                    long j3 = query.getLong(columnIndex5);
                    if (j2 >= j) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                        bigSizeFilesWrapper.name = string2;
                        bigSizeFilesWrapper.id = i2;
                        bigSizeFilesWrapper.path = string;
                        bigSizeFilesWrapper.size = j2;
                        bigSizeFilesWrapper.dateTaken = j3;
                        addChild(bigSizeFilesWrapper);
                    }
                    i++;
                    columnIndex2 = i3;
                    columnIndex3 = i4;
                    j = 0;
                }
            }
            if (query != null) {
                query.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchFilesForExtns(long j, HashMap<String, Boolean> hashMap) {
        String str = "date_added";
        String str2 = "_size";
        String str3 = "_display_name";
        String str4 = "_data";
        String str5 = "_id";
        try {
            Cursor query = this.cntx.getContentResolver().query(Files.getContentUri("external"), new String[]{str5, str4, str3, str2, str}, null, null, "_size DESC");
            if (query != null) {
                int columnIndex = query.getColumnIndex(str4);
                int columnIndex2 = query.getColumnIndex(str2);
                query.getColumnIndex(str3);
                int columnIndex3 = query.getColumnIndex(str5);
                int columnIndex4 = query.getColumnIndex(str);
                for (int i = 0; i < query.getCount(); i++) {
                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    long j2 = query.getLong(columnIndex2);
                    int i2 = query.getInt(columnIndex3);
                    long j3 = query.getLong(columnIndex4);
                    String substring = string.substring(string.lastIndexOf("/") + 1);
                    if (TextUtils.isEmpty(substring)) {
                        substring = new File(string).getName();
                    }
                    if (j2 >= j) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                        str5 = FilenameUtils.getExtension(string);
                        bigSizeFilesWrapper.ext = str5;
                        bigSizeFilesWrapper.name = substring;
                        bigSizeFilesWrapper.id = i2;
                        bigSizeFilesWrapper.path = string;
                        bigSizeFilesWrapper.size = j2;
                        bigSizeFilesWrapper.dateTaken = j3;
                        Boolean bool = (Boolean) hashMap.get(str5.toLowerCase());
                        if (bool == null) {
                            bool = Boolean.valueOf(false);
                        }
                        if (bool.booleanValue()) {
                            File file = new File(string);
                            if (!(!file.exists() || file.isDirectory() || file.isHidden() || file.getPath().contains("/."))) {
                                addChild(bigSizeFilesWrapper);
                            }
                        }
                    } else {
                        HashMap<String, Boolean> hashMap2 = hashMap;
                    }
                }
            }
            if (query != null) {
                query.close();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("files ");
            stringBuilder.append(this.arrContents.size());
            Log.d("SIZE", stringBuilder.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchFilesForNotInExtns(long j, HashMap<String, Boolean> hashMap) {
        String str = "date_added";
        String str2 = "_size";
        String str3 = "_display_name";
        String str4 = "_data";
        String str5 = "_id";
        try {
            Cursor query = this.cntx.getContentResolver().query(Files.getContentUri("external"), new String[]{str5, str4, str3, str2, str}, null, null, "_size DESC");
            if (query != null) {
                int columnIndex = query.getColumnIndex(str4);
                int columnIndex2 = query.getColumnIndex(str2);
                query.getColumnIndex(str3);
                int columnIndex3 = query.getColumnIndex(str5);
                int columnIndex4 = query.getColumnIndex(str);
                for (int i = 0; i < query.getCount(); i++) {
                    HashMap<String, Boolean> hashMap2;
                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    if (string == null || !string.contains(GlobalData.backuppath)) {
                        long j2 = query.getLong(columnIndex2);
                        int i2 = query.getInt(columnIndex3);
                        long j3 = query.getLong(columnIndex4);
                        String substring = string != null ? string.substring(string.lastIndexOf("/") + 1) : null;
                        if (TextUtils.isEmpty(substring) && string != null) {
                            substring = new File(string).getName();
                        }
                        if (j2 >= j) {
                            Boolean bool;
                            BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                            str5 = FilenameUtils.getExtension(string);
                            bigSizeFilesWrapper.ext = str5;
                            bigSizeFilesWrapper.name = substring;
                            bigSizeFilesWrapper.id = i2;
                            bigSizeFilesWrapper.path = string;
                            bigSizeFilesWrapper.size = j2;
                            bigSizeFilesWrapper.dateTaken = j3;
                            if (str5 != null) {
                                bool = (Boolean) hashMap.get(str5.toLowerCase());
                            } else {
                                hashMap2 = hashMap;
                                bool = null;
                            }
                            if (bool == null) {
                                bool = Boolean.valueOf(false);
                            }
                            if (!bool.booleanValue()) {
                                File file = string != null ? new File(string) : null;
                                if (!(file == null || !file.exists() || file.isDirectory() || file.isHidden() || file.getPath().contains("/."))) {
                                    addChild(bigSizeFilesWrapper);
                                }
                            }
                        }
                    }
                    hashMap2 = hashMap;
                }
            }
            if (query != null) {
                query.close();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("files ");
            stringBuilder.append(this.arrContents.size());
            Log.d("SIZE", stringBuilder.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchImages() {
        String str = "datetaken";
        String str2 = "_size";
        String str3 = "_display_name";
        String str4 = "_data";
        String str5 = "_id";
        try {
            Cursor query = this.cntx.getContentResolver().query(Images.Media.EXTERNAL_CONTENT_URI, new String[]{str5, str4, str3, str2, str}, null, null, "_size DESC");
            if (query != null) {
                int columnIndex = query.getColumnIndex(str4);
                int columnIndex2 = query.getColumnIndex(str2);
                int columnIndex3 = query.getColumnIndex(str3);
                int columnIndex4 = query.getColumnIndex(str5);
                int columnIndex5 = query.getColumnIndex(str);

                for (int i = 0; i < query.getCount(); i++) {

                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    long j = query.getLong(columnIndex2);
                    String string2 = query.getString(columnIndex3);
                    long j2 = query.getLong(columnIndex5);
                    if (TextUtils.isEmpty(string2)) {
                        string2 = new File(string).getName();
                    }
                    int i2 = query.getInt(columnIndex4);
                    if (j >= 32768) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                        bigSizeFilesWrapper.name = string2;
                        bigSizeFilesWrapper.id = i2;
                        bigSizeFilesWrapper.path = string;
                        bigSizeFilesWrapper.size = j;
                        bigSizeFilesWrapper.dateTaken = j2;
                        addChild(bigSizeFilesWrapper);
                    }
                }
                query.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("image ");
        stringBuilder.append(this.arrContents.size());
        Log.e("SIZE", stringBuilder.toString());
    }

    public void fetchVideos() {
        String str = "datetaken";
        String str2 = "_size";
        String str3 = "_display_name";
        String str4 = "_data";
        String str5 = "_id";
        try {
            int columnIndex;
            int columnIndex2;
            int columnIndex3;
            int columnIndex4;
            int columnIndex5;
            Cursor query = this.cntx.getContentResolver().query(Video.Media.EXTERNAL_CONTENT_URI, new String[]{str5, str4, str3, str2, str}, null, null, "_size DESC");
            if (query != null) {
                columnIndex = query.getColumnIndex(str4);
                columnIndex2 = query.getColumnIndex(str2);
                columnIndex3 = query.getColumnIndex(str3);
                columnIndex4 = query.getColumnIndex(str5);
                columnIndex5 = query.getColumnIndex(str);
            } else {
                columnIndex5 = 0;
                columnIndex2 = 0;
                columnIndex3 = 0;
                columnIndex = 0;
                columnIndex4 = 0;
            }
            if (query != null) {
                for (int i = 0; i < query.getCount(); i++) {
                    query.moveToPosition(i);
                    String string = query.getString(columnIndex);
                    long j = query.getLong(columnIndex2);
                    String string2 = query.getString(columnIndex3);
                    if (TextUtils.isEmpty(string2)) {
                        string2 = new File(string).getName();
                    }
                    int i2 = query.getInt(columnIndex4);
                    long j2 = query.getLong(columnIndex5);
                    String str6 = "";
                    if (TextUtils.isEmpty(string2)) {
                        if (TextUtils.isEmpty(string)) {
                            string = str6;
                            string2 = string;
                        } else {
                            string2 = new File(string).getName();
                        }
                    }
                    if (j >= 0) {
                        BigSizeFilesWrapper bigSizeFilesWrapper = new BigSizeFilesWrapper();
                        bigSizeFilesWrapper.name = string2;
                        bigSizeFilesWrapper.id = i2;
                        bigSizeFilesWrapper.path = string;
                        bigSizeFilesWrapper.size = j;
                        bigSizeFilesWrapper.dateTaken = j2;
                        addChild(bigSizeFilesWrapper);
                    }
                }
            }
            if (query != null) {
                query.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("video ");
        stringBuilder.append(this.arrContents.size());
        Log.e("SIZE", stringBuilder.toString());

    }

    public String getSelectedTotalString() {
        Util.appendLogphonecleaner(this.TAG, " method getSelectedTotalString  ", GlobalData.FILE_NAME);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.selectedCount);
        stringBuilder.append("/");
        stringBuilder.append(this.totalCount);
        return stringBuilder.toString();
    }

    public void initRecoveredBeforeDelete() {
        this.recoveredCount = 0;
        this.recoveredSize = 0;
    }

    public void refresh() {
        for (int i = 0; i < this.arrContents.size(); i++) {
            ((BigSizeFilesWrapper) this.arrContents.get(i)).ischecked = false;
        }
        this.selectedSize = 0;
        this.selectedCount = 0;
    }

    public void selectAll(ArrayList<BigSizeFilesWrapper> arrayList) {
        long j = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) arrayList.get(i);
            bigSizeFilesWrapper.ischecked = true;
            j += bigSizeFilesWrapper.size;
        }
        this.selectedCount = arrayList.size();
        this.selectedSize = j;
    }

    public void selectNodeAtIndex(int i) {
        Util.appendLogphonecleaner(this.TAG, " method selectNodeAtIndex  ", GlobalData.FILE_NAME);
        BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) this.filesList.get(i);
        bigSizeFilesWrapper.ischecked = true;
        this.selectedCount++;
        this.selectedSize += bigSizeFilesWrapper.size;
    }

    public void unSelectAll() {
        Util.appendLogphonecleaner(this.TAG, " method unSelectAll call ", GlobalData.FILE_NAME);
        for (int i = 0; i < this.arrContents.size(); i++) {
            ((BigSizeFilesWrapper) this.arrContents.get(i)).ischecked = false;
        }
        this.selectedCount = 0;
        this.selectedSize = 0;
    }

    public void unSelectNodeAtIndex(int i) {
        Util.appendLogphonecleaner(this.TAG, " method unSelectNodeAtIndex  ", GlobalData.FILE_NAME);
        BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) this.filesList.get(i);
        bigSizeFilesWrapper.ischecked = false;
        this.selectedCount--;
        this.selectedSize -= bigSizeFilesWrapper.size;
    }

    public void selectAll() {
        Util.appendLogphonecleaner(this.TAG, " method selectAll call ", GlobalData.FILE_NAME);
        for (int i = 0; i < this.arrContents.size(); i++) {
            ((BigSizeFilesWrapper) this.arrContents.get(i)).ischecked = true;
        }
        this.selectedCount = this.totalCount;
        this.selectedSize = this.totalSize;
    }
}
