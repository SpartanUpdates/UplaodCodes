package com.vidsoft.Filters.scrollgalleryview.Grid3DFilter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.AdapterDataObserver;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.SectionIndexer;

import com.vidsoft.collagemaker.pipphotoeffect.R;

public class IndexFastScrollRecyclerSection extends AdapterDataObserver {
    private static final int WHAT_FADE_PREVIEW = 1;
    AttributeSet attrs;
    private int indexPaintPaintColor;
    private int indexbarBackgroudAlpha;
    private String indexbarBackgroudColor;
    private String indexbarTextColor;
    private int mCurrentSection;
    private float mDensity;
    private Handler mHandler;
    private float mIndexbarMargin;
    private RectF mIndexbarRect;
    private float mIndexbarWidth;
    private SectionIndexer mIndexer;
    private boolean mIsIndexing;
    private int mListViewHeight;
    private int mListViewWidth;
    private float mPreviewPadding;
    private RecyclerView mRecyclerView;
    private float mScaledDensity;
    private String[] mSections;
    private int setIndexBarCornerRadius;
    private int setIndexTextSize;
    private float setIndexbarMargin;
    private float setIndexbarWidth;
    private int setPreviewPadding;
    private Typeface setTypeface;

    public IndexFastScrollRecyclerSection(Context context, RecyclerView rv) {
        this.mCurrentSection = -1;
        this.mIsIndexing = false;
        this.mRecyclerView = null;
        this.mIndexer = null;
        this.mSections = null;
        this.setIndexTextSize = IndexFastScrollRecyclerView.setIndexTextSize;
        this.setIndexbarWidth = IndexFastScrollRecyclerView.mIndexbarWidth;
        this.setIndexbarMargin = IndexFastScrollRecyclerView.mIndexbarMargin;
        this.setPreviewPadding = IndexFastScrollRecyclerView.mPreviewPadding;
        this.setIndexBarCornerRadius = IndexFastScrollRecyclerView.mIndexBarCornerRadius;
        this.setTypeface = null;
        this.indexbarBackgroudColor = IndexFastScrollRecyclerView.mIndexbarBackgroudColor;
        this.indexbarTextColor = IndexFastScrollRecyclerView.mIndexbarTextColor;
        this.indexbarBackgroudAlpha = convertTransparentValueToBackgroundAlpha(IndexFastScrollRecyclerView.mIndexBarTransparentValue);
        this.indexPaintPaintColor = -1;
        this.mHandler = new Handler() {
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == IndexFastScrollRecyclerSection.WHAT_FADE_PREVIEW) {
                    IndexFastScrollRecyclerSection.this.mRecyclerView.invalidate();
                }
            }
        };
        this.mDensity = context.getResources().getDisplayMetrics().density;
        this.mScaledDensity = context.getResources().getDisplayMetrics().scaledDensity;
        this.mRecyclerView = rv;
        setAdapter(this.mRecyclerView.getAdapter());
        this.mIndexbarWidth = this.setIndexbarWidth * this.mDensity;
        this.mIndexbarMargin = this.setIndexbarMargin * this.mDensity;
        this.mPreviewPadding = ((float) this.setPreviewPadding) * this.mDensity;
    }

    public void draw(Canvas canvas) {
        Paint indexbarPaint = new Paint();
        indexbarPaint.setColor(Color.parseColor(this.indexbarBackgroudColor));
        indexbarPaint.setAlpha(this.indexbarBackgroudAlpha);
        indexbarPaint.setAntiAlias(true);
        Canvas canvas2 = canvas;
        canvas2.drawRoundRect(this.mIndexbarRect, ((float) this.setIndexBarCornerRadius) * this.mDensity, ((float) this.setIndexBarCornerRadius) * this.mDensity, indexbarPaint);
        if (this.mSections != null && this.mSections.length > 0) {
            if (this.mCurrentSection >= 0) {
                Paint previewPaint = new Paint();
                previewPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
                previewPaint.setAlpha(96);
                previewPaint.setAntiAlias(true);
                previewPaint.setShadowLayer(3.0f, 0.0f, 0.0f, Color.argb(64, 0, 0, 0));
                Paint previewTextPaint = new Paint();
                previewTextPaint.setColor(-1);
                previewTextPaint.setAntiAlias(true);
                previewTextPaint.setTextSize(50.0f * this.mScaledDensity);
                previewTextPaint.setTypeface(this.setTypeface);
                float previewTextWidth = previewTextPaint.measureText(this.mSections[this.mCurrentSection]);
                float previewSize = ((2.0f * this.mPreviewPadding) + previewTextPaint.descent()) - previewTextPaint.ascent();
                RectF previewRect = new RectF((((float) this.mListViewWidth) - previewSize) / 2.0f, (((float) this.mListViewHeight) - previewSize) / 2.0f, ((((float) this.mListViewWidth) - previewSize) / 2.0f) + previewSize, ((((float) this.mListViewHeight) - previewSize) / 2.0f) + previewSize);
                canvas.drawRoundRect(previewRect, 5.0f * this.mDensity, 5.0f * this.mDensity, previewPaint);
                canvas2 = canvas;
                canvas2.drawText(this.mSections[this.mCurrentSection], (previewRect.left + ((previewSize - previewTextWidth) / 2.0f)) - 1.0f, ((previewRect.top + this.mPreviewPadding) - previewTextPaint.ascent()) + 1.0f, previewTextPaint);
                fade(300);
            }
            Paint indexPaint = new Paint();
            indexPaint.setColor(Color.parseColor(this.indexbarTextColor));
            indexPaint.setAntiAlias(true);
            indexPaint.setTextSize(((float) this.setIndexTextSize) * this.mScaledDensity);
            indexPaint.setTypeface(this.setTypeface);
            float sectionHeight = (this.mIndexbarRect.height() - (2.0f * this.mIndexbarMargin)) / ((float) this.mSections.length);
            float paddingTop = (sectionHeight - (indexPaint.descent() - indexPaint.ascent())) / 2.0f;
            for (int i = 0; i < this.mSections.length; i += WHAT_FADE_PREVIEW) {
                canvas2 = canvas;
                canvas2.drawText(this.mSections[i], this.mIndexbarRect.left + ((this.mIndexbarWidth - indexPaint.measureText(this.mSections[i])) / 2.0f), (((this.mIndexbarRect.top + this.mIndexbarMargin) + (((float) i) * sectionHeight)) + paddingTop) - indexPaint.ascent(), indexPaint);
            }
        }
    }

    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case R.styleable.View_android_theme /*0*/:
                if (contains(ev.getX(), ev.getY())) {
                    this.mIsIndexing = true;
                    this.mCurrentSection = getSectionByPoint(ev.getY());
                    ((LinearLayoutManager) this.mRecyclerView.getLayoutManager()).scrollToPositionWithOffset(this.mIndexer.getPositionForSection(this.mCurrentSection), 0);
                    return true;
                }
                break;
            case WHAT_FADE_PREVIEW /*1*/:
                if (this.mIsIndexing) {
                    this.mIsIndexing = false;
                    this.mCurrentSection = -1;
                    break;
                }
                break;
            case R.styleable.View_paddingStart /*2*/:
                if (this.mIsIndexing) {
                    if (contains(ev.getX(), ev.getY())) {
                        this.mCurrentSection = getSectionByPoint(ev.getY());
                        ((LinearLayoutManager) this.mRecyclerView.getLayoutManager()).scrollToPositionWithOffset(this.mIndexer.getPositionForSection(this.mCurrentSection), 0);
                    }
                    return true;
                }
                break;
        }
        return false;
    }

    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        this.mListViewWidth = w;
        this.mListViewHeight = h;
        this.mIndexbarRect = new RectF((((float) w) - this.mIndexbarMargin) - this.mIndexbarWidth, this.mIndexbarMargin, ((float) w) - this.mIndexbarMargin, ((float) h) - this.mIndexbarMargin);
    }

    public void setAdapter(Adapter adapter) {
        if (adapter instanceof SectionIndexer) {
            adapter.registerAdapterDataObserver(this);
            this.mIndexer = (SectionIndexer) adapter;
            this.mSections = (String[]) this.mIndexer.getSections();
        }
    }

    public void onChanged() {
        super.onChanged();
        this.mSections = (String[]) this.mIndexer.getSections();
    }

    public boolean contains(float x, float y) {
        return x >= this.mIndexbarRect.left && y >= this.mIndexbarRect.top && y <= this.mIndexbarRect.top + this.mIndexbarRect.height();
    }

    private int getSectionByPoint(float y) {
        if (this.mSections == null || this.mSections.length == 0 || y < this.mIndexbarRect.top + this.mIndexbarMargin) {
            return 0;
        }
        if (y >= (this.mIndexbarRect.top + this.mIndexbarRect.height()) - this.mIndexbarMargin) {
            return this.mSections.length - 1;
        }
        return (int) (((y - this.mIndexbarRect.top) - this.mIndexbarMargin) / ((this.mIndexbarRect.height() - (2.0f * this.mIndexbarMargin)) / ((float) this.mSections.length)));
    }

    private void fade(long delay) {
        this.mHandler.removeMessages(0);
        this.mHandler.sendEmptyMessageAtTime(WHAT_FADE_PREVIEW, SystemClock.uptimeMillis() + delay);
    }

    private int convertTransparentValueToBackgroundAlpha(float value) {
        return (int) (255.0f * value);
    }

    public void setIndexTextSize(int value) {
        this.setIndexTextSize = value;
    }

    public void setIndexbarWidth(float value) {
        this.mIndexbarWidth = value;
    }

    public void setIndexbarMargin(float value) {
        this.mIndexbarMargin = value;
    }

    public void setPreviewPadding(int value) {
        this.setPreviewPadding = value;
    }

    public void setIndexBarCornerRadius(int value) {
        this.setIndexBarCornerRadius = value;
    }

    public void setIndexBarTransparentValue(float value) {
        this.indexbarBackgroudAlpha = convertTransparentValueToBackgroundAlpha(value);
    }

    public void setTypeface(Typeface typeface) {
        this.setTypeface = typeface;
    }

    public void setIndexBarColor(String color) {
        this.indexbarBackgroudColor = color;
    }

    public void setIndexBarTextColor(String color) {
        this.indexbarTextColor = color;
    }
}
