package com.kotlinz.festivalstorymaker.activity;

import static com.kotlinz.festivalstorymaker.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SelectLogoActivity extends BaseActivity implements SelectLogoAdapter.LogoInterface {

    Activity activity = SelectLogoActivity.this;
    public SelectLogoAdapter selectLogoAdapter;
    public List<String> selectLogoList;
    public boolean IsLogoSelected;
    public SelectLogoAdapter.LogoInterface selectLogoListener;
    public boolean M;
    @BindView(R.id.imgBlur)
    public ImageView imgBlur;

    @BindView(R.id.listLogo)
    public RecyclerView listLogo;

    @BindView(R.id.llMain)
    public LinearLayout llMain;

    @BindView(R.id.rlList)
    public RelativeLayout rlList;

    private ArrayList<Image> images = new ArrayList<>();

    private NativeAd nativeAd;

    public SelectLogoActivity() {
        IsLogoSelected = false;
    }

    @Override
    public void K(final String s, final boolean b) {
        if (b) {
            new File(s).delete();
            selectLogoList.remove(s);
            h0(selectLogoList);
            this.selectLogoAdapter.notifyDataSetChanged();
            return;
        }
        final Intent intent = new Intent();
        intent.putExtra("path", s);
        this.setResult(7924, intent);
        this.finish();
    }

    public void g0(final File file, final File file2) {
        try {
            final FileInputStream fileInputStream = new FileInputStream(file);
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            final byte[] array = new byte[1024];
            while (true) {
                final int read = fileInputStream.read(array);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.close();
            selectLogoList.add(file2.getPath());
            this.h0(selectLogoList);
            this.selectLogoAdapter.notifyDataSetChanged();

            if (IsLogoSelected && !this.M) {
                String str = (String) selectLogoList.get(0);
                Intent intent = new Intent();
                intent.putExtra("path", str);
                setResult(7924, intent);
                finish();
            }
            if (this.M) {
                Intent intent2 = new Intent();
                setResult(7924, intent2);
                finish();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void h0(final List<String> list) {
        final Context applicationContext = this.getApplicationContext();
        this.getApplicationContext();
        int visibility = 0;
        final SharedPreferences.Editor edit = applicationContext.getSharedPreferences("Logo_list", 0).edit();
        edit.putString("myJson", new Gson().toJson(list));
        edit.apply();
        final RelativeLayout rlList = this.rlList;
        if (selectLogoList.size() <= 0) {
            visibility = 8;
        }
        rlList.setVisibility(visibility);
    }

    @Override
    public void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 160) {
            if (intent == null) {
                return;
            }
            final Uri data = intent.getData();
            try {
                final String[] array = {"_data"};
                final Cursor query = this.getContentResolver().query(data, array, null, null, null);
                query.moveToFirst();
                final String string = query.getString(query.getColumnIndex(array[0]));
                query.close();
                this.g0(new File(string), Utils.l());
                return;
            } catch (Exception ex) {
                ex.printStackTrace();
                return;
            }
        }

        images = (ArrayList<Image>) ImagePicker.getImages(intent);
        if (images != null && images.get(0) != null) {
            for (int i = 0; i < images.size(); i++) {
                this.g0(new File(images.get(i).path), Utils.l());
            }
        } else if (n2 == 90 && intent != null && intent.getBooleanExtra("isRefresh", false)) {
            new b().execute();
        }
    }

    @OnClick({R.id.imgSelecteLogo, R.id.imgFolderLogo, R.id.imgBlur, R.id.llMain, R.id.rlList, R.id.cardDesignWithFont})
    public void onClick(final View view) {
        Intent intent = null;
        int n = 0;
        switch (view.getId()) {
            default: {
                return;
            }
            case R.id.imgSelecteLogo: {
                final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
                final ReturnMode f = ReturnMode.GALLERY_ONLY;
                final ImagePickerConfig a2 = a.config;
                a2.returnMode = f;
                a2.folderMode = true;
                a2.folderTitle = "Folder";
                a2.imageTitle = "Tap to select";
                a2.arrowColor = -16777216;
                a.single();
                a.showCamera(a.config.showCamera = false);
                a.start();
                return;
            }
            case R.id.imgFolderLogo: {
                intent = new Intent("android.intent.action.PICK");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/jpeg", "image/png"});
                n = 160;
                break;
            }
            case R.id.imgBlur:
            case R.id.llMain:
            case R.id.rlList: {
                this.finish();
                return;
            }
        }
        this.startActivityForResult(intent, n);
    }

    @Override
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_logo_dialog);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        loadAd();
        this.M = this.getIntent().getBooleanExtra("fromHome", false);
        final byte[] byteArrayExtra = this.getIntent().getByteArrayExtra("image");
        if (byteArrayExtra != null) {
            this.imgBlur.setImageBitmap(BitmapFactory.decodeByteArray(byteArrayExtra, 0, byteArrayExtra.length));
        }
        this.selectLogoListener = this;
        new b().execute();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SelectLogoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (SelectLogoActivity.this.nativeAd != null) {
                            SelectLogoActivity.this.nativeAd.destroy();
                        }
                        SelectLogoActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    @Override
    public void u(final int n, final int n2) {
        Toast.makeText(activity, "Swap", Toast.LENGTH_SHORT).show();
        Collections.swap(selectLogoList, n, n2);
        this.h0(selectLogoList);
        this.selectLogoAdapter.notifyDataSetChanged();
    }

    public class b extends AsyncTask<Void, Void, Void> {
        public b() {
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            rlList.setVisibility(selectLogoList.size() > 0 ? View.VISIBLE : View.GONE);
            selectLogoAdapter = new SelectLogoAdapter(activity, selectLogoList, selectLogoListener);
            listLogo.setAdapter(selectLogoAdapter);
            SelectLogoActivity.this.llMain.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            selectLogoList = Utils.n(activity);
            IsLogoSelected = selectLogoList.size() == 0;
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
        }
    }
}