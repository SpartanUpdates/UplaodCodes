package com.wavymusic.mp3Cutter.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class SongCropModel implements Parcelable {
    public static final Parcelable.Creator<SongCropModel> CREATOR = new Parcelable.Creator<SongCropModel>() {

        public SongCropModel createFromParcel(Parcel parcel) {
            SongCropModel aVar = new SongCropModel();
            aVar.j = parcel.readInt();
            aVar.f5777e = parcel.readString();
            aVar.f5776d = parcel.readString();
            aVar.g = parcel.readLong();
            aVar.f = parcel.readString();
            aVar.i = parcel.readLong();
            aVar.f5773a = parcel.readLong();
            aVar.h = parcel.readFloat();
            aVar.f5775c = parcel.readString();
            aVar.f5774b = parcel.readFloat();
            aVar.k = parcel.readString();
            return aVar;
        }

        public SongCropModel[] newArray(int i) {
            return new SongCropModel[i];
        }
    };

    public long f5773a;
    public float f5774b;
    public String f5775c;
    public String f5776d;
    public String f5777e;
    public String f;
    public long g;
    public float h;
    public long i;
    public int j;
    public String k;
    private boolean l;
    private boolean m = false;

    public void a(int i2) {
        this.j = i2;
    }

    public void a(long j2) {
        this.g = j2;
    }

    public void a(String str) {
        this.f = str;
    }

    public void a(boolean z) {
        this.m = z;
    }

    public boolean a() {
        return this.m;
    }

    public void b(String str) {
        this.f5777e = str;
    }

    public void b(boolean z) {
        this.l = z;
    }

    public boolean b() {
        return this.l;
    }

    public int c() {
        return this.j;
    }

    public void c(String str) {
        this.f5776d = str;
    }

    public long d() {
        return this.i;
    }

    public void d(String str) {
        this.k = str;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.f;
    }

    public String f() {
        return this.f5777e;
    }

    public long g() {
        return this.g;
    }

    public long h() {
        return this.f5773a - this.i;
    }

    public String i() {
        return this.k;
    }

    public SongCropModel clone() throws CloneNotSupportedException {
        SongCropModel aVar = new SongCropModel();
        aVar.j = this.j;
        aVar.f5777e = this.f5777e;
        aVar.f5776d = this.f5776d;
        aVar.g = this.g;
        aVar.f = this.f;
        aVar.i = this.i;
        aVar.f5773a = this.f5773a;
        aVar.f5775c = this.f5775c;
        return aVar;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.j);
        parcel.writeString(this.f5777e);
        parcel.writeString(this.f5776d);
        parcel.writeLong(this.g);
        parcel.writeString(this.f);
        parcel.writeLong(this.i);
        parcel.writeLong(this.f5773a);
        parcel.writeFloat(this.h);
        parcel.writeString(this.f5775c);
        parcel.writeFloat(this.f5774b);
    }

}
