package com.example.postermaker.textitems;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import com.example.postermaker.R;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.utilities.eaz_GradientDrawable;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_TextBorderItem implements OnClickListener, OnProgressChangeListener {
    int[] allcolors;
    Context context;

    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public eaz_TextBorderItem(Context context) {
        this.context = context;
    }

    public void showTextBorderItem() {
        eaz_EditActivity.textbgborderlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.textborderradious.setOnProgressChangeListener(this);
        eaz_EditActivity.textbordersize.setOnProgressChangeListener(this);
        eaz_EditActivity.textborderspace.setOnProgressChangeListener(this);
        eaz_EditActivity.oktextborder.setOnClickListener(this);
        eaz_EditActivity.canceltextborder.setOnClickListener(this);
        this.allcolors = this.context.getResources().getIntArray(R.array.allcolors);
        loadColors();
    }

    public void loadColors() {
        eaz_EditActivity.textbordercolorlayout.removeAllViews();
        for (int i = 0; i < this.allcolors.length; i++) {
            ImageView imageView = new ImageView(this.context);
            circularImageView(imageView, this.allcolors[i]);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_TextShapeStaticValues.bordercolor = eaz_TextBorderItem.this.allcolors[finalI];
                    new eaz_GradientDrawable().manageText(eaz_TextShapeStaticValues.textbgcolor, eaz_TextShapeStaticValues.bordercolor, eaz_TextShapeStaticValues.textbgbordersize, eaz_TextShapeStaticValues.textbgborderspace, eaz_TextShapeStaticValues.textbgradius);
                }
            });
            eaz_EditActivity.textbordercolorlayout.addView(imageView);
        }
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.oktextborder)) {
            eaz_EditActivity.textbgborderlayout.setVisibility(View.GONE);
        } else if (view.equals(eaz_EditActivity.canceltextborder)) {
            eaz_TextShapeStaticValues.bordercolor = 0;
            eaz_TextShapeStaticValues.textbgradius = 0;
            eaz_TextShapeStaticValues.textbgbordersize = 0;
            eaz_TextShapeStaticValues.textbgborderspace = 0;
            eaz_EditActivity.textbgborderlayout.setVisibility(View.GONE);
        }
    }

    public void circularImageView(ImageView imageView, int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.OVAL);
        gradientDrawable.setColor(i);
        imageView.setBackground(gradientDrawable);

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                ViewGroup.MarginLayoutParams.MATCH_PARENT,
                ViewGroup.MarginLayoutParams.WRAP_CONTENT
        );
        marginLayoutParams.setMargins(5, 5, 5, 5);
         imageView.setPadding(40, 40, 40, 40);
        imageView.setLayoutParams(marginLayoutParams);

        //imageView.setLayoutParams(new LayoutParams(45, 45));
    }

    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z) {
        if (discreteSeekBar.equals(eaz_EditActivity.textborderradious)) {
            eaz_TextShapeStaticValues.textbgradius = i;
            new eaz_GradientDrawable().manageText(eaz_TextShapeStaticValues.textbgcolor, eaz_TextShapeStaticValues.bordercolor, eaz_TextShapeStaticValues.textbgbordersize, eaz_TextShapeStaticValues.textbgborderspace, eaz_TextShapeStaticValues.textbgradius);
        } else if (discreteSeekBar.equals(eaz_EditActivity.textbordersize)) {
            eaz_TextShapeStaticValues.textbgbordersize = i;
            new eaz_GradientDrawable().manageText(eaz_TextShapeStaticValues.textbgcolor, eaz_TextShapeStaticValues.bordercolor, eaz_TextShapeStaticValues.textbgbordersize, eaz_TextShapeStaticValues.textbgborderspace, eaz_TextShapeStaticValues.textbgradius);
        } else if (discreteSeekBar.equals(eaz_EditActivity.textborderspace)) {
            eaz_TextShapeStaticValues.textbgborderspace = i;
            new eaz_GradientDrawable().manageText(eaz_TextShapeStaticValues.textbgcolor, eaz_TextShapeStaticValues.bordercolor, eaz_TextShapeStaticValues.textbgbordersize, eaz_TextShapeStaticValues.textbgborderspace, eaz_TextShapeStaticValues.textbgradius);
        }
    }
}
