package com.kotlinz.videoCollage.interfaces;

public interface MsgTextStickerAdapterCallBackInterface {
    void itemClick(int i);
}
