package com.unitedvideos.CropView.imagezoomcrop.photoview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.ImageView;

import com.unitedvideos.CropView.imagezoomcrop.cropoverlay.edge.Edge;
import com.unitedvideos.CropView.imagezoomcrop.cropoverlay.utils.ImageViewUtil;
import com.unitedvideos.CropView.imagezoomcrop.photoview.gestures.OnGestureListener;
import com.unitedvideos.CropView.imagezoomcrop.photoview.gestures.VersionedGestureDetector;
import com.unitedvideos.CropView.imagezoomcrop.photoview.scrollerproxy.ScrollerProxy;
import com.unitedvideos.application.MyApplication;

import java.lang.ref.WeakReference;

class PhotoViewAttacher implements IPhotoView, View.OnTouchListener, OnGestureListener, ViewTreeObserver.OnGlobalLayoutListener
{
  private static final String LOG_TAG = "PhotoViewAttacher";
  private static final boolean DEBUG;
  static final Interpolator sInterpolator;
  int ZOOM_DURATION;
  static final int EDGE_NONE = -1;
  static final int EDGE_LEFT = 0;
  static final int EDGE_RIGHT = 1;
  static final int EDGE_BOTH = 2;
  private float mMinScale;
  private float mMidScale;
  private float mMaxScale;
  private boolean mAllowParentInterceptOnEdge;
  private WeakReference<ImageView> mImageView;
  private GestureDetector mGestureDetector;
  private com.unitedvideos.CropView.imagezoomcrop.photoview.gestures.GestureDetector mScaleDragDetector;
  private final Matrix mBaseMatrix;
  private final Matrix mDrawMatrix;
  private final Matrix mSuppMatrix;
  private final RectF mDisplayRect;
  private final float[] mMatrixValues;
  private OnMatrixChangedListener mMatrixChangeListener;
  private OnPhotoTapListener mPhotoTapListener;
  private OnViewTapListener mViewTapListener;
  private View.OnLongClickListener mLongClickListener;
  private int mIvTop;
  private int mIvRight;
  private int mIvBottom;
  private int mIvLeft;
  private FlingRunnable mCurrentFlingRunnable;
  private int mScrollEdge;
  private boolean mZoomEnabled;
  private ImageView.ScaleType mScaleType;
  private float mRotation;
  IGetImageBounds mBoundsListener;

  static {
    DEBUG = Log.isLoggable("PhotoViewAttacher", 3);
    sInterpolator = (Interpolator)new AccelerateDecelerateInterpolator();
  }

  private static void checkZoomLevels(final float minZoom, final float midZoom, final float maxZoom) {
  }

  private static boolean hasDrawable(final ImageView imageView) {
    return imageView != null && imageView.getDrawable() != null;
  }

  private static boolean isSupportedScaleType(final ImageView.ScaleType scaleType) {
    if (scaleType == null) {
      return false;
    }
    switch (scaleType) {
      case MATRIX: {
        throw new IllegalArgumentException(String.valueOf(scaleType.name()) + " is not supported in PhotoView");
      }
      default: {
        return true;
      }
    }
  }

  private static void setImageViewScaleTypeMatrix(final ImageView imageView) {
    if (imageView != null && !(imageView instanceof IPhotoView) && !ImageView.ScaleType.MATRIX.equals((Object)imageView.getScaleType())) {
      imageView.setScaleType(ImageView.ScaleType.MATRIX);
    }
  }

  public PhotoViewAttacher(final ImageView imageView) {
    this.ZOOM_DURATION = 200;
    this.mMinScale = 1.0f;
    this.mMidScale = 1.75f;
    this.mMaxScale = 3.0f;
    this.mAllowParentInterceptOnEdge = true;
    this.mBaseMatrix = new Matrix();
    this.mDrawMatrix = new Matrix();
    this.mSuppMatrix = new Matrix();
    this.mDisplayRect = new RectF();
    this.mMatrixValues = new float[9];
    this.mScrollEdge = 2;
    this.mScaleType = ImageView.ScaleType.FIT_CENTER;
    this.mImageView = new WeakReference<ImageView>(imageView);
    imageView.setDrawingCacheEnabled(true);
    imageView.setOnTouchListener((View.OnTouchListener)this);
    final ViewTreeObserver observer = imageView.getViewTreeObserver();
    setImageViewScaleTypeMatrix(imageView);
    if (imageView.isInEditMode()) {
      return;
    }
    this.mScaleDragDetector = VersionedGestureDetector.newInstance(imageView.getContext(), this);
    (this.mGestureDetector = new GestureDetector(imageView.getContext(), (GestureDetector.OnGestureListener)new GestureDetector.SimpleOnGestureListener() {
      public void onLongPress(final MotionEvent e) {
        if (PhotoViewAttacher.this.mLongClickListener != null) {
          PhotoViewAttacher.this.mLongClickListener.onLongClick((View)PhotoViewAttacher.this.getImageView());
        }
      }
    })).setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)new DefaultOnDoubleTapListener(this));
    this.setZoomable(true);
  }

  @Override
  public void setOnDoubleTapListener(final GestureDetector.OnDoubleTapListener newOnDoubleTapListener) {
    if (newOnDoubleTapListener != null) {
      this.mGestureDetector.setOnDoubleTapListener(newOnDoubleTapListener);
    }
    else {
      this.mGestureDetector.setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)new DefaultOnDoubleTapListener(this));
    }
  }

  @Override
  public boolean canZoom() {
    return this.mZoomEnabled;
  }

  public void cleanup() {
    if (this.mImageView == null) {
      return;
    }
    final ImageView imageView = this.mImageView.get();
    if (imageView != null) {
      final ViewTreeObserver observer = imageView.getViewTreeObserver();
      if (observer != null && observer.isAlive()) {
        observer.removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
      }
      imageView.setOnTouchListener((View.OnTouchListener)null);
      this.cancelFling();
    }
    if (this.mGestureDetector != null) {
      this.mGestureDetector.setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)null);
    }
    this.mMatrixChangeListener = null;
    this.mPhotoTapListener = null;
    this.mViewTapListener = null;
    this.mImageView = null;
  }

  @Override
  public RectF getDisplayRect() {
    this.checkMatrixBounds();
    return this.getDisplayRect(this.getDrawMatrix());
  }

  @Override
  public boolean setDisplayMatrix(final Matrix finalMatrix) {
    if (finalMatrix == null) {
      throw new IllegalArgumentException("Matrix cannot be null");
    }
    final ImageView imageView = this.getImageView();
    if (imageView == null) {
      return false;
    }
    if (imageView.getDrawable() == null) {
      return false;
    }
    this.mSuppMatrix.set(finalMatrix);
    this.setImageViewMatrix(this.getDrawMatrix());
    this.checkMatrixBounds();
    return true;
  }

  @Override
  public void setPhotoViewRotation(final float degrees) {
    this.setRotationTo(degrees);
  }

  @Override
  public void setRotationTo(final float degrees) {
    final Rect imageBounds = this.getImageBounds();
    this.mSuppMatrix.setRotate(degrees % 360.0f, (float)imageBounds.centerX(), (float)imageBounds.centerY());
    this.checkAndDisplayMatrix();
  }

  @Override
  public void setRotationBy(final float rotationDegree) {
    this.setRotationBy(rotationDegree, false);
  }

  @Override
  public void setRotationBy(final float degrees, final boolean animate) {
    final ImageView imageView = this.getImageView();
    if (imageView == null) {
      return;
    }
    final Rect imageBounds = this.getImageBounds();
    final int centerX = imageBounds.centerX();
    final int centerY = imageBounds.centerY();
    final float oldRotation = this.mRotation;
    final float degreesNorm = degrees % 360.0f;
    if (degreesNorm == 0.0f) {
      this.mRotation = 0.0f;
    }
    else {
      this.mRotation = (this.mRotation + degreesNorm) % 360.0f;
    }
    if (animate) {
      imageView.post((Runnable)new AnimatedRotateRunnable(oldRotation, degreesNorm, centerX, centerY));
    }
    else {
      this.mSuppMatrix.postRotate(degreesNorm, (float)centerX, (float)centerY);
      this.checkAndDisplayMatrix();
    }
  }

  public ImageView getImageView() {
    ImageView imageView = null;
    if (this.mImageView != null) {
      imageView = this.mImageView.get();
    }
    if (imageView == null) {
      this.cleanup();
      Log.i("PhotoViewAttacher", "ImageView no longer exists. You should not use this PhotoViewAttacher any more.");
    }
    return imageView;
  }

  @Deprecated
  @Override
  public float getMinScale() {
    return this.getMinimumScale();
  }

  @Override
  public float getMinimumScale() {
    return this.mMinScale;
  }

  @Deprecated
  @Override
  public float getMidScale() {
    return this.getMediumScale();
  }

  @Override
  public float getMediumScale() {
    return this.mMidScale;
  }

  @Deprecated
  @Override
  public float getMaxScale() {
    return this.getMaximumScale();
  }

  @Override
  public float getMaximumScale() {
    return this.mMaxScale;
  }

  @Override
  public float getScale() {
    return (float)Math.sqrt((float)Math.pow(this.getValue(this.mSuppMatrix, 0), 2.0) + (float)Math.pow(this.getValue(this.mSuppMatrix, 3), 2.0));
  }

  @Override
  public ImageView.ScaleType getScaleType() {
    return this.mScaleType;
  }

  public void onDrag(final float dx, final float dy) {
    if (this.mScaleDragDetector.isScaling()) {
      return;
    }
    if (PhotoViewAttacher.DEBUG) {
      Log.d("PhotoViewAttacher", String.format("onDrag: dx: %.2f. dy: %.2f", dx, dy));
    }
    final ImageView imageView = this.getImageView();
    this.mSuppMatrix.postTranslate(dx, dy);
    this.checkAndDisplayMatrix();
    final ViewParent parent = imageView.getParent();
    if (this.mAllowParentInterceptOnEdge && !this.mScaleDragDetector.isScaling()) {
      if ((this.mScrollEdge == 2 || (this.mScrollEdge == 0 && dx >= 1.0f) || (this.mScrollEdge == 1 && dx <= -1.0f)) && parent != null) {
        parent.requestDisallowInterceptTouchEvent(false);
      }
    }
    else if (parent != null) {
      parent.requestDisallowInterceptTouchEvent(true);
    }
  }

  public void onFling(final float startX, final float startY, final float velocityX, final float velocityY) {
    if (PhotoViewAttacher.DEBUG) {
      Log.d("PhotoViewAttacher", "onFling. sX: " + startX + " sY: " + startY + " Vx: " + velocityX + " Vy: " + velocityY);
    }
    final ImageView imageView = this.getImageView();
    (this.mCurrentFlingRunnable = new FlingRunnable(imageView.getContext())).fling(this.getImageViewWidth(imageView), this.getImageViewHeight(imageView), (int)velocityX, (int)velocityY);
    imageView.post((Runnable)this.mCurrentFlingRunnable);
  }

  public void onGlobalLayout() {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      if (this.mZoomEnabled) {
        final int top = imageView.getTop();
        final int right = imageView.getRight();
        final int bottom = imageView.getBottom();
        final int left = imageView.getLeft();
        if (top != this.mIvTop || bottom != this.mIvBottom || left != this.mIvLeft || right != this.mIvRight) {
          this.updateBaseMatrix(imageView.getDrawable());
          this.mIvTop = top;
          this.mIvRight = right;
          this.mIvBottom = bottom;
          this.mIvLeft = left;
        }
      }
      else {
        this.updateBaseMatrix(imageView.getDrawable());
      }
    }
  }

  public void onScale(final float scaleFactor, final float focusX, final float focusY) {
    if (PhotoViewAttacher.DEBUG) {
      Log.d("PhotoViewAttacher", String.format("onScale: scale: %.2f. fX: %.2f. fY: %.2f", scaleFactor, focusX, focusY));
    }
    this.mSuppMatrix.postScale(scaleFactor, scaleFactor, focusX, focusY);
    this.checkAndDisplayMatrix();
  }

  public boolean onTouch(final View v, final MotionEvent ev) {
    boolean handled = false;
    if (this.mZoomEnabled && hasDrawable((ImageView)v)) {
      final ViewParent parent = v.getParent();
      switch (ev.getAction()) {
        case 0: {
          if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
          }
          else {
            Log.i("PhotoViewAttacher", "onTouch getParent() returned null");
          }
          this.cancelFling();
          break;
        }
        case 1:
        case 3: {
          if (this.getScale() >= this.mMinScale) {
            break;
          }
          final RectF rect = this.getDisplayRect();
          if (rect != null) {
            v.post((Runnable)new AnimatedZoomRunnable(this.getScale(), this.mMinScale, rect.centerX(), rect.centerY()));
            handled = true;
            break;
          }
          break;
        }
      }
      if (this.mScaleDragDetector != null && this.mScaleDragDetector.onTouchEvent(ev)) {
        handled = true;
      }
      if (this.mGestureDetector != null && this.mGestureDetector.onTouchEvent(ev)) {
        handled = true;
      }
    }
    return handled;
  }

  @Override
  public void setAllowParentInterceptOnEdge(final boolean allow) {
    this.mAllowParentInterceptOnEdge = allow;
  }

  @Deprecated
  @Override
  public void setMinScale(final float minScale) {
    this.setMinimumScale(minScale);
  }

  @Override
  public void setMinimumScale(final float minimumScale) {
    checkZoomLevels(minimumScale, this.mMidScale, this.mMaxScale);
    this.mMinScale = minimumScale;
  }

  @Override
  public float setMinimumScaleToFit(final Drawable drawable) {
    float minScale = 1.0f;
    final int h = drawable.getIntrinsicHeight();
    final int w = drawable.getIntrinsicWidth();
    final float cropWindowWidth = Edge.getWidth();
    final float cropWindowHeight = Edge.getHeight();
    if (h <= w) {
      minScale = (cropWindowHeight + 1.0f) / h;
    }
    else if (w < h) {
      minScale = (cropWindowWidth + 1.0f) / w;
    }
    this.setMinimumScale(minScale);
    return minScale;
  }

  @Deprecated
  @Override
  public void setMidScale(final float midScale) {
    this.setMediumScale(midScale);
  }

  @Override
  public void setMediumScale(final float mediumScale) {
    checkZoomLevels(this.mMinScale, mediumScale, this.mMaxScale);
    this.mMidScale = mediumScale;
  }

  @Deprecated
  @Override
  public void setMaxScale(final float maxScale) {
    this.setMaximumScale(maxScale);
  }

  @Override
  public void setMaximumScale(final float maximumScale) {
    checkZoomLevels(this.mMinScale, this.mMidScale, maximumScale);
    this.mMaxScale = maximumScale;
  }

  @Override
  public void setOnLongClickListener(final View.OnLongClickListener listener) {
    this.mLongClickListener = listener;
  }

  @Override
  public void setOnMatrixChangeListener(final OnMatrixChangedListener listener) {
    this.mMatrixChangeListener = listener;
  }

  @Override
  public void setOnPhotoTapListener(final OnPhotoTapListener listener) {
    this.mPhotoTapListener = listener;
  }

  @Override
  public OnPhotoTapListener getOnPhotoTapListener() {
    return this.mPhotoTapListener;
  }

  @Override
  public void setOnViewTapListener(final OnViewTapListener listener) {
    this.mViewTapListener = listener;
  }

  @Override
  public OnViewTapListener getOnViewTapListener() {
    return this.mViewTapListener;
  }

  @Override
  public void setScale(final float scale) {
    this.setScale(scale, false);
  }

  @Override
  public void setScale(final float scale, final boolean animate) {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      this.setScale(scale, imageView.getRight() / 2, imageView.getBottom() / 2, animate);
    }
  }

  @Override
  public void setScale(final float scale, final float focalX, final float focalY, final boolean animate) {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      if (scale < this.mMinScale || scale > this.mMaxScale) {
        Log.i("PhotoViewAttacher", "Scale must be within the range of minScale and maxScale");
        return;
      }
      if (animate) {
        imageView.post((Runnable)new AnimatedZoomRunnable(this.getScale(), scale, focalX, focalY));
      }
      else {
        this.mSuppMatrix.setScale(scale, scale, focalX, focalY);
        this.checkAndDisplayMatrix();
      }
    }
  }

  @Override
  public void setScaleType(final ImageView.ScaleType scaleType) {
    if (isSupportedScaleType(scaleType) && scaleType != this.mScaleType) {
      this.mScaleType = scaleType;
      this.update();
    }
  }

  @Override
  public void setZoomable(final boolean zoomable) {
    this.mZoomEnabled = zoomable;
    this.update();
  }

  @Override
  public void update() {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      if (this.mZoomEnabled) {
        setImageViewScaleTypeMatrix(imageView);
        this.updateBaseMatrix(imageView.getDrawable());
      }
      else {
        this.resetMatrix();
      }
      this.setScale(this.getMinimumScale());
    }
  }

  @Override
  public void reset() {
    this.update();
  }

  @Override
  public Matrix getDisplayMatrix() {
    return new Matrix(this.getDrawMatrix());
  }

  public Matrix getDrawMatrix() {
    this.mDrawMatrix.set(this.mBaseMatrix);
    this.mDrawMatrix.postConcat(this.mSuppMatrix);
    return this.mDrawMatrix;
  }

  private void cancelFling() {
    if (this.mCurrentFlingRunnable != null) {
      this.mCurrentFlingRunnable.cancelFling();
      this.mCurrentFlingRunnable = null;
    }
  }

  private void checkAndDisplayMatrix() {
    if (this.checkMatrixBounds()) {
      this.setImageViewMatrix(this.getDrawMatrix());
    }
  }

  private void checkImageViewScaleType() {
    final ImageView imageView = this.getImageView();
    if (imageView != null && !(imageView instanceof IPhotoView) && !ImageView.ScaleType.MATRIX.equals((Object)imageView.getScaleType())) {
      throw new IllegalStateException("The ImageView's ScaleType has been changed since attaching NotificationUtils PhotoViewAttacher");
    }
  }

  @Override
  public void setImageBoundsListener(final IGetImageBounds listener) {
    this.mBoundsListener = listener;
  }

  public Rect getImageBounds() {
    if (this.getImageView() == null) {
      return new Rect();
    }
    if (this.mBoundsListener != null) {
      return this.mBoundsListener.getImageBounds();
    }
    return new Rect(this.getImageViewWidth(this.getImageView()), 0, 0, this.getImageViewHeight(this.getImageView()));
  }

  private boolean checkMatrixBounds() {
    final ImageView imageView = this.getImageView();
    boolean doScale = false;
    if (imageView == null) {
      return false;
    }
    final RectF rect = this.getDisplayRect(this.getDrawMatrix());
    if (rect == null) {
      return false;
    }
    final float height = rect.height();
    final float width = rect.width();
    float deltaX = 0.0f;
    float deltaY = 0.0f;
    final Rect overlayImageBounds = this.getImageBounds();
    final int overlayViewHeight = overlayImageBounds.height();
    final int viewHeight = this.getImageViewHeight(imageView);
    if (height <= overlayViewHeight) {
      Log.d("MMM", "height <= overlayViewHeight = " + height + "<=" + overlayViewHeight);
      switch (this.mScaleType) {
        case FIT_START: {
          deltaY = -rect.top;
          break;
        }
        case FIT_END: {
          deltaY = overlayViewHeight - height - rect.top;
          break;
        }
        default: {
          deltaY = 0.0f;
          Log.d("MMM", "deltaY = 0;");
          doScale = true;
          if (rect.top > overlayImageBounds.top) {
            Log.d("MMM", "CCC rect.top > overlayImageBounds.top = " + rect.top + ">" + overlayImageBounds.top);
            final float HeightGap = overlayViewHeight - height;
            final float TopGap = rect.top - overlayImageBounds.top;
            final float FinalGapVal = deltaY = -(TopGap - HeightGap / 2.0f);
            break;
          }
          if (rect.bottom < overlayImageBounds.bottom) {
            Log.d("MMM", "CCC rect.bottom < overlayImageBounds.bottom = " + rect.bottom + "<" + overlayImageBounds.bottom);
            final float HeightGap = overlayViewHeight - height;
            final float TopGap = rect.top - overlayImageBounds.top;
            final float FinalGapVal = deltaY = TopGap - HeightGap / 2.0f;
            break;
          }
          break;
        }
      }
    }
    else if (rect.top > overlayImageBounds.top) {
      Log.d("MMM", "rect.top > overlayImageBounds.top = " + rect.top + ">" + overlayImageBounds.top);
      deltaY = -(rect.top - overlayImageBounds.top);
    }
    else if (rect.bottom < overlayImageBounds.bottom) {
      Log.d("MMM", "rect.bottom < overlayImageBounds.bottom = " + rect.bottom + "<" + overlayImageBounds.bottom);
      deltaY = overlayImageBounds.bottom - rect.bottom;
    }
    final int overlayViewWidth = overlayImageBounds.width();
    if (width <= overlayViewWidth) {
      switch (this.mScaleType) {
        case FIT_START: {
          deltaX = -rect.left;
          break;
        }
        case FIT_END: {
          deltaX = overlayViewWidth - width - rect.left;
          break;
        }
        default: {
          deltaX = (overlayViewWidth - width) / 2.0f - rect.left;
          break;
        }
      }
      this.mScrollEdge = 2;
    }
    else if (rect.left > overlayImageBounds.left) {
      this.mScrollEdge = 0;
      deltaX = -(rect.left - overlayImageBounds.left);
    }
    else if (rect.right < overlayImageBounds.right) {
      deltaX = overlayImageBounds.right - rect.right;
      this.mScrollEdge = 1;
    }
    else {
      this.mScrollEdge = -1;
    }
    Log.d("MMM", "getDisplayRect");
    Log.d("MMM", "OV L = " + overlayImageBounds.left + " OV T = " + overlayImageBounds.top + " OV R = " + overlayImageBounds.right + " OV B = " + overlayImageBounds.bottom);
    Log.d("MMM", "overlayImageBounds");
    Log.d("MMM", "RECT L = " + rect.left + " RECT T = " + rect.top + " RECT R = " + rect.right + " RECT B = " + rect.bottom);
    Log.d("MMM", "deltaX = " + deltaX + " AND deltaY = " + deltaY);
    final float scaleWidth = overlayViewWidth / width;
    final float scaleHeight = overlayViewHeight / height;
    Log.d("MMM", "doScale = " + doScale);
    if (doScale && MyApplication.SkipAll) {
      this.mSuppMatrix.postScale(scaleWidth, scaleHeight, rect.width() / 2.0f, rect.height() / 2.0f);
    }
    this.mSuppMatrix.postTranslate(deltaX, deltaY);
    return true;
  }

  private RectF getDisplayRect(final Matrix matrix) {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      final Drawable d = imageView.getDrawable();
      if (d != null) {
        this.mDisplayRect.set(0.0f, 0.0f, (float)d.getIntrinsicWidth(), (float)d.getIntrinsicHeight());
        matrix.mapRect(this.mDisplayRect);
        return this.mDisplayRect;
      }
    }
    return null;
  }

  @Override
  public Bitmap getVisibleRectangleBitmap() {
    final ImageView imageView = this.getImageView();
    if (imageView == null) {
      return null;
    }
    imageView.setDrawingCacheEnabled(true);
    imageView.buildDrawingCache();
    Bitmap visibleBitmap = imageView.getDrawingCache();
    if (visibleBitmap == null) {
      visibleBitmap = Bitmap.createBitmap(imageView.getWidth(), imageView.getHeight(), Bitmap.Config.RGB_565);
      final Canvas c = new Canvas(visibleBitmap);
      imageView.draw(c);
    }
    final Bitmap copy_visibleBitmap = Bitmap.createBitmap(visibleBitmap, 0, 0, visibleBitmap.getWidth(), visibleBitmap.getHeight());
    imageView.destroyDrawingCache();
    imageView.setDrawingCacheEnabled(false);
    visibleBitmap.recycle();
    visibleBitmap = null;
    return copy_visibleBitmap;
  }

  @Override
  public void setZoomTransitionDuration(int milliseconds) {
    if (milliseconds < 0) {
      milliseconds = 200;
    }
    this.ZOOM_DURATION = milliseconds;
  }

  @Override
  public IPhotoView getIPhotoViewImplementation() {
    return this;
  }

  @Override
  public Bitmap getCroppedImage() {
    final Bitmap visibleBitmap = this.getVisibleRectangleBitmap();
    final Rect displayedImageRect = ImageViewUtil.getBitmapRectCenterInside(visibleBitmap, (View)this.getImageView());
    final float actualImageWidth = visibleBitmap.getWidth();
    final float displayedImageWidth = displayedImageRect.width();
    final float scaleFactorWidth = actualImageWidth / displayedImageWidth;
    final float actualImageHeight = visibleBitmap.getHeight();
    final float displayedImageHeight = displayedImageRect.height();
    final float scaleFactorHeight = actualImageHeight / displayedImageHeight;
    final float cropWindowX = Edge.LEFT.getCoordinate() - displayedImageRect.left;
    final float cropWindowY = Edge.TOP.getCoordinate() - displayedImageRect.top;
    final float cropWindowWidth = Edge.getWidth();
    final float cropWindowHeight = Edge.getHeight();
    final float actualCropX = cropWindowX * scaleFactorWidth;
    final float actualCropY = cropWindowY * scaleFactorHeight;
    final float actualCropWidth = cropWindowWidth * scaleFactorWidth;
    final float actualCropHeight = cropWindowHeight * scaleFactorHeight;
    return Bitmap.createBitmap(visibleBitmap, (int)actualCropX, (int)actualCropY, (int)actualCropWidth, (int)actualCropHeight);
  }

  private float getValue(final Matrix matrix, final int whichValue) {
    matrix.getValues(this.mMatrixValues);
    return this.mMatrixValues[whichValue];
  }

  private void resetMatrix() {
    this.mRotation = 0.0f;
    this.mSuppMatrix.reset();
    this.setImageViewMatrix(this.getDrawMatrix());
    this.checkMatrixBounds();
  }

  private void setImageViewMatrix(final Matrix matrix) {
    final ImageView imageView = this.getImageView();
    if (imageView != null) {
      this.checkImageViewScaleType();
      imageView.setImageMatrix(matrix);
      if (this.mMatrixChangeListener != null) {
        final RectF displayRect = this.getDisplayRect(matrix);
        if (displayRect != null) {
          this.mMatrixChangeListener.onMatrixChanged(displayRect);
        }
      }
    }
  }

  private void updateBaseMatrix(final Drawable d) {
    final ImageView imageView = this.getImageView();
    if (imageView == null || d == null) {
      return;
    }
    final float viewWidth = this.getImageViewWidth(imageView);
    final float viewHeight = this.getImageViewHeight(imageView);
    final int drawableWidth = d.getIntrinsicWidth();
    final int drawableHeight = d.getIntrinsicHeight();
    this.mBaseMatrix.reset();
    final Context mCon = imageView.getContext();
    final int height = this.getToolBarHeight(mCon);
    final float widthScale = viewWidth / drawableWidth;
    final float heightScale = viewHeight / drawableHeight;
    Log.d("SSS", "mScaleType = " + this.mScaleType);
    if (this.mScaleType == ImageView.ScaleType.CENTER) {
      Log.d("SSS", "mScaleType =1 " + this.mScaleType);
      this.mBaseMatrix.postTranslate((viewWidth - drawableWidth) / 2.0f, (viewHeight - drawableHeight) / 2.0f);
    }
    else if (this.mScaleType == ImageView.ScaleType.CENTER_CROP) {
      Log.d("SSS", "mScaleType =2 " + this.mScaleType);
      final float scale = Math.max(widthScale, heightScale);
      this.mBaseMatrix.postScale(scale, scale);
      this.mBaseMatrix.postTranslate((viewWidth - drawableWidth * scale) / 2.0f, (viewHeight - drawableHeight * scale) / 2.0f);
    }
    else if (this.mScaleType == ImageView.ScaleType.CENTER_INSIDE) {
      Log.d("SSS", "mScaleType =3 " + this.mScaleType);
      final float scale = Math.min(1.0f, Math.min(widthScale, heightScale));
      this.mBaseMatrix.postScale(scale, scale);
      this.mBaseMatrix.postTranslate((viewWidth - drawableWidth * scale) / 2.0f, (viewHeight - drawableHeight * scale) / 2.0f);
    }
    else {
      final RectF mTempSrc = new RectF(0.0f, 0.0f, (float)drawableWidth, (float)drawableHeight);
      final RectF mTempDst = new RectF(0.0f, 0.0f, viewWidth, viewHeight);
      switch (this.mScaleType) {
        case FIT_CENTER: {
          Log.d("SSS", "mScaleType =4 " + this.mScaleType);
          this.mBaseMatrix.setRectToRect(mTempSrc, mTempDst, Matrix.ScaleToFit.CENTER);
          break;
        }
        case FIT_START: {
          Log.d("SSS", "mScaleType =5 " + this.mScaleType);
          this.mBaseMatrix.setRectToRect(mTempSrc, mTempDst, Matrix.ScaleToFit.START);
          break;
        }
        case FIT_END: {
          Log.d("SSS", "mScaleType =6 " + this.mScaleType);
          this.mBaseMatrix.setRectToRect(mTempSrc, mTempDst, Matrix.ScaleToFit.END);
          break;
        }
        case FIT_XY: {
          Log.d("SSS", "mScaleType =7 " + this.mScaleType);
          this.mBaseMatrix.setRectToRect(mTempSrc, mTempDst, Matrix.ScaleToFit.FILL);
          break;
        }
      }
    }
    this.resetMatrix();
  }

  public int getToolBarHeight(final Context context) {
    int actionBarHeight = 48;
    final TypedValue tv = new TypedValue();
    if (context.getTheme().resolveAttribute(16843499, tv, true)) {
      actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, context.getResources().getDisplayMetrics());
    }
    return actionBarHeight;
  }

  private int getImageViewWidth(final ImageView imageView) {
    if (imageView == null) {
      return 0;
    }
    return imageView.getWidth() - imageView.getPaddingLeft() - imageView.getPaddingRight();
  }

  private int getImageViewHeight(final ImageView imageView) {
    if (imageView == null) {
      return 0;
    }
    return imageView.getHeight() - imageView.getPaddingTop() - imageView.getPaddingBottom();
  }

  private class AnimatedZoomRunnable implements Runnable
  {
    private final float mFocalX;
    private final float mFocalY;
    private final long mStartTime;
    private final float mZoomStart;
    private final float mZoomEnd;

    public AnimatedZoomRunnable(final float currentZoom, final float targetZoom, final float focalX, final float focalY) {
      this.mFocalX = focalX;
      this.mFocalY = focalY;
      this.mStartTime = System.currentTimeMillis();
      this.mZoomStart = currentZoom;
      this.mZoomEnd = targetZoom;
    }

    @Override
    public void run() {
      final ImageView imageView = PhotoViewAttacher.this.getImageView();
      if (imageView == null) {
        return;
      }
      final float t = this.interpolate();
      final float scale = this.mZoomStart + t * (this.mZoomEnd - this.mZoomStart);
      final float deltaScale = scale / PhotoViewAttacher.this.getScale();
      PhotoViewAttacher.this.mSuppMatrix.postScale(deltaScale, deltaScale, this.mFocalX, this.mFocalY);
      PhotoViewAttacher.this.checkAndDisplayMatrix();
      if (t < 1.0f) {
        Compat.postOnAnimation((View)imageView, this);
      }
    }

    private float interpolate() {
      float t = 1.0f * (System.currentTimeMillis() - this.mStartTime) / PhotoViewAttacher.this.ZOOM_DURATION;
      t = Math.min(1.0f, t);
      t = PhotoViewAttacher.sInterpolator.getInterpolation(t);
      return t;
    }
  }

  private class AnimatedRotateRunnable implements Runnable
  {
    private final float mFocalX;
    private final float mFocalY;
    private final long mStartTime;
    private final float mRotationStart;
    private final float mRotationEnd;
    private float mRotationProgress;

    public AnimatedRotateRunnable(final float currentRotation, final float targetRotation, final float focalX, final float focalY) {
      this.mStartTime = System.currentTimeMillis();
      this.mRotationStart = currentRotation;
      this.mRotationEnd = targetRotation;
      this.mFocalX = focalX;
      this.mFocalY = focalY;
    }

    @Override
    public void run() {
      final ImageView imageView = PhotoViewAttacher.this.getImageView();
      if (imageView == null) {
        return;
      }
      final float t = this.interpolate();
      final float totalRotation = (this.mRotationEnd - this.mRotationStart) * t;
      final float rotationDelta = totalRotation - this.mRotationProgress;
      this.mRotationProgress = totalRotation;
      PhotoViewAttacher.this.mSuppMatrix.postRotate(rotationDelta, this.mFocalX, this.mFocalY);
      PhotoViewAttacher.this.checkAndDisplayMatrix();
      if (t < 1.0f) {
        Compat.postOnAnimation((View)imageView, this);
      }
    }

    private float interpolate() {
      float t = 1.0f * (System.currentTimeMillis() - this.mStartTime) / 250.0f;
      t = Math.min(1.0f, t);
      t = PhotoViewAttacher.sInterpolator.getInterpolation(t);
      return t;
    }
  }

  private class FlingRunnable implements Runnable
  {
    private final ScrollerProxy mScroller;
    private int mCurrentX;
    private int mCurrentY;

    public FlingRunnable(final Context context) {
      this.mScroller = ScrollerProxy.getScroller(context);
    }

    public void cancelFling() {
      if (PhotoViewAttacher.DEBUG) {
        Log.d("PhotoViewAttacher", "Cancel Fling");
      }
      this.mScroller.forceFinished(true);
    }

    public void fling(final int viewWidth, final int viewHeight, final int velocityX, final int velocityY) {
      final RectF rect = PhotoViewAttacher.this.getDisplayRect();
      if (rect == null) {
        return;
      }
      final int startX = Math.round(-rect.left);
      final int minX;
      final int maxX = minX = startX;
      final int startY = Math.round(-rect.top);
      final int minY;
      final int maxY = minY = startY;
      this.mCurrentX = startX;
      this.mCurrentY = startY;
      if (PhotoViewAttacher.DEBUG) {
        Log.d("PhotoViewAttacher", "fling. StartX:" + startX + " StartY:" + startY + " MaxX:" + maxX + " MaxY:" + maxY);
      }
      if (startX != maxX || startY != maxY) {
        this.mScroller.fling(startX, startY, velocityX, velocityY, minX, maxX, minY, maxY, 0, 0);
      }
    }

    @Override
    public void run() {
      if (this.mScroller.isFinished()) {
        return;
      }
      final ImageView imageView = PhotoViewAttacher.this.getImageView();
      if (imageView != null && this.mScroller.computeScrollOffset()) {
        final int newX = this.mScroller.getCurrX();
        final int newY = this.mScroller.getCurrY();
        if (PhotoViewAttacher.DEBUG) {
          Log.d("PhotoViewAttacher", "fling run(). CurrentX:" + this.mCurrentX + " CurrentY:" + this.mCurrentY + " NewX:" + newX + " NewY:" + newY);
        }
        PhotoViewAttacher.this.mSuppMatrix.postTranslate((float)(this.mCurrentX - newX), (float)(this.mCurrentY - newY));
        PhotoViewAttacher.this.setImageViewMatrix(PhotoViewAttacher.this.getDrawMatrix());
        this.mCurrentX = newX;
        this.mCurrentY = newY;
        Compat.postOnAnimation((View)imageView, this);
      }
    }
  }

  public interface OnMatrixChangedListener
  {
    void onMatrixChanged(final RectF p0);
  }

  public interface OnPhotoTapListener
  {
    void onPhotoTap(final View p0, final float p1, final float p2);
  }

  public interface OnViewTapListener
  {
    void onViewTap(final View p0, final float p1, final float p2);
  }
}
