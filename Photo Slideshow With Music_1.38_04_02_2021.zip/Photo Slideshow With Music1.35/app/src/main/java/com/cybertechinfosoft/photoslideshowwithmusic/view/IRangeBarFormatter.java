package com.cybertechinfosoft.photoslideshowwithmusic.view;

public interface IRangeBarFormatter {
    String format(String str);
}
