package com.Pulse.VideoStatus.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.Pulse.VideoStatus.Activity.CustomizeTextActivity;
import com.Pulse.VideoStatus.R;

import java.util.ArrayList;

public class ChangeMessageAdapter extends Adapter<ChangeTextHolder> {
    private static Context context;
    private ArrayList<String> listtext;
    private CustomizeTextActivity ActivityOfEditText;
    public ChangeMessageAdapter(ArrayList<String> arrayList, Context context) {
        this.ActivityOfEditText = (CustomizeTextActivity) context;
        ChangeMessageAdapter.context = context;
        this.listtext = arrayList;
    }

    @SuppressLint("InflateParams")
    public ChangeTextHolder a(ViewGroup viewGroup, int i) {
        return new ChangeTextHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_change_text, null));
    }

    public void JsonData() {
        ((CustomizeTextActivity) context).GetJsonResponse();
    }



    @SuppressLint("ClickableViewAccessibility")
    public void BindViewHolder(final ChangeTextHolder changeTextHolderVar, final int is) {
        EditText editText;
        int i2;
        changeTextHolderVar.etDynamicTextMessage.setHint((CharSequence) this.listtext.get(is));
        if (is == this.listtext.size() - 1) {
            editText = changeTextHolderVar.etDynamicTextMessage;
            i2 = 268435462;
        } else {
            editText = changeTextHolderVar.etDynamicTextMessage;
            i2 = 268435461;
        }
        editText.setImeOptions(i2);
        changeTextHolderVar.etDynamicTextMessage.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                listtext.set(is, changeTextHolderVar.etDynamicTextMessage.getText().toString());
            }
        });
        changeTextHolderVar.etDynamicTextMessage.setOnEditorActionListener(new OnEditorActionListener() {

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == 5) {
                    RecyclerView recyclerView = ActivityOfEditText.rvdynamictext;
                    if (recyclerView != null) {
                        RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(is + 1);
                        if (viewHolder == null) {
                            recyclerView.smoothScrollToPosition(i + 1);
                            return true;
                        }
                    }
                    return false;
                } else if (i != 6) {
                    return false;
                } else {
                    JsonData();
                    return true;
                }
            }
        });
        changeTextHolderVar.etDynamicTextMessage.setOnTouchListener(new OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (!changeTextHolderVar.etDynamicTextMessage.hasFocus()) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(true);
                if ((motionEvent.getAction() & 255) != 8) {
                    return false;
                }
                view.getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
        });
    }

    public int getItemCount() {
        return this.listtext.size();

    }

    public int getItemViewType(int i) {
        return i;
    }


    public void onBindViewHolder(@NonNull ChangeTextHolder viewHolder, int i) {
        BindViewHolder(viewHolder, i);
    }

    @NonNull
    public ChangeTextHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return a(viewGroup, i);
    }
}