package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.List;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.Others.gallery.ImageData;

public class GridViewAdapter extends ArrayAdapter<ImageData> {
    ArrayList<ImageData> albumArrayList;
    Context context;
    int intPosition;
    ViewHolder viewHolder;

    public GridViewAdapter(final Context context, final ArrayList<ImageData> albumArrayList, final int intPosition) {
        super(context, R.layout.sel_adapter_photosfolder, (List) albumArrayList);
        this.albumArrayList = new ArrayList<ImageData>();
        this.albumArrayList = albumArrayList;
        this.context = context;
        this.intPosition = intPosition;
    }

    public int getCount() {
        try {
            return this.albumArrayList.get(this.intPosition).getAl_imagepath().size();
        } catch (Exception ex) {
            return 0;
        }
    }

    public long getItemId(final int n) {
        return n;
    }

    public int getItemViewType(final int n) {
        return n;
    }

    public View getView(final int n, View inflate, final ViewGroup viewGroup) {
        if (inflate == null) {
            this.viewHolder = new ViewHolder();
            inflate = LayoutInflater.from(this.getContext()).inflate(R.layout.sel_adapter_photosfolder, viewGroup, false);
            this.viewHolder.ivImage = (ImageView) inflate.findViewById(R.id.iv_image);
            this.viewHolder.ivImageTop = (ImageView) inflate.findViewById(R.id.iv_image_top);
            this.viewHolder.imageView = (ImageView) inflate.findViewById(R.id.selimg);
            inflate.setTag((Object) this.viewHolder);
        } else {
            this.viewHolder = (ViewHolder) inflate.getTag();
        }
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int n2 = widthPixels * 340 / 1080;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(n2, n2);
        layoutParams.addRule(13);
        this.viewHolder.ivImageTop.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final int n3 = widthPixels * 325 / 1080;
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(n3, n3);
        layoutParams2.addRule(13);
        this.viewHolder.ivImage.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(n2, n2);
        layoutParams3.addRule(13);
        this.viewHolder.imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(this.albumArrayList.get(this.intPosition).getAl_imagepath().get(n));
        instance.displayImage(sb.toString(), this.viewHolder.ivImage, build);
        int i = 0;
        boolean b = false;
        while (i < Utils.photos.size()) {
            if (Utils.photos.get(i).equals(this.albumArrayList.get(this.intPosition).getAl_imagepath().get(n))) {
                b = true;
            }
            ++i;
        }
        if (b) {
            this.viewHolder.imageView.setVisibility(View.VISIBLE);
        } else {
            this.viewHolder.imageView.setVisibility(View.GONE);
        }
        this.viewHolder.ivImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        return inflate;
    }

    public int getViewTypeCount() {
        if (this.albumArrayList.get(this.intPosition).getAl_imagepath().size() > 0) {
            return this.albumArrayList.get(this.intPosition).getAl_imagepath().size();
        }
        return 1;
    }

    private static class ViewHolder {
        ImageView ivImage;
        ImageView ivImageTop;
        ImageView imageView;
    }
}
