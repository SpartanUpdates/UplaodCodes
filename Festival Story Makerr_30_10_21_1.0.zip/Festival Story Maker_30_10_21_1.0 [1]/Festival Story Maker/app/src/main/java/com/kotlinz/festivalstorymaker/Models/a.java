package com.kotlinz.festivalstorymaker.Models;

import java.util.ArrayList;

public class a {
    public ArrayList<g> a;
    public String b;
    public String c;
}
