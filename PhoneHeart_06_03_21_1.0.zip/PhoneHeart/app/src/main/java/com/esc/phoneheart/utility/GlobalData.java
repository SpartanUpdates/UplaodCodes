package com.esc.phoneheart.utility;

import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.text.TextUtils;

import com.esc.phoneheart.R;
import com.esc.phoneheart.model.JunkListModel;
import com.esc.phoneheart.wrappers.ProcessWrapper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class GlobalData {
    public static boolean AUTO_START_SHOWN = false;
    public static String FILE_NAME = "CleanerLogging.txt";
    public static final String HEADER_NOTI_TRACK = "HEADER_NOTI_TRACK";
    public static final String NOTI_RESULT_BACK = "NOTI_RESULT_BACK";
    public static final String REDIRECTHOME = "REDIRECTHOME";
    public static final String REDIRECTNOTI = "REDIRECTNOTI";
    public static boolean afterDelete = false;
    public static ArrayList<String> allcacheFoldersPath = new ArrayList();
    public static int audioCriteia = 0;
    public static boolean backPressedResult = false;
    public static String backuppath = "/newphonecachecleaner/backup/";
    public static int boostPause = 120000;
    public static boolean cacheCheckedAboveMarshmallow;
    public static ArrayList<JunkListModel> cacheContainingApps = new ArrayList();
    public static long coolPause = 60000;
    public static String cpu_temperature;
    public static int deviceHeight;
    public static int deviceWidth;
    public static boolean dontAnimate = false;
    public static int duplicacyDist = 7;
    public static int duplicacyLevel = 75;
    public static int duplicacyTime = 7;
    public static int fileCriteia = 0;
    public static boolean fromSpacemanager = false;
    public static int imageCriteia = 0;
    public static boolean imageviewed = false;
    public static boolean isDebug = false;
    public static int junccleanPause = 120000;
    public static boolean loadAds = true;
    public static int otherCriteia = 0;
    public static boolean phone_state_Permission = false;
    public static boolean proceededToAd = false;
    public static ArrayList<ProcessWrapper> processDataList = new ArrayList();
    public static String rGisV;
    public static int rampause = 60000;
    public static boolean returnedAfterDeletion = false;
    public static boolean returnedAfterSocialDeletion = false;
    public static volatile boolean shouldContinue = true;
    public static int videoCriteia = 0;
    public static String xObtk;
    public static long availMem;

    static {
        String str = "7878787878787878";
        xObtk = str;
        rGisV = str;
    }

    public static void SETAPPLAnguage(Context context) {
    }

    public static int StringItirator(String str) {
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            if (str.charAt(i2) == '/') {
                i++;
            }
        }
        return i;
    }

    public static String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        String str2 = "";
        Object obj = 1;
        for (char c : str.toCharArray()) {
            if (obj == null || !Character.isLetter(c)) {
                if (Character.isWhitespace(c)) {
                    obj = 1;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(c);
                str2 = stringBuilder.toString();
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str2);
                stringBuilder2.append(Character.toUpperCase(c));
                str2 = stringBuilder2.toString();
                obj = null;
            }
        }
        return str2;
    }

    public static String getDeviceName() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        if (str2.startsWith(str)) {
            return capitalize(str2);
        }
        if (str.equalsIgnoreCase("HTC")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("HTC ");
            stringBuilder.append(str2);
            return stringBuilder.toString();
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(capitalize(str));
        stringBuilder2.append(" ");
        stringBuilder2.append(str2);
        return stringBuilder2.toString();
    }

    public static Object getObj(Context context, String str) throws IOException, ClassNotFoundException {
        FileInputStream openFileInput = context.openFileInput(str);
        ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
        Object readObject = objectInputStream.readObject();
        objectInputStream.close();
        openFileInput.close();
        return readObject;
    }

    public static String getSleepBatterySetting(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("name", context.getResources().getString(R.string.module_bat_booster));
            jSONObject.put("wifi", true);
            jSONObject.put("autosync", true);
            jSONObject.put("blootooth", true);
            jSONObject.put("brightness", true);
//            jSONObject.put(ServiceConfigUtil.METHOD_CONFIG_TIMEOUT_KEY, true);
            jSONObject.put("vibration", true);
            jSONObject.put("autowifi", true);
            jSONObject.put("autoautosync", true);
            jSONObject.put("autoblootooth", true);
            jSONObject.put("autobrightness", true);
            jSONObject.put("autotimeout", true);
            jSONObject.put("autovibration", true);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jSONObject.toString();
    }

    public static boolean isEmulated(String str) {
        return str.equals("sdcardfs") || str.equals("fuse");
    }

    public static final ArrayList<String> mountPoints(Context context) {
        ArrayList<String> arrayList = new ArrayList();
        String string = context.getString(R.string.pcl_app_storage);
        if (MountPoint.getHoneycombSdcard(context) == null && VERSION.SDK_INT <= 22) {
            arrayList.add(string);
        }
//        Map mountPoints = MountPoint.getMountPoints(context);
//        for (MountPoint mount : mountPoints.values()) {
//            arrayList.add(mount.root);
//            if (mountPoints.size() == 0) {
//                return arrayList;
//            }
//        }
        if (arrayList.size() == 1 && StringItirator((String) arrayList.get(0)) > 2) {
            arrayList.add(string);
        }
        return arrayList;
    }

    public static String storageCardPath() {
        try {
            return Environment.getExternalStorageDirectory().getCanonicalPath();
        } catch (Exception unused) {
            return Environment.getExternalStorageDirectory().getAbsolutePath();
        }
    }

    public static String withSlash(String str) {
        if (str.length() <= 0 || str.charAt(str.length() - 1) == '/') {
            return str;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append('/');
        return stringBuilder.toString();
    }
}
