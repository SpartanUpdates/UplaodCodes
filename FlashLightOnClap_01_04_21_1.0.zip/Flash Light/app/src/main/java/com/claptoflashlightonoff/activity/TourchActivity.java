package com.claptoflashlightonoff.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.claptoflashlightonoff.kprogresshud.KProgressHUD;
import com.claptoflashlightonoff.util.DragSwitch;
import com.claptoflashlightonoff.widget.MyWidgetIntentReceiver;
import com.claptoflashlightonoff.util.SoundHandler;
import com.claptoflashlightonoff.util.Utility;
import com.claptoflashlightonoff.util.onDragSwitchChangeListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.example.speaktourchtight.R;
import androidx.annotation.RequiresApi;

public class TourchActivity extends Activity implements OnClickListener {
    static boolean flashCheck = false;
    CameraManager camManager;
    private DragSwitch dragSwitch;
    boolean flagToCheckFlashlightOrNot = true;
    private boolean hasFlash;
    LinearLayout llGuide;
    private Parameters params;
    private StrobeRunner runner;
    ViewGroup sliderBackgroundImage;
    private Thread thread;
    TextView tvGuide;
    TextView tvHeader;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public class StrobeRunner implements Runnable {
        public volatile int delay;
        public volatile String errorMessage = "";
        private StrobeRunner instance;
        public volatile boolean isRunning = false;
        public volatile boolean requestStop = false;

        protected StrobeRunner() {
        }

        public StrobeRunner getInstance() {
            if (this.instance != null) {
                return this.instance;
            }
            StrobeRunner strobeRunner = new StrobeRunner();
            this.instance = strobeRunner;
            return strobeRunner;
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void run() {
            if (!this.isRunning) {
                this.requestStop = false;
                this.isRunning = true;
                while (!this.requestStop) {
                    try {
                        if (this.delay != 0) {
                            if (Build.VERSION.SDK_INT >= 23) {
                                try {
                                    TourchActivity.this.camManager = (CameraManager) TourchActivity.this.getSystemService("camera");
                                    if (TourchActivity.this.camManager != null) {
                                        TourchActivity.this.camManager.setTorchMode(TourchActivity.this.camManager.getCameraIdList()[0], true);
                                    }
                                } catch (CameraAccessException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                TourchActivity.this.params.setFlashMode("torch");
                                Utility.camera.setParameters(TourchActivity.this.params);
                                Utility.camera.startPreview();
                            }
                            Thread.sleep((long) this.delay);
                            TourchActivity.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_off);
                                }
                            });
                            if (Build.VERSION.SDK_INT >= 23) {
                                try {
                                    TourchActivity.this.camManager = (CameraManager) TourchActivity.this.getSystemService("camera");
                                    if (TourchActivity.this.camManager != null) {
                                        TourchActivity.this.camManager.setTorchMode(TourchActivity.this.camManager.getCameraIdList()[0], false);
                                    }
                                } catch (CameraAccessException e2) {
                                    e2.printStackTrace();
                                }
                            } else {
                                TourchActivity.this.params.setFlashMode("off");
                                Utility.camera.setParameters(TourchActivity.this.params);
                                Utility.camera.startPreview();
                            }
                            Thread.sleep((long) this.delay);
                            TourchActivity.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_on);
                                }
                            });
                        } else if (Build.VERSION.SDK_INT >= 23) {
                            try {
                                TourchActivity.this.camManager = (CameraManager) TourchActivity.this.getSystemService("camera");
                                if (TourchActivity.this.camManager != null) {
                                    TourchActivity.this.camManager.setTorchMode(TourchActivity.this.camManager.getCameraIdList()[0], true);
                                }
                            } catch (CameraAccessException e22) {
                                e22.printStackTrace();
                            }
                        } else {
                            TourchActivity.this.params.setFlashMode("torch");
                            Utility.camera.setParameters(TourchActivity.this.params);
                            Utility.camera.startPreview();
                        }
                    } catch (InterruptedException e3) {
                    } catch (RuntimeException e4) {
                        this.requestStop = true;
                        this.errorMessage = "Error setting camera flash status. Your device may be unsupported.";
                    }
                }
                MyWidgetIntentReceiver.isLightOn = false;
                TourchActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        if (TourchActivity.flashCheck) {
                            TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_off);
                            if (Build.VERSION.SDK_INT >= 23) {
                                try {
                                    TourchActivity.this.camManager = (CameraManager) TourchActivity.this.getSystemService("camera");
                                    if (TourchActivity.this.camManager != null) {
                                        TourchActivity.this.camManager.setTorchMode(TourchActivity.this.camManager.getCameraIdList()[0], false);
                                        return;
                                    }
                                    return;
                                } catch (CameraAccessException e) {
                                    e.printStackTrace();
                                    return;
                                }
                            }
                            TourchActivity.this.params.setFlashMode("off");
                            Utility.camera.setParameters(TourchActivity.this.params);
                            Utility.camera.startPreview();
                        }
                    }
                });
                this.isRunning = false;
                this.requestStop = false;
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourch);
        bindView();
        loadAd();
        BannerAds();

        init();
        addListner();
        maxBrightness();
        flashLightCheck();
        checkIsFlashOn();
        this.llGuide.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                TourchActivity.this.llGuide.setVisibility(View.GONE);
                return false;
            }
        });
    }

    public void checkIsFlashOn() {
        try {
            if (Utility.flagWidget) {
                this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_on);
                this.dragSwitch.setEnable(true);
                this.thread = new Thread(this.runner);
                this.thread.start();
                flashCheck = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void maxBrightness() {
        LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = 1.0f;
        getWindow().setAttributes(layoutParams);
        getWindow().addFlags(128);
    }

    private void bindView() {
        this.tvHeader = (TextView) findViewById(R.id.tvHeaderTitle);
        this.tvGuide = (TextView) findViewById(R.id.tvGuide);
        this.llGuide = (LinearLayout) findViewById(R.id.llGuide);
        this.sliderBackgroundImage = (ViewGroup) findViewById(R.id.layoutSlider);
    }

    private void init() {
        Typeface face = Typeface.createFromAsset(getAssets(), "majalla.ttf");
        this.tvGuide.setTypeface(face);
        this.tvHeader.setTypeface(face);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        if (prefs.getBoolean(getString(R.string.tourch), false)) {
            this.llGuide.setVisibility(View.GONE);
        } else {
            Editor edit = prefs.edit();
            edit.putBoolean(getString(R.string.tourch), Boolean.TRUE.booleanValue());
            edit.commit();
        }
        if (Utility.tempCameraOpenChecker) {
            Utility.tempCameraOpenChecker = false;
        } else if (Build.VERSION.SDK_INT >= 23) {
            this.camManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        } else {
            Utility.camera = Camera.open();
            this.params = Utility.camera.getParameters();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            this.runner = new StrobeRunner();
        }
        this.dragSwitch = new DragSwitch(this);
    }

    private void addListner() {
        findViewById(R.id.ibColor).setOnClickListener(this);
        findViewById(R.id.ibClap).setOnClickListener(this);
        findViewById(R.id.ibPolice).setOnClickListener(this);
        this.dragSwitch.setOnStateChangeListener(new onDragSwitchChangeListener() {
            @Override
            public void switchChangeState(boolean b) {
                if (b) {
                    TourchActivity.this.getWindow().addFlags(128);
                    if (TourchActivity.this.flagToCheckFlashlightOrNot) {
                        TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_on);
                        TourchActivity.this.playSound();
                        TourchActivity.this.thread = new Thread(TourchActivity.this.runner);
                        TourchActivity.this.thread.start();
                        TourchActivity.flashCheck = false;
                        return;
                    }
                    Toast.makeText(TourchActivity.this.getApplicationContext(), R.string.flash_message, Toast.LENGTH_LONG).show();
                    TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_off);
                    TourchActivity.this.dragSwitch.setEnable(false);
                    TourchActivity.this.playSound();
                } else if (!b) {
                    TourchActivity.this.getWindow().clearFlags(128);
                    Utility.flagWidget = false;
                    TourchActivity.this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_off);
                    TourchActivity.this.playSound();
                    TourchActivity.flashCheck = true;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        TourchActivity.this.runner.requestStop = true;
                    }
                }
            }
        });
    }

    private void loadAd() {
        //interstitial FullScreenAd
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        TourchActivity.this.loadColor();
                        break;
                    case 101:
                        TourchActivity.this.loadPolice();
                        break;
                    case 102:
                        TourchActivity.this.loadClap();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitialAd = new InterstitialAd(TourchActivity.this);
            interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(TourchActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void flashLightCheck() {
        this.hasFlash = getApplicationContext().getPackageManager().hasSystemFeature("android.hardware.camera.flash");
        if (this.hasFlash) {
            this.flagToCheckFlashlightOrNot = true;
        } else {
            this.flagToCheckFlashlightOrNot = false;
        }
    }

    protected void onStop() {
        super.onStop();
    }

    public void onBackPressed()
    {
        super.onBackPressed();
        back();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }

    private void back() {
        if (Build.VERSION.SDK_INT < 23) {
            Utility.camera.release();
            Utility.camera = null;
        } else if (this.camManager != null) {
            this.camManager = null;
        }
        Utility.flagWidget = false;
        stopFlashlight();
        Intent receiver = new Intent(this, MyWidgetIntentReceiver.class);
        receiver.putExtra("isFromActivity", true);
        receiver.setAction("FLASHLIGHT");
        sendBroadcast(receiver);
    }

    public void stopFlashlight() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            this.runner.requestStop = true;
        }
        this.dragSwitch.setEnable(false);
        this.sliderBackgroundImage.setBackgroundResource(R.drawable.switch_bg_off);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llGuide:
                this.llGuide.setVisibility(View.GONE);
                return;
            case R.id.ibColor:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(TourchActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 100;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadColor();
                }
                break;

            case R.id.ibPolice:
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(TourchActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 101;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadPolice();
                }
                break;

            case R.id.ibClap:

                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(TourchActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitialAd != null && interstitialAd.isLoaded()) {
                                Adid = 102;
                                interstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    loadClap();
                }
                break;
            default:
                return;
        }
    }

    private void loadPolice() {
        Intent i = new Intent(this, PoliceActivity.class);
        i.putExtra("Act", "Tourch");
        startActivity(i);
        back();
        finish();
    }

    private void loadClap() {
        startActivity(new Intent(this, MainActivity.class));
        back();
        finish();
    }

    private void loadColor() {
        Intent intentFlashBlinking = new Intent(this, ColorActivity.class);
        intentFlashBlinking.putExtra("Act", "Tourch");
        startActivity(intentFlashBlinking);
        back();
        finish();
    }

    private void playSound() {
        if (Utility.soundCheck) {
            SoundHandler.playToggleSound(this);
        }
    }

    public void loadSavedPreferences() {
        Utility.soundCheck = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("cbStart", true);
    }

    protected void onResume() {
        super.onResume();
        loadSavedPreferences();
    }
}
