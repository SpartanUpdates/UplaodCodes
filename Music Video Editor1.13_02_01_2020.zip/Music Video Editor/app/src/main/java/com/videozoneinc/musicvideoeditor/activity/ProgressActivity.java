package com.videozoneinc.musicvideoeditor.activity;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.videozoneinc.musicvideoeditor.MyApplication;
import com.videozoneinc.musicvideoeditor.OnProgressReceiver;
import com.videozoneinc.musicvideoeditor.util.ActivityAnimUtil;
import com.videozoneinc.musicvideoeditor.util.Utils;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.videozoneinc.musicvideoeditor.R;


public class ProgressActivity extends AppCompatActivity implements OnProgressReceiver {
    private MyApplication application;
    final float[] from;
    final float[] hsv;
    boolean isComplate;
    float lastProg;
    final float[] to;
    private TextView tvProgress;

    private void loadAd() {
        if (Utils.Utility.isNetworkAvailable(this)) {
            AdLoader adLoader = new AdLoader.Builder(this, getResources().getString(R.string.Admob_Native))
                    .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                        @Override
                        public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                            NativeTemplateStyle styles = new
                                    NativeTemplateStyle.Builder().build();
                            TemplateView template = findViewById(R.id.my_template);
                            template.setStyles(styles);
                            template.setNativeAd(unifiedNativeAd);
                        }
                    })
                    .build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            findViewById(R.id.nativeAdLayout).setVisibility(View.GONE);
        }
    }

    private void bindView() {
        this.tvProgress = (TextView) this.findViewById(R.id.tvProgress);
    }

    public void onOverlayingFinish(final String s) {
    }

    public void onProgressFinish(final String s) {
        Utils.isVideoCreationRunning = false;
        final Intent intent = new Intent((Context) this, (Class) videoPlay.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("android.intent.extra.TEXT", s);
        intent.putExtra("KEY", "FromProgress");
        this.application.isFristTimeTheme = true;
        ActivityAnimUtil.startActivitySafely((View) this.tvProgress, intent);
        finish();
    }

    public ProgressActivity() {
        this.from = new float[3];
        this.to = new float[3];
        this.hsv = new float[3];
        this.lastProg = 0.0f;
        this.isComplate = true;
    }

    private void changePercentageOnText(final float lastProg) {
        synchronized (this) {
            if (this.isComplate) {
                final ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{this.lastProg, lastProg});
                ofFloat.setDuration(300L);
                ofFloat.setInterpolator((TimeInterpolator) new LinearInterpolator());
                ofFloat.addUpdateListener((ValueAnimator.AnimatorUpdateListener) new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                        ProgressActivity.this.hsv[0] = ProgressActivity.this.from[0] + (ProgressActivity.this.to[0] - ProgressActivity.this.from[0]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[1] = ProgressActivity.this.from[1] + (ProgressActivity.this.to[1] - ProgressActivity.this.from[1]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.hsv[2] = ProgressActivity.this.from[2] + (ProgressActivity.this.to[2] - ProgressActivity.this.from[2]) * (float) valueAnimator.getAnimatedValue() / 100.0f;
                        ProgressActivity.this.tvProgress.setText((CharSequence) String.format(" %05.2f%%", (float) valueAnimator.getAnimatedValue()));
                        float p = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    }
                });
                ofFloat.addListener((Animator.AnimatorListener) new Animator.AnimatorListener() {
                    public void onAnimationCancel(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationEnd(final Animator animator) {
                        ProgressActivity.this.isComplate = true;
                    }

                    public void onAnimationRepeat(final Animator animator) {
                    }

                    public void onAnimationStart(final Animator animator) {
                        ProgressActivity.this.isComplate = false;
                    }
                });
                ofFloat.start();
                this.lastProg = lastProg;
            }
        }
    }

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_progress);
        this.getWindow().addFlags(128);
        this.application = MyApplication.getInstance();
        this.bindView();
        loadAd();
        ImageView imageView2 = (ImageView) findViewById(R.id.image2);
//        final LottieAnimationView animationView = (LottieAnimationView) findViewById(R.id.intro_lottie_animation_view);
//        animationView.useExperimentalHardwareAcceleration(true);
//        animationView.enableMergePathsForKitKatAndAbove(true);
//        animationView.loop(true);
//        animationView.playAnimation();
    }

    public void onImageProgressFrameUpdate(final float n) {
        this.runOnUiThread((Runnable) new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 25.0f / 100.0f);

            }
        });
    }

    protected void onResume() {
        super.onResume();
        this.application.setOnProgressReceiver((OnProgressReceiver) this);
        application.getOnProgressReceiver();
    }

    protected void onStop() {
        super.onStop();
        this.application.setOnProgressReceiver((OnProgressReceiver) this);
    }

    public void onBackPressed() {
    }

    public void onVideoProgressFrameUpdate(final float n) {
        this.runOnUiThread((Runnable) new Runnable() {
            @Override
            public void run() {
                ProgressActivity.this.changePercentageOnText(n * 75.0f / 100.0f + 25.0f);
            }
        });
    }
}
