package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.vidsoft.collagemaker.Model.Filter;
import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.util.ArrayList;

public class FilterAdapter extends Adapter<FilterAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    FilterCallback filterCallback;
    ArrayList<Filter> list;


    public interface FilterCallback {
        void FilterMethod(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout border;
        LinearLayout mainView;
        ImageView thumbnail;
        TextView txtTitle;

        public ViewHolder(View itemView) {
            super(itemView);
            this.thumbnail = (ImageView) itemView.findViewById(R.id.thumbnail);
            this.border = (RelativeLayout) itemView.findViewById(R.id.rl_border);
            this.txtTitle = (TextView) itemView.findViewById(R.id.tvTitle);
            this.mainView = (LinearLayout) itemView.findViewById(R.id.ll_mainView);
        }
    }

    public FilterAdapter(Activity activity, ArrayList<Filter> list) {
        this.Selection = "0";
        this.list = list;
        this.activity = activity;
        this.filterCallback = (FilterCallback) activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.filter_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.thumbnail.setImageResource(((Filter) this.list.get(position)).getThumb());
        holder.txtTitle.setText(((Filter) this.list.get(position)).getTitle());
        if (position == Integer.parseInt(this.Selection)) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.INVISIBLE);
        }
        holder.thumbnail.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                FilterAdapter.this.Selection = String.valueOf(position);
                FilterAdapter.this.notifyDataSetChanged();
                FilterAdapter.this.filterCallback.FilterMethod(position);

            }
        });
    }

    public int getItemCount() {
        return this.list.size();
    }
}