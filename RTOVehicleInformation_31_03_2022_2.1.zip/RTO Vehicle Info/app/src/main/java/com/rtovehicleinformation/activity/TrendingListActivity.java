package com.rtovehicleinformation.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Build;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.rtovehicleinformation.Adapter.TrendingListAdapter;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.application.AppController;
import com.rtovehicleinformation.utils.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.rtovehicleinformation.utils.nativeadsmethod.populateUnifiedNativeAdView;

public class TrendingListActivity extends AppCompatActivity {

    Activity activity = TrendingListActivity.this;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.trending_recycler)
    RecyclerView rvtrending;

    @BindView(R.id.trendy_title)
    TextView tvtrendytitle;

    @BindView(R.id.iv_back)
    ImageView ivback;

    String catName;
    TrendingListAdapter trendingListAdapter;


    private NativeAd nativeAd;

    String Input1;
    String Input2;
    String Input3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trending_list);
        ButterKnife.bind(this);
        catName = getIntent().getStringExtra("categoryname");
        tvtrendytitle.setText(this.catName);
        AppController.getInstance().catName = catName;
        LoadNativeAds();
        PutAnalyticsEvent();
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        if (this.catName.equals("Mr.Perfect")) {
            tvtrendytitle.setText("Mr.Perfect");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.mrperfectsnum, Utils.mrperfectsname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.mrperfectsnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Dancers")) {
            tvtrendytitle.setText("Dancers");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.dancersnum, Utils.dancersname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);
                    } else {
                        substring(Utils.dancersnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Singers")) {
            tvtrendytitle.setText("Singers");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.singersnum, Utils.singersname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.singersnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actors")) {
            tvtrendytitle.setText("Actors");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.actorsnum, Utils.actorsname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.actorsnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Politicians")) {
            tvtrendytitle.setText("Politicians");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.politiciansnum, Utils.politiciansname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.politiciansnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Sports Person")) {
            tvtrendytitle.setText("Sports Person");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.sportspersonsnum, Utils.sportspersonsname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.sportspersonsnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        } else if (this.catName.equals("Actresses")) {
            tvtrendytitle.setText("Actresses");
            this.rvtrending.setLayoutManager(new GridLayoutManager(this, 1));
            this.trendingListAdapter = new TrendingListAdapter(this, Utils.actressesnum, Utils.actressesname, new TrendingListAdapter.OnItemClickListener() {
                public void onItemClick(View view, final int i) {
                    if (AppController.mInterstitialAd != null) {
                        AppController.activity = activity;
                        AppController.getInstance().TrandingPositiion = i;
                        AppController.AdsId = 11;
                        AppController.mInterstitialAd.show(activity);

                    } else {
                        substring(Utils.actressesnum[i]);
                    }
                }
            });
            this.rvtrending.setAdapter(this.trendingListAdapter);
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "TrendingListActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (TrendingListActivity.this.nativeAd != null) {
                            TrendingListActivity.this.nativeAd.destroy();
                        }
                        TrendingListActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void substring(String str) {
        String substring;
        if (Character.isDigit(str.charAt(4))) {
            substring = str.substring(0, 4);
            str = str.substring(4);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = "";
        } else if (Character.isDigit(str.charAt(5))) {
            substring = str.substring(0, 5);
            str = str.substring(5);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 5);
        } else if (Character.isDigit(str.charAt(6))) {
            substring = str.substring(0, 6);
            str = str.substring(6);
            Input1 = substring.substring(0, 2);
            Input2 = substring.substring(2, 4);
            Input3 = substring.substring(4, 6);
        } else {
            substring = str.substring(0, 7);
            str = str.substring(7);
        }

        Intent intent = new Intent(this, VehicleDetailActivity.class);
        intent.putExtra("first", Input1);
        intent.putExtra("second", Input2);
        intent.putExtra("third", Input3);
        intent.putExtra("fourth", str);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }


    @Override
    public void onBackPressed() {
        if (AppController.mInterstitialAd != null) {
            AppController.activity = activity;
            AppController.AdsId = 12;
            AppController.mInterstitialAd.show(activity);
        } else {
            GoBack();
        }
    }

    private void GoBack() {
        startActivity(new Intent(activity, TrendingActivity.class));
        finish();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
