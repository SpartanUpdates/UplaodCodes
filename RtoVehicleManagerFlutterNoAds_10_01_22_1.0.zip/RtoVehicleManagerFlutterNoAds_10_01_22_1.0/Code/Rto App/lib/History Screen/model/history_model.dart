class HistoryModel {
  String licensePlate;
  String ownerName;
  String insuranceCompany;
  String responseClass;
  String registrationDate;
  String insuranceExpiry;
  String engineNumber;
  String fuelType;
  String brandName;
  String brandModel;
  String rto;
  String state;
  String rtoCode;

  HistoryModel(
      {required this.ownerName,
      required this.licensePlate,
      required this.registrationDate,
      required this.responseClass,
      required this.brandName,
      required this.brandModel,
      required this.engineNumber,
      required this.fuelType,
      required this.insuranceCompany,
      required this.insuranceExpiry,
      required this.rto,
      required this.state,
      required this.rtoCode});

  HistoryModel.fromMap(Map<String, dynamic> res)
      : ownerName = res['ownerName'],
        licensePlate = res['licensePlate'],
        registrationDate = res['registrationDate'],
        responseClass = res['responseClass'],
        brandName = res['brandName'],
        brandModel = res['brandModel'],
        engineNumber = res['engineNumber'],
        fuelType = res['fuelType'],
        insuranceCompany = res['insuranceCompany'],
        insuranceExpiry = res['insuranceExpiry'],
        rto = res['rto'],
        state = res['state'],
        rtoCode = res['rtoCode'];

  Map<String, Object?> toMap() {
    return {
      'ownerName': ownerName,
      'licensePlate': licensePlate,
      'registrationDate': registrationDate,
      'responseClass': responseClass,
      'brandName': brandName,
      'brandModel': brandModel,
      'engineNumber': engineNumber,
      'fuelType': fuelType,
      'insuranceCompany': insuranceCompany,
      'insuranceExpiry': insuranceExpiry,
      'rto': rto,
      'state': state,
      'rtoCode': rtoCode
    };
  }
}
