package com.esc.motivationquotes.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.esc.motivationquotes.R;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.model.Quote;
import com.esc.motivationquotes.util.QuoteUtils;

import java.util.ArrayList;

public class QuotesListAdapter extends RecyclerView.Adapter {
    private Callback callback;
    private Context context;
    private ArrayList<String> mQuotesItems;

    public interface Callback {
        void onQuoteClick(int i);

        void onQuoteLongClick(int i);
    }

    public class FavoriteItemHolder extends RecyclerView.ViewHolder {
        private TextView author;
        private TextView quote;
        private RelativeLayout relativeBackground;

        public FavoriteItemHolder(View view) {
            super(view);
            this.quote = view.findViewById(R.id.txt_Quote);
            this.author = view.findViewById(R.id.txt_Author);
            this.relativeBackground = view.findViewById(R.id.relativeBackground);
        }
    }

    public QuotesListAdapter(ArrayList<String> arrayList, Context context, Callback callback) {
        this.mQuotesItems = arrayList;
        this.context = context;
        this.callback = callback;
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new FavoriteItemHolder(LayoutInflater.from(this.context).inflate(R.layout.item_list_quote, viewGroup, false));
    }

    @SuppressLint("ResourceType")
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        ArrayList arrayList = this.mQuotesItems;
        if (arrayList != null) {
            FavoriteItemHolder favoriteItemHolder = (FavoriteItemHolder) viewHolder;
            Quote quote = QuoteUtils.getQuote(1, (String) arrayList.get(i), true);
            favoriteItemHolder.quote.setText(quote.getText());
            if (quote.getAuthor() == null || quote.getAuthor().isEmpty()) {
                favoriteItemHolder.author.setVisibility(8);
            } else {
                favoriteItemHolder.author.setText(quote.getAuthor());
                favoriteItemHolder.author.setVisibility(0);
            }
            favoriteItemHolder.relativeBackground.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (callback != null) {
                        callback.onQuoteLongClick(i);
                    }
                }
            });
            favoriteItemHolder.relativeBackground.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v)
                {
                    if (callback != null) {
                        callback.onQuoteLongClick(i);
                    }
                    return false;
                }
            });
        }
    }

    public int getItemCount() {
        return this.mQuotesItems.size();
    }

    public void setTruckloads(ArrayList<String> arrayList) {
        this.mQuotesItems = arrayList;
        notifyDataSetChanged();
    }
}
