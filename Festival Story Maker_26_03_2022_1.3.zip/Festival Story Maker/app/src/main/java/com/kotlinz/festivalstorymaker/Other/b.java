package com.kotlinz.festivalstorymaker.Other;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.kotlinz.festivalstorymaker.multiTouch.Vector2D;

public class b {

    public final a a;
    public boolean b;
    public MotionEvent c;
    public MotionEvent d;
    public static Vector2D e;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    public float k;
    public float l;
    public float m;
    public float n;
    public float o;
    public float p;
    public boolean q;
    public int r;
    public int s;
    public boolean t;

    public b(final a a) {
        this.a = a;
        this.e = new Vector2D();
    }

    public final int a(final MotionEvent motionEvent, int i, final int n) {
        final int pointerCount = motionEvent.getPointerCount();
        final int pointerIndex = motionEvent.findPointerIndex(i);
        for (i = 0; i < pointerCount; ++i) {
            if (i != n && i != pointerIndex) {
                return i;
            }
        }
        return -1;
    }

    public float b() {
        if (this.n == -1.0f) {
            if (this.l == -1.0f) {
                final float j = this.j;
                final float k = this.k;
                this.l = (float)Math.sqrt(k * k + j * j);
            }
            final float l = this.l;
            if (this.m == -1.0f) {
                final float h = this.h;
                final float i = this.i;
                this.m = (float)Math.sqrt(i * i + h * h);
            }
            this.n = l / this.m;
        }
        return this.n;
    }

    public boolean c(final View view, final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.d();
        }
        final boolean q = this.q;
        final boolean b = false;
        if (q) {
            return false;
        }
        Label_0662: {
            Label_0568: {
                int r;
                if (!this.b) {
                    if (actionMasked != 0) {
                        if (actionMasked == 1) {
                            break Label_0662;
                        }
                        if (actionMasked != 5) {
                            return true;
                        }
                        final MotionEvent c = this.c;
                        if (c != null) {
                            c.recycle();
                        }
                        this.c = MotionEvent.obtain(motionEvent);
                        final int actionIndex = motionEvent.getActionIndex();
                        final int pointerIndex = motionEvent.findPointerIndex(this.r);
                        this.s = motionEvent.getPointerId(actionIndex);
                        if (pointerIndex < 0 || pointerIndex == actionIndex) {
                            this.r = motionEvent.getPointerId(this.a(motionEvent, this.s, -1));
                        }
                        this.t = false;
                        break Label_0568;
                    }
                    else {
                        r = motionEvent.getPointerId(0);
                    }
                }
                else {
                    if (actionMasked == 1) {
                        break Label_0662;
                    }
                    if (actionMasked != 2) {
                        if (actionMasked != 3) {
                            if (actionMasked != 5) {
                                if (actionMasked != 6) {
                                    return true;
                                }
                                final int pointerCount = motionEvent.getPointerCount();
                                final int actionIndex2 = motionEvent.getActionIndex();
                                final int pointerId = motionEvent.getPointerId(actionIndex2);
                                int n = 0;
                                if (pointerCount > 2) {
                                    final int r2 = this.r;
                                    Label_0357: {
                                        Label_0355: {
                                            if (pointerId == r2) {
                                                final int a = this.a(motionEvent, this.s, actionIndex2);
                                                if (a < 0) {
                                                    break Label_0355;
                                                }
                                                if (this.a == null) {
                                                    throw null;
                                                }
                                                this.r = motionEvent.getPointerId(a);
                                                this.t = true;
                                            }
                                            else {
                                                n = (b ? 1 : 0);
                                                if (pointerId != this.s) {
                                                    break Label_0357;
                                                }
                                                final int a2 = this.a(motionEvent, r2, actionIndex2);
                                                if (a2 < 0) {
                                                    break Label_0355;
                                                }
                                                if (this.a == null) {
                                                    throw null;
                                                }
                                                this.s = motionEvent.getPointerId(a2);
                                                this.t = false;
                                            }
                                            this.c = MotionEvent.obtain(motionEvent);
                                            this.e(view, motionEvent);
                                            this.b = this.a.b(view, this);
                                            n = (b ? 1 : 0);
                                            break Label_0357;
                                        }
                                        n = 1;
                                    }
                                    this.c.recycle();
                                    this.c = MotionEvent.obtain(motionEvent);
                                    this.e(view, motionEvent);
                                }
                                else {
                                    n = 1;
                                }
                                if (n == 0) {
                                    return true;
                                }
                                this.e(view, motionEvent);
                                if (pointerId == (r = this.r)) {
                                    r = this.s;
                                }
                                final int pointerIndex2 = motionEvent.findPointerIndex(r);
                                this.f = motionEvent.getX(pointerIndex2);
                                this.g = motionEvent.getY(pointerIndex2);
                                if (this.a == null) {
                                    throw null;
                                }
                                this.d();
                            }
                            else {
                                if (this.a == null) {
                                    throw null;
                                }
                                int r3 = this.r;
                                final int s = this.s;
                                this.d();
                                this.c = MotionEvent.obtain(motionEvent);
                                if (!this.t) {
                                    r3 = s;
                                }
                                this.r = r3;
                                this.s = motionEvent.getPointerId(motionEvent.getActionIndex());
                                this.t = false;
                                if (motionEvent.findPointerIndex(this.r) < 0 || this.r == this.s) {
                                    this.r = motionEvent.getPointerId(this.a(motionEvent, this.s, -1));
                                }
                                break Label_0568;
                            }
                        }
                        else {
                            if (this.a != null) {
                                break Label_0662;
                            }
                            throw null;
                        }
                    }
                    else {
                        this.e(view, motionEvent);
                        if (this.o / this.p > 0.67f && this.a.a(view, this)) {
                            this.c.recycle();
                            this.c = MotionEvent.obtain(motionEvent);
                            return true;
                        }
                        return true;
                    }
                }
                this.r = r;
                this.t = true;
                return true;
            }
            this.e(view, motionEvent);
            this.b = this.a.b(view, this);
            return true;
        }
        this.d();
        return true;
    }

    public final void d() {
        final MotionEvent c = this.c;
        if (c != null) {
            c.recycle();
            this.c = null;
        }
        final MotionEvent d = this.d;
        if (d != null) {
            d.recycle();
            this.d = null;
        }
        this.b = false;
        this.r = -1;
        this.s = -1;
        this.q = false;
    }

    public final void e(final View view, final MotionEvent motionEvent) {
        final MotionEvent d = this.d;
        if (d != null) {
            d.recycle();
        }
        this.d = MotionEvent.obtain(motionEvent);
        this.l = -1.0f;
        this.m = -1.0f;
        this.n = -1.0f;
        this.e.set(0.0f, 0.0f);
        final MotionEvent c = this.c;
        final int pointerIndex = c.findPointerIndex(this.r);
        final int pointerIndex2 = c.findPointerIndex(this.s);
        final int pointerIndex3 = motionEvent.findPointerIndex(this.r);
        final int pointerIndex4 = motionEvent.findPointerIndex(this.s);
        if (pointerIndex >= 0 && pointerIndex2 >= 0 && pointerIndex3 >= 0 && pointerIndex4 >= 0) {
            final float x = c.getX(pointerIndex);
            final float y = c.getY(pointerIndex);
            final float x2 = c.getX(pointerIndex2);
            final float y2 = c.getY(pointerIndex2);
            final float x3 = motionEvent.getX(pointerIndex3);
            final float y3 = motionEvent.getY(pointerIndex3);
            final float x4 = motionEvent.getX(pointerIndex4);
            final float y4 = motionEvent.getY(pointerIndex4);
            final float j = x4 - x3;
            final float k = y4 - y3;
            this.e.set(j, k);
            this.h = x2 - x;
            this.i = y2 - y;
            this.j = j;
            this.k = k;
            this.f = j * 0.5f + x3;
            this.g = k * 0.5f + y3;
            motionEvent.getEventTime();
            c.getEventTime();
            this.o = motionEvent.getPressure(pointerIndex4) + motionEvent.getPressure(pointerIndex3);
            this.p = c.getPressure(pointerIndex2) + c.getPressure(pointerIndex);
            return;
        }
        this.q = true;
        if (!this.b) {
            return;
        }
        if (this.a != null) {
            return;
        }
        throw null;
    }

    public interface a
    {
        boolean a(final View p0, final b p1);

        boolean b(final View p0, final b p1);
    }

}
