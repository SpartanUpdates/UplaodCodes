package com.esc.flashlight.appwidget.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.service.ScreenOnOffService;
import com.esc.flashlight.util.FALib;
import com.esc.flashlight.util.FlashAlertUtil;
import com.esc.flashlight.util.PrefManager;

public class AppWidgetBroadcastReceiver extends BroadcastReceiver {

    public static final String ACTION = " flash.light.shine.appwidgetclick";
    private static final String TAG = "AppWidget";

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, action);
        if (ACTION.equals(action)) {
            PrefManager prefManager = APP.getPrefManager();
            boolean useTotally = prefManager.getUseTotally() ;
            prefManager.setUseTotally(useTotally);
            if (!prefManager.getUseScreenOn()) {
                if (useTotally) {
                    prefManager.setScreenOnTime(SystemClock.elapsedRealtime() - FlashAlertUtil.SCREEN_ON_SAFE_DELAY);
                    context.startService(new Intent(context, ScreenOnOffService.class));
                } else {
                    context.stopService(new Intent(context, ScreenOnOffService.class));
                }
            }
            FALib.sendBroadcastChangedTotallyUseState(context);
        }
    }
}
