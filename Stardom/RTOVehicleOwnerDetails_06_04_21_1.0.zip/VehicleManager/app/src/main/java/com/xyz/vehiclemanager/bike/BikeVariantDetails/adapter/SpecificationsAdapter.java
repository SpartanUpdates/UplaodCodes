package com.xyz.vehiclemanager.bike.BikeVariantDetails.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.adapter.VariantItemAttrAdapter;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeSpecification;
import java.util.ArrayList;

public class SpecificationsAdapter extends RecyclerView.Adapter<SpecificationsAdapter.ViewHolder> {
    private Context context;
    private ArrayList<BikeSpecification> specificationKeyList;
    private ArrayList<Item> engineAndTransmition;
    private ArrayList<Item> breakWheelAndSuspention;
    private ArrayList<Item> dimensionsAndChassis;
    private ArrayList<Item> fuelEfficiencyAndPerfomance;
    private VariantItemAttrAdapter variantItemAttrAdapter;

    public SpecificationsAdapter(Context context, ArrayList<BikeSpecification> specificationKeyList, ArrayList<Item> engineAndTransmition, ArrayList<Item> breakWheelAndSuspention, ArrayList<Item> dimensionsAndChassis, ArrayList<Item> fuelEfficiencyAndPerfomance) {
        this.context = context;
        this.specificationKeyList = specificationKeyList;
        this.engineAndTransmition = engineAndTransmition;
        this.breakWheelAndSuspention = breakWheelAndSuspention;
        this.dimensionsAndChassis = dimensionsAndChassis;
        this.fuelEfficiencyAndPerfomance = fuelEfficiencyAndPerfomance;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        RecyclerView recyclerViewAttrData;
        TextView specificationKey;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            specificationKey=itemView.findViewById(R.id.tv_varinatKeyName);
            recyclerViewAttrData=itemView.findViewById(R.id.rv_variantKey);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_variantkey,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BikeSpecification specificationModel = specificationKeyList.get(position);
        holder.specificationKey.setText(specificationModel.getKey());
        String key = specificationModel.getKey();
        if(key.equals("Engine & Transmission"))
        {
            variantItemAttrAdapter = new VariantItemAttrAdapter(context, engineAndTransmition);
            holder.recyclerViewAttrData.setAdapter(variantItemAttrAdapter);
            holder.recyclerViewAttrData.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerViewAttrData.setHasFixedSize(true);
        }
        if(key.equals("Brakes, Wheels & Suspension"))
        {
            variantItemAttrAdapter = new VariantItemAttrAdapter(context, breakWheelAndSuspention);
            holder.recyclerViewAttrData.setAdapter(variantItemAttrAdapter);
            holder.recyclerViewAttrData.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerViewAttrData.setHasFixedSize(true);
        }
        if(key.equals("Dimensions & Chassis"))
        {
            variantItemAttrAdapter = new VariantItemAttrAdapter(context, dimensionsAndChassis);
            holder.recyclerViewAttrData.setAdapter(variantItemAttrAdapter);
            holder.recyclerViewAttrData.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerViewAttrData.setHasFixedSize(true);
        }
        if(key.equals("Fuel Efficiency & Performance"))
        {
            variantItemAttrAdapter = new VariantItemAttrAdapter(context, fuelEfficiencyAndPerfomance);
            holder.recyclerViewAttrData.setAdapter(variantItemAttrAdapter);
            holder.recyclerViewAttrData.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerViewAttrData.setHasFixedSize(true);
        }
    }
    @Override
    public int getItemCount() {
        return specificationKeyList.size();
    }
}
