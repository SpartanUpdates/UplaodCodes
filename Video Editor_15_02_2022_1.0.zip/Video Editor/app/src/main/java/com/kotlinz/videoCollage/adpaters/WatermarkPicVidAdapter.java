package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.kotlinz.videoCollage.interfaces.PicVidWatermarkAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class WatermarkPicVidAdapter extends Adapter<WatermarkPicVidAdapter.FontAdapterViewHolder> {
    private Context context;
    private int height;
    private ArrayList<String> listWatermark;
    private PicVidWatermarkAdapterCallBackInterface listener;
    private int pos = -1;
    private int width;

    public static class FontAdapterViewHolder extends ViewHolder {
        ImageView imgWatermark;
        LinearLayout mMain;

        public FontAdapterViewHolder(View view) {
            super(view);
            this.mMain = (LinearLayout) view.findViewById(R.id.main_watermark_picvid);
            this.imgWatermark = (ImageView) view.findViewById(R.id.img_watermark_picvid);
        }
    }

    public WatermarkPicVidAdapter(ArrayList<String> arrayList, Context context, PicVidWatermarkAdapterCallBackInterface picVidWatermarkAdapterCallBackInterface) {
        this.context = context;
        this.listWatermark = arrayList;
        this.listener = picVidWatermarkAdapterCallBackInterface;
        Display defaultDisplay = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.width = point.x;
        this.height = point.y;
    }

    public FontAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new FontAdapterViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_watermark_picvid, viewGroup, false));
    }

    public void onBindViewHolder(FontAdapterViewHolder fontAdapterViewHolder, final int i) {
        String str = (String) this.listWatermark.get(i);
        RequestManager with = Glide.with(this.context);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///android_asset/Watermark/");
        stringBuilder.append(str);
        ((RequestBuilder) with.load(Uri.parse(stringBuilder.toString())).diskCacheStrategy(DiskCacheStrategy.NONE)).into(fontAdapterViewHolder.imgWatermark);
        fontAdapterViewHolder.imgWatermark.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                WatermarkPicVidAdapter.this.pos = i;
                WatermarkPicVidAdapter.this.listener.itemClick(i);
                WatermarkPicVidAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            fontAdapterViewHolder.imgWatermark.setBackgroundResource(R.drawable.watermark_selected);
        } else {
            fontAdapterViewHolder.imgWatermark.setBackgroundResource(R.drawable.watermark_un_selected);
        }
    }

    public int getItemCount() {
        return this.listWatermark.size();
    }
}
