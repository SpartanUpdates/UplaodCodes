package com.UnitedVideos.ArrangeImages.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.UnitedVideos.ArrangeImages.Adapter.SwapeImageAdapter;
import com.UnitedVideos.ImageSelection.activity.SelectImageActivityUv;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.ImageSelection.Model.ImageModel;
import com.wavymusic.ImageSelection.View.EmptyRecyclerView;
import com.wavymusic.R;

import java.util.ArrayList;

public class ArrangePhotosActivityUv extends AppCompatActivity {

    Activity activity = ArrangePhotosActivityUv.this;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    ItemTouchHelper.Callback backCall;
    private MyApplication application;
    private SwapeImageAdapter swapeImageAdapterAdapter;
    private EmptyRecyclerView emptyRecyclerview;
    private Toolbar toolbar;
    String result_conc = "";
    String iscut;
    int height;
    int Width;
    public static boolean Preview;
    String isfrom;
    ImageView ivback;
    TextView tvdone;

    private NativeBannerAd mNativeBannerAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrange_photos);
        Preview = getIntent().hasExtra(EXTRA_FROM_PREVIEW);
        this.application = MyApplication.getInstance();
        this.application.isEditModeEnable = true;
        iscut = getIntent().getStringExtra("isCut");
        height = getIntent().getIntExtra("hight", 640);
        Width = getIntent().getIntExtra("width", 520);
        isfrom = getIntent().getStringExtra("isfrom");
        PutAnalyticsEvent();
        bindView();
        init();
        LoadNativeAds();
//        CallNativeAds();
    }


    public View onCreateView(View view, String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public ImageModel getItem(int pos) {
        ArrayList<ImageModel> list = this.application.getSelectedImages();
        if (list.size() <= pos) {
            return new ImageModel();
        }
        return list.get(pos);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == 1001) {
            String i = data.getExtras().get("uri_new").toString();
            ImageModel imgs = new ImageModel();
            imgs.setImagePath(i);
            this.application.ReplaceSelectedImage(imgs, data.getExtras().getInt("position"));

            if (swapeImageAdapterAdapter != null) {
                swapeImageAdapterAdapter.notifyItemChanged(data.getExtras().getInt(
                        "position"));
            }
        }
    }

    public View onCreateView(String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public ArrangePhotosActivityUv() {
        this.Preview = false;
        this.backCall = new ItemTouchHelper.Callback() {
            @Override
            public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState) {
                if (actionState == 0) {
                    ArrangePhotosActivityUv.this.swapeImageAdapterAdapter
                            .notifyDataSetChanged();
                }
            }

            @Override
            public void onMoved(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder,
                                int fromPos, RecyclerView.ViewHolder target, int toPos, int x, int y) {
                ArrangePhotosActivityUv.this.swapeImageAdapterAdapter.swap(
                        viewHolder.getAdapterPosition(),
                        target.getAdapterPosition());
                ArrangePhotosActivityUv.this.application.min_pos = Math.min(
                        ArrangePhotosActivityUv.this.application.min_pos,
                        Math.min(fromPos, toPos));
                MyApplication.isBreak = true;
            }

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder,
                                  RecyclerView.ViewHolder target) {
                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            }

            @Override
            public int getMovementFlags(@NonNull RecyclerView recyclerView,
                                        @NonNull RecyclerView.ViewHolder viewHolder) {
                return ItemTouchHelper.Callback.makeFlag(2, 51);
            }
        };
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ArrangePhotosActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void bindView() {
        this.emptyRecyclerview = findViewById(R.id.relativeL_AlbumVideo);
        this.tvdone = findViewById(R.id.tv_done);
        ivback = findViewById(R.id.ivBack);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tvdone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.fbinterstitialAdUv != null && MyApplication.fbinterstitialAdUv.isAdLoaded()) {
                    MyApplication.AdsIdUv = 1;
                    MyApplication.AdsShowContext = activity;
                    MyApplication.fbinterstitialAdUv.show();
                } else {
                    done();
                }
            }
        });
    }


    private void init() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(
                this, 2, RecyclerView.VERTICAL, false);
        this.swapeImageAdapterAdapter = new SwapeImageAdapter(this);
        this.emptyRecyclerview.setLayoutManager(gridLayoutManager);
        this.emptyRecyclerview.setItemAnimator(new DefaultItemAnimator());
        this.emptyRecyclerview.setEmptyView(findViewById(R.id.emptylist));
        this.emptyRecyclerview.setAdapter(this.swapeImageAdapterAdapter);
        new ItemTouchHelper(this.backCall).attachToRecyclerView(this.emptyRecyclerview);
        toolbar = findViewById(R.id.toolbar);
    }

    @SuppressLint("MissingSuperCall")
    protected void onResume() {
        super.onRestart();
        if (this.swapeImageAdapterAdapter != null) {
            this.swapeImageAdapterAdapter.notifyDataSetChanged();
        }
    }


    public boolean onCreateOptionsMenu(final Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(final MenuItem item) {
        final int itmId = item.getItemId();
        if (itmId == 16908332) {
            super.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void done() {
        application.isEditModeEnable = false;
        if (Preview) {
            setResult(-1);
            finish();
        } else {
            loadPreview();
        }
    }

    private void loadPreview() {
        for (int i = 0; i < this.application.getCropImagesUV().size(); ++i) {
            if (i == 0) {
                result_conc = this.application.getCropImagesUV().get(i);
            } else {
                result_conc = result_conc + MyApplication.SPLIT_PATTERN + this.application.getCropImagesUV().get(i);
            }
        }
        SendDataToUnity();
    }

    public void SendDataToUnity() {
        UnityPlayer.UnitySendMessage("UVThemeData", "GetImagePath", result_conc);
        finish();
    }

    private void LoadNativeAds() {
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(activity, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }

    /*private void CallNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.native_adview);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }*/


    public void onBackPressed() {
        if (iscut.equals("3D")) {
            application.IsBack = true;
            Intent intent = new Intent(ArrangePhotosActivityUv.this, SelectImageActivityUv.class);
            intent.putExtra("hight", height);
            intent.putExtra("width", Width);
            intent.putExtra("isCut", iscut);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        } else {
            application.IsBack = true;
            Intent intent = new Intent(ArrangePhotosActivityUv.this, SelectImageActivityUv.class);
            intent.putExtra("hight", height);
            intent.putExtra("width", Width);
            intent.putExtra("isCut", iscut);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        }
    }
}