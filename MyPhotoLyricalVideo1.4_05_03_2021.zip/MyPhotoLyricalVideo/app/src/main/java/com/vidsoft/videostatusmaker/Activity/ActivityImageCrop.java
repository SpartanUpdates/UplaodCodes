package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.Others.CropImageView;


public class ActivityImageCrop extends Activity {
    ImageView ivBack;
    TextView ivDone;
    Typeface typeface;
    CropImageView cropImageView;
    TextView tvTitle;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.image_crop);
        getWindow().addFlags(1024);
        PutAnalyticsEvent();
        bindview();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityImageCrop");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void bindview() {
        this.cropImageView = (CropImageView) findViewById(R.id.img);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.ivDone = (TextView) findViewById(R.id.done);
        this.tvTitle = (TextView) findViewById(R.id.title);

    }

    private void init() {
        this.tvTitle.setTextSize(18.0f);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.cropImageView.setImageUriAsync(Utils.uri);
        this.cropImageView.setFixedAspectRatio(false);
        this.ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.selected_Bitmap = ActivityImageCrop.this.cropImageView.getCroppedImage();
                ActivityImageCrop.this.setResult(-1);
                ActivityImageCrop.this.finish();
            }
        });
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityImageCrop.this.onBackPressed();
            }
        });
    }

}
