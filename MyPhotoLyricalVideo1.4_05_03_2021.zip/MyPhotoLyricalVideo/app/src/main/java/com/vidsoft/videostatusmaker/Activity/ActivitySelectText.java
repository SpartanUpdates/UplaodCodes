package com.vidsoft.videostatusmaker.Activity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.vidsoft.videostatusmaker.adapter.TextAdapter;

import static com.vidsoft.videostatusmaker.NativeAds.NativeAdMethod.populateNativeAdView;

public class ActivitySelectText extends AppCompatActivity {
    TextAdapter textAdapter;
    ImageView ivBack;
    Typeface typeface;
    GridView gridView;
    String[] styles;
    TextView title;

    private UnifiedNativeAd nativeAd;


    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        PutAnalyticsEvent();
        LoadNativeAds();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySelectText");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivitySelectText.this.onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.gridView = this.findViewById(R.id.stylelist);
        try {
            this.styles = this.getResources().getAssets().list("fonts");
            this.textAdapter = new TextAdapter(this.getApplicationContext(), this.styles);
            this.gridView.setAdapter((ListAdapter) this.textAdapter);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.gridView.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                ActivityPreview.complete = false;
                final TextView lyric_txt1 = ActivityPreview.lyricTxt1;
                final AssetManager assets = ActivitySelectText.this.getAssets();
                final StringBuilder sb = new StringBuilder();
                sb.append("fonts/");
                sb.append(ActivitySelectText.this.styles[n]);
                lyric_txt1.setTypeface(Typeface.createFromAsset(assets, sb.toString()));
                final TextView lyric_txt2 = ActivityPreview.lyricTxt2;
                final AssetManager assets2 = ActivitySelectText.this.getAssets();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("fonts/");
                sb2.append(ActivitySelectText.this.styles[n]);
                lyric_txt2.setTypeface(Typeface.createFromAsset(assets2, sb2.toString()));
                ActivitySelectText.this.setResult(-1, new Intent(ActivitySelectText.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectText.this.finish();
            }
        });
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


}
