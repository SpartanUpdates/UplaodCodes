package com.mbit.VideoMaker.Fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.mbit.VideoMaker.Adapter.OnlineSongAdapter;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Handler.HttpHandler;
import com.mbit.VideoMaker.Model.OnlineSongModel;
import com.mbit.VideoMaker.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class OnlineCategoryWiseSongFragment extends Fragment {

    public static MediaPlayer mediaPlayer;
    public ArrayList<OnlineSongModel> songModelArrayList = new ArrayList<>();
    public OnlineSongAdapter onlineSongAdapter;
    Integer CategoryId = -1;
    RelativeLayout rlloadingpager;
    RecyclerView rvCategoryWiseTheme;
    String SongCatWiseDataUrl = "";
    String offlienResopnseData;
    SharedPreferences ThemeHomePreferences;
    String MY_PREF = "Song_pref";
    SharedPreferences pref;
    //    LinearLayout llInternetCheck;
//    Button btnRefresh;
    private String CatId;
    private boolean IsofflineResopnse = false;


    public static Fragment getInstance(String ThemeCatUrl, int catid) {
        Bundle bundle = new Bundle();
        bundle.putString("SongCatWiseDataUrl", ThemeCatUrl);
        bundle.putInt("CategoryId", catid);
        OnlineCategoryWiseSongFragment categoryWiseSongFragment = new OnlineCategoryWiseSongFragment();
        categoryWiseSongFragment.setArguments(bundle);
        return categoryWiseSongFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SongCatWiseDataUrl = getArguments().getString("SongCatWiseDataUrl");
        CategoryId = getArguments().getInt("CategoryId");
        CatId = String.valueOf(CategoryId);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_online_song_catwise, container, false);
        ThemeHomePreferences = getActivity().getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        bindView(rootView);
        GetThemeUrl();
        if (songModelArrayList != null && songModelArrayList.size() == 0) {
            if (ThemeHomePreferences.getBoolean("ThemeFirstTime", true)) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    ThemeHomePreferences.edit().putBoolean("ThemeFirstTime", false).apply();
                    new GetThemeData().execute(SongCatWiseDataUrl);
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation !", Toast.LENGTH_LONG).show();
                }
            } else {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    new GetThemeData().execute(SongCatWiseDataUrl);
                    SetThemeAdapter();
                } else {
                    IsofflineResopnse = true;
                    new GetThemeData().execute(SongCatWiseDataUrl);
                    SetThemeAdapter();
                }
            }
        } else {
            SetThemeAdapter();
        }
        return rootView;
    }


    private void bindView(View view) {
        rvCategoryWiseTheme = view.findViewById(R.id.rv_onlinesong);
        rlloadingpager = view.findViewById(R.id.rl_load_onlinesong);
//        llInternetCheck = view.findViewById(R.id.ll_internet);
//        btnRefresh = view.findViewById(R.id.btn_refresh);
    }

    public void GetThemeUrl() {
        if (ThemeHomePreferences.getString("hometheme", "homefirsttime").equals("homefirsttime")) {
            SharedPreferences.Editor edit = ThemeHomePreferences.edit();
            edit.putString("hometheme", "ok");
            edit.putString("homethemeurl", SongCatWiseDataUrl);
            edit.apply();
        } else if (ThemeHomePreferences.getString("homethemeurl", null).equals("ok")) {
            SongCatWiseDataUrl = (ThemeHomePreferences.getString("homethemeurl", ""));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        OnlineSongAdapter2.IsMusicPlay = false;
    }

    public void SetThemeAdapter() {
        onlineSongAdapter = new OnlineSongAdapter(getActivity(), songModelArrayList, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvCategoryWiseTheme.setLayoutManager(mLayoutManager);
        rvCategoryWiseTheme.setAdapter(onlineSongAdapter);
        onlineSongAdapter.notifyDataSetChanged();
    }


    public void SetOfflineTheme(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    public void getOfflineTheme(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }

    public void rePlayAudio(final int n, final boolean b) {
        if (b) {
            this.stopPlaying(mediaPlayer);
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.reset();
                mediaPlayer.setDataSource(Utils.INSTANCE.getMusicFolderPath() + File.separator + songModelArrayList.get(n).getSongUrl());
//                FinalMusicPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(n).getSongUrl();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.prepareAsync();
            return;
        }
    }


    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    @SuppressLint("StaticFieldLeak")
    public class GetThemeData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlloadingpager.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(arg0[0]);
            if (jsonStr != null) {
                System.out.println("success");
            } else {
                System.out.println("failed");
            }

            return jsonStr;

        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObj = new JSONObject();
                if (IsofflineResopnse) {
                    String id = pref.getString(CatId, null);
                    if (id != null && !id.equals("")) {
                        getOfflineTheme(getActivity(), CatId);
                        jsonObj = new JSONObject(offlienResopnseData);
                    } else {
//                            llInternetCheck.setVisibility(View.VISIBLE);
                    }
                } else {
                    jsonObj = new JSONObject(result);
                    if (getActivity() != null) {
                        SetOfflineTheme(getActivity(), jsonObj.toString(), CatId);
                    }
                }
                JSONArray jsonArray = jsonObj.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject songJSONObject = jsonArray.getJSONObject(i);
                    OnlineSongModel songModel = new OnlineSongModel();
                    songModel.setId(i);
                    songModel.setSongId(songJSONObject.getString("Sound_Id"));
                    songModel.setSongCategoryId(songJSONObject.getString("Sound_Category_Id"));
                    songModel.setSongName(songJSONObject.getString("Sound_Name"));
                    songModel.setSongUrl(songJSONObject.getString("Sound_Name") + ".mp3");
                    songModel.setSongfull_url(songJSONObject.getString("Sound_full_url"));
                    songModel.setSongSize(songJSONObject.getString("Sound_Size"));
                    songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("Sound_Name") + ".mp3");
                    songModelArrayList.add(songModel);
                }
                onlineSongAdapter.notifyDataSetChanged();
                rlloadingpager.setVisibility(View.GONE);

            } catch (final JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
