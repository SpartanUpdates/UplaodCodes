package com.kotlinz.videoCollage.interfaces;

public interface BGColorAdapterCallBackInterface {
    void itemClick(int i);
}
