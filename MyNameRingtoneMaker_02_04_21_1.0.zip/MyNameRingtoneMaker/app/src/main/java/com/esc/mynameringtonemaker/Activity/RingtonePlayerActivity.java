package com.esc.mynameringtonemaker.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.MediaStore.Audio.Media;
import android.provider.Settings;
import android.provider.Settings.System;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.mynameringtonemaker.Common.Methods;
import com.esc.mynameringtonemaker.Common.ToneType;
import com.esc.mynameringtonemaker.Model.RingtoneModel;
import com.esc.mynameringtonemaker.R;
import com.esc.mynameringtonemaker.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class RingtonePlayerActivity extends AppCompatActivity implements OnClickListener {
    private Activity activity = RingtonePlayerActivity.this;
    private Button btnDownload;
    private Button btnSetAsAlarmTone;
    private Button btnSetAsRingtone;
    private Button btnSetAsSmsTone;
    private Handler handler = new Handler();
    private ImageView imgNext;
    private ImageView imgPlayPause;
    private ImageView imgPrevious;
    private ArrayList<RingtoneModel> list = new ArrayList();
    private MediaPlayer mediaPlayer;
    private ProgressDialog progressDialog;
    private Runnable runnable;
    private SeekBar seekBar;
    private int selectedPos;
    private int totalDuration;
    private TextView tvName;
    private TextView tvTimeLeft;
    private TextView tvTimeRight;
    private String name;
    private ImageView iv_back;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_ringtone_player);

        this.list = (ArrayList) getIntent().getSerializableExtra("list");
        this.selectedPos = getIntent().getExtras().getInt("selectedPos");

        loadAd();
        BannerAds();

        tvName = findViewById(R.id.tvName);
        seekBar = findViewById(R.id.seekBar);
        tvTimeLeft = findViewById(R.id.tvTimeLeft);
        tvTimeRight = findViewById(R.id.tvTimeRight);
        imgPrevious = findViewById(R.id.imgPrevious);
        imgPlayPause = findViewById(R.id.imgPlayPause);
        imgNext = findViewById(R.id.imgNext);
        btnDownload = findViewById(R.id.btn_Download);
        btnSetAsRingtone = findViewById(R.id.btn_SetAsRingtone);
        btnSetAsSmsTone = findViewById(R.id.btn_SetAsSmsTone);
        btnSetAsAlarmTone = findViewById(R.id.btn_SetAsAlarmTone);
        iv_back = findViewById(R.id.iv_back);
        if (this.list.size() == 1) {
            this.imgPrevious.setVisibility(View.GONE);
            this.imgNext.setVisibility(View.GONE);
        }
        new Handler().postDelayed(new Runnable() {
            public void run() {
                RingtonePlayerActivity.this.setMediaPlayer();
            }
        }, 100);
        imgPlayPause.setOnClickListener(this);
        btnDownload.setOnClickListener(this);
        btnSetAsRingtone.setOnClickListener(this);
        btnSetAsSmsTone.setOnClickListener(this);
        btnSetAsAlarmTone.setOnClickListener(this);
        imgNext.setOnClickListener(this);
        imgPrevious.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    public void setMediaPlayer() {
        this.tvName.setText(this.list.get(this.selectedPos).getName().replace("%20", " "));
        this.seekBar.setProgress(0);
        this.seekBar.setMax(99);
        this.seekBar.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (RingtonePlayerActivity.this.mediaPlayer.isPlaying()) {
                    RingtonePlayerActivity.this.mediaPlayer.seekTo((RingtonePlayerActivity.this.totalDuration / 100) * ((SeekBar) view).getProgress());
                }
                return false;
            }
        });
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.stop();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        this.handler.removeCallbacks(this.runnable);
        mediaPlayer = new MediaPlayer();
        this.mediaPlayer = mediaPlayer;
        try {
            mediaPlayer.setDataSource(this.list.get(this.selectedPos).getMp3Url());
            this.mediaPlayer.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.imgPlayPause.setImageResource(R.drawable.ic_pause);
        this.totalDuration = this.mediaPlayer.getDuration();
        this.tvTimeLeft.setText("00:00");
        this.tvTimeRight.setText(String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(this.totalDuration)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(this.totalDuration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(this.totalDuration)))));
        this.mediaPlayer.setOnBufferingUpdateListener(new OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {
                RingtonePlayerActivity.this.seekBar.setSecondaryProgress(i);
            }
        });
        this.mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (RingtonePlayerActivity.this.selectedPos == RingtonePlayerActivity.this.list.size() - 1) {
                    RingtonePlayerActivity.this.selectedPos = 0;
                } else {
                    RingtonePlayerActivity.this.selectedPos = RingtonePlayerActivity.this.selectedPos + 1;
                }
                RingtonePlayerActivity.this.setMediaPlayer();
            }
        });
        this.mediaPlayer.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                RingtonePlayerActivity.this.imgPlayPause.performClick();
            }
        });
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_Download:
                downloadringtone();
                break;
            case R.id.btn_SetAsAlarmTone:
                setToneAs(ToneType.ALARM_TONE);
                break;
            case R.id.btn_SetAsRingtone:
                setToneAs(ToneType.RINGTONE);
                break;
            case R.id.btn_SetAsSmsTone:
                setToneAs(ToneType.SMS_TONE);
                break;
            case R.id.imgNext:
                if (this.selectedPos == this.list.size() - 1) {
                    this.selectedPos = 0;
                } else {
                    this.selectedPos++;
                }
                setMediaPlayer();
                break;
            case R.id.imgPlayPause:
                if (this.mediaPlayer.isPlaying()) {
                    this.mediaPlayer.pause();
                    this.imgPlayPause.setImageResource(R.drawable.ic_play);
                } else {
                    this.mediaPlayer.start();
                    this.imgPlayPause.setImageResource(R.drawable.ic_pause);
                }
                seekBarProgressUpdater();
                break;
            case R.id.imgPrevious:
                if (selectedPos == 0) {
                    this.selectedPos = this.list.size() - 1;
                } else {
                    this.selectedPos = selectedPos - 1;
                }
                setMediaPlayer();
                break;
            case R.id.iv_back:
                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    onBackPressed();
                }
            default:
                break;
        }
    }

    private void downloadringtone() {
        name = this.list.get(this.selectedPos).getName();
        String str = ".mp3";
        if (!name.endsWith(str)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.list.get(this.selectedPos).getName());
            stringBuilder.append(str);
            name = stringBuilder.toString();
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(Methods.getDirectory("Ringtone"));
        stringBuilder2.append(name);
        if (new File(stringBuilder2.toString()).exists()) {
            Toast.makeText(this, "Ringtone already downloaded.", Toast.LENGTH_LONG).show();
            return;
        }
        ProgressDialog dialog = new ProgressDialog(RingtonePlayerActivity.this, R.style.MyProgressDialog) {
            public void onCreate(Bundle bundle) {
                super.onCreate(bundle);
                setContentView(R.layout.layout_dialog_download);
                getWindow().setLayout(-1, -1);
                final TextView textView = RingtonePlayerActivity.this.progressDialog.findViewById(R.id.tvPercentage);
                Methods.download(RingtonePlayerActivity.this, RingtonePlayerActivity.this.list.get(RingtonePlayerActivity.this.selectedPos).getMp3Url(), Methods.getDirectory("Ringtone"), name, new Methods.DownloadListener() {
                    public void onProgress(long j) {
                        TextView txtpercentage = textView;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Downloading ");
                        stringBuilder.append(j);
                        stringBuilder.append("%");
                        txtpercentage.setText(stringBuilder.toString());
                    }

                    public void onComplete() {
                        RingtonePlayerActivity.this.progressDialog.dismiss();
                        Activity access$700 = RingtonePlayerActivity.this;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Ringtone downloaded...\n");
                        stringBuilder.append(Methods.getDirectory("Ringtone"));
                        stringBuilder.append(name);
                        Toast.makeText(access$700, stringBuilder.toString(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        };
        this.progressDialog = dialog;
        dialog.setCancelable(false);
        this.progressDialog.show();
    }

    public void seekBarProgressUpdater() {
        this.seekBar.setProgress((int) ((((float) this.mediaPlayer.getCurrentPosition()) / ((float) this.totalDuration)) * 100.0f));
        this.tvTimeLeft.setText(String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(this.mediaPlayer.getCurrentPosition())), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(this.mediaPlayer.getCurrentPosition()) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(this.mediaPlayer.getCurrentPosition())))));
        if (this.mediaPlayer.isPlaying()) {
            Runnable runnable = new Runnable() {
                public void run() {
                    RingtonePlayerActivity.this.seekBarProgressUpdater();
                }
            };
            this.runnable = runnable;
            this.handler.postDelayed(runnable, 10);
        }
    }

    public void setToneAs(ToneType toneType) {
        if (VERSION.SDK_INT < 23) {
            return;
        }
        StringBuilder stringBuilder;
        if (System.canWrite(this)) {
            String name = ((RingtoneModel) this.list.get(this.selectedPos)).getName();
            String str = ".mp3";
            if (!name.endsWith(str)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(this.list.get(this.selectedPos).getName());
                stringBuilder.append(str);
                name = stringBuilder.toString();
            }
            final String str2 = name;
            stringBuilder = new StringBuilder();
            stringBuilder.append(Methods.getDirectory("Ringtone"));
            stringBuilder.append(str2);
            final File file = new File(stringBuilder.toString());
            if (file.exists()) {
                afterFileCheck(file, toneType);
                return;
            }
            final ToneType toneType2 = toneType;
            ProgressDialog dialog = new ProgressDialog(this, R.style.MyProgressDialog) {
                public void onCreate(Bundle bundle) {
                    super.onCreate(bundle);
                    setContentView(R.layout.layout_dialog_download);
                    getWindow().setLayout(-1, -1);
                    final TextView textView = RingtonePlayerActivity.this.progressDialog.findViewById(R.id.tvPercentage);
                    Methods.download(RingtonePlayerActivity.this, RingtonePlayerActivity.this.list.get(RingtonePlayerActivity.this.selectedPos).getMp3Url(), Methods.getDirectory("Ringtone"), str2, new Methods.DownloadListener() {
                        public void onProgress(long j) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Downloading ");
                            stringBuilder.append(j);
                            stringBuilder.append("%");
                            textView.setText(stringBuilder.toString());
                        }

                        public void onComplete() {
                            RingtonePlayerActivity.this.progressDialog.dismiss();
                            RingtonePlayerActivity.this.afterFileCheck(file, toneType2);
                        }
                    });
                }
            };
            this.progressDialog = dialog;
            dialog.setCancelable(false);
            this.progressDialog.show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
        stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(getPackageName());
        intent.setData(Uri.parse(stringBuilder.toString()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    public void afterFileCheck(File file, ToneType toneType) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
        contentValues.put(MediaStore.MediaColumns.TITLE, "ringtone");
        contentValues.put(MediaStore.MediaColumns.SIZE, Long.valueOf(file.length()));
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp3");
        contentValues.put(MediaStore.Audio.Media.ARTIST, getResources().getString(R.string.app_name));
        ToneType toneType2 = ToneType.RINGTONE;
        String str = "is_music";
        String str2 = "is_alarm";
        String str3 = "is_notification";
        String str4 = "is_ringtone";
        Boolean valueOf = Boolean.valueOf(true);
        Boolean valueOf2 = Boolean.valueOf(false);
        if (toneType == toneType2) {
            contentValues.put(str4, valueOf);
            contentValues.put(str3, valueOf2);
            contentValues.put(str2, valueOf2);
            contentValues.put(str, valueOf2);
        } else if (toneType == ToneType.SMS_TONE) {
            contentValues.put(str4, valueOf2);
            contentValues.put(str3, valueOf);
            contentValues.put(str2, valueOf2);
            contentValues.put(str, valueOf2);
        } else if (toneType == ToneType.ALARM_TONE) {
            contentValues.put(str4, valueOf2);
            contentValues.put(str3, valueOf2);
            contentValues.put(str2, valueOf);
            contentValues.put(str, valueOf2);
        }
        try {
            Uri contentUriForPath = Media.getContentUriForPath(file.getAbsolutePath());
            Uri insert = getContentResolver().insert(contentUriForPath, contentValues);
            if (toneType == ToneType.RINGTONE) {
                RingtoneManager.setActualDefaultRingtoneUri(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, insert);
            } else if (toneType == ToneType.SMS_TONE) {
                RingtoneManager.setActualDefaultRingtoneUri(getApplicationContext(), RingtoneManager.TYPE_NOTIFICATION, insert);
            } else if (toneType == ToneType.ALARM_TONE) {
                RingtoneManager.setActualDefaultRingtoneUri(getApplicationContext(), RingtoneManager.TYPE_ALARM, insert);
            }
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(toneType);
            stringBuilder3.append(" set successfully.");
            Toast.makeText(this, stringBuilder3.toString(), Toast.LENGTH_SHORT).show();
        }catch (Exception e)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error");
            stringBuilder.append(e.getMessage());
        }
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(RingtonePlayerActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        onBackPressed();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onDestroy() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.stop();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        this.handler.removeCallbacks(this.runnable);

        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            this.mediaPlayer.stop();
            this.mediaPlayer.release();
            this.mediaPlayer = null;
        }
        this.handler.removeCallbacks(this.runnable);
        super.onBackPressed();
    }
}