package com.esc.storymaker;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.esc.storymaker.help.ConnectionDetector;

public class LaunchScreenActivity extends AppCompatActivity {
    public static final String mypreference = "myprefadmob";
    ConnectionDetector cd;
    boolean isInternetPresent;
    SharedPreferences sharedpreferences;

    private class BackgroundTask extends AsyncTask<String, String, String> {
        long SPLASH_TIME;

        private BackgroundTask() {
            this.SPLASH_TIME = 3000;
        }


        public void onPreExecute() {
            super.onPreExecute();
        }


        public String doInBackground(String... strArr) {
            try {
                Thread.sleep(this.SPLASH_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }


        public void onPostExecute(String str) {
            super.onPostExecute(str);
            LaunchScreenActivity launchScreenActivity = LaunchScreenActivity.this;
            launchScreenActivity.startActivity(new Intent(launchScreenActivity, MainActivity.class));
            LaunchScreenActivity.this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            LaunchScreenActivity.this.finish();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_launch_screen);
        this.sharedpreferences = getSharedPreferences("myprefadmob", 0);
        this.cd = new ConnectionDetector(getApplicationContext());
        this.isInternetPresent = this.cd.isConnectingToInternet();
        if (this.isInternetPresent) {
            new BackgroundTask().execute(new String[0]);
        } else {
            new BackgroundTask().execute(new String[0]);
        }
    }
}
