package com.UnitedVideos.TextChange.Adapter;

import android.view.View;
import android.widget.EditText;
import androidx.recyclerview.widget.RecyclerView;
import com.wavymusic.R;


public class TextHolderUv extends RecyclerView.ViewHolder {
    public EditText a;

    public TextHolderUv(View view) {
        super(view);
        this.a = (EditText) view.findViewById(R.id.et_row_single);
    }

}