package com.esc.tarotcardreading;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public final class Util {
    public static String encodePostBody(Bundle bundle, String str) {
        if (bundle == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (String str2 : bundle.keySet()) {
            if (bundle.getByteArray(str2) == null) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Content-Disposition: form-data; name=\"");
                stringBuilder2.append(str2);
                stringBuilder2.append("\"\r\n\r\n");
                stringBuilder2.append(bundle.getString(str2));
                stringBuilder.append(stringBuilder2.toString());
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("\r\n--");
                stringBuilder3.append(str);
                stringBuilder3.append("\r\n");
                stringBuilder.append(stringBuilder3.toString());
            }
        }
        return stringBuilder.toString();
    }

    public static String encodeUrl(Bundle bundle) {
        if (bundle == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        Object obj = 1;
        for (String str : bundle.keySet()) {
            if (obj != null) {
                obj = null;
            } else {
                stringBuilder.append("&");
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(URLEncoder.encode(str));
            stringBuilder2.append("=");
            stringBuilder2.append(URLEncoder.encode(bundle.getString(str)));
            stringBuilder.append(stringBuilder2.toString());
        }
        return stringBuilder.toString();
    }

    public static Bundle decodeUrl(String str) {
        Bundle bundle = new Bundle();
        if (str != null) {
            for (String split : str.split("&")) {
                String[] split2 = split.split("=");
                bundle.putString(URLDecoder.decode(split2[0]), URLDecoder.decode(split2[1]));
            }
        }
        return bundle;
    }

    public static Bundle parseUrl(String str) {
        try {
            URL url = new URL(str.replace("fbconnect", "http"));
            Bundle decodeUrl = decodeUrl(url.getQuery());
            decodeUrl.putAll(decodeUrl(url.getRef()));
            return decodeUrl;
        } catch (MalformedURLException unused) {
            return new Bundle();
        }
    }

    public static String openUrl(String str, String str2, Bundle bundle) throws MalformedURLException, IOException {
        StringBuilder stringBuilder;
        String str3 = "GET";
        if (str2.equals(str3)) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("?");
            stringBuilder.append(encodeUrl(bundle));
            str = stringBuilder.toString();
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(str2);
        stringBuilder.append(" URL: ");
        stringBuilder.append(str);
        Log.d("Facebook-Util", stringBuilder.toString());
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
        stringBuilder = new StringBuilder();
        stringBuilder.append(System.getProperties().getProperty("http.agent"));
        stringBuilder.append(" FacebookAndroidSDK");
        httpURLConnection.setRequestProperty("User-Agent", stringBuilder.toString());
        if (!str2.equals(str3)) {
            Bundle bundle2 = new Bundle();
            for (String str4 : bundle.keySet()) {
                if (bundle.getByteArray(str4) != null) {
                    bundle2.putByteArray(str4, bundle.getByteArray(str4));
                }
            }
            String str5 = "method";
            if (!bundle.containsKey(str5)) {
                bundle.putString(str5, str2);
            }
            if (bundle.containsKey(str2)) {
                bundle.putString(str2, URLDecoder.decode(bundle.getString(str2)));
            }
            httpURLConnection.setRequestMethod("POST");
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("multipart/form-data;boundary=");
            str5 = "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f";
            stringBuilder2.append(str5);
            httpURLConnection.setRequestProperty("Content-Type", stringBuilder2.toString());
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
            httpURLConnection.connect();
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
            StringBuilder stringBuilder3 = new StringBuilder();
            String str6 = "--";
            stringBuilder3.append(str6);
            stringBuilder3.append(str5);
            String str7 = "\r\n";
            stringBuilder3.append(str7);
            bufferedOutputStream.write(stringBuilder3.toString().getBytes());
            bufferedOutputStream.write(encodePostBody(bundle, str5).getBytes());
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append(str7);
            stringBuilder4.append(str6);
            stringBuilder4.append(str5);
            stringBuilder4.append(str7);
            bufferedOutputStream.write(stringBuilder4.toString().getBytes());
            if (!bundle2.isEmpty()) {
                for (String str42 : bundle2.keySet()) {
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append("Content-Disposition: form-data; filename=\"");
                    stringBuilder5.append(str42);
                    stringBuilder5.append("\"");
                    stringBuilder5.append(str7);
                    bufferedOutputStream.write(stringBuilder5.toString().getBytes());
                    stringBuilder5 = new StringBuilder();
                    stringBuilder5.append("Content-Type: content/unknown");
                    stringBuilder5.append(str7);
                    stringBuilder5.append(str7);
                    bufferedOutputStream.write(stringBuilder5.toString().getBytes());
                    bufferedOutputStream.write(bundle2.getByteArray(str42));
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(str7);
                    stringBuilder3.append(str6);
                    stringBuilder3.append(str5);
                    stringBuilder3.append(str7);
                    bufferedOutputStream.write(stringBuilder3.toString().getBytes());
                }
            }
            bufferedOutputStream.flush();
        }
        try {
            str2 = read((httpURLConnection).getInputStream());
            return str2;
        }
        catch (FileNotFoundException ex) {
            return read((httpURLConnection).getErrorStream());
        }
    }


    private static String read(InputStream inputStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream), 1000);
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine != null) {
                stringBuilder.append(readLine);
            } else {
                inputStream.close();
                return stringBuilder.toString();
            }
        }
    }

    public static void clearCookies(Context context) {
        CookieSyncManager.createInstance(context);
        CookieManager.getInstance().removeAllCookie();
    }



    public static void showAlert(Context context, String str, String str2) {
        Builder builder = new Builder(context);
        builder.setTitle(str);
        builder.setMessage(str2);
        builder.create().show();
    }
}
