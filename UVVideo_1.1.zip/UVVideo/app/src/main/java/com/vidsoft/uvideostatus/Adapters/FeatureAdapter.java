package com.vidsoft.uvideostatus.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeAdsManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.vidsoft.uvideostatus.Fragments.FeatureFragment;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.FontTextView;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.wang.avi.AVLoadingIndicatorView;

import cz.msebera.android.httpclient.util.ByteArrayBuffer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class FeatureAdapter extends Adapter<RecyclerView.ViewHolder> {
    Activity context;
    public FeatureFragment featureFragment;
    File file;
    public String imgPath;
    private boolean isLoading;
    private boolean loading;
    String title;
    VideoData vddta;
    public ArrayList<VideoData> videoDatalist = new ArrayList<>();
    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    private NativeAdsManager mAdsManager;

    public static class NativeAdViewHolder extends RecyclerView.ViewHolder {
        LinearLayout nativeAdContainer;

        NativeAdViewHolder(@NonNull View itemView) {
            super(itemView);
            nativeAdContainer = itemView.findViewById(R.id.adContainer);
        }
    }


    private class ImageDownloadAndSave extends AsyncTask<String, Void, Bitmap> {
        private ImageDownloadAndSave() {
        }

        public void onPreExecute() {
            FeatureFragment.loader.setVisibility(View.VISIBLE);
            FeatureFragment.lottie_download.setVisibility(View.VISIBLE);
            super.onPreExecute();
            Toast.makeText(FeatureAdapter.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public Bitmap doInBackground(String... strArr) {
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            downloadImagesToSdCard(str, sb.toString());
            return null;
        }

        public void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            Log.d("TAG", "onPostExecute: ");
            FeatureFragment.lottie_download.setVisibility(View.GONE);
            FeatureFragment.loottiedone.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    FeatureFragment.loottiedone.setVisibility(View.GONE);
                }
            }, 300);
            FeatureAdapter.this.shareMultiplePhotos();
        }

        private void downloadImagesToSdCard(String str, String str2) {
            String str3 = "/";
            FeatureAdapter.this.imgPath = str;
            FeatureAdapter featureAdapter = FeatureAdapter.this;
            featureAdapter.title = str2;
            try {
                URL url = new URL(featureAdapter.imgPath);
                StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append(str3);
                sb.append(FeatureAdapter.this.context.getString(R.string.app_name));
                File file = new File(sb.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                String[] split = FeatureAdapter.this.imgPath.split(Pattern.quote(str3));
                StringBuilder sb2 = new StringBuilder();
                sb2.append("captureImage: ");
                sb2.append(FeatureAdapter.this.imgPath);
                sb2.append("    ");
                sb2.append(split[split.length - 1]);
                Log.d("TAG", sb2.toString());
                FeatureAdapter.this.file = new File(file.getAbsolutePath(), split[split.length - 1]);
                if (!FeatureAdapter.this.file.exists()) {
                    URLConnection openConnection = url.openConnection();
                    InputStream inputStream = null;
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode() == 200) {
                        inputStream = httpURLConnection.getInputStream();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(FeatureAdapter.this.file);
                    int contentLength = httpURLConnection.getContentLength();
                    byte[] bArr = new byte[1024];
                    int i = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        i += read;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("downloadedSize:");
                        sb3.append(i);
                        sb3.append("totalSize:");
                        sb3.append(contentLength);
                        Log.i("Progress:", sb3.toString());
                    }
                    fileOutputStream.close();
                }
                Log.d("test", "Image Saved in sdcard..");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    class ProgressBack extends AsyncTask<String, String, String> {
        public ProgressBack() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            FeatureFragment.loader.setVisibility(View.VISIBLE);
            FeatureFragment.lottie_download.setVisibility(View.VISIBLE);
            Toast.makeText(FeatureAdapter.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public String doInBackground(String... strArr) {
            FeatureAdapter featureAdapter = FeatureAdapter.this;
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            featureAdapter.DownloadFile(str, sb.toString());
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(str);
            FeatureFragment.lottie_download.setVisibility(View.GONE);
            FeatureFragment.loottiedone.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    FeatureFragment.loottiedone.setVisibility(View.GONE);
                }
            }, 200);
            Toast.makeText(FeatureAdapter.this.context, "Downloaded Sucessfully", Toast.LENGTH_LONG).show();
        }
    }

    public static class ProgressViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public AVLoadingIndicatorView progressBar;

        public ProgressViewHolder(View view) {
            super(view);
            this.progressBar = view.findViewById(R.id.progressBar1);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public ImageView idIvVideoOption;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.idIvVideoOption = view.findViewById(R.id.idIvVideoOption);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = view.findViewById(R.id.tvVideoListingDuration);
            this.duration = view.findViewById(R.id.duration);
            this.icon_like_main = view.findViewById(R.id.icon_like_main);
            this.icon_like = view.findViewById(R.id.icon_like);
            this.icon_like_main.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ViewHolder.this.icon_like_main.setVisibility(View.GONE);
                    ViewHolder.this.icon_like.setVisibility(View.VISIBLE);
                    ViewHolder.this.icon_like.playAnimation();
                    ViewHolder.this.icon_like.loop(false);
                }
            });
            this.idIvVideoOption.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FeatureAdapter.this.showVideoOption(FeatureAdapter.this.videoDatalist.get(ViewHolder.this.getAdapterPosition()), ViewHolder.this.idIvVideoOption);
                }
            });
        }
    }

    public FeatureAdapter(Activity activity, ArrayList<VideoData> arrayList, FeatureFragment featureFragment2) {
        this.featureFragment = featureFragment2;
        this.context = activity;
        this.videoDatalist = arrayList;
        mAdsManager = featureFragment.mAdsManager;
        notifyDataSetChanged();
        this.isLoading = false;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        if (viewType == ITEM_TYPE_AD) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.nativead_layout, viewGroup, false);
            return new NativeAdViewHolder(v);
        } else {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.multi_item, viewGroup, false);
            return new ViewHolder(v);
        }
    }

    public void onBindViewHolder(final androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, final int i) {
        if (getItemViewType(i) == ITEM_TYPE_AD) {
            final CatogoryAdapter.NativeAdViewHolder nativeviewHolder = (CatogoryAdapter.NativeAdViewHolder) viewHolder;
            View mNativeView;
            this.vddta = this.videoDatalist.get(i);
            if (vddta.IsNativeAds) {
                NativeAd nextNativeAd = mAdsManager.nextNativeAd();
                if (nextNativeAd != null) {
                    nativeviewHolder.nativeAdContainer.removeAllViews();
                    mNativeView = NativeAdView.render(context, nextNativeAd, NativeAdView.Type.HEIGHT_300);
                    nativeviewHolder.nativeAdContainer.addView(mNativeView);
                }
            }
        } else {
            if (viewHolder instanceof ViewHolder) {
                this.vddta = this.videoDatalist.get(i);
                ViewHolder viewHolder2 = (ViewHolder) viewHolder;
                viewHolder2.tvVideoListingName.setText(this.vddta.getTitle());
                viewHolder2.tvVideoListingSize.setText(this.vddta.getLikes());
                FontTextView fontTextView = viewHolder2.tvVideoListingDuration;
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(Utility.getViews(Double.parseDouble(vddta.getViews())));
//            Log.e("getView",""+videoData.getViews());
                    stringBuilder.append(" views");
                    fontTextView.setText(stringBuilder.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                viewHolder2.llVideoList.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        FeatureAdapter.this.featureFragment.playVideo(FeatureAdapter.this.videoDatalist.get(i));
                    }
                });
                RequestOptions requestOptions = new RequestOptions();
                requestOptions.placeholder(R.drawable.video_placeholder);
                requestOptions.error(R.drawable.video_placeholder);
                requestOptions.override(Callback.DEFAULT_SWIPE_ANIMATION_DURATION, Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
                Glide.with(this.context).load(this.vddta.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
            }
        }
    }

    public void showVideoOption(final VideoData videoData, ImageView imageView) {
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.bottomsheet_video_option, null);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this.context);
        bottomSheetDialog.setContentView(inflate);
        TextView textView = bottomSheetDialog.findViewById(R.id.videoOption_Download);
        TextView textView2 = bottomSheetDialog.findViewById(R.id.videoOption_Details);
        bottomSheetDialog.findViewById(R.id.videoOption_Share).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ImageDownloadAndSave().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ProgressBack().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(FeatureAdapter.this.context);
                @SuppressLint("WrongConstant") View inflate = ((LayoutInflater) FeatureAdapter.this.context.getSystemService("layout_inflater")).inflate(R.layout.dialog_report, null);
                builder.setView(inflate);
                Button button = inflate.findViewById(R.id.btn_report);
                Button button2 = inflate.findViewById(R.id.btn_cancel);
                final AlertDialog create = builder.create();
                button2.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        create.cancel();
                    }
                });
                button.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        Toast.makeText(FeatureAdapter.this.context, "Thanks for reporting", Toast.LENGTH_LONG).show();
                        create.cancel();
                    }
                });
                create.show();
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.show();
    }

    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        this.videoDatalist = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        sb.append("addAll12346: ");
        sb.append(this.videoDatalist.size());
        Log.d("TAG", sb.toString());
        int i = 4;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 10;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.videoDatalist.add(videoData);
                this.videoDatalist.add(list.get(i2));
            } else {
                this.videoDatalist.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("getItemCount: ");
        sb.append(this.videoDatalist.size());
        Log.d("TAG", sb.toString());
        return this.videoDatalist.size();
    }

    public int getItemViewType(int i) {
        if ((i > 0) && ((i + 1) % 3 == 0) && mAdsManager.isLoaded()) {
            return ITEM_TYPE_AD;
        }
        return ITEM_TYPE_DATA;
//        return this.videoDatalist.get(i).getType();
    }

    public void DownloadFile(String str, String str2) {
        try {
            String replace = str.replace(" ", "%20");
            StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStorageDirectory());
            sb.append("/Video_player");
            File file2 = new File(sb.toString());
            if (!file2.exists()) {
                file2.mkdirs();
            }
            URL url = new URL(replace);
            File file3 = new File(file2, str2);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(url.openConnection().getInputStream());
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(20000);
            while (true) {
                int read = bufferedInputStream.read();
                if (read != -1) {
                    byteArrayBuffer.append((byte) read);
                } else {
                    FileOutputStream fileOutputStream = new FileOutputStream(file3);
                    fileOutputStream.write(byteArrayBuffer.toByteArray());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void shareMultiplePhotos() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.SUBJECT", "Share");
        Activity activity = this.context;
        StringBuilder sb = new StringBuilder();
        sb.append(this.context.getApplicationContext().getPackageName());
        sb.append(".provider");
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(activity, sb.toString(), this.file));
        this.context.startActivity(Intent.createChooser(intent, "Select"));
    }
}
