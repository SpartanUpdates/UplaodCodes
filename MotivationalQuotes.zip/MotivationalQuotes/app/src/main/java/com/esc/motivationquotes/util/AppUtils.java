package com.esc.motivationquotes.util;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import com.esc.motivationquotes.model.Pref;
import com.esc.motivationquotes.util.Constants;

public class AppUtils {
    public static void hasSoftKeys(Activity activity) {
        Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            defaultDisplay.getRealMetrics(displayMetrics);
        }
        int i = displayMetrics.heightPixels;
        int i2 = displayMetrics.widthPixels;
        DisplayMetrics displayMetrics2 = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics2);
        Object obj = (i2 - displayMetrics2.widthPixels > 0 || i - displayMetrics2.heightPixels > 0) ? 1 : null;
        if (obj != null) {
            Pref.setValue((Context) activity, Constants.PREF_SOFT_KEYS, "1");
        } else {
            Pref.setValue((Context) activity, Constants.PREF_SOFT_KEYS, "0");
        }
    }

    public static float convertDpToPixel(float f, Context context) {
        return f * (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }
}
