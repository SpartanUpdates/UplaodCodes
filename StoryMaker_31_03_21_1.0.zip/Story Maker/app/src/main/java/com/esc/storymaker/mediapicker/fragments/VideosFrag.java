package com.esc.storymaker.mediapicker.fragments;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore.Video.Media;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnItemTouchListener;

import com.esc.storymaker.R;
import com.esc.storymaker.mediapicker.Gallery;
import com.esc.storymaker.mediapicker.adapters.FoldersAdapter;
import com.esc.storymaker.mediapicker.utils.ClickListener;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class VideosFrag extends Fragment {
    public static List<Boolean> selected = new ArrayList();
    public static List<String> videosList = new ArrayList();
    private List<String> bitmapList = new ArrayList();
    private List<String> bucketNames = new ArrayList();
    private FoldersAdapter mAdapter;
    private final String[] projection;
    private final String[] projection2;
    private View rootView;
    private RecyclerView rvVideos;

    public static class RecyclerTouchListener implements OnItemTouchListener {
        private ClickListener clickListener;
        private GestureDetector gestureDetector;

        public void onRequestDisallowInterceptTouchEvent(boolean z) {
        }

        public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
        }

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            this.gestureDetector = new GestureDetector(context, new SimpleOnGestureListener() {
                public boolean onSingleTapUp(MotionEvent motionEvent) {
                    return true;
                }

                public void onLongPress(MotionEvent motionEvent) {
                    View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
                    if (findChildViewUnder != null) {
                        if (clickListener != null) {
                            clickListener.onLongClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
                        }
                    }
                }
            });
        }

        public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {
            View findChildViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
            if (!(findChildViewUnder == null || this.clickListener == null || !this.gestureDetector.onTouchEvent(motionEvent))) {
                this.clickListener.onClick(findChildViewUnder, recyclerView.getChildPosition(findChildViewUnder));
            }
            return false;
        }
    }

    public VideosFrag() {
        String[] strArr = new String[2];
        strArr[0] = "bucket_display_name";
        strArr[1] = "_data";
        this.projection = strArr;
        this.projection2 = new String[]{"_display_name", "_data"};
    }

    public static VideosFrag getInstance() {
        return new VideosFrag();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.bucketNames.clear();
        this.bitmapList.clear();
        videosList.clear();
        getVideoBuckets();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_videos, viewGroup, false);
        this.rvVideos = (RecyclerView) this.rootView.findViewById(R.id.rv_videos);
        populateRecyclerView();
        return this.rootView;
    }

    private void populateRecyclerView() {
        this.mAdapter = new FoldersAdapter(getActivity(), this.bucketNames, this.bitmapList);
        this.rvVideos.setLayoutManager(new GridLayoutManager(getContext(), 3));
        this.rvVideos.setItemAnimator(new DefaultItemAnimator());
        this.rvVideos.setAdapter(this.mAdapter);
        this.rvVideos.addOnItemTouchListener(new RecyclerTouchListener(getContext(), this.rvVideos, new ClickListener() {
            public void onLongClick(View view, int i) {
            }

            public void onClick(View view, int i) {
                VideosFrag videosFrag = VideosFrag.this;
                videosFrag.getVideos((String) videosFrag.bucketNames.get(i));
                ((Gallery) VideosFrag.this.getActivity()).addFragment(GalleryDetailFrag.getInstance((String) VideosFrag.this.bucketNames.get(i), "Videos"));
            }
        }));
        this.mAdapter.notifyDataSetChanged();
    }

    public void getVideos(String str) {
        selected.clear();
        Cursor query = getContext().getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection2, "bucket_display_name =?", new String[]{str}, "date_added");
        ArrayList arrayList = new ArrayList(query.getCount());
        HashSet hashSet = new HashSet();
        if (query.moveToLast()) {
            while (!Thread.interrupted()) {
                String string = query.getString(query.getColumnIndex(this.projection2[1]));
                if (new File(string).exists() && !hashSet.contains(string)) {
                    arrayList.add(string);
                    hashSet.add(string);
                    selected.add(Boolean.valueOf(false));
                }
                if (!query.moveToPrevious()) {
                }
            }
            return;
        }
        query.close();
        videosList.clear();
        videosList.addAll(arrayList);
    }

    public void getVideoBuckets() {
        Cursor query = getContext().getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, null, null, "date_added");
        ArrayList arrayList = new ArrayList(query.getCount());
        ArrayList arrayList2 = new ArrayList(query.getCount());
        HashSet hashSet = new HashSet();
        if (query.moveToLast()) {
            while (!Thread.interrupted()) {
                String string = query.getString(query.getColumnIndex(this.projection[0]));
                String string2 = query.getString(query.getColumnIndex(this.projection[1]));
                if (new File(string2).exists() && !hashSet.contains(string)) {
                    arrayList.add(string);
                    arrayList2.add(string2);
                    hashSet.add(string);
                }
                if (!query.moveToPrevious()) {
                }
            }
            return;
        }
        query.close();
        this.bucketNames.clear();
        this.bitmapList.clear();
        this.bucketNames.addAll(arrayList);
        this.bitmapList.addAll(arrayList2);
    }
}
