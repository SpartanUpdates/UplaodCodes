package com.name.nameart.FavDesign;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.name.nameart.MyUtils.AppCommon;
import com.name.nameart.R;
import com.name.nameart.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;


public class HomeScreen extends AppCompatActivity {
    Activity activity = HomeScreen.this;
    LinearLayout homecreate;
    LinearLayout homecreation;
    LinearLayout homeprivcy;
    LinearLayout homerate;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private LinearLayout ll_ad_container;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.home_screen);

        interstitialAd();

        this.homecreate = (LinearLayout) findViewById(R.id.homecreate);
        this.homecreation = (LinearLayout) findViewById(R.id.homecreation);
        this.homeprivcy = (LinearLayout) findViewById(R.id.homeprivcy);
        this.homerate = (LinearLayout) findViewById(R.id.homerate);

        this.homecreate.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    HomeScreen.this.startActivity(new Intent(HomeScreen.this, NameScreen.class));
                    finish();
                }

            }
        });
        this.homecreation.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {


                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    HomeScreen.this.startActivity(new Intent(HomeScreen.this, SavedScreen.class));
                    finish();
                }
            }
        });
        this.homeprivcy.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String url = getResources().getString(R.string.privacy_policy);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        this.homerate.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    HomeScreen homeScreen = HomeScreen.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("market://details?id=");
                    stringBuilder.append(HomeScreen.this.getPackageName());
                    homeScreen.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(stringBuilder.toString())));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(HomeScreen.this, "unable to find market app", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        HomeScreen.this.startActivity(new Intent(HomeScreen.this, NameScreen.class));
                        break;
                    case 101:
                        HomeScreen.this.startActivity(new Intent(HomeScreen.this, SavedScreen.class));
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
