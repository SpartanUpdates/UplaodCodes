package com.kotlinz.videoCollage.interfaces;

public interface VideoAdapterCallBack {
    void onClick(int i, String str);
}
