package com.vidsoft.videostatusmaker.App;

import android.app.Application;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {

    private static MyApplication instance;

    public static int Variable_VIDEO_HEIGHT = 720;
    public static int Variable_VIDEO_WIDTH = 720;


    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        AudienceNetworkAds.initialize(this);
        AdSettings.addTestDevice("b7902a4f-ce3c-4d8a-abd8-1a9db86bc801");
    }
}
