package com.vidsoft.videostatusmaker.Utils.async;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import java.io.File;
import com.vidsoft.videostatusmaker.Activity.ActivityPreview;
import com.vidsoft.videostatusmaker.Utils.Utils;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

public class MusicAdd extends AsyncTask<Void, Void, Boolean> {
    String strStartVideo;
    String strInputFile;
    Context context;
    String strOutputPath;
    String strDuration;
    String strVideoEnd;
    String strAudioPathName;
    String strAuduiStart;
    String strFolder_path;



    public MusicAdd(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.context = context;
        this.strStartVideo = str;
        this.strDuration = str2;
        this.strInputFile = str3;
        this.strAuduiStart = str4;
        this.strAudioPathName = str5;
        this.strVideoEnd = str6;
        this.strOutputPath = str7;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory());
        stringBuilder.append("/");
        stringBuilder.append(context.getResources().getString(R.string.app_name));
        this.strFolder_path = stringBuilder.toString();
    }


    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected Boolean doInBackground(Void... voidArr) {
        File file = new File(this.strOutputPath);
        if (file.exists()) {
            file.delete();
        }
        final String inputFile = this.strInputFile;
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(this.strAuduiStart);
        final String string = sb.toString();
        final String audioPathName = this.strAudioPathName;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        sb2.append(this.strVideoEnd);
        final String string2 = sb2.toString();
        final String outputPath = this.strOutputPath;
        String[] SongAdd = new String[]{"-i", inputFile, "-ss", string, "-i", audioPathName, "-c:v", "copy", "-c:a", "aac", "-strict", "experimental", "-t", string2, outputPath};
        ExcuteFFmpeg(SongAdd);
        return Boolean.TRUE;
    }

    protected void onPostExecute(Boolean bool) {
        super.onPostExecute(bool);
    }


    void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }

    public void ExcuteFFmpeg(final String[] command) {
        FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(final long executionId, final int returnCode) {
                if (returnCode == RETURN_CODE_SUCCESS) {

                        Utils.video_url = strOutputPath;
                        Utils.complete = true;
                        ((ActivityPreview) context).setComplete(strOutputPath);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(strFolder_path);
                        stringBuilder.append("/");
                        stringBuilder.append(context.getString(R.string.temp_folder));
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    Log.e("TAG", "Async command execution cancelled by user.");
                } else {
                    Log.e("TAG", String.format("Async command execution failed with returnCode=%d.", returnCode));
                }
            }
        });
    }

}