package com.example.knowledgetrivia.models;

public class Report {
    public String comments;
    public String email;
    public int questionId;
    public String reason;

    public Report(int i, String str, String str2, String str3) {
        this.questionId = i;
        this.email = str;
        this.comments = str2;
        this.reason = str3;
    }
}
