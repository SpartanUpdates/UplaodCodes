package com.kotlinz.videoCollage.adpaters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.kotlinz.videoCollage.interfaces.SetOnAudioItemClickListener;
import com.kotlinz.videoCollage.models.AudioModel;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class AudioAdapter extends Adapter<AudioAdapter.viewHolder> {
    ArrayList<AudioModel> audioArrayList;
    Context context;
    public SetOnAudioItemClickListener listener;
    int pos = -1;

    public class viewHolder extends ViewHolder {
        TextView artist;
        ImageView cover,ic_music_unselect_round;
        RelativeLayout main;
        TextView title;

        public viewHolder(View view) {
            super(view);
            this.main = (RelativeLayout) view.findViewById(R.id.main_music);
            this.cover = (ImageView) view.findViewById(R.id.image_thumb);
            this.title = (TextView) view.findViewById(R.id.title);
            this.ic_music_unselect_round=view.findViewById(R.id.ic_music_unselect_round);
        }
    }

    public AudioAdapter(Context context, ArrayList<AudioModel> arrayList, SetOnAudioItemClickListener setOnAudioItemClickListener) {
        this.context = context;
        this.audioArrayList = arrayList;
        this.listener = setOnAudioItemClickListener;
    }

    public viewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new viewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_audio_list, viewGroup, false));
    }

    @SuppressLint("ResourceAsColor")
    public void onBindViewHolder(viewHolder viewholder, final int i) {
        viewholder.title.setText(((AudioModel) this.audioArrayList.get(i)).getTrack());
     //   ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(((AudioModel) this.audioArrayList.get(i)).getBitmap()).placeholder((int) R.drawable.ic_music_unselect)).error((int) R.drawable.ic_music_unselect)).into(viewholder.cover);
        viewholder.main.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (AudioAdapter.this.pos == i) {
                    AudioAdapter.this.listener.onItemClick(i, "pause");
                } else {
                    AudioAdapter.this.listener.onItemClick(i, "new");
                }
                AudioAdapter.this.pos = i;
                AudioAdapter.this.notifyDataSetChanged();
            }
        });
        viewholder.main.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                AudioAdapter.this.listener.onAddClick(i);
                pos = i;
                notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewholder.cover.setImageResource(R.drawable.ic_song_press);
            viewholder.title.setTextColor(context.getResources().getColor(R.color.white));
            viewholder.main.setBackgroundColor(this.context.getResources().getColor(R.color.gradint_center));
            viewholder.ic_music_unselect_round.setImageResource(R.drawable.ic_music_select_round);
        } else {
            viewholder.main.setBackgroundColor(this.context.getResources().getColor(R.color.colorWhite));
            viewholder.cover.setImageResource(R.drawable.ic_song_unpress);
            viewholder.title.setTextColor(context.getResources().getColor(R.color.gray));
            viewholder.ic_music_unselect_round.setImageResource(R.drawable.ic_music_unselect_round);
        }
    }

    public int getItemCount() {
        return this.audioArrayList.size();
    }
}
