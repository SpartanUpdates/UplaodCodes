package com.esc.socialmediacleaner.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.esc.socialmediacleaner.R;

import java.util.ArrayList;
import androidx.recyclerview.widget.RecyclerView;

public class HomeGridAdapter extends RecyclerView.Adapter<HomeGridAdapter.ViewHolder> {
    Context context;
    private ItemClickListener mClickListener;
    private ArrayList<String> mData;
    private LayoutInflater mInflater;

    public interface ItemClickListener {
        void onItemClick(View view, int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements OnClickListener {
        ImageView imageView;

        ViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.img_item);
            view.setOnClickListener(this);
        }

        public void onClick(View view) {
            if (HomeGridAdapter.this.mClickListener != null) {
                HomeGridAdapter.this.mClickListener.onItemClick(view, getAdapterPosition());
            }
        }
    }

    public HomeGridAdapter(Context context, ArrayList arrayList) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = arrayList;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this.mInflater.inflate(R.layout.home_grid_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        ((RequestBuilder) Glide.with(this.context).load((String) this.mData.get(i)).centerCrop()).into(viewHolder.imageView);
    }

    public int getItemCount() {
        return this.mData.size();
    }

    public String getItem(int i) {
        return (String) this.mData.get(i);
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }
}
