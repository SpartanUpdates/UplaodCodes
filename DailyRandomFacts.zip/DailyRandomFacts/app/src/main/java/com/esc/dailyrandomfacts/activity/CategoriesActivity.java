package com.esc.dailyrandomfacts.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;

import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.GridLayoutManager;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;
import com.esc.dailyrandomfacts.kprogresshud.KProgressHUD;
import com.esc.dailyrandomfacts.adapter.CategoriesAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.CategoryManager;
import com.esc.dailyrandomfacts.managers.FavoritesManager;
import com.esc.dailyrandomfacts.managers.OwnQuotesManager;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.model.Category;
import com.esc.dailyrandomfacts.model.Information;
import com.esc.dailyrandomfacts.model.Section;
import com.esc.dailyrandomfacts.receivers.NetworkChangeReceiver;
import com.esc.dailyrandomfacts.util.TrackerEventUtils;
import com.esc.dailyrandomfacts.adapter.CategoriesAdapter.RecyclerViewClickListener;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class CategoriesActivity extends BaseActivity implements RecyclerViewClickListener {
    private Category currentCategory;
    private ImageView iv_back;
    private View linearDivider;
    private ArrayList<Object> list = new ArrayList();
    private RecyclerView listCategories;
    private CategoriesAdapter mCategoriesAdapter;
    private NetworkChangeReceiver myReceiver;
    private NestedScrollView scroll;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_categories);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_CATEGORIES_VIEW, null, null);
        bindUi();
        setListeners();
        loadData();
        createNetworkChangeBroadcastReceiver();
        loadAd();
    }

    private void bindUi() {
        this.iv_back = findViewById(R.id.iv_back);
        this.listCategories = findViewById(R.id.recyclerView);
        this.linearDivider = findViewById(R.id.linearDivider);
        this.scroll = findViewById(R.id.scroll);
    }

    private void setListeners() {
        this.iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                id = 100;
                if (interstitialAd != null && interstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(CategoriesActivity.this, QuotesHomeActivity.class));
                    finish();
                }
            }
        });

        this.scroll.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                if (scroll.getScrollY() == 0) {
                    linearDivider.setVisibility(View.GONE);
                } else {
                    linearDivider.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.myReceiver);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 3 && i2 == -1) {
            this.mCategoriesAdapter.notifyDataSetChanged();
        }
    }

    public void loadData() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        this.listCategories.setLayoutManager(gridLayoutManager);
        CategoriesAdapter categoriesAdapter = new CategoriesAdapter(this.list, gridLayoutManager, 2, this, this);
        this.mCategoriesAdapter = categoriesAdapter;
        this.listCategories.setAdapter(categoriesAdapter);
        loadSectionsAndCategories();
    }

    private void loadSectionsAndCategories() {
        Information informationJson = getInformationJson();
        ArrayList sections = informationJson.getSections();
        ArrayList categories = informationJson.getCategories();
        if (sections.isEmpty()) {
            this.list.addAll(categories);
        } else {
            Iterator it = sections.iterator();
            while (it.hasNext()) {
                Section section = (Section) it.next();
                this.list.add(section);
                Iterator it2 = categories.iterator();
                while (it2.hasNext()) {
                    Category category = (Category) it2.next();
                    if (section.getCategoriesId().contains(category.getId())) {
                        this.list.add(category);
                    }
                }
            }
        }
        CategoriesAdapter categoriesAdapter = this.mCategoriesAdapter;
        if (categoriesAdapter != null) {
            categoriesAdapter.updateItems(this.list);
        }
    }

    public Information getInformationJson() {
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("information");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            stringBuilder.append(".json");
            InputStream open = assets.open(stringBuilder.toString());
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                return new Gson().fromJson(new String(bArr, StandardCharsets.UTF_8), Information.class);
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
        return null;
    }

    public void recyclerViewListClicked(View view, int i) {
        Category category = (Category) this.list.get(i);
        this.currentCategory = category;
        String id = category.getId();
        String str = TrackerEventUtils.KEY_CATEGORY;
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SELECTED_CATEGORY, str, id);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SELECTED_CATEGORY_MIXPANEL, str, this.currentCategory.getId());
        id = this.currentCategory.getId();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.default_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        if (!id.equalsIgnoreCase(stringBuilder.toString())) {
            id = this.currentCategory.getId();
            stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.favorites_category));
            stringBuilder.append(SettingsManager.getLanguageFiles());
            if (!(id.equalsIgnoreCase(stringBuilder.toString()) || this.currentCategory.getId().equalsIgnoreCase(getString(R.string.own_quotes_category)))) {
                if (this.currentCategory.isFree()) {
                    goBackAndLoadCategory(currentCategory);
                    return;
                }
            }
        }
        goBackAndLoadCategory(this.currentCategory);
    }

    public void goBackAndLoadCategory(Category category) {
        if (category != null) {
            String id = category.getId();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.favorites_category));
            stringBuilder.append(SettingsManager.getLanguageFiles());
            if (id.equals(stringBuilder.toString()) && FavoritesManager.getFavorites().isEmpty()) {
                startActivity(new Intent(this, FavoritesActivity.class));
                finish();
                return;
            } else if (category.getId().equals(getString(R.string.own_quotes_category)) && OwnQuotesManager.getOwnQuotes().isEmpty()) {
                startActivity(new Intent(this, YourOwnEmptyActivity.class));
                finish();
                return;
            } else {
                CategoryManager.setCategorySelected(category.getId());
                setResult(-1, new Intent());
                finish();
                return;
            }
        }
        finish();
    }

    private void createNetworkChangeBroadcastReceiver() {
        this.myReceiver = new NetworkChangeReceiver(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        registerReceiver(this.myReceiver, intentFilter);
    }

    public void onResume() {
        super.onResume();
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;
    private AdView adView;

    private void loadAd()
    {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        startActivity(new Intent(CategoriesActivity.this, QuotesHomeActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(CategoriesActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }
}
