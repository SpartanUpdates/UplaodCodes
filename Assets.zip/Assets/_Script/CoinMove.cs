﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinMove : MonoBehaviour
{
    float speed=50f;

    bool startMove=false;

    Vector3 targetPos;

    public GameObject coinEffect;

    void Start()
    {
        targetPos.x = transform.position.x;
        targetPos.y = transform.position.y + 11;
        targetPos.z = transform.position.z + 30;
    }
    Vector3 tempAngle;

    void Update()
    {
        if (!GameManager.instance.isGamePause)
        {
            if (startMove)
            {
                if (Vector3.Distance(transform.position, targetPos) > 0.2f)
                {
                    transform.position = Vector3.MoveTowards(transform.position, targetPos, Time.deltaTime * speed);
                    tempAngle.y = transform.localEulerAngles.y + 30;
                    transform.localEulerAngles = tempAngle;
                }
                else
                {
                    Destroy(this.gameObject);
                }
            }
        }
    }
   
    void OnTriggerEnter(Collider target)
    {
        if (target.CompareTag("Player"))
        {
            coinEffect.SetActive(true);
            startMove = true;
            this.GetComponent<Animator>().enabled = false;
        }
    }
}
