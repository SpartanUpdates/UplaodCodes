package com.esc.uvideostatus.Utility;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.util.Log;
import com.google.android.exoplayer2.C;
import java.lang.reflect.Field;
import java.util.HashMap;

public class TypefaceUtil {
    public static void overrideFont(Context context, String str, String str2) {
        Typeface createFromAsset = Typeface.createFromAsset(context.getAssets(), str2);
        if (VERSION.SDK_INT >= 21) {
            HashMap hashMap = new HashMap();
            hashMap.put(C.SERIF_NAME, createFromAsset);
            try {
                Field declaredField = Typeface.class.getDeclaredField("sSystemFontMap");
                declaredField.setAccessible(true);
                declaredField.set(null, hashMap);
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                Field declaredField2 = Typeface.class.getDeclaredField(str);
                declaredField2.setAccessible(true);
                declaredField2.set(null, createFromAsset);
            } catch (Exception unused) {
                String simpleName = TypefaceUtil.class.getSimpleName();
                StringBuilder sb = new StringBuilder();
                sb.append("Can not set custom font ");
                sb.append(str2);
                sb.append(" instead of ");
                sb.append(str);
                Log.e(simpleName, sb.toString());
            }
        }
    }
}
