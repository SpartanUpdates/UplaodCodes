﻿using UnityEngine;

namespace BallCollect
{
    public static class ColorManager
    {
        public static readonly Color[] PlatfromColor = new Color[]
        {
        new Color(0.2549f, 0.5294f, 0.2784f),
        new Color(0.8431f, 0.3921f, 0.1176f),
        new Color(0.1215f, 0.2784f, 0.8f),
        new Color(0.5137f, 0.1334f, 0.1965f),
        new Color(0.2235f, 0.6901f, 0.4784f),
        new Color(0.2235f, 0.3372f, 0.6941f),
        new Color(0.6745f, 0.2235f, 0.6901f),
        new Color(0.0039f, 0.4627f, 0.7725f),
        new Color(0.1647f, 0.5058f, 0.4784f),
        new Color(0.2745f, 0.1921f, 0.5882f),
        new Color(0.3294f, 0.0901f, 0.1215f),
        new Color(0.1882f, 0.3372f, 0.5843f),
        new Color(0.4901f, 0.1686f, 0.5098f),
        new Color(0.9490f, 0.7882f, 0.0982f),
        new Color(0.4509f, 0.3019f, 0.2274f),
        new Color(0f, 0.2588f, 0.5490f),
        new Color(0.5568f, 0f, 0.2901f),
        new Color(0.9372f, 0.6235f, 0.1411f),
        new Color(0.4392f, 0.5647f, 1f),
        new Color(1f,0.7019f,0.5058f),
        new Color(1f,0.2901f,0.4352f),
        new Color(0.2431f, 0.3882f, 0.3215f),
        new Color(0.2156f, 0.2117f, 0.3764f),
        new Color(0.3725f, 0.2117f, 0.3372f),
        new Color(0f, 0.2823f, 0.4705f),
        new Color(0.0784f, 0.2941f, 0.2745f),
        new Color(0.6667f, 0.3372f, 0.9568f),
        new Color(0.3372f, 0.6274f, 0.9647f),
        new Color(0.4901f, 0.3411f, 0.2509f),
        };

        public static readonly Color[] droneColors = new Color[]
        {
        new Color(1f, 1f, 0.0392156877f),
        new Color(0.968627453f, 0f, 1f),
        new Color(0f, 0.470588237f, 1f),
        new Color(0.5019608f, 0f, 1f)
        };

     

        public static readonly Color[] oceanColors = new Color[]
        {
        new Color(0.9803f, 0.8313f, 0.431372553f),
        new Color(0.4f, 0.4f, 0.4f),
        new Color(0.7490196f, 0.945098042f, 0.8627451f),
        new Color(0.20784314f, 0.8352941f, 0.9490196f),
        new Color(0.854901969f, 0.698039234f, 0.992156863f)
        };

        public static readonly Color[] ballColors = new Color[]
        {
            new Color(1f, 1f, 1f),
        new Color(1f, 0.8705f, 0f),
        new Color(0.2f, 0.2f, 0.2f),
        new Color(0.7725f, 0f, 1f),
        new Color(0f, 0.8235f, 0.0549f),
        new Color(1f, 0.149f, 0.149f),
        new Color(0f, 0.2901f, 1f),
        new Color(0f, 0.7058f, 0.6274f),
        new Color(0.8236f, 0.4321f, 0.0f)
        };

        public static readonly Color[] PlayerColor = new Color[]
        {
        new Color(1f, 0.1450f, 0.1450f),
        new Color(0.2661f, 0.9137f, 0.9725f),
        new Color(0.2784f, 0.2509f, 0.9337f),
        new Color(1f, 0.64705f, 0.2392f),
        new Color(0.5490f, 0.2661f, 0.9725f),
        new Color(0.5098f, 0.5098f, 0.5098f),
        new Color(0.6f, 0.9215f, 0.3176f),
        new Color(0.3176f, 0.6f, 0.9215f),
        new Color(1f, 0.2392f, 0.5568f),
        new Color(1f, 0.2156f, 0.3333f)
        };
    }
}