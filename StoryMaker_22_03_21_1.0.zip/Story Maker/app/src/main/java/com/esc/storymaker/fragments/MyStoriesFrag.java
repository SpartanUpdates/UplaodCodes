package com.esc.storymaker.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.RvStoryAdapter;
import com.esc.storymaker.mediapicker.utils.ScreenUtil;
import com.esc.storymaker.utils.AppUtil;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

public class MyStoriesFrag extends Fragment {
    RelativeLayout btn_cancel;
    RelativeLayout btn_delete;
    FloatingActionButton fab_add;
    private ArrayList<String> imgPaths;
    LinearLayout llAddBtn;
    private String newSaveFolder;
    private String oldSaveFolder;
    private View rootView;
    RecyclerView rvStories;
    private RvStoryAdapter rvStoryAdapter;
    View wgCheckedList;

    public static MyStoriesFrag getInstance() {
        return new MyStoriesFrag();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_my_story, viewGroup, false);
        this.llAddBtn = this.rootView.findViewById(R.id.ll_add_btn);
        this.rvStories = this.rootView.findViewById(R.id.rv_stories);
        this.wgCheckedList = this.rootView.findViewById(R.id.wg_checked_list);
        this.fab_add = this.rootView.findViewById(R.id.fab_add);
        this.btn_cancel = this.rootView.findViewById(R.id.btn_cancel);
        this.btn_delete = this.rootView.findViewById(R.id.btn_delete);
        this.fab_add.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyStoriesFrag.this.onAdd();
            }
        });
        this.btn_cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyStoriesFrag.this.onCancel();
            }
        });
        this.btn_delete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyStoriesFrag.this.onDelete();
            }
        });
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        String str = "/";
        stringBuilder.append(str);
        stringBuilder.append(getString(R.string.app_name));
        this.oldSaveFolder = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        stringBuilder.append(str);
        stringBuilder.append(getString(R.string.app_name).replace(" ", ""));
        this.newSaveFolder = stringBuilder.toString();
        if (AppUtil.permissionGranted(getActivity(), "android.permission.READ_EXTERNAL_STORAGE") && AppUtil.permissionGranted(getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE")) {
            movePhotos();
            setStoriesList();
        }
        return this.rootView;
    }

    private void movePhotos() {
        File file = new File(this.oldSaveFolder);
        if (file.exists()) {
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (File name : listFiles) {
                    String name2 = name.getName();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this.oldSaveFolder);
                    String str = "/";
                    stringBuilder.append(str);
                    stringBuilder.append(name2);
                    File file2 = new File(stringBuilder.toString());
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(this.newSaveFolder);
                    stringBuilder.append(str);
                    stringBuilder.append(name2);
                    file2.renameTo(new File(stringBuilder.toString()));
                }
            }
            AppUtil.deleteFolder(file);
        }
    }

    private void setStoriesList() {
        File file = new File(this.newSaveFolder);
        if (!file.exists()) {
            file.mkdirs();
        }
        File[] listFiles = file.listFiles();
        this.imgPaths = new ArrayList();
        if (listFiles != null && listFiles.length > 0) {
            this.llAddBtn.setVisibility(View.GONE);
            for (File file2 : listFiles) {
                ArrayList arrayList = this.imgPaths;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.newSaveFolder);
                stringBuilder.append("/");
                stringBuilder.append(file2.getName());
                arrayList.add(stringBuilder.toString());
            }
        }
        this.rvStoryAdapter = new RvStoryAdapter(getActivity(), this.imgPaths, ScreenUtil.getScreenWidth(getActivity()), this);
        this.rvStories.setLayoutManager(new GridLayoutManager(getContext(), 2));
        this.rvStories.setAdapter(this.rvStoryAdapter);
    }

    public void setWgCheckedList(boolean z) {
        if (z) {
            this.wgCheckedList.setVisibility(View.VISIBLE);
        } else {
            this.wgCheckedList.setVisibility(View.GONE);
        }
    }

    public int getWgCheckedList() {
        return this.wgCheckedList.getVisibility();
    }

    public void onResume() {
        setStoriesList();
        super.onResume();
    }

    public void onCancel() {
        this.rvStoryAdapter.setCheckedImages(new ArrayList());
        setWgCheckedList(false);
    }

    public void onDelete() {
        ArrayList checkedImages = this.rvStoryAdapter.getCheckedImages();
        setWgCheckedList(false);
        Iterator it = checkedImages.iterator();
        while (it.hasNext()) {
            File file = new File((String) it.next());
            if (file.delete()) {
                getActivity().sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
            }
        }
        setStoriesList();
    }

    public void onAdd() {
        ((MainActivity) getContext()).swipeVP(0);
    }
}
