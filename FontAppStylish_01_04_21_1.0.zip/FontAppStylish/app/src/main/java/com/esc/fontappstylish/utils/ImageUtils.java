package com.esc.fontappstylish.utils;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ImageUtils {
    private static ImageUtils mInstant;

    public static ImageUtils getInstant() {
        if (mInstant == null) {
            mInstant = new ImageUtils();
        }
        return mInstant;
    }

    public Bitmap getCompressedBitmap22(String str) {
        Bitmap createBitmap;
        Bitmap bitmap;
        ByteArrayOutputStream byteArrayOutputStream;
        byte[] toByteArray;
        StringBuilder stringBuilder;
        String str2 = str;
        Options options = new Options();
        options.inJustDecodeBounds = true;
        Bitmap decodeFile = BitmapFactory.decodeFile(str2, options);
        int i = options.outHeight;
        int i2 = options.outWidth;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(i2);
        String str3 = " ";
        stringBuilder2.append(str3);
        stringBuilder2.append(i);
        String str4 = "aaaaaa";
        float f = (float) i2;
        float f2 = (float) i;
        float f3 = f / f2;
        if (f2 > 1080.0f || f > 1024.0f)
        {
            if (f3 < 0.94814813f) {
                i2 = (int) ((1080.0f / f2) * f);
                i = (int) 1080.0f;
            } else {
                i = f3 > 0.94814813f ? (int) ((1024.0f / f) * f2) : (int) 1080.0f;
                i2 = (int) 1024.0f;
            }
        }
        int i3 = i2;
        i2 = i;
        options.inSampleSize = calculateInSampleSize(options, i3, i2);
        options.inJustDecodeBounds = false;
        options.inTempStorage = new byte[16384];
        try {
            decodeFile = BitmapFactory.decodeFile(str2, options);
        } catch (OutOfMemoryError e2) {
            e2.printStackTrace();
        }
        try {
            createBitmap = Bitmap.createBitmap(i3, i2, Config.ARGB_8888);
        } catch (OutOfMemoryError e22) {
            e22.printStackTrace();
            createBitmap = null;
        }
        Bitmap bitmap2 = createBitmap;
        float f4 = (float) i3;
        f = f4 / ((float) options.outWidth);
        float f5 = (float) i2;
        float f6 = f5 / ((float) options.outHeight);
        f4 /= 2.0f;
        f5 /= 2.0f;
        Matrix matrix = new Matrix();
        matrix.setScale(f, f6, f4, f5);
        Canvas canvas = new Canvas(bitmap2);
        canvas.setMatrix(matrix);
        canvas.drawBitmap(decodeFile, f4 - (((float) decodeFile.getWidth()) / 2.0f), f5 - (((float) decodeFile.getHeight()) / 2.0f), new Paint(2));
        try {
            i = new ExifInterface(str2).getAttributeInt("Orientation", 0);
            Matrix matrix2 = new Matrix();
            if (i == 6) {
                matrix2.postRotate(90.0f);
            } else if (i == 3) {
                matrix2.postRotate(180.0f);
            } else if (i == 8) {
                matrix2.postRotate(270.0f);
            }
            bitmap = bitmap2;
            bitmap2 = Bitmap.createBitmap(bitmap2, 0, 0, bitmap2.getWidth(), bitmap2.getHeight(), matrix2, true);
        } catch (IOException e4) {
            e4.printStackTrace();
        }
        byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap2.compress(CompressFormat.JPEG, 85, byteArrayOutputStream);
        toByteArray = byteArrayOutputStream.toByteArray();
        createBitmap = BitmapFactory.decodeByteArray(toByteArray, 0, toByteArray.length);
        stringBuilder = new StringBuilder();
        stringBuilder.append(createBitmap.getWidth());
        stringBuilder.append(str3);
        stringBuilder.append(createBitmap.getHeight());
        return createBitmap;
    }

    private int calculateInSampleSize(Options options, int i, int i2) {
        int round;
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        if (i3 > i2 || i4 > i) {
            round = Math.round(((float) i3) / ((float) i2));
            int round2 = Math.round(((float) i4) / ((float) i));
            if (round >= round2) {
                round = round2;
            }
        } else {
            round = 1;
        }
        while (((float) (i4 * i3)) / ((float) (round * round)) > ((float) ((i * i2) * 2))) {
            round++;
        }
        return round;
    }
}
