package com.vidsoft.videostatusmaker.Utils.gridview;

public interface DynamicGridAdapterInterface
{
  boolean canReorder(final int p0);

  int getColumnCount();

  void reorderItems(final int p0, final int p1);
}
