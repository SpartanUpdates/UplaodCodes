package com.esc.gesturelockscreen.View;

import android.annotation.SuppressLint;
import android.content.Context;
import android.gesture.Gesture;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.esc.gesturelockscreen.Other.LockUIController;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.Service.SignatureLock;
import com.esc.gesturelockscreen.R;
import androidx.annotation.RequiresApi;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class ServiceLayout extends FrameLayout {
    private int count;
    private long hitTime;
    private GestureLockView mGestureLockView;
    private SlideTextView mSlideTextView;
    private SignatureLock neonLock;
    private int wrongCount;

    public ServiceLayout(final Context context) {
        super(context);
        this.count = 0;
        this.hitTime = 0L;
        this.wrongCount = 0;
    }

    public ServiceLayout(final Context context, final AttributeSet set) {
        super(context, set);
        this.count = 0;
        this.hitTime = 0L;
        this.wrongCount = 0;
    }

    public ServiceLayout(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.count = 0;
        this.hitTime = 0L;
        this.wrongCount = 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ServiceLayout(final Context context, final AttributeSet set, final int n, final int n2) {
        super(context, set, n, n2);
        this.count = 0;
        this.hitTime = 0L;
        this.wrongCount = 0;
    }

    @SuppressLint({"InflateParams"})
    public static ServiceLayout getView(final Context context) {
        return (ServiceLayout) LayoutInflater.from(context).inflate(R.layout.layout_service_lockscreen, (ViewGroup) null);
    }

    private boolean hit() {
        if (System.currentTimeMillis() - this.hitTime < 1000L) {
            ++this.count;
            this.hitTime = System.currentTimeMillis();
            if (this.count > 1 && this.neonLock != null) {
                this.neonLock.onStop(true);
            }
            return true;
        }
        this.count = 1;
        this.hitTime = System.currentTimeMillis();
        return true;
    }

    private void setBottom() {
        final float density = this.getContext().getResources().getDisplayMetrics().density;
        final LayoutParams layoutParams = (LayoutParams) this.findViewById(R.id.gesture_lock_title).getLayoutParams();
        layoutParams.gravity = 81;
        layoutParams.bottomMargin = (int) (60.0f * density);
        this.findViewById(R.id.gesture_lock_title).setLayoutParams((ViewGroup.LayoutParams) layoutParams);
    }

    public boolean dispatchKeyEvent(final KeyEvent keyEvent) {
        boolean dispatchKeyEvent = true;
        final int action = keyEvent.getAction();
        final int keyCode = keyEvent.getKeyCode();
        if (!SettingsUtils.getBoolean("KEY_QUICK_UNLOCK", true)) {
            dispatchKeyEvent = super.dispatchKeyEvent(keyEvent);
        } else {
            switch (keyCode) {
                default: {
                    return super.dispatchKeyEvent(keyEvent);
                }
                case 24: {
                    if (action == 0) {
                        this.hit();
                        return true;
                    }
                    break;
                }
                case 25: {
                    if (action == 0) {
                        this.hit();
                        return true;
                    }
                    break;
                }
            }
        }
        return dispatchKeyEvent;
    }

    public void onScreenOff() {
        if (this.mGestureLockView != null) {
            this.mGestureLockView.onScreenOff();
        }
        if (this.mSlideTextView != null) {
            this.mSlideTextView.setStart(false);
        }
    }

    public void onScreenOn() {
        if (this.mGestureLockView != null) {
            this.mGestureLockView.onScreenOn();
        }
        if (this.mSlideTextView != null) {
            this.mSlideTextView.setStart(true);
        }
    }

    public void setListener(final SignatureLock neonLock) {
        this.neonLock = neonLock;
        if (SettingsUtils.getBoolean("ENABLE_GESTURE", false)) {
            this.wrongCount = 0;
            final View inflate = LayoutInflater.from(this.getContext()).inflate(R.layout.layout_signature, (ViewGroup) null);
            this.mGestureLockView = (GestureLockView) inflate.findViewById(R.id.gesture_layout);
            ((FrameLayout) this.findViewById(R.id.frame_lock)).addView(inflate);
            ((FrameLayout) this.findViewById(R.id.frame_lock)).setVisibility(VISIBLE);
            this.setBottom();
            this.mGestureLockView.setListener((GestureLockView.IGestureLockListener) new GestureLockView.IGestureLockListener() {
                @Override
                public void onDrawWrong(final Gesture gesture) {
                    final ServiceLayout this$0 = ServiceLayout.this;
                    ++this$0.wrongCount;
                    LockUIController.getInstance().doVibration(100L);
                    if (ServiceLayout.this.wrongCount > 4) {
                        LockUIController.getInstance().hide();
                    }
                }

                @Override
                public void onNotLoadedError() {
                    neonLock.onStop(true);
                }

                @Override
                public void onUnDrawRecorded(final Gesture gesture) {
                }

                @Override
                public void onUnLockSuccess(final GestureLockView.GESTUREMODE gesturemode) {
                    neonLock.onStop(true);
                }
            });
            this.mGestureLockView.onInitMode(GestureLockView.GESTUREMODE.MODE_UNLOCK);
            return;
        }
        final ViewPager viewPager = (ViewPager) LayoutInflater.from(this.getContext()).inflate(R.layout.layout_viewpager, (ViewGroup) null);
        this.mSlideTextView = (SlideTextView) viewPager.findViewById(R.id.slide);
        viewPager.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() {
                return 3;
            }

            @Override
            public Object instantiateItem(final ViewGroup viewGroup, int n) {
                switch (n) {
                    default: {
                        n = R.id.page_three;
                        break;
                    }
                    case 0: {
                        n = R.id.page_one;
                        break;
                    }
                    case 1: {
                        n = R.id.page_two;
                        break;
                    }
                }
                return ServiceLayout.this.findViewById(n);
            }

            @Override
            public boolean isViewFromObject(final View view, final Object o) {
                return view == o;
            }
        });
        viewPager.setCurrentItem(1);
        viewPager.addOnPageChangeListener((ViewPager.OnPageChangeListener) new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(final int n) {
            }

            @Override
            public void onPageScrolled(final int n, final float n2, final int n3) {
            }

            @Override
            public void onPageSelected(final int n) {
                if (n == 0 || n == 2) {
                    neonLock.onStop(true);
                }
            }
        });
        ((FrameLayout) this.findViewById(R.id.frame_lock)).addView((View) viewPager);
        ((FrameLayout) this.findViewById(R.id.frame_lock)).setVisibility(View.VISIBLE);
    }
}
