package com.kotlinz.videoCollage.other;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.os.Build.VERSION;

public class ImageUtils {

    public static Bitmap resampleImage(String str, int i) throws Exception {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        Options options2 = new Options();
        options2.inSampleSize = getClosestResampleSize(options.outWidth, options.outHeight, i);
        Bitmap decodeFile = BitmapFactory.decodeFile(str, options2);
        Matrix matrix = new Matrix();
        if (decodeFile.getWidth() > i || decodeFile.getHeight() > i) {
            Options resampling = getResampling(decodeFile.getWidth(), decodeFile.getHeight(), i);
            matrix.postScale(((float) resampling.outWidth) / ((float) decodeFile.getWidth()), ((float) resampling.outHeight) / ((float) decodeFile.getHeight()));
        }
        if (new Integer(VERSION.SDK).intValue() > 4) {
            int exifRotation = ExifUtils.getExifRotation(str);
            if (exifRotation != 0) {
                matrix.postRotate((float) exifRotation);
            }
        }
        return Bitmap.createBitmap(decodeFile, 0, 0, decodeFile.getWidth(), decodeFile.getHeight(), matrix, true);
    }

    public static Options getResampling(int i, int i2, int i3) {
        float f;
        float f2;
        Options options = new Options();
        if (i <= i2 && i2 > i) {
            f = (float) i3;
            f2 = (float) i2;
        } else {
            f = (float) i3;
            f2 = (float) i;
        }
        f /= f2;
        options.outWidth = (int) ((((float) i) * f) + 0.5f);
        options.outHeight = (int) ((((float) i2) * f) + 0.5f);
        return options;
    }

    public static int getClosestResampleSize(int i, int i2, int i3) {
        i = Math.max(i, i2);
        int i4 = 1;
        while (i4 < 20) {
            if (i4 * i3 > i) {
                i4--;
                break;
            }
            i4++;
        }
        return i4 > 0 ? i4 : 1;
    }


    public static int dpToPx(Context context, int i) {
        float f = (float) i;
        context.getResources();
        return (int) (f * Resources.getSystem().getDisplayMetrics().density);
    }


    public static Bitmap cropCenterBitmap(Bitmap bitmap, int i, int i2) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width < i && height < i2) {
            return bitmap;
        }
        int i3 = 0;
        int i4 = width > i ? (width - i) / 2 : 0;
        if (height > i2) {
            i3 = (height - i2) / 2;
        }
        if (i > width) {
            i = width;
        }
        if (i2 > height) {
            i2 = height;
        }
        return Bitmap.createBitmap(bitmap, i4, i3, i, i2);
    }


    public static Bitmap getTiledBitmap(Bitmap bitmap, int i, int i2) {
        Rect rect = new Rect(0, 0, i, i2);
        Paint paint = new Paint();
        paint.setShader(new BitmapShader(bitmap, TileMode.REPEAT, TileMode.REPEAT));
        bitmap = Bitmap.createBitmap(i, i2, Config.ARGB_8888);
        new Canvas(bitmap).drawRect(rect, paint);
        return bitmap;
    }




}
