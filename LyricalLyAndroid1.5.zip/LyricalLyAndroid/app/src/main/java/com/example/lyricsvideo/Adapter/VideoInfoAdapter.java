package com.example.lyricsvideo.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.lyricsvideo.CallFromUnity;
import com.example.lyricsvideo.Database.DatabaseHelper;
import com.example.lyricsvideo.Download.DownloadManager;
import com.example.lyricsvideo.Download.ThemeVideoDownloadShare;
import com.example.lyricsvideo.Model.VideoInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.activity.FullVideoPlayActivity;
import com.example.lyricsvideo.activity.MainActivity;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdsManager;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VideoInfoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    public NativeAd ad;
    DatabaseHelper databaseHelper;
    private MainActivity ActivityOfTheme;
    private String UnityXmlPath, TransparantVideoPath;
    private File PreviewVideoPath;
    private Context mContext;
    private ArrayList<VideoInfo> videoInfos;
    private NativeAdsManager mAdsManager;

    public VideoInfoAdapter(Context mContext, ArrayList<VideoInfo> videoInfos) {
        this.mContext = mContext;
        this.ActivityOfTheme = (MainActivity) mContext;
        this.videoInfos = videoInfos;
        databaseHelper = new DatabaseHelper(mContext);
        this.mAdsManager = ActivityOfTheme.mAdsManager;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        if (viewType == ITEM_TYPE_AD) {
            return new NativeAdViewHolder((NativeAdLayout) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.native_ads_row, viewGroup, false));
        } else {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_item_video, viewGroup, false);
            return new ThemeViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (getItemViewType(position) == ITEM_TYPE_AD) {
            final NativeAdViewHolder viewHolder = (NativeAdViewHolder) holder;
            if (videoInfos.get(position).isNativeAds()) {
                NativeAd nextNativeAd = mAdsManager.nextNativeAd();
                viewHolder.adchoicescontainer.removeAllViews();
                if (nextNativeAd == null) {
                    viewHolder.llAdContainer.setVisibility(View.GONE);
                } else if (nextNativeAd.isAdLoaded()) {
                    viewHolder.llAdContainer.setVisibility(View.VISIBLE);
                    viewHolder.adtitle.setText(nextNativeAd.getAdvertiserName());
                    viewHolder.adbody.setText(nextNativeAd.getAdBodyText());
                    viewHolder.adsocial.setText(nextNativeAd.getAdSocialContext());
                    viewHolder.adsponsored.setText("Sponsored");
                    viewHolder.btnAdAction.setText(nextNativeAd.getAdCallToAction());
                    viewHolder.btnAdAction.setVisibility(nextNativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
                    viewHolder.adchoicescontainer.addView(new AdOptionsView(viewHolder.llAdContainer.getContext(), nextNativeAd, viewHolder.nativeAd), 0);
                    List arrayList = new ArrayList();
                    arrayList.add(viewHolder.adicon);
                    arrayList.add(viewHolder.admedia);
                    arrayList.add(viewHolder.btnAdAction);
                    nextNativeAd.registerViewForInteraction(viewHolder.nativeAd, viewHolder.admedia, viewHolder.adicon, arrayList);
                } else {
                    viewHolder.llAdContainer.setVisibility(View.GONE);
                }
            }
        } else {
            if (holder instanceof ThemeViewHolder) {
                final ThemeViewHolder videoHolder = (ThemeViewHolder) holder;
                final VideoInfo videoInfo = videoInfos.get(position);
                if (!videoInfos.get(position).isAvailableOfflineShareVideo) {
                    if (videoInfos.get(position).isDownloadingshareVideo) {
                        videoHolder.ivShare.setVisibility(View.GONE);
                        videoHolder.btnUseNowShare.setVisibility(View.GONE);
                        videoHolder.rlProgressShare.setVisibility(View.VISIBLE);
                    } else {
                        videoHolder.rlProgressShare.setVisibility(View.GONE);
                        videoHolder.btnUseNowShare.setVisibility(View.GONE);
                        videoHolder.ivShare.setVisibility(View.VISIBLE);
                    }
                } else {
                    videoHolder.ivShare.setVisibility(View.GONE);
                    videoHolder.rlProgressShare.setVisibility(View.GONE);
                    videoHolder.btnUseNowShare.setVisibility(View.VISIBLE);
                }


                if (!videoInfos.get(position).isAvailableOffline) {
                    if (videoInfos.get(position).isDownloading) {
                        videoHolder.ivDownload.setVisibility(View.GONE);
                        videoHolder.btnUseNow.setVisibility(View.GONE);
                        videoHolder.rlProgress.setVisibility(View.VISIBLE);
                    } else {
                        videoHolder.rlProgress.setVisibility(View.GONE);
                        videoHolder.btnUseNow.setVisibility(View.GONE);
                        videoHolder.ivDownload.setVisibility(View.VISIBLE);
                    }
                } else {
                    videoHolder.ivDownload.setVisibility(View.GONE);
                    videoHolder.rlProgress.setVisibility(View.GONE);
                    videoHolder.btnUseNow.setVisibility(View.VISIBLE);
                }
                Glide.with(mContext).load(videoInfos.get(position).getLargeThemeImage())
                        .into(videoHolder.ivVideoThumbnail);
                videoHolder.tvSongName.setText(videoInfo.getVideoName());
                videoHolder.tvSongView.setText(videoInfo.getViewCount());
                videoHolder.tvSongShare.setText(videoInfo.getShareCount());
                videoHolder.tvSongdownload.setText(videoInfo.getDownloadCount());
                AppFont.Textfont(mContext, videoHolder.tvSongName);
                AppFont.Textfont(mContext, videoHolder.tvSongView);
                AppFont.Textfont(mContext, videoHolder.tvSongShare);
                AppFont.Textfont(mContext, videoHolder.tvSongdownload);
                AppFont.Textfont(mContext, videoHolder.tvSongDate);
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = sdf.parse(videoInfos.get(position).getVideoCreateDate());
                    long startDate = date.getTime();
                    videoHolder.tvSongDate.setText(Utils.INSTANCE.getTimeAgo(startDate));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                videoHolder.ivDownload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isAllGrant = true;
                        for (int i = 0; i < MainActivity.NECESSARY_PERMISSIONS.length; i++) {
                            if (ContextCompat.checkSelfPermission(mContext,
                                    MainActivity.NECESSARY_PERMISSIONS[i]) == PackageManager.PERMISSION_DENIED) {
                                isAllGrant = false;
                            }
                        }
                        if (isAllGrant) {
                            if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                                videoHolder.ivDownload.setVisibility(View.GONE);
                                videoHolder.rlProgress.setVisibility(View.VISIBLE);
                                databaseHelper.insertdata(videoInfo.getVideoName(), videoInfo.getSmallThemeImage(), videoInfo.getPreviewVideoUrl(), String.valueOf(videoInfo.getNoOfImages()), videoInfo.getContentZipFolderName());
                                new DownloadManager(mContext, videoInfos.get(position).getContentZipFilePath(), videoHolder.pbDownload, videoHolder.tvprogress, videoInfo, videoHolder.ivDownload, videoHolder.btnUseNow, videoHolder.rlProgress);
                                Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeDownloadUrl, videoInfos.get(position).getVideoId());
                            }
                        } else {
                            Toast.makeText(mContext, "Please Allow All Permission First", Toast.LENGTH_LONG).show();
                            ActivityOfTheme.RequiredPermission("Sorry! we need all permission for make experience batter, Go to Setting And Allow Us.");
                        }
                    }
                });
                videoHolder.ivShare.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isAllGrant = true;
                        for (int i = 0; i < MainActivity.NECESSARY_PERMISSIONS.length; i++) {
                            if (ContextCompat.checkSelfPermission(mContext,
                                    MainActivity.NECESSARY_PERMISSIONS[i]) == PackageManager.PERMISSION_DENIED) {
                                isAllGrant = false;
                            }
                        }
                        if (isAllGrant) {
                            if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                                videoHolder.ivShare.setVisibility(View.GONE);
                                videoHolder.rlProgressShare.setVisibility(View.VISIBLE);
                                new ThemeVideoDownloadShare(mContext, videoInfos.get(position).getPreviewVideoUrl(), videoInfos.get(position).getPreviewVideoName(), videoHolder.pbShare, videoHolder.tvProgressShare, videoInfo, videoHolder.ivShare, videoHolder.btnUseNowShare, videoHolder.rlProgressShare);
                                Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeVideoShareUrl, videoInfos.get(position).getVideoId());
                            }
                        } else {
                            Toast.makeText(mContext, "Please Allow All Permission First", Toast.LENGTH_LONG).show();
                            ActivityOfTheme.RequiredPermission("Sorry! we need all permission for make experience batter, Go to Setting And Allow Us.");
                        }
                    }
                });
                videoHolder.ivPlay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(ActivityOfTheme, FullVideoPlayActivity.class);
                        i.putExtra("Url", videoInfos.get(position).getPreviewVideoUrl());
                        i.putExtra("Name", videoInfos.get(position).getVideoName());
                        i.putExtra("videoThumbImage", videoInfos.get(position).getLargeThemeImage());
                        i.putExtra("IsPlayVidoeFromHome", true);
                        i.putExtra("IsVideoFromList", true);
                        ActivityOfTheme.startActivity(i);
                        Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeVideoViewUrl, videoInfos.get(position).getVideoId());
                    }
                });
                videoHolder.btnUseNow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DownloadFiles(position, videoHolder.pbDownload, videoHolder.tvprogress, videoHolder.ivDownload, videoHolder.btnUseNow, videoHolder.rlProgress, videoInfo);
                    }
                });
                videoHolder.btnUseNowShare.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DownloadToShareVideo(position, videoHolder.pbShare, videoHolder.tvProgressShare, videoHolder.ivShare, videoHolder.btnUseNowShare, videoHolder.rlProgressShare, videoInfo);
                    }
                });
            }

        }
    }

    private void DownloadToShareVideo(int position, ProgressBar Pbshare, TextView tvprogressSahre, ImageView ivDownloadShare, AppCompatButton btnUsenowShare, RelativeLayout rlThemeProgressShare, VideoInfo themelModel) {
        PreviewVideoPath = (new File(Utils.INSTANCE.getLyricsPreviewVideoPath() + File.separator + videoInfos.get(position).getPreviewVideoName()));
        int PreviewVideoSize = videoInfos.get(position).getPreviewVideoSize();
        int PreviewVideoExistSize = Integer.parseInt(String.valueOf(PreviewVideoPath.length()));
        if (PreviewVideoPath.exists()) {
            if (PreviewVideoExistSize == PreviewVideoSize) {
                ShareVideoMore(String.valueOf(PreviewVideoPath));
            } else {
                if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                    ivDownloadShare.setVisibility(View.GONE);
                    rlThemeProgressShare.setVisibility(View.VISIBLE);
                    new ThemeVideoDownloadShare(mContext, videoInfos.get(position).getPreviewVideoUrl(), videoInfos.get(position).getPreviewVideoName(), Pbshare, tvprogressSahre, themelModel, ivDownloadShare, btnUsenowShare, rlThemeProgressShare);
                    Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeVideoShareUrl, videoInfos.get(position).getVideoId());
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                ivDownloadShare.setVisibility(View.GONE);
                rlThemeProgressShare.setVisibility(View.VISIBLE);
                new ThemeVideoDownloadShare(mContext, videoInfos.get(position).getPreviewVideoUrl(), videoInfos.get(position).getPreviewVideoName(), Pbshare, tvprogressSahre, themelModel, ivDownloadShare, btnUsenowShare, rlThemeProgressShare);
                Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeVideoShareUrl, videoInfos.get(position).getVideoId());
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void DownloadFiles(int position, ProgressBar progressBar, TextView tvprogress, ImageView ivDownload, AppCompatButton btnUsenow, RelativeLayout rlThemeProgress, VideoInfo themelModel) {
        File ContentDataFilePath = (new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + videoInfos.get(position).getContentZipFolderName() + File.separator + videoInfos.get(position).getContentZipFileName()));
        int ContentDataFileSize = videoInfos.get(position).getContentZipFileSize();
        int ContentDataExistSize = Integer.parseInt(String.valueOf(ContentDataFilePath.length()));
        UnityXmlPath = String.valueOf(new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + videoInfos.get(position).getContentZipFolderName() + File.separator + videoInfos.get(position).getVideoName() + ".xml"));
        TransparantVideoPath = String.valueOf(new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + videoInfos.get(position).getContentZipFolderName() + File.separator + videoInfos.get(position).getVideoName() + ".mp4"));
        CallFromUnity.TransparantVideoPath = TransparantVideoPath;
        CallFromUnity.UnityXmlPath = UnityXmlPath;
        if (ContentDataFilePath.exists()) {
            if (ContentDataExistSize == ContentDataFileSize) {
                if (new File(UnityXmlPath).exists() && new File(TransparantVideoPath).exists()) {
                    CallFromUnity.ImageSelection(mContext, videoInfos.get(position).getWidth(), videoInfos.get(position).getHeight(), videoInfos.get(position).getNoOfImages(), false);
                    ActivityOfTheme.finish();
                } else {
                    Utils.INSTANCE.unpackZip(new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + videoInfos.get(position).getContentZipFolderName() + File.separator + videoInfos.get(position).getContentZipFileName());
                    CallFromUnity.ImageSelection(mContext, videoInfos.get(position).getWidth(), videoInfos.get(position).getHeight(), videoInfos.get(position).getNoOfImages(), false);
                    ActivityOfTheme.finish();
                }
            } else {
                if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    rlThemeProgress.setVisibility(View.VISIBLE);
                    new DownloadManager(mContext, videoInfos.get(position).getContentZipFilePath(), progressBar, tvprogress, themelModel, ivDownload, btnUsenow, rlThemeProgress);
                    Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeDownloadUrl, videoInfos.get(position).getVideoId());
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.CheckIntrenetConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                rlThemeProgress.setVisibility(View.VISIBLE);
                new DownloadManager(mContext, videoInfos.get(position).getContentZipFilePath(), progressBar, tvprogress, themelModel, ivDownload, btnUsenow, rlThemeProgress);
                Utils.INSTANCE.new TaskCount().execute(ActivityOfTheme.ThemeDownloadUrl, videoInfos.get(position).getVideoId());
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void ShareVideoMore(String path) {
        final File file = new File(path);
        final Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.setType("video/*");
        shareIntent.putExtra("android.intent.extra.SUBJECT", ActivityOfTheme.getString(R.string.app_name));
        shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(ActivityOfTheme.getString(R.string.get_free)) + ActivityOfTheme.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + ActivityOfTheme.getPackageName());
        final Uri ShareUri = FileProvider.getUriForFile(ActivityOfTheme, String.valueOf(ActivityOfTheme.getPackageName()) + ".provider", file);
        shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ActivityOfTheme.startActivity(Intent.createChooser(shareIntent, "Share Video"));
    }


    @Override
    public int getItemCount() {
        return videoInfos.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ((position > 0) && ((position + 1) % 3 == 0) && mAdsManager.isLoaded()) {
            return ITEM_TYPE_AD;
        }
        return ITEM_TYPE_DATA;
    }


    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout rlProgress, rlProgressShare;
        ImageView ivPlay, ivShare, ivDownload;
        ImageView ivVideoThumbnail;
        TextView tvSongName, tvSongView, tvSongShare, tvSongDate, tvSongdownload, tvprogress, tvProgressShare;
        AppCompatButton btnUseNow, btnUseNowShare;
        ProgressBar pbDownload, pbShare;

        ThemeViewHolder(View itemView) {
            super(itemView);
            ivVideoThumbnail = itemView.findViewById(R.id.imgVideoThumbnail);
            ivDownload = itemView.findViewById(R.id.imgDownload);
            rlProgress = itemView.findViewById(R.id.layoutProgress);
            tvprogress = itemView.findViewById(R.id.txtProgress);
            btnUseNow = itemView.findViewById(R.id.txtUseNow);
            pbDownload = itemView.findViewById(R.id.progressDownload);
            ivShare = itemView.findViewById(R.id.imgShare);
            rlProgressShare = itemView.findViewById(R.id.layoutProgressShare);
            tvProgressShare = itemView.findViewById(R.id.txtProgressShare);
            btnUseNowShare = itemView.findViewById(R.id.txtShareNow);
            pbShare = itemView.findViewById(R.id.progressShare);
            ivPlay = itemView.findViewById(R.id.imgPlay);
            tvSongName = itemView.findViewById(R.id.txtSongName);
            tvSongView = itemView.findViewById(R.id.txtSongView);
            tvSongShare = itemView.findViewById(R.id.txtSongShare);
            tvSongdownload = itemView.findViewById(R.id.txtSongUsed);
            tvSongDate = itemView.findViewById(R.id.txtSongDate);
        }
    }

    public class NativeAdViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llAdContainer;
        NativeAdLayout nativeAd;
        MediaView admedia;
        MediaView adicon;
        TextView adtitle;
        TextView adbody;
        TextView adsocial;
        TextView adsponsored;
        Button btnAdAction;
        LinearLayout adchoicescontainer;

        NativeAdViewHolder(NativeAdLayout nativeAdLayout) {
            super(nativeAdLayout);
            nativeAd = nativeAdLayout;
            llAdContainer = nativeAdLayout.findViewById(R.id.llNativeAdContainer);
            admedia = nativeAdLayout.findViewById(R.id.native_ad_media);
            adtitle = nativeAdLayout.findViewById(R.id.native_ad_title);
            adbody = nativeAdLayout.findViewById(R.id.native_ad_body);
            adsocial = nativeAdLayout.findViewById(R.id.native_ad_social_context);
            adsponsored = nativeAdLayout.findViewById(R.id.native_ad_sponsored_label);
            btnAdAction = nativeAdLayout.findViewById(R.id.native_ad_call_to_action);
            adicon = nativeAdLayout.findViewById(R.id.native_ad_icon);
            adchoicescontainer = nativeAdLayout.findViewById(R.id.ad_choices_container);
        }
    }


}
