package com.kotlinz.videoeditor.audiovideomixer.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.ParseException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.kotlinz.videoeditor.view.AudioSliceSeekBar;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.SelectMusicActivity;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.audiovideomixer.Utils.AddAudio;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;


@SuppressLint({"WrongConstant"})
public class AudioVideoMixerActivity extends AppCompatActivity {
    static AudioSliceSeekBar a = null;
    LinearLayout b = null;

    static MediaPlayer d = null;
    static Boolean e = Boolean.valueOf(false);
    static ImageView f = null;
    static VideoSliceSeekBar g = null;
    static VideoView h = null;
    static final boolean n = true;
    String videopath = null;
    public static TextView o;

    public static a q = new a();
    ImageView j;
    Context k;
    String l;
    ProgressDialog m = null;

    public TextView r;

    public TextView s;

    public TextView t;


    ImageView ivSelectAudio;
    public VideoPlayerState v = new VideoPlayerState();

    ImageView ivback, ivDone;
    TextView tvToolbarName;

    private static class a extends Handler {
        private boolean a;
        private final Runnable b;

        private a() {
            this.a = false;
            this.b = new Runnable() {
                public void run() {
                    AudioVideoMixerActivity.a.this.a();
                }
            };
        }

        public void a() {
            if (!this.a) {
                this.a = AudioVideoMixerActivity.n;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.a = false;
            AudioVideoMixerActivity.g.videoPlayingProgress(AudioVideoMixerActivity.h.getCurrentPosition());
            if (AudioVideoMixerActivity.d != null && AudioVideoMixerActivity.d.isPlaying()) {
                try {
                    AudioVideoMixerActivity.a.videoPlayingProgress(AudioVideoMixerActivity.d.getCurrentPosition());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (!AudioVideoMixerActivity.h.isPlaying() || AudioVideoMixerActivity.h.getCurrentPosition() >= AudioVideoMixerActivity.g.getRightProgress()) {
                try {
                    if (AudioVideoMixerActivity.h.isPlaying()) {
                        AudioVideoMixerActivity.h.pause();
                        AudioVideoMixerActivity.e = Boolean.valueOf(false);

                    }
                    AudioVideoMixerActivity.g.setSliceBlocked(false);
                    AudioVideoMixerActivity.g.removeVideoStatusThumb();
                    if (AudioVideoMixerActivity.d != null && AudioVideoMixerActivity.d.isPlaying()) {
                        AudioVideoMixerActivity.d.pause();
                        AudioVideoMixerActivity.a.setSliceBlocked(false);
                        AudioVideoMixerActivity.a.removeVideoStatusThumb();
                        return;
                    }
                    return;
                } catch (IllegalStateException e9) {
                    e9.printStackTrace();
                }
            }
            postDelayed(this.b, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.audiovideomixeractivity);
        PutAnalyticsEvent();
        AddAudio.status = 0;
        AddAudio.audioPath = "";
        e = Boolean.valueOf(false);
        this.k = this;
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (h != null && h.isPlaying()) {
                    try {
                        h.pause();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                if (d != null) {
                    try {
                        d.pause();
                    } catch (IllegalStateException e4) {
                        e4.printStackTrace();
                    }
                }
                f();
            }
        });
        b = findViewById(R.id.lnr_audio_select);
        ivSelectAudio = findViewById(R.id.iv_selectaudio);
        g();
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            try {
                this.v = (VideoPlayerState) lastNonConfigurationInstance;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                Bundle extras = getIntent().getExtras();
                this.v.setFilename(extras.getString("song"));
                this.videopath = extras.getString("song");
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        h();
        ivSelectAudio.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                AudioVideoMixerActivity.this.startActivity(new Intent(AudioVideoMixerActivity.this, SelectMusicActivity.class));
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AudioVideoMixerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void e() {
        Intent intent = new Intent(getApplicationContext(), AudioMixerPreviewActivity.class);
        intent.setFlags(67108864);
        intent.putExtra("song", this.l);
        startActivity(intent);
        finish();
    }

    private void f() {
        String format = new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.AudioVideoMixer));
        this.l = sb.toString();
        File file = new File(this.l);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.AudioVideoMixer));
        sb2.append("/audiovideomixer");
        sb2.append(format);
        sb2.append(".mkv");
        this.l = sb2.toString();
        int duration = this.v.getDuration() / 1000;
        a(new String[]{"-y", "-ss", String.valueOf(this.v.getStart() / 1000), "-t", String.valueOf(duration), "-i", this.v.getFilename(), "-ss", String.valueOf((a != null ? a.getLeftProgress() : 0) / 1000), "-i", AddAudio.audioPath, "-map", "0:0", "-map", "1:0", "-acodec", "copy", "-vcodec", "copy", "-preset", "ultrafast", "-ss", "0", "-t", String.valueOf(duration), this.l}, this.l);
    }

    private void a(String[] strArr, final String str) {
        this.m = new ProgressDialog(this.k);
        this.m.setMessage("Adding Audio...");
        this.m.setCancelable(false);
        this.m.setIndeterminate(n);
        this.m.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {


                m.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    if (AudioVideoMixerActivity.this.m != null && AudioVideoMixerActivity.this.m.isShowing()) {
                        AudioVideoMixerActivity.this.m.dismiss();
                    }
                    MediaScannerConnection.scanFile(AudioVideoMixerActivity.this.k, new String[]{AudioVideoMixerActivity.this.l}, new String[]{"mkv"}, null);
                    e();
                    AudioVideoMixerActivity.this.refreshGallery(str);

                } else if (returnCode == RETURN_CODE_CANCEL) {

                    new File(str).delete();
                    AudioVideoMixerActivity.this.deleteFromGallery(str);
                    Toast.makeText(AudioVideoMixerActivity.this, "Error Creating Video", 0).show();
                } else {

                    new File(str).delete();
                    AudioVideoMixerActivity.this.deleteFromGallery(str);
                    Toast.makeText(AudioVideoMixerActivity.this, "Error Creating Video", 0).show();
                }


            }
        });
        getWindow().clearFlags(16);
    }

    private void g() {
        this.r = findViewById(R.id.left_pointer);
        this.t = findViewById(R.id.right_pointer);
        a = findViewById(R.id.audioSeekBar);
        g = findViewById(R.id.seekbar3);
        h = findViewById(R.id.videoView1);
        this.j = findViewById(R.id.ivScreen);
        f = findViewById(R.id.btnPlayVideo);
        this.s = findViewById(R.id.tvStartAudio);
        o = findViewById(R.id.tvEndAudio);
    }

    private void h() {
        h.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(final MediaPlayer mediaPlayer) {
                AudioVideoMixerActivity.g.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (AudioVideoMixerActivity.g.getSelectedThumb() == 1) {
                            AudioVideoMixerActivity.h.seekTo(AudioVideoMixerActivity.g.getLeftProgress());
                        }
                        AudioVideoMixerActivity.this.r.setText(AudioVideoMixerActivity.formatTimeUnit(i, AudioVideoMixerActivity.n));
                        AudioVideoMixerActivity.this.t.setText(AudioVideoMixerActivity.formatTimeUnit(i2, AudioVideoMixerActivity.n));
                        AudioVideoMixerActivity.this.v.setStart(i);
                        AudioVideoMixerActivity.this.v.setStop(i2);
                        if (AudioVideoMixerActivity.d != null && AudioVideoMixerActivity.d.isPlaying()) {
                            try {
                                AudioVideoMixerActivity.d.seekTo(AudioVideoMixerActivity.a.getLeftProgress());
                                AudioVideoMixerActivity.a.videoPlayingProgress(AudioVideoMixerActivity.a.getLeftProgress());
                                AudioVideoMixerActivity.d.start();
                            } catch (IllegalStateException e) {
                                e.printStackTrace();
                            }
                        }
                        mediaPlayer.setVolume(0.0f, 0.0f);
                    }
                });
                AudioVideoMixerActivity.g.setMaxValue(mediaPlayer.getDuration());
                AudioVideoMixerActivity.g.setLeftProgress(0);
                AudioVideoMixerActivity.g.setRightProgress(mediaPlayer.getDuration());
                AudioVideoMixerActivity.g.setProgressMinDiff(0);
                AudioVideoMixerActivity.h.seekTo(100);
            }
        });
        h.setVideoPath(this.v.getFilename());
        f.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AudioVideoMixerActivity.d != null) {
                    try {
                        AudioVideoMixerActivity.d.start();
                    } catch (IllegalStateException e) {
                        e.printStackTrace();
                    }
                }
                if (AudioVideoMixerActivity.e.booleanValue()) {
                    try {
                        AudioVideoMixerActivity.f.setBackgroundResource(R.drawable.ic_play_upress);
                        AudioVideoMixerActivity.e = Boolean.valueOf(false);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                } else {
                    try {
                        AudioVideoMixerActivity.f.setBackgroundResource(R.drawable.ic_pause_unpresss);
                        AudioVideoMixerActivity.e = Boolean.valueOf(AudioVideoMixerActivity.n);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                AudioVideoMixerActivity.this.i();
            }
        });
        h.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                AudioVideoMixerActivity.h.seekTo(0);
                AudioVideoMixerActivity.f.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
    }


    public void i() {
        if (h.isPlaying()) {
            try {
                h.pause();
                g.setSliceBlocked(n);
                g.removeVideoStatusThumb();
                if (d != null && d.isPlaying()) {
                    try {
                        d.pause();
                        return;
                    } catch (IllegalStateException e2) {
                        e2.printStackTrace();
                    }
                }
                return;
            } catch (IllegalStateException e3) {
                e3.printStackTrace();
            }
        }
        h.seekTo(g.getLeftProgress());
        h.start();
        g.videoPlayingProgress(g.getLeftProgress());
        q.a();
        if (d != null && d.isPlaying()) {
            try {
                d.seekTo(a.getLeftProgress());
                a.videoPlayingProgress(a.getLeftProgress());
                d.start();
            } catch (IllegalStateException e4) {
                e4.printStackTrace();
            }
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        try {
            if (AddAudio.status == 1) {
                d = new MediaPlayer();
                f.setBackgroundResource(R.drawable.ic_play_upress);
                e = Boolean.valueOf(false);
                h();
                b.setVisibility(View.VISIBLE);
                try {
                    String[] split = AddAudio.audioPath.split("/");
                    Log.v("audiopath", AddAudio.audioPath);
                    d.setDataSource(AddAudio.audioPath);
                    d.prepare();
                } catch (IllegalArgumentException e2) {
                    e2.printStackTrace();
                } catch (SecurityException e3) {
                    e3.printStackTrace();
                } catch (IllegalStateException e4) {
                    e4.printStackTrace();
                } catch (IOException e5) {
                    e5.printStackTrace();
                }
                d.setOnPreparedListener(new OnPreparedListener() {
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        a.setSeekBarChangeListener(new AudioSliceSeekBar.SeekBarChangeListener() {
                            public void SeekBarValueChanged(int i, int i2) {
                                if (a.getSelectedThumb() == 1) {
                                    d.seekTo(a.getLeftProgress());
                                }
                                s.setText(formatTimeUnit(i, n));
                                o.setText(formatTimeUnit(i2, n));
                                if (h != null && h.isPlaying()) {
                                    h.seekTo(g.getLeftProgress());
                                    h.start();
                                    g.videoPlayingProgress(g.getLeftProgress());
                                    q.a();
                                }
                            }
                        });
                        a.setMaxValue(mediaPlayer.getDuration());
                        a.setLeftProgress(0);
                        a.setRightProgress(mediaPlayer.getDuration());
                        a.setProgressMinDiff(0);
                        s.setText("00:00");
                        try {
                            o.setText(formatTimeUnit1(mediaPlayer.getDuration()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                d.setOnErrorListener(new OnErrorListener() {
                    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                        return AudioVideoMixerActivity.n;
                    }
                });
                return;
            }
            f.setBackgroundResource(R.drawable.ic_play_upress);
            e = Boolean.valueOf(false);
            AddAudio.status = 0;
            AddAudio.audioPath = "";
            b.setVisibility(8);
        } catch (Exception unused) {
            unused.printStackTrace();
        }
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit1(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit(long j2, boolean z) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @SuppressLint("ResourceType")
    public void k() {
        new AlertDialog.Builder(this).setIcon(17301543).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                AudioVideoMixerActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        File file = new File(videopath);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        Intent intent = new Intent(getApplicationContext(), EditActivity.class);
        intent.setFlags(67108864);
        intent.putExtra("videofilename", this.videopath);

        startActivity(intent);
        finish();
    }
}
