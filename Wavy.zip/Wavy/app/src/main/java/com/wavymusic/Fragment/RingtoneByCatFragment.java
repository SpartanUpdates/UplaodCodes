package com.wavymusic.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.wavymusic.Adapter.RingtoneAdapter;
import com.wavymusic.Model.SongModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.Utils.Utils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RingtoneByCatFragment extends Fragment {

    public static MediaPlayer mediaPlayer;
    public static LanguagePref sharedpreferences;
    public ArrayList<SongModel> songModelArrayList = new ArrayList<>();
    public RingtoneAdapter selectSongAdapter;
    Integer CategoryId = -1;
    RelativeLayout rlloadingpager;
    RecyclerView rvCategoryWiseTheme;
    LinearLayout llInternetCheck;
    Button btnRetry;
    String offlienResopnseData;
//    Long timestamps;
    SharedPreferences pref;
    //    String[] split_AllLan;
//    String[] split_selctedLan;
    APIInterface apiInterface;
    private String CatId;

    public static Fragment getInstance(int catid) {
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        RingtoneByCatFragment categoryWiseSongFragment = new RingtoneByCatFragment();
        categoryWiseSongFragment.setArguments(bundle);
        return categoryWiseSongFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CategoryId = getArguments().getInt("CategoryId");
        CatId = String.valueOf(CategoryId);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_song_by_cat, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = LanguagePref.a(getActivity());
        apiInterface = APIClient.getClient().create(APIInterface.class);
        bindView(rootView);
        SetListener();
        SetThemeAdapter();
        if (songModelArrayList != null && songModelArrayList.size() == 0) {
//            if (Utils.checkConnectivity(getActivity(), false)) {
//                String id = pref.getString(CatId, null);
//                if (id != null && !id.equals("")) {
//                    getOfflineCategory(getActivity(), CatId);
//                    if (offlienResopnseData != null && timestamps != null) {
//                        new LoadOfflineData().execute();
//                    }
//                }
//            } else {
//                String id = pref.getString(CatId, null);
//                if (id != null && !id.equals("")) {
//                    getOfflineCategory(getActivity(), CatId);
//                    if (offlienResopnseData != null) {
//                        new LoadOfflineData().execute();
//                    } else {
//                        llInternetCheck.setVisibility(View.VISIBLE);
//                        rlloadingpager.setVisibility(View.GONE);
//                        Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            }
            String id = pref.getString(CatId, null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(getActivity(), CatId);
                if (offlienResopnseData != null) {
                    new LoadOfflineData().execute();
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    rlloadingpager.setVisibility(View.GONE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            SetThemeAdapter();
        }
        return rootView;
    }

    private void bindView(View view) {
        rvCategoryWiseTheme = view.findViewById(R.id.rv_onlinesong);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlloadingpager = view.findViewById(R.id.rl_load_onlinesong);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void SetThemeAdapter() {
        selectSongAdapter = new RingtoneAdapter(getActivity(), songModelArrayList, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvCategoryWiseTheme.setLayoutManager(mLayoutManager);
        rvCategoryWiseTheme.setAdapter(selectSongAdapter);
        selectSongAdapter.notifyDataSetChanged();
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
    }


    public void rePlayAudio(final int n, final boolean b) {
        if (b) {
            this.stopPlaying(mediaPlayer);
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.reset();
                mediaPlayer.setDataSource(Utils.INSTANCE.getMusicFolderPath() + File.separator + songModelArrayList.get(n).getSongUrl());
//                FinalMusicPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(n).getSongUrl();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.prepareAsync();
            return;
        }
    }


    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    private void GetSongByCategory() {
        rlloadingpager.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId, AppConstant.DefaultCategoryId + LanguagePref.a(getActivity()).a("pref_key_language_list", "22"));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
//                        String SoundUrl = jsonObj.getString("souns_url");
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            if (CategoryId == Catid) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                                    SongModel songModel = new SongModel();
                                    songModel.setSongCategoryId(songJSONObject.getString("id"));
                                    songModel.setSongName(songJSONObject.getString("sound_filename"));
                                    songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                    songModel.setSongfull_url(AppConstant.SoundUrl + songJSONObject.getString("sound_file"));
                                    songModel.setSongSize(songJSONObject.getString("sound_size"));
                                    songModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfMusicFolder).getAbsolutePath() + File.separator + songModel.getSongUrl());
                                    songModelArrayList.add(songModel);
                                }
                            }
                        }
                        selectSongAdapter.notifyDataSetChanged();
                        rlloadingpager.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                int Catid = Integer.parseInt(jsonObj.getString("id"));
                if (CategoryId == Catid) {
                    JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                        SongModel songModel = new SongModel();
                        songModel.setSongCategoryId(songJSONObject.getString("id"));
                        songModel.setSongName(songJSONObject.getString("sound_filename"));
                        songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                        songModel.setSongfull_url(AppConstant.SoundUrl + songJSONObject.getString("sound_file"));
                        songModel.setSongSize(songJSONObject.getString("sound_size"));
                        songModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfMusicFolder).getAbsolutePath() + File.separator + songModel.getSongUrl());
                        songModelArrayList.add(songModel);
                    }
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            selectSongAdapter.notifyDataSetChanged();
        }
    }

}
