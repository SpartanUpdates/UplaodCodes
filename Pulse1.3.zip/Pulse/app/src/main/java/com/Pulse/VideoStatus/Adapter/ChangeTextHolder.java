package com.Pulse.VideoStatus.Adapter;

import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.widget.EditText;

import com.Pulse.VideoStatus.R;


public class ChangeTextHolder extends ViewHolder {
    public EditText etDynamicTextMessage;

    public ChangeTextHolder(View view) {
        super(view);
        this.etDynamicTextMessage = (EditText) view.findViewById(R.id.et_row_single);
    }

}