package com.esc.socialmediacleaner.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import com.google.common.primitives.Ints;

public class ScaleImageView extends ImageView {
    private ImageChangeListener imageChangeListener;
    private boolean scaleToWidth = false;

    public interface ImageChangeListener {
        void changed(boolean z);
    }

    public ScaleImageView(Context context) {
        super(context);
        init();
    }

    public ScaleImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    public ScaleImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    private void init() {
        setScaleType(ScaleType.CENTER_INSIDE);
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        ImageChangeListener imageChangeListener = this.imageChangeListener;
        if (imageChangeListener != null) {
            imageChangeListener.changed(bitmap == null);
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        ImageChangeListener imageChangeListener = this.imageChangeListener;
        if (imageChangeListener != null) {
            imageChangeListener.changed(drawable == null);
        }
    }

    public void setImageResource(int i) {
        super.setImageResource(i);
    }

    public ImageChangeListener getImageChangeListener() {
        return this.imageChangeListener;
    }

    public void setImageChangeListener(ImageChangeListener imageChangeListener) {
        this.imageChangeListener = imageChangeListener;
    }

    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        int i3 = 0;
        if (mode == Ints.MAX_POWER_OF_TWO || mode == Integer.MIN_VALUE) {
            this.scaleToWidth = true;
        } else if (mode2 == Ints.MAX_POWER_OF_TWO || mode2 == Integer.MIN_VALUE) {
            this.scaleToWidth = false;
        } else {
            throw new IllegalStateException("width or height needs to be set to match_parent or a specific dimension");
        }
        if (getDrawable() == null || getDrawable().getIntrinsicWidth() == 0) {
            super.onMeasure(i, i2);
            return;
        }
        if (this.scaleToWidth) {
            i = getDrawable().getIntrinsicWidth();
            i2 = getDrawable().getIntrinsicHeight();
            mode = (size * i2) / i;
            if (size2 <= 0 || mode <= size2) {
                size2 = mode;
            } else {
                size = (i * size2) / i2;
            }
            setScaleType(ScaleType.CENTER_CROP);
            setMeasuredDimension(size, size2);
        } else {
            if (!(getParent() == null || getParent().getParent() == null)) {
                i3 = (((RelativeLayout) getParent().getParent()).getPaddingTop() + 0) + ((RelativeLayout) getParent().getParent()).getPaddingBottom();
            }
            setMeasuredDimension((getDrawable().getIntrinsicWidth() * size2) / getDrawable().getIntrinsicHeight(), size2 - i3);
        }
    }
}
