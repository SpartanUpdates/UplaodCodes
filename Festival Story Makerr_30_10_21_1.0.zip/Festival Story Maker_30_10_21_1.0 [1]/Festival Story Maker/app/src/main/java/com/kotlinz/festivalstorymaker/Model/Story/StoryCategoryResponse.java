package com.kotlinz.festivalstorymaker.Model.Story;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class StoryCategoryResponse {

	@SerializedName("success")
	private String success;

	@SerializedName("response")
	private StoryCategoryResponse storyCategoryResponse;

	@SerializedName("data")
	private ArrayList<StoryCategoryData> data;

	@SerializedName("total_records")
	private String totalRecords;

	@SerializedName("total_pages")
	private String totalPages;

	@SerializedName("current_page_number")
	private String currentPageNumber;

	public String getSuccess(){
		return success;
	}

	public StoryCategoryResponse getStoryCategoryResponse(){
		return storyCategoryResponse;
	}

	public ArrayList<StoryCategoryData> getData(){
		return data;
	}

	public String getTotalRecords(){
		return totalRecords;
	}

	public String getTotalPages(){
		return totalPages;
	}

	public String getCurrentPageNumber(){
		return currentPageNumber;
	}
}