package com.name.nameart.ThropicalData;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.MyUtils.AppCommon;
import com.name.nameart.R;

import java.util.ArrayList;


public class ThropicalEnd extends AppCompatActivity implements View.OnClickListener {
    private ThropicalAdAdapter appListAdapter;
    private LinearLayout ll_ad_container;
    TextView no;
    private TextView privacypolicy;
    RelativeLayout rlmoreappshead;
    RecyclerView rv_splash;
    TextView txtMore;
    TextView yes;

    @Override
    public void onBackPressed() {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.thropical_end);
        bindview();
        new Handler().postDelayed(new Runnable() {

            public void run() {
                ThropicalEnd thropicalEnd = ThropicalEnd.this;
            }
        }, 1000);
        this.rv_splash = (RecyclerView) findViewById(R.id.rv_splash);
        this.rlmoreappshead = (RelativeLayout) findViewById(R.id.rlmoreappshead);
        this.txtMore = (TextView) findViewById(R.id.txtMore);
        AppCommon.appDataArrayList.clear();
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://play-lh.googleusercontent.com/o5SgCtdxQCMMx_Y8NHZMW2snuH2dpXUFF29ViNShfl1x6MAjhStRsrUBQ2gXA7q-rtQ=s180", "Radio Fm Without Internet", "https://play.google.com/store/apps/details?id=fmradio.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://play-lh.googleusercontent.com/C60r3FIsIEBrZTD4TBdQr9sTryZG5ntJLxVhRFrslCSr4kj5Y19-iGRmXtd6uVJAlSA0=s180", "Intro Maker With Music", "https://play.google.com/store/apps/details?id=intromaker.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://play-lh.googleusercontent.com/iKTwVYAQWrvtnZV-TEURi_P5-gSLcAYLU9N4-ZR6qlRpUI0l8teo-7cVnaz2pKqgUD8=s180", "Best Quotes and Status", "https://play.google.com/store/apps/details?id=quotescreator.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/6LmYJ1S2axnCshO5Dc3QrU2pQnoTeObZxwQW7FFbGHnNv4H2iJ8rx0MMqz0ka_flND7G=s180", "Sky Filter", "https://play.google.com/store/apps/details?id=skyfiltter.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/ctVF61r20PCPHjUuwipQL-Y43n6-HdIAPMApNLQQngY4dKvKT3aPAJiAA2tIyGhvcXOY=s180", "Video Par Photo Lagane Wala App", "https://play.google.com/store/apps/details?id=videopephoto.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/8towXbsWXuevNgthy9hx6G-Rr-MR0wpFruBM2wnt6ZEvnMMd4iqIEhDCZEa4xiMjUd0=s180", "Scrap Book", "https://play.google.com/store/apps/details?id=scapbook.makepic.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/gZwEJc_lIgjQB3D5oZCfsXRkiypZ3Ve7jC-H4RvGKc9EkXTu8cSqbdiWhRB-jL78hhMY=s180", "Phone Backup : All Backup & Restore", "https://play.google.com/store/apps/details?id=phonebackup.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/5a1zMTmPb9ppxY_iOe47OUCZM4-nbRbhmV8oz041spWmiHDFv2OqgJa9j-m6SRTeDw=s180", "Screen Mirroring with All TV", "https://play.google.com/store/apps/details?id=screenmirroring.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/hzcpCikmuPALbC9fgw49Z2-rbLUvX6HGaWxaO-0E7SdcoVOGAYIxBE-dYvy9w0uLj5EV=s180", "Text Repeater For Messages", "https://play.google.com/store/apps/details?id=textrepeater.thropical.tool"));
        AppCommon.appDataArrayList.add(new ThropicalDataList("https://lh3.googleusercontent.com/gNmlqlM4ieX0LHNaAtKReiOLaYoSXS8hIgXdK7qfftdoieIyuIuikkRGN7ZfUVrWtlE=s180", "Wedding Card & Video Maker", "https://play.google.com/store/apps/details?id=wedding.movie.cards.thropical.tool"));
        setRecyclerView(AppCommon.appDataArrayList);
        this.txtMore.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    ThropicalEnd.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(AppCommon.google_play_account_link)));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(ThropicalEnd.this, "Something went wrong!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    private void setRecyclerView(ArrayList<ThropicalDataList> arrayList) {
        this.rv_splash.setLayoutManager(new GridLayoutManager((Context) this, 1, RecyclerView.HORIZONTAL, false));
        ThropicalAdAdapter thropicalAdAdapter = new ThropicalAdAdapter(this, arrayList);
        this.appListAdapter = thropicalAdAdapter;
        this.rv_splash.setAdapter(thropicalAdAdapter);
    }

    private void bindview() {
        this.yes = (TextView) findViewById(R.id.yes);
        this.no = (TextView) findViewById(R.id.no);
        this.yes.setOnClickListener(this);
        this.no.setOnClickListener(this);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.ll_ad_container);
        this.ll_ad_container = linearLayout;
        TextView textView = (TextView) findViewById(R.id.privacypolicy);
        this.privacypolicy = textView;
        textView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (!AppCommon.CheckNet(ThropicalEnd.this).booleanValue() || AppCommon.company_policy_about_use == null || AppCommon.company_policy_about_use.equals("")) {
                    Toast.makeText(ThropicalEnd.this.getApplicationContext(), "Please Check Internet Connection", Toast.LENGTH_SHORT).show();
                    return;
                }
                ThropicalEnd.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(AppCommon.company_policy_about_use)));
            }
        });
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.no) {
            finish();
        } else if (id == R.id.yes) {
            setResult(-1);
            finish();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}
