package com.example.knowledgetrivia.controller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.knowledgetrivia.R;

import java.util.ArrayList;

public class SSAdapter extends ArrayAdapter<String> {
    private Context context;
    private ArrayList<String> myScore;
    private ArrayList<String> mylevel;

    SSAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        super(context, R.layout.listview_showing_row, R.id.textview1, arrayList);
        this.context = context;
        this.mylevel = arrayList;
        this.myScore = arrayList2;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        view = ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.listview_showing_row, viewGroup, false);
        TextView textView = (TextView) view.findViewById(R.id.textview2);
        ((TextView) view.findViewById(R.id.textview1)).setText((CharSequence) this.mylevel.get(i));
        textView.setText((CharSequence) this.myScore.get(i));
        return view;
    }
}
