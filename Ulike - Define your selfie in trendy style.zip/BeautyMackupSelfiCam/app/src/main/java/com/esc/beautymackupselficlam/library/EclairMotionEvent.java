package com.esc.beautymackupselficlam.library;

import android.view.MotionEvent;

public class EclairMotionEvent
  extends WrapMotionEvent
{
  protected EclairMotionEvent(MotionEvent paramMotionEvent)
  {
    super(paramMotionEvent);
  }
  
  public int getPointerCount()
  {
    return this.event.getPointerCount();
  }
  
  public int getPointerId(int paramInt)
  {
    return this.event.getPointerId(paramInt);
  }
  
  public float getX(int paramInt)
  {
    return this.event.getX(paramInt);
  }
  
  public float getY(int paramInt)
  {
    return this.event.getY(paramInt);
  }
}

