package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import com.esc.gesturelockscreen.Other.BitmapUtils;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.Other.WallpaperLoader;
import com.esc.gesturelockscreen.R;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WallpaperActivity extends Activity {
    public static int[] backgrounds = new int[]{R.drawable.background1, R.drawable.background2, R.drawable.background3, R.drawable.background4, R.drawable.background5, R.drawable.background6};
    private static int selectedId = -1;
    private ExecutorService mExecutor;
    private GridView mGridView;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private File path = null;
    private int Height;
    private int Width;
    private Activity mContext;

    private class WallpaperAdapter extends BaseAdapter {
        private LayoutInflater mInflater;
        Context c;

        private class ViewHolder {
            final ImageView image;
            final View selectedCheck;
            final View selectedView;

            ViewHolder(View v) {
                this.image = (ImageView) v.findViewById(R.id.image_thumb);
                this.selectedView = v.findViewById(R.id.selected);
                this.selectedCheck = v.findViewById(R.id.selectedcheck);
            }
        }

        WallpaperAdapter(Context context) {
            mInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            WallpaperActivity.selectedId = SettingsUtils.getInt(SettingsKeys.KEY_INDEX_WALLPAPER, 0);
        }

        public int getCount() {
            return WallpaperActivity.backgrounds.length;
        }

        public Integer getItem(int i) {
            return Integer.valueOf(i);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int position, View convertView, ViewGroup parent)
        {

            ViewHolder mHolder;
            int i = 0;
            int i2 = 0;
            View row = convertView;
            if (row == null) {
                row = this.mInflater.inflate(R.layout.adapter_item_background, parent, false);
                mHolder = new ViewHolder(row);
                row.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) row.getTag();
            }
            WallpaperLoader.getInstace().displayImage(WallpaperActivity.backgrounds[position], mHolder.image);
            View view = mHolder.selectedView;
            if (position != WallpaperActivity.selectedId) {
                i = 4;
            }
            view.setVisibility(i);
            View view2 = mHolder.selectedCheck;
            if (position != WallpaperActivity.selectedId) {
                i2 = 8;
            }
            view2.setVisibility(i2);
            return row;
        }
    }

    protected void onStart() {
        super.onStart();
        overridePendingTransition(0, 0);
    }

    public void onLowMemory() {
        WallpaperLoader.getInstace().clearCache();
        super.onLowMemory();
    }

    public void onBackPressed(View v) {
        finish();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper);
        this.mContext = this;
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.Width = displayMetrics.widthPixels;
        this.Height = displayMetrics.heightPixels;
        this.mGridView = (GridView) findViewById(R.id.grid_view);
        WallpaperLoader.init(this);
        this.mGridView.setAdapter(new WallpaperAdapter(this));
        this.mGridView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                WallpaperActivity.selectedId = arg2;
                ((WallpaperAdapter) arg0.getAdapter()).notifyDataSetChanged();
            }
        });
    }

    public void onSaveDone(View v) {
        if (selectedId >= 0) {
            SettingsUtils.saveUserWallpaper(null);
            SettingsUtils.putInt(SettingsKeys.KEY_INDEX_WALLPAPER, selectedId);
            SettingsUtils.putBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false);
            setResult(-1);
        }
        finish();
    }

    public void onUserBackground(View v) {
        try {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction("android.intent.action.GET_CONTENT");
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 2);
        } catch (Exception e) {
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == -1) {
            save(data.getData());
        }
    }

    private void save(final Uri mSourceUri) {
        if (mSourceUri == null) {
            postErrorOnMainThread();
            return;
        }
        findViewById(R.id.progress_image).setVisibility(View.VISIBLE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int mViewWidth = dm.widthPixels;
        final int mViewHeight = dm.densityDpi;
        this.mExecutor = Executors.newSingleThreadExecutor();
        this.mExecutor.submit(new Runnable() {
            public void run() {
                boolean done = false;
                int maxSize = BitmapUtils.getMaxSize();
                int requestSize = Math.max(mViewWidth, mViewHeight);
                if (requestSize == 0) {
                    requestSize = maxSize;
                }
                try {
                    Bitmap sampledBitmap = BitmapUtils.decodeSampledBitmapFromUri(WallpaperActivity.this, mSourceUri, requestSize);
                    WallpaperActivity.this.path = new File(WallpaperActivity.this.getFilesDir(), "wallpaper_at_" + System.currentTimeMillis() + ".png");
                    OutputStream outputStream = WallpaperActivity.this.getContentResolver().openOutputStream(Uri.fromFile(WallpaperActivity.this.path));
                    if (outputStream != null) {
                        sampledBitmap.compress(CompressFormat.JPEG, 90, outputStream);
                        done = true;
                    } else {
                        done = false;
                    }
                    BitmapUtils.closeQuietly(outputStream);
                } catch (IOException e) {
                    done = false;
                    BitmapUtils.closeQuietly(null);
                } catch (OutOfMemoryError e2) {
                    WallpaperActivity.this.postErrorOnMainThread();
                    return;
                } catch (Exception e3) {
                    WallpaperActivity.this.postErrorOnMainThread();
                    return;
                } catch (Throwable th) {
                    BitmapUtils.closeQuietly(null);
                }
                final boolean success = done;
                WallpaperActivity.this.mHandler.post(new Runnable() {
                    public void run() {
                        if (success) {
                            WallpaperActivity.this.findViewById(R.id.progress_image).setVisibility(View.GONE);
                            SettingsUtils.saveUserWallpaper(WallpaperActivity.this.path.getAbsolutePath());
                            SettingsUtils.putBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, false);
                            Toast.makeText(WallpaperActivity.this.getApplicationContext(), "Background Changed ", Toast.LENGTH_SHORT).show();
                            WallpaperActivity.this.setResult(-1);
                            WallpaperActivity.this.finish();
                            return;
                        }
                        WallpaperActivity.this.postErrorOnMainThread();
                    }
                });
            }
        });
    }

    protected void postErrorOnMainThread() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            findViewById(R.id.progress_image).setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(), "Error occured", Toast.LENGTH_SHORT).show();
            return;
        }
        this.mHandler.post(new Runnable() {
            @Override
            public void run() {
                WallpaperActivity.this.findViewById(R.id.progress_image).setVisibility(View.GONE);
                Toast.makeText(WallpaperActivity.this.getApplicationContext(), "Error occured", Toast.LENGTH_SHORT).show();
            }
        });
    }

    Activity getmyactivity() {
        return this;
    }
}
