package com.example.statussaver.util;

import android.content.ClipboardManager;

public abstract class ClipboardListener implements ClipboardManager.OnPrimaryClipChangedListener {

}
