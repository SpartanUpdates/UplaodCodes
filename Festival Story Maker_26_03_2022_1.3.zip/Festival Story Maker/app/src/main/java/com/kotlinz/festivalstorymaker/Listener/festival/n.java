package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.FestivalImageListAdapter;

public class n implements View.OnClickListener {
    public final  int n;
    public final  FestivalImageListAdapter o;

    public n(FestivalImageListAdapter festivalImageListAdapter, int i) {
        this.o = festivalImageListAdapter;
        this.n = i;
    }

    public void onClick(View view) {
        FestivalImageListAdapter festivalImageListAdapter = this.o;
        festivalImageListAdapter.t = this.n;
        festivalImageListAdapter.notifyDataSetChanged();
        festivalImageListAdapter = this.o;
        festivalImageListAdapter.r.a(this.n, festivalImageListAdapter.s);
    }

}
