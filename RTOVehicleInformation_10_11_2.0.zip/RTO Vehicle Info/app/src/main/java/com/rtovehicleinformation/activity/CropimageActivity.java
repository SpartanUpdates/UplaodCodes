package com.rtovehicleinformation.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.rtovehicleinformation.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CropimageActivity extends AppCompatActivity {
    String image;
    @BindView(R.id.quick_start_cropped_image)
    ImageView quick_start_cropped_image;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_cropimage);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        this.image = getIntent().getStringExtra("imagepath");
        Glide.with(this).load(getIntent().getStringExtra("imagepath")).into(this.quick_start_cropped_image);
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CropimageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }
}
