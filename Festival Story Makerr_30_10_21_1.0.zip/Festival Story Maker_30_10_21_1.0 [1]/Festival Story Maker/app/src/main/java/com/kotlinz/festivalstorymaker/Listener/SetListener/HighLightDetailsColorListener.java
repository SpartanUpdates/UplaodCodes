package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a;

public final  class HighLightDetailsColorListener implements a {
    public final HighlightDetailsDetailActivity activity;

    public HighLightDetailsColorListener(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
        this.activity = highlightDetailsDetailActivity;
    }

    public final void D(int i) {
        this.activity.D(i);
    }
}
