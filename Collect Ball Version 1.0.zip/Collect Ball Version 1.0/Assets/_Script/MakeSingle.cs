﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeSingle : MonoBehaviour
{
    public GameObject InterstitialFbAds, BannerFbAds, RewaredFbAds;

    public GameObject InterstitialUnityAds, BannerUnityAds, RewaredUnityAds;

    public void Awake()
    {
        GameObject go = GameObject.FindGameObjectWithTag("InterstitialFbAds");
        {
            if (go == null)
                Instantiate(InterstitialFbAds);
        }
        GameObject go1 = GameObject.FindGameObjectWithTag("BannerFbAds");
        {
            if (go1 == null)
                Instantiate(BannerFbAds);
        }
        GameObject go2 = GameObject.FindGameObjectWithTag("RewaredFbAds");
        {
            if (go2 == null)
                Instantiate(RewaredFbAds);
        }
        GameObject go3 = GameObject.FindGameObjectWithTag("InterstitialUnityAds");
        {
            if (go3 == null)
                Instantiate(InterstitialUnityAds);
        }
        GameObject go4 = GameObject.FindGameObjectWithTag("BannerUnityAds");
        {
            if (go4 == null)
                Instantiate(BannerUnityAds);
        }
        GameObject go5 = GameObject.FindGameObjectWithTag("RewaredUnityAds");
        {
            if (go5 == null)
                Instantiate(RewaredUnityAds);
        }
    }
}
