package com.kotlinz.festivalstorymaker.Model.DashBord;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class AllModuleResponse {

	@SerializedName("data")
	private ArrayList<AllModule> data;

	@SerializedName("status")
	private String status;

	public ArrayList<AllModule> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}