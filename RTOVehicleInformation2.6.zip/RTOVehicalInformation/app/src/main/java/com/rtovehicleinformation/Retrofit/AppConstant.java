//package com.rtovehicleinformation.Retrofit;
//
//public class AppConstant {
//    public static String BASEURL = "";
//}
