package com.kotlinz.festivalstorymaker.sticker;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Build;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import androidx.annotation.RequiresApi;

import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StickerView  extends FrameLayout
{
    public int A;
    public com.kotlinz.festivalstorymaker.sticker.e B;
    public a C;
    public long D;
    public int E;
    public boolean e;
    public final boolean f;
    public final boolean g;
    public final List<com.kotlinz.festivalstorymaker.sticker.e> h;
    public final List<com.kotlinz.festivalstorymaker.sticker.a> i;
    public final Paint j;
    public final RectF k;
    public final Matrix l;
    public final Matrix m;
    public final Matrix n;
    public final float[] o;
    public final float[] p;
    public final float[] q;
    public final PointF r;
    public final float[] s;
    public PointF t;
    public final int u;
    public com.kotlinz.festivalstorymaker.sticker.a v;
    public float w;
    public float x;
    public float y;
    public float z;


    public StickerView(final Context context) {
        this(context, null);
    }

    public StickerView(final Context context, final AttributeSet set) {
        this(context, set, 0);
    }

    public StickerView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.h = new ArrayList<com.kotlinz.festivalstorymaker.sticker.e>();
        this.i = new ArrayList<com.kotlinz.festivalstorymaker.sticker.a>(4);
        this.j = new Paint();
        this.k = new RectF();
        this.l = new Matrix();
        this.m = new Matrix();
        this.n = new Matrix();
        this.o = new float[8];
        this.p = new float[8];
        this.q = new float[2];
        this.r = new PointF();
        this.s = new float[2];
        this.t = new PointF();
        this.y = 0.0f;
        this.z = 0.0f;
        this.A = 0;
        this.D = 0L;
        this.E = 200;
        this.u = ViewConfiguration.get(context).getScaledTouchSlop();
        TypedArray obtainStyledAttributes = null;
        try {
            final TypedArray typedArray = obtainStyledAttributes = context.obtainStyledAttributes(set, R.styleable.StickerView);
            this.e = typedArray.getBoolean(4, false);
            obtainStyledAttributes = typedArray;
            this.f = typedArray.getBoolean(3, false);
            obtainStyledAttributes = typedArray;
            this.g = typedArray.getBoolean(2, false);
            obtainStyledAttributes = typedArray;
            this.j.setAntiAlias(true);
            obtainStyledAttributes = typedArray;
            this.j.setColor(typedArray.getColor(1, 0));
            obtainStyledAttributes = typedArray;
            this.j.setAlpha(typedArray.getInteger(0, 0));
            obtainStyledAttributes = typedArray;
            this.f();
            typedArray.recycle();
        }
        finally {
            if (obtainStyledAttributes != null) {
                obtainStyledAttributes.recycle();
            }
        }
    }

    public void a(final e b, final int n) {
        final float n2 = (float)this.getWidth();
        final float n3 = (float)this.getHeight();
        final float n4 = n2 - b.i();
        final float n5 = n3 - b.g();
        float n6;
        if ((n & 0x2) > 0) {
            n6 = n5 / 4.0f;
        }
        else if ((n & 0x10) > 0) {
            n6 = n5 * 0.75f;
        }
        else {
            n6 = n5 / 2.0f;
        }
        float n7;
        if ((n & 0x4) > 0) {
            n7 = n4 / 4.0f;
        }
        else if ((n & 0x8) > 0) {
            n7 = n4 * 0.75f;
        }
        else {
            n7 = n4 / 2.0f;
        }
        b.g.postTranslate(n7, n6);
        final float n8 = (float)this.getWidth();
        final c c = (com.kotlinz.festivalstorymaker.sticker.c)b;
        final float n9 = n8 / c.j.getIntrinsicWidth();
        final float n10 = this.getHeight() / (float)c.j.getIntrinsicHeight();
        float n11 = n9;
        if (n9 > n10) {
            n11 = n10;
        }
        final Matrix g = b.g;
        final float n12 = n11 / 2.0f;
        g.postScale(n12, n12, (float)(this.getWidth() / 2), (float)(this.getHeight() / 2));
        this.B = b;
        this.h.add(b);
        final a c2 = this.C;
        if (c2 != null) {
            c2.c(b);
        }
        this.invalidate();
    }

    public float b(final float n, final float n2, final float n3, final float n4) {
        final double n5 = n - n3;
        final double n6 = n2 - n4;
        return (float)Math.sqrt(n6 * n6 + n5 * n5);
    }

    public float c(final MotionEvent motionEvent) {
        if (motionEvent != null && motionEvent.getPointerCount() >= 2) {
            return this.b(motionEvent.getX(0), motionEvent.getY(0), motionEvent.getX(1), motionEvent.getY(1));
        }
        return 0.0f;
    }

    public float d(final float n, final float n2, final float n3, final float n4) {
        return (float)Math.toDegrees(Math.atan2(n2 - n4, n - n3));
    }

    public void dispatchDraw(final Canvas canvas) {
        super.dispatchDraw(canvas);
        final int n = 0;
        for (int i = 0; i < this.h.size(); ++i) {
            final e e = this.h.get(i);
            if (e != null) {
                final c c = (com.kotlinz.festivalstorymaker.sticker.c)e;
                canvas.save();
                canvas.concat(c.g);
                c.j.setBounds(c.k);
                c.j.draw(canvas);
                canvas.restore();
            }
        }
        if (this.B != null && (this.f || this.e)) {
            final e b = this.B;
            final float[] o = this.o;
            if (b == null) {
                Arrays.fill(o, 0.0f);
            }
            else {
                b.e(this.p);
                b.g.mapPoints(o, this.p);
            }
            final float[] o2 = this.o;
            final float n2 = o2[0];
            final float n3 = o2[1];
            final float n4 = o2[2];
            final float n5 = o2[3];
            final float n6 = o2[4];
            final float n7 = o2[5];
            final float n8 = o2[6];
            final float n9 = o2[7];
            if (this.f) {
                final Paint j = this.j;
                final float n10 = n9;
                final float n11 = n8;
                final float n12 = n7;
                final float n13 = n6;
                canvas.drawLine(n2, n3, n4, n5, j);
                canvas.drawLine(n2, n3, n13, n12, this.j);
                canvas.drawLine(n4, n5, n11, n10, this.j);
                canvas.drawLine(n11, n10, n13, n12, this.j);
            }
            if (this.e) {
                final float d = this.d(n8, n9, n6, n7);
                for (int k = n; k < this.i.size(); ++k) {
                    final com.kotlinz.festivalstorymaker.sticker.a a = this.i.get(k);
                    final int o3 = a.o;
                    if (o3 != 0) {
                        if (o3 != 1) {
                            if (o3 != 2) {
                                if (o3 == 3) {
                                    this.g(a, n8, n9, d);
                                }
                            }
                            else {
                                this.g(a, n6, n7, d);
                            }
                        }
                        else {
                            this.g(a, n4, n5, d);
                        }
                    }
                    else {
                        this.g(a, n2, n3, d);
                    }
                    canvas.drawCircle(a.m, a.n, a.l, this.j);
                    canvas.save();
                    canvas.concat(a.g);
                    a.j.setBounds(a.k);
                    a.j.draw(canvas);
                    canvas.restore();
                }
            }
        }
    }

    public float e(final MotionEvent motionEvent) {
        if (motionEvent != null && motionEvent.getPointerCount() >= 2) {
            return this.d(motionEvent.getX(0), motionEvent.getY(0), motionEvent.getX(1), motionEvent.getY(1));
        }
        return 0.0f;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void f() {
        final com.kotlinz.festivalstorymaker.sticker.a a = new com.kotlinz.festivalstorymaker.sticker.a(com.kotlinz.festivalstorymaker.Other.a.e(this.getContext(),  R.drawable.ic_delete_sticker), 0);
        a.p = new b();
        final com.kotlinz.festivalstorymaker.sticker.a a2 = new com.kotlinz.festivalstorymaker.sticker.a(this.getContext().getDrawable(R.drawable.ic_resize_sticker), 3);
        a2.p = new h();
        final com.kotlinz.festivalstorymaker.sticker.a a3 = new com.kotlinz.festivalstorymaker.sticker.a(this.getContext().getDrawable(R.drawable.icon_flip), 1);
        a3.p = new d();
        this.i.clear();
        this.i.add(a);
        this.i.add(a2);
        this.i.add(a3);
    }

    public void g(final com.kotlinz.festivalstorymaker.sticker.a a, final float m, final float n, final float n2) {
        a.m = m;
        a.n = n;
        a.g.reset();
        a.g.postRotate(n2, (float)(a.i() / 2), (float)(a.g() / 2));
        a.g.postTranslate(m - a.i() / 2, n - a.g() / 2);
    }

    public e getCurrentSticker() {
        return this.B;
    }

    public List<com.kotlinz.festivalstorymaker.sticker.a> getIcons() {
        return this.i;
    }

    public int getMinClickDelayTime() {
        return this.E;
    }

    public a getOnStickerOperationListener() {
        return this.C;
    }

    public int getStickerCount() {
        return this.h.size();
    }

    public com.kotlinz.festivalstorymaker.sticker.a h() {
        for (final com.kotlinz.festivalstorymaker.sticker.a a : this.i) {
            final float n = a.m - this.w;
            final float n2 = a.n - this.x;
            final double n3 = n2 * n2 + n * n;
            final float l = a.l;
            if (n3 <= Math.pow(l + l, 2.0)) {
                return a;
            }
        }
        return null;
    }

    public e i() {
        for (int i = this.h.size() - 1; i >= 0; --i) {
            if (this.j(this.h.get(i), this.w, this.x)) {
                return this.h.get(i);
            }
        }
        return null;
    }

    public boolean j(final e e, final float n, final float n2) {
        final float[] s = this.s;
        s[0] = n;
        s[1] = n2;
        this.e = e.d(s);
        this.invalidate();
        return e.d(this.s);
    }

    public boolean onInterceptTouchEvent(final MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        this.w = motionEvent.getX();
        this.x = motionEvent.getY();
        return this.h() != null || this.i() != null;
    }

    public void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        super.onLayout(b, n, n2, n3, n4);
        if (b) {
            final RectF k = this.k;
            k.left = (float)n;
            k.top = (float)n2;
            k.right = (float)n3;
            k.bottom = (float)n4;
        }
    }

    public void onSizeChanged(int i, final int n, final int n2, final int n3) {
        super.onSizeChanged(i, n, n2, n3);
        e e;
        float n4;
        float n5;
        float n6;
        float n7;
        float n8;
        Matrix l;
        float n9;
        for (i = 0; i < this.h.size(); ++i) {
            e = this.h.get(i);
            if (e != null) {
                this.l.reset();
                n4 = (float)this.getWidth();
                n5 = (float)this.getHeight();
                n6 = (float)e.i();
                n7 = (float)e.g();
                this.l.postTranslate((n4 - n6) / 2.0f, (n5 - n7) / 2.0f);
                if (n4 < n5) {
                    n8 = n4 / n6;
                }
                else {
                    n8 = n5 / n7;
                }
                l = this.l;
                n9 = n8 / 2.0f;
                l.postScale(n9, n9, n4 / 2.0f, n5 / 2.0f);
                e.g.reset();
                e.g.set(this.l);
                this.invalidate();
            }
        }
    }

    public boolean onTouchEvent(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        if (this.C != null) {
            final e b = this.B;
            if (b != null) {
                if (b == null) {
                    throw null;
                }
                b.f(new PointF());
                this.C.h(this.B, this.o);
            }
        }
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                final long uptimeMillis = SystemClock.uptimeMillis();
                if (this.A == 3) {
                    final com.kotlinz.festivalstorymaker.sticker.a v = this.v;
                    if (v != null && this.B != null) {
                        final com.kotlinz.festivalstorymaker.sticker.f p = v.p;
                        if (p != null) {
                            p.a(this, motionEvent);
                        }
                    }
                }
                if (this.A == 1 && Math.abs(motionEvent.getX() - this.w) < this.u && Math.abs(motionEvent.getY() - this.x) < this.u) {
                    final e b2 = this.B;
                    if (b2 != null) {
                        this.A = 4;
                        final a c = this.C;
                        if (c != null) {
                            c.g(b2);
                        }
                        if (uptimeMillis - this.D < this.E) {
                            final a c2 = this.C;
                            if (c2 != null) {
                                c2.i(this.B);
                            }
                        }
                    }
                }
                if (this.A == 1) {
                    final e b3 = this.B;
                    if (b3 != null) {
                        final a c3 = this.C;
                        if (c3 != null) {
                            c3.f(b3);
                        }
                    }
                }
                this.A = 0;
                this.D = uptimeMillis;
                return true;
            }
            if (actionMasked == 2) {
                final int a = this.A;
                Label_0504: {
                    if (a != 1) {
                        if (a != 2) {
                            if (a != 3) {
                                break Label_0504;
                            }
                            if (this.B == null) {
                                break Label_0504;
                            }
                            final com.kotlinz.festivalstorymaker.sticker.a v2 = this.v;
                            if (v2 == null) {
                                break Label_0504;
                            }
                            final com.kotlinz.festivalstorymaker.sticker.f p2 = v2.p;
                            if (p2 != null) {
                                p2.b(this, motionEvent);
                            }
                            break Label_0504;
                        }
                        else {
                            if (this.B == null) {
                                break Label_0504;
                            }
                            final float c4 = this.c(motionEvent);
                            final float e = this.e(motionEvent);
                            this.n.set(this.m);
                            final Matrix n = this.n;
                            final float n2 = c4 / this.y;
                            final PointF t = this.t;
                            n.postScale(n2, n2, t.x, t.y);
                            final Matrix n3 = this.n;
                            final float z = this.z;
                            final PointF t2 = this.t;
                            n3.postRotate(e - z, t2.x, t2.y);
                        }
                    }
                    else {
                        if (this.B == null) {
                            break Label_0504;
                        }
                        this.n.set(this.m);
                        this.n.postTranslate(motionEvent.getX() - this.w, motionEvent.getY() - this.x);
                    }
                    this.B.g.set(this.n);
                }
                this.invalidate();
                return true;
            }
            if (actionMasked != 5) {
                if (actionMasked != 6) {
                    return true;
                }
                if (this.A == 2) {
                    final e b4 = this.B;
                    if (b4 != null) {
                        final a c5 = this.C;
                        if (c5 != null) {
                            c5.a(b4);
                        }
                    }
                }
                this.A = 0;
                return true;
            }
            else {
                this.y = this.c(motionEvent);
                this.z = this.e(motionEvent);
                if (motionEvent.getPointerCount() < 2) {
                    this.t.set(0.0f, 0.0f);
                }
                else {
                    this.t.set((motionEvent.getX(1) + motionEvent.getX(0)) / 2.0f, (motionEvent.getY(1) + motionEvent.getY(0)) / 2.0f);
                }
                this.t = this.t;
                final e b5 = this.B;
                if (b5 != null && this.j(b5, motionEvent.getX(1), motionEvent.getY(1)) && this.h() == null) {
                    this.A = 2;
                    return true;
                }
            }
        }
        else {
            this.A = 1;
            this.w = motionEvent.getX();
            this.x = motionEvent.getY();
            final e b6 = this.B;
            if (b6 == null) {
                this.t.set(0.0f, 0.0f);
            }
            else {
                b6.h(this.t, this.q, this.s);
            }
            final PointF t3 = this.t;
            this.t = t3;
            this.y = this.b(t3.x, t3.y, this.w, this.x);
            final PointF t4 = this.t;
            this.z = this.d(t4.x, t4.y, this.w, this.x);
            final com.kotlinz.festivalstorymaker.sticker.a h = this.h();
            this.v = h;
            if (h != null) {
                this.A = 3;
                final com.kotlinz.festivalstorymaker.sticker.f p3 = h.p;
                if (p3 != null) {
                    p3.c(this, motionEvent);
                }
            }
            else {
                this.B = this.i();
            }
            final e b7 = this.B;
            if (b7 != null) {
                this.m.set(b7.g);
                if (this.g) {
                    this.h.remove(this.B);
                    this.h.add(this.B);
                }
                final a c6 = this.C;
                if (c6 != null) {
                    c6.b(this.B);
                }
            }
            boolean b8;
            if (this.v == null && this.B == null) {
                b8 = false;
            }
            else {
                this.invalidate();
                b8 = true;
            }
            if (!b8) {
                return false;
            }
        }
        return true;
    }

    public void setIcons(final List<com.kotlinz.festivalstorymaker.sticker.a> list) {
        this.i.clear();
        this.i.addAll(list);
        this.invalidate();
    }

    public interface a
    {
        void a(final e p0);

        void b(final e p0);

        void c(final e p0);

        void d(final e p0);

        void e(final e p0);

        void f(final e p0);

        void g(final e p0);

        void h(final e p0, final float[] p1);

        void i(final e p0);
    }
}
