package com.esc.gesturelockscreen.Other;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.esc.gesturelockscreen.R;

@SuppressLint({"ValidFragment"})
public class ColorDialogFragment extends DialogFragment {
  private int RGB;
  private SeekBar alphatize;
  private SeekBar blueSeek;
  private View dialogView;
  private SeekBar greenSeek;
  private IOnColorSelectedListener mListener;
  private SeekBar redSeek;
  private TextView tvAlpha;
  private TextView tvBlue;
  private TextView tvGreen;
  private TextView tvRed;

  static class runnablaclass1 implements Runnable {
    private final SeekBar val$alphatize;

    runnablaclass1(SeekBar seekBar) {
      this.val$alphatize = seekBar;
    }

    public void run() {
      this.val$alphatize.getProgressDrawable().setColorFilter(-12303292, Mode.SRC_IN);
      if (VERSION.SDK_INT >= 16) {
        this.val$alphatize.getThumb().setColorFilter(-12303292, Mode.SRC_IN);
      }
    }
  }

  static class runnablaclass2 implements Runnable {
    private final SeekBar val$alphatize;

    runnablaclass2(SeekBar seekBar) {
      this.val$alphatize = seekBar;
    }

    public void run() {
      this.val$alphatize.getProgressDrawable().setColorFilter(-3355444, Mode.SRC_IN);
      if (VERSION.SDK_INT >= 16) {
        this.val$alphatize.getThumb().setColorFilter(-3355444, Mode.SRC_IN);
      }
    }
  }

  static class AnonymousClass4 implements Runnable {
    private final int val$RGB;
    private final View val$colorView;

    AnonymousClass4(View view, int i) {
      this.val$colorView = view;
      this.val$RGB = i;
    }

    public void run() {
      this.val$colorView.setBackgroundColor(this.val$RGB);
    }
  }

  static class AnonymousClass9 implements Runnable {
    private final int val$RGB;
    private final View val$colorView;

    AnonymousClass9(View view, int i) {
      this.val$colorView = view;
      this.val$RGB = i;
    }

    public void run() {
      this.val$colorView.setBackgroundColor(this.val$RGB);
    }
  }

  public interface IOnColorSelectedListener {
    void onColorSelected(DialogFragment dialogFragment, int i);
  }

  @SuppressLint({"ValidFragment"})
  public ColorDialogFragment(IOnColorSelectedListener mListener) {
    this.mListener = mListener;
  }

  public static void showColorPicker(Activity activity, String tag, int color, IOnColorSelectedListener mListener) {
    ColorDialogFragment fr = new ColorDialogFragment(mListener);
    fr.RGB = color;
    fr.show(activity.getFragmentManager(), String.valueOf(tag));
  }

  public Dialog onCreateDialog(Bundle savedInstanceState) {
    Builder builder = new Builder(getActivity());
    this.dialogView = getActivity().getLayoutInflater().inflate(R.layout.dialog_color_fragment, null);
    this.alphatize = (SeekBar) this.dialogView.findViewById(R.id.alphatize);
    this.redSeek = (SeekBar) this.dialogView.findViewById(R.id.first);
    this.greenSeek = (SeekBar) this.dialogView.findViewById(R.id.second);
    this.blueSeek = (SeekBar) this.dialogView.findViewById(R.id.third);
    this.tvAlpha = (TextView) this.dialogView.findViewById(R.id.tv_alpha);
    this.tvRed = (TextView) this.dialogView.findViewById(R.id.tv_red);
    this.tvGreen = (TextView) this.dialogView.findViewById(R.id.tv_green);
    this.tvBlue = (TextView) this.dialogView.findViewById(R.id.tv_blue);
    View colorView = this.dialogView.findViewById(R.id.color_view);
    int alpha = Color.alpha(this.RGB);
    this.tvAlpha.setText(String.valueOf(alpha));
    previewColor(getActivity(), colorView, this.RGB);
    initializeSeekBars(getActivity(), alpha, this.alphatize, this.redSeek, this.greenSeek, this.blueSeek, colorView);
    this.redSeek.setProgress(Color.red(this.RGB));
    this.greenSeek.setProgress(Color.green(this.RGB));
    this.blueSeek.setProgress(Color.blue(this.RGB));
    builder.setView(this.dialogView);
    builder.setPositiveButton("SELECT", new OnClickListener() {
      @Override
      public void onClick(DialogInterface arg0, int arg1) {
        if (ColorDialogFragment.this.mListener != null) {
          ColorDialogFragment.this.mListener.onColorSelected(ColorDialogFragment.this, Color.argb(ColorDialogFragment.this.alphatize.getProgress(), ColorDialogFragment.this.redSeek.getProgress(), ColorDialogFragment.this.greenSeek.getProgress(), ColorDialogFragment.this.blueSeek.getProgress()));
        }
      }
    }).setNegativeButton("CANCEL", null);
    Dialog d = builder.create();
    d.requestWindowFeature(1);
    return d;
  }

  @SuppressLint({"NewApi"})
  private static void initializeAlphaSeekBarColor(Activity activity, View colorView, SeekBar alphatize, int color) {
    if (1.0d - ((((0.299d * ((double) Color.red(color))) + (0.587d * ((double) Color.green(color)))) + (0.114d * ((double) Color.blue(color)))) / 255.0d) < 0.5d) {
      activity.runOnUiThread(new runnablaclass1(alphatize));
    } else {
      activity.runOnUiThread(new runnablaclass2(alphatize));
    }
  }

  static void previewColor(Activity activity, View colorView, int RGB) {
    activity.runOnUiThread(new AnonymousClass4(colorView, RGB));
  }

  void initializeSeekBars(Activity activity, int alpha, SeekBar alphatize, SeekBar first, SeekBar second, SeekBar third, View colorView) {
    alphatize.setProgress(alpha);
    initializeSeekBarsColors(first, second, third);
    initializeAlphaSeekBarColor(activity, colorView, alphatize, this.RGB);
    SeekBar seekBar = first;
    final SeekBar seekBar4 = alphatize;
    final Activity finalActivity3 = activity;
    final View finalView3 = colorView;
    final SeekBar finalSeekBar6 = second;
    final SeekBar finalSeekBar7 = third;
    alphatize.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
      int RGB;
      int progress = 0;

      public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        this.progress = i;
        this.RGB = Color.argb(this.progress, seekBar.getProgress(), finalSeekBar6.getProgress(), finalSeekBar7.getProgress());
        ColorDialogFragment.previewColor(finalActivity3, finalView3, this.RGB);
        ColorDialogFragment.this.tvAlpha.setText(String.valueOf(this.progress));
        seekBar4.setProgress(this.progress);
      }

      public void onStartTrackingTouch(SeekBar seekBar) {
      }

      public void onStopTrackingTouch(SeekBar seekBar) {
      }
    });
    seekBar = alphatize;
    final SeekBar finalSeekBar = second;
    final SeekBar finalSeekBar1 = third;
    final Activity finalActivity = activity;
    final View finalView = colorView;
    first.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
      int RGB;
      int progress = 0;

      public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
        this.progress = progressValue;
        this.RGB = Color.argb(seekBar.getProgress(), this.progress, finalSeekBar.getProgress(), finalSeekBar1.getProgress());
        ColorDialogFragment.updateColorView(finalActivity, finalView, this.RGB);
        ColorDialogFragment.this.tvRed.setText(String.valueOf(this.progress));
      }

      public void onStartTrackingTouch(SeekBar seekBar) {
      }

      public void onStopTrackingTouch(SeekBar seekBar) {
      }
    });
    seekBar = alphatize;
    final SeekBar finalSeekBar2 = first;
    final SeekBar finalSeekBar3 = third;
    final Activity finalActivity1 = activity;
    final View finalView1 = colorView;
    second.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
      int RGB;
      int progress = 0;

      public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
        this.progress = progressValue;
        this.RGB = Color.argb(seekBar.getProgress(), finalSeekBar2.getProgress(), this.progress, finalSeekBar3.getProgress());
        ColorDialogFragment.updateColorView(finalActivity1, finalView1, this.RGB);
        ColorDialogFragment.this.tvGreen.setText(String.valueOf(this.progress));
      }

      public void onStartTrackingTouch(SeekBar seekBar) {
      }

      public void onStopTrackingTouch(SeekBar seekBar) {
      }
    });
    seekBar = alphatize;
    final SeekBar finalSeekBar4 = first;
    final SeekBar finalSeekBar5 = second;
    final Activity finalActivity2 = activity;
    final View finalView2 = colorView;
    third.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
      int RGB;
      int progress = 0;

      public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
        this.progress = progressValue;
        this.RGB = Color.argb(seekBar.getProgress(), finalSeekBar4.getProgress(), finalSeekBar5.getProgress(), this.progress);
        ColorDialogFragment.updateColorView(finalActivity2, finalView2, this.RGB);
        ColorDialogFragment.this.tvBlue.setText(String.valueOf(this.progress));
      }

      public void onStartTrackingTouch(SeekBar seekBar) {
      }

      public void onStopTrackingTouch(SeekBar seekBar) {
      }
    });
  }

  @SuppressLint({"NewApi"})
  private static void initializeSeekBarsColors(SeekBar... seekBars) {
    for (SeekBar argb : seekBars) {
      int color = Color.parseColor(argb.getTag().toString());
      argb.getProgressDrawable().setColorFilter(color, Mode.SRC_IN);
      if (VERSION.SDK_INT >= 16) {
        argb.getThumb().setColorFilter(color, Mode.SRC_IN);
      }
    }
  }

  static void updateColorView(Activity activity, View colorView, int RGB) {
    activity.runOnUiThread(new AnonymousClass9(colorView, RGB));
  }
}
