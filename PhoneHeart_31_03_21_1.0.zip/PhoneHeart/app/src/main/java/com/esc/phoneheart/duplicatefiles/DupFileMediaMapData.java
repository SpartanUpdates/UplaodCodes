package com.esc.phoneheart.duplicatefiles;

import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;

import java.util.ArrayList;

public class DupFileMediaMapData {
    public String hash;
    public ArrayList<BigSizeFilesWrapper> list;
    public String media;

    public DupFileMediaMapData(String str, String str2, ArrayList<BigSizeFilesWrapper> arrayList) {
        this.media = str;
        this.hash = str2;
        this.list = arrayList;
    }
}
