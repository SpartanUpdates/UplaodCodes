package com.esc.gesturelockscreen.Activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.esc.gesturelockscreen.Other.BitmapUtils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.Service.LockStateService;
import com.esc.gesturelockscreen.View.GestureLockView;
import com.esc.gesturelockscreen.View.GestureLockView.GESTUREMODE;
import com.esc.gesturelockscreen.View.GestureLockView.IGestureLockListener;
import com.esc.gesturelockscreen.R;

import java.io.File;

import androidx.core.view.InputDeviceCompat;

public class GestureLockActivity extends Activity {
    private Activity activity = GestureLockActivity.this;
    public static final int OVERLAY_PERMISSION_REQ_CODE = 1235;
    private boolean createNew = false;
    private ImageView image1;
    ImageView imgBg;
    private GestureLockView mGestureLock;
    BitmapUtils bitmapUtils;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private int size;
    private IGestureLockListener mListener = new IGestureLockListener() {
        @Override
        public void onUnLockSuccess(GESTUREMODE mode) {
            if (GestureLockActivity.this.createNew && mode == GESTUREMODE.MODE_VERIFY) {
                ((TextView) GestureLockActivity.this.findViewById(R.id.top_titlebar)).setText("Draw to create new Signature");
                GestureLockActivity.this.mGestureLock.switchToCreateMode();
                return;
            }
            if (mode == GESTUREMODE.MODE_CONFIRM) {
                SettingsUtils.putBoolean(SettingsKeys.ENABLE_GESTURE, true);
            }
            GestureLockActivity.this.setResult(-1);
            GestureLockActivity.this.finish();
        }

        @Override
        public void onUnDrawRecorded(Gesture mGesture) {
            GestureLockActivity.this.findViewById(R.id.lin_state).setVisibility(View.VISIBLE);
            GestureLockActivity.this.image1.setImageBitmap(mGesture.toBitmap(GestureLockActivity.this.size, GestureLockActivity.this.size, GestureLockActivity.this.size / 10, InputDeviceCompat.SOURCE_ANY));
        }

        @Override
        public void onNotLoadedError() {
        }

        @Override
        public void onDrawWrong(Gesture mGesture) {
            GestureLockActivity.this.doVibration(100);
        }
    };


    public void onBackPressed(View v) {
        finish();
    }

    protected void onStart() {
        super.onStart();
        overridePendingTransition(0, 0);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SettingsUtils.init(getApplicationContext());
        setContentView(R.layout.activity_gesture);
        if (!isSystemAlertPermissionGranted(this)) {
            checkPerms();
        }

        BannerAds();

        this.mGestureLock = (GestureLockView) findViewById(R.id.gesture_layout);
        this.imgBg = (ImageView) findViewById(R.id.img_bg);
        this.bitmapUtils = new BitmapUtils(this);
        this.imgBg.setImageBitmap(this.bitmapUtils.getBackgroundBitmap());

        this.image1 = (ImageView) findViewById(R.id.pattern_1);
        this.size = (int) (getResources().getDisplayMetrics().density * 50.0f);
        this.mGestureLock.setListener(this.mListener);
        if (GestureLibraries.fromFile(new File(getFilesDir(), "gesture.lock")).load()) {
            if (getIntent().hasExtra("verify_n_create")) {
                this.createNew = getIntent().getBooleanExtra("verify_n_create", false);
            }
            ((TextView) findViewById(R.id.top_titlebar)).setText("Draw to verify");
            this.mGestureLock.onInitMode(GESTUREMODE.MODE_VERIFY);
            startService(new Intent(this, LockStateService.class));
            return;
        }
        this.mGestureLock.onInitMode(GESTUREMODE.MODE_CREATE);
        ((TextView) findViewById(R.id.top_titlebar)).setText("Draw to create new Signature");
    }

    public void checkPerms() {
        if (VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), OVERLAY_PERMISSION_REQ_CODE);
            }
        }
    }

    @TargetApi(23)
    public static boolean isSystemAlertPermissionGranted(Context context) {
        return VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
    }

    public void onClear(View v) {
        findViewById(R.id.lin_state).setVisibility(View.INVISIBLE);
        this.image1.setImageBitmap(null);
        this.mGestureLock.switchToCreateMode();
    }

    public void doVibration(long value) {
        if (SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_VIBRATION, true)) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v.hasVibrator()) {
                v.vibrate(value);
            }
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE && !isSystemAlertPermissionGranted(this)) {
            checkPerms();
        }
    }
}
