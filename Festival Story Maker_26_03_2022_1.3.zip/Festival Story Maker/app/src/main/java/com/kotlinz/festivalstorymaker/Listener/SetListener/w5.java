package com.kotlinz.festivalstorymaker.Listener.SetListener;


import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class w5 implements TextStickerViewNew1.b {
    public final FrameEditorNewDesign a;

    public w5(final FrameEditorNewDesign a) {
        this.a = a;
    }

    @Override
    public void a(final boolean b, final TextStickerViewNew1 textStickerViewNew1) {
        if (!b && this.a.llTextEditor.isShown()) {
            final FrameEditorNewDesign a = this.a;
            final TextStickerViewNew1 s1 = a.s1;
            if (s1 == null || s1 == textStickerViewNew1) {
                a.B0(b);
            }
        }
    }
}
