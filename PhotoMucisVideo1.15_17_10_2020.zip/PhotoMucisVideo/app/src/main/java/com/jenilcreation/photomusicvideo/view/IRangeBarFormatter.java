package com.jenilcreation.photomusicvideo.view;

public interface IRangeBarFormatter {
    String format(String str);
}
