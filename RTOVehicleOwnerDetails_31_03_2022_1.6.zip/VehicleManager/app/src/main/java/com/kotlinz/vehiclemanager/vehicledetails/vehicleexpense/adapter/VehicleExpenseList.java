package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;

import java.util.ArrayList;

public class VehicleExpenseList extends BaseExpandableListAdapter {
    Context context;
    ArrayList<VehicleExpense> expenseModels;

    public long getChildId(int i, int i2) {
        return (long) i2;
    }

    public long getGroupId(int i) {
        return (long) i;
    }

    public boolean hasStableIds() {
        return false;
    }

    public boolean isChildSelectable(int i, int i2) {
        return true;
    }

    DarkTheame darkTheame;

    public VehicleExpenseList(Context context, ArrayList<VehicleExpense> arrayList) {
        this.context = context;
        this.expenseModels = arrayList;
        this.darkTheame = new DarkTheame(context);
    }

    public Object getChild(int i, int i2) {
        return this.expenseModels.get(i).getExpenseModels().get(i2);
    }

    @SuppressLint({"WrongConstant"})
    public View getChildView(int i, int i2, boolean z, View view, ViewGroup viewGroup) {
        VehicleExpense vehicleExpenseModel = (VehicleExpense) getChild(i, i2);
        if (view == null) {
            view = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(R.layout.layout_vehicleexpense, null);
        }
        TextView tvcatName = view.findViewById(R.id.list_catname);
        TextView tvNote = view.findViewById(R.id.list_note);
        TextView tvAmount = view.findViewById(R.id.list_amount);
        ImageView ivCatIcon = view.findViewById(R.id.list_caticon);
        TextView tvPayee = view.findViewById(R.id.list_payee);
        LinearLayout ll_childData = view.findViewById(R.id.ll_childData);
        int nightModeFlags = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            ll_childData.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        }
        if (darkTheame.modeData().equals("nightMode")) {
            ll_childData.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Item: ");
        stringBuilder.append(vehicleExpenseModel.getPayee());
        tvPayee.setText(stringBuilder.toString());
        tvcatName.setText(vehicleExpenseModel.getCatname());
        tvNote.setText(vehicleExpenseModel.getNotes());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.context.getString(R.string.rs));
        stringBuilder2.append(" ");
        stringBuilder2.append(vehicleExpenseModel.getAmount());
        tvAmount.setText(stringBuilder2.toString());
        ivCatIcon.setImageResource(vehicleExpenseModel.getCaticon());
        return view;
    }

    public int getChildrenCount(int i) {
        return this.expenseModels.get(i).getExpenseModels().size();
    }

    public Object getGroup(int i) {
        return this.expenseModels.get(i);
    }

    public int getGroupCount() {
        return this.expenseModels.size();
    }

    @SuppressLint({"WrongConstant"})
    public View getGroupView(int i, boolean z, View view, ViewGroup viewGroup) {
        VehicleExpense vehicleExpenseModel = (VehicleExpense) getGroup(i);
        if (view == null) {
            view = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(R.layout.layout_expense_group, null);
        }
        LinearLayout ll_goupData = view.findViewById(R.id.ll_goupData);
        TextView textView = view.findViewById(R.id.lblListHeader);

        if (darkTheame.modeData().equals("nightMode")) {
            ll_goupData.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            textView.setTextColor(Color.parseColor("#FFFFFF"));
        }

        textView.setTypeface(null, 1);
        textView.setText(vehicleExpenseModel.getDuedate());
        return view;
    }

}
