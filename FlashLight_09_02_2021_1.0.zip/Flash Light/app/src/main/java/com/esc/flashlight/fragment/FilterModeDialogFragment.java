package com.esc.flashlight.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.DialogFragment;

import com.esc.flashlight.activity.AppFilterActivity;
import com.esc.flashlight.R;

import java.util.EventListener;

public class FilterModeDialogFragment extends DialogFragment implements OnClickListener {
    private OnSelectListener onSelectListener;

    public interface OnSelectListener extends EventListener {
        void onSelected(AppFilterActivity.FilteredOption filteredOption, String str);
    }

    public OnSelectListener getOnSelectListener() {
        return this.onSelectListener;
    }

    public void setOnSelectListener(OnSelectListener onSelectListener) {
        this.onSelectListener = onSelectListener;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        getDialog().setTitle(R.string.filter_setting_list_view_mode);
        getDialog().getWindow().setBackgroundDrawableResource(R.drawable.round_square);
        View inflate = layoutInflater.inflate(R.layout.df_filter_option_select, null);
        inflate.findViewById(R.id.btn_show_all).setOnClickListener(this);
        inflate.findViewById(R.id.btn_show_selected).setOnClickListener(this);
        inflate.findViewById(R.id.btn_show_preload).setOnClickListener(this);
        inflate.findViewById(R.id.btn_show_download).setOnClickListener(this);
        return inflate;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onClick(View view) {
        String charSequence = ((TextView) view).getText().toString();
        switch (view.getId()) {
            case R.id.btn_show_all :
                performClick(AppFilterActivity.FilteredOption.ALL, charSequence);
                return;
            case R.id.btn_show_download :
                performClick(AppFilterActivity.FilteredOption.DOWNLOADED, charSequence);
                return;
            case R.id.btn_show_preload :
                performClick(AppFilterActivity.FilteredOption.PRELOAD, charSequence);
                return;
            case R.id.btn_show_selected :
                performClick(AppFilterActivity.FilteredOption.SELECTED, charSequence);
                return;
            default:
                return;
        }
    }

    private void performClick(AppFilterActivity.FilteredOption filteredOption, String str) {
        OnSelectListener onSelectListener = this.onSelectListener;
        if (onSelectListener != null) {
            onSelectListener.onSelected(filteredOption, str);
        }
        dismiss();
    }
}
