package com.esc.phoneheart.utility;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.OnClickListener;

import com.esc.phoneheart.activity.BaseActivity;
import com.esc.phoneheart.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public abstract class PermitionActivity extends BaseActivity {
    public boolean fromPermissionSettings = false;
    public SparseIntArray mErrorString;

    public void closebtnClick() {
        findViewById(R.id.iv_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!PermitionActivity.this.doubleClicked()) {
                    PermitionActivity.this.finish();
                }
            }
        });
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.mErrorString = new SparseIntArray();
    }

    public abstract void onPermissionsGranted(int i);

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        int i2 = 0;
        for (int i3 : iArr) {
            i2 += i3;
        }
        if (iArr.length <= 0 || i2 != 0) {
            Util.a = false;
            findViewById(R.id.hiddenpermissionlayout).setVisibility(View.VISIBLE);
            findViewById(R.id.hiddenpermissionlayout).bringToFront();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                findViewById(R.id.hiddenpermissionlayout).setTranslationZ(10.0f);
            }
            if (findViewById(R.id.banner_container) != null) {
                findViewById(R.id.banner_container).setVisibility(View.GONE);
                return;
            }
            return;
        }
        Util.a = true;
        onPermissionsGranted(i);
    }

    public void requestAppPermissions(final String[] strArr, int i, final int i2) {
        this.mErrorString.put(i2, i);
        int i3 = 0;
        Object obj = null;
        for (String str : strArr) {
            i3 += ContextCompat.checkSelfPermission(this, str);
            obj = (obj != null || ActivityCompat.shouldShowRequestPermissionRationale(this, str)) ? 1 : null;
        }
        if (i3 != 0) {
            Util.a = false;
            if (obj != null) {
                findViewById(R.id.hiddenpermissionlayout).setVisibility(View.VISIBLE);
                findViewById(R.id.hiddenpermissionlayout).bringToFront();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    findViewById(R.id.hiddenpermissionlayout).setTranslationZ(10.0f);
                }
                if (findViewById(R.id.banner_container) != null) {
                    findViewById(R.id.banner_container).setVisibility(View.GONE);
                }
            } else {
                ActivityCompat.requestPermissions(this, strArr, i2);
            }
        } else {
            Util.a = true;
            onPermissionsGranted(i2);
        }
        findViewById(R.id.iv_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!PermitionActivity.this.doubleClicked()) {
                    PermitionActivity.this.finish();
                }
            }
        });
        findViewById(R.id.btngrantpermission).setOnClickListener(new OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(View view) {
                String str = Manifest.permission.WRITE_EXTERNAL_STORAGE;
                ContextCompat.checkSelfPermission(PermitionActivity.this, str);
                String str2 = "package:";
                String str3 = "android.intent.category.DEFAULT";
                String str4 = "android.settings.APPLICATION_DETAILS_SETTINGS";
                Intent intent;
                StringBuilder stringBuilder;
                if (GlobalData.phone_state_Permission) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(PermitionActivity.this, "android.permission.READ_PHONE_STATE")) {
                        ActivityCompat.requestPermissions(PermitionActivity.this, strArr, i2);
                        return;
                    }
                    PermitionActivity.this.fromPermissionSettings = true;
                    intent = new Intent();
                    intent.setAction(str4);
                    intent.addCategory(str3);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(PermitionActivity.this.getPackageName());
                    intent.setData(Uri.parse(stringBuilder.toString()));
                    intent.addFlags(268435456);
                    intent.addFlags(1073741824);
                    intent.addFlags(8388608);
                    PermitionActivity.this.startActivity(intent);
                } else if (ActivityCompat.shouldShowRequestPermissionRationale(PermitionActivity.this, str)) {
                    ActivityCompat.requestPermissions(PermitionActivity.this, strArr, i2);
                } else {
                    intent = new Intent();
                    intent.setAction(str4);
                    intent.addCategory(str3);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(PermitionActivity.this.getPackageName());
                    intent.setData(Uri.parse(stringBuilder.toString()));
                    intent.addFlags(268435456);
                    intent.addFlags(1073741824);
                    intent.addFlags(8388608);
                    PermitionActivity.this.startActivity(intent);
                }
            }
        });
    }
}
