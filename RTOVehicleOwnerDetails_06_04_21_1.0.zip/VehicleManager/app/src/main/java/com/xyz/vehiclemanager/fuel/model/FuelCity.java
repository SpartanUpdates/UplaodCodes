package com.xyz.vehiclemanager.fuel.model;

import com.google.gson.annotations.SerializedName;

public class FuelCity
{
    @SerializedName("petrol")
    private String petrol;
    @SerializedName("diesel")
    private String diesel;
    @SerializedName("petrol_price_diff")
    private String petrolPriceDiff;
    @SerializedName("diesel_price_diff")
    private String dieselPriceDiff;
    @SerializedName("city")
    private String city;
    @SerializedName("state")
    private String state;

    public FuelCity() {
    }

    public String getPetrol() {
        return petrol;
    }

    public void setPetrol(String petrol) {
        this.petrol = petrol;
    }

    public String getDiesel() {
        return diesel;
    }

    public void setDiesel(String diesel) {
        this.diesel = diesel;
    }

    public String getPetrolPriceDiff() {
        return petrolPriceDiff;
    }

    public void setPetrolPriceDiff(String petrolPriceDiff) {
        this.petrolPriceDiff = petrolPriceDiff;
    }

    public String getDieselPriceDiff() {
        return dieselPriceDiff;
    }

    public void setDieselPriceDiff(String dieselPriceDiff) {
        this.dieselPriceDiff = dieselPriceDiff;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
