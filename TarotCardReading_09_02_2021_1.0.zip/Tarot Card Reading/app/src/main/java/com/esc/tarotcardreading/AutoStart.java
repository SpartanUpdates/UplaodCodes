package com.esc.tarotcardreading;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;

public class AutoStart extends BroadcastReceiver {
    private static final String TAG = "OnNetworkChangedReceiver-------";
    Intent alarmIntent;
    public AlarmManager alarmManager;
    Context c;
    PendingIntent pendingIntent;

    public void onReceive(Context context, Intent intent) {
        this.c = context;
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            setAlarm();
        }
    }

    public void setAlarm() {
        this.alarmManager = (AlarmManager) this.c.getSystemService(NotificationCompat.CATEGORY_ALARM);
        Intent intent = new Intent(this.c, AlarmReceiver.class);
        this.alarmIntent = intent;
        this.pendingIntent = PendingIntent.getBroadcast(this.c, 0, intent, 0);
        Calendar instance = Calendar.getInstance();
        instance.set(11, 9);
        this.alarmManager.setRepeating(0, instance.getTimeInMillis() + 86400000, 86400000, this.pendingIntent);
    }
}
