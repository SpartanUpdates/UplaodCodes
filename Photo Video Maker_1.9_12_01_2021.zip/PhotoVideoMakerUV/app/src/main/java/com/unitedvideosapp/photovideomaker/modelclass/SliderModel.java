package com.unitedvideosapp.photovideomaker.modelclass;

import android.graphics.drawable.Drawable;

public class SliderModel {
    private Drawable ImagePath;

    public SliderModel(Drawable imagePath) {
        ImagePath = imagePath;
    }

    public Drawable getImagePath() {
        return ImagePath;
    }

    public void setImagePath(Drawable imagePath) {
        ImagePath = imagePath;
    }
}
