package com.esc.storymaker.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.storymaker.LaunchScreenActivity;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.SrvTemplateSectionAdapter;
import com.esc.storymaker.utils.ContractsUtil;

import java.util.ArrayList;

public class TemplatesFrag extends Fragment {
    private ArrayList<String> categories = new ArrayList();
    private MainActivity mainActivity;
    private View rootView;
    RecyclerView rvTemplates;
    private SrvTemplateSectionAdapter srvTemplateSectionAdapter;

    public static TemplatesFrag getInstance(MainActivity mainActivity) {
        TemplatesFrag templatesFrag = new TemplatesFrag();
        templatesFrag.mainActivity = mainActivity;
        return templatesFrag;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_templates, viewGroup, false);
        this.rvTemplates = this.rootView.findViewById(R.id.rv_templates);
        setTemplateCategories();
        return this.rootView;
    }

    private void setTemplateCategories() {
        if (this.mainActivity == null) {
            Intent intent = new Intent(getActivity(), LaunchScreenActivity.class);
            startActivity(intent);
            return;
        }
        this.categories.addAll(ContractsUtil.templateCategories.keySet());
        this.srvTemplateSectionAdapter = new SrvTemplateSectionAdapter(this.mainActivity, this.categories);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        this.rvTemplates.setHasFixedSize(true);
        this.rvTemplates.setLayoutManager(linearLayoutManager);
        this.rvTemplates.setAdapter(this.srvTemplateSectionAdapter);
    }
}
