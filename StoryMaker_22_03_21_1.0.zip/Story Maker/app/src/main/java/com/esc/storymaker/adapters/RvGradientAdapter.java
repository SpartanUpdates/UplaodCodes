package com.esc.storymaker.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.esc.storymaker.EditorActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.interfaces.ItemClickListener;
import com.esc.storymaker.utils.AppUtil;
import java.util.ArrayList;

public class RvGradientAdapter extends RecyclerView.Adapter<RvGradientAdapter.ViewHolderCollagePattern> {
    private int[] colors = new int[0];
    private String[] gradient;
    private String gradientType;
    private String[] gradients;
    private boolean isBackground;
    private boolean isLocked;
    private String linearDirection;
    private ArrayList<String> lockedNumbers = new ArrayList();
    private Context mContext;
    private SharedPreferences prefs;
    private int screenWidth;

    static class ViewHolderCollagePattern extends ViewHolder implements OnClickListener {
        ItemClickListener itemClickListener;
        View vGradient;

        public ViewHolderCollagePattern(View view) {
            super(view);
            this.vGradient = view.findViewById(R.id.v_shape);
            view.setOnClickListener(this);
        }

        public void setItemClickListener(ItemClickListener itemClickListener) {
            this.itemClickListener = itemClickListener;
        }

        public void onClick(View view) {
            this.itemClickListener.onItemClick(view, getLayoutPosition());
        }
    }

    public RvGradientAdapter(Context context, String[] strArr, String str, String str2, boolean z, int i) {
        this.mContext = context;
        this.gradients = strArr;
        this.gradientType = str;
        this.linearDirection = str2;
        this.isBackground = z;
        this.screenWidth = i;
        this.prefs = context.getSharedPreferences("prefs", 0);
        this.isLocked = AppUtil.isLocked(this.prefs, "gradientsAddTime");
        this.lockedNumbers.addAll(AppUtil.getLockedNumbers(this.prefs));
    }

    public ViewHolderCollagePattern onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolderCollagePattern(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_circle_shape, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolderCollagePattern viewHolderCollagePattern, int i) {
        this.gradient = new String[0];
        this.gradient = this.gradients[i].split(" ");
        viewHolderCollagePattern.vGradient.setBackgroundDrawable(AppUtil.generateViewGradient(this.gradient, this.gradientType, this.linearDirection, viewHolderCollagePattern.vGradient.getWidth(), viewHolderCollagePattern.vGradient.getHeight()));
        viewHolderCollagePattern.setItemClickListener(new ItemClickListener() {
            public void onItemClick(View view, int i) {
                RvGradientAdapter.this.gradient = new String[0];
                RvGradientAdapter rvGradientAdapter = RvGradientAdapter.this;
                rvGradientAdapter.gradient = AppUtil.strTOStrArray(rvGradientAdapter.gradients[i], " ");
                if (RvGradientAdapter.this.isBackground) {
                    ((EditorActivity) RvGradientAdapter.this.mContext).changeBackground(null, RvGradientAdapter.this.gradient, null);
                } else {
                    ((EditorActivity) RvGradientAdapter.this.mContext).changeTextEntityGradient(RvGradientAdapter.this.gradient);
                }
            }
        });
    }

    public int getItemCount() {
        String[] strArr = this.gradients;
        return strArr != null ? strArr.length : 0;
    }

    public void refreshList(boolean z) {
        this.isBackground = z;
        this.isLocked = AppUtil.isLocked(this.prefs, "gradientsAddTime");
        notifyDataSetChanged();
    }
}
