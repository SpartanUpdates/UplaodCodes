package com.xyz.vehiclemanager.bikedetails.bikeservice.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.model.CityList;
import com.xyz.vehiclemanager.model.StateList;
import com.xyz.vehiclemanager.model.StateListRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeServiceSelectStateActivity extends AppCompatActivity implements View.OnClickListener {

    private Activity activity = BikeServiceSelectStateActivity.this;
    public static String brandId;
    private ImageView iv_back;
    private Button btn_getdetails;
    private Spinner stateListSpinner;
    private Spinner spinnercitylist;
    private ArrayList<String> stateNameList;
    private ArrayList<String> cityNameList;
    private ArrayList<String> cityIdlist;
    private String selectCityId;
    private String cityName;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikeservice_selectstate);

        Intent intent = getIntent();
        brandId = intent.getStringExtra("brandid");

        stateNameList = new ArrayList<>();
        cityNameList = new ArrayList<>();
        cityIdlist = new ArrayList<>();
        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);

        BindView();
        PutAnalyticsEvent();
        DialogAnimation();
        SetSpinnerlistener();
        if (Utils.isOnline(activity)){
           getBikeServiceStatelist();
        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        stateListSpinner = findViewById(R.id.spinnerstatelist);
        spinnercitylist = findViewById(R.id.spinnercitylist);
        btn_getdetails = findViewById(R.id.btn_get_details);
        iv_back.setOnClickListener(this);
        btn_getdetails.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeServiceSelectStateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void SetSpinnerlistener()
    {
        spinnercitylist.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectCityId = cityIdlist.get(position);
                cityName = cityNameList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.iv_back:
                onBackPressed();
                break;

            case R.id.btn_get_details:
                Intent intent = new Intent(activity, BikeServiceDetailActivity.class);
                intent.putExtra("id", brandId);
                intent.putExtra("cityid",selectCityId);
                intent.putExtra("cityname",cityName);
                startActivity(intent);
                break;
        }
    }

    private void getBikeServiceStatelist()
    {
        Call<StateListRoot> call = rtoDetailsInterface.getCityList();
        call.enqueue(new Callback<StateListRoot>() {
            @Override
            public void onResponse(Call<StateListRoot> call, Response<StateListRoot> response) {
                if (response.isSuccessful()) {
                    if (dialog != null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    final ArrayList<StateList> stateLists = response.body().getData();
                    System.out.println(new Gson().toJson(stateLists));
                    for (int i = 0; i < stateLists.size(); i++) {
                        String name = stateLists.get(i).getStateName();
                        stateNameList.add(name);
                    }
                    ArrayAdapter stateAdapter = new ArrayAdapter(activity, R.layout.support_simple_spinner_dropdown_item, stateNameList);
                    stateAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    stateListSpinner.setAdapter(stateAdapter);

                    stateListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            cityNameList.clear();
                            cityIdlist.clear();
                            for (int j = 0; j < stateLists.size(); j++) {
                                ArrayList<CityList> cityLists = stateLists.get(j).getCityLists();
                                for (int k = 0; k < cityLists.size(); k++) {
                                    String stateTwo = cityLists.get(k).getStateName();
                                    String city = cityLists.get(k).getCityName();
                                    String cityid=cityLists.get(k).getCityId();
                                    if (stateTwo.equals(stateListSpinner.getSelectedItem())) {
                                        cityNameList.add(city);
                                        cityIdlist.add(cityid);
                                    }
                                }
                                ArrayAdapter cityAdapter = new ArrayAdapter(activity, R.layout.support_simple_spinner_dropdown_item, cityNameList);
                                cityAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                                spinnercitylist.setAdapter(cityAdapter);
                            }
                        }
                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<StateListRoot> call, Throwable t) {
                if (dialog != null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
      super.onBackPressed();
    }
}