package com.kotlinz.videoCollage.crop;

import android.graphics.Rect;
import android.view.View;

public enum Edge {
    LEFT,
    TOP,
    RIGHT,
    BOTTOM;
    
    public static final int MIN_CROP_LENGTH_PX = 40;
    private float mCoordinate;


    static  class AnonymousClass1 {
        static final  int[] $SwitchMap$fcom$collage$imagevideo$crop$Edge = null;


        static {

        }
    }

    public void setCoordinate(float f) {
        this.mCoordinate = f;
    }

    public void offset(float f) {
        this.mCoordinate += f;
    }

    public float getCoordinate() {
        return this.mCoordinate;
    }

    public void adjustCoordinate(float f, float f2, Rect rect, float f3, float f4) {
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        if (i == 1) {
            this.mCoordinate = adjustLeft(f, rect, f3, f4);
        } else if (i == 2) {
            this.mCoordinate = adjustTop(f2, rect, f3, f4);
        } else if (i == 3) {
            this.mCoordinate = adjustRight(f, rect, f3, f4);
        } else if (i == 4) {
            this.mCoordinate = adjustBottom(f2, rect, f3, f4);
        }
    }

    public void adjustCoordinate(float f) {
        float coordinate = LEFT.getCoordinate();
        float coordinate2 = TOP.getCoordinate();
        float coordinate3 = RIGHT.getCoordinate();
        float coordinate4 = BOTTOM.getCoordinate();
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        if (i == 1) {
            this.mCoordinate = AspectRatioUtil.calculateLeft(coordinate2, coordinate3, coordinate4, f);
        } else if (i == 2) {
            this.mCoordinate = AspectRatioUtil.calculateTop(coordinate, coordinate3, coordinate4, f);
        } else if (i == 3) {
            this.mCoordinate = AspectRatioUtil.calculateRight(coordinate, coordinate2, coordinate4, f);
        } else if (i == 4) {
            this.mCoordinate = AspectRatioUtil.calculateBottom(coordinate, coordinate2, coordinate3, f);
        }
    }

    public boolean isNewRectangleOutOfBounds(Edge edge, Rect rect, float f) {
        float snapOffset = edge.snapOffset(rect);
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        float coordinate;
        float coordinate2;
        float coordinate3;
        if (i != 1) {
            float f2;
            if (i != 2) {
                if (i != 3) {
                    if (i == 4) {
                        if (edge.equals(LEFT)) {
                            f2 = (float) rect.left;
                            coordinate = RIGHT.getCoordinate() - snapOffset;
                            coordinate2 = TOP.getCoordinate();
                            return isOutOfBounds(coordinate2, f2, AspectRatioUtil.calculateBottom(f2, coordinate2, coordinate, f), coordinate, rect);
                        } else if (edge.equals(RIGHT)) {
                            coordinate = (float) rect.right;
                            f2 = LEFT.getCoordinate() - snapOffset;
                            coordinate2 = TOP.getCoordinate();
                            return isOutOfBounds(coordinate2, f2, AspectRatioUtil.calculateBottom(f2, coordinate2, coordinate, f), coordinate, rect);
                        }
                    }
                } else if (edge.equals(TOP)) {
                    coordinate2 = (float) rect.top;
                    coordinate3 = BOTTOM.getCoordinate() - snapOffset;
                    f2 = LEFT.getCoordinate();
                    return isOutOfBounds(coordinate2, f2, coordinate3, AspectRatioUtil.calculateRight(f2, coordinate2, coordinate3, f), rect);
                } else if (edge.equals(BOTTOM)) {
                    coordinate3 = (float) rect.bottom;
                    coordinate2 = TOP.getCoordinate() - snapOffset;
                    f2 = LEFT.getCoordinate();
                    return isOutOfBounds(coordinate2, f2, coordinate3, AspectRatioUtil.calculateRight(f2, coordinate2, coordinate3, f), rect);
                }
            } else if (edge.equals(LEFT)) {
                f2 = (float) rect.left;
                coordinate = RIGHT.getCoordinate() - snapOffset;
                coordinate3 = BOTTOM.getCoordinate();
                return isOutOfBounds(AspectRatioUtil.calculateTop(f2, coordinate, coordinate3, f), f2, coordinate3, coordinate, rect);
            } else if (edge.equals(RIGHT)) {
                coordinate = (float) rect.right;
                f2 = LEFT.getCoordinate() - snapOffset;
                coordinate3 = BOTTOM.getCoordinate();
                return isOutOfBounds(AspectRatioUtil.calculateTop(f2, coordinate, coordinate3, f), f2, coordinate3, coordinate, rect);
            }
        } else if (edge.equals(TOP)) {
            coordinate2 = (float) rect.top;
            coordinate3 = BOTTOM.getCoordinate() - snapOffset;
            coordinate = RIGHT.getCoordinate();
            return isOutOfBounds(coordinate2, AspectRatioUtil.calculateLeft(coordinate2, coordinate, coordinate3, f), coordinate3, coordinate, rect);
        } else if (edge.equals(BOTTOM)) {
            coordinate3 = (float) rect.bottom;
            coordinate2 = TOP.getCoordinate() - snapOffset;
            coordinate = RIGHT.getCoordinate();
            return isOutOfBounds(coordinate2, AspectRatioUtil.calculateLeft(coordinate2, coordinate, coordinate3, f), coordinate3, coordinate, rect);
        }
        return true;
    }

    private boolean isOutOfBounds(float f, float f2, float f3, float f4, Rect rect) {
        return f < ((float) rect.top) || f2 < ((float) rect.left) || f3 > ((float) rect.bottom) || f4 > ((float) rect.right);
    }

    public float snapToRect(Rect rect) {
        float f = this.mCoordinate;
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        if (i == 1) {
            this.mCoordinate = (float) rect.left;
        } else if (i == 2) {
            this.mCoordinate = (float) rect.top;
        } else if (i == 3) {
            this.mCoordinate = (float) rect.right;
        } else if (i == 4) {
            this.mCoordinate = (float) rect.bottom;
        }
        return this.mCoordinate - f;
    }

    public float snapOffset(Rect rect) {
        int i;
        float f;
        float f2 = this.mCoordinate;
        int i2 = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        if (i2 == 1) {
            i = rect.left;
        } else if (i2 == 2) {
            i = rect.top;
        } else if (i2 == 3) {
            i = rect.right;
        } else if (i2 != 4) {
            f = f2;
            return f - f2;
        } else {
            i = rect.bottom;
        }
        f = (float) i;
        return f - f2;
    }

    public void snapToView(View view) {
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        if (i == 1) {
            this.mCoordinate = 0.0f;
        } else if (i == 2) {
            this.mCoordinate = 0.0f;
        } else if (i == 3) {
            this.mCoordinate = (float) view.getWidth();
        } else if (i == 4) {
            this.mCoordinate = (float) view.getHeight();
        }
    }

    public static float getWidth() {
        return RIGHT.getCoordinate() - LEFT.getCoordinate();
    }

    public static float getHeight() {
        return BOTTOM.getCoordinate() - TOP.getCoordinate();
    }

    public boolean isOutsideMargin(Rect rect, float f) {
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        boolean z = false;
        if (i == 1) {
            return this.mCoordinate - ((float) rect.left) < f;
        } else {
            if (i == 2) {
                return this.mCoordinate - ((float) rect.top) < f;
            } else {
                if (i == 3) {
                    return ((float) rect.right) - this.mCoordinate < f;
                } else {
                    if (i != 4) {
                        return false;
                    }
                    if (((float) rect.bottom) - this.mCoordinate < f) {
                        z = true;
                    }
                    return z;
                }
            }
        }
    }

    public boolean isOutsideFrame(Rect rect) {
        int i = AnonymousClass1.$SwitchMap$fcom$collage$imagevideo$crop$Edge[ordinal()];
        boolean z = false;
        if (i == 1) {
            return ((double) (this.mCoordinate - ((float) rect.left))) < 0.0d;
        } else {
            if (i == 2) {
                return ((double) (this.mCoordinate - ((float) rect.top))) < 0.0d;
            } else {
                if (i == 3) {
                    return ((double) (((float) rect.right) - this.mCoordinate)) < 0.0d;
                } else {
                    if (i != 4) {
                        return false;
                    }
                    if (((double) (((float) rect.bottom) - this.mCoordinate)) < 0.0d) {
                        z = true;
                    }
                    return z;
                }
            }
        }
    }

    private static float adjustLeft(float f, Rect rect, float f2, float f3) {
        if (f - ((float) rect.left) < f2) {
            return (float) rect.left;
        }
        float f4 = Float.POSITIVE_INFINITY;
        float coordinate = f >= RIGHT.getCoordinate() - 40.0f ? RIGHT.getCoordinate() - 40.0f : Float.POSITIVE_INFINITY;
        if ((RIGHT.getCoordinate() - f) / f3 <= 40.0f) {
            f4 = RIGHT.getCoordinate() - (f3 * 40.0f);
        }
        return Math.min(f, Math.min(coordinate, f4));
    }

    private static float adjustRight(float f, Rect rect, float f2, float f3) {
        if (((float) rect.right) - f < f2) {
            return (float) rect.right;
        }
        float f4 = Float.NEGATIVE_INFINITY;
        float coordinate = f <= LEFT.getCoordinate() + 40.0f ? LEFT.getCoordinate() + 40.0f : Float.NEGATIVE_INFINITY;
        if ((f - LEFT.getCoordinate()) / f3 <= 40.0f) {
            f4 = LEFT.getCoordinate() + (f3 * 40.0f);
        }
        return Math.max(f, Math.max(coordinate, f4));
    }

    private static float adjustTop(float f, Rect rect, float f2, float f3) {
        if (f - ((float) rect.top) < f2) {
            return (float) rect.top;
        }
        float f4 = Float.POSITIVE_INFINITY;
        float coordinate = f >= BOTTOM.getCoordinate() - 40.0f ? BOTTOM.getCoordinate() - 40.0f : Float.POSITIVE_INFINITY;
        if ((BOTTOM.getCoordinate() - f) * f3 <= 40.0f) {
            f4 = BOTTOM.getCoordinate() - (40.0f / f3);
        }
        return Math.min(f, Math.min(coordinate, f4));
    }

    private static float adjustBottom(float f, Rect rect, float f2, float f3) {
        if (((float) rect.bottom) - f < f2) {
            return (float) rect.bottom;
        }
        float f4 = Float.NEGATIVE_INFINITY;
        float coordinate = f <= TOP.getCoordinate() + 40.0f ? TOP.getCoordinate() + 40.0f : Float.NEGATIVE_INFINITY;
        if ((f - TOP.getCoordinate()) * f3 <= 40.0f) {
            f4 = TOP.getCoordinate() + (40.0f / f3);
        }
        return Math.max(f, Math.max(f4, coordinate));
    }
}
