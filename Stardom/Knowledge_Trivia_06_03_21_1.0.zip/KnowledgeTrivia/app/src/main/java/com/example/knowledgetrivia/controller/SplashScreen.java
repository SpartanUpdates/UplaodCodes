package com.example.knowledgetrivia.controller;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.knowledgetrivia.R;

public class SplashScreen extends AppCompatActivity {
    private ProgressBar progressBar;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_splash_screen);

        TextView textView = (TextView) findViewById(R.id.splashscreen_maintitle);
        this.progressBar = (ProgressBar) findViewById(R.id.splash_progressBar);
        this.progressBar.getProgressDrawable().setColorFilter(-1, Mode.SRC_IN);
        this.progressBar.setProgress(0);
        this.progressBar.setMax(100);

        textView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.splash_screen_animaton));
        new Thread() {
            public void run() {
                int i = 0;
                while (i < 100) {
                    try {
                        Thread.sleep(20);
                        i++;
                        SplashScreen.this.progressBar.setProgress(i);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                SplashScreen.this.startActivity(new Intent(SplashScreen.this, MainActivity.class));
                SplashScreen.this.finish();
            }
        }.start();
    }
}
