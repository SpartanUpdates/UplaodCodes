package com.kotlinz.vehiclemanager.history.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.history.Adapter.OwnerInfoHistoryAdapter;
import com.kotlinz.vehiclemanager.history.Model.OwnerHistoryPaidModel;
import com.kotlinz.vehiclemanager.history.Room.HistoryDatabase;

import java.util.List;

public class OwnerInfoFragment extends Fragment {
    private View view;
    private RecyclerView rv_owner;
    private OwnerInfoHistoryAdapter ownerInfoHistoryAdapter;
    private HistoryDatabase historyDatabase;
    private  List<OwnerHistoryPaidModel> ownerHistoryList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ownerhistory, container, false);
        rv_owner = view.findViewById(R.id.rv_owner);
        setupDb();
        gettingDataFromDb();
        return view;
    }

    private void setupDb() {
        historyDatabase= Room.databaseBuilder(getActivity(),HistoryDatabase.class,"VehicleDetailsHistory").allowMainThreadQueries().build();
    }
    private void gettingDataFromDb()
    {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run()
                    {
                        ownerHistoryList = historyDatabase.ownerHistoryDao().getOwnerHistory();
                        ownerInfoHistoryAdapter = new OwnerInfoHistoryAdapter(getActivity(), ownerHistoryList);
                        rv_owner.setLayoutManager(new LinearLayoutManager(getActivity()));
                        rv_owner.setAdapter(ownerInfoHistoryAdapter);
                    }
                });
            }
        });thread.start();
    }
}
