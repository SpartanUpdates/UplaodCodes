import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:rto_app/History%20Screen/model/history_model.dart';
import 'package:rto_app/History%20Screen/view/history_screen.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:io' as io;

class HistoryController extends GetxController {
  List<HistoryModel> ownerInfoList = [];
  List<HistoryModel> tempList = [];
  static Database? _db;

  Future<Database?> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDatabase();
    return _db;
  }

  initDatabase() async {
    io.Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, 'ownerinfohistory.db');
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    await db.execute(
        "CREATE TABLE ownerhistory (id INTEGER PRIMARY KEY AUTOINCREMENT, ownerName TEXT NOT NULL,licensePlate TEXT NOT NULL,registrationDate TEXT NOT NULL,responseClass TEXT NOT NULL,brandName TEXT NOT NULL,brandModel TEXT NOT NULL,engineNumber TEXT NOT NULL,fuelType TEXT NOT NULL,insuranceCompany TEXT NOT NULL,insuranceExpiry TEXT NOT NULL,rto TEXT NOT NULL,state TEXT NOT NULL,rtoCode TEXT NOT NULL)");
  }

  Future<void> insert(HistoryModel notesModel) async {
    try {
      var dbClient = await db;
      await dbClient!.insert('ownerhistory', notesModel.toMap());
    } on Exception catch (e) {
      throw Exception(e.toString());
    }
  }

  Future<void> getAllData() async {
    _db = await initDatabase();
    try {
      var dbClient = await db;
      final List<Map<String, Object?>> queryResult =
          await dbClient!.rawQuery('select * from ownerhistory');
      tempList = queryResult.map((e) => HistoryModel.fromMap(e)).toList();
      ownerInfoList = tempList.reversed.toList();
      HistoryScreen.isDataAvailable = true;
    } on Exception catch (_) {
      throw Exception("error");
    }
    update();
  }

  Future<int> delete(String number) async {
    try {
      var dbClient = await db;
      return await dbClient!
          .delete('ownerhistory', where: 'licensePlate=?', whereArgs: [number]);
    } on Exception catch (_) {
      throw Exception("error");
    }
    update();
  }
}
