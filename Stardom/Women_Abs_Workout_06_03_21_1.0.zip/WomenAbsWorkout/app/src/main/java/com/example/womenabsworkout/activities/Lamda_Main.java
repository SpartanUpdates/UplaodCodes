package com.example.womenabsworkout.activities;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.MaterialDialog.SingleButtonCallback;

public final class Lamda_Main implements SingleButtonCallback {
    public static final Lamda_Main INSTANCE = new Lamda_Main();

    private Lamda_Main() {
    }

    public final void onClick(MaterialDialog materialDialog, DialogAction dialogAction) {
        materialDialog.dismiss();
    }
}
