package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Comic implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"ᗩ", "ᗷ", "ᑕ", "ᗪ", "ᗴ", "ᖴ", "ᘜ", "ᕼ", "I", "ᒍ", "K", "ᒪ", "ᗰ", "ᑎ", "O", "ᑭ", "ᑫ", "ᖇ", "Տ", "T", "ᑌ", "ᐯ", "ᗯ", "᙭", "Y", "ᘔ"};
    }

    public String getName() {
        return "ᗩᗷᑕ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"ᗩ", "ᗷ", "ᑕ", "ᗪ", "ᗴ", "ᖴ", "ᘜ", "ᕼ", "I", "ᒍ", "K", "ᒪ", "ᗰ", "ᑎ", "O", "ᑭ", "ᑫ", "ᖇ", "Տ", "T", "ᑌ", "ᐯ", "ᗯ", "᙭", "Y", "ᘔ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
