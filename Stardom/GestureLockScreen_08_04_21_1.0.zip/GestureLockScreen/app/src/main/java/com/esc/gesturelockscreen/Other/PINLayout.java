package com.esc.gesturelockscreen.Other;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.esc.gesturelockscreen.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import androidx.collection.SparseArrayCompat;
import androidx.core.view.ViewCompat;

public class PINLayout extends ViewGroup {
  private static int[] padIds = new int[]{R.id.passcode_btn0, R.id.passcode_btn1, R.id.passcode_btn2, R.id.passcode_btn3, R.id.passcode_btn4, R.id.passcode_btn5, R.id.passcode_btn6, R.id.passcode_btn7, R.id.passcode_btn8, R.id.passcode_btn9};
  private IOnPadButtonClickListener listener;
  private int mColumnCount;
  private String mInputPassword;
  private OnClickListener mPadButtonClickListener;
  private int mRowCount;
  private SparseArrayCompat<Integer> randoms;

  public interface IOnPadButtonClickListener {
    int getMaxInputLimit();

    boolean isButtonEnable();

    void onCancel();

    void onPadInput(String str);
  }

  public PINLayout(Context context) {
    this(context, null);
  }

  public PINLayout(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  @SuppressLint({"NewApi"})
  public PINLayout(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);
    this.mRowCount = 4;
    this.mColumnCount = 3;
    this.randoms = new SparseArrayCompat(10);
    this.mInputPassword = "";
    this.mPadButtonClickListener = new OnClickListener() {
      @Override
      public void onClick(View v) {
        if (PINLayout.this.listener != null && (v instanceof Button)) {
          if (v.getId() == R.id.passcode_btn_clear) {
            int size = PINLayout.this.mInputPassword.length();
            if (size > 0) {
              PINLayout.this.mInputPassword = PINLayout.this.mInputPassword.substring(0, size - 1);
              PINLayout.this.listener.onPadInput(PINLayout.this.mInputPassword);
            }
          } else if (v.getId() == R.id.passcode_btn_back) {
            PINLayout.this.mInputPassword = "";
            PINLayout.this.listener.onCancel();
          }
          if (PINLayout.this.listener.isButtonEnable() && PINLayout.this.randoms.get(v.getId()) != null && PINLayout.this.mInputPassword.length() < PINLayout.this.listener.getMaxInputLimit()) {
            Integer input = (Integer) PINLayout.this.randoms.get(v.getId());
            PINLayout pINLayout = PINLayout.this;
            pINLayout.mInputPassword = pINLayout.mInputPassword + input;
            PINLayout.this.listener.onPadInput(PINLayout.this.mInputPassword);
          }
        }
      }
    };
  }

  @SuppressLint({"NewApi"})
  public PINLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
    super(context, attrs, defStyleAttr, defStyleRes);
    this.mRowCount = 4;
    this.mColumnCount = 3;
    this.randoms = new SparseArrayCompat(10);
    this.mInputPassword = "";
  }

  public boolean shouldDelayChildPressedState() {
    return false;
  }

  protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
    int paddingLeft = getPaddingLeft();
    int paddingRight = getPaddingRight();
    int paddingTop = getPaddingTop();
    int paddingBottom = getPaddingBottom();
    boolean isRTL = ViewCompat.getLayoutDirection(this) == ViewCompat.LAYOUT_DIRECTION_RTL;
    int columnWidth = Math.round((float) (((right - left) - paddingLeft) - paddingRight)) / 3;
    int rowHeight = Math.round((float) (((bottom - top) - paddingTop) - paddingBottom)) / 4;
    int rowIndex = 0;
    int columnIndex = 0;
    for (int childIndex = 0; childIndex < getChildCount(); childIndex++) {
      View childView = getChildAt(childIndex);
      if (childView.getVisibility() != GONE) {
        int i;
        MarginLayoutParams lp = (MarginLayoutParams) childView.getLayoutParams();
        int childTop = (lp.topMargin + paddingTop) + (rowIndex * rowHeight);
        int childBottom = ((childTop - lp.topMargin) - lp.bottomMargin) + rowHeight;
        int i2 = paddingLeft + lp.leftMargin;
        if (isRTL) {
          i = 2 - columnIndex;
        } else {
          i = columnIndex;
        }
        int childLeft = i2 + (i * columnWidth);
        int childRight = ((childLeft - lp.leftMargin) - lp.rightMargin) + columnWidth;
        int childWidth = childRight - childLeft;
        int childHeight = childBottom - childTop;
        if (!(childWidth == childView.getMeasuredWidth() && childHeight == childView.getMeasuredHeight())) {
          childView.measure(MeasureSpec.makeMeasureSpec(childWidth, 1073741824), MeasureSpec.makeMeasureSpec(childHeight, 1073741824));
        }
        childView.layout(childLeft, childTop, childRight, childBottom);
        rowIndex = (((columnIndex + 1) / 3) + rowIndex) % 4;
        columnIndex = (columnIndex + 1) % 3;
      }
    }
  }

  public LayoutParams generateLayoutParams(AttributeSet attrs) {
    return new MarginLayoutParams(getContext(), attrs);
  }

  protected LayoutParams generateDefaultLayoutParams() {
    return new MarginLayoutParams(-2, -2);
  }

  protected LayoutParams generateLayoutParams(LayoutParams p) {
    return new MarginLayoutParams(p);
  }

  protected boolean checkLayoutParams(LayoutParams p) {
    return p instanceof MarginLayoutParams;
  }

  protected void onFinishInflate() {
    super.onFinishInflate();
    onRandom(false);
  }

  void onRandom(boolean random) {
    int i;
    this.randoms.clear();
    List<Integer> texts = new ArrayList();
    for (i = 0; i < padIds.length; i++) {
      texts.add(Integer.valueOf(i));
    }
    i = 0;
    if (random) {
      Collections.shuffle(texts);
    }
    for (Integer intValue : texts) {
      this.randoms.put(padIds[i], Integer.valueOf(intValue.intValue()));
      i++;
    }
    for (int findViewById : padIds) {
      ((Button) findViewById(findViewById)).setOnClickListener(this.mPadButtonClickListener);
    }
    View image = findViewById(R.id.passcode_btn_clear);
    if (image != null) {
      image.setOnClickListener(this.mPadButtonClickListener);
    }
    image = findViewById(R.id.passcode_btn_back);
    if (image != null) {
      image.setOnClickListener(this.mPadButtonClickListener);
    }
  }

  public void setPadButtonListener(IOnPadButtonClickListener listener) {
    this.listener = listener;
  }

  public void onClearClicked() {
    if (this.listener != null) {
      int size = this.mInputPassword.length();
      if (size > 0) {
        this.mInputPassword = this.mInputPassword.substring(0, size - 1);
        this.listener.onPadInput(this.mInputPassword);
      }
    }
  }

  public void reset(boolean notify) {
    this.mInputPassword = "";
    if (notify) {
      this.listener.onPadInput(this.mInputPassword);
    }
  }

  public void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    for (int findViewById : padIds) {
      ((Button) findViewById(findViewById)).setEnabled(enabled);
    }
  }

  public void pause() {
    reset(false);
  }

  public void resume() {
  }
}
