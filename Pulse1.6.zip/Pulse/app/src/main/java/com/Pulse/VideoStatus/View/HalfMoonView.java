package com.Pulse.VideoStatus.View;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import com.Pulse.VideoStatus.R;

public class HalfMoonView extends View {
    public Paint paint;
    public boolean b;

    public HalfMoonView(Context context) {
        super(context);
        setPaint();
    }

    public HalfMoonView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setPaint();
    }

    public final void setPaint() {
        this.paint = new Paint();
        this.paint.setAntiAlias(true);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("height : ");
        stringBuilder.append(getHeight());
        stringBuilder.append(" width : ");
        stringBuilder.append(getWidth());
        this.paint.setShader(new LinearGradient(0.0f, 0.0f, (float) HalfMoonContext.a(getContext(), 40.0f), (float) HalfMoonContext.a(getContext(), 80.0f), new int[]{getResources().getColor(R.color.app_gradiant_start), getResources().getColor(R.color.app_gradiant_center), getResources().getColor(R.color.app_gradiant_end)}, new float[]{0.0f, 0.33f, 1.0f}, Shader.TileMode.CLAMP));

    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.b) {
            float f = (float) (width / 2);
            canvas.drawCircle(f, (float) (height / 2), f, this.paint);
            return;
        }
        canvas.drawCircle(0.0f, (float) (height / 2), (float) width, this.paint);
    }

}
