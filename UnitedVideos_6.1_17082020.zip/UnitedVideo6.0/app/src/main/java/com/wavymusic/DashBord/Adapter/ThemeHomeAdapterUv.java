package com.wavymusic.DashBord.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.UnitedVideos.AppConstant.UvConstant;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.Download.ThemeDownloadUv;
import com.wavymusic.DashBord.Model.ThemeHomeModelUv;
import com.wavymusic.DashBord.View.AVLoadingView.AVLoadingIndicatorView;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.DashBord.activity.ThemeAllActivityUv;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;
import java.io.File;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeHomeAdapterUv extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int INVISIBLE_ITEM_TYPE = 1;

    public int e = -1;
    public int f = -1;
    private Context mContext;
    private ArrayList<ThemeHomeModelUv> themeCategoryList;
    private DashbordActivity ActivityOfTheme;

    public ThemeHomeAdapterUv(Context mContext, ArrayList<ThemeHomeModelUv> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (DashbordActivity) mContext;
        this.themeCategoryList = themeCategoryList;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
//        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_home_item_uv, viewGroup, false);
//        return new ThemeViewHolder(v);
        if (viewType == INVISIBLE_ITEM_TYPE) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item_layout_more, viewGroup, false);
            return new MoreViewHolder(view);
        } else {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_home_item_uv, viewGroup, false);
            return new ThemeViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (getItemViewType(position) == ITEM_TYPE_DATA) {
            if (holder instanceof ThemeViewHolder) {
                final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
                final ThemeHomeModelUv themelModel = themeCategoryList.get(position);
                Glide.with(mContext).load(themelModel.getImage()).diskCacheStrategy(DiskCacheStrategy.ALL).into(viewHolder.iv_thumb);
                if (!themelModel.isAvailableOffline) {
                    if (themelModel.isDownloading) {
                        viewHolder.ivDownload.setVisibility(View.GONE);
                        viewHolder.ivUseTheme.setVisibility(View.GONE);
                        viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                    } else {
                        viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                        viewHolder.ivDownload.setVisibility(View.VISIBLE);
                        viewHolder.ivUseTheme.setVisibility(View.GONE);
                    }
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    viewHolder.ivUseTheme.setVisibility(View.VISIBLE);
                }
            /*if (themelModel.getIsNewRealise().equals("1")){
                int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
                String BundelName = themelModel.getBundelName();
                File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
                int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));
                if (BundelFileSize == UnityBundeldSize) {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    Log.e("TAG","What's New "+themelModel.getBundelName());
                }
            }*/
                viewHolder.tvThemeName.setText(themelModel.getThemeName());
                viewHolder.tvThemeName.setSelected(true);
//            viewHolder.tvInfo.setText("Image: " + String.valueOf(themelModel.getImg_no_of()));
                viewHolder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DownloadThemeFiles(position, viewHolder.ivDownload, viewHolder.ivUseTheme, viewHolder.ThemeDownProgress, viewHolder.indicatorThemeProgress, viewHolder.tvThemeDownProgress, themelModel);

                    }
                });
            }
        } else {
            final MoreViewHolder viewHolder = (MoreViewHolder) holder;
            viewHolder.layoutMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoToViewAllThemeUv();
                }
            });
        }
    }

    private void GoToViewAllThemeUv() {
        Intent intent = new Intent(ActivityOfTheme, ThemeAllActivityUv.class);
        intent.putExtra("IsFromLanguage", ActivityOfTheme.IsFromLanguage);
        ActivityOfTheme.startActivity(intent);
        ActivityOfTheme.finish();
    }

    @Override
    public int getItemCount() {
        return themeCategoryList.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (position > 5) {
            return INVISIBLE_ITEM_TYPE;
        } else {
            if (themeCategoryList.size() > position) {
                return ITEM_TYPE_DATA;
            } else {
                return INVISIBLE_ITEM_TYPE;
            }
        }
    }


    private void DownloadThemeFiles(int position, ImageView ivDownload, ImageView ivuseTheme, LinearLayout themeDownProgress, AVLoadingIndicatorView avLoadingIndicatorView, TextView tvThemeDownprogress, ThemeHomeModelUv themelModel) {
        int UnityBundeldSize = Integer.parseInt(themelModel.getBundelSize());
        String BundelName = themelModel.getBundelName();
        File BundelPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + BundelName);
        int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));

        UvConstant.BundelPath = themelModel.getBundelPath();
        UvConstant.PrefebName = themelModel.getPrefebName();
        UvConstant.AudioPath = themelModel.getAnimSoundPath();

        UvConstant.VideoType = themelModel.getVideoType();
        UvConstant.ImageWidth = themelModel.getImageWidht();
        UvConstant.ImageHeight = themelModel.getImageHeight();
        UvConstant.NoofImage = themelModel.getImg_no_of();
        if (new File(Utils.INSTANCE.getThemeFolderPath() + BundelName).exists()) {
            if (BundelFileSize == UnityBundeldSize) {
                if (!themelModel.isDownloading) {
                    if (MyApplication.mInterstitialAdUv != null && MyApplication.mInterstitialAdUv.isLoaded()) {
                        MyApplication.AdsIdUv = 2;
                        MyApplication.AdsShowContext = ActivityOfTheme;
                        MyApplication.mInterstitialAdUv.show();
                    } else if (MyApplication.fbinterstitialAdUv != null && MyApplication.fbinterstitialAdUv.isAdLoaded()) {
                        MyApplication.AdsIdUv = 2;
                        MyApplication.AdsShowContext = ActivityOfTheme;
                        MyApplication.fbinterstitialAdUv.show();
                    } else {
                        ActivityOfTheme.ShowBannerAds();
                        String AllFilePath = themelModel.getBundelPath() + MyApplication.SPLIT_PATTERN + themelModel.getPrefebName() + MyApplication.SPLIT_PATTERN + themelModel.getAnimSoundPath() + MyApplication.SPLIT_PATTERN + themelModel.getVideoType();
                        UnityPlayer.UnitySendMessage("AndroidManager", "GoUVPreview", AllFilePath);
                        ActivityOfTheme.finish();
                    }
                } else {
                    Toast.makeText(mContext, "Please Wait Theme Download Process Running", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    avLoadingIndicatorView.smoothToShow();
                    DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                    new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, ivuseTheme, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                avLoadingIndicatorView.smoothToShow();
                DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                new ThemeDownloadUv(mContext, themelModel.getBundelUrl(), themelModel.getBundelName(), themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), ivDownload, ivuseTheme, themeDownProgress, avLoadingIndicatorView, tvThemeDownprogress, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void DownloadIncrement(String CatId, String ThemeId) {
        APIInterface apiInterface = APIClient.getClientUv().create(APIInterface.class);
        Call<JsonObject> call = apiInterface.DownloadIncrement(AppConstant.Token, AppConstant.ApplicationId, CatId, ThemeId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {

                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }


    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload;
        TextView tvThemeName, tvThemeDownProgress;
        ImageView ivUseTheme;
        AVLoadingIndicatorView indicatorThemeProgress;
        LinearLayout ThemeDownProgress;
        LinearLayout layoutDownloadMask;
        LinearLayout layoutBottomPanel;
        RelativeLayout layoutInfo;
        TextView tvInfo;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
            ivUseTheme = itemView.findViewById(R.id.ivUseTheme);
            layoutDownloadMask = itemView.findViewById(R.id.downloadMask);
            layoutBottomPanel = itemView.findViewById(R.id.ll_bootom_panel);
            layoutInfo = itemView.findViewById(R.id.layout_info);
            tvInfo = itemView.findViewById(R.id.tvInfo);
        }
    }

    public class MoreViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout layoutMore;

        MoreViewHolder(View itemView) {
            super(itemView);
            layoutMore = itemView.findViewById(R.id.rl_More);
        }
    }
}
