package com.example.knowledgetrivia.controller;

import android.app.ProgressDialog;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.models.Report;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.muddzdev.styleabletoast.StyleableToast.Builder;
import java.util.UUID;


public class ReportController extends AppCompatActivity {
    private EditText comments;
    private EditText email;
    private int questionNumber;
    private RadioGroup radioGroup;
    private MediaPlayer tick;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_report_controller);
        String stringExtra = getIntent().getStringExtra("question");
        this.questionNumber = getIntent().getIntExtra("number", -1);
        this.tick = MediaPlayer.create(this, R.raw.tick);
        this.email = (EditText) findViewById(R.id.report_email);
        this.comments = (EditText) findViewById(R.id.report_comments);
        this.radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        ((TextView) findViewById(R.id.showfav_question)).setText(stringExtra);
        findViewById(R.id.cancelButton).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ReportController.this.tick.start();
                ReportController.this.finish();
            }
        });
        findViewById(R.id.sent_report_button).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ReportController.this.tick.start();
                ReportController reportController = ReportController.this;
                String str = (String) ((RadioButton) reportController.findViewById(reportController.radioGroup.getCheckedRadioButtonId())).getText();
                String obj = ReportController.this.email.getText().toString();
                String obj2 = ReportController.this.comments.getText().toString();
                String str2 = "Should Not Be Empty.";
                if (obj.isEmpty()) {
                    ReportController.this.email.setError(str2);
                } else if (obj2.isEmpty()) {
                    ReportController.this.comments.setError(str2);
                } else {
                    Toast.makeText(ReportController.this,"Report submitted Success",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
