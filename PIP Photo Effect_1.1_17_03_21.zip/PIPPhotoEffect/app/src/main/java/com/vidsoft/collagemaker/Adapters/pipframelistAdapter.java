package com.vidsoft.collagemaker.Adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.vidsoft.collagemaker.pipphotoeffect.R;


public class pipframelistAdapter extends BaseAdapter {
    private Context context;
    public Integer[] thumbIds;

    public pipframelistAdapter(final Context mContext) {
        super();
        this.thumbIds = new Integer[]{Integer.valueOf(R.drawable.pip_alphabet_a),
                Integer.valueOf(R.drawable.pip_alphabet_b),
                Integer.valueOf(R.drawable.pip_alphabet_c),
                Integer.valueOf(R.drawable.pip_alphabet_d),
                Integer.valueOf(R.drawable.pip_alphabet_e),
                Integer.valueOf(R.drawable.pip_alphabet_f),
                Integer.valueOf(R.drawable.pip_alphabet_g),
                Integer.valueOf(R.drawable.pip_alphabet_h),
                Integer.valueOf(R.drawable.pip_alphabet_i),
                Integer.valueOf(R.drawable.pip_alphabet_j),
                Integer.valueOf(R.drawable.pip_alphabet_k),
                Integer.valueOf(R.drawable.pip_alphabet_l),
                Integer.valueOf(R.drawable.pip_alphabet_m),
                Integer.valueOf(R.drawable.pip_alphabet_n),
                Integer.valueOf(R.drawable.pip_alphabet_o),
                Integer.valueOf(R.drawable.pip_alphabet_p),
                Integer.valueOf(R.drawable.pip_alphabet_q),
                Integer.valueOf(R.drawable.pip_alphabet_r),
                Integer.valueOf(R.drawable.pip_alphabet_s),
                Integer.valueOf(R.drawable.pip_alphabet_t),
                Integer.valueOf(R.drawable.pip_alphabet_u),
                Integer.valueOf(R.drawable.pip_alphabet_v),
                Integer.valueOf(R.drawable.pip_alphabet_w),
                Integer.valueOf(R.drawable.pip_alphabet_x),
                Integer.valueOf(R.drawable.pip_alphabet_y),
                Integer.valueOf(R.drawable.pip_alphabet_z)};
        this.context = mContext;
    }

    public int getCount() {
        return this.thumbIds.length;
    }

    public Object getItem(final int n) {
        return this.thumbIds[n];
    }

    public long getItemId(final int n) {
        return 0L;
    }

    public View getView(final int n, final View view, final ViewGroup viewGroup) {
        final RelativeLayout relativeLayout = new RelativeLayout(this.context);
        relativeLayout.removeAllViewsInLayout();
        final ImageView imageView = new ImageView(this.context);
        imageView.setImageResource((int) this.thumbIds[n]);
        relativeLayout.addView((View) imageView);
        return (View) relativeLayout;
    }
}
