package com.wavymusic.notification.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.View.AVLoadingView.AVLoadingIndicatorView;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.notification.Download.DownloadFile;

import java.io.File;

public class NotificationActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = NotificationActivity.this;
    ImageView ivBack;
    public LinearLayout layoutDownload;
    public ImageView ivThumb;
    public ImageView ivThumbDownload;
    public ImageView ivUseTheme;
    public TextView tvVideoName, tvProgress;
    public AVLoadingIndicatorView indicatorView;
    public RelativeLayout layoutNotification;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        BindView();
        PutAnalyticsEvent();
        if (MyApplication.notificcationModels != null && MyApplication.notificcationModels.size() != 0) {
            tvVideoName.setText(MyApplication.notificcationModels.get(0).getThemeName());
            Glide.with(activity).load(MyApplication.notificcationModels.get(0).getThemeThumbnail()).diskCacheStrategy(DiskCacheStrategy.ALL).into(ivThumb);
            if (new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(0).getSongFileName()).exists() && new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(0).getParticalBundelName()).exists()) {
                ivThumbDownload.setVisibility(View.GONE);
                tvProgress.setVisibility(View.GONE);
                ivUseTheme.setVisibility(View.VISIBLE);
            }
        }
        BannerAds();
    }

    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BindView() {
        ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(this);
        ivThumb = findViewById(R.id.ivThumb);
        tvVideoName = findViewById(R.id.tvVideoName);
        tvProgress = findViewById(R.id.tv_Progress);
        ivThumbDownload = findViewById(R.id.ivThumbDownload);
        indicatorView = findViewById(R.id.indicator);
        layoutDownload = findViewById(R.id.ll_download);
        ivUseTheme = findViewById(R.id.ivUseTheme);
        layoutNotification = findViewById(R.id.rlnotification);

        layoutNotification.setOnClickListener(this);
        ivUseTheme.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "NotificationActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DownloadFile(int position) {
        if (MyApplication.notificcationModels != null) {
            MyApplication.NotificationPath = MyApplication.notificcationModels.get(position).getSoundPath() + MyApplication.SPLIT_PATTERN + Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(position).getThemeName() + ".png" + MyApplication.SPLIT_PATTERN + MyApplication.notificcationModels.get(position).getBundelPath() + MyApplication.SPLIT_PATTERN + MyApplication.notificcationModels.get(position).getGameobjectName() + MyApplication.SPLIT_PATTERN + AppConstant.ThemeHome;
            int SoundFileSize = Integer.parseInt(String.valueOf(new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(position).getSongFileName()).length()));
            int ParticalSize = Integer.parseInt(String.valueOf(new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(position).getParticalBundelName()).length()));
            if (new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(position).getSongFileName()).exists() && new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(position).getParticalBundelName()).exists()) {
                if (SoundFileSize == MyApplication.notificcationModels.get(position).getSongSize() && ParticalSize == MyApplication.notificcationModels.get(position).getParticalSize()) {
                    UnityPlayer.UnitySendMessage("AndroidManager", "GoWavyPreview", MyApplication.NotificationPath);
                    ShowBannerAds();
                    finish();
                } else {
                    if (Utils.checkConnectivity(activity, true)) {
                        ivThumbDownload.setVisibility(View.GONE);
                        tvProgress.setVisibility(View.VISIBLE);
                        new DownloadFile(activity, ivThumbDownload, ivUseTheme, tvProgress, MyApplication.notificcationModels);
                    } else {
                        Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                    }
                }
            } else {
                if (Utils.checkConnectivity(activity, true)) {
                    ivThumbDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.VISIBLE);
                    new DownloadFile(activity, ivThumbDownload, ivUseTheme, tvProgress, MyApplication.notificcationModels);
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                onBackPressed();
                break;
            case R.id.rlnotification:
                DownloadFile(0);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}