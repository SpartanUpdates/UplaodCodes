package com.example.knowledgetrivia.controller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;

import java.util.ArrayList;

public class SLAdapter extends ArrayAdapter<String> {
    private Context context;
    private ArrayList<String> mylevel;
    private ArrayList<Boolean> showLevel;

    SLAdapter(Context context, ArrayList<String> arrayList, ArrayList<Boolean> arrayList2) {
        super(context, R.layout.listview_showingscore, R.id.raw_list_ss_title, arrayList);
        this.context = context;
        this.mylevel = arrayList;
        this.showLevel = arrayList2;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        view = ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.listview_showingscore, viewGroup, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.imageView7);
        TextView textView = (TextView) view.findViewById(R.id.raw_list_ss_title);
        textView.setText((CharSequence) this.mylevel.get(i));
        if (((Boolean) this.showLevel.get(i)).booleanValue()) {
            imageView.setVisibility(View.INVISIBLE);
        } else {
            textView.setTextColor(-1);
            view.findViewById(R.id.round_layout_lss).setBackground(ContextCompat.getDrawable(this.context, R.drawable.round_corner_grey));
        }
        return view;
    }
}
