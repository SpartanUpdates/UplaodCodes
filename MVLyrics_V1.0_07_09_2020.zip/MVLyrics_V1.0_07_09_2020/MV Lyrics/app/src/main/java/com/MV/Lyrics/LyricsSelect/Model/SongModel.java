package com.MV.Lyrics.LyricsSelect.Model;

public class SongModel {
    private int id;
    private String SongId;
    private String SongCategoryId;
    private String SongName;
    private String SongUrl;
    private String SongSize;
    private String Songfull_url;

    private String ZipFolderName;
    private String ZipDownloadCatName;
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSongId() {
        return SongId;
    }

    public void setSongId(String songId) {
        SongId = songId;
    }

    public String getSongCategoryId() {
        return SongCategoryId;
    }

    public void setSongCategoryId(String songCategoryId) {
        SongCategoryId = songCategoryId;
    }

    public String getSongName() {
        return SongName;
    }

    public void setSongName(String songName) {
        SongName = songName;
    }

    public String getSongUrl() {
        return SongUrl;
    }

    public void setSongUrl(String songUrl) {
        SongUrl = songUrl;
    }

    public String getSongSize() {
        return SongSize;
    }

    public void setSongSize(String songSize) {
        SongSize = songSize;
    }

    public String getSongfull_url() {
        return Songfull_url;
    }

    public void setSongfull_url(String songfull_url) {
        Songfull_url = songfull_url;
    }

    public String getZipFolderName() {
        return ZipFolderName;
    }

    public void setZipFolderName(String zipFolderName) {
        ZipFolderName = zipFolderName;
    }

    public String getZipDownloadCatName() {
        return ZipDownloadCatName;
    }

    public void setZipDownloadCatName(String zipDownloadCatName) {
        ZipDownloadCatName = zipDownloadCatName;
    }
}
