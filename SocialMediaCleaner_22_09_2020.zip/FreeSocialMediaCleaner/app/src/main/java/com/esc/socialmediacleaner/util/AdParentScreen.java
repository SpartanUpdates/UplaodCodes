package com.esc.socialmediacleaner.util;

import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.esc.socialmediacleaner.R;

public class AdParentScreen extends BaseActivity {
    private static final int ADMOB = 1;
    private static final int FAN = 2;
    private static final int STOP_ATTEMPT = 10;
    private LinearLayout adContainer;
    private AdSize adSize;
    private AdView adViewAdmob;
    private int attempt = 1;
    private int height;
    private int width;

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public void onDestroy() {
//        com.facebook.ads.AdView adView = this.adViewFB;
//        if (adView != null) {
//            adView.destroy();
//        }
//        AdView adView2 = this.adViewAdmob;
//        if (adView2 != null) {
//            adView2.destroy();
//        }
        super.onDestroy();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.attempt = 1;
    }

    public void setDeviceDimensio() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
    }
}
