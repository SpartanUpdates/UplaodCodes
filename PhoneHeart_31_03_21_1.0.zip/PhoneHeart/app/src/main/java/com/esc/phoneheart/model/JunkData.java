package com.esc.phoneheart.model;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.AsyncTask.Status;
import android.os.Build.VERSION;
import android.util.Log;

import com.esc.phoneheart.activity.BaseActivity;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.pref.SharedPrefUtil;
import com.esc.phoneheart.utility.Util;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class JunkData {
    public static final long SIZE_LIMIT = 10485760;
    public static final String f4843a = String.format(Locale.US, "content-length: %d", new Object[]{Long.valueOf(Long.MAX_VALUE)});
    public long APK_CACHE_SIZE;
    public long APP_CACHE_SIZE;
    public long BOOST_CACHE_SIZE;
    public long EMPTY_CACHE_SIZE;
    public long SYS_CACHE_SIZE;
    public long TEMP_CACHE_SIZE;
    public Context mcontext;
    public boolean allChecked;
    public boolean apk_checked = false;
    public boolean boost_checked = true;
    public long boostsizechecked;
    public boolean cache_checked = true;
    public boolean cancel;
    public ArrayList<JunkListModel> dataTodelete;
    public JunkDeleteTask deleteJunk;
    public boolean emptyfolder_checked = true;
    public HashMap<String, ArrayList<JunkListModel>> junkDataMap;
    public JunkDeleteTask junkDeleteTask;
    public ArrayList<String> listDataHeader;
    public int midState;
    public int partialDataSize;
    public boolean partialDelete;
    public boolean removeBoost;
    public boolean removeSysCache;
    public boolean showVideoScreenDirectly;
    public boolean sys_cache_deleted;
    public boolean sys_checked = true;
    public boolean temp_checked = true;
    public long totSelectedToDeleteSize;
    public int totalDeletedCount;
    public long totalDeletedSize;
    public int totalSelectedCategories;
    public int totalcount;
    public int totalemptyfolders;
    public int totalemptyfoldersDeleted;
    public int totalfolders;
    public int totaljunkcount;
    public long totalsize;
    public int totselectedTodelete;

    public class JunkDeleteTask extends AsyncTask<String, Long, String> {

        public ProgressUpdate progressupdate;
        public boolean deleteRemaining;
        public int totalemptyfolders;

        public JunkDeleteTask(Context context, ProgressUpdate progressUpdate, boolean z) {
            mcontext = context;
            deleteRemaining = z;
            progressupdate = progressUpdate;
        }

        private void clearAllCache() {
            PackageManager packageManager = mcontext.getPackageManager();
            Method[] declaredMethods = packageManager.getClass().getDeclaredMethods();
            int length = declaredMethods.length;
            int i = 0;
            while (i < length) {
                Method method = declaredMethods[i];
                if (!method.getName().equals("freeStorage")) {
                    i++;
                } else if (VERSION.SDK_INT < 23) {
                    try {
                        method.invoke(packageManager, new Object[]{Long.valueOf(Long.MAX_VALUE), null});
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } else if (method.getParameterTypes().length == 2) {
                    try {
                        method.invoke(packageManager, new Object[]{Long.valueOf(0), null});
                        return;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        return;
                    }
                } else {
                    return;
                }
            }
        }

        public void onCancelled() {
            super.onCancelled();
            if (JunkData.this.cancel) {
                this.progressupdate.onUpdate(-3, -3, -3, -3);
            }
        }

        public String doInBackground(String... strArr) {
            int i;
            String str;
            ActivityManager activityManager;
            String str2;
            String str3;
            ArrayList arrayList;
            ActivityManager activityManager2;
            String str4;
            String str5;
            String str6;
            String str7;
            String str8;
            String str9;
            if (VERSION.SDK_INT < 23) {
                clearAllCache();
            } else {
                JunkData junkData = JunkData.this;
                if (!junkData.sys_checked || !junkData.cache_checked || !Util.isConnectingToInternet(mcontext)) {
                    if (JunkData.this.cache_checked) {
                        GlobalData.cacheCheckedAboveMarshmallow = true;
                    }
                } else if (VERSION.SDK_INT > 19) {
                    GlobalData.cacheCheckedAboveMarshmallow = true;
                } else {
                    GlobalData.cacheCheckedAboveMarshmallow = false;
                }
            }
            @SuppressLint("WrongConstant") ActivityManager activityManager3 = (ActivityManager) mcontext.getSystemService("activity");
            boolean z = deleteRemaining;
            String str10 = "usercache";
            String str11 = "boost";
            String str12 = "temp";
            String str13 = "cancel == true ";
            String str14 = SharedPrefUtil.RAMATPAUSE;
            String str15 = SharedPrefUtil.RAMPAUSE;
            String str16 = SharedPrefUtil.LASTCOOLTIME;
            String str17 = "empty";
            String str18 = "JJJJJJJJJJJJ";
            String str19 = Intent.ACTION_MEDIA_SCANNER_SCAN_FILE;
            String str20 = "";
            if (z) {
                JunkData junkData2 = JunkData.this;
                junkData2.partialDelete = false;
                int a2 = junkData2.partialDataSize;
                while (a2 < JunkData.this.dataTodelete.size()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("cancel val ");
                    sb.append(JunkData.this.cancel);
                    Log.d(str18, sb.toString());
                    JunkData junkData3 = JunkData.this;
                    if (junkData3.cancel) {
                        Log.d(str18, str13);
                        return null;
                    }
                    if (((JunkListModel) junkData3.dataTodelete.get(a2)).ischecked) {
                        str9 = str13;
                        str8 = str18;
                        publishProgress(new Long[]{Long.valueOf((long) (((a2 + 1) * 100) / JunkData.this.dataTodelete.size())), Long.valueOf(JunkData.this.totalDeletedSize), Long.valueOf((long) JunkData.this.totalDeletedCount), Long.valueOf(JunkData.this.totalsize)});
                        JunkData junkData4 = JunkData.this;
                        junkData4.totalDeletedCount++;
                        str7 = str14;
                        junkData4.totalDeletedSize += ((JunkListModel) junkData4.dataTodelete.get(a2)).size;
                        if (((JunkListModel) JunkData.this.dataTodelete.get(a2)).type.equalsIgnoreCase(str12)) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(str20);
                            sb2.append(((JunkListModel) JunkData.this.dataTodelete.get(a2)).path);
                            File file = new File(new File(sb2.toString()).getParent());
                            if (file.isDirectory()) {
                                JunkData.this.deleteFromFolder(file.getPath());
                            }
                        } else if (((JunkListModel) JunkData.this.dataTodelete.get(a2)).type.equalsIgnoreCase(str11)) {
                            activityManager3.killBackgroundProcesses(((JunkListModel) JunkData.this.dataTodelete.get(a2)).name);
                            JunkData junkData5 = JunkData.this;
                            junkData5.boostsizechecked += ((JunkListModel) junkData5.dataTodelete.get(a2)).size;
                        } else if (!((JunkListModel) JunkData.this.dataTodelete.get(a2)).type.equalsIgnoreCase(str10)) {
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(str20);
                            sb3.append(((JunkListModel) JunkData.this.dataTodelete.get(a2)).path);
                            File file2 = new File(sb3.toString());
                            if (file2.isDirectory()) {
                                JunkData junkData6 = JunkData.this;
                                junkData6.deleteFromFolder(((JunkListModel) junkData6.dataTodelete.get(a2)).path);
                            }
                            if (((JunkListModel) JunkData.this.dataTodelete.get(a2)).type.equalsIgnoreCase(str17)) {
                                JunkData.this.totalemptyfoldersDeleted++;
                            }
                            if (file2.exists()) {
                                file2.delete();
                                mcontext.sendBroadcast(new Intent(str19, Uri.fromFile(file2)));
                            }
                        } else {
                            for (int i2 = 0; i2 < ((JunkListModel) JunkData.this.dataTodelete.get(a2)).fileslist.size(); i2++) {
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append(str20);
                                sb4.append((String) ((JunkListModel) JunkData.this.dataTodelete.get(a2)).fileslist.get(i2));
                                File file3 = new File(sb4.toString());
                                if (file3.exists()) {
                                    file3.delete();
                                    mcontext.sendBroadcast(new Intent(str19, Uri.fromFile(file3)));
                                }
                            }
                        }
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        str9 = str13;
                        str7 = str14;
                        str8 = str18;
                    }
                    a2++;
                    str13 = str9;
                    str18 = str8;
                    str14 = str7;
                }
                String str21 = str14;
                JunkData junkData7 = JunkData.this;
                if (junkData7.boost_checked) {
                    junkData7.killAllProcesses();
                    SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(mcontext);
                    String str22 = SharedPrefUtil.LASTBOOSTTIME;
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(str20);
                    sb5.append(System.currentTimeMillis());
                    sharedPrefUtil.saveString(str22, sb5.toString());
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(str20);
                    sb6.append(System.currentTimeMillis());
                    sharedPrefUtil.saveString(str16, sb6.toString());
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append(str20);
                    sb7.append(System.currentTimeMillis());
                    sharedPrefUtil.saveString(str15, sb7.toString());
                    StringBuilder sb8 = new StringBuilder();
                    sb8.append(str20);
                    JunkData junkData8 = JunkData.this;
                    sb8.append(junkData8.getRamSize(mcontext));
                    sharedPrefUtil.saveString(str21, sb8.toString());
                }
                return null;
            }
            String str23 = str13;
            String str24 = str14;
            String str25 = str18;
            totalemptyfolders = 0;
            JunkData.this.dataTodelete = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            boolean z2;
            JunkData junkData9 = JunkData.this;
            if (junkData9.removeBoost) {
                junkData9.totalSelectedCategories = 4;
            }
            JunkData junkData10 = JunkData.this;
            if (junkData10.removeSysCache) {
                junkData10.totalSelectedCategories = 3;
            }
            for (int i3 = 0; i3 < junkDataMap.size(); i3++) {
                JunkData junkData11 = JunkData.this;
                ArrayList<JunkListModel> arrayList3 = (ArrayList) junkData11.junkDataMap.get(junkData11.listDataHeader.get(i3));
                int i4 = 0;
                while (i4 < arrayList3.size()) {
                    if (arrayList3.get(i4).ischecked) {
                        str5 = str24;
                        dataTodelete.add(arrayList3.get(i4));
                        if (arrayList3.get(i4).type.equalsIgnoreCase(str17)) {
                            totalemptyfolders++;
                        }
                        StringBuilder sb9 = new StringBuilder();
                        sb9.append(arrayList3.get(i4).name);
                        sb9.append(str20);
                        sb9.append(arrayList3.get(i4).path);
                        if (!arrayList2.contains(sb9.toString())) {
                            StringBuilder sb10 = new StringBuilder();
                            sb10.append(arrayList3.get(i4).name);
                            sb10.append(str20);
                            sb10.append(arrayList3.get(i4).path);
                            arrayList2.add(sb10.toString());
                        }
                        JunkData junkData12 = JunkData.this;
                        str4 = str15;
                        str6 = str16;
                        arrayList = arrayList3;
                        activityManager2 = activityManager3;
                        str3 = str10;
                        junkData12.totSelectedToDeleteSize += ((JunkListModel) arrayList3.get(i4)).size;
                        JunkData.this.totselectedTodelete++;
                    } else {
                        arrayList = arrayList3;
                        activityManager2 = activityManager3;
                        str3 = str10;
                        str5 = str24;
                        str4 = str15;
                        str6 = str16;
                    }
                    i4++;
                    str16 = str6;
                    str24 = str5;
                    str15 = str4;
                    activityManager3 = activityManager2;
                    arrayList3 = arrayList;
                    str10 = str3;
                }
                ActivityManager activityManager4 = activityManager3;
                String str26 = str10;
                String str27 = str24;
                String str28 = str15;
                String str29 = str16;
            }
            ActivityManager activityManager5 = activityManager3;
            String str30 = str10;
            String str31 = str24;
            String str32 = str15;
            String str33 = str16;
            JunkData junkData13 = JunkData.this;
            int i5 = (junkData13.totselectedTodelete * 100) / junkData13.totaljunkcount;
            if (Util.isAdsFree(mcontext) || !new SharedPrefUtil(mcontext).getBoolean("RVJ_AD") || ((i5 <= 20 && JunkData.this.totSelectedToDeleteSize <= 10485760) || !Util.isConnectingToInternet(mcontext))) {
                z2 = true;
            } else {
                z2 = true;
                JunkData.this.partialDelete = true;
            }
            JunkData junkData14 = JunkData.this;
            if (junkData14.partialDelete) {
                junkData14.showVideoScreenDirectly = z2;
            }
            JunkData junkData15 = JunkData.this;
            if (junkData15.partialDelete) {
                i = junkData15.totselectedTodelete < 11 ? 50 : 10;
                JunkData.this.midState = i;
            } else {
                i = 100;
            }
            JunkData.this.totselectedTodelete = arrayList2.size();
            if (JunkData.this.dataTodelete.size() != 0) {
                JunkData junkData16 = JunkData.this;
                junkData16.partialDataSize = (junkData16.dataTodelete.size() * i) / 100;
                int i6 = 0;
                while (i6 < JunkData.this.partialDataSize) {
                    JunkData junkData17 = JunkData.this;
                    if (junkData17.cancel) {
                        Log.d(str25, str23);
                        return null;
                    }
                    String str34 = str23;
                    String str35 = str25;
                    if (((JunkListModel) junkData17.dataTodelete.get(i6)).ischecked) {
                        publishProgress(new Long[]{Long.valueOf((long) (((i6 + 1) * 100) / JunkData.this.dataTodelete.size())), Long.valueOf(JunkData.this.totalDeletedSize), Long.valueOf((long) JunkData.this.totalDeletedCount), Long.valueOf(JunkData.this.totalsize)});
                        JunkData junkData18 = JunkData.this;
                        junkData18.totalDeletedCount++;
                        str = str11;
                        junkData18.totalDeletedSize += ((JunkListModel) junkData18.dataTodelete.get(i6)).size;
                        if (((JunkListModel) JunkData.this.dataTodelete.get(i6)).type.equalsIgnoreCase(str12)) {
                            StringBuilder sb11 = new StringBuilder();
                            sb11.append(str20);
                            sb11.append(((JunkListModel) JunkData.this.dataTodelete.get(i6)).path);
                            File file4 = new File(new File(sb11.toString()).getParent());
                            if (file4.isDirectory()) {
                                JunkData.this.deleteFromFolder(file4.getPath());
                            }
                            str25 = str35;
                            activityManager = activityManager5;
                        } else {
                            String str36 = str;
                            if (((JunkListModel) JunkData.this.dataTodelete.get(i6)).type.equalsIgnoreCase(str36)) {
                                activityManager = activityManager5;
                                activityManager.killBackgroundProcesses(((JunkListModel) JunkData.this.dataTodelete.get(i6)).name);
                                JunkData junkData19 = JunkData.this;
                                str25 = str35;
                                str = str36;
                                junkData19.boostsizechecked += ((JunkListModel) junkData19.dataTodelete.get(i6)).size;
                            } else {
                                str25 = str35;
                                str = str36;
                                activityManager = activityManager5;
                                str2 = str30;
                                if (!((JunkListModel) JunkData.this.dataTodelete.get(i6)).type.equalsIgnoreCase(str2)) {
                                    StringBuilder sb12 = new StringBuilder();
                                    sb12.append(str20);
                                    sb12.append(((JunkListModel) JunkData.this.dataTodelete.get(i6)).path);
                                    File file5 = new File(sb12.toString());
                                    if (file5.isDirectory()) {
                                        JunkData junkData20 = JunkData.this;
                                        junkData20.deleteFromFolder(((JunkListModel) junkData20.dataTodelete.get(i6)).path);
                                    }
                                    if (((JunkListModel) JunkData.this.dataTodelete.get(i6)).type.equalsIgnoreCase(str17)) {
                                        JunkData.this.totalemptyfoldersDeleted++;
                                    }
                                    if (file5.exists()) {
                                        file5.delete();
                                        mcontext.sendBroadcast(new Intent(str19, Uri.fromFile(file5)));
                                    }
                                } else {
                                    for (int i7 = 0; i7 < ((JunkListModel) JunkData.this.dataTodelete.get(i6)).fileslist.size(); i7++) {
                                        StringBuilder sb13 = new StringBuilder();
                                        sb13.append(str20);
                                        sb13.append((String) ((JunkListModel) JunkData.this.dataTodelete.get(i6)).fileslist.get(i7));
                                        File file6 = new File(sb13.toString());
                                        if (file6.exists()) {
                                            file6.delete();
                                            mcontext.sendBroadcast(new Intent(str19, Uri.fromFile(file6)));
                                        }
                                    }
                                }
                            }
                        }
                        str2 = str30;

                    } else {
                        str25 = str35;
                        str = str11;
                        activityManager = activityManager5;
                        str2 = str30;
                    }
                    i6++;
                    str23 = str34;
                    str30 = str2;
                    activityManager5 = activityManager;
                    str11 = str;
                }
                JunkData junkData21 = JunkData.this;
                if (junkData21.boost_checked && !junkData21.partialDelete) {
                    SharedPrefUtil sharedPrefUtil2 = new SharedPrefUtil(mcontext);
                    String str37 = SharedPrefUtil.LASTBOOSTTIME;
                    StringBuilder sb14 = new StringBuilder();
                    sb14.append(str20);
                    sb14.append(System.currentTimeMillis());
                    sharedPrefUtil2.saveString(str37, sb14.toString());
                    StringBuilder sb15 = new StringBuilder();
                    sb15.append(str20);
                    sb15.append(System.currentTimeMillis());
                    sharedPrefUtil2.saveString(str33, sb15.toString());
                    StringBuilder sb16 = new StringBuilder();
                    sb16.append(str20);
                    sb16.append(System.currentTimeMillis());
                    sharedPrefUtil2.saveString(str32, sb16.toString());
                    StringBuilder sb17 = new StringBuilder();
                    sb17.append(str20);
                    JunkData junkData22 = JunkData.this;
                    sb17.append(junkData22.getRamSize(mcontext));
                    sharedPrefUtil2.saveString(str31, sb17.toString());
                }
            }
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(str);
            StringBuilder sb = new StringBuilder();
            sb.append("onpost cancel ");
            sb.append(JunkData.this.cancel);
            Log.d("JJJJJJJJJJJJ", sb.toString());
            JunkData junkData = JunkData.this;
            if (junkData.cancel) {
                this.progressupdate.onUpdate(-3, -3, -3, -3);
            } else if (junkData.partialDelete) {
                this.progressupdate.onUpdate(-1, -1, -1, -1);
            } else {
                this.progressupdate.onUpdate(-2, -2, -2, -2);
                if (JunkData.this.allChecked) {
                    SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(mcontext);
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("");
                    sb2.append(System.currentTimeMillis());
                    sharedPrefUtil.saveString(SharedPrefUtil.JUNCCLEANTIME, sb2.toString());
                }
            }
        }

        public void onProgressUpdate(Long... lArr) {
            super.onProgressUpdate(lArr);
            this.progressupdate.onUpdate(lArr[0].longValue(), lArr[1].longValue(), lArr[2].longValue(), lArr[3].longValue());
        }
    }

    public interface ProgressUpdate {
        void onUpdate(long j, long j2, long j3, long j4);
    }

    public JunkData(HashMap<String, ArrayList<JunkListModel>> hashMap) {
        this.junkDataMap = hashMap;
        this.showVideoScreenDirectly = false;
        this.partialDelete = false;
        this.dataTodelete = new ArrayList<>();
        this.removeSysCache = false;
        this.allChecked = false;
    }

    public String deleteFromFolder(String str) {
        File file = new File(str);
        if (file.isDirectory()) {
            Log.d("TTTTTTTT", "is directory");
        }
        String[] list = file.list();
        if (file.isDirectory() && list != null) {
            for (int i = 0; i < list.length; i++) {
                String str2 = "log";
                if (list[i].toLowerCase().endsWith(str2) || list[i].toLowerCase().endsWith("xlog") || list[i].equalsIgnoreCase(str2) || list[i].toLowerCase().endsWith("tmp") || list[i].toLowerCase().endsWith("dat") || list[i].toLowerCase().endsWith("journal") || list[i].toLowerCase().endsWith("cuid") || list[i].toLowerCase().endsWith("bat") || list[i].toLowerCase().endsWith("dk") || list[i].toLowerCase().endsWith("xml") || list[i].toLowerCase().endsWith("nomedia") || list[i].toLowerCase().endsWith("bin") || list[i].toLowerCase().endsWith("thumbnail") || list[i].toLowerCase().endsWith("thumbnails") || list[i].toLowerCase().endsWith("js") || list[i].toLowerCase().endsWith("css") || list[i].toLowerCase().endsWith("file") || list[i].toLowerCase().endsWith("idx")) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(str);
                    sb.append("/");
                    sb.append(list[i]);
                    File file2 = new File(sb.toString());
                    file2.delete();
                    mcontext.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file2)));
                }
            }
        }
        return "";
    }

    public void killAllProcesses() {
        try {
            List<ApplicationInfo> installedApplications = mcontext.getPackageManager().getInstalledApplications(0);
            @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) mcontext.getSystemService("activity");
            ArrayList ignoredData = ((BaseActivity) mcontext).getIgnoredData();
            for (ApplicationInfo applicationInfo : installedApplications) {
                if ((applicationInfo.flags & 1) != 1) {
                    if (!applicationInfo.packageName.equals("")) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(applicationInfo.packageName);
                        if (!ignoredData.contains(sb.toString())) {
                            activityManager.killBackgroundProcesses(applicationInfo.packageName);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean showSavedTemp(String str, String str2) {
        if (str == null && str2 == null) {
            return false;
        }
        StringBuilder sb = new StringBuilder();
        String str3 = "";
        sb.append(str3);
        sb.append(System.currentTimeMillis());
        if (Util.checkTimeDifference(sb.toString(), str) > GlobalData.coolPause) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str3);
            sb2.append(System.currentTimeMillis());
            if (Util.checkTimeDifference(sb2.toString(), str2) > ((long) GlobalData.boostPause)) {
                return false;
            }
        }
        return true;
    }

    public void cancelCleaning() {
        Log.d("JJJJJJJJJJJJ", "cancel cleaning ");
        JunkDeleteTask junkDeleteTask2 = this.junkDeleteTask;
        if (junkDeleteTask2 != null && junkDeleteTask2.getStatus() == Status.RUNNING) {
            JunkDeleteTask junkDeleteTask3 = this.junkDeleteTask;
            if (junkDeleteTask3 != null) {
                this.cancel = true;
                junkDeleteTask3.cancel(true);
            }
        }
    }

    public void deleteJunk(Context context, ProgressUpdate progressUpdate, boolean z) {
        JunkDeleteTask junkDeleteTask2 = new JunkDeleteTask(context, progressUpdate, z);
        this.junkDeleteTask = junkDeleteTask2;
        junkDeleteTask2.execute(new String[0]);
    }

    public int getRamSize(Context context) {
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        MemoryInfo memoryInfo = new MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        long j = memoryInfo.totalMem;
        return Math.round((float) (((j - memoryInfo.availMem) * 100) / j)) - 1;
    }

    public long getSizeAsPerOS(long j) {
        return j;
    }

    public boolean isAlreadyBoosted(Context context) {
        SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(context);
        return showSavedTemp(sharedPrefUtil.getString(SharedPrefUtil.LASTCOOLTIME), sharedPrefUtil.getString(SharedPrefUtil.LASTBOOSTTIME));
    }
}
