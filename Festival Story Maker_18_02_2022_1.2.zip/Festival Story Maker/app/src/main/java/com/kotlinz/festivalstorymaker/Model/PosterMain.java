package com.kotlinz.festivalstorymaker.Model;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;


public class PosterMain {

    @SerializedName("response")
    private ArrayList<PosterCategory> mResponse;
    @SerializedName("success")
    private String mSuccess;

    public ArrayList<PosterCategory> getResponse() {
        return mResponse;
    }

    public void setResponse(ArrayList<PosterCategory> response) {
        mResponse = response;
    }

    public String getSuccess() {
        return mSuccess;
    }

    public void setSuccess(String success) {
        mSuccess = success;
    }

}
