package com.esc.phoneheart.animations;

import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Matrix.ScaleToFit;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.PointF;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import com.esc.phoneheart.R;
import com.esc.phoneheart.interfaceclass.AnimationStateChangedListener;
import java.text.DecimalFormat;
import androidx.annotation.ColorInt;
import androidx.annotation.FloatRange;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;

public class CircleProgressView extends View {
    public static final boolean DEBUG = false;
    public static final String TAG = "CircleView";
    public Direction a = Direction.CW;
    public float b = 0.0f;
    public float c = 0.0f;
    public float d = 0.0f;
    public DecimalFormat decimalFormat;
    public float e = 100.0f;
    public float f = 0.0f;
    public float g = -1.0f;
    public float h = 0.0f;
    public float i = 42.0f;
    public float j = 0.0f;
    public float k = 2.8f;
    public boolean l = false;
    public double m = 900.0d;
    public RectF mActualTextBounds = new RectF();
    public int mBackgroundCircleColor = 0;
    public Paint mBackgroundCirclePaint;
    public final int mBarColorStandard = -16738680;
    public int[] mBarColors = new int[]{-16738680};
    public Paint mBarPaint;
    public Paint mBarSpinnerPaint;
    public int mBarStartEndLineColor = -1442840576;
    public Paint mBarStartEndLinePaint;
    public float mBarStartEndLineSweep = 10.0f;
    public int mBarStartEndLineWidth = 0;
    public BarStartFinishLiner mBarStartFinishLiner = BarStartFinishLiner.NONE;
    public Cap mBarStrokeCap;
    public int mBarWidth = 40;
    public int mBlockCount;
    public float mBlockDegree;
    public float mBlockScale;
    public float mBlockScaleDegree;
    public PointF mCenter;
    public RectF mCircleBounds = new RectF();
    public RectF mCircleInnerContour = new RectF();
    public RectF mCircleOuterContour = new RectF();
    public Bitmap mClippingBitmap;
    public RectF mInnerCircleBound = new RectF();
    public int mInnerContourColor = -1442840576;
    public Paint mInnerContourPaint;
    public float mInnerContourSize = 1.0f;
    public boolean mIsAutoColorEnabled = false;
    public boolean mIsAutoTextSize;
    public int mLayoutHeight = 0;
    public int mLayoutWidth = 0;
    public Paint mMaskPaint;
    public int mOuterContourColor = -1442840576;
    public Paint mOuterContourPaint;
    public float mOuterContourSize = 1.0f;
    public RectF mOuterTextBounds = new RectF();
    public float mRelativeUniteSize;
    public int mRimColor = -1434201911;
    public Paint mRimPaint;
    public int mRimWidth = 40;
    public boolean mRoundToBlock;
    public boolean mRoundToWholeNumber;
    public boolean mSeekModeEnabled;
    public Paint mShaderlessBarPaint;
    public boolean mShowBlock;
    public boolean mShowTextWhileSpinning;
    public boolean mShowUnit;
    public int mSpinnerColor = -16738680;
    public Cap mSpinnerStrokeCap;
    public int mStartAngle = 270;
    public String mText;
    public int mTextColor = -16777216;
    public int mTextLength;
    public TextMode mTextMode;
    public Paint mTextPaint;
    public float mTextScale = 1.0f;
    public int mTextSize = 10;
    public int mTouchEventCount;
    public String mUnit;
    public RectF mUnitBounds = new RectF();
    public int mUnitColor = -16777216;
    public UnitPosition mUnitPosition;
    public float mUnitScale = 1.0f;
    public Paint mUnitTextPaint;
    public int mUnitTextSize = 10;
    public int n = 10;
    public boolean o;
    public OnProgressChangedListener onProgressChangedListener;
    public AnimationHandling p = new AnimationHandling(this);
    public float previousProgressChangedValue;
    public AnimationState q = AnimationState.IDLE;
    public AnimationStateChangedListener r;
    public Typeface textTypeface;
    public Typeface unitTextTypeface;


    public static class Circleprogressview {
        public static final int[] a;
        public static final int[] b;
        static {
            int[] iArr = new int[TextMode.values().length];
            b = iArr;
            try {
                iArr[TextMode.TEXT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[TextMode.PERCENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[TextMode.VALUE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[UnitPosition.values().length];
            a = iArr2;
            iArr2[UnitPosition.TOP.ordinal()] = 1;
            a[UnitPosition.BOTTOM.ordinal()] = 2;
            a[UnitPosition.LEFT_TOP.ordinal()] = 3;
            a[UnitPosition.RIGHT_TOP.ordinal()] = 4;
            a[UnitPosition.LEFT_BOTTOM.ordinal()] = 5;
            a[UnitPosition.RIGHT_BOTTOM.ordinal()] = 6;
        }
    }

    public interface OnProgressChangedListener {
        void onProgressChanged(float f);
    }

    public CircleProgressView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Cap cap = Cap.BUTT;
        this.mBarStrokeCap = cap;
        this.mSpinnerStrokeCap = cap;
        this.mBarPaint = new Paint();
        this.mBarSpinnerPaint = new Paint();
        this.mBarStartEndLinePaint = new Paint();
        this.mBackgroundCirclePaint = new Paint();
        this.mRimPaint = new Paint();
        this.mTextPaint = new Paint();
        this.mUnitTextPaint = new Paint();
        this.mOuterContourPaint = new Paint();
        this.mInnerContourPaint = new Paint();
        String str = "";
        this.mText = str;
        this.mUnit = str;
        this.mUnitPosition = UnitPosition.RIGHT_TOP;
        this.mTextMode = TextMode.PERCENT;
        this.mShowUnit = false;
        this.mRelativeUniteSize = 1.0f;
        this.mSeekModeEnabled = false;
        this.mShowTextWhileSpinning = false;
        this.mShowBlock = false;
        this.mBlockCount = 18;
        this.mBlockScale = 0.9f;
        float f = (float) (360 / 18);
        this.mBlockDegree = f;
        this.mBlockScaleDegree = f * 0.9f;
        this.mRoundToBlock = false;
        this.mRoundToWholeNumber = false;
        this.decimalFormat = new DecimalFormat("0");
        parseAttributes(context.obtainStyledAttributes(attributeSet, R.styleable.CircleProgressView));
        if (!isInEditMode() && VERSION.SDK_INT >= 11) {
            setLayerType(2, null);
        }
        Paint paint = new Paint(1);
        this.mMaskPaint = paint;
        paint.setFilterBitmap(false);
        this.mMaskPaint.setXfermode(new PorterDuffXfermode(Mode.DST_IN));
        setupPaints();
        if (this.l) {
            spin();
        }
    }

    public static double calcRotationAngleInDegrees(PointF pointF, PointF pointF2) {
        double toDegrees = Math.toDegrees(Math.atan2((double) (pointF2.y - pointF.y), (double) (pointF2.x - pointF.x)));
        return toDegrees < 0.0d ? toDegrees + 360.0d : toDegrees;
    }

    private RectF calcTextBounds(String str, Paint paint, RectF rectF) {
        Rect rect = new Rect();
        paint.getTextBounds(str, 0, str.length(), rect);
        float width = (float) (rect.left + rect.width());
        float height = ((float) rect.bottom) + (((float) rect.height()) * 0.93f);
        RectF rectF2 = new RectF();
        rectF2.left = rectF.left + ((rectF.width() - width) / 2.0f);
        float height2 = rectF.top + ((rectF.height() - height) / 2.0f);
        rectF2.top = height2;
        rectF2.right = rectF2.left + width;
        rectF2.bottom = height2 + height;
        return rectF2;
    }

    public static float calcTextSizeForRect(String str, Paint paint, RectF rectF) {
        Matrix matrix = new Matrix();
        Rect rect = new Rect();
        str = str.replace('1', '0');
        paint.getTextBounds(str, 0, str.length(), rect);
        matrix.setRectToRect(new RectF(rect), rectF, ScaleToFit.CENTER);
        float[] fArr = new float[9];
        matrix.getValues(fArr);
        return paint.getTextSize() * fArr[0];
    }

    private void drawBar(Canvas canvas, float f) {
        float f2 = this.a == Direction.CW ? (float) this.mStartAngle : ((float) this.mStartAngle) - f;
        Canvas canvas2;
        float f3;
        if (this.mShowBlock) {
            drawBlocks(canvas, this.mCircleBounds, f2, f, false, this.mBarPaint);
        } else if (this.mBarStrokeCap == Cap.BUTT || f <= 0.0f || this.mBarColors.length <= 1) {
            canvas.drawArc(this.mCircleBounds, f2, f, false, this.mBarPaint);
        } else if (f > 180.0f) {
            f /= 2.0f;
            canvas2 = canvas;
            f3 = f2;
            canvas2.drawArc(this.mCircleBounds, f3, f, false, this.mBarPaint);
            canvas2.drawArc(this.mCircleBounds, f3, 1.0f, false, this.mShaderlessBarPaint);
            canvas.drawArc(this.mCircleBounds, f2 + f, f, false, this.mBarPaint);
        } else {
            canvas2 = canvas;
            f3 = f2;
            canvas2.drawArc(this.mCircleBounds, f3, f, false, this.mBarPaint);
            canvas2.drawArc(this.mCircleBounds, f3, 1.0f, false, this.mShaderlessBarPaint);
        }
    }

    private void drawBlocks(Canvas canvas, RectF rectF, float f, float f2, boolean z, Paint paint) {
        float f3 = 0.0f;
        while (f3 < f2) {
            canvas.drawArc(rectF, f + f3, Math.min(this.mBlockScaleDegree, f2 - f3), z, paint);
            f3 += this.mBlockDegree;
        }
    }

    private void drawSpinner(Canvas canvas) {
        float f;
        float f2;
        if (this.h < 0.0f) {
            this.h = 1.0f;
        }
        if (this.a == Direction.CW) {
            f = ((float) this.mStartAngle) + this.j;
            f2 = this.h;
        } else {
            f = (float) this.mStartAngle;
            f2 = this.j;
        }
        float f3 = f - f2;
        canvas.drawArc(this.mCircleBounds, f3, this.h, false, this.mBarSpinnerPaint);
    }

    private void drawStartEndLine(Canvas canvas, float f) {
        if (f != 0.0f) {
            float f2 = (this.a == Direction.CW ? (float) this.mStartAngle : ((float) this.mStartAngle) - f) - (this.mBarStartEndLineSweep / 2.0f);
            BarStartFinishLiner barStartFinishLiner = this.mBarStartFinishLiner;
            if (barStartFinishLiner == BarStartFinishLiner.START || barStartFinishLiner == BarStartFinishLiner.BOTH) {
                canvas.drawArc(this.mCircleBounds, f2, this.mBarStartEndLineSweep, false, this.mBarStartEndLinePaint);
            }
            barStartFinishLiner = this.mBarStartFinishLiner;
            if (barStartFinishLiner == BarStartFinishLiner.END || barStartFinishLiner == BarStartFinishLiner.BOTH) {
                canvas.drawArc(this.mCircleBounds, f2 + f, this.mBarStartEndLineSweep, false, this.mBarStartEndLinePaint);
            }
        }
    }

    private void drawTextWithUnit(Canvas canvas) {
        float f;
        float f2;
        float f3;
        String format;
        int i = Circleprogressview.a[this.mUnitPosition.ordinal()];
        Object obj = 1;
        if (i == 1 || i == 2) {
            f = this.mRelativeUniteSize;
            f2 = 0.25f * f;
            f3 = 0.4f;
        } else {
            f = this.mRelativeUniteSize;
            f2 = 0.55f * f;
            f3 = 0.3f;
        }
        float width = (this.mOuterTextBounds.width() * 0.05f) / 2.0f;
        f = (f * f3) * this.mOuterTextBounds.width();
        f3 = (this.mOuterTextBounds.height() * 0.025f) / 2.0f;
        f2 *= this.mOuterTextBounds.height();
        if (this.mIsAutoColorEnabled) {
            this.mTextPaint.setColor(calcTextColor((double) this.b));
        }
        int i2 = Circleprogressview.b[this.mTextMode.ordinal()];
        if (i2 == 2) {
            format = this.decimalFormat.format((double) ((100.0f / this.e) * this.b));
        } else if (i2 != 3) {
            format = this.mText;
            if (format == null) {
                format = "";
            }
        } else {
            format = this.decimalFormat.format((double) this.b);
        }
        if (this.mTextLength != format.length()) {
            int length = format.length();
            this.mTextLength = length;
            if (length == 1) {
                this.mOuterTextBounds = getInnerCircleRect(this.mCircleBounds);
                RectF rectF = this.mOuterTextBounds;
                float width2 = rectF.left + (rectF.width() * 0.1f);
                rectF = this.mOuterTextBounds;
                this.mOuterTextBounds = new RectF(width2, rectF.top, rectF.right - (rectF.width() * 0.1f), this.mOuterTextBounds.bottom);
            } else {
                this.mOuterTextBounds = getInnerCircleRect(this.mCircleBounds);
            }
            if (this.mIsAutoTextSize) {
                setTextSizeAndTextBoundsWithAutoTextSize(width, f, f3, f2, format);
            } else {
                setTextSizeAndTextBoundsWithFixedTextSize(format);
            }
        } else {
            obj = null;
        }
        canvas.drawText(format, this.mActualTextBounds.left - (this.mTextPaint.getTextSize() * 0.02f), this.mActualTextBounds.bottom, this.mTextPaint);
        if (this.mShowUnit) {
            if (this.mIsAutoColorEnabled) {
                this.mUnitTextPaint.setColor(calcTextColor((double) this.b));
            }
            if (obj != null) {
                if (this.mIsAutoTextSize) {
                    setUnitTextBoundsAndSizeWithAutoTextSize(width, f, f3, f2);
                } else {
                    setUnitTextBoundsAndSizeWithFixedTextSize(width * 2.0f, f3 * 2.0f);
                }
            }
            canvas.drawText(this.mUnit, this.mUnitBounds.left - (this.mUnitTextPaint.getTextSize() * 0.02f), this.mUnitBounds.bottom, this.mUnitTextPaint);
        }
    }

    private RectF getInnerCircleRect(RectF rectF) {
        float f;
        float width = (rectF.width() - ((float) ((((double) (((rectF.width() - ((float) Math.max(this.mBarWidth, this.mRimWidth))) - this.mOuterContourSize) - this.mInnerContourSize)) / 2.0d) * Math.sqrt(2.0d)))) / 2.0f;
        float f2 = 1.0f;
        if (isUnitVisible()) {
            switch (Circleprogressview.a[this.mUnitPosition.ordinal()]) {
                case 1:
                case 2:
                    f2 = 1.1f;
                    f = 0.88f;
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                    f2 = 0.77f;
                    f = 1.33f;
                    break;
            }
        }
        f = 1.0f;
        f2 *= width;
        width *= f;
        return new RectF(rectF.left + f2, rectF.top + width, rectF.right - f2, rectF.bottom - width);
    }

    private float getRotationAngleForPointFromStart(PointF pointF) {
        long round = Math.round(calcRotationAngleInDegrees(this.mCenter, pointF));
        return normalizeAngle(this.a == Direction.CW ? (float) (round - ((long) this.mStartAngle)) : (float) (((long) this.mStartAngle) - round));
    }

    public static float normalizeAngle(float f) {
        return ((f % 360.0f) + 360.0f) % 360.0f;
    }

    @SuppressLint("ResourceType")
    private void parseAttributes(TypedArray typedArray) {
        setBarWidth((int) typedArray.getDimension(11, (float) this.mBarWidth));
        setRimWidth((int) typedArray.getDimension(25, (float) this.mRimWidth));
        setSpinSpeed((float) ((int) typedArray.getFloat(34, this.k)));
        setSpin(typedArray.getBoolean(31, this.l));
        setDirection(Direction.values()[typedArray.getInt(15, 0)]);
        float f = typedArray.getFloat(49, this.b);
        setValue(f);
        this.b = f;
        if (typedArray.hasValue(2) && typedArray.hasValue(3) && typedArray.hasValue(4) && typedArray.hasValue(5)) {
            this.mBarColors = new int[]{typedArray.getColor(2, -16738680), typedArray.getColor(3, -16738680), typedArray.getColor(4, -16738680), typedArray.getColor(5, -16738680)};
        } else if (typedArray.hasValue(2) && typedArray.hasValue(3) && typedArray.hasValue(4)) {
            this.mBarColors = new int[]{typedArray.getColor(2, -16738680), typedArray.getColor(3, -16738680), typedArray.getColor(4, -16738680)};
        } else if (typedArray.hasValue(2) && typedArray.hasValue(3)) {
            this.mBarColors = new int[]{typedArray.getColor(2, -16738680), typedArray.getColor(3, -16738680)};
        } else {
            this.mBarColors = new int[]{typedArray.getColor(2, -16738680), typedArray.getColor(2, -16738680)};
        }
        if (typedArray.hasValue(10)) {
            setBarStrokeCap(StrokeCap.values()[typedArray.getInt(10, 0)].a);
        }
        if (typedArray.hasValue(9) && typedArray.hasValue(6)) {
            setBarStartEndLine((int) typedArray.getDimension(9, 0.0f), BarStartFinishLiner.values()[typedArray.getInt(6, 3)], typedArray.getColor(7, this.mBarStartEndLineColor), typedArray.getFloat(8, this.mBarStartEndLineSweep));
        }
        setSpinBarColor(typedArray.getColor(33, this.mSpinnerColor));
        setSpinningBarLength(typedArray.getFloat(32, this.i));
        if (typedArray.hasValue(40)) {
            setTextSize((int) typedArray.getDimension(40, (float) this.mTextSize));
        }
        if (typedArray.hasValue(46)) {
            setUnitSize((int) typedArray.getDimension(46, (float) this.mUnitTextSize));
        }
        if (typedArray.hasValue(37)) {
            setTextColor(typedArray.getColor(37, this.mTextColor));
        }
        if (typedArray.hasValue(43)) {
            setUnitColor(typedArray.getColor(43, this.mUnitColor));
        }
        if (typedArray.hasValue(0)) {
            setTextColorAuto(typedArray.getBoolean(0, this.mIsAutoColorEnabled));
        }
        if (typedArray.hasValue(1)) {
            setAutoTextSize(typedArray.getBoolean(1, this.mIsAutoTextSize));
        }
        if (typedArray.hasValue(38)) {
            setTextMode(TextMode.values()[typedArray.getInt(38, 0)]);
        }
        if (typedArray.hasValue(44)) {
            setUnitPosition(UnitPosition.values()[typedArray.getInt(44, 3)]);
        }
        if (typedArray.hasValue(36)) {
            setText(typedArray.getString(36));
        }
        setUnitToTextScale(typedArray.getFloat(47, 1.0f));
        setRimColor(typedArray.getColor(24, this.mRimColor));
        setFillCircleColor(typedArray.getColor(16, this.mBackgroundCircleColor));
        setOuterContourColor(typedArray.getColor(22, this.mOuterContourColor));
        setOuterContourSize(typedArray.getDimension(23, this.mOuterContourSize));
        setInnerContourColor(typedArray.getColor(17, this.mInnerContourColor));
        setInnerContourSize(typedArray.getDimension(18, this.mInnerContourSize));
        setMaxValue(typedArray.getFloat(19, this.e));
        setMinValueAllowed(typedArray.getFloat(21, this.f));
        setMaxValueAllowed(typedArray.getFloat(20, this.g));
        setRoundToBlock(typedArray.getBoolean(26, this.mRoundToBlock));
        setRoundToWholeNumber(typedArray.getBoolean(27, this.mRoundToWholeNumber));
        setUnit(typedArray.getString(42));
        setUnitVisible(typedArray.getBoolean(30, this.mShowUnit));
        setTextScale(typedArray.getFloat(39, this.mTextScale));
        setUnitScale(typedArray.getFloat(45, this.mUnitScale));
        setSeekModeEnabled(typedArray.getBoolean(28, this.mSeekModeEnabled));
        setStartAngle(typedArray.getInt(35, this.mStartAngle));
        setShowTextWhileSpinning(typedArray.getBoolean(29, this.mShowTextWhileSpinning));
        if (typedArray.hasValue(12)) {
            setBlockCount(typedArray.getInt(12, 1));
            setBlockScale(typedArray.getFloat(13, 0.9f));
        }
        if (typedArray.hasValue(41)) {
            try {
                this.textTypeface = Typeface.createFromAsset(getContext().getAssets(), typedArray.getString(41));
            } catch (Exception unused) {
            }
        }
        if (typedArray.hasValue(48)) {
            try {
                this.unitTextTypeface = Typeface.createFromAsset(getContext().getAssets(), typedArray.getString(48));
            } catch (Exception unused2) {
            }
        }
        if (typedArray.hasValue(14)) {
            try {
                String string = typedArray.getString(14);
                if (string != null) {
                    this.decimalFormat = new DecimalFormat(string);
                }
            } catch (Exception e) {
                Log.w(TAG, e.getMessage());
            }
        }
        typedArray.recycle();
    }

    private void setSpin(boolean z) {
        this.l = z;
    }

    private void setTextSizeAndTextBoundsWithAutoTextSize(float f, float f2, float f3, float f4, String str) {
        RectF rectF = this.mOuterTextBounds;
        if (this.mShowUnit) {
            int i = Circleprogressview.a[this.mUnitPosition.ordinal()];
            RectF rectF2;
            RectF rectF3;
            if (i == 1) {
                rectF2 = this.mOuterTextBounds;
                rectF = new RectF(rectF2.left, (rectF2.top + f4) + f3, rectF2.right, rectF2.bottom);
            } else if (i == 2) {
                rectF2 = this.mOuterTextBounds;
                rectF = new RectF(rectF2.left, rectF2.top, rectF2.right, (rectF2.bottom - f4) - f3);
            } else if (i == 3 || i == 5) {
                rectF3 = this.mOuterTextBounds;
                rectF = new RectF((rectF3.left + f2) + f, rectF3.top, rectF3.right, rectF3.bottom);
            } else {
                rectF3 = this.mOuterTextBounds;
                rectF = new RectF(rectF3.left, rectF3.top, (rectF3.right - f2) - f, rectF3.bottom);
            }
        }
        Paint paint = this.mTextPaint;
        paint.setTextSize(calcTextSizeForRect(str, paint, rectF) * this.mTextScale);
        this.mActualTextBounds = calcTextBounds(str, this.mTextPaint, rectF);
    }

    private void setTextSizeAndTextBoundsWithFixedTextSize(String str) {
        this.mTextPaint.setTextSize((float) this.mTextSize);
        this.mActualTextBounds = calcTextBounds(str, this.mTextPaint, this.mCircleBounds);
    }

    private void setUnitTextBoundsAndSizeWithAutoTextSize(float f, float f2, float f3, float f4) {
        int i = Circleprogressview.a[this.mUnitPosition.ordinal()];
        RectF rectF;
        float f5;
        float f6;
        RectF rectF2;
        if (i == 1) {
            rectF = this.mOuterTextBounds;
            f5 = rectF.left;
            f6 = rectF.top;
            this.mUnitBounds = new RectF(f5, f6, rectF.right, (f4 + f6) - f3);
        } else if (i == 2) {
            rectF = this.mOuterTextBounds;
            f5 = rectF.left;
            f6 = rectF.bottom;
            this.mUnitBounds = new RectF(f5, (f6 - f4) + f3, rectF.right, f6);
        } else if (i == 3 || i == 5) {
            rectF2 = this.mOuterTextBounds;
            f6 = rectF2.left;
            f5 = rectF2.top;
            this.mUnitBounds = new RectF(f6, f5, (f2 + f6) - f, f4 + f5);
        } else {
            rectF2 = this.mOuterTextBounds;
            f6 = rectF2.right;
            f2 = (f6 - f2) + f;
            f = rectF2.top;
            this.mUnitBounds = new RectF(f2, f, f6, f4 + f);
        }
        Paint paint = this.mUnitTextPaint;
        paint.setTextSize(calcTextSizeForRect(this.mUnit, paint, this.mUnitBounds) * this.mUnitScale);
        this.mUnitBounds = calcTextBounds(this.mUnit, this.mUnitTextPaint, this.mUnitBounds);
        int i2 = Circleprogressview.a[this.mUnitPosition.ordinal()];
        RectF rectF3;
        if (i2 == 3 || i2 == 4) {
            f = this.mActualTextBounds.top;
            rectF3 = this.mUnitBounds;
            rectF3.offset(0.0f, f - rectF3.top);
        } else if (i2 == 5 || i2 == 6) {
            f = this.mActualTextBounds.bottom;
            rectF3 = this.mUnitBounds;
            rectF3.offset(0.0f, f - rectF3.bottom);
        }
    }

    private void setUnitTextBoundsAndSizeWithFixedTextSize(float f, float f2) {
        this.mUnitTextPaint.setTextSize((float) this.mUnitTextSize);
        this.mUnitBounds = calcTextBounds(this.mUnit, this.mUnitTextPaint, this.mOuterTextBounds);
        int i = Circleprogressview.a[this.mUnitPosition.ordinal()];
        RectF rectF;
        RectF rectF2;
        if (i == 1) {
            rectF = this.mUnitBounds;
            rectF.offsetTo(rectF.left, (this.mActualTextBounds.top - f2) - rectF.height());
        } else if (i == 2) {
            rectF = this.mUnitBounds;
            rectF.offsetTo(rectF.left, this.mActualTextBounds.bottom + f2);
        } else if (i == 3 || i == 5) {
            rectF2 = this.mUnitBounds;
            rectF2.offsetTo((this.mActualTextBounds.left - f) - rectF2.width(), this.mUnitBounds.top);
        } else {
            rectF2 = this.mUnitBounds;
            rectF2.offsetTo(this.mActualTextBounds.right + f, rectF2.top);
        }
        int i2 = Circleprogressview.a[this.mUnitPosition.ordinal()];
        RectF rectF3;
        if (i2 == 3 || i2 == 4) {
            f = this.mActualTextBounds.top;
            rectF3 = this.mUnitBounds;
            rectF3.offset(0.0f, f - rectF3.top);
        } else if (i2 == 5 || i2 == 6) {
            f = this.mActualTextBounds.bottom;
            rectF3 = this.mUnitBounds;
            rectF3.offset(0.0f, f - rectF3.bottom);
        }
    }

    private void setupBackgroundCirclePaint() {
        this.mBackgroundCirclePaint.setColor(this.mBackgroundCircleColor);
        this.mBackgroundCirclePaint.setAntiAlias(true);
        this.mBackgroundCirclePaint.setStyle(Style.FILL);
    }

    private void setupBarPaint() {
        int[] iArr = this.mBarColors;
        if (iArr.length > 1) {
            this.mBarPaint.setShader(new SweepGradient(this.mCircleBounds.centerX(), this.mCircleBounds.centerY(), this.mBarColors, null));
            Matrix matrix = new Matrix();
            this.mBarPaint.getShader().getLocalMatrix(matrix);
            matrix.postTranslate(-this.mCircleBounds.centerX(), -this.mCircleBounds.centerY());
            matrix.postRotate((float) this.mStartAngle);
            matrix.postTranslate(this.mCircleBounds.centerX(), this.mCircleBounds.centerY());
            this.mBarPaint.getShader().setLocalMatrix(matrix);
            this.mBarPaint.setColor(this.mBarColors[0]);
        } else if (iArr.length == 1) {
            this.mBarPaint.setColor(iArr[0]);
            this.mBarPaint.setShader(null);
        } else {
            this.mBarPaint.setColor(-16738680);
            this.mBarPaint.setShader(null);
        }
        this.mBarPaint.setAntiAlias(true);
        this.mBarPaint.setStrokeCap(this.mBarStrokeCap);
        this.mBarPaint.setStyle(Style.STROKE);
        this.mBarPaint.setStrokeWidth((float) this.mBarWidth);
        if (this.mBarStrokeCap != Cap.BUTT) {
            Paint paint = new Paint(this.mBarPaint);
            this.mShaderlessBarPaint = paint;
            paint.setShader(null);
            this.mShaderlessBarPaint.setColor(this.mBarColors[0]);
        }
    }

    private void setupBarSpinnerPaint() {
        this.mBarSpinnerPaint.setAntiAlias(true);
        this.mBarSpinnerPaint.setStrokeCap(this.mSpinnerStrokeCap);
        this.mBarSpinnerPaint.setStyle(Style.STROKE);
        this.mBarSpinnerPaint.setStrokeWidth((float) this.mBarWidth);
        this.mBarSpinnerPaint.setColor(this.mSpinnerColor);
    }

    private void setupBarStartEndLinePaint() {
        this.mBarStartEndLinePaint.setColor(this.mBarStartEndLineColor);
        this.mBarStartEndLinePaint.setAntiAlias(true);
        this.mBarStartEndLinePaint.setStyle(Style.STROKE);
        this.mBarStartEndLinePaint.setStrokeWidth((float) this.mBarStartEndLineWidth);
    }

    private void setupBounds() {
        int min = Math.min(this.mLayoutWidth, this.mLayoutHeight);
        int i = this.mLayoutWidth - min;
        int i2 = (this.mLayoutHeight - min) / 2;
        float paddingTop = (float) (getPaddingTop() + i2);
        float paddingBottom = (float) (getPaddingBottom() + i2);
        i /= 2;
        float paddingLeft = (float) (getPaddingLeft() + i);
        float paddingRight = (float) (getPaddingRight() + i);
        int width = getWidth();
        int height = getHeight();
        int i3 = this.mBarWidth;
        float f = ((float) i3) / 2.0f;
        int i4 = this.mRimWidth;
        float f2 = ((float) i4) / 2.0f;
        float f3 = this.mOuterContourSize;
        float f4 = f > f2 + f3 ? ((float) i3) / 2.0f : (((float) i4) / 2.0f) + f3;
        float f5 = ((float) width) - paddingRight;
        float f6 = ((float) height) - paddingBottom;
        this.mCircleBounds = new RectF(paddingLeft + f4, paddingTop + f4, f5 - f4, f6 - f4);
        i2 = this.mBarWidth;
        this.mInnerCircleBound = new RectF(paddingLeft + ((float) i2), paddingTop + ((float) i2), f5 - ((float) i2), f6 - ((float) i2));
        this.mOuterTextBounds = getInnerCircleRect(this.mCircleBounds);
        RectF rectF = this.mCircleBounds;
        paddingBottom = rectF.left;
        int i5 = this.mRimWidth;
        paddingBottom += ((float) i5) / 2.0f;
        f5 = this.mInnerContourSize;
        this.mCircleInnerContour = new RectF(paddingBottom + (f5 / 2.0f), (rectF.top + (((float) i5) / 2.0f)) + (f5 / 2.0f), (rectF.right - (((float) i5) / 2.0f)) - (f5 / 2.0f), (rectF.bottom - (((float) i5) / 2.0f)) - (f5 / 2.0f));
        rectF = this.mCircleBounds;
        paddingBottom = rectF.left;
        i5 = this.mRimWidth;
        paddingBottom -= ((float) i5) / 2.0f;
        f5 = this.mOuterContourSize;
        this.mCircleOuterContour = new RectF(paddingBottom - (f5 / 2.0f), (rectF.top - (((float) i5) / 2.0f)) - (f5 / 2.0f), (rectF.right + (((float) i5) / 2.0f)) + (f5 / 2.0f), (rectF.bottom + (((float) i5) / 2.0f)) + (f5 / 2.0f));
        this.mCenter = new PointF(this.mCircleBounds.centerX(), this.mCircleBounds.centerY());
    }

    private void setupInnerContourPaint() {
        this.mInnerContourPaint.setColor(this.mInnerContourColor);
        this.mInnerContourPaint.setAntiAlias(true);
        this.mInnerContourPaint.setStyle(Style.STROKE);
        this.mInnerContourPaint.setStrokeWidth(this.mInnerContourSize);
    }

    private void setupOuterContourPaint() {
        this.mOuterContourPaint.setColor(this.mOuterContourColor);
        this.mOuterContourPaint.setAntiAlias(true);
        this.mOuterContourPaint.setStyle(Style.STROKE);
        this.mOuterContourPaint.setStrokeWidth(this.mOuterContourSize);
    }

    private void setupRimPaint() {
        this.mRimPaint.setColor(this.mRimColor);
        this.mRimPaint.setAntiAlias(true);
        this.mRimPaint.setStyle(Style.STROKE);
        this.mRimPaint.setStrokeWidth((float) this.mRimWidth);
    }

    private void setupTextPaint() {
        this.mTextPaint.setSubpixelText(true);
        this.mTextPaint.setLinearText(true);
        this.mTextPaint.setTypeface(Typeface.MONOSPACE);
        this.mTextPaint.setColor(this.mTextColor);
        this.mTextPaint.setStyle(Style.FILL);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setTextSize((float) this.mTextSize);
        Typeface typeface = this.textTypeface;
        if (typeface != null) {
            this.mTextPaint.setTypeface(typeface);
        } else {
            this.mTextPaint.setTypeface(Typeface.MONOSPACE);
        }
    }

    private void setupUnitTextPaint() {
        this.mUnitTextPaint.setStyle(Style.FILL);
        this.mUnitTextPaint.setAntiAlias(true);
        Typeface typeface = this.unitTextTypeface;
        if (typeface != null) {
            this.mUnitTextPaint.setTypeface(typeface);
        }
    }

    private void triggerOnProgressChanged(float f) {
        OnProgressChangedListener onProgressChangedListener = this.onProgressChangedListener;
        if (onProgressChangedListener != null && f != this.previousProgressChangedValue) {
            onProgressChangedListener.onProgressChanged(f);
            this.previousProgressChangedValue = f;
        }
    }

    private void triggerReCalcTextSizesAndPositions() {
        this.mTextLength = -1;
        this.mOuterTextBounds = getInnerCircleRect(this.mCircleBounds);
        invalidate();
    }

    public float getMaxValue() {
        return this.e;
    }

    public int getTextSize() {
        return this.mTextSize;
    }

    public boolean isUnitVisible() {
        return this.mShowUnit;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float f = (360.0f / this.e) * this.b;
        if (this.mBackgroundCircleColor != 0) {
            canvas.drawArc(this.mInnerCircleBound, 360.0f, 360.0f, false, this.mBackgroundCirclePaint);
        }
        if (this.mRimWidth > 0) {
            if (this.mShowBlock) {
                drawBlocks(canvas, this.mCircleBounds, (float) this.mStartAngle, 360.0f, false, this.mRimPaint);
            } else {
                canvas.drawArc(this.mCircleBounds, 360.0f, 360.0f, false, this.mRimPaint);
            }
        }
        if (this.mOuterContourSize > 0.0f) {
            canvas.drawArc(this.mCircleOuterContour, 360.0f, 360.0f, false, this.mOuterContourPaint);
        }
        if (this.mInnerContourSize > 0.0f) {
            canvas.drawArc(this.mCircleInnerContour, 360.0f, 360.0f, false, this.mInnerContourPaint);
        }
        AnimationState animationState = this.q;
        if (animationState == AnimationState.SPINNING || animationState == AnimationState.END_SPINNING) {
            drawSpinner(canvas);
            if (this.mShowTextWhileSpinning) {
                drawTextWithUnit(canvas);
            }
        } else if (animationState == AnimationState.END_SPINNING_START_ANIMATING) {
            drawSpinner(canvas);
            if (this.o) {
                drawBar(canvas, f);
                drawTextWithUnit(canvas);
            } else if (this.mShowTextWhileSpinning) {
                drawTextWithUnit(canvas);
            }
        } else {
            drawBar(canvas, f);
            drawTextWithUnit(canvas);
        }
        Bitmap bitmap = this.mClippingBitmap;
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, this.mMaskPaint);
        }
        if (this.mBarStartEndLineWidth > 0 && this.mBarStartFinishLiner != BarStartFinishLiner.NONE) {
            drawStartEndLine(canvas, f);
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = getMeasuredWidth();
        i = (i - getPaddingLeft()) - getPaddingRight();
        i2 = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        if (i > i2) {
            i = i2;
        }
        setMeasuredDimension((getPaddingLeft() + i) + getPaddingRight(), (i + getPaddingTop()) + getPaddingBottom());
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.mLayoutWidth = i;
        this.mLayoutHeight = i2;
        setupBounds();
        setupBarPaint();
        Bitmap bitmap = this.mClippingBitmap;
        if (bitmap != null) {
            this.mClippingBitmap = Bitmap.createScaledBitmap(bitmap, getWidth(), getHeight(), false);
        }
        invalidate();
    }

    public boolean onTouchEvent(@NonNull MotionEvent motionEvent) {
        if (!this.mSeekModeEnabled) {
            return super.onTouchEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0 || actionMasked == 1) {
            this.mTouchEventCount = 0;
            setValueAnimated((this.e / 360.0f) * getRotationAngleForPointFromStart(new PointF(motionEvent.getX(), motionEvent.getY())), 800);
            return true;
        } else if (actionMasked == 2) {
            actionMasked = this.mTouchEventCount + 1;
            this.mTouchEventCount = actionMasked;
            if (actionMasked <= 5) {
                return false;
            }
            setValue((this.e / 360.0f) * getRotationAngleForPointFromStart(new PointF(motionEvent.getX(), motionEvent.getY())));
            return true;
        } else if (actionMasked != 3) {
            return super.onTouchEvent(motionEvent);
        } else {
            this.mTouchEventCount = 0;
            return false;
        }
    }

    public void setAutoTextSize(boolean z) {
        this.mIsAutoTextSize = z;
    }

    public void setBarColor(@ColorInt int... iArr) {
        this.mBarColors = iArr;
        setupBarPaint();
    }

    public void setBarStartEndLine(int i, BarStartFinishLiner barStartFinishLiner, @ColorInt int i2, float f) {
        this.mBarStartEndLineWidth = i;
        this.mBarStartFinishLiner = barStartFinishLiner;
        this.mBarStartEndLineColor = i2;
        this.mBarStartEndLineSweep = f;
    }

    public void setBarStrokeCap(Cap cap) {
        this.mBarStrokeCap = cap;
        this.mBarPaint.setStrokeCap(cap);
        if (this.mBarStrokeCap != Cap.BUTT) {
            Paint paint = new Paint(this.mBarPaint);
            this.mShaderlessBarPaint = paint;
            paint.setShader(null);
            this.mShaderlessBarPaint.setColor(this.mBarColors[0]);
        }
    }

    public void setBarWidth(@IntRange(from = 0) int i) {
        this.mBarWidth = i;
        float f = (float) i;
        this.mBarPaint.setStrokeWidth(f);
        this.mBarSpinnerPaint.setStrokeWidth(f);
    }

    public void setBlockCount(int i) {
        if (i > 1) {
            this.mShowBlock = true;
            this.mBlockCount = i;
            float f = 360.0f / ((float) i);
            this.mBlockDegree = f;
            this.mBlockScaleDegree = f * this.mBlockScale;
            return;
        }
        this.mShowBlock = false;
    }

    public void setBlockScale(@FloatRange(from = 0.0d, to = 1.0d) float f) {
        if (f >= 0.0f && f <= 1.0f) {
            this.mBlockScale = f;
            this.mBlockScaleDegree = this.mBlockDegree * f;
        }
    }

    @TargetApi(11)
    public void setClippingBitmap(Bitmap bitmap) {
        if (getWidth() <= 0 || getHeight() <= 0) {
            this.mClippingBitmap = bitmap;
        } else {
            this.mClippingBitmap = Bitmap.createScaledBitmap(bitmap, getWidth(), getHeight(), false);
        }
        if (this.mClippingBitmap == null) {
            setLayerType(2, null);
        } else {
            setLayerType(1, null);
        }
    }

    public void setDecimalFormat(DecimalFormat decimalFormat) {
        if (decimalFormat != null) {
            this.decimalFormat = decimalFormat;
            return;
        }
        throw new IllegalArgumentException("decimalFormat must not be null!");
    }

    public void setDelayMillis(int i) {
        this.n = i;
    }

    public void setDirection(Direction direction) {
        this.a = direction;
    }

    public void setFillCircleColor(@ColorInt int i) {
        this.mBackgroundCircleColor = i;
        this.mBackgroundCirclePaint.setColor(i);
    }

    public void setInnerContourColor(@ColorInt int i) {
        this.mInnerContourColor = i;
        this.mInnerContourPaint.setColor(i);
    }

    public void setInnerContourSize(@FloatRange(from = 0.0d) float f) {
        this.mInnerContourSize = f;
        this.mInnerContourPaint.setStrokeWidth(f);
    }

    public void setLengthChangeInterpolator(TimeInterpolator timeInterpolator) {
        this.p.setLengthChangeInterpolator(timeInterpolator);
    }

    public void setMaxValue(@FloatRange(from = 0.0d) float f) {
        this.e = f;
    }

    public void setMaxValueAllowed(@FloatRange(from = 0.0d) float f) {
        this.g = f;
    }

    public void setMinValueAllowed(@FloatRange(from = 0.0d) float f) {
        this.f = f;
    }

    public void setOuterContourColor(@ColorInt int i) {
        this.mOuterContourColor = i;
        this.mOuterContourPaint.setColor(i);
    }

    public void setOuterContourSize(@FloatRange(from = 0.0d) float f) {
        this.mOuterContourSize = f;
        this.mOuterContourPaint.setStrokeWidth(f);
    }

    public void setRimColor(@ColorInt int i) {
        this.mRimColor = i;
        this.mRimPaint.setColor(i);
    }

    public void setRimWidth(@IntRange(from = 0) int i) {
        this.mRimWidth = i;
        this.mRimPaint.setStrokeWidth((float) i);
    }

    public void setRoundToBlock(boolean z) {
        this.mRoundToBlock = z;
    }

    public void setRoundToWholeNumber(boolean z) {
        this.mRoundToWholeNumber = z;
    }

    public void setSeekModeEnabled(boolean z) {
        this.mSeekModeEnabled = z;
    }

    public void setShowBlock(boolean z) {
        this.mShowBlock = z;
    }

    public void setShowTextWhileSpinning(boolean z) {
        this.mShowTextWhileSpinning = z;
    }

    public void setSpinBarColor(@ColorInt int i) {
        this.mSpinnerColor = i;
        this.mBarSpinnerPaint.setColor(i);
    }

    public void setSpinSpeed(float f) {
        this.k = f;
    }

    public void setSpinnerStrokeCap(Cap cap) {
        this.mSpinnerStrokeCap = cap;
        this.mBarSpinnerPaint.setStrokeCap(cap);
    }

    public void setSpinningBarLength(@FloatRange(from = 0.0d) float f) {
        this.i = f;
        this.h = f;
    }

    public void setStartAngle(@IntRange(from = 0, to = 360) int i) {
        this.mStartAngle = (int) normalizeAngle((float) i);
    }

    public void setText(String str) {
        if (str == null) {
            str = "";
        }
        this.mText = str;
        invalidate();
    }

    public void setTextColor(@ColorInt int i) {
        this.mTextColor = i;
        this.mTextPaint.setColor(i);
    }

    public void setTextColorAuto(boolean z) {
        this.mIsAutoColorEnabled = z;
    }

    public void setTextMode(TextMode textMode) {
        this.mTextMode = textMode;
    }

    public void setTextScale(@FloatRange(from = 0.0d) float f) {
        this.mTextScale = f;
    }

    public void setTextSize(@IntRange(from = 0) int i) {
        this.mTextPaint.setTextSize((float) i);
        this.mTextSize = i;
        this.mIsAutoTextSize = false;
    }

    public void setTextTypeface(Typeface typeface) {
        this.mTextPaint.setTypeface(typeface);
    }

    public void setUnit(String str) {
        if (str == null) {
            this.mUnit = "";
        } else {
            this.mUnit = str;
        }
        invalidate();
    }

    public void setUnitColor(@ColorInt int i) {
        this.mUnitColor = i;
        this.mUnitTextPaint.setColor(i);
        this.mIsAutoColorEnabled = false;
    }

    public void setUnitPosition(UnitPosition unitPosition) {
        this.mUnitPosition = unitPosition;
        triggerReCalcTextSizesAndPositions();
    }

    public void setUnitScale(@FloatRange(from = 0.0d) float f) {
        this.mUnitScale = f;
    }

    public void setUnitSize(@IntRange(from = 0) int i) {
        this.mUnitTextSize = i;
        this.mUnitTextPaint.setTextSize((float) i);
    }

    public void setUnitToTextScale(@FloatRange(from = 0.0d) float f) {
        this.mRelativeUniteSize = f;
        triggerReCalcTextSizesAndPositions();
    }

    public void setUnitVisible(boolean z) {
        if (z != this.mShowUnit) {
            this.mShowUnit = z;
            triggerReCalcTextSizesAndPositions();
        }
    }

    public void setValue(float f) {
        float f2;
        if (this.mShowBlock && this.mRoundToBlock) {
            f2 = this.e / ((float) this.mBlockCount);
            f = ((float) Math.round(f / f2)) * f2;
        } else if (this.mRoundToWholeNumber) {
            f = (float) Math.round(f);
        }
        f = Math.max(this.f, f);
        f2 = this.g;
        if (f2 >= 0.0f) {
            f = Math.min(f2, f);
        }
        Message message = new Message();
        message.what = AnimationText.SET_VALUE.ordinal();
        message.obj = new float[]{f, f};
        this.p.sendMessage(message);
        triggerOnProgressChanged(f);
    }

    public void setupPaints() {
        setupBarPaint();
        setupBarSpinnerPaint();
        setupOuterContourPaint();
        setupInnerContourPaint();
        setupUnitTextPaint();
        setupTextPaint();
        setupBackgroundCirclePaint();
        setupRimPaint();
        setupBarStartEndLinePaint();
    }

    public void spin() {
        setSpin(true);
        this.p.sendEmptyMessage(AnimationText.START_SPINNING.ordinal());
    }

    private int calcTextColor(double d) {
        int[] iArr = this.mBarColors;
        int i = 0;
        if (iArr.length <= 1) {
            return iArr.length == 1 ? iArr[0] : -16777216;
        } else {
            double maxValue = ((double) (1.0f / getMaxValue())) * d;
            int floor = (int) Math.floor(((double) (this.mBarColors.length - 1)) * maxValue);
            int i2 = floor + 1;
            if (floor < 0) {
                i2 = 1;
            } else {
                int[] iArr2 = this.mBarColors;
                if (i2 >= iArr2.length) {
                    floor = iArr2.length - 2;
                    i2 = iArr2.length - 1;
                }
                i = floor;
            }
            int[] iArr3 = this.mBarColors;
            return ColorUtils.getRGBGradient(iArr3[i], iArr3[i2], (float) (1.0d - ((((double) (iArr3.length - 1)) * maxValue) % 1.0d)));
        }
    }

    public void setValueAnimated(float f, long j) {
        setValueAnimated(this.b, f, j);
    }

    public void setValueAnimated(float f, float f2, long j) {
        float f3;
        if (this.mShowBlock && this.mRoundToBlock) {
            f3 = this.e / ((float) this.mBlockCount);
            f2 = ((float) Math.round(f2 / f3)) * f3;
        } else if (this.mRoundToWholeNumber) {
            f2 = (float) Math.round(f2);
        }
        f2 = Math.max(this.f, f2);
        f3 = this.g;
        if (f3 >= 0.0f) {
            f2 = Math.min(f3, f2);
        }
        this.m = (double) j;
        Message message = new Message();
        message.what = AnimationText.SET_VALUE_ANIMATED.ordinal();
        message.obj = new float[]{f, f2};
        this.p.sendMessage(message);
        triggerOnProgressChanged(f2);
    }
}
