package com.MV.Lyrics.VideoPlay.Preference;

import android.content.Context;
import android.content.SharedPreferences;

public class VideoPlayerPreference {
    public static SharedPreferences a;
    public static SharedPreferences.Editor b;

    public static void a(Context context, long j, String str) {
        b = context.getSharedPreferences("VIDEOPLAYERS", 0).edit();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("lptrack");
        stringBuilder.append(str);
        b.putLong(stringBuilder.toString(), j);
        b.commit();
    }

    public static void a(Context context, Boolean bool, String str) {
        b = context.getSharedPreferences("VIDEOPLAYERS", 0).edit();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isplay");
        stringBuilder.append(str);
        b.putBoolean(stringBuilder.toString(), bool.booleanValue());
        b.commit();
    }

    public static boolean a(Context context) {
        return context.getSharedPreferences("VIDEOPLAYERS", 0).getBoolean("AlwaseStartTrack", false);
    }

}
