﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeSingle : MonoBehaviour
{
    public GameObject AddControl, AddControl2, AddControl3;

    public void Awake()
    {
        GameObject go = GameObject.FindGameObjectWithTag("AddManager");
        {
            if (go == null)
            {
                Instantiate(AddControl);
            }
        }
        GameObject go1 = GameObject.FindGameObjectWithTag("AddManager2");
        {
            if (go == null)
            {
                Instantiate(AddControl2);
            }
        }
        GameObject go2 = GameObject.FindGameObjectWithTag("AddManager3");
        {
            if (go == null)
            {
                Instantiate(AddControl3);
            }
        }
    }
}
