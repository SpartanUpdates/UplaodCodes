package com.wavymusic.Download;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.wavymusic.Model.ParticalItemModel;
import com.wavymusic.Utils.Utils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadTask {

    private static final String TAG = "DownloadPartical";
    private Context context;
    private ImageView ivDownload;
    private TextView tvProgress;
    private ParticalItemModel particalModel;

    public DownloadTask(Context context, ImageView ivDownload, TextView tvThemeDownprogress, ParticalItemModel particalModel) {
        this.context = context;
        this.ivDownload = ivDownload;
        this.tvProgress = tvThemeDownprogress;
        this.particalModel = particalModel;
        //Start Downloading Task
        new DownloadingTask().execute();
        new DownloadingimageTask().execute();
    }

    private class DownloadingTask extends AsyncTask<String, Integer, String> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            particalModel.isDownloading = true;
            particalModel.isAvailableOffline = false;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (outputFile != null) {
                    particalModel.isDownloading = false;
                    particalModel.isAvailableOffline = true;
                    ivDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                } else {
                    particalModel.isDownloading = false;
                    particalModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + particalModel.getBundelName());
                    Log.e(TAG, "Download Failed");

                }
            } catch (Exception e) {
                e.printStackTrace();
                particalModel.isDownloading = false;
                particalModel.isAvailableOffline = false;
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + particalModel.getBundelName());
                Log.e(TAG, "Download Failed with Exception - " + e.getLocalizedMessage());
            }
            super.onPostExecute(result);
        }

        protected void onProgressUpdate(Integer... progress) {
            Log.d("ANDRO_ASYNC", String.valueOf(progress[0]));
            tvProgress.setText(String.valueOf(progress[0]));
        }

        @Override
        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(particalModel.getThemeBundel());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                //Get File if SD card is present
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getAssetUnityPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                    Log.e(TAG, "Directory Created.");
                }
                outputFile = new File(apkStorage, particalModel.getBundelName());
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                    Log.e(TAG, "File Created");
                }
                int fileLength = c.getContentLength();
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                long total = 0;
                int count;
                while ((count = is.read(buffer)) != -1) {
                    // allow canceling with back button
                    if (isCancelled()) {
                        is.close();
                        return null;
                    }
                    total += count;
                    // publishing the progress....
                    if (fileLength > 0) // only if total length is known
                        publishProgress((int) (total * 100 / fileLength));
                    fos.write(buffer, 0, count);
                }

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
                Log.e(TAG, "Download Error Exception " + e.getMessage());
            }
            return null;
        }
    }

    private class DownloadingimageTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.e("TAG","ImageDownload");
//            particalModel.isDownloading = true;
//            particalModel.isAvailableOffline = false;
        }

        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + particalModel.getThemeInfo() + ".png");
                    Log.e(TAG, "Download Failed");

                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + particalModel.getThemeInfo()+".png");
                Log.e(TAG, "Download Failed with Exception - " + e.getLocalizedMessage());
            }
            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(particalModel.getThumbImage());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                //Get File if SD card is present
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getAssetUnityPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                    Log.e(TAG, "Directory Created.");
                }
                outputFile = new File(apkStorage, particalModel.getThemeInfo()+".png");
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                    Log.e(TAG, "File Created");
                }
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
                Log.e(TAG, "Download Error Exception " + e.getMessage());
            }
            return null;
        }
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }
}
