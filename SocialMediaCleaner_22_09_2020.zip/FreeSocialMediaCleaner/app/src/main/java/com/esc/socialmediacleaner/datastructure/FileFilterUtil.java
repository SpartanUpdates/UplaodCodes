package com.esc.socialmediacleaner.datastructure;

import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.FileFilter;

public class FileFilterUtil implements FileFilter {
    private String[] fileExtensions = new String[]{"jpg", "jpeg"};

    public FileFilterUtil(int i) {
        int i2 = i;
        if (i2 == 0) {
            this.fileExtensions = new String[]{"jpeg", "jpg", "png", "tiff", "tif", "bmp"};
        } else if (i2 == 1) {
            this.fileExtensions = new String[]{"mp4", "mpg", "gif", "3gp", "avi", "mpeg"};
        } else if (i2 == 2) {
            this.fileExtensions = new String[]{"mp3", "aac", "m4a", "wav"};
        } else if (i2 == 3) {
            this.fileExtensions = new String[]{"mp4"};
        } else if (i2 == 4) {
            this.fileExtensions = new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"};
        }
    }

    public boolean accept(File file) {
        for (String endsWith : this.fileExtensions) {
            if (file.getName().toLowerCase().endsWith(endsWith)) {
                return true;
            }
        }
        return false;
    }
}
