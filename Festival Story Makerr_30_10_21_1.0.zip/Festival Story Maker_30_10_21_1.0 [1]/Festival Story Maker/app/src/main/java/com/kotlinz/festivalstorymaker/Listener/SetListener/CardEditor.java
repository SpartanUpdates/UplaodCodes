package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class CardEditor implements View.OnClickListener
{
    public final  int Position;
    public final  ImageView imageView;
    public final  com.kotlinz.festivalstorymaker.Models.g editmodel;
    public final  CardView cardView;
    public final  CardView cardView1;
    public final  RecyclerView j;
    public final  RecyclerView k;
    public final CanvasEditorActivity l;

    public CardEditor(final CanvasEditorActivity l, final int pos, final ImageView imageView, final com.kotlinz.festivalstorymaker.Models.g editmodel, final CardView cv1, final CardView i, final RecyclerView j, final RecyclerView k) {
        this.l = l;
        this.Position = pos;
        this.imageView = imageView;
        this.editmodel = editmodel;
        this.cardView = cv1;
        this.cardView1 = i;
        this.j = j;
        this.k = k;
    }

    public void onClick(final View view) {
        final CanvasEditorActivity l = this.l;
        if (!l.X0 && !l.u1) {
            l.w0();
            l.H0 = Position;
            final ImageView y1 = CanvasEditorActivity.y1;
            if (y1 != null) {
                y1.setOnTouchListener((View.OnTouchListener)null);
                CanvasEditorActivity.y1.setBackground((Drawable)null);
            }
            final TextView z1 = CanvasEditorActivity.z1;
            if (z1 != null) {
                z1.setBackground((Drawable)null);
            }
            CanvasEditorActivity.I1 = (CanvasEditorActivity.y1 = imageView);
            CanvasEditorActivity.U1 = false;
            CanvasEditorActivity.V1 = false;
            CanvasEditorActivity.W1 = false;
            CanvasEditorActivity.P1 = false;
            CanvasEditorActivity canvasEditorActivity;
            Object o;
            if (!this.editmodel.F.equals("1") && !this.editmodel.E.equals("1")) {
                canvasEditorActivity = this.l;
                if (this.editmodel.G.equals("1")) {
                    o = this.j;
                }
                else {
                    o = this.k;
                }
            }
            else {
                canvasEditorActivity = this.l;
                if (this.editmodel.F.equals("1")) {
                    o = this.cardView;
                }
                else {
                    o = this.cardView1;
                }
            }
            CanvasEditorActivity.k0(canvasEditorActivity, (View)o);
            return;
        }
        final CanvasEditorActivity i = this.l;
        i.u1 = false;
        i.X0 = false;
    }
}
