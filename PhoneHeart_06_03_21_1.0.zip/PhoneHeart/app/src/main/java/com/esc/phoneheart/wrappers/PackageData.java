package com.esc.phoneheart.wrappers;

import java.io.Serializable;
import java.util.ArrayList;

public class PackageData implements Serializable {
    public String apkPath;
    public String appname;
    public long appsize;
    public String datadir;
    public String id;
    public boolean ignored;
    public int installLocation;
    public boolean isSystemApp;
    public boolean ischecked;
    public String pname;
    public String saurcedir;
    public long userCacheSize;
    public ArrayList<String> userCachefilesList;
    public int versionCode = 0;
    public String versionName;

    public PackageData() {
        String str = "";
        this.appname = str;
        this.pname = str;
        this.apkPath = str;
        this.versionName = str;
        this.datadir = str;
        this.saurcedir = str;
        this.isSystemApp = false;
        this.ignored = false;
    }
}
