package com.name.nameart.ThropicalData;

public class ThropicalDataList {
    String appname;
    String logo;
    String packg;
    int resor;

    public ThropicalDataList(String str, String str2, String str3) {
        this.logo = str;
        this.appname = str2;
        this.packg = str3;
    }

    public String getAppname() {
        return this.appname;
    }

    public void setAppname(String str) {
        this.appname = str;
    }

    public String getLogo() {
        return this.logo;
    }

    public void setLogo(String str) {
        this.logo = str;
    }

    public ThropicalDataList(int i, String str) {
        this.resor = i;
        this.packg = str;
    }

    public int getResor() {
        return this.resor;
    }

    public void setResor(int i) {
        this.resor = i;
    }

    public String getPackg() {
        return this.packg;
    }

    public void setPackg(String str) {
        this.packg = str;
    }
}
