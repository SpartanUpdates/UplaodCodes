package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class p5 extends GestureDetector.SimpleOnGestureListener {
    public final TextView e;
    public final FrameLayout f;
    public final View g;
    public final FrameEditorNewDesign h;

    public p5(final FrameEditorNewDesign h, final TextView e, final FrameLayout f, final View g) {
        this.h = h;
        this.e = e;
        this.f = f;
        this.g = g;
    }

    public boolean onDoubleTap(final MotionEvent motionEvent) {
        final TextView textView = FrameEditorNewDesign.w1 = this.e;
        FrameEditorNewDesign.M1 = true;
        this.h.A0(this.f, this.g, textView);
        return super.onDoubleTap(motionEvent);
    }

    public void onLongPress(final MotionEvent motionEvent) {
        final FrameEditorNewDesign h = this.h;
        h.d1 = true;
        h.e1 = this.g;
        h.a0 = this.f;
        h.z0(true);
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        TextView textView;
        Drawable drawable;
        if ((FrameEditorNewDesign.w1 = this.e).getBackground() == null) {
            textView = this.e;
            drawable = this.h.getResources().getDrawable(R.drawable.rounded_border_to_view);
        } else {
            textView = this.e;
            drawable = null;
        }
        textView.setBackground(drawable);
        return true;
    }
}
