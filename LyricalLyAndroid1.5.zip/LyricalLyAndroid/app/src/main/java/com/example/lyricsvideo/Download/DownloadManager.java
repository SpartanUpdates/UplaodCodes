package com.example.lyricsvideo.Download;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.lyricsvideo.Model.VideoInfo;
import com.example.lyricsvideo.Utils.Utils;
import com.liulishuo.okdownload.DownloadTask;
import com.liulishuo.okdownload.SpeedCalculator;
import com.liulishuo.okdownload.StatusUtil;
import com.liulishuo.okdownload.core.Util;
import com.liulishuo.okdownload.core.breakpoint.BlockInfo;
import com.liulishuo.okdownload.core.breakpoint.BreakpointInfo;
import com.liulishuo.okdownload.core.cause.EndCause;
import com.liulishuo.okdownload.core.listener.DownloadListener4WithSpeed;
import com.liulishuo.okdownload.core.listener.assist.Listener4SpeedAssistExtend;

import java.io.File;
import java.util.List;
import java.util.Map;


public class DownloadManager {
    private DownloadTask BundleDownloadTask;
    private ProgressBar donutProgress;
    private TextView tvprogress;
    private ImageView ivDownload;
    private AppCompatButton btnusenow;
    private RelativeLayout rlThemeProgress;
    private VideoInfo themelModel;
    private Context context;

    public DownloadManager(Context context, String DataFileUrl, ProgressBar progressBar, TextView tvProgress, VideoInfo themelModel, ImageView ivDownload, AppCompatButton btnUseNow, RelativeLayout rlThemeProgress) {
        this.context = context;
        this.donutProgress = progressBar;
        this.btnusenow = btnUseNow;
        this.tvprogress = tvProgress;
        this.themelModel = themelModel;
        this.ivDownload = ivDownload;
        this.rlThemeProgress = rlThemeProgress;
        initTask(DataFileUrl);
        initStatus();
        initAction();
        try {
            String rootPath = Utils.INSTANCE.getLyricsFolderPath() + File.separator + themelModel.getContentZipFolderName();
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void initTask(String URL) {
        themelModel.isDownloading = true;
        themelModel.isAvailableOffline = false;
        final File parentFile = new File(Utils.INSTANCE.getLyricsFolderPath() + File.separator + themelModel.getContentZipFolderName());
        BundleDownloadTask = new DownloadTask.Builder(URL, parentFile)
                .setFilename(themelModel.getContentZipFileName())
                .setMinIntervalMillisCallbackProcess(16)
                .setPassIfAlreadyCompleted(false)
                .build();


    }

    private void initStatus() {
        final StatusUtil.Status status = StatusUtil.getStatus(BundleDownloadTask);
        if (status == StatusUtil.Status.COMPLETED) {
            Log.e("TAG", "Bundel Download Complated");
        }

        final BreakpointInfo info = StatusUtil.getCurrentInfo(BundleDownloadTask);
        if (info != null) {
            Log.d("TAG", "Bundel init status with: " + info.toString());
        }
    }

    private void initAction() {
        final boolean started = BundleDownloadTask.getTag() != null;
        if (started) {
            BundleDownloadTask.cancel();
        } else {
            startTask();
            BundleDownloadTask.setTag("mark-BundleDownloadTask-started");
        }
    }

    private void startTask() {
        BundleDownloadTask.enqueue(new DownloadListener4WithSpeed() {
            private long totalLength;
            private String readableTotalLength;

            @Override
            public void taskStart(@NonNull DownloadTask task) {
            }

            @Override
            public void infoReady(@NonNull DownloadTask task, @NonNull BreakpointInfo info,
                                  boolean fromBreakpoint,
                                  @NonNull Listener4SpeedAssistExtend.Listener4SpeedModel model) {
                totalLength = info.getTotalLength();
                readableTotalLength = Util.humanReadableBytes(totalLength, true);
            }

            @Override
            public void connectStart(@NonNull DownloadTask task, int blockIndex,
                                     @NonNull Map<String, List<String>> requestHeaders) {
            }

            @Override
            public void connectEnd(@NonNull DownloadTask task, int blockIndex, int responseCode,
                                   @NonNull Map<String, List<String>> responseHeaders) {
            }

            @Override
            public void progressBlock(@NonNull DownloadTask task, int blockIndex,
                                      long currentBlockOffset,
                                      @NonNull SpeedCalculator blockSpeed) {

            }

            @Override
            public void progress(@NonNull DownloadTask task, long currentOffset,
                                 @NonNull SpeedCalculator taskSpeed) {
                int percentage = (int) (currentOffset * 100 / totalLength);
                donutProgress.setProgress(percentage);
                tvprogress.setText(String.valueOf(percentage) + "%");
            }

            @Override
            public void blockEnd(@NonNull DownloadTask task, int blockIndex, BlockInfo info,
                                 @NonNull SpeedCalculator blockSpeed) {
            }

            @Override
            public void taskEnd(@NonNull DownloadTask task, @NonNull EndCause cause,
                                @Nullable Exception realCause,
                                @NonNull SpeedCalculator taskSpeed) {
                task.setTag(null);
                if (cause == EndCause.CANCELED) {
                    themelModel.isDownloading = false;
                    themelModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + themelModel.getContentZipFolderName() + File.separator + task.getFilename());
                } else if (cause == EndCause.ERROR) {
                    themelModel.isDownloading = false;
                    themelModel.isAvailableOffline = false;
                    DeleteFileIfInterupt(new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + themelModel.getContentZipFolderName() + File.separator + task.getFilename());
                }
                if (themelModel.getContentZipFileName().equals(task.getFilename())) {
                    if (cause == EndCause.COMPLETED) {
                        themelModel.isDownloading = false;
                        themelModel.isAvailableOffline = true;
                        btnusenow.setVisibility(View.VISIBLE);
                        ivDownload.setVisibility(View.GONE);
                        rlThemeProgress.setVisibility(View.GONE);
                        Utils.INSTANCE.unpackZip(new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + themelModel.getContentZipFolderName() + File.separator + task.getFilename());
                        Log.e("TAG", "Bundel Downloaded Complate" + new File(Utils.INSTANCE.getLyricsFolderPath()).getAbsolutePath() + File.separator + themelModel.getContentZipFolderName() + File.separator + task.getFilename());
                    }
                }
            }
        });
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }

}



