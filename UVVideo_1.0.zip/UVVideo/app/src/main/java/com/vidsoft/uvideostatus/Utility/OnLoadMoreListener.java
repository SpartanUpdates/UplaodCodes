package com.vidsoft.uvideostatus.Utility;

public interface OnLoadMoreListener {
    void onLoadMore();
}
