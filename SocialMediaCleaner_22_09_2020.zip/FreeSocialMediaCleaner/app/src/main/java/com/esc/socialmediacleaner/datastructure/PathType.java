package com.esc.socialmediacleaner.datastructure;

public enum PathType {
    SENT,
    RECEIVED,
    PROFILEPIC,
    STATUS
}
