package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.Models.h;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MyPostFramesListAdapter extends RecyclerView.Adapter<MyPostFramesListAdapter.ViewHolder> {

    public Activity activity;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.h> arrayList;
    public a i;

    public MyPostFramesListAdapter(Activity activity, ArrayList<com.kotlinz.festivalstorymaker.Models.h> arrayList, a aVar) {
        this.activity = activity;
        this.arrayList = arrayList;
        this.i = aVar;
    }

    public interface a {

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_home_frame_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        String str = ((h) arrayList.get(position)).m;
        if (Utils.y(activity, false)) {
            holder.imgPro.setVisibility(View.GONE);
        } else {
            Resources resources;
            int i2;
            holder.imgPro.setVisibility(View.VISIBLE);
            if (((h) arrayList.get(position)).p.equalsIgnoreCase("0")) {
                resources = activity.getResources();
                i2 = R.drawable.ic_pro_bg;
            } else {
                resources = activity.getResources();
                i2 = R.drawable.ic_free_poster;
            }
            holder.imgPro.setImageDrawable(resources.getDrawable(i2));
        }
        if (str.length()>0){
            Picasso.get().load(str).placeholder(R.drawable.progress).into(holder.img,null);
        }
        else {
            Picasso.get().load(R.drawable.white_bg).placeholder(R.drawable.progress).into(holder.img,null);
        }

        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!Utils.x(activity)) {
                    return;
                }
                if (((com.kotlinz.festivalstorymaker.Models.h) arrayList.get(position)).p.equalsIgnoreCase("1") || Utils.y(activity, true)) {
//               ((a) this.f.i).a(this.e);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.imgPoster)
        public ImageView img;
        @BindView(R.id.imgPro)
        public ImageView imgPro;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
