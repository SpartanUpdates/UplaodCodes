package com.kotlinz.festivalstorymaker.Model.QuoteMaker;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class QuoteMakerResponse {

	@SerializedName("data")
	private ArrayList<QuoteMainCategory> data;

	@SerializedName("status")
	private String status;

	public ArrayList<QuoteMainCategory> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}