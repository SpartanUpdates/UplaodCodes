package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;

import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.vidsoft.collagemaker.pipphotoeffect.R;

public class FontsPatternAdapter extends Adapter<FontsPatternAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    LayoutInflater inflater;
    int[] list;

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout border;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.imageView = (ImageView) itemView.findViewById(R.id.image);
            this.border = (RelativeLayout) itemView.findViewById(R.id.rl_border);
        }
    }

    public FontsPatternAdapter(Activity activity, int[] list) {
        this.Selection = BuildConfig.FLAVOR;
        this.inflater = LayoutInflater.from(activity);
        this.activity = activity;
        this.list = list;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.font_pattern_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.border.setVisibility(View.GONE);
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.GONE);
        }
        holder.imageView.setImageResource(this.list[position]);
    }

    public int getItemCount() {
        return this.list.length;
    }

    public void setSelection(int position) {
        this.Selection = String.valueOf(position);
        notifyDataSetChanged();
    }
}