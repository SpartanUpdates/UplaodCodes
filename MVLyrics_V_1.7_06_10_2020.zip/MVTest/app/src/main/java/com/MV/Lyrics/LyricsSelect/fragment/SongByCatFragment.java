package com.MV.Lyrics.LyricsSelect.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.LyricsSelect.Adapter.SelectLyricsAdapter;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.LyricsSelect.Model.SongModel;
import com.MV.Lyrics.R;
import com.MV.Lyrics.Retrofit.APIClient;
import com.MV.Lyrics.Retrofit.APIInterface;
import com.MV.Lyrics.Retrofit.AppConstant;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SongByCatFragment extends Fragment {

    public static LanguagePref sharedpreferences;
    public ArrayList<SongModel> songModelArrayList = new ArrayList<>();
    public SelectLyricsAdapter selectLyricsAdapter;
    Integer CategoryId = -1;
    RelativeLayout rlloadingpager;
    RecyclerView rvCategoryWiseTheme;
    LinearLayout llInternetCheck;
    Button btnRetry;
    String offlienResopnseData;
    SharedPreferences pref;
    String[] split_AllLan;
    String[] split_selctedLan;
    APIInterface apiInterface;
    private String CatId;

    Integer TabIndex = -1;
    public static Fragment getInstance(int catid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        bundle.putInt("TabIndex", TabIndex);
        SongByCatFragment categoryWiseSongFragment = new SongByCatFragment();
        categoryWiseSongFragment.setArguments(bundle);
        return categoryWiseSongFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CategoryId = getArguments().getInt("CategoryId");
        TabIndex = getArguments().getInt("TabIndex");
        CatId = String.valueOf(CategoryId);
    }

    public int getTabIndex() {
        return this.TabIndex;
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_lyrics_by_cat, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = LanguagePref.a(getActivity());
        split_AllLan = ("28,31,32,34,35,36,37,38,39,40,41,42,43,44").split(",");
        split_selctedLan = LanguagePref.a(getActivity()).a("pref_key_language_list", "22").split(",");
        apiInterface = APIClient.getClient().create(APIInterface.class);
        bindView(rootView);
        SetListener();
        SetThemeAdapter();
        if (songModelArrayList != null && songModelArrayList.size() == 0) {
            String id = pref.getString(CatId, null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(getActivity(), CatId);
                if (offlienResopnseData != null) {
                    new LoadOfflineData().execute();
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    rlloadingpager.setVisibility(View.GONE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            SetThemeAdapter();
        }
        return rootView;
    }

    private void bindView(View view) {
        rvCategoryWiseTheme = view.findViewById(R.id.rv_onlinesong);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlloadingpager = view.findViewById(R.id.rl_load_onlinesong);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void SetThemeAdapter() {
        selectLyricsAdapter = new SelectLyricsAdapter(getActivity(), songModelArrayList, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvCategoryWiseTheme.setLayoutManager(mLayoutManager);
        rvCategoryWiseTheme.setAdapter(selectLyricsAdapter);
        selectLyricsAdapter.notifyDataSetChanged();
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }



    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    private void GetSongByCategory() {
        rlloadingpager.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.doGetUserList(AppConstant.Token, AppConstant.ApplicationId, "1", "1");
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
//                        String bundelPath = jsonObj.getString("thumb_big_path");
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            String CategoryName = themeJSONObject.getString("name");
                            if (CategoryId == Catid) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                                    SongModel songModel = new SongModel();
                                    songModel.setSongCategoryId(songJSONObject.getString("category"));
                                    songModel.setSongName(songJSONObject.getString("video_name"));
                                    songModel.setSongUrl(songJSONObject.getString("data_file"));
                                    songModel.setSongfull_url(AppConstant.DataFilePath + songJSONObject.getString("data_file"));
                                    songModel.setSongSize(songJSONObject.getString("data_file_size"));
                                    songModel.setZipDownloadCatName(CategoryName);
                                    String foldername = songModel.getSongUrl();
                                    int pos = foldername.lastIndexOf(".");
                                    if (pos > 0) {
                                        foldername = foldername.substring(0, pos);
                                    }
                                    songModel.setZipFolderName(foldername);
                                    songModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + songModel.getZipDownloadCatName() + File.separator + songModel.getZipFolderName() + File.separator + songModel.getSongUrl());
                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                        songModelArrayList.add(songModel);
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        songModelArrayList.add(songModel);
                                    }
                                }
                            }
                        }
                        selectLyricsAdapter.notifyDataSetChanged();
                        rlloadingpager.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
//                String bundelPath = jsonObj.getString("thumb_big_path");
                int Catid = Integer.parseInt(jsonObj.getString("id"));
                String CategoryName = jsonObj.getString("name");
                if (CategoryId == Catid) {
                    JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                        SongModel songModel = new SongModel();
                        songModel.setSongCategoryId(songJSONObject.getString("category"));
                        songModel.setSongName(songJSONObject.getString("video_name"));
//                        String BundelName = songJSONObject.getString("Thumnail_Big").substring(songJSONObject.getString("Thumnail_Big").lastIndexOf("/") + 1);
                        songModel.setSongUrl(songJSONObject.getString("data_file"));
                        songModel.setSongfull_url(AppConstant.DataFilePath + songJSONObject.getString("data_file"));
                        songModel.setSongSize(songJSONObject.getString("data_file_size"));
                        songModel.setZipDownloadCatName(CategoryName);
                        String foldername = songModel.getSongUrl();
                        int pos = foldername.lastIndexOf(".");
                        if (pos > 0) {
                            foldername = foldername.substring(0, pos);
                        }
                        songModel.setZipFolderName(foldername);
                        songModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfThemeFolder).getAbsolutePath() + File.separator + songModel.getZipDownloadCatName() + File.separator + songModel.getZipFolderName() + File.separator + songModel.getSongUrl());
                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                            songModelArrayList.add(songModel);
                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                            songModelArrayList.add(songModel);
                        }
                    }
                }
            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            selectLyricsAdapter.notifyDataSetChanged();
        }
    }

}
