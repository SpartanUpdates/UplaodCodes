﻿using UnityEngine;
namespace BallCollect
{
    public class MulBall : MonoBehaviour
    {
        public GameObject bigBall;
        public GameObject ball;
        public int max = 10;

        private void Start()
        {
            this.GetComponent<Rigidbody>().isKinematic = true;
        }
        public void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                this.GetComponent<Rigidbody>().isKinematic = false;
                GetComponent<Rigidbody>().AddForce(Vector3.down * 200);
            }
        }
        GameObject component;

        Vector3 tempVelocity;

        static float num = 0.5f;

        Vector3[] array = new Vector3[]
               {
                new Vector3(-num, 0f, 0f),
                new Vector3(0f, 0f, 0f),
                new Vector3(num, 0f, 0f),
                new Vector3(-num, 0f, -num),
                new Vector3(0f, 0f, -num),
                new Vector3(num, 0f, -num),
                new Vector3(-num, 0f, num),
                new Vector3(0f, 0f, num),
                new Vector3(num, 0f, num),
                new Vector3(0f, 0f, 0f),
                new Vector3(0f, 0f, num + 0.3f)
                };
        private void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.CompareTag("Road"))
            {
                Destroy(this.GetComponent<Rigidbody>());

                this.bigBall.gameObject.SetActive(false);
               
                for (int i = 0; i < max; i++)
                {
                    component = Instantiate(ball, bigBall.transform.position + array[i], Quaternion.identity).gameObject;
                    component.transform.SetParent(this.gameObject.transform);
                    tempVelocity.x = Random.Range(-1.5f, 1.5f);
                    tempVelocity.y = Random.Range(3.5f, 4.5f);
                    tempVelocity.z = Random.Range(-1.9f, 1.9f);
                    component.GetComponent<Rigidbody>().velocity = tempVelocity;
                }
            }
        }
    }
}