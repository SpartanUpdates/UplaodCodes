package com.esc.uvideostatus.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.uvideostatus.R;

public class LanguageActivity extends AppCompatActivity {
    private static String[] strings = {"Gujarati", "English", "Marathi", "Punjabi", "Tamil", "Hindi", "Kannada", "Telugu", "Bhojpuri"};
    ImageView iv_backpress;
    ListView listView;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_language);
        this.listView = findViewById(R.id.listview);
        this.iv_backpress = findViewById(R.id.iv_backpress);
        this.listView.setAdapter(new ArrayAdapter(this, 17367043, strings));
        this.iv_backpress.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                LanguageActivity.this.onBackPressed();
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
