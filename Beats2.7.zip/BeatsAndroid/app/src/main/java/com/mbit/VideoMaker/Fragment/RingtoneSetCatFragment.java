package com.mbit.VideoMaker.Fragment;


import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mbit.VideoMaker.Adapter.RingtoneAdapter;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.d;
import com.mbit.VideoMaker.Model.OnlineSongModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.retrofit.APIClient;
import com.mbit.VideoMaker.retrofit.ApiInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RingtoneSetCatFragment extends Fragment {

    public static MediaPlayer mediaPlayer;
    public ArrayList<OnlineSongModel> songModelArrayList = new ArrayList<>();
    public RingtoneAdapter ringtoneAdapter;
    Integer CategoryId = -1;
    RelativeLayout rlloadingpager;
    RecyclerView rvCategoryWiseTheme;
    LinearLayout llInternetCheck;
    Button btnRetry;
    //    String SongCatWiseDataUrl = "";
    String offlienResopnseData;
    SharedPreferences ThemeHomePreferences;
    String MY_PREF = "Song_pref";
    SharedPreferences pref;
    private String CatId;
    private boolean IsofflineResopnse = false;
    public static d sharedpreferences;
    String[] split_AllLan;
    String[] split_selctedLan;

    Long timestamps;
    public static Fragment getInstance(int catid) {
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        RingtoneSetCatFragment categoryWiseSongFragment = new RingtoneSetCatFragment();
        categoryWiseSongFragment.setArguments(bundle);
        return categoryWiseSongFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CategoryId = getArguments().getInt("CategoryId");
        CatId = String.valueOf(CategoryId);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_online_song_catwise, container, false);
        ThemeHomePreferences = getActivity().getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = d.a(getActivity());
        split_AllLan = ("35,27,34,33,29,32,30,31,28,24,22,25,36").split(",");
        split_selctedLan = d.a(getActivity()).a("pref_key_language_list", "22").split(",");
        bindView(rootView);
        SetListener();
        SetThemeAdapter();
        if (songModelArrayList != null && songModelArrayList.size() == 0) {
            /*if (ThemeHomePreferences.getBoolean("ThemeFirstTime", true)) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    ThemeHomePreferences.edit().putBoolean("ThemeFirstTime", false).apply();
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation !", Toast.LENGTH_LONG).show();
                }
            } else {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    IsofflineResopnse = true;
                    String id = pref.getString(CatId, null);
                    if (id != null && !id.equals("")) {
                        SetThemeAdapter();
                        getOfflineCategory(getActivity(), CatId);
                        LoadOfflineSongByCat(offlienResopnseData);
                    } else {
                        llInternetCheck.setVisibility(View.VISIBLE);
                        Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                    }
                }
            }*/
            if (Utils.checkConnectivity(getActivity(), false)) {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null && timestamps != null) {
                    if (offlienResopnseData != null) {
                        LoadOfflineSongByCat(offlienResopnseData);
                    }
                }
            } else {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null) {
                    LoadOfflineSongByCat(offlienResopnseData);
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }

        } else {
            SetThemeAdapter();
        }
        return rootView;
    }


    private void bindView(View view) {
        rvCategoryWiseTheme = view.findViewById(R.id.rv_onlinesong);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlloadingpager = view.findViewById(R.id.rl_load_onlinesong);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void SetThemeAdapter() {
        ringtoneAdapter = new RingtoneAdapter(getActivity(), songModelArrayList, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvCategoryWiseTheme.setLayoutManager(mLayoutManager);
        rvCategoryWiseTheme.setAdapter(ringtoneAdapter);
        ringtoneAdapter.notifyDataSetChanged();
    }


    public void SetOfflineTheme(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    public void rePlayAudio(final int n, final boolean b) {
        if (b) {
            this.stopPlaying(mediaPlayer);
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.reset();
                mediaPlayer.setDataSource(Utils.INSTANCE.getMusicFolderPath() + File.separator + songModelArrayList.get(n).getSongUrl());
//                FinalMusicPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(n).getSongUrl();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.prepareAsync();
            return;
        }
    }


    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    private void LoadOfflineSongByCat(String Response) {
        try {
            JSONObject jsonObj = new JSONObject(Response);
            JSONArray jsonArray = jsonObj.getJSONArray("category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                if (CategoryId == Catid) {
                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                        OnlineSongModel songModel = new OnlineSongModel();
                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                            songModel.setSongCategoryId(songJSONObject.getString("id"));
                            songModel.setSongName(songJSONObject.getString("sound_filename"));
                            songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                            songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                            songModel.setSongSize(songJSONObject.getString("sound_size"));
                            songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                            songModelArrayList.add(songModel);
                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                            songModel.setSongCategoryId(songJSONObject.getString("id"));
                            songModel.setSongName(songJSONObject.getString("sound_filename"));
                            songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                            songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                            songModel.setSongSize(songJSONObject.getString("sound_size"));
                            songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                            songModelArrayList.add(songModel);
                        }

                    }
                }
            }
            ringtoneAdapter.notifyDataSetChanged();
            rlloadingpager.setVisibility(View.GONE);
        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }

    private void GetSongByCategory() {
        rlloadingpager.setVisibility(View.VISIBLE);
        APIClient.getRetrofit().create(ApiInterface.class).GetAllTheme("aciativtyksdfhal5215ajal", "5").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
//                        if (getActivity() != null) {
//                            SetOfflineTheme(getActivity(), jsonObj.toString(), CatId);
//                        }
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            if (CategoryId == Catid) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                                    OnlineSongModel songModel = new OnlineSongModel();
                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                        songModel.setSongCategoryId(songJSONObject.getString("id"));
                                        songModel.setSongName(songJSONObject.getString("sound_filename"));
                                        songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                        songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                        songModel.setSongSize(songJSONObject.getString("sound_size"));
                                        songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                        songModelArrayList.add(songModel);
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        songModel.setSongCategoryId(songJSONObject.getString("id"));
                                        songModel.setSongName(songJSONObject.getString("sound_filename"));
                                        songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                        songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                        songModel.setSongSize(songJSONObject.getString("sound_size"));
                                        songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                        songModelArrayList.add(songModel);
                                    }

                                }
                            }
                        }
                        ringtoneAdapter.notifyDataSetChanged();
                        rlloadingpager.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }
}
