<?php


// Firebase API Key
define('FIREBASE_API_KEY', 'AAAA8f4Toyg:APA91bEDPqpGc0aafLR7KfbJo6m68DE0lI5RWqNgomyo2GuzGizxK3gX-0pWWJfJGilXhoEQFOnTmrWhr3keVxFoGQGJXKSfzoJis5_wuJp_DFybO-r5A6OkJMUVTIokNHI8yhpvP48X');
