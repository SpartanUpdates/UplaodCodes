package com.kotlinz.festivalstorymaker.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Layout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class BaseActivity extends AppCompatActivity {
    public static Activity activity;
    public int A;
    public Bitmap bitmap;
    public Canvas canvas;
    public StringBuilder StringBuilder;
    public List<String> fontList;
    public String[] colorList;
    public RelativeLayout.LayoutParams layoutParams;
    public Utils u;
    public File file;
    public Bitmap bitmap2;
    public FileOutputStream fileOutputStream;
    public Intent intent;
    public int anInt;

    public BaseActivity() {
        file = null;
        bitmap = null;
    }

    public TextStickerViewNew1 d0(final Context context, final ScrollView scrollView, int layoutX, int layoutY, final String s) {
        layoutX /= 2;
        layoutY /= 2;
        final TextStickerViewNew1 textStickerViewNew1 = new TextStickerViewNew1(context, scrollView, layoutX, layoutY);
        (layoutParams = new RelativeLayout.LayoutParams(-2, -2)).addRule(10);
        textStickerViewNew1.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final Font font = new Font();
        font.a = -16777216;
        font.b = 15;
        textStickerViewNew1.setText("");
        textStickerViewNew1.setLayoutX(layoutX);
        textStickerViewNew1.setLayoutY(layoutY);
        textStickerViewNew1.setScale(4.0f);
        textStickerViewNew1.setPaddingLeft(10);
        textStickerViewNew1.setPaddingRight(10);
        textStickerViewNew1.setAlign(Layout.Alignment.ALIGN_CENTER);
        textStickerViewNew1.setOpacity(255);
        textStickerViewNew1.setUnderLine(false);
        textStickerViewNew1.setStrikethrough(false);
        textStickerViewNew1.setLetterSpacing(0.0f);
        textStickerViewNew1.setLineSpacing(10.0f);
        textStickerViewNew1.setTag((Object) 1);
        return textStickerViewNew1;
    }


    public Bitmap e0(final View view) {
        anInt = view.getHeight() * 2;
        final int a = view.getWidth() * 2;
        this.A = a;
        view.measure(View.MeasureSpec.makeMeasureSpec(a, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(anInt, View.MeasureSpec.EXACTLY));
        try {
            bitmap = Bitmap.createBitmap(this.A, anInt, Bitmap.Config.ARGB_8888);
            (canvas = new Canvas(bitmap)).translate(0.0f, 0.0f);
            canvas.drawColor(-1, PorterDuff.Mode.CLEAR);
            canvas.scale(2.0f, 2.0f);
            view.draw(canvas);
            return bitmap;
        } catch (Exception ex) {
            ex.printStackTrace();
            return bitmap;
        }
    }

    public String f0(final String s) {
        StringBuilder = new StringBuilder(s.length());
        final String[] split = s.split(" ");
        for (int length = split.length, i = 0; i < length; ++i) {
            final String s2 = split[i];
            if (!s2.isEmpty()) {
                StringBuilder.append(Character.toUpperCase(s2.charAt(0)));
                StringBuilder.append(s2.substring(1).toLowerCase());
            }
            if (StringBuilder.length() != s.length()) {
                StringBuilder.append(" ");
            }
        }
        return StringBuilder.toString();
    }

    @Override
    public void onCreate(final Bundle bundle) {
        super.onCreate(null);
        (this.u = new Utils(this)).c("Loading...");
        BaseActivity.activity = this;
        Utils.u = new ArrayList<String>();
        final String o = AppConstant.FontList;
        Utils.v = ((Context) this).getSharedPreferences("Font_list", 0);
        Utils.w = new Gson();
        if (!(Utils.x = Utils.v.getString("FontList", "")).isEmpty()) {
            Utils.u = Utils.w.fromJson(Utils.x, Utils.y = new com.kotlinz.festivalstorymaker.Other.e().getType());
        }
        fontList = Utils.u;
        colorList = this.getResources().getStringArray(R.array.colors_list);
        PutAnalyticsEvent();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BaseActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    @Override
    public void onDestroy() {
        final Utils u = this.u;
        if (u != null) {
            u.u();
        }
        super.onDestroy();
    }

    @Override
    public void onResume() {
        super.onResume();
        Utils.E = this;
    }


    public static class a {
        public a() {
        }


        public ColorFilter a(float n) {
            final ColorMatrix colorMatrix = new ColorMatrix();
            n = Math.min(360.0f, Math.max(-360.0f, n)) / 180.0f * 3.1415927f;
            if (n != 0.0f) {
                final double n2 = n;
                n = (float) Math.cos(n2);
                final float n3 = (float) Math.sin(n2);
                final float n4 = n * -0.715f + 0.715f;
                final float n5 = -0.072f * n + 0.072f;
                final float n6 = -0.213f * n + 0.213f;
                colorMatrix.postConcat(new ColorMatrix(new float[]{n3 * -0.213f + (0.787f * n + 0.213f), -0.715f * n3 + n4, n3 * 0.928f + n5, 0.0f, 0.0f, 0.143f * n3 + n6, 0.14f * n3 + (0.28500003f * n + 0.715f), -0.283f * n3 + n5, 0.0f, 0.0f, -0.787f * n3 + n6, 0.715f * n3 + n4, n3 * 0.072f + (n * 0.928f + 0.072f), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f}));
            }
            return (ColorFilter) new ColorMatrixColorFilter(colorMatrix);
        }
    }

    public class b extends AsyncTask<View, Boolean, File> {


        @Override
        protected void onPostExecute(File o) {
            super.onPostExecute(o);
            final File file = (File) o;
            u.u();
            if (file != null) {
                Utils.d();
                (intent = new Intent("android.intent.action.SEND")).setType("image/*");
                intent.putExtra("android.intent.extra.STREAM", (Parcelable) Uri.fromFile(file));
                final BaseActivity a = BaseActivity.this;
                a.startActivity(Intent.createChooser(a.intent, (CharSequence) "Share image using"));
            }
        }

        @Override
        protected File doInBackground(View... array) {
            final View[] array2 = (View[]) array;
            try {
                bitmap2 = e0(array2[0]);
                file = Utils.r();
                if (file != null) {
                    fileOutputStream = new FileOutputStream(file.getAbsolutePath());
                    bitmap2.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream) fileOutputStream);
                    fileOutputStream.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return file;
        }

        public void onPreExecute() {
            super.onPreExecute();
            u.M();
        }
    }
}