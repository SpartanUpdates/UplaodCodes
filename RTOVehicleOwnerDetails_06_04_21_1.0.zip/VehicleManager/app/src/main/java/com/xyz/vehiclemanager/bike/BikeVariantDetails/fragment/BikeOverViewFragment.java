package com.xyz.vehiclemanager.bike.BikeVariantDetails.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.activity.BikeVariantTabActivity;
import com.xyz.vehiclemanager.adapter.VariantItemAttrAdapter;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeOverview;
import com.xyz.vehiclemanager.bike.BikeVariantDetails.model.BikeVariantRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeOverViewFragment extends Fragment {
    private View view;
    private TextView tv_title;
    private RecyclerView rv_variantdetails;
    private ArrayList<Item> overviewlist = new ArrayList<>();
    private VariantItemAttrAdapter variantItemAttrAdapter;
    private RtoDetailsInterface rtoDetailsInterface;

    public BikeOverViewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_variant_details, container, false);

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        rv_variantdetails = view.findViewById(R.id.rv_variantdetails);
        tv_title = view.findViewById(R.id.tv_title);
        getOverViewVariantData();
        return view;
    }

    private void getOverViewVariantData() {
        Call<BikeVariantRoot> call = rtoDetailsInterface.getBikeVariantDetails(BikeVariantTabActivity.varientId);
        call.enqueue(new Callback<BikeVariantRoot>() {
            @Override
            public void onResponse(Call<BikeVariantRoot> call, Response<BikeVariantRoot> response) {
                if (response.isSuccessful()) {
                    tv_title.setText("OverView");
                    ArrayList<BikeOverview> variantlist = response.body().getDetails().getOverview();
                    for (int i = 0; i < variantlist.size(); i++) {
                        String key = variantlist.get(i).getKey();
                        ArrayList<Item> itemlist = response.body().getDetails().getOverview().get(i).getItems();
                        for (int j = 0; j < itemlist.size(); j++) {
                            Item item = new Item();
                            String sAttrName = itemlist.get(j).getAttrName();
                            String sAttrValue = itemlist.get(j).getAttrValue();
                            item.setAttrName(sAttrName);
                            item.setAttrValue(sAttrValue);
                            overviewlist.add(item);
                        }
                        variantItemAttrAdapter = new VariantItemAttrAdapter(getContext(), overviewlist);
                        rv_variantdetails.setAdapter(variantItemAttrAdapter);
                        rv_variantdetails.setLayoutManager(new LinearLayoutManager(getContext()));
                    }
                }
            }

            @Override
            public void onFailure(Call<BikeVariantRoot> call, Throwable t) {
                Toast.makeText(getActivity(), "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}