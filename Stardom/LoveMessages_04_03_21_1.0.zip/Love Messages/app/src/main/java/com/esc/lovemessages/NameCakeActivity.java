package com.esc.lovemessages;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class NameCakeActivity extends AppCompatActivity {
    Activity activity = NameCakeActivity.this;
    static GridAdapter adapter2 = null;
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (NameCakeActivity.i == 0) {
                NameCakeActivity.i++;
                NameCakeActivity.handler.postDelayed(NameCakeActivity.changeAdBool, 45000);
                return;
            }
            NameCakeActivity.showbool = true;
            NameCakeActivity.i = 0;
            NameCakeActivity.stopRunnable();
        }
    };
    static Editor editor1 = null;
    public static GridView gv = null;
    public static Handler handler = new Handler();
    static int i = 0;
    static int[] icon = new int[8];
    static boolean showbool = false;
    static boolean startbool = false;
    static boolean stopbool = false;
    public static Typeface typeface;
    public Editor editorAds;
    private RelativeLayout exitrelative;
    TextView exittxt;
    ImageView imageView;
    DisplayMetrics metrics;
    public int sh;
    SharedPreferences sharedPreferences;
    public SharedPreferences sharedPreferencesAds;
    public int sw;
    TextView textView;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    private class GridAdapter extends BaseAdapter {
        Context context;
        private int[] gimg;
        ViewHolder holder;
        private LayoutInflater inflater = null;
        private String pgurl2;

        class ViewHolder {
            public ImageView image;

            ViewHolder() {
            }
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public GridAdapter(Context context, int[] iArr) {
            this.context = context;
            this.gimg = iArr;
            this.inflater = LayoutInflater.from(context);
        }

        public int getCount() {
            return this.gimg.length;
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = this.inflater.inflate(R.layout.grid_list, null);
                this.holder = new ViewHolder();
                this.holder.image = (ImageView) view.findViewById(R.id.gridicon);
                view.setTag(this.holder);
            } else {
                this.holder = (ViewHolder) view.getTag();
            }
            NameCakeActivity.this.imageView = this.holder.image;
            NameCakeActivity.this.imageView.getLayoutParams().width = NameCakeActivity.this.sw / 2;
            NameCakeActivity.this.imageView.getLayoutParams().height = NameCakeActivity.this.sw / 2;
            this.holder.image.setImageResource(NameCakeActivity.icon[i]);
            return view;
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_name_cake);
        String str = "MYPREFERENCE";
        this.sharedPreferencesAds = getSharedPreferences(str, 0);
        this.editorAds = this.sharedPreferencesAds.edit();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        textView.setText("Name On Birthday Cake");
        textView.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf"));
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        this.textView = (TextView) findViewById(R.id.textView);
        typeface = Typeface.createFromAsset(getAssets(), "fonts/Magnolia Script.otf");
        this.textView.setTypeface(typeface);
        textView.setTypeface(typeface);
        this.exitrelative = (RelativeLayout) findViewById(R.id.exitrelative2);
        this.exitrelative.setVisibility(View.GONE);
        this.exittxt = (TextView) findViewById(R.id.exitmsg);
        BannerAds();
        int i = 0;
        while (i < 8) {
            Resources resources = getResources();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("cake");
            int i2 = i + 1;
            stringBuilder.append(i2);
            icon[i] = resources.getIdentifier(stringBuilder.toString(), "drawable", getPackageName());
            i = i2;
        }
        this.metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.metrics);
        this.sw = this.metrics.widthPixels;
        this.sh = this.metrics.heightPixels;
        this.sharedPreferences = getSharedPreferences(str, 0);
        editor1 = this.sharedPreferences.edit();
        gv = (GridView) findViewById(R.id.gridView1);
        gv.setAdapter(adapter2);
        gv.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Intent intent = new Intent(NameCakeActivity.this, SecondActivity.class);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(i + 1);
                stringBuilder.append("");
                intent.putExtra("image", stringBuilder.toString());
                NameCakeActivity.this.startActivity(intent);
            }
        });
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void stopRunnable() {
        if (stopbool) {
            handler.removeCallbacks(changeAdBool);
        }
    }

    public static void startRunnable() {
        if (!startbool) {
            changeAdBool.run();
            showbool = false;
            stopbool = false;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onResume() {
        super.onResume();
        startRunnable();
        String str = "RESUME";
        Log.e(str, str);
        gv.setAdapter(new GridAdapter(getApplicationContext(), icon));
    }

    private static boolean isNetworkAvailable(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static void openAppRating(Context context) {
        String packageName = context.getPackageName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("market://details?id=");
        stringBuilder.append(packageName);
        String str = "android.intent.action.VIEW";
        Intent intent = new Intent(str, Uri.parse(stringBuilder.toString()));
        int i = 0;
        for (ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(intent, 0)) {
            if (resolveInfo.activityInfo.applicationInfo.packageName.equals("com.android.vending")) {
                ActivityInfo activityInfo = resolveInfo.activityInfo;
                ComponentName componentName = new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name);
                intent.setComponent(componentName);
                context.startActivity(intent);
                i = 1;
                break;
            }
        }
        if (i == 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("https://play.google.com/store/apps/details?id=");
            stringBuilder.append(packageName);
            context.startActivity(new Intent(str, Uri.parse(stringBuilder.toString())));
        }
    }
}
