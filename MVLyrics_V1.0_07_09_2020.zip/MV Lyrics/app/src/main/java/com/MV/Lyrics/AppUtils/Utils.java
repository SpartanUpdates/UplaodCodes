package com.MV.Lyrics.AppUtils;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.os.Environment;
import android.widget.Toast;
import com.MV.Lyrics.Partical.Model.ParticalModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class Utils {
    public static final Utils INSTANCE;
    public ArrayList<ParticalModel> particalAssetModels = new ArrayList<ParticalModel>();
    public static String SongCropCommanPath;
    public static long mDeleteFileCount;
//    public static String PathOfMusicFolder = Environment.getExternalStorageDirectory() + File.separator + "MV Lyrics" + File.separator + "Online Song";
    public static String PathOfAssetFolder = Environment.getExternalStorageDirectory() + File.separator + "MV Lyrics" + File.separator + ".asset_bundle";
    public static String PathOfThemeFolder = Environment.getExternalStorageDirectory() + File.separator + "MV Lyrics" + File.separator + ".ThemeDownload";

    static {
        INSTANCE = new Utils();
        Utils.SongCropCommanPath = Environment.getExternalStorageDirectory() + File.separator + "MV Lyrics" + File.separator + "My Story";
        Utils.mDeleteFileCount = 0L;
    }

    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }


    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/MV Lyrics/";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Utils.INSTANCE.getStoryFolderPath();
    }

    public final String getAPPFOLDER() {
        return "MV Lyrics";
    }

    public final String getOutputPath() {
        final String path = Environment.getExternalStorageDirectory().toString() + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getStoryFolderPath() {
        final String path = this.getOutputPath() + "My Story" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getTrimVideoFolderPath() {
        final String path = this.getOutputPath() + "Trim Video" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getLyricsPath() {
        final String path = this.getOutputPath() + "Download Lyrics" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath() {
        final String path = this.getOutputPath() + ".ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    /*public final String getMusicFolderPath() {
        final String path = this.getOutputPath() + "Online Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }
*/
    public final String getCropSongPath() {
        final String path = this.getOutputPath() + "Crop Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getAssetUnityPath() {
        final String path = this.getOutputPath() + ".asset_bundle" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }

    public String TimeCaculate(long value) {
        String videoTime;
        int dur = (int) value;
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60000;
        int scs = dur % 60000 / 1000;
        if (hrs > 0) {
            videoTime = String.format("%02d:%02d:%02d", hrs, mns, scs);
        } else {
            videoTime = String.format("%02d:%02d", mns, scs);
        }
        return videoTime;
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    public void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                this.deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    public void CopyAssets(Context context) {
        AssetManager assetManager = context.getAssets();
        String[] files = null;
        try {
            files = assetManager.list("Partical");
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (String filename : files) {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = assetManager.open("Partical" + "/" + filename);   // if files resides inside the "Files" directory itself
                out = new FileOutputStream(getAssetUnityPath() + filename);
                copyFile(in, out);
                in.close();
                in = null;
                out.flush();
                out.close();
                out = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }

    public static float dp2px(final Resources resources, final float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(final Resources resources, final float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }
}
