package com.esc.tarotcardreading;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class FbDialog extends Dialog {
    static final float[] DIMENSIONS_DIFF_LANDSCAPE = new float[]{20.0f, 60.0f};
    static final float[] DIMENSIONS_DIFF_PORTRAIT = new float[]{40.0f, 60.0f};
    static final String DISPLAY_STRING = "touch";
    static final int FB_BLUE = -9599820;
    static final LayoutParams FILL = new LayoutParams(-1, -1);
    static final int MARGIN = 4;
    static final int PADDING = 2;
    private FrameLayout mContent;
    private ImageView mCrossImage;
    private Facebook.DialogListener mListener;
    private ProgressDialog mSpinner;
    private String mUrl;
    private WebView mWebView;

    private class FbWebViewClient extends WebViewClient {
        private FbWebViewClient() {
        }

         FbWebViewClient(FbDialog fbDialog) {
            this();
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Redirect URL: ");
            stringBuilder.append(str);
            Log.d("Facebook-WebView", stringBuilder.toString());
            if (str.startsWith(Facebook.REDIRECT_URI)) {
                Bundle parseUrl = Util.parseUrl(str);
                str = parseUrl.getString("error");
                if (str == null) {
                    str = parseUrl.getString("error_type");
                }
                if (str == null) {
                    FbDialog.this.mListener.onComplete(parseUrl);
                } else if (str.equals("access_denied") || str.equals("OAuthAccessDeniedException")) {
                    FbDialog.this.mListener.onCancel();
                } else {
                    FbDialog.this.mListener.onFacebookError(new FacebookError(str));
                }
                FbDialog.this.dismiss();
                return true;
            } else if (str.startsWith(Facebook.CANCEL_URI)) {
                FbDialog.this.mListener.onCancel();
                FbDialog.this.dismiss();
                return true;
            } else if (str.contains(FbDialog.DISPLAY_STRING)) {
                return false;
            } else {
                FbDialog.this.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                return true;
            }
        }

        public void onReceivedError(WebView webView, int i, String str, String str2) {
            super.onReceivedError(webView, i, str, str2);
            FbDialog.this.mListener.onError(new DialogError(str, i, str2));
            FbDialog.this.dismiss();
        }

        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Webview loading URL: ");
            stringBuilder.append(str);
            Log.d("Facebook-WebView", stringBuilder.toString());
            super.onPageStarted(webView, str, bitmap);
            FbDialog.this.mSpinner.show();
        }

        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            FbDialog.this.mSpinner.dismiss();
            FbDialog.this.mContent.setBackgroundColor(0);
            FbDialog.this.mWebView.setVisibility(View.VISIBLE);
            FbDialog.this.mCrossImage.setVisibility(View.VISIBLE);
        }
    }

    public FbDialog(Context context, String str, Facebook.DialogListener dialogListener) {
        super(context);
        this.mUrl = str;
        this.mListener = dialogListener;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        this.mSpinner = progressDialog;
        progressDialog.requestWindowFeature(1);
        this.mSpinner.setMessage("Loading...");
        requestWindowFeature(1);
        this.mContent = new FrameLayout(getContext());
        createCrossImage();
        setUpWebView(this.mCrossImage.getDrawable().getIntrinsicWidth() / 2);
        this.mContent.addView(this.mCrossImage, new ViewGroup.LayoutParams(-2, -2));
        addContentView(this.mContent, new ViewGroup.LayoutParams(-1, -1));
    }

    private void createCrossImage() {
        ImageView imageView = new ImageView(getContext());
        this.mCrossImage = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FbDialog.this.mListener.onCancel();
                FbDialog.this.dismiss();
            }
        });
        this.mCrossImage.setImageDrawable(getContext().getResources().getDrawable(R.drawable.close));
        this.mCrossImage.setVisibility(View.INVISIBLE);
    }

    private void setUpWebView(int i) {
        LinearLayout linearLayout = new LinearLayout(getContext());
        WebView webView = new WebView(getContext());
        this.mWebView = webView;
        webView.setVerticalScrollBarEnabled(false);
        this.mWebView.setHorizontalScrollBarEnabled(false);
        this.mWebView.setWebViewClient(new FbWebViewClient(this));
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.loadUrl(this.mUrl);
        this.mWebView.setLayoutParams(FILL);
        this.mWebView.setVisibility(View.INVISIBLE);
        linearLayout.setPadding(i, i, i, i);
        linearLayout.addView(this.mWebView);
        this.mContent.addView(linearLayout);
    }
}
