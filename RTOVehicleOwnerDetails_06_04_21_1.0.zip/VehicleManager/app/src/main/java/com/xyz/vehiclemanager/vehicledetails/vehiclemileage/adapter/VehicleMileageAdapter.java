package com.xyz.vehiclemanager.vehicledetails.vehiclemileage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;
import java.text.DecimalFormat;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class VehicleMileageAdapter extends RecyclerView.Adapter<VehicleMileageAdapter.ViewHolder> {

    Context context;
    ArrayList<Mileage> arrayList;
    OnItemClickListener clickListener;

    public interface OnItemClickListener {
        void onItemClick(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_from_kms, tv_to_kms, tv_pricefuel, tv_date, tv_kmperltr, tv_inrperkm, tv_inrperltr;
        LinearLayout ll_click;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_from_kms = itemView.findViewById(R.id.tv_from_kms);
            tv_to_kms = itemView.findViewById(R.id.tv_to_kms);
            tv_pricefuel = itemView.findViewById(R.id.tv_pricefuel);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_kmperltr = itemView.findViewById(R.id.tv_kmperltr);
            tv_inrperkm = itemView.findViewById(R.id.tv_inrperkm);
            tv_inrperltr = itemView.findViewById(R.id.tv_inrperltr);
            ll_click = itemView.findViewById(R.id.ll_click);
        }
    }

    public VehicleMileageAdapter(Context context, ArrayList<Mileage> arrayList, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.arrayList = arrayList;
        this.clickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(context).inflate(R.layout.layout_mileage,null,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position)
    {
        Mileage mileage = arrayList.get(position);

        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("You spend ");
        stringBuilder.append(mileage.getFuel());
        stringBuilder.append(" for ");
        stringBuilder.append(mileage.getPrice());
        stringBuilder.append(" ");
        stringBuilder.append(this.context.getString(R.string.COST_UNIT));
        stringBuilder.append(" liter fuel.");

        holder.tv_from_kms.setText(arrayList.get(position).getLastReserve());
        holder.tv_to_kms.setText(arrayList.get(position).getCurrentReserve());
        holder.tv_pricefuel.setText(stringBuilder.toString());
        holder.tv_date.setText(mileage.getDate());
        holder.tv_kmperltr.setText(mileage.getMileageKm()+" km/ltr || ");
        holder.tv_inrperltr.setText(mileage.getMileageInrLtr()+" inr/ltr");
        holder.tv_inrperkm.setText(mileage.getMileageInrKm()+" inr/km || ");

        holder.ll_click.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view)
            {
                VehicleMileageAdapter.this.clickListener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
}
