package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;


public class CEFontHeight implements SeekBar.OnSeekBarChangeListener
{
    public final CanvasEditorActivity activity;

    public CEFontHeight(final CanvasEditorActivity e) {
        this.activity = e;
    }

    public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
        if (b) {
            this.activity.t1.setLineSpacing((float)n);
            this.activity.t1.requestLayout();
            final com.kotlinz.festivalstorymaker.Models.z.c c = activity.s1.get((int)activity.t1.getTag());
            c.b = n + 5;
            activity.s1.set((int)activity.t1.getTag(), c);
        }
    }

    public void onStartTrackingTouch(final SeekBar seekBar) {
    }

    public void onStopTrackingTouch(final SeekBar seekBar) {
    }
}
