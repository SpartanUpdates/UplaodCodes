package com.kotlinz.vehiclemanager.Preferance;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.Date;

public class PreferencesManager {
    public static final PreferencesManager INSTANCE;

    public long ApiUpdateTime = 86400000L;//After 24 Hour To Update Api Data
    public static String credentials = "credentials";
    public static String credentialsResponseTime = "credentialsResponseTime";

    static {
        INSTANCE = new PreferencesManager();
    }

    public SharedPreferences pref;

    public void setDataToOffline(Context context, String response, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(preferencesKey, response);
        editor.apply();
    }

    public void SetApiCallResponseTime(Context context, final Date date, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(preferencesKey, date.getTime());
        editor.apply();
    }

    public String getPreferencesData(Context context, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        return pref.getString(preferencesKey, "");
    }

    public long getPreferencesResponseTime(Context context, String preferencesKey, long DefaultValue) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        return pref.getLong(preferencesKey, DefaultValue);
    }

    public void removePreference(Context context, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(key);
        editor.apply();
    }
}
