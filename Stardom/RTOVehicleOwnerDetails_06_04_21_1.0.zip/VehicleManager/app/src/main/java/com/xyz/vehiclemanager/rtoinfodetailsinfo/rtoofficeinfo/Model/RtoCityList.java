package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RtoCityList {
    @SerializedName("name")
    public String stateName;
    @SerializedName("rtoList")
    public ArrayList<RtoOfficeDetail> cityName;

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public ArrayList<RtoOfficeDetail> getCityName() {
        return cityName;
    }

    public void setCityName(ArrayList<RtoOfficeDetail> cityName) {
        this.cityName = cityName;
    }
}
