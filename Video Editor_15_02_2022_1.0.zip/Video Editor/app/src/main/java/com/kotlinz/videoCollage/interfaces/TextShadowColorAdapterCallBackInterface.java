package com.kotlinz.videoCollage.interfaces;

public interface TextShadowColorAdapterCallBackInterface {
    void itemClick(int i);
}
