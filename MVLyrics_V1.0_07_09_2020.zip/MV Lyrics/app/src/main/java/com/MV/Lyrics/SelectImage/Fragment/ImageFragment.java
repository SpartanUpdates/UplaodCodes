package com.MV.Lyrics.SelectImage.Fragment;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.MV.Lyrics.R;
import com.google.android.material.tabs.TabLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

public class ImageFragment extends Fragment {

    private ArrayList<String> FolderNameList = new ArrayList<>();
    private TabLayout tabLayout;
    private ViewPager viewPager;
    PagerAdapter adp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_image, container, false);
        BindView(view);
        getAllImageFolderFormStorage();
        return view;
    }

    private void BindView(View view) {
        tabLayout = view.findViewById(R.id.tab_image_folder);
        viewPager = view.findViewById(R.id.vp_image);
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                LinearLayout underline = customView.findViewById(R.id.indictor);
                underline.setVisibility(View.VISIBLE);
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout underline = customView.findViewById(R.id.indictor);
                underline.setVisibility(View.VISIBLE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout underline = customView.findViewById(R.id.indictor);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

    }

    private void setUpPagerNew() {
        adp = new PagerAdapter(getChildFragmentManager());
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    public class PagerAdapter extends FragmentPagerAdapter {

        public PagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return (ImageMediaFragment.getInstance(FolderNameList.get(position), "Images"));
        }

        @Override
        public int getCount() {
            return FolderNameList.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(getActivity()).inflate(
                    R.layout.row_folder_item, null);
            TextView tv = tab.findViewById(R.id.tvFolderName);
            tv.setText(FolderNameList.get(position));
            return tab;
        }
    }

    public void getAllImageFolderFormStorage() {
        FolderNameList.clear();
        String[] projection = new String[]{MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DATA};
        Cursor cursor = getContext().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, MediaStore.Images.Media.DATE_ADDED);
        ArrayList<String> FolderNameList = new ArrayList<>(cursor.getCount());
        ArrayList<String> ImageList = new ArrayList<>(cursor.getCount());
        HashSet<String> albumSet = new HashSet<>();
        File file;
        if (cursor.moveToLast()) {
            do {
                if (Thread.interrupted()) {
                    return;
                }
                String album = cursor.getString(cursor.getColumnIndex(projection[0]));
                String image = cursor.getString(cursor.getColumnIndex(projection[1]));
                file = new File(image);
                if (file.exists() && !albumSet.contains(album)) {
                    FolderNameList.add(album);
                    ImageList.add(image);
                    albumSet.add(album);
                }
            } while (cursor.moveToPrevious());
        }
        cursor.close();
        if (FolderNameList == null) {
            this.FolderNameList = new ArrayList<>();
        }
        this.FolderNameList.clear();
        this.FolderNameList.addAll(FolderNameList);
        setUpPagerNew();
        SetTabLayout();
    }
}



