package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.TextBGColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class TextBGColorAdapter extends Adapter<TextBGColorAdapter.ViewHolder> {
    private String[] bgColorList;
    private Context context;
    private TextBGColorAdapterCallBackInterface listener;
    private int pos = 1;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgTextBGColor;
        ImageView imgTextBGSelector;

        ViewHolder(View view) {
            super(view);
            this.imgTextBGColor = (ImageView) view.findViewById(R.id.img_text_bg_color);
            this.imgTextBGSelector = (ImageView) view.findViewById(R.id.img_text_bg_color_selector);
        }
    }

    public TextBGColorAdapter(String[] strArr, Context context, TextBGColorAdapterCallBackInterface textBGColorAdapterCallBackInterface) {
        this.bgColorList = strArr;
        this.listener = textBGColorAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_text_bg_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = this.bgColorList[i];
        viewHolder.imgTextBGColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgTextBGColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgTextBGColor.setBackground(gradientDrawable);
        viewHolder.imgTextBGColor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextBGColorAdapter.this.pos = i;
                TextBGColorAdapter.this.listener.itemClick(i);
                TextBGColorAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgTextBGSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgTextBGSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.bgColorList.length;
    }
}
