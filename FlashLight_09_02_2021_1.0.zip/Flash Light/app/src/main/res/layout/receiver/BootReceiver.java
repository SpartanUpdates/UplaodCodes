package flash.light.shine.com.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.Log;
import flash.light.shine.com.APP;
import flash.light.shine.com.service.ScreenOnOffService;
import flash.light.shine.com.util.PrefManager;

public class BootReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            if (action != null) {
                if ("android.intent.action.BOOT_COMPLETED".equals(action)) {
                    Log.d("BootReceiver", "ACTION_BOOT_COMPLETED");
                    initScreenOnOffService(context);
                } else if (VERSION.SDK_INT >= 12) {
                    onPackageReplaced(context, action);
                }
            }
        }
    }

    private void onPackageReplaced(Context context, String str) {
        if ("android.intent.action.MY_PACKAGE_REPLACED".equals(str)) {
            Log.d("BootReceiver", "ACTION_MY_PACKAGE_REPLACED");
            initScreenOnOffService(context);
        }
    }

    private void initScreenOnOffService(Context context) {
        PrefManager prefManager = APP.getPrefManager();
        if (!prefManager.getUseScreenOn() && prefManager.getUseTotally()) {
            prefManager.setScreenOnTime(SystemClock.elapsedRealtime());
            Intent intent = new Intent(context, ScreenOnOffService.class);
            intent.putExtra(ScreenOnOffService.EXTRA_BOOT_COMPLETED, true);
            context.startService(intent);
        }
    }
}
