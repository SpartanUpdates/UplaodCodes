package com.unitedvideos.CropView.imagezoomcrop.cropoverlay.utils;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.view.View;

public class ImageViewUtil
{
  public static Rect getBitmapRectCenterInside(final Bitmap bitmap, final View view) {
    final int bitmapWidth = bitmap.getWidth();
    final int bitmapHeight = bitmap.getHeight();
    final int viewWidth = view.getWidth();
    final int viewHeight = view.getHeight();
    return getBitmapRectCenterInsideHelper(bitmapWidth, bitmapHeight, viewWidth, viewHeight);
  }

  public static Rect getBitmapRectCenterInside(final int bitmapWidth, final int bitmapHeight, final int viewWidth, final int viewHeight) {
    return getBitmapRectCenterInsideHelper(bitmapWidth, bitmapHeight, viewWidth, viewHeight);
  }

  private static Rect getBitmapRectCenterInsideHelper(final int bitmapWidth, final int bitmapHeight, final int viewWidth, final int viewHeight) {
    double viewToBitmapWidthRatio = Double.POSITIVE_INFINITY;
    double viewToBitmapHeightRatio = Double.POSITIVE_INFINITY;
    if (viewWidth < bitmapWidth) {
      viewToBitmapWidthRatio = viewWidth / bitmapWidth;
    }
    if (viewHeight < bitmapHeight) {
      viewToBitmapHeightRatio = viewHeight / bitmapHeight;
    }
    double resultWidth;
    double resultHeight;
    if (viewToBitmapWidthRatio != Double.POSITIVE_INFINITY || viewToBitmapHeightRatio != Double.POSITIVE_INFINITY) {
      if (viewToBitmapWidthRatio <= viewToBitmapHeightRatio) {
        resultWidth = viewWidth;
        resultHeight = bitmapHeight * resultWidth / bitmapWidth;
      }
      else {
        resultHeight = viewHeight;
        resultWidth = bitmapWidth * resultHeight / bitmapHeight;
      }
    }
    else {
      resultHeight = bitmapHeight;
      resultWidth = bitmapWidth;
    }
    int resultX;
    int resultY;
    if (resultWidth == viewWidth) {
      resultX = 0;
      resultY = (int)Math.round((viewHeight - resultHeight) / 2.0);
    }
    else if (resultHeight == viewHeight) {
      resultX = (int)Math.round((viewWidth - resultWidth) / 2.0);
      resultY = 0;
    }
    else {
      resultX = (int)Math.round((viewWidth - resultWidth) / 2.0);
      resultY = (int)Math.round((viewHeight - resultHeight) / 2.0);
    }
    final Rect result = new Rect(resultX, resultY, resultX + (int)Math.ceil(resultWidth), resultY + (int)Math.ceil(resultHeight));
    return result;
  }
}
