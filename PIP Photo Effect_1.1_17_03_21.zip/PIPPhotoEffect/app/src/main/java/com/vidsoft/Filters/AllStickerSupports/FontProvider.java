package com.vidsoft.Filters.AllStickerSupports;

import android.content.res.Resources;
import android.graphics.Typeface;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FontProvider {
    private static final String DEFAULT_FONT_NAME = "Helvetica";
    private final Map<String, String> fontNameToTypefaceFile;
    private final List<String> fontNames;
    private final Resources resources;
    private final Map<String, Typeface> typefaces;

    public FontProvider(Resources resources) {
        this.resources = resources;
        this.typefaces = new HashMap();
        this.fontNameToTypefaceFile = new HashMap();
        this.fontNameToTypefaceFile.put("Text1", "Akadora.ttf");
        this.fontNameToTypefaceFile.put("Text2", "Arial.ttf");
        this.fontNameToTypefaceFile.put("Text3", "Atelas.ttf");
        this.fontNameToTypefaceFile.put("Text4", "Black.ttf");
        this.fontNameToTypefaceFile.put("Text5", "Blkchry.ttf");
        this.fontNameToTypefaceFile.put("Text7", "Greenpil.ttf");
        this.fontNameToTypefaceFile.put("Text8", "Grinched.ttf");
        this.fontNameToTypefaceFile.put("Text10", "Libertango.ttf");
        this.fontNameToTypefaceFile.put("Text11", "MetalMacabre.ttf");
        this.fontNameToTypefaceFile.put("Text12", "ParryHotter.ttf");
        this.fontNameToTypefaceFile.put("Text13", "Strato.ttf");
        this.fontNameToTypefaceFile.put("Text15", "Waltograph.ttf");
        this.fontNameToTypefaceFile.put("Text16", "Calligraffitti-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text18", "Damion-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text19", "GrandHotel-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text20", "GreatVibes-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text22", "IndieFlower.ttf");
        this.fontNameToTypefaceFile.put("Text23", "LeckerliOne-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text24", "LilyScriptOne-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text25", "Lobster-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text26", "MarckScript-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text30", "Niconne-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text31", "OleoScript-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text32", "Pacifico-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text34", "PinyonScript-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text35", "Playball-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text36", "Rochester-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text37", "Sacramento-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text38", "Satisfy-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text39", "ShadowsIntoLight.ttf");
        this.fontNameToTypefaceFile.put("Text40", "SueEllenFrancisco.ttf");
        this.fontNameToTypefaceFile.put("Text41", "Yellowtail-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text42", "Yesteryear-Regular.ttf");
        this.fontNameToTypefaceFile.put("Text43", "Beatles.ttf");
        this.fontNameToTypefaceFile.put("Text44", "SofiaProLight.otf");
        this.fontNames = new ArrayList(this.fontNameToTypefaceFile.keySet());
    }

    public Typeface getTypeface(String typefaceName) {
        if (TextUtils.isEmpty(typefaceName)) {
            return Typeface.DEFAULT;
        }
        if (this.typefaces.get(typefaceName) == null) {
            this.typefaces.put(typefaceName, Typeface.createFromAsset(this.resources.getAssets(), "fonts/" + ((String) this.fontNameToTypefaceFile.get(typefaceName))));
        }
        return (Typeface) this.typefaces.get(typefaceName);
    }

    public List<String> getFontNames() {
        return this.fontNames;
    }

    public String getDefaultFontName() {
        return DEFAULT_FONT_NAME;
    }
}
