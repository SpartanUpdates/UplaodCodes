package com.kotlinz.festivalstorymaker.esafirm.imagepicker.features;

import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.common.MvpView;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Folder;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import java.util.List;

public interface ImagePickerView extends MvpView {
    void showLoading(boolean isLoading);
    void showFetchCompleted(List<Image> images, List<Folder> folders);
    void showError(Throwable throwable);
    void showEmpty();
    void showCapturedImage();
    void finishPickImages(List<Image> images);
}
