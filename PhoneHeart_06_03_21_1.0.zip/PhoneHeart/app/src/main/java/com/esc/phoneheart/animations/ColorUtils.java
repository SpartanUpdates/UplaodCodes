package com.esc.phoneheart.animations;

import android.graphics.Color;

import androidx.annotation.ColorInt;

public class ColorUtils {
    public static int getRGBGradient(@ColorInt int i, @ColorInt int i2, float f) {
        int[] iArr = new int[]{interpolate((float) Color.red(i), (float) Color.red(i2), f), interpolate((float) Color.green(i), (float) Color.green(i2), f), interpolate((float) Color.blue(i), (float) Color.blue(i2), f)};
        return Color.argb(255, iArr[0], iArr[1], iArr[2]);
    }

    public static int interpolate(float f, float f2, float f3) {
        return Math.round((f * f3) + (f2 * (1.0f - f3)));
    }
}
