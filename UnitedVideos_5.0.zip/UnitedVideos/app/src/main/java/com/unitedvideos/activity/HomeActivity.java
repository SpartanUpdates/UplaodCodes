package com.unitedvideos.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.root.unity.AppUsages;
import com.unitedvideos.Fragment.ThemeFragmentByCategory;
import com.unitedvideos.Model.CategoryModel;
import com.unitedvideos.R;
import com.unitedvideos.Retrofit.APIClient;
import com.unitedvideos.Retrofit.APIInterface;
import com.unitedvideos.Retrofit.AppConstant;
import com.unitedvideos.UnityPlayerActivity;
import com.unitedvideos.Utils.Utils;
import com.unitedvideos.application.MyApplication;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Date;
import static com.unitedvideos.NativeAds.NativeAdvanceAds.populateUnifiedNativeAdView;


public class HomeActivity extends AppCompatActivity {
    Activity activity = HomeActivity.this;
//    private final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
//    private final int REQUEST_PERMISSION_SETTING = 101;
    ArrayList<CategoryModel> tabcategorylist = new ArrayList<>();
    ViewPagerAdapter adp;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    APIInterface apiInterface;
    //    TextView tvMycreation;
    ImageView ivMoreApp;
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    Button btnRetry;
    Toolbar toolbar;
    TextView tvtitle;
    int SelectedPosition = 0;
    SharedPreferences pref;
    private SharedPreferences ePreferences;

    AdRequest adRequest;
    AdView adView;

    String Version;
    PackageInfo info = null;
    FrameLayout fldrawermain;
    ImageView ivSetting;

    boolean isSetupReady = false;
    public static boolean isApiRunning = false;

    TextView tv_prg_msg;
    LinearLayout llRateHome, llHomeMain, llShareHome;
    public int id;
    InterstitialAd mInterstitialAd;
    private UnifiedNativeAd nativeAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        ePreferences = getSharedPreferences("pref_key_rate", MODE_PRIVATE);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView();
        MyApplication.isEditCall = false;
        if (Utils.checkConnectivity(activity, false)) {
            if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                if (!isApiRunning) {
                    isApiRunning = true;
                    GetCategory();
                }
            } else if (((new Date().getTime() - pref.getLong("offlineResponseTime", 1588598205L)) >= 300000L)) {
                Log.e("TAG", "5 Min Complate");
                if (!isApiRunning) {
                    isApiRunning = true;
                    GetCategory();
                }
            }
        } else if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            Log.e("HomeActivity", "No Internet");
        }
        GetAppVersion();
        BannerAds();
//        CallInterstitialAd();
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HomeActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        SetListener();
        SetThemeData();
    }

    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void GetAppVersion() {
        PackageManager manager = activity.getPackageManager();
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            Version = info.versionName;
        }
    }

    private void BindView() {
        toolbar = findViewById(R.id.toolbar);
        fldrawermain = findViewById(R.id.fl_drawer_main);
        ivSetting = findViewById(R.id.ivNavDrawer);
        tvtitle = findViewById(R.id.tv_app_name);
        rlLoading = findViewById(R.id.rl_loading);
        tabLayout = findViewById(R.id.mTabLayout);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        tv_prg_msg = findViewById(R.id.tv_prg_msg);
        tv_prg_msg.setText("Please wait…");
        ivMoreApp = findViewById(R.id.iv_more_app);
        llRateHome = findViewById(R.id.ll_rate);
        llHomeMain = findViewById(R.id.ll_home_main);
        llShareHome = findViewById(R.id.ll_share);
        ivSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoToSetting();
            }
        });
        ivMoreApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity,GetFreeAppActivity.class));
                finish();
            }
        });
        llRateHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RateApp();
            }
        });
        llHomeMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoToMyCreation();
            }
        });
        llShareHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShareAPP();
            }
        });
    }


    private void BannerAds() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    private void CallInterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 101:
                        GoToExit();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }


    public void GoToSetting() {
        startActivity(new Intent(activity, SettingActivity.class));
        finish();
    }

    private void GoToMyCreation() {
        startActivity(new Intent(activity, MyVideoActivity.class));
        finish();
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

   /* public void RequestPermission(boolean z) {
        if ((ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            Utils.CreateDirectory();
            AppUsages.loadFFMpeg(activity);
            SetThemeData();
        } else if (z) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle("Necessary permission");
            builder.setMessage("Allow Required Permission");
            builder.setCancelable(false);
            builder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    PremissionFromSetting(HomeActivity.this);
                }
            });
            builder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
//                    UnityPlayerActivity.mUnityPlayer.quit();
                    finish();
                }
            });
            builder.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
                AppUsages.loadFFMpeg(activity);
                SetThemeData();
            } else {
                RequestPermission(true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    Utils.CreateDirectory();
                    AppUsages.loadFFMpeg(activity);
                    SetThemeData();
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    this.B = true;
                    RequestPermission(true);
                }
            }
        }
    }

    public void PremissionFromSetting(HomeActivity homeActivity) {
        homeActivity.D = true;
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", homeActivity.getPackageName(), null);
        intent.setData(uri);
        homeActivity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }
*/
    private void SetThemeData() {
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            isSetupReady = true;
        } else {
            Log.e("TAG", "OfflineRes" + pref.getString("offlineResponse", ""));
            SetupDataInLayout(pref.getString("offlineResponse", ""));
        }
    }

    private void SetOfflineCategory(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineResponseTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }


    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
        }

        ((TextView) tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.app_gradiant_end));
        LinearLayout linearLayout = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.ll_tab_home);
        linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));

        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_home);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.app_gradiant_end));
                SelectedPosition = tab.getPosition();
                MyApplication.ThemePosition = 0;
                MyApplication.CatSelectedPosition = SelectedPosition;
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_home);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.round_background));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.app_gradiant_end));
                    LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_home);
                    linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));
                }
            }
        });
    }

    private void setUpPagerNew() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        int i;
//        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        if (MyApplication.CatSelectedPosition != -1) {
            i = MyApplication.CatSelectedPosition;
        } else {
            i = 0;
        }
        viewPager.setCurrentItem(i);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void GetCategory() {
        final Handler handler = new Handler();
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            Log.e("HomeActivity", "Handler Running");
            handler.postDelayed(new Runnable() {
                public void run() {
                    Log.e("HomeActivity", "Your Internet Connection Too Slow");
                    tv_prg_msg.setText("Slow Internet Connection");
//                    Toast.makeText(activity, "Your Internet Connection Too Slow", Toast.LENGTH_SHORT).show();
                }
            }, 10000);
        }
        llRetry.setVisibility(View.GONE);
        rlLoading.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId, "1", "1");
        MyApplication.Tempcall = call;
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        if (handler != null) {
                            Log.e("HomeActivity", "removeCallbacksAndMessages");
                            handler.removeCallbacksAndMessages(null);
                        }

                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineCategory(activity, jsonObj.toString(), "offlineResponse");
                        Log.e("HomeActivity", "" + response.body());
                        //Set Response Time
                        SetOfflineResponseTime(activity, new Date(), "offlineResponseTime");
                        isApiRunning = false;
                        if (isSetupReady) {
                            isSetupReady = false;
                            SetupDataInLayout(jsonObj.toString());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("HomeActivity", "Response Failed");
                isApiRunning = false;
                rlLoading.setVisibility(View.GONE);
                if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetupDataInLayout(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray tabcategory = jsonObj.getJSONArray("category");
            for (int i = 0; i < tabcategory.length(); i++) {
                JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                String CategoryId = tabcategoryJSONObject.getString("id");
                SetOfflineCategory(activity, tabcategoryJSONObject.toString(), CategoryId);
                CategoryModel categoryModel = new CategoryModel();
                categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                tabcategorylist.add(categoryModel);

            }
            setUpPagerNew();
            SetTabLayout();
            rlLoading.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return ThemeFragmentByCategory.newInstance(Integer.parseInt(tabcategorylist.get(position).getCategoryId()));
        }


        @Override
        public int getCount() {
            return tabcategorylist.size();
        }


        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tv_cat_Name);
            tv.setText(tabcategorylist.get(position).getName());
            return tabCatView;
        }
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Beats");
            String shareMessage = "\nGet free Beats at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(activity);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
                java.lang.System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    final SharedPreferences.Editor edit = ePreferences.edit();
                    edit.putBoolean("pref_key_rate", true);
                    edit.apply();
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                    java.lang.System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                java.lang.System.exit(0);

            }
        });
        dialog.show();
    }


    public void onBackPressed() {
//        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
//            id = 101;
//            mInterstitialAd.show();
//        } else {
//            GoToExit();
//        }
        GoToExit();
    }

    private void GoToExit() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }
}
