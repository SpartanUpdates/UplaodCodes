package com.esc.phoneheart.utility;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import com.bumptech.glide.load.ResourceDecoder;
import com.bumptech.glide.load.engine.Resource;
import com.bumptech.glide.load.resource.drawable.DrawableResource;
import com.bumptech.glide.util.Util;

import java.io.IOException;

public class ApplicationIconDecoder implements ResourceDecoder<ApplicationInfo, Drawable> {
    public final Context context;

    public ApplicationIconDecoder(Context context) {
        this.context = context;
    }

    public String getId() {
        return "ApplicationInfoToDrawable";
    }

    public Resource<Drawable> decode(ApplicationInfo applicationInfo, int i, int i2) throws IOException {
        return new DrawableResource<Drawable>(context.getPackageManager().getApplicationIcon(applicationInfo)) {
            public int getSize() {
                Drawable drawable = this.drawable;
                if (drawable instanceof BitmapDrawable) {
                    return Util.getBitmapByteSize(((BitmapDrawable) drawable).getBitmap());
                }
                return 1;
            }

            public void recycle() {
            }
        };
    }
}
