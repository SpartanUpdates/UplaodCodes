package com.esc.mynameringtonemaker.Model;

import java.io.Serializable;

public class RingtoneModel implements Serializable {
    String mp3Url;
    String name;

    public RingtoneModel(String str, String str2) {
        this.name = str;
        this.mp3Url = str2;
    }

    public RingtoneModel() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getMp3Url() {
        return this.mp3Url;
    }

    public void setMp3Url(String str) {
        this.mp3Url = str;
    }
}
