package com.jenilcreation.photomusicvideo;

import android.graphics.Typeface;

public interface OnStickerSelected {
    void onStickerTouch(int i);

    void onTextStyleChange(Typeface typeface);
}
