package com.example.womenabsworkout;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

import com.example.womenabsworkout.receiver.NotificationReceiver;

import java.util.Calendar;


public class DailyBrodcast extends BroadcastReceiver {
    public Context context;

    public void onReceive(Context context, Intent intent) {
        this.context = context;
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED") || intent.getAction().equals("android.intent.action.QUICKBOOT_POWERON")) {
            setAlarm();
        }
    }

    @SuppressLint("WrongConstant")
    public void setAlarm() {
        Calendar instance = Calendar.getInstance();
        instance.set(11, 7);
        instance.set(12, 30);
        instance.set(13, 0);
        ((AlarmManager) this.context.getSystemService(NotificationCompat.CATEGORY_ALARM)).setRepeating(AlarmManager.RTC_WAKEUP, instance.getTimeInMillis(), 86400000, PendingIntent.getBroadcast(this.context, 100, new Intent(this.context, NotificationReceiver.class), PendingIntent.FLAG_CANCEL_CURRENT));
    }
}
