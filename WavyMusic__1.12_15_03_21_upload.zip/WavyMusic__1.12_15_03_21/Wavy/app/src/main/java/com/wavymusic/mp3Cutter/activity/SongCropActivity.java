package com.wavymusic.mp3Cutter.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.mp3Cutter.Adapter.SongCropAdapter;
import com.wavymusic.mp3Cutter.Dialog.SetRingtoneDialog;
import com.wavymusic.mp3Cutter.Fragment.SongCropFragment;
import com.wavymusic.mp3Cutter.Model.PhoneSong;
import com.wavymusic.mp3Cutter.Model.PhoneSongAllFolders;
import com.wavymusic.mp3Cutter.Model.SongCropModel;
import com.wavymusic.mp3Cutter.mycreation.activity.SongCropMycreationActivity;
import com.wavymusic.mp3Cutter.Services.SongMediaPlayer;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.wavymusic.application.MyApplication;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

public class SongCropActivity extends AppCompatActivity {

    Activity activity = SongCropActivity.this;
    public static int k = -1;
    public static boolean l = false;
    public static int m = -1;
    public static int n = -1;
    public Context context = this;
    String[] command;
    String CorpSongPath;
    private ViewPager viewPager;
    PagerAdapter pagerAdapter;
    private RelativeLayout rlPreogress;
    private TextView tvNoMusicFound;
    private TabLayout tabLayout;
    public SimpleDateFormat simpleDateFormat;
    private Handler O = new Handler();

    private boolean Q = true;
    public SongMediaPlayer service;
    public boolean r = true;
    public long s;
    Thread thread;
    Dialog dialog;
    TextView tvProgressMsg;
    ImageView ivback;
    private String output;
    private long timeout;

    private AdView adView;

    public static List<SongCropModel> localTrackList = new ArrayList<>();
    public static PhoneSongAllFolders PhoneSongFolders;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        setUiVisibility();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_list);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SongCropActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        this.timeout = Long.MAX_VALUE;
        k = 0;
        n = -1;
        m = -1;
        simpleDateFormat = new SimpleDateFormat("mm:ss", Locale.ENGLISH);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        ivback = findViewById(R.id.ivBack);
        rlPreogress = findViewById(R.id.rl_load_sound_activity);
        tvNoMusicFound = findViewById(R.id.tv_no_music_found);
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.viewpager);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        LocalSongsFeatch();
        if (PhoneSongFolders == null) {
            PhoneSongFolders = new PhoneSongAllFolders();
        }
        if (PhoneSongFolders.getMusicFolders().size() > 0) {
            setUpPagerNew();
            SetTabLayout();
        } else {
            tvNoMusicFound.setVisibility(View.VISIBLE);
        }
        LoadMyCreation();
        findViewById(R.id.imgMyCreation).setOnClickListener(new View.OnClickListener() {
            /* class com.example.videostatus.mp3cutter.activity.AudioListActivity.AnonymousClass2 */

            public void onClick(View view) {
                Intent intent = new Intent(SongCropActivity.this, SongCropMycreationActivity.class);
                intent.putExtra("FolderName", Utils.f5846d);
                intent.putExtra("PageTitle", "Audio Cut");
                SongCropActivity.this.startActivity(intent);
            }
        });
        BannerAds();
    }

    private void BannerAds() {
        adView = new AdView(this, getResources().getString(R.string.fb_banner), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
        adContainer.addView(adView);
        adView.loadAd();
    }

    public class b extends AsyncTask<Void, Void, Void> {

        String[] f5920a;

        String f5921b;

        b(String[] strArr, String str) {
            this.f5920a = strArr;
            this.f5921b = str;
        }

        public Void doInBackground(Void... r8) {

            return null;
        }

        public void onPostExecute(Void voidR) {
            super.onPostExecute(voidR);
            try {
                if (SongCropActivity.this.dialog != null && SongCropActivity.this.dialog.isShowing()) {
                    SongCropActivity.this.dialog.dismiss();
                }
                MediaScannerConnection.scanFile(SongCropActivity.this, new String[]{this.f5921b}, null, new MediaScannerConnection.OnScanCompletedListener() {

                    public void onScanCompleted(String str, Uri uri) {
                        Log.e("ExternalStorage", "Scanned " + str + ":");
                        StringBuilder sb = new StringBuilder();
                        sb.append("-> uri=");
                        sb.append(uri);
                        Log.e("ExternalStorage", sb.toString());
                    }
                });
                Log.e("TagPath", "Crop Song ->" + this.f5921b);
                if (new File(this.f5921b).exists()) {
                    SetRingtoneDialog.a(this.f5921b, BuildConfig.FLAVOR).show(SongCropActivity.this.getSupportFragmentManager(), SetRingtoneDialog.Tag);
                } else {
                    Toast.makeText(SongCropActivity.this.context, "File not supported!", Toast.LENGTH_SHORT).show();
                }
                SongCropActivity.this.u();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        public void onPreExecute() {
            Log.e("FROMSDDDD", "PRE");
            super.onPreExecute();
            try {
                SongCropActivity.this.dialog = new Dialog(SongCropActivity.this, R.style.DialogTheme);
                SongCropActivity.this.dialog.setContentView(R.layout.auto_crop_dialog);
                SongCropActivity.this.dialog.setCancelable(false);
                SongCropActivity.this.tvProgressMsg = SongCropActivity.this.dialog.findViewById(R.id.tv_progress_msg);
                SongCropActivity.this.tvProgressMsg.setText(SongCropActivity.this.getString(R.string.please_wait));
                if (SongCropActivity.this.dialog != null && !SongCropActivity.this.dialog.isShowing()) {
                    SongCropActivity.this.dialog.show();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }


    @SuppressLint({"StaticFieldLeak"})
    public class d extends AsyncTask<Void, Void, Void> {
        public d() {

        }


        public Void doInBackground(Void... r8) {
           /* try {
                process = Runtime.getRuntime().exec(command);
                if (process != null) {
                    try {
                        checkAndUpdateProcess();
                    } catch (TimeoutException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }*/
            return null;
        }


        public void onPostExecute(Void voidR) {
            super.onPostExecute(voidR);
            try {
                if (SongCropActivity.this.dialog != null && SongCropActivity.this.dialog.isShowing()) {
                    SongCropActivity.this.dialog.dismiss();
                }
                MediaScannerConnection.scanFile(SongCropActivity.this, new String[]{SongCropActivity.this.CorpSongPath}, null, new MediaScannerConnection.OnScanCompletedListener() {

                    public void onScanCompleted(String str, Uri uri) {
                        Log.e("ExternalStorage", "Scanned " + str + ":");
                        StringBuilder sb = new StringBuilder();
                        sb.append("-> uri=");
                        sb.append(uri);
                        Log.e("ExternalStorage", sb.toString());
                    }
                });
                Log.e("TagPath", "Crop Song ->" + SongCropActivity.this.CorpSongPath);
                if (!new File(SongCropActivity.this.CorpSongPath).exists() || new File(SongCropActivity.this.CorpSongPath).length() <= 0) {
                    Toast.makeText(SongCropActivity.this.context, "File not supported!", Toast.LENGTH_SHORT).show();
                } else {
                    SetRingtoneDialog.a(SongCropActivity.this.CorpSongPath, BuildConfig.FLAVOR).show(SongCropActivity.this.getSupportFragmentManager(), SetRingtoneDialog.Tag);
                }
                SongCropActivity.this.u();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }


        public void onPreExecute() {
            Log.e("FROMSDDDD", "PRE");
            super.onPreExecute();
            try {
                SongCropActivity.this.dialog = new Dialog(SongCropActivity.this, R.style.DialogTheme);
                SongCropActivity.this.dialog.setContentView(R.layout.auto_crop_dialog);
                SongCropActivity.this.dialog.setCancelable(false);
                SongCropActivity.this.tvProgressMsg = SongCropActivity.this.dialog.findViewById(R.id.tv_progress_msg);
                SongCropActivity.this.tvProgressMsg.setText(SongCropActivity.this.getString(R.string.please_wait));
                if (SongCropActivity.this.dialog != null && !SongCropActivity.this.dialog.isShowing()) {
                    SongCropActivity.this.dialog.show();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void checkAndUpdateProcess() throws TimeoutException {
       /* while (!Util.isProcessCompleted(this.process)) {
            if (Util.isProcessCompleted(this.process)) {
                return;
            }
            if (timeout != Long.MAX_VALUE && System.currentTimeMillis() > System.currentTimeMillis() + timeout) {
                throw new TimeoutException("FFmpeg timed out");
            }
            try {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(this.process.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    output = this.output + line + "\n";
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/
    }

    private void LocalSongsFeatch() {
        rlPreogress.setVisibility(View.VISIBLE);
        localTrackList.clear();
        PhoneSongFolders = new PhoneSongAllFolders();
        PhoneSongFolders.getMusicFolders().clear();
        SongCropModel lt;
        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");

        if (musicCursor != null && musicCursor.moveToFirst()) {
            int titleColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ARTIST);
            int albumColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.ALBUM);
            int pathColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.DATA);
            int durationColumn = musicCursor.getColumnIndex
                    (MediaStore.Audio.Media.DURATION);

            do {
                int thisId = musicCursor.getInt(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String thisAlbum = musicCursor.getString(albumColumn);
                String path = musicCursor.getString(pathColumn);
                long duration = musicCursor.getLong(durationColumn);
                String string4 = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), musicCursor.getLong(musicCursor.getColumnIndex("album_id"))).toString();
                lt = this.a(thisId, thisTitle, thisArtist, path, duration, string4);

                localTrackList.add(lt);
                File f = new File(path);
                String dirName = f.getParentFile().getName();
                if (getFolder(dirName) == null) {
                    PhoneSong mf = new PhoneSong(dirName);
                    mf.getLocalTracks().add(lt);
                    PhoneSongFolders.getMusicFolders().add(mf);
                } else {
                    getFolder(dirName).getLocalTracks().add(lt);
                    getFileName(String.valueOf(f));
                }
            }
            while (musicCursor.moveToNext());
        }

        if (musicCursor != null) {
            musicCursor.close();
        }
    }

    public PhoneSong getFolder(String folderName) {
        PhoneSong mf = null;
        for (int i = 0; i < PhoneSongFolders.getMusicFolders().size(); i++) {
            PhoneSong mf1 = PhoneSongFolders.getMusicFolders().get(i);
            if (mf1.getFolderName().equals(folderName)) {
                mf = mf1;
                break;
            }
        }
        return mf;
    }

    private class PagerAdapter extends FragmentPagerAdapter {

        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(R.layout.row_phone_song_cat, null);
            TextView tv = tab.findViewById(R.id.folder_name);
            tv.setText(PhoneSongFolders.getMusicFolders().get(position).getFolderName());
            return tab;
        }
    }

    private int getFileName(String str) {
        File parentFile = new File(str).getParentFile();
        return a(parentFile.getAbsolutePath(), parentFile.getName());
    }

    public static int a(String string, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(File.separator);
        sb.append(s);
        string = sb.toString();
        try {
            final byte[] digest = MessageDigest.getInstance("MD5").digest(string.getBytes(StandardCharsets.UTF_8));
            final StringBuilder sb2 = new StringBuilder(digest.length * 2);
            for (int length = digest.length, i = 0; i < length; ++i) {
                final int n = digest[i] & 0xFF;
                if (n < 16) {
                    sb2.append("0");
                }
                sb2.append(Integer.toHexString(n));
            }
            return sb2.toString().hashCode();
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException("NoSuchAlgorithmException", ex);
        }
    }

    private SongCropModel a(int i, String str, String str2, String str3, long j, String str4) {
        SongCropModel aVar = new SongCropModel();
        aVar.a(i);
        aVar.b(str);
        aVar.c(str2);
        aVar.a(str3);
        aVar.a(j);
        aVar.d(str4);
        aVar.b(false);
        return aVar;
    }


    private void a(final SongCropModel aVar) {
        this.O.post(new Runnable() {

            public void run() {
                SongCropActivity.this.service.a(aVar.e());
                SongCropActivity.this.service.b();
                boolean z = SongCropActivity.l;
                SongCropActivity.this.v();
            }
        });
    }

    private void SongCrop(String str, long j, long j2) {
        String str2 = this.CorpSongPath;
        this.command = new String[]{Utils.b(this), "-y", "-i", str, "-ss", getTimeDuration(j), "-t", getTimeDuration(j2 - j), "-f", "mp3", "-ab", "320000", "-vn", str2};
        new b(this.command, str2).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    private void LoadMyCreation() {
        String[] strArr = {"_id", "title", "artist", "_data", "duration", "_size", "is_music", "album_id"};
        try {
            ContentResolver contentResolver = getContentResolver();
            Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            Cursor query = contentResolver.query(uri, strArr, "_data like '%" + MyApplication.f.getAbsolutePath() + File.separator + Utils.f5846d + "%'", null, null);
            if (query != null) {
                if (query.getCount() == 0) {
                    query.close();
                    findViewById(R.id.imgMyCreation).setVisibility(View.GONE);
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @SuppressLint("DefaultLocale")
    public String getTimeDuration(long j) {
        return String.format("%02d:%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toHours(j)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j))));
    }

    public void a(Context context, TextView textView) {
        textView.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/OpenSans_Regular.ttf"));
    }

    public void a(SongCropModel aVar, int i) {
        Log.e("TAG","called");
        n = i;
        k = aVar.c();
        this.s = 0L;
        a(aVar);
        this.service.f();
    }

    public void a(final SongCropAdapter.MyViewHolder bVar) {
        this.r = true;
        thread = new Thread(new Runnable() {
            public void run() {
                while (SongCropActivity.this.r) {
                    bVar.playMusicControllerView.setPlayProgress(SongCropActivity.this.service.c());
                    Log.e("StartTime", SongCropActivity.this.simpleDateFormat.format(bVar.z));
                    if (((long) SongCropActivity.this.service.c()) >= bVar.A) {
                        Log.e("TAG", "start : " + bVar.z);
                        SongCropActivity.this.service.a(bVar.z);
                    }
                    SongCropActivity.this.runOnUiThread(new Runnable() {

                        @SuppressLint({"SetTextI18n"})
                        public void run() {
                            TextView textView = bVar.tvplaytime;
                            textView.setText(SongCropActivity.this.simpleDateFormat.format(SongCropActivity.this.service.c()) + " - ");
                        }
                    });
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }


    public void a(String str, String str2, long j, long j2) {
        String substring = str.substring(str.lastIndexOf("."));
        this.CorpSongPath = Environment.getExternalStorageDirectory() + File.separator + MyApplication.f4905e + File.separator + Utils.f5846d + File.separator + System.currentTimeMillis() + ".mp3";
        if (substring.equalsIgnoreCase(".mp3")) {
            this.command = new String[]{Utils.b(this), "-i", str, "-ss", getTimeDuration(j), "-t", getTimeDuration(j2 - j), "-acodec", "copy", "-y", this.CorpSongPath};
            File file = new File(Environment.getExternalStorageDirectory() + File.separator + MyApplication.f4905e + File.separator + Utils.f5846d);
            if (!file.exists()) {
                file.mkdirs();
            }
            new d().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            SongCrop(str, j, j2);
        }
        Log.e("Tag", "FFMPEG=>" + Utils.b(this));
        Log.e("tag", "Path : " + this.CorpSongPath);
    }


    public void setUiVisibility() {
        try {
            if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
                getWindow().getDecorView().setSystemUiVisibility(8);
            } else if (Build.VERSION.SDK_INT >= 19) {
                getWindow().getDecorView().setSystemUiVisibility(4096);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (Build.VERSION.SDK_INT >= 23 && i == 111 && Settings.System.canWrite(this)) {
            MyApplication.a(MyApplication.aF, this);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(pagerAdapter.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setUpPagerNew() {
        viewPager.setOffscreenPageLimit(1);
        pagerAdapter = new PagerAdapter(getSupportFragmentManager());
        for (int i = 0; i < PhoneSongFolders.getMusicFolders().size(); i++) {
            pagerAdapter.addFrag(SongCropFragment.getInstance(i, i, SongCropActivity.this), "");
        }
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        rlPreogress.setVisibility(View.GONE);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("Ondestroy", "destroy");
        this.r = false;
        l = false;
        SongMediaPlayer aVar = this.service;
        if (aVar != null) {
            aVar.g();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LayoutDataChnage();
        n = -1;
        m = -1;
        setUiVisibility();
        LoadMyCreation();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (this.Q) {
            this.service = new SongMediaPlayer(this);
            this.Q = false;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (this.service.e()) {
            u();
        }
    }


    public boolean isSongPlay() {
        if (this.service.e()) {
            return true;
        }
        this.service.e();
        return false;
    }

    public void t() {
        if (this.service.e()) {
            u();
        } else {
            v();
        }
    }

    public void u() {
        this.service.d();
        this.s = this.service.c();
    }

    public void v() {
        this.service.f();
        this.service.a(this.s);
    }

    public void LayoutDataChnage() {
        if (SongCropActivity.m != -1) {
            final FragmentManager fragmentManager = this.getSupportFragmentManager();
            final StringBuilder sb = new StringBuilder();
            sb.append("android:switcher:2131231733:");
            sb.append(SongCropActivity.m);
            final Fragment fragment = fragmentManager.findFragmentByTag(sb.toString());

            if (fragment != null) {
                final SongCropFragment a2 = (SongCropFragment) fragment;
                if (a2.rvSongCrop.getLayoutManager() == null) {
                    return;
                }
                if (SongCropActivity.n != -1 && a2.rvSongCrop != null) {
                    final View childAt = a2.rvSongCrop.getChildAt(SongCropActivity.n - ((LinearLayoutManager) a2.rvSongCrop.getLayoutManager()).findFirstCompletelyVisibleItemPosition());
                    if (childAt != null) {
                        try {
                            childAt.findViewById(R.id.image_content).setSelected(false);
                            ((ImageView) childAt.findViewById(R.id.ivPopularPlayPause)).setImageResource(R.drawable.icon_player_play);
                            ((ImageView) childAt.findViewById(R.id.image_content)).setImageResource(R.drawable.icon_ringtone_thumb);
                            childAt.findViewById(R.id.rl_cuttor_main).setVisibility(View.GONE);
                            childAt.findViewById(R.id.tvUseMusic).setBackground(getResources().getDrawable(R.drawable.btn_gradiant_use_normal));
                            childAt.findViewById(R.id.tvUseMusic).setSelected(false);
                            childAt.findViewById(R.id.indicator).setVisibility(View.GONE);
                            childAt.findViewById(R.id.image_layout).setBackgroundColor(getResources().getColor(R.color.app_main_bg_color));
                            ((TextView) childAt.findViewById(R.id.tvUseMusic)).setText("Cut");
                        } catch (Resources.NotFoundException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
