package com.esc.howtomakeschoolsupplies.fragment;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.esc.howtomakeschoolsupplies.activity.Constants;
import com.esc.howtomakeschoolsupplies.activity.ContentFragmentOnCreateView1;
import com.esc.howtomakeschoolsupplies.activity.ContentFragmentOnCreateView2;
import com.esc.howtomakeschoolsupplies.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.like.LikeButton;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import androidx.fragment.app.FragmentTransaction;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import com.esc.howtomakeschoolsupplies.data.LikesContract;
import com.esc.howtomakeschoolsupplies.data.LikesContract.DBEntry;
import com.esc.howtomakeschoolsupplies.data.LikesDbHelper;

public class ContentFragment extends Fragment {
    public static final Companion Companion = new Companion();
    private static final String KEY_CONTENT_ARTICLE = "content_article";
    private HashMap findViewCache;
    public boolean isLike;
    public LikesDbHelper mLikesDbHelper;
    public List<Integer> mListDBFavorite = new ArrayList();
    public List<Integer> mListDBLikes = new ArrayList();
    private SharedPreferences pref;
    private MediaPlayer mplike;
    private MediaPlayer mpclick;
    private MediaPlayer mpfavorite;
    private View inflate;
    private int numberArticle;
    private ImageButton btnLike;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public static final class Companion {
        private Companion() {
        }

        public final ContentFragment newInstance(int i) {
            Bundle bundle = new Bundle();
            bundle.putInt(ContentFragment.KEY_CONTENT_ARTICLE, i);
            ContentFragment contentFragment = new ContentFragment();
            contentFragment.setArguments(bundle);
            return contentFragment;
        }
    }

    public void clearFindViewByIdCache() {
        HashMap hashMap = this.findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View findCachedViewById(int i) {
        if (this.findViewCache == null) {
            this.findViewCache = new HashMap();
        }
        View view = (View) this.findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            view = getView();
            if (view == null) {
                return null;
            }
            view = view.findViewById(i);
            this.findViewCache.put(Integer.valueOf(i), view);
        }
        return view;
    }

    public void onDestroyView() {
        super.onDestroyView();
        clearFindViewByIdCache();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(layoutInflater, "inflater");
        inflate = layoutInflater.inflate(R.layout.activity_content, viewGroup, false);
        numberArticle = requireArguments().getInt(KEY_CONTENT_ARTICLE);
        Intrinsics.checkExpressionValueIsNotNull(inflate, "rootView");
        this.mLikesDbHelper = new LikesDbHelper(getActivity());
        btnLike = inflate.findViewById(R.id.btnLike);
        LikeButton likeButton = (LikeButton) inflate.findViewById(R.id.btnFavorite);
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(Constants.APP_PREFERENCES, 0);
        Intrinsics.checkExpressionValueIsNotNull(sharedPreferences, "requireActivity().getSha…ES, Context.MODE_PRIVATE)");
        this.pref = sharedPreferences;
        Context activity = getActivity();
        Resources resources = getResources();
        FragmentActivity requireActivity = requireActivity();
        String str2 = "requireActivity()";
        Intrinsics.checkExpressionValueIsNotNull(requireActivity, str2);
        String str3 = "raw";
        mpfavorite = MediaPlayer.create(activity, resources.getIdentifier("favorite", str3, requireActivity.getPackageName()));
        Context activity2 = getActivity();
        Resources resources2 = getResources();
        FragmentActivity requireActivity2 = requireActivity();
        Intrinsics.checkExpressionValueIsNotNull(requireActivity2, str2);
        mpclick = MediaPlayer.create(activity2, resources2.getIdentifier("click2", str3, requireActivity2.getPackageName()));
        Context activity3 = getActivity();
        Resources resources3 = getResources();
        FragmentActivity requireActivity3 = requireActivity();
        Intrinsics.checkExpressionValueIsNotNull(requireActivity3, str2);
        mplike = MediaPlayer.create(activity3, resources3.getIdentifier("like", str3, requireActivity3.getPackageName()));

        checkNewArticle(numberArticle);
        WebView webView = (WebView) inflate.findViewById(R.id.webview);
        StringBuilder append = new StringBuilder().append("http://167.172.217.101:8080/chancellery/read?id=").append(numberArticle).append("&lang=");
        Locale locale = Locale.getDefault();
        Intrinsics.checkExpressionValueIsNotNull(locale, "Locale.getDefault()");
        webView.loadUrl(append.append(locale.getLanguage()).toString());
        updateListsDB();
        this.isLike = checkLikeAndFavorite(this.mListDBLikes, numberArticle);

        Intrinsics.checkExpressionValueIsNotNull(likeButton, "rootView.btnFavorite");
        likeButton.setLiked(Boolean.valueOf(checkLikeAndFavorite(this.mListDBFavorite, numberArticle)));
        if (this.isLike) {
            btnLike.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_like_fill));
        } else {
            btnLike.setImageDrawable(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_like_unfill_white));
        }
        AnimationEffect();
        setClickListener();
        BannerAds();
        return inflate;
    }

    public void AnimationEffect() {
        Animation loadAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.content);
        Animation loadAnimation2 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon1);
        Animation loadAnimation3 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon2);
        Animation loadAnimation4 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon3);
        Animation loadAnimation5 = AnimationUtils.loadAnimation(getActivity(), R.anim.icon4);
        Animation loadAnimation6 = AnimationUtils.loadAnimation(getActivity(), R.anim.bar);
        ((WebView) inflate.findViewById(R.id.webview)).startAnimation(loadAnimation);
        ((ImageButton) inflate.findViewById(R.id.buttonBack)).startAnimation(loadAnimation2);
        ((ImageButton) inflate.findViewById(R.id.buttonHome)).startAnimation(loadAnimation3);
        ((ImageButton) inflate.findViewById(R.id.btnLike)).startAnimation(loadAnimation4);
        ((LikeButton) inflate.findViewById(R.id.btnFavorite)).startAnimation(loadAnimation5);
        ((LinearLayout) inflate.findViewById(R.id.navMenuVisible)).startAnimation(loadAnimation6);

        ((ImageButton) inflate.findViewById(R.id.btnLike)).setOnClickListener(new ContentFragmentOnCreateView1(this, mpclick, inflate, numberArticle, mplike));
        ((LikeButton) inflate.findViewById(R.id.btnFavorite)).setOnLikeListener(new ContentFragmentOnCreateView2(this, mpfavorite, numberArticle, mpclick));
    }

    public void setClickListener() {

        ((ImageButton) inflate.findViewById(R.id.buttonHome)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mpclick.start();
                FragmentActivity requireActivity = requireActivity();
                String str = "requireActivity()";
                Intrinsics.checkExpressionValueIsNotNull(requireActivity, str);
                requireActivity.getSupportFragmentManager().popBackStack(null, 1);
                requireActivity = requireActivity();
                Intrinsics.checkExpressionValueIsNotNull(requireActivity, str);
                FragmentTransaction beginTransaction = requireActivity.getSupportFragmentManager().beginTransaction();
                Intrinsics.checkExpressionValueIsNotNull(beginTransaction, "requireActivity().suppor…anager.beginTransaction()");
                beginTransaction.add(R.id.container, (Fragment) new BeginFragment());
                beginTransaction.addToBackStack(null);
                beginTransaction.commit();
            }
        });

        ((ImageButton) inflate.findViewById(R.id.buttonBack)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mpclick.start();
                FragmentActivity requireActivity = requireActivity();
                Intrinsics.checkExpressionValueIsNotNull(requireActivity, "requireActivity()");
                requireActivity.getSupportFragmentManager().popBackStack();
            }
        });
    }

    public final void animationLike() {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((ImageButton) findCachedViewById(R.id.btnLike), "rotation", new float[]{0.0f, 360.0f});
        Intrinsics.checkExpressionValueIsNotNull(ofFloat, "animatorTranslate");
        ofFloat.setDuration(1000);
        ofFloat.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (((ImageButton) findCachedViewById(R.id.btnLike)) != null) {
                    ImageButton imageButton = (ImageButton) findCachedViewById(R.id.btnLike);
                    FragmentActivity activity = getActivity();
                    if (activity == null) {
                        Intrinsics.throwNpe();
                    }
                    imageButton.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_like_fill));
                }
            }

        });
        ofFloat.start();
    }

    public final void insertLine(String str, int i) {
        LikesDbHelper likesDbHelper = this.mLikesDbHelper;
        if (likesDbHelper == null) {
            Intrinsics.throwNpe();
        }
        SQLiteDatabase writableDatabase = likesDbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBEntry.COLUMN_ARTICLE_ID, Integer.valueOf(i));
        writableDatabase.insert(str, null, contentValues);
        writableDatabase.close();
    }

    public final void removeLine(String str, int i) {
        LikesDbHelper likesDbHelper = this.mLikesDbHelper;
        if (likesDbHelper == null) {
            Intrinsics.throwNpe();
        }
        SQLiteDatabase writableDatabase = likesDbHelper.getWritableDatabase();
        writableDatabase.delete(str, "article_id=?", new String[]{String.valueOf(i)});
        writableDatabase.close();
    }

    public final void checkNewArticle(int i) {
        SharedPreferences sharedPreferences = this.pref;
        String str = "pref";
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException("pref");
        }
        String str2 = Constants.APP_PREFERENCES_NEW_ARTICLES;
        String str3 = ",";
        SharedPreferences.Editor edit;

        if (sharedPreferences.contains(Constants.APP_PREFERENCES_NEW_ARTICLES)) {
            SharedPreferences sharedPreferences2 = this.pref;
            if (sharedPreferences2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("pref");
            }
            String string = sharedPreferences2.getString(Constants.APP_PREFERENCES_NEW_ARTICLES, new String());
            if (string == null) {
                Intrinsics.throwNpe();
            }
            boolean z = true;
            Collection arrayList = new ArrayList();
            for (Object next : StringsKt.split((CharSequence) string, new String[]{","}, false, 0)) {
                if (((String) next).length() > 0) {
                    arrayList.add(next);
                }
            }
            Iterator it = ((List) arrayList).iterator();
            if (it.hasNext()) {
                if (i == Integer.parseInt((String) it.next())) {
                    z = false;
                }
                return;
            }
            if (z) {
                StringBuilder stringBuilder = new StringBuilder(string);
                sharedPreferences = this.pref;
                if (sharedPreferences == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str);
                }
                edit = sharedPreferences.edit();
                stringBuilder.append(i).append(str3);
                edit.putString(str2, stringBuilder.toString());
                edit.apply();
                return;
            }
            return;

        }
        SharedPreferences sharedPreferences4 = this.pref;
        if (sharedPreferences4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("pref");
        }
        SharedPreferences.Editor edit2 = sharedPreferences4.edit();
        edit2.putString(Constants.APP_PREFERENCES_NEW_ARTICLES, String.valueOf(i) + ",");
        edit2.apply();
    }

    public final boolean checkLikeAndFavorite(List<Integer> list, int i) {
        for (Number intValue : list) {
            if (intValue.intValue() == i) {
                return true;
            }
        }
        return false;
    }

    public final void updateListsDB() {
        List databaseInfoValues = LikesContract.databaseInfoValues(getActivity(), DBEntry.TABLE_NAME_LIKES);
        Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues, "LikesContract.databaseIn…DBEntry.TABLE_NAME_LIKES)");
        this.mListDBLikes = databaseInfoValues;
        databaseInfoValues = LikesContract.databaseInfoValues(getActivity(), DBEntry.TABLE_NAME_FAVORITES);
        Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues, "LikesContract.databaseIn…try.TABLE_NAME_FAVORITES)");
        this.mListDBFavorite = databaseInfoValues;
    }

    private void BannerAds() {
        if (isAdded())
        {
            try {
                adContainerView = inflate.findViewById(R.id.banner_ad_view_container);
                Display defaultDisplay = getActivity().getWindowManager().getDefaultDisplay();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                defaultDisplay.getMetrics(displayMetrics);
                float f = displayMetrics.density;
                float width = (float) adContainerView.getWidth();
                if (width == 0.0f) {
                    width = (float) displayMetrics.widthPixels;
                }
                adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(getActivity(), (int) (width / f));
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
                layoutParams.height = adSize.getHeightInPixels(getActivity());
                adContainerView.setLayoutParams(layoutParams);
                adContainerView.post(new Runnable() {
                    public final void run() {
                        ShowAds();
                    }
                });
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(getActivity());
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
