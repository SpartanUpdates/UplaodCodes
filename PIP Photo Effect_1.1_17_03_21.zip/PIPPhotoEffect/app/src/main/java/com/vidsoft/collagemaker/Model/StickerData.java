package com.vidsoft.collagemaker.Model;

public class StickerData
{
  boolean isSelected;
  String name;

  public StickerData(String paramString, boolean paramBoolean)
  {
    this.name = paramString;
    this.isSelected = paramBoolean;
  }

  public String getName()
  {
    return this.name;
  }

  public boolean isSelected()
  {
    return this.isSelected;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setSelected(boolean paramBoolean)
  {
    this.isSelected = paramBoolean;
  }
}