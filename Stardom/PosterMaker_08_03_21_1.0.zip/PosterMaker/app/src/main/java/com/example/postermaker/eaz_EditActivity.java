package com.example.postermaker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.postermaker.editorsclasses.choseitems.eaz_ChooseItems;
import com.example.postermaker.editorsclasses.eaz_BackgroundITems;
import com.example.postermaker.kprogresshud.KProgressHUD;
import com.example.postermaker.savelayout.eaz_Save;
import com.example.postermaker.textitems.eaz_TextEditor;
import com.example.postermaker.utilities.eaz_Utility;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.xiaopo.flying.sticker.DrawableSticker;
import com.xiaopo.flying.sticker.StickerView;

import java.io.File;
import java.io.IOException;

import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;

public class eaz_EditActivity extends AppCompatActivity implements OnClickListener {
    Activity activity = eaz_EditActivity.this;
    public static RelativeLayout addTextlayout;
    public static LinearLayout addtext;
    public static ImageView addtextlogo;
    public static TextView amazing;
    public static TextView animal;
    public static ImageView arctext;
    public static DiscreteSeekBar backgroundbirghtness;
    public static LinearLayout backgroundborder;
    public static RelativeLayout backgroundborderlayout;
    public static LinearLayout backgroundcolor;
    public static LinearLayout backgroundcolorcontainer;
    public static RelativeLayout backgroundcolorlayout;
    public static ImageView backgroundimage;
    public static LinearLayout backgroundimages;
    public static LinearLayout backgrounditems, items;
    public static RelativeLayout backgrounditemslayout;
    public static RelativeLayout backgroundlayout;
    public static LinearLayout backgroundok;
    public static LinearLayout backgroundsize;
    public static RelativeLayout backgroundsizelayout;
    public static DiscreteSeekBar backhight;
    public static DiscreteSeekBar backwidth;
    public static TextView birthday;
    public static TextView border;
    public static LinearLayout bordercolorlayout;
    public static DiscreteSeekBar borderradious;
    public static DiscreteSeekBar bordersize;
    public static DiscreteSeekBar borderwidth;
    public static ImageView cancel;
    public static ImageView cancelBorder;
    public static ImageView cancelgradient;
    public static ImageView cancelimage;
    public static ImageView cancelshadow;
    public static ImageView cancelsize;
    public static Button canceltext;
    public static ImageView canceltextbgcolor;
    public static ImageView canceltextborder;
    public static ImageView canceltextsize;
    public static TextView cars;
    public static TextView cartoon;
    public static LinearLayout chooseimage;
    public static LinearLayout chooseitems;
    public static LinearLayout chosebackground;
    public static RelativeLayout choseitemslayout;
    public static TextView circles;
    public static TextView coffe;
    public static LinearLayout colorlayoutgradeint;
    public static Context context;
    public static ImageView donetext;
    public static TextView education;
    public static TextView exercise;
    public static TextView festival;
    public static TextView flat;
    public static ImageView font;
    public static RelativeLayout foregroundlayout;
    public static ImageView forgroundimage;
    public static LinearLayout forgrounditems;
    public static TextView fruites;
    public static ImageView gradient;
    public static DiscreteSeekBar imagehight;
    public static DiscreteSeekBar imagewidth;
    public static EditText inputText;
    public static LinearLayout itemsLoader;
    public static TextView logoText;
    public static TextView love;
    public static TextView music;
    public static TextView nature;
    public static TextView offer;
    public static ImageView ok;
    public static ImageView okborder;
    public static ImageView okgradient;
    public static ImageView okimage;
    public static ImageView okshadow;
    public static ImageView oksize;
    public static Button oktext;
    public static ImageView oktextbgcolor;
    public static ImageView oktextborder;
    public static ImageView oktextsize;
    public static TextView ribbon;
    public static TextView sale;
    public static LinearLayout saveitems;
    public static DiscreteSeekBar shadowdown;
    public static DiscreteSeekBar shadowup;
    public static TextView shapes;
    public static StickerView stickerView;
    public static TextView tea;
    public static RelativeLayout textItemlayout;
    public static RelativeLayout textbgborderlayout;
    public static ImageView textbgcolor;
    public static RelativeLayout textbgcoloritemlayout;
    public static LinearLayout textbgcolorlayout;
    public static DiscreteSeekBar textbghight;
    public static DiscreteSeekBar textbgwidth;
    public static ImageView textborder;
    public static LinearLayout textbordercolorlayout;
    public static DiscreteSeekBar textborderradious;
    public static DiscreteSeekBar textbordersize;
    public static DiscreteSeekBar textborderspace;
    public static ImageView textcolor;
    public static LinearLayout textdrawLayout;
    public static RelativeLayout textgradientLayout;
    public static RelativeLayout textshadowLayout;
    public static ImageView textsize;
    public static RelativeLayout textsizeItemlayout;
    public static DiscreteSeekBar textsizes;
    public static ImageView texture;
    AlertDialog alertDialog;
    private final Handler handler = new Handler();
    private int imgProgress;
    RelativeLayout savelayout;
    ImageView img_back;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.eaz_create_poster);
        getWindow().setFlags(1024, 1024);
        stickerView = findViewById(R.id.sticker_view);
        initializeBackgroundLayout();
        initializeForegroundLayout();
        loadBackgrounditems();
        loadBackgroundColors();
        LoadBackgroundBorder();
        LoadBackgroundSize();
        initializeChoseItems();
        initilizeAddTextLayout();
        initliazeTextBGColorItemLayout();
        initializeTextLayout();
        initiliazaTextBorderItemLayout();
        initliazeTextSizeItemlayout();
        initializeTextGradient();
        initializeTextShadow();
        checkPermissions();
        interstitialAd();
        img_back = findViewById(R.id.img_back);
        img_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void initializeBackgroundLayout() {
        this.savelayout = findViewById(R.id.savelayout);
        backgroundlayout = findViewById(R.id.backgroundlayout);

        backgrounditems = findViewById(R.id.backgrounditem);
        backgrounditems.setOnClickListener(this);

        backgroundimage = findViewById(R.id.backgroundimage);

        chooseitems = findViewById(R.id.items);
        chooseitems.setOnClickListener(this);

        chooseimage = findViewById(R.id.uploaditem);
        chooseimage.setOnClickListener(this);

        addtext = findViewById(R.id.textitems);
        addtext.setOnClickListener(this);

        saveitems = findViewById(R.id.saveitems);
        saveitems.setOnClickListener(this);
    }

    public void loadBackgrounditems() {
        backgrounditemslayout = findViewById(R.id.backgrounditemslayout);
        backgroundcolor = findViewById(R.id.backgroundcolors);
        backgroundimages = findViewById(R.id.backgroundimages);
        backgroundsize = findViewById(R.id.backgroundsize);
        backgroundborder = findViewById(R.id.backgroundborder);
        backgroundok = findViewById(R.id.backgroundok);
        LinearLayout linearLayout = findViewById(R.id.backgroundchose);
        chosebackground = linearLayout;
        linearLayout.setOnClickListener(this);
    }

    public void loadBackgroundColors() {
        backgroundcolorcontainer = findViewById(R.id.backgroundcolorlscontainer);
        backgroundcolorcontainer.setPadding(10, 10, 10, 10);
        backgroundcolorlayout = findViewById(R.id.backgroundcolorslayout);
        ok = findViewById(R.id.ok);
        cancel = findViewById(R.id.cancel);
        backgroundbirghtness = findViewById(R.id.backgroundbrightness);
    }

    public void LoadBackgroundBorder() {
        backgroundborderlayout = findViewById(R.id.backgroundborderlayout);
        bordercolorlayout = findViewById(R.id.bordercolorcontainer);
        borderwidth = findViewById(R.id.borderwidth);
        bordersize = findViewById(R.id.bordersize);
        borderradious = findViewById(R.id.borderradius);
        okborder = findViewById(R.id.okborder);
        cancelBorder = findViewById(R.id.cancelborder);
    }

    public void LoadBackgroundSize() {
        backgroundsizelayout = findViewById(R.id.backgroundsizelayout);
        backwidth = findViewById(R.id.backgroundlayoutwidth);
        backhight = findViewById(R.id.backgroundlayouthight);
        imagewidth = findViewById(R.id.backgroundimagewidth);
        imagehight = findViewById(R.id.backgroundimagesizehight);
        oksize = findViewById(R.id.oksize);
        cancelsize = findViewById(R.id.cancelsize);
    }

    public void initializeForegroundLayout() {
        foregroundlayout = findViewById(R.id.forgroundlayout);
        LinearLayout linearLayout = findViewById(R.id.foregrounditems);
        forgrounditems = linearLayout;
        linearLayout.setOnClickListener(this);
        ImageView imageView = findViewById(R.id.forgroundImage);
        forgroundimage = imageView;
        imageView.setOnClickListener(this);
    }

    public void initializeChoseItems() {
        sale = findViewById(R.id.saleitems);
        offer = findViewById(R.id.offeritems);
        ribbon = findViewById(R.id.ribbonitems);
        amazing = findViewById(R.id.wowitems);
        birthday = findViewById(R.id.birthdayitems);
        border = findViewById(R.id.borderitems);
        cars = findViewById(R.id.caritems);
        circles = findViewById(R.id.circleitems);
        coffe = findViewById(R.id.coffeitems);
        education = findViewById(R.id.educationitems);
        exercise = findViewById(R.id.exerciseitems);
        fruites = findViewById(R.id.fruitesitems);
        festival = findViewById(R.id.festivalitems);
        love = findViewById(R.id.loveitems);
        music = findViewById(R.id.musicitems);
        nature = findViewById(R.id.natureitems);
        shapes = findViewById(R.id.shapesitems);
        tea = findViewById(R.id.teaitems);
        animal = findViewById(R.id.animalitems);
        cartoon = findViewById(R.id.cartoonitems);
        flat = findViewById(R.id.flatitems);
        itemsLoader = findViewById(R.id.itemsloader);
        choseitemslayout = findViewById(R.id.choseitems);
    }

    public void initializeTextLayout() {
        textItemlayout = findViewById(R.id.textitemslayout);
        textbgcolor = findViewById(R.id.textbgcolor);
        textcolor = findViewById(R.id.textcolor);
        textborder = findViewById(R.id.textborder);
        textsize = findViewById(R.id.textsize);
        gradient = findViewById(R.id.textgradient);
        texture = findViewById(R.id.texttexture);
        font = findViewById(R.id.fonts);
        arctext = findViewById(R.id.curvetext);
        donetext = findViewById(R.id.donetext);
        addtextlogo = findViewById(R.id.addlogotext);
        textdrawLayout = findViewById(R.id.textdrawyinglayout);
    }

    public void initilizeAddTextLayout() {

        addTextlayout = findViewById(R.id.addtextlayout);
        inputText = findViewById(R.id.input_text);
        oktext = findViewById(R.id.add);
        canceltext = findViewById(R.id.can);
    }

    public void initliazeTextBGColorItemLayout() {
        textbgcoloritemlayout = findViewById(R.id.textbgcoloritemlayout);
        oktextbgcolor = findViewById(R.id.oktextbg);
        canceltextbgcolor = findViewById(R.id.canceltextbg);
        textbgcolorlayout = findViewById(R.id.textbgcolorlayout);
    }

    public void initiliazaTextBorderItemLayout() {
        textbgborderlayout = findViewById(R.id.textbgborderitemlayout);
        textborderradious = findViewById(R.id.radis);
        textbordersize = findViewById(R.id.sizeborder);
        textborderspace = findViewById(R.id.spaceborder);
        oktextborder = findViewById(R.id.oktextborder);
        canceltextborder = findViewById(R.id.canceltextborder);
        textbordercolorlayout = findViewById(R.id.textbordercolor);
    }

    public void initliazeTextSizeItemlayout() {
        textsizeItemlayout = findViewById(R.id.textsizeitemlayout);
        textbgwidth = findViewById(R.id.textbackwidth);
        textbghight = findViewById(R.id.textbackhight);
        textsizes = findViewById(R.id.textsizes);
        oktextsize = findViewById(R.id.oktextsize);
        canceltextsize = findViewById(R.id.canceltextsize);
    }

    public void initializeTextGradient() {
        textgradientLayout = findViewById(R.id.textgradientlayout);
        okgradient = findViewById(R.id.okgrad);
        cancelgradient = findViewById(R.id.cancelgrad);
        colorlayoutgradeint = findViewById(R.id.colorlayoutgrad);
    }

    public void initializeTextShadow() {
        textshadowLayout = findViewById(R.id.textshadowlayout);
        shadowdown = findViewById(R.id.shadowdown);
        shadowup = findViewById(R.id.shadowup);
        okshadow = findViewById(R.id.okshadow);
        cancelshadow = findViewById(R.id.cancelshadow);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        Log.e("TAG", "Code" + i);
        if (i2 == -1 && i == 1001) {
            Uri imageUri = intent.getData();
            Log.e("TAG", "Image Path" + imageUri);
            stickerView.addSticker(new DrawableSticker(new BitmapDrawable(getRealPathFromURI(imageUri))));
        }
        if (i2 == -1 && i == 100) {
            Uri imageUri = intent.getData();
            if (eaz_ConstantValues.bgchoice == 1) {
                backgroundimage.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(getRealPathFromURI(imageUri))));
            }
            if (eaz_ConstantValues.bgchoice == 2) {
                forgroundimage.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(getRealPathFromURI(imageUri))));
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

    private void startPhotoPickIntent(int i) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");

        if (i == 100) {

            startActivityForResult(intent, i);
            return;
        }

        startActivityForResult(intent, i);
    }

    private Uri getTempUri() {
        return Uri.fromFile(getTempFile());
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
      /*  intent.putExtra("crop", "true");
        intent.putExtra("output", getTempFileUri());
        intent.putExtra("outputFormat", CompressFormat.PNG.toString());*/
        startActivityForResult(intent, 1001);
    }

    private Uri getTempFileUri() {
        return Uri.fromFile(getTempFile());
    }

    private File getTempFile() {


        File file = new File(Environment.getExternalStorageDirectory(), eaz_ConstantValues.TEMP_FILE_NAME);
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public void checkPermissions() {
        eaz_Utility.checkPermissionContects(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        eaz_Utility.checkPermissionContects(this, Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    public void onClick(View view) {
        if (view.equals(backgrounditems)) {
            new eaz_BackgroundITems().loadBackgroundItems();
            eaz_ConstantValues.bgchoice = 1;
        } else if (view.equals(forgroundimage)) {
            stickerView.setLocked(!stickerView.isLocked());
        } else if (view.equals(forgrounditems)) {
            new eaz_BackgroundITems().loadBackgroundItems();
            eaz_ConstantValues.bgchoice = 2;
        } else if (view.equals(chooseitems)) {
            new eaz_ChooseItems(view.getContext()).loadItemsChoser();
        } else if (view.equals(chosebackground)) {
            startPhotoPickIntent(100);
        } else if (view.equals(chooseimage)) {
            openGallery();
        } else if (view.equals(addtext)) {
            new eaz_TextEditor(this).loadTextItemsLayout();
        } else if (view.equals(saveitems)) {
            stickerView.setLocked(true);
            this.savelayout.setBackgroundColor(0);

            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                try {
                    hud = KProgressHUD.create(activity)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                            id = 100;
                            mInterstitialAd.show();
                        }
                    }
                }, 2000);
            } else {
                process();
            }

        }
    }

    public void process() {
        new eaz_Save(this.savelayout, this).execute();
        finish();
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdmobInterstitialId));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        stickerView.setLocked(true);
                        savelayout.setBackgroundColor(0);
                        process();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdmobInterstitialId));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
