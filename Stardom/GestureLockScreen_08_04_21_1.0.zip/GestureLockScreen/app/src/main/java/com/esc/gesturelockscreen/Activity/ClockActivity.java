package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.View.ClockView;
import com.esc.gesturelockscreen.R;

public class ClockActivity extends Activity {
    public static int[] clockStyles;
    private static int selectedId;
    private ListView mListView;

    static {
        ClockActivity.clockStyles = new int[]{R.layout.layout_clock_style1, R.layout.layout_clock_style2, R.layout.layout_clock_style3, R.layout.layout_clock_style4, R.layout.layout_clock_style_5, R.layout.layout_clock_style6};
        ClockActivity.selectedId = -1;
    }


    public void onBackPressed(final View view) {
        this.finish();
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_clock);
        (this.mListView = (ListView) this.findViewById(R.id.list_view)).setAdapter((ListAdapter) new ClockAdapter(this));
        this.mListView.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                ClockActivity.selectedId = n;
                ((ClockAdapter) adapterView.getAdapter()).notifyDataSetChanged();
                SettingsUtils.putInt("KEY_INDEX_CLOCK", ClockActivity.selectedId);
            }
        });
    }

    protected void onStart() {
        super.onStart();
        this.overridePendingTransition(0, 0);
    }

    private static class ClockAdapter extends BaseAdapter {
        private final LayoutInflater mInflater;

        ClockAdapter(final Activity activity) {
            this.mInflater = activity.getLayoutInflater();
            ClockActivity.selectedId = SettingsUtils.getInt("KEY_INDEX_CLOCK", 0);
        }

        public int getCount() {
            return ClockActivity.clockStyles.length;
        }

        public Integer getItem(final int n) {
            return ClockActivity.clockStyles[n];
        }

        public long getItemId(final int n) {
            return n;
        }

        public View getView(final int n, View inflate, final ViewGroup viewGroup) {
            int visibility = 0;
            final boolean b = false;
            ViewHolder tag;
            if (inflate == null) {
                inflate = this.mInflater.inflate(R.layout.adapter_item_clock, viewGroup, false);
                tag = new ViewHolder(inflate);
                inflate.setTag((Object) tag);
            } else {
                tag = (ViewHolder) inflate.getTag();
            }
            final ClockView clockView = (ClockView) this.mInflater.inflate((int) this.getItem(n), viewGroup, false);
            tag.frame.removeAllViews();
            tag.frame.addView((View) clockView);
            clockView.handleTimeUpdate();
            final View selectedView = tag.selectedView;
            if (n != ClockActivity.selectedId) {
                visibility = 4;
            }
            selectedView.setVisibility(visibility);
            final View selectedCheck = tag.selectedCheck;
            int visibility2 = b ? 1 : 0;
            if (n != ClockActivity.selectedId) {
                visibility2 = 8;
            }
            selectedCheck.setVisibility(visibility2);
            return inflate;
        }

        private static class ViewHolder {
            final FrameLayout frame;
            final View selectedCheck;
            final View selectedView;

            ViewHolder(final View view) {
                this.frame = (FrameLayout) view.findViewById(R.id.frame_clock);
                this.selectedView = view.findViewById(R.id.selected);
                this.selectedCheck = view.findViewById(R.id.selectedcheck);
            }
        }
    }
}
