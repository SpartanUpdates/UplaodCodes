package com.esc.photovault.activity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import com.esc.photovault.R;
import com.esc.photovault.util.Utils;
import com.hiddencamera.CameraConfig;
import com.hiddencamera.CameraError;
import com.hiddencamera.HiddenCameraActivity;
import com.hiddencamera.config.CameraImageFormat;
import com.hiddencamera.config.CameraRotation;
import java.io.File;

public class CamActivity extends HiddenCameraActivity {

    private CameraConfig mConfig;

    class runnableHendler implements Runnable {
        runnableHendler() {
        }

        public void run() {
            CamActivity.this.takePicture();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cam);
        this.mConfig = new CameraConfig().getBuilder(this).setCameraFacing(1).setCameraResolution(2006).setImageFormat(CameraImageFormat.FORMAT_JPEG).setImageRotation(CameraRotation.ROTATION_270).build();
        if (ActivityCompat.checkSelfPermission(this, Utils.permission.CAMERA) == 0) {
            startCamera(this.mConfig);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Utils.permission.CAMERA}, 101);
        }
        new Handler().postDelayed(new runnableHendler(), 200);
    }

    @SuppressLint({"MissingPermission"})
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode != 101) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        } else if (grantResults[0] == 0) {
            startCamera(this.mConfig);
        } else {
            Toast.makeText(this, "Camera permission denied.", Toast.LENGTH_SHORT).show();
        }
    }

    public void onImageCapture(@NonNull File imageFile) {
        Options options = new Options();
        options.inPreferredConfig = Config.RGB_565;
        ((ImageView) findViewById(R.id.cam_prev)).setImageBitmap(BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options));
    }

    public void onCameraError(int errorCode) {
        switch (errorCode) {
            case CameraError.ERROR_CAMERA_OPEN_FAILED:
                Toast.makeText(this, "Camera cannot open!!", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_CAMERA_PERMISSION_NOT_AVAILABLE:
                Toast.makeText(this, "Camera permission not available!!", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_DOES_NOT_HAVE_FRONT_CAMERA:
                Toast.makeText(this, "Your device does not have front camera!!", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_IMAGE_WRITE_FAILED:
                Toast.makeText(this, "Cannot write image captured by camera!!", Toast.LENGTH_SHORT).show();
                return;
            default:
                return;
        }
    }
}
