package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.kotlinz.videoCollage.fragments.MyAlbumImagesFragment;
import com.kotlinz.videoCollage.fragments.MyAlbumVideosFragment;

public class MyAlbumPagerAdapter extends FragmentPagerAdapter {
    private MyAlbumImagesFragment imagesFragmentNew;
    private int totalTabs;
    private MyAlbumVideosFragment videosFragmentNew;

    public MyAlbumPagerAdapter(Context context, FragmentManager fragmentManager, int i) {
        super(fragmentManager);
        this.totalTabs = i;
        this.imagesFragmentNew = new MyAlbumImagesFragment(context);
        this.videosFragmentNew = new MyAlbumVideosFragment(context);
    }

    public Fragment getItem(int i) {
        if (i != 0) {
            return i != 1 ? null : this.videosFragmentNew;
        } else {
            return this.imagesFragmentNew;
        }
    }

    public int getCount() {
        return this.totalTabs;
    }
}
