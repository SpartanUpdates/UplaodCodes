package com.wavymusic.WidgetView;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Build;
import androidx.annotation.FloatRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import com.wavymusic.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


public class ExpandIconView extends View {
    private static final float MORE_STATE_ALPHA = -45.0F;
    private static final float DELTA_ALPHA = 90.0F;
    private static final float THICKNESS_PROPORTION = 0.1388889F;
    private static final float PADDING_PROPORTION = 0.16666667F;
    private static final long DEFAULT_ANIMATION_DURATION = 150L;
    public static final int MORE = 0;
    public static final int LESS = 1;
    private static final int INTERMEDIATE = 2;
    private int state;
    private float alpha = -45.0F;
    private float centerTranslation = 0.0F;
    @FloatRange(from = 0.0D, to = 1.0D)
    private float fraction = 1.0F;

    private final float animationSpeed;
    private boolean switchColor = false;
    private int color = -16777216;

    private final int colorMore;
    private final int colorLess;
    @NonNull
    private final Paint paint;
    private final Point left = new Point();
    private final Point right = new Point();
    private final Point center = new Point();
    private final Point tempLeft = new Point();
    private final Point tempRight = new Point();

    private final boolean useDefaultPadding;

    private int padding;
    private final Path path = new Path();
    @Nullable
    private ValueAnimator arrowAnimator;

    public ExpandIconView(@NonNull Context context) {
        this(context, null);
    }

    public ExpandIconView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ExpandIconView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        TypedArray array = getContext().getTheme().obtainStyledAttributes(
                attrs, R.styleable.ExpandIconView, 0, 0);
        long animationDuration;
        boolean roundedCorners;
        try {
            roundedCorners = array.getBoolean(R.styleable.ExpandIconView_eiv_roundedCorners, false);
            switchColor = array.getBoolean(
                    R.styleable.ExpandIconView_eiv_switchColor, false);
            color = array.getColor(R.styleable.ExpandIconView_eiv_color,
                    -1);
            colorMore = array.getColor(
                    R.styleable.ExpandIconView_eiv_colorMore, -1);
            colorLess = array.getColor(
                    R.styleable.ExpandIconView_eiv_colorLess, -1);
            animationDuration = array.getInteger(
                    R.styleable.ExpandIconView_eiv_animationDuration,
                    150);
            padding = array.getDimensionPixelSize(
                    R.styleable.ExpandIconView_eiv_padding, -1);
            useDefaultPadding = (padding == -1);
        } finally {
            array.recycle();
        }


        paint = new Paint(1);
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setDither(true);
        if (roundedCorners) {
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
        }


        animationSpeed = (90.0F / (float) animationDuration);
        setState(1, false);
    }

    public void switchState() {
        switchState(true);
    }

    public void switchState(final boolean animate) {
        int newState = 0;
        switch (this.state) {
            case 0: {
                newState = 1;
                break;
            }
            case 1: {
                newState = 0;
                break;
            }
            case 2: {
                newState = this.getFinalStateByFraction();
                break;
            }
            default: {
                throw new IllegalArgumentException("Unknown state [" + this.state + "]");
            }
        }
        this.setState(newState, animate);
    }


    public void setState(int state, boolean animate) {
        this.state = state;
        if (state == 0) {
            fraction = 0.0F;
        } else if (state == 1) {
            fraction = 1.0F;
        } else {
            throw new IllegalArgumentException(
                    "Unknown state, must be one of STATE_MORE = 0,  STATE_LESS = 1");
        }
        updateArrow(animate);
    }


    public void setFraction(@FloatRange(from = 0.0D, to = 1.0D) float fraction, boolean animate) {
        if ((fraction < 0.0F) || (fraction > 1.0F)) {
            throw new IllegalArgumentException(
                    "Fraction value must be from 0 to 1f, fraction=" + fraction);
        }

        if (this.fraction == fraction) {
            return;
        }

        this.fraction = fraction;
        if (fraction == 0.0F) {
            state = 0;
        } else if (fraction == 1.0F) {
            state = 1;
        } else {
            state = 2;
        }

        updateArrow(animate);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(0.0F, centerTranslation);
        canvas.drawPath(path, paint);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        calculateArrowMetrics();
        updateArrowPath();
    }

    private void calculateArrowMetrics() {
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int arrowMaxHeight = height - 2 * padding;
        int arrowWidth = width - 2 * padding;
        arrowWidth = arrowMaxHeight >= arrowWidth ? arrowWidth : arrowMaxHeight;
        if (useDefaultPadding) {
            padding = ((int) (0.16666667F * width));
        }
        float thickness = (int) (arrowWidth * 0.1388889F);
        paint.setStrokeWidth(thickness);
        center.set(width / 2, height / 2);
        left.set(center.x - arrowWidth / 2, center.y);
        right.set(center.x + arrowWidth / 2, center.y);
    }

    private void updateArrow(boolean animate) {
        float toAlpha = -45.0F + fraction * 90.0F;
        if (animate) {
            animateArrow(toAlpha);
        } else {
            cancelAnimation();
            alpha = toAlpha;
            if (switchColor) {
                updateColor(new ArgbEvaluator());
            }
            updateArrowPath();
            invalidate();
        }
    }

    private void updateArrowPath() {
        path.reset();
        if ((left != null) && (right != null)) {
            rotate(left, -alpha, tempLeft);
            rotate(right, alpha, tempRight);
            centerTranslation = ((center.y - tempLeft.y) / 2);
            path.moveTo(tempLeft.x, tempLeft.y);
            path.lineTo(center.x, center.y);
            path.lineTo(tempRight.x, tempRight.y);
        }
    }

    private void animateArrow(float toAlpha) {
        cancelAnimation();


        ValueAnimator valueAnimator = ValueAnimator.ofFloat(new float[]{alpha, toAlpha});
        valueAnimator
                .addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    private final ArgbEvaluator colorEvaluator = new ArgbEvaluator();

                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        alpha = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                        ExpandIconView.this.updateArrowPath();
                        if (switchColor) {
                            ExpandIconView.this.updateColor(colorEvaluator);
                        }
                        ExpandIconView.this.postInvalidateOnAnimationCompat();
                    }
                });
        valueAnimator.setInterpolator(new DecelerateInterpolator());
        valueAnimator.setDuration(calculateAnimationDuration(toAlpha));
        valueAnimator.start();

        arrowAnimator = valueAnimator;
    }

    private void cancelAnimation() {
        if ((arrowAnimator != null) && (arrowAnimator.isRunning())) {
            arrowAnimator.cancel();
        }
    }

    private void updateColor(@NonNull ArgbEvaluator colorEvaluator) {
        color = ((Integer) colorEvaluator.evaluate((alpha + 45.0F) / 90.0F, Integer.valueOf(colorMore),
                Integer.valueOf(colorLess))).intValue();
        paint.setColor(color);
    }

    private long calculateAnimationDuration(final float toAlpha) {
        return (long) (Math.abs(toAlpha - this.alpha) / this.animationSpeed);
    }

    private void rotate(@NonNull final Point startPosition, final double degrees, @NonNull final Point target) {
        final double angle = Math.toRadians(degrees);
        final int x = (int) (this.center.x + (startPosition.x - this.center.x) * Math.cos(angle) - (startPosition.y - this.center.y) * Math.sin(angle));
        final int y = (int) (this.center.y + (startPosition.x - this.center.x) * Math.sin(angle) + (startPosition.y - this.center.y) * Math.cos(angle));
        target.set(x, y);
    }


    private int getFinalStateByFraction() {
        if (fraction <= 0.5F) {
            return 0;
        }
        return 1;
    }

    private void postInvalidateOnAnimationCompat() {
        long fakeFrameTime = 10L;
        if (Build.VERSION.SDK_INT > 15) {
            postInvalidateOnAnimation();
        } else {
            postInvalidateDelayed(10L);
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    public static @interface State {
    }
}
