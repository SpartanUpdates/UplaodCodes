package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdsManager;
import com.mbit.VideoMaker.Activity.HomeActivity;
import com.mbit.VideoMaker.Download.ThemeDownload;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.ThemelModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.View.Indicator;
import com.mbit.VideoMaker.application.MyApplication;
import com.unity3d.player.UnityPlayer;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class ThemeCategoryWiseAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    private Context mContext;
    private ArrayList<ThemelModel> themeCategoryList;
    private HomeActivity ActivityOfTheme;
    private NativeAdsManager mAdsManager;

    public ThemeCategoryWiseAdapter(Context mContext, ArrayList<ThemelModel> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (HomeActivity) mContext;
        this.themeCategoryList = themeCategoryList;
        this.mAdsManager = MyApplication.getInstance().mAdsManager;
//        this.mAdsManager = ActivityOfTheme.mAdsManager;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        if (viewType == ITEM_TYPE_AD) {
            return new NativeAdViewHolder((NativeAdLayout) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.native_ad_for_theme, viewGroup, false));
        } else {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item, viewGroup, false);
            return new ThemeViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (getItemViewType(position) == ITEM_TYPE_AD) {
            final NativeAdViewHolder viewHolder = (NativeAdViewHolder) holder;
            if (mAdsManager != null && themeCategoryList.get(position).isNativeAds()) {
                NativeAd nextNativeAd = mAdsManager.nextNativeAd();
                viewHolder.adchoicescontainer.removeAllViews();
                if (nextNativeAd.isAdLoaded()) {
                    viewHolder.llAdContainer.setVisibility(View.VISIBLE);
                    viewHolder.adtitle.setText(nextNativeAd.getAdvertiserName());
                    viewHolder.adbody.setText(nextNativeAd.getAdBodyText());
                    viewHolder.adsocial.setText(nextNativeAd.getAdSocialContext());
                    viewHolder.adsponsored.setText("Sponsored");
                    viewHolder.btnAdAction.setText(nextNativeAd.getAdCallToAction());
                    viewHolder.btnAdAction.setVisibility(nextNativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
                    viewHolder.adchoicescontainer.addView(new AdOptionsView(viewHolder.llAdContainer.getContext(), nextNativeAd, viewHolder.nativeAd), 0);
                    List arrayList = new ArrayList();
                    arrayList.add(viewHolder.adicon);
                    arrayList.add(viewHolder.admedia);
                    arrayList.add(viewHolder.btnAdAction);
                    nextNativeAd.registerViewForInteraction(viewHolder.nativeAd, viewHolder.admedia, viewHolder.adicon, arrayList);
                } else {
                    viewHolder.llAdContainer.setVisibility(View.GONE);
                }
            } else {
                viewHolder.llAdContainer.setVisibility(View.GONE);
            }

        } else {
            if (holder instanceof ThemeViewHolder) {
                final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
                final ThemelModel themelModel = themeCategoryList.get(position);
                Glide.with(this.mContext).load(themeCategoryList.get(position).getImage()).into(viewHolder.iv_thumb);
                if (!themeCategoryList.get(position).isAvailableOffline) {
                    if (themeCategoryList.get(position).isDownloading) {
                        viewHolder.ivDownload.setVisibility(View.GONE);
                        viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                    } else {
                        viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                        viewHolder.ivDownload.setVisibility(View.VISIBLE);
                    }
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                }
                viewHolder.tvThemeName.setText(themeCategoryList.get(position).getThemeName());
                viewHolder.tvThemeName.setSelected(true);
                viewHolder.tvThemeSize.setText(readableFileSize(themeCategoryList.get(position).getAnimSoundfilesize()));
                viewHolder.tvThemeCounter.setText(String.valueOf(themeCategoryList.get(position).getThemeCounter()));
                viewHolder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isAllGrant = true;
                        for (int i = 0; i < ActivityOfTheme.NECESSARY_PERMISSIONS.length; i++) {
                            if (ContextCompat.checkSelfPermission(mContext,
                                    ActivityOfTheme.NECESSARY_PERMISSIONS[i]) == PackageManager.PERMISSION_DENIED) {
                                isAllGrant = false;
                            }
                        }
                        if (isAllGrant) {
                            DownloadFiles(position, viewHolder.ivDownload, viewHolder.ThemeDownProgress, viewHolder.tvThemeDownProgress, themelModel);
                        } else {
                            Toast.makeText(mContext, "Please Allow All Permission First", Toast.LENGTH_LONG).show();
                            ActivityOfTheme.RequiredPermission("Sorry! we need all permission for make experience batter, Go to Setting And Allow Us.");
                        }
                    }
                });
            }
        }
    }


    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ((position > 0) && ((position + 1) % 5 == 0) && mAdsManager.isLoaded()) {
            return ITEM_TYPE_AD;
        }
        return ITEM_TYPE_DATA;
    }


    private String readableFileSize(long size) {
        if (size <= 0) return "0";
        final String[] units = new String[]{"B", "kB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);

    }

    private void DownloadFiles(int position, ImageView ivDownload, LinearLayout themeDownProgress, TextView tvThemeDownprogress, ThemelModel themelModel) {
        int UnitySoundSize = themeCategoryList.get(position).getAnimSoundfilesize();
        String SongName = themeCategoryList.get(position).getAnimSoundname();
        File SongPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        ActivityOfTheme.AllPath = themeCategoryList.get(position).getAnimSoundPath() + "?" + Utils.INSTANCE.getThemeFolderPath() + File.separator + themeCategoryList.get(position).getThemeName() + ".png" + "?" + themeCategoryList.get(position).getGameobjectName();
        if (new File(Utils.INSTANCE.getThemeFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
//                if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isAdLoaded()) {
//                    ActivityOfTheme.id = 100;
//                    MyApplication.ShowDialog(mContext);
//                    ActivityOfTheme.mInterstitialAd.show();
//                } else {
//                    UnityPlayer.UnitySendMessage("CategoryManagement", "OnLoadUserData", ActivityOfTheme.AllPath);
//                    HideShowUnityBannerAds();
//                    ActivityOfTheme.finish();
//                }
                UnityPlayer.UnitySendMessage("CategoryManagement", "OnLoadUserData", ActivityOfTheme.AllPath);
                HideShowUnityBannerAds();
                ActivityOfTheme.finish();
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    new DownloadTask().execute(ActivityOfTheme.DownloadCountUrl, themeCategoryList.get(position).getThemeid());
                    new ThemeDownload(mContext, themeCategoryList.get(position).getAnimsoundurl(), themeCategoryList.get(position).getAnimSoundname(), themeCategoryList.get(position).getAnimSoundfilesize(), themeCategoryList.get(position).getImage(), themeCategoryList.get(position).getThemeName(), ivDownload, themeDownProgress, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                new DownloadTask().execute(ActivityOfTheme.DownloadCountUrl, themeCategoryList.get(position).getThemeid());
                new ThemeDownload(mContext, themeCategoryList.get(position).getAnimsoundurl(), themeCategoryList.get(position).getAnimSoundname(), themeCategoryList.get(position).getAnimSoundfilesize(), themeCategoryList.get(position).getImage(), themeCategoryList.get(position).getThemeName() + ".png", ivDownload, themeDownProgress, tvThemeDownprogress, themelModel);

            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload, ivLikeTheme;
        TextView tvThemeName, tvThemeSize, tvThemeCounter, tvThemeDownProgress;
        Indicator indicatorThemeProgress;
        LinearLayout ThemeDownProgress;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            ivLikeTheme = itemView.findViewById(R.id.iv_like_theme);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeCounter = itemView.findViewById(R.id.tvLike_counter);
            tvThemeSize = itemView.findViewById(R.id.tvVideoSize);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
        }
    }


    public class NativeAdViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llAdContainer;
        NativeAdLayout nativeAd;
        MediaView admedia;
        MediaView adicon;
        TextView adtitle;
        TextView adbody;
        TextView adsocial;
        TextView adsponsored;
        Button btnAdAction;
        LinearLayout adchoicescontainer;


        NativeAdViewHolder(NativeAdLayout nativeAdLayout) {
            super(nativeAdLayout);
            nativeAd = nativeAdLayout;
            llAdContainer = nativeAdLayout.findViewById(R.id.llNativeAdContainer);
            admedia = nativeAdLayout.findViewById(R.id.native_ad_media);
            adtitle = nativeAdLayout.findViewById(R.id.native_ad_title);
            adbody = nativeAdLayout.findViewById(R.id.native_ad_body);
            adsocial = nativeAdLayout.findViewById(R.id.native_ad_social_context);
            adsponsored = nativeAdLayout.findViewById(R.id.native_ad_sponsored_label);
            btnAdAction = nativeAdLayout.findViewById(R.id.native_ad_call_to_action);
            adicon = nativeAdLayout.findViewById(R.id.native_ad_icon);
            adchoicescontainer = nativeAdLayout.findViewById(R.id.ad_choices_container);

        }
    }

    @SuppressLint("StaticFieldLeak")
    public class DownloadTask extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("theme_id", arg0[1]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }
}
