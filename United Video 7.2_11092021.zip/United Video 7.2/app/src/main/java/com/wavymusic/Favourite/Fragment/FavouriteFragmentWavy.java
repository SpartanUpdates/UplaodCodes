package com.wavymusic.Favourite.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.Favourite.Adapter.MyTemplateAdapterWavy;
import com.wavymusic.Favourite.Database.DatabaseHelperwavy;
import com.wavymusic.Favourite.Model.MytemplateModelWavy;
import com.wavymusic.R;
import com.wavymusic.UnityPlayerActivity;

import java.util.ArrayList;
import java.util.List;


public class FavouriteFragmentWavy extends Fragment {

    DatabaseHelperwavy database;
    RecyclerView rvMyTemplate;
    LinearLayout llCreateVideo;
    MyTemplateAdapterWavy templateAdapter;
    List<MytemplateModelWavy> favThemeList;
    Button btnCreateNow;


    public static FavouriteFragmentWavy newInstance() {
        FavouriteFragmentWavy fragment = new FavouriteFragmentWavy();
        return fragment;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favourite_wavy, container, false);
        rvMyTemplate = view.findViewById(R.id.rv_my_template);
        btnCreateNow = view.findViewById(R.id.btn_fav_createvideo);
        llCreateVideo = view.findViewById(R.id.ll_fav_createvideo);
        favThemeList = new ArrayList<>();
        database = new DatabaseHelperwavy(getActivity());
        favThemeList = database.getdataWavy();
        templateAdapter = new MyTemplateAdapterWavy(getActivity(), favThemeList);
        StaggeredGridLayoutManager gridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        rvMyTemplate.setLayoutManager(gridLayoutManager);
        rvMyTemplate.setAdapter(templateAdapter);
        if (favThemeList.size() > 0) {
            llCreateVideo.setVisibility(View.GONE);
        } else {
            llCreateVideo.setVisibility(View.VISIBLE);
        }
        btnCreateNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), DashbordActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
        return view;
    }
}