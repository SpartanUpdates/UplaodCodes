package com.vidsoft.uvideostatus.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnScrollListener;
import com.airbnb.lottie.LottieAnimationView;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdsManager;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vidsoft.uvideostatus.Activity.Video_play_Activity;
import com.vidsoft.uvideostatus.Adapters.FeatureAdapter;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.GridSpacingItemDecoration;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FeatureFragment extends Fragment implements OnClickListener {
    public static LottieAnimationView icon_like;
    public static RelativeLayout loader;
    public static LottieAnimationView loottiedone;
    public static LottieAnimationView lottie_download;
    RecyclerView album_recyclerview;
    ImageView fb_layout;
    public boolean isLastPage = false;
    FeatureAdapter mAdapter;
    GridLayoutManager mLayoutManager;
    String main_url;
    ImageView share_layout;
    public int totalCount = 1;
    ArrayList<VideoData> videoData = new ArrayList<>();
    VideoData videoDataobj = new VideoData();
    String vurl;
    ImageView wp_layout;
    ImageView you_layout;
    public NativeAdsManager mAdsManager;

    class dataTrendingHandler extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataTrendingHandler() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            try {
                JSONObject jSONObject = new JSONObject(new String(bArr));
                jSONObject.getString("error");
                try {
                    FeatureFragment.this.videoData.remove(FeatureFragment.this.videoData.size() - 1);
                    FeatureFragment.this.mAdapter.notifyItemRemoved(FeatureFragment.this.videoData.size());
                } catch (Exception unused) {
                }
                try {
                    JSONArray jSONArray = jSONObject.getJSONArray("data");
                    if (jSONArray.length() != 0) {
                        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                            FeatureFragment.this.videoDataobj = new VideoData();
                            FeatureFragment.this.videoDataobj.setVideo_id(jSONObject2.getLong(TtmlNode.ATTR_ID));
                            videoDataobj.setTitle(jSONObject.getString("title"));
                            FeatureFragment.this.videoDataobj.setUrl(jSONObject2.getString(str));
                            VideoData videoData = FeatureFragment.this.videoDataobj;
                            StringBuilder sb = new StringBuilder();
                            sb.append(FeatureFragment.this.vurl);
                            sb.append(jSONObject2.getString(str));
                            sb.append(".mp4");
                            videoData.setReal_videopath(sb.toString());
                            VideoData videoData2 = FeatureFragment.this.videoDataobj;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(FeatureFragment.this.vurl);
                            sb2.append(jSONObject2.getString(str));
                            videoData2.setThumbnail(sb2.toString());
                            FeatureFragment.this.videoDataobj.setCatagory(jSONObject2.getString("category"));
                            FeatureFragment.this.videoDataobj.setSub_catagory(jSONObject2.getString("subcategory"));
                            FeatureFragment.this.videoDataobj.setLikes(jSONObject2.getString("likes"));
                            FeatureFragment.this.videoDataobj.setViews(jSONObject2.getString("view"));
//                            FeatureFragment.this.videoData.add(FeatureFragment.this.videoDataobj);
                        }
                        if ((videoData.size() + 1) %3 == 0) {
                            videoDataobj.IsNativeAds = true;
                            videoData.add(videoDataobj);
                            Log.e("DataAdd",""+videoData);
                        } else {
                            videoData.add(videoDataobj);
                        }
                        FeatureFragment.this.mAdapter.addAll(FeatureFragment.this.videoData);
                        FeatureFragment.this.totalCount = FeatureFragment.this.totalCount + 1;
                        if (FeatureFragment.this.videoData.size() < 20) {
                            FeatureFragment.this.isLastPage = true;
                        } else {
                            FeatureFragment.this.isLastPage = false;
                        }
                    } else {
                        FeatureFragment.this.isLastPage = true;
                    }
                    FeatureFragment.this.mAdapter.setLoaded();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
    }

    public void onClick(View view) {
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.feature_fragment, viewGroup, false);
        if (getArguments() != null) {
            this.main_url = getArguments().getString("url");
            this.vurl = getArguments().getString("vurl");
        }
        initViews(inflate);
        initNativeAds();
        return inflate;
    }

    private void initViews(View view) {
        loader = (RelativeLayout) view.findViewById(R.id.loader);
        lottie_download = (LottieAnimationView) view.findViewById(R.id.lottie_download);
        loottiedone = (LottieAnimationView) view.findViewById(R.id.loottiedone);
        this.album_recyclerview = (RecyclerView) view.findViewById(R.id.album_recyclerview);
        this.fb_layout = (ImageView) view.findViewById(R.id.fb_layout);
        this.you_layout = (ImageView) view.findViewById(R.id.you_layout);
        this.wp_layout = (ImageView) view.findViewById(R.id.wp_layout);
        this.share_layout = (ImageView) view.findViewById(R.id.share_layout);
        this.wp_layout.setOnClickListener(this);
        this.fb_layout.setOnClickListener(this);
        this.you_layout.setOnClickListener(this);
        this.share_layout.setOnClickListener(this);
        this.album_recyclerview.addItemDecoration(new GridSpacingItemDecoration(2, 8, true));
        this.mLayoutManager = new GridLayoutManager(getActivity(), 2);
        this.album_recyclerview.setLayoutManager(this.mLayoutManager);
        this.mAdapter = new FeatureAdapter(getActivity(), this.videoData, this);
        this.album_recyclerview.setAdapter(this.mAdapter);
        this.mLayoutManager.setSpanSizeLookup(new SpanSizeLookup() {
            public int getSpanSize(int i) {
                int itemViewType = FeatureFragment.this.mAdapter.getItemViewType(i);
                if (itemViewType != 1) {
                    return (itemViewType == 2 || itemViewType == 3) ? 2 : 1;
                }
                return 1;
            }
        });
        this.album_recyclerview.addOnScrollListener(new OnScrollListener() {
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }

            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (i2 > 0) {
                    if (FeatureFragment.this.mLayoutManager.getChildCount() + FeatureFragment.this.mLayoutManager.findFirstVisibleItemPosition() >= FeatureFragment.this.mLayoutManager.getItemCount() && !FeatureFragment.this.isLastPage) {
                        FeatureFragment.this.videoData.remove(FeatureFragment.this.videoData.size() - 1);
                        FeatureFragment.this.mAdapter.notifyItemRemoved(FeatureFragment.this.videoData.size());
                        FeatureFragment.this.videoDataobj = new VideoData();
                        FeatureFragment.this.videoDataobj.setType(2);
                        FeatureFragment.this.videoData.add(FeatureFragment.this.videoDataobj);
                        FeatureFragment.this.mAdapter.notifyItemInserted(FeatureFragment.this.videoData.size() - 1);
                        FeatureFragment.this.getTrendingVideo();
                    }
                }
            }
        });
        getTrendingVideo();
    }

    public void initNativeAds() {
        mAdsManager = new NativeAdsManager(getActivity(), getResources().getString(R.string.fb_native), 5);
        mAdsManager.loadAds();
        mAdsManager.setListener(new NativeAdsManager.Listener() {
            @Override
            public void onAdsLoaded() {
                Log.e("FBAds", "Native Ad Load");
                Log.e("title",""+mAdsManager.nextNativeAd().getAdHeadline());
                Log.e("BodyText",""+mAdsManager.nextNativeAd().getAdBodyText());
            }

            @Override
            public void onAdError(AdError adError) {
                Log.e("FBAds", "Native Ad Not Load : " + adError.getErrorMessage());

            }
        });
    }


    public void getTrendingVideo() {
        RequestParams requestParams = new RequestParams();
        requestParams.put("page", String.valueOf(this.totalCount));
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.addHeader("Authorization", String.valueOf(123));
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append(this.main_url);
        sb.append("getvideo");
        asyncHttpClient.post(sb.toString(), requestParams, new dataTrendingHandler());
    }

    public void playVideo(VideoData videoData2) {
        Intent intent = new Intent(getActivity(), Video_play_Activity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("main_url", this.main_url);
        intent.putExtra("vurl", this.vurl);
        intent.putExtra("list", videoData2);
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        startActivity(intent);
    }
}
