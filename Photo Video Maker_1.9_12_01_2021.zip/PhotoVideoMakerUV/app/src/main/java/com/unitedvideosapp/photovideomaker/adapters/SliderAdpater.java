package com.unitedvideosapp.photovideomaker.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.smarteist.autoimageslider.SliderViewAdapter;
import com.unitedvideosapp.photovideomaker.activity.MainActivity;
import com.unitedvideosapp.photovideomaker.modelclass.SliderModel;
import com.uvvideos.photo.video.slideshow.maker.R;

import java.util.ArrayList;

public class SliderAdpater extends SliderViewAdapter<SliderAdpater.SlideAdapterHolder> {

    private Context context;
    private MainActivity ActivityOfMain;
    private ArrayList<SliderModel> sliderList = new ArrayList<>();

    public SliderAdpater(Context context, ArrayList<SliderModel> sliderList) {
        this.context = context;
        ActivityOfMain = (MainActivity) context;
        this.sliderList = sliderList;
    }

    @Override
    public SlideAdapterHolder onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_slider_item, null, false);
        return new SlideAdapterHolder(inflate);
    }

    @Override
    public void onBindViewHolder(SlideAdapterHolder viewHolder, final int position) {
        SliderModel sliderItem = sliderList.get(position);
//        Glide.with(context).load(sliderItem.getImagePath()).into(viewHolder.ivBanner);
        viewHolder.layoutSldierMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://453.win.qureka.com/intro/question");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                ActivityOfMain.startActivity(intent);
            }
        });
    }

    @Override
    public int getCount() {
        return sliderList.size();
    }

    class SlideAdapterHolder extends SliderViewAdapter.ViewHolder {

        FrameLayout layoutSldierMain;
        ImageView ivBanner;

        public SlideAdapterHolder(View itemView) {
            super(itemView);
            layoutSldierMain = itemView.findViewById(R.id.fl_slider_main);
            ivBanner = itemView.findViewById(R.id.iv_banner);
        }

    }
}
