package com.hiddencamera;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.RequiresPermission;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public abstract class HiddenCameraFragment extends Fragment implements CameraCallbacks {
    private CameraConfig mCachedCameraConfig;
    private CameraPreview mCameraPreview;

    private CameraPreview addPreView() {
        final CameraPreview cameraPreview = new CameraPreview((Context) this.getActivity(), this);
        cameraPreview.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        final View child = ((ViewGroup) this.getActivity().getWindow().getDecorView().getRootView()).getChildAt(0);
        if (child instanceof LinearLayout) {
            ((LinearLayout) child).addView((View) cameraPreview, (ViewGroup.LayoutParams) new LinearLayout.LayoutParams(1, 1));
            return cameraPreview;
        }
        if (child instanceof RelativeLayout) {
            final RelativeLayout relativeLayout = (RelativeLayout) child;
            final RelativeLayout.LayoutParams relativeLayoutLayoutParams = new RelativeLayout.LayoutParams(1, 1);
            relativeLayoutLayoutParams.addRule(9, -1);
            relativeLayoutLayoutParams.addRule(12, -1);
            relativeLayout.addView((View) cameraPreview, (ViewGroup.LayoutParams) relativeLayoutLayoutParams);
            return cameraPreview;
        }
        if (child instanceof FrameLayout) {
            ((FrameLayout) child).addView((View) cameraPreview, (ViewGroup.LayoutParams) new FrameLayout.LayoutParams(1, 1));
            return cameraPreview;
        }
        throw new RuntimeException("Root view of the activity/fragment cannot be other than Linear/Relative or frame layout");
    }

    @Override
    public void onPause() {
        super.onPause();
        if (this.mCameraPreview != null) {
            this.mCameraPreview.stopPreviewAndFreeCamera();
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onResume() {
        super.onResume();
        if (this.mCachedCameraConfig != null) {
            this.startCamera(this.mCachedCameraConfig);
        }
    }

    @RequiresPermission("android.permission.CAMERA")
    public void startCamera(final CameraConfig mCachedCameraConfig) {
        if (ContextCompat.checkSelfPermission((Context) this.getActivity(), "android.permission.CAMERA") != 0) {
            this.onCameraError(5472);
            return;
        }
        if (mCachedCameraConfig.getFacing() == 1 && !HiddenCameraUtils.isFrontCameraAvailable((Context) this.getActivity())) {
            this.onCameraError(8722);
            return;
        }
        if (this.mCameraPreview == null) {
            this.mCameraPreview = this.addPreView();
        }
        this.mCameraPreview.startCameraInternal(mCachedCameraConfig);
        this.mCachedCameraConfig = mCachedCameraConfig;
    }

    public void stopCamera() {
        this.mCachedCameraConfig = null;
        if (this.mCameraPreview != null) {
            this.mCameraPreview.stopPreviewAndFreeCamera();
        }
    }

    public void takePicture() {
        if (this.mCameraPreview != null) {
            if (this.mCameraPreview.isSafeToTakePictureInternal()) {
                this.mCameraPreview.takePictureInternal();
            }
            return;
        }
        throw new RuntimeException("Background camera not initialized. Call startCamera() to initialize the camera.");
    }
}
