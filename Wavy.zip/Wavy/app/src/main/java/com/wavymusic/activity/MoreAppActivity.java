//package com.wavymusic.activity;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.Toast;
//import com.wavymusic.Adapter.MoreAppAdapter;
//import com.wavymusic.Model.MoreAppModel;
//import com.wavymusic.R;
//import com.wavymusic.Retrofit.APIClient;
//import com.wavymusic.Retrofit.APIInterface;
//import com.wavymusic.Utils.Utils;
//import java.util.ArrayList;
//
//public class MoreAppActivity extends AppCompatActivity {
//
//    Activity activity = MoreAppActivity.this;
//    LinearLayout llRetry;
//    RelativeLayout rlLoadingMoreApp;
//    Button btnRetry;
//    ImageView ivBack;
//    RecyclerView rvMoreApp;
//    private ArrayList<MoreAppModel> moreAppList = new ArrayList<>();
//    private MoreAppAdapter moreAppAdapter;
//    APIInterface apiInterface;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_more_app);
//        apiInterface = APIClient.getClient().create(APIInterface.class);
//        BindView();
////        GetMoreApp();
//        adListener();
//    }
//
//    private void BindView() {
//        ivBack = findViewById(R.id.ivBack);
//        rlLoadingMoreApp = findViewById(R.id.rl_loading_pager);
//        llRetry = findViewById(R.id.llRetry);
//        btnRetry = findViewById(R.id.btnRetry);
//        rvMoreApp = findViewById(R.id.rvMoreApp);
//    }
//
//    private void adListener() {
//        ivBack.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
//        btnRetry.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (Utils.checkConnectivity(activity, false)) {
//                    llRetry.setVisibility(View.GONE);
//                    GetMoreApp();
//                } else {
//                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
//                }
//            }
//        });
//    }
//
//    private void SetAdapter() {
//        moreAppAdapter = new MoreAppAdapter(activity, moreAppList);
//        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false);
//        rvMoreApp.setLayoutManager(mLayoutManager);
//        rvMoreApp.setAdapter(moreAppAdapter);
//        moreAppAdapter.notifyDataSetChanged();
//    }
//
//    private void GetMoreApp() {
//        rlLoadingMoreApp.setVisibility(View.VISIBLE);
//        SetAdapter();
//    }
//
//    public void onBackPressed() {
//        Intent intent = new Intent(activity, HomeActivity.class);
//        startActivity(intent);
//        finish();
//    }
//}
