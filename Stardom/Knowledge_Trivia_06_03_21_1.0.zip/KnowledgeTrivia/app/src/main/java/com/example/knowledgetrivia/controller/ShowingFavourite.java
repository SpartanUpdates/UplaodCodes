package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityOptionsCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.FavouriteDatabaseHelper;
import com.example.knowledgetrivia.kprogresshud.KProgressHUD;
import com.example.knowledgetrivia.manager.QuestionManager;
import com.example.knowledgetrivia.models.Question;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.Iterator;


public class ShowingFavourite extends AppCompatActivity {
    Activity activity = ShowingFavourite.this;
    private ArrayList<Question> questions;
    private MediaPlayer tick;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private ImageView img_back;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);

        setContentView(R.layout.activity_showing_favourite);
        img_back = findViewById(R.id.img_back);

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        BannerAds();

        this.tick = MediaPlayer.create(this, R.raw.tick);
        ListView listView = (ListView) findViewById(R.id.lay_sf_list);
        this.questions = new ArrayList();
        ArrayList arrayList = new ArrayList();
        QuestionManager instance = QuestionManager.getInstance(this);
        ArrayList favouriteQuestions = new FavouriteDatabaseHelper(this).getFavouriteQuestions();
        TextView textView = (TextView) findViewById(R.id.no_any_favourites);
        if (favouriteQuestions.isEmpty()) {
            textView.setVisibility(View.VISIBLE);
        }
        Iterator it = favouriteQuestions.iterator();
        while (it.hasNext()) {
            Question questionById = instance.getQuestionById(((Integer) it.next()).intValue());
            if (questionById != null) {
                this.questions.add(questionById);
                arrayList.add(questionById.getQuestion());
            }
        }
        listView.setAdapter(new ArrayAdapter(this, R.layout.listview_showing_fav, R.id.showing_fav_ques, arrayList));

        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                ShowingFavourite.this.tick.start();
                Question question = (Question) ShowingFavourite.this.questions.get(i);
                Intent intent = new Intent(ShowingFavourite.this, ShowFavQuestions.class);
                intent.putExtra("question", question.getQuestion());
                intent.putExtra("answer", (String) question.getOptions().get(question.getSolutionIndex() - 1));
                ShowingFavourite.this.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(ShowingFavourite.this.getApplicationContext(), R.anim.slide_in_right, R.anim.slide_out_left).toBundle());
            }
        });
    }

    public void finish() {
        super.finish();
        overridePendingTransition(17432576, 17432577);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
