package com.vidsoft.videostatusmaker.Activity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.vidsoft.videostatusmaker.Utils.EPreferences;
import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

import java.io.File;


public class FirstActivity extends AppCompatActivity {
    int height;
    ImageLoader imageLoader;
    private boolean isPause = false;
    ImageView ivmyCreations;
    String[] permission = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    ImageView ivStart;
    int width;
    EPreferences ePreferences;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.startactivity);
        goToMain();
        this.ePreferences = EPreferences.getInstance((Context) this);
        getWindow().addFlags(1024);
        loadAds();
        init();
        initImageLoader();
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialog.dismiss();
            }
        }, 2000);
    }

    private NativeAd NativeAd;
    private int id;
    private InterstitialAd interstitialAd;
    Dialog dialog;

    private void loadAds() {
        dialog = new Dialog(FirstActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_progress);
        dialog.setCanceledOnTouchOutside(false);
        NativeAd = new NativeAd(this, getString(R.string.FB_Native));
        NativeAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeAdView.render(FirstActivity.this, NativeAd, NativeAdView.Type.HEIGHT_300);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        NativeAd.loadAd();
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialog.dismiss();
                switch (id) {
                    case R.id.start:
                        FirstActivity.this.startActivity(new Intent(FirstActivity.this.getApplicationContext(), MainActivity.class));
                        break;
                    case R.id.mywork:
                        FirstActivity.this.startActivity(new Intent(FirstActivity.this.getApplicationContext(), ActivityMyCreations.class));
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();


    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            backDialog();
        } else {
            RateDialog();
        }
    }

    protected void onResume() {
        this.isPause = false;
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/");
            stringBuilder.append(getResources().getString(R.string.app_name));
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("/");
            stringBuilder3.append(getString(R.string.temp_folder));
            MainActivity.deleteRecursive(new File(stringBuilder3.toString()));
            Utils.photos.clear();
        }
        ActivityPreview.THEME = 0;
        super.onResume();
        return;
    }


    private void initImageLoader() {
        this.imageLoader = ImageLoader.getInstance();
        this.imageLoader.init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    void AllowPermission() {
        try {
            VmPolicy.Builder builder = new VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
            if (VERSION.SDK_INT >= 18) {
                builder.detectFileUriExposure();
            }
        } catch (Exception e) {
            e.toString();
        }
        if (VERSION.SDK_INT < 23) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            requestPermissions(this.permission, 100);
        }
    }

    private void init() {
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        this.ivmyCreations = (ImageView) findViewById(R.id.mywork);
        this.ivStart = (ImageView) findViewById(R.id.start);
        this.ivStart.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                id = R.id.start;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialog.show();
                    AdsDialogShow();
                } else {
                    FirstActivity.this.startActivity(new Intent(FirstActivity.this.getApplicationContext(), MainActivity.class));
                }
            }
        });
        this.ivmyCreations.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                id = R.id.mywork;
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    dialog.show();
                    AdsDialogShow();
                } else {
                    FirstActivity.this.startActivity(new Intent(FirstActivity.this.getApplicationContext(), ActivityMyCreations.class));
                }
            }
        });
    }

    protected void onPause() {
        this.isPause = true;
        super.onPause();
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (VERSION.SDK_INT >= 23) {
            AllowPermission();
        }
    }

    private void goToMain() {
        AllowPermission();
    }

    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(FirstActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_rate);
        dialog.setCanceledOnTouchOutside(false);
        final NativeBannerAd mNativeBannerAd;
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.findViewById(R.id.tvLoadingads).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(FirstActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) dialog.findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        mNativeBannerAd.loadAd();
        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    ePreferences.putBoolean("pref_key_rate", true);
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    private void backDialog() {
        final Dialog dialog = new Dialog(FirstActivity.this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_back);
        final NativeBannerAd mNativeBannerAd;
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(FirstActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) dialog.findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
        dialog.setCanceledOnTouchOutside(false);
        Button btnLatter = (Button) dialog.findViewById(R.id.btnLater);
        Button btnSubmit = (Button) dialog.findViewById(R.id.btnSubmit);
        btnLatter.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        btnSubmit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
        dialog.show();
    }

}