package com.kotlinz.videoCollage.fragments;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoeditor.R;

public class EditTextDialogFragment extends DialogFragment {
    Context context;
    public EditText edittext;
    ImageView imageBack;
    ImageView imageView;
    InputMethodManager mInputMethodManager;
    String string = "";
    View view;

    public EditTextDialogFragment(Context context, String str) {
        this.string = str;
        this.context = context;
    }

    public void setText(String str) {
        this.string = str;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.fragment_edittext_dialog, viewGroup, false);
        inIt();
        clickListener();
        this.mInputMethodManager.toggleSoftInput(2, 0);
        if (!this.string.equals("")) {
            this.edittext.setText(this.string);
        }
        openKeyboard(this.edittext);
        this.edittext.setFocusableInTouchMode(true);
        this.edittext.requestFocus();
        this.edittext.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (keyEvent.getAction() != 0 || i != 4) {
                    return false;
                }
                ((GridActivity) EditTextDialogFragment.this.context).onDelete();
                EditTextDialogFragment.this.dismiss();
                return true;
            }
        });
        this.edittext.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if ((keyEvent != null && keyEvent.getKeyCode() == 66) || i == 6) {
                    if (EditTextDialogFragment.this.edittext.getText().toString().length() != 0) {
                        EditTextDialogFragment.this.mInputMethodManager.hideSoftInputFromWindow(EditTextDialogFragment.this.view.getWindowToken(), 0);
                        ((GridActivity) EditTextDialogFragment.this.context).textAdd(EditTextDialogFragment.this.edittext.getText().toString().trim());
                        EditTextDialogFragment.this.dismiss();
                    } else {
                        Toast.makeText(EditTextDialogFragment.this.view.getContext(), "Enter text", Toast.LENGTH_SHORT).show();
                    }
                }
                return false;
            }
        });
        return this.view;
    }

    private void clickListener() {
        this.imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (EditTextDialogFragment.this.edittext.getText().toString().length() != 0) {
                    EditTextDialogFragment.this.mInputMethodManager.hideSoftInputFromWindow(EditTextDialogFragment.this.view.getWindowToken(), 0);
                    ((GridActivity) EditTextDialogFragment.this.context).textAdd(EditTextDialogFragment.this.edittext.getText().toString().trim());
                    EditTextDialogFragment.this.dismiss();
                    return;
                }
                Toast.makeText(EditTextDialogFragment.this.view.getContext(), "Enter text", Toast.LENGTH_SHORT).show();
            }
        });
        this.imageBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditTextDialogFragment.this.mInputMethodManager.hideSoftInputFromWindow(EditTextDialogFragment.this.view.getWindowToken(), 0);
                ((GridActivity) EditTextDialogFragment.this.context).showController();
                EditTextDialogFragment.this.dismiss();
            }
        });
    }

    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
    }

    private void inIt() {
        this.edittext = (EditText) this.view.findViewById(R.id.add_text_edit_text);
        this.imageView = (ImageView) this.view.findViewById(R.id.add_text_done_tv);
        this.imageBack = (ImageView) this.view.findViewById(R.id.img_text_edit_back);
        this.mInputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    public void openKeyboard(EditText editText) {
        InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(editText, 1);
        }
    }
}
