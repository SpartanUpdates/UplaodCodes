package com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.imageloader;

public enum ImageType {
    FOLDER,
    GALLERY
}
