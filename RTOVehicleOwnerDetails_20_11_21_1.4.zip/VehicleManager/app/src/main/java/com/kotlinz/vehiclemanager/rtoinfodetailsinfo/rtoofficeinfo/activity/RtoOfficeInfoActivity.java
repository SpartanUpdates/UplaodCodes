package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Adapter.ExpandableListViewAdapter;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RtoOfficeInfoActivity extends AppCompatActivity {
    private Activity activity = RtoOfficeInfoActivity.this;
    private ArrayList<String> stateList = new ArrayList<>();
    private List<List<String>> cityList = new ArrayList<>();
    private ExpandableListView expandableListView;
    private HashMap<String, List<String>> bindingList = new HashMap();
    private ImageView iv_back;
    private AppCompatDialog dialog;
    private TextView title_tv;

    GGAdview gg_native;

    //InterstitialAds
    private int id;
    public GGInterstitialAd interstitialAd;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo);

        expandableListView = findViewById(R.id.expandListView);
        title_tv = findViewById(R.id.title_tv);
        iv_back = findViewById(R.id.iv_back);
        PutAnalyticsEvent();
        Setlistener();
        DialogAnimation();
        CallNativeAds();
        InterAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        }

        DarkTheame darkTheame = new DarkTheame(RtoOfficeInfoActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        }

        getRtoOfficeData();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void CallNativeAds(){
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback()
                         {
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds(){
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity,getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(RtoOfficeInfoActivity.this, MainActivity.class));
                        finish();
                        break;
                }
            }
            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed (AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_dialog_search);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void Setlistener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        expandableListView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                expandableListView.setIndicatorBounds(expandableListView.getMeasuredWidth() - 100, expandableListView.getMeasuredWidth());
            }
        });

        final int[] prevExpandPosition = {-1};

        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                if (prevExpandPosition[0] >= 0 && prevExpandPosition[0] != groupPosition) {
                    expandableListView.collapseGroup(prevExpandPosition[0]);
                }
                prevExpandPosition[0] = groupPosition;
            }
        });
    }

    private void getRtoOfficeData() {
        String cityStateJsonData = Utils.getStateCityFromJson(RtoOfficeInfoActivity.this, "rtoofficeinfo.json");
        try {
            JSONObject obj = new JSONObject(cityStateJsonData);
            JSONArray mainArray = obj.getJSONArray("details");
            for (int i = 0; i < mainArray.length(); i++) {
                JSONObject stateObj = mainArray.getJSONObject(i);
                String stateName = stateObj.getString("name");
                stateList.add(stateName);
                List<String> CityNamelist = new ArrayList<>();
                JSONArray cityArray = stateObj.getJSONArray("rtoList");
                for (int j = 0; j < cityArray.length(); j++) {
                    JSONObject cityObj = cityArray.getJSONObject(j);
                    String insideStateName=cityObj.getString("state");
                    if(stateName.equals(insideStateName))
                    {
                        String cityName = cityObj.getString("district");
                        String rtoCode = cityObj.getString("rto_code");
                        String state = cityObj.getString("state");
                        String address = cityObj.getString("address");
                        String contact = cityObj.getString("phone");
                        String website = cityObj.getString("website");
                        CityNamelist.add(rtoCode + ">" + cityName + ">" + state + ">" + address + ">" + contact + ">" + website);
                    }
                }

                cityList.add(CityNamelist);
                bindingList.put(stateList.get(i), cityList.get(i));

                ExpandableListAdapter expandableListAdapter = new ExpandableListViewAdapter(activity, stateList, bindingList);
                expandableListView.setAdapter(expandableListAdapter);

                dialog.dismiss();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(RtoOfficeInfoActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}