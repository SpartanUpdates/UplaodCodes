package com.wavymusic.SongSelection.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.SongSelection.Adapter.SelectSongAdapter;
import com.wavymusic.SongSelection.Fragment.SongByCatFragment;
import com.wavymusic.SongSelection.Model.SongCatModel;
import com.wavymusic.SongSelection.Model.SongModel;
import com.wavymusic.SongSelection.songCrop.controler.Mediacontroler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SongSelectActivity extends AppCompatActivity {

    Activity activity = SongSelectActivity.this;
    public SharedPreferences pref;
    public int id;
    //    public String FinalSongPath;
    ViewPagerAdapter adp;
    ArrayList<SongCatModel> SongList = new ArrayList<>();
    RelativeLayout rlLoadingTheme;
    LinearLayout layoutSongSdCard;
    ImageView ivBack;
    Button btnRetry;
    LinearLayout llRetry;
    APIInterface apiInterface;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public MediaPlayer mediaPlayer;
    public int selectedSongPosition;
    public int SelectedTabPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_select);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        selectedSongPosition = -1;
        SelectedTabPosition = 0;
        apiInterface = APIClient.getClient().create(APIInterface.class);
        PutAnalyticsEvent();
        BindView();
        BannerAds();
        adListener();
        SetThemeSong();
    }

    private void SetThemeSong() {
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            GetSongCategory();
        } else {
            SetupDataInSongLayout(pref.getString("offlineResponse", ""));
        }
    }

    public void onStart() {
        super.onStart();
        mediaPlayer = new MediaPlayer();
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SetSong(SongModel songModel, int position) {
        selectedSongPosition = position;
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(Utils.INSTANCE.getMusicFolderPath() + songModel.getSongUrl());
            mediaPlayer.prepare();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void SongPlayPause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
        }
    }

    public boolean isSongPlay() {
        if (mediaPlayer.isPlaying()) {
            return true;
        }
        mediaPlayer.isPlaying();
        return false;
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SongSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        ivBack = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song_online);
        viewPager = findViewById(R.id.vp_song_online);
        layoutSongSdCard = findViewById(R.id.ll_from_storage);
        rlLoadingTheme = findViewById(R.id.rl_load_song_online);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
    }

    private void adListener() {
        layoutSongSdCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, PhoneSongActivity.class), 101);
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetSongCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerSong() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayoutSong() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
        }
        LinearLayout linearLayout = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.ll_tab_main);
        linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));
                selectedSongPosition = -1;
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.round_background));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                    linearLayout.setBackground(getResources().getDrawable(R.drawable.bg_tab_selected));
                }
            }
        });
    }


    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        final StringBuilder sb = new StringBuilder();
        sb.append("onlinemusic act onact result requestcode ");
        sb.append(n);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("onlinemusic act onact result resultcode ");
        sb2.append(n2);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            intent.getExtras().getString("audio_path");
            UnityPlayer.UnitySendMessage("WavyThemeData", "LoadMusic", intent.getExtras().getString("audio_path"));
            this.setResult(-1);
            this.finish();
        }
    }

    private void GetSongCategory() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineCategory(activity, jsonObj.toString(), "offlineResponse");
                        //Set Response Time
                        SetOfflineResponseTime(activity, new Date(), "offlineResponseTime");
                        SetupDataInSongLayout(jsonObj.toString());
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                rlLoadingTheme.setVisibility(View.GONE);
            }
        });
    }

    private void SetupDataInSongLayout(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
//            AppConstant.SoundUrlWavy = jsonObj.getString("souns_url");
            JSONArray jsonArray = jsonObj.getJSONArray("category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject songJSONObject = jsonArray.getJSONObject(i);
                String CategoryId = songJSONObject.getString("id");
                SetOfflineCategory(activity, songJSONObject.toString(), "Wavy" + CategoryId);
                SongCatModel songCatModel = new SongCatModel();
                songCatModel.setSongCatId(songJSONObject.getString("id"));
                songCatModel.setSongCatName(songJSONObject.getString("name"));
                SongList.add(songCatModel);
            }
            setUpPagerSong();
            SetTabLayoutSong();
            rlLoadingTheme.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return (SongByCatFragment.getInstance(Integer.parseInt(SongList.get(position).getSongCatId()), position));
        }

        @Override
        public int getCount() {
            return SongList.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.row_song_cat, null);
            TextView tv = tab.findViewById(R.id.custom_text);
            tv.setText(SongList.get(position).getSongCatName());
            return tab;
        }
    }


    private void SetOfflineCategory(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineResponseTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    public void onBackPressed() {
        super.onBackPressed();
        UnityPlayer.UnitySendMessage("WavyThemeData", "PlayMainMusic", "");
    }
}