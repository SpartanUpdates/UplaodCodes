package com.example.postermaker.textitems;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.postermaker.R;
import com.example.postermaker.eaz_EditActivity;
import com.makeramen.roundedimageview.RoundedImageView;


public class eaz_TextGradient implements View.OnClickListener {
    Context context;
    int f9l;
    public String[] fonts;
    public int[] gradientitems;
    public int[] textures;
    char type;

    public eaz_TextGradient(final Context context, final int f9l, final char type) {
        this.fonts = new String[]{"f1.ttf", "f2.ttf", "f3.ttf", "f4.ttf", "f5.ttf", "f6.ttf", "f7.ttf", "f8.ttf", "f9.ttf", "f10.ttf", "f11.ttf", "f12.ttf", "f13.ttf", "f14.ttf", "f15.ttf", "f16.ttf", "f17.ttf", "f18.ttf", "f19.ttf", "f20.ttf", "f21.ttf", "f22.ttf", "f23.ttf", "f24.ttf", "f25.ttf", "f26.ttf", "f27.ttf", "f28.ttf", "f29.ttf", "f30.ttf", "f31.ttf", "f32.ttf", "f33.ttf", "f34.ttf", "f35.ttf", "f36.ttf", "f37.ttf", "f38.ttf", "f39.ttf", "f40.ttf", "f41.ttf", "f42.ttf", "f43.ttf", "f44.ttf", "f45.ttf", "f46.ttf", "f47.ttf", "f48.ttf", "f49.ttf", "f50.ttf", "f51.ttf", "f52.ttf", "f53.ttf", "f54.ttf", "f55.ttf", "f56.ttf", "f57.ttf", "f58.ttf", "f59.ttf", "f60.ttf", "f61.ttf", "f62.ttf", "f63.ttf", "f64.ttf", "f65.ttf", "f66.ttf", "f66.ttf", "f67.ttf", "f68.ttf", "f69.ttf", "f70.ttf", "f71.ttf", "f72.ttf", "f73.ttf", "f74.ttf", "f75.ttf", "f76.ttf", "f77.ttf", "f78.ttf", "f78.ttf", "f79.ttf", "f80.ttf", "f81.ttf", "f82.ttf", "f83.ttf", "f84.ttf", "f85.ttf", "f86.ttf", "f88.ttf", "f89.ttf", "f90.ttf", "f91.ttf", "f92.ttf", "f93.ttf", "f94.ttf", "f95.ttf", "f96.ttf", "f97.ttf", "f98.ttf", "f99.ttf", "f100.ttf"};
        gradientitems = new int[]{R.drawable.color_preset_1, R.drawable.color_preset_2, R.drawable.color_preset_3, R.drawable.color_preset_4, R.drawable.color_preset_5, R.drawable.color_preset_6, R.drawable.color_preset_7, R.drawable.color_preset_8, R.drawable.color_preset_9, R.drawable.color_preset_10, R.drawable.color_preset_11, R.drawable.color_preset_12, R.drawable.color_preset_13, R.drawable.color_preset_14, R.drawable.color_preset_15, R.drawable.color_preset_16, R.drawable.color_preset_17, R.drawable.color_preset_18, R.drawable.color_preset_19, R.drawable.color_preset_20, R.drawable.color_preset_21, R.drawable.color_preset_22, R.drawable.color_preset_23, R.drawable.color_preset_24, R.drawable.color_preset_25, R.drawable.color_preset_26, R.drawable.color_preset_27, R.drawable.color_preset_28, R.drawable.color_preset_29, R.drawable.color_preset_30, R.drawable.gradient_1, R.drawable.gradient_2, R.drawable.gradient_3, R.drawable.gradient_4, R.drawable.gradient_5, R.drawable.gradient_6, R.drawable.gradient_7, R.drawable.gradient_8, R.drawable.gradient_9, R.drawable.gradient_10, R.drawable.gradient_11, R.drawable.gradient_12, R.drawable.gradient_13, R.drawable.gradient_14, R.drawable.gradient_15, R.drawable.gradient_16, R.drawable.gradient_17, R.drawable.gradient_18, R.drawable.gradient_19, R.drawable.gradient_20, R.drawable.gradient_21, R.drawable.gradient_22, R.drawable.gradient_23, R.drawable.gradient_24, R.drawable.gradient_25, R.drawable.gradient_26, R.drawable.gradient_27, R.drawable.gradient_28, R.drawable.gradient_29, R.drawable.gradient_30, R.drawable.gradient_31, R.drawable.gradient_32, R.drawable.gradient_33};
        this.f9l = 0;
        textures = new int[]{R.drawable.pattern_bg_1, R.drawable.pattern_bg_2, R.drawable.pattern_bg_3, R.drawable.pattern_bg_4, R.drawable.pattern_bg_5, R.drawable.pattern_bg_6, R.drawable.pattern_bg_7, R.drawable.pattern_bg_8, R.drawable.pattern_bg_9, R.drawable.pattern_bg_10, R.drawable.pattern_bg_11, R.drawable.pattern_bg_12, R.drawable.pattern_bg_13, R.drawable.pattern_bg_14, R.drawable.pattern_bg_15, R.drawable.pattern_bg_16, R.drawable.pattern_bg_17, R.drawable.pattern_bg_18, R.drawable.pattern_bg_19, R.drawable.pattern_bg_20, R.drawable.pattern_bg_21, R.drawable.pattern_bg_22, R.drawable.pattern_bg_23, R.drawable.pattern_bg_24, R.drawable.pattern_bg_25, R.drawable.pattern_bg_26, R.drawable.pattern_bg_27, R.drawable.pattern_bg_28, R.drawable.pattern_bg_29, R.drawable.pattern_bg_30, R.drawable.pattern_bg_31, R.drawable.pattern_bg_32, R.drawable.pattern_bg_33, R.drawable.pattern_bg_34, R.drawable.pattern_bg_35, R.drawable.pattern_bg_36, R.drawable.pattern_bg_37, R.drawable.pattern_bg_38, R.drawable.pattern_bg_39, R.drawable.pattern_bg_40, R.drawable.pattern_bg_41, R.drawable.pattern_bg_42, R.drawable.pattern_bg_43, R.drawable.pattern_bg_44, R.drawable.pattern_bg_45, R.drawable.pattern_bg_46, R.drawable.pattern_bg_47, R.drawable.pattern_bg_48, R.drawable.pattern_bg_49, R.drawable.pattern_bg_50, R.drawable.pattern_bg_51, R.drawable.pattern_bg_52, R.drawable.pattern_bg_53, R.drawable.pattern_bg_54, R.drawable.pattern_bg_55, R.drawable.pattern_bg_56, R.drawable.pattern_bg_57, R.drawable.pattern_bg_58, R.drawable.pattern_bg_59, R.drawable.pattern_bg_60, R.drawable.pattern_bg_61, R.drawable.pattern_bg_62, R.drawable.pattern_bg_63, R.drawable.pattern_bg_64, R.drawable.pattern_bg_65, R.drawable.pattern_bg_66, R.drawable.pattern_bg_67, R.drawable.pattern_bg_68, R.drawable.pattern_bg_69, R.drawable.pattern_bg_70, R.drawable.pattern_bg_71, R.drawable.pattern_bg_72, R.drawable.pattern_bg_73, R.drawable.pattern_bg_74, R.drawable.pattern_bg_75, R.drawable.pattern_bg_76, R.drawable.pattern_bg_77, R.drawable.pattern_bg_78, R.drawable.pattern_bg_79, R.drawable.pattern_bg_80, R.drawable.pattern_bg_81, R.drawable.pattern_bg_82, R.drawable.pattern_bg_83, R.drawable.pattern_bg_84, R.drawable.pattern_bg_85};
        this.type = 'G';
        this.context = context;
        this.f9l = f9l;
        this.type = type;
    }

    public void circularImageView(final RoundedImageView roundedImageView, final int n, final int n2) {

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                ViewGroup.MarginLayoutParams.MATCH_PARENT,
                ViewGroup.MarginLayoutParams.WRAP_CONTENT
        );
        marginLayoutParams.setMargins(10, 10, 10, 10);
        roundedImageView.setPadding(1, 1, 1, 1);
        roundedImageView.setLayoutParams(marginLayoutParams);

        roundedImageView.setLayoutParams((ViewGroup.LayoutParams) new ViewGroup.LayoutParams(55, 55));
        roundedImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        roundedImageView.setCornerRadius(10.0f);
        roundedImageView.setBorderWidth(2.0f);
        roundedImageView.setBorderColor(-12303292);
        roundedImageView.mutateBackground(true);
        roundedImageView.setImageDrawable(ContextCompat.getDrawable(this.context, n2));
        roundedImageView.setOval(true);
        roundedImageView.setTileModeX(Shader.TileMode.REPEAT);
        roundedImageView.setTileModeY(Shader.TileMode.REPEAT);
    }

    public void loadFonts() {
        eaz_EditActivity.colorlayoutgradeint.removeAllViews();
        for (int i = 0; i < this.fonts.length; ++i) {
            final TextView textView = new TextView(this.context);
            textView.setText((CharSequence) " Company ");
            textView.setTextSize(30.0f);
            textView.setTypeface(Typeface.createFromAsset(this.context.getAssets(), this.fonts[i]));
            int finalI = i;
            textView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                public void onClick(final View view) {
                    eaz_EditActivity.logoText.setTypeface(Typeface.createFromAsset(eaz_TextGradient.this.context.getAssets(), eaz_TextGradient.this.fonts[finalI]));
                }
            });
            eaz_EditActivity.colorlayoutgradeint.addView((View) textView);
        }
    }

    public void loadGradients() {
        final int f9l = this.f9l;
        int i = 0;
        int n;
        if (f9l == 0) {
            n = this.gradientitems.length;
        } else if (f9l == 1) {
            n = this.textures.length;
        } else {
            n = 0;
        }
        eaz_EditActivity.colorlayoutgradeint.removeAllViews();
        while (i < n) {
            final RoundedImageView roundedImageView = new RoundedImageView(this.context);
            final int f9l2 = this.f9l;
            if (f9l2 == 0) {
                this.circularImageView(roundedImageView, -16777216, this.gradientitems[i]);
            } else if (f9l2 == 1) {
                this.circularImageView(roundedImageView, -16777216, this.textures[i]);
            }
            int finalI = i;
            roundedImageView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                public void onClick(final View view) {
                    Bitmap bitmap;
                    if (eaz_TextGradient.this.f9l == 0) {
                        bitmap = BitmapFactory.decodeResource(eaz_TextGradient.this.context.getResources(), eaz_TextGradient.this.gradientitems[finalI]);
                    } else if (eaz_TextGradient.this.f9l == 1) {
                        bitmap = BitmapFactory.decodeResource(eaz_TextGradient.this.context.getResources(), eaz_TextGradient.this.textures[finalI]);
                    } else {
                        bitmap = null;
                    }
                    final BitmapShader shader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT.REPEAT);
                    eaz_EditActivity.logoText.setLayerType(View.LAYER_TYPE_SOFTWARE, (Paint) null);
                    eaz_EditActivity.logoText.getPaint().setShader((Shader) shader);
                }
            });
            eaz_EditActivity.colorlayoutgradeint.addView((View) roundedImageView);
            ++i;
        }
    }

    public void onClick(final View view) {
        if (view.equals(eaz_EditActivity.okgradient)) {
            eaz_EditActivity.textgradientLayout.setVisibility(View.GONE);
            return;
        }
        if (view.equals(eaz_EditActivity.cancelgradient)) {
            eaz_EditActivity.textgradientLayout.setVisibility(View.GONE);
        }
    }

    public void showGradientLayout() {
        eaz_EditActivity.textgradientLayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.okgradient.setOnClickListener((View.OnClickListener) this);
        eaz_EditActivity.cancelgradient.setOnClickListener((View.OnClickListener) this);
        final char type = this.type;
        if (type == 'G') {
            this.loadGradients();
            return;
        }
        if (type == 'F') {
            this.loadFonts();
        }
    }
}
