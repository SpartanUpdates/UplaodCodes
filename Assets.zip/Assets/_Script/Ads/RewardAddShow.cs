﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;

public class RewardAddShow : MonoBehaviour
{
    public static RewardAddShow instance;

    [HideInInspector]
    public RewardBasedVideoAd rewardBasedVideo;

    public void Awake()
    {
        instance = this;
        DontDestroyOnLoad(this.gameObject);
        RequestRewardBasedVideo();
    }
    private void OnEnable()
    {
        this.rewardBasedVideo.OnAdLoaded += RewardBasedVideoLoaded;
        this.rewardBasedVideo.OnAdFailedToLoad += RewardBasedVideoFailedToLoad;
        this.rewardBasedVideo.OnAdOpening += RewardBasedVideoOpened;
        this.rewardBasedVideo.OnAdStarted += RewardBasedVideoStarted;
        this.rewardBasedVideo.OnAdRewarded += RewardBasedVideoRewarded;
        this.rewardBasedVideo.OnAdClosed += RewardBasedVideoClosed;
        this.rewardBasedVideo.OnAdLeavingApplication += RewardBasedVideoLeftApplication;
    }
    private void OnDisable()
    {
        this.rewardBasedVideo.OnAdLoaded -= RewardBasedVideoLoaded;
        this.rewardBasedVideo.OnAdFailedToLoad -= RewardBasedVideoFailedToLoad;
        this.rewardBasedVideo.OnAdOpening -= RewardBasedVideoOpened;
        this.rewardBasedVideo.OnAdStarted -= RewardBasedVideoStarted;
        this.rewardBasedVideo.OnAdRewarded -= RewardBasedVideoRewarded;
        this.rewardBasedVideo.OnAdClosed -= RewardBasedVideoClosed;
        this.rewardBasedVideo.OnAdLeavingApplication -= RewardBasedVideoLeftApplication;
    }

    public void RequestRewardBasedVideo()
    {
        rewardBasedVideo = RewardBasedVideoAd.Instance;

        AdRequest request = new AdRequest.Builder().Build();

        rewardBasedVideo.LoadAd(request, Manager.instance.RewardID);
    }

    public void ShowVideo()
    {
        if (rewardBasedVideo.IsLoaded())
        {
            rewardBasedVideo.Show();
        }
        else
        {
            RequestRewardBasedVideo();
        }
    }

    bool isVideoSkip = true;

    public void RewardBasedVideoLoaded(object sender, EventArgs args)
    {

    }

    public void RewardBasedVideoFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {

    }

    public void RewardBasedVideoOpened(object sender, EventArgs args)
    {
    }

    public void RewardBasedVideoStarted(object sender, EventArgs args)
    {
    }

    public void RewardBasedVideoClosed(object sender, EventArgs args)
    {
        if (!isVideoSkip)
        {
            if (PlayerSelection.instane != null)
            {
                if (PlayerSelection.instane.isRewardClick)
                {
                    PlayerSelection.instane.isRewardDone = true;
                    PlayerSelection.instane.RewardDone();
                }
            }
            if (GameManager.instance != null)
            {
                if (GameManager.instance.isRewardCoinClick)
                {
                    GameManager.instance.isRewardCoinDone = true;
                    GameManager.instance.RewardDone();
                }
                else if (GameManager.instance.isRewardSaveClick)
                {
                    GameManager.instance.isRewardSaveDone = true;
                    GameManager.instance.SaveMeDone();
                }
            }
            if (GiftRoom.instance != null)
            {
                if (GiftRoom.instance.isRewardKeyClick)
                {
                    GiftRoom.instance.isRewardKeyDone = true;
                    GiftRoom.instance.RewardDone();
                }
            }
        }
        else
        {
            if (PlayerSelection.instane != null)
            {
                if (PlayerSelection.instane.isRewardClick)
                {
                    PlayerSelection.instane.isRewardDone = false;
                    PlayerSelection.instane.RewardDone();
                }
            }
            if (GameManager.instance != null)
            {
                if (GameManager.instance.isRewardCoinClick)
                {
                    GameManager.instance.isRewardCoinDone = false;
                    GameManager.instance.RewardDone();
                }else if (GameManager.instance.isRewardSaveClick)
                {
                    GameManager.instance.isRewardSaveDone = false;
                    GameManager.instance.SaveMeDone();
                }
            }
            if (GiftRoom.instance != null)
            {
                if (GiftRoom.instance.isRewardKeyClick)
                {
                    GiftRoom.instance.isRewardKeyDone = false;
                    GiftRoom.instance.RewardDone();
                }
            }

        }
        isVideoSkip = true;
        RequestRewardBasedVideo();
    }

    public void RewardBasedVideoRewarded(object sender, Reward args)
    {
        isVideoSkip = false;
    }

    public void RewardBasedVideoLeftApplication(object sender, EventArgs args)
    {
    }
}
