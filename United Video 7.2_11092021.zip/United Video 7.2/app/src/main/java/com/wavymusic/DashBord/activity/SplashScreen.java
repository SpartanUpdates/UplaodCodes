package com.wavymusic.DashBord.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.wavymusic.R;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
    }
}