package com.claptoflashlightonoff.util;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;

import com.example.speaktourchtight.R;

public class SoundHandler {
    private static MediaPlayer mPlayerSound;

    private SoundHandler() {
    }

    public static void playToggleSound(Context context) {
        mPlayerSound = MediaPlayer.create(context, R.raw.sound_toggle);
        mPlayerSound.setOnCompletionListener(new OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mp.release();
            }
        });
        mPlayerSound.start();
    }
}
