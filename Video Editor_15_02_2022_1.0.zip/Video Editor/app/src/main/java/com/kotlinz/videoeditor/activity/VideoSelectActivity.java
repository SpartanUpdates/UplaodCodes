package com.kotlinz.videoeditor.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.kotlinz.videoeditor.Adapter.AlbumAdapterById;
import com.kotlinz.videoeditor.Adapter.VideoByAlbumAdapter;
import com.kotlinz.videoeditor.Interface.OnItemClickListner;
import com.kotlinz.videoeditor.Model.VideoModel;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.videocutter.VideoCutterActivity;
import com.kotlinz.videoeditor.videojoiner.activity.VideoJoinerActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.List;

public class VideoSelectActivity extends AppCompatActivity {

    Activity activity = VideoSelectActivity.this;

    private MyApplication application;

    ImageView ivBack, ivDone;

    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    private AlbumAdapterById albumAdapter;
    private VideoByAlbumAdapter albumImagesAdapter;
    private String IsVideoFrom;
    public static String Name;
    private ArrayList<VideoModel> mModelList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_select);
        application = MyApplication.getInstance();
        IsVideoFrom = getIntent().getStringExtra("IsVideoFrom");
        Name = IsVideoFrom;
        PutAnalyticsEvent();
        application.init();
        Init();
        CallListener();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void Init() {
        ivBack = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        rvAlbum = findViewById(R.id.rvAlbum);
        rvAlbumImages = findViewById(R.id.rvImageAlbum);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        albumAdapter = new AlbumAdapterById(activity);
        albumImagesAdapter = new VideoByAlbumAdapter(activity, getListData());

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        rvAlbum.setLayoutManager(mLayoutManager);
        rvAlbum.setItemAnimator(new DefaultItemAnimator());
        rvAlbum.setAdapter(albumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(getApplicationContext(), 3);
        rvAlbumImages.setLayoutManager(gridLayputManager);
        rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumImages.setAdapter(albumImagesAdapter);
    }

    private List<VideoModel> getListData() {
        mModelList = new ArrayList<>();
        for (int i = 1; i <= mModelList.size(); i++) {
            mModelList.add(new VideoModel(i));
        }
        return mModelList;
    }

    private void CallListener() {
        ivDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (IsVideoFrom.equals("Single")) {
                    if (application.getSelectedVideo().size() != 0) {
                        int i = 0;
                        for (final VideoModel videoModel : application.getSelectedVideo()) {
                            Intent intent = new Intent(activity, VideoCutterActivity.class);
                            intent.putExtra("path", videoModel.getImagePath());
                            startActivity(intent);
                            ++i;
                            finish();
                        }
                    } else {
                        Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                    }
                } else if (IsVideoFrom.equals("MergeVideo")) {
                    if (VideoByAlbumAdapter.count > 1) {
                        if (application.getSelectedVideo().size() != 0) {
                            int i = 0;
                            for (final VideoModel videoModel : application.getSelectedVideo()) {
                                Intent intent = new Intent(activity, VideoJoinerActivity.class);
                                intent.putExtra("path", videoModel.getImagePath());
                                startActivity(intent);
                                ++i;
                                finish();
                            }
                        } else {
                            Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Select Minimum two Videos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        albumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumImagesAdapter.notifyDataSetChanged();
            }
        });

        albumImagesAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, StartActivity.class));
        finish();
    }
}