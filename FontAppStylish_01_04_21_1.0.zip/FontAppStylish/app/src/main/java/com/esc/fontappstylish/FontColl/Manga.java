package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Manga implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"卂", "乃", "匚", "ᗪ", "乇", "千", "ᘜ", "卄", "|", "ﾌ", "Ҝ", "ㄥ", "爪", "几", "ㄖ", "卩", "Ҩ", "尺", "丂", "ㄒ", "ㄩ", "ᐯ", "山", "乂", "ㄚ", "乙"};
    }

    public String getName() {
        return "卂乃匚";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"卂", "乃", "匚", "ᗪ", "乇", "千", "ᘜ", "卄", "|", "ﾌ", "Ҝ", "ㄥ", "爪", "几", "ㄖ", "卩", "Ҩ", "尺", "丂", "ㄒ", "ㄩ", "ᐯ", "山", "乂", "ㄚ", "乙"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
