package com.esc.socialmediacleaner.datastructure;

public class FileDataWrapper {
    public String ext;
    public boolean ischecked;
    public long lastModified;
    public String name;
    public String path;
    public PathType pathType;
    public long size;
    public SocialAppType socialAppType;
    public MediaType type;
}
