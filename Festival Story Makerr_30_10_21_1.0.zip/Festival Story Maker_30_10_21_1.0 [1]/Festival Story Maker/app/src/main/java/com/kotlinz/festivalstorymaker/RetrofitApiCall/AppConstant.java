package com.kotlinz.festivalstorymaker.RetrofitApiCall;

public class AppConstant {

    public static String BaseUrl = "http://sociallyapp.trendinganimations.com/public/api/";
    public static String token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "35";

    public static int CollageBackgroundId = 59;

}
