package com.mbit.VideoMaker.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.mbit.VideoMaker.Activity.HomeActivity;
import com.mbit.VideoMaker.Adapter.ThemeCategoryWiseAdapter;
import com.mbit.VideoMaker.AllData.GetUrl;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Model.ThemelModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.application.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import javax.net.ssl.HttpsURLConnection;


public class CategoryWiseThemeFragment extends Fragment {

    public int id;
    //    public String ThemeCategoryWiseDataUrl = a.ThemeCategoryWiseDataUrl;
    public String ThemeCategoryWiseDataUrl = GetUrl.m;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    String offlienResopnseData;
    //    SharedPreferences ThemeCategoryPreference;
//    String MY_PREF = "Cat_home_preference";
    //    private boolean IsofflineResopnse = false;
    int AppId = -1;
    int CategoryId = -1;
    SharedPreferences pref;
    GridLayoutManager gridLayoutManager;
    long timestamps;
    Date date = new Date();
    SwipeRefreshLayout mSwipeRefreshLayout;
    private String CatId;
    private ArrayList<ThemelModel> ThemeListCategoryWise = new ArrayList<>();
    private ThemeCategoryWiseAdapter themeAdapter;
    private MyApplication application;

    public static CategoryWiseThemeFragment newInstance(int catid, int Appid) {
        CategoryWiseThemeFragment fragment = new CategoryWiseThemeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        bundle.putInt("AppId", Appid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            AppId = getArguments().getInt("AppId");
            CategoryId = getArguments().getInt("CategoryId");
            CatId = String.valueOf(CategoryId);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_wise_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        application = MyApplication.getInstance();
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (Utils.checkConnectivity(getActivity(), false)) {
                String id = pref.getString(String.valueOf(CategoryId), null);
                if (id != null && !id.equals("")) {
                    getOfflineCategory(getActivity(), String.valueOf(CategoryId));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        if (offlienResopnseData != null && !Objects.isNull(timestamps)) {
                            if (Math.abs(System.currentTimeMillis() - timestamps) > 300000) {
                                new GetTabThemeCategory().execute(ThemeCategoryWiseDataUrl, String.valueOf(AppId), String.valueOf(CategoryId));
                            } else {
                                if (offlienResopnseData != null) {
                                    LoadOfflineData(offlienResopnseData);
                                }
                            }
                        }
                    } else {
                        new GetTabThemeCategory().execute(ThemeCategoryWiseDataUrl, String.valueOf(AppId), String.valueOf(CategoryId));
                    }

                } else {
                    new GetTabThemeCategory().execute(ThemeCategoryWiseDataUrl, String.valueOf(AppId), String.valueOf(CategoryId));
                }

            } else {
                String id = pref.getString(String.valueOf(CategoryId), null);
                if (id != null && !id.equals("")) {
                    getOfflineCategory(getActivity(), String.valueOf(CategoryId));
                    if (offlienResopnseData != null) {
                        LoadOfflineData(offlienResopnseData);
                    }
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }

        } else {
            SetUpAdapter();
        }

        return view;
    }

    private void BindView(View view) {
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    ThemeListCategoryWise.clear();
                    new GetTabThemeCategory().execute(ThemeCategoryWiseDataUrl, String.valueOf(AppId), String.valueOf(CategoryId));
                    mSwipeRefreshLayout.setRefreshing(false);
                } else {
                    mSwipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void SetOfflineCategory(Context c, String userObject, String key, final Date date) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.putLong(key + "_value", date.getTime());
        editor.apply();
    }

    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        themeAdapter = new ThemeCategoryWiseAdapter(getActivity(), ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append(" ");
                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();


            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (themeAdapter.getItemViewType(position)) {
                    case ThemeCategoryWiseAdapter.ITEM_TYPE_AD:
                        return 2;
                    case ThemeCategoryWiseAdapter.ITEM_TYPE_DATA:
                        return 1;
                    default:
                        return -1;
                }
            }
        });
        themeAdapter.notifyDataSetChanged();
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }


    private void LoadOfflineData(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                String id = jsonObject1.getString("Id");
                if (CatId != null) {
                    if (id.equals(CatId)) {
                        JSONArray themeArray = new JSONArray(jsonArray.getJSONObject(i).getString("themes"));
                        for (int j = 0; j < themeArray.length(); j++) {
                            JSONObject themeJSONObject = themeArray.getJSONObject(j);
//                            Log.e("TAG", "offline ThemeData" + themeArray.getJSONObject(j));
                            ThemelModel themeModel = new ThemelModel();
                            themeModel.setThemeid(themeJSONObject.getString("Id"));
                            themeModel.setCategoryid(themeJSONObject.getString("Cat_Id"));
                            themeModel.setThemeName(themeJSONObject.getString("Theme_Name"));
                            themeModel.setImage(themeJSONObject.getString("Thumnail_Big"));
                            themeModel.setAnimsoundurl(themeJSONObject.getString("SoundFile"));
                            String SoundName = themeModel.getAnimsoundurl().substring(themeModel.getAnimsoundurl().lastIndexOf('/') + 1);
                            themeModel.setAnimSoundname(SoundName);
                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + SoundName);
                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + SoundName);
                            themeModel.setAnimSoundfilesize(Integer.parseInt(themeJSONObject.getString("sound_size")));
                            themeModel.setGameobjectName(themeJSONObject.getString("GameobjectName"));
                            themeModel.setNewRealise(themeJSONObject.getBoolean("isNewRealise"));
//                            themeModel.setThemeCounter(("0"));
                            ThemeListCategoryWise.add(themeModel);
                            if (application.IsNativeAdsLoaded) {
                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                    themeModel.setNativeAds(true);
                                    ThemeListCategoryWise.add(themeModel);
                                }
                            }
                        }
                    }
                    SetUpAdapter();
                }
            }


           /* JSONObject jsonObj = new JSONObject(result);
            JSONArray jsonArray = jsonObj.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                ThemelModel themeModel = new ThemelModel();
                themeModel.setThemeid(themeJSONObject.getString("Id"));
                themeModel.setCategoryid(themeJSONObject.getString("Cat_Id"));
                themeModel.setThemeName(themeJSONObject.getString("Theme_Name"));
                themeModel.setImage(themeJSONObject.getString("Thumnail_Big"));
                themeModel.setAnimsoundurl(themeJSONObject.getString("SoundFile"));
                themeModel.setAnimSoundname(themeJSONObject.getString("SoundName") + ".mp3");
                themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + themeJSONObject.getString("SoundName") + ".mp3");
                themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + themeJSONObject.getString("SoundName") + ".mp3");
                themeModel.setAnimSoundfilesize(Integer.parseInt(themeJSONObject.getString("sound_size")));
                themeModel.setGameobjectName(themeJSONObject.getString("GameobjectName"));
                themeModel.setThemeCounter(("0"));
                ThemeListCategoryWise.add(themeModel);
                if (application.IsNativeAdsLoaded) {
                    if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                        themeModel.setNativeAds(true);
                        ThemeListCategoryWise.add(themeModel);
                    }
                }
            }
            SetUpAdapter();*/
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class GetTabThemeCategory extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("Application_Id", arg0[1]);
//                postDataParams.put("Category_Id", arg0[2]);
//                CatId = arg0[2];
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return "false : " + responseCode;
                }
            } catch (Exception e) {
                return "Exception: " + e.getMessage();
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    if (getActivity() != null) {
                        SetOfflineCategory(getActivity(), jsonObject.toString(), CatId, date);
                    }
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String id = jsonObject1.getString("Id");
                        if (CatId != null) {
                            if (id.equals(CatId)) {
                                JSONArray themeArray = new JSONArray(jsonArray.getJSONObject(i).getString("themes"));
                                for (int j = 0; j < themeArray.length(); j++) {
                                    JSONObject themeJSONObject = themeArray.getJSONObject(j);
                                    ThemelModel themeModel = new ThemelModel();
                                    themeModel.setThemeid(themeJSONObject.getString("Id"));
                                    themeModel.setCategoryid(themeJSONObject.getString("Cat_Id"));
                                    themeModel.setThemeName(themeJSONObject.getString("Theme_Name"));
                                    themeModel.setImage(themeJSONObject.getString("Thumnail_Big"));
                                    themeModel.setAnimsoundurl(themeJSONObject.getString("SoundFile"));
                                    String SoundName = themeModel.getAnimsoundurl().substring(themeModel.getAnimsoundurl().lastIndexOf('/') + 1);
                                    themeModel.setAnimSoundname(SoundName);
                                    themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + SoundName);
                                    themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + SoundName);
                                    themeModel.setAnimSoundfilesize(Integer.parseInt(themeJSONObject.getString("sound_size")));
                                    themeModel.setGameobjectName(themeJSONObject.getString("GameobjectName"));
                                    themeModel.setNewRealise(themeJSONObject.getBoolean("isNewRealise"));
//                                    Log.e("TAG", "isNewRealise" + themeJSONObject.getBoolean("isNewRealise"));
//                                    themeModel.setThemeCounter(("0"));
                                    ThemeListCategoryWise.add(themeModel);
                                    if (application.IsNativeAdsLoaded) {
                                        if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                            themeModel.setNativeAds(true);
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                    }
                                }
                                SetUpAdapter();
                            }
                        }

                    }

                  /*  JSONObject jsonObj = new JSONObject(result);
                    if (getActivity() != null) {
                        SetOfflineCategory(getActivity(), jsonObj.toString(), CatId, date);
                    }
                    JSONArray jsonArray = jsonObj.getJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                        ThemelModel themeModel = new ThemelModel();
                        themeModel.setThemeid(themeJSONObject.getString("Id"));
                        themeModel.setCategoryid(themeJSONObject.getString("Cat_Id"));
                        themeModel.setThemeName(themeJSONObject.getString("Theme_Name"));
                        themeModel.setImage(themeJSONObject.getString("Thumnail_Big"));
                        themeModel.setAnimsoundurl(themeJSONObject.getString("SoundFile"));
                        themeModel.setAnimSoundname(themeJSONObject.getString("SoundName") + ".mp3");
                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + themeJSONObject.getString("SoundName") + ".mp3");
                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + themeJSONObject.getString("SoundName") + ".mp3");
                        themeModel.setAnimSoundfilesize(Integer.parseInt(themeJSONObject.getString("sound_size")));
                        themeModel.setGameobjectName(themeJSONObject.getString("GameobjectName"));
                        themeModel.setThemeCounter(("0"));
                        ThemeListCategoryWise.add(themeModel);
                        if (application.IsNativeAdsLoaded) {
                            if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                themeModel.setNativeAds(true);
                                ThemeListCategoryWise.add(themeModel);
                            }
                        }
                    }
                    SetUpAdapter();*/
                    rlLoadingTheme.setVisibility(View.GONE);
                } catch (final JSONException e) {
                    e.printStackTrace();
                }
            } else {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getActivity(), "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }

}
