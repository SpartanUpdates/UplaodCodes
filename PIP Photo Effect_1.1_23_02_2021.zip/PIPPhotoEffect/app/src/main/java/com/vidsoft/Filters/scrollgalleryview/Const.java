package com.vidsoft.Filters.scrollgalleryview;

public class Const {
    public static final String IMAGE = "image";
    public static final String IS_LOCKED = "isLocked";
    public static final String ZOOM = "zoom";
}
