package com.MV.Lyrics.videolib.libffmpeg;

import android.content.Context;
import android.os.AsyncTask;

import java.io.File;

class FFmpegLoadLibraryAsyncTask
  extends AsyncTask<Void, Void, Boolean>
{
  private final String cpuArchNameFromAssets;
  private final FFmpegLoadBinaryResponseHandler ffmpegLoadBinaryResponseHandler;
  private final Context context;
  
  FFmpegLoadLibraryAsyncTask(Context context, String cpuArchNameFromAssets, FFmpegLoadBinaryResponseHandler ffmpegLoadBinaryResponseHandler)
  {
    this.context = context;
    this.cpuArchNameFromAssets = cpuArchNameFromAssets;
    this.ffmpegLoadBinaryResponseHandler = ffmpegLoadBinaryResponseHandler;
  }
  
  protected Boolean doInBackground(Void... params) {
    File ffmpegFile = new File(FileUtils.getFFmpeg(context));
    if ((ffmpegFile.exists()) && (isDeviceFFmpegVersionOld()) && 
      (!ffmpegFile.delete())) {
      return Boolean.valueOf(false);
    }
    if (!ffmpegFile.exists())
    {



      boolean isFileCopied = FileUtils.copyBinaryFromSDCardToData(
        context, String.valueOf(cpuArchNameFromAssets) + 
        File.separator + "ffmpeg", "ffmpeg");
      
      if (isFileCopied) {
        if (ffmpegFile.canExecute()) {
          return Boolean.valueOf(true);
        }
        if (ffmpegFile.setExecutable(true)) {
          return Boolean.valueOf(true);
        }
      }
    }
    if ((ffmpegFile.exists()) && (ffmpegFile.canExecute())) {
      return Boolean.valueOf(true);
    }
    return Boolean.valueOf(false);
  }
  
  protected void onPostExecute(Boolean isSuccess) {
    super.onPostExecute(isSuccess);
    if (ffmpegLoadBinaryResponseHandler != null) {
      if (isSuccess.booleanValue()) {
        ffmpegLoadBinaryResponseHandler.onSuccess();
        ffmpegLoadBinaryResponseHandler
          .onSuccess(cpuArchNameFromAssets);
      } else {
        ffmpegLoadBinaryResponseHandler.onFailure();
        ffmpegLoadBinaryResponseHandler
          .onFailure(cpuArchNameFromAssets);
      }
      ffmpegLoadBinaryResponseHandler.onFinish();
    }
  }
  
  private boolean isDeviceFFmpegVersionOld() {
    return 
      CpuArch.fromString(FileUtils.SHA1(FileUtils.getFFmpeg(context))).equals(
      CpuArch.NONE);
  }
}
