package com.esc.storymaker.utils;

import com.esc.storymaker.R;

import java.util.LinkedHashMap;

public class ContractsUtil {
    public static LinkedHashMap<Integer, Integer> mainTabIcons = new LinkedHashMap();
    public static LinkedHashMap<String, String> templateCategories = new LinkedHashMap();
    private static LinkedHashMap<String, Integer> templates;
    public static LinkedHashMap<String, String> vignetteContracts = new LinkedHashMap();

    static {
        mainTabIcons.put(Integer.valueOf(R.drawable.ic_template_dark_grey), Integer.valueOf(R.drawable.ic_template_grey));
        mainTabIcons.put(Integer.valueOf(R.drawable.ic_mystory_dark_grey), Integer.valueOf(R.drawable.ic_mystory_grey));
        mainTabIcons.put(Integer.valueOf(R.drawable.ic_draft_dark_grey), Integer.valueOf(R.drawable.ic_draft_grey));
        templateCategories.put("Simple", "#ea8f7b");
        templateCategories.put("Brush", "#e0bd85");
        templateCategories.put("Pinpur", "#7a84d1");
        templateCategories.put("Birthday", "#F68100");
        templateCategories.put("Forests", "#8ebf56");
        templateCategories.put("Vintage", "#ddb16e");
        templateCategories.put("Oceans", "#7cd7ed");
        templateCategories.put("Candy", "#FFA4CD");
        templateCategories.put("Summer", "#fbc02d");
        templateCategories.put("Roundel", "#C0CBD5");
        templateCategories.put("JShine", "#c471ed");
        templateCategories.put("Mothers Day", "#92505e");
        templateCategories.put("Islamic Holidays", "#7dce3b");
        templateCategories.put("Christmas", "#5EA9BE");
        templateCategories.put("White Christmas", "#CBE1EF");
        templateCategories.put("Danyah", "#424242");
        templateCategories.put("Love", "#e76565");
        templateCategories.put("Deserts", "#D4BBB2");
        templateCategories.put("Clean", "#cecece");
        vignetteContracts.put("Mayfair", "100x#000000x50");
        vignetteContracts.put("Amaro", "100x#4B5A82x80");
        vignetteContracts.put("Hudson", "50x#000000x100");
        vignetteContracts.put("Earlybird", "100x#000000x80");
        vignetteContracts.put("Nashville", "20x#000000x100");
    }

    public static LinkedHashMap<String, Integer> initTemplates(String str) {
        char c;
        templates = new LinkedHashMap<>();
        switch (str.hashCode()) {
            case -2096555199:
                if (str.equals("JShine")) {
                    c = 17;
                    break;
                }
            case -1938730155:
                if (str.equals("Oceans")) {
                    c = 15;
                    break;
                }
            case -1904277128:
                if (str.equals("Pinpur")) {
                    c = 3;
                    break;
                }
            case -1818419758:
                if (str.equals("Simple")) {
                    c = 0;
                    break;
                }
            case -1807340593:
                if (str.equals("Summer")) {
                    c = 14;
                    break;
                }
            case -1741740365:
                if (str.equals("Islamic Holidays")) {
                    c = 13;
                    break;
                }
            case -1244845419:
                if (str.equals("Roundel")) {
                    c = 16;
                    break;
                }
            case -1092594356:
                if (str.equals("Mothers Day")) {
                    c = 10;
                    break;
                }
            case -1073387810:
                if (str.equals("Deserts")) {
                    c = 7;
                    break;
                }
            case 2092848:
                if (str.equals("Card")) {
                    c = 9;
                    break;
                }
            case 2374546:
                if (str.equals("Love")) {
                    c = 5;
                    break;
                }
            case 64464666:
                if (str.equals("Brush")) {
                    c = 2;
                    break;
                }
            case 64874565:
                if (str.equals("Candy")) {
                    c = 4;
                    break;
                }
            case 65193513:
                if (str.equals("Clean")) {
                    c = 8;
                    break;
                }
            case 754039819:
                if (str.equals("White Christmas")) {
                    c = 12;
                    break;
                }
            case 986988502:
                if (str.equals("Forests")) {
                    c = 1;
                    break;
                }
            case 1134020253:
                if (str.equals("Birthday")) {
                    c = 18;
                    break;
                }
            case 1235317602:
                if (str.equals("Christmas")) {
                    c = 11;
                    break;
                }
            case 2039760207:
                if (str.equals("Danyah")) {
                    c = 6;
                    break;
                }
            case 2127105670:
                if (str.equals("Vintage")) {
                    c = 19;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                templates.put("template_simple_1", Integer.valueOf(R.layout.template_simple_1));
                templates.put("template_simple_2", Integer.valueOf(R.layout.template_simple_2));
                templates.put("template_simple_3", Integer.valueOf(R.layout.template_simple_3));
                templates.put("template_simple_4", Integer.valueOf(R.layout.template_simple_4));
                templates.put("template_simple_5", Integer.valueOf(R.layout.template_simple_5));
                templates.put("template_simple_6", Integer.valueOf(R.layout.template_simple_6));
                templates.put("template_simple_7", Integer.valueOf(R.layout.template_simple_7));
                templates.put("template_simple_8", Integer.valueOf(R.layout.template_simple_8));
                break;
            case 1:
                templates.put("template_forests_1", Integer.valueOf(R.layout.template_forests_1));
                templates.put("template_forests_2", Integer.valueOf(R.layout.template_forests_2));
                templates.put("template_forests_3", Integer.valueOf(R.layout.template_forests_3));
                templates.put("template_forests_4", Integer.valueOf(R.layout.template_forests_4));
                templates.put("template_forests_5", Integer.valueOf(R.layout.template_forests_5));
                templates.put("template_forests_6", Integer.valueOf(R.layout.template_forests_6));
                templates.put("template_forests_7", Integer.valueOf(R.layout.template_forests_7));
                templates.put("template_forests_8", Integer.valueOf(R.layout.template_forests_8));
                templates.put("template_forests_9", Integer.valueOf(R.layout.template_forests_9));
                templates.put("template_forests_a1", Integer.valueOf(R.layout.template_forests_a1));
                break;
            case 2:
                templates.put("template_brush_1", Integer.valueOf(R.layout.template_brush_1));
                templates.put("template_brush_2", Integer.valueOf(R.layout.template_brush_2));
                templates.put("template_brush_3", Integer.valueOf(R.layout.template_brush_3));
                templates.put("template_brush_4", Integer.valueOf(R.layout.template_brush_4));
                templates.put("template_brush_5", Integer.valueOf(R.layout.template_brush_5));
                templates.put("template_brush_6", Integer.valueOf(R.layout.template_brush_6));
                templates.put("template_brush_7", Integer.valueOf(R.layout.template_brush_7));
                templates.put("template_brush_8", Integer.valueOf(R.layout.template_brush_8));
                templates.put("template_brush_9", Integer.valueOf(R.layout.template_brush_9));
                templates.put("template_brush_a1", Integer.valueOf(R.layout.template_brush_a1));
                break;
            case 3:
                templates.put("template_pinpur_1", Integer.valueOf(R.layout.template_pinpur_1));
                templates.put("template_pinpur_2", Integer.valueOf(R.layout.template_pinpur_2));
                templates.put("template_pinpur_3", Integer.valueOf(R.layout.template_pinpur_3));
                templates.put("template_pinpur_4", Integer.valueOf(R.layout.template_pinpur_4));
                templates.put("template_pinpur_5", Integer.valueOf(R.layout.template_pinpur_5));
                templates.put("template_pinpur_6", Integer.valueOf(R.layout.template_pinpur_6));
                templates.put("template_pinpur_7", Integer.valueOf(R.layout.template_pinpur_7));
                templates.put("template_pinpur_8", Integer.valueOf(R.layout.template_pinpur_8));
                templates.put("template_pinpur_9", Integer.valueOf(R.layout.template_pinpur_9));
                break;
            case 4:
                templates.put("template_candy_1", Integer.valueOf(R.layout.template_candy_1));
                templates.put("template_candy_2", Integer.valueOf(R.layout.template_candy_2));
                templates.put("template_candy_3", Integer.valueOf(R.layout.template_candy_3));
                templates.put("template_candy_4", Integer.valueOf(R.layout.template_candy_4));
                templates.put("template_candy_5", Integer.valueOf(R.layout.template_candy_5));
                templates.put("template_candy_6", Integer.valueOf(R.layout.template_candy_6));
                templates.put("template_candy_7", Integer.valueOf(R.layout.template_candy_7));
                break;
            case 5:
                templates.put("template_love_2", Integer.valueOf(R.layout.template_love_2));
                templates.put("template_love_1", Integer.valueOf(R.layout.template_love_1));
                templates.put("template_love_3", Integer.valueOf(R.layout.template_love_3));
                templates.put("template_love_4", Integer.valueOf(R.layout.template_love_4));
                templates.put("template_love_5", Integer.valueOf(R.layout.template_love_5));
                templates.put("template_love_6", Integer.valueOf(R.layout.template_love_6));
                templates.put("template_love_7", Integer.valueOf(R.layout.template_love_7));
                templates.put("template_love_8", Integer.valueOf(R.layout.template_love_8));
                break;
            case 6:
                templates.put("template_danyah_1", Integer.valueOf(R.layout.template_danyah_1));
                templates.put("template_danyah_2", Integer.valueOf(R.layout.template_danyah_2));
                templates.put("template_danyah_3", Integer.valueOf(R.layout.template_danyah_3));
                templates.put("template_danyah_4", Integer.valueOf(R.layout.template_danyah_4));
                templates.put("template_danyah_5", Integer.valueOf(R.layout.template_danyah_5));
                templates.put("template_danyah_6", Integer.valueOf(R.layout.template_danyah_6));
                templates.put("template_danyah_7", Integer.valueOf(R.layout.template_danyah_7));
                templates.put("template_danyah_8", Integer.valueOf(R.layout.template_danyah_8));
                templates.put("template_danyah_9", Integer.valueOf(R.layout.template_danyah_9));
                break;
            case 7:
                templates.put("template_deserts_1", Integer.valueOf(R.layout.template_deserts_1));
                templates.put("template_deserts_2", Integer.valueOf(R.layout.template_deserts_2));
                templates.put("template_deserts_3", Integer.valueOf(R.layout.template_deserts_3));
                templates.put("template_deserts_4", Integer.valueOf(R.layout.template_deserts_4));
                templates.put("template_deserts_5", Integer.valueOf(R.layout.template_deserts_5));
                templates.put("template_deserts_6", Integer.valueOf(R.layout.template_deserts_6));
                templates.put("template_deserts_7", Integer.valueOf(R.layout.template_deserts_7));
                templates.put("template_deserts_8", Integer.valueOf(R.layout.template_deserts_8));
                break;
            case 8:
                templates.put("template_clean_1", Integer.valueOf(R.layout.template_clean_1));
                templates.put("template_clean_2", Integer.valueOf(R.layout.template_clean_2));
                templates.put("template_clean_3", Integer.valueOf(R.layout.template_clean_3));
                templates.put("template_clean_4", Integer.valueOf(R.layout.template_clean_4));
                templates.put("template_clean_5", Integer.valueOf(R.layout.template_clean_5));
                templates.put("template_clean_6", Integer.valueOf(R.layout.template_clean_6));
                templates.put("template_clean_7", Integer.valueOf(R.layout.template_clean_7));
                break;
            case 9:
                templates.put("template_card_1", Integer.valueOf(R.layout.template_card_1));
                templates.put("template_card_2", Integer.valueOf(R.layout.template_card_2));
                templates.put("template_card_3", Integer.valueOf(R.layout.template_card_3));
                templates.put("template_card_4", Integer.valueOf(R.layout.template_card_4));
                templates.put("template_card_5", Integer.valueOf(R.layout.template_card_5));
                break;
            case 10:
                templates.put("template_mothers_day_1", Integer.valueOf(R.layout.template_mothers_day_1));
                templates.put("template_mothers_day_2", Integer.valueOf(R.layout.template_mothers_day_2));
                templates.put("template_mothers_day_3", Integer.valueOf(R.layout.template_mothers_day_3));
                templates.put("template_mothers_day_4", Integer.valueOf(R.layout.template_mothers_day_4));
                templates.put("template_mothers_day_5", Integer.valueOf(R.layout.template_mothers_day_5));
                break;
            case 11:
                templates.put("template_christmas_1", Integer.valueOf(R.layout.template_christmas_1));
                templates.put("template_christmas_2", Integer.valueOf(R.layout.template_christmas_2));
                templates.put("template_christmas_3", Integer.valueOf(R.layout.template_christmas_3));
                templates.put("template_christmas_4", Integer.valueOf(R.layout.template_christmas_4));
                templates.put("template_christmas_5", Integer.valueOf(R.layout.template_christmas_5));
                break;
            case 12:
                templates.put("template_white_christmas_1", Integer.valueOf(R.layout.template_white_christmas_1));
                templates.put("template_white_christmas_2", Integer.valueOf(R.layout.template_white_christmas_2));
                templates.put("template_white_christmas_3", Integer.valueOf(R.layout.template_white_christmas_3));
                templates.put("template_white_christmas_4", Integer.valueOf(R.layout.template_white_christmas_4));
                templates.put("template_white_christmas_5", Integer.valueOf(R.layout.template_white_christmas_5));
                templates.put("template_white_christmas_6", Integer.valueOf(R.layout.template_white_christmas_6));
                break;
            case 13:
                templates.put("template_islamic_holidays_1", Integer.valueOf(R.layout.template_islamic_holidays_1));
                templates.put("template_islamic_holidays_2", Integer.valueOf(R.layout.template_islamic_holidays_2));
                templates.put("template_islamic_holidays_3", Integer.valueOf(R.layout.template_islamic_holidays_3));
                templates.put("template_islamic_holidays_4", Integer.valueOf(R.layout.template_islamic_holidays_4));
                templates.put("template_islamic_holidays_5", Integer.valueOf(R.layout.template_islamic_holidays_5));
                templates.put("template_islamic_holidays_6", Integer.valueOf(R.layout.template_islamic_holidays_6));
                break;
            case 14:
                templates.put("template_summer_1", Integer.valueOf(R.layout.template_summer_1));
                templates.put("template_summer_2", Integer.valueOf(R.layout.template_summer_2));
                templates.put("template_summer_3", Integer.valueOf(R.layout.template_summer_3));
                templates.put("template_summer_4", Integer.valueOf(R.layout.template_summer_4));
                templates.put("template_summer_5", Integer.valueOf(R.layout.template_summer_5));
                templates.put("template_summer_6", Integer.valueOf(R.layout.template_summer_6));
                break;
            case 15:
                templates.put("template_oceans_1", Integer.valueOf(R.layout.template_oceans_1));
                templates.put("template_oceans_2", Integer.valueOf(R.layout.template_oceans_2));
                templates.put("template_oceans_3", Integer.valueOf(R.layout.template_oceans_3));
                templates.put("template_oceans_4", Integer.valueOf(R.layout.template_oceans_4));
                templates.put("template_oceans_5", Integer.valueOf(R.layout.template_oceans_5));
                templates.put("template_oceans_6", Integer.valueOf(R.layout.template_oceans_6));
                templates.put("template_oceans_7", Integer.valueOf(R.layout.template_oceans_7));
                templates.put("template_oceans_8", Integer.valueOf(R.layout.template_oceans_8));
                break;
            case 16:
                templates.put("template_roundel_1", Integer.valueOf(R.layout.template_roundel_1));
                templates.put("template_roundel_2", Integer.valueOf(R.layout.template_roundel_2));
                templates.put("template_roundel_3", Integer.valueOf(R.layout.template_roundel_3));
                templates.put("template_roundel_4", Integer.valueOf(R.layout.template_roundel_4));
                templates.put("template_roundel_5", Integer.valueOf(R.layout.template_roundel_5));
                templates.put("template_roundel_6", Integer.valueOf(R.layout.template_roundel_6));
                templates.put("template_roundel_7", Integer.valueOf(R.layout.template_roundel_7));
                templates.put("template_roundel_8", Integer.valueOf(R.layout.template_roundel_8));
                templates.put("template_roundel_9", Integer.valueOf(R.layout.template_roundel_9));
                templates.put("template_roundel_a1", Integer.valueOf(R.layout.template_roundel_a1));
                break;
            case 17:
                templates.put("template_jshine_1", Integer.valueOf(R.layout.template_jshine_1));
                templates.put("template_jshine_2", Integer.valueOf(R.layout.template_jshine_2));
                templates.put("template_jshine_3", Integer.valueOf(R.layout.template_jshine_3));
                templates.put("template_jshine_4", Integer.valueOf(R.layout.template_jshine_4));
                templates.put("template_jshine_5", Integer.valueOf(R.layout.template_jshine_5));
                templates.put("template_jshine_6", Integer.valueOf(R.layout.template_jshine_6));
                templates.put("template_jshine_7", Integer.valueOf(R.layout.template_jshine_7));
                templates.put("template_jshine_8", Integer.valueOf(R.layout.template_jshine_8));
                break;
            case 18:
                templates.put("template_birthday_1", Integer.valueOf(R.layout.template_birthday_1));
                templates.put("template_birthday_2", Integer.valueOf(R.layout.template_birthday_2));
                templates.put("template_birthday_3", Integer.valueOf(R.layout.template_birthday_3));
                templates.put("template_birthday_4", Integer.valueOf(R.layout.template_birthday_4));
                templates.put("template_birthday_5", Integer.valueOf(R.layout.template_birthday_5));
                templates.put("template_birthday_6", Integer.valueOf(R.layout.template_birthday_6));
                break;
            case 19:
                templates.put("template_vintage_1", Integer.valueOf(R.layout.template_vintage_1));
                templates.put("template_vintage_2", Integer.valueOf(R.layout.template_vintage_2));
                templates.put("template_vintage_3", Integer.valueOf(R.layout.template_vintage_3));
                templates.put("template_vintage_4", Integer.valueOf(R.layout.template_vintage_4));
                templates.put("template_vintage_5", Integer.valueOf(R.layout.template_vintage_5));
                templates.put("template_vintage_6", Integer.valueOf(R.layout.template_vintage_6));
                templates.put("template_vintage_7", Integer.valueOf(R.layout.template_vintage_7));
                templates.put("template_vintage_8", Integer.valueOf(R.layout.template_vintage_8));
                break;
        }
        return templates;
    }
}
