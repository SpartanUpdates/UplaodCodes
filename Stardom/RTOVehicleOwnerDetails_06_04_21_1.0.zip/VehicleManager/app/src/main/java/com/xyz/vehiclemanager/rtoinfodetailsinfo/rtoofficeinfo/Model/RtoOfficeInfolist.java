package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model;

import com.google.gson.annotations.SerializedName;

public class RtoOfficeInfolist
{
    @SerializedName("id")
    public String id;
    @SerializedName("rto_code")
    public String rto_code;
    @SerializedName("district")
    public String district;
    @SerializedName("state")
    public String state;
    @SerializedName("address")
    public String address;
    @SerializedName("phone")
    public String phone;
    @SerializedName("website")
    public String website;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRto_code() {
        return rto_code;
    }

    public void setRto_code(String rto_code) {
        this.rto_code = rto_code;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }
}
