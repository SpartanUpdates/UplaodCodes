package com.kotlinz.festivalstorymaker.Other;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.exifinterface.media.ExifInterface;

import com.appizona.yehiahd.fastsave.FastSave;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.google.gson.Gson;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class Utils {
    public static boolean A = false;
    public static Dialog B;
    public static String C;
    public static String[] D;
    public static Activity E;
    public static int F = 0;
    public static int G = 0;
    public static boolean b = false;
    public static final Pattern c;
    public static Activity d;
    public static String[] e;
    public static int[][] f;
    public static StrictMode.VmPolicy.Builder g;
    public static StrictMode.ThreadPolicy h;
    public static SimpleDateFormat i;
    public static String j;
    public static String k;
    public static File l;
    public static int m;
    public static int n;
    public static Bitmap o;
    public static Bitmap p;
    public static RenderScript q;
    public static ScriptIntrinsicBlur r;
    public static Allocation s;
    public static Allocation t;
    public static List<String> u;
    public static SharedPreferences v;
    public static Gson w;
    public static String x;
    public static Type y;
    public static SharedPreferences.Editor z;
    public ProgressDialog a;

    public static String Fs;

    public static ArrayList<String> sf;
    public static SharedPreferences tf;
    public static Gson uf;
    public static String vf;

    static {
        c = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}\\@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25})+");
        Utils.e = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    public Utils(final Activity d) {
        Utils.d = d;
    }

    public static Bitmap A(final String s) {
        try {
            ExifInterface exifInterface = new ExifInterface(s);
            int g = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (g == 2) {
                return e(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), true, false, false);
            }
            if (g == 3) {
                return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 180.0f, false);
            }
            if (g == 4) {
                return e(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), false, true, false);
            }
            if (g == 6) {
                return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 90.0f, false);
            }
            if (g != 8) {
                return a(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), new Matrix(), false);
            }
            return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 270.0f, false);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static Bitmap B(final String s) {
        try {
            ExifInterface exifInterface = new ExifInterface(s);
            int g = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (g == 2) {
                return e(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), true, false, true);
            }
            if (g == 3) {
                return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 180.0f, true);
            }
            if (g == 4) {
                return e(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), false, true, true);
            }
            if (g == 6) {
                return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 90.0f, true);
            }
            if (g != 8) {
                return a(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), new Matrix(), true);
            }
            return H(BitmapFactory.decodeFile(s, new BitmapFactory.Options()), 270.0f, true);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }


    public static class c implements View.OnClickListener {
        public final Activity e;

        public c(Activity activity) {
            this.e = activity;
        }

        public void onClick(View view) {
            String str = "android.intent.action.VIEW";
            String packageName = this.e.getPackageName();
            Activity activity;
            StringBuilder stringBuilder;
            try {
                activity = this.e;
                stringBuilder = new StringBuilder();
                stringBuilder.append("market://details?id=");
                stringBuilder.append(packageName);
                activity.startActivity(new Intent(str, Uri.parse(stringBuilder.toString())));
            } catch (ActivityNotFoundException unused) {
                activity = this.e;
                stringBuilder = new StringBuilder();
                stringBuilder.append("https://play.google.com/store/apps/details?id=");
                stringBuilder.append(packageName);
                activity.startActivity(new Intent(str, Uri.parse(stringBuilder.toString())));
            }
        }
    }

    public static class d implements View.OnClickListener {
        public void onClick(View view) {
            Utils.B.dismiss();
        }
    }


    public static void E(final Activity activity, final String s) {
        final Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(s));
        activity.startActivity(intent);
    }

    /*public static void F(Activity activity, String str) {
        try {
            Object obj;
            Uri parse;
            Intent intent = new Intent("android.intent.action.VIEW");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append("&text=");
            stringBuilder.append(URLEncoder.encode("Hi", "UTF-8"));
            str = stringBuilder.toString();
            Object obj2 = null;
            try {
                activity.getPackageManager().getPackageInfo(, PackageManager.GET_ACTIVITIES);
                obj = 1;
            } catch (PackageManager.NameNotFoundException unused) {
                obj = null;
            }
            if (obj != null) {
                activity.getPackageManager();

                parse = Uri.parse(str);
            } else {
                try {
                    activity.getPackageManager().getPackageInfo( PackageManager.GET_ACTIVITIES);
                    obj2 = 1;
                } catch (PackageManager.NameNotFoundException unused2) {
                    unused2.printStackTrace();
                }
                if (obj2 != null) {
                    activity.getPackageManager();
                    intent.setPackage();
                    parse = Uri.parse(str);
                } else {
                    Toast.makeText(activity, "WhatsApp not installed!!", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            intent.setData(parse);
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    public static void G(final Activity activity) {
        com.kotlinz.festivalstorymaker.Utils.a.a.c(activity).b(activity);
    }


    public static Bitmap H(Bitmap bitmap, float f, boolean z) {
        Bitmap a = a(bitmap, new Matrix(), z);
        Matrix matrix = new Matrix();
        matrix.postRotate(f);
        return Bitmap.createBitmap(a, 0, 0, a.getWidth(), a.getHeight(), matrix, true);
    }

    public static void I(final List<String> list, final Context context) {
        final String o = AppConstant.FontList;
        (Utils.z = (Utils.v = context.getSharedPreferences("Font_list", 0)).edit()).putString("FontList", Utils.x = (Utils.w = new Gson()).toJson(list));
        Utils.z.commit();
    }

    public static void J(final String s, final String s2) {
        /*final l o = o.b.l.o();
        o.a(false);
        o.c();
        final i.j j = o.n(i.j.class, true, Collections.emptyList());
        j.e(s);
        j.f(s2);
        o.d();*/
    }

    public static void K(final Context context, final File file) {
        final Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(file));
        context.sendBroadcast(intent);
    }


    public static void N(final Context context, final String s) {
        Toast.makeText(context, s, Toast.LENGTH_LONG).show();
    }

    public static void O() {
        StrictMode.setThreadPolicy(Utils.h = new StrictMode.ThreadPolicy.Builder().permitAll().build());
    }

    public static Bitmap a(final Bitmap bitmap, final Matrix matrix, final boolean b) {
        Utils.F = bitmap.getWidth();
        Utils.G = bitmap.getHeight();
        final int f = Utils.F;
        final int n = 900;
        final int n2 = 2000;
        int n3;
        if (b) {
            n3 = 900;
        } else {
            n3 = 2000;
        }
        if (f <= n3) {
            final int g = Utils.G;
            int n4;
            if (b) {
                n4 = 1000;
            } else {
                n4 = 2000;
            }
            if (g <= n4) {
                return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            }
        }
        final int f2 = Utils.F;
        final int g2 = Utils.G;
        if (f2 <= g2 && f2 != g2) {
            int n5;
            if (b) {
                n5 = 1000;
            } else {
                n5 = 2000;
            }
            Utils.F = f2 * n5 / Utils.G;
            int g3 = n2;
            if (b) {
                g3 = 1000;
            }
            Utils.G = g3;
        } else {
            final int g4 = Utils.G;
            int n6;
            if (b) {
                n6 = 900;
            } else {
                n6 = 2000;
            }
            Utils.G = g4 * n6 / Utils.F;
            int f3;
            if (b) {
                f3 = n;
            } else {
                f3 = 2000;
            }
            Utils.F = f3;
        }
        if (bitmap.getWidth() != Utils.F || bitmap.getHeight() != Utils.G) {
            matrix.setScale(Utils.F / (float) bitmap.getWidth(), Utils.G / (float) bitmap.getHeight());
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }


    public static void d() {
        StrictMode.setVmPolicy((Utils.g = new StrictMode.VmPolicy.Builder()).build());
    }

    public static Bitmap e(final Bitmap bitmap, final boolean b, final boolean b2, final boolean b3) {
        final Matrix matrix = new Matrix();
        float n = -1.0f;
        float n2;
        if (b) {
            n2 = -1.0f;
        } else {
            n2 = 1.0f;
        }
        if (!b2) {
            n = 1.0f;
        }
        matrix.preScale(n2, n);
        return a(bitmap, matrix, b3);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static TextView f(final Activity activity, final com.kotlinz.festivalstorymaker.Models.g g, final float x, final float y, double n, double n2, final Font a, final boolean b, final boolean b2) {
        final TextView textView = new TextView(activity);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        textView.setX(x);
        textView.setY(y);
        final ViewGroup.LayoutParams layoutParams = textView.getLayoutParams();
        final int n3 = (int) n;
        layoutParams.width = n3;
        final ViewGroup.LayoutParams layoutParams2 = textView.getLayoutParams();
        final int n4 = (int) n2;
        layoutParams2.height = n4;
        textView.setIncludeFontPadding(false);
        textView.setLineSpacing(0.0f, 0.0f);
        if (b2) {
            textView.setSingleLine(true);
        } else {
            textView.setSingleLine(false);
            textView.setInputType(131072);
        }
        textView.setTextSize(a.b);
        textView.setTextColor(a.a);
        textView.setTypeface(a.c);
        int n5;
        if (g.t.equalsIgnoreCase("left")) {
            n5 = 3;
        } else if (g.t.equalsIgnoreCase("center")) {
            n5 = 17;
        } else {
            n5 = 5;
        }
        textView.setGravity(n5 | 0x10);
        if (g.r.length() > 0) {
            textView.setLetterSpacing(Float.parseFloat(g.s) / 1000.0f);
        }
        textView.setText(g.x);
        if (b) {
            textView.setOnClickListener(new View.OnClickListener() {
                public void onClick(final View view) {
                    TextInputDilaog.q0(activity, textView.getText().toString(), true, g.x).m0 = new TextInputDilaog.d() {
                        @Override
                        public void a(final String text, final int n) {
                            textView.setText(text);
                        }

                        @Override
                        public void b(final String s) {
                        }
                    };
                }
            });
        }
        if (g.y.length() > 0 && Integer.parseInt(g.y) > 0) {
            final double n6 = x;
            n2 /= 2.0;
            n /= 2.0;
            textView.setX((float) (n6 - n2 + n));
            textView.setY((float) (y - n + n2));
            textView.setRotation((float) Integer.parseInt(g.y));
            textView.getLayoutParams().height = n3;
            textView.getLayoutParams().width = n4;
            textView.requestLayout();
        }
        return textView;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static TextView ff(final Activity activity, com.kotlinz.festivalstorymaker.Models.g g, final float x, final float y, double n, double n2, final Font a, final boolean b, final boolean b2) {
        final TextView textView = new TextView(activity);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        textView.setX(x);
        textView.setY(y);
        final ViewGroup.LayoutParams layoutParams = textView.getLayoutParams();
        final int n3 = (int) n;
        layoutParams.width = n3;
        final ViewGroup.LayoutParams layoutParams2 = textView.getLayoutParams();
        final int n4 = (int) n2;
        layoutParams2.height = n4;
        textView.setIncludeFontPadding(false);
        textView.setLineSpacing(0.0f, 0.0f);
        if (b2) {
            textView.setSingleLine(true);
        } else {
            textView.setSingleLine(false);
            textView.setInputType(131072);
        }
        textView.setTextSize(a.b);
        textView.setTextColor(a.a);
        textView.setTypeface(a.c);
        int n5;
        if (g.t.equalsIgnoreCase("left")) {
            n5 = 3;
        } else if (g.t.equalsIgnoreCase("center")) {
            n5 = 17;
        } else {
            n5 = 5;
        }
        textView.setGravity(n5 | 0x10);
        if (g.r.length() > 0) {
            textView.setLetterSpacing(Float.parseFloat(g.s) / 1000.0f);
        }
        textView.setText(g.x);
        if (b) {
            textView.setOnClickListener(new View.OnClickListener() {
                public void onClick(final View view) {
                    TextInputDilaog.q0(activity, textView.getText().toString(), true, g.x).m0 = new TextInputDilaog.d() {
                        @Override
                        public void a(final String text, final int n) {
                            textView.setText(text);
                        }

                        @Override
                        public void b(final String s) {
                        }
                    };
                }
            });
        }
        if (g.y.length() > 0 && Integer.parseInt(g.y) > 0) {
            final double n6 = x;
            n2 /= 2.0;
            n /= 2.0;
            textView.setX((float) (n6 - n2 + n));
            textView.setY((float) (y - n + n2));
            textView.setRotation((float) Integer.parseInt(g.y));
            textView.getLayoutParams().height = n3;
            textView.getLayoutParams().width = n4;
            textView.requestLayout();
        }
        return textView;
    }

    public static Bitmap g(final Context context, final Uri uri) {
        try {
            final Bitmap bitmap = MediaStore.Images.Media.getBitmap(context.getContentResolver(), uri);
            if (bitmap != null) {
                final float min = Math.min(50.0f / bitmap.getWidth(), 50.0f / bitmap.getHeight());
                return Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * min), Math.round(min * bitmap.getHeight()), true);
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static BorderedTextView h(final Activity activity, final com.kotlinz.festivalstorymaker.Models.g g, final float x, final float y, final double n, final double n2, final Font a, final boolean b) {
        final BorderedTextView borderedTextView = new BorderedTextView(activity);
        borderedTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        borderedTextView.setX(x);
        borderedTextView.setY(y);
        borderedTextView.getLayoutParams().height = (int) Math.ceil(n2);
        borderedTextView.getLayoutParams().width = (int) Math.ceil(n);
        borderedTextView.setBorderTypeface(a.c);
        borderedTextView.setBorderedColor(a.a);
        borderedTextView.setIncludeFontPadding(false);
        borderedTextView.setLineSpacing(0.0f, 0.0f);
        if (b) {
            borderedTextView.setSingleLine(true);
        } else {
            borderedTextView.setSingleLine(false);
            borderedTextView.setInputType(131072);
        }
        if (g.n.length() > 0) {
            borderedTextView.setBorderedColor(Color.parseColor(g.n));
            borderedTextView.setBorderWidth((int) Float.parseFloat(g.o));
            borderedTextView.setInsetColor(17170445);
        }
        borderedTextView.setTextSizes(a.b);
        borderedTextView.setTypeface(a.c);
        BorderedTextView.a textAlign;
        if (g.t.equalsIgnoreCase("left")) {
            textAlign = BorderedTextView.a.g;
        } else if (g.t.equalsIgnoreCase("center")) {
            textAlign = BorderedTextView.a.j;
        } else {
            textAlign = BorderedTextView.a.h;
        }
        borderedTextView.setTextAlign(textAlign);
        if (g.r.length() > 0) {
            borderedTextView.setLetterSpacing(Float.parseFloat(g.s) / 1000.0f);
        }
        if (g.y.length() > 0 && Integer.parseInt(g.y) > 0) {
            final double n3 = x;
            final double n4 = n2 / 2.0;
            final double n5 = n / 2.0;
            borderedTextView.setX((float) (n3 - n4 + n5));
            borderedTextView.setY((float) (y - n5 + n4));
            borderedTextView.setRotation((float) Integer.parseInt(g.y));
            borderedTextView.getLayoutParams().height = (int) n;
            borderedTextView.getLayoutParams().width = (int) n2;
            borderedTextView.requestLayout();
        }
        borderedTextView.setText(g.x);
        borderedTextView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                TextInputDilaog.q0(activity, borderedTextView.getText().toString(), true, g.x).m0 = new TextInputDilaog.d() {
                    @Override
                    public void a(final String text, final int n) {
                        borderedTextView.setText(text);
                    }

                    @Override
                    public void b(final String s) {
                    }
                };
            }
        });
        return borderedTextView;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static BorderedTextView hf(final Activity activity, com.kotlinz.festivalstorymaker.Models.g g, final float x, final float y, final double n, final double n2, final Font a, final boolean b) {
        final BorderedTextView borderedTextView = new BorderedTextView(activity);
        borderedTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        borderedTextView.setX(x);
        borderedTextView.setY(y);
        borderedTextView.getLayoutParams().height = (int) Math.ceil(n2);
        borderedTextView.getLayoutParams().width = (int) Math.ceil(n);
        borderedTextView.setBorderTypeface(a.c);
        borderedTextView.setBorderedColor(a.a);
        borderedTextView.setIncludeFontPadding(false);
        borderedTextView.setLineSpacing(0.0f, 0.0f);
        if (b) {
            borderedTextView.setSingleLine(true);
        } else {
            borderedTextView.setSingleLine(false);
            borderedTextView.setInputType(131072);
        }
        if (g.n.length() > 0) {
            borderedTextView.setBorderedColor(Color.parseColor(g.n));
            borderedTextView.setBorderWidth((int) Float.parseFloat(g.o));
            borderedTextView.setInsetColor(17170445);
        }
        borderedTextView.setTextSizes(a.b);
        borderedTextView.setTypeface(a.c);
        BorderedTextView.a textAlign;
        if (g.t.equalsIgnoreCase("left")) {
            textAlign = BorderedTextView.a.g;
        } else if (g.t.equalsIgnoreCase("center")) {
            textAlign = BorderedTextView.a.j;
        } else {
            textAlign = BorderedTextView.a.h;
        }
        borderedTextView.setTextAlign(textAlign);
        if (g.r.length() > 0) {
            borderedTextView.setLetterSpacing(Float.parseFloat(g.s) / 1000.0f);
        }
        if (g.y.length() > 0 && Integer.parseInt(g.y) > 0) {
            final double n3 = x;
            final double n4 = n2 / 2.0;
            final double n5 = n / 2.0;
            borderedTextView.setX((float) (n3 - n4 + n5));
            borderedTextView.setY((float) (y - n5 + n4));
            borderedTextView.setRotation((float) Integer.parseInt(g.y));
            borderedTextView.getLayoutParams().height = (int) n;
            borderedTextView.getLayoutParams().width = (int) n2;
            borderedTextView.requestLayout();
        }
        borderedTextView.setText(g.x);
        borderedTextView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                TextInputDilaog.q0(activity, borderedTextView.getText().toString(), true, g.x).m0 = new TextInputDilaog.d() {
                    @Override
                    public void a(final String text, final int n) {
                        borderedTextView.setText(text);
                    }

                    @Override
                    public void b(final String s) {
                    }
                };
            }
        });
        return borderedTextView;
    }


    public static TextView fFestival(final Activity activity, final com.kotlinz.festivalstorymaker.Models.g g, final float x, final float y, double n, double n2, final Font a, final boolean b, final boolean b2) {
        final TextView textView = new TextView((Context) activity);
        textView.setLayoutParams((ViewGroup.LayoutParams) new LinearLayout.LayoutParams(-2, -2));
        textView.setX(x);
        textView.setY(y);
        final ViewGroup.LayoutParams layoutParams = textView.getLayoutParams();
        final int n3 = (int) n;
        layoutParams.width = n3;
        final ViewGroup.LayoutParams layoutParams2 = textView.getLayoutParams();
        final int n4 = (int) n2;
        layoutParams2.height = n4;
        textView.setIncludeFontPadding(false);
        textView.setLineSpacing(0.0f, 0.0f);
        if (b2) {
            textView.setSingleLine(true);
        } else {
            textView.setSingleLine(false);
            textView.setInputType(131072);
        }
        textView.setTextSize(a.b);
        textView.setTextColor(a.a);
        textView.setTypeface(a.c);
        int n5;
        if (g.t.equalsIgnoreCase("left")) {
            n5 = 3;
        } else if (g.t.equalsIgnoreCase("center")) {
            n5 = 17;
        } else {
            n5 = 5;
        }
        textView.setGravity(n5 | 0x10);
        if (g.r.length() > 0) {
            textView.setLetterSpacing(Float.parseFloat(g.s) / 1000.0f);
        }
        textView.setText((CharSequence) g.x);
        if (b) {
            textView.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                public void onClick(final View view) {
                    TextInputDilaog.q0((Context) activity, textView.getText().toString(), true, g.x).m0 = new TextInputDilaog.d() {
                        @Override
                        public void a(final String text, final int n) {
                            textView.setText((CharSequence) text);
                        }

                        @Override
                        public void b(final String s) {
                        }
                    };
                }
            });
        }
        if (g.y.length() > 0 && Integer.parseInt(g.y) > 0) {
            final double n6 = x;
            n2 /= 2.0;
            n /= 2.0;
            textView.setX((float) (n6 - n2 + n));
            textView.setY((float) (y - n + n2));
            textView.setRotation((float) Integer.parseInt(g.y));
            textView.getLayoutParams().height = n3;
            textView.getLayoutParams().width = n4;
            textView.requestLayout();
        }
        return textView;
    }


    public static String i(final Activity activity) {
        return Settings.Secure.getString(activity.getContentResolver(), "android_id");
    }


    public static String k(final Activity activity, final String s) {
        Utils.C = "Mont-Bold.ttf";
        try {
            final String[] array = Utils.D = activity.getAssets().list("fonts");
            if (array != null) {
                String c = null;
                Block_5:
                {
                    for (int length = array.length, i = 0; i < length; ++i) {
                        c = array[i];
                        if (c.substring(0, c.indexOf(".")).equalsIgnoreCase(s)) {
                            break Block_5;
                        }
                    }
                    return Utils.C;
                }
                Utils.C = c;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return Utils.C;
    }

    public static File l() {
        Utils.j = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(Utils.i = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        sb.append("/.Festival Story Maker/");
        if (!(Utils.l = new File(sb.toString())).exists()) {
            Utils.l.mkdirs();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Utils.l.getAbsolutePath());
        sb2.append("/");
        return new File(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.r(sb2, Utils.j, ".jpg"));
    }

    public static File m(final int n) {
        Utils.j = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(Utils.i = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        sb.append("/.Festival Story Maker/");
        if (!(Utils.l = new File(sb.toString())).exists()) {
            Utils.l.mkdirs();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Utils.l.getAbsolutePath());
        sb2.append("/");
        sb2.append(n);
        sb2.append("_");
        return new File(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.r(sb2, Utils.j, ".jpg"));
    }


    public static List<String> n(final Context context) {
        Utils.u = new ArrayList<String>();
        final String m = AppConstant.LogoList;
        Utils.v = context.getSharedPreferences("Logo_list", 0);
        Utils.w = new Gson();
        if (!(Utils.x = Utils.v.getString("myJson", "")).isEmpty()) {
            Utils.u = Utils.w.fromJson(Utils.x, Utils.y = new com.kotlinz.festivalstorymaker.Other.e().getType());
        }
        return Utils.u;
    }


    public static String o(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        File file = new File(com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.r(stringBuilder, File.separator, ".Festival Story Maker"));
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, str.substring(str.lastIndexOf("/")));
        try {
            file2.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file2.getAbsolutePath();
    }


    public static File q(final Activity activity) {
        Utils.j = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(Utils.i = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        sb.append(File.separator);
        sb.append(activity.getResources().getString(R.string.app_name));
        if (!(Utils.l = new File(sb.toString())).exists()) {
            Utils.l.mkdirs();
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Utils.l);
        sb2.append(File.separator);
        if (TextUtils.isEmpty(Utils.k = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.r(sb2, Utils.j, ".png"))) {
            return null;
        }
        return new File(Utils.k);
    }

    public static File r() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "Share Image";
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        final StringBuilder v = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.v(".");
        v.append(simpleDateFormat.format(new Date()));
        final String string = v.toString();
        final File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(file);
        sb.append(File.separator);
        sb.append(string);
        sb.append(".jpg");
        final String string2 = sb.toString();
        if (TextUtils.isEmpty(string2)) {
            return null;
        }
        return new File(string2);
    }

    public static File H(String str) {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "Share Image";
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file);
        stringBuilder.append(File.separator);
        stringBuilder.append(simpleDateFormat.format(new Date()));
        stringBuilder.append(str);
        stringBuilder.append(".jpg");
        str = stringBuilder.toString();
        return TextUtils.isEmpty(str) ? null : new File(str);
    }

    public static String n0(String str) {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "Share Image";
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(file.getAbsolutePath());
        String str2 = "/";
        stringBuilder2.append(str.substring(str.lastIndexOf(str2)));
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(file.getAbsolutePath());
        stringBuilder2.append(str.substring(str.lastIndexOf(str2)));
        return stringBuilder2.toString();
    }

    public static File o0() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "Festival_Logo";
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getAbsolutePath());
        stringBuilder.append("/");
        stringBuilder.append(simpleDateFormat.format(new Date()));
        stringBuilder.append(".jpg");
        return TextUtils.isEmpty(stringBuilder.toString()) ? null : new File(stringBuilder.toString());
    }

    public static File t0(int i) {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "Share Image";
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getAbsolutePath());
        stringBuilder.append(File.separator);
        stringBuilder.append(simpleDateFormat.format(new Date()));
        stringBuilder.append("_");
        stringBuilder.append(i);
        stringBuilder.append(".png");
        String stringBuilder2 = stringBuilder.toString();
        Fs = stringBuilder2;
        return TextUtils.isEmpty(stringBuilder2) ? null : new File(Fs);
    }


    public static File M() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "FestivalVideos";
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file.getAbsolutePath());
        stringBuilder.append(File.separator);
        stringBuilder.append(simpleDateFormat.format(new Date()));
        stringBuilder.append(".mp4");
        return TextUtils.isEmpty(stringBuilder) ? null : new File(Fs);
    }

    public static int[][] s(final Bitmap bitmap) {
        Utils.f = (int[][]) Array.newInstance(Integer.TYPE, bitmap.getWidth(), bitmap.getHeight());
        for (int i = 0; i < bitmap.getWidth(); ++i) {
            for (int j = 0; j < bitmap.getHeight(); ++j) {
                Utils.f[i][j] = bitmap.getPixel(i, j);
            }
        }
        return Utils.f;
    }

    public static void t(final Context context, final EditText editText) {
        editText.clearFocus();
        final InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(editText, 1);
        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }

    public static boolean w(final String s) {
        return Utils.c.matcher(s).matches();
    }

    public static boolean x(final Activity activity) {
        final NetworkInfo activeNetworkInfo = ((ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            return true;
        }
        N(activity, activity.getResources().getString(R.string.check_network));
        return false;
    }

    public static boolean y(final Activity activity, final boolean b) {
        return Utils.A;
    }


    public static String t(Activity activity) {
        return Settings.Secure.getString(activity.getContentResolver(), "android_id");
    }


    public static Bitmap z(final Activity activity) {
        final View decorView = activity.getWindow().getDecorView();
        decorView.setDrawingCacheEnabled(true);
        decorView.buildDrawingCache();
        if (!com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.L1) && !com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.V1)) {
            final Bitmap drawingCache = decorView.getDrawingCache();
            final Rect rect = new Rect();
            activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
            final int top = rect.top;
            final Bitmap bitmap = Bitmap.createBitmap(drawingCache, 0, top, activity.getWindowManager().getDefaultDisplay().getWidth(), activity.getWindowManager().getDefaultDisplay().getHeight() - top);
            decorView.destroyDrawingCache();
            final Bitmap copy = bitmap.copy(bitmap.getConfig(), true);
            Utils.m = Math.round(copy.getWidth() * 0.1f);
            Utils.p = Bitmap.createBitmap(Utils.o = Bitmap.createScaledBitmap(copy, Utils.m, Utils.n = Math.round(copy.getHeight() * 0.1f), true));
            final RenderScript renderScript = Utils.q = RenderScript.create(activity);
            Utils.r = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
            Utils.s = Allocation.createFromBitmap(Utils.q, Utils.o);
            Utils.t = Allocation.createFromBitmap(Utils.q, Utils.p);
            Utils.r.setRadius(25.0f);
            Utils.r.setInput(Utils.s);
            Utils.r.forEach(Utils.t);
            Utils.t.copyTo(Utils.p);
            return Utils.p;
        }
        return BitmapFactory.decodeResource(activity.getResources(), 2131231114);
    }

    public void m() {
        final ProgressDialog a = this.a;
        if (a != null && !a.isShowing()) {
            this.a.show();
        }
    }

    public void c(final String message) {
        (this.a = new ProgressDialog(Utils.d, 3)).setMessage(message);
        this.a.setCancelable(false);
    }

    public void u() {
        final ProgressDialog a = this.a;
        if (a != null && a.isShowing()) {
            this.a.dismiss();
        }
    }

    public void v(final Activity activity) {
        final ProgressDialog a = this.a;
        if (a != null && a.isShowing() && !activity.isFinishing()) {
            this.a.dismiss();
        }
    }

    public static void g0(ArrayList arrayList, TextStickerViewNew1 textStickerViewNew1) {
        textStickerViewNew1.setTag(Integer.valueOf(arrayList.size()));
    }


    public static Bitmap S(Activity activity) {
        String str = "";
        if (FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.i3) || FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.s3) || FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.b3)) {
            return BitmapFactory.decodeResource(activity.getResources(), R.drawable.ic_transparent_white_bg);
        }
        View decorView = activity.getWindow().getDecorView();
        decorView.setDrawingCacheEnabled(true);
        decorView.buildDrawingCache();
        Bitmap drawingCache = decorView.getDrawingCache();
        Rect rect = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        int i = rect.top;
        drawingCache = Bitmap.createBitmap(drawingCache, 0, i, activity.getWindowManager().getDefaultDisplay().getWidth(), activity.getWindowManager().getDefaultDisplay().getHeight() - i);
        decorView.destroyDrawingCache();
        return d(activity, drawingCache.copy(drawingCache.getConfig(), true));
    }


    @SuppressLint({"NewApi"})
    public static Bitmap d(Context context, Bitmap bitmap) {
       /* k = Math.round(((float) bitmap.getWidth()) * 0.1f);
        int round = Math.round(((float) bitmap.getHeight()) * 0.1f);
        l = round;
        bitmap = Bitmap.createScaledBitmap(bitmap, k, round, true);
        m = bitmap;
        n = Bitmap.createBitmap(bitmap);
        RenderScript create = RenderScript.create(context);
        o = create;
        p = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        q = Allocation.createFromBitmap(o, m);
        r = Allocation.createFromBitmap(o, n);
        p.setRadius(25.0f);
        p.setInput(q);
        p.forEach(r);
        r.copyTo(n);
        return n;*/
        return null;
    }

    public static Bitmap p(Context context, Uri uri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(context.getContentResolver(), uri);
            if (bitmap != null) {
                float min = Math.min(50.0f / ((float) bitmap.getWidth()), 50.0f / ((float) bitmap.getHeight()));
                return Bitmap.createScaledBitmap(bitmap, Math.round(((float) bitmap.getWidth()) * min), Math.round(min * ((float) bitmap.getHeight())), true);
            }
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        return null;
    }

    public static List<String> u(Context context) {
        sf = new ArrayList();
        String str = AppConstant.k0;
        tf = context.getSharedPreferences("Festival_Frame_list", 0);
        uf = new Gson();
        String string = tf.getString("FestivalFrames", "");
        vf = string;
        if (!string.isEmpty()) {
            Type type = new com.kotlinz.festivalstorymaker.Other.e().getType();
            y = type;
            sf = (ArrayList) uf.fromJson(vf, type);
        }
        return sf;
    }

    public static void f0(final ArrayList list, final FrameLayout frameLayout, final TextStickerViewNew1 textStickerViewNew1) {
        list.add(new com.kotlinz.festivalstorymaker.Models.festival.f0.c());
        frameLayout.addView((View) textStickerViewNew1);
        frameLayout.requestLayout();
    }

    public static int p0(EditText editText) {
        return editText.getText().toString().length();
    }

    public static boolean l0(EditText editText) {
        return w(editText.getText().toString());
    }

    public static void L(Context context, EditText editText) {
        editText.clearFocus();
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(editText, 1);
        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }

    public static void U(Bitmap.CompressFormat compressFormat, Bundle bundle, String str, String str2, int i) {
        bundle.putString(str, compressFormat.name());
        bundle.putInt(str2, i);
    }

    public static Uri cf(String str) {
        return Uri.fromFile(new File(str));
    }

    public static Bundle e(String str, Uri uri, String str2, Uri uri2) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(str, uri);
        bundle.putParcelable(str2, uri2);
        return bundle;
    }

    public static String A(StringBuilder stringBuilder, String str) {
        stringBuilder.append(System.currentTimeMillis());
        stringBuilder.append(str);
        return stringBuilder.toString();
    }



}
