package com.example.sdkx_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.greedygame.core.GreedyGameAds;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.AppOpenAdsEventsListener;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interfaces.PrefetchAdsListener;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.greedygame.core.models.general.PrefetchUnit;

import org.jetbrains.annotations.NotNull;

public class StartScreen extends AppCompatActivity {
ImageView btnStart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_screen);

        GGAppOpenAds.show();
        GGAdview bStartb = findViewById(R.id.ggAdView_banner);
        bStartb.setUnitId(getResources().getString(R.string.BannerAd));
        bStartb.loadAd(new AdLoadCallback(){
                           @Override
                           public void onReadyForRefresh() {
                               Log.d("GGADS","Ad Ready for refresh");
                           }
                           @Override
                           public void onUiiClosed() {
                               Log.d("GGADS","Uii closed");
                           }
                           @Override
                           public void onUiiOpened() {
                               Log.d("GGADS","Uii Opened");
                           }
                           @Override
                           public void onAdLoaded() {
                               Log.d("GGADS","Ad Loaded");
                           }

                           @Override
                           public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                           }
                       }
        );
        GGAdview bStart = findViewById(R.id.ggAdView_native);
        bStart.setUnitId(getResources().getString(R.string.NativeAd));
        bStart.loadAd(new AdLoadCallback(){
                          @Override
                          public void onReadyForRefresh() {
                              Log.d("GGADS","Ad Ready for refresh");
                          }
                          @Override
                          public void onUiiClosed() {
                              Log.d("GGADS","Uii closed");
                          }
                          @Override
                          public void onUiiOpened() {
                              Log.d("GGADS","Uii Opened");
                          }
                          @Override
                          public void onAdLoaded() {
                              Log.d("GGADS","Ad Loaded");
                          }

                          @Override
                          public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                          }
                      }
        );

        this.btnStart = findViewById(R.id.start);
        this.btnStart.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i = new Intent(StartScreen.this, MainActivity.class);
                startActivity(i);
            }
        });


    }
}
