package com.vidsoft.videostatusmaker.Others;

import android.graphics.PointF;
import android.graphics.RectF;
final class CropWindowMoveHandler {

    private final CropWindowHandler mCropWindowHandler;

    private final Type mType;
    private final PointF mTouchOffset = new PointF();
    public CropWindowMoveHandler(Type type, CropWindowHandler cropWindowHandler, float touchX, float touchY) {
        mType = type;
        mCropWindowHandler = cropWindowHandler;
        calculateTouchOffset(touchX, touchY);
    }

    public void move(float x, float y, RectF bounds, int viewWidth, int viewHeight, float snapMargin, boolean fixedAspectRatio, float aspectRatio) {
        float adjX = x + mTouchOffset.x;
        float adjY = y + mTouchOffset.y;

        if (mType == Type.CENTER) {
            moveCenter(adjX, adjY, bounds, viewWidth, viewHeight, snapMargin);
        } else {
            if (fixedAspectRatio) {
                moveSizeWithFixedAspectRatio(adjX, adjY, bounds, viewWidth, viewHeight, snapMargin, aspectRatio);
            } else {
                moveSizeWithFreeAspectRatio(adjX, adjY, bounds, viewWidth, viewHeight, snapMargin);
            }
        }
    }

    private void calculateTouchOffset(float touchX, float touchY) {

        float touchOffsetX = 0;
        float touchOffsetY = 0;

        RectF rect = mCropWindowHandler.getRect();

        switch (mType) {
            case TOP_LEFT:
                touchOffsetX = rect.left - touchX;
                touchOffsetY = rect.top - touchY;
                break;
            case TOP_RIGHT:
                touchOffsetX = rect.right - touchX;
                touchOffsetY = rect.top - touchY;
                break;
            case BOTTOM_LEFT:
                touchOffsetX = rect.left - touchX;
                touchOffsetY = rect.bottom - touchY;
                break;
            case BOTTOM_RIGHT:
                touchOffsetX = rect.right - touchX;
                touchOffsetY = rect.bottom - touchY;
                break;
            case LEFT:
                touchOffsetX = rect.left - touchX;
                touchOffsetY = 0;
                break;
            case TOP:
                touchOffsetX = 0;
                touchOffsetY = rect.top - touchY;
                break;
            case RIGHT:
                touchOffsetX = rect.right - touchX;
                touchOffsetY = 0;
                break;
            case BOTTOM:
                touchOffsetX = 0;
                touchOffsetY = rect.bottom - touchY;
                break;
            case CENTER:
                touchOffsetX = rect.centerX() - touchX;
                touchOffsetY = rect.centerY() - touchY;
                break;
            default:
                break;
        }

        mTouchOffset.x = touchOffsetX;
        mTouchOffset.y = touchOffsetY;
    }

    private void moveCenter(float x, float y, RectF bounds, int viewWidth, int viewHeight, float snapRadius) {
        RectF rect = mCropWindowHandler.getRect();
        float dx = x - rect.centerX();
        float dy = y - rect.centerY();
        if (rect.left + dx < 0 || rect.right + dx > viewWidth) {
            dx /= 1.05f;
            mTouchOffset.x -= dx / 2;
        }
        if (rect.top + dy < 0 || rect.bottom + dy > viewHeight) {
            dy /= 1.05f;
            mTouchOffset.y -= dy / 2;
        }
        rect.offset(dx, dy);
        snapEdgesToBounds(rect, bounds, snapRadius);
        mCropWindowHandler.setRect(rect);
    }

    private void moveSizeWithFreeAspectRatio(float x, float y, RectF bounds, int viewWidth, int viewHeight, float snapMargin) {
        switch (mType) {
            case TOP_LEFT:
                adjustTop(y, bounds, snapMargin, 0, false, false);
                adjustLeft(x, bounds, snapMargin, 0, false, false);
                break;
            case TOP_RIGHT:
                adjustTop(y, bounds, snapMargin, 0, false, false);
                adjustRight(x, bounds, viewWidth, snapMargin, 0, false, false);
                break;
            case BOTTOM_LEFT:
                adjustBottom(y, bounds, viewHeight, snapMargin, 0, false, false);
                adjustLeft(x, bounds, snapMargin, 0, false, false);
                break;
            case BOTTOM_RIGHT:
                adjustBottom(y, bounds, viewHeight, snapMargin, 0, false, false);
                adjustRight(x, bounds, viewWidth, snapMargin, 0, false, false);
                break;
            case LEFT:
                adjustLeft(x, bounds, snapMargin, 0, false, false);
                break;
            case TOP:
                adjustTop(y, bounds, snapMargin, 0, false, false);
                break;
            case RIGHT:
                adjustRight(x, bounds, viewWidth, snapMargin, 0, false, false);
                break;
            case BOTTOM:
                adjustBottom(y, bounds, viewHeight, snapMargin, 0, false, false);
                break;
            default:
                break;
        }
    }

    private void moveSizeWithFixedAspectRatio(float x, float y, RectF bounds, int viewWidth, int viewHeight, float snapMargin, float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        switch (mType) {
            case TOP_LEFT:
                if (calculateAspectRatio(x, y, rect.right, rect.bottom) < aspectRatio) {
                    adjustTop(y, bounds, snapMargin, aspectRatio, true, false);
                    adjustLeftByAspectRatio(aspectRatio);
                } else {
                    adjustLeft(x, bounds, snapMargin, aspectRatio, true, false);
                    adjustTopByAspectRatio(aspectRatio);
                }
                break;
            case TOP_RIGHT:
                if (calculateAspectRatio(rect.left, y, x, rect.bottom) < aspectRatio) {
                    adjustTop(y, bounds, snapMargin, aspectRatio, false, true);
                    adjustRightByAspectRatio(aspectRatio);
                } else {
                    adjustRight(x, bounds, viewWidth, snapMargin, aspectRatio, true, false);
                    adjustTopByAspectRatio(aspectRatio);
                }
                break;
            case BOTTOM_LEFT:
                if (calculateAspectRatio(x, rect.top, rect.right, y) < aspectRatio) {
                    adjustBottom(y, bounds, viewHeight, snapMargin, aspectRatio, true, false);
                    adjustLeftByAspectRatio(aspectRatio);
                } else {
                    adjustLeft(x, bounds, snapMargin, aspectRatio, false, true);
                    adjustBottomByAspectRatio(aspectRatio);
                }
                break;
            case BOTTOM_RIGHT:
                if (calculateAspectRatio(rect.left, rect.top, x, y) < aspectRatio) {
                    adjustBottom(y, bounds, viewHeight, snapMargin, aspectRatio, false, true);
                    adjustRightByAspectRatio(aspectRatio);
                } else {
                    adjustRight(x, bounds, viewWidth, snapMargin, aspectRatio, false, true);
                    adjustBottomByAspectRatio(aspectRatio);
                }
                break;
            case LEFT:
                adjustLeft(x, bounds, snapMargin, aspectRatio, true, true);
                adjustTopBottomByAspectRatio(bounds, aspectRatio);
                break;
            case TOP:
                adjustTop(y, bounds, snapMargin, aspectRatio, true, true);
                adjustLeftRightByAspectRatio(bounds, aspectRatio);
                break;
            case RIGHT:
                adjustRight(x, bounds, viewWidth, snapMargin, aspectRatio, true, true);
                adjustTopBottomByAspectRatio(bounds, aspectRatio);
                break;
            case BOTTOM:
                adjustBottom(y, bounds, viewHeight, snapMargin, aspectRatio, true, true);
                adjustLeftRightByAspectRatio(bounds, aspectRatio);
                break;
            default:
                break;
        }
    }

    private void snapEdgesToBounds(RectF edges, RectF bounds, float margin) {
        if (edges.left < bounds.left + margin) {
            edges.offset(bounds.left - edges.left, 0);
        }
        if (edges.top < bounds.top + margin) {
            edges.offset(0, bounds.top - edges.top);
        }
        if (edges.right > bounds.right - margin) {
            edges.offset(bounds.right - edges.right, 0);
        }
        if (edges.bottom > bounds.bottom - margin) {
            edges.offset(0, bounds.bottom - edges.bottom);
        }
    }

    private void adjustLeft(float left, RectF bounds, float snapMargin, float aspectRatio, boolean topMoves, boolean bottomMoves) {

        RectF rect = mCropWindowHandler.getRect();

        float newLeft = left;

        if (newLeft < 0) {
            newLeft /= 1.05f;
            mTouchOffset.x -= newLeft / 1.1f;
        }

        if (newLeft - bounds.left < snapMargin) {
            newLeft = bounds.left;
        }

        if (rect.right - newLeft < mCropWindowHandler.getMinCropWidth()) {
            newLeft = rect.right - mCropWindowHandler.getMinCropWidth();
        }

        if (rect.right - newLeft > mCropWindowHandler.getMaxCropWidth()) {
            newLeft = rect.right - mCropWindowHandler.getMaxCropWidth();
        }

        if (newLeft - bounds.left < snapMargin) {
            newLeft = bounds.left;
        }
        if (aspectRatio > 0) {
            float newHeight = (rect.right - newLeft) / aspectRatio;

            if (newHeight < mCropWindowHandler.getMinCropHeight()) {
                newLeft = Math.max(bounds.left, rect.right - mCropWindowHandler.getMinCropHeight() * aspectRatio);
                newHeight = (rect.right - newLeft) / aspectRatio;
            }
            if (newHeight > mCropWindowHandler.getMaxCropHeight()) {
                newLeft = Math.max(bounds.left, rect.right - mCropWindowHandler.getMaxCropHeight() * aspectRatio);
                newHeight = (rect.right - newLeft) / aspectRatio;
            }
            if (topMoves && bottomMoves) {
                newLeft = Math.max(newLeft, Math.max(bounds.left, rect.right - bounds.height() * aspectRatio));
            } else {
                if (topMoves && rect.bottom - newHeight < bounds.top) {
                    newLeft = Math.max(bounds.left, rect.right - (rect.bottom - bounds.top) * aspectRatio);
                    newHeight = (rect.right - newLeft) / aspectRatio;
                }
                if (bottomMoves && rect.top + newHeight > bounds.bottom) {
                    newLeft = Math.max(newLeft, Math.max(bounds.left, rect.right - (bounds.bottom - rect.top) * aspectRatio));
                }
            }
        }

        rect.left = newLeft;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustRight(float right, RectF bounds, int viewWidth, float snapMargin, float aspectRatio, boolean topMoves, boolean bottomMoves) {

        RectF rect = mCropWindowHandler.getRect();

        float newRight = right;

        if (newRight > viewWidth) {
            newRight = viewWidth + (newRight - viewWidth) / 1.05f;
            mTouchOffset.x -= (newRight - viewWidth) / 1.1f;
        }

        if (bounds.right - newRight < snapMargin) {
            newRight = bounds.right;
        }
        if (newRight - rect.left < mCropWindowHandler.getMinCropWidth()) {
            newRight = rect.left + mCropWindowHandler.getMinCropWidth();
        }
        if (newRight - rect.left > mCropWindowHandler.getMaxCropWidth()) {
            newRight = rect.left + mCropWindowHandler.getMaxCropWidth();
        }
        if (bounds.right - newRight < snapMargin) {
            newRight = bounds.right;
        }

        if (aspectRatio > 0) {
            float newHeight = (newRight - rect.left) / aspectRatio;

            if (newHeight < mCropWindowHandler.getMinCropHeight()) {
                newRight = Math.min(bounds.right, rect.left + mCropWindowHandler.getMinCropHeight() * aspectRatio);
                newHeight = (newRight - rect.left) / aspectRatio;
            }
            if (newHeight > mCropWindowHandler.getMaxCropHeight()) {
                newRight = Math.min(bounds.right, rect.left + mCropWindowHandler.getMaxCropHeight() * aspectRatio);
                newHeight = (newRight - rect.left) / aspectRatio;
            }

            if (topMoves && bottomMoves) {
                newRight = Math.min(newRight, Math.min(bounds.right, rect.left + bounds.height() * aspectRatio));
            } else {
                if (topMoves && rect.bottom - newHeight < bounds.top) {
                    newRight = Math.min(bounds.right, rect.left + (rect.bottom - bounds.top) * aspectRatio);
                    newHeight = (newRight - rect.left) / aspectRatio;
                }

                if (bottomMoves && rect.top + newHeight > bounds.bottom) {
                    newRight = Math.min(newRight, Math.min(bounds.right, rect.left + (bounds.bottom - rect.top) * aspectRatio));
                }
            }
        }

        rect.right = newRight;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustTop(float top, RectF bounds, float snapMargin, float aspectRatio, boolean leftMoves, boolean rightMoves) {

        RectF rect = mCropWindowHandler.getRect();

        float newTop = top;

        if (newTop < 0) {
            newTop /= 1.05f;
            mTouchOffset.y -= newTop / 1.1f;
        }

        if (newTop - bounds.top < snapMargin) {
            newTop = bounds.top;
        }

        if (rect.bottom - newTop < mCropWindowHandler.getMinCropHeight()) {
            newTop = rect.bottom - mCropWindowHandler.getMinCropHeight();
        }

        if (rect.bottom - newTop > mCropWindowHandler.getMaxCropHeight()) {
            newTop = rect.bottom - mCropWindowHandler.getMaxCropHeight();
        }

        if (newTop - bounds.top < snapMargin) {
            newTop = bounds.top;
        }

        if (aspectRatio > 0) {
            float newWidth = (rect.bottom - newTop) * aspectRatio;

            if (newWidth < mCropWindowHandler.getMinCropWidth()) {
                newTop = Math.max(bounds.top, rect.bottom - (mCropWindowHandler.getMinCropWidth() / aspectRatio));
                newWidth = (rect.bottom - newTop) * aspectRatio;
            }
            if (newWidth > mCropWindowHandler.getMaxCropWidth()) {
                newTop = Math.max(bounds.top, rect.bottom - (mCropWindowHandler.getMaxCropWidth() / aspectRatio));
                newWidth = (rect.bottom - newTop) * aspectRatio;
            }

            if (leftMoves && rightMoves) {
                newTop = Math.max(newTop, Math.max(bounds.top, rect.bottom - bounds.width() / aspectRatio));
            } else {
                if (leftMoves && rect.right - newWidth < bounds.left) {
                    newTop = Math.max(bounds.top, rect.bottom - (rect.right - bounds.left) / aspectRatio);
                    newWidth = (rect.bottom - newTop) * aspectRatio;
                }
                if (rightMoves && rect.left + newWidth > bounds.right) {
                    newTop = Math.max(newTop, Math.max(bounds.top, rect.bottom - (bounds.right - rect.left) / aspectRatio));
                }
            }
        }

        rect.top = newTop;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustBottom(float bottom, RectF bounds, int viewHeight, float snapMargin, float aspectRatio, boolean leftMoves, boolean rightMoves) {

        RectF rect = mCropWindowHandler.getRect();

        float newBottom = bottom;

        if (newBottom > viewHeight) {
            newBottom = viewHeight + (newBottom - viewHeight) / 1.05f;
            mTouchOffset.y -= (newBottom - viewHeight) / 1.1f;
        }

        if (bounds.bottom - newBottom < snapMargin) {
            newBottom = bounds.bottom;
        }

        if (newBottom - rect.top < mCropWindowHandler.getMinCropHeight()) {
            newBottom = rect.top + mCropWindowHandler.getMinCropHeight();
        }

        if (newBottom - rect.top > mCropWindowHandler.getMaxCropHeight()) {
            newBottom = rect.top + mCropWindowHandler.getMaxCropHeight();
        }

        if (bounds.bottom - newBottom < snapMargin) {
            newBottom = bounds.bottom;
        }

        if (aspectRatio > 0) {
            float newWidth = (newBottom - rect.top) * aspectRatio;

            if (newWidth < mCropWindowHandler.getMinCropWidth()) {
                newBottom = Math.min(bounds.bottom, rect.top + mCropWindowHandler.getMinCropWidth() / aspectRatio);
                newWidth = (newBottom - rect.top) * aspectRatio;
            }

            if (newWidth > mCropWindowHandler.getMaxCropWidth()) {
                newBottom = Math.min(bounds.bottom, rect.top + mCropWindowHandler.getMaxCropWidth() / aspectRatio);
                newWidth = (newBottom - rect.top) * aspectRatio;
            }

            if (leftMoves && rightMoves) {
                newBottom = Math.min(newBottom, Math.min(bounds.bottom, rect.top + bounds.width() / aspectRatio));
            } else {
                if (leftMoves && rect.right - newWidth < bounds.left) {
                    newBottom = Math.min(bounds.bottom, rect.top + (rect.right - bounds.left) / aspectRatio);
                    newWidth = (newBottom - rect.top) * aspectRatio;
                }

                if (rightMoves && rect.left + newWidth > bounds.right) {
                    newBottom = Math.min(newBottom, Math.min(bounds.bottom, rect.top + (bounds.right - rect.left) / aspectRatio));
                }
            }
        }

        rect.bottom = newBottom;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustLeftByAspectRatio(float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.left = rect.right - rect.height() * aspectRatio;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustTopByAspectRatio(float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.top = rect.bottom - rect.width() / aspectRatio;
        mCropWindowHandler.setRect(rect);
    }
    private void adjustRightByAspectRatio(float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.right = rect.left + rect.height() * aspectRatio;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustBottomByAspectRatio(float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.bottom = rect.top + rect.width() / aspectRatio;
        mCropWindowHandler.setRect(rect);
    }

    private void adjustLeftRightByAspectRatio(RectF bounds, float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.inset((rect.width() - rect.height() * aspectRatio) / 2, 0);
        if (rect.left < bounds.left) {
            rect.offset(bounds.left - rect.left, 0);
        }
        if (rect.right > bounds.right) {
            rect.offset(bounds.right - rect.right, 0);
        }
        mCropWindowHandler.setRect(rect);
    }
    private void adjustTopBottomByAspectRatio(RectF bounds, float aspectRatio) {
        RectF rect = mCropWindowHandler.getRect();
        rect.inset(0, (rect.height() - rect.width() / aspectRatio) / 2);
        if (rect.top < bounds.top) {
            rect.offset(0, bounds.top - rect.top);
        }
        if (rect.bottom > bounds.bottom) {
            rect.offset(0, bounds.bottom - rect.bottom);
        }
        mCropWindowHandler.setRect(rect);
    }
    private static float calculateAspectRatio(float left, float top, float right, float bottom) {
        return (right - left) / (bottom - top);
    }
    public enum Type {
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT,
        LEFT,
        TOP,
        RIGHT,
        BOTTOM,
        CENTER
    }
}