import 'dart:convert';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/model/rto_question_model.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RtoQuestionController extends GetxController {
  BuildContext context;
  bool isRtoPreparation;
  List<RtoQuestionModel> questionList = [];
  List<int> storedList = [];
  bool isDataAvailable = false;
  RtoQuestionController(this.context, this.isRtoPreparation);
  var randomQuestion;
  int currentQue = 0;
  int yourScore = 0;
  int rightAns = 0;
  int wrongAns = 0;
  int highScore = 0;
  int currentIndexA = 0;
  int currentIndexB = 0;
  int currentIndexC = 0;

  @override
  void onReady() {
    CommanDialog.showRtoPreparationDialog(context, isRtoPreparation);
  }

  Future<void> changingIndex(int A, int B, int C) async {
    currentIndexA = A;
    currentIndexB = B;
    currentIndexC = C;
    update();
  }

  Future<void> incRightAns() async {
    yourScore = yourScore + 5;
    if (yourScore > highScore) {
      setHighScore();
    }
    rightAns++;

    update();
  }

  Future<void> incWrongAns() async {
    if (yourScore > highScore) {
      setHighScore();
    }
    wrongAns++;
    update();
  }

  Future<void> setHighScore() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    highScore = yourScore;
    getHighScore();
    isRtoPreparation
        ? await prefs.setInt('highScore', highScore)
        : await prefs.setInt('examHighScore', highScore);
  }

  Future<void> restartGame() async {
    currentQue = 0;
    yourScore = 0;
    rightAns = 0;
    wrongAns = 0;
    update();
  }

  Future<void> resetAll() async {
    currentQue = 1;
    yourScore = 0;
    rightAns = 0;
    wrongAns = 0;
    update();
  }

  Future<void> getHighScore() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    highScore = (isRtoPreparation
            ? prefs.getInt('highScore')
            : prefs.getInt('examHighScore')) ??
        0;
  }

  Future<void> fetchRtoQuestionData() async {
    var response = await rootBundle.loadString('assets/data/rto_question.json');
    final questionData = jsonDecode(response);
    var list = List.from(questionData)
        .map<RtoQuestionModel>((data) => RtoQuestionModel.fromJson(data))
        .toList();
    questionList.assignAll(list);
    isDataAvailable = true;
    fetchRandomQuestion();
    update();
  }

  Future<void> fetchRandomQuestion() async {
    bool isExist = false;
    isDataAvailable = true;
    Random random = new Random();
    int randomNumber = 0;
    randomNumber = random.nextInt(248);
    for (int i = 0; i < storedList.length; i++) {
      if (storedList[i] == randomNumber) {
        isExist = true;
      }
    }
    if (isExist) {
      randomNumber = random.nextInt(248);
    }
    storedList.add(randomNumber);
    randomQuestion = questionList[randomNumber];
    currentQue++;
    getHighScore();
    update();
  }
}
