package com.example.funnyjokesandshayari.mainquotes;

public class Quote extends MainActivity {
    String quote;

    public Quote(String str) {
        this.quote = str;
    }

    public String getQuote() {
        return this.quote;
    }

    public void setQuote(String str) {
        this.quote = str;
    }
}
