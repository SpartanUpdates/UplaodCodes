package com.kotlinz.festivalstorymaker.Other;

import android.widget.ImageView;

public interface OnTouch {
    void m(final int p0, final int p1, final ImageView p2);

    void n(final int p0, final int p1, final ImageView p2);
}
