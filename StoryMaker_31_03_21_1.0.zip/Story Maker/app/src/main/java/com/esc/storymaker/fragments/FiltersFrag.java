package com.esc.storymaker.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.storymaker.EditorActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.adapters.RvFiltersAdapter;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.kprogresshud.KProgressHUD;
import com.esc.storymaker.utils.AnimationsUtil;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.BitmapUtil;
import com.esc.storymaker.utils.ContractsUtil;
import com.esc.storymaker.utils.GPUImageFilterTools;
import com.esc.storymaker.utils.ScreenUtil;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.warkiz.widget.IndicatorSeekBar;
import com.warkiz.widget.OnSeekChangeListener;
import com.warkiz.widget.SeekParams;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import jp.co.cyberagent.android.gpuimage.GPUImage;


public class FiltersFrag extends Fragment {
    public static final String mypreference = "myprefadmob";
    private ImageView ImageOverlayadview;
    Activity activity;
    private String[] adjFilters = new String[]{"Sepia", ""};
    private GPUImageFilterTools.FilterType choseFilter;
    private String choseFltName;
    ConnectionDetector connectionDetector;
    private Bitmap crtBitmap;
    int displayad;
    private float filterProgress = 50.0f;
    private int filterSelected = -1;
    private ArrayList<String> filterWithVignette = new ArrayList();
    private GPUImageFilterTools.FilterList filters;
    private ArrayList<String> filtersNameList = new ArrayList();
    private float finalProgress = 0.0f;
    private Bitmap fitBitmap;
    private Bitmap fltBitmap;
    private boolean fltSeekbar;
    private ArrayList<String> fullFilters = new ArrayList();
    private IndicatorSeekBar indicatorSeekBar;
    @BindView(R.id.iv_photo)
    ImageView ivPhoto;
    @BindView(R.id.seekbar_container)
    LinearLayout llSeekBarContainer;
    private GPUImageFilterTools.FilterAdjuster mFilterAdjuster;
    private RvFiltersAdapter mFiltersAdapter;
    private GPUImage mGPUImage;
    private GPUImageFilterTools mGpuImageFilterTools = new GPUImageFilterTools();
    private int numOfClick = 0;
    private Bitmap orgBitmap;
    private View rootView;
    @BindView(R.id.rv_menu_filters)
    RecyclerView rvFilters;
    private int sbMax;
    private int sbMin;
    private int screenHeight;
    private int screenWidth;
    SharedPreferences sharedpreferences;
    @BindView(R.id.tb_filter)
    TextView tbFilterName;
    private String vignetteColor;
    private int vignetteIntensity;
    private int vignetteLevel;
    int whichAdFirst;


    private int id;
    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private class GenerateFiltersThumbnails extends AsyncTask<Bitmap, String, ArrayList<Bitmap>> {
        private GenerateFiltersThumbnails() {

        }

        public void onPreExecute() {
            super.onPreExecute();
            FiltersFrag.this.loading(true);
        }

        public ArrayList<Bitmap> doInBackground(Bitmap... bitmapArr) {
            GPUImageFilterTools.FilterList filterList = GPUImageFilterTools.getFilterList();
            GPUImage gPUImage = new GPUImage(FiltersFrag.this.getContext());
            try {
                int totalMemory = AppUtil.getTotalMemory(FiltersFrag.this.getContext());
                int i = 10;
                if (totalMemory <= 2000) {
                    i = 14;
                } else if (totalMemory <= 4000) {
                    i = 12;
                }
                gPUImage.setImage(Bitmap.createScaledBitmap(bitmapArr[0], bitmapArr[0].getWidth() / i, bitmapArr[0].getHeight() / i, false));
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(ContractsUtil.vignetteContracts.keySet());
                for (i = 0; i < filterList.names.size(); i++) {
                    if (FiltersFrag.this.fullFilters.contains(filterList.names.get(i))) {
                        gPUImage.setFilter(GPUImageFilterTools.createFilterForType(FiltersFrag.this.getContext(), filterList.filters.get(i), 1.0f, null));
                    } else {
                        gPUImage.setFilter(GPUImageFilterTools.createFilterForType(FiltersFrag.this.getContext(), filterList.filters.get(i), 0.5f, null));
                    }
                    if (arrayList.contains(filterList.names.get(i))) {
                        String[] split = ContractsUtil.vignetteContracts.get(filterList.names.get(i)).split("x");
                        Integer.parseInt(split[0]);
                        String str = split[1];
                        Integer.parseInt(split[2]);
                    }
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPostExecute(ArrayList<Bitmap> arrayList) {
            super.onPostExecute(arrayList);
            if (arrayList == null) {
                new GenerateFiltersThumbnails().execute(FiltersFrag.this.fitBitmap);
            }
        }
    }

    private class ResultDone extends AsyncTask<String, String, String> {

        public String doInBackground(String... strArr) {
            return null;
        }

        ResultDone(FiltersFrag filtersFrag) {
            this();
        }

        private ResultDone() {
        }


        public void onPreExecute() {
            super.onPreExecute();
            FiltersFrag.this.loading(true);
        }


        public void onPostExecute(String str) {
            super.onPostExecute(str);
            if (FiltersFrag.this.finalProgress != 0.0f) {
                EditorActivity editorActivity = (EditorActivity) FiltersFrag.this.getActivity();
                FiltersFrag filtersFrag = FiltersFrag.this;
                editorActivity.setSelectedPhoto(filtersFrag.applyFltBitmap(filtersFrag.orgBitmap, FiltersFrag.this.finalProgress));
                return;
            }
            ((EditorActivity) FiltersFrag.this.getActivity()).setSelectedPhoto(FiltersFrag.this.orgBitmap);
        }
    }

    public static FiltersFrag getInstance(Bitmap bitmap) {
        FiltersFrag filtersFrag = new FiltersFrag();
        filtersFrag.orgBitmap = bitmap;
        return filtersFrag;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void init() {
        AnimationsUtil.initAnimationsValue(getContext());
        this.screenWidth = ScreenUtil.getScreenWidth(getActivity());
        this.screenHeight = ScreenUtil.getScreenHeight(getActivity());
        this.fitBitmap = BitmapUtil.createFitBitmap(this.orgBitmap, 1920);
        this.ivPhoto.setImageBitmap(this.fitBitmap);
        this.fltBitmap = this.fitBitmap;
        this.crtBitmap = this.fltBitmap;
        this.ivPhoto.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                int action = motionEvent.getAction();
                if (action == 0) {
                    FiltersFrag.this.ivPhoto.setImageBitmap(FiltersFrag.this.fitBitmap);
                } else if (action == 1) {
                    if (FiltersFrag.this.rootView.findViewById(R.id.ll_seekbar_container).isShown()) {
                        FiltersFrag.this.ivPhoto.setImageBitmap(FiltersFrag.this.fltBitmap);
                    } else {
                        FiltersFrag.this.ivPhoto.setImageBitmap(FiltersFrag.this.crtBitmap);
                    }
                }
                return true;
            }
        });
        this.fullFilters.add("Sepia");
        this.fullFilters.add("Moon");
    }

    private void BannerAds(View view) {
        try {
            adContainerView = view.findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getActivity().getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(getActivity(), (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(getActivity());
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_filters, viewGroup, false);
        ButterKnife.bind(this, this.rootView);
        this.sharedpreferences = getActivity().getSharedPreferences("myprefadmob", 0);
        this.activity = getActivity();
        this.connectionDetector = new ConnectionDetector(this.activity.getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.ImageOverlayadview = this.rootView.findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        if (isConnectingToInternet) {

        } else {
            this.rootView.findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        BannerAds(rootView);
        interstitialAd();
        init();
        showFiltersMenu();
        return this.rootView;
    }

    public void showFiltersMenu() {
        this.filters = GPUImageFilterTools.getFilterList();
        this.filtersNameList.add("Original");
        for (int i = 0; i < this.filters.names.size(); i++) {
            this.filtersNameList.add(this.filters.names.get(i));
        }
        this.mFiltersAdapter = new RvFiltersAdapter(getContext(), this.filtersNameList, "Filters", this);
        this.rvFilters.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false));
        this.rvFilters.setAdapter(this.mFiltersAdapter);
    }

    public void switchFilterTo(final int i) {
        this.fltSeekbar = true;
        if (i < 0) {
            this.numOfClick = 0;
            this.finalProgress = 0.0f;
            this.fltBitmap = this.fitBitmap;
            this.crtBitmap = this.fltBitmap;
            this.ivPhoto.setImageBitmap(this.mGpuImageFilterTools.applyAdjustment(getContext(), this.crtBitmap, AppUtil.getInAdjustsContrast(getContext())));
            showSeekBar(false);
            return;
        }
        this.numOfClick++;
        if (this.filterSelected != i) {
            if (this.fullFilters.contains(this.choseFltName)) {
                this.filterProgress = 100.0f;
            } else {
                this.filterProgress = 50.0f;
            }
            this.numOfClick = 1;
            this.filterSelected = i;
            showSeekBar(false);
        }
        if (this.numOfClick == 2) {
            this.numOfClick = 1;
            this.sbMax = 100;
            this.sbMin = 0;
            setUpSeekBar(this.filterProgress);
            this.indicatorSeekBar.setOnSeekChangeListener(new OnSeekChangeListener() {
                public void onSeeking(SeekParams seekParams) {
                }

                public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
                }

                public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
                    FiltersFrag filtersFrag;
                    if (Arrays.asList(FiltersFrag.this.adjFilters).contains(FiltersFrag.this.filters.filters.get(i))) {
                        FiltersFrag.this.mFilterAdjuster.adjust(indicatorSeekBar.getProgress());
                        FiltersFrag.this.mGPUImage.requestRender();
                        filtersFrag = FiltersFrag.this;
                        filtersFrag.fltBitmap = filtersFrag.mGpuImageFilterTools.applyAdjustment(FiltersFrag.this.getContext(), FiltersFrag.this.mGPUImage.getBitmapWithFilterApplied(), AppUtil.getInAdjustsContrast(FiltersFrag.this.getContext()));
                    } else {
                        float floatValue;
                        try {
                            floatValue = Float.valueOf(new DecimalFormat("#.#").format(indicatorSeekBar.getProgressFloat() / 100.0f)).floatValue();
                        } catch (NumberFormatException unused) {
                            floatValue = 1.0f;
                        }
                        FiltersFrag filtersFrag2 = FiltersFrag.this;
                        filtersFrag2.mGPUImage = new GPUImage(filtersFrag2.getContext());
                        FiltersFrag.this.mGPUImage.setImage(FiltersFrag.this.fitBitmap);
                        FiltersFrag.this.mGPUImage.setFilter(GPUImageFilterTools.createFilterForType(FiltersFrag.this.getContext(), FiltersFrag.this.filters.filters.get(i), floatValue, null));
                        if (FiltersFrag.this.filterWithVignette.contains(FiltersFrag.this.filters.names.get(i))) {
                            FiltersFrag filtersFrag3 = FiltersFrag.this;
                            filtersFrag3.fltBitmap = filtersFrag3.mGpuImageFilterTools.applyAdjustment(FiltersFrag.this.getContext(), BitmapUtil.applyVignette(FiltersFrag.this.mGPUImage.getBitmapWithFilterApplied(), FiltersFrag.this.vignetteLevel, FiltersFrag.this.vignetteColor, (FiltersFrag.this.vignetteIntensity * indicatorSeekBar.getProgress()) / 100), AppUtil.getInAdjustsContrast(FiltersFrag.this.getContext()));
                        } else {
                            filtersFrag = FiltersFrag.this;
                            filtersFrag.fltBitmap = filtersFrag.mGpuImageFilterTools.applyAdjustment(FiltersFrag.this.getContext(), FiltersFrag.this.mGPUImage.getBitmapWithFilterApplied(), AppUtil.getInAdjustsContrast(FiltersFrag.this.getContext()));
                        }
                    }
                    FiltersFrag.this.ivPhoto.setImageBitmap(FiltersFrag.this.fltBitmap);
                }
            });
            showSeekBar(true);
            return;
        }
        this.choseFilter = this.filters.filters.get(i);
        this.choseFltName = this.filters.names.get(i);
        if (this.fullFilters.contains(this.choseFltName)) {
            this.filterProgress = 100.0f;
            this.finalProgress = 1.0f;
            applyFltBitmap(this.fitBitmap, 1.0f);
        } else {
            this.filterProgress = 50.0f;
            this.finalProgress = 0.5f;
            applyFltBitmap(this.fitBitmap, 0.5f);
        }
        this.crtBitmap = this.fltBitmap;
        this.ivPhoto.setImageBitmap(this.crtBitmap);
        this.tbFilterName.setText(this.filtersNameList.get(i));
    }

    private Bitmap applyFltBitmap(Bitmap bitmap, float f) {
        this.mGPUImage = new GPUImage(getActivity());
        this.mGPUImage.setImage(bitmap);
        this.mGPUImage.setFilter(GPUImageFilterTools.createFilterForType(getActivity(), this.choseFilter, f, null));
        if (this.filterWithVignette.contains(this.choseFltName)) {
            String[] split = ContractsUtil.vignetteContracts.get(this.choseFltName).split("x");
            this.vignetteLevel = Integer.parseInt(split[0]);
            this.vignetteColor = split[1];
            this.vignetteIntensity = Integer.parseInt(split[2]);
            this.fltBitmap = BitmapUtil.applyVignette(this.mGPUImage.getBitmapWithFilterApplied(), this.vignetteLevel, this.vignetteColor, this.vignetteIntensity);
        } else {
            this.fltBitmap = this.mGPUImage.getBitmapWithFilterApplied();
        }
        return this.mGpuImageFilterTools.applyAdjustment(getContext(), this.fltBitmap, AppUtil.getInAdjustsContrast(getContext()));
    }

    private void showSeekBar(boolean z) {
        if (z) {
            this.rootView.findViewById(R.id.ll_seekbar_container).setVisibility(View.VISIBLE);
            this.tbFilterName.setVisibility(View.VISIBLE);
            return;
        }
        this.rootView.findViewById(R.id.ll_seekbar_container).setVisibility(View.GONE);
        this.tbFilterName.setVisibility(View.GONE);
    }

    private void setUpSeekBar(float f) {
        this.llSeekBarContainer.removeAllViews();
        this.indicatorSeekBar = IndicatorSeekBar.with(getContext()).max((float) this.sbMax).min((float) this.sbMin).progress(f).trackBackgroundSize(1).trackBackgroundColor(getActivity().getResources().getColor(R.color.colorLightGrey)).trackProgressSize(1).trackProgressColor(getActivity().getResources().getColor(R.color.colorLightGrey)).indicatorColor(getActivity().getResources().getColor(R.color.colorAccent)).showIndicatorType(1).thumbSize(15).thumbColor(getActivity().getResources().getColor(R.color.colorAccent)).build();
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        layoutParams.gravity = 17;
        this.llSeekBarContainer.addView(this.indicatorSeekBar, layoutParams);
    }

    public void loading(boolean z) {
        if (z) {
            this.rootView.findViewById(R.id.wg_flt_loading).setVisibility(View.VISIBLE);
        } else {
            this.rootView.findViewById(R.id.wg_flt_loading).setVisibility(View.GONE);
        }
    }

    @OnClick({R.id.tb_close})
    public void tbClose() {
        ((EditorActivity) getActivity()).setSelectedPhoto(null);
    }

    @OnClick({R.id.tb_done})
    public void tbDone() {
        if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
            try {
                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 101;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        }
        else {
           FilterDone();
        }

    }

    private void FilterDone(){
        new ResultDone(this).execute();
    }
    @OnClick({R.id.tv_cancel})
    public void tvCancel() {
        this.ivPhoto.setImageBitmap(this.crtBitmap);
        showSeekBar(false);
    }

    @OnClick({R.id.tv_done})
    public void tvDone() {
        this.filterProgress = (float) this.indicatorSeekBar.getProgress();
        this.finalProgress = this.filterProgress / 100.0f;
        this.crtBitmap = this.fltBitmap;
        this.ivPhoto.setImageBitmap(this.crtBitmap);
        showSeekBar(false);
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 101:
                        FilterDone();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.admob_interstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
