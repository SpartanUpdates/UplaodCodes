package com.esc.lovemessages;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.work.WorkRequest;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.ironsource.mediationsdk.IronSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class GreetingActivity extends AppCompatActivity {
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (GreetingActivity.i == 0) {
                GreetingActivity.i++;
                GreetingActivity.startbool = true;
                GreetingActivity.handler.postDelayed(GreetingActivity.changeAdBool, WorkRequest.DEFAULT_BACKOFF_DELAY_MILLIS);
                return;
            }
            GreetingActivity.showbool = true;
            GreetingActivity.i = 0;
            GreetingActivity.stopbool = true;
            GreetingActivity.stopRunnable();
        }
    };
    public static boolean display_AD = false;
    public static boolean exitbool = false;
    public static boolean gridclicked = false;
    public static Handler handler = new Handler();
    public static int height;
    static int i = 0;
    public static boolean showbool = false;
    static String source;
    public static boolean startbool = false;
    public static boolean stopbool = false;
    public static int width;
    DisplayMetrics displayMetrics;
    public Editor editor;
    public Editor editorAds;
    GridAdapter gridAdapter;
    GridView gridView;
    Integer[] img = new Integer[]{Integer.valueOf(R.drawable.thumb1), Integer.valueOf(R.drawable.thumb2), Integer.valueOf(R.drawable.thumb3), Integer.valueOf(R.drawable.thumb4), Integer.valueOf(R.drawable.thumb5), Integer.valueOf(R.drawable.thumb6), Integer.valueOf(R.drawable.thumb7), Integer.valueOf(R.drawable.thumb8), Integer.valueOf(R.drawable.thumb9), Integer.valueOf(R.drawable.thumb10), Integer.valueOf(R.drawable.thumb11), Integer.valueOf(R.drawable.thumb12), Integer.valueOf(R.drawable.thumb13), Integer.valueOf(R.drawable.thumb14)};
    Map<Integer, String> imgalign = new HashMap();
    String msg;
    private UnifiedNativeAd nativeAd;
    TextView selectcat;
    public SharedPreferences sharedPreferences;
    public SharedPreferences sharedPreferencesAds;
    Integer[] temp = new Integer[]{Integer.valueOf(R.drawable.temp1), Integer.valueOf(R.drawable.temp2), Integer.valueOf(R.drawable.temp3), Integer.valueOf(R.drawable.temp4), Integer.valueOf(R.drawable.temp5), Integer.valueOf(R.drawable.temp6), Integer.valueOf(R.drawable.temp7), Integer.valueOf(R.drawable.temp8), Integer.valueOf(R.drawable.temp9), Integer.valueOf(R.drawable.temp10), Integer.valueOf(R.drawable.temp11), Integer.valueOf(R.drawable.temp12), Integer.valueOf(R.drawable.temp13), Integer.valueOf(R.drawable.temp14)};
    Map<Integer, String> textalign = new HashMap();

    public GreetingActivity() {
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_greeting);
        MyApplication myApplication = (MyApplication) getApplication();
        String str = "MYPREFERENCE";
        this.sharedPreferences = getSharedPreferences(str, 0);
        this.sharedPreferencesAds = getSharedPreferences(str, 0);
        this.editorAds = this.sharedPreferencesAds.edit();
        this.editor = this.sharedPreferences.edit();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle((CharSequence) "");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        textView.setText("Personalize This Greeting");
        String str2 = "fonts/CormorantGaramond-Bold.ttf";
        textView.setTypeface(Typeface.createFromAsset(getAssets(), str2));
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        this.displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.displayMetrics);
        height = this.displayMetrics.heightPixels;
        width = this.displayMetrics.widthPixels;
        this.selectcat = (TextView) findViewById(R.id.selectcat);
        this.selectcat.setTypeface(Typeface.createFromAsset(getAssets(), str2));
        String str3 = "bottom";
        this.textalign.put(Integer.valueOf(R.drawable.temp1), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp2), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp3), str3);
        String str4 = "top";
        this.textalign.put(Integer.valueOf(R.drawable.temp4), str4);
        this.textalign.put(Integer.valueOf(R.drawable.temp5), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp6), str4);
        this.textalign.put(Integer.valueOf(R.drawable.temp7), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp8), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp9), str3);
        this.textalign.put(Integer.valueOf(R.drawable.temp10), str4);
        this.textalign.put(Integer.valueOf(R.drawable.temp11), str3);
        String str5 = "center";
        this.textalign.put(Integer.valueOf(R.drawable.temp12), str5);
        this.textalign.put(Integer.valueOf(R.drawable.temp13), str4);
        this.textalign.put(Integer.valueOf(R.drawable.temp14), str4);
        this.imgalign.put(Integer.valueOf(R.drawable.temp1), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp2), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp3), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp4), "rightbottom");
        this.imgalign.put(Integer.valueOf(R.drawable.temp5), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp6), "leftbottom");
        this.imgalign.put(Integer.valueOf(R.drawable.temp7), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp8), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp9), str5);
        this.imgalign.put(Integer.valueOf(R.drawable.temp10), "leftbottom");
        this.imgalign.put(Integer.valueOf(R.drawable.temp11), str5);
        str2 = "null";
        this.imgalign.put(Integer.valueOf(R.drawable.temp12), str2);
        this.imgalign.put(Integer.valueOf(R.drawable.temp13), str2);
        this.imgalign.put(Integer.valueOf(R.drawable.temp14), str2);
        bundle = getIntent().getExtras();
        this.msg = bundle.getString(NotificationCompat.CATEGORY_MESSAGE);
        source = bundle.getString("source");
        str = source;
        if (str != null) {
            this.editor.putString("source", str);
            this.editor.commit();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(",,,,");
        stringBuilder.append(this.msg);
        Log.e("****msg", stringBuilder.toString());
        this.gridAdapter = new GridAdapter(getApplicationContext(), this.img);
        this.gridView = (GridView) findViewById(R.id.categorygrid);
        this.gridView.setAdapter(this.gridAdapter);
        this.gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                GreetingActivity.gridclicked = true;
                Intent intent = new Intent(GreetingActivity.this, DemoActivity.class);
                String str = "images";
                if (i > 10) {
                    intent.putExtra(str, "no");
                } else {
                    intent.putExtra(str, "yes");
                }
                str = "txtcolor";
                if (i == 1 || i == 2) {
                    intent.putExtra(str, "white");
                } else {
                    intent.putExtra(str, "black");
                }
                for (Entry entry : GreetingActivity.this.textalign.entrySet()) {
                    if (((Integer) entry.getKey()).equals(GreetingActivity.this.temp[i])) {
                        intent.putExtra("textalign", (String) entry.getValue());
                    }
                }
                for (Entry entry2 : GreetingActivity.this.imgalign.entrySet()) {
                    if (((Integer) entry2.getKey()).equals(GreetingActivity.this.temp[i])) {
                        intent.putExtra("imgalign", (String) entry2.getValue());
                    }
                }
                intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, GreetingActivity.this.msg);
                intent.putExtra("selectedimage", GreetingActivity.this.temp[i]);
                GreetingActivity.this.startActivity(intent);
                DemoActivity.change_bg = false;
            }
        });
        MobileAds.initialize((Context) this, new OnInitializationCompleteListener() {
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }




    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }


    public static void stopRunnable() {
        if (stopbool) {
            handler.removeCallbacks(changeAdBool);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();

    }
}
