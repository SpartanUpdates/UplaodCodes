package com.kotlinz.videoCollage.flying.poiphoto;

import android.os.AsyncTask;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Photo;
import java.util.List;

public class GetAllPhotoTask extends AsyncTask<PhotoManager, Integer, List<Photo>> {
    private static final String TAG = "GetAllPhotoTask";


    public List<Photo> doInBackground(PhotoManager... photoManagerArr) {
        return photoManagerArr[0].getAllPhoto();
    }
}
