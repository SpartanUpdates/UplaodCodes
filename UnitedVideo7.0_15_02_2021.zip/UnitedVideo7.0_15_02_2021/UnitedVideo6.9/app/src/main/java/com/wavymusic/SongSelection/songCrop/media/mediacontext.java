package com.wavymusic.SongSelection.songCrop.media;

import android.content.Context;

public class mediacontext {
    public static int context(Context context, float f) {
        return (int) ((f * context.getResources().getDisplayMetrics().density) + 0.5f);
    }
}
