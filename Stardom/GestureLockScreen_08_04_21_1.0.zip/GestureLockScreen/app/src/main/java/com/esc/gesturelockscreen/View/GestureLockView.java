package com.esc.gesturelockscreen.View;

import android.annotation.SuppressLint;
import android.content.Context;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGestureListener;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.Prediction;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.R;
import java.io.File;
import java.util.ArrayList;
import androidx.annotation.NonNull;

public class GestureLockView extends FrameLayout {
    Context context;
    private boolean create = true;
    private GestureLibrary gestureLib;
    private OnGesturePerformedListener gestureListener = new gestureloack();
    private IGestureLockListener listener;
    private Gesture mGesture;
    private GestureOverlayView mGestureView;
    private Handler mHandlerWrong = new Handler();
    private Runnable mRunnableWrong = new runnableHendler();
    private GESTUREMODE myMode = GESTUREMODE.MODE_WAIT;
    private TextView tvSubtitle;

    class gestureloack implements OnGesturePerformedListener {
        gestureloack() {
        }

        public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
            try {
                ArrayList<Prediction> predictions = GestureLockView.this.gestureLib.recognize(gesture);
                if (predictions == null || predictions.size() <= 0 || ((Prediction) predictions.get(0)).score <= ((double) SettingsUtils.getDifficultyLevel()) || !((Prediction) predictions.get(0)).name.equalsIgnoreCase("pass")) {
                    GestureLockView.this.mGestureView.clear(true);
                    if (GestureLockView.this.myMode == GESTUREMODE.MODE_UNLOCK || GestureLockView.this.myMode == GESTUREMODE.MODE_VERIFY) {
                        GestureLockView.this.tvSubtitle.setText("Your drew wrong Signature");
                        GestureLockView.this.mHandlerWrong.removeCallbacks(GestureLockView.this.mRunnableWrong);
                        GestureLockView.this.mHandlerWrong.postDelayed(GestureLockView.this.mRunnableWrong, 2000);
                    }
                    if (GestureLockView.this.listener != null) {
                        GestureLockView.this.listener.onDrawWrong(gesture);
                    }
                } else if (GestureLockView.this.listener != null) {
                    GestureLockView.this.listener.onUnLockSuccess(GestureLockView.this.myMode);
                }
            } catch (Exception e) {
                e.printStackTrace();
                GestureLockView.this.mGestureView.clear(true);
                if (GestureLockView.this.myMode == GESTUREMODE.MODE_UNLOCK || GestureLockView.this.myMode == GESTUREMODE.MODE_VERIFY) {
                    GestureLockView.this.tvSubtitle.setText("Your drew wrong Signature");
                    GestureLockView.this.mHandlerWrong.removeCallbacks(GestureLockView.this.mRunnableWrong);
                    GestureLockView.this.mHandlerWrong.postDelayed(GestureLockView.this.mRunnableWrong, 2000);
                }
                if (GestureLockView.this.listener != null) {
                    GestureLockView.this.listener.onDrawWrong(gesture);
                }
            }
        }
    }

    class runnableHendler implements Runnable {
        runnableHendler() {
        }

        public void run() {
            GestureLockView.this.tvSubtitle.setText(GestureLockView.this.myMode.textId);
        }
    }

    public enum GESTUREMODE {
        MODE_CREATE(R.string.gesture_title_create),
        MODE_CONFIRM(R.string.gesture_title_confirm),
        MODE_VERIFY(R.string.gesture_title_verify),
        MODE_UNLOCK(R.string.gesture_title_unlock),
        MODE_WAIT(R.string.wait_sec);

        int textId;

        private GESTUREMODE(int textId) {
            this.textId = textId;
        }
    }

    private class GesturesProcessor implements OnGestureListener {
        GestureLibrary tempGeLibrary;

        private GesturesProcessor() {
        }

        public void onGestureStarted(GestureOverlayView overlay, MotionEvent event) {
        }

        public void onGesture(GestureOverlayView overlay, MotionEvent event) {
        }

        public void onGestureEnded(GestureOverlayView overlay, MotionEvent event) {
            if (GestureLockView.this.myMode == GESTUREMODE.MODE_CREATE) {
                GestureLockView.this.mGesture = overlay.getGesture();
                if (GestureLockView.this.mGesture.getLength() < 120.0f) {
                    overlay.clear(false);
                    return;
                }
                overlay.clear(false);
                String name = "temp_" + System.currentTimeMillis();
                this.tempGeLibrary = GestureLibraries.fromFile(new File(GestureLockView.this.getContext().getFilesDir(), name));
                this.tempGeLibrary.addGesture("temp", GestureLockView.this.mGesture);
                this.tempGeLibrary.save();
                this.tempGeLibrary = GestureLibraries.fromFile(new File(GestureLockView.this.getContext().getFilesDir(), name));
                this.tempGeLibrary.load();
                if (GestureLockView.this.listener != null) {
                    GestureLockView.this.listener.onUnDrawRecorded(GestureLockView.this.mGesture);
                }
                GestureLockView.this.myMode = GESTUREMODE.MODE_CONFIRM;
            } else if (this.tempGeLibrary != null && GestureLockView.this.myMode == GESTUREMODE.MODE_CONFIRM) {
                GestureLockView.this.mGesture = overlay.getGesture();
                try {
                    ArrayList<Prediction> predictions = this.tempGeLibrary.recognize(GestureLockView.this.mGesture);
                    if (((Prediction) predictions.get(0)).score > ((double) SettingsUtils.getDifficultyLevel()) && ((Prediction) predictions.get(0)).name.equalsIgnoreCase("temp") && GestureLockView.this.listener != null && GestureLockView.this.addGesture(GestureLockView.this.mGesture)) {
                        GestureLockView.this.listener.onUnLockSuccess(GestureLockView.this.myMode);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void onGestureCancelled(GestureOverlayView overlay, MotionEvent event) {
        }
    }

    public interface IGestureLockListener {
        void onDrawWrong(Gesture gesture);

        void onNotLoadedError();

        void onUnDrawRecorded(Gesture gesture);

        void onUnLockSuccess(GESTUREMODE gesturemode);
    }

    public GestureLockView(Context context) {
        super(context);
        init(context);
    }

    public GestureLockView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    @SuppressLint({"NewApi"})
    public GestureLockView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @SuppressLint({"NewApi"})
    public GestureLockView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context) {
        this.context = context;
        addView(LayoutInflater.from(getContext()).inflate(R.layout.layout_gesture_lock, this, false));
        this.mGestureView = (GestureOverlayView) findViewById(R.id.gestures_overlay);
        this.tvSubtitle = (TextView) findViewById(R.id.gesture_lock_title);

    }

    public void onInitMode(GESTUREMODE mode) {
        setNewMode(mode);
        if (SettingsUtils.hideGesture() && mode == GESTUREMODE.MODE_UNLOCK) {
            this.mGestureView.setGestureColor(0);
            this.mGestureView.setUncertainGestureColor(0);
        } else {
            this.mGestureView.setGestureColor(SettingsUtils.getGestureColor());
            this.mGestureView.setUncertainGestureColor(SettingsUtils.getUncertainGestureColor());
        }
        this.gestureLib = GestureLibraries.fromFile(new File(getContext().getFilesDir(), "gesture.lock"));
        if (this.gestureLib.load()) {
            this.create = false;
        } else {
            if (this.listener != null) {
                this.listener.onNotLoadedError();
            }
            this.create = true;
        }
        if ((mode == GESTUREMODE.MODE_VERIFY || mode == GESTUREMODE.MODE_UNLOCK) && !this.create) {
            this.mGestureView.removeAllOnGestureListeners();
            this.mGestureView.removeAllOnGesturePerformedListeners();
            this.mGestureView.addOnGesturePerformedListener(this.gestureListener);
            return;
        }
        this.mGestureView.removeAllOnGesturePerformedListeners();
        this.mGestureView.removeAllOnGestureListeners();
        this.mGestureView.addOnGestureListener(new GesturesProcessor());
    }

    public void setListener(@NonNull IGestureLockListener l) {
        this.listener = l;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
    }

    public void onScreenOff() {
        this.mGestureView.removeAllOnGesturePerformedListeners();
    }

    public void onScreenOn() {
        this.mGestureView.addOnGesturePerformedListener(this.gestureListener);
    }

    public void setNewMode(GESTUREMODE mode) {
        if (this.myMode != mode) {
            this.myMode = mode;
            if (findViewById(R.id.gesture_lock_title) != null) {
                ((TextView) findViewById(R.id.gesture_lock_title)).setText(mode.textId);
            }
        }
    }

    public void switchToCreateMode() {
        onInitMode(GESTUREMODE.MODE_CREATE);
    }

    public boolean addGesture(Gesture mGesture) {
        if (mGesture == null) {
            return false;
        }
        String name = "pass";
        if (!this.create) {
            this.gestureLib.removeEntry("pass");
        }
        this.gestureLib.addGesture(name.toString(), mGesture);
        return this.gestureLib.save();
    }
}
