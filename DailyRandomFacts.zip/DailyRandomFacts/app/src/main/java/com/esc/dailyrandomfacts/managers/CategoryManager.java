package com.esc.dailyrandomfacts.managers;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.esc.dailyrandomfacts.util.Quotes;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.model.Category;
import java.util.ArrayList;
import java.util.List;

public class CategoryManager {
    private static final String PREF_CATEGORY_REMINDERS = "pref_category_reminderscom.esc.dailyrandomfacts.facts";
    private static final String PREF_CATEGORY_SELECTED = "PREF_CATEGORY_SELECTED_com.esc.dailyrandomfacts.facts";
    private static final String PREF_NEW_CATEGORY = "PREF_NEW_CATEGORYcom.esc.dailyrandomfacts.facts";
    private static final String PREF_NEW_THEME = "PREF_NEW_THEMEcom.esc.dailyrandomfacts.facts";

    private static Context getContext() {
        return Quotes.getInstance();
    }

    public static void addCategoryReminder(Category category) {
        ArrayList categoriesReminders = getCategoriesReminders();
        if (categoriesReminders.isEmpty()) {
            categoriesReminders = new ArrayList();
        }
        if (!categoriesReminders.contains(category)) {
            categoriesReminders.add(category);
        }
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        if (categoriesReminders != null) {
            edit.putString(PREF_CATEGORY_REMINDERS, new Gson().toJson(categoriesReminders));
        }
        edit.commit();
    }

    public static ArrayList<Category> getCategoriesReminders() {
        String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_CATEGORY_REMINDERS, null);
        if (string != null) {
            return (ArrayList) new Gson().fromJson(string, new TypeToken<List<Category>>() {
            }.getType());
        }
        return new ArrayList();
    }

    public static void clearCategoriesReminder() {
        Object arrayList = new ArrayList();
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putString(PREF_CATEGORY_REMINDERS, new Gson().toJson(arrayList));
        edit.commit();
    }

    public static void setCategorySelected(String str) {
        PreferenceManager.getDefaultSharedPreferences(getContext()).edit().putString(PREF_CATEGORY_SELECTED, str).apply();
    }

    public static String getCategorySelected() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_CATEGORY_SELECTED, getContext().getString(R.string.default_category));
    }

    public static void setNewCategory(boolean z) {
        PreferenceManager.getDefaultSharedPreferences(getContext()).edit().putBoolean(PREF_NEW_CATEGORY, z).apply();
    }

    public static Boolean hasNewCategory() {
        return Boolean.valueOf(PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_NEW_CATEGORY, true));
    }

    public static void setNewTheme(boolean z) {
        PreferenceManager.getDefaultSharedPreferences(getContext()).edit().putBoolean(PREF_NEW_THEME, z).apply();
    }

    public static Boolean hasNewTheme() {
        return Boolean.valueOf(PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean(PREF_NEW_THEME, true));
    }
}
