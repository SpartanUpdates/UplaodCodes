package com.example.womenabsworkout.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.womenabsworkout.ConstantValues;
import com.example.womenabsworkout.R;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class Activity_MyProfile extends AppCompatActivity {
    Activity activity = Activity_MyProfile.this;
    private String age;
    private TextView age_profile;
    RelativeLayout change_profile;
    private String gender;
    private TextView gender_profile;
    private String height;
    private TextView height_profile;
    private ImageView imageView;
    private Toolbar toolbar;
    private String weight;
    private TextView weight_profile;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activyt_profile);
        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));


        BannerAds();
        interstitialAd();

        initializeviews();
        getUserData();
    }

    private void initializeviews() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.gender_profile = (TextView) findViewById(R.id.gender_profile);
        this.age_profile = (TextView) findViewById(R.id.age_profile);
        this.height_profile = (TextView) findViewById(R.id.height_profile);
        this.weight_profile = (TextView) findViewById(R.id.weight_profile);
        this.change_profile = (RelativeLayout) findViewById(R.id.reset_profile);
        ImageView imageView = (ImageView) findViewById(R.id.back_arrow);
        this.imageView = imageView;

        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Activity_MyProfile.this.onBackPressed();
            }
        });

        this.change_profile.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Activity_MyProfile.this.startActivity(new Intent(Activity_MyProfile.this, UserDetailsActivity.class));
                    Activity_MyProfile.this.finish();
                }

            }
        });
    }

    private void getUserData() {
        SharedPreferences sharedPreferences = getSharedPreferences(ConstantValues.PREFS_NAME, 0);
        String str = (String) null;
        this.gender = sharedPreferences.getString("gender", str);
        this.age = sharedPreferences.getString("age", str);
        this.height = sharedPreferences.getString("height", str);
        this.weight = sharedPreferences.getString("weight", str);
        this.gender_profile.setText(this.gender);
        this.age_profile.setText(this.age);
        this.weight_profile.setText(this.weight);
        this.height_profile.setText(this.height);
    }

    public void onBackPressed() {
        finish();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.admob_banner_ad));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        Activity_MyProfile.this.startActivity(new Intent(Activity_MyProfile.this, UserDetailsActivity.class));
                        Activity_MyProfile.this.finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
