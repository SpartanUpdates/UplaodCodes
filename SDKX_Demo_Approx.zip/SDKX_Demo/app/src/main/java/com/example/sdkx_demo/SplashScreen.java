package com.example.sdkx_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.greedygame.core.GreedyGameAds;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.AppOpenAdsEventsListener;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interfaces.PrefetchAdsListener;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.greedygame.core.models.general.PrefetchUnit;

public class SplashScreen extends AppCompatActivity {
    public  static GGInterstitialAd mAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);

        PrefetchAdsListener listener = new PrefetchAdsListener() {
            @Override
            public void onAdPrefetched(String unitId) {
                Intent i = new Intent(SplashScreen.this, StartScreen.class);
                startActivity(i);
            }



            @Override
            public void onAdPrefetchFailed(String unitId, AdErrors cause) {
                Intent i = new Intent(SplashScreen.this, StartScreen.class);
                startActivity(i);
            }

            @Override
            public void onPrefetchComplete() {
            }
        };
        PrefetchUnit[] units = {new PrefetchUnit("float-8279", PrefetchUnit.UnitType.APP_OPEN)};
        GreedyGameAds.prefetchAds(listener, units);

        GGAppOpenAds.setListener(new AppOpenAdsEventsListener() {
            @Override
            public void onAdLoaded() {
                Log.d("GGADS", "AppOpenAd loaded");
            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {
                Log.d("GGADS", "AppOpenAd load failed " + cause);
            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdOpened() {
                Log.d("GGADS", "AppOpenAd Opened");
            }

            @Override
            public void onAdClosed() {
                Log.d("GGADS", "AppOpenAd closed");
            }

        });
        GGAppOpenAds.loadAd("float-8279");

        mAd = new GGInterstitialAd(SplashScreen.this,"float-8278");
        mAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {
                Log.d("GGADS","Ad Loaded");
            }

            @Override
            public void onAdClosed() {
                mAd.loadAd();
                Log.d("GGADS","Ad Closed");
            }
            @Override
            public void onAdOpened() {
                Log.d("GGADS","Ad Opened");
            }

            @Override
            public void onAdShowFailed() {
                Log.d("GGADS","Ad Show failed" );
            }

            @Override
            public void onAdLoadFailed (AdErrors cause) {
                Log.d("GGADS","Ad Load Failed "+cause);
            }
        });
        mAd.loadAd();
    }
}
