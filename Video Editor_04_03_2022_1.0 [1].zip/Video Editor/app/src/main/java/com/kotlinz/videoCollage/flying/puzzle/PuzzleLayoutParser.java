package com.kotlinz.videoCollage.flying.puzzle;

import android.graphics.RectF;

import com.kotlinz.videoCollage.flying.puzzle.slant.SlantPuzzleLayout;
import com.kotlinz.videoCollage.flying.puzzle.straight.StraightPuzzleLayout;

class PuzzleLayoutParser {
    private PuzzleLayoutParser() {
    }

    public static PuzzleLayout parse(final PuzzleLayout.Info info) {
        PuzzleLayout anonymousClass1;
        if (info.type == 0) {
            anonymousClass1 = new StraightPuzzleLayout() {
                public void layout() {
                    int size = info.steps.size();
                    for (int i = 0; i < size; i++) {
                        Step step = (Step) info.steps.get(i);
                        int i2 = step.type;
                        if (i2 == 0) {
                            addLine(step.position, step.lineDirection(), 0.5f);
                        } else if (i2 == 1) {
                            addCross(step.position, 0.5f);
                        } else if (i2 == 2) {
                            cutAreaEqualPart(step.position, step.hSize, step.vSize);
                        } else if (i2 == 3) {
                            cutAreaEqualPart(step.position, step.part, step.lineDirection());
                        } else if (i2 == 4) {
                            cutSpiral(step.position);
                        }
                    }
                }
            };
        } else {
            anonymousClass1 = new SlantPuzzleLayout() {
                public void layout() {
                    int size = info.steps.size();
                    for (int i = 0; i < size; i++) {
                        Step step = (Step) info.steps.get(i);
                        int i2 = step.type;
                        if (i2 == 0) {
                            addLine(step.position, step.lineDirection(), 0.5f);
                        } else if (i2 == 1) {
                            addCross(step.position, 0.5f, 0.5f, 0.5f, 0.5f);
                        } else if (i2 == 2) {
                            cutArea(step.position, step.hSize, step.vSize);
                        }
                    }
                }
            };
        }
        anonymousClass1.setOuterBounds(new RectF(info.left, info.top, info.right, info.bottom));
        anonymousClass1.layout();
        anonymousClass1.setColor(info.color);
        anonymousClass1.setRadian(info.radian);
        anonymousClass1.setPadding(info.padding);
        int size = info.lineInfos.size();
        for (int i = 0; i < size; i++) {
            PuzzleLayout.LineInfo lineInfo = (PuzzleLayout.LineInfo) info.lineInfos.get(i);
            Line line = (Line) anonymousClass1.getLines().get(i);
            line.startPoint().x = lineInfo.startX;
            line.startPoint().y = lineInfo.startY;
            line.endPoint().x = lineInfo.endX;
            line.endPoint().y = lineInfo.endY;
        }
        anonymousClass1.sortAreas();
        anonymousClass1.update();
        return anonymousClass1;
    }
}
