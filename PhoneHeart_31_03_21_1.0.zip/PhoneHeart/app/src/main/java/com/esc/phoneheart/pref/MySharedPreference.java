package com.esc.phoneheart.pref;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MySharedPreference {
    public static final String DUPLICATED = "DUPLICATED";
    public static Editor editor;
    public static SharedPreferences sharePref;

    public static int getLngIndex(Context context) {
        String str = "lng_index";
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 0);
        sharePref = sharedPreferences;
        return sharedPreferences.getInt(str, 0);
    }

    public static boolean isAVFree(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(DUPLICATED, 0);
        sharePref = sharedPreferences;
        return sharedPreferences.getBoolean("avfree", false);
    }

    public static boolean isAdsFree(Context context) {
        sharePref = context.getSharedPreferences(DUPLICATED, 0);
        return true;
    }

    public static boolean isAllInOne(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(DUPLICATED, 0);
        sharePref = sharedPreferences;
        return sharedPreferences.getBoolean("all_inone", false);
    }

    public static void setLngIndex(Context context, int i) {
        String str = "lng_index";
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 0);
        sharePref = sharedPreferences;
        Editor edit = sharedPreferences.edit();
        editor = edit;
        edit.putInt(str, i);
        editor.apply();
    }
}
