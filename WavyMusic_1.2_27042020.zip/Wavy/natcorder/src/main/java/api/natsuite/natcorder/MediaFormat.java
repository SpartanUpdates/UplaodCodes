//package api.natsuite.natcorder;
//
//import java.nio.ByteBuffer;
//
//public abstract class MediaFormat {
//    protected static final String KEY_MIME = "mime";
//    protected static final String KEY_DURATION = "durationUs";
//
//    public MediaFormat() {
//    }
//
//    public String getMimeType() {
//        return this.getString("mime");
//    }
//
//    public long getDuration() {
//        return this.getLong("durationUs");
//    }
//
//    public abstract ByteBuffer getByteBuffer(String var1);
//
//    protected abstract void setInteger(String var1, int var2);
//
//    protected abstract int getInteger(String var1);
//
//    protected abstract long getLong(String var1);
//
//    protected abstract String getString(String var1);
//}
