package com.kotlinz.videoCollage.interfaces;

public interface TextFontAdapterCallBackInterface {
    void itemClick(int i, String str);
}
