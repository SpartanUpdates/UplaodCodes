package api.natsuite.natcorder;

import android.os.*;
import android.util.*;
import java.io.*;
import java.nio.*;
import api.natsuite.natrender.*;
import api.natsuite.natcorder.utility.*;

public class GIFRecorder implements MediaRecorder
{
    private final HandlerThread writerThread;
    private final Handler delegateHandler;
    private final int width;
    private final int height;
    private final int delay;
    private String recordingPath;
    private Callback delegate;
    private OutputStream outputStream;
    private byte[] indexedPixels;
    private Handler writerHandler;
    private final int PALETTE_SIZE = 7;
    private final int R_RANGE = 6;
    private final int G_RANGE = 7;
    private final int B_RANGE = 6;
    
    public GIFRecorder(final int width, final int height, final float frameDuration) {
        this.writerThread = new HandlerThread("NatCorder GIF Encoding Thread");
        this.delegateHandler = new Handler(Looper.myLooper());
        this.width = width;
        this.height = height;
        this.delay = (int)(100.0f * frameDuration);
    }
    
    @Override
    public void startRecording(final String recordingPath, final Callback delegate) {
        this.recordingPath = recordingPath;
        this.delegate = delegate;
        try {
            this.outputStream = new FileOutputStream(recordingPath);
        }
        catch (IOException ex) {
            Log.e("Unity", "NatCorder Error: Failed to create GIF encoder", (Throwable)ex);
            return;
        }
        this.indexedPixels = new byte[this.width * this.height];
        Log.v("Unity", "NatCorder: Preparing GIF encoder with format: " + this.width + "x" + this.height + " @" + 10 * this.delay + "Ms");
        this.writerThread.start();
        (this.writerHandler = new Handler(this.writerThread.getLooper())).post((Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    GIFRecorder.this.writeString("GIF89a");
                    GIFRecorder.this.writeLSD();
                    GIFRecorder.this.writeGCT();
                    GIFRecorder.this.writeNetscapeExt();
                    Log.v("Unity", "NatCorder: GIFRecorder started recording");
                }
                catch (IOException ex) {
                    Log.e("Unity", "NatCorder: GIF encoding encountered exception", (Throwable)ex);
                    GIFRecorder.this.writerThread.quit();
                }
            }
        });
    }
    
    @Override
    public void stopRecording() {
        this.writerHandler.post((Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    GIFRecorder.this.outputStream.write(59);
                    GIFRecorder.this.outputStream.flush();
                    GIFRecorder.this.outputStream.close();
                    Log.v("Unity", "NatCorder: GIFRecorder stopped recording");
                    GIFRecorder.this.delegateHandler.post((Runnable)new Runnable() {
                        @Override
                        public void run() {
                            GIFRecorder.this.delegate.onRecording(GIFRecorder.this.recordingPath);
                        }
                    });
                }
                catch (IOException ex) {
                    Log.e("Unity", "NatCorder: GIF encoding encountered exception", (Throwable)ex);
                }
                finally {
                    GIFRecorder.this.writerThread.quit();
                }
            }
        });
    }
    
    @Override
    public void encodeFrame(final ByteBuffer pixelBuffer, final long timestamp) {
        final byte[] pixelData = new byte[this.width * this.height * 4];
        for (int i = this.height - 1; i >= 0; --i) {
            pixelBuffer.get(pixelData, i * this.width * 4, this.width * 4);
        }
        this.writerHandler.post((Runnable)new Runnable() {
            @Override
            public void run() {
                GIFRecorder.this.dither(pixelData, GIFRecorder.this.indexedPixels);
                try {
                    GIFRecorder.this.writeGraphicCtrlExt();
                    GIFRecorder.this.writeLCT();
                    GIFRecorder.this.writePixels(GIFRecorder.this.indexedPixels);
                }
                catch (IOException ex) {
                    Log.e("Unity", "NatCorder: GIF encoding encountered exception", (Throwable)ex);
                    GIFRecorder.this.writerThread.quit();
                }
            }
        });
    }
    
    @Override
    public synchronized void encodeFrame(final long nativeBuffer, final long timestamp) {
        this.encodeFrame(Unmanaged.wrapBuffer(nativeBuffer, (long)(this.width * this.height * 4)), timestamp);
    }
    
    @Override
    public void encodeSamples(final float[] samples, final long timestamp) {
    }
    
    private int readPixel(final byte[] pixelBuffer, final int x, final int y, final int channel) {
        return pixelBuffer[4 * x + y * this.width * 4 + channel] & 0xFF;
    }
    
    private void writePixel(final byte[] pixelBuffer, final int x, final int y, final int channel, final int value) {
        pixelBuffer[4 * x + y * this.width * 4 + channel] = (byte)Math.min(255, Math.max(0, value));
    }
    
    private void dither(final byte[] srcPixels, final byte[] dstPixels) {
        for (int y = 0; y < this.height; ++y) {
            for (int x = 0; x < this.width; ++x) {
                final int ri = this.readPixel(srcPixels, x, y, 0);
                final int gi = this.readPixel(srcPixels, x, y, 1);
                final int bi = this.readPixel(srcPixels, x, y, 2);
                final int ro = (ri * 5 + 127) / 255;
                final int go = (gi * 6 + 127) / 255;
                final int bo = (bi * 5 + 127) / 255;
                dstPixels[x + y * this.width] = (byte)(ro * 42 + go * 6 + bo);
                if (x != 0) {
                    if (x != this.width - 1) {
                        if (y != this.height - 1) {
                            final int re = ri - 255 * ro / 5;
                            final int ge = gi - 255 * go / 6;
                            final int be = bi - 255 * bo / 5;
                            int xi = x + 1;
                            int yi = y;
                            this.writePixel(srcPixels, xi, yi, 0, this.readPixel(srcPixels, xi, yi, 0) + re * 7 / 16);
                            this.writePixel(srcPixels, xi, yi, 1, this.readPixel(srcPixels, xi, yi, 1) + ge * 7 / 16);
                            this.writePixel(srcPixels, xi, yi, 2, this.readPixel(srcPixels, xi, yi, 2) + be * 7 / 16);
                            xi = x - 1;
                            yi = y + 1;
                            this.writePixel(srcPixels, xi, yi, 0, this.readPixel(srcPixels, xi, yi, 0) + re * 3 / 16);
                            this.writePixel(srcPixels, xi, yi, 1, this.readPixel(srcPixels, xi, yi, 1) + ge * 3 / 16);
                            this.writePixel(srcPixels, xi, yi, 2, this.readPixel(srcPixels, xi, yi, 2) + be * 3 / 16);
                            xi = x;
                            yi = y + 1;
                            this.writePixel(srcPixels, xi, yi, 0, this.readPixel(srcPixels, xi, yi, 0) + re * 5 / 16);
                            this.writePixel(srcPixels, xi, yi, 1, this.readPixel(srcPixels, xi, yi, 1) + ge * 5 / 16);
                            this.writePixel(srcPixels, xi, yi, 2, this.readPixel(srcPixels, xi, yi, 2) + be * 5 / 16);
                            xi = x + 1;
                            yi = y + 1;
                            this.writePixel(srcPixels, xi, yi, 0, this.readPixel(srcPixels, xi, yi, 0) + re * 1 / 16);
                            this.writePixel(srcPixels, xi, yi, 1, this.readPixel(srcPixels, xi, yi, 1) + ge * 1 / 16);
                            this.writePixel(srcPixels, xi, yi, 2, this.readPixel(srcPixels, xi, yi, 2) + be * 1 / 16);
                        }
                    }
                }
            }
        }
    }
    
    private void writeGraphicCtrlExt() throws IOException {
        this.outputStream.write(33);
        this.outputStream.write(249);
        this.outputStream.write(4);
        this.outputStream.write(0);
        this.writeShort(this.delay);
        this.outputStream.write(0);
        this.outputStream.write(0);
    }
    
    private void writeLSD() throws IOException {
        this.writeShort(this.width);
        this.writeShort(this.height);
        this.outputStream.write(247);
        this.outputStream.write(0);
        this.outputStream.write(0);
    }
    
    private void writeGCT() throws IOException {
        final byte[] colorTable = new byte[768];
        int r = 0;
        int index = 0;
        while (r < 6) {
            for (int g = 0; g < 7; ++g) {
                for (int b = 0; b < 6; ++b, ++index) {
                    colorTable[index * 3] = (byte)(255 * r / 5);
                    colorTable[index * 3 + 1] = (byte)(255 * g / 6);
                    colorTable[index * 3 + 2] = (byte)(255 * b / 5);
                }
            }
            ++r;
        }
        this.outputStream.write(colorTable);
    }
    
    private void writeLCT() throws IOException {
        this.outputStream.write(44);
        this.writeShort(0);
        this.writeShort(0);
        this.writeShort(this.width);
        this.writeShort(this.height);
        this.outputStream.write(7);
    }
    
    private void writeNetscapeExt() throws IOException {
        this.outputStream.write(33);
        this.outputStream.write(255);
        this.outputStream.write(11);
        this.writeString("NETSCAPE2.0");
        this.outputStream.write(3);
        this.outputStream.write(1);
        this.writeShort(0);
        this.outputStream.write(0);
    }
    
    private void writePixels(final byte[] indexedPixels) throws IOException {
        final int COLOR_DEPTH = 8;
        final LZWEncoder imageWriter = new LZWEncoder(this.width, this.height, 8);
        imageWriter.encode(indexedPixels, this.outputStream);
    }
    
    private void writeShort(final int value) throws IOException {
        this.outputStream.write(value & 0xFF);
        this.outputStream.write(value >> 8 & 0xFF);
    }
    
    private void writeString(final String s) throws IOException {
        for (int i = 0; i < s.length(); ++i) {
            this.outputStream.write((byte)s.charAt(i));
        }
    }
}
