package com.kotlinz.videoCollage.crop;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.view.View;

public class ImageViewUtil {
    public static Rect getBitmapRectCenterInside(Bitmap bitmap, View view) {
        return getBitmapRectCenterInsideHelper(bitmap.getWidth(), bitmap.getHeight(), view.getWidth(), view.getHeight());
    }

    public static Rect getBitmapRectCenterInside(int i, int i2, int i3, int i4) {
        return getBitmapRectCenterInsideHelper(i, i2, i3, i4);
    }

    private static Rect getBitmapRectCenterInsideHelper(int i, int i2, int i3, int i4) {
        double d;
        double d2;
        long round;
        double d3 = i3 < i ? ((double) i3) / ((double) i) : Double.POSITIVE_INFINITY;
        double d4 = i4 < i2 ? ((double) i4) / ((double) i2) : Double.POSITIVE_INFINITY;
        if (d3 == Double.POSITIVE_INFINITY && d4 == Double.POSITIVE_INFINITY) {
            d = (double) i2;
            d2 = (double) i;
        } else if (d3 <= d4) {
            d = (double) i3;
            double d5 = (((double) i2) * d) / ((double) i);
            d2 = d;
            d = d5;
        } else {
            d = (double) i4;
            d2 = (((double) i) * d) / ((double) i2);
        }
        d3 = (double) i3;
        i3 = 0;
        if (d2 == d3) {
            round = Math.round((((double) i4) - d) / 2.0d);
        } else {
            double d6 = (double) i4;
            if (d == d6) {
                i3 = (int) Math.round((d3 - d2) / 2.0d);
                i4 = 0;
                return new Rect(i3, i4, ((int) Math.ceil(d2)) + i3, ((int) Math.ceil(d)) + i4);
            }
            i3 = (int) Math.round((d3 - d2) / 2.0d);
            round = Math.round((d6 - d) / 2.0d);
        }
        i4 = (int) round;
        return new Rect(i3, i4, ((int) Math.ceil(d2)) + i3, ((int) Math.ceil(d)) + i4);
    }
}
