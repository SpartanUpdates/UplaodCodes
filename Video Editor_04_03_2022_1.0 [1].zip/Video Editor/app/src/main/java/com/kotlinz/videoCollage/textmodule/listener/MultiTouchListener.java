package com.kotlinz.videoCollage.textmodule.listener;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.RelativeLayout;
import androidx.core.view.MotionEventCompat;

import com.kotlinz.videoCollage.textmodule.AutofitTextRel;

public class MultiTouchListener implements OnTouchListener {
    private static final int INVALID_POINTER_ID = -1;
    Bitmap bitmap;
    boolean bt = false;
    GestureDetector gd = null;
    public boolean isLockEnabled = false;
    public boolean isRotateEnabled = true;
    public boolean isRotationEnabled = false;
    public boolean isTranslateEnabled = true;
    private TouchCallbackListener listener = null;
    private int mActivePointerId = -1;
    Context mContext;
    private float mPrevX;
    private float mPrevY;
    private ScaleGestureDetector mScaleGestureDetector;
    public float maximumScale = 8.0f;
    public float minimumScale = 0.5f;

    public interface TouchCallbackListener {
        void onCenterPosX(View view);

        void onCenterPosXY(View view);

        void onCenterPosY(View view);

        void onOtherPos(View view);

        void onTouchCallback(View view);

        void onTouchMoveCallback(View view);

        void onTouchUpCallback(View view);
    }

    private class TransformInfo {
        public float deltaAngle;
        public float deltaScale;
        public float deltaX;
        public float deltaY;
        public float maximumScale;
        public float minimumScale;
        public float pivotX;
        public float pivotY;

        private TransformInfo() {
        }
    }

    private class ScaleGestureListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private float mPivotX;
        private float mPivotY;
        private Vector2D mPrevSpanVector;

        private ScaleGestureListener() {
            this.mPrevSpanVector = new Vector2D();
        }

        public boolean onScaleBegin(View view, ScaleGestureDetector scaleGestureDetector) {
            this.mPivotX = scaleGestureDetector.getFocusX();
            this.mPivotY = scaleGestureDetector.getFocusY();
            this.mPrevSpanVector.set(scaleGestureDetector.getCurrentSpanVector());
            return true;
        }

        public boolean onScale(View view, ScaleGestureDetector scaleGestureDetector) {
            TransformInfo transformInfo = new TransformInfo();
            float f = 0.0f;
            transformInfo.deltaAngle = MultiTouchListener.this.isRotateEnabled ? Vector2D.getAngle(this.mPrevSpanVector, scaleGestureDetector.getCurrentSpanVector()) : 0.0f;
            transformInfo.deltaX = MultiTouchListener.this.isTranslateEnabled ? scaleGestureDetector.getFocusX() - this.mPivotX : 0.0f;
            if (MultiTouchListener.this.isTranslateEnabled) {
                f = scaleGestureDetector.getFocusY() - this.mPivotY;
            }
            transformInfo.deltaY = f;
            transformInfo.pivotX = this.mPivotX;
            transformInfo.pivotY = this.mPivotY;
            transformInfo.minimumScale = MultiTouchListener.this.minimumScale;
            transformInfo.maximumScale = MultiTouchListener.this.maximumScale;
            MultiTouchListener.this.move(view, transformInfo);
            return false;
        }
    }

    private static float adjustAngle(float f) {
        if (f > 180.0f) {
            return f - 360.0f;
        }
        if (f < -180.0f) {
            f += 360.0f;
        }
        return f;
    }

    public MultiTouchListener setGestureListener(GestureDetector gestureDetector) {
        this.gd = gestureDetector;
        return this;
    }

    public MultiTouchListener setOnTouchCallbackListener(TouchCallbackListener touchCallbackListener) {
        this.listener = touchCallbackListener;
        return this;
    }

    public MultiTouchListener(Context context) {
        this.mContext = context;
        this.mScaleGestureDetector = new ScaleGestureDetector(new ScaleGestureListener());
    }

    public MultiTouchListener enableRotation(boolean z) {
        this.isRotationEnabled = z;
        return this;
    }

    public MultiTouchListener setMinScale(float f) {
        this.minimumScale = f;
        return this;
    }

    private void move(View view, TransformInfo transformInfo) {
        if (this.isRotationEnabled) {
            float adjustAngle = adjustAngle(view.getRotation() + transformInfo.deltaAngle);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(view.getRotation());
            String str = " ";
            stringBuilder.append(str);
            stringBuilder.append(transformInfo.deltaAngle);
            stringBuilder.append(str);
            stringBuilder.append(adjustAngle);
            Log.e("testing", stringBuilder.toString());
            view.setRotation(adjustAngle);
        }
    }

    private void adjustTranslation(View view, float f, float f2) {
        Object obj;
        float[] r1 = new float[2];
        int i = 0;
        r1[0] = f;
        r1[1] = f2;
        view.getMatrix().mapVectors(r1);
        f2 = view.getTranslationY() + r1[1];
        view.setTranslationX(view.getTranslationX() + r1[0]);
        view.setTranslationY(f2);
        AutofitTextRel autofitTextRel = (AutofitTextRel) view;
        float mainWidth = autofitTextRel.getMainWidth();
        f2 = autofitTextRel.getMainHeight();
        this.mContext.getResources();
        float width = (float) (view.getWidth() / 2);
        float height = (float) (view.getHeight() / 2);
        int y = (int) (view.getY() + height);
        float x = (float) ((int) (view.getX() + width));
        mainWidth /= 2.0f;
        float f3 = (float) ((int) (Resources.getSystem().getDisplayMetrics().density * 5.0f));
        if (x <= mainWidth - f3 || x >= mainWidth + f3) {
            obj = null;
        } else {
            view.setX(mainWidth - width);
            obj = 1;
        }
        width = (float) y;
        f2 /= 2.0f;
        if (width > f2 - f3 && width < f3 + f2) {
            view.setY(f2 - height);
            i = 1;
        }
        TouchCallbackListener touchCallbackListener;
        if (obj != null && i != 0) {
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onCenterPosXY(view);
            }
        } else if (obj != null) {
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onCenterPosX(view);
            }
        } else if (i != 0) {
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onCenterPosY(view);
            }
        } else {
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onOtherPos(view);
            }
        }
        f = view.getRotation();
        if (Math.abs(90.0f - Math.abs(f)) <= 5.0f) {
            f = f > 0.0f ? 90.0f : -90.0f;
        }
        if (Math.abs(0.0f - Math.abs(f)) <= 5.0f) {
            f = f > 0.0f ? 0.0f : -0.0f;
        }
        if (Math.abs(180.0f - Math.abs(f)) <= 5.0f) {
            f = f > 0.0f ? 180.0f : -180.0f;
        }
        view.setRotation(f);
    }

    private static void computeRenderOffset(View view, float f, float f2) {
        if (view.getPivotX() != f || view.getPivotY() != f2) {
            float[] fArr = new float[]{0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr);
            view.setPivotX(f);
            view.setPivotY(f2);
            float[] fArr2 = new float[]{0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr2);
            float f3 = fArr2[1] - fArr[1];
            view.setTranslationX(view.getTranslationX() - (fArr2[0] - fArr[0]));
            view.setTranslationY(view.getTranslationY() - f3);
        }
    }

    public boolean handleTransparency(View view, MotionEvent motionEvent) {
        try {
            boolean z = true;
            if (motionEvent.getAction() == 2 && this.bt) {
                return true;
            }
            if (motionEvent.getAction() == 1 && this.bt) {
                this.bt = false;
                if (this.bitmap != null) {
                    this.bitmap.recycle();
                }
                return true;
            }
            int[] iArr = new int[2];
            view.getLocationOnScreen(iArr);
            int rawX = (int) (motionEvent.getRawX() - ((float) iArr[0]));
            int rawY = (int) (motionEvent.getRawY() - ((float) iArr[1]));
            float rotation = view.getRotation();
            Matrix matrix = new Matrix();
            matrix.postRotate(-rotation);
            float[] fArr = new float[]{(float) rawX, (float) rawY};
            matrix.mapPoints(fArr);
            rawY = (int) fArr[0];
            int i = (int) fArr[1];
            if (motionEvent.getAction() == 0) {
                this.bt = false;
                view.setDrawingCacheEnabled(true);
                Bitmap createBitmap = Bitmap.createBitmap(view.getDrawingCache());
                this.bitmap = createBitmap;
                rawY = (int) (((float) rawY) * (((float) createBitmap.getWidth()) / (((float) this.bitmap.getWidth()) * view.getScaleX())));
                i = (int) (((float) i) * (((float) this.bitmap.getWidth()) / (((float) this.bitmap.getHeight()) * view.getScaleX())));
                view.setDrawingCacheEnabled(false);
            }
            if (rawY >= 0 && i >= 0 && rawY <= this.bitmap.getWidth()) {
                if (i <= this.bitmap.getHeight()) {
                    if (this.bitmap.getPixel(rawY, i) != 0) {
                        z = false;
                    }
                    if (motionEvent.getAction() != 0) {
                        return z;
                    }
                    this.bt = z;
                    return z;
                }
            }
            return false;
        } catch (Exception unused) {
        }
        return false;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        RelativeLayout relativeLayout = (RelativeLayout) view.getParent();
        this.mScaleGestureDetector.onTouchEvent(view, motionEvent);
        GestureDetector gestureDetector = this.gd;
        if (gestureDetector != null) {
            gestureDetector.onTouchEvent(motionEvent);
        }
        if (!this.isTranslateEnabled) {
            return true;
        }
        int action = motionEvent.getAction();
        int actionMasked = motionEvent.getActionMasked() & action;
        int i = 0;
        TouchCallbackListener touchCallbackListener;
        float rotation;
        if (actionMasked == 0) {
            if (relativeLayout != null) {
                relativeLayout.requestDisallowInterceptTouchEvent(true);
            }
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onTouchCallback(view);
            }
            view.bringToFront();
            if (view instanceof AutofitTextRel) {
                ((AutofitTextRel) view).setBorderVisibility(true);
            }
            this.mPrevX = motionEvent.getX();
            this.mPrevY = motionEvent.getY();
            this.mActivePointerId = motionEvent.getPointerId(0);
        } else if (actionMasked == 1) {
            this.mActivePointerId = -1;
            TouchCallbackListener touchCallbackListener2 = this.listener;
            if (touchCallbackListener2 != null) {
                touchCallbackListener2.onTouchUpCallback(view);
            }
            rotation = view.getRotation();
            if (Math.abs(90.0f - Math.abs(rotation)) <= 5.0f) {
                rotation = rotation > 0.0f ? 90.0f : -90.0f;
            }
            if (Math.abs(0.0f - Math.abs(rotation)) <= 5.0f) {
                rotation = rotation > 0.0f ? 0.0f : -0.0f;
            }
            if (Math.abs(180.0f - Math.abs(rotation)) <= 5.0f) {
                rotation = rotation > 0.0f ? 180.0f : -180.0f;
            }
            view.setRotation(rotation);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Final Rotation : ");
            stringBuilder.append(rotation);
            Log.i("testing", stringBuilder.toString());
        } else if (actionMasked == 2) {
            if (relativeLayout != null) {
                relativeLayout.requestDisallowInterceptTouchEvent(true);
            }
            touchCallbackListener = this.listener;
            if (touchCallbackListener != null) {
                touchCallbackListener.onTouchMoveCallback(view);
            }
            int findPointerIndex = motionEvent.findPointerIndex(this.mActivePointerId);
            if (findPointerIndex != -1) {
                float x = motionEvent.getX(findPointerIndex);
                rotation = motionEvent.getY(findPointerIndex);
                if (!this.mScaleGestureDetector.isInProgress()) {
                    adjustTranslation(view, x - this.mPrevX, rotation - this.mPrevY);
                }
            }
        } else if (actionMasked == 3) {
            this.mActivePointerId = -1;
        } else if (actionMasked == 6) {
            int i2 = (MotionEventCompat.ACTION_POINTER_INDEX_MASK & action) >> 8;
            if (motionEvent.getPointerId(i2) == this.mActivePointerId) {
                if (i2 == 0) {
                    i = 1;
                }
                this.mPrevX = motionEvent.getX(i);
                this.mPrevY = motionEvent.getY(i);
                this.mActivePointerId = motionEvent.getPointerId(i);
            }
        }
        return true;
    }
}
