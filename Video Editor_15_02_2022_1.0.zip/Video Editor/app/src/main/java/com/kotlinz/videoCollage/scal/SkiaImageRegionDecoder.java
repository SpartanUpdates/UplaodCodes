package com.kotlinz.videoCollage.scal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory.Options;
import android.graphics.BitmapRegionDecoder;
import android.graphics.Rect;
import android.os.Build.VERSION;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SkiaImageRegionDecoder implements ImageRegionDecoder {
    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final String FILE_PREFIX = "file://";
    private static final String RESOURCE_PREFIX = "android.resource://";
    private final Config bitmapConfig;
    private BitmapRegionDecoder decoder;
    private final ReadWriteLock decoderLock;

    public SkiaImageRegionDecoder() {
        this(null);
    }

    public SkiaImageRegionDecoder(Config config) {
        this.decoderLock = new ReentrantReadWriteLock(true);
        Config preferredBitmapConfig = SubSamplingScaleImageView.getPreferredBitmapConfig();
        if (config != null) {
            this.bitmapConfig = config;
        } else if (preferredBitmapConfig != null) {
            this.bitmapConfig = preferredBitmapConfig;
        } else {
            this.bitmapConfig = Config.RGB_565;
        }
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    public android.graphics.Point init(android.content.Context r8, android.net.Uri r9) throws Exception {
        /*
        r7 = this;
        r0 = r9.toString();
        r1 = "android.resource://";
        r1 = r0.startsWith(r1);
        r2 = 1;
        r3 = 0;
        if (r1 == 0) goto L_0x0076;
    L_0x000e:
        r0 = r9.getAuthority();
        r1 = r8.getPackageName();
        r1 = r1.equals(r0);
        if (r1 == 0) goto L_0x0021;
    L_0x001c:
        r1 = r8.getResources();
        goto L_0x0029;
    L_0x0021:
        r1 = r8.getPackageManager();
        r1 = r1.getResourcesForApplication(r0);
    L_0x0029:
        r9 = r9.getPathSegments();
        r4 = r9.size();
        r5 = 2;
        if (r4 != r5) goto L_0x004d;
    L_0x0034:
        r5 = r9.get(r3);
        r5 = (java.lang.String) r5;
        r6 = "drawable";
        r5 = r5.equals(r6);
        if (r5 == 0) goto L_0x004d;
    L_0x0042:
        r9 = r9.get(r2);
        r9 = (java.lang.String) r9;
        r9 = r1.getIdentifier(r9, r6, r0);
        goto L_0x0067;
    L_0x004d:
        if (r4 != r2) goto L_0x0066;
    L_0x004f:
        r0 = r9.get(r3);
        r0 = (java.lang.CharSequence) r0;
        r0 = android.text.TextUtils.isDigitsOnly(r0);
        if (r0 == 0) goto L_0x0066;
    L_0x005b:
        r9 = r9.get(r3);	 Catch:{ NumberFormatException -> 0x0066 }
        r9 = (java.lang.String) r9;	 Catch:{ NumberFormatException -> 0x0066 }
        r9 = java.lang.Integer.parseInt(r9);	 Catch:{ NumberFormatException -> 0x0066 }
        goto L_0x0067;
    L_0x0066:
        r9 = 0;
    L_0x0067:
        r8 = r8.getResources();
        r8 = r8.openRawResource(r9);
        r8 = android.graphics.BitmapRegionDecoder.newInstance(r8, r3);
        r7.decoder = r8;
        goto L_0x00c2;
    L_0x0076:
        r1 = "file:///android_asset/";
        r1 = r0.startsWith(r1);
        if (r1 == 0) goto L_0x0093;
    L_0x007e:
        r8 = r8.getAssets();
        r9 = 22;
        r9 = r0.substring(r9);
        r8 = r8.open(r9, r2);
        r8 = android.graphics.BitmapRegionDecoder.newInstance(r8, r3);
        r7.decoder = r8;
        goto L_0x00c2;
    L_0x0093:
        r1 = "file://";
        r1 = r0.startsWith(r1);
        if (r1 == 0) goto L_0x00a7;
    L_0x009b:
        r8 = 7;
        r8 = r0.substring(r8);
        r8 = android.graphics.BitmapRegionDecoder.newInstance(r8, r3);
        r7.decoder = r8;
        goto L_0x00c2;
    L_0x00a7:
        r0 = 0;
        r8 = r8.getContentResolver();	 Catch:{ all -> 0x00bc }
        r0 = r8.openInputStream(r9);	 Catch:{ all -> 0x00bc }
        r8 = android.graphics.BitmapRegionDecoder.newInstance(r0, r3);	 Catch:{ all -> 0x00bc }
        r7.decoder = r8;	 Catch:{ all -> 0x00bc }
        if (r0 == 0) goto L_0x00c2;
    L_0x00b8:
        r0.close();	 Catch:{ Exception -> 0x00c2 }
        goto L_0x00c2;
        if (r0 == 0) goto L_0x00c2;
    L_0x00bf:
        r0.close();	 Catch:{  }
    L_0x00c2:
        r8 = new android.graphics.Point;
        r9 = r7.decoder;
        r9 = r9.getWidth();
        r0 = r7.decoder;
        r0 = r0.getHeight();
        r8.<init>(r9, r0);
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: fcom.collage.imagevideo.scal.SkiaImageRegionDecoder.init(android.content.Context, android.net.Uri):android.graphics.Point");
    }

    public Bitmap decodeRegion(Rect rect, int i) {
        getDecodeLock().lock();
        try {
            if (this.decoder == null || this.decoder.isRecycled()) {
                throw new IllegalStateException("Cannot decode region after decoder has been recycled");
            }
            Options options = new Options();
            options.inSampleSize = i;
            options.inPreferredConfig = this.bitmapConfig;
            Bitmap decodeRegion = this.decoder.decodeRegion(rect, options);
            if (decodeRegion != null) {
                return decodeRegion;
            }
            throw new RuntimeException("Skia image decoder returned null bitmap - image format may not be supported");
        } finally {
            getDecodeLock().unlock();
        }
    }

    public synchronized boolean isReady() {
        boolean z;
        z = (this.decoder == null || this.decoder.isRecycled()) ? false : true;
        return z;
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001c */
    /* JADX WARNING: Can't wrap try/catch for region: R(7:1|2|3|4|5|6|7) */
    public synchronized void recycle() {
        /*
        r1 = this;
        monitor-enter(r1);
        r0 = r1.decoderLock;	 Catch:{ all -> 0x0027 }
        r0 = r0.writeLock();	 Catch:{ all -> 0x0027 }
        r0.lock();	 Catch:{ all -> 0x0027 }
        r0 = r1.decoder;	 Catch:{ all -> 0x001c }
        r0.recycle();	 Catch:{ all -> 0x001c }
        r0 = 0;
        r1.decoder = r0;	 Catch:{ all -> 0x001c }
        r0 = r1.decoderLock;	 Catch:{ all -> 0x001c }
        r0 = r0.writeLock();	 Catch:{ all -> 0x001c }
        r0.unlock();	 Catch:{ all -> 0x001c }
        goto L_0x0025;
    L_0x001c:
        r0 = r1.decoderLock;	 Catch:{ all -> 0x0027 }
        r0 = r0.writeLock();	 Catch:{ all -> 0x0027 }
        r0.unlock();	 Catch:{ all -> 0x0027 }
    L_0x0025:
        monitor-exit(r1);
        return;
    L_0x0027:
        r0 = move-exception;
        monitor-exit(r1);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: fcom.collage.imagevideo.scal.SkiaImageRegionDecoder.recycle():void");
    }

    private Lock getDecodeLock() {
        if (VERSION.SDK_INT < 21) {
            return this.decoderLock.writeLock();
        }
        return this.decoderLock.readLock();
    }
}
