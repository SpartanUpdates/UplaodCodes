package com.kotlinz.festivalstorymaker.Other.k;

public interface c {
    void I(int i, String str);

    void T(int i, String str);
}
