package com.esc.storymaker.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint.Style;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.SweepGradient;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.ShapeDrawable.ShaderFactory;
import android.graphics.drawable.shapes.RectShape;
import android.graphics.drawable.shapes.RoundRectShape;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog.Builder;
import androidx.core.content.ContextCompat;

import com.esc.storymaker.EditorActivity;
import com.esc.storymaker.MainActivity;
import com.esc.storymaker.R;
import com.esc.storymaker.models.Draft;
import com.google.android.gms.common.ConnectionResult;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class AppUtil {
    public static void mainPermissionGranted(final MainActivity mainActivity, String str, final String str2, final String str3, final String str4) {
        Dexter.withActivity(mainActivity).withPermission(str).withListener(new PermissionListener() {
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                mainActivity.onPermissionGranted(str2, str3, str4);
            }

            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                if (permissionDeniedResponse.isPermanentlyDenied()) {
                    AppUtil.showSettingsDialog(mainActivity);
                }
            }

            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                AppUtil.showPermissionDialog(mainActivity, permissionToken);
            }
        }).check();
    }

    public static void editorPermissionGranted(final EditorActivity editorActivity, String str) {
        Dexter.withActivity(editorActivity).withPermission(str).withListener(new PermissionListener() {
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                editorActivity.onPermissionGranted();
            }

            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                if (permissionDeniedResponse.isPermanentlyDenied()) {
                    AppUtil.showSettingsDialog(editorActivity);
                }
            }

            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                AppUtil.showPermissionDialog(editorActivity, permissionToken);
            }
        }).check();
    }

    public static boolean permissionGranted(final Activity activity, String str) {
        final boolean[] zArr = new boolean[]{false};
        Dexter.withActivity(activity).withPermission(str).withListener(new PermissionListener() {
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                zArr[0] = true;
            }

            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                if (permissionDeniedResponse.isPermanentlyDenied()) {
                    AppUtil.showSettingsDialog(activity);
                } else {
                    activity.onBackPressed();
                }
            }

            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                AppUtil.showPermissionDialog(activity, permissionToken);
            }
        }).check();
        return zArr[0];
    }

    private static void showSettingsDialog(final Activity activity) {
        Builder builder = new Builder(activity);
        builder.setTitle((CharSequence) "Need Permissions");
        builder.setMessage((CharSequence) "This app needs permissions to use this feature. You can grant them in app settings.");
        builder.setPositiveButton((CharSequence) "GOTO SETTINGS", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                AppUtil.openSettings(activity);
            }
        });
        builder.setNegativeButton((CharSequence) "Cancel", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                activity.onBackPressed();
            }
        });
        builder.show();
    }

    private static void showPermissionDialog(final Activity activity, final PermissionToken permissionToken) {
        new Builder(activity).setMessage((int) R.string.MSG_ASK_PERMISSION).setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                permissionToken.cancelPermissionRequest();
                activity.onBackPressed();
            }
        }).setPositiveButton("GOTO SETTINGS", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                permissionToken.continuePermissionRequest();
            }
        }).setOnDismissListener(new OnDismissListener() {
            public void onDismiss(DialogInterface dialogInterface) {
                permissionToken.cancelPermissionRequest();
            }
        }).show();
    }

    private static void openSettings(Activity activity) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", activity.getPackageName(), null));
        activity.startActivityForResult(intent, 101);
    }

    public static void showKeyboard(Activity activity, EditText editText) {
        editText.requestFocus();
        ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(editText, 1);
    }

    public static void hideKeyboard(Activity activity, EditText editText) {
        editText.clearFocus();
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(editText, 1);
        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }

    public static void showWidget(List<View> list, View view) {
        for (View view2 : list) {
            if (view2 != view) {
                view2.setVisibility(View.GONE);
            } else {
                view2.setVisibility(View.VISIBLE);
            }
        }
    }

    public static String getFileType(String str) {
        File file = new File(str);
        String[] strings = new String[3];
        int i = 0;
        strings[0] = "jpg";
        strings[1] = "png";
        strings[2] = "jpeg";
        int length = strings.length;
        while (i < length) {
            if (file.getName().toLowerCase().endsWith(strings[i])) {
                return "Image";
            }
            i++;
        }
        return file.getName().toLowerCase().endsWith("gif") ? "Gif" : "Video";
    }

    public static boolean equals(Object obj, Object obj2) {
        if (obj != null) {
            return obj.equals(obj2);
        }
        return obj2 == null;
    }

    public static String inputStreamToString(InputStream inputStream) {
        try {
            byte[] bArr = new byte[inputStream.available()];
            inputStream.read(bArr, 0, bArr.length);
            return new String(bArr);
        } catch (IOException unused) {
            return null;
        }
    }

    public static void putInAdjustsContrast(Context context, String str, float f) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("Data Holder", 0);
        Editor edit = sharedPreferences.edit();
        String str2 = "adjustContracts";
        Object obj = (LinkedHashMap) new Gson().fromJson(sharedPreferences.getString(str2, ""), new TypeToken<LinkedHashMap<String, Float>>() {
        }.getType());
//        ob/j.put(str, Float.valueOf(f));
        edit.putString(str2, new Gson().toJson(obj));
        edit.commit();
    }

    public static LinkedHashMap getInAdjustsContrast(Context context) {
        return (LinkedHashMap) new Gson().fromJson(context.getSharedPreferences("Data Holder", 0).getString("adjustContracts", ""), new TypeToken<LinkedHashMap<String, Float>>() {
        }.getType());
    }

    public static String readableFileSize(long j) {
        if (j <= 0) {
            return "0";
        }
        String[] strArr = new String[]{"B", "kB", "MB", "GB", "TB"};
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder stringBuilder = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, (double) log10);
        Double.isNaN(d);
        Double.isNaN(d);
        stringBuilder.append(decimalFormat.format(d / pow));
        stringBuilder.append(" ");
        stringBuilder.append(strArr[log10]);
        return stringBuilder.toString();
    }

    public static Drawable getRoundedRect(Activity activity, int i, int i2, int i3, int i4, int i5) {
        i3 = DensityUtil.dp2px(activity, (float) i3);
        i2 = DensityUtil.dp2px(activity, (float) i2);
        i4 = DensityUtil.dp2px(activity, (float) i4);
        float f = (float) i2;
        float f2 = (float) i3;
        float dp2px = (float) DensityUtil.dp2px(activity, (float) i5);
        float f3 = (float) i4;
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(new float[]{f, f, f2, f2, dp2px, dp2px, f3, f3}, null, null));
        shapeDrawable.getPaint().setColor(i);
        shapeDrawable.getPaint().setStyle(Style.FILL);
        shapeDrawable.getPaint().setAntiAlias(true);
        shapeDrawable.getPaint().setFlags(1);
        return shapeDrawable;
    }

    public static String getCurrentTime() {
        return new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
    }

    public static void removeDrafts(ArrayList<Draft> arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Draft draft = (Draft) it.next();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory().getPath());
            stringBuilder.append("/Android/data/com.maxvidzgallery.storymaker/drafts/");
            stringBuilder.append(draft.draft_name);
            deleteFolder(new File(stringBuilder.toString()));
            File file = new File(draft.save_path);
            if (file.exists()) {
                file.delete();
            }
        }
    }

    public static void removeDraft(Draft draft) {
        File file;
        if (draft.thumbnail != null) {
            file = new File(draft.thumbnail);
            if (file.exists()) {
                file.delete();
            }
        }
        file = new File(draft.save_path);
        if (file.exists()) {
            file.delete();
        }
    }

    public static String[] strTOStrArray(String str, String str2) {
        return str == null ? null : str.split(str2);
    }

    public static String strArrayToStr(String[] strArr, String str) {
        if (strArr == null) {
            return null;
        }
        String str2 = "";
        for (String str3 : strArr) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str3);
            stringBuilder.append(str);
            str2 = stringBuilder.toString();
        }
        return str2.trim();
    }

    public static PaintDrawable generateViewGradient(String[] strArr, final String str, final String str2, int i, int i2) {
        final int[] iArr = new int[strArr.length];
        for (i2 = 0; i2 < strArr.length; i2++) {
            iArr[i2] = Color.parseColor(strArr[i2]);
        }
        final TileMode tileMode = TileMode.MIRROR;
        ShaderFactory anonymousClass11 = new ShaderFactory() {
            public Shader resize(int i, int i2) {
                if (str.equals("Linear")) {
                    Shader linearGradient = null;
                    if (str2.equals("Horizontal")) {
                        Shader linearGradient2 = new LinearGradient(0.0f, 0.0f, (float) i, 0.0f, iArr, null, tileMode);
                    } else {
                        linearGradient = str2.equals("Vertical") ? new LinearGradient(0.0f, 0.0f, 0.0f, (float) i2, iArr, null, tileMode) : null;
                    }
                    return linearGradient;
                } else if (str.equals("Radial")) {
                    return new RadialGradient((float) (i / 2), (float) (i2 / 2), (float) i, iArr, null, tileMode);
                } else {
                    if (str.equals("Sweep")) {
                        return new SweepGradient((float) (i / 2), (float) (i2 / 2), iArr, null);
                    }
                    return null;
                }
            }
        };
        PaintDrawable paintDrawable = new PaintDrawable();
        paintDrawable.setShape(new RectShape());
        paintDrawable.setShaderFactory(anonymousClass11);
        return paintDrawable;
    }

    public static ArrayList<Integer> convertDecimalToFraction(float f, float f2) {
        float f3 = f / f2;
        if (f3 < 0.0f) {
            return null;
        }
        double d = (double) f3;
        double d2 = 0.0d;
        double d3 = d2;
        double d4 = 1.0d;
        double d5 = d4;
        double d6 = d;
        while (true) {
            double floor = Math.floor(d6);
            d2 = (floor * d4) + d2;
            d5 = (floor * d3) + d5;
            d6 = 1.0d / (d6 - floor);
            floor = d2 / d5;
            Double.isNaN(d);
            Double.isNaN(d);
            floor = Math.abs(d - floor);
            Double.isNaN(d);
            Double.isNaN(d);
            if (floor <= 1.0E-6d * d) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(Integer.valueOf((int) d2));
                arrayList.add(Integer.valueOf((int) d5));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("ratio = ");
                stringBuilder.append(f3);
                stringBuilder.append(" ");
                stringBuilder.append(d2);
                stringBuilder.append(":");
                stringBuilder.append(d5);
                return arrayList;
            }
            double d7 = d3;
            d3 = d5;
            d5 = d7;
            double d8 = d4;
            d4 = d2;
            d2 = d8;
        }
    }

    public static void openUrl(Context context, String str) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.BROWSABLE");
        intent.setData(Uri.parse(str));
        context.startActivity(intent);
    }

    public static void shareIntent(Context context, String str, String str2, Uri uri) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.setPackage(str);
        if (TextUtils.isEmpty(str2)) {
            str2 = "";
        }
        intent.putExtra("android.intent.extra.TEXT", str2);
        if (uri != null) {
            intent.putExtra("android.intent.extra.STREAM", uri);
            intent.setType("image/*");
        }
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(context, "No Such App Found", Toast.LENGTH_SHORT).show();
        }
    }

    public static void sendFeedback(Activity activity) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/html");
        intent.setPackage("com.google.android.gm");
        intent.putExtra("android.intent.extra.EMAIL", new String[]{activity.getString(R.string.Feedback)});
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Feedback ");
        stringBuilder.append(activity.getString(R.string.app_name));
        intent.putExtra("android.intent.extra.SUBJECT", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("\n\n\n\n\n");
        stringBuilder.append(activity.getString(R.string.MSG_DELETE_INFO));
        stringBuilder.append("\nApp Version: ");
        stringBuilder.append(activity.getString(R.string.app_version));
        stringBuilder.append("\nBrand: ");
        stringBuilder.append(Build.BRAND);
        stringBuilder.append("\nModel: ");
        stringBuilder.append(Build.MODEL);
        stringBuilder.append("\nManufacture: ");
        stringBuilder.append(Build.MANUFACTURER);
        stringBuilder.append("\nAndroid Version: ");
        stringBuilder.append(VERSION.RELEASE);
        stringBuilder.append("\nSDK: ");
        stringBuilder.append(VERSION.SDK);
        stringBuilder.append("\nCPU_ABI: ");
        stringBuilder.append(Build.CPU_ABI);
        stringBuilder.append("\nTotal Memory: ");
        stringBuilder.append(getTotalMemory(activity));
        stringBuilder.append("mb\nScreen Resolution: ");
        stringBuilder.append(ScreenUtil.getScreenWidth(activity));
        stringBuilder.append("/");
        stringBuilder.append(ScreenUtil.getScreenHeight(activity));
        stringBuilder.append("\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        activity.startActivity(Intent.createChooser(intent, "Send Feedback:"));
    }

    public static void showBottomDialog(Context context, Dialog dialog, View view, boolean z) {
        dialog.setContentView(view);
        LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.width = context.getResources().getDisplayMetrics().widthPixels;
        view.setLayoutParams(layoutParams);
//        dialog.getWindow().setGravity(80);
        dialog.setCanceledOnTouchOutside(z);
        dialog.getWindow();
        dialog.show();
    }

    public static void cropPhoto(Activity activity, File file, int i, int i2, int i3) {
        float f;
        if (i3 <= ConnectionResult.DRIVE_EXTERNAL_STORAGE_REQUIRED) {
            i3 = 90;
            f = 0.9f;
        } else if (i3 <= 2500) {
            i3 = 92;
            f = 1.0f;
        } else if (i3 <= 4500) {
            i3 = 95;
            f = 1.2f;
        } else {
            i3 = 100;
            f = 1.4f;
        }
        UCrop.Options options = new UCrop.Options();
        options.setCompressionQuality(i3);
        options.setMaxBitmapSize(8000);
        options.withAspectRatio((float) i, (float) i2);
        options.withMaxResultSize((int) (((float) ScreenUtil.getScreenWidth(activity)) * f), (int) (((float) ScreenUtil.getScreenHeight(activity)) * f));
        options.setToolbarColor(ContextCompat.getColor(activity, R.color.colorPrimary));
        options.setStatusBarColor(ContextCompat.getColor(activity, R.color.colorPrimaryDark));
        options.setToolbarWidgetColor(ContextCompat.getColor(activity, R.color.colorBlack));
        options.setFreeStyleCropEnabled(false);
        UCrop.of(Uri.fromFile(file), Uri.fromFile(new File(activity.getCacheDir(), "tempCropImage"))).withOptions(options).start(activity);
    }

    public static void deleteFolder(File file) {
        if (file.isDirectory()) {
            for (File deleteFolder : file.listFiles()) {
                deleteFolder(deleteFolder);
            }
        }
        file.delete();
    }

    public static ArrayList<String> getFilesPath(String str) {
        ArrayList arrayList = new ArrayList();
        File file = new File(str);
        if (file.exists()) {
            file = file.getAbsoluteFile();
            if (file.list().length > 0) {
                for (String str2 : file.list()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(str2);
                    arrayList.add(stringBuilder.toString());
                }
            }
        }
        return arrayList;
    }

    public static int getTotalMemory(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        MemoryInfo memoryInfo = new MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        return (int) (memoryInfo.totalMem / 1000000);
    }

    public static Set<String> getLockedNumbers(SharedPreferences sharedPreferences) {
        return sharedPreferences.getStringSet("lockedNumbers", new LinkedHashSet());
    }

    public static boolean isLocked(SharedPreferences sharedPreferences, String str) {
        Date obj;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd:HH:mm");
        String format = simpleDateFormat.format(Calendar.getInstance().getTime());
        String string = sharedPreferences.getString(str, format);
        Date date = null;
        try {
            Date parse = simpleDateFormat.parse(format);
            try {
                date = simpleDateFormat.parse(string);
            } catch (ParseException e) {
                e.printStackTrace();
                parse.equals(date);
            }
            obj = date;
            date = parse;
        } catch (ParseException e2) {
            e2.printStackTrace();
            date.equals(date);
            obj = date;
        }
        return !date.equals(obj) || date.after(obj);
    }
}
