package com.esc.howtomakeschoolsupplies.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.esc.howtomakeschoolsupplies.activity.Constants;
import com.esc.howtomakeschoolsupplies.activity.MainActivity;
import com.esc.howtomakeschoolsupplies.adapter.ListAdapter;
import com.esc.howtomakeschoolsupplies.R;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import com.esc.howtomakeschoolsupplies.data.LikesContract;
import com.esc.howtomakeschoolsupplies.data.LikesContract.DBEntry;
import com.esc.howtomakeschoolsupplies.pojo.Article;
import com.esc.howtomakeschoolsupplies.pojo.Category;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class ListFragment extends Fragment {
    public static final Companion Companion = new Companion();
    private static final String KEY_ARTICLES = "articles";
    private static final String KEY_CATEGORY_ID = "category_id";
    private HashMap findViewCache;
    private View inflate;
    private RecyclerView mRecyclerView;
    private ListAdapter mAdapter;
    private SharedPreferences pref;
    private RelativeLayout constraintlayout;
    private TextView favorite_empty;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    public static  String Title;
    private TextView tv_title;
    private ImageView iv_back;
    public static final class Companion {
        private Companion() {
        }

        public final ListFragment newInstance(ArrayList<Article> arrayList, int i,String title) {
            String str = ListFragment.KEY_ARTICLES;
            Intrinsics.checkParameterIsNotNull(arrayList, str);
            Title=title;
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList(str, arrayList);
            bundle.putInt(ListFragment.KEY_CATEGORY_ID, i);
            ListFragment listFragment = new ListFragment();
            listFragment.setArguments(bundle);
            return listFragment;
        }
    }

    public void clearFindViewByIdCache() {
        HashMap hashMap = this.findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public void onDestroyView() {
        super.onDestroyView();
        clearFindViewByIdCache();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(layoutInflater, "inflater");
        inflate = layoutInflater.inflate(R.layout.activity_list, viewGroup, false);
        ArrayList parcelableArrayList = requireArguments().getParcelableArrayList(KEY_ARTICLES);
        int i = requireArguments().getInt(KEY_CATEGORY_ID);
        List databaseInfoValues = LikesContract.databaseInfoValues(getActivity(), DBEntry.TABLE_NAME_LIKES);
        List databaseInfoValues2 = LikesContract.databaseInfoValues(getActivity(), DBEntry.TABLE_NAME_FAVORITES);
        Intrinsics.checkExpressionValueIsNotNull(inflate, "rootView");
        mRecyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerview);
        tv_title = inflate.findViewById(R.id.tv_title);
        tv_title.setText(Title);
        iv_back = inflate.findViewById(R.id.iv_back);
        favorite_empty = (TextView) inflate.findViewById(R.id.favorite_empty);
        Intrinsics.checkExpressionValueIsNotNull(mRecyclerView, "rootView.recyclerview");
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences(Constants.APP_PREFERENCES, 0);
        Intrinsics.checkExpressionValueIsNotNull(sharedPreferences, "requireActivity().getSha…ES, Context.MODE_PRIVATE)");
        this.pref = sharedPreferences;
        constraintlayout = inflate.findViewById(R.id.list_layout);
        Intrinsics.checkExpressionValueIsNotNull(constraintlayout, "rootView.list_layout");
        FragmentActivity requireActivity = requireActivity();
        String str2 = "requireActivity()";
        Intrinsics.checkExpressionValueIsNotNull(requireActivity, str2);

        BannerAds();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
            }
        });

        String str = "listDBFavorite";
        String str3 = "listDBLikes";
        String str4 = "requireActivity().windowManager.defaultDisplay";
        String str5 = "requireActivity().windowManager";
        FragmentActivity requireActivity2;
        Display defaultDisplay;

        if (i != -1) {
            if (parcelableArrayList == null) {
                Intrinsics.throwNpe();
            }
            Collection arrayList = new ArrayList();
            for (Object next : parcelableArrayList) {
                Category category = ((Article) next).getCategory();
                if (category == null) {
                    Intrinsics.throwNpe();
                }
                if ((category.getId() == i ? 1 : null) != null) {
                    arrayList.add(next);
                }
            }
            List list = (List) arrayList;
            checkNewArticleInCategory(list);
            checkNewArticles(list);
            FragmentActivity requireActivity3 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity3, str2);
            Context context = requireActivity3;
            requireActivity2 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity2, str2);
            WindowManager windowManager = requireActivity2.getWindowManager();
            Intrinsics.checkExpressionValueIsNotNull(windowManager, str5);
            defaultDisplay = windowManager.getDefaultDisplay();
            Intrinsics.checkExpressionValueIsNotNull(defaultDisplay, str4);
            List<Object> initListObject = initListObject(list);
            Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues, str3);
            Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues2, str);
            mAdapter = new ListAdapter(context, defaultDisplay, initListObject, databaseInfoValues, databaseInfoValues2);
        } else {
            if (parcelableArrayList == null) {
                Intrinsics.throwNpe();
            }
            List list2 = parcelableArrayList;
            checkNewArticles(list2);
            requireActivity2 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity2, str2);
            Context context2 = requireActivity2;
            FragmentActivity requireActivity4 = requireActivity();
            Intrinsics.checkExpressionValueIsNotNull(requireActivity4, str2);
            WindowManager windowManager2 = requireActivity4.getWindowManager();
            Intrinsics.checkExpressionValueIsNotNull(windowManager2, str5);
            defaultDisplay = windowManager2.getDefaultDisplay();
            Intrinsics.checkExpressionValueIsNotNull(defaultDisplay, str4);
            List<Object> initListObject2 = initListObject(initFavoriteList(list2, inflate));
            Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues, str3);
            Intrinsics.checkExpressionValueIsNotNull(databaseInfoValues2, str);
            mAdapter = new ListAdapter(context2, defaultDisplay, initListObject2, databaseInfoValues, databaseInfoValues2);
        }

        String str6 = "mRecyclerView";
        if (mRecyclerView == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str6);
        }
        if (mAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mAdapter");
        }
        mRecyclerView.setAdapter(mAdapter);
        if (mRecyclerView == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str6);
        }
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return inflate;
    }

    private final List<Article> initFavoriteList(List<Article> list, View view) {
        List favoriteList = LikesContract.getFavoriteList(getActivity());
        ArrayList arrayList = new ArrayList();
        Intrinsics.checkExpressionValueIsNotNull(favoriteList, "favoriteList");
        int size = favoriteList.size();
        for (int i = 0; i < size; i++) {
            for (Article article : list) {
                int id = article.getId();
                Integer num = (Integer) favoriteList.get(i);
                if (num != null) {
                    if (id == num.intValue()) {
                        arrayList.add(article);
                    }
                }
            }
        }
        String str = "rootView.favorite_empty";
        if (arrayList.isEmpty()) {
            favorite_empty = (TextView) view.findViewById(R.id.favorite_empty);
            Intrinsics.checkExpressionValueIsNotNull(favorite_empty, str);
            favorite_empty.setVisibility(View.VISIBLE);
        } else {
            favorite_empty = (TextView) view.findViewById(R.id.favorite_empty);
            Intrinsics.checkExpressionValueIsNotNull(favorite_empty, str);
            favorite_empty.setVisibility(View.INVISIBLE);
        }
        return arrayList;
    }

    private final void checkNewArticles(List<Article> list) {
        SharedPreferences sharedPreferences = this.pref;
        String str = "pref";
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        String str2 = Constants.APP_PREFERENCES_NEW_ARTICLES;
        if (sharedPreferences.contains(str2)) {
            sharedPreferences = this.pref;
            if (sharedPreferences == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            String string = sharedPreferences.getString(str2, new String());
            if (string == null) {
                Intrinsics.throwNpe();
            }
            Intrinsics.checkExpressionValueIsNotNull(string, "pref.getString(Constants…NEW_ARTICLES, String())!!");
            Collection arrayList = new ArrayList();
            for (Object next : StringsKt.split((CharSequence) string, new String[]{","}, false, 0)) {
                if ((((CharSequence) ((String) next)).length() > 0 ? 1 : null) != null) {
                    arrayList.add(next);
                }
            }
            List<String> list2 = (List) arrayList;
            for (Article article : list) {
                for (String parseInt : list2) {
                    if (article.getId() == Integer.parseInt(parseInt)) {
                        article.setOldArticle(true);
                    }
                }
            }
        }
    }

    private final void checkNewArticleInCategory(List<Article> list) {
        String str = new String();
        SharedPreferences sharedPreferences = this.pref;
        String str2 = "pref";
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str2);
        }
        String str3 = Constants.APP_PREFERENCES_NEW_ARTICLES_CATEGORY;
        String str4 = ",";
        if (sharedPreferences.contains(str3)) {
            SharedPreferences sharedPreferences2 = this.pref;
            if (sharedPreferences2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str2);
            }
            str = sharedPreferences2.getString(str3, new String());
            if (str == null) {
                Intrinsics.throwNpe();
            }
            CharSequence charSequence = str;
            String[] strArr = new String[1];
            int i = 0;
            strArr[0] = str4;
            Iterable split$default = StringsKt.split(charSequence, strArr, false, 0);
            Collection arrayList = new ArrayList();
            for (Object next : split$default) {
                if ((((CharSequence) ((String) next)).length() > 0 ? 1 : null) != null) {
                    arrayList.add(next);
                }
            }
            List<String> list2 = (List) arrayList;
            for (Article article : list) {
                for (String parseInt : list2) {
                    if (article.getId() == Integer.parseInt(parseInt)) {
                        i = 1;
                        break;
                    }
                }
                if (i == 0) {
                    str = (str + article.getId()) + str4;
                }
            }
        } else {
            for (Article id : list) {
                str = (str + id.getId()) + str4;
            }
        }
        SharedPreferences sharedPreferences3 = this.pref;
        if (sharedPreferences3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str2);
        }
        Editor edit = sharedPreferences3.edit();
        edit.putString(str3, str);
        edit.apply();
    }

    public void onResume() {
        super.onResume();
        ListAdapter listAdapter = this.mAdapter;
        if (listAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mAdapter");
        }
        listAdapter.setOnAttach(false);
    }

    private final List<Object> initListObject(List<Article> list) {

        List arrayList = new ArrayList();
        arrayList.addAll(list);

        return arrayList;
    }

    private void BannerAds()
    {
        if (isAdded()) {
            try {
                adContainerView = inflate.findViewById(R.id.banner_ad_view_container);
                Display defaultDisplay = getActivity().getWindowManager().getDefaultDisplay();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                defaultDisplay.getMetrics(displayMetrics);
                float f = displayMetrics.density;
                float width = (float) adContainerView.getWidth();
                if (width == 0.0f) {
                    width = (float) displayMetrics.widthPixels;
                }
                adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(getActivity(), (int) (width / f));
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
                layoutParams.height = adSize.getHeightInPixels(getActivity());
                adContainerView.setLayoutParams(layoutParams);
                adContainerView.post(new Runnable() {
                    public final void run() {
                        ShowAds();
                    }
                });
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private void ShowAds() {
        try
        {
            adView = new AdView(getActivity());
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
