package com.xyz.vehiclemanager.history.Model;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "OwnerHistory",indices = @Index(value = {"registrationNo"},unique = true))
public class OwnerHistory {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String imageUrl;
    public String ownerName;
    public String registrationNo;
    public String registrationDate;
    public String fuelType;
    public String chasisNumber;
    public String fuelNorms;
    public String engineNumber;
    public String insuranceUpto;
    public String fitnessUpto;
    public String vehicleClass;
    public String city;
    public String markerModel;
    public String brandName;
    public String modelName;
    public String showRoomPrice;
    public String vehicleType;
    public String vehicleColor;
    public String seatCapacity;
    public String ownership;

    public OwnerHistory(String imageUrl, String ownerName, String registrationNo, String registrationDate, String fuelType, String chasisNumber, String fuelNorms, String engineNumber, String insuranceUpto, String fitnessUpto, String vehicleClass, String city, String markerModel, String brandName, String modelName, String showRoomPrice, String vehicleType, String vehicleColor, String seatCapacity, String ownership) {
        this.imageUrl = imageUrl;
        this.ownerName = ownerName;
        this.registrationNo = registrationNo;
        this.registrationDate = registrationDate;
        this.fuelType = fuelType;
        this.chasisNumber = chasisNumber;
        this.fuelNorms = fuelNorms;
        this.engineNumber = engineNumber;
        this.insuranceUpto = insuranceUpto;
        this.fitnessUpto = fitnessUpto;
        this.vehicleClass = vehicleClass;
        this.city = city;
        this.markerModel = markerModel;
        this.brandName = brandName;
        this.modelName = modelName;
        this.showRoomPrice = showRoomPrice;
        this.vehicleType = vehicleType;
        this.vehicleColor = vehicleColor;
        this.seatCapacity = seatCapacity;
        this.ownership = ownership;
    }

    public int getId() {
        return id;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public String getRegistrationDate() {
        return registrationDate;
    }

    public String getFuelType() {
        return fuelType;
    }

    public String getChasisNumber() {
        return chasisNumber;
    }

    public String getFuelNorms() {
        return fuelNorms;
    }

    public String getEngineNumber() {
        return engineNumber;
    }

    public String getInsuranceUpto() {
        return insuranceUpto;
    }

    public String getFitnessUpto() {
        return fitnessUpto;
    }

    public String getVehicleClass() {
        return vehicleClass;
    }

    public String getCity() {
        return city;
    }

    public String getMarkerModel() {
        return markerModel;
    }

    public String getBrandName() {
        return brandName;
    }

    public String getModelName() {
        return modelName;
    }

    public String getShowRoomPrice() {
        return showRoomPrice;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getVehicleColor() {
        return vehicleColor;
    }

    public String getSeatCapacity() {
        return seatCapacity;
    }

    public String getOwnership() {
        return ownership;
    }
}
