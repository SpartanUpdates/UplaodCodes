package com.kotlinz.videoCollage.scal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

import androidx.core.internal.view.SupportMenu;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SubSamplingScaleImageView extends View {
    public static final int EASE_IN_OUT_QUAD = 2;
    public static final int EASE_OUT_QUAD = 1;
    private static final int MESSAGE_LONG_CLICK = 1;
    public static final int ORIENTATION_0 = 0;
    public static final int ORIENTATION_180 = 180;
    public static final int ORIENTATION_270 = 270;
    public static final int ORIENTATION_90 = 90;
    public static final int ORIENTATION_USE_EXIF = -1;
    public static final int ORIGIN_ANIM = 1;
    public static final int ORIGIN_DOUBLE_TAP_ZOOM = 4;
    public static final int ORIGIN_FLING = 3;
    public static final int ORIGIN_TOUCH = 2;
    public static final int PAN_LIMIT_CENTER = 3;
    public static final int PAN_LIMIT_INSIDE = 1;
    public static final int PAN_LIMIT_OUTSIDE = 2;
    public static final int SCALE_TYPE_CENTER_CROP = 2;
    public static final int SCALE_TYPE_CENTER_INSIDE = 1;
    public static final int SCALE_TYPE_CUSTOM = 3;
    public static final int SCALE_TYPE_START = 4;
    private static final String TAG = SubSamplingScaleImageView.class.getSimpleName();
    public static int TILE_SIZE_AUTO = 20;
    //    public static int TILE_SIZE_AUTO = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    private static final List<Integer> VALID_EASING_STYLES;
    private static final List<Integer> VALID_ORIENTATIONS;
    //    private static final List<Integer> VALID_PAN_LIMITS;
//    private static final List<Integer> VALID_SCALE_TYPES;
//    private static final List<Integer> VALID_ZOOM_STYLES;
    public static final int ZOOM_FOCUS_CENTER = 2;
    public static final int ZOOM_FOCUS_CENTER_IMMEDIATE = 3;
    public static final int ZOOM_FOCUS_FIXED = 1;
    private static Config preferredBitmapConfig;
    private Anim anim;
    private Bitmap bitmap;
    private DecoderFactory<? extends ImageDecoder> bitmapDecoderFactory;
    private boolean bitmapIsCached;
    private boolean bitmapIsPreview;
    private Paint bitmapPaint;
    private boolean debug;
    private Paint debugLinePaint;
    private Paint debugTextPaint;
    private ImageRegionDecoder decoder;
    private final ReadWriteLock decoderLock;
    private float density;
    private GestureDetector detector;
    private int doubleTapZoomDuration;
    private float doubleTapZoomScale;
    private int doubleTapZoomStyle;
    private float[] dstArray;
    private boolean eagerLoadingEnabled;
    private Executor executor;
    private int fullImageSampleSize;
    private Handler handler;
    private boolean imageLoadedSent;
    private boolean isPanning;
    private boolean isQuickScaling;
    private boolean isZooming;
    private Matrix matrix;
    private float maxScale;
    private int maxTileHeight;
    private int maxTileWidth;
    private int maxTouchCount;
    private float minScale;
    private int minimumScaleType;
    private int minimumTileDpi;
    private OnImageEventListener onImageEventListener;
    private OnLongClickListener onLongClickListener;
    private OnStateChangedListener onStateChangedListener;
    private int orientation;
    private Rect pRegion;
    private boolean panEnabled;
    private int panLimit;
    private Float pendingScale;
    private boolean quickScaleEnabled;
    private float quickScaleLastDistance;
    private boolean quickScaleMoved;
    private PointF quickScaleSCenter;
    private final float quickScaleThreshold;
    private PointF quickScaleVLastPoint;
    private PointF quickScaleVStart;
    private boolean readySent;
    private DecoderFactory<? extends ImageRegionDecoder> regionDecoderFactory;
    private int sHeight;
    private int sOrientation;
    private PointF sPendingCenter;
    private RectF sRect;
    private Rect sRegion;
    private PointF sRequestedCenter;
    private int sWidth;
    private ScaleAndTranslate satTemp;
    private float scale;
    private float scaleStart;
    private GestureDetector singleDetector;
    private float[] srcArray;
    private Paint tileBgPaint;
    private Map<Integer, List<Tile>> tileMap;
    private Uri uri;
    private PointF vCenterStart;
    private float vDistStart;
    private PointF vTranslate;
    private PointF vTranslateBefore;
    private PointF vTranslateStart;
    private boolean zoomEnabled;

    private static class Anim {
        private long duration;
        private int easing;
        private boolean interruptible;
        private OnAnimationEventListener listener;
        private int origin;
        private PointF sCenterEnd;
        private PointF sCenterEndRequested;
        private PointF sCenterStart;
        private float scaleEnd;
        private float scaleStart;
        private long time;
        private PointF vFocusEnd;
        private PointF vFocusStart;

        private Anim() {
            this.duration = 500;
            this.interruptible = true;
            this.easing = 2;
            this.origin = 1;
            this.time = System.currentTimeMillis();
        }

        Anim(String str) {
            this();
        }
    }

    public final class AnimationBuilder {
        private long duration;
        private int easing;
        private boolean interruptible;
        private OnAnimationEventListener listener;
        private int origin;
        private boolean panLimited;
        private final PointF targetSCenter;
        private final float targetScale;
        private final PointF vFocus;

        AnimationBuilder(SubSamplingScaleImageView subSamplingScaleImageView, SubSamplingScaleImageView subSamplingScaleImageView2, float f, PointF pointF, PointF pointF2, String str) {
            this(f, pointF, pointF2);
        }

        private AnimationBuilder(SubSamplingScaleImageView subSamplingScaleImageView, PointF pointF, String str) {
            this.duration = 500;
            this.easing = 2;
            this.origin = 1;
            this.interruptible = true;
            this.panLimited = true;
            this.targetScale = SubSamplingScaleImageView.this.scale;
            this.targetSCenter = pointF;
            this.vFocus = null;
        }

        private AnimationBuilder(SubSamplingScaleImageView subSamplingScaleImageView, float f) {
            this.duration = 500;
            this.easing = 2;
            this.origin = 1;
            this.interruptible = true;
            this.panLimited = true;
            this.targetScale = f;
            this.targetSCenter = SubSamplingScaleImageView.this.getCenter();
            this.vFocus = null;
        }

        private AnimationBuilder(SubSamplingScaleImageView subSamplingScaleImageView, float f, PointF pointF) {
            this.duration = 500;
            this.easing = 2;
            this.origin = 1;
            this.interruptible = true;
            this.panLimited = true;
            this.targetScale = f;
            this.targetSCenter = pointF;
            this.vFocus = null;
        }

        private AnimationBuilder(float f, PointF pointF, PointF pointF2) {
            this.duration = 500;
            this.easing = 2;
            this.origin = 1;
            this.interruptible = true;
            this.panLimited = true;
            this.targetScale = f;
            this.targetSCenter = pointF;
            this.vFocus = null;
        }

        private AnimationBuilder(SubSamplingScaleImageView subSamplingScaleImageView, float f, PointF pointF, PointF pointF2) {
            this.duration = 500;
            this.easing = 2;
            this.origin = 1;
            this.interruptible = true;
            this.panLimited = true;
            this.targetScale = f;
            this.targetSCenter = pointF;
            this.vFocus = pointF2;
        }

        public AnimationBuilder withDuration(long j) {
            this.duration = j;
            return this;
        }

        public AnimationBuilder withInterruptible(boolean z) {
            this.interruptible = z;
            return this;
        }

        public AnimationBuilder withEasing(int i) {
            if (SubSamplingScaleImageView.VALID_EASING_STYLES.contains(Integer.valueOf(i))) {
                this.easing = i;
                return this;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown easing type: ");
            stringBuilder.append(i);
            throw new IllegalArgumentException(stringBuilder.toString());
        }

        public AnimationBuilder withOnAnimationEventListener(OnAnimationEventListener onAnimationEventListener) {
            this.listener = onAnimationEventListener;
            return this;
        }

        private AnimationBuilder withPanLimited(boolean z) {
            this.panLimited = z;
            return this;
        }

        private AnimationBuilder withOrigin(int i) {
            this.origin = i;
            return this;
        }

        public void start() {
            if (!(SubSamplingScaleImageView.this.anim == null || SubSamplingScaleImageView.this.anim.listener == null)) {
                try {
                    SubSamplingScaleImageView.this.anim.listener.onInterruptedByNewAnim();
                } catch (Exception e) {
                    Log.w(SubSamplingScaleImageView.TAG, "Error thrown by animation listener", e);
                }
            }
            int paddingLeft = SubSamplingScaleImageView.this.getPaddingLeft() + (((SubSamplingScaleImageView.this.getWidth() - SubSamplingScaleImageView.this.getPaddingRight()) - SubSamplingScaleImageView.this.getPaddingLeft()) / 2);
            int paddingTop = SubSamplingScaleImageView.this.getPaddingTop() + (((SubSamplingScaleImageView.this.getHeight() - SubSamplingScaleImageView.this.getPaddingBottom()) - SubSamplingScaleImageView.this.getPaddingTop()) / 2);
            float access$500 = SubSamplingScaleImageView.this.limitedScale(this.targetScale);
            PointF access$600 = this.panLimited ? SubSamplingScaleImageView.this.limitedSCenter(this.targetSCenter.x, this.targetSCenter.y, access$500, new PointF()) : this.targetSCenter;
            SubSamplingScaleImageView.this.anim = new Anim();
            SubSamplingScaleImageView.this.anim.scaleStart = SubSamplingScaleImageView.this.scale;
            SubSamplingScaleImageView.this.anim.scaleEnd = access$500;
            SubSamplingScaleImageView.this.anim.time = System.currentTimeMillis();
            SubSamplingScaleImageView.this.anim.sCenterEndRequested = access$600;
            SubSamplingScaleImageView.this.anim.sCenterStart = SubSamplingScaleImageView.this.getCenter();
            SubSamplingScaleImageView.this.anim.sCenterEnd = access$600;
            SubSamplingScaleImageView.this.anim.vFocusStart = SubSamplingScaleImageView.this.sourceToViewCoord(access$600);
            SubSamplingScaleImageView.this.anim.vFocusEnd = new PointF((float) paddingLeft, (float) paddingTop);
            SubSamplingScaleImageView.this.anim.duration = this.duration;
            SubSamplingScaleImageView.this.anim.interruptible = this.interruptible;
            SubSamplingScaleImageView.this.anim.easing = this.easing;
            SubSamplingScaleImageView.this.anim.origin = this.origin;
            SubSamplingScaleImageView.this.anim.time = System.currentTimeMillis();
            SubSamplingScaleImageView.this.anim.listener = this.listener;
            PointF pointF = this.vFocus;
            if (pointF != null) {
                float f = pointF.x - (SubSamplingScaleImageView.this.anim.sCenterStart.x * access$500);
                float f2 = this.vFocus.y - (SubSamplingScaleImageView.this.anim.sCenterStart.y * access$500);
                ScaleAndTranslate scaleAndTranslate = new ScaleAndTranslate(access$500, new PointF(f, f2), null);
                SubSamplingScaleImageView.this.fitToBounds(true, scaleAndTranslate);
                SubSamplingScaleImageView.this.anim.vFocusEnd = new PointF(this.vFocus.x + (scaleAndTranslate.vTranslate.x - f), this.vFocus.y + (scaleAndTranslate.vTranslate.y - f2));
            }
            SubSamplingScaleImageView.this.invalidate();
        }
    }

    private static class BitmapLoadTask extends AsyncTask<Void, Void, Integer> {
        private Bitmap bitmap;
        private final WeakReference<Context> contextRef;
        private final WeakReference<DecoderFactory<? extends ImageDecoder>> decoderFactoryRef;
        private Exception exception;
        private final boolean preview;
        private final Uri source;
        private final WeakReference<SubSamplingScaleImageView> viewRef;

        BitmapLoadTask(SubSamplingScaleImageView subSamplingScaleImageView, Context context, DecoderFactory<? extends ImageDecoder> decoderFactory, Uri uri, boolean z) {
            this.viewRef = new WeakReference(subSamplingScaleImageView);
            this.contextRef = new WeakReference(context);
            this.decoderFactoryRef = new WeakReference(decoderFactory);
            this.source = uri;
            this.preview = z;
        }

        public Integer doInBackground(Void... voidArr) {
            try {
                String uri = this.source.toString();
                Context context = (Context) this.contextRef.get();
                DecoderFactory decoderFactory = (DecoderFactory) this.decoderFactoryRef.get();
                SubSamplingScaleImageView subSamplingScaleImageView = (SubSamplingScaleImageView) this.viewRef.get();
                if (!(context == null || decoderFactory == null || subSamplingScaleImageView == null)) {
                    subSamplingScaleImageView.debug("BitmapLoadTask.doInBackground", new Object[0]);
                    this.bitmap = ((ImageDecoder) decoderFactory.make()).decode(context, this.source);
                    return Integer.valueOf(subSamplingScaleImageView.getExifOrientation(context, uri));
                }
            } catch (Exception e) {
                Log.e(SubSamplingScaleImageView.TAG, "Failed to load bitmap", e);
                this.exception = e;
            } catch (OutOfMemoryError e2) {
                Log.e(SubSamplingScaleImageView.TAG, "Failed to load bitmap - OutOfMemoryError", e2);
                this.exception = new RuntimeException(e2);
            }
            return null;
        }

        public void onPostExecute(Integer num) {
            SubSamplingScaleImageView subSamplingScaleImageView = (SubSamplingScaleImageView) this.viewRef.get();
            if (subSamplingScaleImageView != null) {
                Bitmap bitmap = this.bitmap;
                if (bitmap == null || num == null) {
                    if (!(this.exception == null || subSamplingScaleImageView.onImageEventListener == null)) {
                        if (this.preview) {
                            subSamplingScaleImageView.onImageEventListener.onPreviewLoadError(this.exception);
                        } else {
                            subSamplingScaleImageView.onImageEventListener.onImageLoadError(this.exception);
                        }
                    }
                } else if (this.preview) {
                    subSamplingScaleImageView.onPreviewLoaded(bitmap);
                } else {
                    subSamplingScaleImageView.onImageLoaded(bitmap, num.intValue(), false);
                }
            }
        }
    }

    public interface OnAnimationEventListener {
        void onComplete();

        void onInterruptedByNewAnim();

        void onInterruptedByUser();
    }

    public interface OnImageEventListener {
        void onImageLoadError(Exception exception);

        void onImageLoaded();

        void onPreviewLoadError(Exception exception);

        void onPreviewReleased();

        void onReady();

        void onTileLoadError(Exception exception);
    }

    public interface OnStateChangedListener {
        void onCenterChanged(PointF pointF, int i);

        void onScaleChanged(float f, int i);
    }

    private static class ScaleAndTranslate {
        private float scale;
        private PointF vTranslate;

        ScaleAndTranslate(float f, PointF pointF, String str) {
            this(f, pointF);
        }

        private ScaleAndTranslate(float f, PointF pointF) {
            this.scale = f;
            this.vTranslate = pointF;
        }
    }

    private static class Tile {
        private Bitmap bitmap;
        private Rect fileSRect;
        private boolean loading;
        private Rect sRect;
        private int sampleSize;
        private Rect vRect;
        private boolean visible;

        private Tile() {
        }

        Tile(String str) {
            this();
        }
    }

    private static class TileLoadTask extends AsyncTask<Void, Void, Bitmap> {
        private final WeakReference<ImageRegionDecoder> decoderRef;
        private Exception exception;
        private final WeakReference<Tile> tileRef;
        private final WeakReference<SubSamplingScaleImageView> viewRef;

        TileLoadTask(SubSamplingScaleImageView subSamplingScaleImageView, ImageRegionDecoder imageRegionDecoder, Tile tile) {
            this.viewRef = new WeakReference(subSamplingScaleImageView);
            this.decoderRef = new WeakReference(imageRegionDecoder);
            this.tileRef = new WeakReference(tile);
            tile.loading = true;
        }

        /* JADX WARNING: Removed duplicated region for block: B:31:0x00c7 A:{Splitter:B:1:0x0001, ExcHandler: Exception (r0_8 'e' java.lang.Exception)} */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x00b5 A:{Splitter:B:1:0x0001, ExcHandler: OutOfMemoryError (r0_7 'e' java.lang.OutOfMemoryError)} */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing block: B:29:0x00b5, code skipped:
            r0 = move-exception;
     */
        /* JADX WARNING: Missing block: B:30:0x00b6, code skipped:
            android.util.Log.e(fcom.collage.imagevideo.scal.SubSamplingScaleImageView.access$400(), "Failed to decode tile - OutOfMemoryError", r0);
            r8.exception = new java.lang.RuntimeException(r0);
     */
        /* JADX WARNING: Missing block: B:31:0x00c7, code skipped:
            r0 = move-exception;
     */
        /* JADX WARNING: Missing block: B:32:0x00c8, code skipped:
            android.util.Log.e(fcom.collage.imagevideo.scal.SubSamplingScaleImageView.access$400(), "Failed to decode tile", r0);
            r8.exception = r0;
     */
        public Bitmap doInBackground(Void... r9) {
            /*
            r8 = this;
            r9 = 0;
            r0 = r8.viewRef;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a8 }
            r0 = r0.get();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a8 }
            r0 = (fcom.collage.imagevideo.scal.SubSamplingScaleImageView) r0;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a8 }
            r1 = r8.decoderRef;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1 = r1.get();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1 = (fcom.collage.imagevideo.scal.ImageRegionDecoder) r1;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = r8.tileRef;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = r2.get();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = (fcom.collage.imagevideo.scal.SubSamplingScaleImageView.Tile) r2;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r3 = 0;
            if (r1 == 0) goto L_0x00a2;
        L_0x001c:
            if (r2 == 0) goto L_0x00a2;
        L_0x001e:
            if (r0 == 0) goto L_0x00a2;
        L_0x0020:
            r4 = r1.isReady();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            if (r4 == 0) goto L_0x00a2;
        L_0x0026:
            r4 = r2.visible;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            if (r4 != 0) goto L_0x002d;
        L_0x002c:
            goto L_0x00a2;
        L_0x002d:
            r4 = "TileLoadTask.doInBackground, tile.sRect=%s, tile.sampleSize=%d";
            r5 = 2;
            r5 = new java.lang.Object[r5];	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r6 = r2.sRect;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r5[r3] = r6;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r6 = 1;
            r7 = r2.sampleSize;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r7 = java.lang.Integer.valueOf(r7);	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r5[r6] = r7;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r0.debug(r4, r5);	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r0.decoderLock;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r4.readLock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4.lock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r1.isReady();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            if (r4 == 0) goto L_0x0093;
        L_0x0057:
            r3 = r2.sRect;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r2.fileSRect;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r0.fileSRect(r3, r4);	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r3 = r0.sRegion;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            if (r3 == 0) goto L_0x007b;
        L_0x0068:
            r3 = r2.fileSRect;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r0.sRegion;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r4 = r4.left;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r5 = r0.sRegion;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r5 = r5.top;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r3.offset(r4, r5);	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
        L_0x007b:
            r3 = r2.fileSRect;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = r2.sampleSize;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1 = r1.decodeRegion(r3, r2);	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = r0.decoderLock;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2 = r2.readLock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r2.unlock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            return r1;
        L_0x0093:
            r2.loading = r3;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1 = r0.decoderLock;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1 = r1.readLock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            r1.unlock();	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
            return r9;
        L_0x00a2:
            if (r2 == 0) goto L_0x00a7;
        L_0x00a4:
            r2.loading = r3;	 Catch:{ Exception -> 0x00c7, OutOfMemoryError -> 0x00b5, all -> 0x00a9 }
        L_0x00a7:
            return r9;
        L_0x00a8:
            r0 = r9;
        L_0x00a9:
            r0 = r0.decoderLock;
            r0 = r0.readLock();
            r0.unlock();
            goto L_0x00d3;
        L_0x00b5:
            r0 = move-exception;
            r1 = fcom.collage.imagevideo.scal.SubSamplingScaleImageView.TAG;
            r2 = "Failed to decode tile - OutOfMemoryError";
            android.util.Log.e(r1, r2, r0);
            r1 = new java.lang.RuntimeException;
            r1.<init>(r0);
            r8.exception = r1;
            goto L_0x00d3;
        L_0x00c7:
            r0 = move-exception;
            r1 = fcom.collage.imagevideo.scal.SubSamplingScaleImageView.TAG;
            r2 = "Failed to decode tile";
            android.util.Log.e(r1, r2, r0);
            r8.exception = r0;
        L_0x00d3:
            return r9;
            */
            throw new UnsupportedOperationException("Method not decompiled: fcom.collage.imagevideo.scal.SubSamplingScaleImageView$TileLoadTask.doInBackground(java.lang.Void[]):android.graphics.Bitmap");
        }

        public void onPostExecute(Bitmap bitmap) {
            SubSamplingScaleImageView subSamplingScaleImageView = (SubSamplingScaleImageView) this.viewRef.get();
            Tile tile = (Tile) this.tileRef.get();
            if (subSamplingScaleImageView != null && tile != null) {
                if (bitmap != null) {
                    tile.bitmap = bitmap;
                    tile.loading = false;
                    subSamplingScaleImageView.onTileLoaded();
                } else if (this.exception != null && subSamplingScaleImageView.onImageEventListener != null) {
                    subSamplingScaleImageView.onImageEventListener.onTileLoadError(this.exception);
                }
            }
        }
    }

    private static class TilesInitTask extends AsyncTask<Void, Void, int[]> {
        private final WeakReference<Context> contextRef;
        private ImageRegionDecoder decoder;
        private final WeakReference<DecoderFactory<? extends ImageRegionDecoder>> decoderFactoryRef;
        private Exception exception;
        private final Uri source;
        private final WeakReference<SubSamplingScaleImageView> viewRef;

        TilesInitTask(SubSamplingScaleImageView subSamplingScaleImageView, Context context, DecoderFactory<? extends ImageRegionDecoder> decoderFactory, Uri uri) {
            this.viewRef = new WeakReference(subSamplingScaleImageView);
            this.contextRef = new WeakReference(context);
            this.decoderFactoryRef = new WeakReference(decoderFactory);
            this.source = uri;
        }

        public int[] doInBackground(Void... voidArr) {
            try {
                String uri = this.source.toString();
                Context context = (Context) this.contextRef.get();
                DecoderFactory decoderFactory = (DecoderFactory) this.decoderFactoryRef.get();
                SubSamplingScaleImageView subSamplingScaleImageView = (SubSamplingScaleImageView) this.viewRef.get();
                if (!(context == null || decoderFactory == null || subSamplingScaleImageView == null)) {
                    subSamplingScaleImageView.debug("TilesInitTask.doInBackground", new Object[0]);
                    ImageRegionDecoder imageRegionDecoder = (ImageRegionDecoder) decoderFactory.make();
                    this.decoder = imageRegionDecoder;
                    Point init = imageRegionDecoder.init(context, this.source);
                    int i = init.x;
                    int i2 = init.y;
                    int access$2300 = subSamplingScaleImageView.getExifOrientation(context, uri);
                    if (subSamplingScaleImageView.sRegion != null) {
                        subSamplingScaleImageView.sRegion.left = Math.max(0, subSamplingScaleImageView.sRegion.left);
                        subSamplingScaleImageView.sRegion.top = Math.max(0, subSamplingScaleImageView.sRegion.top);
                        subSamplingScaleImageView.sRegion.right = Math.min(i, subSamplingScaleImageView.sRegion.right);
                        subSamplingScaleImageView.sRegion.bottom = Math.min(i2, subSamplingScaleImageView.sRegion.bottom);
                        i = subSamplingScaleImageView.sRegion.width();
                        i2 = subSamplingScaleImageView.sRegion.height();
                    }
                    return new int[]{i, i2, access$2300};
                }
            } catch (Exception e) {
                Log.e(SubSamplingScaleImageView.TAG, "Failed to initialise bitmap decoder", e);
                this.exception = e;
            }
            return null;
        }

        public void onPostExecute(int[] iArr) {
            SubSamplingScaleImageView subSamplingScaleImageView = (SubSamplingScaleImageView) this.viewRef.get();
            if (subSamplingScaleImageView != null) {
                ImageRegionDecoder imageRegionDecoder = this.decoder;
                if (imageRegionDecoder != null && iArr != null && iArr.length == 3) {
                    subSamplingScaleImageView.onTilesInited(imageRegionDecoder, iArr[0], iArr[1], iArr[2]);
                } else if (!(this.exception == null || subSamplingScaleImageView.onImageEventListener == null)) {
                    subSamplingScaleImageView.onImageEventListener.onImageLoadError(this.exception);
                }
            }
        }
    }

    public static class DefaultOnAnimationEventListener implements OnAnimationEventListener {
        public void onComplete() {
        }

        public void onInterruptedByNewAnim() {
        }

        public void onInterruptedByUser() {
        }
    }

    public static class DefaultOnImageEventListener implements OnImageEventListener {
        public void onImageLoadError(Exception exception) {
        }

        public void onImageLoaded() {
        }

        public void onPreviewLoadError(Exception exception) {
        }

        public void onPreviewReleased() {
        }

        public void onReady() {
        }

        public void onTileLoadError(Exception exception) {
        }
    }

    public static class DefaultOnStateChangedListener implements OnStateChangedListener {
        public void onCenterChanged(PointF pointF, int i) {
        }

        public void onScaleChanged(float f, int i) {
        }
    }

    private float easeInOutQuad(long j, float f, float f2, long j2) {
        float f3 = ((float) j) / (((float) j2) / 2.0f);
        if (f3 < 1.0f) {
            f2 = ((f2 / 2.0f) * f3) * f3;
        } else {
            f3 -= 1.0f;
            f2 = ((-f2) / 2.0f) * (((f3 - 2.0f) * f3) - 1.0f);
        }
        return f2 + f;
    }

    private float easeOutQuad(long j, float f, float f2, long j2) {
        float f3 = ((float) j) / ((float) j2);
        return (((-f2) * f3) * (f3 - 2.0f)) + f;
    }

    public static void setPreferredBitmapConfig(Config config) {
    }

    public void onImageLoaded() {
    }

    public void onReady() {
    }

    static {
        Integer[] numArr = new Integer[2];
        numArr[0] = Integer.valueOf(2);
        numArr[1] = Integer.valueOf(1);
        VALID_EASING_STYLES = Arrays.asList(numArr);
        numArr = new Integer[5];
        numArr[0] = Integer.valueOf(0);
        numArr[1] = Integer.valueOf(90);
        numArr[2] = Integer.valueOf(ORIENTATION_180);
        Integer valueOf = Integer.valueOf(ORIENTATION_270);
        Integer valueOf2 = Integer.valueOf(3);
        numArr[3] = valueOf;
        numArr[4] = Integer.valueOf(-1);
        VALID_ORIENTATIONS = Arrays.asList(numArr);
//        VALID_PAN_LIMITS = Arrays.asList(new Integer[]{r5, r1, valueOf2});
//        VALID_SCALE_TYPES = Arrays.asList(new Integer[]{r1, r5, valueOf2, Integer.valueOf(4)});
//        VALID_ZOOM_STYLES = Arrays.asList(new Integer[]{r5, r1, valueOf2});
    }

    public SubSamplingScaleImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.orientation = 0;
        this.maxScale = 2.0f;
        this.minScale = minScale();
        this.minimumTileDpi = -1;
        this.panLimit = 1;
        this.minimumScaleType = 1;
        int i = TILE_SIZE_AUTO;
        this.maxTileWidth = i;
        this.maxTileHeight = i;
        this.executor = AsyncTask.THREAD_POOL_EXECUTOR;
        this.eagerLoadingEnabled = true;
        this.panEnabled = true;
        this.zoomEnabled = true;
        this.quickScaleEnabled = true;
        this.doubleTapZoomScale = 1.0f;
        this.doubleTapZoomStyle = 1;
        this.doubleTapZoomDuration = 500;
        this.decoderLock = new ReentrantReadWriteLock(true);
        this.bitmapDecoderFactory = new CompatDecoderFactory(SkiaImageDecoder.class);
        this.regionDecoderFactory = new CompatDecoderFactory(SkiaImageRegionDecoder.class);
        this.srcArray = new float[8];
        this.dstArray = new float[8];
        this.density = getResources().getDisplayMetrics().density;
        setMinimumDpi(160);
        setDoubleTapZoomDpi(160);
        setMinimumTileDpi(320);
        setGestureDetector(context);
        this.handler = new Handler(new Callback() {
            public boolean handleMessage(Message message) {
                if (message.what == 1 && SubSamplingScaleImageView.this.onLongClickListener != null) {
                    SubSamplingScaleImageView.this.maxTouchCount = 0;
                    SubSamplingScaleImageView subSamplingScaleImageView = SubSamplingScaleImageView.this;
//                    super.setOnLongClickListener(subSamplingScaleImageView.onLongClickListener);
                    SubSamplingScaleImageView.this.performLongClick();
//                    super.setOnLongClickListener(null);
                }
                return true;
            }
        });
        /*if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.ActionBar);
            if (obtainStyledAttributes.hasValue(0)) {
                String string = obtainStyledAttributes.getString(0);
                if (string != null && string.length() > 0) {
                    setImage(ImageSource.asset(string).tilingEnabled());
                }
            }
            if (obtainStyledAttributes.hasValue(3)) {
                i = obtainStyledAttributes.getResourceId(3, 0);
                if (i > 0) {
                    setImage(ImageSource.resource(i).tilingEnabled());
                }
            }
            if (obtainStyledAttributes.hasValue(1)) {
                setPanEnabled(obtainStyledAttributes.getBoolean(1, true));
            }
            if (obtainStyledAttributes.hasValue(5)) {
                setZoomEnabled(obtainStyledAttributes.getBoolean(5, true));
            }
            if (obtainStyledAttributes.hasValue(2)) {
                setQuickScaleEnabled(obtainStyledAttributes.getBoolean(2, true));
            }
            if (obtainStyledAttributes.hasValue(4)) {
                setTileBackgroundColor(obtainStyledAttributes.getColor(4, Color.argb(0, 0, 0, 0)));
            }
            obtainStyledAttributes.recycle();
        }*/
        this.quickScaleThreshold = TypedValue.applyDimension(1, 20.0f, context.getResources().getDisplayMetrics());
    }

    public SubSamplingScaleImageView(Context context) {
        this(context, null);
    }

    public static Config getPreferredBitmapConfig() {
        return preferredBitmapConfig;
    }

    public final void setOrientation(int i) {
        if (VALID_ORIENTATIONS.contains(Integer.valueOf(i))) {
            this.orientation = i;
            reset(false);
            invalidate();
            requestLayout();
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid orientation: ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final void setImage(ImageSource imageSource) {
        setImage(imageSource, null, null);
    }

    public final void setImage(ImageSource imageSource, ImageViewState imageViewState) {
        setImage(imageSource, null, imageViewState);
    }

    public final void setImage(ImageSource imageSource, ImageSource imageSource2) {
        setImage(imageSource, imageSource2, null);
    }

    public final void setImage(ImageSource imageSource, ImageSource imageSource2, ImageViewState imageViewState) {
        if (imageSource != null) {
            reset(true);
            if (imageViewState != null) {
                restoreState(imageViewState);
            }
            String str = "/";
            String str2 = "android.resource://";
            if (imageSource2 != null) {
                if (imageSource.getBitmap() != null) {
                    throw new IllegalArgumentException("Preview image cannot be used when a bitmap is provided for the activity image");
                } else if (imageSource.getSWidth() <= 0 || imageSource.getSHeight() <= 0) {
                    throw new IllegalArgumentException("Preview image cannot be used unless dimensions are provided for the activity image");
                } else {
                    this.sWidth = imageSource.getSWidth();
                    this.sHeight = imageSource.getSHeight();
                    this.pRegion = imageSource2.getSRegion();
                    if (imageSource2.getBitmap() != null) {
                        this.bitmapIsCached = imageSource2.isCached();
                        onPreviewLoaded(imageSource2.getBitmap());
                    } else {
                        Uri uri = imageSource2.getUri();
                        if (uri == null && imageSource2.getResource() != null) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(str2);
                            stringBuilder.append(getContext().getPackageName());
                            stringBuilder.append(str);
                            stringBuilder.append(imageSource2.getResource());
                            uri = Uri.parse(stringBuilder.toString());
                        }
                        execute(new BitmapLoadTask(this, getContext(), this.bitmapDecoderFactory, uri, true));
                    }
                }
            }
            if (imageSource.getBitmap() != null && imageSource.getSRegion() != null) {
                onImageLoaded(Bitmap.createBitmap(imageSource.getBitmap(), imageSource.getSRegion().left, imageSource.getSRegion().top, imageSource.getSRegion().width(), imageSource.getSRegion().height()), 0, false);
            } else if (imageSource.getBitmap() != null) {
                onImageLoaded(imageSource.getBitmap(), 0, imageSource.isCached());
            } else {
                this.sRegion = imageSource.getSRegion();
                Uri uri2 = imageSource.getUri();
                this.uri = uri2;
                if (uri2 == null && imageSource.getResource() != null) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str2);
                    stringBuilder2.append(getContext().getPackageName());
                    stringBuilder2.append(str);
                    stringBuilder2.append(imageSource.getResource());
                    this.uri = Uri.parse(stringBuilder2.toString());
                }
                if (imageSource.getTile() || this.sRegion != null) {
                    execute(new TilesInitTask(this, getContext(), this.regionDecoderFactory, this.uri));
                    return;
                } else {
                    execute(new BitmapLoadTask(this, getContext(), this.bitmapDecoderFactory, this.uri, false));
                }
            }
            return;
        }
        throw new NullPointerException("imageSource must not be null");
    }

    private void reset(boolean z) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reset newImage=");
        stringBuilder.append(z);
        debug(stringBuilder.toString(), new Object[0]);
        this.scale = 0.0f;
        this.scaleStart = 0.0f;
        this.vTranslate = null;
        this.vTranslateStart = null;
        this.vTranslateBefore = null;
        this.pendingScale = Float.valueOf(0.0f);
        this.sPendingCenter = null;
        this.sRequestedCenter = null;
        this.isZooming = false;
        this.isPanning = false;
        this.isQuickScaling = false;
        this.maxTouchCount = 0;
        this.fullImageSampleSize = 0;
        this.vCenterStart = null;
        this.vDistStart = 0.0f;
        this.quickScaleLastDistance = 0.0f;
        this.quickScaleMoved = false;
        this.quickScaleSCenter = null;
        this.quickScaleVLastPoint = null;
        this.quickScaleVStart = null;
        this.anim = null;
        this.satTemp = null;
        this.matrix = null;
        this.sRect = null;
        if (z) {
            this.uri = null;
            this.decoderLock.writeLock().lock();
            try {
                if (this.decoder != null) {
                    this.decoder.recycle();
                    this.decoder = null;
                }
                this.decoderLock.writeLock().unlock();
                if (!(this.bitmap == null || this.bitmapIsCached)) {
                    this.bitmap.recycle();
                }
                if (!(this.bitmap == null || !this.bitmapIsCached || this.onImageEventListener == null)) {
                    this.onImageEventListener.onPreviewReleased();
                }
                this.sWidth = 0;
                this.sHeight = 0;
                this.sOrientation = 0;
                this.sRegion = null;
                this.pRegion = null;
                this.readySent = false;
                this.imageLoadedSent = false;
                this.bitmap = null;
                this.bitmapIsPreview = false;
                this.bitmapIsCached = false;
            } catch (Throwable unused) {
                this.decoderLock.writeLock().unlock();
            }
        }
       /* Map map = this.tileMap;
        if (map != null) {
            for (Entry value : map.entrySet()) {
                for (Tile tile : (List) value.getValue()) {
                    tile.visible = false;
                    if (tile.bitmap != null) {
                        tile.bitmap.recycle();
                        tile.bitmap = null;
                    }
                }
            }
            this.tileMap = null;
        }*/
        setGestureDetector(getContext());
    }

    private void setGestureDetector(final Context context) {
        this.detector = new GestureDetector(context, new SimpleOnGestureListener() {
            public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
                if (!SubSamplingScaleImageView.this.panEnabled || !SubSamplingScaleImageView.this.readySent || SubSamplingScaleImageView.this.vTranslate == null || motionEvent == null || motionEvent2 == null || ((Math.abs(motionEvent.getX() - motionEvent2.getX()) <= 50.0f && Math.abs(motionEvent.getY() - motionEvent2.getY()) <= 50.0f) || ((Math.abs(f) <= 500.0f && Math.abs(f2) <= 500.0f) || SubSamplingScaleImageView.this.isZooming))) {
                    return super.onFling(motionEvent, motionEvent2, f, f2);
                }
                PointF pointF = new PointF(SubSamplingScaleImageView.this.vTranslate.x + (f * 0.25f), SubSamplingScaleImageView.this.vTranslate.y + (f2 * 0.25f));
                SubSamplingScaleImageView subSamplingScaleImageView = SubSamplingScaleImageView.this;
//                new AnimationBuilder(subSamplingScaleImageView, subSamplingScaleImageView, new PointF((((float) (SubSamplingScaleImageView.this.getWidth() / 2)) - pointF.x) / SubSamplingScaleImageView.this.scale, (((float) (SubSamplingScaleImageView.this.getHeight() / 2)) - pointF.y) / SubSamplingScaleImageView.this.scale), null, null).withEasing(1).withPanLimited(false).withOrigin(3).start();
                return true;
            }

            public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
                SubSamplingScaleImageView.this.performClick();
                return true;
            }

            public boolean onDoubleTap(MotionEvent motionEvent) {
                if (!SubSamplingScaleImageView.this.zoomEnabled || !SubSamplingScaleImageView.this.readySent || SubSamplingScaleImageView.this.vTranslate == null) {
                    return super.onDoubleTapEvent(motionEvent);
                }
                SubSamplingScaleImageView.this.setGestureDetector(context);
                SubSamplingScaleImageView subSamplingScaleImageView;
                if (SubSamplingScaleImageView.this.quickScaleEnabled) {
                    SubSamplingScaleImageView.this.vCenterStart = new PointF(motionEvent.getX(), motionEvent.getY());
                    SubSamplingScaleImageView.this.vTranslateStart = new PointF(SubSamplingScaleImageView.this.vTranslate.x, SubSamplingScaleImageView.this.vTranslate.y);
                    subSamplingScaleImageView = SubSamplingScaleImageView.this;
                    subSamplingScaleImageView.scaleStart = subSamplingScaleImageView.scale;
                    SubSamplingScaleImageView.this.isQuickScaling = true;
                    SubSamplingScaleImageView.this.isZooming = true;
                    SubSamplingScaleImageView.this.quickScaleLastDistance = -1.0f;
                    subSamplingScaleImageView = SubSamplingScaleImageView.this;
                    subSamplingScaleImageView.quickScaleSCenter = subSamplingScaleImageView.viewToSourceCoord(subSamplingScaleImageView.vCenterStart);
                    SubSamplingScaleImageView.this.quickScaleVStart = new PointF(motionEvent.getX(), motionEvent.getY());
                    SubSamplingScaleImageView.this.quickScaleVLastPoint = new PointF(SubSamplingScaleImageView.this.quickScaleSCenter.x, SubSamplingScaleImageView.this.quickScaleSCenter.y);
                    SubSamplingScaleImageView.this.quickScaleMoved = false;
                    return false;
                }
                subSamplingScaleImageView = SubSamplingScaleImageView.this;
                subSamplingScaleImageView.doubleTapZoom(subSamplingScaleImageView.viewToSourceCoord(new PointF(motionEvent.getX(), motionEvent.getY())), new PointF(motionEvent.getX(), motionEvent.getY()));
                return true;
            }
        });
        this.singleDetector = new GestureDetector(context, new SimpleOnGestureListener() {
            public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
                SubSamplingScaleImageView.this.performClick();
                return true;
            }
        });
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        debug("onSizeChanged %dx%d -> %dx%d", Integer.valueOf(i3), Integer.valueOf(i4), Integer.valueOf(i), Integer.valueOf(i2));
        PointF center = getCenter();
        if (this.readySent && center != null) {
            this.anim = null;
            this.pendingScale = Float.valueOf(this.scale);
            this.sPendingCenter = center;
        }
    }

    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        i = MeasureSpec.getSize(i);
        i2 = MeasureSpec.getSize(i2);
        Object obj = null;
        Object obj2 = mode != 1073741824 ? 1 : null;
        if (mode2 != 1073741824) {
            obj = 1;
        }
        if (this.sWidth > 0 && this.sHeight > 0) {
            if (obj2 != null && obj != null) {
                i = sWidth();
                i2 = sHeight();
            } else if (obj != null) {
                i2 = (int) ((((double) sHeight()) / ((double) sWidth())) * ((double) i));
            } else if (obj2 != null) {
                i = (int) ((((double) sWidth()) / ((double) sHeight())) * ((double) i2));
            }
        }
        setMeasuredDimension(Math.max(i, getSuggestedMinimumWidth()), Math.max(i2, getSuggestedMinimumHeight()));
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        Anim anim = this.anim;
        boolean z = true;
        if (anim == null || anim.interruptible) {
            anim = this.anim;
            if (!(anim == null || anim.listener == null)) {
                try {
                    this.anim.listener.onInterruptedByUser();
                } catch (Exception e) {
                    Log.w(TAG, "Error thrown by animation listener", e);
                }
            }
            this.anim = null;
            GestureDetector gestureDetector;
            if (this.vTranslate == null) {
                gestureDetector = this.singleDetector;
                if (gestureDetector == null) {
                    return true;
                }
                gestureDetector.onTouchEvent(motionEvent);
                return true;
            }
            if (!this.isQuickScaling) {
                gestureDetector = this.detector;
                if (gestureDetector == null || gestureDetector.onTouchEvent(motionEvent)) {
                    this.isZooming = false;
                    this.isPanning = false;
                    this.maxTouchCount = 0;
                    return true;
                }
            }
            if (this.vTranslateStart == null) {
                this.vTranslateStart = new PointF(0.0f, 0.0f);
            }
            if (this.vTranslateBefore == null) {
                this.vTranslateBefore = new PointF(0.0f, 0.0f);
            }
            if (this.vCenterStart == null) {
                this.vCenterStart = new PointF(0.0f, 0.0f);
            }
            float f = this.scale;
            this.vTranslateBefore.set(this.vTranslate);
            boolean onTouchEventInternal = onTouchEventInternal(motionEvent);
            sendStateChanged(f, this.vTranslateBefore, 2);
            if (!(onTouchEventInternal || super.onTouchEvent(motionEvent))) {
                z = false;
            }
            return z;
        }
        requestDisallowInterceptTouchEvent(true);
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:132:0x03e6  */
    /* JADX WARNING: Missing block: B:11:0x001f, code skipped:
            if (r1 != 262) goto L_0x03ef;
     */
    private boolean onTouchEventInternal(MotionEvent r13) {
        /*
        r12 = this;
        r0 = r13.getPointerCount();
        r1 = r13.getAction();
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r3 = 2;
        r4 = 0;
        r5 = 1;
        if (r1 == 0) goto L_0x0461;
    L_0x000f:
        if (r1 == r5) goto L_0x03f0;
    L_0x0011:
        if (r1 == r3) goto L_0x0023;
    L_0x0013:
        r6 = 5;
        if (r1 == r6) goto L_0x0461;
    L_0x0016:
        r6 = 6;
        if (r1 == r6) goto L_0x03f0;
    L_0x0019:
        r6 = 261; // 0x105 float:3.66E-43 double:1.29E-321;
        if (r1 == r6) goto L_0x0461;
    L_0x001d:
        r2 = 262; // 0x106 float:3.67E-43 double:1.294E-321;
        if (r1 == r2) goto L_0x03f0;
    L_0x0021:
        goto L_0x03ef;
    L_0x0023:
        r1 = r12.maxTouchCount;
        if (r1 <= 0) goto L_0x03e3;
    L_0x0027:
        r1 = 1084227584; // 0x40a00000 float:5.0 double:5.356796015E-315;
        if (r0 < r3) goto L_0x0195;
    L_0x002b:
        r0 = r13.getX(r4);
        r6 = r13.getX(r5);
        r7 = r13.getY(r4);
        r8 = r13.getY(r5);
        r0 = r12.distance(r0, r6, r7, r8);
        r6 = r13.getX(r4);
        r7 = r13.getX(r5);
        r6 = r6 + r7;
        r6 = r6 / r2;
        r7 = r13.getY(r4);
        r13 = r13.getY(r5);
        r7 = r7 + r13;
        r7 = r7 / r2;
        r13 = r12.zoomEnabled;
        if (r13 == 0) goto L_0x03e3;
    L_0x0057:
        r13 = r12.vCenterStart;
        r13 = r13.x;
        r2 = r12.vCenterStart;
        r2 = r2.y;
        r13 = r12.distance(r13, r6, r2, r7);
        r13 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1));
        if (r13 > 0) goto L_0x0077;
    L_0x0067:
        r13 = r12.vDistStart;
        r13 = r0 - r13;
        r13 = java.lang.Math.abs(r13);
        r13 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1));
        if (r13 > 0) goto L_0x0077;
    L_0x0073:
        r13 = r12.isPanning;
        if (r13 == 0) goto L_0x03e3;
    L_0x0077:
        r12.isZooming = r5;
        r12.isPanning = r5;
        r13 = r12.scale;
        r1 = (double) r13;
        r13 = r12.maxScale;
        r8 = r12.vDistStart;
        r8 = r0 / r8;
        r9 = r12.scaleStart;
        r8 = r8 * r9;
        r13 = java.lang.Math.min(r13, r8);
        r12.scale = r13;
        r8 = r12.minScale();
        r13 = (r13 > r8 ? 1 : (r13 == r8 ? 0 : -1));
        if (r13 > 0) goto L_0x00ac;
    L_0x0096:
        r12.vDistStart = r0;
        r13 = r12.minScale();
        r12.scaleStart = r13;
        r13 = r12.vCenterStart;
        r13.set(r6, r7);
        r13 = r12.vTranslateStart;
        r0 = r12.vTranslate;
        r13.set(r0);
        goto L_0x018b;
    L_0x00ac:
        r13 = r12.panEnabled;
        if (r13 == 0) goto L_0x0136;
    L_0x00b0:
        r13 = r12.vCenterStart;
        r13 = r13.y;
        r3 = r12.vTranslateStart;
        r3 = r3.y;
        r13 = r13 - r3;
        r3 = r12.scale;
        r8 = r12.scaleStart;
        r3 = r3 / r8;
        r13 = r13 * r3;
        r3 = r12.vTranslate;
        r8 = r12.vCenterStart;
        r8 = r8.x;
        r9 = r12.vTranslateStart;
        r9 = r9.x;
        r8 = r8 - r9;
        r9 = r12.scale;
        r10 = r12.scaleStart;
        r9 = r9 / r10;
        r8 = r8 * r9;
        r8 = r6 - r8;
        r3.x = r8;
        r3 = r12.vTranslate;
        r13 = r7 - r13;
        r3.y = r13;
        r13 = r12.sHeight();
        r8 = (double) r13;
        r8 = r8 * r1;
        r13 = r12.getHeight();
        r10 = (double) r13;
        r13 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1));
        if (r13 >= 0) goto L_0x00fe;
    L_0x00ec:
        r13 = r12.scale;
        r3 = r12.sHeight();
        r3 = (float) r3;
        r13 = r13 * r3;
        r3 = r12.getHeight();
        r3 = (float) r3;
        r13 = (r13 > r3 ? 1 : (r13 == r3 ? 0 : -1));
        if (r13 >= 0) goto L_0x0120;
    L_0x00fe:
        r13 = r12.sWidth();
        r8 = (double) r13;
        r8 = r8 * r1;
        r13 = r12.getWidth();
        r1 = (double) r13;
        r13 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1));
        if (r13 >= 0) goto L_0x018b;
    L_0x010e:
        r13 = r12.scale;
        r1 = r12.sWidth();
        r1 = (float) r1;
        r13 = r13 * r1;
        r1 = r12.getWidth();
        r1 = (float) r1;
        r13 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1));
        if (r13 < 0) goto L_0x018b;
    L_0x0120:
        r12.fitToBounds(r5);
        r13 = r12.vCenterStart;
        r13.set(r6, r7);
        r13 = r12.vTranslateStart;
        r1 = r12.vTranslate;
        r13.set(r1);
        r13 = r12.scale;
        r12.scaleStart = r13;
        r12.vDistStart = r0;
        goto L_0x018b;
    L_0x0136:
        r13 = r12.sRequestedCenter;
        if (r13 == 0) goto L_0x0161;
    L_0x013a:
        r13 = r12.vTranslate;
        r0 = r12.getWidth();
        r0 = r0 / r3;
        r0 = (float) r0;
        r1 = r12.scale;
        r2 = r12.sRequestedCenter;
        r2 = r2.x;
        r1 = r1 * r2;
        r0 = r0 - r1;
        r13.x = r0;
        r13 = r12.vTranslate;
        r0 = r12.getHeight();
        r0 = r0 / r3;
        r0 = (float) r0;
        r1 = r12.scale;
        r2 = r12.sRequestedCenter;
        r2 = r2.y;
        r1 = r1 * r2;
        r0 = r0 - r1;
        r13.y = r0;
        goto L_0x018b;
    L_0x0161:
        r13 = r12.vTranslate;
        r0 = r12.getWidth();
        r0 = r0 / r3;
        r0 = (float) r0;
        r1 = r12.scale;
        r2 = r12.sWidth();
        r2 = r2 / r3;
        r2 = (float) r2;
        r1 = r1 * r2;
        r0 = r0 - r1;
        r13.x = r0;
        r13 = r12.vTranslate;
        r0 = r12.getHeight();
        r0 = r0 / r3;
        r0 = (float) r0;
        r1 = r12.scale;
        r2 = r12.sHeight();
        r2 = r2 / r3;
        r2 = (float) r2;
        r1 = r1 * r2;
        r0 = r0 - r1;
        r13.y = r0;
    L_0x018b:
        r12.fitToBounds(r5);
        r13 = r12.eagerLoadingEnabled;
        r12.refreshRequiredTiles(r13);
        goto L_0x0301;
    L_0x0195:
        r0 = r12.isQuickScaling;
        if (r0 == 0) goto L_0x0304;
    L_0x0199:
        r0 = r12.quickScaleVStart;
        r0 = r0.y;
        r1 = r13.getY();
        r0 = r0 - r1;
        r0 = java.lang.Math.abs(r0);
        r0 = r0 * r2;
        r1 = r12.quickScaleThreshold;
        r0 = r0 + r1;
        r1 = r12.quickScaleLastDistance;
        r2 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r1 != 0) goto L_0x01b5;
    L_0x01b3:
        r12.quickScaleLastDistance = r0;
    L_0x01b5:
        r1 = r13.getY();
        r2 = r12.quickScaleVLastPoint;
        r2 = r2.y;
        r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r1 <= 0) goto L_0x01c3;
    L_0x01c1:
        r1 = 1;
        goto L_0x01c4;
    L_0x01c3:
        r1 = 0;
    L_0x01c4:
        r2 = r12.quickScaleVLastPoint;
        r13 = r13.getY();
        r6 = 0;
        r2.set(r6, r13);
        r13 = r12.quickScaleLastDistance;
        r13 = r0 / r13;
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r13 = r2 - r13;
        r13 = java.lang.Math.abs(r13);
        r7 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r13 = r13 * r7;
        r7 = 1022739087; // 0x3cf5c28f float:0.03 double:5.053002475E-315;
        r7 = (r13 > r7 ? 1 : (r13 == r7 ? 0 : -1));
        if (r7 > 0) goto L_0x01e9;
    L_0x01e5:
        r7 = r12.quickScaleMoved;
        if (r7 == 0) goto L_0x02f7;
    L_0x01e9:
        r12.quickScaleMoved = r5;
        r7 = r12.quickScaleLastDistance;
        r7 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
        if (r7 <= 0) goto L_0x01f6;
    L_0x01f1:
        if (r1 == 0) goto L_0x01f5;
    L_0x01f3:
        r2 = r2 + r13;
        goto L_0x01f6;
    L_0x01f5:
        r2 = r2 - r13;
    L_0x01f6:
        r13 = r12.scale;
        r7 = (double) r13;
        r13 = r12.minScale();
        r1 = r12.maxScale;
        r9 = r12.scale;
        r9 = r9 * r2;
        r1 = java.lang.Math.min(r1, r9);
        r13 = java.lang.Math.max(r13, r1);
        r12.scale = r13;
        r13 = r12.panEnabled;
        if (r13 == 0) goto L_0x02a2;
    L_0x0211:
        r13 = r12.vCenterStart;
        r13 = r13.y;
        r1 = r12.vTranslateStart;
        r1 = r1.y;
        r13 = r13 - r1;
        r1 = r12.scale;
        r2 = r12.scaleStart;
        r1 = r1 / r2;
        r13 = r13 * r1;
        r1 = r12.vTranslate;
        r2 = r12.vCenterStart;
        r2 = r2.x;
        r3 = r12.vCenterStart;
        r3 = r3.x;
        r9 = r12.vTranslateStart;
        r9 = r9.x;
        r3 = r3 - r9;
        r9 = r12.scale;
        r10 = r12.scaleStart;
        r9 = r9 / r10;
        r3 = r3 * r9;
        r2 = r2 - r3;
        r1.x = r2;
        r1 = r12.vTranslate;
        r2 = r12.vCenterStart;
        r2 = r2.y;
        r2 = r2 - r13;
        r1.y = r2;
        r13 = r12.sHeight();
        r1 = (double) r13;
        r1 = r1 * r7;
        r13 = r12.getHeight();
        r9 = (double) r13;
        r13 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1));
        if (r13 >= 0) goto L_0x0265;
    L_0x0253:
        r13 = r12.scale;
        r1 = r12.sHeight();
        r1 = (float) r1;
        r13 = r13 * r1;
        r1 = r12.getHeight();
        r1 = (float) r1;
        r13 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1));
        if (r13 >= 0) goto L_0x0287;
    L_0x0265:
        r13 = r12.sWidth();
        r1 = (double) r13;
        r1 = r1 * r7;
        r13 = r12.getWidth();
        r7 = (double) r13;
        r13 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1));
        if (r13 >= 0) goto L_0x02f7;
    L_0x0275:
        r13 = r12.scale;
        r1 = r12.sWidth();
        r1 = (float) r1;
        r13 = r13 * r1;
        r1 = r12.getWidth();
        r1 = (float) r1;
        r13 = (r13 > r1 ? 1 : (r13 == r1 ? 0 : -1));
        if (r13 < 0) goto L_0x02f7;
    L_0x0287:
        r12.fitToBounds(r5);
        r13 = r12.vCenterStart;
        r0 = r12.quickScaleSCenter;
        r0 = r12.sourceToViewCoord(r0);
        r13.set(r0);
        r13 = r12.vTranslateStart;
        r0 = r12.vTranslate;
        r13.set(r0);
        r13 = r12.scale;
        r12.scaleStart = r13;
        r0 = 0;
        goto L_0x02f7;
    L_0x02a2:
        r13 = r12.sRequestedCenter;
        if (r13 == 0) goto L_0x02cd;
    L_0x02a6:
        r13 = r12.vTranslate;
        r1 = r12.getWidth();
        r1 = r1 / r3;
        r1 = (float) r1;
        r2 = r12.scale;
        r6 = r12.sRequestedCenter;
        r6 = r6.x;
        r2 = r2 * r6;
        r1 = r1 - r2;
        r13.x = r1;
        r13 = r12.vTranslate;
        r1 = r12.getHeight();
        r1 = r1 / r3;
        r1 = (float) r1;
        r2 = r12.scale;
        r3 = r12.sRequestedCenter;
        r3 = r3.y;
        r2 = r2 * r3;
        r1 = r1 - r2;
        r13.y = r1;
        goto L_0x02f7;
    L_0x02cd:
        r13 = r12.vTranslate;
        r1 = r12.getWidth();
        r1 = r1 / r3;
        r1 = (float) r1;
        r2 = r12.scale;
        r6 = r12.sWidth();
        r6 = r6 / r3;
        r6 = (float) r6;
        r2 = r2 * r6;
        r1 = r1 - r2;
        r13.x = r1;
        r13 = r12.vTranslate;
        r1 = r12.getHeight();
        r1 = r1 / r3;
        r1 = (float) r1;
        r2 = r12.scale;
        r6 = r12.sHeight();
        r6 = r6 / r3;
        r3 = (float) r6;
        r2 = r2 * r3;
        r1 = r1 - r2;
        r13.y = r1;
    L_0x02f7:
        r12.quickScaleLastDistance = r0;
        r12.fitToBounds(r5);
        r13 = r12.eagerLoadingEnabled;
        r12.refreshRequiredTiles(r13);
    L_0x0301:
        r13 = 1;
        goto L_0x03e4;
    L_0x0304:
        r0 = r12.isZooming;
        if (r0 != 0) goto L_0x03e3;
    L_0x0308:
        r0 = r13.getX();
        r2 = r12.vCenterStart;
        r2 = r2.x;
        r0 = r0 - r2;
        r0 = java.lang.Math.abs(r0);
        r2 = r13.getY();
        r3 = r12.vCenterStart;
        r3 = r3.y;
        r2 = r2 - r3;
        r2 = java.lang.Math.abs(r2);
        r3 = r12.density;
        r3 = r3 * r1;
        r1 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1));
        if (r1 > 0) goto L_0x0332;
    L_0x032a:
        r6 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1));
        if (r6 > 0) goto L_0x0332;
    L_0x032e:
        r6 = r12.isPanning;
        if (r6 == 0) goto L_0x03e3;
    L_0x0332:
        r6 = r12.vTranslate;
        r7 = r12.vTranslateStart;
        r7 = r7.x;
        r8 = r13.getX();
        r9 = r12.vCenterStart;
        r9 = r9.x;
        r8 = r8 - r9;
        r7 = r7 + r8;
        r6.x = r7;
        r6 = r12.vTranslate;
        r7 = r12.vTranslateStart;
        r7 = r7.y;
        r13 = r13.getY();
        r8 = r12.vCenterStart;
        r8 = r8.y;
        r13 = r13 - r8;
        r7 = r7 + r13;
        r6.y = r7;
        r13 = r12.vTranslate;
        r13 = r13.x;
        r6 = r12.vTranslate;
        r6 = r6.y;
        r12.fitToBounds(r5);
        r7 = r12.vTranslate;
        r7 = r7.x;
        r13 = (r13 > r7 ? 1 : (r13 == r7 ? 0 : -1));
        if (r13 == 0) goto L_0x036b;
    L_0x0369:
        r13 = 1;
        goto L_0x036c;
    L_0x036b:
        r13 = 0;
    L_0x036c:
        r7 = r12.vTranslate;
        r7 = r7.y;
        r7 = (r6 > r7 ? 1 : (r6 == r7 ? 0 : -1));
        if (r7 == 0) goto L_0x0376;
    L_0x0374:
        r7 = 1;
        goto L_0x0377;
    L_0x0376:
        r7 = 0;
    L_0x0377:
        if (r13 == 0) goto L_0x0383;
    L_0x0379:
        r8 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r8 <= 0) goto L_0x0383;
    L_0x037d:
        r8 = r12.isPanning;
        if (r8 != 0) goto L_0x0383;
    L_0x0381:
        r8 = 1;
        goto L_0x0384;
    L_0x0383:
        r8 = 0;
    L_0x0384:
        if (r7 == 0) goto L_0x0390;
    L_0x0386:
        r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1));
        if (r0 <= 0) goto L_0x0390;
    L_0x038a:
        r0 = r12.isPanning;
        if (r0 != 0) goto L_0x0390;
    L_0x038e:
        r0 = 1;
        goto L_0x0391;
    L_0x0390:
        r0 = 0;
    L_0x0391:
        r9 = r12.vTranslate;
        r9 = r9.y;
        r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1));
        if (r6 != 0) goto L_0x03a3;
    L_0x0399:
        r6 = 1077936128; // 0x40400000 float:3.0 double:5.325712093E-315;
        r6 = r6 * r3;
        r6 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r6 <= 0) goto L_0x03a3;
    L_0x03a1:
        r6 = 1;
        goto L_0x03a4;
    L_0x03a3:
        r6 = 0;
    L_0x03a4:
        if (r8 != 0) goto L_0x03b5;
    L_0x03a6:
        if (r0 != 0) goto L_0x03b5;
    L_0x03a8:
        if (r13 == 0) goto L_0x03b2;
    L_0x03aa:
        if (r7 == 0) goto L_0x03b2;
    L_0x03ac:
        if (r6 != 0) goto L_0x03b2;
    L_0x03ae:
        r13 = r12.isPanning;
        if (r13 == 0) goto L_0x03b5;
    L_0x03b2:
        r12.isPanning = r5;
        goto L_0x03c5;
    L_0x03b5:
        if (r1 > 0) goto L_0x03bb;
    L_0x03b7:
        r13 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1));
        if (r13 <= 0) goto L_0x03c5;
    L_0x03bb:
        r12.maxTouchCount = r4;
        r13 = r12.handler;
        r13.removeMessages(r5);
        r12.requestDisallowInterceptTouchEvent(r4);
    L_0x03c5:
        r13 = r12.panEnabled;
        if (r13 != 0) goto L_0x03dc;
    L_0x03c9:
        r13 = r12.vTranslate;
        r0 = r12.vTranslateStart;
        r0 = r0.x;
        r13.x = r0;
        r13 = r12.vTranslate;
        r0 = r12.vTranslateStart;
        r0 = r0.y;
        r13.y = r0;
        r12.requestDisallowInterceptTouchEvent(r4);
    L_0x03dc:
        r13 = r12.eagerLoadingEnabled;
        r12.refreshRequiredTiles(r13);
        goto L_0x0301;
    L_0x03e3:
        r13 = 0;
    L_0x03e4:
        if (r13 == 0) goto L_0x03ef;
    L_0x03e6:
        r13 = r12.handler;
        r13.removeMessages(r5);
        r12.invalidate();
        return r5;
    L_0x03ef:
        return r4;
    L_0x03f0:
        r1 = r12.handler;
        r1.removeMessages(r5);
        r1 = r12.isQuickScaling;
        if (r1 == 0) goto L_0x0406;
    L_0x03f9:
        r12.isQuickScaling = r4;
        r1 = r12.quickScaleMoved;
        if (r1 != 0) goto L_0x0406;
    L_0x03ff:
        r1 = r12.quickScaleSCenter;
        r2 = r12.vCenterStart;
        r12.doubleTapZoom(r1, r2);
    L_0x0406:
        r1 = r12.maxTouchCount;
        if (r1 <= 0) goto L_0x0458;
    L_0x040a:
        r1 = r12.isZooming;
        if (r1 != 0) goto L_0x0413;
    L_0x040e:
        r1 = r12.isPanning;
        if (r1 != 0) goto L_0x0413;
    L_0x0412:
        goto L_0x0458;
    L_0x0413:
        r1 = r12.isZooming;
        if (r1 == 0) goto L_0x0449;
    L_0x0417:
        if (r0 != r3) goto L_0x0449;
    L_0x0419:
        r12.isPanning = r5;
        r1 = r12.vTranslateStart;
        r2 = r12.vTranslate;
        r2 = r2.x;
        r6 = r12.vTranslate;
        r6 = r6.y;
        r1.set(r2, r6);
        r1 = r13.getActionIndex();
        if (r1 != r5) goto L_0x043c;
    L_0x042e:
        r1 = r12.vCenterStart;
        r2 = r13.getX(r4);
        r13 = r13.getY(r4);
        r1.set(r2, r13);
        goto L_0x0449;
    L_0x043c:
        r1 = r12.vCenterStart;
        r2 = r13.getX(r5);
        r13 = r13.getY(r5);
        r1.set(r2, r13);
    L_0x0449:
        r13 = 3;
        if (r0 >= r13) goto L_0x044e;
    L_0x044c:
        r12.isZooming = r4;
    L_0x044e:
        if (r0 >= r3) goto L_0x0454;
    L_0x0450:
        r12.isPanning = r4;
        r12.maxTouchCount = r4;
    L_0x0454:
        r12.refreshRequiredTiles(r5);
        return r5;
    L_0x0458:
        if (r0 != r5) goto L_0x0460;
    L_0x045a:
        r12.isZooming = r4;
        r12.isPanning = r4;
        r12.maxTouchCount = r4;
    L_0x0460:
        return r5;
    L_0x0461:
        r1 = 0;
        r12.anim = r1;
        r12.requestDisallowInterceptTouchEvent(r5);
        r1 = r12.maxTouchCount;
        r1 = java.lang.Math.max(r1, r0);
        r12.maxTouchCount = r1;
        if (r0 < r3) goto L_0x04be;
    L_0x0471:
        r0 = r12.zoomEnabled;
        if (r0 == 0) goto L_0x04b6;
    L_0x0475:
        r0 = r13.getX(r4);
        r1 = r13.getX(r5);
        r3 = r13.getY(r4);
        r6 = r13.getY(r5);
        r0 = r12.distance(r0, r1, r3, r6);
        r1 = r12.scale;
        r12.scaleStart = r1;
        r12.vDistStart = r0;
        r0 = r12.vTranslateStart;
        r1 = r12.vTranslate;
        r1 = r1.x;
        r3 = r12.vTranslate;
        r3 = r3.y;
        r0.set(r1, r3);
        r0 = r12.vCenterStart;
        r1 = r13.getX(r4);
        r3 = r13.getX(r5);
        r1 = r1 + r3;
        r1 = r1 / r2;
        r3 = r13.getY(r4);
        r13 = r13.getY(r5);
        r3 = r3 + r13;
        r3 = r3 / r2;
        r0.set(r1, r3);
        goto L_0x04b8;
    L_0x04b6:
        r12.maxTouchCount = r4;
    L_0x04b8:
        r13 = r12.handler;
        r13.removeMessages(r5);
        goto L_0x04e3;
    L_0x04be:
        r0 = r12.isQuickScaling;
        if (r0 != 0) goto L_0x04e3;
    L_0x04c2:
        r0 = r12.vTranslateStart;
        r1 = r12.vTranslate;
        r1 = r1.x;
        r2 = r12.vTranslate;
        r2 = r2.y;
        r0.set(r1, r2);
        r0 = r12.vCenterStart;
        r1 = r13.getX();
        r13 = r13.getY();
        r0.set(r1, r13);
        r13 = r12.handler;
        r0 = 600; // 0x258 float:8.41E-43 double:2.964E-321;
        r13.sendEmptyMessageDelayed(r5, r0);
    L_0x04e3:
        return r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: fcom.collage.imagevideo.scal.SubSamplingScaleImageView.onTouchEventInternal(android.view.MotionEvent):boolean");
    }

    private void requestDisallowInterceptTouchEvent(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    private void doubleTapZoom(PointF pointF, PointF pointF2) {
        if (!this.panEnabled) {
            PointF pointF3 = this.sRequestedCenter;
            if (pointF3 != null) {
                pointF.x = pointF3.x;
                pointF.y = this.sRequestedCenter.y;
            } else {
                pointF.x = (float) (sWidth() / 2);
                pointF.y = (float) (sHeight() / 2);
            }
        }
        float min = Math.min(this.maxScale, this.doubleTapZoomScale);
        float f = this.scale;
        Object obj = (((double) f) <= ((double) min) * 0.9d || f == this.minScale) ? 1 : null;
        if (obj == null) {
            min = minScale();
        }
        float f2 = min;
        int i = this.doubleTapZoomStyle;
        if (i == 3) {
            setScaleAndCenter(f2, pointF);
        } else if (i == 2 || obj == null || !this.panEnabled) {
            new AnimationBuilder(this, this, f2, pointF, null, null).withInterruptible(false).withDuration((long) this.doubleTapZoomDuration).withOrigin(4).start();
        } else if (i == 1) {
            new AnimationBuilder(this, this, f2, pointF, pointF2, null).withInterruptible(false).withDuration((long) this.doubleTapZoomDuration).withOrigin(4).start();
        }
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        Canvas canvas2 = canvas;
        super.onDraw(canvas);
        createPaints();
        if (this.sWidth != 0 && this.sHeight != 0 && getWidth() != 0 && getHeight() != 0) {
            if (this.tileMap == null && this.decoder != null) {
                initialiseBaseLayer(getMaxBitmapDimensions(canvas));
            }
            if (checkReady()) {
                float f;
                float ease;
                int i;
                int i2;
                preDraw();
                Anim anim = this.anim;
                if (!(anim == null || anim.vFocusStart == null)) {
                    f = this.scale;
                    if (this.vTranslateBefore == null) {
                        this.vTranslateBefore = new PointF(0.0f, 0.0f);
                    }
                    this.vTranslateBefore.set(this.vTranslate);
                    long currentTimeMillis = System.currentTimeMillis() - this.anim.time;
                    boolean z = currentTimeMillis > this.anim.duration;
                    long min = Math.min(currentTimeMillis, this.anim.duration);
                    this.scale = ease(this.anim.easing, min, this.anim.scaleStart, this.anim.scaleEnd - this.anim.scaleStart, this.anim.duration);
                    float ease2 = ease(this.anim.easing, min, this.anim.vFocusStart.x, this.anim.vFocusEnd.x - this.anim.vFocusStart.x, this.anim.duration);
                    ease = ease(this.anim.easing, min, this.anim.vFocusStart.y, this.anim.vFocusEnd.y - this.anim.vFocusStart.y, this.anim.duration);
                    PointF pointF = this.vTranslate;
                    pointF.x -= sourceToViewX(this.anim.sCenterEnd.x) - ease2;
                    pointF = this.vTranslate;
                    pointF.y -= sourceToViewY(this.anim.sCenterEnd.y) - ease;
                    boolean z2 = z || this.anim.scaleStart == this.anim.scaleEnd;
                    fitToBounds(z2);
                    sendStateChanged(f, this.vTranslateBefore, this.anim.origin);
                    refreshRequiredTiles(z);
                    if (z) {
                        if (this.anim.listener != null) {
                            try {
                                this.anim.listener.onComplete();
                            } catch (Exception e) {
                                Log.w(TAG, "Error thrown by animation listener", e);
                            }
                        }
                        this.anim = null;
                    }
                    invalidate();
                }
                if (this.tileMap == null || !isBaseLayerReady()) {
                    i = 35;
                    i2 = 15;
                    Bitmap bitmap = this.bitmap;
                    if (bitmap != null) {
                        ease = this.scale;
                        if (this.bitmapIsPreview) {
                            ease *= ((float) this.sWidth) / ((float) bitmap.getWidth());
                            f = this.scale * (((float) this.sHeight) / ((float) this.bitmap.getHeight()));
                        } else {
                            f = ease;
                        }
                        if (this.matrix == null) {
                            this.matrix = new Matrix();
                        }
                        this.matrix.reset();
                        this.matrix.postScale(ease, f);
                        this.matrix.postRotate((float) getRequiredRotation());
                        this.matrix.postTranslate(this.vTranslate.x, this.vTranslate.y);
                        if (getRequiredRotation() == ORIENTATION_180) {
                            Matrix matrix = this.matrix;
                            ease = this.scale;
                            matrix.postTranslate(((float) this.sWidth) * ease, ease * ((float) this.sHeight));
                        } else if (getRequiredRotation() == 90) {
                            this.matrix.postTranslate(this.scale * ((float) this.sHeight), 0.0f);
                        } else if (getRequiredRotation() == ORIENTATION_270) {
                            this.matrix.postTranslate(0.0f, this.scale * ((float) this.sWidth));
                        }
                        if (this.tileBgPaint != null) {
                            if (this.sRect == null) {
                                this.sRect = new RectF();
                            }
                            this.sRect.set(0.0f, 0.0f, (float) (this.bitmapIsPreview ? this.bitmap.getWidth() : this.sWidth), (float) (this.bitmapIsPreview ? this.bitmap.getHeight() : this.sHeight));
                            this.matrix.mapRect(this.sRect);
                            canvas2.drawRect(this.sRect, this.tileBgPaint);
                        }
                        canvas2.drawBitmap(this.bitmap, this.matrix, this.bitmapPaint);
                    }
                } else {
                    int min2 = Math.min(this.fullImageSampleSize, calculateInSampleSize(this.scale));
                    Object obj = null;
                    for (Entry entry : this.tileMap.entrySet()) {
                        if (((Integer) entry.getKey()).intValue() == min2) {
                            /*for (Tile tile : (List) entry.getValue()) {
                                if (tile.visible && (tile.loading || tile.bitmap == null)) {
                                    obj = 1;
                                }
                            }*/
                        }
                    }
                    for (Entry entry2 : this.tileMap.entrySet()) {
                        if (((Integer) entry2.getKey()).intValue() == min2 || obj != null) {
                            /*for (Tile tile2 : (List) entry2.getValue()) {
                                sourceToViewRect(tile2.sRect, tile2.vRect);
                                if (!tile2.loading && tile2.bitmap != null) {
                                    if (this.tileBgPaint != null) {
                                        canvas2.drawRect(tile2.vRect, this.tileBgPaint);
                                    }
                                    if (this.matrix == null) {
                                        this.matrix = new Matrix();
                                    }
                                    this.matrix.reset();
                                    setMatrixArray(this.srcArray, 0.0f, 0.0f, (float) tile2.bitmap.getWidth(), 0.0f, (float) tile2.bitmap.getWidth(), (float) tile2.bitmap.getHeight(), 0.0f, (float) tile2.bitmap.getHeight());
                                    if (getRequiredRotation() == 0) {
                                        setMatrixArray(this.dstArray, (float) tile2.vRect.left, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.bottom);
                                    } else if (getRequiredRotation() == 90) {
                                        setMatrixArray(this.dstArray, (float) tile2.vRect.right, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.top);
                                    } else if (getRequiredRotation() == ORIENTATION_180) {
                                        setMatrixArray(this.dstArray, (float) tile2.vRect.right, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.top);
                                    } else if (getRequiredRotation() == ORIENTATION_270) {
                                        setMatrixArray(this.dstArray, (float) tile2.vRect.left, (float) tile2.vRect.bottom, (float) tile2.vRect.left, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.top, (float) tile2.vRect.right, (float) tile2.vRect.bottom);
                                    }
                                    this.matrix.setPolyToPoly(this.srcArray, 0, this.dstArray, 0, 4);
                                    canvas2.drawBitmap(tile2.bitmap, this.matrix, this.bitmapPaint);
                                    if (this.debug) {
                                        canvas2.drawRect(tile2.vRect, this.debugLinePaint);
                                    }
                                } else if (tile2.loading && this.debug) {
                                    canvas2.drawText("LOADING", (float) (tile2.vRect.left + px(5)), (float) (tile2.vRect.top + px(35)), this.debugTextPaint);
                                    if (!tile2.visible && this.debug) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("ISS ");
                                        stringBuilder.append(tile2.sampleSize);
                                        stringBuilder.append(" RECT ");
                                        stringBuilder.append(tile2.sRect.top);
                                        String str = ",";
                                        stringBuilder.append(str);
                                        stringBuilder.append(tile2.sRect.left);
                                        stringBuilder.append(str);
                                        stringBuilder.append(tile2.sRect.bottom);
                                        stringBuilder.append(str);
                                        stringBuilder.append(tile2.sRect.right);
                                        canvas2.drawText(stringBuilder.toString(), (float) (tile2.vRect.left + px(5)), (float) (tile2.vRect.top + px(15)), this.debugTextPaint);
                                    }
                                }
                                if (!tile2.visible) {
                                }
                            }*/
                        }
                    }
                    i = 35;
                    i2 = 15;
                }
                if (this.debug) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Scale: ");
                    String str2 = "%.2f";
                    stringBuilder2.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(this.scale)}));
                    stringBuilder2.append(" (");
                    stringBuilder2.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(minScale())}));
                    stringBuilder2.append(" - ");
                    stringBuilder2.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(this.maxScale)}));
                    stringBuilder2.append(")");
                    canvas2.drawText(stringBuilder2.toString(), (float) px(5), (float) px(i2), this.debugTextPaint);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Translate: ");
                    stringBuilder2.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(this.vTranslate.x)}));
                    String str3 = ":";
                    stringBuilder2.append(str3);
                    stringBuilder2.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(this.vTranslate.y)}));
                    canvas2.drawText(stringBuilder2.toString(), (float) px(5), (float) px(30), this.debugTextPaint);
                    PointF center = getCenter();
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("Source center: ");
                    stringBuilder3.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(center.x)}));
                    stringBuilder3.append(str3);
                    stringBuilder3.append(String.format(Locale.ENGLISH, str2, new Object[]{Float.valueOf(center.y)}));
                    canvas2.drawText(stringBuilder3.toString(), (float) px(5), (float) px(45), this.debugTextPaint);
                    anim = this.anim;
                    if (anim != null) {
                        center = sourceToViewCoord(anim.sCenterStart);
                        PointF sourceToViewCoord = sourceToViewCoord(this.anim.sCenterEndRequested);
                        PointF sourceToViewCoord2 = sourceToViewCoord(this.anim.sCenterEnd);
                        canvas2.drawCircle(center.x, center.y, (float) px(10), this.debugLinePaint);
                        this.debugLinePaint.setColor(SupportMenu.CATEGORY_MASK);
                        canvas2.drawCircle(sourceToViewCoord.x, sourceToViewCoord.y, (float) px(20), this.debugLinePaint);
                        this.debugLinePaint.setColor(-16776961);
                        canvas2.drawCircle(sourceToViewCoord2.x, sourceToViewCoord2.y, (float) px(25), this.debugLinePaint);
                        this.debugLinePaint.setColor(-16711681);
                        canvas2.drawCircle((float) (getWidth() / 2), (float) (getHeight() / 2), (float) px(30), this.debugLinePaint);
                    }
                    if (this.vCenterStart != null) {
                        this.debugLinePaint.setColor(SupportMenu.CATEGORY_MASK);
                        canvas2.drawCircle(this.vCenterStart.x, this.vCenterStart.y, (float) px(20), this.debugLinePaint);
                    }
                    if (this.quickScaleSCenter != null) {
                        this.debugLinePaint.setColor(-16776961);
                        canvas2.drawCircle(sourceToViewX(this.quickScaleSCenter.x), sourceToViewY(this.quickScaleSCenter.y), (float) px(i), this.debugLinePaint);
                    }
                    if (this.quickScaleVStart != null && this.isQuickScaling) {
                        this.debugLinePaint.setColor(-16711681);
                        canvas2.drawCircle(this.quickScaleVStart.x, this.quickScaleVStart.y, (float) px(30), this.debugLinePaint);
                    }
                    this.debugLinePaint.setColor(-65281);
                }
            }
        }
    }

    private void setMatrixArray(float[] fArr, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        fArr[0] = f;
        fArr[1] = f2;
        fArr[2] = f3;
        fArr[3] = f4;
        fArr[4] = f5;
        fArr[5] = f6;
        fArr[6] = f7;
        fArr[7] = f8;
    }

    private boolean isBaseLayerReady() {
        boolean z = true;
        if (this.bitmap != null && !this.bitmapIsPreview) {
            return true;
        }
        Map map = this.tileMap;
        if (map == null) {
            return false;
        }
       /* for (Entry entry : map.entrySet()) {
            if (((Integer) entry.getKey()).intValue() == this.fullImageSampleSize) {
                for (Tile tile : (List) entry.getValue()) {
                    if (tile.loading || tile.bitmap == null) {
                        z = false;
                    }
                }
            }
        }*/
        return z;
    }

    private boolean checkReady() {
        boolean z = getWidth() > 0 && getHeight() > 0 && this.sWidth > 0 && this.sHeight > 0 && (this.bitmap != null || isBaseLayerReady());
        if (!this.readySent && z) {
            preDraw();
            this.readySent = true;
            onReady();
            OnImageEventListener onImageEventListener = this.onImageEventListener;
            if (onImageEventListener != null) {
                onImageEventListener.onReady();
            }
        }
        return z;
    }

    private boolean checkImageLoaded() {
        boolean isBaseLayerReady = isBaseLayerReady();
        if (!this.imageLoadedSent && isBaseLayerReady) {
            preDraw();
            this.imageLoadedSent = true;
            onImageLoaded();
            OnImageEventListener onImageEventListener = this.onImageEventListener;
            if (onImageEventListener != null) {
                onImageEventListener.onImageLoaded();
            }
        }
        return isBaseLayerReady;
    }

    private void createPaints() {
        Paint paint;
        if (this.bitmapPaint == null) {
            paint = new Paint();
            this.bitmapPaint = paint;
            paint.setAntiAlias(true);
            this.bitmapPaint.setFilterBitmap(true);
            this.bitmapPaint.setDither(true);
        }
        if ((this.debugTextPaint == null || this.debugLinePaint == null) && this.debug) {
            paint = new Paint();
            this.debugTextPaint = paint;
            paint.setTextSize((float) px(12));
            this.debugTextPaint.setColor(-65281);
            this.debugTextPaint.setStyle(Style.FILL);
            paint = new Paint();
            this.debugLinePaint = paint;
            paint.setColor(-65281);
            this.debugLinePaint.setStyle(Style.STROKE);
            this.debugLinePaint.setStrokeWidth((float) px(1));
        }
    }

    private synchronized void initialiseBaseLayer(Point point) {
        debug("initialiseBaseLayer maxTileDimensions=%dx%d", Integer.valueOf(point.x), Integer.valueOf(point.y));
        ScaleAndTranslate scaleAndTranslate = new ScaleAndTranslate(0.0f, new PointF(0.0f, 0.0f), null);
        this.satTemp = scaleAndTranslate;
        fitToBounds(true, scaleAndTranslate);
        int calculateInSampleSize = calculateInSampleSize(this.satTemp.scale);
        this.fullImageSampleSize = calculateInSampleSize;
        if (calculateInSampleSize > 1) {
            this.fullImageSampleSize = calculateInSampleSize / 2;
        }
        if (this.fullImageSampleSize == 1 && this.sRegion == null && sWidth() < point.x) {
            if (sHeight() < point.y) {
                this.decoder.recycle();
                this.decoder = null;
                execute(new BitmapLoadTask(this, getContext(), this.bitmapDecoderFactory, this.uri, false));
            }
        }
        initialiseTileMap(point);
      /*  for (Tile tileLoadTask : (List) this.tileMap.get(Integer.valueOf(this.fullImageSampleSize))) {
            execute(new TileLoadTask(this, this.decoder, tileLoadTask));
        }*/
        refreshRequiredTiles(true);
    }

    private void refreshRequiredTiles(boolean z) {
        if (this.decoder != null && this.tileMap != null) {
            int min = Math.min(this.fullImageSampleSize, calculateInSampleSize(this.scale));
            for (Entry value : this.tileMap.entrySet()) {
                /*for (Tile tile : (List) value.getValue()) {
                    if (tile.sampleSize < min || (tile.sampleSize > min && tile.sampleSize != this.fullImageSampleSize)) {
                        tile.visible = false;
                        if (tile.bitmap != null) {
                            tile.bitmap.recycle();
                            tile.bitmap = null;
                        }
                    }
                    if (tile.sampleSize == min) {
                        if (tileVisible(tile)) {
                            tile.visible = true;
                            if (!tile.loading && tile.bitmap == null && z) {
                                execute(new TileLoadTask(this, this.decoder, tile));
                            }
                        } else if (tile.sampleSize != this.fullImageSampleSize) {
                            tile.visible = false;
                            if (tile.bitmap != null) {
                                tile.bitmap.recycle();
                                tile.bitmap = null;
                            }
                        }
                    } else if (tile.sampleSize == this.fullImageSampleSize) {
                        tile.visible = true;
                    }
                }*/
            }
        }
    }

    private boolean tileVisible(Tile tile) {
        return viewToSourceX(0.0f) <= ((float) tile.sRect.right) && ((float) tile.sRect.left) <= viewToSourceX((float) getWidth()) && viewToSourceY(0.0f) <= ((float) tile.sRect.bottom) && ((float) tile.sRect.top) <= viewToSourceY((float) getHeight());
    }

    private void preDraw() {
        if (getWidth() != 0 && getHeight() != 0 && this.sWidth > 0 && this.sHeight > 0) {
            if (this.sPendingCenter != null) {
                Float f = this.pendingScale;
                if (f != null) {
                    this.scale = f.floatValue();
                    if (this.vTranslate == null) {
                        this.vTranslate = new PointF();
                    }
                    this.vTranslate.x = ((float) (getWidth() / 2)) - (this.scale * this.sPendingCenter.x);
                    this.vTranslate.y = ((float) (getHeight() / 2)) - (this.scale * this.sPendingCenter.y);
                    this.sPendingCenter = null;
                    this.pendingScale = null;
                    fitToBounds(true);
                    refreshRequiredTiles(true);
                }
            }
            fitToBounds(false);
        }
    }

    private int calculateInSampleSize(float f) {
        if (this.minimumTileDpi > 0) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            f *= ((float) this.minimumTileDpi) / ((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0f);
        }
        int sWidth = (int) (((float) sWidth()) * f);
        int sHeight = (int) (((float) sHeight()) * f);
        if (sWidth == 0 || sHeight == 0) {
            return 32;
        }
        int i = 1;
        if (sHeight() > sHeight || sWidth() > sWidth) {
            sHeight = Math.round(((float) sHeight()) / ((float) sHeight));
            sWidth = Math.round(((float) sWidth()) / ((float) sWidth));
            if (sHeight >= sWidth) {
                sHeight = sWidth;
            }
        } else {
            sHeight = 1;
        }
        while (true) {
            sWidth = i * 2;
            if (sWidth >= sHeight) {
                return i;
            }
            i = sWidth;
        }
    }

    private void fitToBounds(boolean z, ScaleAndTranslate scaleAndTranslate) {
        float max;
        int max2;
        float max3;
        if (this.panLimit == 2 && isReady()) {
            z = false;
        }
        PointF access$2100 = scaleAndTranslate.vTranslate;
        float limitedScale = limitedScale(scaleAndTranslate.scale);
        float sWidth = ((float) sWidth()) * limitedScale;
        float sHeight = ((float) sHeight()) * limitedScale;
        if (this.panLimit == 3 && isReady()) {
            access$2100.x = Math.max(access$2100.x, ((float) (getWidth() / 2)) - sWidth);
            access$2100.y = Math.max(access$2100.y, ((float) (getHeight() / 2)) - sHeight);
        } else if (z) {
            access$2100.x = Math.max(access$2100.x, ((float) getWidth()) - sWidth);
            access$2100.y = Math.max(access$2100.y, ((float) getHeight()) - sHeight);
        } else {
            access$2100.x = Math.max(access$2100.x, -sWidth);
            access$2100.y = Math.max(access$2100.y, -sHeight);
        }
        float f = 0.5f;
        float paddingLeft = (getPaddingLeft() > 0 || getPaddingRight() > 0) ? ((float) getPaddingLeft()) / ((float) (getPaddingLeft() + getPaddingRight())) : 0.5f;
        if (getPaddingTop() > 0 || getPaddingBottom() > 0) {
            f = ((float) getPaddingTop()) / ((float) (getPaddingTop() + getPaddingBottom()));
        }
        if (this.panLimit == 3 && isReady()) {
            max = (float) Math.max(0, getWidth() / 2);
            max2 = Math.max(0, getHeight() / 2);
        } else if (z) {
            max = Math.max(0.0f, (((float) getWidth()) - sWidth) * paddingLeft);
            max3 = Math.max(0.0f, (((float) getHeight()) - sHeight) * f);
            access$2100.x = Math.min(access$2100.x, max);
            access$2100.y = Math.min(access$2100.y, max3);
            scaleAndTranslate.scale = limitedScale;
        } else {
            max = (float) Math.max(0, getWidth());
            max2 = Math.max(0, getHeight());
        }
//        max3 = (float) max2;
        access$2100.x = Math.min(access$2100.x, max);
//        access$2100.y = Math.min(access$2100.y, max3);
        scaleAndTranslate.scale = limitedScale;
    }

    private void fitToBounds(boolean z) {
        Object obj;
        if (this.vTranslate == null) {
            obj = 1;
            this.vTranslate = new PointF(0.0f, 0.0f);
        } else {
            obj = null;
        }
        if (this.satTemp == null) {
            this.satTemp = new ScaleAndTranslate(0.0f, new PointF(0.0f, 0.0f), null);
        }
        this.satTemp.scale = this.scale;
        this.satTemp.vTranslate.set(this.vTranslate);
        fitToBounds(z, this.satTemp);
        this.scale = this.satTemp.scale;
        this.vTranslate.set(this.satTemp.vTranslate);
        if (obj != null && this.minimumScaleType != 4) {
            this.vTranslate.set(vTranslateForSCenter((float) (sWidth() / 2), (float) (sHeight() / 2), this.scale));
        }
    }

    private void initialiseTileMap(Point point) {
        Point point2 = point;
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(point2.x);
        int i = 1;
        objArr[1] = Integer.valueOf(point2.y);
        debug("initialiseTileMap maxTileDimensions=%dx%d", objArr);
        this.tileMap = new LinkedHashMap();
        int i2 = this.fullImageSampleSize;
        int i3 = 1;
        int i4 = 1;
        while (true) {
            int i5;
            int sWidth = sWidth() / i3;
            int sHeight = sHeight() / i4;
            int i6 = sWidth / i2;
            int i7 = sHeight / i2;
            if ((i6 + i3) + i > point2.x || (((double) i6) > ((double) getWidth()) * 1.25d && i2 < this.fullImageSampleSize)) {
                i3++;
                sWidth = sWidth() / i3;
                i5 = sWidth / i2;
            }
            if ((i7 + i4) + 1 > point2.y || (((double) i7) > ((double) getHeight()) * 1.25d && i2 < this.fullImageSampleSize)) {
                i4++;
                sHeight = sHeight() / i4;
                i5 = sHeight / i2;
            }
            ArrayList arrayList = new ArrayList(i3 * i4);
            i = 0;
            while (i < i3) {
                i6 = 0;
                while (i6 < i4) {
                    Tile tile = new Tile();
                    tile.sampleSize = i2;
                    tile.visible = i2 == this.fullImageSampleSize;
                    tile.sRect = new Rect(i * sWidth, i6 * sHeight, i == i3 + -1 ? sWidth() : (i + 1) * sWidth, i6 == i4 + -1 ? sHeight() : (i6 + 1) * sHeight);
                    tile.vRect = new Rect(0, 0, 0, 0);
                    tile.fileSRect = new Rect(tile.sRect);
                    arrayList.add(tile);
                    i6++;
                }
                i++;
            }
            this.tileMap.put(Integer.valueOf(i2), arrayList);
            if (i2 != 1) {
                i2 /= 2;
                i = 1;
            } else {
                return;
            }
        }
    }

    private synchronized void onTilesInited(ImageRegionDecoder imageRegionDecoder, int i, int i2, int i3) {
        debug("onTilesInited sWidth=%d, sHeight=%d, sOrientation=%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(this.orientation));
        if (this.sWidth > 0 && this.sHeight > 0 && !(this.sWidth == i && this.sHeight == i2)) {
            reset(false);
            if (this.bitmap != null) {
                if (!this.bitmapIsCached) {
                    this.bitmap.recycle();
                }
                this.bitmap = null;
                if (this.onImageEventListener != null && this.bitmapIsCached) {
                    this.onImageEventListener.onPreviewReleased();
                }
                this.bitmapIsPreview = false;
                this.bitmapIsCached = false;
            }
        }
        this.decoder = imageRegionDecoder;
        this.sWidth = i;
        this.sHeight = i2;
        this.sOrientation = i3;
        checkReady();
        if (!checkImageLoaded() && this.maxTileWidth > 0 && this.maxTileWidth != TILE_SIZE_AUTO && this.maxTileHeight > 0 && this.maxTileHeight != TILE_SIZE_AUTO && getWidth() > 0 && getHeight() > 0) {
            initialiseBaseLayer(new Point(this.maxTileWidth, this.maxTileHeight));
        }
        invalidate();
        requestLayout();
    }

    private synchronized void onTileLoaded() {
        debug("onTileLoaded", new Object[0]);
        checkReady();
        checkImageLoaded();
        if (isBaseLayerReady() && this.bitmap != null) {
            if (!this.bitmapIsCached) {
                this.bitmap.recycle();
            }
            this.bitmap = null;
            if (this.onImageEventListener != null && this.bitmapIsCached) {
                this.onImageEventListener.onPreviewReleased();
            }
            this.bitmapIsPreview = false;
            this.bitmapIsCached = false;
        }
        invalidate();
    }

    private synchronized void onPreviewLoaded(Bitmap bitmap) {
        debug("onPreviewLoaded", new Object[0]);
        if (this.bitmap == null) {
            if (!this.imageLoadedSent) {
                if (this.pRegion != null) {
                    this.bitmap = Bitmap.createBitmap(bitmap, this.pRegion.left, this.pRegion.top, this.pRegion.width(), this.pRegion.height());
                } else {
                    this.bitmap = bitmap;
                }
                this.bitmapIsPreview = true;
                if (checkReady()) {
                    invalidate();
                    requestLayout();
                }
            }
        }
        bitmap.recycle();
    }

    private synchronized void onImageLoaded(Bitmap bitmap, int i, boolean z) {
        debug("onImageLoaded", new Object[0]);
        if (this.sWidth > 0 && this.sHeight > 0 && !(this.sWidth == bitmap.getWidth() && this.sHeight == bitmap.getHeight())) {
            reset(false);
        }
        if (!(this.bitmap == null || this.bitmapIsCached)) {
            this.bitmap.recycle();
        }
        if (!(this.bitmap == null || !this.bitmapIsCached || this.onImageEventListener == null)) {
            this.onImageEventListener.onPreviewReleased();
        }
        this.bitmapIsPreview = false;
        this.bitmapIsCached = z;
        this.bitmap = bitmap;
        this.sWidth = bitmap.getWidth();
        this.sHeight = bitmap.getHeight();
        this.sOrientation = i;
        boolean checkReady = checkReady();
        boolean checkImageLoaded = checkImageLoaded();
        if (checkReady || checkImageLoaded) {
            invalidate();
            requestLayout();
        }
    }

    private int getExifOrientation(Context context, String str) {
        throw new UnsupportedOperationException("Method not decompiled: com.psma.videowatermark.scale.SubSamplingScaleImageView.getExifOrientation(android.content.Context, java.lang.String):int");
    }

    private void execute(AsyncTask<Void, Void, ?> asyncTask) {
        asyncTask.executeOnExecutor(this.executor, new Void[0]);
    }

    private void restoreState(ImageViewState imageViewState) {
        if (imageViewState != null && imageViewState.getCenter() != null && VALID_ORIENTATIONS.contains(Integer.valueOf(imageViewState.getOrientation()))) {
            this.orientation = imageViewState.getOrientation();
            this.pendingScale = Float.valueOf(imageViewState.getScale());
            this.sPendingCenter = imageViewState.getCenter();
            invalidate();
        }
    }

    public void setMaxTileSize(int i) {
        this.maxTileWidth = i;
        this.maxTileHeight = i;
    }

    public void setMaxTileSize(int i, int i2) {
        this.maxTileWidth = i;
        this.maxTileHeight = i2;
    }

    private Point getMaxBitmapDimensions(Canvas canvas) {
        return new Point(Math.min(canvas.getMaximumBitmapWidth(), this.maxTileWidth), Math.min(canvas.getMaximumBitmapHeight(), this.maxTileHeight));
    }

    private int sWidth() {
        int requiredRotation = getRequiredRotation();
        if (requiredRotation == 90 || requiredRotation == ORIENTATION_270) {
            return this.sHeight;
        }
        return this.sWidth;
    }

    private int sHeight() {
        int requiredRotation = getRequiredRotation();
        if (requiredRotation == 90 || requiredRotation == ORIENTATION_270) {
            return this.sWidth;
        }
        return this.sHeight;
    }

    private void fileSRect(Rect rect, Rect rect2) {
        if (getRequiredRotation() == 0) {
            rect2.set(rect);
        } else if (getRequiredRotation() == 90) {
            rect2.set(rect.top, this.sHeight - rect.right, rect.bottom, this.sHeight - rect.left);
        } else if (getRequiredRotation() == ORIENTATION_180) {
            rect2.set(this.sWidth - rect.right, this.sHeight - rect.bottom, this.sWidth - rect.left, this.sHeight - rect.top);
        } else {
            rect2.set(this.sWidth - rect.bottom, rect.left, this.sWidth - rect.top, rect.right);
        }
    }

    private int getRequiredRotation() {
        int i = this.orientation;
        return i == -1 ? this.sOrientation : i;
    }

    private float distance(float f, float f2, float f3, float f4) {
        f -= f2;
        f3 -= f4;
        return (float) Math.sqrt((double) ((f * f) + (f3 * f3)));
    }

    public void recycle() {
        reset(true);
        this.bitmapPaint = null;
        this.debugTextPaint = null;
        this.debugLinePaint = null;
        this.tileBgPaint = null;
    }

    private float viewToSourceX(float f) {
        PointF pointF = this.vTranslate;
        if (pointF == null) {
            return Float.NaN;
        }
        return (f - pointF.x) / this.scale;
    }

    private float viewToSourceY(float f) {
        PointF pointF = this.vTranslate;
        if (pointF == null) {
            return Float.NaN;
        }
        return (f - pointF.y) / this.scale;
    }

    public void viewToFileRect(Rect rect, Rect rect2) {
        if (this.vTranslate != null && this.readySent) {
            rect2.set((int) viewToSourceX((float) rect.left), (int) viewToSourceY((float) rect.top), (int) viewToSourceX((float) rect.right), (int) viewToSourceY((float) rect.bottom));
            fileSRect(rect2, rect2);
            rect2.set(Math.max(0, rect2.left), Math.max(0, rect2.top), Math.min(this.sWidth, rect2.right), Math.min(this.sHeight, rect2.bottom));
            rect = this.sRegion;
            if (rect != null) {
                rect2.offset(rect.left, this.sRegion.top);
            }
        }
    }

    public void visibleFileRect(Rect rect) {
        if (this.vTranslate != null && this.readySent) {
            rect.set(0, 0, getWidth(), getHeight());
            viewToFileRect(rect, rect);
        }
    }

    public final PointF viewToSourceCoord(PointF pointF) {
        return viewToSourceCoord(pointF.x, pointF.y, new PointF());
    }

    public final PointF viewToSourceCoord(float f, float f2) {
        return viewToSourceCoord(f, f2, new PointF());
    }

    public final PointF viewToSourceCoord(PointF pointF, PointF pointF2) {
        return viewToSourceCoord(pointF.x, pointF.y, pointF2);
    }

    public final PointF viewToSourceCoord(float f, float f2, PointF pointF) {
        if (this.vTranslate == null) {
            return null;
        }
        pointF.set(viewToSourceX(f), viewToSourceY(f2));
        return pointF;
    }

    private float sourceToViewX(float f) {
        PointF pointF = this.vTranslate;
        if (pointF == null) {
            return Float.NaN;
        }
        return (this.scale * f) + pointF.x;
    }

    private float sourceToViewY(float f) {
        PointF pointF = this.vTranslate;
        if (pointF == null) {
            return Float.NaN;
        }
        return (this.scale * f) + pointF.y;
    }

    public final PointF sourceToViewCoord(PointF pointF) {
        return sourceToViewCoord(pointF.x, pointF.y, new PointF());
    }

    public final PointF sourceToViewCoord(float f, float f2) {
        return sourceToViewCoord(f, f2, new PointF());
    }

    public final PointF sourceToViewCoord(PointF pointF, PointF pointF2) {
        return sourceToViewCoord(pointF.x, pointF.y, pointF2);
    }

    public final PointF sourceToViewCoord(float f, float f2, PointF pointF) {
        if (this.vTranslate == null) {
            return null;
        }
        pointF.set(sourceToViewX(f), sourceToViewY(f2));
        return pointF;
    }

    private Rect sourceToViewRect(Rect rect, Rect rect2) {
        rect2.set((int) sourceToViewX((float) rect.left), (int) sourceToViewY((float) rect.top), (int) sourceToViewX((float) rect.right), (int) sourceToViewY((float) rect.bottom));
        return rect2;
    }

    private PointF vTranslateForSCenter(float f, float f2, float f3) {
        int paddingLeft = getPaddingLeft() + (((getWidth() - getPaddingRight()) - getPaddingLeft()) / 2);
        int paddingTop = getPaddingTop() + (((getHeight() - getPaddingBottom()) - getPaddingTop()) / 2);
        if (this.satTemp == null) {
            this.satTemp = new ScaleAndTranslate(0.0f, new PointF(0.0f, 0.0f), null);
        }
        this.satTemp.scale = f3;
        this.satTemp.vTranslate.set(((float) paddingLeft) - (f * f3), ((float) paddingTop) - (f2 * f3));
        fitToBounds(true, this.satTemp);
        return this.satTemp.vTranslate;
    }

    private PointF limitedSCenter(float f, float f2, float f3, PointF pointF) {
        PointF vTranslateForSCenter = vTranslateForSCenter(f, f2, f3);
        pointF.set((((float) (getPaddingLeft() + (((getWidth() - getPaddingRight()) - getPaddingLeft()) / 2))) - vTranslateForSCenter.x) / f3, (((float) (getPaddingTop() + (((getHeight() - getPaddingBottom()) - getPaddingTop()) / 2))) - vTranslateForSCenter.y) / f3);
        return pointF;
    }

    private float minScale() {
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int i = this.minimumScaleType;
        if (i == 2 || i == 4) {
            return Math.max(((float) (getWidth() - paddingLeft)) / ((float) sWidth()), ((float) (getHeight() - paddingBottom)) / ((float) sHeight()));
        }
        if (i == 3) {
            float f = this.minScale;
            if (f > 0.0f) {
                return f;
            }
        }
        return Math.min(((float) (getWidth() - paddingLeft)) / ((float) sWidth()), ((float) (getHeight() - paddingBottom)) / ((float) sHeight()));
    }

    private float limitedScale(float f) {
        return Math.min(this.maxScale, Math.max(minScale(), f));
    }

    private float ease(int i, long j, float f, float f2, long j2) {
        if (i == 1) {
            return easeOutQuad(j, f, f2, j2);
        }
        if (i == 2) {
            return easeInOutQuad(j, f, f2, j2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected easing type: ");
        stringBuilder.append(i);
        throw new IllegalStateException(stringBuilder.toString());
    }

    private void debug(String str, Object... objArr) {
        if (this.debug) {
            Log.d(TAG, String.format(str, objArr));
        }
    }

    private int px(int i) {
        return (int) (this.density * ((float) i));
    }

    public final void setRegionDecoderClass(Class<? extends ImageRegionDecoder> cls) {
        if (cls != null) {
            this.regionDecoderFactory = new CompatDecoderFactory(cls);
            return;
        }
        throw new IllegalArgumentException("Decoder class cannot be set to null");
    }

    public final void setRegionDecoderFactory(DecoderFactory<? extends ImageRegionDecoder> decoderFactory) {
        if (decoderFactory != null) {
            this.regionDecoderFactory = decoderFactory;
            return;
        }
        throw new IllegalArgumentException("Decoder factory cannot be set to null");
    }

    public final void setBitmapDecoderClass(Class<? extends ImageDecoder> cls) {
        if (cls != null) {
            this.bitmapDecoderFactory = new CompatDecoderFactory(cls);
            return;
        }
        throw new IllegalArgumentException("Decoder class cannot be set to null");
    }

    public final void setBitmapDecoderFactory(DecoderFactory<? extends ImageDecoder> decoderFactory) {
        if (decoderFactory != null) {
            this.bitmapDecoderFactory = decoderFactory;
            return;
        }
        throw new IllegalArgumentException("Decoder factory cannot be set to null");
    }

    public final void getPanRemaining(RectF rectF) {
        if (isReady()) {
            float sWidth = this.scale * ((float) sWidth());
            float sHeight = this.scale * ((float) sHeight());
            int i = this.panLimit;
            if (i == 3) {
                rectF.top = Math.max(0.0f, -(this.vTranslate.y - ((float) (getHeight() / 2))));
                rectF.left = Math.max(0.0f, -(this.vTranslate.x - ((float) (getWidth() / 2))));
                rectF.bottom = Math.max(0.0f, this.vTranslate.y - (((float) (getHeight() / 2)) - sHeight));
                rectF.right = Math.max(0.0f, this.vTranslate.x - (((float) (getWidth() / 2)) - sWidth));
            } else if (i == 2) {
                rectF.top = Math.max(0.0f, -(this.vTranslate.y - ((float) getHeight())));
                rectF.left = Math.max(0.0f, -(this.vTranslate.x - ((float) getWidth())));
                rectF.bottom = Math.max(0.0f, this.vTranslate.y + sHeight);
                rectF.right = Math.max(0.0f, this.vTranslate.x + sWidth);
            } else {
                rectF.top = Math.max(0.0f, -this.vTranslate.y);
                rectF.left = Math.max(0.0f, -this.vTranslate.x);
                rectF.bottom = Math.max(0.0f, (this.vTranslate.y + sHeight) - ((float) getHeight()));
                rectF.right = Math.max(0.0f, (this.vTranslate.x + sWidth) - ((float) getWidth()));
            }
        }
    }

    public final void setPanLimit(int i) {
      /*  if (VALID_PAN_LIMITS.contains(Integer.valueOf(i))) {
            this.panLimit = i;
            if (isReady()) {
                fitToBounds(true);
                invalidate();
                return;
            }
            return;
        }*/
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid pan limit: ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final void setMinimumScaleType(int i) {
       /* if (VALID_SCALE_TYPES.contains(Integer.valueOf(i))) {
            this.minimumScaleType = i;
            if (isReady()) {
                fitToBounds(true);
                invalidate();
                return;
            }
            return;
        }*/
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid scale type: ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final void setMaxScale(float f) {
        this.maxScale = f;
    }

    public final void setMinScale(float f) {
        this.minScale = f;
    }

    public final void setMinimumDpi(int i) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        setMaxScale(((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0f) / ((float) i));
    }

    public final void setMaximumDpi(int i) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        setMinScale(((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0f) / ((float) i));
    }

    public float getMaxScale() {
        return this.maxScale;
    }

    public final float getMinScale() {
        return minScale();
    }

    public void setMinimumTileDpi(int i) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.minimumTileDpi = (int) Math.min((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0f, (float) i);
        if (isReady()) {
            reset(false);
            invalidate();
        }
    }

    public final PointF getCenter() {
        return viewToSourceCoord((float) (getWidth() / 2), (float) (getHeight() / 2));
    }

    public final float getScale() {
        return this.scale;
    }

    public final void setScaleAndCenter(float f, PointF pointF) {
        this.anim = null;
        this.pendingScale = Float.valueOf(f);
        this.sPendingCenter = pointF;
        this.sRequestedCenter = pointF;
        invalidate();
    }

    public final void resetScaleAndCenter() {
        this.anim = null;
        this.pendingScale = Float.valueOf(limitedScale(0.0f));
        if (isReady()) {
            this.sPendingCenter = new PointF((float) (sWidth() / 2), (float) (sHeight() / 2));
        } else {
            this.sPendingCenter = new PointF(0.0f, 0.0f);
        }
        invalidate();
    }

    public final boolean isReady() {
        return this.readySent;
    }

    public final boolean isImageLoaded() {
        return this.imageLoadedSent;
    }

    public final int getSWidth() {
        return this.sWidth;
    }

    public final int getSHeight() {
        return this.sHeight;
    }

    public final int getOrientation() {
        return this.orientation;
    }

    public final int getAppliedOrientation() {
        return getRequiredRotation();
    }

    public final ImageViewState getState() {
        return (this.vTranslate == null || this.sWidth <= 0 || this.sHeight <= 0) ? null : new ImageViewState(getScale(), getCenter(), getOrientation());
    }

    public final boolean isZoomEnabled() {
        return this.zoomEnabled;
    }

    public final void setZoomEnabled(boolean z) {
        this.zoomEnabled = z;
    }

    public final boolean isQuickScaleEnabled() {
        return this.quickScaleEnabled;
    }

    public final void setQuickScaleEnabled(boolean z) {
        this.quickScaleEnabled = z;
    }

    public final boolean isPanEnabled() {
        return this.panEnabled;
    }

    public final void setPanEnabled(boolean z) {
        this.panEnabled = z;
        if (!z) {
            PointF pointF = this.vTranslate;
            if (pointF != null) {
                pointF.x = ((float) (getWidth() / 2)) - (this.scale * ((float) (sWidth() / 2)));
                this.vTranslate.y = ((float) (getHeight() / 2)) - (this.scale * ((float) (sHeight() / 2)));
                if (isReady()) {
                    refreshRequiredTiles(true);
                    invalidate();
                }
            }
        }
    }

    public final void setTileBackgroundColor(int i) {
        if (Color.alpha(i) == 0) {
            this.tileBgPaint = null;
        } else {
            Paint paint = new Paint();
            this.tileBgPaint = paint;
            paint.setStyle(Style.FILL);
            this.tileBgPaint.setColor(i);
        }
        invalidate();
    }

    public final void setDoubleTapZoomScale(float f) {
        this.doubleTapZoomScale = f;
    }

    public final void setDoubleTapZoomDpi(int i) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        setDoubleTapZoomScale(((displayMetrics.xdpi + displayMetrics.ydpi) / 2.0f) / ((float) i));
    }

    public final void setDoubleTapZoomStyle(int i) {
     /*   if (VALID_ZOOM_STYLES.contains(Integer.valueOf(i))) {
            this.doubleTapZoomStyle = i;
            return;
        }*/
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid zoom style: ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final void setDoubleTapZoomDuration(int i) {
        this.doubleTapZoomDuration = Math.max(0, i);
    }

    public void setExecutor(Executor executor) {
        if (executor != null) {
            this.executor = executor;
            return;
        }
        throw new NullPointerException("Executor must not be null");
    }

    public void setEagerLoadingEnabled(boolean z) {
        this.eagerLoadingEnabled = z;
    }

    public final void setDebug(boolean z) {
        this.debug = z;
    }

    public boolean hasImage() {
        return (this.uri == null && this.bitmap == null) ? false : true;
    }

    public void setOnLongClickListener(OnLongClickListener onLongClickListener) {
        this.onLongClickListener = onLongClickListener;
    }

    public void setOnImageEventListener(OnImageEventListener onImageEventListener) {
        this.onImageEventListener = onImageEventListener;
    }

    public void setOnStateChangedListener(OnStateChangedListener onStateChangedListener) {
        this.onStateChangedListener = onStateChangedListener;
    }

    private void sendStateChanged(float f, PointF pointF, int i) {
        OnStateChangedListener onStateChangedListener = this.onStateChangedListener;
        if (onStateChangedListener != null) {
            float f2 = this.scale;
            if (f2 != f) {
                onStateChangedListener.onScaleChanged(f2, i);
            }
        }
        if (this.onStateChangedListener != null && !this.vTranslate.equals(pointF)) {
            this.onStateChangedListener.onCenterChanged(getCenter(), i);
        }
    }

    public AnimationBuilder animateCenter(PointF pointF) {
        isReady();
        return null;
    }

    public AnimationBuilder animateScale(float f) {
//        return isReady() ? new AnimationBuilder(this, this, f, null, null) : null;
        return null;
    }

    public AnimationBuilder animateScaleAndCenter(float f, PointF pointF) {
        return isReady() ? new AnimationBuilder(this, this, f, pointF, null, null) : null;
    }
}
