package com.rtovehicleinformation.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class OwnerRootPaidModel {

    public int code;
    public String status;
    public Response response;

    public OwnerRootPaidModel(int code, String status, Response response) {
        this.code = code;
        this.status = status;
        this.response = response;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public class Response
    {
        public String isValid;
        public String license_plate;
        public String owner_name;
        public String financer;
        public String model;
        @SerializedName("class")
        public String vehicleClass;
        public String registration_date;
        public String vehicle_age;
        public String insurance_expiry;
        public String pollution_expiry;
        public String chassis_number;
        public String engine_number;
        public String fuel_type;
        public String brand_name;
        public String brand_model;
        public CarSpecification car_specification;
        public String fitness_upto;
        public String wheel_count;
        public String id;
        public String rto_code;
        public String rto;
        public String state;
        public List<String> images;

        public class CarSpecification{
            public String rpm;
            public String transmission;
            public String mileage;
            public String airbags;
            public String sunroof;

            public CarSpecification(String rpm, String transmission, String mileage, String airbags, String sunroof) {
                this.rpm = rpm;
                this.transmission = transmission;
                this.mileage = mileage;
                this.airbags = airbags;
                this.sunroof = sunroof;
            }

            public String getRpm() {
                return rpm;
            }

            public void setRpm(String rpm) {
                this.rpm = rpm;
            }

            public String getTransmission() {
                return transmission;
            }

            public void setTransmission(String transmission) {
                this.transmission = transmission;
            }

            public String getMileage() {
                return mileage;
            }

            public void setMileage(String mileage) {
                this.mileage = mileage;
            }

            public String getAirbags() {
                return airbags;
            }

            public void setAirbags(String airbags) {
                this.airbags = airbags;
            }

            public String getSunroof() {
                return sunroof;
            }

            public void setSunroof(String sunroof) {
                this.sunroof = sunroof;
            }
        }

        public Response(String isValid, String license_plate, String owner_name, String financer, String model, String vehicleClass, String registration_date, String vehicle_age, String insurance_expiry, String pollution_expiry, String chassis_number, String engine_number, String fuel_type, String brand_name, String brand_model, CarSpecification car_specification, String fitness_upto, String wheel_count, String id, String rto_code, String rto, String state, List<String> images) {
            this.isValid = isValid;
            this.license_plate = license_plate;
            this.owner_name = owner_name;
            this.financer = financer;
            this.model = model;
            this.vehicleClass = vehicleClass;
            this.registration_date = registration_date;
            this.vehicle_age = vehicle_age;
            this.insurance_expiry = insurance_expiry;
            this.pollution_expiry = pollution_expiry;
            this.chassis_number = chassis_number;
            this.engine_number = engine_number;
            this.fuel_type = fuel_type;
            this.brand_name = brand_name;
            this.brand_model = brand_model;
            this.car_specification = car_specification;
            this.fitness_upto = fitness_upto;
            this.wheel_count = wheel_count;
            this.id = id;
            this.rto_code = rto_code;
            this.rto = rto;
            this.state = state;
            this.images = images;
        }

        public String getIsValid() {
            return isValid;
        }

        public void setIsValid(String isValid) {
            this.isValid = isValid;
        }

        public String getLicense_plate() {
            return license_plate;
        }

        public void setLicense_plate(String license_plate) {
            this.license_plate = license_plate;
        }

        public String getOwner_name() {
            return owner_name;
        }

        public void setOwner_name(String owner_name) {
            this.owner_name = owner_name;
        }

        public String getFinancer() {
            return financer;
        }

        public void setFinancer(String financer) {
            this.financer = financer;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public String getVehicleClass() {
            return vehicleClass;
        }

        public void setVehicleClass(String vehicleClass) {
            this.vehicleClass = vehicleClass;
        }

        public String getRegistration_date() {
            return registration_date;
        }

        public void setRegistration_date(String registration_date) {
            this.registration_date = registration_date;
        }

        public String getVehicle_age() {
            return vehicle_age;
        }

        public void setVehicle_age(String vehicle_age) {
            this.vehicle_age = vehicle_age;
        }

        public String getInsurance_expiry() {
            return insurance_expiry;
        }

        public void setInsurance_expiry(String insurance_expiry) {
            this.insurance_expiry = insurance_expiry;
        }

        public String getPollution_expiry() {
            return pollution_expiry;
        }

        public void setPollution_expiry(String pollution_expiry) {
            this.pollution_expiry = pollution_expiry;
        }

        public String getChassis_number() {
            return chassis_number;
        }

        public void setChassis_number(String chassis_number) {
            this.chassis_number = chassis_number;
        }

        public String getEngine_number() {
            return engine_number;
        }

        public void setEngine_number(String engine_number) {
            this.engine_number = engine_number;
        }

        public String getFuel_type() {
            return fuel_type;
        }

        public void setFuel_type(String fuel_type) {
            this.fuel_type = fuel_type;
        }

        public String getBrand_name() {
            return brand_name;
        }

        public void setBrand_name(String brand_name) {
            this.brand_name = brand_name;
        }

        public String getBrand_model() {
            return brand_model;
        }

        public void setBrand_model(String brand_model) {
            this.brand_model = brand_model;
        }

        public CarSpecification getCar_specification() {
            return car_specification;
        }

        public void setCar_specification(CarSpecification car_specification) {
            this.car_specification = car_specification;
        }

        public String getFitness_upto() {
            return fitness_upto;
        }

        public void setFitness_upto(String fitness_upto) {
            this.fitness_upto = fitness_upto;
        }

        public String getWheel_count() {
            return wheel_count;
        }

        public void setWheel_count(String wheel_count) {
            this.wheel_count = wheel_count;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getRto_code() {
            return rto_code;
        }

        public void setRto_code(String rto_code) {
            this.rto_code = rto_code;
        }

        public String getRto() {
            return rto;
        }

        public void setRto(String rto) {
            this.rto = rto;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }
    }
}
