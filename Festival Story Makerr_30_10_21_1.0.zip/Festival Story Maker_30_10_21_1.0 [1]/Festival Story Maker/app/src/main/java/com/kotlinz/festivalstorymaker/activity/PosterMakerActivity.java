
package com.kotlinz.festivalstorymaker.activity;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.Poster.PosterCategoryAdapter;
import com.kotlinz.festivalstorymaker.Adapter.Poster.PosterParentCategoryAdapter;
import com.kotlinz.festivalstorymaker.Adapter.Poster.PosterSubCategoryAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.CategoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.CategoryWiseData.CategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterChildCategory;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterMainCategory;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterMakerResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PosterMakerActivity extends AppCompatActivity {

    public Activity activity = PosterMakerActivity.this;
    @BindView(R.id.rv_poster_category)
    RecyclerView rvPosterCategory;

    @BindView(R.id.rv_poster_Parentcategory)
    public RecyclerView rvPosterParentCategory;

    @BindView(R.id.rv_Poster_subcategory)
    public RecyclerView rvPosterSubCategory;

    @BindView(R.id.rl_main_data)
    public RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    public LinearLayout llRetry;

    private int ModuleId;

    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    ArrayList<PosterMainCategory> posterCategoriesList;
    PosterCategoryAdapter posterCategoryAdapter;

    public ArrayList<PosterChildCategory> posterParentCategoriesList;
    public PosterParentCategoryAdapter posterParentCategoryAdapter;

    public ArrayList<CategoryWiseData> posterSubCategoryList;
    public PosterSubCategoryAdapter posterSubCategoryAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    private ArrayList<Image> images = new ArrayList<>();
    ArrayList<String> arrayList = new ArrayList<String>();

    Gson gson = new Gson();

    public String ParentCatId;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poster_maker);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        posterCategoriesList = new ArrayList<>();
        posterParentCategoriesList = new ArrayList<>();
        posterSubCategoryList = new ArrayList<>();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        InitProgressDialog();
        BannerAds();
        SetPosterMakerMainCategoryData();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "PosterMakerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetPosterCategory();
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }

    private void SetPosterMakerMainCategoryData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker).equalsIgnoreCase("")) {
                GetPosterCategory();

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.PosterMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetPosterCategory();

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker).equalsIgnoreCase("")) {

                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker));
            }
        }
    }


    private void GetPosterCategory() {
        progressDialog.show();
        Call<PosterMakerResponse> call = apiInterface.getModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<PosterMakerResponse>() {
            @Override
            public void onResponse(Call<PosterMakerResponse> call, Response<PosterMakerResponse> response) {
                if (response.isSuccessful()) {

                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.PosterMaker);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.PosterMakerResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<PosterMakerResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMaker).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineDataMainCategory(String response) {

        PosterMakerResponse posterMakerResponse = gson.fromJson(response, PosterMakerResponse.class);
        posterCategoriesList = posterMakerResponse.getData();

        posterCategoryAdapter = new PosterCategoryAdapter(activity, posterCategoriesList);
        mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
        rvPosterCategory.setLayoutManager(mLayoutManager);
        rvPosterCategory.setAdapter(posterCategoryAdapter);

        ParentCatId = String.valueOf(posterCategoriesList.get(0).getCatId());
        SetPosterParentCategory(0, posterCategoriesList);
        SetPosterThemeData(0, posterCategoriesList);
        progressDialog.dismiss();
    }

    public void SetPosterParentCategory(int Position, ArrayList<PosterMainCategory> posterCategoryList) {
        posterParentCategoriesList = posterCategoryList.get(Position).getChildCategory();
        posterParentCategoryAdapter = new PosterParentCategoryAdapter(activity, posterParentCategoriesList);
        mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
        rvPosterParentCategory.setLayoutManager(mLayoutManager);
        rvPosterParentCategory.setAdapter(posterParentCategoryAdapter);
    }

    public void SetPosterThemeData(int Position, ArrayList<PosterMainCategory> posterCategoryList) {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + posterCategoryList.get(Position).getCatId() + posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                posterParentCategoriesList = posterCategoryList.get(Position).getChildCategory();
                if (posterCategoryList.get(Position).getChildCategory().size() != 0) {
                    GetPosterCategoryDataByID(String.valueOf(posterCategoryList.get(Position).getCatId()), String.valueOf(posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
                }

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.PosterMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                posterParentCategoriesList = posterCategoryList.get(Position).getChildCategory();
                if (posterCategoryList.get(Position).getChildCategory().size() != 0) {
                    GetPosterCategoryDataByID(String.valueOf(posterCategoryList.get(Position).getCatId()), String.valueOf(posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
                }

            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + posterCategoryList.get(Position).getCatId() + posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {

                SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + posterCategoryList.get(Position).getCatId() + posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));

            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + posterCategoryList.get(Position).getCatId() + posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineParentCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + posterCategoryList.get(Position).getCatId() + posterCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        }
    }

    public void GetPosterCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<CategoryWiseResponse> call = apiInterface.getCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<CategoryWiseResponse>() {
            @Override
            public void onResponse(Call<CategoryWiseResponse> call, Response<CategoryWiseResponse> response) {
                if (response.isSuccessful()) {

                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.PosterMakerTheme + ParentCatId + ChildCatId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.PosterMakerThemeResponseTime);
                    SetOfflineParentCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<CategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.PosterMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineParentCategory(String response) {

        CategoryWiseResponse categoryWiseResponse = gson.fromJson(response, CategoryWiseResponse.class);
        posterSubCategoryList = categoryWiseResponse.getData();
        posterSubCategoryAdapter = new PosterSubCategoryAdapter(activity, posterSubCategoryList);
        rvPosterSubCategory.setLayoutManager(new GridLayoutManager(activity, 2));
        rvPosterSubCategory.setAdapter(posterSubCategoryAdapter);
        progressDialog.dismiss();

    }

    @OnClick({R.id.iv_my_creation})
    public void MyPost(View view) {
        startActivity(new Intent(activity, MyPostActivity.class));
    }

    public void ShowImageDialog(String IsFrom) {
        Dialog dialog = new Dialog(activity, R.style.AppImageAlertDialog);
        dialog.setContentView(R.layout.dialog_select_imagevideo);
        LinearLayout llCamera = dialog.findViewById(R.id.llCamera);
        LinearLayout llGallery = dialog.findViewById(R.id.llGallery);
        llCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCamera();
                dialog.dismiss();
            }
        });
        llGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenGallery();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void OpenGallery() {
        final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
        final ImagePickerConfig a2 = a.config;
        a2.folderMode = true;
        a2.theme = 10;
        a2.showCamera = false;
        a2.limit = Constant.NoofImage;
        a.start(0);
    }

    private void OpenCamera() {
       /* Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(intent, Constant.Camera);*/
        Toast.makeText(activity, "Coming Soon", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == -1) {
            images = (ArrayList<Image>) ImagePicker.getImages(data);
            if (images != null) {
                if (images.size() == Constant.NoofImage) {
                    for (int i = 0; i < images.size(); i++) {
                        arrayList.add(images.get(i).getPath());
                    }
                }
                Intent intent = new Intent(activity, CanvasEditorActivity.class);
                intent.putExtra("images", arrayList);
                intent.putExtra("FilePath", Constant.TextFilePath);
                intent.putExtra("IsFrom", Constant.IsFromPoster);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(activity, "Please select " + Constant.NoofImage + "Images", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @OnClick(R.id.iv_back)
    public void Back(View view) {
        onBackPressed();
    }

    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 18;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                startActivity(new Intent(activity, MyPostActivity.class));
                finish();
            }
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, DashBordActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 17;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(activity, DashBordActivity.class));
                finish();
            }
        }
    }
}