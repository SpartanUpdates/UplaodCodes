package com.kotlinz.festivalstorymaker.activity;


import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.BackgroundCatImageListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.BackgroundCategoryListAdapter;
import com.kotlinz.festivalstorymaker.Adapter.CollageMakeBottomFrameListAdapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.TextUtils;
import android.transition.Slide;
import android.transition.TransitionManager;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.Behavior;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundMainResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundResponse;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerSavePath;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.cameraonly.CameraOnlyConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.Models.h;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.kotlinz.festivalstorymaker.Listener.SetListener.HighLightDetailsColorListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HighLightDetailsSticker;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDTextStickerViewSideTouchListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDFontListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDTextStickerViewTouchListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDFontHeight;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDFontSpacing;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDaddOnGlobalLayoutListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HdImageGestureTouchListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.s6;
import com.kotlinz.festivalstorymaker.Listener.SetListener.t6;
import com.kotlinz.festivalstorymaker.Listener.SetListener.u6;
import com.kotlinz.festivalstorymaker.Listener.SetListener.v6;
import com.kotlinz.festivalstorymaker.Listener.SetListener.HDimageStickerView;

import org.json.JSONObject;

import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.squareup.picasso.Picasso;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.TextSticker;
import com.yalantis.ucrop.UCropActivity;

import static com.kotlinz.festivalstorymaker.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

public class HighlightDetailsDetailActivity extends BaseActivity implements com.kotlinz.festivalstorymaker.Other.g.c, com.kotlinz.festivalstorymaker.texteditor.FontListAdapter.a, com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a {

    Activity activity = HighlightDetailsDetailActivity.this;
    public CollageMakeBottomFrameListAdapter I;


    @BindView(com.kotlinz.festivalstorymaker.R.id.listBackgroundCat)
    public RecyclerView rvBackground;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listBackgroundCatImage)
    public RecyclerView rvBackgroundCatImage;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView rvColor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView rvFont;


    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llBackgroundSelection)
    public LinearLayout llBackgroundSelection;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout llCaps;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llColors;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llDeleteImage)
    public LinearLayout llDeleteImage;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlTop)
    public RelativeLayout rlTop;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;

    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView svScroll;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar sbFontSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar sbFontHeight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.frameElements)
    public FrameLayout flElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.frameLayout)
    public FrameLayout flFramelayout;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView ivAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView ivAlignCenter;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView ivAlignLeft;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView ivAlignRight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView ivAllCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView ivCaps;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView ivColor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView ivFirstCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView ivFont;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView ivLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView ivSmall;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView ivSpace;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_background)
    ImageView ivBackground;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_text)
    ImageView ivText;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_logo)
    ImageView ivLogo;

    @BindView(com.kotlinz.festivalstorymaker.R.id.iv_element)
    ImageView ivElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_background)
    TextView tvBackground;

    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_text)
    TextView tvText;

    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_logo)
    TextView tvLogo;

    @BindView(com.kotlinz.festivalstorymaker.R.id.tv_element)
    TextView tvElements;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlMain)
    RelativeLayout rlMain;

    @BindView(com.kotlinz.festivalstorymaker.R.id.fl_adplaceholder)
    FrameLayout frameLayout;

    @BindView(com.kotlinz.festivalstorymaker.R.id.sticker_view)
    public StickerView stickerView;

    public com.kotlinz.festivalstorymaker.Other.g.a K;
    public ArrayList<h> M = new ArrayList();
    public ArrayList<com.kotlinz.festivalstorymaker.Models.e> N = new ArrayList();
    public String O;
    public String P;
    public String Q;
    public int R;
    public ImageStickerViewNew T;
    public JSONObject U;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> Y;
    public int a0;
    public int b0;
    public int c0;
    public int d0;
    public ImageView e0;
    public ImageView f0;
    public ImageView g0;
    public boolean h0;
    public FontListAdapter i0;
    public ColorListAdapter j0;
    public int k0;
    public int l0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.z.c> m0;
    public TextStickerViewNew1 n0;
    public boolean o0;

    private int ModuleId;
    String FilePath;

    BackgroundCategoryListAdapter backgroundCategoryListAdapter;
    public ArrayList<BackgroundMainResponse> backgroundMainResponses = new ArrayList();

    private NativeAd nativeAd;

    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    private void DownloadComplete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.layout_download_complete, null);
        builder.setView(customLayout);
        AlertDialog dialog = builder.create();
        ImageView ivOk = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.iv_ok);
        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public class DownloadFile extends AsyncTask<String, Boolean, File> {


        @Override
        protected void onPostExecute(File obj) {
            super.onPostExecute(obj);
            File file = obj;
            HighlightDetailsDetailActivity.this.u.u();
            DownloadComplete();
        }

        @Override
        protected File doInBackground(String... strings) {
            String[] strArr = strings;
            Utils.J(com.kotlinz.festivalstorymaker.Other.AppConstant.e2, HighlightDetailsDetailActivity.this.Q);
            try {
                Bitmap bitmap = HighlightDetailsDetailActivity.this.e0(rlMain);
                File file = DownloadTheme();
                if (file != null) {
                    FileOutputStream fileOutputStream = new FileOutputStream(file.getAbsolutePath());
                    bitmap.compress(CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                    Utils.K(HighlightDetailsDetailActivity.this, file);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return new File("");
        }

        public void onPreExecute() {
            super.onPreExecute();
            u = new Utils(activity);
            u.c(getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            u.m();
        }
    }

    public class g extends AsyncTask<Void, Void, Void> {
        public String a;
        public Bitmap b;

        public g(String str) {
            this.a = str;
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (this.b != null) {
                ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(HighlightDetailsDetailActivity.this, this.a, 150.0f, 150.0f, 1.0f, 0.0f, 2, true);
                imageStickerViewNew.setGif(false);
                imageStickerViewNew.setScroll(svScroll);
                imageStickerViewNew.setTag("Element");
                imageStickerViewNew.setBitmap(this.b, Boolean.TRUE);
                imageStickerViewNew.setSize(250.0f);
                imageStickerViewNew.setOperationListener(new HDimageStickerView(HighlightDetailsDetailActivity.this, this, imageStickerViewNew));
                flElements.addView(imageStickerViewNew);
                flElements.requestLayout();
            }
            if (!HighlightDetailsDetailActivity.this.isFinishing()) {
                HighlightDetailsDetailActivity.this.u.u();
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Void[] voidArr = voids;
            Utils.O();
            try {
                this.b = BitmapFactory.decodeStream(new URL(this.a).openConnection().getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            HighlightDetailsDetailActivity.this.u = new Utils(HighlightDetailsDetailActivity.this);
            HighlightDetailsDetailActivity highlightDetailsDetailActivity = HighlightDetailsDetailActivity.this;
            highlightDetailsDetailActivity.u.c(highlightDetailsDetailActivity.getResources().getString(com.kotlinz.festivalstorymaker.R.string.loading));
            if (!HighlightDetailsDetailActivity.this.isFinishing()) {
                HighlightDetailsDetailActivity.this.u.m();
            }
        }
    }

    public class a implements TextInputDilaog.d {
        public final FrameLayout a;
        public final TextStickerViewNew1 b;

        public a(HighlightDetailsDetailActivity highlightDetailsDetailActivity, FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
            this.a = frameLayout;
            this.b = textStickerViewNew1;
        }

        public void a(String str, int i) {
            if (str.length() == 0) {
                this.a.removeView(this.b);
                this.a.requestLayout();
                return;
            }
            this.b.setText(str);
        }

        public void b(String str) {
        }
    }

    public class b implements CollageMakeBottomFrameListAdapter.a {
        public void a(int i) {
            o0(M.get(i).e);
        }
    }

    public class c implements BackgroundCategoryListAdapter.a {
        public void a(int i) {
            HighlightDetailsDetailActivity.this.t0(i);
        }
    }

    public class d implements BackgroundCatImageListAdapter.a {
        public final int a;

        public d(int i) {
            this.a = i;
        }

        public void a(int i) {
            HighlightDetailsDetailActivity highlightDetailsDetailActivity = HighlightDetailsDetailActivity.this;
            highlightDetailsDetailActivity.P = highlightDetailsDetailActivity.N.get(this.a).k.get(i).b;
            HighlightDetailsDetailActivity highlightDetailsDetailActivity2 = HighlightDetailsDetailActivity.this;
            if (highlightDetailsDetailActivity2.g0 != null && highlightDetailsDetailActivity2.P.length() > 0) {
                Picasso.get().load(HighlightDetailsDetailActivity.this.P).into(HighlightDetailsDetailActivity.this.g0, null);
            }
        }
    }

    public static class e extends BottomSheetDialogFragment {
        public Behavior k0;

        public class a implements OnClickListener {
            public void onClick(View view) {
                Behavior behavior = e.this.k0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                cameraOnlyConfig.returnMode = ReturnMode.GALLERY_ONLY;
                FragmentActivity c = e.this.getActivity();
                Intent intent = new Intent(c, ImagePickerActivity.class);
                intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                c.startActivityForResult(intent, 553);
            }
        }

        public class b implements OnClickListener {
            public void onClick(View view) {
                Behavior behavior = e.this.k0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                ImagePicker.ImagePickerWithActivity aVar = new ImagePicker.ImagePickerWithActivity(e.this.getActivity());
                ImagePickerConfig imagePickerConfig = aVar.config;
                imagePickerConfig.folderMode = true;
                imagePickerConfig.returnMode = ReturnMode.CAMERA_ONLY;
                aVar.single();
                aVar.config.showCamera = false;
                aVar.start();
            }
        }


        @SuppressLint("RestrictedApi")
        @Override
        public void setupDialog(@NonNull Dialog dialog, int style) {
            super.setupDialog(dialog, style);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setDimAmount(0.0f);
            View inflate = View.inflate(getActivity(), com.kotlinz.festivalstorymaker.R.layout.dialog_select_image, null);
            dialog.setContentView(inflate);
            CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) inflate.getParent()).getLayoutParams();
            CoordinatorLayout.Behavior behavior = params.getBehavior();
            this.k0 = behavior;
            if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_EXPANDED);
            }
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llCamera).setOnClickListener(new a());
            dialog.findViewById(com.kotlinz.festivalstorymaker.R.id.llGallery).setOnClickListener(new b());
        }

    }

    public HighlightDetailsDetailActivity() {
        String str = "";
        this.P = str;
        this.Q = str;
        this.R = 45;
        this.a0 = 0;
        this.h0 = false;
        this.k0 = -1;
        this.l0 = -1;
        this.m0 = new ArrayList();
        this.o0 = false;
    }

    public static void i0(HighlightDetailsDetailActivity highlightDetailsDetailActivity, String str, int i, int i2) {
        if (highlightDetailsDetailActivity != null) {
            Utils.d();
            Bundle bundle = new Bundle();
            bundle.putString("com.yalantis.ucrop.CompressionFormatName", CompressFormat.JPEG.name());
            bundle.putInt("com.yalantis.ucrop.CompressionQuality", 100);
            bundle.putString("com.yalantis.ucrop.UcropToolbarTitleText", "Crop");
            bundle.putBoolean("com.yalantis.ucrop.HideBottomControls", true);
            bundle.putBoolean("com.yalantis.ucrop.FreeStyleCrop", false);
            Uri fromFile = Uri.fromFile(new File(str));
            File cacheDir = highlightDetailsDetailActivity.getCacheDir();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(System.currentTimeMillis());
            stringBuilder.append(".png");
            Uri fromFile2 = Uri.fromFile(new File(cacheDir, stringBuilder.toString()));
            Intent intent = new Intent();
            Bundle bundle2 = new Bundle();
            bundle2.putParcelable("com.yalantis.ucrop.InputUri", fromFile);
            bundle2.putParcelable("com.yalantis.ucrop.OutputUri", fromFile2);
            float f = (float) i;
            float f2 = (float) i2;
            bundle2.putFloat("com.yalantis.ucrop.AspectRatioX", f);
            bundle2.putFloat("com.yalantis.ucrop.AspectRatioY", f2);
            bundle2.putInt("com.yalantis.ucrop.MaxSizeX", 2200);
            bundle2.putInt("com.yalantis.ucrop.MaxSizeY", 2200);
            bundle2.putAll(bundle);
            intent.setClass(highlightDetailsDetailActivity, UCropActivity.class);
            intent.putExtras(bundle2);
            highlightDetailsDetailActivity.startActivityForResult(intent, 69);
            return;
        }
        throw null;
    }

    public void B(Typeface typeface, int i) {
        Font font = this.n0.getFont();
        font.c = typeface;
        this.n0.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.f = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public void D(int i) {
        Font font = this.n0.getFont();
        font.a = Color.parseColor(colorList[i]);
        this.n0.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.d = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public void L(int i, String str) {
    }

    public final void g0(FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new a(this, frameLayout, textStickerViewNew1);
    }

    @SuppressLint({"NewApi"})
    public final void k0(int i) {
        int i2 = -16777216;
        ivAlignCenter.setColorFilter(i == 0 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAlignLeft.setColorFilter(i == -1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivAlignRight;
        if (i != 1) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.n0.getText();
        TextStickerViewNew1 textStickerViewNew1 = this.n0;
        Alignment alignment = i == 0 ? Alignment.ALIGN_CENTER : i == 1 ? Alignment.ALIGN_OPPOSITE : Alignment.ALIGN_NORMAL;
        textStickerViewNew1.setAlign(alignment);
        this.n0.setText(str);
        this.n0.requestLayout();
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.c = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public final void l0(int i) {
        int i2 = -16777216;
        ivFirstCap.setColorFilter(i == 1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAllCap.setColorFilter(i == 2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivSmall;
        if (i != 0) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.n0.getText();
        if (i != -1) {
            TextStickerViewNew1 textStickerViewNew1 = this.n0;
            str = i == 2 ? str.toUpperCase() : i == 0 ? str.toLowerCase() : f0(str);
            textStickerViewNew1.setText(str);
        }
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.m0.get(((Integer) this.n0.getTag()).intValue());
        cVar.e = i;
        this.m0.set(((Integer) this.n0.getTag()).intValue(), cVar);
    }

    public final void m0(ImageView imageView) {
        LinearLayout linearLayout;
        ImageView imageView2 = ivFont;
        int i = -16777216;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivColor;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivAlign;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivSpace;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivSmall;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivCaps;
        if (imageView != imageView2) {
            i = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView2.setColorFilter(i);
        if (imageView == ivFont) {
            linearLayout = llFonts;
        } else if (imageView == ivColor) {
            linearLayout = llColors;
        } else if (imageView == ivAlign) {
            linearLayout = llAlign;
        } else if (imageView == ivSpace) {
            linearLayout = llSpacing;
        } else if (imageView == ivLine) {
            linearLayout = llLine;
        } else if (imageView == ivCaps) {
            linearLayout = llCaps;
        } else {
            return;
        }
        linearLayout.bringToFront();
    }

    public void n0() {
        if (llDeleteImage.isShown()) {
            r0(false);
        }
        ImageStickerViewNew imageStickerViewNew = this.T;
        if (imageStickerViewNew != null) {
            imageStickerViewNew.setInEdit(false);
        }
        TextStickerViewNew1 textStickerViewNew1 = this.n0;
        if (textStickerViewNew1 != null) {
            textStickerViewNew1.setInEdit(false);
        }
        if (llTextEditor.isShown()) {
            s0(false);
        }
    }

    public final void o0(String str) {
        this.Q = str;
        GetEditData();
    }

    private void GetEditData() {
        File fileEvents = new File(FilePath);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileEvents));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String Response = text.toString();
        z(320, Response);
    }


    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != this.R) {
            if (i2 == -1 && i == 69) {
                String str = "com.yalantis.ucrop.OutputUri";
                if (this.h0) {
                    this.h0 = false;
                    this.f0.setImageURI(intent.getParcelableExtra(str));
                    this.f0.setScaleX(1.0f);
                    this.f0.setScaleY(1.0f);
                } else {
                    this.e0.setImageURI(intent.getParcelableExtra(str));
                    return;
                }
            }
            i2 = com.kotlinz.festivalstorymaker.Other.AppConstant.H;
            if (i == 7924 && intent != null) {
                String stringExtra = intent.getStringExtra("path");
                if (!stringExtra.isEmpty()) {
                    String str2;
                    i = 0;
                    while (true) {
                        str2 = "LOGO";
                        if (i < flElements.getChildCount()) {
                            if ((flElements.getChildAt(i) instanceof ImageStickerViewNew) && flElements.getChildAt(i) != null && flElements.getChildAt(i).getTag().toString().equalsIgnoreCase(str2)) {
                                flElements.removeViewAt(i);
                                break;
                            }
                            i++;
                        } else {
                            break;
                        }
                    }
                    Bitmap decodeFile = BitmapFactory.decodeFile(new File(stringExtra).getAbsolutePath());
                    float x = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getWidth(), (((float) decodeFile.getWidth()) * 150.0f) / ((float) decodeFile.getHeight()), 2.0f, (float) ((decodeFile.getWidth() / 2) + 10), 20.0f);
                    float x2 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) decodeFile.getHeight(), 150.0f, 2.0f, (float) ((decodeFile.getHeight() / 2) + 10), 20.0f);
                    File file = new File(stringExtra);
                    if (file.exists()) {
                        try {
                            decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                            ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, stringExtra, x, x2, 1.0f, 0.0f, 2, true);
                            imageStickerViewNew.setGif(false);
                            imageStickerViewNew.setScroll(svScroll);
                            imageStickerViewNew.setTag(str2);
                            imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                            imageStickerViewNew.setOperationListener(new HighLightDetailsSticker(this, imageStickerViewNew));
                            imageStickerViewNew.setInEdit(false);
                            imageStickerViewNew.setSize(150.0f);
                            flElements.addView(imageStickerViewNew);
                            flElements.requestLayout();
                            return;
                        } catch (OutOfMemoryError e) {
                            e.printStackTrace();
                            return;
                        }
                    }
                    return;
                }
                return;
            } else if (intent != null) {
                List c = ImagePicker.getImages(intent);
                if (c != null && c.size() > 0) {
                    this.O = ((Image) c.get(0)).path;
                    this.e0.setImageURI(Uri.parse(((Image) c.get(0)).path));
                    this.e0.setScaleType(ScaleType.CENTER_CROP);
                    this.e0.requestLayout();
                    this.f0.setImageURI(Uri.parse(((Image) c.get(0)).path));
                    this.f0.setScaleX(1.5f);
                    this.f0.setScaleY(1.5f);
                    this.f0.setScaleType(ScaleType.CENTER_CROP);
                } else {
                    return;
                }
            } else {
                return;
            }
            this.f0.requestLayout();
        } else if (intent != null) {
            String str3 = "element";
            if (intent.getStringExtra(str3) != null) {
                new g(intent.getStringExtra(str3)).execute();
            }
        }
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.iv_back, com.kotlinz.festivalstorymaker.R.id.iv_Download, com.kotlinz.festivalstorymaker.R.id.llAddBackground, com.kotlinz.festivalstorymaker.R.id.rlFull, com.kotlinz.festivalstorymaker.R.id.llAddElement, com.kotlinz.festivalstorymaker.R.id.llAddLogo, com.kotlinz.festivalstorymaker.R.id.llAddText})
    public void onClick(View view) {
        Intent intent;
        int i;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.iv_back:
                finish();
                return;
            case com.kotlinz.festivalstorymaker.R.id.iv_Download:
                n0();
                new DownloadFile().execute();
                return;
            case com.kotlinz.festivalstorymaker.R.id.llAddBackground:
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_press);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                q0();
            case com.kotlinz.festivalstorymaker.R.id.rlFull:
                return;
            case com.kotlinz.festivalstorymaker.R.id.llAddElement:
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);

                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));

                intent = new Intent(this, ElementsActivity.class);
                intent.putExtra("moduleid", ModuleId);
                i = this.R;
                break;
            case com.kotlinz.festivalstorymaker.R.id.llAddLogo:
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_colllagelogo_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                Utils.z(this).compress(CompressFormat.PNG, 100, byteArrayOutputStream);
                intent = new Intent(getApplicationContext(), SelectLogoActivity.class).putExtra("image", byteArrayOutputStream.toByteArray());
                i = com.kotlinz.festivalstorymaker.Other.AppConstant.H;
                i = 7924;
                break;
            case com.kotlinz.festivalstorymaker.R.id.llAddText:
                ivText.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collagetext_press);
                ivBackground.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_bg_unpress);
                ivLogo.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_collage_logo_unpress);
                ivElements.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_element_unpress);

                tvText.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_press));
                tvBackground.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvLogo.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));
                tvElements.setTextColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.child_cat_text_unpress));

                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.add_text_dialog, null);
                builder.setCancelable(false);
                builder.setView(customLayout);
                AlertDialog dialog = builder.create();
                EditText etText = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_edit_text);
                ImageView ivCancel = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_cancel_tv);
                ImageView ivDone = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.add_text_done_tv);
                ivCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                ivDone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextSticker sticker = new TextSticker(activity);
                        if (etText.getText().toString().matches("")) {
                            Toast.makeText(activity, "Enter Text First", Toast.LENGTH_SHORT).show();
                        } else {
                            sticker.setText(etText.getText().toString());
                            sticker.setTextColor(Color.BLACK);
                            sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
                            sticker.resizeText();
                            stickerView.addSticker(sticker);
                            dialog.dismiss();
                        }
                    }
                });
                dialog.show();

              /*  FrameLayout frameLayout = flElements;
                TextStickerViewNew1 d0 = d0(this, svScroll, frameLayout.getWidth(), frameLayout.getHeight(), "");
                g0(frameLayout, d0);
                d0.setOperationListener(new HDTextStickerViewSideTouchListener(this, frameLayout, d0));
                d0.setOnOutSideTouchListner(new HDTextStickerViewTouchListener(this));
                com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.G(this.m0, d0);
                this.m0.add(new com.kotlinz.festivalstorymaker.Models.z.c());
                frameLayout.addView(d0);
                frameLayout.requestLayout();*/
                return;
            default:
                return;
        }
        startActivityForResult(intent, i);
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.imgAlign, com.kotlinz.festivalstorymaker.R.id.imgAlignCenter, com.kotlinz.festivalstorymaker.R.id.imgAlignLeft, com.kotlinz.festivalstorymaker.R.id.imgAlignRight, com.kotlinz.festivalstorymaker.R.id.imgAllCap, com.kotlinz.festivalstorymaker.R.id.imgCaps, com.kotlinz.festivalstorymaker.R.id.imgColor, com.kotlinz.festivalstorymaker.R.id.imgFirstCap, com.kotlinz.festivalstorymaker.R.id.imgFont, com.kotlinz.festivalstorymaker.R.id.imgLine, com.kotlinz.festivalstorymaker.R.id.imgSmall, com.kotlinz.festivalstorymaker.R.id.imgSpace})
    public void onClicks(View view) {
        ImageView imageView;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.imgAlign:
                imageView = this.ivAlign;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter:
                k0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft:
                k0(-1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight:
                k0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap:
                l0(2);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgCaps:
                imageView = ivCaps;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgColor:
                imageView = ivColor;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap:
                l0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgFont:
                imageView = ivFont;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgLine:
                imageView = ivLine;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgSmall:
                l0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgSpace:
                imageView = ivSpace;
                break;
            default:
                return;
        }
        m0(imageView);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_collage_maker_detail);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        InitProgressDialog();
        /*  ModuleId = getIntent().getIntExtra("moduleid", 0);*/
        ModuleId = AppConstant.CollageBackgroundId;
        FilePath = getIntent().getStringExtra("FilePath");
        O = getIntent().getStringArrayListExtra("list").get(0);
        LoadNativeAds();
        K = new com.kotlinz.festivalstorymaker.Other.g.a(activity, this);
        GetEditData();
        ivFont.setColorFilter(-16777216);
        llFonts.bringToFront();
        FontListAdapter fontListAdapter = new FontListAdapter(activity, fontList, new HDFontListener(this), this.l0);
        i0 = fontListAdapter;
        rvFont.setAdapter(fontListAdapter);
        ColorListAdapter colorListAdapter = new ColorListAdapter(activity, colorList, new HighLightDetailsColorListener(this), this.k0);
        j0 = colorListAdapter;
        rvColor.setAdapter(colorListAdapter);
        sbFontHeight.setOnSeekBarChangeListener(new HDFontHeight(this));
        sbFontSpacing.setOnSeekBarChangeListener(new HDFontSpacing(this));
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HighlightDetailsDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(com.kotlinz.festivalstorymaker.R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (HighlightDetailsDetailActivity.this.nativeAd != null) {
                            HighlightDetailsDetailActivity.this.nativeAd.destroy();
                        }
                        HighlightDetailsDetailActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(com.kotlinz.festivalstorymaker.R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.cardCancelImage, com.kotlinz.festivalstorymaker.R.id.cardDeleteImage})
    public void onViewClick(View view) {
        int id = view.getId();
        if (id == com.kotlinz.festivalstorymaker.R.id.cardCancelImage || id == com.kotlinz.festivalstorymaker.R.id.cardDeleteImage) {
            r0(false);
        }
    }

    public File DownloadTheme() {
        String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post" + File.separator + "Zoom Collage";
        String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file);
        stringBuilder.append(File.separator);
        stringBuilder.append(s);
        stringBuilder.append(".jpg");
        absolutePath = stringBuilder.toString();
        return TextUtils.isEmpty(absolutePath) ? null : new File(absolutePath);
    }

    public final void q0() {
        LinearLayout linearLayout = llBackgroundSelection;
        int Visibility = View.GONE;
        int AdsVisibility = View.VISIBLE;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(com.kotlinz.festivalstorymaker.R.id.llBackgroundSelection);
        if (!linearLayout.isShown()) {
            Visibility = 0;
            GetCollageBackground(ModuleId);
        }
        linearLayout.setVisibility(Visibility);

        if (frameLayout.isShown()) {
            AdsVisibility = View.GONE;
        }
        frameLayout.setVisibility(AdsVisibility);
    }

    private void GetCollageBackground(int ModuleId) {
        progressDialog.show();
        Call<BackgroundResponse> call = apiInterface.getBackgroundDetails(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<BackgroundResponse>() {
            @Override
            public void onResponse(Call<BackgroundResponse> call, Response<BackgroundResponse> response) {
                if (response.isSuccessful()) {
                    backgroundMainResponses = response.body().getData();
                    backgroundCategoryListAdapter = new BackgroundCategoryListAdapter(activity, backgroundMainResponses, new c(), 0);
                    rvBackground.setLayoutManager(new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false));
                    rvBackground.setAdapter(backgroundCategoryListAdapter);
                    t0(0);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<BackgroundResponse> call, Throwable t) {

            }
        });
    }

    public final void r0(boolean z) {
        int i = 0;
        rlTop.setVisibility(z ? View.VISIBLE : View.GONE);
        LinearLayout linearLayout = llDeleteImage;
        FrameLayout frameLayout = flFramelayout;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(llDeleteImage);
        TransitionManager.beginDelayedTransition(frameLayout, slide);
        if (!z) {
            i = 8;
        }
        linearLayout.setVisibility(i);
    }

    public final void s0(boolean z) {
        if (z) {
            m0(ivFont);
            com.kotlinz.festivalstorymaker.Models.z.c cVar = m0.get(((Integer) n0.getTag()).intValue());
            k0 = cVar.d;
            l0 = cVar.f;
            sbFontHeight.setProgress(cVar.a);
            sbFontSpacing.setProgress(cVar.b);
            j0.k(k0);
            i0.k(l0);
            k0(cVar.c);
            l0(cVar.e);
        }
        LinearLayout linearLayout = llTextEditor;
        FrameLayout frameLayout = flFramelayout;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(linearLayout);
        TransitionManager.beginDelayedTransition(frameLayout, slide);
        linearLayout.setVisibility(z ? View.VISIBLE : View.GONE);
    }

    public final void t0(int i) {
        rvBackgroundCatImage.setAdapter(new BackgroundCatImageListAdapter(activity, backgroundMainResponses.get(i).getBackgroundImages(), new d(i)));
    }

    public final void u0(int i) {
        if (i == 0) {
            b0 = (int) Float.parseFloat(this.Y.get(i).j);
            int parseFloat = (int) Float.parseFloat(Y.get(i).k);
            c0 = parseFloat;
            d0 = (parseFloat * this.a0) / b0;
            flFramelayout.getLayoutParams().width = a0;
            flFramelayout.getLayoutParams().height = d0;
            flFramelayout.requestLayout();
            flElements.getLayoutParams().width = a0;
            flElements.getLayoutParams().height = d0;
            flElements.requestLayout();
        }
        if (Y.get(i).e.equalsIgnoreCase("image")) {
            com.kotlinz.festivalstorymaker.Models.g gVar = Y.get(i);
            Float valueOf = Float.valueOf((Float.parseFloat(gVar.h) * ((float) a0)) / ((float) b0));
            Float valueOf2 = Float.valueOf((Float.parseFloat(gVar.i) * ((float) a0)) / ((float) b0));
            int parseFloat2 = (int) ((Float.parseFloat(gVar.j) * ((float) a0)) / ((float) b0));
            int parseFloat3 = (int) ((Float.parseFloat(gVar.k) * ((float) a0)) / ((float) b0));
            ImageView imageView = new ImageView(this);
            String str = "1";
            if (gVar.B.equals(str) || gVar.q.equals(str)) {
                imageView.setLayoutParams(new LayoutParams(-1, -1));
                imageView.getLayoutParams().width = parseFloat2;
                imageView.getLayoutParams().height = parseFloat3;
                imageView.setX(valueOf.floatValue());
                imageView.setY(valueOf2.floatValue());
                imageView.setAdjustViewBounds(true);
                imageView.setBackgroundColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
                if (gVar.f.isEmpty() || O.length() <= 0) {
                    imageView.setScaleType(ScaleType.FIT_CENTER);
                    Picasso.get().load(com.kotlinz.festivalstorymaker.R.drawable.ic_add_image).into(imageView, null);
                } else {
                    imageView.setScaleType(ScaleType.CENTER_CROP);
                    if (O.length() > 0) {
                        Picasso.get().load(new File(this.O)).placeholder(com.kotlinz.festivalstorymaker.R.drawable.ic_add_image).into(imageView, null);
                    }
                    imageView.setTag(Integer.valueOf(0));
                }
                imageView.requestLayout();
                imageView.setOnTouchListener(new s6(this, imageView, new GestureDetector(new HdImageGestureTouchListener(this, parseFloat2, parseFloat3))));
            } else if (gVar.g.contains("zoom")) {
                imageView.setAdjustViewBounds(true);
                imageView.setScaleType(ScaleType.CENTER_CROP);
                imageView.setImageBitmap(Utils.A(this.O));
                imageView.setTag(this.O);
                imageView.setScaleX(1.5f);
                imageView.setScaleY(1.5f);
                imageView.setLayoutParams(new LayoutParams(-1, -1));
                imageView.requestLayout();
                RelativeLayout relativeLayout = new RelativeLayout(this);
                relativeLayout.setLayoutParams(new LayoutParams(-2, -2));
                relativeLayout.setX(valueOf.floatValue());
                relativeLayout.setY(valueOf2.floatValue());
                relativeLayout.getLayoutParams().width = parseFloat2;
                relativeLayout.getLayoutParams().height = parseFloat3;
                relativeLayout.setBackgroundColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.white));
                relativeLayout.setGravity(13);
                relativeLayout.addView(imageView);
                relativeLayout.requestLayout();
                this.f0 = imageView;
                relativeLayout.setOnTouchListener(new u6(this, new GestureDetector(new t6(this, parseFloat2, parseFloat3))));
                flFramelayout.addView(relativeLayout);
                flFramelayout.requestLayout();
            } else {
                imageView.setLayoutParams(new LayoutParams(-1, -1));
                imageView.setX(valueOf.floatValue());
                imageView.setY(valueOf2.floatValue());
                imageView.getLayoutParams().width = parseFloat2;
                imageView.getLayoutParams().height = parseFloat3;
                imageView.requestLayout();
                imageView.setAdjustViewBounds(true);
                imageView.setBackgroundColor(getResources().getColor(com.kotlinz.festivalstorymaker.R.color.transparent_black));
                imageView.setScaleType(ScaleType.CENTER_CROP);
                imageView.requestLayout();
                if (gVar.C.equalsIgnoreCase(str)) {
                    imageView.setOnClickListener(new v6(this));
                }
                if (!gVar.f.isEmpty()) {
                    Picasso.get().load(gVar.f).into(imageView, null);
                }
                if (i == 0) {
                    this.g0 = imageView;
                    if (this.P.length() > 0) {
                        Picasso.get().load(P).into(imageView, null);
                    }
                }
            }
            flFramelayout.requestLayout();
        }
    }

    public void z(int i, String str) {
        int i2 = 0;
        if (i == 320) {
            flFramelayout.removeAllViews();
            flFramelayout.requestLayout();
            ArrayList d = new com.kotlinz.festivalstorymaker.Other.AppConstant().getCollageEditThemeData(this, str);
            this.Y = d;
            if (d != null && d.size() > 0) {
                if (this.a0 == 0) {
                    flFramelayout.getViewTreeObserver().addOnGlobalLayoutListener(new HDaddOnGlobalLayoutListener(this));
                    return;
                }
                while (i2 < this.Y.size()) {
                    u0(i2);
                    i2++;
                }
                return;
            }
            return;
        }
    }
}