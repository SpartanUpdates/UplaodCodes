package com.esc.gesturelockscreen.Service;

import android.app.*;
import android.content.*;
import android.os.*;

public class ScreenLockService extends Service
{
  public static boolean isVisible;
  private BroadcastReceiver mBroadcastReceiver;
  private final ILockerService mLockerService;
  private SignatureLock mSignatureLock;

  static {
    ScreenLockService.isVisible = false;
  }

  public ScreenLockService() {
    this.mLockerService = (ILockerService)new ILockerService() {
      @Override
      public Context getContext() {
        return ScreenLockService.this.getApplicationContext();
      }

      @Override
      public void onUnlock() {
        ScreenLockService.this.stopSelf();
      }
    };
  }

  public IBinder onBind(final Intent intent) {
    return null;
  }

  public void onCreate() {
    super.onCreate();
    this.mSignatureLock = new SignatureLockImpl(this.mLockerService);
    final IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("HIDE_LOCK");
    intentFilter.addAction("SHOW_LOCK");
    intentFilter.addAction("android.intent.action.SCREEN_ON");
    intentFilter.addAction("SCREEN_OFF");
    this.registerReceiver(this.mBroadcastReceiver = new BroadcastReceiver() {
      public void onReceive(final Context context, final Intent intent) {
        if (ScreenLockService.this.mSignatureLock != null) {
          final String action = intent.getAction();
          if (action.equals("SHOW_LOCK")) {
            if (!ScreenLockService.isVisible) {
              ScreenLockService.this.mSignatureLock.show();
              ScreenLockService.isVisible = true;
            }
          }
          else if (action.equals("HIDE_LOCK")) {
            if (ScreenLockService.isVisible) {
              ScreenLockService.this.mSignatureLock.hide();
              ScreenLockService.isVisible = false;
            }
          }
          else if (action.equals("android.intent.action.SCREEN_ON")) {
            if (ScreenLockService.this.mSignatureLock != null) {
              ScreenLockService.this.mSignatureLock.onScreenOn();
            }
          }
          else if (action.equals("SCREEN_OFF")) {
            if (ScreenLockService.this.mSignatureLock != null) {
              ScreenLockService.this.mSignatureLock.onScreenOff();
              return;
            }
            if (ScreenLockService.this.mSignatureLock == null) {
              ScreenLockService.this.mSignatureLock = new SignatureLockImpl(ScreenLockService.this.mLockerService);
              ScreenLockService.this.mSignatureLock.onStart(intent);
            }
          }
        }
      }
    }, intentFilter);
  }

  public void onDestroy() {
    ScreenLockService.isVisible = false;
    if (Build.VERSION.SDK_INT >= 18) {
      this.stopForeground(true);
    }
    if (this.mSignatureLock != null) {
      this.mSignatureLock.onStop(false);
      this.mSignatureLock = null;
    }
    if (this.mBroadcastReceiver != null) {
      this.unregisterReceiver(this.mBroadcastReceiver);
    }
    super.onDestroy();
  }

  public int onStartCommand(final Intent intent, final int n, final int n2) {
    if (this.mSignatureLock == null) {
      this.mSignatureLock = new SignatureLockImpl(this.mLockerService);
    }
    this.mSignatureLock.onStart(intent);
    return START_STICKY;
  }

  public interface ILockerService
  {
    Context getContext();

    void onUnlock();
  }
}
