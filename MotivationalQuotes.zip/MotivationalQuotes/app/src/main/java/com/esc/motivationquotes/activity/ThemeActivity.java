package com.esc.motivationquotes.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;

import com.esc.motivationquotes.adapter.ThemesAdapter;
import com.esc.motivationquotes.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.esc.motivationquotes.R;
import com.google.android.gms.ads.AdRequest;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.model.Theme;
import com.esc.motivationquotes.receivers.NetworkChangeReceiver;
import com.esc.motivationquotes.util.FileChooserUtils;
import com.esc.motivationquotes.util.JsonUtils;
import com.esc.motivationquotes.util.TrackerEventUtils;
import com.esc.motivationquotes.adapter.ThemesAdapter.RecyclerViewClickListener;

import java.util.ArrayList;

public class ThemeActivity extends BaseActivity implements RecyclerViewClickListener {
    private Theme currentTheme;
    private int dialogStyle = R.style.DialogStyleLight;
    private boolean hasRemovedCustomTheme = false;
    private ImageView ic_back;
    private View linearDivider;
    private boolean loadOwnTheme = false;
    private ArrayList<Object> mThemes = new ArrayList();
    private ThemesAdapter mThemesAdapter;
    private NetworkChangeReceiver myReceiver;
    private RecyclerView recyclerView;
    private AppCompatDialog Dialog;
    private NestedScrollView scroll;
    private boolean selectOwnTheme = false;
    private ImageView iv_setbackground;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_themes);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_THEMES_VIEW, null, null);
        bindUi();
        setListeners();
        loadData();
        createNetworkChangeBroadcastReceiver();
        loadAd();
    }

    private void bindUi() {
        this.recyclerView = findViewById(R.id.recyclerView);
        this.ic_back = findViewById(R.id.iv_back);
        this.iv_setbackground = findViewById(R.id.iv_setbackground);
        this.linearDivider = findViewById(R.id.linearDivider);
        this.scroll = findViewById(R.id.scroll);
    }

    private void setListeners()
    {
        this.ic_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                id = 100;
                if (interstitialAd != null && interstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    if (hasRemovedCustomTheme) {
                        currentTheme = null;
                        goBackAndLoadTheme(null);
                        return;
                    }
                    startActivity(new Intent(ThemeActivity.this, QuotesHomeActivity.class));
                    finish();
                }
            }
        });

        this.iv_setbackground.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SettingsManager.isPremium()) {
                    confgirueOwnTheme();
                } else if (SettingsManager.getOwnBackground() != null) {
                    hasRemovedCustomTheme = true;
                    SettingsManager.setOwnBackground(null);
                    mThemesAdapter.notifyDataSetChanged();
                } else {
                    selectOwnTheme = true;
                    ShowDialog();
                }
            }
        });

        this.scroll.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                if (scroll.getScrollY() == View.VISIBLE) {
                    linearDivider.setVisibility(View.GONE);
                } else {
                    linearDivider.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void loadData() {

        this.mThemes.clear();
        this.mThemes.addAll(JsonUtils.getThemes(this));
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        this.mThemesAdapter = new ThemesAdapter(this.mThemes, this, this);
        this.recyclerView.setLayoutManager(gridLayoutManager);
        this.recyclerView.setAdapter(this.mThemesAdapter);
        displayThemes(this.mThemes);
    }

    private void createNetworkChangeBroadcastReceiver() {
        this.myReceiver = new NetworkChangeReceiver(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        registerReceiver(this.myReceiver, intentFilter);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 3) {
            if (i2 == -1) {
                this.mThemesAdapter.notifyDataSetChanged();
            }
        } else if (i == 71 && intent != null) {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                SettingsManager.setOwnBackground(FileChooserUtils.getPath(this, intent.getData()));
            }
            this.mThemesAdapter.updateBitmap(FileChooserUtils.getBitmapOwnThumbnail());
            this.mThemesAdapter.notifyDataSetChanged();
        }
    }

    public void onBackPressed() {
        if (this.hasRemovedCustomTheme) {
            this.currentTheme = null;
            goBackAndLoadTheme(null);
        }
        startActivity(new Intent(ThemeActivity.this, QuotesHomeActivity.class));
        finish();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr != null && iArr.length > 0 && iArr[0] == 0) {
            chooseImage();
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE")) {
            showStoragePermissionRationale();
        } else {
            @SuppressLint("WrongConstant") Snackbar make = Snackbar.make(findViewById(R.id.linearMain), getString(R.string.permission_bar_title), 0);
            make.getView().setBackgroundColor(ContextCompat.getColor(this, R.color.color_white));
            make.setAction(getString(R.string.permission_go_settings), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", getPackageName(), null));
                    startActivity(intent);
                }
            });
            make.show();
        }
    }

    public void displayThemes(ArrayList<Object> arrayList) {
        this.mThemes = arrayList;
        ThemesAdapter themesAdapter = this.mThemesAdapter;
        if (themesAdapter != null) {
            themesAdapter.setThemes(arrayList);
        }
    }

    public void recyclerViewListClicked(View view, int i) {
        this.currentTheme = (Theme) this.mThemes.get(i);
        if (this.currentTheme.getName().equalsIgnoreCase(getString(R.string.default_theme)) || this.currentTheme.getName().equalsIgnoreCase(getString(R.string.default_th))) {
            goBackAndLoadTheme(this.currentTheme);
            return;
        }
        this.selectOwnTheme = false;
        if (this.loadOwnTheme) {
            this.loadOwnTheme = false;
            goBackAndLoadTheme(this.currentTheme);
            return;
        }
        ShowDialog();
    }

    public void goBackAndLoadTheme(Theme theme) {
        if (theme != null) {
            String name = theme.getName();
            String str = TrackerEventUtils.KEY_THEME;
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SELECTED_THEME, str, name);
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_SELECTED_THEME_MIXPANEL, str, theme.getName());
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(Theme.TAG, theme);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(-1, intent);
        finish();
    }

    public void requestExternalStoragePermission() {
        String str = "android.permission.READ_EXTERNAL_STORAGE";
        if (ContextCompat.checkSelfPermission(this, str) == 0) {
            chooseImage();
        } else if (VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(this, new String[]{str}, 71);
        } else {
            chooseImage();
        }
    }

    private void showStoragePermissionRationale() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.PermissionsDialog);
        builder.setTitle(getString(R.string.permission_denied_title));
        builder.setMessage(getString(R.string.permission_denied_info));
        builder.setPositiveButton(getString(R.string.permission_denied_sure), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setNegativeButton(getString(R.string.permission_denied_retry), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                requestExternalStoragePermission();
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void chooseImage() {
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/jpeg", "image/png"});
        startActivityForResult(Intent.createChooser(intent, ""), 71);
    }

    private void ShowDialog() {
        AppCompatDialog appCompatDialog = new AppCompatDialog(this, this.dialogStyle);
        this.Dialog = appCompatDialog;
        appCompatDialog.setContentView(R.layout.dialog_click_theme);
        this.Dialog.setCanceledOnTouchOutside(true);
        Button btn_settheme = this.Dialog.findViewById(R.id.btn_settheme);
        Button btn_cancel = this.Dialog.findViewById(R.id.btn_cancel);

        this.Dialog.getWindow().setLayout(-1, -2);
        btn_settheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = 101;
                if (interstitialAd !=null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                }else {
                    if (selectOwnTheme) {
                        confgirueOwnTheme();
                    } else {
                        goBackAndLoadTheme(currentTheme);
                    }
                    Dialog.dismiss();
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog.dismiss();

            }
        });
        if (!this.Dialog.isShowing() && !isFinishing()) {
            this.Dialog.show();
        }
    }

    private void confgirueOwnTheme() {
        if (SettingsManager.getOwnBackground() == null) {
            requestExternalStoragePermission();
            return;
        }
        this.hasRemovedCustomTheme = true;
        SettingsManager.setOwnBackground(null);
        this.mThemesAdapter.notifyDataSetChanged();
    }

    public void onDestroy() {
        unregisterReceiver(this.myReceiver);
        super.onDestroy();
    }

    private FrameLayout adContainerView;
    private AdView adView;
    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {

        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id)
                {
                    case 100:
                        if (hasRemovedCustomTheme) {
                            currentTheme = null;
                            goBackAndLoadTheme(null);
                            return;
                        }
                        startActivity(new Intent(ThemeActivity.this, QuotesHomeActivity.class));
                        finish();
                        break;

                    case 101:
                        if (selectOwnTheme) {
                            confgirueOwnTheme();
                        } else {
                            goBackAndLoadTheme(currentTheme);
                        }
                        Dialog.dismiss();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(ThemeActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    public void onResume() {
        super.onResume();
    }

}
