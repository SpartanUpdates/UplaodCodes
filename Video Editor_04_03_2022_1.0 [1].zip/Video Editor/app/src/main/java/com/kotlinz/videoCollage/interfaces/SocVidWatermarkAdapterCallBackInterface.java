package com.kotlinz.videoCollage.interfaces;

public interface SocVidWatermarkAdapterCallBackInterface {
    void itemClick(int i);
}
