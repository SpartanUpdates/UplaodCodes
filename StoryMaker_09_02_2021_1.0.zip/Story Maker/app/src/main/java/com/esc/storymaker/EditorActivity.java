package com.esc.storymaker;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore.Images.Media;
import android.text.Editable;
import android.text.Layout.Alignment;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import butterknife.OnClick;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.github.florent37.shapeofview.ShapeOfView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.android.material.tabs.TabLayout.Tab;
import com.google.gson.Gson;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.jaredrummler.materialspinner.MaterialSpinner.OnItemSelectedListener;
import com.esc.storymaker.adapters.RvColorsAdapter;
import com.esc.storymaker.adapters.RvFontAdapter;
import com.esc.storymaker.adapters.RvGradientAdapter;
import com.esc.storymaker.fragments.FiltersFrag;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.mediapicker.Gallery;
import com.esc.storymaker.models.Draft;
import com.esc.storymaker.models.Draft.Photo;
import com.esc.storymaker.models.Draft.Text;
import com.esc.storymaker.models.Font;
import com.esc.storymaker.models.Glob_Sticker;
import com.esc.storymaker.models.Template;
import com.esc.storymaker.models.Template.Layout;
import com.esc.storymaker.utils.AnimationsUtil;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.BitmapUtil;
import com.esc.storymaker.utils.ContractsUtil;
import com.esc.storymaker.utils.DensityUtil;
import com.esc.storymaker.utils.FontProvider;
import com.esc.storymaker.utils.OnOneOffClickListener;
import com.esc.storymaker.utils.ScreenUtil;
import com.esc.storymaker.widgets.ImageStickerView;
import com.esc.storymaker.widgets.PhotoView;
import com.esc.storymaker.widgets.TextStickerView;
import com.esc.storymaker.widgets.TextStickerView.OperationListener;
import com.warkiz.widget.IndicatorSeekBar;
import com.warkiz.widget.OnSeekChangeListener;
import com.warkiz.widget.SeekParams;
import com.yalantis.ucrop.UCrop;

import devlight.io.library.ntb.NavigationTabBar;
import devlight.io.library.ntb.NavigationTabBar.Model;
import devlight.io.library.ntb.NavigationTabBar.Model.Builder;
import devlight.io.library.ntb.NavigationTabBar.OnTabBarSelectedIndexListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;

public class EditorActivity extends AppCompatActivity {
    protected static final Queue<Callable> actionQueue = new ConcurrentLinkedQueue();
    protected static final Handler handler = new Handler();
    protected static final Runnable runnable = new Runnable() {
        public void run() {
            Callable callable;
            do {
                callable = (Callable) EditorActivity.actionQueue.poll();
                if (callable != null) {
                    try {
                        callable.call();
                        continue;
                    } catch (Exception unused) {
                        continue;
                    }
                }
            } while (callable != null);
            EditorActivity.handler.postDelayed(this, 250);
        }
    };
    File A;
    String B;
    AppCompatActivity activity;
    private ArrayList<PhotoView> addedPhotos = new ArrayList();
    Alignment alignment;
    private ArrayList<ImageStickerView> allImageSticker = new ArrayList();
    private ArrayList<View> allLayouts = new ArrayList();
    private ArrayList<TextStickerView> allTextSticker = new ArrayList();
    @BindViews({R.id.sb_bg_scale, R.id.sb_bg_blur})
    List<IndicatorSeekBar> bgSeekBars;
    private int canvasHeight;
    private int canvasWidth;
    private int centreX;
    private int centreY;
    final String[] colorList;
    ConnectionDetector connectionDetector;
    private ImageStickerView currentImgSticker;
    private TextStickerView currentTextSticker;
    private Drawable d;
    private String[] directionsMenu;
    private Draft draft;
    private String draftFolder;
    private String draftJson;
    private ArrayList<String> draftPhotoIds = new ArrayList();
    private ArrayList<Text> draftTexts = new ArrayList();
    private String draftsPath;
    @BindView(R.id.et_text_editor)
    EditText etTextEditor;
    private ArrayList<ViewGroup> fabControllers = new ArrayList();
    private boolean firstLaunch;
    @BindView(R.id.fl_img_sticker)
    FrameLayout flImageSticker;
    @BindView(R.id.fl_layout)
    FrameLayout flLayout;
    @BindView(R.id.fl_text_sticker)
    FrameLayout flTextSticker;
    @BindView(R.id.fl_wrapper)
    FrameLayout flWrapper;
    private FragmentManager fm;
    private ArrayList<String> fontCategories = new ArrayList();
    private FontProvider fontProvider;
    private ArrayList<View> frameLayouts = new ArrayList();
    private String gradientTile;
    private String gradientType;
    private String gradientTypeBg;
    private ImageStickerView imgSticker;
    boolean isActivityLeft;
    private boolean isDraft;
    boolean isInternetPresent;
    private boolean isSaved;
    @BindView(R.id.iv_background)
    ImageView ivBackground;
    private String linearDirection;
    private String linearDirectionBg;
    private long mLastClickTime;
    private ArrayList<View> mediaMasks = new ArrayList();
    @BindView(R.id.sp_bg_gType)
    MaterialSpinner msgBgType;
    @BindView(R.id.sp_gType)
    MaterialSpinner msgType;
    @BindView(R.id.sp_pRepeat)
    MaterialSpinner mspRepeat;
    @BindView(R.id.sp_pTile)
    MaterialSpinner mspTile;
    @BindView(R.id.ntb_bg_editor)
    NavigationTabBar ntbBgEditor;
    @BindView(R.id.ntb_text_editor)
    NavigationTabBar ntbTextEditor;
    private String outputName;
    private RelativeLayout overlayClicked;
    private LayoutParams params;
    private String patternPath;
    private int patternRepeats;
    private TileMode patternTile1;
    private PhotoView photoClicked;
    private int photoTag;
    private ArrayList<JSONObject> photos;
    private SharedPreferences prefs;
    @BindView(R.id.rl_container)
    RelativeLayout rlContainer;
    @BindView(R.id.rv_bg_color)
    RecyclerView rvBgColors;
    private RvGradientAdapter rvBgGradientAdapter;
    @BindView(R.id.rv_bg_gradients)
    RecyclerView rvBgGradients;
    @BindView(R.id.rv_bg_pattern)
    RecyclerView rvBgPatterns;
    @BindView(R.id.rv_bg_pattern_menu)
    RecyclerView rvBgPatternsMenu;
    private RvColorsAdapter rvColorAdapter;
    @BindView(R.id.rv_text_color)
    RecyclerView rvColors;
    private RvFontAdapter rvFontAdapter;
    @BindView(R.id.rv_font_detail)
    RecyclerView rvFontDetail;
    private RvGradientAdapter rvGradientAdapter;
    @BindView(R.id.rv_gradients)
    RecyclerView rvGradients;
    @BindView(R.id.rv_text_pattern)
    RecyclerView rvPatterns;
    @BindView(R.id.rv_text_pattern_menu)
    RecyclerView rvPatternsMenu;
    private int saveHeight;
    private String savePath;
    private int saveWidth;
    private int screenHeight;
    private int screenWidth;
    private String selectedBgColor;
    private String[] selectedBgGradient;
    private String selectedBgPattern;
    private int selectedBtn;
    private ArrayList<Integer> selectedViewRatio = new ArrayList();
    @BindViews({R.id.sb_text_font_size, R.id.sb_text_opacity, R.id.sb_text_width_size, R.id.sb_text_height_size, R.id.sb_text_padding_left, R.id.sb_text_padding_right})
    List<IndicatorSeekBar> teSeekBars;
    private Template template;
    private String templateCategory;
    private String templateJson;
    private String templateName;
    private ViewGroup templateViewGroup;
    private ArrayList<Template.Text> templeteTexts = new ArrayList();
    private TextStickerView textSticker;
    private String[] tilesMenu;
    @BindView(R.id.tl_font_categories)
    TabLayout tlFontCategories;
    private int totalMemory;
    private TextStickerView touchTextSticker;
    private boolean txBtnClicked;
    @BindView(R.id.v_background)
    View vBgColor;
    @BindViews({R.id.wg_main_menu, R.id.wg_text_edit})
    List<View> vWidgets;
    @BindView(R.id.wg_text_edit)
    View wgTextEditor;
    int whichActivitytoStart = 0;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public class DragListener implements OnDragListener {
        public boolean onDrag(View view, DragEvent dragEvent) {
            View view2 = (View) dragEvent.getLocalState();
            int action = dragEvent.getAction();
            if (action != 1) {
                if (action == 3) {
                    ViewGroup viewGroup = (ViewGroup) view2.getParent().getParent();
                    FrameLayout frameLayout = (FrameLayout) viewGroup.getChildAt(0);
                    View childAt = viewGroup.getChildAt(1);
                    viewGroup.removeAllViews();
                    FrameLayout frameLayout2 = (FrameLayout) view;
                    ViewGroup viewGroup2 = (ViewGroup) frameLayout2.getParent();
                    if (viewGroup2 != null) {
                        View childAt2 = viewGroup2.getChildAt(1);
                        viewGroup2.removeAllViews();
                        viewGroup2.addView(frameLayout);
                        viewGroup2.addView(childAt);
                        viewGroup.addView(frameLayout2);
                        viewGroup.addView(childAt2);
                    } else {
                        viewGroup.addView(frameLayout);
                        viewGroup.addView(childAt);
                    }
                    view2.setVisibility(View.VISIBLE);
                    EditorActivity.this.addedPhotos = new ArrayList();
                    EditorActivity.this.photoTag = 0;
                    EditorActivity editorActivity = EditorActivity.this;
                    editorActivity.setMediaOptions(editorActivity.templateViewGroup, true);
                    editorActivity = EditorActivity.this;
                    editorActivity.updateMediaOrder(editorActivity.templateViewGroup);
                } else if (action == 5) {
                    view2.setVisibility(View.VISIBLE);
                }
            }
            return true;
        }
    }

    private class SaveDraft extends AsyncTask<String, String, JSONObject> {
        private Bitmap btmDraw;
        private String coverName;
        private boolean isPhoto;
        private String traceName;
        private int videoQuality;

        public SaveDraft(int i, boolean z, String str) {
            this.videoQuality = i;
            this.isPhoto = z;
            this.traceName = str;
        }

        public void onPreExecute() {
            super.onPreExecute();
            EditorActivity editorActivity = EditorActivity.this;
            editorActivity.setCurrentTextStickerEdit(false, editorActivity.currentTextSticker);
            editorActivity = EditorActivity.this;
            editorActivity.setCurrentImgStickerEdit(false, editorActivity.currentImgSticker);
            Iterator it = EditorActivity.this.fabControllers.iterator();
            while (it.hasNext()) {
                ((ViewGroup) it.next()).setVisibility(View.INVISIBLE);
            }
            EditorActivity.this.loading(true, this.isPhoto);
            EditorActivity.this.flWrapper.setDrawingCacheEnabled(true);
            EditorActivity.this.flWrapper.buildDrawingCache(true);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(EditorActivity.this.templateName);
            stringBuilder.append("-thumbnail-");
            stringBuilder.append(AppUtil.getCurrentTime());
            stringBuilder.append(".png");
            this.coverName = stringBuilder.toString();
            Bitmap drawingCache = EditorActivity.this.flWrapper.getDrawingCache();
            stringBuilder = new StringBuilder();
            stringBuilder.append(EditorActivity.this.draftsPath);
            String str = "/";
            stringBuilder.append(str);
            stringBuilder.append(EditorActivity.this.draftFolder);
            stringBuilder.append(str);
            BitmapUtil.savePhoto(drawingCache, stringBuilder.toString(), this.coverName, 600, 1066, true);
            if (EditorActivity.this.isDraft) {
                File file = new File(EditorActivity.this.draft.thumbnail);
                if (file.exists()) {
                    file.delete();
                }
                file = new File(EditorActivity.this.draft.save_path);
                if (file.exists()) {
                    file.delete();
                }
            }
            if (EditorActivity.this.isSaved) {
                this.btmDraw = BitmapUtil.createScaledBitmap(EditorActivity.this.flWrapper.getDrawingCache(), EditorActivity.this.saveWidth, EditorActivity.this.saveHeight, true);
            }
        }

        public JSONObject doInBackground(String... strArr) {
            String str = "gradient_type";
            String str2 = "/";
            JSONObject jSONObject = new JSONObject();
            try {
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                JSONObject jSONObject2;
                String str8;
                jSONObject.put("draft_name", EditorActivity.this.draftFolder);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(EditorActivity.this.draftsPath);
                stringBuilder.append(str2);
                stringBuilder.append(EditorActivity.this.draftFolder);
                stringBuilder.append(str2);
                stringBuilder.append(this.coverName);
                jSONObject.put("thumbnail", stringBuilder.toString());
                jSONObject.put("template_name", EditorActivity.this.templateName);
                jSONObject.put("template_category", EditorActivity.this.templateCategory);
                jSONObject.put("background_color", EditorActivity.this.selectedBgColor);
                jSONObject.put("background_gradient", EditorActivity.this.selectedBgGradient);
                jSONObject.put("gradient_linear_direction", EditorActivity.this.linearDirectionBg);
                jSONObject.put(str, EditorActivity.this.gradientTypeBg);
                jSONObject.put("background_photo", EditorActivity.this.selectedBgPattern);
                jSONObject.put("photo_scale", Float.valueOf(EditorActivity.this.ivBackground.getScaleX()));
                jSONObject.put("photo_blur", Integer.valueOf(((IndicatorSeekBar) EditorActivity.this.bgSeekBars.get(1)).getProgress()));
                jSONObject.put("saved", Boolean.valueOf(EditorActivity.this.isSaved));
                ArrayList arrayList = new ArrayList();
                Iterator it = EditorActivity.this.allTextSticker.iterator();
                while (true) {
                    str3 = "rotate";
                    str4 = "layout_y";
                    str5 = "layout_x";
                    str6 = "scale";
                    str7 = "id";
                    if (!it.hasNext()) {
                        break;
                    }
                    TextStickerView textStickerView = (TextStickerView) it.next();
                    jSONObject2 = new JSONObject();
                    jSONObject2.put(str7, textStickerView.getTag());
                    jSONObject2.put(str5, Integer.valueOf(textStickerView.getLayoutX()));
                    jSONObject2.put(str4, Integer.valueOf(textStickerView.getLayoutY()));
                    jSONObject2.put(str3, Float.valueOf(textStickerView.getRotateAngle()));
                    jSONObject2.put(str6, Float.valueOf(textStickerView.getScale()));
                    jSONObject2.put("paddingLeft", Integer.valueOf(textStickerView.getPaddingLeft()));
                    jSONObject2.put("paddingRight", Integer.valueOf(textStickerView.getPaddingRight()));
                    jSONObject2.put("opacity", Integer.valueOf(textStickerView.getOpacity()));
                    jSONObject2.put("text", textStickerView.getText());
                    jSONObject2.put("size", Float.valueOf(textStickerView.getFont().getSize()));
                    jSONObject2.put("color", Integer.valueOf(textStickerView.getFont().getColor()));
                    jSONObject2.put("font_category", textStickerView.getFont().getCategory());
                    jSONObject2.put("font_name", textStickerView.getFont().getTypeface());
                    jSONObject2.put("letter_spacing", Float.valueOf(textStickerView.getLetterSpacing()));
                    jSONObject2.put("line_spacing", Float.valueOf(textStickerView.getLineSpacing()));
                    jSONObject2.put("underline", Boolean.valueOf(textStickerView.isUnderLine()));
                    jSONObject2.put("strikethrough", Boolean.valueOf(textStickerView.isStrikethrough()));
                    jSONObject2.put("align", textStickerView.getAlign());
                    jSONObject2.put("gradient", AppUtil.strArrayToStr(textStickerView.getFont().getGradient(), " "));
                    jSONObject2.put(str, textStickerView.getFont().getGradientType());
                    jSONObject2.put("linear_direction", textStickerView.getFont().getLinearDirection());
                    jSONObject2.put("pattern_path", textStickerView.getFont().getPatternPath());
                    jSONObject2.put("pattern_mode", textStickerView.getFont().getPatternMode());
                    jSONObject2.put("pattern_repeats", Integer.valueOf(textStickerView.getFont().getPatternRepeats()));
                    arrayList.add(jSONObject2);
                }
                jSONObject.put("texts", arrayList);
                ArrayList arrayList2 = new ArrayList();
                Iterator it2 = EditorActivity.this.allImageSticker.iterator();
                while (true) {
                    str8 = "path";
                    if (!it2.hasNext()) {
                        break;
                    }
                    ImageStickerView imageStickerView = (ImageStickerView) it2.next();
                    imageStickerView.calculate();
                    jSONObject2 = new JSONObject();
                    jSONObject2.put(str7, Integer.valueOf(imageStickerView.getStickerId()));
                    jSONObject2.put(str8, imageStickerView.getStickerPath());
                    jSONObject2.put(str5, Float.valueOf(imageStickerView.getLayoutX()));
                    jSONObject2.put(str4, Float.valueOf(imageStickerView.getLayoutY()));
                    jSONObject2.put(str6, Float.valueOf(imageStickerView.getScale()));
                    jSONObject2.put(str3, Float.valueOf(imageStickerView.getRotate()));
                    arrayList2.add(jSONObject2);
                }
                jSONObject.put("stickers", arrayList2);
                arrayList2 = new ArrayList();
                it2 = EditorActivity.this.addedPhotos.iterator();
                while (it2.hasNext()) {
                    PhotoView photoView = (PhotoView) it2.next();
                    JSONObject jSONObject3 = new JSONObject();
                    jSONObject3.put(str7, photoView.getTag());
                    jSONObject3.put(str6, Float.valueOf(photoView.getScale()));
                    jSONObject3.put(str8, photoView.getPhotoPath());
                    arrayList2.add(jSONObject3);
                }
                jSONObject.put("photos", arrayList2);
                try {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(Environment.getExternalStorageDirectory().getPath());
                    stringBuilder2.append("/Android/data/");
                    stringBuilder2.append(EditorActivity.this.getPackageName());
                    stringBuilder2.append("/drafts/Json/");
                    str = stringBuilder2.toString();
                    if (!new File(str).exists()) {
                        new File(str).mkdirs();
                    }
                    if (EditorActivity.this.isDraft) {
                        str2 = EditorActivity.this.draft.save_path.replace(str, "");
                    } else {
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(EditorActivity.this.templateName);
                        stringBuilder3.append("-");
                        stringBuilder3.append(AppUtil.getCurrentTime());
                        stringBuilder3.append(".json");
                        str2 = stringBuilder3.toString();
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(str2);
                    jSONObject.put("save_path", stringBuilder.toString());
                    File file = new File(str, str2);
                    FileWriter fileWriter;
                    try {
                        fileWriter = new FileWriter(file);
                        fileWriter.write(jSONObject.toJSONString());
                        fileWriter.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    EditorActivity.this.draftJson = AppUtil.inputStreamToString(new FileInputStream(file));
                    Gson gson = new Gson();
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(str);
                    stringBuilder4.append(str2);
                    EditorActivity.this.draft = (Draft) gson.fromJson(AppUtil.inputStreamToString(new FileInputStream(new File(stringBuilder4.toString()))), Draft.class);
                    EditorActivity.this.removeUnusedFiles();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                if (EditorActivity.this.isSaved) {
                    EditorActivity.this.imageProcessing(this.btmDraw);
                }
            } catch (JSONException e3) {
                e3.printStackTrace();
            }
            return jSONObject;
        }

        public void onPostExecute(JSONObject jSONObject) {
            super.onPostExecute(jSONObject);
            if (EditorActivity.this.isSaved) {
                EditorActivity.this.flWrapper.setDrawingCacheEnabled(false);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(EditorActivity.this.savePath);
                stringBuilder.append("/");
                stringBuilder.append(EditorActivity.this.outputName);
                File file = new File(stringBuilder.toString());
                if (file.exists()) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("title", EditorActivity.this.outputName);
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(EditorActivity.this.getString(R.string.app_name));
                    stringBuilder2.append(" Application Android");
                    contentValues.put("description", stringBuilder2.toString());
                    contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
                    contentValues.put("bucket_id", Integer.valueOf(file.toString().toLowerCase(Locale.US).hashCode()));
                    contentValues.put("bucket_display_name", file.getName().toLowerCase(Locale.US));
                    contentValues.put("_data", file.getAbsolutePath());
                    EditorActivity.this.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, contentValues);
                    EditorActivity editorActivity = EditorActivity.this;
                    editorActivity.whichActivitytoStart = 1;
                    editorActivity.A = file;
                    editorActivity.B = editorActivity.draftJson;
                } else {
                    Context context = EditorActivity.this;
                    Toast.makeText(context, "" + getResources().getString(R.string.MSG_SOMETHING_WRONG), Toast.LENGTH_SHORT).show();
                }
                EditorActivity.this.loading(false, true);
                return;
            }
            EditorActivity.this.loading(false, this.isPhoto);
            EditorActivity.this.finish();
            EditorActivity.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    public class SavePhoto extends AsyncTask<String, String, File> {
        private Bitmap btmDraw;
        private int height;
        private String photoName;
        private String savePath;
        private boolean showLoading;
        private int width;

        public SavePhoto(String str, String str2, int i, int i2, boolean z) {
            this.savePath = str;
            this.photoName = str2;
            this.width = i;
            this.height = i2;
            this.showLoading = z;
        }

        public void onPreExecute() {
            super.onPreExecute();
            EditorActivity editorActivity = EditorActivity.this;
            editorActivity.setCurrentTextStickerEdit(false, editorActivity.currentTextSticker);
            editorActivity = EditorActivity.this;
            editorActivity.setCurrentImgStickerEdit(false, editorActivity.currentImgSticker);
            EditorActivity.this.flWrapper.setDrawingCacheEnabled(true);
            EditorActivity.this.flWrapper.buildDrawingCache(true);
            this.btmDraw = BitmapUtil.createScaledBitmap(EditorActivity.this.flWrapper.getDrawingCache(), this.width, this.height, true);
        }

        public File doInBackground(String... strArr) {
            File file = new File(this.savePath);
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file, this.photoName);
            if (file2.exists()) {
                file2.delete();
            }
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                this.btmDraw.compress(CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (this.showLoading) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("title", this.photoName);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(EditorActivity.this.getString(R.string.app_name));
                stringBuilder.append(" Application Android");
                contentValues.put("description", stringBuilder.toString());
                contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
                contentValues.put("bucket_id", Integer.valueOf(file2.toString().toLowerCase(Locale.US).hashCode()));
                contentValues.put("bucket_display_name", file2.getName().toLowerCase(Locale.US));
                contentValues.put("_data", file2.getAbsolutePath());
                EditorActivity.this.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, contentValues);
            }
            return file2;
        }

        public void onPostExecute(File file) {
            super.onPostExecute(file);
            if (this.showLoading) {
                EditorActivity.this.loading(false, true);
                if (file != null) {
                    EditorActivity.this.flWrapper.setDrawingCacheEnabled(false);
                    Intent intent = new Intent(EditorActivity.this, PreviewActivity.class);
                    intent.putExtra("savedImageFile", file);
                    intent.putExtra("draft", EditorActivity.this.draftJson);
                    EditorActivity.this.startActivity(intent);
                    EditorActivity.this.overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom);
                }
            }
        }
    }

    public EditorActivity() {
        String str = "#ffccbc";
        String str2 = "#ffab91";
        String str3 = "#ff8a65";
        String str4 = "#ff7043";
        String str5 = "#ff5722";
        String str6 = "#f4511e";
        String str7 = "#e64a19";
        String str8 = "#d84315";
        String str9 = "#bf360c";
        this.colorList = new String[]{"#ffffff", "#d9d9d9", "#c4c4c4", "#9d9d9d", "#7b7b7b", "#555555", "#434343", "#262626", "#e1bee7", "#ce93d8", "#ba68c8", "#ab47bc", "#9c27b0", "#8e24aa", "#7b1fa2", "#6a1b9a", "#4a148c", "#d1c4e9", "#b39ddb", "#9575cd", "#7e57c2", "#673ab7", "#5e35b1", "#512da8", "#4527a0", "#311b92", "#c5cae9", "#9fa8da", "#7986cb", "#5c6ac0", "#3f50b5", "#3948ab", "#303e9f", "#283493", "#1a227e", "#bbdefb", "#91cbf9", "#65b6f6", "#43a6f5", "#2397f3", "#1f89e5", "#1a77d2", "#1666c0", "#0d48a1", "#b3e5fc", "#82d5fa", "#50c4f7", "#2bb7f6", "#08aaf4", "#069ce5", "#0389d1", "#0378bd", "#01589b", "#b2ebf2", "#80dfea", "#4dd1e1", "#26c7da", "#00bdd4", "#00adc1", "#0098a7", "#00848f", "#006164", "#b2dfdb", "#80cbc4", "#4db6ac", "#26a69a", "#009688", "#00897b", "#00796b", "#00695c", "#004d40", "#c8e6c9", "#a5d6a7", "#81c784", "#66bb6a", "#4caf4f", "#43a046", "#388e3b", "#2e7d31", "#1b5e1f", "#dcedc8", "#c5e1a5", "#aed581", "#9ccc65", "#8bc34a", "#7cb342", "#689f38", "#558b2f", "#33691e", "#f0f4c3", "#e6ee9c", "#dce775", "#d4e157", "#cddc39", "#c0ca33", "#afb42b", "#9e9d24", "#827717", "#fff9c4", "#fff59d", "#fddb00", "#fceb55", "#fae635", "#fdd835", "#fbc02d", "#f9a825", "#f57f17", "#ffecb3", "#ffe082", "#ffd54f", "#ffca28", "#ffc106", "#ffb300", "#ffa000", "#ff8f00", "#ff6f00", "#ffe0b2", "#ffcc80", "#ffb74d", "#ffa726", "#ff9800", "#fb8c00", "#f57c00", "#ef6c00", "#e65100", str, str2, str3, str4, str5, str6, str7, str8, str9, str, str2, str3, str4, str5, str6, str7, str8, str9, "#ffcdd2", "#ef9a9a", "#e57373", "#ef5350", "#f44336", "#e53935", "#d32f2f", "#c62828", "#b71c1c", "#f8bbd0", "#f48fb1", "#f06292", "#ec407a", "#e91e63", "#d81b60", "#c2185b", "#ad1457", "#880e4f", "#d7ccc8", "#bcaaa4", "#a1887f", "#8d6e63", "#795548", "#6d4c41", "#5d4037", "#4e342e", "#3e2723", "#cfd8dc", "#b0bec5", "#90a4ae", "#78909c", "#607d8b", "#546e7a", "#455a64", "#37474f", "#263238"};
        String str10 = "Linear";
        this.directionsMenu = new String[]{str10, "Radial", "Sweep"};
        String str11 = "Clamp";
        this.tilesMenu = new String[]{str11, "Mirror", "Repeat"};
        this.selectedBgGradient = null;
        this.photoTag = 0;
        this.patternRepeats = 2;
        this.gradientTile = str11;
        this.gradientType = str10;
        String str12 = "Horizontal";
        this.linearDirection = str12;
        this.gradientTypeBg = str10;
        this.linearDirectionBg = str12;
        this.firstLaunch = true;
        this.patternTile1 = TileMode.MIRROR;
        this.params = new LayoutParams(-1, -1);
    }

    private void init() {
        AnimationsUtil.initAnimationsValue(this);
        this.fm = getSupportFragmentManager();
        this.totalMemory = AppUtil.getTotalMemory(this);
        this.prefs = getSharedPreferences("Data Holder", 0);
        this.screenWidth = ScreenUtil.getScreenWidth(this);
        this.screenHeight = ScreenUtil.getScreenHeight(this);
        this.fontProvider = new FontProvider(this, getResources());
        this.isSaved = getIntent().getBooleanExtra("IsDraft", false);
        this.isDraft = getIntent().getBooleanExtra("draft", false);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.DIRECTORY_PICTURES);
        stringBuilder.append("/");
        stringBuilder.append(getString(R.string.app_name).replace(" ", ""));
        this.savePath = Environment.getExternalStoragePublicDirectory(stringBuilder.toString()).getAbsolutePath();
        stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory().getPath());
        stringBuilder.append("/Android/data/");
        stringBuilder.append(getPackageName());
        stringBuilder.append("/drafts");
        this.draftsPath = stringBuilder.toString();
        this.flWrapper.post(new Runnable() {
            public void run() {
                StringBuilder stringBuilder;
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.canvasHeight = editorActivity.flWrapper.getMeasuredHeight();
                double access$2900 = (double) EditorActivity.this.canvasHeight;
                Double.isNaN(access$2900);
                EditorActivity editorActivity2 = EditorActivity.this;
                Double.isNaN(access$2900);
                editorActivity2.canvasWidth = (int) (access$2900 * 0.5625d);
                if (EditorActivity.this.canvasWidth >= EditorActivity.this.screenWidth) {
                    editorActivity = EditorActivity.this;
                    editorActivity.canvasWidth = (editorActivity.screenWidth * 90) / 100;
                    access$2900 = (double) EditorActivity.this.canvasWidth;
                    Double.isNaN(access$2900);
                    editorActivity2 = EditorActivity.this;
                    Double.isNaN(access$2900);
                    editorActivity2.canvasHeight = (int) (access$2900 * 1.7777777777777777d);
                }
                ViewGroup.LayoutParams layoutParams = EditorActivity.this.flWrapper.getLayoutParams();
                layoutParams.width = EditorActivity.this.canvasWidth;
                layoutParams.height = EditorActivity.this.canvasHeight;
                EditorActivity.this.flWrapper.setLayoutParams(layoutParams);
                editorActivity = EditorActivity.this;
                editorActivity.centreX = (int) (editorActivity.flWrapper.getX() + ((float) (EditorActivity.this.flWrapper.getWidth() / 2)));
                editorActivity = EditorActivity.this;
                editorActivity.centreY = (int) (editorActivity.flWrapper.getY() + ((float) (EditorActivity.this.flWrapper.getHeight() / 2)));
                if (EditorActivity.this.isDraft) {
                    EditorActivity.this.setupDraft();
                } else {
                    EditorActivity.this.setupTemplate();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("draft-");
                    stringBuilder.append(AppUtil.getCurrentTime());
                    EditorActivity.this.draftFolder = stringBuilder.toString();
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(EditorActivity.this.draftsPath);
                String str = "/";
                stringBuilder.append(str);
                stringBuilder.append(EditorActivity.this.draftFolder);
                stringBuilder.append(str);
                File file = new File(stringBuilder.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                EditorActivity.this.initTextEntitiesListeners();
                EditorActivity.this.setBackgroundListeners();
                EditorActivity.this.setCustomColorListeners();
            }
        });
        this.mLastClickTime = System.currentTimeMillis();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_editor);
        ButterKnife.bind(this);
        this.isActivityLeft = false;
        this.activity = this;
        this.connectionDetector = new ConnectionDetector(getApplicationContext());
        this.isInternetPresent = this.connectionDetector.isConnectingToInternet();
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        BannerAds();
        addTemplate();
        init();
        replaceScreen();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addTemplate() {
        this.templateCategory = getIntent().getStringExtra("category");
        this.templateName = getIntent().getStringExtra("template");
        flLayout.removeAllViewsInLayout();
        this.templateViewGroup = (ViewGroup) LayoutInflater.from(this).inflate(((Integer) ContractsUtil.initTemplates(this.templateCategory).get(this.templateName)).intValue(), this.flLayout, false);
        this.flLayout.addView(this.templateViewGroup);
        this.flLayout.setBackgroundColor(0);
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Templates/");
            stringBuilder.append(this.templateName);
            stringBuilder.append(".json");
            this.templateJson = AppUtil.inputStreamToString(assets.open(stringBuilder.toString()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < this.templateViewGroup.getChildCount(); i++) {
            ViewGroup viewGroup = (ViewGroup) this.templateViewGroup.getChildAt(i);
            this.allLayouts.add(viewGroup);
            if (viewGroup.getChildAt(0) instanceof ShapeOfView) {
                ShapeOfView shapeOfView = (ShapeOfView) viewGroup.getChildAt(0);
                if ((shapeOfView.getChildAt(0) instanceof FrameLayout) && (((FrameLayout) shapeOfView.getChildAt(0)).getChildAt(0) instanceof PhotoView)) {
                    this.frameLayouts.add(viewGroup);
                }
            }
        }
        this.template = (Template) new Gson().fromJson(this.templateJson, Template.class);
    }

    public void setupTemplate() {
        boolean z;
        EditorActivity editorActivity = this;
        editorActivity.setMediaOptions(editorActivity.templateViewGroup, false);
        editorActivity.templeteTexts = editorActivity.template.texts;
        int i = 0;
        while (i < editorActivity.templeteTexts.size()) {
            int i2;
            Font font = new Font();
            font.setColor(Color.parseColor(((Template.Text) editorActivity.templeteTexts.get(i)).color));
            font.setSize(((Template.Text) editorActivity.templeteTexts.get(i)).size);
            font.setCategory(((Template.Text) editorActivity.templeteTexts.get(i)).font_category);
            font.setTypeface(((Template.Text) editorActivity.templeteTexts.get(i)).font_name);
            font.setGradient(AppUtil.strTOStrArray(((Template.Text) editorActivity.templeteTexts.get(i)).gradient, " "));
            font.setGradientType(((Template.Text) editorActivity.templeteTexts.get(i)).gradient_type);
            font.setLinearDirection(((Template.Text) editorActivity.templeteTexts.get(i)).linear_direction);
            font.setPatternPath(((Template.Text) editorActivity.templeteTexts.get(i)).pattern_path);
            font.setPatternMode(((Template.Text) editorActivity.templeteTexts.get(i)).pattern_mode);
            font.setPatternRepeats(((Template.Text) editorActivity.templeteTexts.get(i)).pattern_repeats);
            editorActivity.alignment = Alignment.ALIGN_CENTER;
            String str = ((Template.Text) editorActivity.templeteTexts.get(i)).align;
            int i3;
            TextStickerView textStickerView;
            int i4;
            int i5;
            String str2;
            int i6;
            float f;
            float f2;
            int i7;
            int i8;
            Alignment alignment;
            int i9;
            int i10;
            if (str.contains("right")) {
                editorActivity.alignment = Alignment.ALIGN_NORMAL;
                i3 = ((Template.Text) editorActivity.templeteTexts.get(i)).layout_id;
                editorActivity.textSticker = new TextStickerView(editorActivity, editorActivity.canvasWidth, editorActivity.canvasHeight, editorActivity.fontProvider);
                if (((Template.Text) editorActivity.templeteTexts.get(i)).position.bottom != null) {
                    textStickerView = (TextStickerView) editorActivity.allTextSticker.get(Integer.parseInt(((Template.Text) editorActivity.templeteTexts.get(i)).position.bottom));
                    i3 = (int) (((textStickerView.getTextCenterY() + ((float) ((textStickerView.getTextHeight() * 70) / 100))) + ((float) DensityUtil.dp2px(editorActivity, (float) ((Template.Text) editorActivity.templeteTexts.get(i)).margin_top))) - ((float) DensityUtil.dp2px(editorActivity, (float) ((Template.Text) editorActivity.templeteTexts.get(i)).margin_bottom)));
                } else {
                    i3 = (int) ((((float) editorActivity.canvasHeight) * ((Template.Text) editorActivity.templeteTexts.get(i)).layout_y) / 100.0f);
                }
                i4 = i3;
                i5 = ((Template.Text) editorActivity.templeteTexts.get(i)).id;
                str2 = ((Template.Text) editorActivity.templeteTexts.get(i)).text;
                i6 = (int) ((((float) editorActivity.canvasWidth) * ((Template.Text) editorActivity.templeteTexts.get(i)).layout_x) / 100.0f);
                f = ((Template.Text) editorActivity.templeteTexts.get(i)).rotate;
                f2 = ((Template.Text) editorActivity.templeteTexts.get(i)).scale;
                i7 = ((Template.Text) editorActivity.templeteTexts.get(i)).padding_left;
                i8 = ((Template.Text) editorActivity.templeteTexts.get(i)).padding_right;
                alignment = editorActivity.alignment;
                i9 = ((Template.Text) editorActivity.templeteTexts.get(i)).opacity;
                boolean z2 = ((Template.Text) editorActivity.templeteTexts.get(i)).underLine;
                boolean z3 = ((Template.Text) editorActivity.templeteTexts.get(i)).strikethrough;
                boolean z4 = z2;
                i10 = i;
                createTextStickView(i5, str2, font, i6, i4, f, f2, i7, i8, alignment, i9, z4, z3, (float) ((Template.Text) editorActivity.templeteTexts.get(i)).letter_spacing, (float) ((Template.Text) editorActivity.templeteTexts.get(i)).line_spacing);
                i2 = i10;
            } else {
                int i11;
                i10 = i;
                int i12;
                boolean z5;
                boolean z6;
                if (str.contains("center")) {
                    i12 = i10;
                    i3 = ((Template.Text) this.templeteTexts.get(i12)).layout_id;
                    this.textSticker = new TextStickerView(this, this.canvasWidth, this.canvasHeight, this.fontProvider);
                    if (((Template.Text) this.templeteTexts.get(i12)).position.bottom != null) {
                        textStickerView = (TextStickerView) this.allTextSticker.get(Integer.parseInt(((Template.Text) this.templeteTexts.get(i12)).position.bottom));
                        i3 = (int) (((textStickerView.getTextCenterY() + ((float) ((textStickerView.getTextHeight() * 70) / 100))) + ((float) DensityUtil.dp2px(this, (float) ((Template.Text) this.templeteTexts.get(i12)).margin_top))) - ((float) DensityUtil.dp2px(this, (float) ((Template.Text) this.templeteTexts.get(i12)).margin_bottom)));
                    } else {
                        i3 = (int) ((((float) this.canvasHeight) * ((Template.Text) this.templeteTexts.get(i12)).layout_y) / 100.0f);
                    }
                    i4 = i3;
                    i5 = ((Template.Text) this.templeteTexts.get(i12)).id;
                    str2 = ((Template.Text) this.templeteTexts.get(i12)).text;
                    i6 = (int) ((((float) this.canvasWidth) * ((Template.Text) this.templeteTexts.get(i12)).layout_x) / 100.0f);
                    f = ((Template.Text) this.templeteTexts.get(i12)).rotate;
                    f2 = ((Template.Text) this.templeteTexts.get(i12)).scale;
                    i7 = ((Template.Text) this.templeteTexts.get(i12)).padding_left;
                    i8 = ((Template.Text) this.templeteTexts.get(i12)).padding_right;
                    alignment = this.alignment;
                    i9 = ((Template.Text) this.templeteTexts.get(i12)).opacity;
                    z5 = ((Template.Text) this.templeteTexts.get(i12)).underLine;
                    z6 = ((Template.Text) this.templeteTexts.get(i12)).strikethrough;
                    i11 = i12;
                    createTextStickView(i5, str2, font, i6, i4, f, f2, i7, i8, alignment, i9, z5, z6, (float) ((Template.Text) this.templeteTexts.get(i12)).letter_spacing, (float) ((Template.Text) this.templeteTexts.get(i12)).line_spacing);
                } else {
                    i11 = i10;
                    if (str.contains("left")) {
                        i12 = i11;
                        i3 = ((Template.Text) this.templeteTexts.get(i12)).layout_id;
                        this.textSticker = new TextStickerView(this, this.canvasWidth, this.canvasHeight, this.fontProvider);
                        if (((Template.Text) this.templeteTexts.get(i12)).position.bottom != null) {
                            textStickerView = (TextStickerView) this.allTextSticker.get(Integer.parseInt(((Template.Text) this.templeteTexts.get(i12)).position.bottom));
                            i3 = (int) (((textStickerView.getTextCenterY() + ((float) ((textStickerView.getTextHeight() * 70) / 100))) + ((float) DensityUtil.dp2px(this, (float) ((Template.Text) this.templeteTexts.get(i12)).margin_top))) - ((float) DensityUtil.dp2px(this, (float) ((Template.Text) this.templeteTexts.get(i12)).margin_bottom)));
                        } else {
                            i3 = (int) ((((float) this.canvasHeight) * ((Template.Text) this.templeteTexts.get(i12)).layout_y) / 100.0f);
                        }
                        i4 = i3;
                        i5 = ((Template.Text) this.templeteTexts.get(i12)).id;
                        str2 = ((Template.Text) this.templeteTexts.get(i12)).text;
                        i6 = (int) ((((float) this.canvasWidth) * ((Template.Text) this.templeteTexts.get(i12)).layout_x) / 100.0f);
                        f = ((Template.Text) this.templeteTexts.get(i12)).rotate;
                        f2 = ((Template.Text) this.templeteTexts.get(i12)).scale;
                        i7 = ((Template.Text) this.templeteTexts.get(i12)).padding_left;
                        i8 = ((Template.Text) this.templeteTexts.get(i12)).padding_right;
                        alignment = this.alignment;
                        i9 = ((Template.Text) this.templeteTexts.get(i12)).opacity;
                        z5 = ((Template.Text) this.templeteTexts.get(i12)).underLine;
                        z6 = ((Template.Text) this.templeteTexts.get(i12)).strikethrough;
                        String str3 = str2;
                        int i13 = i6;
                        float f3 = f;
                        f = f2;
                        int i14 = i7;
                        i7 = i8;
                        Alignment alignment2 = alignment;
                        int i15 = i9;
                        boolean z7 = z5;
                        z5 = z6;
                        i2 = i12;
                        createTextStickView(i5, str3, font, i13, i4, f3, f, i14, i7, alignment2, i15, z7, z5, (float) ((Template.Text) this.templeteTexts.get(i12)).letter_spacing, (float) ((Template.Text) this.templeteTexts.get(i12)).line_spacing);
                    }
                }
                i2 = i11;
            }
            i = i2 + 1;
            editorActivity = this;
        }
        EditorActivity editorActivity2 = editorActivity;
        editorActivity2.selectedBgColor = editorActivity2.template.background_color;
        editorActivity2.selectedBgGradient = editorActivity2.template.background_gradient;
        if (editorActivity2.selectedBgColor != null) {
            editorActivity2.ivBackground.setVisibility(View.GONE);
            editorActivity2.vBgColor.setBackgroundColor(Color.parseColor(editorActivity2.selectedBgColor));
        } else if (editorActivity2.selectedBgGradient != null) {
            editorActivity2.ivBackground.setVisibility(View.GONE);
            editorActivity2.gradientTypeBg = editorActivity2.template.gradient_type;
            editorActivity2.linearDirectionBg = editorActivity2.template.gradient_linear_direction;
            editorActivity2.changeBackground(null, editorActivity2.selectedBgGradient, null);
        } else {
            editorActivity2.findViewById(R.id.menu_background).setVisibility(View.GONE);
            setRoundedRect();
            z = false;
            editorActivity2.firstLaunch = false;
            setRoundedRect();
            editorActivity2.firstLaunch = z;
        }
        z = false;
        setRoundedRect();
        editorActivity2.firstLaunch = z;
    }

    public void setupDraft() {
        Exception e;
        EditorActivity editorActivity = this;
        EditorActivity editorActivity2;
        try {
            boolean z;
            editorActivity.draft = (Draft) new Gson().fromJson(AppUtil.inputStreamToString(new FileInputStream(new File(getIntent().getStringExtra("savePath")))), Draft.class);
            Iterator it = editorActivity.draft.photos.iterator();
            while (it.hasNext()) {
                editorActivity.draftPhotoIds.add(((Photo) it.next()).id);
            }
            editorActivity.setMediaOptions(editorActivity.templateViewGroup, false);
            editorActivity.draftFolder = editorActivity.draft.draft_name;
            editorActivity.draftTexts = editorActivity.draft.texts;
            if (editorActivity.draftTexts != null) {
                int i = 0;
                while (i < editorActivity.draftTexts.size()) {
                    int i2;
                    try {
                        Font font = new Font();
                        font.setColor(((Text) editorActivity.draftTexts.get(i)).color);
                        font.setSize(((Text) editorActivity.draftTexts.get(i)).size);
                        font.setCategory(((Text) editorActivity.draftTexts.get(i)).font_category);
                        font.setTypeface(((Text) editorActivity.draftTexts.get(i)).font_name);
                        font.setGradient(AppUtil.strTOStrArray(((Text) editorActivity.draftTexts.get(i)).gradient, " "));
                        font.setGradientType(((Text) editorActivity.draftTexts.get(i)).gradient_type);
                        font.setLinearDirection(((Text) editorActivity.draftTexts.get(i)).linear_direction);
                        font.setPatternPath(((Text) editorActivity.draftTexts.get(i)).pattern_path);
                        font.setPatternMode(((Text) editorActivity.draftTexts.get(i)).pattern_mode);
                        font.setPatternRepeats(((Text) editorActivity.draftTexts.get(i)).pattern_repeats);
                        Alignment alignment = Alignment.ALIGN_CENTER;
                        String str = ((Text) editorActivity.draftTexts.get(i)).align;
                        int i3 = 65535;
                        int hashCode = str.hashCode();
                        if (hashCode != -1371700497) {
                            if (hashCode != -1047432319) {
                                if (hashCode == 1015327489 && str.equals("ALIGN_OPPOSITE")) {
                                    i3 = 2;
                                }
                            } else if (str.equals("ALIGN_NORMAL")) {
                                i3 = 0;
                            }
                        } else if (str.equals("ALIGN_CENTER")) {
                            i3 = 1;
                        }
                        if (i3 == 0) {
                            alignment = Alignment.ALIGN_NORMAL;
                        } else if (i3 == 1) {
                            alignment = Alignment.ALIGN_CENTER;
                        } else if (i3 == 2) {
                            alignment = Alignment.ALIGN_OPPOSITE;
                        }
                        Alignment alignment2 = alignment;
                        int i4 = ((Text) editorActivity.draftTexts.get(i)).padding_left;
                        ((Text) editorActivity.draftTexts.get(i)).padding_left = (((Text) editorActivity.draftTexts.get(i)).padding_left * Callback.DEFAULT_DRAG_ANIMATION_DURATION) / editorActivity.canvasWidth;
                        ((Text) editorActivity.draftTexts.get(i)).padding_right = (((Text) editorActivity.draftTexts.get(i)).padding_right * Callback.DEFAULT_DRAG_ANIMATION_DURATION) / editorActivity.canvasWidth;
                        float f = (float) ((Text) editorActivity.draftTexts.get(i)).letter_spacing;
                        int i5 = ((Text) editorActivity.draftTexts.get(i)).id;
                        String str2 = ((Text) editorActivity.draftTexts.get(i)).text;
                        hashCode = ((Text) editorActivity.draftTexts.get(i)).layout_x;
                        int i6 = ((Text) editorActivity.draftTexts.get(i)).layout_y;
                        float f2 = ((Text) editorActivity.draftTexts.get(i)).rotate;
                        float f3 = ((Text) editorActivity.draftTexts.get(i)).scale;
                        int i7 = ((Text) editorActivity.draftTexts.get(i)).padding_left;
                        int i8 = ((Text) editorActivity.draftTexts.get(i)).padding_right;
                        int i9 = ((Text) editorActivity.draftTexts.get(i)).opacity;
                        boolean z2 = ((Text) editorActivity.draftTexts.get(i)).underLine;
                        i2 = i;
                        try {
                            createTextStickView(i5, str2, font, hashCode, i6, f2, f3, i7, i8, alignment2, i9, z2, ((Text) editorActivity.draftTexts.get(i)).strikethrough, f, (float) ((Text) editorActivity.draftTexts.get(i)).line_spacing);
                            i = i2 + 1;
                            editorActivity = this;
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }
                }
                editorActivity2 = editorActivity;
                try {
                    editorActivity2.selectedBgColor = editorActivity2.draft.background_color;
                    editorActivity2.selectedBgGradient = editorActivity2.draft.background_gradient;
                    editorActivity2.selectedBgPattern = editorActivity2.draft.background_photo;
                    if (editorActivity2.selectedBgColor != null) {
                        editorActivity2.ivBackground.setVisibility(View.GONE);
                        editorActivity2.vBgColor.setBackgroundColor(Color.parseColor(editorActivity2.selectedBgColor));
                    } else if (editorActivity2.selectedBgGradient != null) {
                        editorActivity2.ivBackground.setVisibility(View.GONE);
                        editorActivity2.gradientTypeBg = editorActivity2.draft.gradient_type;
                        editorActivity2.linearDirectionBg = editorActivity2.draft.gradient_linear_direction;
                        editorActivity2.changeBackground(null, editorActivity2.selectedBgGradient, null);
                    } else if (editorActivity2.selectedBgPattern != null) {
                        z = false;
                        try {
                            editorActivity2.ivBackground.setVisibility(View.VISIBLE);
                            BitmapUtil.applyBlur(editorActivity2, editorActivity2.selectedBgPattern, ((IndicatorSeekBar) editorActivity2.bgSeekBars.get(1)).getProgress(), editorActivity2.ivBackground);
                            editorActivity2.ivBackground.setScaleX(editorActivity2.draft.photo_scale);
                            editorActivity2.ivBackground.setScaleY(editorActivity2.draft.photo_scale);
                            ((IndicatorSeekBar) editorActivity2.bgSeekBars.get(0)).setProgress((editorActivity2.draft.photo_scale - 1.0f) * 100.0f);
                            ((IndicatorSeekBar) editorActivity2.bgSeekBars.get(1)).setProgress((float) editorActivity2.draft.photo_blur);
                            setRoundedRect();
                            editorActivity2.firstLaunch = false;
                        } catch (Exception e5) {
                            e = e5;
                        }
                        setRoundedRect();
                        editorActivity2.firstLaunch = z;
                    }
                } catch (Exception e6) {
                    e6.printStackTrace();
                }
            }
            editorActivity2 = editorActivity;
            z = false;
            setRoundedRect();
            editorActivity2.firstLaunch = z;
        } catch (Exception e8) {
            e8.printStackTrace();
        }
    }

    private void setRoundedRect() {
        for (int i = 0; i < this.allLayouts.size(); i++) {
            if (((Layout) this.template.layouts.get(i)).rounded_rect) {
                ViewGroup viewGroup = (ViewGroup) this.allLayouts.get(i);
                if (viewGroup.getChildAt(0) instanceof ShapeOfView) {
                    ((ShapeOfView) viewGroup.getChildAt(0)).setDrawable(AppUtil.getRoundedRect(this, getResources().getColor(R.color.colorWhite), ((Layout) this.template.layouts.get(i)).topLeftRadius, ((Layout) this.template.layouts.get(i)).topRightRadius, ((Layout) this.template.layouts.get(i)).bottomLeftRadius, ((Layout) this.template.layouts.get(i)).bottomRightRadius));
                }
            }
        }
    }

    private void setMediaOptions(ViewGroup viewGroup, boolean z) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt instanceof ShapeOfView) {
                ShapeOfView shapeOfView = (ShapeOfView) childAt;
                shapeOfView.setDrawingCacheEnabled(false);
                shapeOfView.buildDrawingCache(false);
                if (shapeOfView.getChildCount() > 1 && !shapeOfView.getChildAt(1).isShown()) {
                    this.mediaMasks.add(shapeOfView.getChildAt(1));
                }
            }
            boolean z2 = childAt instanceof PhotoView;
            if (z2) {
                final PhotoView photoView = (PhotoView) childAt;
                photoView.setTag(Integer.valueOf(this.photoTag));
                this.photoTag++;
                if (!z && this.isDraft && this.draftPhotoIds.contains(photoView.getTag().toString())) {
                    String str = ((Photo) this.draft.photos.get(this.draftPhotoIds.indexOf(photoView.getTag().toString()))).path;
                    Bitmap decodeFile = BitmapFactory.decodeFile(str, null);
                    this.addedPhotos.add(photoView);
                    photoView.setFullScreen(true, false);
                    photoView.enableImageTransforms(true);
                    photoView.setCenterCropScaleType(true);
                    photoView.bindPhoto(decodeFile);
                    photoView.setPhotoPath(str);
                    photoView.setVisibility(View.VISIBLE);
                }
                ViewGroup viewGroup2 = (ViewGroup) photoView.getParent();
                viewGroup2.setOnDragListener(new DragListener());
                final ViewGroup viewGroup3 = (ViewGroup) viewGroup2.getParent().getParent();
                final ViewGroup viewGroup4 = (ViewGroup) ((ViewGroup) viewGroup3.getChildAt(2)).getChildAt(0);
                this.fabControllers.add(viewGroup4);
                for (int i2 = 0; i2 < this.allLayouts.size(); i2++) {
                    if (((View) this.allLayouts.get(i2)).equals(viewGroup3)) {
                        photoView.setPhotoRotation(((Layout) this.template.layouts.get(i2)).rotation);
                    }
                }
                photoView.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        if (!EditorActivity.this.txBtnClicked) {
                            EditorActivity.this.isClickable();
                            EditorActivity.this.hideControllersFab(viewGroup4);
                            EditorActivity editorActivity = EditorActivity.this;
                            editorActivity.setCurrentTextStickerEdit(false, editorActivity.currentTextSticker);
                            EditorActivity editorActivity2 = EditorActivity.this;
                            editorActivity2.setCurrentImgStickerEdit(false, editorActivity2.currentImgSticker);
                            EditorActivity.this.photoClicked = photoView;
                            if (viewGroup4.isShown()) {
                                viewGroup4.setVisibility(View.GONE);
                                return;
                            }
                            viewGroup4.setVisibility(View.VISIBLE);
                            viewGroup4.getChildAt(0).setOnClickListener(new OnClickListener() {
                                public void onClick(View view) {
                                    EditorActivity.this.isClickable();
                                    EditorActivity.this.addedPhotos.remove(EditorActivity.this.photoClicked);
                                    EditorActivity.this.photoClicked.clearDrawable();
                                    viewGroup4.setVisibility(View.INVISIBLE);
                                    viewGroup3.getChildAt(1).setVisibility(View.VISIBLE);
                                    EditorActivity.this.photoClicked.setVisibility(View.INVISIBLE);
                                    EditorActivity.this.photoClicked = null;
                                }
                            });
                            viewGroup4.getChildAt(1).setOnClickListener(new OnClickListener() {
                                public void onClick(View view) {
                                    if (AppUtil.permissionGranted(EditorActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) && AppUtil.permissionGranted(EditorActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                                        EditorActivity.this.findViewById(R.id.fl_fragment).setVisibility(View.VISIBLE);
                                        EditorActivity.this.addFragment(FiltersFrag.getInstance(EditorActivity.this.photoClicked.getPhoto()), R.id.fl_fragment, 0, 0);
                                    }
                                }
                            });
                            viewGroup4.getChildAt(1).setVisibility(View.INVISIBLE);
                        }
                    }
                });
            }
            if (z2) {
                PhotoView photoView2 = (PhotoView) childAt;
                final ViewGroup viewGroup5 = (ViewGroup) photoView2.getParent();
                final ViewGroup viewGroup6 = (ViewGroup) ((ViewGroup) viewGroup5.getParent()).getParent();
                if (viewGroup6.getChildAt(1) instanceof RelativeLayout) {
                    viewGroup6.getChildAt(1).setOnClickListener(new OnOneOffClickListener() {
                        public void onOneClick(View view) {
                            if (!EditorActivity.this.txBtnClicked) {
                                EditorActivity.this.isClickable();
                                EditorActivity.this.hideControllersFab(null);
                                EditorActivity.this.overlayClicked = (RelativeLayout) viewGroup6.getChildAt(1);
                                EditorActivity editorActivity = EditorActivity.this;
                                editorActivity.setCurrentTextStickerEdit(false, editorActivity.currentTextSticker);
                                EditorActivity editorActivity2 = EditorActivity.this;
                                editorActivity2.setCurrentImgStickerEdit(false, editorActivity2.currentImgSticker);
                                EditorActivity.this.photoClicked = (PhotoView) viewGroup5.getChildAt(0);
                                EditorActivity editorActivity3 = EditorActivity.this;
                                editorActivity3.selectedViewRatio = AppUtil.convertDecimalToFraction((float) editorActivity3.overlayClicked.getMeasuredWidth(), (float) EditorActivity.this.overlayClicked.getMeasuredHeight());
                                Intent intent = new Intent(EditorActivity.this, Gallery.class);
                                intent.putExtra("title", "Select media");
                                intent.putExtra("mode", 0);
                                intent.putExtra("maxSelection", 1);
                                EditorActivity.this.startActivityForResult(intent, 0);
                                reset();
                            }
                        }
                    });
                }
                if (viewGroup5.getChildAt(0).isShown() || photoView2.isShown()) {
                    viewGroup6.getChildAt(1).setVisibility(View.INVISIBLE);
                }
            } else if (childAt instanceof ViewGroup) {
                setMediaOptions((ViewGroup) childAt, z);
            }
        }
    }

    public void updateMediaOrder(ViewGroup viewGroup) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childAt = viewGroup.getChildAt(i);
            if (childAt instanceof PhotoView) {
                PhotoView photoView = (PhotoView) childAt;
                if (photoView.isShown() && photoView.isShown()) {
                    this.addedPhotos.add(photoView);
                }
            } else if (childAt instanceof ViewGroup) {
                updateMediaOrder((ViewGroup) childAt);
            }
        }
    }

    public void setSelectedPhoto(Bitmap bitmap) {
        if (bitmap != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("photo-");
            stringBuilder.append(AppUtil.getCurrentTime());
            stringBuilder.append(".png");
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(this.draftsPath);
            String str = "/";
            stringBuilder3.append(str);
            stringBuilder3.append(this.draftFolder);
            stringBuilder3.append(str);
            String stringBuilder4 = stringBuilder3.toString();
            BitmapUtil.savePhoto(bitmap, stringBuilder4, stringBuilder2);
            PhotoView photoView = this.photoClicked;
            if (photoView != null) {
                photoView.setVisibility(View.VISIBLE);
            }
            this.overlayClicked.setVisibility(View.INVISIBLE);
            photoView = this.photoClicked;
            if (photoView != null) {
                this.addedPhotos.add(photoView);
                this.photoClicked.setFullScreen(true, false);
                this.photoClicked.enableImageTransforms(true);
                this.photoClicked.setCenterCropScaleType(true);
                this.photoClicked.bindPhoto(bitmap);
                PhotoView photoView2 = this.photoClicked;
                StringBuilder stringBuilder5 = new StringBuilder();
                stringBuilder5.append(stringBuilder4);
                stringBuilder5.append(stringBuilder2);
                photoView2.setPhotoPath(stringBuilder5.toString());
            }
        }
        onBackPressed();
    }

    private void createTextStickView(int i, String str, Font font, int i2, int i3, float f, float f2, int i4, int i5, Alignment alignment, int i6, boolean z, boolean z2, float f3, float f4) {
        this.textSticker = new TextStickerView(this, this.canvasWidth, this.canvasHeight, this.fontProvider);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.addRule(10);
        this.textSticker.setLayoutParams(layoutParams);
        String str2 = str;
        this.textSticker.setText(str);
        int i7 = i2;
        this.textSticker.setLayoutX(i2);
        i7 = i3;
        this.textSticker.setLayoutY(i3);
        float f5 = f;
        this.textSticker.setRotateAngle(f);
        f5 = f2;
        this.textSticker.setScale(f2);
        i7 = i4;
        this.textSticker.setPaddingLeft(i4);
        i7 = i5;
        this.textSticker.setPaddingRight(i5);
        Font font2 = font;
        this.textSticker.setFont(font);
        Alignment alignment2 = alignment;
        this.textSticker.setAlign(alignment);
        this.textSticker.setOpacity(i6);
        this.textSticker.setUnderLine(z);
        this.textSticker.setStrikethrough(z2);
        this.textSticker.setLetterSpacing(f3);
        this.textSticker.setLineSpacing(f4);
        this.textSticker.setTag(Integer.valueOf(i));
        this.textSticker.setOperationListener(new OperationListener() {
            public void onUnselect(TextStickerView textStickerView) {
            }

            public void onDelete(TextStickerView textStickerView) {
                if (EditorActivity.this.currentTextSticker != null && textStickerView.getTag().equals(EditorActivity.this.currentTextSticker.getTag()) && textStickerView.isShowHelpBox()) {
                    if (EditorActivity.this.wgTextEditor.isShown()) {
                        EditorActivity.this.setCurrentTextStickerEdit(false, textStickerView);
                    }
                    EditorActivity.this.flTextSticker.removeView(textStickerView);
                    EditorActivity.this.allTextSticker.remove(textStickerView);
                }
                EditorActivity.this.setTxBtnClicked();
            }

            public void onEdit(TextStickerView textStickerView) {
                EditorActivity.this.bgClose();
                EditorActivity.this.setCurrentTextStickerEdit(true, textStickerView);
                EditorActivity.this.initTextEntitiesValues(textStickerView);
                EditorActivity.this.setTxBtnClicked();
            }

            public void onTouch(TextStickerView textStickerView) {
                EditorActivity.this.touchTextSticker = textStickerView;
                EditorActivity.this.setTxBtnClicked();
            }

            public void onSelect(TextStickerView textStickerView) {
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.setCurrentImgStickerEdit(false, editorActivity.imgSticker);
                Iterator it = EditorActivity.this.fabControllers.iterator();
                while (it.hasNext()) {
                    ((ViewGroup) it.next()).setVisibility(View.INVISIBLE);
                }
                if (EditorActivity.this.currentTextSticker != null) {
                    EditorActivity.this.currentTextSticker.setInEdit(false);
                }
                EditorActivity.this.currentTextSticker = textStickerView;
                EditorActivity.this.currentTextSticker.setInEdit(true);
                EditorActivity.this.currentTextSticker.setShowHelpBox(true);
                EditorActivity.this.setTxBtnClicked();
            }
        });
        this.flTextSticker.addView(this.textSticker);
        this.allTextSticker.add(this.textSticker);
        setCurrentTextStickerEdit(true, this.textSticker);
    }

    private void initTextEntitiesListeners() {
        this.etTextEditor.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                if (EditorActivity.this.currentTextSticker != null) {
                    EditorActivity.this.currentTextSticker.setText(editable.toString());
                }
            }
        });
        this.etTextEditor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.iv_text_keyboard).setVisibility(View.GONE);
                EditorActivity.this.findViewById(R.id.iv_text_edit).setVisibility(View.VISIBLE);
                EditorActivity.this.ntbTextEditor.setVisibility(View.GONE);
                EditorActivity.this.findViewById(R.id.swg_text_editor).setVisibility(View.GONE);
            }
        });
        findViewById(R.id.iv_text_done).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.setCurrentTextStickerEdit(false, editorActivity.currentTextSticker);
            }
        });
        findViewById(R.id.iv_text_edit).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.initTextEntitiesValues(editorActivity.currentTextSticker);
                editorActivity = EditorActivity.this;
                AppUtil.hideKeyboard(editorActivity, editorActivity.etTextEditor);
                EditorActivity.this.findViewById(R.id.iv_text_keyboard).setVisibility(View.VISIBLE);
                EditorActivity.this.findViewById(R.id.iv_text_edit).setVisibility(View.GONE);
                EditorActivity.this.ntbTextEditor.setVisibility(View.VISIBLE);
                EditorActivity.this.findViewById(R.id.swg_text_editor).setVisibility(View.VISIBLE);
                EditorActivity.this.findViewById(R.id.swg_text_editor).post(new Runnable() {
                    public void run() {
                        if (EditorActivity.this.currentTextSticker.getLayoutY() <= EditorActivity.this.centreY - ((EditorActivity.this.canvasHeight * 10) / 100)) {
                            EditorActivity.this.params.setMargins(0, 0, 0, DensityUtil.dp2px(EditorActivity.this, 80.0f));
                        } else {
                            EditorActivity.this.params.setMargins(0, ((-EditorActivity.this.screenHeight) / 2) + EditorActivity.this.findViewById(R.id.swg_text_editor).getMeasuredHeight(), 0, 0);
                        }
                        EditorActivity.this.rlContainer.setLayoutParams(EditorActivity.this.params);
                    }
                });
            }
        });
        findViewById(R.id.iv_text_keyboard).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity editorActivity = EditorActivity.this;
                AppUtil.showKeyboard(editorActivity, editorActivity.etTextEditor);
                if (EditorActivity.this.currentTextSticker.getLayoutY() <= EditorActivity.this.centreY - ((EditorActivity.this.canvasHeight * 10) / 100)) {
                    EditorActivity.this.params.setMargins(0, 0, 0, 0);
                } else {
                    EditorActivity.this.params.setMargins(0, ((-EditorActivity.this.screenHeight) / 2) + DensityUtil.dp2px(EditorActivity.this, 80.0f), 0, 0);
                }
                EditorActivity.this.rlContainer.setLayoutParams(EditorActivity.this.params);
                EditorActivity.this.ntbTextEditor.setVisibility(View.GONE);
                EditorActivity.this.findViewById(R.id.swg_text_editor).setVisibility(View.GONE);
                EditorActivity.this.findViewById(R.id.iv_text_keyboard).setVisibility(View.GONE);
                EditorActivity.this.findViewById(R.id.iv_text_edit).setVisibility(View.VISIBLE);
            }
        });
        findViewById(R.id.iv_align_left).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorLightGrey);
                EditorActivity.this.findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.currentTextSticker.setAlign(Alignment.ALIGN_NORMAL);
            }
        });
        findViewById(R.id.iv_align_center).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorLightGrey);
                EditorActivity.this.findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.currentTextSticker.setAlign(Alignment.ALIGN_CENTER);
            }
        });
        findViewById(R.id.iv_align_right).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorWhite);
                EditorActivity.this.findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorLightGrey);
                EditorActivity.this.currentTextSticker.setAlign(Alignment.ALIGN_OPPOSITE);
            }
        });
        findViewById(R.id.iv_text_underline).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (EditorActivity.this.currentTextSticker.isUnderLine()) {
                    EditorActivity.this.findViewById(R.id.iv_text_underline).setBackgroundResource(R.color.colorWhite);
                    EditorActivity.this.currentTextSticker.setUnderLine(false);
                    return;
                }
                EditorActivity.this.findViewById(R.id.iv_text_underline).setBackgroundResource(R.color.colorLightGrey);
                EditorActivity.this.currentTextSticker.setUnderLine(true);
            }
        });
        findViewById(R.id.iv_text_strikethrough).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (EditorActivity.this.currentTextSticker.isStrikethrough()) {
                    EditorActivity.this.findViewById(R.id.iv_text_strikethrough).setBackgroundResource(R.color.colorWhite);
                    EditorActivity.this.currentTextSticker.setStrikethrough(false);
                    return;
                }
                EditorActivity.this.findViewById(R.id.iv_text_strikethrough).setBackgroundResource(R.color.colorLightGrey);
                EditorActivity.this.currentTextSticker.setStrikethrough(true);
            }
        });
        findViewById(R.id.iv_quote).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                TextStickerView access$400 = EditorActivity.this.currentTextSticker;
                StringBuilder stringBuilder = new StringBuilder();
                String str = "\"";
                stringBuilder.append(str);
                stringBuilder.append(EditorActivity.this.currentTextSticker.getText());
                stringBuilder.append(str);
                access$400.setText(stringBuilder.toString());
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(0)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.getFont().setSize((seekParams.progressFloat * 3.0f) / 1000.0f);
                EditorActivity.this.currentTextSticker.invalidate();
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(1)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.setOpacity((seekParams.progress * 255) / 100);
                EditorActivity.this.currentTextSticker.invalidate();
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(2)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.setLetterSpacing((float) seekParams.progress);
                EditorActivity.this.currentTextSticker.invalidate();
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(3)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.setLineSpacing((float) (seekParams.progress * 2));
                EditorActivity.this.currentTextSticker.invalidate();
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(4)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.setPaddingLeft(seekParams.progress);
            }
        });
        ((IndicatorSeekBar) this.teSeekBars.get(5)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.currentTextSticker.setPaddingRight(seekParams.progress);
            }
        });
        setTexEditorTabs();
        this.fontCategories = new ArrayList(Arrays.asList(getResources().getStringArray(R.array.font_categories)));
        for (int i = 0; i < this.fontCategories.size(); i++) {
            TabLayout tabLayout = this.tlFontCategories;
            tabLayout.addTab(tabLayout.newTab().setText((CharSequence) this.fontCategories.get(i)));
        }
        String defaultFontCategory = this.fontProvider.getDefaultFontCategory();
        FontProvider fontProvider = this.fontProvider;
        List fontNames = fontProvider.getFontNames(fontProvider.getDefaultFontCategory());
        FontProvider fontProvider2 = this.fontProvider;
        this.rvFontAdapter = new RvFontAdapter(this, defaultFontCategory, fontNames, fontProvider2, fontProvider2.getDefaultFontName(), this.screenWidth);
        this.rvFontDetail.setAdapter(this.rvFontAdapter);
        this.tlFontCategories.addOnTabSelectedListener(new OnTabSelectedListener() {
            public void onTabReselected(Tab tab) {
            }

            public void onTabUnselected(Tab tab) {
            }

            public void onTabSelected(Tab tab) {
                EditorActivity.this.rvFontAdapter = new RvFontAdapter(EditorActivity.this, tab.getText().toString(), EditorActivity.this.fontProvider.getFontNames(tab.getText().toString()), EditorActivity.this.fontProvider, EditorActivity.this.fontProvider.getDefaultFontName(), EditorActivity.this.screenWidth);
                EditorActivity.this.rvFontDetail.setAdapter(EditorActivity.this.rvFontAdapter);
            }
        });
        this.rvColorAdapter = new RvColorsAdapter(this, this.colorList, false, this.screenWidth);
        this.rvColors.setLayoutManager(new GridLayoutManager((Context) this, 9, RecyclerView.VERTICAL, false));
        this.rvColors.setAdapter(this.rvColorAdapter);
        findViewById(R.id.btn_text_custom_color).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.wg_custom_color).setVisibility(View.VISIBLE);
                EditorActivity.this.findViewById(R.id.wg_custom_color).startAnimation(AnimationsUtil.SlideUpIn);
            }
        });
        final String[] stringArray = getResources().getStringArray(R.array.gradient_palette);
        this.rvGradientAdapter = new RvGradientAdapter(this, stringArray, this.gradientType, this.linearDirection, false, this.screenWidth);
        this.rvGradients.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.rvGradients.setAdapter(this.rvGradientAdapter);
        this.msgType.setItems(getResources().getStringArray(R.array.directions_menu));
        this.msgType.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(MaterialSpinner materialSpinner, int i, long j, Object obj) {
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.gradientType = editorActivity.directionsMenu[i];
                Context context = EditorActivity.this;
                rvGradientAdapter = new RvGradientAdapter(context, stringArray, gradientType, EditorActivity.this.linearDirection, false, EditorActivity.this.screenWidth);
                EditorActivity.this.rvGradients.setAdapter(EditorActivity.this.rvGradientAdapter);
            }
        });
        findViewById(R.id.iv_gradientH).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.linearDirection = "Horizontal";
                Context context = EditorActivity.this;
                rvGradientAdapter = new RvGradientAdapter(context, stringArray, gradientType, EditorActivity.this.linearDirection, false, EditorActivity.this.screenWidth);
                EditorActivity.this.rvGradients.setAdapter(EditorActivity.this.rvGradientAdapter);
            }
        });
        findViewById(R.id.iv_gradientV).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.linearDirection = "Vertical";
                Context context = EditorActivity.this;
                rvGradientAdapter = new RvGradientAdapter(context, stringArray, gradientType, EditorActivity.this.linearDirection, false, EditorActivity.this.screenWidth);
                EditorActivity.this.rvGradients.setAdapter(EditorActivity.this.rvGradientAdapter);
            }
        });
    }

    private void setTexEditorTabs() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_align), getResources().getColor(R.color.colorGrey)).build());
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_adjust), getResources().getColor(R.color.colorGrey)).build());
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_font), getResources().getColor(R.color.colorGrey)).build());
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_color), getResources().getColor(R.color.colorGrey)).build());
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_gradient), getResources().getColor(R.color.colorGrey)).build());
        this.ntbTextEditor.setModels(arrayList);
        this.ntbTextEditor.setModelIndex(0);
        this.ntbTextEditor.getLayoutParams().width = arrayList.size() * DensityUtil.dp2px(this, 35.0f);
        this.ntbTextEditor.setOnTabBarSelectedIndexListener(new OnTabBarSelectedIndexListener() {
            public void onEndTabSelected(Model model, int i) {
            }

            public void onStartTabSelected(Model model, int i) {
                if (i == 0) {
                    EditorActivity.this.findViewById(R.id.sswg_text_align).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_text_adjust).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_font).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_color).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_gradient).setVisibility(View.GONE);
                } else if (i == 1) {
                    EditorActivity.this.findViewById(R.id.sswg_text_align).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_adjust).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_text_font).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_color).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_gradient).setVisibility(View.GONE);
                } else if (i == 2) {
                    EditorActivity.this.findViewById(R.id.sswg_text_align).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_adjust).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_font).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_text_color).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_gradient).setVisibility(View.GONE);
                } else if (i == 3) {
                    EditorActivity.this.findViewById(R.id.sswg_text_align).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_adjust).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_font).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_color).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_text_gradient).setVisibility(View.GONE);
                } else if (i == 4) {
                    EditorActivity.this.findViewById(R.id.sswg_text_align).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_adjust).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_font).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_color).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_text_gradient).setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void initTextEntitiesValues(TextStickerView textStickerView) {
        int i = textStickerView.getAlign().ordinal();
        if (i == 1) {
            findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorLightGrey);
            findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorWhite);
            findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorWhite);
        } else if (i == 2) {
            findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorWhite);
            findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorLightGrey);
            findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorWhite);
        } else if (i == 3) {
            findViewById(R.id.iv_align_left).setBackgroundResource(R.color.colorWhite);
            findViewById(R.id.iv_align_center).setBackgroundResource(R.color.colorWhite);
            findViewById(R.id.iv_align_right).setBackgroundResource(R.color.colorLightGrey);
        }
        if (textStickerView.isUnderLine()) {
            findViewById(R.id.iv_text_underline).setBackgroundResource(R.color.colorLightGrey);
        } else {
            findViewById(R.id.iv_text_underline).setBackgroundResource(R.color.colorWhite);
        }
        if (textStickerView.isStrikethrough()) {
            findViewById(R.id.iv_text_strikethrough).setBackgroundResource(R.color.colorLightGrey);
        } else {
            findViewById(R.id.iv_text_strikethrough).setBackgroundResource(R.color.colorWhite);
        }
        ((IndicatorSeekBar) this.teSeekBars.get(0)).setProgress((textStickerView.getFont().getSize() * 1000.0f) / 3.0f);
        ((IndicatorSeekBar) this.teSeekBars.get(1)).setProgress((float) ((textStickerView.getOpacity() * 100) / 255));
        ((IndicatorSeekBar) this.teSeekBars.get(2)).setProgress(textStickerView.getLetterSpacing());
        ((IndicatorSeekBar) this.teSeekBars.get(3)).setProgress(textStickerView.getLineSpacing() / 2.0f);
        ((IndicatorSeekBar) this.teSeekBars.get(4)).setProgress((float) textStickerView.getPaddingLeft());
        ((IndicatorSeekBar) this.teSeekBars.get(5)).setProgress((float) textStickerView.getPaddingRight());
        this.tlFontCategories.getTabAt(this.fontCategories.indexOf(textStickerView.getFont().getCategory())).select();
        this.rvFontAdapter = new RvFontAdapter(this, textStickerView.getFont().getCategory(), this.fontProvider.getFontNames(textStickerView.getFont().getCategory()), this.fontProvider, textStickerView.getFont().getTypeface(), this.screenWidth);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        int fontPosition = this.fontProvider.getFontPosition(textStickerView.getFont().getCategory(), textStickerView.getFont().getTypeface());
        int i2 = this.screenWidth;
        int i3 = i2 / 2;
        double d = (double) i2;
        Double.isNaN(d);
        Double.isNaN(d);
        linearLayoutManager.scrollToPositionWithOffset(fontPosition, (i3 - (((int) (d / 3.5d)) / 2)) - DensityUtil.dp2px(this, 6.0f));
        this.rvFontDetail.setLayoutManager(linearLayoutManager);
        this.rvFontDetail.setAdapter(this.rvFontAdapter);
    }

    public void changeTextEntityFont(String str, String str2) {
        this.currentTextSticker.getFont().setCategory(str);
        this.currentTextSticker.getFont().setTypeface(str2);
        this.currentTextSticker.invalidate();
    }

    public void changeTextEntityColor(String str) {
        this.currentTextSticker.getFont().setColor(Color.parseColor(str));
        this.currentTextSticker.getFont().setGradient(null);
        this.currentTextSticker.getFont().setPatternPath(null);
        this.currentTextSticker.invalidate();
    }

    public void changeTextEntityGradient(String[] strArr) {
        this.currentTextSticker.getFont().setGradient(strArr);
        this.currentTextSticker.getFont().setGradientType(this.gradientType);
        this.currentTextSticker.getFont().setLinearDirection(this.linearDirection);
        this.currentTextSticker.getFont().setPatternPath(null);
        this.currentTextSticker.invalidate();
    }

    private void setTxBtnClicked() {
        this.txBtnClicked = true;
        new Handler().postDelayed(new Runnable() {
            public void run() {
                EditorActivity.this.txBtnClicked = false;
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.setMediaOptions(editorActivity.templateViewGroup, false);
            }
        }, 1500);
    }

    public void setCurrentTextStickerEdit(boolean z, TextStickerView textStickerView) {
        if (!this.firstLaunch) {
            TextStickerView textStickerView2 = this.currentTextSticker;
            if (textStickerView2 != null) {
                textStickerView2.setInEdit(false);
            }
            this.currentTextSticker = textStickerView;
            if (z) {
                this.etTextEditor.setText(this.currentTextSticker.getText());
                EditText editText = this.etTextEditor;
                editText.setSelection(editText.getText().length());
                if (this.currentTextSticker.getLayoutY() <= this.centreY - ((this.canvasHeight * 10) / 100)) {
                    this.params.setMargins(0, 0, 0, 0);
                } else {
                    this.params.setMargins(0, ((-this.screenHeight) / 2) + DensityUtil.dp2px(this, 80.0f), 0, 0);
                }
                this.rlContainer.setLayoutParams(this.params);
                AppUtil.showKeyboard(this, this.etTextEditor);
                AppUtil.showWidget(this.vWidgets, findViewById(R.id.wg_text_edit));
                this.currentTextSticker.setInEdit(true);
            } else if (textStickerView != null) {
                textStickerView.setInEdit(false);
                if (findViewById(R.id.wg_main_menu).getVisibility() == View.GONE) {
                    this.params.setMargins(0, 0, 0, DensityUtil.dp2px(this, 80.0f));
                    this.rlContainer.setLayoutParams(this.params);
                    AppUtil.hideKeyboard(this, this.etTextEditor);
                    AppUtil.showWidget(this.vWidgets, findViewById(R.id.wg_main_menu));
                }
                this.currentTextSticker = null;
            }
            findViewById(R.id.iv_text_keyboard).setVisibility(View.GONE);
            findViewById(R.id.iv_text_edit).setVisibility(View.VISIBLE);
            this.ntbTextEditor.setVisibility(View.GONE);
            findViewById(R.id.swg_text_editor).setVisibility(View.GONE);
        } else if (textStickerView != null) {
            textStickerView.setInEdit(false);
        }
    }

    private void setCurrentImgStickerEdit(boolean z, ImageStickerView imageStickerView) {
        if (!this.firstLaunch) {
            ImageStickerView imageStickerView2 = this.currentImgSticker;
            if (imageStickerView2 != null) {
                imageStickerView2.setInEdit(false);
            }
            this.currentImgSticker = imageStickerView;
            if (z) {
                imageStickerView.setInEdit(true);
            } else if (imageStickerView != null) {
                imageStickerView.setInEdit(false);
            }
        } else if (imageStickerView != null) {
            imageStickerView.setInEdit(false);
        }
    }

    private void setBackgroundListeners() {
        setBgEditorTabs();
        this.rvColorAdapter = new RvColorsAdapter(this, this.colorList, true, this.screenWidth);
        this.rvBgColors.setLayoutManager(new GridLayoutManager((Context) this, 9, RecyclerView.VERTICAL, false));
        this.rvBgColors.setAdapter(this.rvColorAdapter);
        findViewById(R.id.btn_bg_custom_color).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.wg_custom_color).setVisibility(View.VISIBLE);
                EditorActivity.this.findViewById(R.id.wg_custom_color).startAnimation(AnimationsUtil.SlideUpIn);
            }
        });
        findViewById(R.id.btn_custom_color_close).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.findViewById(R.id.wg_custom_color).startAnimation(AnimationsUtil.SlideUpOut);
                EditorActivity.this.findViewById(R.id.wg_custom_color).setVisibility(View.GONE);
            }
        });
        final String[] stringArray = getResources().getStringArray(R.array.gradient_palette);
        this.rvBgGradientAdapter = new RvGradientAdapter(this, stringArray, this.gradientTypeBg, this.linearDirectionBg, true, this.screenWidth);
        this.rvBgGradients.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.rvBgGradients.setAdapter(this.rvBgGradientAdapter);
        this.msgBgType.setItems(getResources().getStringArray(R.array.directions_menu));
        this.msgBgType.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(MaterialSpinner materialSpinner, int i, long j, Object obj) {
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.gradientTypeBg = editorActivity.directionsMenu[i];
                Context context = EditorActivity.this;
                rvBgGradientAdapter = new RvGradientAdapter(context, stringArray, gradientTypeBg, EditorActivity.this.linearDirectionBg, true, EditorActivity.this.screenWidth);
                EditorActivity.this.rvBgGradients.setAdapter(EditorActivity.this.rvBgGradientAdapter);
            }
        });
        findViewById(R.id.iv_bg_gradientH).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.linearDirectionBg = "Horizontal";
                Context context = EditorActivity.this;
                rvBgGradientAdapter = new RvGradientAdapter(context, stringArray, gradientTypeBg, EditorActivity.this.linearDirectionBg, true, EditorActivity.this.screenWidth);
                EditorActivity.this.rvBgGradients.setAdapter(EditorActivity.this.rvBgGradientAdapter);
            }
        });
        findViewById(R.id.iv_bg_gradientV).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                EditorActivity.this.linearDirectionBg = "Vertical";
                Context context = EditorActivity.this;
                rvBgGradientAdapter = new RvGradientAdapter(context, stringArray, gradientTypeBg, EditorActivity.this.linearDirectionBg, true, EditorActivity.this.screenWidth);
                EditorActivity.this.rvBgGradients.setAdapter(EditorActivity.this.rvBgGradientAdapter);
            }
        });
        ((IndicatorSeekBar) this.bgSeekBars.get(0)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                EditorActivity.this.ivBackground.setScaleX((((float) seekParams.progress) / 100.0f) + 1.0f);
                EditorActivity.this.ivBackground.setScaleY((((float) seekParams.progress) / 100.0f) + 1.0f);
            }
        });
        ((IndicatorSeekBar) this.bgSeekBars.get(1)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                if (EditorActivity.this.selectedBgPattern != null) {
                    EditorActivity editorActivity = EditorActivity.this;
                    BitmapUtil.applyBlur(editorActivity, editorActivity.selectedBgPattern, seekParams.progress, EditorActivity.this.ivBackground);
                    return;
                }
                EditorActivity editorActivity2 = EditorActivity.this;
                Toast.makeText(editorActivity2, editorActivity2.getString(R.string.MSG_SELECT_PATTERN), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setBgEditorTabs() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_color), getResources().getColor(R.color.colorGrey)).build());
        arrayList.add(new Builder(getResources().getDrawable(R.drawable.icon_text_gradient), getResources().getColor(R.color.colorGrey)).build());
        this.ntbBgEditor.setModels(arrayList);
        this.ntbBgEditor.setModelIndex(0);
        this.ntbBgEditor.getLayoutParams().width = arrayList.size() * DensityUtil.dp2px(this, 60.0f);
        this.ntbBgEditor.setOnTabBarSelectedIndexListener(new OnTabBarSelectedIndexListener() {
            public void onEndTabSelected(Model model, int i) {
            }

            public void onStartTabSelected(Model model, int i) {
                if (i == 0) {
                    EditorActivity.this.findViewById(R.id.sswg_bg_color).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_bg_gradient).setVisibility(View.GONE);
                } else if (i == 1) {
                    EditorActivity.this.findViewById(R.id.sswg_bg_color).setVisibility(View.GONE);
                    EditorActivity.this.findViewById(R.id.sswg_bg_gradient).setVisibility(View.VISIBLE);
                    EditorActivity.this.findViewById(R.id.sswg_bg_pattern).setVisibility(View.GONE);
                }
            }
        });
    }

    public void changeBackground(String str, String[] strArr, String str2) {
        if (str != null) {
            this.ivBackground.setVisibility(View.GONE);
            this.vBgColor.setBackgroundColor(Color.parseColor(str));
            this.selectedBgColor = str;
            this.selectedBgGradient = null;
            this.selectedBgPattern = null;
        } else if (strArr != null) {
            this.ivBackground.setVisibility(View.GONE);
            this.vBgColor.setBackgroundDrawable(null);
            this.vBgColor.setBackgroundDrawable(AppUtil.generateViewGradient(strArr, this.gradientTypeBg, this.linearDirectionBg, this.canvasWidth, this.canvasHeight));
            this.selectedBgColor = null;
            this.selectedBgGradient = strArr;
            this.selectedBgPattern = null;
        } else if (str2 != null) {
            this.ivBackground.setVisibility(View.VISIBLE);
            BitmapUtil.applyBlur(this, str2, ((IndicatorSeekBar) this.bgSeekBars.get(1)).getProgress(), this.ivBackground);
            this.selectedBgColor = null;
            this.selectedBgGradient = null;
            this.selectedBgPattern = str2;
        }
    }

    private void addFragment(Fragment fragment, int i, int i2, int i3) {
        this.fm.executePendingTransactions();
        FragmentTransaction beginTransaction = this.fm.beginTransaction();
        if (!(i2 == 0 && i3 == 0)) {
            beginTransaction.setCustomAnimations(i2, i3);
        }
        beginTransaction.replace(i, fragment);
        beginTransaction.commitAllowingStateLoss();
    }

    public void loading(boolean z, boolean z2) {
        if (!z) {
            findViewById(R.id.wg_loading).setVisibility(View.GONE);
        } else if (z2) {
            findViewById(R.id.wg_loading).setVisibility(View.VISIBLE);
        }
    }

    private void setCustomColorListeners() {
        final int[] iArr = new int[]{255};
        final int[] iArr2 = new int[]{255};
        final int[] iArr3 = new int[]{255};
        ((IndicatorSeekBar) findViewById(R.id.sb_red)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                iArr[0] = seekParams.progress;
                String str = "#%02x%02x%02x";
                if (EditorActivity.this.wgTextEditor.isShown()) {
                    EditorActivity.this.changeTextEntityColor(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}));
                    return;
                }
                EditorActivity.this.changeBackground(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}), null, null);
            }
        });
        ((IndicatorSeekBar) findViewById(R.id.sb_green)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                iArr2[0] = seekParams.progress;
                String str = "#%02x%02x%02x";
                if (EditorActivity.this.wgTextEditor.isShown()) {
                    EditorActivity.this.changeTextEntityColor(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}));
                    return;
                }
                EditorActivity.this.changeBackground(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}), null, null);
            }
        });
        ((IndicatorSeekBar) findViewById(R.id.sb_blue)).setOnSeekChangeListener(new OnSeekChangeListener() {
            public void onStartTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onStopTrackingTouch(IndicatorSeekBar indicatorSeekBar) {
            }

            public void onSeeking(SeekParams seekParams) {
                iArr3[0] = seekParams.progress;
                String str = "#%02x%02x%02x";
                if (EditorActivity.this.wgTextEditor.isShown()) {
                    EditorActivity.this.changeTextEntityColor(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}));
                    return;
                }
                EditorActivity.this.changeBackground(String.format(str, new Object[]{Integer.valueOf(iArr[0]), Integer.valueOf(iArr2[0]), Integer.valueOf(iArr3[0])}), null, null);
            }
        });
    }

    public void isClickable() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.mLastClickTime >= 3000) {
            this.mLastClickTime = currentTimeMillis;
        }
    }

    private void hideControllersFab(View view) {
        Iterator it = this.fabControllers.iterator();
        while (it.hasNext()) {
            View view2 = (ViewGroup) it.next();
            if (view2 != view) {
                view2.setVisibility(View.INVISIBLE);
            }
        }
    }

    private void removeUnusedFiles() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.draftsPath);
        String str = "/";
        stringBuilder.append(str);
        stringBuilder.append(this.draftFolder);
        stringBuilder.append(str);
        ArrayList filesPath = AppUtil.getFilesPath(stringBuilder.toString());
        ArrayList arrayList = new ArrayList();
        Iterator it = this.draft.photos.iterator();
        while (it.hasNext()) {
            arrayList.add(((Photo) it.next()).path);
        }
        Iterator it2 = filesPath.iterator();
        while (it2.hasNext()) {
            String str2 = (String) it2.next();
            if (!(str2.contains("thumb") || arrayList.contains(str2) || !new File(str2).exists())) {
                new File(str2).delete();
            }
        }
    }

    public void onPermissionGranted() {
        if (this.selectedBtn == R.id.menu_save) {
            final Dialog dialog = new Dialog(this);
            View inflate = LayoutInflater.from(this).inflate(R.layout.wg_resolution_alert_dialog, null);
            AppUtil.showBottomDialog(this, dialog, inflate, true);
            inflate.findViewById(R.id.btn_standard).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (EditorActivity.this.totalMemory <= 1500) {
                        EditorActivity.this.saveWidth = 450;
                        EditorActivity.this.saveHeight = 800;
                    } else if (EditorActivity.this.totalMemory <= 2500) {
                        EditorActivity.this.saveWidth = 720;
                        EditorActivity.this.saveHeight = 1280;
                    } else if (EditorActivity.this.totalMemory <= 4500) {
                        EditorActivity.this.saveWidth = 810;
                        EditorActivity.this.saveHeight = 1440;
                    } else {
                        EditorActivity.this.saveWidth = 1080;
                        EditorActivity.this.saveHeight = 1920;
                    }
                    dialog.dismiss();
                    EditorActivity.this.isSaved = true;
                    String str = "save_photo";
                    new SaveDraft(0, true, str).execute(new String[0]);
//                    new SavePhoto().execute();
                }
            });
            inflate.findViewById(R.id.btn_medium).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (EditorActivity.this.totalMemory <= 1500D) {
                        EditorActivity.this.saveWidth = 720;
                        EditorActivity.this.saveHeight = 1280;
                    } else if (EditorActivity.this.totalMemory <= 2500) {
                        EditorActivity.this.saveWidth = 810;
                        EditorActivity.this.saveHeight = 1440;
                    } else if (EditorActivity.this.totalMemory < 4500) {
                        EditorActivity.this.saveWidth = 1080;
                        EditorActivity.this.saveHeight = 1920;
                    } else {
                        EditorActivity.this.saveWidth = 1620;
                        EditorActivity.this.saveHeight = 2880;
                    }
                    dialog.dismiss();
                    EditorActivity.this.isSaved = true;
                    new SaveDraft(0, true, "save_photo").execute(new String[0]);
                }
            });
            inflate.findViewById(R.id.btn_high).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (EditorActivity.this.totalMemory <= 1500D) {
                        EditorActivity.this.saveWidth = 810;
                        EditorActivity.this.saveHeight = 1440;
                    } else if (EditorActivity.this.totalMemory <= 2500) {
                        EditorActivity.this.saveWidth = 1080;
                        EditorActivity.this.saveHeight = 1920;
                    } else if (EditorActivity.this.totalMemory < 4500) {
                        EditorActivity.this.saveWidth = 1620;
                        EditorActivity.this.saveHeight = 2880;
                    } else {
                        EditorActivity.this.saveWidth = 2160;
                        EditorActivity.this.saveHeight = 3840;
                    }
                    dialog.dismiss();
                    EditorActivity.this.isSaved = true;
                    new SaveDraft(0, true, "save_photo").execute(new String[0]);
                }
            });
        }
    }

    private void imageProcessing(Bitmap bitmap) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StoryMaker");
        stringBuilder.append(AppUtil.getCurrentTime());
        stringBuilder.append(".png");
        this.outputName = stringBuilder.toString();
        File file = new File(this.savePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, this.outputName);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        char c;
        super.onActivityResult(i, i2, intent);
        if (i2 == -1) {
            String str = "filePath";
            if (i == 0) {
                try {
                    String stringExtra = intent.getStringExtra(str);
                    String fileType = AppUtil.getFileType(stringExtra);
                    int hashCode = fileType.hashCode();
                    if (hashCode != 71588) {
                        if (hashCode != 70760763) {
                            if (hashCode == 82650203 && fileType.equals("Video")) {
                                c = 2;
                                if (c != 0) {
                                    AppUtil.cropPhoto(this, new File(stringExtra), ((Integer) this.selectedViewRatio.get(0)).intValue(), ((Integer) this.selectedViewRatio.get(1)).intValue(), this.totalMemory);
                                    return;
                                }
                                return;
                            }
                        } else if (fileType.equals("Image")) {
                            c = 0;
                            AppUtil.cropPhoto(this, new File(stringExtra), ((Integer) this.selectedViewRatio.get(0)).intValue(), ((Integer) this.selectedViewRatio.get(1)).intValue(), this.totalMemory);
                            if (c != 0) {
                            }
                        }
                    } else if (fileType.equals("Gif")) {
                        c = 1;
                        if (c != 0) {
                        }
                    }
                    c = 65535;
                    if (c != 0) {
                    }
                } catch (Exception unused) {
                    Toast.makeText(activity, "Somthing Went Wrong" + getString(R.string.MSG_SOMETHING_WRONG), Toast.LENGTH_SHORT).show();
                }
            } else if (i == 69) {
                try {
                    Bitmap bitmap = Media.getBitmap(getContentResolver(), UCrop.getOutput(intent));
                    findViewById(R.id.fl_fragment).setVisibility(View.VISIBLE);
                    addFragment(FiltersFrag.getInstance(bitmap), R.id.fl_fragment, 0, 0);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (i == 11) {
                String stringExtra2 = intent.getStringExtra("rewardType");
                if (stringExtra2.equals(getString(R.string.TITLE_FONTS_LOCKED))) {
                    this.rvFontAdapter.refreshList();
                    this.rvFontDetail.setAdapter(this.rvFontAdapter);
                } else if (stringExtra2.equals(getString(R.string.TITLE_GRADIENTS_LOCKED))) {
                    if (findViewById(R.id.wg_background_menu).isShown()) {
                        this.rvGradientAdapter.refreshList(true);
                    } else {
                        this.rvGradientAdapter.refreshList(false);
                    }
                    this.rvGradients.setAdapter(this.rvGradientAdapter);
                    this.rvBgGradients.setAdapter(this.rvGradientAdapter);
                }
                Toast.makeText(this, "Thanks for watching", Toast.LENGTH_SHORT).show();
            } else if (i == 12) {
                try {
                    addStickerView();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        } else if (i2 == 96) {
            Toast.makeText(activity, "" + UCrop.getError(intent).getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void addStickerView() throws IOException {
        AssetManager assets = getAssets();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("crown/");
        stringBuilder.append(Glob_Sticker.SelectedTattooName.replace("assets://crown/", ""));
        this.d = Drawable.createFromStream(assets.open(stringBuilder.toString()), null);
        ImageStickerView imageStickerView = new ImageStickerView(this, "", (float) (this.canvasWidth / 2), (float) (this.canvasHeight / 2), 0.3f, 0.0f, this.allImageSticker.size());
        Bitmap convertDrawableToBitmap = convertDrawableToBitmap(this.d);
        this.imgSticker = imageStickerView;
        this.imgSticker.setBitmap(convertDrawableToBitmap);
        this.imgSticker.setOperationListener(new ImageStickerView.OperationListener() {
            public void onDeleteClick() {
                EditorActivity.this.allImageSticker.remove(EditorActivity.this.currentImgSticker);
                EditorActivity.this.flImageSticker.removeView(EditorActivity.this.currentImgSticker);
            }

            public void onEdit(ImageStickerView imageStickerView) {
                EditorActivity.this.bgClose();
                EditorActivity editorActivity = EditorActivity.this;
                editorActivity.setCurrentTextStickerEdit(false, editorActivity.textSticker);
                Iterator it = EditorActivity.this.fabControllers.iterator();
                while (it.hasNext()) {
                    ((ViewGroup) it.next()).setVisibility(View.INVISIBLE);
                }
                if (EditorActivity.this.currentImgSticker != null) {
                    EditorActivity.this.currentImgSticker.setInEdit(false);
                }
                EditorActivity.this.currentImgSticker = imageStickerView;
                EditorActivity.this.currentImgSticker.setInEdit(true);
            }

            public void onTop(ImageStickerView imageStickerView) {
                int indexOf = EditorActivity.this.allImageSticker.indexOf(imageStickerView);
                if (indexOf != EditorActivity.this.allImageSticker.size() - 1) {
                    EditorActivity.this.allImageSticker.add(EditorActivity.this.allImageSticker.size(), (ImageStickerView) EditorActivity.this.allImageSticker.remove(indexOf));
                }
            }
        });
        this.flImageSticker.addView(this.imgSticker, new LayoutParams(-1, -1));
        this.allImageSticker.add(this.imgSticker);
        setCurrentImgStickerEdit(true, this.imgSticker);
    }

    private Bitmap convertDrawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        Bitmap createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(12, 12, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    public void onBackPressed() {
        if (!findViewById(R.id.wg_loading).isShown()) {
            if (findViewById(R.id.fl_fragment).isShown()) {
                findViewById(R.id.fl_fragment).setVisibility(View.GONE);
                if (this.fm.findFragmentById(R.id.fl_fragment) != null) {
                    FragmentTransaction beginTransaction = this.fm.beginTransaction();
                    Fragment findFragmentById = this.fm.findFragmentById(R.id.fl_fragment);
                    findFragmentById.getClass();
                    beginTransaction.remove(findFragmentById).commit();
                }
                return;
            }
            goBack();
        }
    }

    @OnClick({R.id.menu_close})
    public void goBack() {
        final Dialog dialog = new Dialog(this);
        View inflate = LayoutInflater.from(this).inflate(R.layout.wg_bottom_alert_dialog, null);
        AppUtil.showBottomDialog(this, dialog, inflate, true);
        inflate.findViewById(R.id.btn_neutral).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btn_negative).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (EditorActivity.this.isDraft) {
                    EditorActivity.this.removeUnusedFiles();
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(EditorActivity.this.draftsPath);
                    stringBuilder.append("/");
                    stringBuilder.append(EditorActivity.this.draftFolder);
                    AppUtil.deleteFolder(new File(stringBuilder.toString()));
                }
                dialog.dismiss();
                EditorActivity.this.finish();
                EditorActivity.this.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        inflate.findViewById(R.id.btn_positive).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (AppUtil.permissionGranted(EditorActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) && AppUtil.permissionGranted(EditorActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    EditorActivity.this.isSaved = false;
                    dialog.dismiss();
                    new SaveDraft(0, true, "save_draft").execute(new String[0]);
                }
            }
        });
    }

    @OnClick({R.id.menu_save})
    public void save() {
        isClickable();
        if (this.addedPhotos.size() < this.frameLayouts.size()) {
            Toast.makeText(activity, "" + getString(R.string.MSG_FILL_FRAMES), Toast.LENGTH_SHORT).show();
            return;
        }
        this.selectedBtn = R.id.menu_save;
        AppUtil.editorPermissionGranted(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    @OnClick({R.id.menu_text})
    public void addText() {
        isClickable();
        Font font = new Font();
        font.setColor(ViewCompat.MEASURED_STATE_MASK);
        font.setSize(0.075f);
        font.setCategory(this.fontProvider.getDefaultFontCategory());
        font.setTypeface(this.fontProvider.getDefaultFontName());
        createTextStickView(this.allTextSticker.size() - 1, "My Story", font, this.canvasWidth / 2, this.centreY, 0.0f, 1.0f, 0, 0, Alignment.ALIGN_CENTER, 255, false, false, 0.0f, 10.0f);
    }

    @OnClick({R.id.menu_background})
    public void addBackground() {
        isClickable();
        findViewById(R.id.wg_background_menu).setVisibility(View.VISIBLE);
    }

    @OnClick({R.id.bg_close})
    public void bgClose() {
        isClickable();
        findViewById(R.id.wg_background_menu).setVisibility(View.GONE);
    }

    @OnClick({R.id.menu_sticker})
    public void addSticker() {
        isClickable();
        if (AppUtil.permissionGranted(this, Manifest.permission.READ_EXTERNAL_STORAGE) && AppUtil.permissionGranted(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            startActivityForResult(new Intent(getApplicationContext(), StickerActivity.class), 12);
        }
    }

    @OnClick({R.id.menu_paint})
    public void addPaint() {
        isClickable();
    }

    private void replaceScreen() {
        if (this.whichActivitytoStart == 1) {
            Intent intent = new Intent(this, PreviewActivity.class);
            intent.putExtra("savedImageFile", this.A);
            intent.putExtra("draft", this.B);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom);
        }
    }

    public void onPause() {
        super.onPause();
        this.isActivityLeft = true;
    }

    public void onResume() {
        super.onResume();
        this.isActivityLeft = false;
    }

    public void onStop() {
        super.onStop();
        this.isActivityLeft = true;
    }

    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
        this.isActivityLeft = true;
    }
}
