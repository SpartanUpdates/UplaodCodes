package com.esc.phoneheart.advancedclean;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.esc.phoneheart.activity.PhoneCleaner;
import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;


public class CleanMasterAccessbilityService extends AccessibilityService {
    public static final String ACT_CLEAN = "1";
    public static final String ACT_EXIT = "3";
    public static final String ACT_STOP = "2";
    public static final String TAG = "AccessbilityService";
    public static boolean sRunning = false;
    public final int MAX_RETRY_TIME = 3;
    public Action mAction = new Action(Looper.getMainLooper());
    public int mCurrentRetryTime = 0;
    public String mCurrentTask;
    public TASK_STATE mState = TASK_STATE.INIT;
    public List<String> mSticky = new ArrayList();
    public List<String> mTasks = new ArrayList();
    public CleanUI mView;

    public class Action extends Handler {
        public static final int S_HIDE_PANEL = 3;
        public static final int S_INIT = 0;
        public static final int S_NEXT = 2;
        public static final int S_START = 1;

        public Action(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            int i = message.what;
            if (i != 0) {
                if (i == 1) {
                    CleanMasterAccessbilityService.this.startClean();
                    return;
                } else if (i != 2) {
                    if (i == 3) {
                        CleanMasterAccessbilityService.this.hideOverlayAndExit();
                        return;
                    }
                    return;
                }
            }
            if (CleanMasterAccessbilityService.sRunning) {
                CleanMasterAccessbilityService.this.takeNextTask();
            }
        }
    }

    public enum TASK_STATE {
        INIT,
        FOUND,
        FORCE_STOPED,
        ENSUREED,
        SUCCESS,
        FAILED
    }

    private void hideOverlayAndExit() {
        this.mView.show(false);
        SystemUtils.killProcess(getBaseContext());
    }

    private void initTasks() {
        reset();
        this.mTasks.addAll(PhoneCleaner.getInstance().advancedCleaningList);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("installed: ");
        stringBuilder.append(this.mTasks.size());
        Log.i(TAG, stringBuilder.toString());
    }

    private void iterateViews(AccessibilityNodeInfo accessibilityNodeInfo) {
        int childCount = accessibilityNodeInfo.getChildCount();
        for (int i = 0; i < childCount; i++) {
            String str = "";
            String str2 = ">>>>>>>>";
            AccessibilityNodeInfo child;
            StringBuilder stringBuilder;
            if (childCount == 0) {
                child = accessibilityNodeInfo.getChild(i);
                if (!(child == null || child.getText() == null)) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(child.getText());
                    stringBuilder.append(str);
                    Log.e(str2, stringBuilder.toString());
                }
            } else {
                child = accessibilityNodeInfo.getChild(i);
                try {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(accessibilityNodeInfo.getText());
                    stringBuilder.append(str);
                    Log.e(str2, stringBuilder.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (child != null) {
                    iterateViews(child);
                }
            }
        }
    }

    private void notifyTaskStateIfNeeded() {
        if (this.mCurrentTask != null) {
            this.mView.onResult(this.mState);
        }
    }

    private void onStop() {
        if (sRunning) {
            sRunning = false;
            this.mAction.removeMessages(2);
            this.mAction.removeMessages(0);
            notifyTaskStateIfNeeded();
            if (VERSION.SDK_INT >= 16) {
                SystemUtils.backToHome(getApplicationContext());
            }
            this.mView.onStop(this.mSticky);
            reset();
        }
    }

    private void reset() {
        this.mSticky.clear();
        this.mTasks.clear();
        this.mCurrentTask = null;
    }

    private void setState(TASK_STATE task_state) {
        if (task_state != null && this.mState.ordinal() < task_state.ordinal()) {
            this.mState = task_state;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("state = ");
            stringBuilder.append(task_state.name());
            Log.i(TAG, stringBuilder.toString());
        }
    }

    private boolean takeNextTask() {
        Log.i(TAG, "takeNextTask");
        this.mCurrentRetryTime = 0;
        if (this.mTasks.size() > 0) {
            String str = (String) this.mTasks.remove(0);
            if (str != null) {
                notifyTaskStateIfNeeded();
                this.mAction.removeMessages(2);
                this.mAction.sendEmptyMessageDelayed(2, Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
                try {
                    this.mCurrentTask = str;
                    this.mView.onTaskStart(str);
                    this.mState = TASK_STATE.INIT;
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
//                    intent.addFlags(1409351680);
                    intent.setData(Uri.fromParts("package", str, null));
                    if (VERSION.SDK_INT >= 16) {
                        startActivity(intent, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle());
                    } else {
                        startActivity(intent);
                    }
                } catch (Throwable th) {
                    th.printStackTrace();
                    this.mAction.removeMessages(2);
                    this.mAction.sendEmptyMessage(2);
                }
            } else {
                notifyTaskStateIfNeeded();
            }
        } else {
            onStop();
            this.mAction.sendEmptyMessageDelayed(3, 4000);
        }
        return false;
    }

    private boolean tryClickStop(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo != null) {
            int childCount = accessibilityNodeInfo.getChildCount();
            if (accessibilityNodeInfo.getText() != null) {
                String charSequence = accessibilityNodeInfo.getText().toString();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(" ");
                stringBuilder.append(charSequence);
                Log.e(">>>>>>>>>>>>>>>", stringBuilder.toString());
                boolean contains = StringUtils.contains(charSequence, "停止");
                String str = "try stop success";
                String str2 = TAG;
                if ((contains || StringUtils.containsIgnoreCase(charSequence, "Storage")) && accessibilityNodeInfo.getParent() != null && accessibilityNodeInfo.getParent().isClickable()) {
                    if (accessibilityNodeInfo.isEnabled()) {
                        Log.i(str2, str);
                        accessibilityNodeInfo.getParent().performAction(16);
                        setState(TASK_STATE.FORCE_STOPED);
                        return true;
                    } else if (this.mState.ordinal() >= TASK_STATE.FOUND.ordinal()) {
                        setState(TASK_STATE.SUCCESS);
                    } else {
                        setState(TASK_STATE.FOUND);
                    }
                } else if (StringUtils.containsIgnoreCase(charSequence, "Clear Cache")) {
                    if (accessibilityNodeInfo.isEnabled()) {
                        Log.i(str2, str);
                        accessibilityNodeInfo.performAction(16);
                        setState(TASK_STATE.FORCE_STOPED);
                        return true;
                    } else if (this.mState.ordinal() >= TASK_STATE.FOUND.ordinal()) {
                        setState(TASK_STATE.SUCCESS);
                    } else {
                        setState(TASK_STATE.FOUND);
                    }
                }
            }
            for (int i = 0; i < childCount; i++) {
                if (tryClickStop(accessibilityNodeInfo.getChild(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean tryEnsure(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo != null) {
            int childCount = accessibilityNodeInfo.getChildCount();
            if (accessibilityNodeInfo.getText() != null) {
                String charSequence = accessibilityNodeInfo.getText().toString();
                if ((StringUtils.contains(charSequence, "确定") || StringUtils.containsIgnoreCase(charSequence, "Clear Cache")) && accessibilityNodeInfo.isClickable() && accessibilityNodeInfo.isEnabled()) {
                    Log.i(TAG, "try ensure success");
                    accessibilityNodeInfo.performAction(16);
                    setState(TASK_STATE.ENSUREED);
                    return true;
                }
            }
            for (int i = 0; i < childCount; i++) {
                if (tryEnsure(accessibilityNodeInfo.getChild(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (sRunning) {
            AccessibilityNodeInfo source = accessibilityEvent.getSource();
            if (source != null) {
                int eventType = accessibilityEvent.getEventType();
                if (eventType == 2048 || eventType == 32) {
                    if (this.mCurrentRetryTime > 3 || tryClickStop(source)) {
                        this.mAction.removeMessages(2);
                        this.mAction.sendEmptyMessageDelayed(2, 1000);
                    } else if (tryEnsure(source)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("retried ");
                        stringBuilder.append(this.mCurrentRetryTime);
                        Log.i(TAG, stringBuilder.toString());
                        eventType = this.mCurrentRetryTime + 1;
                        this.mCurrentRetryTime = eventType;
                        if (eventType > 3) {
                            this.mSticky.add(this.mCurrentTask);
                            setState(TASK_STATE.FAILED);
                            if (VERSION.SDK_INT >= 16) {
                                performGlobalAction(1);
                            }
                            takeNextTask();
                        } else {
                            this.mAction.removeMessages(2);
                            this.mAction.sendEmptyMessageDelayed(2, 500);
                        }
                    }
                }
            }
        }
    }

    public void onCreate() {
        super.onCreate();
        this.mView = new CleanUI(this);
    }

    public void onInterrupt() {
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onStartCommand ");
        stringBuilder.append(intent);
        stringBuilder.append(" flags: ");
        stringBuilder.append(i);
        stringBuilder.append(" startId: ");
        stringBuilder.append(i2);
        Log.i(TAG, stringBuilder.toString());
        if (intent != null) {
            if ("1".equals(intent.getAction())) {
                this.mAction.sendEmptyMessage(1);
            } else {
                if (ACT_STOP.equals(intent.getAction())) {
                    onStop();
                } else {
                    if (ACT_EXIT.equals(intent.getAction())) {
                        onStop();
                        this.mAction.sendEmptyMessageDelayed(3, 1000);
                    }
                }
            }
        }
        return super.onStartCommand(intent, i, i2);
    }

    public void startClean() {
        sRunning = true;
        this.mView.show(true);
        initTasks();
        this.mView.onStart(this.mTasks.size());
        this.mAction.sendEmptyMessage(0);
    }
}
