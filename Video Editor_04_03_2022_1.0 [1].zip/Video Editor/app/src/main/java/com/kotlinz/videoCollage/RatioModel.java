package com.kotlinz.videoCollage;

public class RatioModel {
    String name;

    public RatioModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
