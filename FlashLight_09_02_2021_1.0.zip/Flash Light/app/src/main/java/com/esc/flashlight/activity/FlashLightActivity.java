package com.esc.flashlight.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import com.esc.flashlight.NativeAds.NativeAdvanceAds;
import com.esc.flashlight.R;
import com.esc.flashlight.database.TinyDB;
import com.esc.flashlight.preference.EPreferences;
import com.esc.flashlight.util.PrefManager;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;


@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class FlashLightActivity extends BaseActivity {
    Activity activity = FlashLightActivity.this;
    private ImageView both;
    private LinearLayout bottom;
    private CameraManager camManager;
    private Camera camera = null;
    private String cameraId;
    private boolean deviceHasFlash;
    private long dtime = 0;
    private int fcount = 0;
    private TextView flashcount;
    private boolean isFlashLightOn = false;
    private boolean isON = false;
    private boolean istimeon = false;
    private ImageView iv_moon;
    private ImageView iv_setting;
    private LinearLayout main_layout;
    private Parameters parameter;
    private ImageView phonelight;
    private PrefManager prefManager;
    private long startTime = 0;
    private CountDownTimer timer;
    private TextView timetxt;
    private TinyDB tinyDB;
    private boolean toggle;
    private Toolbar toolbar;
    private LinearLayout top;
    private ImageView tourch;
    private ImageView tourchlight;
    EPreferences ePreferences;

    private UnifiedNativeAd nativeAd;

    public class MyCounter extends CountDownTimer {
        public MyCounter(long j, long j2) {
            super(j, j2);
            FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " s");
        }

        public void onTick(long j) {
            FlashLightActivity.this.timetxt.setText((j / 1000) + " s");
        }

        public void onFinish() {
            FlashLightActivity.this.istimeon = false;
            if (FlashLightActivity.this.timer != null) {
                FlashLightActivity.this.timer.cancel();
                FlashLightActivity.this.timer = null;
                FlashLightActivity.this.startTime = 0;
                FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " S");
            }
            FlashLightActivity.this.isFlashLightOn = false;
            FlashLightActivity.this.tourch.setImageResource(R.drawable.power_off);
            FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_off);
            FlashLightActivity flashLightActivity = FlashLightActivity.this;
            flashLightActivity.setOnOff(flashLightActivity.isFlashLightOn);
        }
    }

    public class MyTask extends AsyncTask<Void, Void, Boolean> {

        public Boolean doInBackground(Void... voidArr) {
            while (true) {
                Log.e("call for", "onClick:  " + FlashLightActivity.this.isFlashLightOn);
                if (FlashLightActivity.this.fcount != 0) {
                    if (FlashLightActivity.this.isFlashLightOn || FlashLightActivity.this.istimeon) {
                        FlashLightActivity flashLightActivity = FlashLightActivity.this;
                        flashLightActivity.toggle(flashLightActivity.dtime, FlashLightActivity.this.dtime);
                    } else {
                        FlashLightActivity.this.setOnOff(false);
                        return Boolean.valueOf(true);
                    }
                }
            }
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.tinyDB = new TinyDB(this);
        setContentView(R.layout.activity_flash_light);
        this.tinyDB.putBoolean("purchased", true);
        this.ePreferences = EPreferences.getInstance(this);
        this.prefManager = new PrefManager(this);
        this.iv_moon = findViewById(R.id.iv_moon);
        this.iv_setting = findViewById(R.id.iv_setting);
        Toolbar toolbar = findViewById(R.id.toolbar);
        this.toolbar = toolbar;
        toolbar.setTitle(getString(R.string.flash_light));
        this.tourch = findViewById(R.id.btn_on_off);
        this.top = findViewById(R.id.id_top);
        this.bottom = findViewById(R.id.id_bottom);
        this.tourchlight = findViewById(R.id.btn_tourch);
        this.phonelight = findViewById(R.id.btn_phone);
        this.both = findViewById(R.id.btn_both);
        this.main_layout = findViewById(R.id.id_main_layout);
        this.flashcount = findViewById(R.id.btn_flash_count);
        this.timetxt = findViewById(R.id.btn_time);
        this.iv_setting.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(FlashLightActivity.this, MainActivity.class));
            }
        });
        boolean hasSystemFeature = getApplication().getPackageManager().hasSystemFeature("android.hardware.camera.flash");
        this.deviceHasFlash = hasSystemFeature;
        if (hasSystemFeature) {
            this.flashcount.setText(this.fcount + "");
            this.timetxt.setText(this.startTime + " s");
            this.main_layout.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FlashLightActivity.this.tourch.setVisibility(View.VISIBLE);
                }
            });
            this.tourchlight.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FlashLightActivity.this.unselect();
                    FlashLightActivity.this.tourchlight.setImageResource(R.drawable.sel_torch);
                    FlashLightActivity.this.prefManager.setLightOption("torch");
                    FlashLightActivity flashLightActivity = FlashLightActivity.this;
                    flashLightActivity.switchFlashLight(flashLightActivity.isFlashLightOn);
                }
            });
            this.phonelight.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FlashLightActivity.this.unselect();
                    FlashLightActivity.this.phonelight.setImageResource(R.drawable.sel_phone_light);
                    FlashLightActivity.this.prefManager.setLightOption("phone");
                    FlashLightActivity flashLightActivity = FlashLightActivity.this;
                    flashLightActivity.switchPhoneLight(flashLightActivity.isFlashLightOn);
                }
            });
            this.both.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FlashLightActivity.this.unselect();
                    FlashLightActivity.this.both.setImageResource(R.drawable.sel_both);
                    FlashLightActivity.this.prefManager.setLightOption("both");
                    FlashLightActivity flashLightActivity = FlashLightActivity.this;
                    flashLightActivity.switchFlashLight(flashLightActivity.isFlashLightOn);
                    flashLightActivity = FlashLightActivity.this;
                    flashLightActivity.switchPhoneLight(flashLightActivity.isFlashLightOn);
                }
            });
            this.flashcount.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (FlashLightActivity.this.fcount == 0) {
                        FlashLightActivity.this.fcount = 1;
                        FlashLightActivity.this.dtime = 500;
                    } else if (FlashLightActivity.this.fcount == 1) {
                        FlashLightActivity.this.fcount = 2;
                        FlashLightActivity.this.dtime = 250;
                    } else if (FlashLightActivity.this.fcount == 2) {
                        FlashLightActivity.this.fcount = 3;
                        FlashLightActivity.this.dtime = 100;
                    } else if (FlashLightActivity.this.fcount == 3) {
                        FlashLightActivity.this.fcount = 0;
                        FlashLightActivity.this.dtime = 0;
                    }
                    FlashLightActivity.this.flashcount.setText(FlashLightActivity.this.fcount + "");
                    if (FlashLightActivity.this.fcount == 0) {
                        FlashLightActivity flashLightActivity = FlashLightActivity.this;
                        flashLightActivity.setOnOff(flashLightActivity.isFlashLightOn);
                    } else if (FlashLightActivity.this.isFlashLightOn) {
                        new MyTask().execute();
                    } else {
                        FlashLightActivity.this.setOnOff(false);
                    }
                }
            });
            this.timetxt.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (FlashLightActivity.this.startTime == 0) {
                        FlashLightActivity.this.startTime = 10;
                    } else if (FlashLightActivity.this.startTime == 10) {
                        FlashLightActivity.this.startTime = 20;
                    } else if (FlashLightActivity.this.startTime == 20) {
                        FlashLightActivity.this.startTime = 30;
                    } else if (FlashLightActivity.this.startTime == 30) {
                        FlashLightActivity.this.startTime = 40;
                    } else if (FlashLightActivity.this.startTime == 40) {
                        FlashLightActivity.this.startTime = 50;
                    } else if (FlashLightActivity.this.startTime == 50) {
                        FlashLightActivity.this.startTime = 60;
                    } else if (FlashLightActivity.this.startTime == 60) {
                        FlashLightActivity.this.startTime = 0;
                    }
                    FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " s");
                    if (FlashLightActivity.this.isFlashLightOn && FlashLightActivity.this.startTime != 0) {
                        if (FlashLightActivity.this.timer != null) {
                            FlashLightActivity.this.timer.cancel();
                            FlashLightActivity.this.timer = null;
                        }
                        FlashLightActivity flashLightActivity = FlashLightActivity.this;
                        FlashLightActivity flashLightActivity2 = FlashLightActivity.this;
                        flashLightActivity.timer = new MyCounter(flashLightActivity2.startTime * 1000, 200);
                        FlashLightActivity.this.timer.start();
                        FlashLightActivity.this.istimeon = true;
                    }
                }
            });

            this.tourch.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (FlashLightActivity.this.tinyDB.getBoolean("purchased")) {
                        String str = "onClick: ";
                        if (FlashLightActivity.this.isFlashLightOn) {
                            FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_off);
                            Log.e("flash else", str + FlashLightActivity.this.isFlashLightOn);
                            FlashLightActivity.this.isFlashLightOn = false;
                            FlashLightActivity.this.tourch.setImageResource(R.drawable.power_off);
                            if (FlashLightActivity.this.timer != null) {
                                FlashLightActivity.this.timer.cancel();
                                FlashLightActivity.this.timer = null;
                                FlashLightActivity.this.startTime = 0;
                                FlashLightActivity.this.istimeon = false;
                                FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " S");
                            }
                        } else {
                            Log.e("flash", str + FlashLightActivity.this.isFlashLightOn);
                            FlashLightActivity.this.isFlashLightOn = true;
                            FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_on);
                            FlashLightActivity.this.tourch.setImageResource(R.drawable.power_on);
                            if (FlashLightActivity.this.startTime != 0) {
                                if (FlashLightActivity.this.timer != null) {
                                    FlashLightActivity.this.timer.cancel();
                                    FlashLightActivity.this.timer = null;
                                }
                                FlashLightActivity flashLightActivity = FlashLightActivity.this;
                                FlashLightActivity flashLightActivity2 = FlashLightActivity.this;
                                flashLightActivity.timer = new MyCounter(1000 * flashLightActivity2.startTime, 200);
                                FlashLightActivity.this.timer.start();
                                FlashLightActivity.this.istimeon = true;
                            }
                        }
                        new Handler().postDelayed(new Runnable() {
                            public void run() {
                                if (FlashLightActivity.this.fcount == 0) {
                                    FlashLightActivity.this.setOnOff(FlashLightActivity.this.isFlashLightOn);
                                    return;
                                }
                                Log.e("fcount", "onClick: " + FlashLightActivity.this.dtime + "  " + FlashLightActivity.this.fcount);
                                if (FlashLightActivity.this.isFlashLightOn) {
                                    new MyTask().execute();
                                } else {
                                    FlashLightActivity.this.setOnOff(false);
                                }
                            }
                        }, 100);
                        return;
                    }

                    /*Fragment newInstance = StartFreeTrialDialog.newInstance(FlashLightActivity.this, new StartFreeTrialDialog.Callback() {
                        public void OnResult() {
                            Fragment findFragmentByTag = FlashLightActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                FlashLightActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            String str = "onClick: ";
                            if (FlashLightActivity.this.isFlashLightOn) {
                                FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_off);
                                Log.e("flash else", str + FlashLightActivity.this.isFlashLightOn);
                                FlashLightActivity.this.isFlashLightOn = false;
                                FlashLightActivity.this.tourch.setImageResource(R.drawable.power_off);
                                if (FlashLightActivity.this.timer != null) {
                                    FlashLightActivity.this.timer.cancel();
                                    FlashLightActivity.this.timer = null;
                                    FlashLightActivity.this.startTime = 0;
                                    FlashLightActivity.this.istimeon = false;
                                    FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " S");
                                }
                            } else {
                                Log.e("flash", str + FlashLightActivity.this.isFlashLightOn);
                                FlashLightActivity.this.isFlashLightOn = true;
                                FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_on);
                                FlashLightActivity.this.tourch.setImageResource(R.drawable.power_on);
                                if (FlashLightActivity.this.startTime != 0) {
                                    if (FlashLightActivity.this.timer != null) {
                                        FlashLightActivity.this.timer.cancel();
                                        FlashLightActivity.this.timer = null;
                                    }
                                    FlashLightActivity.this.timer = new MyCounter(1000 * FlashLightActivity.this.startTime, 200);
                                    FlashLightActivity.this.timer.start();
                                    FlashLightActivity.this.istimeon = true;
                                }
                            }
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    if (FlashLightActivity.this.fcount == 0) {
                                        FlashLightActivity.this.setOnOff(FlashLightActivity.this.isFlashLightOn);
                                        return;
                                    }
                                    Log.e("fcount", "onClick: " + FlashLightActivity.this.dtime + "  " + FlashLightActivity.this.fcount);
                                    if (FlashLightActivity.this.isFlashLightOn) {
                                        new MyTask().execute();
                                    } else {
                                        FlashLightActivity.this.setOnOff(false);
                                    }
                                }
                            }, 100);
                        }

                        public void OnSubscribed() {
                            Fragment findFragmentByTag = FlashLightActivity.this.getSupportFragmentManager().findFragmentByTag(StartFreeTrialDialog.TAG);
                            if (findFragmentByTag != null) {
                                FlashLightActivity.this.getSupportFragmentManager().beginTransaction().remove(findFragmentByTag).commitAllowingStateLoss();
                            }
                            String str = "onClick: ";
                            if (FlashLightActivity.this.isFlashLightOn) {
                                FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_off);
                                Log.e("flash else", str + FlashLightActivity.this.isFlashLightOn);
                                FlashLightActivity.this.isFlashLightOn = false;
                                FlashLightActivity.this.tourch.setImageResource(R.drawable.power_off);
                                if (FlashLightActivity.this.timer != null) {
                                    FlashLightActivity.this.timer.cancel();
                                    FlashLightActivity.this.timer = null;
                                    FlashLightActivity.this.startTime = 0;
                                    FlashLightActivity.this.istimeon = false;
                                    FlashLightActivity.this.timetxt.setText(FlashLightActivity.this.startTime + " S");
                                }
                            } else {
                                Log.e("flash", str + FlashLightActivity.this.isFlashLightOn);
                                FlashLightActivity.this.isFlashLightOn = true;
                                FlashLightActivity.this.iv_moon.setImageResource(R.drawable.moon_on);
                                FlashLightActivity.this.tourch.setImageResource(R.drawable.power_on);
                                if (FlashLightActivity.this.startTime != 0) {
                                    if (FlashLightActivity.this.timer != null) {
                                        FlashLightActivity.this.timer.cancel();
                                        FlashLightActivity.this.timer = null;
                                    }
                                    FlashLightActivity.this.timer = new MyCounter(1000 * FlashLightActivity.this.startTime, 200);
                                    FlashLightActivity.this.timer.start();
                                    FlashLightActivity.this.istimeon = true;
                                }
                            }
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    if (FlashLightActivity.this.fcount == 0) {
                                        FlashLightActivity.this.setOnOff(FlashLightActivity.this.isFlashLightOn);
                                        return;
                                    }
                                    Log.e("fcount", "onClick: " + FlashLightActivity.this.dtime + "  " + FlashLightActivity.this.fcount);
                                    if (FlashLightActivity.this.isFlashLightOn) {
                                        new MyTask().execute();
                                    } else {
                                        FlashLightActivity.this.setOnOff(false);
                                    }
                                }
                            }, 100);
                        }
                    });
                    FragmentTransaction beginTransaction = FlashLightActivity.this.getSupportFragmentManager().beginTransaction();
                    beginTransaction.replace((int) R.id.frame_container, newInstance, StartFreeTrialDialog.TAG);
                    beginTransaction.commitAllowingStateLoss();*/
                }
            });
            return;
        }
        Toast.makeText(this, "Sorry, you device does not have any camera", Toast.LENGTH_LONG).show();
    }


    public void onBackPressed() {
        if (ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(activity);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        TextView tvMessage;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        tvMessage = dialog.findViewById(R.id.tvPro);

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }


    private void toggle(long j, long j2) {
        if (this.isFlashLightOn) {
            try {
                int i = 0;
                boolean z = !this.toggle;
                this.toggle = z;
                if (z) {
                    while (i < 1) {
                        setOnOff(true);
                        i++;
                    }
                    Thread.sleep(j);
                    return;
                }
                for (int i2 = 0; i2 < 1; i2++) {
                    setOnOff(false);
                }
                Thread.sleep(j2);
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.e("error", "toggle: " + e.getMessage());
            }
        }
    }

    public void setOnOff(boolean z) {
        if (this.prefManager.getLightOption().equals("torch")) {
            switchFlashLight(z);
        } else if (this.prefManager.getLightOption().equals("phone")) {
            switchPhoneLight(z);
        } else {
            String str = "both";
            if (this.prefManager.getLightOption().equals(str)) {
                Log.e(str, "setOnOff: " + this.prefManager.getLightOption());
                switchFlashLight(z);
                switchPhoneLight(z);
            }
        }
    }

    public void switchFlashLight(boolean z) {
        if (VERSION.SDK_INT >= 23) {
            try {
                CameraManager cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
                this.camManager = cameraManager;
                if (cameraManager != null) {
                    this.camManager.setTorchMode(cameraManager.getCameraIdList()[0], z);
                    return;
                }
                return;
            } catch (CameraAccessException e) {
                Log.e("TAG", e.toString());
                return;
            }
        }
        Camera camera = this.camera;
        if (camera != null) {
            camera.stopPreview();
            this.camera.release();
            this.camera = null;
        }
        camera = Camera.open(0);
        this.camera = camera;
        Parameters parameters = camera.getParameters();
        this.parameter = parameters;
        if (z) {
            parameters.setFlashMode("torch");
            this.camera.setParameters(this.parameter);
            this.camera.startPreview();
            return;
        }
        parameters.setFlashMode("off");
        this.camera.setParameters(this.parameter);
        this.camera.stopPreview();
        this.camera.release();
        this.camera = null;
    }

    public void switchPhoneLight(boolean z) {
        if (z) {
            runOnUiThread(new Runnable() {
                public void run() {
                    FlashLightActivity.this.main_layout.setBackgroundColor(FlashLightActivity.this.getResources().getColor(R.color.white));
                    FlashLightActivity.this.top.setVisibility(View.INVISIBLE);
                    FlashLightActivity.this.bottom.setVisibility(View.INVISIBLE);
                    FlashLightActivity.this.toolbar.setVisibility(View.INVISIBLE);
                }
            });
        } else if (this.fcount == 0) {
            this.main_layout.setBackgroundResource(R.drawable.bg_main);
            this.top.setVisibility(View.VISIBLE);
            this.bottom.setVisibility(View.VISIBLE);
            this.toolbar.setVisibility(View.VISIBLE);
        } else {
            runOnUiThread(new Runnable() {
                public void run() {
                    FlashLightActivity.this.main_layout.setBackgroundColor(FlashLightActivity.this.getResources().getColor(R.color.black));
                    if (!FlashLightActivity.this.isFlashLightOn) {
                        FlashLightActivity.this.main_layout.setBackgroundResource(R.drawable.bg_main);
                        FlashLightActivity.this.top.setVisibility(View.VISIBLE);
                        FlashLightActivity.this.bottom.setVisibility(View.VISIBLE);
                        FlashLightActivity.this.toolbar.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    }

    public void unselect() {
        this.tourchlight.setImageResource(R.drawable.torch);
        this.phonelight.setImageResource(R.drawable.phone_light);
        this.both.setImageResource(R.drawable.both);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void flashLightOn() {
        try {
            String str = this.camManager.getCameraIdList()[0];
            this.cameraId = str;
            this.camManager.setTorchMode(str, true);
            this.isFlashLightOn = true;
        } catch (Exception e) {
            Log.e("error", "flashLightOn: " + e.getMessage());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void flashLightOff() {
        try {
            String str = this.camManager.getCameraIdList()[0];
            this.cameraId = str;
            this.camManager.setTorchMode(str, false);
            this.isFlashLightOn = false;
        } catch (Exception e) {
            Log.e("error", "flashLightOff: " + e.getMessage());
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
        }
        return true;
    }

    public void onStop() {
        super.onStop();
        CountDownTimer countDownTimer = this.timer;
        if (countDownTimer != null) {
            this.startTime = 0;
            countDownTimer.cancel();
            this.timer = null;
            this.timetxt.setText(this.startTime + " s");
        }
    }


    public void onPause() {
        super.onPause();
    }


    public void onResume() {
        super.onResume();
    }


    public void onStart() {
        super.onStart();
    }


    public void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.timer;
        if (countDownTimer != null) {
            this.startTime = 0;
            countDownTimer.cancel();
            this.timetxt.setText(this.startTime + " s");
        }
        Camera camera = this.camera;
        if (camera != null) {
            camera.stopPreview();
            this.camera.release();
            this.camera = null;
        }
    }
}
