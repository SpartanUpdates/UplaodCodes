package com.kotlinz.festivalstorymaker.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.DashBord.AllModuleAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModule;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModuleResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashBordActivity extends AppCompatActivity {

    Activity activity = DashBordActivity.this;

    private static final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    public AlertDialog alertDialog;

    @BindView(R.id.rl_main_Data)
    RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    LinearLayout llRetry;

    @BindView(R.id.iv_menu)
    ImageView ivMenu;


    APIInterface apiInterface;

    RecyclerView rvAllModule;

    ArrayList<AllModule> allModulesList = new ArrayList<>();
    AllModuleAdapter allModuleAdapter;
    public GridLayoutManager mLayoutManager;

    public int ModuleId;

    Gson gson = new Gson();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashbord);
        ButterKnife.bind(this);
        rvAllModule = findViewById(R.id.rv_all_module);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        SetDashboardsAllModuleData();
        RequestPermission(false, true);
        PutAnalyticsEvent();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "DashBordActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetAllModule();
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }

    @OnClick(R.id.iv_menu)
    public void PopUpDialog() {
        PopupMenu popup = new android.widget.PopupMenu(activity, ivMenu);
        popup.getMenuInflater().inflate(R.menu.menu_dialog, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.privacy_policy:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                        startActivity(intent1);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.rate_us:
                    try {
                        startActivity(new Intent("android.intent.action.VIEW", Uri
                                .parse("market://details?id=" + getApplicationContext().getPackageName())));
                    } catch (ActivityNotFoundException ex) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri
                                .parse("http://play.google.com/store/apps/details?id="
                                        + getApplicationContext().getPackageName())));
                    }
                    break;
                case R.id.feedback:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.feedback)));
                        startActivity(intent1);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
            }
            return true;
        });
        popup.show();
    }


    private void SetDashboardsAllModuleData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                GetAllModule();

            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.AllModuleDataResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetAllModule();
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {

                SetOfflineData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData));
            }
        }
    }

    private void GetAllModule() {
        Call<AllModuleResponse> call = apiInterface.getAllModule(AppConstant.token, AppConstant.ApplicationId);
        call.enqueue(new Callback<AllModuleResponse>() {
            @Override
            public void onResponse(Call<AllModuleResponse> call, Response<AllModuleResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.AllModuleData);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.AllModuleDataResponseTime);
                    SetOfflineData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<AllModuleResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void SetOfflineData(String response) {
        AllModuleResponse allModuleResponse = gson.fromJson(response, AllModuleResponse.class);
        allModulesList = allModuleResponse.getData();
        allModuleAdapter = new AllModuleAdapter(activity, allModulesList);
        mLayoutManager = new GridLayoutManager(activity, 2, GridLayoutManager.VERTICAL, false);
        rvAllModule.setLayoutManager(mLayoutManager);
        rvAllModule.setAdapter(allModuleAdapter);
    }

    private void RequestPermission(boolean z, boolean isFromFirst) {
        if ((ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            if (isFromFirst) {
                Utils.CreateDirectory();
            }
        } else if (z) {
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
            alertDialogBuilder.setTitle("Necessary permission");
            alertDialogBuilder.setMessage("Allow Required Permission");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    PremissionFromSetting();
                }
            });

            alertDialogBuilder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
            } else {
                RequestPermission(true, true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    Utils.CreateDirectory();
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    RequestPermission(true, true);
                }
            }
        }
    }

    public void PremissionFromSetting() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }


    public void PosterMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 1;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, PosterMakerActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, PosterMakerActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void StoryMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 2;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "Story Maker");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "Story Maker");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void PreDesignArtbord() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 7;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "PreDesign ArtBord");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "PreDesign ArtBord");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void ThematicTemplate() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "Thematic Template");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "Thematic Template");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void WishMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 10;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "Wish Maker");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "Wish Maker");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void OfferPoster() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 11;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "Offer Poster");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "Offer Poster");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void FestivalPoster() {
        /*if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 12;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsForm", "Festival");
                intent.putExtra("moduleid", ModOuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsForm", "Festival");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }*/
        Toast.makeText(activity, "Coming Soon.", Toast.LENGTH_SHORT).show();
    }

    public void CollageMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 3;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, CollageMakerActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, CollageMakerActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void ZoomCollage() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 8;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, HighlightDetailActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, HighlightDetailActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void QuoteMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 6;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, QuoteMakerDetailActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, QuoteMakerDetailActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    @Override
    public void onBackPressed() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 13;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                GoToExit();
            }
        } else {
            GoToExit();
            MyApplication.isShowAd = 0;
        }

    }

    private void GoToExit() {
        startActivity(new Intent(activity, ExitActivity.class));
        finish();
    }
}