package com.Pulse.VideoStatus.videolib.libffmpeg;

public class ExecuteBinaryResponseHandler
  implements FFmpegExecuteResponseHandler
{
  public ExecuteBinaryResponseHandler() {}
  
  public void onSuccess(String message) {}
  
  public void onProgress(String message) {}
  
  public void onFailure(String message) {}
  
  public void onStart() {}
  
  public void onFinish() {}
}
