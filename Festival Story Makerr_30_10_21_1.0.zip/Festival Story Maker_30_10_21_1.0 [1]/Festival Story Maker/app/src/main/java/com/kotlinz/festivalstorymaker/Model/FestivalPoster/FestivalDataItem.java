package com.kotlinz.festivalstorymaker.Model.FestivalPoster;

import com.google.gson.annotations.SerializedName;

public class FestivalDataItem {

	@SerializedName("festival_id")
	private String festivalId;

	@SerializedName("image")
	private String image;

	@SerializedName("thumb")
	private String thumb;

	@SerializedName("is_free")
	private String isFree;

	@SerializedName("id")
	private String id;

	@SerializedName("video")
	public String video;

	public String getFestivalId(){
		return festivalId;
	}

	public String getImage(){
		return image;
	}

	public String getThumb(){
		return thumb;
	}

	public String getIsFree(){
		return isFree;
	}

	public String getId(){
		return id;
	}

	public String getVideo(){
		return video;
	}

	public void setFestivalId(String festivalId) {
		this.festivalId = festivalId;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setThumb(String thumb) {
		this.thumb = thumb;
	}

	public void setIsFree(String isFree) {
		this.isFree = isFree;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setVideo(String video) {
		this.video = video;
	}
}