package com.example.knowledgetrivia.controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;

import com.example.knowledgetrivia.R;
import com.example.knowledgetrivia.database.DatabaseHelper;
import com.example.knowledgetrivia.database.FavouriteDatabaseHelper;
import com.example.knowledgetrivia.helper.Option;
import com.example.knowledgetrivia.manager.QuestionManager;
import com.example.knowledgetrivia.models.LevelScore;
import com.example.knowledgetrivia.models.Question;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.muddzdev.styleabletoast.StyleableToast;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class ShowingQuestion extends AppCompatActivity {
    Activity activity=ShowingQuestion.this;
    private Option answeKey;
    private RelativeLayout bodyLayout;
    private CircularProgressBar circularProgressBar;
    private String[] colorArray;
    private MediaPlayer correctSound;
    private CountDownTimer countDownTimer;
    private Question currentQuestion;
    private DatabaseHelper databaseHelper;
    private ConstraintLayout favLay;
    private FavouriteDatabaseHelper favouriteDatabaseHelper;
    private ImageView favouriteImage;
    private ArrayList<Integer> favouriteQuestionsNo;
    private int index;
    private Intent intent;
    private int levelNum;
    private QuestionManager manager;
    private int milliSecondsRemaining = 31000;
    private TextView optionA;
    private TextView optionB;
    private TextView optionC;
    private TextView optionD;
    private TextView question_Text;
    private ArrayList<Question> questions;
    private TextView questiontext;
    private Random random;
    private ConstraintLayout reportLay;
    private TextView scoreText;
    private TextView score_text;
    private MediaPlayer tick;
    private TextView timeRemainingLabel;
    private int timecount = 0;
    private TextView totalQuestion;
    private int totalScore = 0;
    private MediaPlayer wrongSound;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);

        setContentView(R.layout.activity_showing_question);
        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));

        init();

        executeQuestion();
        BannerAds();
    }

    private void startingCountDownTimer(int i)
    {
        this.countDownTimer = new CountDownTimer((long) i, 100)
        {
            public void onTick(long j) {
                int i = (int) j;
                ShowingQuestion.this.milliSecondsRemaining = i;
                float f = (100.0f - (((float) j) / 310.0f)) + 1.0f;
                ShowingQuestion.this.timecount = i / 1000;
                ShowingQuestion.this.circularProgressBar.setProgress(f);
                TextView access$400 = ShowingQuestion.this.timeRemainingLabel;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(ShowingQuestion.this.timecount);
                stringBuilder.append(" s");
                access$400.setText(stringBuilder.toString());
            }

            public void onFinish()
            {
                new StyleableToast.Builder(ShowingQuestion.this.getApplicationContext()).text("Time's up").
                        backgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.sad_color))
                        .textColor(-1).length(0).iconStart(R.drawable.sad).solidBackground().show();
                ShowingQuestion.this.execute(Option.Z);
            }
        }.start();
    }

    private void init() {
        this.manager = QuestionManager.getInstance(this);
        this.questiontext = (TextView) findViewById(R.id.ly_sq_question);
        this.optionA = (TextView) findViewById(R.id.ly_sq_optionA);
        this.optionB = (TextView) findViewById(R.id.ly_sq_optionB);
        this.optionC = (TextView) findViewById(R.id.ly_sq_optionC);
        this.optionD = (TextView) findViewById(R.id.ly_sq_optionD);
        this.bodyLayout = (RelativeLayout) findViewById(R.id.lay_sq_body);
        this.score_text = (TextView) findViewById(R.id.lay_sq_score);
        this.totalQuestion = (TextView) findViewById(R.id.lay_sq_totalQuestion);
        this.question_Text = (TextView) findViewById(R.id.lay_sq_title_questions);
        this.scoreText = (TextView) findViewById(R.id.lay_sq_score_title);
        this.circularProgressBar = (CircularProgressBar) findViewById(R.id.circularProgressBar);
        this.timeRemainingLabel = (TextView) findViewById(R.id.shwoingQuestion_seconds);
        this.databaseHelper = new DatabaseHelper(this);
        this.favouriteDatabaseHelper = new FavouriteDatabaseHelper(this);
        this.favLay = (ConstraintLayout) findViewById(R.id.fav_lay_question);
        this.reportLay = (ConstraintLayout) findViewById(R.id.report_lay_question);
        this.favouriteImage = (ImageView) findViewById(R.id.showingQuestion_favourite);
        this.favouriteQuestionsNo = this.favouriteDatabaseHelper.getFavouriteQuestions();

        this.colorArray = getResources().getStringArray(R.array.bgcolors);

        this.random = new Random();


        this.correctSound = MediaPlayer.create(this, R.raw.correct);
        this.wrongSound = MediaPlayer.create(this, R.raw.wrong);
        this.tick = MediaPlayer.create(this, R.raw.tick);

        this.optionA.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                ShowingQuestion.this.execute(Option.A);
            }
        });

        this.optionB.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                ShowingQuestion.this.execute(Option.B);
            }
        });

        this.optionC.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                ShowingQuestion.this.execute(Option.C);
            }
        });

        this.optionD.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ShowingQuestion.this.execute(Option.D);
            }
        });

        this.reportLay.setOnClickListener(new OnClickListener()
        {
            public void onClick(View view)
            {
                ShowingQuestion.this.tick.start();

                new FancyAlertDialog.Builder(ShowingQuestion.this).setTitle("Registering a Report!")
                        .setBackgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.happy_color))
                        .setMessage("Do you want to register a report about this question?").setNegativeBtnText("No")
                        .setPositiveBtnBackground(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.happy_color))
                        .setPositiveBtnText("Yes").setNegativeBtnBackground(Color.parseColor("#FFA9A7A8")).setAnimation(Animation.POP)
                        .isCancellable(false).setIcon(R.drawable.information, Icon.Visible).OnPositiveClicked(new FancyAlertDialogListener() {
                    public void OnClick() {
                        ShowingQuestion.this.tick.start();

                        ConnectivityManager connectivityManager = (ConnectivityManager) ShowingQuestion.this.getSystemService(CONNECTIVITY_SERVICE);
                        if (connectivityManager == null) {
                            return;
                        }
                        if (connectivityManager.getNetworkInfo(0).getState() == State.CONNECTED || connectivityManager.getNetworkInfo(1).getState() == State.CONNECTED) {
                            Intent intent = new Intent(ShowingQuestion.this, ReportController.class);
                            intent.putExtra("question", ShowingQuestion.this.currentQuestion.getQuestion());
                            intent.putExtra("number", ShowingQuestion.this.currentQuestion.getId());
                            ShowingQuestion.this.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(ShowingQuestion.this.getApplicationContext(), R.anim.slide_in_right, R.anim.slide_out_left).toBundle());
                            return;
                        }
                        new StyleableToast.Builder(ShowingQuestion.this.getApplicationContext()).text("Connect to Internet").backgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.happy_color)).textColor(-1).length(0).iconStart(R.drawable.happy).solidBackground().show();
                    }
                }).OnNegativeClicked(new FancyAlertDialogListener() {
                    public void OnClick() {
                        ShowingQuestion.this.tick.start();
                    }
                }).build();
            }
        });
        this.favLay.setOnClickListener(new OnClickListener() {
            public void onClick(View view)
            {
                ShowingQuestion.this.tick.start();
                try {
                    if (ShowingQuestion.this.favouriteQuestionsNo.contains(Integer.valueOf(ShowingQuestion.this.currentQuestion.getId()))) {
                        ShowingQuestion.this.favouriteDatabaseHelper.removeFromFavouriteTable(ShowingQuestion.this.currentQuestion.getId());
                        ShowingQuestion.this.favouriteQuestionsNo.remove(Integer.valueOf(ShowingQuestion.this.currentQuestion.getId()));
                        ShowingQuestion.this.favouriteImage.setImageResource(R.drawable.heart);
                        new StyleableToast.Builder(ShowingQuestion.this.getApplicationContext()).text("Removed from Favourites").backgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.happy_color)).textColor(-1).iconStart(R.drawable.heart).length(0).solidBackground().show();
                        return;
                    }
                    ShowingQuestion.this.favouriteDatabaseHelper.insertDataInFavouriteTable(ShowingQuestion.this.currentQuestion.getId());
                    ShowingQuestion.this.favouriteQuestionsNo.add(Integer.valueOf(ShowingQuestion.this.currentQuestion.getId()));
                    ShowingQuestion.this.favouriteImage.setImageResource(R.drawable.heartfilled);
                    new StyleableToast.Builder(ShowingQuestion.this.getApplicationContext()).text("Added into Favourites").backgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.happy_color)).textColor(-1).iconStart(R.drawable.heartfilled).length(0).solidBackground().show();
                } catch (Exception e) {
                    new StyleableToast.Builder(ShowingQuestion.this.getApplicationContext()).text("Something went wrong.").backgroundColor(ContextCompat.getColor(ShowingQuestion.this.getApplicationContext(), R.color.sad_color)).textColor(-1).length(0).iconStart(R.drawable.sad).solidBackground().show();
                    e.printStackTrace();
                }
            }
        });
    }

    private void execute(Option option) {
        String str;
        this.countDownTimer.cancel();
        if (option == this.answeKey) {
            this.correctSound.start();
            this.totalScore++;
            TextView textView = this.score_text;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.totalScore);
            stringBuilder.append("");
            textView.setText(stringBuilder.toString());
        } else {
            this.wrongSound.start();
            str = "#D8000C";
            if (option == Option.A) {
                this.optionA.setTextColor(Color.parseColor(str));
                this.optionA.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.B) {
                this.optionB.setTextColor(Color.parseColor(str));
                this.optionB.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.C) {
                this.optionC.setTextColor(Color.parseColor(str));
                this.optionC.setTypeface(Typeface.DEFAULT_BOLD);
            }
            if (option == Option.D) {
                this.optionD.setTextColor(Color.parseColor(str));
                this.optionD.setTypeface(Typeface.DEFAULT_BOLD);
            }
        }
        str = "#228B22";
        if (this.answeKey == Option.A) {
            this.optionA.setTextColor(Color.parseColor(str));
            this.optionA.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.B) {
            this.optionB.setTextColor(Color.parseColor(str));
            this.optionB.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.C) {
            this.optionC.setTextColor(Color.parseColor(str));
            this.optionC.setTypeface(Typeface.DEFAULT_BOLD);
        }
        if (this.answeKey == Option.D) {
            this.optionD.setTextColor(Color.parseColor(str));
            this.optionD.setTypeface(Typeface.DEFAULT_BOLD);
        }

        clickableTextviews(false);

        new Thread()
        {
            public void run()
            {
                try {
                    Thread.sleep(1250);
                    ShowingQuestion.this.runOnUiThread(new Runnable() {
                        public void run()
                        {
                            ShowingQuestion.this.index = ShowingQuestion.this.index + 1;

                            if (ShowingQuestion.this.index < ShowingQuestion.this.questions.size())
                            {

                                String[]colors=getResources().getStringArray(R.array.bgcolors);
                                String randomcolor=colors[new Random().nextInt(colors.length)];

                                //int nextInt = ShowingQuestion.this.random.nextInt(ShowingQuestion.this.colorArray.length);

                                ShowingQuestion.this.bodyLayout.setBackgroundColor(Color.parseColor(randomcolor));

                                ShowingQuestion.this.optionA.setTextColor(Color.parseColor(randomcolor));
                                ShowingQuestion.this.optionB.setTextColor(Color.parseColor(randomcolor));
                                ShowingQuestion.this.optionC.setTextColor(Color.parseColor(randomcolor));
                                ShowingQuestion.this.optionD.setTextColor(Color.parseColor(randomcolor));

                                ShowingQuestion.this.optionA.setTypeface(Typeface.DEFAULT);
                                ShowingQuestion.this.optionB.setTypeface(Typeface.DEFAULT);
                                ShowingQuestion.this.optionC.setTypeface(Typeface.DEFAULT);
                                ShowingQuestion.this.optionD.setTypeface(Typeface.DEFAULT);

                                ShowingQuestion.this.question_Text.setTextColor(Color.parseColor(randomcolor));
                                ShowingQuestion.this.scoreText.setTextColor(Color.parseColor(randomcolor));

                                ShowingQuestion.this.countDownTimer.cancel();

                                ShowingQuestion.this.milliSecondsRemaining = 31000;

                                ShowingQuestion.this.startingCountDownTimer(ShowingQuestion.this.milliSecondsRemaining);

                                ShowingQuestion.this.clickableTextviews(true);

                            }
                            ShowingQuestion.this.showQuestion();
                        }
                    });

                } catch (InterruptedException unused)
                {

                }
            }
        }.start();
    }

    private void executeQuestion() {
        this.manager = QuestionManager.getInstance(this);
        this.levelNum = getIntent().getIntExtra("level", 1);
        this.questions = this.manager.getLevel(this.levelNum).getQuestionlist();
        Collections.shuffle(this.questions);
        showQuestion();
        TextView textView = this.score_text;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.totalScore);
        stringBuilder.append("");
        textView.setText(stringBuilder.toString());
    }

    public void showQuestion()
    {
        if (this.index < this.questions.size()) {
            this.currentQuestion = (Question) this.questions.get(this.index);
            if (this.favouriteQuestionsNo.contains(Integer.valueOf(this.currentQuestion.getId())))
            {
                this.favouriteImage.setImageResource(R.drawable.heartfilled);
            } else {
                this.favouriteImage.setImageResource(R.drawable.heart);
            }
            this.questiontext.setText(this.currentQuestion.getQuestion());
            ArrayList options = this.currentQuestion.getOptions();
            this.optionA.setText((CharSequence) options.get(0));
            this.optionB.setText((CharSequence) options.get(1));
            this.optionC.setText((CharSequence) options.get(2));
            this.optionD.setText((CharSequence) options.get(3));
            int solutionIndex = this.currentQuestion.getSolutionIndex();
            if (solutionIndex == 1) {
                this.answeKey = Option.A;
            }
            if (solutionIndex == 2) {
                this.answeKey = Option.B;
            }
            if (solutionIndex == 3) {
                this.answeKey = Option.C;
            }
            if (solutionIndex == 4) {
                this.answeKey = Option.D;
            }
            TextView textView = this.totalQuestion;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.index + 1);
            stringBuilder.append(" / ");
            stringBuilder.append(String.valueOf(this.questions.size()));
            textView.setText(stringBuilder.toString());
            return;
        }
        this.databaseHelper.insertDataInScoreTable(new LevelScore(this.levelNum, this.totalScore));
        this.countDownTimer.cancel();
        finish();
        this.intent = new Intent(this, ShowingScore.class);
        this.intent.putExtra("currentlevel", this.levelNum);
        this.intent.putExtra("frommenu", false);


        startActivity(this.intent);

    }

    public void onStop() {
        super.onStop();
        this.countDownTimer.cancel();
    }

    public void onDestroy() {
        super.onDestroy();
        this.countDownTimer.cancel();
    }

    public void onBackPressed()
    {
        new FancyAlertDialog.Builder(this).setTitle("Do you really want to Exit?").setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.sad_color)).setMessage("You will lose your progress by quitting this level.").setNegativeBtnText("No").setPositiveBtnBackground(ContextCompat.getColor(getApplicationContext(), R.color.sad_color)).setPositiveBtnText("Quit").setNegativeBtnBackground(Color.parseColor("#FFA9A7A8")).setAnimation(Animation.POP).isCancellable(false).setIcon(R.drawable.cross, Icon.Visible).OnPositiveClicked(new FancyAlertDialogListener()
        {
            public void OnClick() {
                ShowingQuestion.this.tick.start();
                ShowingQuestion.this.finish();
            }
        }).OnNegativeClicked(new FancyAlertDialogListener()
        {
            public void OnClick() {
                ShowingQuestion.this.tick.start();
            }
        }).build();
    }

    public void clickableTextviews(boolean z)
    {
        this.optionA.setClickable(z);
        this.optionB.setClickable(z);
        this.optionC.setClickable(z);
        this.optionD.setClickable(z);
    }

    public void onPause()
    {
        super.onPause();
        this.countDownTimer.cancel();
    }

    public void onResume()
    {
        super.onResume();
        startingCountDownTimer(this.milliSecondsRemaining);
    }

    public void finish()
    {
        super.finish();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdmobBannerId));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
