package com.kotlinz.videoCollage.cmd;

import android.util.Log;

import java.util.ArrayList;

public class ThemeFiveAllHorizontal {
    public static StringBuilder getOrderString(boolean z, ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2) {
        StringBuilder stringBuilder = new StringBuilder();
        if (z) {
            stringBuilder.append("[scale0][scale1][scale2][scale3][scale4]hstack=inputs=5[vidCombine];");
        } else {
            String str;
            ArrayList arrayList3 = new ArrayList();
            int i = 0;
            while (true) {
                str = "save";
                if (i >= arrayList.size()) {
                    break;
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("stackCount.get(i) :: ");
                stringBuilder2.append(arrayList.get(i));
                Log.e(str, stringBuilder2.toString());
                if (!arrayList2.contains(arrayList.get(i))) {
                    arrayList3.add(arrayList.get(i));
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("IMAGE stackCount.get(i) :: ");
                    stringBuilder2.append(arrayList.get(i));
                    Log.e(str, stringBuilder2.toString());
                }
                i++;
            }
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("imagePos.size :: ");
            stringBuilder3.append(arrayList3.size());
            Log.e(str, stringBuilder3.toString());
            if (arrayList3.size() == 1) {
                if (((Integer) arrayList3.get(0)).intValue() == 0) {
                    stringBuilder.append("[scale0]split=4[scale0_1][scale0_2][scale0_3][scale0_4];[scale2]split=3[scale2_1][scale2_2][scale2_3];[scale4]split=3[scale4_1][scale4_2][scale4_3];[scale6]split=3[scale6_1][scale6_2][scale6_3];[scale8]split=3[scale8_1][scale8_2][scale8_3];[scale0_1][scale1][scale4_1][scale6_1][scale8_1]hstack=inputs=5[vid1]; [scale0_2][scale2_1][scale3][scale6_2][scale8_2]hstack=inputs=5[vid2]; [scale0_3][scale2_2][scale4_2][scale5][scale8_3]hstack=inputs=5[vid3]; [scale0_4][scale2_3][scale4_3][scale6_3][scale7]hstack=inputs=5[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2) {
                    stringBuilder.append("[scale1]split=3[scale1_1][scale1_2][scale1_3];[scale2]split=4[scale2_1][scale2_2][scale2_3][scale2_4];[scale4]split=3[scale4_1][scale4_2][scale4_3];[scale6]split=3[scale6_1][scale6_2][scale6_3];[scale8]split=3[scale8_1][scale8_2][scale8_3];[scale0][scale2_1][scale4_1][scale6_1][scale8_1]hstack=inputs=5[vid1]; [scale1_1][scale2_2][scale3][scale6_2][scale8_2]hstack=inputs=5[vid2]; [scale1_2][scale2_3][scale4_2][scale5][scale8_3]hstack=inputs=5[vid3]; [scale1_3][scale2_4][scale4_3][scale6_3][scale7]hstack=inputs=5[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 4) {
                    stringBuilder.append("[scale1]split=3[scale1_1][scale1_2][scale1_3];[scale3]split=3[scale3_1][scale3_2][scale3_3];[scale4]split=4[scale4_1][scale4_2][scale4_3][scale4_4];[scale6]split=3[scale6_1][scale6_2][scale6_3];[scale8]split=3[scale8_1][scale8_2][scale8_3];[scale0][scale3_1][scale4_1][scale6_1][scale8_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale4_2][scale6_2][scale8_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4_3][scale5][scale8_3]hstack=inputs=5[vid3]; [scale1_3][scale3_3][scale4_4][scale6_3][scale7]hstack=inputs=5[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 6) {
                    stringBuilder.append("[scale1]split=3[scale1_1][scale1_2][scale1_3];[scale3]split=3[scale3_1][scale3_2][scale3_3];[scale5]split=3[scale5_1][scale5_2][scale5_3];[scale6]split=4[scale6_1][scale6_2][scale6_3][scale6_4];[scale8]split=3[scale8_1][scale8_2][scale8_3];[scale0][scale3_1][scale5_1][scale6_1][scale8_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale5_2][scale6_2][scale8_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4][scale6_3][scale8_3]hstack=inputs=5[vid3]; [scale1_3][scale3_3][scale5_3][scale6_4][scale7]hstack=inputs=5[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
                } else {
                    stringBuilder.append("[scale1]split=3[scale1_1][scale1_2][scale1_3];[scale3]split=3[scale3_1][scale3_2][scale3_3];[scale5]split=3[scale5_1][scale5_2][scale5_3];[scale7]split=3[scale7_1][scale7_2][scale7_3];[scale8]split=4[scale8_1][scale8_2][scale8_3][scale8_4];[scale0][scale3_1][scale5_1][scale7_1][scale8_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale5_2][scale7_2][scale8_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4][scale7_3][scale8_3]hstack=inputs=5[vid3]; [scale1_3][scale3_3][scale5_3][scale6][scale8_4]hstack=inputs=5[vid4]; [vid1][vid2][vid3][vid4] concat=n=4 [vidCombine];");
                }
            } else if (arrayList3.size() == 2) {
                if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 1) {
                    stringBuilder.append("[scale0]split=3[scale0_1][scale0_2][scale0_3];[scale1]split=3[scale1_1][scale1_2][scale1_3];[scale3]split[scale3_1][scale3_2];[scale5]split[scale5_1][scale5_2];[scale7]split[scale7_1][scale7_2]; [scale0_1][scale1_1][scale2][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale0_2][scale1_2][scale3_1][scale4][scale7_2]hstack=inputs=5[vid2]; [scale0_3][scale1_3][scale3_2][scale5_2][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 3) {
                    stringBuilder.append("[scale0]split=3[scale0_1][scale0_2][scale0_3];[scale2]split[scale2_1][scale2_2];[scale3]split=3[scale3_1][scale3_2][scale3_3];[scale5]split[scale5_1][scale5_2];[scale7]split[scale7_1][scale7_2]; [scale0_1][scale1][scale3_1][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale0_2][scale2_1][scale3_2][scale4][scale7_2]hstack=inputs=5[vid2]; [scale0_3][scale2_2][scale3_3][scale5_2][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 5) {
                    stringBuilder.append("[scale0]split=3[scale0_1][scale0_2][scale0_3];[scale2]split[scale2_1][scale2_2];[scale4]split[scale4_1][scale4_2];[scale5]split=3[scale5_1][scale5_2][scale5_3];[scale7]split[scale7_1][scale7_2]; [scale0_1][scale1][scale4_1][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale0_2][scale2_1][scale3][scale5_2][scale7_2]hstack=inputs=5[vid2]; [scale0_3][scale2_2][scale4_2][scale5_3][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 7) {
                    stringBuilder.append("[scale0]split=3[scale0_1][scale0_2][scale0_3];[scale2]split[scale2_1][scale2_2];[scale4]split[scale4_1][scale4_2];[scale6]split[scale6_1][scale6_2];[scale7]split=3[scale7_1][scale7_2][scale7_3]; [scale0_1][scale1][scale4_1][scale6_1][scale7_1]hstack=inputs=5[vid1]; [scale0_2][scale2_1][scale3][scale6_2][scale7_2]hstack=inputs=5[vid2]; [scale0_3][scale2_2][scale4_2][scale5][scale7_3]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 3) {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale2]split=3[scale2_1][scale2_2][scale2_3];[scale3]split=3[scale3_1][scale3_2][scale3_3];[scale5]split[scale5_1][scale5_2];[scale7]split[scale7_1][scale7_2]; [scale0][scale2_1][scale3_1][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2_2][scale3_2][scale4][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale2_3][scale3_3][scale5_2][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 5) {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale2]split=3[scale2_1][scale2_2][scale2_3];[scale4]split[scale4_1][scale4_2];[scale5]split=3[scale5_1][scale5_2][scale5_3];[scale7]split[scale7_1][scale7_2]; [scale0][scale2_1][scale4_1][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2_2][scale3][scale5_2][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale2_3][scale4_2][scale5_3][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 7) {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale2]split=3[scale2_1][scale2_2][scale2_3];[scale4]split[scale4_1][scale4_2];[scale6]split[scale6_1][scale6_2];[scale7]split=3[scale7_1][scale7_2][scale7_3]; [scale0][scale2_1][scale4_1][scale6_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2_2][scale3][scale6_2][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale2_3][scale4_2][scale5][scale7_3]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 4 && ((Integer) arrayList3.get(1)).intValue() == 5) {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale3]split[scale3_1][scale3_2];[scale4]split=3[scale4_1][scale4_2][scale4_3];[scale5]split=3[scale5_1][scale5_2][scale5_3];[scale7]split[scale7_1][scale7_2]; [scale0][scale3_1][scale4_1][scale5_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale4_2][scale5_2][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4_3][scale5_3][scale6]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 4 && ((Integer) arrayList3.get(1)).intValue() == 7) {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale3]split[scale3_1][scale3_2];[scale4]split=3[scale4_1][scale4_2][scale4_3];[scale6]split[scale6_1][scale6_2];[scale7]split=3[scale7_1][scale7_2][scale7_3]; [scale0][scale3_1][scale4_1][scale6_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale4_2][scale6_2][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4_3][scale5][scale7_3]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                } else {
                    stringBuilder.append("[scale1]split[scale1_1][scale1_2];[scale3]split[scale3_1][scale3_2];[scale5]split[scale5_1][scale5_2];[scale6]split=3[scale6_1][scale6_2][scale6_3];[scale7]split=3[scale7_1][scale7_2][scale7_3]; [scale0][scale3_1][scale5_1][scale6_1][scale7_1]hstack=inputs=5[vid1]; [scale1_1][scale2][scale5_2][scale6_2][scale7_2]hstack=inputs=5[vid2]; [scale1_2][scale3_2][scale4][scale6_3][scale7_3]hstack=inputs=5[vid3]; [vid1][vid2][vid3] concat=n=3 [vidCombine];");
                }
            } else if (arrayList3.size() == 3) {
                if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 1 && ((Integer) arrayList3.get(2)).intValue() == 2) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale1]split[scale1_1][scale1_2];[scale2]split[scale2_1][scale2_2];[scale0_1][scale1_1][scale2_1][scale3][scale6]hstack=inputs=5[vid1]; [scale0_2][scale1_2][scale2_2][scale4][scale5]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 1 && ((Integer) arrayList3.get(2)).intValue() == 4) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale1]split[scale1_1][scale1_2];[scale4]split[scale4_1][scale4_2];[scale0_1][scale1_1][scale2][scale4_1][scale6]hstack=inputs=5[vid1]; [scale0_2][scale1_2][scale3][scale4_2][scale5]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 1 && ((Integer) arrayList3.get(2)).intValue() == 6) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale1]split[scale1_1][scale1_2];[scale6]split[scale6_1][scale6_2];[scale0_1][scale1_1][scale2][scale5][scale6_1]hstack=inputs=5[vid1]; [scale0_2][scale1_2][scale3][scale4][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 3 && ((Integer) arrayList3.get(2)).intValue() == 4) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale3]split[scale3_1][scale3_2];[scale4]split[scale4_1][scale4_2];[scale0_1][scale1][scale3_1][scale4_1][scale6]hstack=inputs=5[vid1]; [scale0_2][scale2][scale3_2][scale4_2][scale5]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 3 && ((Integer) arrayList3.get(2)).intValue() == 6) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale3]split[scale3_1][scale3_2];[scale6]split[scale6_1][scale6_2];[scale0_1][scale1][scale3_1][scale5][scale6_1]hstack=inputs=5[vid1]; [scale0_2][scale2][scale3_2][scale4][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 0 && ((Integer) arrayList3.get(1)).intValue() == 5 && ((Integer) arrayList3.get(2)).intValue() == 6) {
                    stringBuilder.append("[scale0]split[scale0_1][scale0_2];[scale5]split[scale5_1][scale5_2];[scale6]split[scale6_1][scale6_2];[scale0_1][scale1][scale4][scale5_1][scale6_1]hstack=inputs=5[vid1]; [scale0_2][scale2][scale3][scale5_2][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 3 && ((Integer) arrayList3.get(2)).intValue() == 4) {
                    stringBuilder.append("[scale2]split[scale2_1][scale2_2];[scale3]split[scale3_1][scale3_2];[scale4]split[scale4_1][scale4_2];[scale0][scale2_1][scale3_1][scale4_1][scale6]hstack=inputs=5[vid1]; [scale1][scale2_2][scale3_2][scale4_2][scale5]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 3 && ((Integer) arrayList3.get(2)).intValue() == 6) {
                    stringBuilder.append("[scale2]split[scale2_1][scale2_2];[scale3]split[scale3_1][scale3_2];[scale6]split[scale6_1][scale6_2];[scale0][scale2_1][scale3_1][scale5][scale6_1]hstack=inputs=5[vid1]; [scale1][scale2_2][scale3_2][scale4][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else if (((Integer) arrayList3.get(0)).intValue() == 2 && ((Integer) arrayList3.get(1)).intValue() == 5 && ((Integer) arrayList3.get(2)).intValue() == 6) {
                    stringBuilder.append("[scale2]split[scale2_1][scale2_2];[scale5]split[scale5_1][scale5_2];[scale6]split[scale6_1][scale6_2];[scale0][scale2_1][scale4][scale5_1][scale6_1]hstack=inputs=5[vid1]; [scale1][scale2_2][scale3][scale5_2][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                } else {
                    stringBuilder.append("[scale4]split[scale4_1][scale4_2];[scale5]split[scale5_1][scale5_2];[scale6]split[scale6_1][scale6_2];[scale0][scale3][scale4_1][scale5_1][scale6_1]hstack=inputs=5[vid1]; [scale1][scale2][scale4_2][scale5_2][scale6_2]hstack=inputs=5[vid2]; [vid1][vid2] concat=n=2 [vidCombine];");
                }
            }
        }
        return stringBuilder;
    }
}
