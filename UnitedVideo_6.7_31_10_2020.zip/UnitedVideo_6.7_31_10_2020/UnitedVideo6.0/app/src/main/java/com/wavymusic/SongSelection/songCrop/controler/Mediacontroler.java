package com.wavymusic.SongSelection.songCrop.controler;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.MediaPlayer;

import com.wavymusic.SongSelection.activity.PhoneSongActivity;


public class Mediacontroler {
    private AssetManager assetManager;
    private String SongPath = null;
    private MediaPlayer mediaPlayer = new MediaPlayer();

    public Mediacontroler(Context context) {
        assetManager = context.getAssets();
    }

    public String getSongPath() {
        return SongPath;
    }

    public void setSeekposition(long j) {
        mediaPlayer.seekTo((int) j);
    }

    public void setSongPath(String str) {
        SongPath = str;
    }

    public void SetSongSource() {
        mediaPlayer.reset();
        try {
            mediaPlayer.setDataSource(SongPath);
            mediaPlayer.prepare();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer mediaPlayer) {
                    if (PhoneSongActivity.l) {
                        mediaPlayer.start();
                    } else {
                        PhoneSongActivity.l = true;
                    }
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public int getSongposition() {
        return mediaPlayer.getCurrentPosition();
    }

    public void isSongPause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    public boolean isSongPlaying() {
        return mediaPlayer.isPlaying();
    }

    public void isSongStart() {
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    public void isSongStop() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
    }
}
