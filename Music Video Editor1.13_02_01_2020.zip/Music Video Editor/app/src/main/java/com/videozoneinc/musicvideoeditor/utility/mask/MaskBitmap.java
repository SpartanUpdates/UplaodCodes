package com.videozoneinc.musicvideoeditor.utility.mask;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Xfermode;

import java.lang.reflect.Array;
import java.util.Random;

public class MaskBitmap {
    public static float ANIMATED_FRAME = 22.0f;
    public static int ANIMATED_FRAME_CAL;
    public static int ORIGANAL_FRAME;
    public static int TOTAL_FRAME;
    static final Paint PAINT;
    static int[][] ints;
    static Random random;

    static {
        MaskBitmap.ANIMATED_FRAME_CAL = (int) (MaskBitmap.ANIMATED_FRAME - 1.0f);
        MaskBitmap.ORIGANAL_FRAME = 8;
        MaskBitmap.TOTAL_FRAME = 30;
        PAINT = new Paint();
        MaskBitmap.ints = (int[][]) Array.newInstance(Integer.TYPE, 20, 20);
        MaskBitmap.random = new Random();
        MaskBitmap.PAINT.setColor(-16777216);
        MaskBitmap.PAINT.setAntiAlias(true);
        MaskBitmap.PAINT.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    static float a(final int n, final int n2) {
        return (float) Math.sqrt((n * n + n2 * n2) / 4);
    }

    public static Paint getPaint() {
        MaskBitmap.PAINT.setColor(-16777216);
        MaskBitmap.PAINT.setAntiAlias(true);
        MaskBitmap.PAINT.setStyle(Paint.Style.FILL_AND_STROKE);
        return MaskBitmap.PAINT;
    }

    public static void reintRect() {
        MaskBitmap.ints = (int[][]) Array.newInstance(Integer.TYPE, (int) MaskBitmap.ANIMATED_FRAME, (int) MaskBitmap.ANIMATED_FRAME);
        for (int i = 0; i < MaskBitmap.ints.length; ++i) {
            for (int j = 0; j < MaskBitmap.ints[i].length; ++j) {
                MaskBitmap.ints[i][j] = 0;
            }
        }
    }

    public enum EFFECT {
        CIRCLE_IN("Circle in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint(1);
                paint.setColor(-16777216);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float a = MaskBitmap.a(n * 2, n2 * 2);
                final float n4 = a / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n5 = n3;
                paint.setColor(-16777216);
                canvas.drawColor(-16777216);
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                canvas.drawCircle(n / 2.0f, n2 / 2.0f, a - n4 * n5, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_LEFT_BOTTOM("Circle left bottom") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(0.0f, (float) n2, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_LEFT_TOP("CIRCLE LEFT TOP") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(0.0f, 0.0f, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_OUT("Circle out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(n / 2.0f, n2 / 2.0f, MaskBitmap.a(n * 2, n2 * 2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_RIGHT_BOTTOM("Circle right bottom") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle((float) n, (float) n2, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_RIGHT_TOP("Circle right top") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle((float) n, 0.0f, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CROSS_IN("Cross in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                path.lineTo(n7, n9);
                path.lineTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.close();
                path.moveTo(n4, 0.0f);
                final float n10 = n4 - n7;
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n9);
                path.lineTo(n4, n9);
                path.lineTo(n4, 0.0f);
                path.close();
                path.moveTo(n4, n8);
                path.lineTo(n10, n8);
                final float n11 = n8 - n9;
                path.lineTo(n10, n11);
                path.lineTo(n4, n11);
                path.lineTo(n4, n8);
                path.close();
                path.moveTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.lineTo(n7, n11);
                path.lineTo(0.0f, n11);
                path.lineTo(0.0f, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CROSS_OUT("Cross out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                final float n10 = n4 / 2.0f;
                final float n11 = n10 + n7;
                path.moveTo(n11, 0.0f);
                final float n12 = n8 / 2.0f;
                final float n13 = n12 - n9;
                path.lineTo(n11, n13);
                path.lineTo(n4, n13);
                final float n14 = n12 + n9;
                path.lineTo(n4, n14);
                path.lineTo(n11, n14);
                path.lineTo(n11, n8);
                final float n15 = n10 - n7;
                path.lineTo(n15, n8);
                path.lineTo(n15, n13);
                path.lineTo(0.0f, n13);
                path.lineTo(0.0f, n14);
                path.lineTo(n15, n14);
                path.lineTo(n15, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        DIAMOND_IN("Diamond in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                final float n12 = n11 - n9;
                path.moveTo(n10, n12);
                path.lineTo(n10 + n7, n11);
                path.lineTo(n10, n9 + n11);
                path.lineTo(n10 - n7, n11);
                path.lineTo(n10, n12);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        DIAMOND_OUT("Diamond out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint(1);
                paint.setColor(-16777216);
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawColor(-16777216);
                final Path path = new Path();
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n4 - n5 * n6;
                final float n8 = n2;
                final float n9 = n8 - n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                final float n12 = n11 - n9;
                path.moveTo(n10, n12);
                path.lineTo(n10 + n7, n11);
                path.lineTo(n10, n9 + n11);
                path.lineTo(n10 - n7, n11);
                path.lineTo(n10, n12);
                path.close();
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        ECLIPSE_IN("Eclipse in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n2;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final RectF rectF = new RectF(-n9, 0.0f, n9, n4);
                final RectF rectF2 = new RectF(0.0f, -n7, n8, n7);
                final RectF rectF3 = new RectF(n8 - n9, 0.0f, n9 + n8, n4);
                final RectF rectF4 = new RectF(0.0f, n4 - n7, n8, n4 + n7);
                canvas.drawOval(rectF, MaskBitmap.PAINT);
                canvas.drawOval(rectF2, MaskBitmap.PAINT);
                canvas.drawOval(rectF3, MaskBitmap.PAINT);
                canvas.drawOval(rectF4, MaskBitmap.PAINT);
                this.drawText(canvas);
                return bitmap;
            }
        },
        FOUR_TRIANGLE("Four triangle") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                final float n10 = n8 - n9;
                path.lineTo(n4, n10);
                path.lineTo(n4, n8);
                final float n11 = n4 - n7;
                path.lineTo(n11, n8);
                path.lineTo(0.0f, n9);
                path.close();
                path.moveTo(n11, 0.0f);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.lineTo(0.0f, n10);
                path.lineTo(n11, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        HORIZONTAL_COLUMN_DOWNMASK("Horizontal column downmask") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = MaskBitmap.ANIMATED_FRAME_CAL / 2.0f;
                final float n5 = n;
                final float n6 = n5 / (MaskBitmap.ANIMATED_FRAME_CAL / 2.0f);
                final float n7 = n3;
                final float n8 = n2;
                final float n9 = n8 / 2.0f;
                canvas.drawRoundRect(new RectF(0.0f, 0.0f, n6 * n7, n9), 0.0f, 0.0f, paint);
                if (n7 >= 0.5f + n4) {
                    canvas.drawRoundRect(new RectF(n5 - n5 / ((MaskBitmap.ANIMATED_FRAME_CAL - 1) / 2.0f) * (int) (n7 - n4), n9, n5, n8), 0.0f, 0.0f, paint);
                }
                return bitmap;
            }
        },
        HORIZONTAL_RECT("Horizontal rect") {
            @Override
            public Bitmap getMask(int i, final int n, final int n2) {
                final Bitmap bitmap = Bitmap.createBitmap(i, n, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n3 = i / 10.0f;
                final float n4 = n3 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n5 = n2;
                float n6;
                for (i = 0; i < 10; ++i) {
                    n6 = i * n3;
                    canvas.drawRect(new Rect((int) n6, 0, (int) (n6 + n4 * n5), n), paint);
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        LEAF("LEAF") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setStrokeCap(Paint.Cap.BUTT);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                final float n5 = n2 / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n6 = n2;
                path.moveTo(0.0f, n6);
                final float n7 = n;
                final float n8 = n7 / 2.0f;
                final float n9 = n6 / 2.0f;
                path.cubicTo(0.0f, n6, n8 - n4, n9 - n5, n7, 0.0f);
                path.cubicTo(n7, 0.0f, n8 + n4, n9 + n5, 0.0f, n6);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        OPEN_DOOR("OPEN_DOOR") {
            @Override
            public Bitmap getMask(int n, final int n2, int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setStrokeCap(Paint.Cap.BUTT);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                n3 = n2 / MaskBitmap.ANIMATED_FRAME_CAL;
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n5 = n / 2;
                path.moveTo(n5, 0.0f);
                final float n6 = n5 - n4;
                path.lineTo(n6, 0.0f);
                final float n7 = n4 / 2.0f;
                final float n8 = n5 - n7;
                n = n2 / 6;
                final float n9 = n;
                path.lineTo(n8, n9);
                final float n10 = n2 - n;
                path.lineTo(n8, n10);
                final float n11 = n2;
                path.lineTo(n6, n11);
                final float n12 = n4 + n5;
                path.lineTo(n12, n11);
                final float n13 = n5 + n7;
                path.lineTo(n13, n10);
                path.lineTo(n13, n9);
                path.lineTo(n12, 0.0f);
                path.lineTo(n6, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        PIN_WHEEL("PIN_WHEEL") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                path.moveTo(n10, n11);
                path.lineTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(n4, n8);
                path.lineTo(n4, n8 - n9);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4 - n7, 0.0f);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(0.0f, n9);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        RECT_RANDOM("RECT_RANDOM") {
            @Override
            public Bitmap getMask(int i, int j, final int n) {
                final Bitmap bitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n2 = i / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n3 = j / MaskBitmap.ANIMATED_FRAME_CAL;
                float n4;
                float n5;
                for (i = 0; i < MaskBitmap.ints.length; ++i) {
                    for (j = MaskBitmap.random.nextInt(MaskBitmap.ints[i].length); MaskBitmap.ints[i][j] == 1; j = MaskBitmap.random.nextInt(MaskBitmap.ints[i].length)) {
                    }
                    MaskBitmap.ints[i][j] = 1;
                    for (j = 0; j < MaskBitmap.ints[i].length; ++j) {
                        if (MaskBitmap.ints[i][j] == 1) {
                            n4 = i;
                            n5 = j;
                            canvas.drawRoundRect(new RectF(n4 * n2, n5 * n3, (n4 + 1.0f) * n2, (n5 + 1.0f) * n3), 0.0f, 0.0f, paint);
                        }
                    }
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        SKEW_LEFT_MEARGE("SKEW_LEFT_MEARGE") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(n7, 0.0f);
                path.lineTo(0.0f, 0.0f);
                path.close();
                path.moveTo(n4 - n7, n8);
                path.lineTo(n4, n8 - n9);
                path.lineTo(n4, n8);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_LEFT_SPLIT("SKEW_LEFT_SPLIT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                path.lineTo(n4, n8 - n9);
                path.lineTo(n4, n8);
                path.lineTo(n4 - n7, n8);
                path.lineTo(0.0f, n9);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_RIGHT_MEARGE("SKEW_RIGHT_MEARGE") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n8 - n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.close();
                path.moveTo(n4 - n7, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n4, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_RIGHT_SPLIT("SKEW_RIGHT_SPLIT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                final float n10 = n4 - n7;
                path.moveTo(n10, 0.0f);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.lineTo(0.0f, n8 - n9);
                path.lineTo(n10, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SLIDESHOW("Slideshow") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                new Paint(1).setColor(-16777216);
                return Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
            }
        },
        SQUARE_IN("SQUARE_IN") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, 0.0f);
                path.lineTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.lineTo(n7, 0.0f);
                path.moveTo(n4, n8);
                path.lineTo(n4, 0.0f);
                final float n10 = n4 - n7;
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n8);
                path.moveTo(n7, n9);
                path.lineTo(n7, 0.0f);
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n9);
                final float n11 = n8 - n9;
                path.moveTo(n7, n11);
                path.lineTo(n7, n8);
                path.lineTo(n10, n8);
                path.lineTo(n10, n11);
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SQUARE_OUT("SQUARE_OUT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n5 = n3;
                final float n6 = n4 * n5;
                final float n7 = n2 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n5;
                final Canvas canvas = new Canvas(bitmap);
                final float n8 = n / 2;
                final float n9 = n2 / 2;
                canvas.drawRect(new RectF(n8 - n6, n9 - n7, n8 + n6, n9 + n7), paint);
                return bitmap;
            }
        },
        VERTICAL_RECT("VERTICAL_RECT") {
            @Override
            public Bitmap getMask(final int n, int i, final int n2) {
                final Bitmap bitmap = Bitmap.createBitmap(n, i, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n3 = i / 10.0f;
                final float n4 = n2 * n3 / MaskBitmap.ANIMATED_FRAME_CAL;
                float n5;
                for (i = 0; i < 10; ++i) {
                    n5 = i * n3;
                    canvas.drawRect(new Rect(0, (int) n5, n, (int) (n5 + n4)), paint);
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        WIND_MILL("WIND_MILL") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final float a = MaskBitmap.a(n, n2);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final RectF rectF = new RectF();
                final float n4 = n / 2.0f;
                final float n5 = n2 / 2.0f;
                rectF.set(n4 - a, n5 - a, n4 + a, n5 + a);
                final float n6 = n3 * (90.0f / MaskBitmap.ANIMATED_FRAME_CAL);
                canvas.drawArc(rectF, 90.0f, n6, true, paint);
                canvas.drawArc(rectF, 180.0f, n6, true, paint);
                canvas.drawArc(rectF, 270.0f, n6, true, paint);
                canvas.drawArc(rectF, 360.0f, n6, true, paint);
                this.drawText(canvas);
                return bitmap;
            }
        };

        String a;

        private EFFECT(final String a) {
            this.a = "";
            this.a = a;
        }

        public void drawText(final Canvas canvas) {
            final Paint paint = new Paint();
            paint.setTextSize(50.0f);
            paint.setColor(-65536);
        }

        public abstract Bitmap getMask(final int p0, final int p1, final int p2);
    }
}