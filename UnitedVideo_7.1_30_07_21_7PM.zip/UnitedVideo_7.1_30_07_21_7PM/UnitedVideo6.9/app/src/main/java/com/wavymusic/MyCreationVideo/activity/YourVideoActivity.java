package com.wavymusic.MyCreationVideo.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.MyCreationVideo.Adapter.VideoAdapter;
import com.wavymusic.MyCreationVideo.Model.VideoModel;
import com.wavymusic.R;
import com.wavymusic.kprogresshud.KProgressHUD;

import java.io.File;
import java.util.ArrayList;

public class YourVideoActivity extends AppCompatActivity {

    Activity activity = YourVideoActivity.this;
    public ArrayList<VideoModel> videoList;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    String from = "";
    TextView tvcreatevideoNow;
    RecyclerView rvVideoList;
    VideoAdapter videoAdapter;
    private StaggeredGridLayoutManager gridLayoutManager;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private int id;
    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_video);
        from = getIntent().getStringExtra("from");
        PutAnalyticsEvent();
        bindView();
        init();
        BannerAds();
        interstitialAd();
        SetVideoAdapter();
        addListener();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "YourVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.InterstitialAd_id_Wavy));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                requestInterstitial();
                GoToHome();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        txtMainTitle = findViewById(R.id.tv_name);
        llcreatevideo = findViewById(R.id.ll_novideo);
        tvcreatevideoNow = findViewById(R.id.tv_create_now);
        rvVideoList = findViewById(R.id.rvAlubmPhotos);
    }


    private void addListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        tvcreatevideoNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, DashbordActivity.class));
                finish();
            }
        });
    }

    private void init() {
        getVideoList();
        if (videoList.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }

    private void getVideoList() {
        this.videoList = new ArrayList<VideoModel>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getStoryFolderPath() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoData = new VideoModel();
                videoData.videoDuration = cur.getLong(bucketColumn);
                videoData.videoFullPath = cur.getString(data);
                videoData.videoName = cur.getString(name);
                videoData.dateTaken = cur.getLong(dateTaken);
                if (new File(videoData.videoFullPath).exists()) {
                    this.videoList.add(videoData);
                }
            } while (cur.moveToNext());
        }
    }

    private void SetVideoAdapter() {
        if (videoList.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        videoAdapter = new VideoAdapter(activity, videoList);
        gridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        gridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gridLayoutManager);
        rvVideoList.setAdapter(videoAdapter);
        videoAdapter.notifyDataSetChanged();

    }

    public void onBackPressed() {
        if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
            try {
                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        }
        else {
            GoToHome();
        }
    }

    private void GoToHome(){
        Intent intent = new Intent(activity, DashbordActivity.class);
        startActivity(intent);
        finish();
    }
}