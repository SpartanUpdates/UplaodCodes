/*
package com.cybertechinfosoft.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.cybertechinfosoft.photoslideshowwithmusic.R;

public class InterstitialActivity extends Activity implements OnClickListener {
    private Animation animation;
    private ImageView imageView;
    private ImageView imageView1;
    private ImageView imageView2;
    private ImageView imageView3;
    private Animation animation1;
    private Animation animation2;
    private Animation animation3;
    private Animation animation4;
    private Animation heartbeat;
    private TextView imgBtnInstall;
    int uvAdCheck;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.interstitial_installbtn);
        uvAdCheck = getIntent().getIntExtra("UvAd", 0);
        bindview();
    }

    private void bindview() {
        this.imageView = (ImageView) findViewById(R.id.ivImg1);
        this.imageView1 = (ImageView) findViewById(R.id.ivImg2);
        this.imageView2 = (ImageView) findViewById(R.id.ivImg3);
        this.imageView3 = (ImageView) findViewById(R.id.ivImg4);
        this.animation = AnimationUtils.loadAnimation(this, R.anim.exit_scale_anim1);
        findViewById(R.id.ivClose).setOnClickListener(this);
        imgBtnInstall = (TextView) findViewById(R.id.imgBtnInstall);
        imgBtnInstall.setOnClickListener(this);
        this.imageView.setOnClickListener(this);
        this.imageView1.setOnClickListener(this);
        this.imageView2.setOnClickListener(this);
        this.imageView3.setOnClickListener(this);
        this.animation1 = AnimationUtils.loadAnimation(this, R.anim.s_in_from_right);
        this.animation2 = AnimationUtils.loadAnimation(this, R.anim.s_in_from_right1);
        this.animation3 = AnimationUtils.loadAnimation(this, R.anim.s_in_from_right2);
        this.animation4 = AnimationUtils.loadAnimation(this, R.anim.s_in_from_right3);
        this.heartbeat = AnimationUtils.loadAnimation(this, R.anim.heartbeat);
        this.imageView1.startAnimation(this.animation1);
        this.animation1.setAnimationListener(new AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                InterstitialActivity.this.imageView.setVisibility(View.GONE);
                InterstitialActivity.this.imageView2.startAnimation(InterstitialActivity.this.animation2);
                InterstitialActivity.this.imageView2.bringToFront();
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        this.animation2.setAnimationListener(new AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                InterstitialActivity.this.imageView1.setVisibility(View.GONE);
                InterstitialActivity.this.imageView3.startAnimation(InterstitialActivity.this.animation4);
                InterstitialActivity.this.imageView3.bringToFront();
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        this.animation4.setAnimationListener(new AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                InterstitialActivity.this.imageView2.setVisibility(View.GONE);
                InterstitialActivity.this.imageView.startAnimation(InterstitialActivity.this.animation3);
                InterstitialActivity.this.imageView.bringToFront();
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
        this.animation3.setAnimationListener(new AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                InterstitialActivity.this.imageView3.setVisibility(View.GONE);
                InterstitialActivity.this.imageView1.startAnimation(InterstitialActivity.this.animation1);
                InterstitialActivity.this.imageView1.bringToFront();
                imgBtnInstall.startAnimation(InterstitialActivity.this.heartbeat);
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });
    }


    public void onBackPressed() {
        super.onBackPressed();
        gotoActivity();
        finish();
    }

    private void gotoActivity() {
        if (uvAdCheck == 1) {
            final Intent intent = new Intent((Context) this, (Class) ImageEditActivity.class);
            intent.putExtra("isFromCameraNotification", false);
            intent.putExtra("KEY", "FromImageSelection");
            this.startActivity(intent);
        } else if (uvAdCheck == 2) {
            startActivity(new Intent(this, PreviewActivity.class));
            finish();
        }
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.imgBtnInstall) {
            if (id == R.id.ivClose) {
                gotoActivity();
                finish();
            }
            return;
        }
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.uv.unitedvideos.videostory.photoslideshow")));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.uv.unitedvideos.videostory.photoslideshow")));
        }
    }


}*/
