package com.name.nameart.FavDesign;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.FileProvider;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.name.nameart.R;
import com.name.nameart.adapter.StickerAdapter;
import com.name.nameart.kprogresshud.KProgressHUD;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ShareScreen extends AppCompatActivity {

    Activity activity=ShareScreen.this;
    public static int rate_type = 1;
    Bitmap bitmap;
    private ImageView icback;
    private Boolean is_ads_loaded = false;
    private Boolean is_return_to_activity = false;
    ImageView ivIFb;
    ImageView ivInsta;
    ImageView ivOther;
    ImageView ivWhatsApp;
    private ImageView myhome;
    ImageView picture;
    String sharerimgpath;
    private UnifiedNativeAd nativeAd;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.share_screen);

        this.picture = (ImageView) findViewById(R.id.picture);
        this.ivInsta = (ImageView) findViewById(R.id.ivInsta);
        this.ivIFb = (ImageView) findViewById(R.id.ivIFb);
        this.ivWhatsApp = (ImageView) findViewById(R.id.ivWhatsApp);
        this.icback = (ImageView) findViewById(R.id.icback);
        this.myhome = (ImageView) findViewById(R.id.myhome);
        refreshAd();
        interstitialAd();
        this.ivOther = (ImageView) findViewById(R.id.ivOther);
        Intent intent = getIntent();
        this.sharerimgpath = intent.getStringExtra("picture_path");

        Bitmap image = setImage(intent.getStringExtra("picture_path"));


        this.bitmap = image;

        Log.e("IMAAAAA",bitmap.toString());

        if (image != null) {

            this.picture.setImageBitmap(image);
        }
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        this.ivOther.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ShareScreen shareScreen = ShareScreen.this;
                shareScreen.shareImage(shareScreen.bitmap);
            }
        });
        this.ivInsta.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ShareScreen shareScreen = ShareScreen.this;
                shareScreen.shareVideoInsta(shareScreen.bitmap);
            }
        });
        this.ivIFb.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ShareScreen shareScreen = ShareScreen.this;
                shareScreen.shareVideoFb(shareScreen.bitmap);
            }
        });
        this.ivWhatsApp.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ShareScreen shareScreen = ShareScreen.this;
                shareScreen.shareVideoWhatsApp(shareScreen.bitmap);
            }
        });
        this.myhome.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view)
            {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Intent intent = new Intent(ShareScreen.this, HomeScreen.class);
                    startActivity(intent);
                    finish();
                }

            }
        });
        this.icback.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view)
            {
                ShareScreen.this.finish();
            }
        });
    }

    public void shareImage(Bitmap bitmap2) {
        try {
            File file = new File(getExternalCacheDir(), "my_images/");
            file.mkdirs();
            File file2 = new File(file, "Image_123.png");
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                bitmap2.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e2)
            {
                e2.printStackTrace();
            }
            Uri uriForFile = FileProvider.getUriForFile(this, getPackageName()+".provider", file2);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_TEXT, "Create your Name Shadow Art from below link : \n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
            startActivity(Intent.createChooser(intent, "Share with"));
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    private Bitmap setImage(String str) {
        File file = new File(str);
        if (file.exists()) {
            return BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        return null;
    }

    public boolean appInstalledOrNot(String str) {
        try {
            getPackageManager().getPackageInfo(str, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public void shareVideoWhatsApp(Bitmap bitmap2) {
        try {
            if (appInstalledOrNot("com.whatsapp")) {
                File file = new File(getExternalCacheDir(), "my_images/");
                file.mkdirs();
                File file2 = new File(file, "Image_123.png");
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    bitmap2.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                Uri uriForFile = FileProvider.getUriForFile(this ,getPackageName()+".provider", file2);
                Intent intent = new Intent("android.intent.action.SEND");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setPackage("com.whatsapp");
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                intent.setType("image/png");
                intent.putExtra(Intent.EXTRA_TEXT, "Create your Name Shadow Art from below link : \n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share with"));
                return;
            }
            Toast.makeText(this, "Whatsapp is not installed", Toast.LENGTH_SHORT).show();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void shareVideoFb(Bitmap bitmap2) {
        try {
            if (appInstalledOrNot("com.facebook.katana"))
            {
                File file = new File(getExternalCacheDir(), "my_images/");
                file.mkdirs();
                File file2 = new File(file, "Image_123.png");
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    bitmap2.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                Uri uriForFile = FileProvider.getUriForFile(this,getPackageName()+".provider", file2);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setPackage("com.facebook.katana");
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                intent.setType("image/png");
                intent.putExtra(Intent.EXTRA_TEXT, "Create your Name Shadow Art from below link : \n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share with"));
                return;
            }

            Toast.makeText(this, "Facebook is not installed", Toast.LENGTH_SHORT).show();

        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void shareVideoInsta(Bitmap bitmap2) {
        try {
            if (appInstalledOrNot("com.instagram.android")) {
                File file = new File(getExternalCacheDir(), "my_images/");
                file.mkdirs();
                File file2 = new File(file, "Image_123.png");
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    bitmap2.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                Uri uriForFile = FileProvider.getUriForFile(this, getPackageName()+".provider", file2);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setPackage("com.instagram.android");
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                intent.setType("image/png");
                intent.putExtra(Intent.EXTRA_TEXT, "Create your Name Shadow Art from below link : \n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share with"));
                return;
            }
            Toast.makeText(this, "Instagram is not installed", Toast.LENGTH_SHORT).show();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        Intent intent = new Intent(ShareScreen.this, HomeScreen.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (!this.is_ads_loaded.booleanValue()) {
            this.is_return_to_activity = true;
        }
    }
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, HomeScreen.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView)
    {
        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        }
        else
        {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }


        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent())
        {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks()
            {
                @Override
                public void onVideoEnd()
                {
                    super.onVideoEnd();
                }
            });
        }
    }

    private void refreshAd() {

        AdLoader.Builder builder = new AdLoader.Builder(this,getResources().getString(R.string.Admob_Native));

        builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            unifiedNativeAd.destroy();
                            return;
                        }

                        if (nativeAd != null) {
                            nativeAd.destroy();
                        }
                        nativeAd = unifiedNativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        UnifiedNativeAdView adView =
                                (UnifiedNativeAdView) getLayoutInflater()
                                        .inflate(R.layout.ad_unified, null);
                        populateUnifiedNativeAdView(unifiedNativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener()
        {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError)
            {
                String error = String.format("domain: %s, code: %d, message: %s", loadAdError.getDomain(), loadAdError.getCode(), loadAdError.getMessage());
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

}
