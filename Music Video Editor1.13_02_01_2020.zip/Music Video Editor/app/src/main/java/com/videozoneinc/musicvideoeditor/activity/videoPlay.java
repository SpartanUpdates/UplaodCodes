package com.videozoneinc.musicvideoeditor.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.videozoneinc.musicvideoeditor.util.Utils;
import com.videozoneinc.musicvideoeditor.util.apprater.AppRater;
import com.videozoneinc.musicvideoeditor.videolib.libffmpeg.FileUtils;
import com.videozoneinc.musicvideoeditor.view.MyVideoView;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.videozoneinc.musicvideoeditor.R;
import java.io.File;
import java.util.Random;

public class videoPlay extends AppCompatActivity implements MyVideoView.PlayPauseListner, OnClickListener, OnSeekBarChangeListener {

    private int currentVideoDuration;
    private ImageView ivPlayPause;
    private Handler Handler;
    private boolean Complate;
    private String StrVideoPath;
    private Runnable runnable;
    private SeekBar SbVideo;
    private Long CaptureTime;
    private Toolbar toolbar;
    private MyVideoView myVideoView;
    private TextView tvDuration;
    private TextView tvEndDuration;
    private ImageView imgFacebook;
    private ImageView imgInstagram;
    private ImageView imgShare;
    private ImageView imgTwitter;
    private ImageView imgWhatsApp;

    public videoPlay() {
        this.Handler = new Handler();
        this.CaptureTime = Long.valueOf(0);
        this.runnable = new Runnable() {
            @Override
            public void run() {
                if (!videoPlay.this.Complate) {
                    videoPlay.this.currentVideoDuration = videoPlay.this.myVideoView
                            .getCurrentPosition();
                    videoPlay videoPlayActivity = videoPlay.this;
                    videoPlayActivity.CaptureTime = Long
                            .valueOf(videoPlayActivity.CaptureTime.longValue() + 100);
                    videoPlay.this.tvDuration.setText(FileUtils
                            .getDuration((long) videoPlay.this.myVideoView
                                    .getCurrentPosition()));
                    videoPlay.this.tvEndDuration.setText(FileUtils
                            .getDuration((long) videoPlay.this.myVideoView
                                    .getDuration()));
                    videoPlay.this.SbVideo
                            .setProgress(videoPlay.this.currentVideoDuration);
                    videoPlay.this.Handler.postDelayed(this, 100);
                }
            }
        };
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creationvideo_play);
        findViewbyIds();
        this.StrVideoPath = getIntent().getStringExtra("android.intent.extra.TEXT");
        this.myVideoView.setVideoPath(this.StrVideoPath);
        getSupportActionBar().setHomeButtonEnabled(true);
        TextView mTitle = (TextView) this.toolbar.findViewById(R.id.tvtittleToolbar);
        mTitle.setText(getString(R.string.sharemycreation));
        Utils.setFont(this, mTitle);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.myVideoView.setOnPlayPauseListner(this);
        this.myVideoView.setOnPreparedListener(new OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.seekTo(100);
                videoPlay.this.SbVideo.setMax(mp.getDuration());
                videoPlay.this.progressToTimer(mp.getDuration(), mp.getDuration());
                videoPlay.this.tvDuration.setText(FileUtils.getDuration((long) mp.getCurrentPosition()));
                videoPlay.this.tvEndDuration.setText(FileUtils.getDuration((long) mp.getDuration()));
            }
        });
        findViewById(R.id.ClickVideo).setOnClickListener(this);
        this.myVideoView.setOnClickListener(this);
        this.ivPlayPause.setOnClickListener(this);
        this.SbVideo.setOnSeekBarChangeListener(this);
        this.myVideoView.setOnCompletionListener(new OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoPlay.this.Complate = true;
                videoPlay.this.Handler
                        .removeCallbacks(videoPlay.this.runnable);
                videoPlay.this.tvDuration.setText(FileUtils
                        .getDuration((long) mp.getDuration()));
                videoPlay.this.tvEndDuration.setText(FileUtils
                        .getDuration((long) mp.getDuration()));
            }
        });
        loadAd();
        loadAdmobAd();
        this.imgFacebook = (ImageView) findViewById(R.id.imgFacebook);
        this.imgWhatsApp = (ImageView) findViewById(R.id.imgWhatsApp);
        this.imgInstagram = (ImageView) findViewById(R.id.imgInstagram);
        this.imgShare = (ImageView) findViewById(R.id.imgShare);
        this.imgTwitter = (ImageView) findViewById(R.id.imgTwitter);
        this.imgFacebook.setOnClickListener(this);
        this.imgInstagram.setOnClickListener(this);
        this.imgWhatsApp.setOnClickListener(this);
        this.imgTwitter.setOnClickListener(this);
        this.imgShare.setOnClickListener(this);
    }

    private void findViewbyIds() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(this.toolbar);
        this.myVideoView = (MyVideoView) findViewById(R.id.MyvideoView);
        this.tvDuration = (TextView) findViewById(R.id.tvStartDuration);
        this.tvEndDuration = (TextView) findViewById(R.id.tvEndDuration);
        this.ivPlayPause = (ImageView) findViewById(R.id.ivPlayPause);
        this.SbVideo = (SeekBar) findViewById(R.id.VideoSeekbar);
        tvDuration.setSelected(true);
//        tvDuration.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvDuration.setSingleLine(true);
        tvEndDuration.setSelected(true);
//        tvEndDuration.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvEndDuration.setSingleLine(true);
    }


    private void loadAd() {
        if (Utils.Utility.isNetworkAvailable(this)) {
            AdLoader adLoader = new AdLoader.Builder(this, getResources().getString(R.string.Admob_Native))
                    .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                        @Override
                        public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                            NativeTemplateStyle styles = new
                                    NativeTemplateStyle.Builder().build();
                            TemplateView template = findViewById(R.id.my_template);
                            template.setStyles(styles);
                            template.setNativeAd(unifiedNativeAd);
                        }
                    })
                    .build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            findViewById(R.id.nativeAdLayout).setVisibility(View.GONE);
        }
    }

    private InterstitialAd mInterstitialAd;
    int idd;

    private void loadAdmobAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.Admob_Inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {

            @Override
            public void onAdClosed() {
                Intent intent;
                switch (idd) {
                    case 100:
                        intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                        startActivity(intent);
                        finish();
                        break;
                    case 101:
                        intent = new Intent(videoPlay.this, ActivityVideoAlbum.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                        intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
                        startActivity(intent);
                        finish();
                        break;
                    case 102:
                        intent = new Intent(videoPlay.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                        startActivity(intent);
                        finish();
                        break;

                }
                requestNewInterstitialAdmob();
            }
        });

    }

    private void requestNewInterstitialAdmob() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    protected void onPause() {
        super.onPause();
        this.myVideoView.pause();
    }

    public View onCreateView(View view, String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public void onVideoPause() {
        if (!(this.Handler == null || this.runnable == null)) {
            this.Handler.removeCallbacks(this.runnable);
        }
        Animation animation = new AlphaAnimation(0.0f,
                1.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }
        });
    }

    public void onVideoPlay() {
        updateProgressBar();
        Animation animation = new AlphaAnimation(
                1.0f, 0.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                videoPlay.this.ivPlayPause.setVisibility(View.INVISIBLE);
            }
        });
    }

    public void updateProgressBar() {
        try {
            this.Handler.removeCallbacks(this.runnable);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.Handler.postDelayed(this.runnable, 100);
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        this.getMenuInflater().inflate(R.menu.delete_video, menu);
        return true;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.MyvideoView:
            case R.id.ClickVideo:
            case R.id.ivPlayPause:
                if (this.myVideoView.isPlaying()) {
                    this.myVideoView.pause();
                    return;
                }
                this.myVideoView.start();
                this.Complate = false;
                break;
            case R.id.imgFacebook:
                shareImageWhatsApp("com.facebook.katana", "Facebook");
                return;
            case R.id.imgInstagram:
                shareImageWhatsApp("com.instagram.android", "Instagram");
                return;
            case R.id.imgShare:
                Parcelable fromFile;
                if (Build.VERSION.SDK_INT <= 19) {
                    fromFile = Uri.fromFile(new File(this.StrVideoPath));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
                    fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.StrVideoPath));
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/mp4");
                intent.putExtra("android.intent.extra.STREAM", fromFile);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
                return;
            case R.id.imgTwitter:
                shareImageWhatsApp("com.twitter.android", "Twitter");
                return;
            case R.id.imgWhatsApp:
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
                return;
            default:
        }
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    public void shareImageWhatsApp(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(this.StrVideoPath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.StrVideoPath));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/mp4");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }


    public void onProgressChanged(SeekBar seekBar, int progress,
                                  boolean fromUser) {
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
        this.currentVideoDuration = progressToTimer(seekBar.getProgress(),
                this.myVideoView.getDuration());
        this.myVideoView.seekTo(seekBar.getProgress());
        if (this.myVideoView.isPlaying()) {
            updateProgressBar();
        }
    }

    public int progressToTimer(int progress, int totalDuration) {
        return ((int) ((((double) progress) / 100.0d) * ((double) (totalDuration / 1000))))
                * 1000;
    }

    protected void onDestroy() {
        this.myVideoView.stopPlayback();
        this.Handler.removeCallbacks(this.runnable);
        super.onDestroy();
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            case R.id.action_delete:
                if (this.myVideoView.isPlaying()) {
                    this.myVideoView.pause();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(videoPlay.this,
                        R.style.Theme_MovieMaker_AlertDialog);
                builder.setTitle((CharSequence) "Delete Video !");
                builder.setMessage("Are you sure to delete?");
                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FileUtils.deleteFile(new File(
                                StrVideoPath));
                        startActivity(new Intent(videoPlay.this, ActivityVideoAlbum.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", null);
                builder.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        Intent intent;
        if (getIntent().getExtras().get("KEY").equals("FromVideoAlbum")) {
            if (new Random().nextInt(100) > 50) {
                AppRater.showRateDialog(this);
                AppRater.setCallback((AppRater.Callback) new AppRater.Callback() {
                    @Override
                    public void onCancelClicked() {
                        final Intent intent = new Intent((Context) videoPlay.this, (Class) ActivityVideoAlbum.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("EXTRA_FROM_VIDEO", true);
                        videoPlay.this.startActivity(intent);
                        videoPlay.this.finish();
                    }
                });
                return;
            }
            idd = 100;
            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, ActivityVideoAlbum.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                startActivity(intent);
                finish();
            }
        } else if (getIntent().getExtras().get("KEY").equals("FromProgress")) {
            idd = 101;
            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, ActivityVideoAlbum.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                intent.putExtra("KEY", ActivityVideoAlbum.EXTRA_FROM_VIDEO);
                startActivity(intent);
                finish();
            }
        } else if (getIntent().getExtras().get("KEY").equals("FromNotify")) {
            idd = 102;
            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                intent = new Intent(this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(ActivityVideoAlbum.EXTRA_FROM_VIDEO, true);
                startActivity(intent);
                finish();
            }
        } else {
            super.onBackPressed();
        }
    }
}
