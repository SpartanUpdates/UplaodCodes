package com.vidsoft.Filters.scrollgalleryview.Grid3DFilter;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import com.vidsoft.collagemaker.pipphotoeffect.R;

public class PorterShapeImageView extends PorterImageView {
    private Matrix drawMatrix;
    private Matrix matrix;
    private Drawable shape;

    public PorterShapeImageView(Context context) {
        super(context);
        setup(context, null, 0);
    }

    public PorterShapeImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setup(context, attrs, 0);
    }

    public PorterShapeImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setup(context, attrs, defStyle);
    }

    private void setup(Context context, AttributeSet attrs, int defStyle) {
        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ShaderImageView, defStyle, 0);
            this.shape = typedArray.getDrawable(R.styleable.ShaderImageView_siShape);
            typedArray.recycle();
        }
        this.matrix = new Matrix();
    }

    protected void paintMaskCanvas(Canvas maskCanvas, Paint maskPaint, int width, int height) {
        if (this.shape != null) {
            if (this.shape instanceof BitmapDrawable) {
                configureBitmapBounds(width, height);
                if (this.drawMatrix != null) {
                    int drawableSaveCount = maskCanvas.getSaveCount();
                    maskCanvas.save();
                    maskCanvas.concat(this.matrix);
                    this.shape.draw(maskCanvas);
                    maskCanvas.restoreToCount(drawableSaveCount);
                    return;
                }
            }
            this.shape.setBounds(0, 0, width, height);
            this.shape.draw(maskCanvas);
        }
    }

    private void configureBitmapBounds(int viewWidth, int viewHeight) {
        this.drawMatrix = null;
        int drawableWidth = this.shape.getIntrinsicWidth();
        int drawableHeight = this.shape.getIntrinsicHeight();
        boolean fits;
        if (viewWidth == drawableWidth && viewHeight == drawableHeight) {
            fits = true;
        } else {
            fits = false;
        }
        if (drawableWidth > 0 && drawableHeight > 0 && !fits) {
            this.shape.setBounds(0, 0, drawableWidth, drawableHeight);
            float scale = Math.min(((float) viewWidth) / ((float) drawableWidth), ((float) viewHeight) / ((float) drawableHeight));
            float dx = (float) ((int) (((((float) viewWidth) - (((float) drawableWidth) * scale)) * 0.5f) + 0.5f));
            float dy = (float) ((int) (((((float) viewHeight) - (((float) drawableHeight) * scale)) * 0.5f) + 0.5f));
            this.matrix.setScale(scale, scale);
            this.matrix.postTranslate(dx, dy);
        }
    }
}
