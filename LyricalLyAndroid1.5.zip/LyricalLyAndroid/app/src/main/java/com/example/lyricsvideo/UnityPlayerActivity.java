package com.example.lyricsvideo;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AdSettings;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.unity3d.player.UnityPlayer;

import java.util.ArrayList;
import java.util.List;

public class UnityPlayerActivity extends Activity {
    public static UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code
    public static RelativeLayout layoutNativeBanner;
    private NativeAdLayout nativeAdLayout;
    private NativeAd mNativeBannerAd;
    private LinearLayout adView;

    // Setup activity layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        AdSettings.addTestDevice("ed82ec5f-3ede-41b5-8b49-66d656505138");
        getWindow().setFormat(PixelFormat.RGBX_8888); // <--- This makes xperia play happy
        mUnityPlayer = new UnityPlayer(this);
        setContentView(R.layout.unity_ui);
        ((FrameLayout) findViewById(R.id.fram_main)).addView(this.mUnityPlayer, 0);
        layoutNativeBanner = findViewById(R.id.rlNativeBanner);
        mUnityPlayer.requestFocus();
        loadAd();
    }

    // Quit Unity
    @Override
    protected void onDestroy() {
        mUnityPlayer.quit();
        super.onDestroy();
    }

    // Pause Unity
    @Override
    protected void onPause() {
        super.onPause();
        mUnityPlayer.pause();
        if (AppUsages.alertDialog != null && AppUsages.alertDialog.isShowing()) {
            AppUsages.alertDialog.dismiss();
            AppUsages.IsPreview = true;
        }
    }

    // Resume Unity
    @Override
    protected void onResume() {
        super.onResume();
        mUnityPlayer.resume();
        if (AppUsages.IsPreview) {
            UnityPlayer.UnitySendMessage("XMLReader", "ShowPreview", CallFromUnity.UnityXmlPath);
            UnityPlayer.UnitySendMessage("XMLReader", "SpritePathString", CallFromUnity.ImagePath);
        }
    }

    // This ensures the layout will be correct.
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mUnityPlayer.configurationChanged(newConfig);
    }

    // Notify Unity of the focus change.
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mUnityPlayer.windowFocusChanged(hasFocus);
    }

    // For some reason the multiple keyevent type is not supported by the ndk.
    // Force event injection by overriding dispatchKeyEvent().
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayer.injectEvent(event);
        return super.dispatchKeyEvent(event);
    }

    // Pass any events not handled by (unfocused) views straight to UnityPlayer
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    /*API12*/
    public boolean onGenericMotionEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }


    public void loadAd() {
        mNativeBannerAd = new NativeAd(this, getString(R.string.FB_nativebanner));
        nativeAdLayout = findViewById(R.id.banner_container);
        LayoutInflater inflater = LayoutInflater.from(UnityPlayerActivity.this);
        adView = (LinearLayout) inflater.inflate(R.layout.native_ad_unit, nativeAdLayout, false);
        nativeAdLayout.addView(adView);
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (mNativeBannerAd == null || mNativeBannerAd != ad) {
                    return;
                }
                inflateAd(mNativeBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
    }

    private void inflateAd(NativeAd nativeBannerAd) {
        nativeBannerAd.unregisterView();
        LinearLayout llAdContainer = nativeAdLayout.findViewById(R.id.llNativeAdContainer);
        MediaView admedia = nativeAdLayout.findViewById(R.id.native_ad_media);
        TextView adtitle = nativeAdLayout.findViewById(R.id.native_ad_title);
        TextView adbody = nativeAdLayout.findViewById(R.id.native_ad_body);
        TextView adsocial = nativeAdLayout.findViewById(R.id.native_ad_social_context);
        TextView adsponsored = nativeAdLayout.findViewById(R.id.native_ad_sponsored_label);
        Button btnAdAction = nativeAdLayout.findViewById(R.id.native_ad_call_to_action);
        MediaView adicon = nativeAdLayout.findViewById(R.id.native_ad_icon);
        LinearLayout adchoicescontainer = nativeAdLayout.findViewById(R.id.ad_choices_container);
        llAdContainer.setVisibility(View.VISIBLE);
        adtitle.setText(nativeBannerAd.getAdvertiserName());
        adbody.setText(nativeBannerAd.getAdBodyText());
        adsocial.setText(nativeBannerAd.getAdSocialContext());
        adsponsored.setText("Sponsored");
        btnAdAction.setText(nativeBannerAd.getAdCallToAction());
        btnAdAction.setVisibility(nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        adchoicescontainer.addView(new AdOptionsView(llAdContainer.getContext(), nativeBannerAd, nativeAdLayout), 0);
        List arrayList = new ArrayList();
        arrayList.add(adicon);
        arrayList.add(admedia);
        arrayList.add(btnAdAction);
        nativeBannerAd.registerViewForInteraction(nativeAdLayout, admedia, adicon, arrayList);
    }
}
