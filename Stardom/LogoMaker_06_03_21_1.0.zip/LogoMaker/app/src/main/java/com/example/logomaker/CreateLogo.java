package com.example.logomaker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Shader.TileMode;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.text.Layout.Alignment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.internal.view.SupportMenu;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.loader.content.CursorLoader;

import com.bumptech.glide.Glide;
import com.example.logomaker.kprogresshud.KProgressHUD;
import com.example.logomaker.utilities.Constants;
import com.example.logomaker.utilities.Save;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.xiaopo.flying.sticker.DrawableSticker;
import com.xiaopo.flying.sticker.StickerView;

import java.io.File;
import java.io.IOException;
import java.net.URI;

public class CreateLogo extends AppCompatActivity implements OnClickListener, OnSeekBarChangeListener {

    Activity activity = CreateLogo.this;
    ImageView add_bg;
    ImageView add_logo;
    ImageView add_text;
    ImageView addshapes;
    Button cancel;
    ImageView clearData;
    LinearLayout datalayout;
    HorizontalScrollView infoHorizentallayout;
    LinearLayout infoLayout;
    ImageView lock;
    RelativeLayout mainlayout;
    Button ok;
    ImageView save;
    SeekBar seekbar;
    int seekno = 0;
    ImageView share;
    StickerView stickerView;
    EditText text_input;
    RelativeLayout text_input_layout;
    private static final int SELECT_SINGLE_PICTURE = 101;
    public static final String IMAGE_TYPE = "image/*";

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.create_logo);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        interstitialAd();

        text_input_layout = findViewById(R.id.addtextlayout);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setSoftInputMode(48);
        this.stickerView = (StickerView) findViewById(R.id.sticker_view);
        ImageView imageView = (ImageView) findViewById(R.id.addtext);
        this.add_text = imageView;
        imageView.setOnClickListener(this);
        add_bg = (ImageView) findViewById(R.id.iv_background);
        add_bg.setOnClickListener(this);
        imageView = (ImageView) findViewById(R.id.logos);
        this.add_logo = imageView;
        imageView.setOnClickListener(this);
        imageView = (ImageView) findViewById(R.id.shapes);
        this.addshapes = imageView;
        imageView.setOnClickListener(this);
        imageView = (ImageView) findViewById(R.id.lock);
        this.lock = imageView;
        imageView.setOnClickListener(this);
        imageView = (ImageView) findViewById(R.id.save);
        this.save = imageView;
        imageView.setOnClickListener(this);
        imageView = (ImageView) findViewById(R.id.clearitems);
        this.clearData = imageView;
        imageView.setOnClickListener(this);
        this.infoHorizentallayout = (HorizontalScrollView) findViewById(R.id.allinfolayout);
        this.infoLayout = (LinearLayout) findViewById(R.id.info);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.mainlayout);
        this.mainlayout = relativeLayout;
        relativeLayout.setOnClickListener(this);
        this.datalayout = (LinearLayout) findViewById(R.id.infor);
        SeekBar seekBar = (SeekBar) findViewById(R.id.opacity_handler);
        this.seekbar = seekBar;
        seekBar.setOnSeekBarChangeListener(this);
        this.seekbar.setMax(255);
        this.seekbar.setProgress(255);
    }

    public void addTextInfo() {
        RelativeLayout text_input_layout = (RelativeLayout) findViewById(R.id.addtextlayout);
        text_input_layout.setVisibility(View.VISIBLE);
        this.text_input = (EditText) findViewById(R.id.textarea);
        this.ok = (Button) findViewById(R.id.add);
        this.cancel = (Button) findViewById(R.id.cancel);
        this.ok.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (CreateLogo.this.text_input.getText().toString().length() > 0) {
                    MyTextSticker myTextSticker = new MyTextSticker(CreateLogo.this);
                    myTextSticker.setText(CreateLogo.this.text_input.getText().toString());
                    myTextSticker.setTextAlign(Alignment.ALIGN_CENTER);
                    myTextSticker.resizeText();
                    myTextSticker.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                    CreateLogo.this.stickerView.addSticker(myTextSticker);
                    CreateLogo.this.stickerView.invalidate();
                    CreateLogo.this.text_input.setText("");
                    CreateLogo.this.text_input_layout.setVisibility(View.GONE);

                    InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    return;
                }
                Toast.makeText(CreateLogo.this, "No Input", Toast.LENGTH_SHORT).show();
            }
        });
        this.cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                text_input.setImeOptions(EditorInfo.IME_ACTION_DONE);
                CreateLogo.this.text_input.setText("");
                CreateLogo.this.text_input_layout.setVisibility(View.GONE);
                InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        });
    }

    public void addFontText() {

        this.infoLayout.removeAllViews();
        final String[] array = {"f1.ttf", "f2.ttf", "f3.ttf", "f4.ttf", "f5.ttf", "f6.ttf", "f7.ttf", "f8.ttf", "f9.ttf", "f10.ttf", "f11.ttf", "f12.ttf", "f13.ttf", "f14.ttf", "f15.ttf", "f16.ttf", "f17.ttf", "f18.ttf", "f19.ttf", "f20.ttf", "f21.ttf", "f22.ttf", "f23.ttf", "f24.ttf", "f25.ttf", "f26.ttf", "f27.ttf", "f28.ttf", "f29.ttf", "f30.ttf", "f31.ttf", "f32.ttf", "f33.ttf", "f34.ttf", "f35.ttf", "f36.ttf", "f37.ttf", "f38.ttf", "f39.ttf", "f40.ttf", "f41.ttf", "f42.ttf", "f43.ttf", "f44.ttf", "f45.ttf", "f46.ttf", "f47.ttf", "f48.ttf", "f49.ttf", "f50.ttf", "f51.ttf", "f52.ttf", "f53.ttf", "f54.ttf", "f55.ttf", "f56.ttf", "f57.ttf", "f58.ttf", "f59.ttf", "f60.ttf", "f61.ttf", "f62.ttf", "f63.ttf", "f64.ttf", "f65.ttf", "f66.ttf", "f66.ttf", "f67.ttf", "f68.ttf", "f69.ttf", "f70.ttf", "f71.ttf", "f72.ttf", "f73.ttf", "f74.ttf", "f75.ttf", "f76.ttf", "f77.ttf", "f78.ttf", "f78.ttf", "f79.ttf", "f80.ttf", "f81.ttf", "f82.ttf", "f83.ttf", "f84.ttf", "f85.ttf", "f86.ttf", "f88.ttf", "f89.ttf", "f90.ttf", "f91.ttf", "f92.ttf", "f93.ttf", "f94.ttf", "f95.ttf", "f96.ttf", "f97.ttf", "f98.ttf", "f99.ttf", "f100.ttf"};

        this.infoHorizentallayout.setVisibility(View.VISIBLE);
        for (int i = 0; i < 101; i++) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(80, 80));
            linearLayout.setGravity(17);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            TextView textView = new TextView(this);
            textView.setLayoutParams(new LayoutParams(-3, -3));
            textView.setText("lm");
            textView.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
            // textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
            textView.setPadding(5, 3, 3, 5);
            textView.setTypeface(Typeface.createFromAsset(getAssets(), array[i]));
            textView.setTextSize(20.0f);
            int finalI = i;
            linearLayout.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Typeface createFromAsset = Typeface.createFromAsset(CreateLogo.this.getAssets(), array[finalI]);
                    if (CreateLogo.this.stickerView.getCurrentSticker() instanceof MyTextSticker) {
                        ((MyTextSticker) CreateLogo.this.stickerView.getCurrentSticker()).setTypeface(createFromAsset);
                        CreateLogo.this.stickerView.invalidate();
                        return;
                    }
                    Toast.makeText(CreateLogo.this, "Cant Apply on Image", Toast.LENGTH_SHORT).show();
                }
            });
            linearLayout.addView(textView);
            this.infoLayout.addView(linearLayout);
        }
    }

    public void loadBackgrounds() {
        this.infoLayout.removeAllViews();
        int i = 0;
        this.infoHorizentallayout.setVisibility(View.VISIBLE);
        final int[] iArr = new int[]{R.drawable.ff1, R.drawable.ff2, R.drawable.ff3, R.drawable.ff4, R.drawable.ff5, R.drawable.ff6, R.drawable.ff7, R.drawable.ff8, R.drawable.ff9, R.drawable.ff10, R.drawable.ff11, R.drawable.ff12, R.drawable.ff13, R.drawable.ff14, R.drawable.ff15, R.drawable.ff16, R.drawable.ff17, R.drawable.ff18, R.drawable.ff19, R.drawable.ff20, R.drawable.ff21, R.drawable.ff22, R.drawable.ff23, R.drawable.ff24, R.drawable.ff25, R.drawable.ff26, R.drawable.ff27, R.drawable.ff28, R.drawable.ff29, R.drawable.ff30, R.drawable.ff31, R.drawable.ff32, R.drawable.ff33, R.drawable.ff34, R.drawable.ff35, R.drawable.ff36, R.drawable.ff37, R.drawable.ff38, R.drawable.ff39, R.drawable.ff40, R.drawable.ff41, R.drawable.ff42, R.drawable.ff43, R.drawable.ff44, R.drawable.ff45, R.drawable.ff46, R.drawable.ff47, R.drawable.ff48, R.drawable.ff49, R.drawable.ff50, R.drawable.ff51, R.drawable.ff52, R.drawable.ff53, R.drawable.ff54, R.drawable.ff55, R.drawable.ff56, R.drawable.ff57, R.drawable.ff58, R.drawable.ff59, R.drawable.ff60, R.drawable.ff61, R.drawable.ff62, R.drawable.ff63, R.drawable.ff64, R.drawable.ff65, R.drawable.ff66, R.drawable.ff67, R.drawable.ff68, R.drawable.ff69, R.drawable.ff70, R.drawable.ff71, R.drawable.ff72, R.drawable.ff73, R.drawable.ff74, R.drawable.ff75, R.drawable.ff76, R.drawable.ff77, R.drawable.ff78, R.drawable.ff79, R.drawable.ff80, R.drawable.ff81, R.drawable.ff82, R.drawable.ff83, R.drawable.ff84, R.drawable.ff85, R.drawable.ff86, R.drawable.ff87, R.drawable.ff88, R.drawable.ff89, R.drawable.ff90, R.drawable.ff91, R.drawable.ff92, R.drawable.ff93, R.drawable.ff94, R.drawable.ff95, R.drawable.ff96, R.drawable.ff97, R.drawable.ff98, R.drawable.ff99, R.drawable.ff100, R.drawable.ff101, R.drawable.ff102, R.drawable.ff103, R.drawable.ff104, R.drawable.ff105, R.drawable.ff106, R.drawable.ff107, R.drawable.ff108, R.drawable.ff109, R.drawable.ff110, R.drawable.ff111, R.drawable.ff112, R.drawable.ff113, R.drawable.ff114, R.drawable.ff115, R.drawable.ff116, R.drawable.ff117, R.drawable.ff118, R.drawable.ff119, R.drawable.ff120, R.drawable.ff121, R.drawable.ff122, R.drawable.ff123, R.drawable.ff124, R.drawable.ff125, R.drawable.ff126, R.drawable.ff127, R.drawable.ff128, R.drawable.ff129, R.drawable.ff130, R.drawable.ff131, R.drawable.ff132, R.drawable.ff133, R.drawable.ff134, R.drawable.ff135, R.drawable.ff136, R.drawable.ff137, R.drawable.ff138, R.drawable.temp1, R.drawable.temp2, R.drawable.temp3, R.drawable.temp4, R.drawable.temp5, R.drawable.temp6, R.drawable.temp7, R.drawable.temp8, R.drawable.temp9, R.drawable.temp10, R.drawable.temp11, R.drawable.temp12, R.drawable.temp13, R.drawable.temp14, R.drawable.temp15, R.drawable.temp16, R.drawable.temp17, R.drawable.temp18, R.drawable.temp19, R.drawable.temp20, R.drawable.temp21, R.drawable.temp22, R.drawable.temp23, R.drawable.temp24, R.drawable.temp25, R.drawable.temp26, R.drawable.temp27, R.drawable.temp28, R.drawable.temp29, R.drawable.temp30, R.drawable.temp31, R.drawable.temp32, R.drawable.temp33, R.drawable.temp34, R.drawable.temp35, R.drawable.temp36, R.drawable.temp37, R.drawable.temp38, R.drawable.temp39, R.drawable.temp40, R.drawable.temp41, R.drawable.temp42, R.drawable.temp43, R.drawable.temp44, R.drawable.temp45, R.drawable.temp46, R.drawable.temp47, R.drawable.temp48, R.drawable.temp49, R.drawable.temp50, R.drawable.temp51, R.drawable.temp52, R.drawable.temp54, R.drawable.temp55, R.drawable.temp56, R.drawable.b1, R.drawable.b2, R.drawable.b3, R.drawable.b4, R.drawable.b5, R.drawable.b6, R.drawable.b7, R.drawable.b8, R.drawable.b9, R.drawable.b10, R.drawable.b11, R.drawable.b12, R.drawable.b13, R.drawable.b14, R.drawable.b15, R.drawable.b16, R.drawable.b17, R.drawable.b18, R.drawable.b19, R.drawable.b20, R.drawable.b21, R.drawable.b22, R.drawable.b23, R.drawable.b24, R.drawable.b25, R.drawable.b26, R.drawable.b27, R.drawable.b28, R.drawable.b29, R.drawable.b30, R.drawable.b31, R.drawable.bg26, R.drawable.bg27, R.drawable.bg28, R.drawable.bg29, R.drawable.bg30, R.drawable.bg31, R.drawable.bg32, R.drawable.bg33, R.drawable.bg34, R.drawable.bg35, R.drawable.bg36, R.drawable.bg37, R.drawable.bg38, R.drawable.bg39, R.drawable.bg40, R.drawable.bg41, R.drawable.backgrounds_1, R.drawable.backgrounds_2, R.drawable.backgrounds_3, R.drawable.backgrounds_4, R.drawable.backgrounds_5, R.drawable.backgrounds_6, R.drawable.backgrounds_7, R.drawable.backgrounds_8, R.drawable.backgrounds_9, R.drawable.backgrounds_10, R.drawable.backgrounds_11, R.drawable.backgrounds_12, R.drawable.backgrounds_13, R.drawable.backgrounds_14, R.drawable.backgrounds_15, R.drawable.backgrounds_16, R.drawable.backgrounds_17, R.drawable.backgrounds_18, R.drawable.backgrounds_19, R.drawable.backgrounds_20, R.drawable.backgrounds_21, R.drawable.backgrounds_22, R.drawable.backgrounds_23, R.drawable.backgrounds_24, R.drawable.backgrounds_25};
        while (i < 265) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(100, 100));
            linearLayout.setGravity(17);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LayoutParams(80, 80));
            Glide.with((FragmentActivity) this).load(Integer.valueOf(iArr[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CreateLogo.this.stickerView.setBackgroundResource(iArr[finalI]);
                }
            });
            linearLayout.addView(imageView);
            this.infoLayout.addView(linearLayout);
            i++;
        }
    }

    public void loadGradientTexturesonText() {
        final int[] iArr = new int[]{R.drawable.color_preset_1, R.drawable.color_preset_2, R.drawable.color_preset_3, R.drawable.color_preset_4, R.drawable.color_preset_5, R.drawable.color_preset_6, R.drawable.color_preset_7, R.drawable.color_preset_8, R.drawable.color_preset_9, R.drawable.color_preset_10, R.drawable.color_preset_11, R.drawable.color_preset_12, R.drawable.color_preset_13, R.drawable.color_preset_14, R.drawable.color_preset_15, R.drawable.color_preset_16, R.drawable.color_preset_17, R.drawable.color_preset_18, R.drawable.color_preset_19, R.drawable.color_preset_20, R.drawable.color_preset_21, R.drawable.color_preset_22, R.drawable.color_preset_23, R.drawable.color_preset_24, R.drawable.color_preset_25, R.drawable.color_preset_26, R.drawable.color_preset_27, R.drawable.color_preset_28, R.drawable.color_preset_29, R.drawable.color_preset_30, R.drawable.gradient_1, R.drawable.gradient_2, R.drawable.gradient_3, R.drawable.gradient_4, R.drawable.gradient_5, R.drawable.gradient_6, R.drawable.gradient_7, R.drawable.gradient_8, R.drawable.gradient_9, R.drawable.gradient_10, R.drawable.gradient_11, R.drawable.gradient_12, R.drawable.gradient_13, R.drawable.gradient_14, R.drawable.gradient_15, R.drawable.gradient_16, R.drawable.gradient_17, R.drawable.gradient_18, R.drawable.gradient_19, R.drawable.gradient_20, R.drawable.gradient_21, R.drawable.gradient_22, R.drawable.gradient_23, R.drawable.gradient_24, R.drawable.gradient_25, R.drawable.gradient_26, R.drawable.gradient_27, R.drawable.gradient_28, R.drawable.gradient_29, R.drawable.gradient_30, R.drawable.gradient_31, R.drawable.gradient_32, R.drawable.gradient_33};
        final int[] iArr2 = new int[]{R.drawable.pattern_bg_1, R.drawable.pattern_bg_3, R.drawable.pattern_bg_4, R.drawable.pattern_bg_5, R.drawable.pattern_bg_7, R.drawable.pattern_bg_9, R.drawable.pattern_bg_12, R.drawable.pattern_bg_13, R.drawable.pattern_bg_14, R.drawable.pattern_bg_15, R.drawable.pattern_bg_16, R.drawable.pattern_bg_17, R.drawable.pattern_bg_18, R.drawable.pattern_bg_19, R.drawable.pattern_bg_21, R.drawable.pattern_bg_24, R.drawable.pattern_bg_25, R.drawable.pattern_bg_26, R.drawable.pattern_bg_28, R.drawable.pattern_bg_30, R.drawable.pattern_bg_31, R.drawable.pattern_bg_32, R.drawable.pattern_bg_33, R.drawable.pattern_bg_34, R.drawable.pattern_bg_35, R.drawable.pattern_bg_36, R.drawable.pattern_bg_37, R.drawable.pattern_bg_38, R.drawable.pattern_bg_39, R.drawable.pattern_bg_40, R.drawable.pattern_bg_41, R.drawable.pattern_bg_43, R.drawable.pattern_bg_45, R.drawable.pattern_bg_46, R.drawable.pattern_bg_47, R.drawable.pattern_bg_48, R.drawable.pattern_bg_49, R.drawable.pattern_bg_50, R.drawable.pattern_bg_51, R.drawable.pattern_bg_52, R.drawable.pattern_bg_53, R.drawable.pattern_bg_54, R.drawable.pattern_bg_55, R.drawable.pattern_bg_56, R.drawable.pattern_bg_57, R.drawable.pattern_bg_58, R.drawable.pattern_bg_59, R.drawable.pattern_bg_60, R.drawable.pattern_bg_61, R.drawable.pattern_bg_62, R.drawable.pattern_bg_63, R.drawable.pattern_bg_64, R.drawable.pattern_bg_65, R.drawable.pattern_bg_66, R.drawable.pattern_bg_67, R.drawable.pattern_bg_68, R.drawable.pattern_bg_69, R.drawable.pattern_bg_70, R.drawable.pattern_bg_71, R.drawable.pattern_bg_72, R.drawable.pattern_bg_73, R.drawable.pattern_bg_74, R.drawable.pattern_bg_75, R.drawable.pattern_bg_76, R.drawable.pattern_bg_77, R.drawable.pattern_bg_78, R.drawable.pattern_bg_79, R.drawable.pattern_bg_80, R.drawable.pattern_bg_81, R.drawable.pattern_bg_82, R.drawable.pattern_bg_83, R.drawable.pattern_bg_84, R.drawable.pattern_bg_85};

        for (int i = 0; i < 63; i++) {
            ImageView imageView = new ImageView(this);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(100, 100));
            linearLayout.setGravity(17);
            LayoutParams layoutParams = new LayoutParams(80, 80);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            linearLayout.setPadding(10, 10, 10, 10);
            imageView.setLayoutParams(layoutParams);
            Glide.with((FragmentActivity) this).asBitmap().load(Integer.valueOf(iArr[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ((MyTextSticker) CreateLogo.this.stickerView.getCurrentSticker()).setShader(new BitmapShader(BitmapFactory.decodeResource(CreateLogo.this.getResources(), iArr[finalI]), TileMode.REPEAT, TileMode.REPEAT));
                    CreateLogo.this.stickerView.invalidate();
                }
            });
            linearLayout.addView(imageView);
            this.datalayout.addView(linearLayout);

        }
        for (int i2 = 0; i2 < 73; i2++) {
            ImageView imageView2 = new ImageView(this);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setLayoutParams(new LayoutParams(120, 120));
            linearLayout2.setGravity(17);
            LayoutParams layoutParams2 = new LayoutParams(80, 80);
            linearLayout2.setBackgroundResource(R.drawable.itemsbg);
            linearLayout2.setPadding(10, 10, 10, 10);
            imageView2.setLayoutParams(layoutParams2);
            Glide.with((FragmentActivity) this).asBitmap().load(Integer.valueOf(iArr2[i2])).into(imageView2);
            int finalI = i2;
            imageView2.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ((MyTextSticker) CreateLogo.this.stickerView.getCurrentSticker()).setShader(new BitmapShader(BitmapFactory.decodeResource(CreateLogo.this.getResources(), iArr2[finalI]), TileMode.REPEAT, TileMode.REPEAT));
                    CreateLogo.this.stickerView.invalidate();
                }
            });
            linearLayout2.addView(imageView2);
            this.datalayout.addView(linearLayout2);
        }
    }

    public void loadBackgroundColor() {
        this.datalayout.removeAllViews();
        int i = 0;
        this.infoHorizentallayout.setVisibility(View.VISIBLE);
        final int[] intArray = getResources().getIntArray(R.array.allcolors);
        while (i < intArray.length) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(30, 80));
            linearLayout.setGravity(17);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LayoutParams(30, 80));
            imageView.setBackgroundColor(intArray[i]);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CreateLogo.this.stickerView.setBackgroundColor(intArray[finalI]);
                }
            });
            linearLayout.addView(imageView);
            this.datalayout.addView(linearLayout);
            i++;
        }
    }

    public void loadAllcolors() {
        this.datalayout.removeAllViews();
        int i = 0;
        this.infoHorizentallayout.setVisibility(View.VISIBLE);
        final int[] intArray = getResources().getIntArray(R.array.allcolors);
        while (i < intArray.length) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(30, 80));
            linearLayout.setGravity(17);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LayoutParams(30, 80));
            imageView.setBackgroundColor(intArray[i]);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (CreateLogo.this.stickerView.getCurrentSticker() instanceof MyTextSticker) {
                        ((MyTextSticker) CreateLogo.this.stickerView.getCurrentSticker()).setTextColor(intArray[finalI]);
                        CreateLogo.this.stickerView.invalidate();
                    } else if (CreateLogo.this.stickerView.getCurrentSticker() instanceof DrawableSticker) {
                        int[] iArr = intArray;
                        int i = finalI;
                        int i2 = (iArr[i] & 16711680) / SupportMenu.USER_MASK;
                        int i3 = (iArr[i] & MotionEventCompat.ACTION_POINTER_INDEX_MASK) / 255;
                        int i4 = iArr[i] & 255;
                        ColorMatrixColorFilter colorMatrixColorFilter = new ColorMatrixColorFilter(new float[]{0.0f, 0.0f, 0.0f, 0.0f, (float) i2, 0.0f, 0.0f, 0.0f, 0.0f, (float) i3, 0.0f, 0.0f, 0.0f, 0.0f, (float) i4, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f});
                        Drawable drawable = ((DrawableSticker) CreateLogo.this.stickerView.getCurrentSticker()).getDrawable();
                        drawable.setColorFilter(colorMatrixColorFilter);
                        ((DrawableSticker) CreateLogo.this.stickerView.getCurrentSticker()).setDrawable(drawable);
                        CreateLogo.this.stickerView.replace((DrawableSticker) CreateLogo.this.stickerView.getCurrentSticker());
                        CreateLogo.this.stickerView.invalidate();
                    } else {
                        Toast.makeText(CreateLogo.this, "No item found", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            linearLayout.addView(imageView);
            this.datalayout.addView(linearLayout);
            i++;
        }
    }

    public void loadIShapes() {
        this.infoLayout.removeAllViews();
        int i = 0;
        this.infoHorizentallayout.setVisibility(View.VISIBLE);
        final int[] iArr = new int[]{R.drawable.shape_1, R.drawable.shape_2, R.drawable.shape_3, R.drawable.shape_4, R.drawable.shape_5, R.drawable.shape_6, R.drawable.shape_7, R.drawable.shape_8, R.drawable.shape_9, R.drawable.shape_10, R.drawable.shape_11, R.drawable.shape_12, R.drawable.shape_13, R.drawable.shape_14, R.drawable.shape_15, R.drawable.shape_16, R.drawable.shape_17, R.drawable.shape_18, R.drawable.shape_19, R.drawable.shape_20, R.drawable.shape_21, R.drawable.shape_22, R.drawable.shape_23, R.drawable.shape_24, R.drawable.shape_25, R.drawable.shape_26, R.drawable.shape_27, R.drawable.shape_28, R.drawable.shape_29, R.drawable.shape_30, R.drawable.shape_31, R.drawable.shape_32, R.drawable.shape_33, R.drawable.shape_34, R.drawable.shape_35, R.drawable.shape_36, R.drawable.shape_37, R.drawable.shape_38, R.drawable.shape_39, R.drawable.shape_40, R.drawable.shape_41, R.drawable.shape_42, R.drawable.shape_43, R.drawable.shape_44, R.drawable.shape_45, R.drawable.shape_46, R.drawable.shape_47, R.drawable.shape_48, R.drawable.shape_49, R.drawable.shape_50, R.drawable.shape_51, R.drawable.shape_52, R.drawable.shape_53, R.drawable.shape_54, R.drawable.shape_55, R.drawable.shape_56, R.drawable.shape_57, R.drawable.shape_58, R.drawable.shape_59, R.drawable.shape_60, R.drawable.shape_61, R.drawable.shape_62, R.drawable.shape_63, R.drawable.shape_64, R.drawable.shape_65, R.drawable.shape_66, R.drawable.shape_67, R.drawable.shape_68, R.drawable.shape_69, R.drawable.shape_70, R.drawable.shape_71, R.drawable.shape_72, R.drawable.shape_73, R.drawable.shape_74, R.drawable.shape_75, R.drawable.shape_76, R.drawable.shape_77, R.drawable.shape_78, R.drawable.shape_79, R.drawable.shape_80, R.drawable.shape_81, R.drawable.shape_82, R.drawable.shape_83, R.drawable.shape_84, R.drawable.shape_85, R.drawable.shape_86, R.drawable.shape_87, R.drawable.shape_88, R.drawable.shape_89, R.drawable.shape_90, R.drawable.shape_91, R.drawable.shape_92, R.drawable.shape_93, R.drawable.shape_94, R.drawable.shape_95, R.drawable.shape_96, R.drawable.shape_97, R.drawable.shape_98, R.drawable.shape_99, R.drawable.shape_100, R.drawable.shape_101, R.drawable.shape_102, R.drawable.shape_103, R.drawable.shape_104, R.drawable.shape_105, R.drawable.shape_106, R.drawable.shape_107, R.drawable.shape_108, R.drawable.shape_109, R.drawable.shape_110, R.drawable.shape_111, R.drawable.shape_112, R.drawable.shape_113, R.drawable.shape_114, R.drawable.shape_115, R.drawable.shape_116, R.drawable.shape_117, R.drawable.shape_118, R.drawable.shape_119, R.drawable.shape_120, R.drawable.shape_121, R.drawable.shape_122, R.drawable.shape_123, R.drawable.shape_124, R.drawable.shape_125, R.drawable.shape_126, R.drawable.shape_127, R.drawable.shape_128, R.drawable.shape_129, R.drawable.shape_130, R.drawable.shape_131, R.drawable.shape_132, R.drawable.shape_133, R.drawable.shape_134, R.drawable.shape_135, R.drawable.shape_136, R.drawable.shape_137, R.drawable.shape_138, R.drawable.shape_139, R.drawable.shape_140, R.drawable.shape_141, R.drawable.shape_142, R.drawable.shape_143, R.drawable.shape_144, R.drawable.shape_145, R.drawable.shape_146, R.drawable.shape_147, R.drawable.shape_148, R.drawable.shape_149, R.drawable.shape_150, R.drawable.shape_151, R.drawable.shape_152, R.drawable.shape_153, R.drawable.shape_154, R.drawable.shape_155, R.drawable.shape_156, R.drawable.shape_157, R.drawable.shape_158, R.drawable.shape_159, R.drawable.shape_160, R.drawable.shape_161, R.drawable.shape_162, R.drawable.shape_163, R.drawable.shape_164, R.drawable.shape_165, R.drawable.shape_166, R.drawable.shape_167, R.drawable.shape_168, R.drawable.shape_169, R.drawable.shape_170, R.drawable.shape_171, R.drawable.shape_172, R.drawable.shape_173, R.drawable.shape_174, R.drawable.shape_175, R.drawable.shape_176, R.drawable.shape_177, R.drawable.shape_178, R.drawable.shape_179, R.drawable.shape_180, R.drawable.shape_181, R.drawable.shape_182, R.drawable.shape_183, R.drawable.shape_184, R.drawable.shape_185, R.drawable.shape_186, R.drawable.shape_187, R.drawable.shape_188, R.drawable.shape_189, R.drawable.shape_190, R.drawable.shape_191, R.drawable.shape_192, R.drawable.shape_193, R.drawable.shape_194, R.drawable.shape_195, R.drawable.shape_196, R.drawable.shape_197, R.drawable.shape_198, R.drawable.shape_199, R.drawable.shape_200};
        while (i < 200) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(100, 100));
            linearLayout.setGravity(17);
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LayoutParams(80, 80));
            imageView.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
            Glide.with((FragmentActivity) this).load(Integer.valueOf(iArr[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CreateLogo.this.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(CreateLogo.this, iArr[finalI])));
                    CreateLogo.this.stickerView.invalidate();
                }
            });
            linearLayout.addView(imageView);
            this.infoLayout.addView(linearLayout);
            i++;
        }
    }

    public void loadLogos() {
        this.infoLayout.removeAllViews();
        final int[] iArr = new int[]{R.drawable.esport_logo_01, R.drawable.esport_logo_02, R.drawable.esport_logo_03, R.drawable.esport_logo_04, R.drawable.esport_logo_05, R.drawable.esport_logo_06, R.drawable.esport_logo_07, R.drawable.esport_logo_08, R.drawable.esport_logo_09, R.drawable.esport_logo_010, R.drawable.esport_logo_011, R.drawable.esport_logo_012, R.drawable.esport_logo_013, R.drawable.esport_logo_014, R.drawable.esport_logo_015, R.drawable.esport_logo_016, R.drawable.esport_logo_017, R.drawable.esport_logo_018, R.drawable.esport_logo_019, R.drawable.esport_logo_020, R.drawable.esport_logo_021, R.drawable.esport_logo_022, R.drawable.esport_logo_023, R.drawable.esport_logo_024, R.drawable.esport_logo_025, R.drawable.esport_logo_026, R.drawable.esport_logo_027, R.drawable.esport_logo_028, R.drawable.esport_logo_029, R.drawable.esport_logo_030, R.drawable.esport_logo_031, R.drawable.esport_logo_032, R.drawable.esport_logo_033, R.drawable.esport_logo_034, R.drawable.esport_logo_035, R.drawable.esport_logo_036, R.drawable.esport_logo_037, R.drawable.esport_logo_038, R.drawable.esport_logo_039, R.drawable.esport_logo_040, R.drawable.esport_logo_041, R.drawable.esport_logo_042, R.drawable.esport_logo_043, R.drawable.esport_logo_044, R.drawable.esport_logo_045, R.drawable.esport_logo_046, R.drawable.esport_logo_047, R.drawable.esport_logo_048, R.drawable.esport_logo_049, R.drawable.esport_logo_050, R.drawable.esport_logo_051, R.drawable.esport_logo_052, R.drawable.esport_logo_053, R.drawable.esport_logo_054, R.drawable.esport_logo_055, R.drawable.esport_logo_056, R.drawable.esport_logo_057, R.drawable.esport_logo_058, R.drawable.esport_logo_059, R.drawable.esport_logo_060, R.drawable.esport_logo_061, R.drawable.esport_logo_062, R.drawable.esport_logo_063, R.drawable.esport_logo_064, R.drawable.esport_logo_065, R.drawable.esport_logo_066, R.drawable.esport_logo_067, R.drawable.esport_logo_068, R.drawable.esport_logo_069, R.drawable.esport_logo_070, R.drawable.esport_logo_071, R.drawable.esport_logo_072, R.drawable.esport_logo_073, R.drawable.esport_logo_074, R.drawable.esport_logo_075, R.drawable.esport_logo_076, R.drawable.esport_logo_077, R.drawable.esport_logo_078, R.drawable.esport_logo_079, R.drawable.esport_logo_080, R.drawable.esport_logo_081, R.drawable.esport_logo_082, R.drawable.esport_logo_083, R.drawable.esport_logo_084, R.drawable.esport_logo_085, R.drawable.esport_logo_086, R.drawable.esport_logo_087, R.drawable.esport_logo_088, R.drawable.esport_logo_089, R.drawable.esport_logo_090, R.drawable.esport_logo_091, R.drawable.esport_logo_092, R.drawable.esport_logo_093, R.drawable.esport_logo_094, R.drawable.esport_logo_095, R.drawable.esport_logo_096, R.drawable.esport_logo_097, R.drawable.esport_logo_098, R.drawable.esport_logo_099, R.drawable.esport_logo_0100, R.drawable.l301, R.drawable.l302, R.drawable.l303, R.drawable.l304, R.drawable.l305, R.drawable.l306, R.drawable.l307, R.drawable.l308, R.drawable.l309, R.drawable.l310, R.drawable.l311, R.drawable.l312, R.drawable.l313, R.drawable.l314, R.drawable.l315, R.drawable.l316, R.drawable.l317, R.drawable.l318, R.drawable.l319, R.drawable.l320, R.drawable.l321, R.drawable.l322, R.drawable.l323, R.drawable.l324, R.drawable.l325, R.drawable.l326, R.drawable.l327, R.drawable.l328, R.drawable.l329, R.drawable.l330, R.drawable.l331, R.drawable.l332, R.drawable.l333, R.drawable.l334, R.drawable.l335, R.drawable.l336, R.drawable.l337, R.drawable.l338, R.drawable.l339, R.drawable.l340, R.drawable.l341, R.drawable.l342, R.drawable.l343, R.drawable.l344, R.drawable.l345, R.drawable.l346, R.drawable.l347, R.drawable.l348, R.drawable.l349, R.drawable.l350, R.drawable.l351, R.drawable.l352, R.drawable.l353, R.drawable.l354, R.drawable.l355};
        for (int i = 0; i < 155; i++) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setLayoutParams(new LayoutParams(100, 100));
            linearLayout.setBackgroundResource(R.drawable.itemsbg);
            linearLayout.setGravity(17);
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LayoutParams(80, 80));
            Glide.with((FragmentActivity) this).asBitmap().load(Integer.valueOf(iArr[i])).into(imageView);
            int finalI = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CreateLogo.this.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(CreateLogo.this, iArr[finalI])));
                    CreateLogo.this.stickerView.invalidate();
                }
            });
            linearLayout.addView(imageView);
            this.infoLayout.addView(linearLayout);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && i == 1001) {
            new LayoutParams(-2, -2).addRule(13);
            Uri imageUri = intent.getData();
            stickerView.addSticker(new DrawableSticker(new BitmapDrawable(getRealPathFromURI(imageUri))));
        }
        if (i2 == -1 && i == 100) {
            Uri imageUri = intent.getData();
            Log.e("TAG", "Set background" + imageUri);
            stickerView.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(getRealPathFromURI(imageUri))));
        }
        super.onActivityResult(i, i2, intent);
    }


    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

    private void startPhotoPickIntent(int i) {
        Intent intent = new Intent("android.intent.action.PICK", Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("output", getTempUri());
        intent.putExtra("outputFormat", CompressFormat.PNG.toString());
        startActivityForResult(intent, i);
    }

    private Uri getTempUri() {
        return Uri.fromFile(getTempFile());
    }

    private void openGallery() {
        @SuppressLint("IntentReset")
        Intent intent = new Intent("android.intent.action.PICK", Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("output", getTempFileUri());
        intent.putExtra("outputFormat", CompressFormat.PNG.toString());
        startActivityForResult(intent, 1001);
    }

    private Uri getTempFileUri() {
        return Uri.fromFile(getTempFile());
    }

    private File getTempFile() {
        File file = new File(Environment.getExternalStorageDirectory(), Constants.TEMP_FILE_NAME);
        if (!file.mkdirs()) {
            file.mkdirs();
        }
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    public void showDialogUpload() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_layout_addtext);
        dialog.setTitle(null);
        Button button = (Button) dialog.findViewById(R.id.logoselect);

        ((Button) dialog.findViewById(R.id.backselect)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CreateLogo.this.startPhotoPickIntent(100);
                dialog.dismiss();
            }
        });

        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CreateLogo.this.openGallery();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void onClick(View view) {

        if (view.equals(this.mainlayout)) {
            if (this.stickerView.isLocked()) {
                this.stickerView.setLocked(false);
            } else {
                this.stickerView.setLocked(true);
            }
        }
        if (view.equals(this.add_text)) {
            add_text.setImageResource(R.drawable.select_text);

            add_bg.setImageResource(R.drawable.ic_bg);
            addshapes.setImageResource(R.drawable.ic_shapes);
            add_logo.setImageResource(R.drawable.ic_logos);
            lock.setImageResource(R.drawable.ic_upload);

            addTextInfo();
            addFontText();
            loadAllcolors();
            loadGradientTexturesonText();
            this.seekno = 4;
        } else if (view.equals(this.add_bg)) {
            add_bg.setImageResource(R.drawable.select_bg);
            text_input_layout.setVisibility(View.GONE);
            add_logo.setImageResource(R.drawable.ic_logos);
            addshapes.setImageResource(R.drawable.ic_shapes);
            add_text.setImageResource(R.drawable.ic_text);
            lock.setImageResource(R.drawable.ic_upload);

            loadBackgrounds();
            loadBackgroundColor();

            this.seekno = 1;
        } else if (view.equals(this.add_logo)) {
            add_logo.setImageResource(R.drawable.select_logo);

            add_bg.setImageResource(R.drawable.ic_bg);
            addshapes.setImageResource(R.drawable.ic_shapes);
            add_text.setImageResource(R.drawable.ic_text);
            lock.setImageResource(R.drawable.ic_upload);
            text_input_layout.setVisibility(View.GONE);

            loadLogos();
            loadAllcolors();
            this.seekno = 2;
        } else if (view.equals(this.addshapes)) {
            addshapes.setImageResource(R.drawable.select_shape);

            add_logo.setImageResource(R.drawable.ic_logos);
            add_bg.setImageResource(R.drawable.ic_bg);
            add_text.setImageResource(R.drawable.ic_text);
            lock.setImageResource(R.drawable.ic_upload);
            text_input_layout.setVisibility(View.GONE);
            loadIShapes();
            loadAllcolors();
            this.seekno = 3;
        } else if (view.equals(this.lock)) {
            lock.setImageResource(R.drawable.select_upload);

            add_logo.setImageResource(R.drawable.ic_logos);
            add_bg.setImageResource(R.drawable.ic_bg);
            add_text.setImageResource(R.drawable.ic_text);
            addshapes.setImageResource(R.drawable.ic_shapes);
            text_input_layout.setVisibility(View.GONE);
            showDialogUpload();


        } else if (view.equals(this.save)) {
            if (!stickerView.isLocked()) {
                stickerView.setLocked(true);
            }
            try {
                new Save(this.stickerView).execute(new Void[0]);
                Intent intent=new Intent(CreateLogo.this,MainActivity.class);
                startActivity(intent);

            } catch (Exception unused) {
                Toast.makeText(this, "Cant't Save yet", Toast.LENGTH_LONG).show();
            }

        } else if (view.equals(this.clearData)) {

            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                try {
                    hud = KProgressHUD.create(activity)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                            id = 100;
                            mInterstitialAd.show();
                        }
                    }
                }, 2000);
            } else {
                this.stickerView.setBackgroundResource(0);
                this.stickerView.removeAllStickers();
                this.stickerView.invalidate();
            }
        }
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Exit");
        builder.setMessage("Are you sure Save the file?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (seekBar.equals(this.seekbar)) {
            int i2 = this.seekno;
            if (i2 == 1) {
                try {
                    this.stickerView.getBackground().setAlpha(i);
                    this.stickerView.invalidate();
                } catch (Exception unused) {
                    Toast.makeText(this, "No background added yet", Toast.LENGTH_LONG).show();
                }
            } else if (i2 == 2) {
                if (this.stickerView.getCurrentSticker() instanceof DrawableSticker) {
                    this.stickerView.getCurrentSticker().setAlpha(i);
                    this.stickerView.invalidate();
                }
            } else if (i2 == 3) {
                if (this.stickerView.getCurrentSticker() instanceof DrawableSticker) {
                    this.stickerView.getCurrentSticker().setAlpha(i);
                    this.stickerView.invalidate();
                }
            } else if (i2 == 4 && (this.stickerView.getCurrentSticker() instanceof MyTextSticker)) {
                this.stickerView.getCurrentSticker().setAlpha(i);
                this.stickerView.invalidate();
            }
        }
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        stickerView.setBackgroundResource(0);
                        stickerView.removeAllStickers();
                        stickerView.invalidate();
                        break;

                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
