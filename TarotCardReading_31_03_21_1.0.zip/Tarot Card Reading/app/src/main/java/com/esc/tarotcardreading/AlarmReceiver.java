package com.esc.tarotcardreading;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    public static boolean isAlarmNotified;
    public static int random;
    public static int randomlang;
    Context context;

    public void onReceive(Context context, Intent intent) {
        this.context = context;
        isAlarmNotified = true;
        new NotificationHelper(context).createNotification();
    }
}
