package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import java.io.File;
import com.kotlinz.videostatusmaker.Others.gallery.ActivityImageFolder;
import org.jetbrains.annotations.NotNull;

public class MainActivity extends AppCompatActivity {
    public static int anInt;
    public static Activity activity;
    ImageView fullscreen;
    ImageView square1;

    GGAdview gg_native;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        /*GGAppOpenAds.show();*/
        activity = this;
        getWindow().addFlags(1024);
        square1 = findViewById(R.id.square1);
        fullscreen = findViewById(R.id.fullscreen);
        anInt = 0;
        PutAnalyticsEvent();
        CallNativeAds();
        btnClick();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void btnClick() {
        square1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    Square();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MainActivity.anInt = 0;
                        MyApplication.Variable_VIDEO_HEIGHT = 720;
                        MyApplication.Variable_VIDEO_WIDTH = 720;
                        MyApplication.AdsId = 25;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        Square();
                    }
                }
            }
        });
        fullscreen.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    FullScreen();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MainActivity.anInt = 1;
                        MyApplication.Variable_VIDEO_WIDTH = 1080;
                        MyApplication.Variable_VIDEO_HEIGHT = 1920;
                        MyApplication.AdsId = 26;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        FullScreen();
                    }
                }
            }
        });
    }

    private void Square() {
        MainActivity.anInt = 0;
        MyApplication.Variable_VIDEO_HEIGHT = 720;
        MyApplication.Variable_VIDEO_WIDTH = 720;
        startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
    }

    private void FullScreen() {
        MainActivity.anInt = 1;
        MyApplication.Variable_VIDEO_WIDTH = 1080;
        MyApplication.Variable_VIDEO_HEIGHT = 1920;
        startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
    }

    private void CallNativeAds() {
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    protected void onResume() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
            stringBuilder.append("/");
            stringBuilder.append(getResources().getString(R.string.app_name));
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("/");
            stringBuilder3.append(getString(R.string.temp_folder));
            deleteRecursive(new File(stringBuilder3.toString()));
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(MainActivity.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    public static void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }
}


