﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace BallCollect
{
	public static class VibrationManager 
	{
		public static long LightDuration = 20L;

		public static long MediumDuration = 40L;

		public static long HeavyDuration = 80L;

		public static int LightAmplitude = 40;

		public static int MediumAmplitude = 120;

		public static int HeavyAmplitude = 255;

		private static int _sdkVersion = -1;

		private static long[] _lightimpactPattern = new long[]
		{
			0L,
			LightDuration
		};

		private static int[] _lightimpactPatternAmplitude = new int[]
		{
			0,
			LightAmplitude
		};

		private static long[] _mediumimpactPattern = new long[]
		{
			0L,
			MediumDuration
		};

		private static int[] _mediumimpactPatternAmplitude = new int[]
		{
			0,
			MediumAmplitude
		};

		private static long[] _HeavyimpactPattern = new long[]
		{
			0L,
			HeavyDuration
		};

		private static int[] _HeavyimpactPatternAmplitude = new int[]
		{
			0,
			HeavyAmplitude
		};

		private static long[] _successPattern = new long[]
		{
			0L,
			LightDuration,
			LightDuration,
			HeavyDuration
		};

		private static int[] _successPatternAmplitude = new int[]
		{
			0,
			LightAmplitude,
			0,
			HeavyAmplitude
		};

		private static long[] _warningPattern = new long[]
		{
			0L,
			VibrationManager.HeavyDuration,
			VibrationManager.LightDuration,
			VibrationManager.MediumDuration
		};

		private static int[] _warningPatternAmplitude = new int[]
		{
			0,
			VibrationManager.HeavyAmplitude,
			0,
			VibrationManager.MediumAmplitude
		};

		private static long[] _failurePattern = new long[]
		{
			0L,
			MediumDuration,
			LightDuration,
			MediumDuration,
			LightDuration,
			HeavyDuration,
			LightDuration,
			LightDuration
		};

		private static int[] _failurePatternAmplitude = new int[]
		{
			0,
			MediumAmplitude,
			0,
			MediumAmplitude,
			0,
			HeavyAmplitude,
			0,
			LightAmplitude
		};


		private static AndroidJavaClass UnityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

		private static AndroidJavaObject CurrentActivity = VibrationManager.UnityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

		private static AndroidJavaObject AndroidVibrator = VibrationManager.CurrentActivity.Call<AndroidJavaObject>("getSystemService", new object[]
		{
			"vibrator"
		});

		private static AndroidJavaClass VibrationEffectClass;

		private static AndroidJavaObject VibrationEffect;

		private static IntPtr AndroidVibrateMethodRawClass = AndroidJNIHelper.GetMethodID(VibrationManager.AndroidVibrator.GetRawClass(), "vibrate", "(J)V", false);

		private static jvalue[] AndroidVibrateMethodRawClassParameters = new jvalue[1];


		public static bool Android()
		{
			return true;
		}

		
		public static void Vibrate()
		{
			if (Android())
			{
				VibrationManager.AndroidVibrate(MediumDuration);
				return;
			}
		}

		public static void Haptic(VibrateType type, bool defaultToRegularVibrate = false)
		{
			if (!GameController.instance.isVibrate)
				return;
			
				if (Android())
				{
				switch (type)
				{
				case VibrateType.Selection:
					VibrationManager.AndroidVibrate(LightDuration, LightAmplitude);
					return;
				case VibrateType.Success:
					VibrationManager.AndroidVibrate(_successPattern, _successPatternAmplitude, -1);
					return;
				case VibrateType.Warning:
					VibrationManager.AndroidVibrate(_warningPattern, _warningPatternAmplitude, -1);
					return;
				case VibrateType.Failure:
					VibrationManager.AndroidVibrate(_failurePattern, _failurePatternAmplitude, -1);
					return;
				case VibrateType.LightImpact:
					VibrationManager.AndroidVibrate(_lightimpactPattern, _lightimpactPatternAmplitude, -1);
					return;
				case VibrateType.MediumImpact:
					VibrationManager.AndroidVibrate(_mediumimpactPattern, _mediumimpactPatternAmplitude, -1);
					return;
				case VibrateType.HeavyImpact:
					VibrationManager.AndroidVibrate(_HeavyimpactPattern, _HeavyimpactPatternAmplitude, -1);
					return;
				case VibrateType.None:
					break;
				default:
					return;
				}
			}
		}

		public static void AndroidVibrate(long milliseconds)
		{
			if (!Android())
			{
				return;
			}
			VibrationManager.AndroidVibrateMethodRawClassParameters[0].j = milliseconds;
			AndroidJNI.CallVoidMethod(VibrationManager.AndroidVibrator.GetRawObject(), VibrationManager.AndroidVibrateMethodRawClass, VibrationManager.AndroidVibrateMethodRawClassParameters);
		}

		public static void AndroidVibrate(long milliseconds, int amplitude)
		{
			if (!Android())
			{
				return;
			}
			if (VibrationManager.AndroidSDKVersion() < 26)
			{
				VibrationManager.AndroidVibrate(milliseconds);
				return;
			}
			VibrationManager.VibrationEffectClassInitialization();
			VibrationManager.VibrationEffect = VibrationManager.VibrationEffectClass.CallStatic<AndroidJavaObject>("createOneShot", new object[]
			{
				milliseconds,
				amplitude
			});
			VibrationManager.AndroidVibrator.Call("vibrate", new object[]
			{
				VibrationManager.VibrationEffect
			});
		}

		public static void AndroidVibrate(long[] pattern, int repeat)
		{
			if (!VibrationManager.Android())
			{
				return;
			}
			if (VibrationManager.AndroidSDKVersion() < 26)
			{
				VibrationManager.AndroidVibrator.Call("vibrate", new object[]
				{
					pattern,
					repeat
				});
				return;
			}
			VibrationManager.VibrationEffectClassInitialization();
			VibrationManager.VibrationEffect = VibrationManager.VibrationEffectClass.CallStatic<AndroidJavaObject>("createWaveform", new object[]
			{
				pattern,
				repeat
			});
			VibrationManager.AndroidVibrator.Call("vibrate", new object[]
			{
				VibrationManager.VibrationEffect
			});
		}

		public static void AndroidVibrate(long[] pattern, int[] amplitudes, int repeat)
		{
			if (!Android())
			{
				return;
			}
			if (VibrationManager.AndroidSDKVersion() < 26)
			{
				VibrationManager.AndroidVibrator.Call("vibrate", new object[]
				{
					pattern,
					repeat
				});
				return;
			}
			VibrationManager.VibrationEffectClassInitialization();
			VibrationManager.VibrationEffect = VibrationManager.VibrationEffectClass.CallStatic<AndroidJavaObject>("createWaveform", new object[]
			{
				pattern,
				amplitudes,
				repeat
			});
			VibrationManager.AndroidVibrator.Call("vibrate", new object[]
			{
				VibrationManager.VibrationEffect
			});
		}

		public static void AndroidCancelVibrations()
		{
			if (!Android())
			{
				return;
			}
			VibrationManager.AndroidVibrator.Call("cancel", Array.Empty<object>());
		}

		private static void VibrationEffectClassInitialization()
		{
			if (VibrationManager.VibrationEffectClass == null)
			{
				VibrationManager.VibrationEffectClass = new AndroidJavaClass("android.os.VibrationEffect");
			}
		}

		public static int AndroidSDKVersion()
		{
			if (_sdkVersion == -1)
			{
				return _sdkVersion = int.Parse(SystemInfo.operatingSystem.Substring(SystemInfo.operatingSystem.IndexOf("-") + 1, 3));
			}
			return _sdkVersion;
		}

		public static bool HapticsSupported()
		{
			return false;
		}
	}
}
