package com.kotlinz.festivalstorymaker.Listener.festival;

import android.os.Handler;
import android.view.View;
import com.kotlinz.festivalstorymaker.Utils.MagnifierView;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class m5 implements View.OnClickListener {
    public final  FestivalDetailActivity_New n;

    public class a implements Runnable {
        public void run() {
            FestivalDetailActivity_New festivalDetailActivity_New = m5.this.n;
            MagnifierView.b bVar = new MagnifierView.b(festivalDetailActivity_New, festivalDetailActivity_New.rlMainView);
            FestivalDetailActivity_New festivalDetailActivity_New2 = m5.this.n;
            bVar.c((festivalDetailActivity_New2.o0 / 2) - 60, (festivalDetailActivity_New2.p0 / 2) - 60);
            bVar.d = 250;
            bVar.e = 250;
            bVar.f = 4.0f;
            bVar.g = 4.0f;
            bVar.a(16);
            bVar.h = 17170445;
            festivalDetailActivity_New.R = bVar.b();
            festivalDetailActivity_New = m5.this.n;
            festivalDetailActivity_New.R.setListner(festivalDetailActivity_New.q0);
            m5.this.n.R.a();
        }
    }

    public m5(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }

    public void onClick(View view) {
        this.n.K0();
        this.n.rlFull.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new a(), 600);
    }

}
