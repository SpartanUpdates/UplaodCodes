package com.esc.dailyrandomfacts.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.LinearLayout;

public class CheckableRelativeLayout extends LinearLayout implements Checkable {
    private static final int[] STATE_CHECKABLE = new int[]{16842919};
    boolean checked = false;

    public CheckableRelativeLayout(Context context) {
        super(context);
    }

    public CheckableRelativeLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public CheckableRelativeLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void setChecked(boolean z) {
        this.checked = z;
        refreshDrawableState();
    }

    public boolean isChecked() {
        return this.checked;
    }

    public void toggle() {
        setChecked(this.checked);
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (this.checked) {
            mergeDrawableStates(onCreateDrawableState, STATE_CHECKABLE);
        }
        return onCreateDrawableState;
    }
}
