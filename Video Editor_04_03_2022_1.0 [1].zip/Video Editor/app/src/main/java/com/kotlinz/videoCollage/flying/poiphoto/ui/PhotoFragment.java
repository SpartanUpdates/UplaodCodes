package com.kotlinz.videoCollage.flying.poiphoto.ui;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.flying.poiphoto.Configure;
import com.kotlinz.videoCollage.flying.poiphoto.Define;
import com.kotlinz.videoCollage.flying.poiphoto.PhotoManager;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Photo;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.PhotoAdapter;
import com.kotlinz.videoeditor.R;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class PhotoFragment extends Fragment {
    ImageView back;
    ImageView done;
    private PhotoAdapter mAdapter;
    RecyclerView mPhotoList;
    private PhotoManager mPhotoManager;

    private class PhotoTask extends AsyncTask<String, Integer, List<Photo>> {
        private PhotoTask() {
        }

        PhotoTask(PhotoFragment photoFragment) {
            this();
        }


        public List<Photo> doInBackground(String... strArr) {
            return PhotoFragment.this.mPhotoManager.getPhoto(strArr[0]);
        }


        public void onPostExecute(List<Photo> list) {
            super.onPostExecute(list);
            PhotoFragment.this.refreshPhotoList(list);
        }
    }

    public static PhotoFragment newInstance(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("bucketId", str);
        PhotoFragment photoFragment = new PhotoFragment();
        photoFragment.setArguments(bundle);
        return photoFragment;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mPhotoManager = new PhotoManager(getContext());
        ActionBar supportActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.poiphoto_fragment_photo, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
        String string = getArguments().getString("bucketId");
        new PhotoTask(this).execute(new String[]{string});
    }

    private void init(final View view) {
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.image_toolbar);
        final Configure configure = ((PickImageActivity) getActivity()).getConfigure();
        if (toolbar != null) {
            initToolbar(toolbar, configure);
        }
        this.back = (ImageView) view.findViewById(R.id.img_photo_tool_back);
        this.done = (ImageView) view.findViewById(R.id.img_photo_tool_done);
        this.mPhotoList = (RecyclerView) view.findViewById(R.id.photo_list);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.photo_list);
        this.mPhotoList = recyclerView;
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        PhotoAdapter photoAdapter = new PhotoAdapter(getActivity(), "replace");
        this.mAdapter = photoAdapter;
        photoAdapter.setMaxCount(configure.getMaxCount());
        this.mAdapter.setOnSelectedMaxListener(new PhotoAdapter.OnSelectedMaxListener() {
            public void onSelectedMax() {
                Snackbar.make(view, configure.getMaxNotice(), BaseTransientBottomBar.LENGTH_SHORT).show();
            }
        });
        this.mAdapter.setOnPhotoSelectedListener(new PhotoAdapter.OnPhotoSelectedListener() {
            public void onPhotoSelected(Photo photo, int i) {
            }
        });
        this.mAdapter.setOnPhotoUnSelectedListener(new PhotoAdapter.OnPhotoUnSelectedListener() {
            public void onPhotoUnSelected(Photo photo, int i) {
            }
        });
        this.mPhotoList.setHasFixedSize(true);
        this.mPhotoList.setAdapter(this.mAdapter);
        this.back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PhotoFragment.this.getActivity().onBackPressed();
            }
        });
        this.done.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (PhotoFragment.this.mAdapter.getSelectedPhotoPaths().size() > 0) {
                    Intent intent = new Intent();
                    intent.putStringArrayListExtra(Define.PATHS, PhotoFragment.this.mAdapter.getSelectedPhotoPaths());
                    intent.putParcelableArrayListExtra(Define.PHOTOS, PhotoFragment.this.mAdapter.getSelectedPhotos());
                    PhotoFragment.this.getActivity().setResult(-1, intent);
                    PhotoFragment.this.getActivity().finish();
                    return;
                }
                Toast.makeText(PhotoFragment.this.getContext(), "Select any one photo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initToolbar(Toolbar toolbar, Configure configure) {
        if (configure != null) {
            toolbar.setTitle(configure.getPhotoTitle());
            toolbar.setBackgroundColor(configure.getToolbarColor());
            toolbar.setTitleTextColor(configure.getToolbarTitleColor());
        }
    }

    private void refreshPhotoList(List<Photo> list) {
        this.mAdapter.refreshData(list);
    }
}
