package com.UnitedVideos.TextChange.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.UnitedVideos.TextChange.Adapter.TextAdapterU;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import static com.wavymusic.NativeAds.NativeAdvanceAds.populateNativeAdView;


public class TextEditActivityUv extends Activity {

    Activity activity = TextEditActivityUv.this;
    public static ArrayList<String> a = new ArrayList();
    public static ArrayList<String> b = new ArrayList();
    RecyclerView c;
    TextAdapterU d;
    String e;
    public static String f;
    public static String g;
    public static String h;
    String i;
    LinearLayout j;
    EditText k;
    OnDateSetListener l;
    Calendar m;
    ImageView n;
    ImageView o;
    AlertDialog p;
    private Toolbar q;
    private boolean w;
    TextView tvtitle, tvDone, tvchangemessage;
    ImageView ivbcak;

    private UnifiedNativeAd nativeAd;

    private void h() {
        k.setText(new SimpleDateFormat("dd-MMMM", Locale.US).format(m.getTime()));
        String obj = k.getText().toString();
        f = obj.substring(0, obj.indexOf("-"));
        g = obj.substring(obj.indexOf("-") + 1);
    }

    public static String a(ArrayList<String> arrayList) {
        JSONObject jSONObject = new JSONObject();
        try {
            String str;
            Object obj;
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < arrayList.size()) {
                jSONArray.put(arrayList.get(i).equals("") ? b.get(i) : arrayList.get(i));
                i++;
            }
            if (f.equals("")) {
                str = "Bdate";
                obj = h;
            } else {
                str = "Bdate";
                obj = f;
            }
            jSONObject.put(str, obj);
            if (g.equals("")) {
                str = "Bmonth";
                obj = i;
            } else {
                str = "Bmonth";
                obj = g;
            }
            jSONObject.put(str, obj);
            jSONObject.put("data", jSONArray);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FINAL Down Json:");
            stringBuilder.append(jSONObject.toString());
            Log.e("DDD", stringBuilder.toString());
            return jSONObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    public void a() {
        q = findViewById(R.id.toolbar);
        tvtitle = findViewById(R.id.tv_message);
        tvDone = findViewById(R.id.tv_done);
        tvchangemessage = findViewById(R.id.tv_change_message);
        ivbcak = findViewById(R.id.ivBack);
        c = findViewById(R.id.rv_edit_group);
        j = findViewById(R.id.ll_default_date);
        k = findViewById(R.id.et_date_input);
        n = findViewById(R.id.iv_info_date);
        o = findViewById(R.id.iv_info_message);
    }

    public void a(int i) {
        View findViewByPosition = c.getLayoutManager().findViewByPosition(i + 1);
        if (findViewByPosition != null) {
            findViewByPosition.findViewById(R.id.et_row_single).requestFocus();
        }
    }

    public void a(Context context, TextView textView) {
        textView.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/Ubuntu-R.ttf"));
    }

    class C18275 implements DialogInterface.OnClickListener {

        final TextEditActivityUv a;

        C18275(TextEditActivityUv textEditActivityUv) {
            a = textEditActivityUv;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            a.p.dismiss();
        }
    }

    public void a(String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage(str);
        builder.setPositiveButton("OK", new C18275(this));
        p = builder.create();
        p.show();
    }

    private void CallNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public ArrayList<String> b(String str) {
        ArrayList<String> arrayList = new ArrayList();
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                f = jSONObject.getString("Bdate");
                g = jSONObject.getString("Bmonth");
                h = f;
                i = g;
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                for (int i = 0; i < jSONArray.length(); i++) {
                    arrayList.add(jSONArray.getString(i));
                }
                return arrayList;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void b() {
        m = Calendar.getInstance();

        g();
        d = new TextAdapterU(a, this);
        c.setLayoutManager(new LinearLayoutManager(this));
        c.setHasFixedSize(true);
        c.setAdapter(d);
        if (!f.equals("0")) {
            j.setVisibility(View.VISIBLE);
            EditText editText = k;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(f);
            stringBuilder.append("-");
            stringBuilder.append(g);
            editText.setText(stringBuilder.toString());
        }
    }

    public void c() {
        k.setOnClickListener(new View.OnClickListener() {
            final TextEditActivityUv a = TextEditActivityUv.this;

            public void onClick(View view) {
                new DatePickerDialog(a, a.l, a.m.get(1), a.m.get(2), a.m.get(5)).show();
            }
        });
        l = new OnDateSetListener() {
            final TextEditActivityUv a = TextEditActivityUv.this;

            public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                a.m.set(1, i);
                a.m.set(2, i2);
                a.m.set(5, i3);
                a.h();
            }
        };
        n.setOnClickListener(new View.OnClickListener() {
            final TextEditActivityUv a = TextEditActivityUv.this;

            public void onClick(View view) {
                a.a("This date will appear in  video.");
            }
        });
        o.setOnClickListener(new View.OnClickListener() {
            final TextEditActivityUv a = TextEditActivityUv.this;

            public void onClick(View view) {
                a.a("This messages will appear in video.");
            }
        });
    }


    public void f() {
        String a = a(TextEditActivityUv.a);
        UnityPlayer.UnitySendMessage("UVThemeData", "ReturnTextResponce", a);
        finish();
    }

    public void g() {
        e = getIntent().getStringExtra("JsonStr");
        Log.e("DDD", "fillDataArray() called");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InputJson = ");
        stringBuilder.append(e);
        Log.e("DDD", stringBuilder.toString());
        a.addAll(b(e));
        b.addAll(a);
    }


    public void onBackPressed() {
        super.onBackPressed();
        if (a != null && b != null) {
            a.clear();
            b.clear();
        }
        UnityPlayer.UnitySendMessage("UVThemeData", "BackFromGallery", "");
        finish();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editable_text_change_uv);
        PutAnalyticsEvent();
        if (a != null && b != null) {
            a.clear();
            b.clear();
        }
        a();
        b();
        c();
        CallNativeAds();
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.mInterstitialAdUv != null && MyApplication.mInterstitialAdUv.isLoaded()) {
                    MyApplication.AdsIdUv = 3;
                    MyApplication.AdsShowContext = activity;
                    MyApplication.mInterstitialAdUv.show();
                } else if (MyApplication.fbinterstitialAdUv != null && MyApplication.fbinterstitialAdUv.isAdLoaded()) {
                    MyApplication.AdsIdUv = 3;
                    MyApplication.AdsShowContext = activity;
                    MyApplication.fbinterstitialAdUv.show();
                } else {
                    f();
                }
            }
        });
        ivbcak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "TextEditActivityUv");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }
}