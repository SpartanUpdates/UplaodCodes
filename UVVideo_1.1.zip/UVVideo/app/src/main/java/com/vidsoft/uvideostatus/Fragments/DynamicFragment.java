package com.vidsoft.uvideostatus.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.vidsoft.uvideostatus.R;

public class DynamicFragment extends Fragment {
    private int page;
    private String title;

    public static DynamicFragment newInstance(int i, String str) {
        DynamicFragment dynamicFragment = new DynamicFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("someInt", i);
        bundle.putString("someTitle", str);
        dynamicFragment.setArguments(bundle);
        return dynamicFragment;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.page = getArguments().getInt("someInt", 0);
        this.title = getArguments().getString("someTitle");
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.trending_fragment, viewGroup, false);
    }
}
