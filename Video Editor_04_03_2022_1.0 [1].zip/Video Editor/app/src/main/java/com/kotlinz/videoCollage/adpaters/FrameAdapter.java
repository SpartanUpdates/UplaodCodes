package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.interfaces.FrameAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FrameAdapter extends RecyclerView.Adapter<FrameAdapter.ViewHolder> {
    private Context context;
    private ArrayList<String> listFrames;
    public FrameAdapterCallBackInterface listener;
    public int pos = 0;

    int position = -1;

    public FrameAdapter(ArrayList<String> arrayList, Context context2, FrameAdapterCallBackInterface frameAdapterCallBackInterface) {
        this.listFrames = arrayList;
        this.listener = frameAdapterCallBackInterface;
        this.context = context2;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_frame, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        InputStream inputStream;
        String str = this.listFrames.get(i);
        try {
            AssetManager assets = this.context.getAssets();
            inputStream = assets.open("frame/" + str);
        } catch (IOException e) {
            e.printStackTrace();
            inputStream = null;
        }
        viewHolder.imgFrame.setImageBitmap(BitmapFactory.decodeStream(inputStream));
        viewHolder.imgFrame.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                position = i;
                FrameAdapter.this.listener.itemClick(i);
                notifyDataSetChanged();

            }
        });
        if (this.position == i) {
            viewHolder.imgFrameSelector.setBackgroundResource(R.drawable.frame_bg_selector);
        } else {
            viewHolder.imgFrameSelector.setBackgroundResource(R.drawable.frame_bg_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
        notifyDataSetChanged();
    }

    public int getItemCount() {
        return this.listFrames.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgFrame;
        ImageView imgFrameSelector;

        ViewHolder(View view) {
            super(view);
            this.imgFrame = (ImageView) view.findViewById(R.id.img_frame);
            this.imgFrameSelector = (ImageView) view.findViewById(R.id.img_frame_selector);
        }
    }
}
