package com.esc.phoneheart.utility;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.util.Log;

import com.esc.phoneheart.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.documentfile.provider.DocumentFile;

public class FileUtil {
    public static final String PRIMARY_VOLUME_NAME = "primary";

    public FileUtil() {
        throw new UnsupportedOperationException();
    }

    public static boolean IsDeletionBelow6() {
        return VERSION.SDK_INT <= 21;
    }

    public static long convertCRC64(String str) {
        if (str == null) {
        }
        return 0;
    }

    public static boolean deleteFile(Context context, @NonNull File file) {
        boolean z = true;
        if (file.delete()) {
            return true;
        }
        if (VERSION.SDK_INT < 21) {
            return file.exists();
        }
        DocumentFile documentFile = getDocumentFile(context, file, false, true);
        if (documentFile == null || !documentFile.delete()) {
            z = false;
        }
        return z;
    }

    public static char[] genrateCPlusChar(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            stringBuilder.append(str.charAt(i));
            stringBuilder.append("\u0000");
        }
        return stringBuilder.toString().toCharArray();
    }

    public static DocumentFile getDocumentFile(Context context, @NonNull File file, boolean z, boolean z2) {
        Uri[] treeUris = getTreeUris(context);
        if (treeUris.length == 0) {
            return null;
        }
        try {
            String canonicalPath = file.getCanonicalPath();
            String str = null;
            Uri uri = null;
            int i = 0;
            while (str == null && i < treeUris.length) {
                String fullPathFromTreeUri = null;
                if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    fullPathFromTreeUri = getFullPathFromTreeUri(treeUris[i], context);
                }
                if (fullPathFromTreeUri != null && canonicalPath.startsWith(fullPathFromTreeUri)) {
                    uri = treeUris[i];
                    str = fullPathFromTreeUri;
                }
                i++;
            }
            if (str == null) {
                uri = treeUris[0];
                if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    str = getExtSdCardFolder(context, file);
                }
            }
            if (str == null) {
                return null;
            }
            String substring = canonicalPath.substring(str.length() + 1);
            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(context, uri);
            String[] split = substring.split("\\/");
            for (int i2 = 0; i2 < split.length; i2++) {
                DocumentFile findFile = fromTreeUri.findFile(split[i2]);
                if (findFile != null) {
                    fromTreeUri = findFile;
                } else if (i2 < split.length - 1) {
                    if (!z2) {
                        return null;
                    }
                    fromTreeUri = fromTreeUri.createDirectory(split[i2]);
                } else if (z) {
                    fromTreeUri = fromTreeUri.createDirectory(split[i2]);
                } else {
                    fromTreeUri = fromTreeUri.createFile("image", split[i2]);
                }
            }
            return fromTreeUri;
        } catch (IOException unused) {
            return null;
        }
    }

    @RequiresApi(21)
    public static String getDocumentPathFromTreeUri(Uri uri) {
        String[] split = DocumentsContract.getTreeDocumentId(uri).split(":");
        if (split.length < 2 || split[1] == null) {
            return File.separator;
        }
        return split[1];
    }

    public static String getExtSdCardFolder(Context context, @NonNull File file) {
        try {
            for (String str : getExtSdCardPaths(context)) {
                if (file.getCanonicalPath().startsWith(str)) {
                    return str;
                }
            }
        } catch (IOException unused) {
        }
        return null;
    }

    public static String[] getExtSdCardPaths(Context context) {
        ArrayList arrayList = new ArrayList();
        String str = "external";
        if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            for (File file : context.getExternalFilesDirs(str)) {
                if (!(file == null || file.equals(context.getExternalFilesDir(str)))) {
                    int lastIndexOf = file.getAbsolutePath().lastIndexOf("/Android/data");
                    if (lastIndexOf < 0) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Unexpected external file dir: ");
                        stringBuilder.append(file.getAbsolutePath());
                        Log.w("FileUtil", stringBuilder.toString());
                    } else {
                        String substring = file.getAbsolutePath().substring(0, lastIndexOf);
                        try {
                            substring = new File(substring).getCanonicalPath();
                        } catch (IOException unused) {
                        }
                        arrayList.add(substring);
                    }
                }
            }
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    @Nullable
    public static String getFullPathFromTreeUri(@Nullable Uri uri, Context context) {
        if (uri == null) {
            return null;
        }
        String volumePath = null;
        if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            volumePath = getVolumePath(getVolumeIdFromTreeUri(uri), context);
        }
        if (volumePath == null) {
            return File.separator;
        }
        if (volumePath.endsWith(File.separator)) {
            volumePath = volumePath.substring(0, volumePath.length() - 1);
        }
        String documentPathFromTreeUri = null;
        if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            documentPathFromTreeUri = getDocumentPathFromTreeUri(uri);
        }
        if (documentPathFromTreeUri.endsWith(File.separator)) {
            documentPathFromTreeUri = documentPathFromTreeUri.substring(0, documentPathFromTreeUri.length() - 1);
        }
        if (documentPathFromTreeUri.length() <= 0) {
            return volumePath;
        }
        StringBuilder stringBuilder;
        if (documentPathFromTreeUri.startsWith(File.separator)) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(volumePath);
            stringBuilder.append(documentPathFromTreeUri);
            return stringBuilder.toString();
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(volumePath);
        stringBuilder.append(File.separator);
        stringBuilder.append(documentPathFromTreeUri);
        return stringBuilder.toString();
    }

    @NonNull
    public static String getSdCardPath() {
        String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        try {
            absolutePath = new File(absolutePath).getCanonicalPath();
            return absolutePath;
        } catch (IOException e) {
            Log.e("FileUtil", "Could not get SD directory", e);
            return absolutePath;
        }
    }

    public static Uri getSharedPreferenceUri(int i, Context context) {
        String string = getSharedPreferences(context).getString(context.getString(i), null);
        if (string == null) {
            return null;
        }
        return Uri.parse(string);
    }

    public static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static Uri[] getTreeUris(Context context) {
        ArrayList arrayList = new ArrayList();
        Uri sharedPreferenceUri = getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_photos, context);
        if (sharedPreferenceUri != null) {
            arrayList.add(sharedPreferenceUri);
        }
        Uri sharedPreferenceUri2 = getSharedPreferenceUri(R.string.pcl_key_internal_uri_extsdcard_input, context);
        if (sharedPreferenceUri2 != null) {
            arrayList.add(sharedPreferenceUri2);
        }
        return (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
    }

    public static String getVolumeIdFromTreeUri(Uri uri) {
        String[] split = new String[0];
        if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            split = DocumentsContract.getTreeDocumentId(uri).split(":");
        }
        return split.length > 0 ? split[0] : null;
    }

    public static String getVolumePath(String str, Context context) {
        if (VERSION.SDK_INT < 21) {
            return null;
        }
        try {
            @SuppressLint("WrongConstant") StorageManager storageManager = (StorageManager) context.getSystemService("storage");
            Class cls = Class.forName("android.os.storage.StorageVolume");
            Method method = storageManager.getClass().getMethod("getVolumeList", new Class[0]);
            Method method2 = cls.getMethod("getUuid", new Class[0]);
            Method method3 = cls.getMethod("getPath", new Class[0]);
            Method method4 = cls.getMethod("isPrimary", new Class[0]);
            Object invoke = method.invoke(storageManager, new Object[0]);
            int length = Array.getLength(invoke);
            for (int i = 0; i < length; i++) {
                Object obj = Array.get(invoke, i);
                String str2 = (String) method2.invoke(obj, new Object[0]);
                if (((Boolean) method4.invoke(obj, new Object[0])).booleanValue() && PRIMARY_VOLUME_NAME.equals(str)) {
                    return (String) method3.invoke(obj, new Object[0]);
                }
                if (str2 != null && str2.equals(str)) {
                    return (String) method3.invoke(obj, new Object[0]);
                }
            }
        } catch (Exception unused) {
        }
        return null;
    }

    public static boolean isKitKat() {
        return VERSION.SDK_INT == 19;
    }

    public static boolean isOnExtSdCard(Context context, @NonNull File file) {
        return getExtSdCardFolder(context, file) != null;
    }

    public static boolean isSystemAndroid5() {
        return VERSION.SDK_INT >= 21;
    }

    public static boolean isWritable(@NonNull File file) {
        boolean exists = file.exists();

        try {
            new FileOutputStream(file, true).close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        boolean canWrite = file.canWrite();
        if (!exists) {
            file.delete();
        }
        return canWrite;
    }

    @RequiresApi(api = 21)
    public static boolean isWritableNormalOrSaf(Context context, @Nullable File file) {
        Util.appendLogphonecleaner("IsWritable", "method isWritableNormalOrSaf", GlobalData.FILE_NAME);
        boolean z = false;
        if (file != null && file.exists() && file.isDirectory()) {
            File file2;
            int i = 0;
            do {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("AugendiagnoseDummyFile");
                i++;
                stringBuilder.append(i);
                file2 = new File(file, stringBuilder.toString());
            } while (file2.exists());
            if (isWritable(file2)) {
                return true;
            }
            try {
                DocumentFile documentFile = getDocumentFile(context, file2, false, false);
                if (documentFile == null) {
                    return false;
                }
                if (documentFile.canWrite() && file2.exists()) {
                    z = true;
                }
                documentFile.delete();
            } catch (Exception unused) {
            }
        }
        return z;
    }
}
