package com.kotlinz.videoeditor.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Audio.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.kotlinz.videoeditor.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.concurrent.TimeUnit;

@SuppressLint({"WrongConstant"})
public class AudioPlayerActivity extends AppCompatActivity implements OnSeekBarChangeListener {

    Activity activity = AudioPlayerActivity.this;
    static final boolean BOOLEN = true;
    Bundle a;
    ImageView b;
    ImageView c;
    int d = 0;
    Handler e = new Handler();
    boolean f = false;
    boolean g = false;
    SeekBar h;
    Uri i;
    TextView j;
    TextView k;
    String n = "";

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    Runnable o = new Runnable() {
        public void run() {
            if (AudioPlayerActivity.this.r.isPlaying()) {
                int currentPosition = AudioPlayerActivity.this.r.getCurrentPosition();
                AudioPlayerActivity.this.h.setProgress(currentPosition);
                AudioPlayerActivity.this.j.setText(AudioPlayerActivity.formatTimeUnit(currentPosition));
                if (currentPosition == AudioPlayerActivity.this.d) {
                    AudioPlayerActivity.this.h.setProgress(0);
                    AudioPlayerActivity.this.j.setText(zero);
                    AudioPlayerActivity.this.e.removeCallbacks(AudioPlayerActivity.this.o);
                    return;
                }
                AudioPlayerActivity.this.e.postDelayed(AudioPlayerActivity.this.o, 200);
                return;
            }
            AudioPlayerActivity.this.h.setProgress(AudioPlayerActivity.this.d);
            AudioPlayerActivity.this.j.setText(AudioPlayerActivity.formatTimeUnit(AudioPlayerActivity.this.d));
            AudioPlayerActivity.this.e.removeCallbacks(AudioPlayerActivity.this.o);
        }
    };
    OnClickListener p = new OnClickListener() {
        @Override
        public void onClick(View view) {
            StringBuilder sb = new StringBuilder();
            sb.append("play status ");
            sb.append(AudioPlayerActivity.this.f);
            Log.e("", sb.toString());
            if (AudioPlayerActivity.this.f) {
                try {
                    r.pause();
                    e.removeCallbacks(o);
                    c.setBackgroundResource(R.drawable.ic_play_upress);
                } catch (IllegalStateException e1) {
                    e1.printStackTrace();
                }
            } else {
                try {
                    r.seekTo(h.getProgress());
                    r.start();
                    e.postDelayed(o, 200);
                    b.setVisibility(0);
                    c.setBackgroundResource(R.drawable.ic_pause_unpresss);
                } catch (IllegalStateException e2) {
                    e2.printStackTrace();
                }
            }
            f ^= AudioPlayerActivity.BOOLEN;
        }
    };

    MediaPlayer r;
    private final String zero = "00:00";

    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    public void onStopTrackingTouch(SeekBar seekBar) {

    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.audioplayer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText("My Audio");
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        PutAnalyticsEvent();
        BannerAds();
        if (BOOLEN || supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(BOOLEN);
            supportActionBar.setDisplayShowTitleEnabled(false);
            this.a = getIntent().getExtras();
            if (this.a != null) {
                this.n = this.a.getString("song");
                this.g = this.a.getBoolean("isfrom", false);
            }
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(new File(this.n)));
            sendBroadcast(intent);
            thumbAudio(this.n);
            this.b = findViewById(R.id.iv_Thumb);
            this.h = findViewById(R.id.sbVideo);
            this.h.setOnSeekBarChangeListener(this);
            this.r = MediaPlayer.create(this, Uri.parse(this.n));
            this.j = findViewById(R.id.tvStartVideo);
            this.k = findViewById(R.id.tvEndVideo);
            this.c = findViewById(R.id.btnPlayVideo);
            this.r.setOnErrorListener(new OnErrorListener() {
                public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                    Toast.makeText(AudioPlayerActivity.this.getApplicationContext(), "Audio Player Not Supproting", 0).show();
                    return AudioPlayerActivity.BOOLEN;
                }
            });
            this.r.setOnPreparedListener(new OnPreparedListener() {
                public void onPrepared(MediaPlayer mediaPlayer) {
                    AudioPlayerActivity.this.d = AudioPlayerActivity.this.r.getDuration();
                    AudioPlayerActivity.this.h.setMax(AudioPlayerActivity.this.d);
                    AudioPlayerActivity.this.j.setText(zero);
                    AudioPlayerActivity.this.k.setText(AudioPlayerActivity.formatTimeUnit(AudioPlayerActivity.this.d));
                    StringBuilder sb = new StringBuilder();
                    sb.append("duration : ");
                    sb.append(VideoPlayerActivity.formatTimeUnit(AudioPlayerActivity.this.d));
                }
            });
            this.r.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    AudioPlayerActivity.this.c.setBackgroundResource(R.drawable.ic_play_upress);
                    AudioPlayerActivity.this.r.seekTo(0);
                    AudioPlayerActivity.this.h.setProgress(0);
                    AudioPlayerActivity.this.j.setText(zero);
                    AudioPlayerActivity.this.e.removeCallbacks(AudioPlayerActivity.this.o);
                    AudioPlayerActivity.this.f ^= AudioPlayerActivity.BOOLEN;
                }
            });
            this.c.setOnClickListener(this.p);


        } else {
            throw new AssertionError();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AudioPlayerActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean isOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager.getActiveNetworkInfo() == null || !connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting()) {
            return false;
        }
        return BOOLEN;
    }

    public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
        if (z) {
            this.r.seekTo(i2);
            this.j.setText(formatTimeUnit(i2));
        }
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit(long j2) {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    public void thumbAudio(String str) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        String[] strArr = {"_data", "_id"};
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        sb.append(str);
        sb.append("%");
        Cursor managedQuery = managedQuery(uri, strArr, "_data  like ?", new String[]{sb.toString()}, " _id DESC");
        int count = managedQuery.getCount();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("count");
        sb2.append(count);
        Log.e("", sb2.toString());
        if (count > 0) {
            managedQuery.moveToFirst();
            for (int i2 = 0; i2 < count; i2++) {
                Uri withAppendedPath = Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, getLong(managedQuery));
                StringBuilder sb3 = new StringBuilder();
                sb3.append("===******* uri ===");
                sb3.append(withAppendedPath);
                Log.e("", sb3.toString());
                this.i = withAppendedPath;
                managedQuery.moveToNext();
            }
        }
    }

    public String getLong(Cursor cursor) {
        return String.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
    }

    public void delete() {
        new AlertDialog.Builder(this).setTitle("Are you sure?").setMessage("delete Ringtone")
                .setPositiveButton("delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        r.pause();
                        e.removeCallbacks(o);
                        c.setBackgroundResource(R.drawable.ic_play_upress);
                        File file = new File(n);
                        if (file.exists()) {
                            file.delete();
                            try {
                                Uri contentUriForPath = Media.getContentUriForPath(AudioPlayerActivity.this.n);
                                StringBuilder sb = new StringBuilder();
                                sb.append("=====Enter ====");
                                sb.append(contentUriForPath);
                                Log.e("", sb.toString());
                                ContentResolver contentResolver = AudioPlayerActivity.this.getContentResolver();
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append("_data=\"");
                                sb2.append(AudioPlayerActivity.this.n);
                                sb2.append("\"");
                                contentResolver.delete(contentUriForPath, sb2.toString(), null);
                            } catch (Exception unused) {
                                unused.printStackTrace();
                            }
                            AudioPlayerActivity.this.onBackPressed();
                        }
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).setCancelable(BOOLEN).show();
    }

    @Override
    public void onStart() {
        super.onStart();
    }


    @Override
    public void onStop() {
        getWindow().clearFlags(128);
        super.onStop();
    }


    @Override
    public void onResume() {
        super.onResume();
    }


    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(this, StartActivity.class);
        intent.setFlags(67108864);
        startActivity(intent);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_deleteshare, menu);
        return BOOLEN;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            if (this.r.isPlaying()) {
                this.r.stop();
            }
            super.onBackPressed();
            if (this.g) {
                try {
                    onBackPressed();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            finish();
            return BOOLEN;
        }
        if (menuItem.getItemId() == R.id.Delete) {
            delete();
        } else if (menuItem.getItemId() == R.id.Share) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("audio/*");
                intent.putExtra("android.intent.extra.STREAM", this.i);
                startActivity(Intent.createChooser(intent, "Share File"));
            } catch (Exception unused) {
                unused.printStackTrace();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
