package com.esc.howtomakeschoolsupplies.network;

import java.util.TimerTask;

public class ConnectToServerconnectArticle1onFailureinlinedschedule1 extends TimerTask {
    final ConnectToServerconnectArticle1 this$0;

    public ConnectToServerconnectArticle1onFailureinlinedschedule1(ConnectToServerconnectArticle1 connectToServer$connectArticle$1) {
        this.this$0 = connectToServer$connectArticle$1;
    }

    public void run() {
        TimerTask timerTask = this;
        new ConnectToServer().connectArticle(this.this$0.$loadingArticles);
    }
}
