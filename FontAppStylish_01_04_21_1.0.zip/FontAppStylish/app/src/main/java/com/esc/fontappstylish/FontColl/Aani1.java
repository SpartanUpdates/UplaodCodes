package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Aani1 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"", "Ᏸ", "ፈ", "Ꮄ", "Ꮛ", "Ꭶ", "Ꮆ", "Ꮒ", "Ꭵ", "Ꮰ", "Ꮶ", "Ꮭ", "Ꮇ", "Ꮑ", "Ꭷ", "Ꭾ", "Ꭴ", "Ꮢ", "Ꮥ", "Ꮦ", "Ꮼ", "Ꮙ", "Ꮗ", "ጀ", "Ꭹ", "ፚ"};
    }

    public String getName() {
        return "ᏗᏰፈ";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"Ꮧ", "Ᏸ", "ፈ", "Ꮄ", "Ꮛ", "Ꭶ", "Ꮆ", "Ꮒ", "Ꭵ", "Ꮰ", "Ꮶ", "Ꮭ", "Ꮇ", "Ꮑ", "Ꭷ", "Ꭾ", "Ꭴ", "Ꮢ", "Ꮥ", "Ꮦ", "Ꮼ", "Ꮙ", "Ꮗ", "ጀ", "Ꭹ", "ፚ"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
