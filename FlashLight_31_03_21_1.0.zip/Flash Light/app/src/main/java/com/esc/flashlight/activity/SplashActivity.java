package com.esc.flashlight.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.core.content.ContextCompat;
import com.esc.flashlight.R;

public class SplashActivity extends BaseActivity {

    Activity activity = SplashActivity.this;
    Intent intent;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView((int) R.layout.activity_splash);
        new Thread() {
            public void run() {
                SplashActivity splashActivity;
                Intent intent;
                try {
                    sleep(2000);
                    if (SplashActivity.this.requestStoragePermission()) {
                        intent = new Intent(SplashActivity.this, FlashLightActivity.class);
                        intent = intent;
                        startActivity(intent);
                        finish();
                    } else {
                        intent = new Intent(SplashActivity.this, PermissionActivity.class);
                        intent = intent;
                        startActivity(intent);
                        finish();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    if (SplashActivity.this.requestStoragePermission()) {
                        intent = new Intent(SplashActivity.this, FlashLightActivity.class);
                    } else {
                        intent = new Intent(SplashActivity.this, PermissionActivity.class);
                    }
                } catch (Throwable th) {
                    if (SplashActivity.this.requestStoragePermission()) {
                        SplashActivity.this.intent = new Intent(SplashActivity.this, FlashLightActivity.class);
                        splashActivity = SplashActivity.this;
                        splashActivity.startActivity(splashActivity.intent);
                        SplashActivity.this.finish();
                    } else {
                        SplashActivity.this.intent = new Intent(SplashActivity.this, PermissionActivity.class);
                        splashActivity = SplashActivity.this;
                        splashActivity.startActivity(splashActivity.intent);
                        SplashActivity.this.finish();
                    }
                }
            }
        }.start();
    }

    public boolean requestStoragePermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.READ_PHONE_STATE") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE") == 0;
    }
}
