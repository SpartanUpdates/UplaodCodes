package com.kotlinz.festivalstorymaker.Model.PosterMaker;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class PosterMakerResponse {

	@SerializedName("data")
	private ArrayList<PosterMainCategory> data;

	@SerializedName("status")
	private String status;

	public ArrayList<PosterMainCategory> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}