package com.esc.socialmediacleaner.util;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.OnClickListener;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.primitives.Ints;
import com.esc.socialmediacleaner.R;

public abstract class PermitionActivity extends AppCompatActivity {
    private SparseIntArray mErrorString;

    public abstract void onPermissionsGranted(int i);

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mErrorString = new SparseIntArray();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        int i2 = 0;
        for (int i3 : iArr) {
            i2 += i3;
        }
        if (iArr.length <= 0 || i2 != 0) {
            findViewById(R.id.hiddenpermissionlayout).setVisibility(View.VISIBLE);
            findViewById(R.id.hiddenpermissionlayout).bringToFront();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                findViewById(R.id.hiddenpermissionlayout).setTranslationZ(10.0f);
            }
            return;
        }
        onPermissionsGranted(i);
    }

    public void requestAppPermissions(final String[] strArr, int i, final int i2) {
        this.mErrorString.put(i2, i);
        int i3 = 0;
        Object obj = null;
        for (String str : strArr) {
            i3 += ContextCompat.checkSelfPermission(this, str);
            obj = (obj != null || ActivityCompat.shouldShowRequestPermissionRationale(this, str)) ? 1 : null;
        }
        if (i3 == 0) {
            onPermissionsGranted(i2);
        } else if (obj != null) {
            findViewById(R.id.hiddenpermissionlayout).setVisibility(View.VISIBLE);
            findViewById(R.id.hiddenpermissionlayout).bringToFront();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                findViewById(R.id.hiddenpermissionlayout).setTranslationZ(10.0f);
            }
        } else {
            ActivityCompat.requestPermissions(this, strArr, i2);
        }
        findViewById(R.id.iv_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PermitionActivity.this.finish();
            }
        });
        findViewById(R.id.btngrantpermission).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = "android.permission.WRITE_EXTERNAL_STORAGE";
                ContextCompat.checkSelfPermission(PermitionActivity.this, str);
                if (ActivityCompat.shouldShowRequestPermissionRationale(PermitionActivity.this, str)) {
                    ActivityCompat.requestPermissions(PermitionActivity.this, strArr, i2);
                    return;
                }
                Intent intent = new Intent();
                intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent.addCategory("android.intent.category.DEFAULT");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("package:");
                stringBuilder.append(PermitionActivity.this.getPackageName());
                intent.setData(Uri.parse(stringBuilder.toString()));
                intent.addFlags(268435456);
                intent.addFlags(Ints.MAX_POWER_OF_TWO);
                intent.addFlags(8388608);
                PermitionActivity.this.startActivity(intent);
            }
        });
    }

    public void closebtnClick() {
        findViewById(R.id.iv_permission_close_btn).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PermitionActivity.this.finish();
            }
        });
    }
}
