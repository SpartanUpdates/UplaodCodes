package com.kotlinz.vehiclemanager.retrofit;

public class AppConstant {
    public static String API_CLUB_BASEURL = "https://api.apiclub.in/api/";
    public static String API_RTO_VEHICLE_INFORMATION_CREDENTIALS = "http://rto.trendinganimations.com/api/";
    public static String XAuthorization = "Czjg7Tfg0pWyPfbkgOR1rsqRWBZp0gCY";
    public static String AppPackageName = "com.clorasoft.rtovehiclemanager";
}
