﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace BallCollect
{
	public class BallControl : MonoBehaviour
	{
		public PhysicMaterial mtrPhysic;

		public Collider ballCollider;

		public Rigidbody objRigidbody;

		public GameObject breakBall;
		
		Vector3 orignalPosition;

		public bool isX = false, isY = false, isZ = false;

		public float speed = 0.1f;

		public AudioClip ballCollectMusic, ballDropMusic;

		AudioSource touchSound;

		bool isTouchPlay = false;

		private void Awake()
		{
			this.objRigidbody = this.GetComponent<Rigidbody>();
			touchSound = this.GetComponent<AudioSource>();
			
		}
		Vector3 throwPos;
		public void ThrowBall()
		{
			this.ballCollider.material = this.mtrPhysic;
			throwPos.x = (float)UnityEngine.Random.Range(-8, 8);
			throwPos.z = (float)UnityEngine.Random.Range(9, 12);
			this.objRigidbody.velocity = throwPos;
		}
		MeshRenderer[] g;
		private void OnTriggerEnter(Collider other)
		{
			if (other.CompareTag("BallCounter"))
			{
				if (GameController.instance.isSound)
					touchSound.PlayOneShot(ballDropMusic);
				StartCoroutine(BallBlast(0.2f));
			}

			if (other.CompareTag("Gear"))
			{
				this.gameObject.SetActive(false);
				GameObject go =  Instantiate(breakBall, transform.position, Quaternion.identity);

				g = go.GetComponentsInChildren<MeshRenderer>();
				for (int i = 0; i < g.Length; i++)
				{
					g[i].material.color = ColorManager.PlatfromColor[GameController.instance.colorNo];
				}				
				Destroy(this.gameObject);
				Destroy(go,2);
			}
			if (other.gameObject.CompareTag("Player") && !isTouchPlay)
			{
				isTouchPlay = true;
				if (GameController.instance.isSound)
				{
					touchSound.Play();
				}
				StartCoroutine(WaitVibrate());
			}
		}

		IEnumerator WaitVibrate()
		{
			yield return new WaitForSecondsRealtime(0.1f);
			GameController.instance.BallTouchVibrate();
		}
		private void OnCollisionEnter(Collision collision)
		{
			if (collision.gameObject.CompareTag("CheckPointBase"))
			{
				objRigidbody.velocity = Vector3.zero;
			}
		}

		Vector3 tempPos;
		float elapsed = 0f;
		Rigidbody[] go1;
		public IEnumerator BallBlast(float duration)
		{
			float tempWait = UnityEngine.Random.Range(0.3f, 2.0f);
			WaitForSecondsRealtime delay = new WaitForSecondsRealtime(tempWait);
			yield return delay;
			orignalPosition = transform.localPosition; // Shake Conding

			while (elapsed < duration)
			{
				if (isX)
				{
					tempPos.x = UnityEngine.Random.Range(orignalPosition.x - speed, orignalPosition.x + speed);
				}
				else
				{
					tempPos.x = orignalPosition.x;
				}

				if (isY)
				{
					tempPos.y = UnityEngine.Random.Range(orignalPosition.y - speed, orignalPosition.y + speed);
				}
				else
				{
					tempPos.y = orignalPosition.y;
				}

				if (isZ)
				{
					tempPos.z = UnityEngine.Random.Range(orignalPosition.z - speed, orignalPosition.z + speed);
				}
				else
				{
					tempPos.z = orignalPosition.z;
				}

				transform.localPosition = tempPos;
				elapsed += Time.deltaTime;
				yield return null;
			}

			transform.localPosition = orignalPosition;

			this.gameObject.SetActive(false);

			GameObject go= Instantiate(breakBall, transform.position, Quaternion.identity);

			if (!GameController.instance.isSound)
				go.GetComponent<AudioSource>().mute = true;

			go1 = go.GetComponentsInChildren<Rigidbody>();

			tempPos.x = UnityEngine.Random.Range(-0.9f, 0.9f);
			tempPos.y = UnityEngine.Random.Range(6.5f, 9.5f);
			tempPos.z=UnityEngine.Random.Range(-2.5f, 0.9f);
			for (int i = 0; i < go1.Length; i++)
			{
				go1[i].velocity = tempPos;
			}
			Destroy(go, UnityEngine.Random.Range(2.0f, 3.0f));
		}
		private void OnDisable()
		{
			StopAllCoroutines();
		}
		private void OnDestroy()
		{
			Destroy(GetComponent<BallControl>());
		}
	}
}