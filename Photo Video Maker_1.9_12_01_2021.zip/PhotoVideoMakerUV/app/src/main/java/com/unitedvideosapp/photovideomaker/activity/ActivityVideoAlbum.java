package com.unitedvideosapp.photovideomaker.activity;

import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Video.Media;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideosapp.photovideomaker.MyApplication;
import com.unitedvideosapp.photovideomaker.adapters.AllVideoAlbumAdapter;
import com.unitedvideosapp.photovideomaker.modelclass.VideoData;
import com.unitedvideosapp.photovideomaker.util.ActivityAnimUtil;
import com.unitedvideosapp.photovideomaker.util.PermissionModelUtil;
import com.unitedvideosapp.photovideomaker.util.Utils;
import com.unitedvideosapp.photovideomaker.video.FileUtils;
import com.unitedvideosapp.photovideomaker.view.EmptyRecyclerView;
import com.unitedvideosapp.photovideomaker.view.SpacesItemDecoration;
import com.uvvideos.photo.video.slideshow.maker.R;
import java.io.File;
import java.util.ArrayList;
import static com.unitedvideosapp.photovideomaker.view.CustomNativeAd.populateUnifiedNativeAdView;


public class ActivityVideoAlbum extends AppCompatActivity {
    public static final String EXTRA_FROM_VIDEO = "EXTRA_FROM_VIDEO";
    private boolean isFromVideo = false;
    private AllVideoAlbumAdapter mAllVideoAlbumAdapter;
    private ArrayList<VideoData> mVideoDatas;
    PermissionModelUtil modelUtil;
    private EmptyRecyclerView rvVideoAlbum;
    private Toolbar toolbar;

    protected void onCreate(@Nullable Bundle bundle) {
        try {
            sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.fromFile(FileUtils.APP_DIRECTORY)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onCreate(bundle);
        this.isFromVideo = getIntent().hasExtra(EXTRA_FROM_VIDEO);
        setContentView(R.layout.activity_mycreation);
        setActionBar();
        bindView();
        init();
        loadAd();
        PutAnalyticsEvent();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityVideoAlbum");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private UnifiedNativeAd nativeAd;

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admobNativeAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    protected void onResume() {
        super.onResume();
        if (this.mAllVideoAlbumAdapter != null) {
            this.mAllVideoAlbumAdapter.notifyDataSetChanged();
        }
    }

    private void bindView() {
        this.toolbar = findViewById(R.id.toolbar);
        this.rvVideoAlbum = findViewById(R.id.rvVideoAlbum);
    }

    private void init() {
        getVideoList();
        this.modelUtil = new PermissionModelUtil(this);
        if (this.modelUtil.needPermissionCheck()) {
            this.modelUtil.showPermissionExplanationThenAuthorization();
        } else {
            MyApplication.getInstance().getFolderList();
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(1001);
        LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 1);
        this.mAllVideoAlbumAdapter = new AllVideoAlbumAdapter(this, this.mVideoDatas);
        this.rvVideoAlbum.setLayoutManager(gridLayoutManager);
        this.rvVideoAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvVideoAlbum.addItemDecoration(new SpacesItemDecoration(getResources().getDimensionPixelSize(R.dimen.spacing)));
        this.rvVideoAlbum.setEmptyView(findViewById(R.id.list_empty));
        this.rvVideoAlbum.setAdapter(this.mAllVideoAlbumAdapter);
        findViewById(R.id.btnCreateVideo).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    ActivityAnimUtil.startActivitySafely(view, new Intent(ActivityVideoAlbum.this, PhotoselectActivity.class));
                    ActivityVideoAlbum.this.finish();
                    return;
                }
                Toast.makeText(ActivityVideoAlbum.this.getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.list_empty).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    ActivityAnimUtil.startActivitySafely(view, new Intent(ActivityVideoAlbum.this, PhotoselectActivity.class));
                    ActivityVideoAlbum.this.finish();
                    return;
                }
                Toast.makeText(ActivityVideoAlbum.this.getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textView = toolbar.findViewById(R.id.toolbar_title);
        textView.setText(getString(R.string.my_creation));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Utils.setFont(this, textView);
    }

    private void getVideoList() {
        this.mVideoDatas = new ArrayList();
        String[] strArr = new String[]{"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_data like '%");
        stringBuilder.append(FileUtils.APP_DIRECTORY.getAbsolutePath());
        stringBuilder.append("%'");
        Cursor query = contentResolver.query(uri, strArr, stringBuilder.toString(), null, "datetaken DESC");
        if (query.moveToFirst()) {
            int columnIndex = query.getColumnIndex("duration");
            int columnIndex2 = query.getColumnIndex("_data");
            int columnIndex3 = query.getColumnIndex("title");
            int columnIndex4 = query.getColumnIndex("datetaken");
            do {
                VideoData videoData = new VideoData();
                videoData.videoDuration = query.getLong(columnIndex);
                videoData.videoFullPath = query.getString(columnIndex2);
                videoData.videoName = query.getString(columnIndex3);
                videoData.dateTaken = query.getLong(columnIndex4);
                if (new File(videoData.videoFullPath).exists()) {
                    this.mVideoDatas.add(videoData);
                }
            } while (query.moveToNext());
        }
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        MyApplication.getInstance().setFrame(0);
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        ActivityAnimUtil.startActivitySafely(this.toolbar, intent);
        finish();
        return;
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }
}
