package com.kotlinz.festivalstorymaker.Listener;

import android.view.View;

import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;

public class DefaultListener implements View.OnClickListener
{
    public DefaultListener(final SelectLogoAdapter e) {
    }

    public void onClick(final View view) {
    }
}
