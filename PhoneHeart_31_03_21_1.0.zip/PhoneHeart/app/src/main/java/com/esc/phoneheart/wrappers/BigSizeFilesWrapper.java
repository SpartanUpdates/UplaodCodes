package com.esc.phoneheart.wrappers;

import android.os.Parcel;
import android.os.Parcelable;
import org.apache.commons.io.FilenameUtils;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import androidx.core.app.NotificationCompat;

public class BigSizeFilesWrapper implements Parcelable {
    public static final Creator<BigSizeFilesWrapper> CREATOR = new Creator<BigSizeFilesWrapper>() {
        public BigSizeFilesWrapper createFromParcel(Parcel parcel) {
            return new BigSizeFilesWrapper(parcel);
        }

        public BigSizeFilesWrapper[] newArray(int i) {
            return new BigSizeFilesWrapper[i];
        }
    };
    public List arrExtensionAudio;
    public List arrExtensionImage;
    public List arrExtensionVideo;
    public long dateTaken;
    public String ext;
    public File file;
    public String hash;
    public int id;
    public boolean ischecked;
    public Date lastModDate;
    public long lastModified;
    public boolean lockImg;
    public String name;
    public int orientation;
    public String path;
    public long size;
    public String sizegroup;
    public List textFileExtensions;
    public long totalSize;
    public String type;

    public BigSizeFilesWrapper() {
        this.arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
        this.arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
        this.arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
        this.textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});
    }

    private String getType() {
        if (this.arrExtensionImage.contains(this.ext)) {
            return "Photos";
        }
        if (this.arrExtensionVideo.contains(this.ext)) {
            return "Videos";
        }
        if (this.arrExtensionAudio.contains(this.ext)) {
            return "Audio";
        }
        return this.textFileExtensions.contains(this.ext) ? "Documents" : null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.lastModified);
        parcel.writeInt(this.id);
        parcel.writeString(this.name);
        parcel.writeString(this.path);
        parcel.writeInt(this.orientation);
        parcel.writeLong(this.size);
        parcel.writeString(this.type);
        parcel.writeString(this.sizegroup);
        parcel.writeByte(this.ischecked ? (byte) 1 : 0);
        parcel.writeString(this.ext);
        parcel.writeLong(this.totalSize);
    }

    public BigSizeFilesWrapper(File file) {
        this.arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
        this.arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
        this.arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
        this.textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});
        this.file = file;
        this.name = file.getName();
        this.path = file.getAbsolutePath();
        this.size = file.length();
        this.ischecked = false;
        this.lastModified = file.lastModified();
        this.lastModDate = new Date(file.lastModified());
    }

    public BigSizeFilesWrapper(String str, String str2, boolean z) {
        String str3 = str;
        this.arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
        this.arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
        this.arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
        this.textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});
        File file = new File(str3);
        this.file = file;
        this.name = file.getName();
        this.hash = str2;
        this.path = str3;
        this.size = file.length();
        this.ischecked = z;
        this.lastModified = file.lastModified();
        this.lastModDate = new Date(file.lastModified());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(FilenameUtils.getExtension(str));
        this.ext = stringBuilder.toString();
        this.type = getType();
    }

    public BigSizeFilesWrapper(Parcel parcel) {
        this.arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
        this.arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
        this.arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
        this.textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});
        this.lastModified = parcel.readLong();
        this.id = parcel.readInt();
        this.name = parcel.readString();
        this.path = parcel.readString();
        this.orientation = parcel.readInt();
        this.size = parcel.readLong();
        this.type = parcel.readString();
        this.sizegroup = parcel.readString();
        this.ischecked = parcel.readByte() != (byte) 0;
        this.ext = parcel.readString();
        this.totalSize = parcel.readLong();
    }
}
