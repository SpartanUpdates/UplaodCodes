package com.esc.flashlight.util;

public class PackageData implements Comparable<PackageData> {
    public boolean externalStorage;
    public String label;
    public String packageName;
    public boolean thirdParty;

    public PackageData(String str, String str2, boolean z, boolean z2) {
        this.packageName = str;
        this.label = str2;
        this.thirdParty = z;
        this.externalStorage = z2;
    }

    public int compareTo(PackageData packageData) {
        return compare(this.label, packageData.label);
    }

    public static int compare(String str, String str2) {
        int length = str.length();
        int length2 = str2.length();
        int i = length < length2 ? length : length2;
        for (int i2 = 0; i2 < i; i2++) {
            char charAt = str.charAt(i2);
            char charAt2 = str2.charAt(i2);
            if (charAt < charAt2) {
                return -1;
            }
            if (charAt > charAt2) {
                return 1;
            }
        }
        if (length < length2) {
            return -1;
        }
        return length2 < length ? 1 : 0;
    }
}
