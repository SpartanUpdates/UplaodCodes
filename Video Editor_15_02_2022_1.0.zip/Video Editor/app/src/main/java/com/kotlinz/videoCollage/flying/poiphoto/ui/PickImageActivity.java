package com.kotlinz.videoCollage.flying.poiphoto.ui;

import android.os.Build.VERSION;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.kotlinz.videoCollage.flying.poiphoto.Configure;
import com.kotlinz.videoCollage.flying.poiphoto.Define;
import com.kotlinz.videoeditor.R;


public class PickImageActivity extends AppCompatActivity {
    private Configure mConfigure;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.poiphoto_activity);
        this.mConfigure = (Configure) getIntent().getParcelableExtra(Define.CONFIGURE);
        if (VERSION.SDK_INT > 21) {
            changeStatusBar(this.mConfigure.getStatusBarColor());
        }
        bundle = new Bundle();
        bundle.putString("from", "PickImageActivity");
        AlbumFragment albumFragment = new AlbumFragment();
        albumFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, albumFragment).commit();
    }

    private void changeStatusBar(int i) {
        getWindow().setStatusBarColor(i);
    }

    public void setConfigure(Configure configure) {
        this.mConfigure = configure;
    }

    public Configure getConfigure() {
        return this.mConfigure;
    }
}
