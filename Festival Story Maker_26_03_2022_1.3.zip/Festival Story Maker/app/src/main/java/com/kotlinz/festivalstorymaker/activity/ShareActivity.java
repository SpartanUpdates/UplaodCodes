package com.kotlinz.festivalstorymaker.activity;

import static com.kotlinz.festivalstorymaker.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.R;

import java.io.File;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ShareActivity extends AppCompatActivity {

    Activity activity = ShareActivity.this;

    @BindView(R.id.iv_back)
    ImageView ivBack;

    @BindView(R.id.iv_Preview)
    ImageView ivPreview;


    @BindView(R.id.img_Share_More)
    ImageView ivShareMore;

    @BindView(R.id.cv_share)
    CardView cvShare;

    private NativeAd nativeAd;

    public String IsFrom;
    public String ImagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        ButterKnife.bind(this);
        IsFrom = getIntent().getStringExtra("IsFrom");
        ImagePath = getIntent().getStringExtra("ImagePath");
        MyApplication.IsFromMyCreationShare = IsFrom;
        Glide.with(activity).load(ImagePath).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                cvShare.setVisibility(View.VISIBLE);
                return false;
            }
        }).fitCenter().into(ivPreview);
        PutAnalyticsEvent();
        loadAd();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ShareActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(activity, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ShareActivity.this.nativeAd != null) {
                            ShareActivity.this.nativeAd.destroy();
                        }
                        ShareActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    @OnClick(R.id.img_whatsapp)
    public void ShareToWhatsApp() {
        try {
            ShareToApp("com.whatsapp", "WhatsApp");
            return;
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp doesn't installed", Toast.LENGTH_SHORT).show();
            return;
        }
    }


    @OnClick(R.id.img_facebook)
    public void ShareToFB() {
        try {
            ShareToApp("com.facebook.katana", "Facebook");
            return;
        } catch (Exception e) {
            Toast.makeText(this, "Facebook doesn't installed", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    @OnClick(R.id.img_instagram)
    public void ShareToInsta() {
        try {
            ShareToApp("com.instagram.android", "Instagram");
            return;
        } catch (Exception e) {
            Toast.makeText(this, "Instagram doesn't installed", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    @OnClick(R.id.img_Share_More)
    public void ShareMore() {
        Intent sharingIntent;
        if (Build.VERSION.SDK_INT < 23) {
            Parcelable fromFile;
            if (Build.VERSION.SDK_INT <= 19) {
                fromFile = Uri.fromFile(new File(ImagePath));
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getPackageName());
                stringBuilder.append(".provider");
                fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(ImagePath));
            }
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("image/*");
            intent.putExtra("android.intent.extra.TEXT", getApplicationContext().getString(R.string.app_name) + " Create By : " + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName());

            intent.putExtra("android.intent.extra.STREAM", fromFile);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_template)));
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            Parcelable fromFile;
            if (Build.VERSION.SDK_INT <= 19) {
                fromFile = Uri.fromFile(new File(ImagePath));
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getPackageName());
                stringBuilder.append(".provider");
                fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(ImagePath));
            }
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("image/*");
            intent.putExtra("android.intent.extra.TEXT",
                    getApplicationContext().getString(R.string.app_name) + " Create By : " + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName());

            intent.putExtra("android.intent.extra.STREAM", fromFile);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_template)));
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1);
        }
    }

    private void ShareToApp(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(ImagePath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(ImagePath));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_template)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    @OnClick(R.id.iv_back)
    public void GoBack() {
        if (MyApplication.isShowAd == 1) {
            onBackPressed();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 28;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                onBackPressed();
            }
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom", IsFrom));
        finish();
    }
}