package com.esc.phoneheart.animations;

public enum UnitPosition {
    TOP,
    BOTTOM,
    LEFT_TOP,
    RIGHT_TOP,
    LEFT_BOTTOM,
    RIGHT_BOTTOM
}
