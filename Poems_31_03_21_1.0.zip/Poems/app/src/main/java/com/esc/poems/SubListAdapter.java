package com.esc.poems;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class SubListAdapter extends BaseAdapter {
    private ViewHolder holder;
    private LayoutInflater inflater = null;
    private ArrayList<String> stext;
    private ArrayList<String> stext2;

    class ViewHolder {
        public TextView text;
        public TextView text2;

        ViewHolder() {
        }
    }

    public long getItemId(int i) {
        return i;
    }

    public SubListAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        this.stext = arrayList;
        this.stext2 = arrayList2;
        this.inflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return this.stext.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.subcat, null);
            ViewHolder viewHolder = new ViewHolder();
            this.holder = viewHolder;
            viewHolder.text = view.findViewById(R.id.stxt1);
            this.holder.text2 = view.findViewById(R.id.stxt2);
            view.setTag(this.holder);
        } else {
            this.holder = (ViewHolder) view.getTag();
        }
        this.holder.text.setText(this.stext.get(i));
        this.holder.text2.setText(this.stext2.get(i));
        return view;
    }
}
