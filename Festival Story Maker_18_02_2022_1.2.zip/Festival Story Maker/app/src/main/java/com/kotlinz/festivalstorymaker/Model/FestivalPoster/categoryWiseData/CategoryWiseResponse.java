package com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.SerializedName;

public class CategoryWiseResponse {

	@SerializedName("data")
	private ArrayList<CategoryWiseData> data;

	@SerializedName("total_records")
	private int totalRecords;

	@SerializedName("status")
	private String status;

	public void setData(ArrayList<CategoryWiseData> data){
		this.data = data;
	}

	public ArrayList<CategoryWiseData> getData(){
		return data;
	}

	public void setTotalRecords(int totalRecords){
		this.totalRecords = totalRecords;
	}

	public int getTotalRecords(){
		return totalRecords;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}
}