package com.esc.storymaker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;

import com.esc.storymaker.NativeAds.NativeAdvanceAds;
import com.esc.storymaker.adapters.SliderAdpater;
import com.esc.storymaker.adapters.VpMainAdapter;
import com.esc.storymaker.fragments.MyDraftsFrag;
import com.esc.storymaker.fragments.MyStoriesFrag;
import com.esc.storymaker.fragments.TemplatesDetailFrag;
import com.esc.storymaker.fragments.TemplatesFrag;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.mediapicker.models.TabItem;
import com.esc.storymaker.models.SliderModel;
import com.esc.storymaker.preference.EPreferences;
import com.esc.storymaker.utils.AnimationsUtil;
import com.esc.storymaker.utils.AppUtil;
import com.esc.storymaker.utils.ContractsUtil;
import com.flyco.tablayout.CommonTabLayout;
import com.flyco.tablayout.listener.CustomTabEntity;
import com.flyco.tablayout.listener.OnTabSelectListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String mypreference = "myprefadmob";
    String A;
    String B;
    String C;
    private ImageView ImageOverlayadview;
    AppCompatActivity activity;
    ConnectionDetector connectionDetector;
    CommonTabLayout ctlMain;
    int displayad;
    private FragmentManager fm;
    boolean isActivityLeft;
    private ArrayList<Fragment> mFragments = new ArrayList();
    private ArrayList<CustomTabEntity> mTabItems = new ArrayList();
    private ArrayList<Integer> mainTabSelectedIcons = new ArrayList();
    private String[] mainTabTitles;
    private SharedPreferences prefs;
    ImageView sb_back;
    LinearLayout sb_feedback;
    LinearLayout sb_more;
    LinearLayout sb_privacy;
    LinearLayout sb_rate_us;
    LinearLayout sb_share;
    SharedPreferences sharedpreferences;
    private Editor spEditor;
    ViewPager vpMain;
    ImageView tb_sidebar;
    private VpMainAdapter vpMainAdapter;
    int whichActivitytoStart = 0;
    int whichAdFirst;

    EPreferences ePreferences;
    private UnifiedNativeAd nativeAd;

    SliderView sliderHome;
    ArrayList<SliderModel> sliderList = new ArrayList<>();
    SliderAdpater sliderAdpater;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.sharedpreferences = getSharedPreferences("myprefadmob", 0);
        this.ePreferences = EPreferences.getInstance(this);
        this.isActivityLeft = false;
        this.activity = this;
        this.connectionDetector = new ConnectionDetector(getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.ImageOverlayadview = findViewById(R.id.Image_overlayadview);
        BannerAds();
        if (isConnectingToInternet) {

        } else {
            findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        this.fm = getSupportFragmentManager();
        AnimationsUtil.initAnimationsValue(this);
        this.prefs = getSharedPreferences("prefs", 0);
        this.spEditor = this.prefs.edit();
        this.sliderHome = findViewById(R.id.slider_home);
        this.tb_sidebar = findViewById(R.id.tb_sidebar);
        this.ctlMain = findViewById(R.id.ctl_main);
        this.vpMain = findViewById(R.id.vp_main);
        this.sb_back = findViewById(R.id.sb_back);
        this.sb_feedback = findViewById(R.id.sb_feedback);
        this.sb_rate_us = findViewById(R.id.sb_rate_us);
        this.sb_share = findViewById(R.id.sb_share);
        this.sb_privacy = findViewById(R.id.sb_privacy);
        this.sb_more = findViewById(R.id.sb_more);
        SetSliderAdapter();
        this.tb_sidebar.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.tbSidebar();
            }
        });
        this.sb_back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbBack();
            }
        });
        this.sb_feedback.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbFeedback();
            }
        });
        this.sb_rate_us.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbRate();
            }
        });
        this.sb_share.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbShare();
            }
        });
        this.sb_privacy.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbPrivacy();
            }
        });
        this.sb_more.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.sbMoreApps();
            }
        });
        setTabBar();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetSliderAdapter() {
        sliderList.add(0, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/1598020791SunMeriSehzadi.png"));
        sliderList.add(1, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/15969710234925a22b52f81d5cdab6505cce3c12a3fc2.png"));
        sliderList.add(2, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/1598020943YeMosamKiBaris.png"));
        sliderList.add(3, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/1598020892YeHasiWadiyaYehKhulaAasmaan.png"));
        sliderList.add(4, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/1596971183c5bbdf83249e97db3890bf51bfcf748d.png"));
        sliderList.add(5, new SliderModel("https://beatsadmin.s3.ap-south-1.amazonaws.com/thumb/1598020560DilMeraBlast.png"));
        sliderAdpater = new SliderAdpater(activity, sliderList);
        sliderHome.setSliderAdapter(sliderAdpater);
        sliderHome.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderHome.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderHome.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderHome.setIndicatorSelectedColor(getResources().getColor(R.color.white));
        sliderHome.setIndicatorUnselectedColor(getResources().getColor(R.color.slide_unselected));
        sliderHome.setScrollTimeInSec(3);
        sliderHome.setAutoCycle(true);
        sliderHome.startAutoCycle();
    }

    private void setTabBar() {
        this.mFragments = new ArrayList();
        this.mFragments.add(TemplatesFrag.getInstance(this));
        this.mFragments.add(MyStoriesFrag.getInstance());
        this.mFragments.add(MyDraftsFrag.getInstance(this));
        this.mainTabSelectedIcons = new ArrayList();
        this.mainTabSelectedIcons.addAll(ContractsUtil.mainTabIcons.keySet());
        this.mainTabTitles = new String[0];
        this.mainTabTitles = getResources().getStringArray(R.array.main_tab_titles);
        this.mTabItems = new ArrayList();
        int i = 0;
        while (true) {
            String[] strArr = this.mainTabTitles;
            if (i < strArr.length) {
                this.mTabItems.add(new TabItem(strArr[i], this.mainTabSelectedIcons.get(i).intValue(), ContractsUtil.mainTabIcons.get(this.mainTabSelectedIcons.get(i)).intValue()));
                i++;
            } else {
                this.ctlMain.setTabData(this.mTabItems);
                this.ctlMain.setOnTabSelectListener(new OnTabSelectListener() {
                    public void onTabReselect(int i) {
                    }

                    public void onTabSelect(int i) {
                        MainActivity.this.vpMain.setCurrentItem(i);
                    }
                });
                this.vpMainAdapter = new VpMainAdapter(getSupportFragmentManager(), this.mFragments);
                this.vpMain.setAdapter(this.vpMainAdapter);
                this.vpMain.addOnPageChangeListener(new OnPageChangeListener() {
                    public void onPageScrollStateChanged(int i) {
                    }

                    public void onPageScrolled(int i, float f, int i2) {
                    }

                    public void onPageSelected(int i) {
                        MainActivity.this.ctlMain.setCurrentTab(i);
                    }
                });
                this.vpMain.setCurrentItem(0);
                this.vpMain.setOffscreenPageLimit(3);
                return;
            }
        }
    }

    public void selectTempCategory(String str) {
        addFragment(TemplatesDetailFrag.getInstance(this, str), R.id.fl_templates_detail, R.anim.slide_in_top, R.anim.slide_in_top);
        findViewById(R.id.fl_templates_detail).setVisibility(View.VISIBLE);
    }

    public void selectTemplate(String str, String str2) {
        loading(true);
        Intent intent = new Intent(this, EditorActivity.class);
        intent.putExtra("category", str);
        intent.putExtra("template", str2);
        intent.putExtra("draft", false);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void selectDraft(String str, String str2, String str3) {
        loading(true);
        if (str.toLowerCase().contains("card")) {
            Toast.makeText(activity, "Sorry this new update does not support this template we will work to fix the issue soon, Thanks", Toast.LENGTH_SHORT).show();
            return;
        }
        if (AppUtil.permissionGranted(this, "android.permission.READ_EXTERNAL_STORAGE") && AppUtil.permissionGranted(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            Intent intent = new Intent(this, EditorActivity.class);
            intent.putExtra("category", str);
            intent.putExtra("template", str2);
            intent.putExtra("savePath", str3);
            intent.putExtra("draft", true);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    public void swipeVP(int i) {
        this.vpMain.setCurrentItem(i);
    }

    private void addFragment(Fragment fragment, int i, int i2, int i3) {
        this.fm.executePendingTransactions();
        FragmentTransaction beginTransaction = this.fm.beginTransaction();
        if (!(i2 == 0 && i3 == 0)) {
            beginTransaction.setCustomAnimations(i2, i3);
        }
        beginTransaction.replace(i, fragment);
        beginTransaction.commitAllowingStateLoss();
    }

    public void onPermissionGranted(String str, String str2, String str3) {
        if (str3 == null) {
            this.A = str;
            this.B = str2;
            this.whichActivitytoStart = 1;
            replaceScreen();
            return;
        }
        this.A = str;
        this.B = str2;
        this.C = str3;
        this.whichActivitytoStart = 2;
        replaceScreen();
    }

    public void loading(boolean z) {
        if (z) {
            findViewById(R.id.wg_loading).setVisibility(View.VISIBLE);
        } else {
            findViewById(R.id.wg_loading).setVisibility(View.GONE);
        }
    }

    public void tbSidebar() {
        findViewById(R.id.wg_sidebar).setVisibility(View.VISIBLE);
        findViewById(R.id.wg_sidebar).startAnimation(AnimationsUtil.SlideUpIn);
    }

    public void sbBack() {
        findViewById(R.id.wg_sidebar).setVisibility(View.GONE);
        findViewById(R.id.wg_sidebar).startAnimation(AnimationsUtil.SlideUpOut);
    }

    public void sbFeedback() {
        AppUtil.sendFeedback(this);
    }

    public void sbRate() {
        Intent intent = new Intent("android.intent.action.VIEW");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        intent.setData(Uri.parse(stringBuilder.toString()));
        startActivity(intent);
    }

    public void sbShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" Free Application https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        startActivity(Intent.createChooser(intent, getResources().getText(R.string.APD_SEND_TO)));
    }

    public void sbMoreApps() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getResources().getString(R.string.MoreApps))));
    }

    public void sbPrivacy() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getResources().getString(R.string.PrivacyPolicy))));
    }


    public void checkDisplayOverlayBannerG() {
        if (new Utils(this.activity).checkTimeB()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void checkDisplayOverlayBannerFB() {
        if (new Utils(this.activity).checkTimeBf()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }

    public void onPause() {
        super.onPause();
        this.isActivityLeft = true;
    }

    public void onResume() {
        super.onResume();
        loading(false);
        this.isActivityLeft = false;
    }


    public void onStop() {
        super.onStop();
        this.isActivityLeft = true;
    }


    public void onDestroy() {
        super.onDestroy();
        this.isActivityLeft = true;
    }

    private void replaceScreen() {
        int i = this.whichActivitytoStart;
        if (i == 1) {
            selectTemplate(this.A, this.B);
        } else if (i == 2) {
            selectDraft(this.A, this.B, this.C);
        }
    }

    public void onBackPressed() {
        if (findViewById(R.id.wg_sidebar).getVisibility() == View.VISIBLE) {
            findViewById(R.id.wg_sidebar).setVisibility(View.GONE);
            findViewById(R.id.wg_sidebar).startAnimation(AnimationsUtil.SlideUpOut);
            return;
        }
        if (ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(activity);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);

        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                NativeAdvanceAds.populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        dialog.findViewById(R.id.btnLater).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }
}
