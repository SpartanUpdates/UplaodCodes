package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.Collections;

public class TarolovespreadActivity extends AppCompatActivity implements AnimationListener, OnClickListener {
    Activity activity = TarolovespreadActivity.this;
    static final String[] cardnames = new String[]{"ACE OF CUPS", "TWO OF CUPS", "THREE OF CUPS", "FOUR OF CUPS", "FIVE OF CUPS", "SIX OF CUPS", "SEVEN OF CUPS", "EIGHT OF CUPS", "NINE OF CUPS", "TEN OF CUPS", "PAGE OF CUPS", "KNIGHT OF CUPS", "QUEEN OF CUPS", "KING OF CUPS", "ACE OF WANDS", "TWO OF WANDS", "THREE OF WANDS", "FOUR OF WANDS", "FIVE OF WANDS", "SIX OF WANDS", "SEVEN OF WANDS", "EIGHT OF WANDS", "NINE OF WANDS", "TEN OF WANDS", "PAGE OF WANDS", "KNIGHT OF WANDS", "QUEEN OF WANDS", "KING OF WANDS", "ACE OF SWORDS", "TWO OF SWORDS", "THREE OF SWORDS", "FOUR OF SWORDS", "FIVE OF SWORDS", "SIX OF SWORDS", "SEVEN OF SWORDS", "EIGHT OF SWORDS", "NINE OF SWORDS", "TEN OF SWORDS", "PAGE OF SWORDS", "KNIGHT OF SWORDS", "QUEEN OF SWORDS", "KING OF SWORDS", "ACE OF PENTACLES", "TWO OF PENTACLES", "THREE OF PENTACLES", "FOUR OF PENTACLES", "FIVE OF PENTACLES", "SIX OF PENTACLES", "SEVEN OF PENTACLES", "EIGHT OF PENTACLES", "NINE OF PENTACLES", "TEN OF PENTACLES", "PAGE OF PENTACLES", "KNIGHT OF PENTACLES", "QUEEN OF PENTACLES", "KING OF PENTACLES", "DEATH", "JUDGEMENT", "JUSTICE", "STRENGTH", "TEMPERANCE", "THE CHARIOT", "THE DEVIL", "THE EMPEROR", "THE EMPRESS", "THE FOOL", "THE HANGED MAN", "THE HERMIT", "THE HIEROPHANT", "THE HIGH PRIESTESS", "THE LOVERS", "THE MAGICIAN", "THE MOON", "THE STAR", "THE SUN", "THE TOWER", "THE WORLD", "WHEEL OF FORTUNE"};
    static final String[] cardnames2 = new String[78];
    static int screenHeight;
    static int screenWidth;
    Animation animation;
    boolean animplaying = false;
    Button btn;
    final int[] cardint = new int[]{R.string.aceofcups, R.string.twoofcups, R.string.threeofcups, R.string.fourofcups, R.string.fiveofcups, R.string.sixofcups, R.string.sevenofcups, R.string.eightofcups, R.string.nineofcups, R.string.tenofcups, R.string.pageofcups, R.string.knightofcups, R.string.queenofcups, R.string.kingofcups, R.string.aceofwands, R.string.twoofwands, R.string.threeofwands, R.string.fourofwands, R.string.fiveofwands, R.string.sixofwands, R.string.sevenofwands, R.string.eightofwands, R.string.nineofwands, R.string.tenofwands, R.string.pageofwands, R.string.knightofwands, R.string.queenofwands, R.string.kingofwands, R.string.aceofswords, R.string.twoofswords, R.string.threeofswords, R.string.fourofswords, R.string.fiveofswords, R.string.sixofswords, R.string.sevenofswords, R.string.eightofswords, R.string.nineofswords, R.string.tenofswords, R.string.pageofswords, R.string.knightofswords, R.string.queenofswords, R.string.kingofswords, R.string.aceofpentacles, R.string.twoofpentacles, R.string.threeofpentacles, R.string.fourofpentacles, R.string.fiveofpentacles, R.string.sixofpentacles, R.string.sevenofpentacles, R.string.eightofpentacles, R.string.nineofpentacles, R.string.tenofpentacles, R.string.pageofpentacles, R.string.knightofpentacles, R.string.queenofpentacles, R.string.kingofpentacles, R.string.death, R.string.judgement, R.string.justice, R.string.strength, R.string.temperance, R.string.thechariot, R.string.thedevil, R.string.theemperor, R.string.theempress, R.string.thefool, R.string.thehangedman, R.string.thehermit, R.string.thehierophant, R.string.thehighpriestress, R.string.thelovers, R.string.themagician, R.string.themoon, R.string.thestar, R.string.thesun, R.string.thetower, R.string.theworld, R.string.wheeloffortune};
    int cardopencount = 0;
    int[] cardsimg = new int[]{R.drawable.aceofcups, R.drawable.twoofcups, R.drawable.threeofcups, R.drawable.fourofcups, R.drawable.fiveofcups, R.drawable.sixofcups, R.drawable.sevenofcups, R.drawable.eightofcups, R.drawable.nineofcups, R.drawable.tenofcups, R.drawable.pageofcups, R.drawable.knightofcups, R.drawable.queenofcups, R.drawable.kingofcups, R.drawable.aceofwands, R.drawable.twoofwands, R.drawable.threeofwands, R.drawable.fourofwands, R.drawable.fiveofwands, R.drawable.sixofwands, R.drawable.sevenofwands, R.drawable.eightofwands, R.drawable.nineofwands, R.drawable.tenofwands, R.drawable.pageofwands, R.drawable.knightofwands, R.drawable.queenofwands, R.drawable.kingofwands, R.drawable.aceofswords, R.drawable.twoofswords, R.drawable.threeofswords, R.drawable.fourofswords, R.drawable.fiveofswords, R.drawable.sixofswords, R.drawable.sevenofswords, R.drawable.eightofswords, R.drawable.nineofswords, R.drawable.tenofswords, R.drawable.pageofswords, R.drawable.knightofswords, R.drawable.queenofswords, R.drawable.kingofswords, R.drawable.aceofpentacles, R.drawable.twoofpentacles, R.drawable.threeofpentacles, R.drawable.fourofpentacles, R.drawable.fiveofpentacles, R.drawable.sixofpentacles, R.drawable.sevenofpentacles, R.drawable.eightofpentacles, R.drawable.nineofpentacles, R.drawable.tenofpentacles, R.drawable.pageofpentacles, R.drawable.knightofpentacles, R.drawable.queenofpentacles, R.drawable.kingofpentacles, R.drawable.death, R.drawable.judgement, R.drawable.justice, R.drawable.strength, R.drawable.temperance, R.drawable.thechariot, R.drawable.thedevil, R.drawable.theemperor, R.drawable.theempress, R.drawable.thefool, R.drawable.thehangedman, R.drawable.thehermit, R.drawable.thehierophant, R.drawable.thehighpriestess, R.drawable.thelovers, R.drawable.themagician, R.drawable.themoon, R.drawable.thestar, R.drawable.thesun, R.drawable.thetower, R.drawable.theworld, R.drawable.wheeloffortune};
    String[] cnames = new String[5];
    String[] cnames2 = new String[5];
    ImageView[] img;
    int imgno;
    private boolean isBackOfCardShowing = true;
    ArrayList<Integer> list = new ArrayList();
    RelativeLayout relate1;
    TextView txt1;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView txt5;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onAnimationRepeat(Animation animation) {
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_tarolovespread);
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
        generateRandomNumber();
        for (int i = 0; i < 78; i++) {
            cardnames2[i] = getResources().getString(this.cardint[i]);
        }
        this.txt1 = findViewById(R.id.textView1);
        this.txt2 = findViewById(R.id.textView2);
        this.txt3 = findViewById(R.id.textView3);
        this.txt4 = findViewById(R.id.textView4);
        this.txt5 = findViewById(R.id.textView5);
        this.relate1 = findViewById(R.id.relative1);
        ImageView[] imageViews = new ImageView[5];
        this.img = imageViews;
        imageViews[0] = findViewById(R.id.imageView1);
        this.img[1] = findViewById(R.id.imageView2);
        this.img[2] = findViewById(R.id.imageView3);
        this.img[3] = findViewById(R.id.imageView4);
        this.img[4] = findViewById(R.id.imageView5);
        Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.to_middle);
        this.animation = loadAnimation;
        loadAnimation.setAnimationListener(this);
        this.img[0].setTag(Integer.valueOf(0));
        this.img[0].setOnClickListener(this);
        this.img[1].setTag(Integer.valueOf(1));
        this.img[1].setOnClickListener(this);
        this.img[2].setTag(Integer.valueOf(2));
        this.img[2].setOnClickListener(this);
        this.img[3].setTag(Integer.valueOf(3));
        this.img[3].setOnClickListener(this);
        this.img[4].setTag(Integer.valueOf(4));
        this.img[4].setOnClickListener(this);
        Button button = findViewById(R.id.button1);
        this.btn = button;
        button.setVisibility(View.INVISIBLE);
        this.btn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(TarolovespreadActivity.this, TaroResultActivity.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("name", TarolovespreadActivity.this.cnames);
                bundle.putStringArray("name2", TarolovespreadActivity.this.cnames2);
                bundle.putString("ques", TarolovespreadActivity.this.getResources().getString(R.string.lovetitle));
                bundle.putString("type", "five");
                bundle.putString("ccc", "Find Love");
                intent.putExtras(bundle);
                TarolovespreadActivity.this.startActivity(intent);
            }
        });
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenWidth = displayMetrics.widthPixels;
        screenHeight = displayMetrics.heightPixels;
        LayoutParams layoutParams = this.img[0].getLayoutParams();
        double d = screenWidth;
        Double.isNaN(d);
        layoutParams.height = (int) (d * 0.25d);
        layoutParams = this.img[0].getLayoutParams();
        d = screenWidth;
        Double.isNaN(d);
        layoutParams.width = (int) (d * 0.25d);
        layoutParams = this.img[1].getLayoutParams();
        d = screenWidth;
        Double.isNaN(d);
        layoutParams.height = (int) (d * 0.25d);
        layoutParams = this.img[1].getLayoutParams();
        double d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.width = (int) (d2 * 0.25d);
        layoutParams = this.img[2].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.height = (int) (d2 * 0.25d);
        layoutParams = this.img[2].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.width = (int) (d2 * 0.25d);
        layoutParams = this.img[3].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.height = (int) (d2 * 0.25d);
        layoutParams = this.img[3].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.width = (int) (d2 * 0.25d);
        layoutParams = this.img[4].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.height = (int) (d2 * 0.25d);
        layoutParams = this.img[4].getLayoutParams();
        d2 = screenWidth;
        Double.isNaN(d2);
        layoutParams.width = (int) (d2 * 0.25d);
        LinearLayout.LayoutParams layoutParams2;
        int i2;
        double d3;
        int i3;
        double d4;
        LayoutParams layoutParams3;
        double d5;
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            this.txt1.setTextSize(30.0f);
            this.txt2.setTextSize(30.0f);
            this.txt3.setTextSize(30.0f);
            this.txt4.setTextSize(30.0f);
            this.txt5.setTextSize(30.0f);
            this.btn.setTextSize(30.0f);
            layoutParams2 = (LinearLayout.LayoutParams) this.relate1.getLayoutParams();
            i2 = screenHeight;
            d3 = i2;
            Double.isNaN(d3);
            i3 = (int) (d3 * 0.01d);
            d4 = i2;
            Double.isNaN(d4);
            layoutParams2.setMargins(0, i3, 0, (int) (d4 * 0.01d));
            this.relate1.setLayoutParams(layoutParams2);
            layoutParams3 = this.btn.getLayoutParams();
            d5 = screenWidth;
            Double.isNaN(d5);
            layoutParams3.width = (int) (d5 * 0.4d);
            layoutParams3 = this.btn.getLayoutParams();
            d5 = screenWidth;
            Double.isNaN(d5);
            layoutParams3.height = (int) (d5 * 0.08d);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            this.txt1.setTextSize(25.0f);
            this.txt2.setTextSize(25.0f);
            this.txt3.setTextSize(25.0f);
            this.txt4.setTextSize(25.0f);
            this.txt5.setTextSize(25.0f);
            this.btn.setTextSize(25.0f);
            layoutParams2 = (LinearLayout.LayoutParams) this.relate1.getLayoutParams();
            i2 = screenHeight;
            d3 = i2;
            Double.isNaN(d3);
            i3 = (int) (d3 * 0.02d);
            d4 = i2;
            Double.isNaN(d4);
            layoutParams2.setMargins(0, i3, 0, (int) (d4 * 0.02d));
            this.relate1.setLayoutParams(layoutParams2);
            layoutParams3 = this.btn.getLayoutParams();
            d5 = screenWidth;
            Double.isNaN(d5);
            layoutParams3.width = (int) (d5 * 0.4d);
            layoutParams3 = this.btn.getLayoutParams();
            d5 = screenWidth;
            Double.isNaN(d5);
            layoutParams3.height = (int) (d5 * 0.08d);
        } else {
            this.txt1.setTextSize(15.0f);
            this.txt2.setTextSize(15.0f);
            this.txt3.setTextSize(15.0f);
            this.txt4.setTextSize(15.0f);
            this.txt5.setTextSize(15.0f);
            this.btn.setTextSize(15.0f);
            layoutParams2 = (LinearLayout.LayoutParams) this.relate1.getLayoutParams();
            int i4 = screenHeight;
            double d6 = i4;
            Double.isNaN(d6);
            int i5 = (int) (d6 * 0.02d);
            d5 = i4;
            Double.isNaN(d5);
            layoutParams2.setMargins(0, i5, 0, (int) (d5 * 0.02d));
            this.relate1.setLayoutParams(layoutParams2);
            layoutParams3 = this.btn.getLayoutParams();
            double d7 = screenWidth;
            Double.isNaN(d7);
            layoutParams3.width = (int) (d7 * 0.4d);
            layoutParams3 = this.btn.getLayoutParams();
            d7 = screenWidth;
            Double.isNaN(d7);
            layoutParams3.height = (int) (d7 * 0.1d);
        }
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClick(View view) {
        if (!this.animplaying) {
            view.setEnabled(false);
            view.setClickable(false);
            int intValue = ((Integer) view.getTag()).intValue();
            this.img[intValue].clearAnimation();
            this.img[intValue].setAnimation(this.animation);
            this.img[intValue].startAnimation(this.animation);
            this.imgno = intValue;
        }
    }

    public void onAnimationEnd(Animation animation) {
        if (animation != this.animation) {
            this.isBackOfCardShowing = true;
        } else if (this.isBackOfCardShowing) {
            ImageView[] imageViewArr = this.img;
            int i = this.imgno;
            imageViewArr[i].setImageResource(this.cardsimg[this.list.get(i).intValue() - 1]);
            String[] strArr = this.cnames;
            i = this.imgno;
            strArr[i] = cardnames[this.list.get(i).intValue() - 1];
            strArr = this.cnames2;
            i = this.imgno;
            strArr[i] = cardnames2[this.list.get(i).intValue() - 1];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.imgno);
            stringBuilder.append(" = ");
            stringBuilder.append(this.cnames[this.imgno]);
            Log.e("CNAME", stringBuilder.toString());
            this.cardopencount++;
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(this.cardopencount);
            Log.e("cardcn", stringBuilder.toString());
            if (this.cardopencount == 5) {
                this.btn.setVisibility(View.VISIBLE);
            }
            this.animplaying = false;
        }
    }

    public void onAnimationStart(Animation animation) {
        this.animplaying = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.popular_tarot, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    private void generateRandomNumber() {
        int i = 0;
        while (i < 78) {
            i++;
            this.list.add(new Integer(i));
        }
        Collections.shuffle(this.list);
        for (int i2 = 0; i2 < 10; i2++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(this.list.get(i2));
            Log.e("RAN", stringBuilder.toString());
        }
    }

    /* Access modifiers changed, original: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
