package com.UnitedVideos.CropImage.photoview;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.View.OnLongClickListener;
import android.widget.ImageView.ScaleType;

public abstract interface IPhotoView {
    public static final float DEFAULT_MAX_SCALE = 3.0F;
    public static final float DEFAULT_MID_SCALE = 1.75F;
    public static final float DEFAULT_MIN_SCALE = 1.0F;
    public static final int DEFAULT_ZOOM_DURATION = 200;
    public static final int DEFAULT_ROTATE_DURATION = 250;

    public abstract boolean canZoom();

    public abstract RectF getDisplayRect();

    public abstract boolean setDisplayMatrix(Matrix paramMatrix);

    public abstract Matrix getDisplayMatrix();

    @Deprecated
    public abstract float getMinScale();

    public abstract float getMinimumScale();

    @Deprecated
    public abstract float getMidScale();

    public abstract float getMediumScale();

    @Deprecated
    public abstract float getMaxScale();

    public abstract float getMaximumScale();

    public abstract float getScale();

    public abstract ScaleType getScaleType();

    public abstract void setAllowParentInterceptOnEdge(boolean paramBoolean);

    @Deprecated
    public abstract void setMinScale(float paramFloat);

    public abstract void setMinimumScale(float paramFloat);

    public abstract float setMinimumScaleToFit(Drawable paramDrawable);

    @Deprecated
    public abstract void setMidScale(float paramFloat);

    public abstract void setMediumScale(float paramFloat);

    @Deprecated
    public abstract void setMaxScale(float paramFloat);

    public abstract void setMaximumScale(float paramFloat);

    public abstract void setOnLongClickListener(OnLongClickListener paramOnLongClickListener);

    public abstract void setOnMatrixChangeListener(PhotoViewAttacher.OnMatrixChangedListener paramOnMatrixChangedListener);

    public abstract void setOnPhotoTapListener(PhotoViewAttacher.OnPhotoTapListener paramOnPhotoTapListener);

    public abstract PhotoViewAttacher.OnPhotoTapListener getOnPhotoTapListener();

    public abstract void setOnViewTapListener(PhotoViewAttacher.OnViewTapListener paramOnViewTapListener);

    public abstract void setRotationTo(float paramFloat);

    public abstract void setRotationBy(float paramFloat);

    public abstract void setRotationBy(float paramFloat, boolean paramBoolean);

    public abstract PhotoViewAttacher.OnViewTapListener getOnViewTapListener();

    public abstract void setScale(float paramFloat);

    public abstract void setScale(float paramFloat, boolean paramBoolean);

    public abstract void setScale(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean);

    public abstract void setScaleType(ScaleType paramScaleType);

    public abstract void setZoomable(boolean paramBoolean);

    /**
     * @deprecated
     */
    public abstract void setPhotoViewRotation(float paramFloat);

    public abstract Bitmap getVisibleRectangleBitmap();

    public abstract void setZoomTransitionDuration(int paramInt);

    public abstract IPhotoView getIPhotoViewImplementation();

    public abstract Bitmap getCroppedImage();

    public abstract void setOnDoubleTapListener(OnDoubleTapListener paramOnDoubleTapListener);

    public abstract void update();

    public abstract void reset();

    public abstract void setImageBoundsListener(IGetImageBounds paramIGetImageBounds);
}
