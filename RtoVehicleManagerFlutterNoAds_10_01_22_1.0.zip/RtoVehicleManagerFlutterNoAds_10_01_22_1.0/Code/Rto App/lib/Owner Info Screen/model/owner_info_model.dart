// To parse this JSON data, do
//
//     final ownerInfoModel = ownerInfoModelFromJson(jsonString);

import 'dart:convert';

OwnerInfoModel ownerInfoModelFromJson(String str) =>
    OwnerInfoModel.fromJson(json.decode(str));

String ownerInfoModelToJson(OwnerInfoModel data) => json.encode(data.toJson());

class OwnerInfoModel {
  OwnerInfoModel({
    required this.code,
    required this.status,
    required this.response,
  });

  int code;
  String status;
  Response response;

  factory OwnerInfoModel.fromJson(Map<String, dynamic> json) => OwnerInfoModel(
        code: json["code"],
        status: json["status"],
        response: Response.fromJson(json["response"]),
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "status": status,
        "response": response.toJson(),
      };
}

class Response {
  Response({
    required this.isValid,
    required this.licensePlate,
    required this.ownerName,
    required this.financer,
    required this.insuranceCompany,
    required this.insurancePolicy,
    required this.model,
    required this.responseClass,
    required this.registrationDate,
    required this.vehicleAge,
    required this.insuranceExpiry,
    required this.pollutionExpiry,
    required this.chassisNumber,
    required this.engineNumber,
    required this.fuelType,
    required this.brandName,
    required this.brandModel,
    required this.seatingCapacity,
    required this.cubicCapacity,
    required this.fitnessUpto,
    required this.wheelCount,
    required this.rtoCode,
    required this.rto,
    required this.state,
  });

  String isValid;
  String licensePlate;
  String ownerName;
  String financer;
  String insuranceCompany;
  String insurancePolicy;
  String model;
  String responseClass;
  DateTime registrationDate;
  String vehicleAge;
  String insuranceExpiry;
  String pollutionExpiry;
  String chassisNumber;
  String engineNumber;
  String fuelType;
  String brandName;
  String brandModel;
  String seatingCapacity;
  String cubicCapacity;
  String fitnessUpto;
  String wheelCount;
  String rtoCode;
  String rto;
  String state;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
        isValid: json["isValid"],
        licensePlate: json["license_plate"],
        ownerName: json["owner_name"],
        financer: json["financer"],
        insuranceCompany: json["insurance_company"],
        insurancePolicy: json["insurance_policy"],
        model: json["model"],
        responseClass: json["class"],
        registrationDate: DateTime.parse(json["registration_date"]),
        vehicleAge: json["vehicle_age"],
        insuranceExpiry: json["insurance_expiry"],
        pollutionExpiry: json["pollution_expiry"],
        chassisNumber: json["chassis_number"],
        engineNumber: json["engine_number"],
        fuelType: json["fuel_type"],
        brandName: json["brand_name"],
        brandModel: json["brand_model"],
        seatingCapacity: json["seating_capacity"],
        cubicCapacity: json["cubic_capacity"],
        fitnessUpto: json["fitness_upto"],
        wheelCount: json["wheel_count"],
        rtoCode: json["rto_code"],
        rto: json["rto"],
        state: json["state"],
      );

  Map<String, dynamic> toJson() => {
        "isValid": isValid,
        "license_plate": licensePlate,
        "owner_name": ownerName,
        "financer": financer,
        "insurance_company": insuranceCompany,
        "insurance_policy": insurancePolicy,
        "model": model,
        "class": responseClass,
        "registration_date":
            "${registrationDate.year.toString().padLeft(4, '0')}-${registrationDate.month.toString().padLeft(2, '0')}-${registrationDate.day.toString().padLeft(2, '0')}",
        "vehicle_age": vehicleAge,
        "insurance_expiry": insuranceExpiry,
        "pollution_expiry": pollutionExpiry,
        "chassis_number": chassisNumber,
        "engine_number": engineNumber,
        "fuel_type": fuelType,
        "brand_name": brandName,
        "brand_model": brandModel,
        "seating_capacity": seatingCapacity,
        "cubic_capacity": cubicCapacity,
        "fitness_upto": fitnessUpto,
        "wheel_count": wheelCount,
        "rto_code": rtoCode,
        "rto": rto,
        "state": state,
      };
}
