package com.esc.socialmediacleaner.adapter;

import android.content.Context;
import android.view.View;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.datastructure.MediaType;
import com.esc.socialmediacleaner.datastructure.PathType;
import com.esc.socialmediacleaner.datastructure.SocialAppType;
import com.esc.socialmediacleaner.fragment.DocFragment;
import com.esc.socialmediacleaner.fragment.ImageFragment;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;

public class CategoryPagerAdapter extends FragmentPagerAdapter {
    private final AppCompatCheckBox cheSlectAll;
    private final ArrayList<FileDataWrapper> listdata;
    private final Context mContext;
    private ArrayList<PathType> tabCategoryList = new ArrayList();

    public CategoryPagerAdapter(Context context, FragmentManager fragmentManager, ArrayList<FileDataWrapper> arrayList, AppCompatCheckBox appCompatCheckBox, TabLayout tabLayout) {
        super(fragmentManager);
        this.mContext = context;
        this.listdata = arrayList;
        this.cheSlectAll = appCompatCheckBox;
        for (int i = 0; i < arrayList.size(); i++) {
            if (!this.tabCategoryList.contains(((FileDataWrapper) arrayList.get(i)).pathType)) {
                this.tabCategoryList.add(((FileDataWrapper) arrayList.get(i)).pathType);
            }
        }
        if (((FileDataWrapper) arrayList.get(0)).socialAppType != SocialAppType.WHATSAPP) {
            tabLayout.setVisibility(View.INVISIBLE);
        }
    }

    public Fragment getItem(int i) {
        ArrayList arrayList = new ArrayList();
        if (((PathType) this.tabCategoryList.get(i)).ordinal() == PathType.SENT.ordinal()) {
            for (i = 0; i < this.listdata.size(); i++) {
                if (((FileDataWrapper) this.listdata.get(i)).pathType == PathType.SENT) {
                    arrayList.add(this.listdata.get(i));
                }
            }
        } else if (((PathType) this.tabCategoryList.get(i)).ordinal() == PathType.RECEIVED.ordinal()) {
            for (i = 0; i < this.listdata.size(); i++) {
                if (((FileDataWrapper) this.listdata.get(i)).pathType == PathType.RECEIVED) {
                    arrayList.add(this.listdata.get(i));
                }
            }
        } else if (((PathType) this.tabCategoryList.get(i)).ordinal() == PathType.PROFILEPIC.ordinal()) {
            for (i = 0; i < this.listdata.size(); i++) {
                if (((FileDataWrapper) this.listdata.get(i)).pathType == PathType.PROFILEPIC) {
                    arrayList.add(this.listdata.get(i));
                }
            }
        }
        if (((FileDataWrapper) this.listdata.get(0)).type.ordinal() == MediaType.AUDIOS.ordinal() || ((FileDataWrapper) this.listdata.get(0)).type.ordinal() == MediaType.DOCUMENTS.ordinal()) {
            return new DocFragment(this.mContext, arrayList, this.cheSlectAll);
        }
        return new ImageFragment(this.mContext, arrayList, this.cheSlectAll);
    }

    public CharSequence getPageTitle(int i) {
        return ((PathType) this.tabCategoryList.get(i)).toString();
    }

    public int getCount() {
        return this.tabCategoryList.size();
    }
}
