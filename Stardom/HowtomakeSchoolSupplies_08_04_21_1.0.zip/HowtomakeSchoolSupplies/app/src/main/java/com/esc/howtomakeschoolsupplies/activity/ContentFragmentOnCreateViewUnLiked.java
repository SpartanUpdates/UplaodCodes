package com.esc.howtomakeschoolsupplies.activity;

import com.esc.howtomakeschoolsupplies.data.LikesContract;

public class ContentFragmentOnCreateViewUnLiked implements Runnable {
    final ContentFragmentOnCreateView2 this$0;

    ContentFragmentOnCreateViewUnLiked(ContentFragmentOnCreateView2 contentFragment$onCreateView$3) {
        this.this$0 = contentFragment$onCreateView$3;
    }

    public final void run() {
        this.this$0.this$0.removeLine(LikesContract.DBEntry.TABLE_NAME_FAVORITES, this.this$0.$numberArticle);
    }
}
