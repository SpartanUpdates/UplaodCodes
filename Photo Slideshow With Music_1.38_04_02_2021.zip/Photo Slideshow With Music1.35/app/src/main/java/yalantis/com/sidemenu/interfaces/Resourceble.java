package yalantis.com.sidemenu.interfaces;

public interface Resourceble {
    int getImageRes();

    String getName();
}
