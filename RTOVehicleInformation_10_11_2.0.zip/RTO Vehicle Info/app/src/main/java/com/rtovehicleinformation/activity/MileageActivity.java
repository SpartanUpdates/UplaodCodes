package com.rtovehicleinformation.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.rtovehicleinformation.Adapter.MileageListAdapter;
import com.rtovehicleinformation.Database.OpenSQLite;
import com.rtovehicleinformation.Model.MileageModel;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.application.AppController;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.rtovehicleinformation.utils.nativeadsmethod.populateUnifiedNativeAdView;

public class MileageActivity extends AppCompatActivity {

    Activity activity = MileageActivity.this;
    @BindView(R.id.addmileage)
    ImageView ivaddmileage;

    @BindView(R.id.emptyLayout)
    LinearLayout emptyLayout;

    @BindView(R.id.my_recycler_view)
    RecyclerView rvmileage;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.iv_back)
    ImageView ivback;

    MileageListAdapter mileageListAdapter;
    ArrayList<MileageModel> mileageModels = new ArrayList();
    OpenSQLite openSQLite;
    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mileage);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        this.openSQLite = new OpenSQLite(this.getApplicationContext());
        this.mileageModels = this.openSQLite.listmileage();
        this.mileageListAdapter = new MileageListAdapter(this.mileageModels, this, new MileageListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(final int n) {
                if (!MileageActivity.this.isFinishing()) {
                    final AlertDialog.Builder aleartdialog = new AlertDialog.Builder(MileageActivity.this);
                    aleartdialog.setMessage("Do you want to delete item ?");
                    aleartdialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialogInterface, final int i) {
                            if (MileageActivity.this.openSQLite.dltmileage(MileageActivity.this.mileageModels.get(n).getId()) > 0) {
                                MileageActivity.this.mileageModels.remove(n);
                            }
                            if (MileageActivity.this.mileageModels != null && !MileageActivity.this.mileageModels.isEmpty()) {
                                MileageActivity.this.emptyLayout.setVisibility(View.GONE);
                                MileageActivity.this.rvmileage.setVisibility(View.VISIBLE);
                            } else {
                                MileageActivity.this.rvmileage.setVisibility(View.GONE);
                                MileageActivity.this.emptyLayout.setVisibility(View.VISIBLE);
                            }
                            MileageActivity.this.rvmileage.setLayoutManager(new GridLayoutManager(MileageActivity.this, 1));
                            MileageActivity.this.rvmileage.setAdapter(MileageActivity.this.mileageListAdapter);
                        }
                    });
                    aleartdialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    if (!MileageActivity.this.isFinishing()) {
                        aleartdialog.show();
                    }
                }
            }
        });
        this.rvmileage.setLayoutManager(new GridLayoutManager(this, 1));
        this.rvmileage.setAdapter(this.mileageListAdapter);
        final ArrayList<MileageModel> mileageModels = this.mileageModels;
        if (mileageModels != null && !mileageModels.isEmpty()) {
            this.emptyLayout.setVisibility(View.GONE);
            this.rvmileage.setVisibility(View.VISIBLE);
        } else {
            this.rvmileage.setVisibility(View.GONE);
            this.emptyLayout.setVisibility(View.VISIBLE);
        }
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.ivaddmileage.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                Intent intent = new Intent(MileageActivity.this, MileageEntryActivity.class);
                intent.putExtra("KM_UNIT", MileageActivity.this.getResources().getString(R.string.KM_UNIT));
                intent.putExtra("FULL_UNIT", MileageActivity.this.getResources().getString(R.string.FULL_UNIT));
                intent.putExtra("COST_UNIT", MileageActivity.this.getResources().getString(R.string.COST_UNIT));
                MileageActivity.this.startActivity(intent);
                MileageActivity.this.finish();
                MileageActivity.this.overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            }
        });
        LoadNativeAds();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MileageActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }


    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (MileageActivity.this.nativeAd != null) {
                            MileageActivity.this.nativeAd.destroy();
                        }
                        MileageActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public void onBackPressed() {
        if (AppController.mInterstitialAd != null) {
            AppController.activity = activity;
            AppController.AdsId = 8;
            AppController.mInterstitialAd.show(activity);
        } else {
            GoBack();
        }
    }

    private void GoBack() {
        startActivity(new Intent(activity, MainActivity.class));
        finish();
    }

}
