package com.esc.uvideostatus.Utility;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View.MeasureSpec;
import android.widget.ImageView;

public class StretchyImageView extends ImageView {
    public static int height;

    public StretchyImageView(Context context) {
        super(context);
    }

    public StretchyImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public StretchyImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (getDrawable() != null) {
            int mode = MeasureSpec.getMode(i);
            int mode2 = MeasureSpec.getMode(i2);
            int intrinsicWidth = getDrawable().getIntrinsicWidth();
            int intrinsicHeight = getDrawable().getIntrinsicHeight();
            if (intrinsicWidth <= 0) {
                intrinsicWidth = 1;
            }
            if (intrinsicHeight <= 0) {
                intrinsicHeight = 1;
            }
            float f = ((float) intrinsicWidth) / ((float) intrinsicHeight);
            boolean z = false;
            boolean z2 = mode != 1073741824;
            if (mode2 != 1073741824) {
                z = true;
            }
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int paddingTop = getPaddingTop();
            int paddingBottom = getPaddingBottom();
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            String str = "TAG";
            if (z2 && !z) {
                int i3 = ((int) (f * ((float) ((measuredHeight - paddingTop) - paddingBottom)))) + paddingLeft + paddingRight;
                height = measuredHeight;
                setMeasuredDimension(i3, measuredHeight);
                StringBuilder sb = new StringBuilder();
                sb.append("onMeasure: ");
                sb.append(measuredHeight);
                Log.d(str, sb.toString());
            } else if (z && !z2) {
                int i4 = ((int) (((float) ((measuredWidth - paddingLeft) - paddingRight)) / f)) + paddingTop + paddingBottom;
                height = i4;
                setMeasuredDimension(measuredWidth, i4);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("onMeasure12: ");
                sb2.append(i4);
                Log.d(str, sb2.toString());
            }
        }
    }
}
