package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.Typeface;
import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;

public class SetFont implements FontListAdapter.a {
    public final  CollageMakerDetailActivity e;

    public SetFont(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.e = collageMakerDetailActivity;
    }

    public final void B(Typeface typeface, int i) {
        this.e.B(typeface, i);
    }
}
