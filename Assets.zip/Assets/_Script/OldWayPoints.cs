﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldWayPoints : MonoBehaviour
{
    public GameObject[] wayContainer;

    public Color lineColor;

    Vector3 size = new Vector3(.7f, .7f, .7f);

    public virtual GameObject[] GetPathPoints()
    {
        return wayContainer;
    }
    [ExecuteInEditMode]
    void OnDrawGizmos()
    {
        if (wayContainer.Length > 2)
        {
            Vector3 start = wayContainer[0].transform.position;
            Vector3 end = wayContainer[wayContainer.Length - 1].transform.position;
            Gizmos.color = Color.blue;
            Gizmos.DrawWireCube(start, size * GetHandleSize(start) * 1.5f);
            Gizmos.DrawWireCube(end, size * GetHandleSize(end) * 1.5f);

            for (int i = 1; i < wayContainer.Length - 1; i++)
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawWireSphere(wayContainer[i].transform.position, 0.4f * GetHandleSize(wayContainer[i].transform.position));
            }
            DrawStraight(wayContainer);
        }
    }
    public virtual float GetHandleSize(Vector3 pos)
    {
        float handleSize = 1f;
        #if UNITY_EDITOR
            handleSize = UnityEditor.HandleUtility.GetHandleSize(pos) * 0.4f;
            handleSize = Mathf.Clamp(handleSize, 0, 1.2f);
        #endif
        return handleSize;
    }
    void DrawStraight(GameObject[] waypoints)
    {
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            waypoints[i].name = "WayPoints " + i;
            Gizmos.color = lineColor;
            Gizmos.DrawLine(waypoints[i].transform.position, waypoints[i + 1].transform.position);
        }

        for (int i = 0; i < waypoints.Length; i++)
        {
            waypoints[i].name = "WayPoints " + i;
        }
    }
}
