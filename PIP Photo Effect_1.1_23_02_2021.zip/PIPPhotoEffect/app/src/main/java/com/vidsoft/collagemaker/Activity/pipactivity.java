package com.vidsoft.collagemaker.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Stickers.CropActivity;
import com.vidsoft.collagemaker.Utils.Stickers.MultiTouchListener;
import com.vidsoft.collagemaker.Utils.Stickers.TouchImageView;
import com.vidsoft.collagemaker.Utils.Stickers.Utility;
import com.vidsoft.collagemaker.Utils.CompressImage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class pipactivity extends Activity implements View.OnClickListener {
    private static final int ACTION_REQUEST_GALLERY = 99;
    private static final int CROP_REQUEST_CODE = 11;
    private static final String IMAGE_DIRECTORY_NAME = "TextPhoto";
    private static final int MEDIA_TYPE_IMAGE = 1;
    private static final int PICK_FROM_CAMERA = 100;
    public static int intSelectPip;
    public static String strImageType;
    private Uri ImageUri;
    private Bitmap bitmap_bg;
    private Bitmap bitmap_pic;
    private ImageView imgbutton_1;
    private ImageView imgbutton_10;
    private ImageView imgbutton_11;
    private ImageView imgbutton_12;
    private ImageView imgbutton_13;
    private ImageView imgbutton_14;
    private ImageView imgbutton_15;
    private ImageView imgbutton_16;
    private ImageView imgbutton_17;
    private ImageView imgbutton_18;
    private ImageView imgbutton_19;
    private ImageView imgbutton_2;
    private ImageView imgbutton_20;
    private ImageView imgbutton_21;
    private ImageView imgbutton_22;
    private ImageView imgbutton_23;
    private ImageView imgbutton_24;
    private ImageView imgbutton_25;
    private ImageView imgbutton_26;
    private ImageView imgbutton_27;
    private ImageView imgbutton_3;
    private ImageView imgbutton_4;
    private ImageView imgbutton_5;
    private ImageView imgbutton_6;
    private ImageView imgbutton_7;
    private ImageView imgbutton_8;
    private ImageView imgbutton_9;
    private Button emoticons;
    private Button pipimg;
    private Button save;
    private Button text;
    private Uri contentUri;
    private Dialog dialog;
    private EditText editText;
    private Typeface typeface;
    private int height;
    private ImageView imgCon1;
    private ImageView imgCon10;
    private ImageView imgCon11;
    private ImageView imgCon12;
    private ImageView imgCon13;
    private ImageView imgCon14;
    private ImageView imgCon15;
    private ImageView imgCon16;
    private ImageView imgCon17;
    private ImageView imgCon18;
    private ImageView imgCon19;
    private ImageView imgCon2;
    private ImageView imgCon20;
    private ImageView imgCon3;
    private ImageView imgCon4;
    private ImageView imgCon5;
    private ImageView imgCon6;
    private ImageView imgCon7;
    private ImageView imgCon8;
    private ImageView imgCon9;
    private ImageView imgControlText;
    private ImageView imgEm1;
    private ImageView imgEm10;
    private ImageView imgEm11;
    private ImageView imgEm12;
    private ImageView imgEm13;
    private ImageView imgEm14;
    private ImageView imgEm15;
    private ImageView imgEm16;
    private ImageView imgEm17;
    private ImageView imgEm18;
    private ImageView imgEm19;
    private ImageView imgEm2;
    private ImageView imgEm20;
    private ImageView imgEm3;
    private ImageView imgEm4;
    private ImageView imgEm5;
    private ImageView imgEm6;
    private ImageView imgEm7;
    private ImageView imgEm8;
    private ImageView imgEm9;
    private String imgName;
    private TouchImageView img_view;
    private int int_image1;
    private int int_image10;
    private int int_image11;
    private int int_image12;
    private int int_image13;
    private int int_image14;
    private int int_image15;
    private int int_image16;
    private int int_image17;
    private int int_image18;
    private int int_image19;
    private int int_image2;
    private int int_image20;
    private int int_image3;
    private int int_image4;
    private int int_image5;
    private int int_image6;
    private int int_image7;
    private int int_image8;
    private int int_image9;
    private int int_txt_color;
    private LinearLayout layoutPip;
    private LinearLayout layoutStickers;
    private ImageView mimageview;
    private Uri uri;
    private ProgressDialog progressDialog;
    private RelativeLayout rlEmo;
    private RelativeLayout rlMain;
    private Typeface sTypeface;
    private Drawable selectedD;
    private String str_text;
    private TextView text_title;
    private int width;
    public static String stringImgURI;
    public static Bitmap myBitmap;
    public static String str_urlShareimg;

    static {
        pipactivity.strImageType = "";
        pipactivity.intSelectPip = 0;
    }

    public pipactivity() {
        super();
        this.width = 0;
        this.height = 0;
        this.int_image1 = 0;
        this.int_image2 = 0;
        this.int_image3 = 0;
        this.int_image4 = 0;
        this.int_image5 = 0;
        this.int_image6 = 0;
        this.int_image7 = 0;
        this.int_image8 = 0;
        this.int_image9 = 0;
        this.int_image10 = 0;
        this.int_image11 = 0;
        this.int_image12 = 0;
        this.int_image13 = 0;
        this.int_image14 = 0;
        this.int_image15 = 0;
        this.int_image16 = 0;
        this.int_image17 = 0;
        this.int_image18 = 0;
        this.int_image19 = 0;
        this.int_image20 = 0;
        this.sTypeface = null;
        this.int_txt_color = -1;
        this.str_text = "";
    }

    private void PiPClaerIcons() {
        this.imgbutton_1.setImageResource(0);
        this.imgbutton_2.setImageResource(0);
        this.imgbutton_3.setImageResource(0);
        this.imgbutton_4.setImageResource(0);
        this.imgbutton_5.setImageResource(0);
        this.imgbutton_6.setImageResource(0);
        this.imgbutton_7.setImageResource(0);
        this.imgbutton_8.setImageResource(0);
        this.imgbutton_9.setImageResource(0);
        this.imgbutton_10.setImageResource(0);
        this.imgbutton_11.setImageResource(0);
        this.imgbutton_12.setImageResource(0);
        this.imgbutton_13.setImageResource(0);
        this.imgbutton_14.setImageResource(0);
        this.imgbutton_15.setImageResource(0);
        this.imgbutton_16.setImageResource(0);
        this.imgbutton_17.setImageResource(0);
        this.imgbutton_18.setImageResource(0);
        this.imgbutton_19.setImageResource(0);
        this.imgbutton_20.setImageResource(0);
    }

    private void PiPIcons() {
        this.imgbutton_1.setImageResource(R.drawable.pip_alphabet_a);
        this.imgbutton_2.setImageResource(R.drawable.pip_alphabet_b);
        this.imgbutton_3.setImageResource(R.drawable.pip_alphabet_c);
        this.imgbutton_4.setImageResource(R.drawable.pip_alphabet_d);
        this.imgbutton_5.setImageResource(R.drawable.pip_alphabet_e);
        this.imgbutton_6.setImageResource(R.drawable.pip_alphabet_f);
        this.imgbutton_7.setImageResource(R.drawable.pip_alphabet_g);
        this.imgbutton_8.setImageResource(R.drawable.pip_alphabet_h);
        this.imgbutton_9.setImageResource(R.drawable.pip_alphabet_i);
        this.imgbutton_10.setImageResource(R.drawable.pip_alphabet_j);
        this.imgbutton_11.setImageResource(R.drawable.pip_alphabet_k);
        this.imgbutton_12.setImageResource(R.drawable.pip_alphabet_l);
        this.imgbutton_13.setImageResource(R.drawable.pip_alphabet_m);
        this.imgbutton_14.setImageResource(R.drawable.pip_alphabet_n);
        this.imgbutton_15.setImageResource(R.drawable.pip_alphabet_o);
        this.imgbutton_16.setImageResource(R.drawable.pip_alphabet_p);
        this.imgbutton_17.setImageResource(R.drawable.pip_alphabet_q);
        this.imgbutton_18.setImageResource(R.drawable.pip_alphabet_r);
        this.imgbutton_19.setImageResource(R.drawable.pip_alphabet_s);
        this.imgbutton_20.setImageResource(R.drawable.pip_alphabet_t);
        this.imgbutton_21.setImageResource(R.drawable.pip_alphabet_u);
        this.imgbutton_22.setImageResource(R.drawable.pip_alphabet_v);
        this.imgbutton_23.setImageResource(R.drawable.pip_alphabet_w);
        this.imgbutton_24.setImageResource(R.drawable.pip_alphabet_x);
        this.imgbutton_25.setImageResource(R.drawable.pip_alphabet_y);
        this.imgbutton_26.setImageResource(R.drawable.pip_alphabet_z);
    }

    private void PiPIconsBackground(View v) {
        this.imgbutton_1.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_2.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_3.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_4.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_5.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_6.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_7.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_8.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_9.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_10.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_11.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_12.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_13.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_14.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_15.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_16.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_17.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_18.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_19.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_20.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_21.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_22.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_23.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_24.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_25.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_26.setBackgroundResource(R.drawable.btn_bg);
        this.imgbutton_27.setBackgroundResource(R.drawable.btn_bg);
        v.setBackgroundResource(R.drawable.selectedbg);
    }

    private void SetPiP(final int n) {
        if (n == 1) {
            this.frame1();
        } else if (n == 2) {
            this.frame2();
        } else if (n == 3) {
            this.frame3();
        } else if (n == 4) {
            this.frame4();
        } else if (n == 5) {
            this.frame5();
        } else if (n == 6) {
            this.frame6();
        } else if (n == 7) {
            this.frame7();
        } else if (n == 8) {
            this.frame8();
        } else if (n == 9) {
            this.frame9();
        } else if (n == 10) {
            this.frame10();
        } else if (n == 11) {
            this.frame11();
        } else if (n == 12) {
            this.frame12();
        } else if (n == 13) {
            this.frame13();
        } else if (n == 14) {
            this.frame14();
        } else if (n == 15) {
            this.frame15();
        } else if (n == 16) {
            this.frame16();
        } else if (n == 17) {
            this.frame17();
        } else if (n == 18) {
            this.frame18();
        } else if (n == 19) {
            this.frame19();
        } else if (n == 20) {
            this.frame20();
        } else if (n == 21) {
            this.frame21();
        } else if (n == 22) {
            this.frame22();
        } else if (n == 23) {
            this.frame23();
        } else if (n == 24) {
            this.frame24();
        } else if (n == 25) {
            this.frame25();
        } else if (n == 26) {
            this.frame26();
        }
        this.PiPIcons();
    }

    private void ShowPip() {
        this.emoticonsHide();
        this.emoticons_disable_enable(false);
        this.PiPIcons();
        this.layoutPip.setVisibility(View.VISIBLE);
        this.layoutStickers.setVisibility(View.GONE);
    }

    private void ShowStickers() {
        this.PiPClaerIcons();
        this.emoticons_disable_enable(true);
        this.show_emoticons();
        this.layoutPip.setVisibility(View.GONE);
        this.layoutStickers.setVisibility(View.VISIBLE);
    }

    static void access1(final pipactivity piPShapeActivity,
                        final Uri mUri) {
        piPShapeActivity.uri = mUri;
    }

    static void access10(final pipactivity piPShapeActivity,
                         final String str_text) {
        piPShapeActivity.str_text = str_text;
    }

    static void access12(final pipactivity piPShapeActivity,
                         final Drawable selected_d) {
        piPShapeActivity.selectedD = selected_d;
    }


    static void access6(final pipactivity piPShapeActivity,
                        final Typeface s_typeface) {
        piPShapeActivity.sTypeface = s_typeface;
    }

    private void captureImage() {
        final Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra("output",
                (Parcelable) (this.ImageUri = this.getOutputMediaFileUri(1)));
        this.startActivityForResult(intent, 100);
    }

    private void emoticonsHide() {
        this.imgEm1.setImageResource(0);
        this.imgEm2.setImageResource(0);
        this.imgEm3.setImageResource(0);
        this.imgEm4.setImageResource(0);
        this.imgEm5.setImageResource(0);
        this.imgEm6.setImageResource(0);
        this.imgEm7.setImageResource(0);
        this.imgEm8.setImageResource(0);
        this.imgEm9.setImageResource(0);
        this.imgEm10.setImageResource(0);
        this.imgEm11.setImageResource(0);
        this.imgEm12.setImageResource(0);
        this.imgEm13.setImageResource(0);
        this.imgEm14.setImageResource(0);
        this.imgEm15.setImageResource(0);
        this.imgEm16.setImageResource(0);
        this.imgEm17.setImageResource(0);
        this.imgEm18.setImageResource(0);
        this.imgEm19.setImageResource(0);
        this.imgEm20.setImageResource(0);
    }

    private void emoticons_disable_enable(final boolean b) {
        this.imgCon1.setEnabled(b);
        this.imgCon1.setClickable(b);
        this.imgCon2.setEnabled(b);
        this.imgCon2.setClickable(b);
        this.imgCon3.setEnabled(b);
        this.imgCon3.setClickable(b);
        this.imgCon4.setEnabled(b);
        this.imgCon4.setClickable(b);
        this.imgCon5.setEnabled(b);
        this.imgCon5.setClickable(b);
        this.imgCon6.setEnabled(b);
        this.imgCon6.setClickable(b);
        this.imgCon7.setEnabled(b);
        this.imgCon7.setClickable(b);
        this.imgCon8.setEnabled(b);
        this.imgCon8.setClickable(b);
        this.imgCon9.setEnabled(b);
        this.imgCon9.setClickable(b);
        this.imgCon10.setEnabled(b);
        this.imgCon10.setClickable(b);
        this.imgCon11.setEnabled(b);
        this.imgCon11.setClickable(b);
        this.imgCon12.setEnabled(b);
        this.imgCon12.setClickable(b);
        this.imgCon13.setEnabled(b);
        this.imgCon13.setClickable(b);
        this.imgCon14.setEnabled(b);
        this.imgCon14.setClickable(b);
        this.imgCon15.setEnabled(b);
        this.imgCon15.setClickable(b);
        this.imgCon16.setEnabled(b);
        this.imgCon16.setClickable(b);
        this.imgCon17.setEnabled(b);
        this.imgCon17.setClickable(b);
        this.imgCon18.setEnabled(b);
        this.imgCon18.setClickable(b);
        this.imgCon19.setEnabled(b);
        this.imgCon19.setClickable(b);
        this.imgCon20.setEnabled(b);
        this.imgCon20.setClickable(b);
    }

    private void emoticons_menu() {
        this.rlEmo = (RelativeLayout) findViewById(R.id.ll_menu_frame);
        this.imgEm1 = (ImageView) findViewById(R.id.control_1);
        this.imgEm1.setOnClickListener(this);
        this.imgEm2 = (ImageView) findViewById(R.id.control_2);
        this.imgEm2.setOnClickListener(this);
        this.imgEm3 = (ImageView) findViewById(R.id.control_3);
        this.imgEm3.setOnClickListener(this);
        this.imgEm4 = (ImageView) findViewById(R.id.control_4);
        this.imgEm4.setOnClickListener(this);
        this.imgEm5 = (ImageView) findViewById(R.id.control_5);
        this.imgEm5.setOnClickListener(this);
        this.imgEm6 = (ImageView) findViewById(R.id.control_6);
        this.imgEm6.setOnClickListener(this);
        this.imgEm7 = (ImageView) findViewById(R.id.control_7);
        this.imgEm7.setOnClickListener(this);
        this.imgEm8 = (ImageView) findViewById(R.id.control_8);
        this.imgEm8.setOnClickListener(this);
        this.imgEm9 = (ImageView) findViewById(R.id.control_9);
        this.imgEm9.setOnClickListener(this);
        this.imgEm10 = (ImageView) findViewById(R.id.control_10);
        this.imgEm10.setOnClickListener(this);
        this.imgEm11 = (ImageView) findViewById(R.id.control_11);
        this.imgEm11.setOnClickListener(this);
        this.imgEm12 = (ImageView) findViewById(R.id.control_12);
        this.imgEm12.setOnClickListener(this);
        this.imgEm13 = (ImageView) findViewById(R.id.control_13);
        this.imgEm13.setOnClickListener(this);
        this.imgEm14 = (ImageView) findViewById(R.id.control_14);
        this.imgEm14.setOnClickListener(this);
        this.imgEm15 = (ImageView) findViewById(R.id.control_15);
        this.imgEm15.setOnClickListener(this);
        this.imgEm16 = (ImageView) findViewById(R.id.control_16);
        this.imgEm16.setOnClickListener(this);
        this.imgEm17 = (ImageView) findViewById(R.id.control_17);
        this.imgEm17.setOnClickListener(this);
        this.imgEm18 = (ImageView) findViewById(R.id.control_18);
        this.imgEm18.setOnClickListener(this);
        this.imgEm19 = (ImageView) findViewById(R.id.control_19);
        this.imgEm19.setOnClickListener(this);
        this.imgEm20 = (ImageView) findViewById(R.id.control_20);
        this.imgEm20.setOnClickListener(this);
        this.imgCon1 = (ImageView) findViewById(R.id.img_control_1);
        this.imgCon1.setOnTouchListener(new MultiTouchListener());
        this.imgCon2 = (ImageView) findViewById(R.id.img_control_2);
        this.imgCon2.setOnTouchListener(new MultiTouchListener());
        this.imgCon3 = (ImageView) findViewById(R.id.img_control_3);
        this.imgCon3.setOnTouchListener(new MultiTouchListener());
        this.imgCon4 = (ImageView) findViewById(R.id.img_control_4);
        this.imgCon4.setOnTouchListener(new MultiTouchListener());
        this.imgCon5 = (ImageView) findViewById(R.id.img_control_5);
        this.imgCon5.setOnTouchListener(new MultiTouchListener());
        this.imgCon6 = (ImageView) findViewById(R.id.img_control_6);
        this.imgCon6.setOnTouchListener(new MultiTouchListener());
        this.imgCon7 = (ImageView) findViewById(R.id.img_control_7);
        this.imgCon7.setOnTouchListener(new MultiTouchListener());
        this.imgCon8 = (ImageView) findViewById(R.id.img_control_8);
        this.imgCon8.setOnTouchListener(new MultiTouchListener());
        this.imgCon9 = (ImageView) findViewById(R.id.img_control_9);
        this.imgCon9.setOnTouchListener(new MultiTouchListener());
        this.imgCon10 = (ImageView) findViewById(R.id.img_control_10);
        this.imgCon10.setOnTouchListener(new MultiTouchListener());
        this.imgCon11 = (ImageView) findViewById(R.id.img_control_11);
        this.imgCon11.setOnTouchListener(new MultiTouchListener());
        this.imgCon12 = (ImageView) findViewById(R.id.img_control_12);
        this.imgCon12.setOnTouchListener(new MultiTouchListener());
        this.imgCon13 = (ImageView) findViewById(R.id.img_control_13);
        this.imgCon13.setOnTouchListener(new MultiTouchListener());
        this.imgCon14 = (ImageView) findViewById(R.id.img_control_14);
        this.imgCon14.setOnTouchListener(new MultiTouchListener());
        this.imgCon15 = (ImageView) findViewById(R.id.img_control_15);
        this.imgCon15.setOnTouchListener(new MultiTouchListener());
        this.imgCon16 = (ImageView) findViewById(R.id.img_control_16);
        this.imgCon16.setOnTouchListener(new MultiTouchListener());
        this.imgCon17 = (ImageView) findViewById(R.id.img_control_17);
        this.imgCon17.setOnTouchListener(new MultiTouchListener());
        this.imgCon18 = (ImageView) findViewById(R.id.img_control_18);
        this.imgCon18.setOnTouchListener(new MultiTouchListener());
        this.imgCon19 = (ImageView) findViewById(R.id.img_control_19);
        this.imgCon19.setOnTouchListener(new MultiTouchListener());
        this.imgCon20 = (ImageView) findViewById(R.id.img_control_20);
        this.imgCon20.setOnTouchListener(new MultiTouchListener());
        this.imgControlText = (ImageView) findViewById(R.id.txt_image);
        this.imgControlText.setOnTouchListener(new MultiTouchListener());
    }

    private void frame1() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_1a, R.drawable.f_1a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame2() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_2a, R.drawable.f_2a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame3() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_3a, R.drawable.f_3a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame4() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_4a, R.drawable.f_4a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame5() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_5a, R.drawable.f_5a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame6() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_6a, R.drawable.f_6a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame7() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_7a, R.drawable.f_7a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame8() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_8a, R.drawable.f_8a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame9() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage, R.drawable.f_9a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame10() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_10a, R.drawable.f_10a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame11() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_11a, R.drawable.f_11a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame12() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.v_12a, R.drawable.f_12a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame13() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_13a, R.drawable.f13a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame14() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_14a, R.drawable.f_14a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame15() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_15a, R.drawable.f_15a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame16() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_16a, R.drawable.f_16a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame17() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_17a, R.drawable.f_17a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame18() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_18a, R.drawable.f18a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame19() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_19a, R.drawable.f_19a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame20() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_20a, R.drawable.f_20a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame21() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_21a, R.drawable.f_21a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame22() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_22a, R.drawable.f_22a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame23() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_23a, R.drawable.f_23a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame24() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_24a, R.drawable.f_24a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame25() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_25a, R.drawable.f_25a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame26() {
        Utility.makeMaskImage(this, this.mimageview, this.bitmap_bg,
                R.drawable.maskimage_26a, R.drawable.f_26a, this.width,
                this.height);
        this.img_view.setImageBitmap(this.bitmap_pic);
    }

    private void frame27() {
    }

    private File getOutputMediaFile(final int n) {
        final File file = new File(
                Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "TextPhoto");
        if (!file.exists() && !file.mkdirs()) {
            Log.d("TextPhoto", "Oops! Failed create TextPhoto directory");
        } else {
            final String format = new SimpleDateFormat("yyyyMMdd_HHmmss",
                    Locale.getDefault()).format(new Date());
            if (n == 1) {
                this.imgName = "IMG_" + format + ".jpg";
                return new File(String.valueOf(file.getPath()) + File.separator
                        + this.imgName);
            }
        }
        return null;
    }

    private void images_visibility(int i_side) {
        select_emo_bg(i_side);
        if (i_side == MEDIA_TYPE_IMAGE) {
            if (this.int_image1 == 0) {
                this.int_image1 = MEDIA_TYPE_IMAGE;
                this.imgCon1.setBackgroundResource(R.drawable.ss1);
                this.imgCon1.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image1 = 0;
            this.imgCon1.setVisibility(View.GONE);
        } else if (i_side == 2) {
            if (this.int_image2 == 0) {
                this.int_image2 = MEDIA_TYPE_IMAGE;
                this.imgCon2.setBackgroundResource(R.drawable.ss2);
                this.imgCon2.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image2 = 0;
            this.imgCon2.setVisibility(View.GONE);
        } else if (i_side == 3) {
            if (this.int_image3 == 0) {
                this.int_image3 = MEDIA_TYPE_IMAGE;
                this.imgCon3.setBackgroundResource(R.drawable.ss3);
                this.imgCon3.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image3 = 0;
            this.imgCon3.setVisibility(View.GONE);
        } else if (i_side == 4) {
            if (this.int_image4 == 0) {
                this.int_image4 = MEDIA_TYPE_IMAGE;
                this.imgCon4.setBackgroundResource(R.drawable.ss4);
                this.imgCon4.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image4 = 0;
            this.imgCon4.setVisibility(View.GONE);
        } else if (i_side == 5) {
            if (this.int_image5 == 0) {
                this.int_image5 = MEDIA_TYPE_IMAGE;
                this.imgCon5.setBackgroundResource(R.drawable.ss5);
                this.imgCon5.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image5 = 0;
            this.imgCon5.setVisibility(View.GONE);
        } else if (i_side == 6) {
            if (this.int_image6 == 0) {
                this.int_image6 = MEDIA_TYPE_IMAGE;
                this.imgCon6.setBackgroundResource(R.drawable.ss6);
                this.imgCon6.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image6 = 0;
            this.imgCon6.setVisibility(View.GONE);
        } else if (i_side == 7) {
            if (this.int_image7 == 0) {
                this.int_image7 = MEDIA_TYPE_IMAGE;
                this.imgCon7.setBackgroundResource(R.drawable.ss7);
                this.imgCon7.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image7 = 0;
            this.imgCon7.setVisibility(View.GONE);
        } else if (i_side == 8) {
            if (this.int_image8 == 0) {
                this.int_image8 = MEDIA_TYPE_IMAGE;
                this.imgCon8.setBackgroundResource(R.drawable.ss8);
                this.imgCon8.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image8 = 0;
            this.imgCon8.setVisibility(View.GONE);
        } else if (i_side == 9) {
            if (this.int_image9 == 0) {
                this.int_image9 = MEDIA_TYPE_IMAGE;
                this.imgCon9.setBackgroundResource(R.drawable.ss9);
                this.imgCon9.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image9 = 0;
            this.imgCon9.setVisibility(View.GONE);
        } else if (i_side == 10) {
            if (this.int_image10 == 0) {
                this.int_image10 = MEDIA_TYPE_IMAGE;
                this.imgCon10.setBackgroundResource(R.drawable.ss10);
                this.imgCon10.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image10 = 0;
            this.imgCon10.setVisibility(View.GONE);
        } else if (i_side == CROP_REQUEST_CODE) {
            if (this.int_image11 == 0) {
                this.int_image11 = MEDIA_TYPE_IMAGE;
                this.imgCon11.setBackgroundResource(R.drawable.ss11);
                this.imgCon11.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image11 = 0;
            this.imgCon11.setVisibility(View.GONE);
        } else if (i_side == 12) {
            if (this.int_image12 == 0) {
                this.int_image12 = MEDIA_TYPE_IMAGE;
                this.imgCon12.setBackgroundResource(R.drawable.ss12);
                this.imgCon12.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image12 = 0;
            this.imgCon12.setVisibility(View.GONE);
        } else if (i_side == 13) {
            if (this.int_image13 == 0) {
                this.int_image13 = MEDIA_TYPE_IMAGE;
                this.imgCon13.setBackgroundResource(R.drawable.ss13);
                this.imgCon13.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image13 = 0;
            this.imgCon13.setVisibility(View.GONE);
        } else if (i_side == 14) {
            if (this.int_image14 == 0) {
                this.int_image14 = MEDIA_TYPE_IMAGE;
                this.imgCon14.setBackgroundResource(R.drawable.ss14);
                this.imgCon14.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image14 = 0;
            this.imgCon14.setVisibility(View.GONE);
        } else if (i_side == 15) {
            if (this.int_image15 == 0) {
                this.int_image15 = MEDIA_TYPE_IMAGE;
                this.imgCon15.setBackgroundResource(R.drawable.ss15);
                this.imgCon15.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image15 = 0;
            this.imgCon15.setVisibility(View.GONE);
        } else if (i_side == 16) {
            if (this.int_image16 == 0) {
                this.int_image16 = MEDIA_TYPE_IMAGE;
                this.imgCon16.setBackgroundResource(R.drawable.ss16);
                this.imgCon16.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image16 = 0;
            this.imgCon16.setVisibility(View.GONE);
        } else if (i_side == 17) {
            if (this.int_image17 == 0) {
                this.int_image17 = MEDIA_TYPE_IMAGE;
                this.imgCon17.setBackgroundResource(R.drawable.ss17);
                this.imgCon17.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image17 = 0;
            this.imgCon17.setVisibility(View.GONE);
        } else if (i_side == 18) {
            if (this.int_image18 == 0) {
                this.int_image18 = MEDIA_TYPE_IMAGE;
                this.imgCon18.setBackgroundResource(R.drawable.ss18);
                this.imgCon18.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image18 = 0;
            this.imgCon18.setVisibility(View.GONE);
        } else if (i_side == 19) {
            if (this.int_image19 == 0) {
                this.int_image19 = MEDIA_TYPE_IMAGE;
                this.imgCon19.setBackgroundResource(R.drawable.ss19);
                this.imgCon19.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image19 = 0;
            this.imgCon19.setVisibility(View.GONE);
        } else if (i_side != 20) {
        } else {
            if (this.int_image20 == 0) {
                this.int_image20 = MEDIA_TYPE_IMAGE;
                this.imgCon20.setBackgroundResource(R.drawable.ss20);
                this.imgCon20.setVisibility(View.VISIBLE);
                return;
            }
            this.int_image20 = 0;
            this.imgCon20.setVisibility(View.GONE);
        }
    }

    private void loadAsync(final Uri uri) {
        final Drawable drawable = this.img_view.getDrawable();
        if (drawable != null
                && drawable instanceof BitmapDrawable
                && ((BitmapDrawable) this.img_view.getDrawable()).getBitmap() != null) {
            ((BitmapDrawable) this.img_view.getDrawable()).getBitmap()
                    .recycle();
        }
        this.img_view.setImageDrawable((Drawable) null);
        new DownloadAsync().execute(new Uri[]{uri});
    }

    private void pickFromGallery() {
        final Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        this.startActivityForResult(
                Intent.createChooser(intent, "Choose a Picture"),
                99);
    }

    private void select_emo_bg(final int n) {
        this.imgEm1.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm2.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm3.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm4.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm5.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm6.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm7.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm8.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm9.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm10.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm11.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm12.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm13.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm14.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm15.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm16.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm17.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm18.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm19.setBackgroundResource(R.drawable.btn_bg);
        this.imgEm20.setBackgroundResource(R.drawable.btn_bg);
        if (n == MEDIA_TYPE_IMAGE) {
            if (this.int_image1 == 0) {
                this.imgEm1.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm1.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 2) {
            if (this.int_image2 == 0) {
                this.imgEm2.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm2.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 3) {
            if (this.int_image3 == 0) {
                this.imgEm3.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm3.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 4) {
            if (this.int_image4 == 0) {
                this.imgEm4.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm4.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 5) {
            if (this.int_image5 == 0) {
                this.imgEm5.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm5.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 6) {
            if (this.int_image6 == 0) {
                this.imgEm6.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm6.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 7) {
            if (this.int_image7 == 0) {
                this.imgEm7.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm7.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 8) {
            if (this.int_image8 == 0) {
                this.imgEm8.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm8.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 9) {
            if (this.int_image9 == 0) {
                this.imgEm9.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm9.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 10) {
            if (this.int_image10 == 0) {
                this.imgEm10.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm10.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == CROP_REQUEST_CODE) {
            if (this.int_image11 == 0) {
                this.imgEm11.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm11.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 12) {
            if (this.int_image12 == 0) {
                this.imgEm12.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm12.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 13) {
            if (this.int_image13 == 0) {
                this.imgEm13.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm13.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 14) {
            if (this.int_image14 == 0) {
                this.imgEm14.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm14.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 15) {
            if (this.int_image15 == 0) {
                this.imgEm15.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm15.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 16) {
            if (this.int_image16 == 0) {
                this.imgEm16.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm16.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 17) {
            if (this.int_image17 == 0) {
                this.imgEm17.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm17.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 18) {
            if (this.int_image18 == 0) {
                this.imgEm18.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm18.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n == 19) {
            if (this.int_image19 == 0) {
                this.imgEm19.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm19.setBackgroundResource(R.drawable.btn_bg);
            }
        } else if (n != 20) {
        } else {
            if (this.int_image20 == 0) {
                this.imgEm20.setBackgroundResource(R.drawable.selectedbg);
            } else {
                this.imgEm20.setBackgroundResource(R.drawable.btn_bg);
            }
        }
    }

    private void show_emoticons() {
        this.emoticons_disable_enable(true);
        this.rlEmo.setVisibility(View.VISIBLE);
        this.imgEm1.setImageResource(R.drawable.ss1s);
        this.imgEm2.setImageResource(R.drawable.ss2s);
        this.imgEm3.setImageResource(R.drawable.ss3s);
        this.imgEm4.setImageResource(R.drawable.ss4s);
        this.imgEm5.setImageResource(R.drawable.ss5s);
        this.imgEm6.setImageResource(R.drawable.ss6s);
        this.imgEm7.setImageResource(R.drawable.ss7s);
        this.imgEm8.setImageResource(R.drawable.ss8s);
        this.imgEm9.setImageResource(R.drawable.ss9s);
        this.imgEm10.setImageResource(R.drawable.ss10s);
        this.imgEm11.setImageResource(R.drawable.ss11s);
        this.imgEm12.setImageResource(R.drawable.ss12s);
        this.imgEm13.setImageResource(R.drawable.ss13s);
        this.imgEm14.setImageResource(R.drawable.ss14s);
        this.imgEm15.setImageResource(R.drawable.ss15s);
        this.imgEm16.setImageResource(R.drawable.ss16s);
        this.imgEm17.setImageResource(R.drawable.ss17s);
        this.imgEm18.setImageResource(R.drawable.ss18s);
        this.imgEm19.setImageResource(R.drawable.ss19s);
        this.imgEm20.setImageResource(R.drawable.ss20s);
    }

    private void text_dialog() {
        (this.dialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen))
                .requestWindowFeature(1);
        this.dialog.getWindow().setBackgroundDrawable(
                (Drawable) new ColorDrawable(getResources().getColor(R.color.Status_Bar)));
        this.dialog.setContentView(R.layout.text_layout);
        (this.editText = (EditText) this.dialog.findViewById(R.id.et_field))
                .setText((CharSequence) this.str_text);
        this.editText.setTextColor(this.int_txt_color);
        final LinearLayout linearLayout = (LinearLayout) this.dialog
                .findViewById(R.id.ll_font);
        final LinearLayout linearLayout2 = (LinearLayout) this.dialog
                .findViewById(R.id.ll_font_size);
        linearLayout.setVisibility(View.GONE);
        linearLayout2.setVisibility(View.GONE);
        Button button = (Button) this.dialog.findViewById(R.id.style_btn1);
        Button button2 = (Button) this.dialog.findViewById(R.id.style_btn2);
        Button button3 = (Button) this.dialog.findViewById(R.id.style_btn3);
        Button button4 = (Button) this.dialog.findViewById(R.id.style_btn4);
        Button button5 = (Button) this.dialog.findViewById(R.id.style_btn5);
        Button button6 = (Button) this.dialog.findViewById(R.id.style_btn6);
        Button button7 = (Button) this.dialog.findViewById(R.id.style_btn7);
        Button button8 = (Button) this.dialog.findViewById(R.id.style_btn8);
        Button button9 = (Button) this.dialog.findViewById(R.id.style_btn9);
        Button button10 = (Button) this.dialog.findViewById(R.id.style_btn10);
        Button button11 = (Button) this.dialog.findViewById(R.id.style_btn11);
        Button button12 = (Button) this.dialog.findViewById(R.id.style_btn12);
        Button button13 = (Button) this.dialog.findViewById(R.id.btnsize_1);
        Button button14 = (Button) this.dialog.findViewById(R.id.btnsize_2);
        Button button15 = (Button) this.dialog.findViewById(R.id.btnsize_3);
        Button button16 = (Button) this.dialog.findViewById(R.id.btnsize_4);
        Button button17 = (Button) this.dialog.findViewById(R.id.btnsize_5);
        Button button18 = (Button) this.dialog.findViewById(R.id.btnsize_6);
        Button button19 = (Button) this.dialog.findViewById(R.id.btnsize_7);
        Button button20 = (Button) this.dialog.findViewById(R.id.btnsize_8);
        Button button21 = (Button) this.dialog.findViewById(R.id.btnsize_9);
        Button button22 = (Button) this.dialog.findViewById(R.id.btnsize_10);
        Button button23 = (Button) this.dialog.findViewById(R.id.btnsize_11);
        Button button24 = (Button) this.dialog.findViewById(R.id.btnsize_12);
        final Typeface fromAsset = Typeface.createFromAsset(this.getAssets(),
                "fonts/f1.ttf");
        final Typeface fromAsset2 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f2.ttf");
        final Typeface fromAsset3 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f3.otf");
        final Typeface fromAsset4 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f4.otf");
        final Typeface fromAsset5 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f5.ttf");
        final Typeface fromAsset6 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f6.otf");
        final Typeface fromAsset7 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f7.ttf");
        final Typeface fromAsset8 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f8.otf");
        final Typeface fromAsset9 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f9.ttf");
        final Typeface fromAsset10 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f10.otf");
        final Typeface fromAsset11 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f11.ttf");
        final Typeface fromAsset12 = Typeface.createFromAsset(this.getAssets(),
                "fonts/f12.otf");
        button.setTypeface(fromAsset);
        button2.setTypeface(fromAsset2);
        button3.setTypeface(fromAsset3);
        button4.setTypeface(fromAsset4);
        button5.setTypeface(fromAsset5);
        button6.setTypeface(fromAsset6);
        button7.setTypeface(fromAsset7);
        button8.setTypeface(fromAsset8);
        button9.setTypeface(fromAsset9);
        button10.setTypeface(fromAsset10);
        button11.setTypeface(fromAsset11);
        button12.setTypeface(fromAsset12);
        button13.setTypeface(fromAsset);
        button14.setTypeface(fromAsset);
        button15.setTypeface(fromAsset);
        button16.setTypeface(fromAsset);
        button17.setTypeface(fromAsset);
        button18.setTypeface(fromAsset);
        button19.setTypeface(fromAsset);
        button20.setTypeface(fromAsset);
        button21.setTypeface(fromAsset);
        button22.setTypeface(fromAsset);
        button23.setTypeface(fromAsset);
        button24.setTypeface(fromAsset);
        button.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button2.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset2);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button3.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset3);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button4.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset4);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button5.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset5);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button6.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset6);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button7.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset7);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button8.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset8);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button9.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset9);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button10.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset10);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button11.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset11);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button12.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.access6(pipactivity.this, fromAsset12);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button13.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(30.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button14.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(35.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button15.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(40.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button16.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(45.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button17.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(50.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button18.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(55.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button19.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(60.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button20.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(65.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button21.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(70.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button22.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(75.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button23.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(80.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        button24.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                pipactivity.this.editText.setTextSize(85.0f);
                pipactivity.this.editText
                        .setTypeface(pipactivity.this.sTypeface);
            }
        });
        final ImageView imageView = (ImageView) this.dialog
                .findViewById(R.id.btn_done);
        final ImageView imageView2 = (ImageView) this.dialog
                .findViewById(R.id.btn_font);
        final ImageView imageView3 = (ImageView) this.dialog
                .findViewById(R.id.btn_size);
        imageView
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        pipactivity.this.dialog.dismiss();
                        pipactivity.access10(pipactivity.this,
                                pipactivity.this.editText.getText()
                                        .toString());
                        pipactivity
                                .access12(
                                        pipactivity.this,
                                        (Drawable) new BitmapDrawable(
                                                pipactivity.this
                                                        .get_bitmap(pipactivity.this.str_text)));
                        pipactivity.this.imgControlText
                                .setImageDrawable(pipactivity.this.selectedD);
                        pipactivity.this.rlEmo.setVisibility(View.VISIBLE);
                    }
                });
        imageView2
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        linearLayout.setVisibility(View.VISIBLE);
                        linearLayout2.setVisibility(View.GONE);
                    }
                });
        imageView3
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view) {
                        linearLayout.setVisibility(View.GONE);
                        linearLayout2.setVisibility(View.VISIBLE);
                    }
                });
        this.dialog
                .setOnKeyListener((DialogInterface.OnKeyListener) new DialogInterface.OnKeyListener() {
                    public boolean onKey(final DialogInterface dialogInterface,
                                         final int n, final KeyEvent keyEvent) {
                        if (n == 4) {
                            pipactivity.this.dialog.dismiss();
                        }
                        return true;
                    }
                });
        this.dialog.show();
    }


    public Uri getOutputMediaFileUri(final int n) {
        return Uri.fromFile(this.getOutputMediaFile(n));
    }

    void getScreenSnapShot() {
        View content = findViewById(R.id.ll_main);
        content.setDrawingCacheEnabled(true);
        File imgFile = CompressImage.tempImage(getApplicationContext(), content.getDrawingCache());
        try {
            File f = new File(imgFile.getAbsolutePath());
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 10;
            opts.inMutable = true;
            myBitmap = BitmapFactory.decodeStream(new FileInputStream(f));
            myBitmap = myBitmap.copy(Bitmap.Config.ARGB_8888, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        takeScreenshot(myBitmap, getResources().getString(R.string.app_name));
    }

    public Bitmap get_bitmap(final String s) {
        final TextPaint textPaint = new TextPaint();
        textPaint.setColor(this.int_txt_color);
        if (this.sTypeface != null) {
            textPaint.setTypeface(Typeface.create(this.sTypeface, 0));
        } else {
            textPaint.setTypeface(Typeface.create("", 0));
        }
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(100.0f);
        final StaticLayout staticLayout = new StaticLayout((CharSequence) s,
                textPaint, this.width, Layout.Alignment.ALIGN_CENTER, 1.0f,
                0.0f, false);
        final Bitmap bitmap = Bitmap.createBitmap(this.width,
                staticLayout.getHeight() + 100, Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
        canvas.translate(6.0f, 40.0f);
        staticLayout.draw(canvas);
        return bitmap;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FROM_CAMERA) {
            if (resultCode == -1) {
                try {
                    loadAsync(this.ImageUri);
                } catch (Exception e) {
                }
            } else if (resultCode == 0) {
                finish();
            }
        } else if (requestCode == ACTION_REQUEST_GALLERY) {
            if (resultCode == -1) {
                try {
                    loadAsync(data.getData());
                } catch (Exception e2) {
                }
            } else if (resultCode == 0) {
                finish();
            }
        } else if (requestCode != CROP_REQUEST_CODE) {
        } else {
            if (resultCode == -1) {
                this.bitmap_pic = Utility.CropBitmap;
                this.bitmap_bg = Utility.CropBitmap;
                intSelectPip = 2;
            } else if (resultCode == 0) {
                finish();
            }
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        pipactivity.intSelectPip = 0;
    }

    public void onClick(final View view) {
        if (view == this.pipimg) {
            this.imgControlText.setEnabled(false);
            this.imgControlText.setClickable(false);
            this.ShowPip();
        } else {
            if (view == this.emoticons) {
                this.imgControlText.setEnabled(false);
                this.imgControlText.setClickable(false);
                this.ShowStickers();
                return;
            }
            if (view == this.text) {
                this.imgControlText.setEnabled(true);
                this.imgControlText.setClickable(true);
                this.emoticons_disable_enable(false);
                this.text_dialog();
                return;
            }
            if (view == this.save) {
                loadSaveImage();
            }
            if (view == this.imgbutton_1) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 1;
                this.frame1();
                return;
            }
            if (view == this.imgbutton_2) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 2;
                this.frame2();
                return;
            }
            if (view == this.imgbutton_3) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 3;
                this.frame3();
                return;
            }
            if (view == this.imgbutton_4) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 4;
                this.frame4();
                return;
            }
            if (view == this.imgbutton_5) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 5;
                this.frame5();
                return;
            }
            if (view == this.imgbutton_6) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 6;
                this.frame6();
                return;
            }
            if (view == this.imgbutton_7) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 7;
                this.frame7();
                return;
            }
            if (view == this.imgbutton_8) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 8;
                this.frame8();
                return;
            }
            if (view == this.imgbutton_9) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 9;
                this.frame9();
                return;
            }
            if (view == this.imgbutton_10) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 10;
                this.frame10();
                return;
            }
            if (view == this.imgbutton_11) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 11;
                this.frame11();
                return;
            }
            if (view == this.imgbutton_12) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 12;
                this.frame12();
                return;
            }
            if (view == this.imgbutton_13) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 13;
                this.frame13();
                return;
            }
            if (view == this.imgbutton_14) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 14;
                this.frame14();
                return;
            }
            if (view == this.imgbutton_15) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 15;
                this.frame15();
                return;
            }
            if (view == this.imgbutton_16) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 16;
                this.frame16();
                return;
            }
            if (view == this.imgbutton_17) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 17;
                this.frame17();
                return;
            }
            if (view == this.imgbutton_18) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 18;
                this.frame18();
                return;
            }
            if (view == this.imgbutton_19) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 19;
                this.frame19();
                return;
            }
            if (view == this.imgbutton_20) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 20;
                this.frame20();
                return;
            }
            if (view == this.imgbutton_21) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 21;
                this.frame21();
                return;
            }
            if (view == this.imgbutton_22) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 22;
                this.frame22();
                return;
            }
            if (view == this.imgbutton_23) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 23;
                this.frame23();
                return;
            }
            if (view == this.imgbutton_24) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 24;
                this.frame24();
                return;
            }
            if (view == this.imgbutton_25) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 25;
                this.frame25();
                return;
            }
            if (view == this.imgbutton_26) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 26;
                this.frame26();
                return;
            }
            if (view == this.imgbutton_27) {
                this.PiPIconsBackground(view);
                pipactivity.intSelectPip = 27;
                this.frame27();
                return;
            }
            if (view == this.imgEm1) {
                this.images_visibility(1);
                return;
            }
            if (view == this.imgEm2) {
                this.images_visibility(2);
                return;
            }
            if (view == this.imgEm3) {
                this.images_visibility(3);
                return;
            }
            if (view == this.imgEm4) {
                this.images_visibility(4);
                return;
            }
            if (view == this.imgEm5) {
                this.images_visibility(5);
                return;
            }
            if (view == this.imgEm6) {
                this.images_visibility(6);
                return;
            }
            if (view == this.imgEm7) {
                this.images_visibility(7);
                return;
            }
            if (view == this.imgEm8) {
                this.images_visibility(8);
                return;
            }
            if (view == this.imgEm9) {
                this.images_visibility(9);
                return;
            }
            if (view == this.imgEm10) {
                this.images_visibility(10);
                return;
            }
            if (view == this.imgEm11) {
                this.images_visibility(11);
                return;
            }
            if (view == this.imgEm12) {
                this.images_visibility(12);
                return;
            }
            if (view == this.imgEm13) {
                this.images_visibility(13);
                return;
            }
            if (view == this.imgEm14) {
                this.images_visibility(14);
                return;
            }
            if (view == this.imgEm15) {
                this.images_visibility(15);
                return;
            }
            if (view == this.imgEm16) {
                this.images_visibility(16);
                return;
            }
            if (view == this.imgEm17) {
                this.images_visibility(17);
                return;
            }
            if (view == this.imgEm18) {
                this.images_visibility(18);
                return;
            }
            if (view == this.imgEm19) {
                this.images_visibility(19);
                return;
            }
            if (view == this.imgEm20) {
                this.images_visibility(20);
            }
        }
    }

    private void loadSaveImage() {
        new saves().execute(new String[]{""});
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialogAd.dismiss();
            }
        }, 2000);
    }

    private int id;
    private InterstitialAd interstitialAd;
    Dialog dialogAd;

    private void loadAd() {
        dialogAd = new Dialog(pipactivity.this);
        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialogAd.getWindow().setGravity(Gravity.CENTER);
        dialogAd.setContentView(R.layout.dialog_layout_progress);
        dialogAd.setCanceledOnTouchOutside(false);
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialogAd.dismiss();
                switch (id) {
                    case R.id.btnsave:
                        startActivity(new Intent(pipactivity.this, ShareActivity.class).putExtra("key", 3));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();
    }

    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.alphabet_activity);
        bindControls();
        setProgressBar();
        loadAd();
    }

    private void setProgressBar() {
        (this.progressDialog = new ProgressDialog((Context) this))
                .setMessage((CharSequence) "Please wait...");
        this.progressDialog.setCancelable(false);
        if (pipactivity.strImageType.equalsIgnoreCase("1")) {
            this.pickFromGallery();
        } else if (pipactivity.strImageType.equalsIgnoreCase("2")) {
            this.captureImage();
        }
    }

    private void bindControls() {
        this.typeface = Typeface.createFromAsset(this.getResources().getAssets(),
                "fonts/header.otf");
        (this.text_title = (TextView) this.findViewById(R.id.headertitle))
                .setText("PIP Alphabets");
        (this.pipimg = (Button) this.findViewById(R.id.btnpipImage))
                .setOnClickListener(this);
        (this.emoticons = (Button) this.findViewById(R.id.btnStickers))
                .setOnClickListener((View.OnClickListener) this);
        (this.text = (Button) this.findViewById(R.id.btntext))
                .setOnClickListener((View.OnClickListener) this);
        (this.save = (Button) this.findViewById(R.id.btnsave))
                .setOnClickListener((View.OnClickListener) this);
        this.rlMain = (RelativeLayout) this.findViewById(R.id.ll_main);
        this.mimageview = (ImageView) this.findViewById(R.id.imageview_id);
        this.img_view = (TouchImageView) this.findViewById(R.id.imageview_main);
        this.layoutPip = (LinearLayout) this.findViewById(R.id.linear_pip);
        this.layoutStickers = (LinearLayout) this
                .findViewById(R.id.ll_stickers);
        this.emoticons_menu();
        this.imgbutton_1 = (ImageView) findViewById(R.id.imgView1);
        this.imgbutton_2 = (ImageView) findViewById(R.id.imgView2);
        this.imgbutton_3 = (ImageView) findViewById(R.id.imgView3);
        this.imgbutton_4 = (ImageView) findViewById(R.id.imgView4);
        this.imgbutton_5 = (ImageView) findViewById(R.id.imgView5);
        this.imgbutton_6 = (ImageView) findViewById(R.id.imgView6);
        this.imgbutton_7 = (ImageView) findViewById(R.id.imgView7);
        this.imgbutton_8 = (ImageView) findViewById(R.id.imgView8);
        this.imgbutton_9 = (ImageView) findViewById(R.id.imgView9);
        this.imgbutton_10 = (ImageView) findViewById(R.id.imgView10);
        this.imgbutton_11 = (ImageView) findViewById(R.id.imgView11);
        this.imgbutton_12 = (ImageView) findViewById(R.id.imgView12);
        this.imgbutton_13 = (ImageView) findViewById(R.id.imgView13);
        this.imgbutton_14 = (ImageView) findViewById(R.id.imgView14);
        this.imgbutton_15 = (ImageView) findViewById(R.id.imgView15);
        this.imgbutton_16 = (ImageView) findViewById(R.id.imgView16);
        this.imgbutton_17 = (ImageView) findViewById(R.id.imgView17);
        this.imgbutton_18 = (ImageView) findViewById(R.id.imgView18);
        this.imgbutton_19 = (ImageView) findViewById(R.id.imgView19);
        this.imgbutton_20 = (ImageView) findViewById(R.id.imgView20);
        this.imgbutton_21 = (ImageView) findViewById(R.id.imgView21);
        this.imgbutton_22 = (ImageView) findViewById(R.id.imgView22);
        this.imgbutton_23 = (ImageView) findViewById(R.id.imgView23);
        this.imgbutton_24 = (ImageView) findViewById(R.id.imgView24);
        this.imgbutton_25 = (ImageView) findViewById(R.id.imgView25);
        this.imgbutton_26 = (ImageView) findViewById(R.id.imgView26);
        this.imgbutton_27 = (ImageView) findViewById(R.id.imgView27);
        this.imgbutton_1.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_2.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_3.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_4.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_5.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_6.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_7.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_8.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_9.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_10.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_11.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_12.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_13.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_14.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_15.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_16.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_17.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_18.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_19.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_20.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_21.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_22.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_23.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_24.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_25.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_26.setOnClickListener((View.OnClickListener) this);
        this.imgbutton_27.setOnClickListener((View.OnClickListener) this);
    }

    protected void onRestoreInstanceState(final Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.ImageUri = (Uri) bundle.getParcelable("file_uri");
    }

    protected void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable("file_uri", this.ImageUri);
    }

    protected void onStart() {
        super.onStart();
    }

    public void onWindowFocusChanged(final boolean b) {
        super.onWindowFocusChanged(b);
        this.width = this.rlMain.getWidth();
        this.height = this.rlMain.getHeight();
        if (pipactivity.intSelectPip == 2) {
            this.SetPiP(Utility.int_pip_type);
        }
    }

    private void takeScreenshot(Bitmap bitmap, String storePath) {

        File file = null;
        if (Environment.getExternalStorageState().equals("mounted")) {
            File directory = new File(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(getResources().getString(R.string.app_name)).toString());

            if (!directory.exists()) {
                directory.mkdirs();
            }
            file = new File(directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png");
            str_urlShareimg = directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png";
        }

        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));

    }

    class DownloadAsync extends AsyncTask<Uri, Void, Bitmap> {
        protected Bitmap doInBackground(final Uri... array) {
            pipactivity.access1(pipactivity.this, array[0]);
            try {
                if (pipactivity.strImageType.equalsIgnoreCase("1")) {
                    return MediaStore.Images.Media.getBitmap(
                            pipactivity.this.getContentResolver(),
                            pipactivity.this.uri);
                }
                if (pipactivity.strImageType.equalsIgnoreCase("2")) {
                    final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
                    bitmapFactory$Options.inSampleSize = 4;
                    return BitmapFactory.decodeFile(
                            pipactivity.this.uri.getPath(),
                            bitmapFactory$Options);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(final Bitmap bitmap) {
            super.onPostExecute(bitmap);
            pipactivity.this.progressDialog.hide();
            if (bitmap == null) {
                return;
            }
            try {
                Utility.CropBitmap = Utility.getResizedBitmap(bitmap, 800);
                pipactivity.this.startActivityForResult(new Intent(
                        (Context) pipactivity.this,
                        (Class) CropActivity.class), 11);
                pipactivity.strImageType = "0";
                return;
            } catch (Exception ex) {
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
            pipactivity.this.progressDialog.show();
        }
    }

    private class saves extends AsyncTask<String, Void, Boolean> {
        protected Boolean doInBackground(final String... array) {
            pipactivity.this.getScreenSnapShot();
            return true;
        }

        protected void onPostExecute(final Boolean b) {
            pipactivity.this.progressDialog.hide();

            id = R.id.btnsave;
            if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                dialogAd.show();
                AdsDialogShow();
            } else {
                startActivity(new Intent(pipactivity.this, ShareActivity.class).putExtra("key", 3));
                finish();
            }
        }

        protected void onPreExecute() {
            pipactivity.this.progressDialog.show();
        }
    }
}
