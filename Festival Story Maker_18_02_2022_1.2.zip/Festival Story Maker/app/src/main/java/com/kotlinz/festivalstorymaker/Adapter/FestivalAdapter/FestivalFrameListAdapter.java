package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.R;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FestivalFrameListAdapter extends RecyclerView.Adapter<FestivalFrameListAdapter.MyViewHolder> {

    public Activity p;
    public List<String> q;
    public a r;
    public int s;
    public int t = 0;

    public FestivalFrameListAdapter(Activity activity, List<String> list, a aVar, int i) {
        this.p = activity;
        this.q = list;
        this.r = aVar;
        this.s = i;
    }

    public interface a {
        void a(int i, int i2);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_festival_frame_list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.cardMain.setCardElevation(t == position ? 10.0f : 0.0f);
        int i2 = 8;
        holder.imgPro.setVisibility(View.GONE);
        holder.rlBg.setBackgroundColor(this.p.getResources().getColor(R.color.white));
        holder.txtSelectFrame.setVisibility(position == 0 ? View.VISIBLE : View.GONE);
        ImageView imageView = holder.img;
        if (position != 0) {
            i2 = 0;
        }
        imageView.setVisibility(i2);
        if (((String) q.get(position)).length() > 0) {
            Glide.with(p).load(new File(q.get(position))).placeholder(R.drawable.ic_placehoder).into(holder.img);
        } else if (position != 0) {
            holder.img.setImageDrawable(p.getResources().getDrawable(R.drawable.ic_black_white_image));
            holder.rlBg.setPadding(3, 3, 3, 3);
            holder.rlBg.setBackgroundColor(p.getResources().getColor(R.color.black));
        }
        holder.rlBg.setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.m(this, position));
    }

    @Override
    public int getItemCount() {
        return q.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.cardMain)
        public CardView cardMain;
        @BindView(R.id.imgBg)
        public ImageView img;
        @BindView(R.id.imgPro)
        public ImageView imgPro;
        @BindView(R.id.rlBg)
        public RelativeLayout rlBg;
        @BindView(R.id.txtSelectFrame)
        public TextView txtSelectFrame;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
