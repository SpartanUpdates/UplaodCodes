package com.esc.dailyrandomfacts.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.RemoteViews;
import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.managers.CategoryManager;
import com.esc.dailyrandomfacts.managers.FavoritesManager;
import com.esc.dailyrandomfacts.managers.QuotesManager;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.managers.ThemeManager;
import com.esc.dailyrandomfacts.model.Quote;
import com.esc.dailyrandomfacts.model.Theme;
import com.esc.dailyrandomfacts.usecases.AddReadQuoteUsecase;
import com.esc.dailyrandomfacts.util.Constants;
import com.esc.dailyrandomfacts.util.JsonUtils;
import com.esc.dailyrandomfacts.util.QuoteUtils;
import com.esc.dailyrandomfacts.util.TrackerEventUtils;
import com.esc.dailyrandomfacts.activity.QuotesHomeActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class QuotesWidget extends AppWidgetProvider {
    private static ArrayList<String> quotesList = new ArrayList();

    private static int getCellsForSize(int i) {
        int i2 = 2;
        while ((i2 * 70) - 30 < i) {
            i2++;
        }
        return i2 - 1;
    }

    @SuppressLint("WrongConstant")
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        for (int i : iArr) {
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.quotes_widget);
            loadWidgetTheme(context, remoteViews);
            if (quotesList.isEmpty()) {
                loadQuotes(context);
            } else {
                int nextInt = new Random().nextInt(quotesList.size());
                Quote quote = QuoteUtils.getQuote(0, (String) quotesList.get(nextInt), true);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(quote.getText());
                stringBuilder.append(quote.getAuthor());
                remoteViews.setTextViewText(R.id.txtWidgetQuote, stringBuilder.toString());
                Intent intent = new Intent(context, QuotesHomeActivity.class);
                intent.putExtra(Constants.WIDGET_MESSAGE, (String) quotesList.get(nextInt));
                intent.addFlags(603979776);
                PendingIntent activity = PendingIntent.getActivity(context, 0, intent, 134217728);
                remoteViews.setOnClickPendingIntent(R.id.txtWidgetQuote, activity);
                remoteViews.setOnClickPendingIntent(R.id.linearHeader, activity);
                remoteViews.setOnClickPendingIntent(R.id.imgBg, activity);
                new AddReadQuoteUsecase((String) quotesList.get(nextInt)).execute();
            }
            appWidgetManager.updateAppWidget(i, remoteViews);
        }
    }

    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager, int i, Bundle bundle) {
        int i2 = appWidgetManager.getAppWidgetOptions(i).getInt("appWidgetMinHeight");
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.quotes_widget);
        if (getCellsForSize(i2) >= 3) {
            remoteViews.setTextViewTextSize(R.id.txtWidgetQuote, 2, 22.0f);
        } else if (getCellsForSize(i2) == 2) {
            remoteViews.setTextViewTextSize(R.id.txtWidgetQuote, 2, 20.0f);
        } else {
            remoteViews.setTextViewTextSize(R.id.txtWidgetQuote, 2, 13.0f);
        }
        appWidgetManager.updateAppWidget(i, remoteViews);
        super.onAppWidgetOptionsChanged(context, appWidgetManager, i, bundle);
    }

    public void onEnabled(Context context) {
        loadQuotes(context);
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_ADD_WIDGET, null, null);
    }

    public void onDisabled(Context context) {
        TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_REMOVE_WIDGET, null, null);
    }

    public void loadQuotes(Context context) {
        quotesList = new ArrayList();
        String categorySelected = CategoryManager.getCategorySelected();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context.getString(R.string.favorites_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        if (categorySelected.equals(stringBuilder.toString())) {
            quotesList.addAll(FavoritesManager.getFavorites());
            return;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(context.getString(R.string.default_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        if (categorySelected.equals(stringBuilder.toString())) {
            addQuotesByApp(context);
        } else {
            addQuotesFromFile(context.getResources().getIdentifier(categorySelected, "raw", context.getPackageName()), context);
        }
        removeReadQuotesAndSort();
    }

    private void addQuotesByApp(Context context) {
        String languageFiles = SettingsManager.getLanguageFiles();
        Resources resources = context.getResources();
        String packageName = context.getPackageName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("quotes");
        stringBuilder.append(languageFiles);
        addQuotesFromFile(resources.getIdentifier(stringBuilder.toString(), "raw", packageName), context);
    }

    public void addQuotesFromFile(int i, Context context) {
        ArrayList arrayList = new ArrayList();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(context.getResources().openRawResource(i), "utf-8"));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    quotesList.addAll(arrayList);
                    return;
                } else if (!(arrayList.contains(readLine) || quotesList.contains(readLine))) {
                    arrayList.add(readLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removeReadQuotesAndSort() {
        ArrayList readQuotes = QuotesManager.getReadQuotes();
        if (readQuotes != null) {
            quotesList.removeAll(readQuotes);
        }
        readQuotes = new ArrayList();
        ArrayList arrayList = new ArrayList();
        readQuotes.addAll(quotesList);
        Iterator it = readQuotes.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            int min = Math.min(10, arrayList.size());
            arrayList.add(Math.max(0, arrayList.size() - (min != 0 ? new Random().nextInt(min) : 0)), str);
        }
        quotesList.clear();
        quotesList.addAll(arrayList);
    }

    private void loadWidgetTheme(Context context, RemoteViews remoteViews) {
        Theme theme = ThemeManager.getTheme();
        if (theme == null || SettingsManager.getOwnBackground() != null) {
            theme = getDefaultTheme(context);
        }
        String str = "#";
        if (theme.getBackgroundImageName() != null) {
            remoteViews.setImageViewResource(R.id.imgBg, context.getResources().getIdentifier(theme.getBackgroundImageName(), "drawable", context.getPackageName()));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(theme.getBackground());
            int parseColor = Color.parseColor(stringBuilder.toString());
            remoteViews.setImageViewResource(R.id.imgBg, 0);
            remoteViews.setInt(R.id.imgBg, "setBackgroundColor", parseColor);
        }
        if (theme.getColor() != null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(theme.getColor());
            remoteViews.setTextColor(R.id.txtWidgetQuote, Color.parseColor(stringBuilder2.toString()));
        }
    }

    private Theme getDefaultTheme(Context context) {
        Iterator it = JsonUtils.getThemes(context).iterator();
        while (it.hasNext()) {
            Theme theme = (Theme) it.next();
            if (theme.getName().equalsIgnoreCase(context.getString(R.string.default_th))) {
                return theme;
            }
        }
        return null;
    }
}
