package com.esc.gesturelockscreen.Service;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.media.SoundPool;
import android.media.SoundPool.Builder;
import android.os.Build.VERSION;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import com.esc.gesturelockscreen.Other.Actions;
import com.esc.gesturelockscreen.Other.LockUIController;
import com.esc.gesturelockscreen.Other.SettingsKeys;
import com.esc.gesturelockscreen.Other.SettingsUtils;
import com.esc.gesturelockscreen.Service.ScreenLockService.ILockerService;
import com.esc.gesturelockscreen.R;
import androidx.core.view.InputDeviceCompat;

public class SignatureLockImpl implements SignatureLock {
  public static SignatureLockImpl _instance;
  private boolean isPreview = false;
  private boolean isSound = false;
  private final Context mContext;
  private LayoutParams mLayoutParam;
  private View mMainView;
  private PendingIntent mPe;
  private SoundPool mSoundPool;
  private WindowManager mWindowManager;
  private final ILockerService service;
  private int soundId = -1;

  @SuppressLint({"NewApi"})
  private void loadSound() {
    this.isSound = SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_SOUND, true);
    if (this.isSound) {
      SoundPool build;
      if (VERSION.SDK_INT >= 21) {
        build = new Builder().setMaxStreams(1).build();
      } else {
        build = new SoundPool(1, 3, 0);
      }
      this.mSoundPool = build;
      this.soundId = this.mSoundPool.load(this.mContext, R.raw.sound, 1);
    }
  }

  private void play() {
    if (this.isSound && this.mSoundPool != null) {
      this.mSoundPool.play(this.soundId, 1.0f, 1.0f, 1, 0, 1.0f);
    }
  }

  public SignatureLockImpl(ILockerService service) {
    _instance = this;
    this.mContext = service.getContext();
    this.service = service;
    SettingsUtils.init(this.mContext.getApplicationContext());
  }

  public void onStart(Intent intent) {
    this.isPreview = false;
    if (!(intent == null || intent.getAction() == null || !intent.getAction().equals(Actions.SERVICE_PREVIEW_LOCK))) {
      this.isPreview = true;
      if (!SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, false) && LockStateService.checkAndStartService(this.mContext, LockStateService.class)) {
        this.mContext.sendBroadcast(new Intent(Actions.BROADCAST_LOCK_ENABLED).setPackage(this.mContext.getPackageName()));
      }
    }
    if (!SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, false) && !this.isPreview) {
      this.service.onUnlock();
    } else if (this.mWindowManager == null) {
      ScreenLockService.isVisible = true;
      this.mWindowManager = (WindowManager) this.mContext.getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
      this.mMainView = LockUIController.getInstance().initView(this.mContext, this);
      this.mWindowManager.addView(this.mMainView, getViewParam(true));
      loadSound();
    }
  }

  @SuppressLint({"NewApi"})
  private LayoutParams getViewParam(boolean first) {
    LayoutParams params = new LayoutParams(-1, -1, 2010, 4718848, -3);
    if (null != null) {
      params.type = 2002;
    }
    if (VERSION.SDK_INT >= 19) {
      int height;
      if (null != null) {
        params.systemUiVisibility = 5378;
      } else {
        params.systemUiVisibility = InputDeviceCompat.SOURCE_TOUCHSCREEN;
      }
      Point point = new Point();
      this.mWindowManager.getDefaultDisplay().getRealSize(point);
      params.width = -1;
      if (point.y > point.x) {
        height = point.y;
      } else {
        height = point.x;
      }
      params.height = height;
      params.flags |= 268435456;
      params.flags |= 16777216;
      params.flags |= 67108864;
    }
    if (VERSION.SDK_INT >= 14 && VERSION.SDK_INT <= 18) {
      params.systemUiVisibility = 1;
      params.flags |= 268435456;
      params.flags |= 16777216;
      if (VERSION.SDK_INT >= 16 && null != null) {
        params.systemUiVisibility |= 1280;
      }
    } else if (VERSION.SDK_INT >= 11) {
      params.flags |= 16777216;
    }
    params.gravity = 49;
    params.softInputMode = 2;
    params.flags |= 131072;
    if (SettingsUtils.getBoolean(SettingsKeys.KEY_SHOW_LIVEWALLPAPER, true)) {
      params.flags |= 1048576;
    }
    params.screenOrientation = 5;
    this.mLayoutParam = params;
    return this.mLayoutParam;
  }

  @SuppressLint({"NewApi"})
  public void onStop(boolean destroy) {
    if (this.mWindowManager != null) {
      if (this.mMainView != null) {
        LockUIController.getInstance().unregister();
        play();
        if (VERSION.SDK_INT >= 14) {
          this.mLayoutParam.systemUiVisibility = 0;
          this.mWindowManager.updateViewLayout(this.mMainView, this.mLayoutParam);
        }
        this.mWindowManager.removeView(this.mMainView);
        if (!SettingsUtils.getBoolean(SettingsKeys.KEY_ENABLE_LOCKSCREEN, false) && this.isPreview) {
          this.mContext.sendBroadcast(new Intent(Actions.BROADCAST_LOCK_DISABLED).setPackage(this.mContext.getPackageName()));
        }
        if (VERSION.SDK_INT >= 19 && this.mPe != null) {
          try {
            this.mPe.send();
          } catch (CanceledException e) {
            e.printStackTrace();
          }
        }
        this.mMainView = null;
      }
      this.mWindowManager = null;
    }
    ScreenLockService.isVisible = false;
    if (this.service != null && destroy) {
      this.service.onUnlock();
    }
  }

  public void onScreenOn() {
    LockUIController.getInstance().onScreenOn();
  }

  public void onScreenOff() {
    LockUIController.getInstance().onScreenOff();
  }

  public void hide() {
    LockUIController.getInstance().onScreenOff();
    this.mMainView.setVisibility(View.GONE);
  }

  public void show() {
    this.mMainView.setVisibility(View.VISIBLE);
    LockUIController.getInstance().onScreenOn();
  }

  public LayoutParams getWindowLayoutParams() {
    return this.mLayoutParam;
  }

  public void setPendingIntent(PendingIntent pIntent) {
    this.mPe = pIntent;
  }
}
