package com.videozoneinc.musicvideoeditor.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.videozoneinc.musicvideoeditor.MyApplication;
import com.videozoneinc.musicvideoeditor.R;
import com.videozoneinc.musicvideoeditor.adapters.ImageEditAdapter;
import com.videozoneinc.musicvideoeditor.adapters.OnItemClickListner;
import com.videozoneinc.musicvideoeditor.modelclass.ImageData;
import com.videozoneinc.musicvideoeditor.util.ActivityAnimUtil;
import com.videozoneinc.musicvideoeditor.util.ImageEditor;
import com.videozoneinc.musicvideoeditor.util.Utils;
import com.videozoneinc.musicvideoeditor.view.EmptyRecyclerView;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import java.io.File;

public class Activity_ArrangeImage extends AppCompatActivity {
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isEdit = false;
    TextView textView;
    ItemTouchHelper.Callback callback = new ItemTouchHelper.Callback() {
        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
            return true;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int i) {
        }


        @Override
        public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int i) {
            if (i == 0) {
                Activity_ArrangeImage.this.imageEditAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onMoved(final RecyclerView recyclerView, final RecyclerView.ViewHolder recyclerView$ViewHolder, final int n, final RecyclerView.ViewHolder recyclerView$ViewHolder2, final int n2, final int n3, final int n4) {
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isStartFrameExist() && n2 == 0) {
                return;
            }
            if (MyApplication.isStoryAdded && Activity_ArrangeImage.this.isEndFrameExist() && n2 == Activity_ArrangeImage.this.application.selectedImages.size() - 1) {
                return;
            }
            Activity_ArrangeImage.this.imageEditAdapter.swap(recyclerView$ViewHolder.getAdapterPosition(), recyclerView$ViewHolder2.getAdapterPosition());
            Activity_ArrangeImage.this.application.min_pos = Math.min(Activity_ArrangeImage.this.application.min_pos, Math.min(n, n2));
            MyApplication.isBreak = true;
        }

        public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
            return makeFlag(2, 51);
        }
    };
    private MyApplication application;
    private ImageEditAdapter imageEditAdapter;
    private boolean isFromCameraNotification;
    public boolean isFromPreview = false;
    private EmptyRecyclerView rvSelectedImages;
    String tempImgPath;
    private Toolbar toolbar;


    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_images_arrange);
        if (Utils.checkPermission(this)) {
            this.isFromPreview = getIntent().hasExtra("extra_from_preview");
            this.application = MyApplication.getInstance();
            this.application.isEditModeEnable = true;
            bindView();
            init();
            loadAd();
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void bindView() {
        this.rvSelectedImages = (EmptyRecyclerView) findViewById(R.id.rvVideoAlbum);
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);

    }

    private void init() {
        setupAdapter();
        new ItemTouchHelper(this.callback).attachToRecyclerView(this.rvSelectedImages);
        setSupportActionBar(this.toolbar);
        textView = (TextView) this.toolbar.findViewById(R.id.toolbar_title);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        textView.setText(getString(R.string.swap_images));
        Utils.setFont(this, textView);
        this.isFromCameraNotification = getIntent().getExtras().getBoolean("isFromCameraNotification");
        if (getIntent().getExtras().getString("KEY").equals("FromImageSelection") || getIntent().getExtras().getString("KEY").equals("FromCameraService") || getIntent().getExtras().getString("KEY").equals("FromPreview")) {
            isEdit = true;
        }
    }

    private void setupAdapter() {
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(this, 2, 1, false);
        this.imageEditAdapter = new ImageEditAdapter(Activity_ArrangeImage.this);
        this.rvSelectedImages.setLayoutManager(gridLayoutManager);
        this.rvSelectedImages.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImages.setEmptyView(findViewById(R.id.list_empty));
        this.rvSelectedImages.setAdapter(this.imageEditAdapter);
        this.imageEditAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                Integer.parseInt((String) view.getTag());
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == ImageEditor.IMAGE_EDIT_ACTIVITY_TEXT_AND_STICKER && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData idata = new ImageData();
            idata.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, idata);
            setupAdapter();
        }
    }

    protected void onResume() {
        super.onResume();
        if (Utils.checkPermission(this)) {
            this.application.isEditModeEnable = true;
            if (this.imageEditAdapter != null) {
                this.imageEditAdapter.notifyDataSetChanged();
                return;
            }
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private boolean isEndFrameExist() {
        return Fragment_EndFrame.lastsaveTempPath != null ? new File(Fragment_EndFrame.lastsaveTempPath).exists() : false;
    }

    private boolean isStartFrameExist() {
        return new File(Fragment_StartFrame.lastsaveTempPath).exists();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        menu.removeItem(R.id.menu_clear);
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SubMenu subMenu = item.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int i2 = 0; i2 < subMenu.size(); i2++) {
                    Utils.applyFontToMenuItem(getApplicationContext(), subMenu.getItem(i2));
                }
            }
            Utils.applyFontToMenuItem(getApplicationContext(), item);
        }
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == android.R.id.home) {
            onBackPressed();
        } else if (itemId == R.id.menu_done) {
            addTitle();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void done() {
        this.application.isEditModeEnable = false;
        if (this.isFromPreview) {
            setResult(-1);
            finish();
            return;
        }
        ActivityAnimUtil.startActivitySafely(this.toolbar, new Intent(this, PreviewActivity.class));
    }

    private void addTitle() {
        Intent intent = new Intent(this, AddTitleActivity.class);
        intent.putExtra("ISFROMPREVIEW", this.isFromPreview);
        ActivityAnimUtil.startActivitySafely(this.toolbar, intent);
        if (this.isFromPreview) {
            finish();
        }
    }

    public void onBackPressed() {
        isEdit = false;
        if (this.isFromPreview && !this.isFromCameraNotification) {
            addTitleAlert();
        }
        if (this.isFromCameraNotification) {
            Intent intent = new Intent(this, PhotoselectActivity.class);
            intent.putExtra("isFromImageEditActivity", true);
            startActivity(intent);
            finish();
            return;
        }
        onBackDialog();
    }

    private void addTitleAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppAlertDialog);
        builder.setTitle(R.string.add_story_title);
        builder.setMessage(R.string.do_you_want_to_add_title_frame_);
        builder.setPositiveButton(R.string.yes, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Activity_ArrangeImage.this.application.isEditModeEnable = false;
                final Intent intent = new Intent((Context) Activity_ArrangeImage.this, (Class) AddTitleActivity.class);
                intent.putExtra("ISFROMPREVIEW", Activity_ArrangeImage.this.isFromPreview);
                ActivityAnimUtil.startActivitySafely((View) Activity_ArrangeImage.this.toolbar, intent);
                if (Activity_ArrangeImage.this.isFromPreview) {
                    Activity_ArrangeImage.this.finish();
                }
            }
        });
        builder.setNegativeButton(R.string.skip, new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Activity_ArrangeImage.this.done();
            }
        });
        builder.show();
    }

    private void onBackDialog() {
        new AlertDialog.Builder(this, R.style.Theme_MovieMaker_AlertDialog).setTitle(R.string.app_name).setMessage(R.string.your_changes_on_images_will_be_removed_are_you_sure_to_go_back_).setPositiveButton(R.string.go_back, new OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, final int n) {
                if (Activity_ArrangeImage.this.isFromPreview && !Activity_ArrangeImage.this.isFromCameraNotification) {
                    Activity_ArrangeImage.this.done();
                    return;
                }
                final Intent intent = new Intent((Context) Activity_ArrangeImage.this, (Class) PhotoselectActivity.class);
                intent.putExtra("isFromImageEditActivity", true);
                Activity_ArrangeImage.this.startActivity(intent);
                Activity_ArrangeImage.this.finish();
            }
        }).setNegativeButton(R.string.stay_here, null).create().show();
    }


    private void loadAd() {
        if (Utils.Utility.isNetworkAvailable(this)) {
            AdLoader adLoader = new AdLoader.Builder(this, getResources().getString(R.string.Admob_Native))
                    .forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                        @Override
                        public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                            NativeTemplateStyle styles = new
                                    NativeTemplateStyle.Builder().build();
                            TemplateView template = findViewById(R.id.my_template);
                            template.setStyles(styles);
                            template.setNativeAd(unifiedNativeAd);
                        }
                    })
                    .build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            findViewById(R.id.nativeAdLayout).setVisibility(View.GONE);
        }
    }
}
