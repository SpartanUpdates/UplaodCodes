package com.xyz.vehiclemanager.cardetails.carservice.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.carservice.model.ServiceCenterDetail;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarServiceDetailsAdapter extends RecyclerView.Adapter<CarServiceDetailsAdapter.MyViewHolder> {

    Context mcontext;
    private ArrayList<ServiceCenterDetail> carServiceDetailList;

    public CarServiceDetailsAdapter(Context mcontext, ArrayList<ServiceCenterDetail> carServiceDetailList) {
        this.mcontext = mcontext;
        this.carServiceDetailList = carServiceDetailList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_name;
        TextView tv_address;
        TextView tv_contact;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_address = itemView.findViewById(R.id.tv_address);
            tv_contact = itemView.findViewById(R.id.tv_contact);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_car_servicedetails,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        final ServiceCenterDetail carServiceDetail = carServiceDetailList.get(position);
        String contactNo = carServiceDetail.getContactNo();
        String address = carServiceDetail.getAddress();
        holder.tv_name.setText(carServiceDetail.getName());
        holder.tv_address.setText(carServiceDetail.getAddress());
        if(contactNo==null)
        {
            holder.tv_contact.setVisibility(View.GONE);
        }
        else
        {
            holder.tv_contact.setText(contactNo);
        }
        if(address==null)
        {
            holder.tv_address.setVisibility(View.GONE);
        }
        else
        {
            holder.tv_address.setText(address);
        }
    }

    @Override
    public int getItemCount() {
        return carServiceDetailList.size();
    }
}
