package com.esc.lovemessages;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static String DB_NAME = "wifemsg";
    private static String DB_PATH = "";
    private static String TAG = "DataBaseHelper";
    File dbFile;
    private final Context mContext;
    private SQLiteDatabase mDataBase;
    ArrayList<String> qid =new ArrayList<>();

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        String str = "/databases/";
        StringBuilder stringBuilder;
        if (VERSION.SDK_INT >= 17) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(context.getApplicationInfo().dataDir);
            stringBuilder.append(str);
            DB_PATH = stringBuilder.toString();
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("/data/data/");
            stringBuilder.append(context.getPackageName());
            stringBuilder.append(str);
            DB_PATH = stringBuilder.toString();
        }
        this.mContext = context;
    }

    public void createDataBase() throws IOException {
        getReadableDatabase();
        close();
        try {
            copyDataBase();
            Log.e(TAG, "createDatabase database created");
            int i = 0;
            while (i < this.qid.size()) {
                try {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("favorite", Integer.valueOf(1));
                    this.mDataBase = getWritableDatabase();
                    try {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("msg_id=");
                        stringBuilder.append((String) this.qid.get(i));
                        this.mDataBase.update("message", contentValues, stringBuilder.toString(), null);
                    } catch (Exception unused) {
                    }
                    i++;
                } catch (Exception unused2) {
                    return;
                }
            }
        } catch (IOException e) {
            String str = TAG;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(e);
            Log.e(str, stringBuilder2.toString());
            throw new Error("ErrorCopyingDataBase"+e.getMessage());
        }
    }



    private void copyDataBase() throws IOException {
        InputStream open = this.mContext.getAssets().open(DB_NAME);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(stringBuilder.toString());
        byte[] bArr = new byte[1024];
        while (true) {
            int read = open.read(bArr);
            if (read > 0) {
                fileOutputStream.write(bArr, 0, read);
            } else {
                fileOutputStream.flush();
                fileOutputStream.close();
                open.close();
                return;
            }
        }
    }

    public boolean openDataBase() throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        this.mDataBase = SQLiteDatabase.openDatabase(stringBuilder.toString(), null, 268435456);
        return this.mDataBase != null;
    }

    public synchronized void close() {
        if (this.mDataBase != null) {
            this.mDataBase.close();
        }
        super.close();
    }

    public ArrayList<String> getPg_Id() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select pg_id from pageinfo where premium = 0", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getPg_Title() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select pg_title from pageinfo where premium = 0", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getMsgId(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg_id from messagedetail where pg_id=");
        stringBuilder.append(str);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getMsg(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg from message where msg_id IN(select msg_id from messagedetail where pg_id=");
        stringBuilder.append(str);
        stringBuilder.append(")");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getImage(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        String str2 = "select image from message where msg_id IN(select msg_id from messagedetail where pg_id=";
        stringBuilder.append(str2);
        stringBuilder.append(str);
        String str3 = ")";
        stringBuilder.append(str3);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        stringBuilder = new StringBuilder();
        stringBuilder.append(str2);
        stringBuilder.append(str);
        stringBuilder.append(str3);
        Log.e("****", stringBuilder.toString());
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getFav(String str) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select favorite from message where msg_id IN(select msg_id from messagedetail where pg_id=");
        stringBuilder.append(str);
        stringBuilder.append(")");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public boolean updateFavorite(int i, int i2) {
        String str = " ";
        String str2 = "Update";
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("favorite", Integer.valueOf(i));
            this.mDataBase = getWritableDatabase();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("msg_id=");
            stringBuilder.append(i2);
            int update = this.mDataBase.update("message", contentValues, stringBuilder.toString(), null);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("informationupdated ");
            stringBuilder2.append(Integer.toString(update));
            stringBuilder2.append(str);
            stringBuilder2.append(Integer.toString(i2));
            stringBuilder2.append(str);
            stringBuilder2.append(Integer.toString(i));
            Log.e(str2, stringBuilder2.toString());
            this.mDataBase.close();
            return true;
        } catch (Exception e) {
            this.mDataBase.close();
            Log.d(str2, e.toString());
            return false;
        }
    }

    public String getUrl(String str) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select pg_url from pageinfo where pg_id=");
        stringBuilder.append(str);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        String str2 = "";
        while (rawQuery.moveToNext()) {
            str2 = rawQuery.getString(0);
        }
        this.mDataBase.close();
        rawQuery.close();
        return str2;
    }

    public ArrayList<String> getFavUrl() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select pg_url From pageinfo pg , messagedetail md, message m where pg.pg_id = md.pg_id and md.msg_id = m.msg_id and m.favorite =1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public String getCat(String str) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sectionid from pageinfo where pg_id=");
        stringBuilder.append(str);
        str = stringBuilder.toString();
        String str2 = null;
        Cursor rawQuery = sQLiteDatabase.rawQuery(str, null);
        while (rawQuery.moveToNext()) {
            str2 = rawQuery.getString(0);
        }
        this.mDataBase.close();
        rawQuery.close();
        return str2;
    }

    public ArrayList<String> getFavCat() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select sectionId From pageinfo pg , messagedetail md, message m where pg.pg_id = md.pg_id and md.msg_id = m.msg_id and m.favorite =1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getFavMsg() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select msg from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getFavMsgId() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select msg_id from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getFavImage() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select image from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getFavFav() {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor rawQuery = this.mDataBase.rawQuery("select favorite from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        this.mDataBase.close();
        rawQuery.close();
        return arrayList;
    }

    public ArrayList<String> getPremiumMessages(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg from message where msg_id IN(select msg_id from messagedetail where pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(")");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getPremiumMessagesid(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg_id from message where msg_id IN(select msg_id from messagedetail where pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(")");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public String getPremiumMessagesURL(int i) {
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select pg_url from pageinfo where pg_id=");
        stringBuilder.append(i);
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        String str = "";
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public ArrayList<Integer> getPremiumMessagesFavorite(int i) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        SQLiteDatabase sQLiteDatabase = this.mDataBase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select favorite from message where msg_id IN(select msg_id from messagedetail where pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(")");
        Cursor rawQuery = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }
}
