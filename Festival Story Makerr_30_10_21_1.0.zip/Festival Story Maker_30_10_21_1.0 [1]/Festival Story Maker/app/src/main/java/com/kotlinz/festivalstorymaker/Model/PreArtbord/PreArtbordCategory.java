package com.kotlinz.festivalstorymaker.Model.PreArtbord;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class PreArtbordCategory {

	@SerializedName("image")
	private String image;

	@SerializedName("content_id")
	private String contentId;

	@SerializedName("parent_id")
	private String parentId;

	@SerializedName("type_id")
	private String typeId;

	@SerializedName("name")
	private String name;

	@SerializedName("parent_category")
	private ArrayList<Object> parentCategory;

	@SerializedName("id")
	private String id;

	public String getImage(){
		return image;
	}

	public String getContentId(){
		return contentId;
	}

	public String getParentId(){
		return parentId;
	}

	public String getTypeId(){
		return typeId;
	}

	public String getName(){
		return name;
	}

	public ArrayList<Object> getParentCategory(){
		return parentCategory;
	}

	public String getId(){
		return id;
	}
}