package com.unitedvideos.CropView.imagezoomcrop.demo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.CropView.imagezoomcrop.cropoverlay.CropOverlayView;
import com.unitedvideos.CropView.imagezoomcrop.photoview.IGetImageBounds;
import com.unitedvideos.CropView.imagezoomcrop.photoview.PhotoView;
import com.unitedvideos.CropView.imagezoomcrop.photoview.RotationSeekBar;
import com.unitedvideos.R;
import com.unitedvideos.activity.ArrangePhotosActivity;
import com.unitedvideos.activity.ImageSelectionActivity;
import com.unitedvideos.application.MyApplication;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeBannerAd;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

public class ImageCropActivity extends Activity {
    public static final String TAG = "ImageCropActivity";
    private static final int ANCHOR_CENTER_DELTA = 10;
    PhotoView mImageView;
    CropOverlayView mCropOverlayView;
    RotationSeekBar mRotationBar;
    private ContentResolver mContentResolver;
    private final int IMAGE_MAX_SIZE = 1024;
    private final Bitmap.CompressFormat mOutputFormat;
    private String mImagePath;
    private Uri mSaveUri;
    private Uri mImageUri;
    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    public static final int REQUEST_CODE_PICK_GALLERY = 1;
    public static final int REQUEST_CODE_TAKE_PICTURE = 2;
    public static final int REQUEST_CODE_CROPPED_PICTURE = 3;
    public static final String ERROR_MSG = "error_msg";
    public static final String ERROR = "error";
    String[] mAllPath;
    String mConcatPath;
    int last_crop_idx;
    Utils mUtils;
    String save_path;
    ArrayList<String> mAllSavePath;
    int pera_h;
    int pera_w;
    public static int flag;
    RelativeLayout rl_skip;
    RelativeLayout rl_undo;
    RelativeLayout rl_crop;
    TextView tvtitle;
    TextView tv_skip;
    //    TextView tv_undo;
//    TextView tv_crop;
    TextView tv_instruct_line_one;
    TextView tv_instruct_line_two;
    ImageView ivback;
    Toolbar toolbar;
    SeekBar sb_skipall;
    RelativeLayout rl_progress;
    public int SkipAllPercent;
    public boolean IsSkipAllEnable;
    TextView tv_skipall_prg;
    RelativeLayout rl_skipall_root, rl_AutoCrop;
    private View.OnClickListener btnDoneListerner;
    private View.OnClickListener btnResetListerner;
    private View.OnClickListener btnSkipListener;
    private View.OnClickListener btnSkipAllListener;
    private MyApplication application;
    private boolean IsUpdateImage;
    String iscut;
    String isfrom;

    public ImageCropActivity() {
        this.mOutputFormat = Bitmap.CompressFormat.JPEG;
        this.mSaveUri = null;
        this.mImageUri = null;
        this.mConcatPath = "";
        this.last_crop_idx = -1;
        this.save_path = null;
        this.mAllSavePath = new ArrayList<String>();
        this.pera_h = -1;
        this.pera_w = -1;
        this.SkipAllPercent = 0;
        this.IsSkipAllEnable = false;
        this.btnDoneListerner = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View v) {
                new SaveSingleAsynk().execute(new Void[0]);
            }
        };
        this.btnResetListerner = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View v) {
                ImageCropActivity.this.mRotationBar.reset();
                ImageCropActivity.this.mImageView.reset();
            }
        };
        this.btnSkipListener = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View v) {
                ImageCropActivity.this.makeSingleSkip();
            }
        };

        this.btnSkipAllListener = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View v) {
                MyApplication.SkipAll = true;
                ImageCropActivity.this.rl_skipall_root.setVisibility(View.VISIBLE);
                ImageCropActivity.this.slideUpDown();
                ImageCropActivity.this.IsSkipAllEnable = true;
                final Handler mAnimHandler = new Handler();
                mAnimHandler.postDelayed((Runnable) new Runnable() {
                    @Override
                    public void run() {
                        new SaveSingleAsynk().execute(new Void[0]);
                    }
                }, 600L);
            }
        };

    }

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_crop_image);
        application = MyApplication.getInstance();
        MyApplication.SkipAll = false;
        ImageCropActivity.flag = 0;
        this.mUtils = new Utils();
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageCropActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        loadAd();
        this.mContentResolver = this.getContentResolver();
        this.mImageView = (PhotoView) this.findViewById(R.id.iv_photo);
        this.mCropOverlayView = (CropOverlayView) this.findViewById(R.id.crop_overlay);
        final int[] hw = this.getIntent().getIntArrayExtra("hw");
        this.pera_h = hw[0];
        this.pera_w = hw[1];
        CropOverlayView.setHW(this.pera_h, this.pera_w);
        this.mCropOverlayView.init((Context) this);
        this.rl_skip = (RelativeLayout) this.findViewById(R.id.rlSkipSingleForActivityCrop);
        this.rl_undo = (RelativeLayout) this.findViewById(R.id.rlUndoForImageCrop);
        this.rl_crop = (RelativeLayout) this.findViewById(R.id.rlCropForImgCrop);
        rl_AutoCrop = findViewById(R.id.rlAutocrop);
        tvtitle = findViewById(R.id.tool_title);
        ivback = findViewById(R.id.ivBack);
        this.mRotationBar = (RotationSeekBar) this.findViewById(R.id.slider_view_seek_bar);
        this.rl_skip.setOnClickListener(this.btnSkipListener);
        this.rl_AutoCrop.setOnClickListener(this.btnSkipAllListener);
        this.rl_crop.setOnClickListener(this.btnDoneListerner);
        this.rl_undo.setOnClickListener(this.btnResetListerner);
        this.toolbar = (Toolbar) this.findViewById(R.id.toolbar);

        this.tv_skip = (TextView) this.findViewById(R.id.tv_skip);
//        this.tv_undo = (TextView) this.findViewById(R.id.tv_undo);
//        this.tv_crop = (TextView) this.findViewById(R.id.tv_crop);
        this.tv_instruct_line_one = (TextView) this.findViewById(R.id.tv_instruct_line_one);
        this.tv_instruct_line_two = (TextView) this.findViewById(R.id.tv_instruct_line_two);
        this.rl_progress = (RelativeLayout) this.findViewById(R.id.rl_progress);
        (this.sb_skipall = (SeekBar) this.findViewById(R.id.sb_skipall)).setEnabled(false);
        this.tv_skipall_prg = (TextView) this.findViewById(R.id.tv_skipall_prg);
        (this.rl_skipall_root = (RelativeLayout) this.findViewById(R.id.rl_skipall_root)).setOnTouchListener((View.OnTouchListener) new View.OnTouchListener() {
            public boolean onTouch(final View arg0, final MotionEvent arg1) {
                return true;
            }
        });
        this.setAllFont();
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.mImageView.setImageBoundsListener(new IGetImageBounds() {
            @Override
            public Rect getImageBounds() {
                return ImageCropActivity.this.mCropOverlayView.getImageBounds();
            }
        });
        this.mRotationBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) new RotationSeekBar.OnRotationSeekBarChangeListener(this.mRotationBar) {
            private float mLastAngle;

            @Override
            public void onRotationProgressChanged(@NonNull final RotationSeekBar seekBar, final float angle, final float delta, final boolean fromUser) {
                this.mLastAngle = angle;
                if (fromUser) {
                    ImageCropActivity.this.mImageView.setRotationBy(delta, false);
                }
            }

            @Override
            public void onStopTrackingTouch(final SeekBar seekBar) {
                super.onStopTrackingTouch(seekBar);
                if (Math.abs(this.mLastAngle) < 10.0f) {
                    ImageCropActivity.this.mRotationBar.reset();
                    ImageCropActivity.this.mImageView.setRotationBy(0.0f, true);
                }
            }
        });
        IsUpdateImage = getIntent().getBooleanExtra("Imageupdate", false);
        iscut = getIntent().getStringExtra("isCut");
        isfrom = getIntent().getStringExtra("isfrom");
        Log.e("TAG", "Imagecrop update: " + IsUpdateImage);
        Log.e("TAG", "Imagecrop isCut : " + iscut);
        Log.e("TAG", "Imagecrop isfrom: " + isfrom);
        this.setImageBunch();
    }

    private NativeAdLayout nativeAdLayout;
    private LinearLayout adView;
    private NativeBannerAd nativeBannerAd;
    private InterstitialAd interstitialAd;

    private void loadAd() {
        /*nativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_nativebanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (nativeBannerAd == null || nativeBannerAd != ad) {
                    return;
                }
                inflateAd(nativeBannerAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        if (com.xyz.Uvvideos.Photo.Slideshow.SupportClasses.MyStudioData.Utils.checkConnectivity(ImageCropActivity.this, false)) {
            nativeBannerAd.loadAd();
        } else {
            findViewById(R.id.banner_container).setVisibility(View.GONE);
        }


        interstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Intent intent = new Intent(ImageCropActivity.this, ArrangePhotosActivity.class);
                intent.putExtra("update", Updateimage);
                intent.putExtra("isCut", iscut);
                intent.putExtra("isfrom", isfrom);
                Log.e(TAG, "startResultAct: " + iscut);
                startActivity(intent);
                ImageCropActivity.this.finish();
                interstitialAd.loadAd();

            }
        });
        interstitialAd.loadAd();*/
    }

    private void inflateAd(NativeBannerAd nativeBannerAd) {
//        nativeBannerAd.unregisterView();
//        nativeAdLayout = findViewById(R.id.banner_container);
//        LayoutInflater inflater = LayoutInflater.from(ImageCropActivity.this);
//        adView = (LinearLayout) inflater.inflate(R.layout.native_banner_ad_unit, nativeAdLayout, false);
//        nativeAdLayout.addView(adView);
//        RelativeLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
//        AdOptionsView adOptionsView = new AdOptionsView(ImageCropActivity.this, nativeBannerAd, nativeAdLayout);
//        adChoicesContainer.removeAllViews();
//        adChoicesContainer.addView(adOptionsView, 0);
//        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
//        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
//        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
//        AdIconView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
//        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);
//        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
//        nativeAdCallToAction.setVisibility(
//                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
//        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
//        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
//        sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());
//        List<View> clickableViews = new ArrayList<>();
//        clickableViews.add(nativeAdTitle);
//        clickableViews.add(nativeAdCallToAction);
//        nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
    }

    public void setAllFont() {
//        UtilsData.Toolbarfont(this, tvtitle);
//        UtilsData.Textfont(this, tv_skip);
//        UtilsData.Textfont(this,tv_undo);
//        UtilsData.Textfont(this,tv_crop);
//        UtilsData.Textfont(this, tv_instruct_line_one);
//        UtilsData.Textfont(this, tv_instruct_line_two);

        for (int i = 0; i < this.toolbar.getChildCount(); ++i) {
            final View view = this.toolbar.getChildAt(i);
            if (view instanceof TextView) {
                final TextView tv = (TextView) view;
                if (tv.getText().equals(this.toolbar.getTitle())) {
                    tv.setTextSize(18.0f);
//                    UtilsData.Textfont(this, tv);
                    break;
                }
            }
        }
    }

    public void setFont(final Context mContext, final TextView tv) {
        final Typeface typeFace = Typeface.createFromAsset(mContext.getAssets(), "fonts/Ubuntu-R.ttf");
        tv.setTypeface(typeFace);
    }

    protected void onStart() {
        super.onStart();
    }

    private void init() {
        final Bitmap bitmap = this.getBitmap(this.mImageUri);
        final Drawable drawable = (Drawable) new BitmapDrawable(this.getResources(), bitmap);
        final float minScale = this.mImageView.setMinimumScaleToFit(drawable);
        this.mImageView.setMaximumScale(minScale * 3.0f);
        this.mImageView.setMediumScale(minScale * 2.0f);
        this.mImageView.setScale(minScale);
        this.mImageView.setImageDrawable(drawable);
        if (this.IsSkipAllEnable) {
            final Handler mLayoutHandler = new Handler();
            mLayoutHandler.postDelayed((Runnable) new Runnable() {
                @Override
                public void run() {
                    new SaveSingleAsynk().execute(new Void[0]);
                }
            }, 500L);
        }
    }

    public boolean saveCropResult() {
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        final String file_path = this.getOutFilePath(this.mAllPath[this.last_crop_idx], this.last_crop_idx);
        Bitmap croppedImage = null;
        try {
            croppedImage = this.mImageView.getCroppedImage();
            this.mSaveUri = Utils.getImageUri(file_path);
            if (this.mSaveUri != null) {
                OutputStream outputStream = null;
                try {
                    outputStream = this.mContentResolver.openOutputStream(this.mSaveUri);
                    if (outputStream != null) {
                        croppedImage.compress(this.mOutputFormat, 90, outputStream);
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                } finally {
                    this.closeSilently(outputStream);
                }
                this.closeSilently(outputStream);
                this.mAllSavePath.add(file_path);
                croppedImage.recycle();
                return true;
            }
            Log.e("ImageCropActivity", "not defined image url");
            return false;
        } catch (IllegalArgumentException e) {
            return false;
        } catch (Exception e2) {
            return false;
        }
    }

    public void slideUpDown() {
        if (!this.isPanelShown()) {
            final Animation bottomUp = AnimationUtils.loadAnimation((Context) this, R.anim.player_bottom_up);
            this.rl_progress.setVisibility(View.VISIBLE);
            this.rl_progress.startAnimation(bottomUp);
        } else {
            final Animation bottomDown = AnimationUtils.loadAnimation((Context) this, R.anim.player_bottom_down);
            this.rl_progress.startAnimation(bottomDown);
            this.rl_progress.setVisibility(View.GONE);
        }
    }

    private boolean isPanelShown() {
        return this.rl_progress.getVisibility() == View.VISIBLE;
    }

    public void makeSingleSkip() {
        final File src = new File(this.mAllPath[this.last_crop_idx]);
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        final String file_path = this.getOutFilePath(this.mAllPath[this.last_crop_idx], this.last_crop_idx);
        final File dst = new File(file_path);
        try {
            Utils.copy(src, dst);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.mAllSavePath.add(file_path);
        this.startCropFor();
    }

    public void saveSkipAll() {
        final int startIdx = this.mAllSavePath.size();
        if (this.save_path == null) {
            this.save_path = this.mUtils.getAppTempAudioPath();
        }
        for (int i = startIdx; i < this.mAllPath.length; ++i) {
            final File src = new File(this.mAllPath[i]);
            final String file_path = this.getOutFilePath(this.mAllPath[i], i);
            final File dst = new File(file_path);
            try {
                Utils.copy(src, dst);
                this.mAllSavePath.add(file_path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void setImageBunch() {
        String ConcatPath = null;
        ConcatPath = this.getIntent().getStringExtra("path");
        Log.e(TAG, "setImageBunch:" + ConcatPath);
        if (!ConcatPath.equals("")) {
            final String[] allPath = ConcatPath.split("\\" + MyApplication.SPLIT_PATTERN);
            this.mAllPath = allPath;
            this.mConcatPath = ConcatPath;
            this.startCropFor();
        } else {
            Toast.makeText((Context) this, (CharSequence) "No Img Found", Toast.LENGTH_SHORT).show();
        }


    }

    public void startCropFor() {
        ++this.last_crop_idx;
        if (this.last_crop_idx < this.mAllPath.length) {
            this.mImagePath = this.mAllPath[this.last_crop_idx];
            this.mSaveUri = Utils.getImageUri(this.mImagePath);
            this.mImageUri = Utils.getImageUri(this.mImagePath);
            this.init();
        } else {
            this.last_crop_idx = this.mAllPath.length - 1;
            this.startResultAct();
        }
    }

    public void startResultAct() {
        if (this.mAllSavePath.size() > 0) {
            String result_conc = "";
            result_conc = this.mAllSavePath.get(0);
            Log.e("Result Count", "==" + result_conc);
            if (IsUpdateImage) {
                application.cropimaglist.clear();

            }
            for (int i = 0; i < this.mAllSavePath.size(); ++i) {
                Log.e("Result " + i, "==" + result_conc);
                result_conc = String.valueOf(result_conc) + MyApplication.SPLIT_PATTERN + this.mAllSavePath.get(i);

                application.AddCropImages(mAllSavePath.get(i));
                Log.e(TAG, "mAllSavePath--------------: " + mAllSavePath.get(i));
            }

            if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                interstitialAd.show();
            } else {
                Intent intent = new Intent(ImageCropActivity.this, ArrangePhotosActivity.class);
                intent.putExtra("hight", pera_h);
                intent.putExtra("width", pera_w);
                intent.putExtra("Imageupdate", IsUpdateImage);
                intent.putExtra("isCut", iscut);
                intent.putExtra("isfrom", isfrom);
                Log.e(TAG, "startResultAct: " + iscut);
                startActivity(intent);
                ImageCropActivity.this.finish();
            }
        } else {
            Toast.makeText(this, (CharSequence) "No Img Found", Toast.LENGTH_SHORT).show();
        }
    }

    public String getOutFilePath(final String inPath, final int count) {
        final File forname = new File(inPath);
        String ext = forname.getName();
        ext = ext.substring(ext.lastIndexOf("."));
        final String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        final String file_path = String.valueOf(this.save_path) + timeStamp + "_" + count + "_" + ext;
        return file_path;
    }

    public void onSaveInstanceState(final Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putBoolean("restoreState", true);
    }

    private void pickImage() {
        final Intent intent = new Intent("android.intent.action.GET_CONTENT").setType("image/*");
        try {
            this.startActivityForResult(intent, 1);
        } catch (ActivityNotFoundException e) {
            Toast.makeText((Context) this, (CharSequence) "No image source available", Toast.LENGTH_SHORT).show();
        }
    }

    private static void copyStream(final InputStream input, final OutputStream output) throws IOException {
        final byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = input.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
    }

    private Bitmap getBitmap(final Uri uri) {
        InputStream in = null;
        Bitmap returnedBitmap = null;
        try {
            in = this.mContentResolver.openInputStream(uri);
            final BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, (Rect) null, o);
            in.close();
            int scale = 1;
            if (o.outHeight > 1024 || o.outWidth > 1024) {
                scale = (int) Math.pow(2.0, (int) Math.round(Math.log(1024.0 / Math.max(o.outHeight, o.outWidth)) / Math.log(0.5)));
            }
            final BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            in = this.mContentResolver.openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(in, (Rect) null, o2);
            in.close();
            final ExifInterface ei = new ExifInterface(uri.getPath());
            final int orientation = ei.getAttributeInt("Orientation", 1);
            switch (orientation) {
                case 6: {
                    returnedBitmap = this.rotateImage(bitmap, 90.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                case 3: {
                    returnedBitmap = this.rotateImage(bitmap, 180.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                case 8: {
                    returnedBitmap = this.rotateImage(bitmap, 270.0f);
                    bitmap.recycle();
                    bitmap = null;
                    break;
                }
                default: {
                    returnedBitmap = bitmap;
                    break;
                }
            }
            return returnedBitmap;
        } catch (FileNotFoundException e) {
            Log.e("", "ERR " + e);
        } catch (IOException e2) {
            Log.e("", "ERR " + e2);
        }
        return null;
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(final MenuItem item) {
        final int itmId = item.getItemId();
        if (itmId == 16908332) {
//            super.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void closeSilently(final Closeable c) {
        if (c == null) {
            return;
        }
        try {
            c.close();
        } catch (Throwable t) {
        }
    }

    private Bitmap rotateImage(final Bitmap source, final float angle) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    class SaveSingleAsynk extends AsyncTask<Void, Void, Void> {
        ProgressDialog pDialog;
        boolean isCropSuccess;
        int fullLen;

        SaveSingleAsynk() {
            this.isCropSuccess = false;
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.fullLen = ImageCropActivity.this.mAllPath.length;
            ImageCropActivity.this.rl_crop.setEnabled(false);
            ImageCropActivity.this.tv_skipall_prg.setText((CharSequence) (String.valueOf(ImageCropActivity.this.last_crop_idx + 1) + "/" + this.fullLen));
            ImageCropActivity.this.SkipAllPercent = (ImageCropActivity.this.last_crop_idx + 1) * 100 / this.fullLen;
            ImageCropActivity.this.sb_skipall.setProgress(ImageCropActivity.this.SkipAllPercent);
        }

        protected Void doInBackground(final Void... arg0) {
            this.isCropSuccess = ImageCropActivity.this.saveCropResult();
            return null;
        }

        protected void onPostExecute(final Void result) {
            super.onPostExecute(result);
            ImageCropActivity.this.mRotationBar.reset();
            ImageCropActivity.this.mImageView.reset();
            ImageCropActivity.this.rl_crop.setEnabled(true);
            if (this.pDialog != null && this.pDialog.isShowing()) {
                this.pDialog.dismiss();
            }
            ImageCropActivity.this.tv_skipall_prg.setText((CharSequence) (String.valueOf(ImageCropActivity.this.last_crop_idx + 1) + "/" + this.fullLen));
            ImageCropActivity.this.SkipAllPercent = (ImageCropActivity.this.last_crop_idx + 1) * 100 / this.fullLen;
            ImageCropActivity.this.sb_skipall.setProgress(ImageCropActivity.this.SkipAllPercent);
            if (this.isCropSuccess) {
                ImageCropActivity.this.startCropFor();
            } else {
                ImageCropActivity.this.makeSingleSkip();
            }
        }
    }

    class SkipAllAsynk extends AsyncTask<Void, Void, Void> {
        ProgressDialog pDialog;

        protected void onPreExecute() {
            super.onPreExecute();
            (this.pDialog = new ProgressDialog((Context) ImageCropActivity.this)).setTitle((CharSequence) "Please wait");
            this.pDialog.setMessage((CharSequence) "Loading Image...");
            this.pDialog.setCancelable(false);
            this.pDialog.setCanceledOnTouchOutside(false);
            this.pDialog.show();
        }

        protected Void doInBackground(final Void... arg0) {
            ImageCropActivity.this.saveSkipAll();
            return null;
        }

        protected void onPostExecute(final Void result) {
            super.onPostExecute(result);
            if (this.pDialog != null && this.pDialog.isShowing()) {
                this.pDialog.dismiss();
            }
            ImageCropActivity.this.startResultAct();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (IsUpdateImage) {
            application.IsBack = true;
            Intent intent = new Intent(ImageCropActivity.this, ImageSelectionActivity.class);
            intent.putExtra("hight", pera_h);
            intent.putExtra("width", pera_w);
            intent.putExtra("Imageupdate", IsUpdateImage);
            intent.putExtra("isCut", iscut);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        } else {
            application.IsBack = true;
            Intent intent = new Intent(ImageCropActivity.this, ImageSelectionActivity.class);
            intent.putExtra("hight", pera_h);
            intent.putExtra("width", pera_w);
            intent.putExtra("Imageupdate", IsUpdateImage);
            intent.putExtra("isCut", iscut);
            intent.putExtra("isfrom", isfrom);
            startActivity(intent);
            finish();
        }
    }
}
