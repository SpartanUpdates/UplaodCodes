package com.kotlinz.festivalstorymaker.RetrofitApiCall;

import android.os.Environment;
import java.io.File;

public class AppConstant {

    public static String BaseUrl = "http://sociallyapp.trendinganimations.com/public/api/";
    public static String token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "36";

    public static int CollageBackgroundId = 71;

    public static String TempCameraImageName = "tempImage.png";
    public static String CameraImageFilePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + "Festival Story Maker" + File.separator + "Temp";

    public static String FestivalBusinessTemplate = "28";
}
