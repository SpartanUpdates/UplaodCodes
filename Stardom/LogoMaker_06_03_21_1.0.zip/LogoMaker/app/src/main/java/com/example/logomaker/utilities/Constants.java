package com.example.logomaker.utilities;

import java.io.File;

public class Constants {
    public static final String D_NAME = "LogoMakerFree";
    public static final int PHOTO_PICK = 1001;
    public static final String SELECTED_ITEM = "EXTRA_ITEM";
    public static final String TEMP_FILE_NAME = "temp_file.jpeg";
    public static int choose;
    public static File filetosave;
}

