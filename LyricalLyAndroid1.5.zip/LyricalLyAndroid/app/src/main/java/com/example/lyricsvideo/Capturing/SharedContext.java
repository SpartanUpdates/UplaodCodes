package com.example.lyricsvideo.Capturing;

import android.graphics.SurfaceTexture;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

public class SharedContext
{
  private static final String TAG = "SharedContext";
  private EGL10 egl;
  private EGLContext eglContext;
  private EGLDisplay eglDisplay;
  EGLConfig auxConfig;
  private EGLSurface auxSurface;
  private static final int EGL_CONTEXT_CLIENT_VERSION = 12440;
  private static final int EGL_OPENGL_ES2_BIT = 4;
  private int[] textures;
  private SurfaceTexture surfaceTexture;
  final int[] auxConfigAttribs;

  SharedContext() {
    this.auxSurface = null;
    this.textures = new int[1];
    this.auxConfigAttribs = new int[] { 12339, 4, 12352, 4, 12324, 8, 12323, 8, 12322, 8, 12321, 0, 12325, 0, 12326, 0, 12344 };
    try {
      this.egl = (EGL10)EGLContext.getEGL();
      this.eglDisplay = this.egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
      if (this.eglDisplay == EGL10.EGL_NO_DISPLAY) {
        Log.e("SharedContext", "--- eglGetDisplay failed: " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
      }
      final int[] version = new int[2];
      if (!this.egl.eglInitialize(this.eglDisplay, version)) {
        Log.e("SharedContext", "--- eglInitialize failed: " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
      }
      this.auxConfig = this.chooseEglConfig();
      if (this.auxConfig == null) {
        Log.e("SharedContext", "--- eglConfig not initialized");
      }
      final int[] contextAttrs = { 12440, 2, 12344 };
      final EGLContext currentContext = this.egl.eglGetCurrentContext();
      this.eglContext = this.egl.eglCreateContext(this.eglDisplay, this.auxConfig, currentContext, contextAttrs);
      if (this.eglContext != null) {
        Log.d("SharedContext", "--- eglContext created");
      }
      GLES20.glActiveTexture(33984);
      GLES20.glGenTextures(1, this.textures, 0);
      GLES20.glBindTexture(36197, this.textures[0]);
      this.surfaceTexture = new SurfaceTexture(this.textures[0]);
      this.auxSurface = this.egl.eglCreateWindowSurface(this.eglDisplay, this.auxConfig, (Object)this.surfaceTexture, (int[])null);
      if (this.auxSurface == null || this.auxSurface == EGL10.EGL_NO_SURFACE) {
        Log.e("SharedContext", "--- createWindowSurface returned error: " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private EGLConfig chooseEglConfig() {
    try {
      final EGLConfig[] auxConfigs = { null };
      final int[] auxConfigsCount = { 0 };
      if (!this.egl.eglChooseConfig(this.eglDisplay, this.auxConfigAttribs, auxConfigs, 1, auxConfigsCount)) {
        throw new IllegalArgumentException("eglChooseConfig failed " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
      }
      if (auxConfigsCount[0] > 0) {
        return auxConfigs[0];
      }
      return null;
    }
    catch (Exception e) {
      e.printStackTrace();
      return this.auxConfig;
    }
  }

  public void makeCurrent() {
    if (!this.egl.eglMakeCurrent(this.eglDisplay, this.auxSurface, this.auxSurface, this.eglContext)) {
      Log.e("SharedContext", "--- eglMakeCurrent failed: " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
    }
  }

  public void doneCurrent() {
    if (!this.egl.eglMakeCurrent(this.eglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT)) {
      Log.e("SharedContext", "--- eglMakeCurrent failed: " + GLUtils.getEGLErrorString(this.egl.eglGetError()));
    }
  }
}
