package com.esc.phoneheart.utility;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.esc.phoneheart.R;

import java.util.concurrent.TimeUnit;

import androidx.core.internal.view.SupportMenu;

public class TimerView extends View {
    public Bitmap mBitmap;
    public Canvas mCanvas;
    public RectF mCircleInnerBounds;
    public RectF mCircleOuterBounds;
    public Paint mCirclePaint;
    public float mCircleSweepAngle;
    public Paint mEraserPaint;
    public ValueAnimator mTimerAnimator;

    public TimerView(Context context) {
        this(context, null);
    }

    private void drawProgress(float f) {
        this.mCircleSweepAngle = f * 360.0f;
        invalidate();
    }

    private void updateBounds() {
        float width = ((float) getWidth()) * 0.02f;
        this.mCircleOuterBounds = new RectF(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
        RectF rectF = this.mCircleOuterBounds;
        this.mCircleInnerBounds = new RectF(rectF.left + width, rectF.top + width, rectF.right - width, rectF.bottom - width);
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        this.mCanvas.drawColor(0, Mode.CLEAR);
        float f = this.mCircleSweepAngle;
        if (f > 0.0f) {
            this.mCanvas.drawArc(this.mCircleOuterBounds, 45.0f, f, true, this.mCirclePaint);
            this.mCanvas.drawOval(this.mCircleInnerBounds, this.mEraserPaint);
        }
        canvas.drawBitmap(this.mBitmap, 0.0f, 0.0f, null);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i);
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        if (!(i == i3 && i2 == i4)) {
            Bitmap createBitmap = Bitmap.createBitmap(i, i2, Config.ARGB_8888);
            this.mBitmap = createBitmap;
            createBitmap.eraseColor(0);
            this.mCanvas = new Canvas(this.mBitmap);
        }
        super.onSizeChanged(i, i2, i3, i4);
        updateBounds();
    }

    public void start(int i) {
        stop();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        this.mTimerAnimator = ofFloat;
        ofFloat.setDuration(TimeUnit.SECONDS.toMillis((long) i));
        this.mTimerAnimator.setInterpolator(new LinearInterpolator());
        this.mTimerAnimator.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                TimerView.this.drawProgress(((Float) valueAnimator.getAnimatedValue()).floatValue());
            }
        });
        this.mTimerAnimator.start();
    }

    public void stop() {
        ValueAnimator valueAnimator = this.mTimerAnimator;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.mTimerAnimator.cancel();
            this.mTimerAnimator = null;
            drawProgress(0.0f);
        }
    }

    public TimerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TimerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int i2 = SupportMenu.CATEGORY_MASK;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.TimerView);
            if (obtainStyledAttributes != null) {
                i2 = obtainStyledAttributes.getColor(0, SupportMenu.CATEGORY_MASK);
                obtainStyledAttributes.recycle();
            }
        }
        Paint paint = new Paint();
        this.mCirclePaint = paint;
        paint.setAntiAlias(true);
        this.mCirclePaint.setColor(i2);
        paint = new Paint();
        this.mEraserPaint = paint;
        paint.setAntiAlias(true);
        this.mEraserPaint.setColor(0);
        this.mEraserPaint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
    }
}
