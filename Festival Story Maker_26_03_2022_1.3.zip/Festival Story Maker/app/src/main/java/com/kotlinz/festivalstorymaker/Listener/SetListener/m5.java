package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class m5 extends GestureDetector.SimpleOnGestureListener {
    public final  BorderedTextView e;
    public final  com.kotlinz.festivalstorymaker.Models.g f;
    public final FrameLayout g;
    public final  FrameEditorNewDesign h;

    public m5(final FrameEditorNewDesign h, final BorderedTextView e, final com.kotlinz.festivalstorymaker.Models.g f, final FrameLayout g) {
        this.h = h;
        this.e = e;
        this.f = f;
        this.g = g;
    }

    public void onLongPress(final MotionEvent motionEvent) {
        final FrameEditorNewDesign h = this.h;
        h.d1 = true;
        h.e1 = (View) this.e;
        h.a0 = this.g;
        h.z0(true);
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        this.h.u0();
        com.kotlinz.festivalstorymaker.Other.TextInputDilaog.q0((Context) this.h, this.e.getText().toString(), true, this.f.x).m0 = (com.kotlinz.festivalstorymaker.Other.TextInputDilaog.d) new com.kotlinz.festivalstorymaker.Other.TextInputDilaog.d() {
            @Override
            public void a(final String text, final int n) {
                m5.this.e.setText((CharSequence) text);
            }

            @Override
            public void b(final String s) {
            }
        };
        return true;
    }
}
