package com.vidsoft.uvideostatus.Adapters;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.vidsoft.uvideostatus.Fragments.CatogoryFragment;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.FontTextView;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.google.ads.AdRequest;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeAppInstallAd.OnAppInstallAdLoadedListener;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;
import com.wang.avi.AVLoadingIndicatorView;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CatogoryAdapter extends Adapter<RecyclerView.ViewHolder> {
    public List<VideoData> VideoList = new ArrayList();
    CatogoryFragment catogoryFragment;
    private Activity context;
    int count;
    private TrendingVideoAdpter directory;
    private boolean isLoading;
    private int like_total;
    private boolean loading;
    private String path;
    private int visibleThreshold = 2;

    class ProgressBack extends AsyncTask<String, String, String> {
        ProgressDialog PD;

        /* Access modifiers changed, original: protected */
        public void onPreExecute() {
            this.PD = ProgressDialog.show(CatogoryAdapter.this.context, null, "Please Wait ...", true);
            this.PD.setCancelable(true);
        }

        /* Access modifiers changed, original: protected|varargs */
        public String doInBackground(String... strArr) {
            CatogoryAdapter catogoryAdapter = CatogoryAdapter.this;
            String str = strArr[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(strArr[1]);
            stringBuilder.append(".mp4");
            catogoryAdapter.DownloadFile(str, stringBuilder.toString());
            return null;
        }

        /* Access modifiers changed, original: protected */
        public void onPostExecute(String str) {
            super.onPostExecute(str);
            this.PD.dismiss();
        }
    }

    public class AdViewHolder extends RecyclerView.ViewHolder {
        TextView mAdBody;
        Button mAdButton;
        TextView mAdHeadline;
        ImageView mAdIcon;
        ImageView mAdImage;
        RelativeLayout mAdParentView;
        NativeAppInstallAdView mNativeAppInstallAdView;

        public AdViewHolder(View view) {
            super(view);
            this.mAdParentView = (RelativeLayout) view.findViewById(R.id.adCardView1);
            this.mNativeAppInstallAdView = (NativeAppInstallAdView) view.findViewById(R.id.nativeAppInstallAdView1);
            this.mAdImage = (ImageView) view.findViewById(R.id.appinstall_image1);
            this.mAdIcon = (ImageView) view.findViewById(R.id.appinstall_app_icon1);
            this.mAdHeadline = (TextView) view.findViewById(R.id.appinstall_headline1);
            this.mAdBody = (TextView) view.findViewById(R.id.appinstall_body1);
            this.mAdButton = (Button) view.findViewById(R.id.appinstall_call_to_action1);
            Display defaultDisplay = CatogoryAdapter.this.context.getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            int i = displayMetrics.heightPixels;
        }
    }

    public static class ProgressViewHolder extends RecyclerView.ViewHolder {
        public AVLoadingIndicatorView progressBar;

        public ProgressViewHolder(View view) {
            super(view);
            this.progressBar = (AVLoadingIndicatorView) view.findViewById(R.id.progressBar1);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;
        public FontTextView tvlike;
        public FontTextView tvtitle;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = (FontTextView) view.findViewById(R.id.tvVideoListingName);
            this.llVideoList = (RelativeLayout) view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = (ImageView) view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = (FontTextView) view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = (FontTextView) view.findViewById(R.id.tvVideoListingDuration);
            this.duration = (FontTextView) view.findViewById(R.id.duration);
            this.tvtitle = (FontTextView) view.findViewById(R.id.tvtitle);
            this.icon_like_main = (ImageView) view.findViewById(R.id.icon_like_main);
            this.tvlike = (FontTextView) view.findViewById(R.id.tvlike);
            this.icon_like = (LottieAnimationView) view.findViewById(R.id.icon_like);
            this.llVideoList.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    try {
                        if (CatogoryAdapter.this.VideoList != null && ViewHolder.this.getAdapterPosition() != -1 && ViewHolder.this.getAdapterPosition() < CatogoryAdapter.this.VideoList.size()) {
                            CatogoryAdapter.this.catogoryFragment.playVideo((VideoData) CatogoryAdapter.this.VideoList.get(ViewHolder.this.getAdapterPosition()));
                        }
                    } catch (Exception unused) {
                    }
                }
            });
        }
    }

    public CatogoryAdapter(Activity activity, ArrayList<VideoData> arrayList, CatogoryFragment catogoryFragment, RecyclerView recyclerView) {
        this.VideoList = arrayList;
        this.context = activity;
        this.catogoryFragment = catogoryFragment;
        notifyDataSetChanged();
        this.isLoading = false;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 1) {
            return new ViewHolder(from.inflate(R.layout.multi_item, viewGroup, false));
        }
        if (i == 3) {
            return new AdViewHolder(from.inflate(R.layout.item_native_ad1, viewGroup, false));
        }
        return new ProgressViewHolder(from.inflate(R.layout.progress_item, viewGroup, false));
    }

    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int i) {
        if (viewHolder instanceof ProgressViewHolder) {
            ProgressViewHolder progressViewHolder = (ProgressViewHolder) viewHolder;
            progressViewHolder.progressBar.setVisibility(View.VISIBLE);
            progressViewHolder.progressBar.show();
        } else if (viewHolder instanceof AdViewHolder) {
            final AdViewHolder adViewHolder = (AdViewHolder) viewHolder;
            Context context = this.context;
            Builder builder = new Builder(context, context.getString(R.string.AdMob_NativeAdvanceAd));
            builder.forAppInstallAd(new OnAppInstallAdLoadedListener() {
                public void onAppInstallAdLoaded(NativeAppInstallAd nativeAppInstallAd) {
                    adViewHolder.mNativeAppInstallAdView.setImageView(adViewHolder.mAdImage);
                    adViewHolder.mNativeAppInstallAdView.setIconView(adViewHolder.mAdIcon);
                    adViewHolder.mNativeAppInstallAdView.setHeadlineView(adViewHolder.mAdHeadline);
                    adViewHolder.mNativeAppInstallAdView.setBodyView(adViewHolder.mAdBody);
                    adViewHolder.mNativeAppInstallAdView.setCallToActionView(adViewHolder.mAdButton);
                    try {
                        ((TextView) adViewHolder.mNativeAppInstallAdView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());
                    } catch (Exception unused) {
                    }
                    ((TextView) adViewHolder.mNativeAppInstallAdView.getBodyView()).setText(nativeAppInstallAd.getBody());
                    ((Button) adViewHolder.mNativeAppInstallAdView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());
                    try {
                        ((ImageView) adViewHolder.mNativeAppInstallAdView.getIconView()).setImageDrawable(nativeAppInstallAd.getIcon().getDrawable());
                    } catch (Exception unused2) {
                    }
                    List images = nativeAppInstallAd.getImages();
                    if (images.size() > 0) {
                        ((ImageView) adViewHolder.mNativeAppInstallAdView.getImageView()).setImageDrawable(((Image) images.get(0)).getDrawable());
                    }
                    adViewHolder.mNativeAppInstallAdView.setNativeAd(nativeAppInstallAd);
                    adViewHolder.mAdParentView.removeAllViews();
                    adViewHolder.mAdParentView.addView(adViewHolder.mNativeAppInstallAdView);
                }
            });
            builder.withAdListener(new AdListener() {
                public void onAdFailedToLoad(int i) {
                }

                public void onAdLoaded() {
                    Log.e(AdRequest.LOGTAG, "loaded native ad");
                    adViewHolder.mNativeAppInstallAdView.setVisibility(View.VISIBLE);
                }
            }).build().loadAd(new com.google.android.gms.ads.AdRequest.Builder().build());
        } else if (viewHolder instanceof ViewHolder) {
            VideoData videoData = (VideoData) this.VideoList.get(i);
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            viewHolder2.tvVideoListingName.setText(videoData.getTitle());
            viewHolder2.tvVideoListingSize.setText(videoData.getLikes());
            FontTextView fontTextView = viewHolder2.tvVideoListingDuration;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Utility.getViews(Double.parseDouble(videoData.getViews())));
            stringBuilder.append(" views");
            fontTextView.setText(stringBuilder.toString());
            viewHolder2.tvlike.setText(videoData.getLikes());
            viewHolder2.tvtitle.setText(videoData.getCatagory());
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder((int) R.drawable.video_placeholder);
            requestOptions.error((int) R.drawable.video_placeholder);
            requestOptions.override(Callback.DEFAULT_SWIPE_ANIMATION_DURATION, Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
            Glide.with(this.context).load(videoData.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
            viewHolder2.icon_like_main.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CatogoryAdapter catogoryAdapter = CatogoryAdapter.this;
                    catogoryAdapter.like_total = Integer.parseInt(((VideoData) catogoryAdapter.VideoList.get(i)).getLikes()) + 1;
                    FontTextView fontTextView = ((ViewHolder) viewHolder).tvlike;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(CatogoryAdapter.this.like_total);
                    fontTextView.setText(stringBuilder.toString());
                    ((ViewHolder) viewHolder).icon_like_main.setVisibility(View.GONE);
                    ((ViewHolder) viewHolder).icon_like.setVisibility(View.VISIBLE);
                    ((ViewHolder) viewHolder).icon_like.playAnimation();
                    ((ViewHolder) viewHolder).icon_like.loop(false);
                }
            });
        }
    }

    public void DownloadFile(String str, String str2) {
        try {
            str = str.replace(" ", "%20");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/Video_player");
            File file = new File(stringBuilder.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            URL url = new URL(str);
            File file2 = new File(file, str2);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(url.openConnection().getInputStream());
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(20000);
            while (true) {
                int read = bufferedInputStream.read();
                if (read != -1) {
                    byteArrayBuffer.append((byte) read);
                } else {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    fileOutputStream.write(byteArrayBuffer.toByteArray());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("addAll12346: ");
        stringBuilder.append(this.VideoList.size());
        Log.d("TAG", stringBuilder.toString());
        int i = 2;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 10;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.VideoList.add(videoData);
                this.VideoList.add(list.get(i2));
            } else {
                this.VideoList.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getItemCount: ");
        stringBuilder.append(this.VideoList.size());
        Log.d("TAG", stringBuilder.toString());
        return this.VideoList.size();
    }

    public int getItemViewType(int i) {
        return ((VideoData) this.VideoList.get(i)).getType();
    }
}