package com.esc.dailyrandomfacts.managers;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.esc.dailyrandomfacts.util.Quotes;
import com.esc.dailyrandomfacts.model.Theme;

public class ThemeManager {
    private static final String PREF_THEME = "pref_theme_com.esc.dailyrandomfacts.facts";

    public static void saveThemeData(Theme theme) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        if (theme != null) {
            edit.putString(PREF_THEME, new Gson().toJson((Object) theme));
        }
        edit.commit();
    }

    public static Theme getTheme() {
        String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_THEME, null);
        if (string != null) {
            return (Theme) new Gson().fromJson(string, Theme.class);
        }
        return null;
    }

    private static Context getContext() {
        return Quotes.getInstance();
    }
}
