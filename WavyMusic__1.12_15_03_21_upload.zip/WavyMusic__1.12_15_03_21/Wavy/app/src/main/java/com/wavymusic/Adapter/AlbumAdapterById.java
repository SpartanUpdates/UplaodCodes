package com.wavymusic.Adapter;


import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.wavymusic.Listener.OnItemClickListner;
import com.wavymusic.Model.ImageModel;
import com.wavymusic.R;
import com.wavymusic.activity.SelectImageActivity;
import com.wavymusic.application.MyApplication;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import de.hdodenhof.circleimageview.CircleImageView;

public class AlbumAdapterById extends RecyclerView.Adapter<AlbumAdapterById.Holder> {
    private MyApplication application;
    private ArrayList<String> folderId;
    private LayoutInflater inflater;
    private OnItemClickListner<Object> clickListner;
    private RequestManager glide;
    private SelectImageActivity activity;

    public AlbumAdapterById(final Context activity) {
        this.glide = Glide.with(activity);
        this.application = MyApplication.getInstance();
        this.folderId = new ArrayList<String>(this.application.getAllAlbum().keySet());
        this.activity = (SelectImageActivity) activity;
        Collections.sort(this.folderId, new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return s1.compareToIgnoreCase(s2);
            }
        });

        if (folderId.size() != 0) {
            this.application.setSelectedFolderId(this.folderId.get(0));
        } else {
            Toast.makeText(application, "No Image Album Found In Your Phone Please Add Some Image First", Toast.LENGTH_SHORT).show();
        }
        this.inflater = LayoutInflater.from(activity);
    }


    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.clickListner = clickListner;
    }

    public int getItemCount() {
        return folderId == null ? 0 : folderId.size();
    }

    public String getItem(final int pos) {
        return this.folderId.get(pos);
    }

    public void onBindViewHolder(final Holder holder, final int pos) {
        final String currentFolderId = this.getItem(pos);
        final ImageModel data = this.application.getImageByAlbum(currentFolderId).get(0);
        holder.textView.setSelected(true);

        String imagecount = String.valueOf(application.getImageByAlbum(currentFolderId).size());
        holder.tvcount.setText(imagecount);
        holder.textView.setSelected(true);
        holder.textView.setText(data.folderName);
        if (currentFolderId.equals(application.getSelectedFolderId())) {
            holder.ivtrans.setVisibility(View.GONE);
            holder.tvcount.setVisibility(View.GONE);
        } else {
            holder.ivtrans.setVisibility(View.VISIBLE);
            holder.tvcount.setVisibility(View.VISIBLE);
        }
        this.glide.load(data.imagePath).into(holder.imageView);
        holder.clickableView.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {

                AlbumAdapterById.this.application.setSelectedFolderId(currentFolderId);

                if (AlbumAdapterById.this.clickListner != null) {
                    AlbumAdapterById.this.clickListner.onItemClick(v, data);

                }
                AlbumAdapterById.this.notifyDataSetChanged();
            }
        });
    }


    @NonNull
    public Holder onCreateViewHolder(@NonNull final ViewGroup parent, final int pos) {
        return new Holder(this.inflater.inflate(R.layout.row_image_folder, parent, false));
    }

    public class Holder extends RecyclerView.ViewHolder {
        CircleImageView imageView, ivtrans;
        TextView textView, tvcount;
        View parent;
        private LinearLayout clickableView;

        public Holder(final View v) {
            super(v);
            this.parent = v;
            this.imageView = v.findViewById(R.id.imageView1);
            this.ivtrans = v.findViewById(R.id.iv_trans);
            this.textView = v.findViewById(R.id.textView1);
            this.tvcount = v.findViewById(R.id.tv_count);
            this.clickableView = v.findViewById(R.id.fl_clickableView);
        }

        public void onItemClick(final View view, final Object item) {
            if (AlbumAdapterById.this.clickListner != null) {
                AlbumAdapterById.this.clickListner.onItemClick(view, item);
            }
        }
    }
}
