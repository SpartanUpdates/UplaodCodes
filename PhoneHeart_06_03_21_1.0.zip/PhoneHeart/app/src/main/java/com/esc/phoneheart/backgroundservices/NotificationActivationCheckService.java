package com.esc.phoneheart.backgroundservices;

import android.app.IntentService;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import androidx.core.app.NotificationManagerCompat;
import de.greenrobot.event.EventBus;

public class NotificationActivationCheckService extends IntentService {
    public Handler handler;

    public NotificationActivationCheckService() {
        super("NotificationActivationCheckService");
        EventBus.getDefault();
    }

    private boolean notificationEnabled() {
        boolean z = false;
        for (String equals : NotificationManagerCompat.getEnabledListenerPackages(this)) {
            if (equals.equals(getPackageName())) {
                z = true;
            }
        }
        return z;
    }

    public void onDestroy() {
        stopSelf();
        Log.d("SERVICE", "destroyed");
        super.onDestroy();
    }

    public void onHandleIntent(Intent intent) {
        Log.d("SERVICE", "startedRUNNING");
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        this.handler = new Handler();
        return super.onStartCommand(intent, i, i2);
    }
}
