﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class GiftRoom : MonoBehaviour
{
    public static GiftRoom instance;

    public GameObject[] buttonSet;

    public GameObject[] keySet;

    public GameObject extraBtn, noThanksbtn;

    public Sprite unLock;

    int totalCount = 3;

    int totalExtra = 3;

    [HideInInspector]
    public bool isRewardKeyClick = false,isRewardKeyDone=false;

    void Awake()
    {
        instance = this;
    }
    void OnEnable()
    {
        extraBtn.GetComponent<Button>().interactable = false;
        noThanksbtn.SetActive(false);
        for (int i = 0; i < buttonSet.Length; i++)
        {
            buttonSet[i].name = Random.Range(30, 50).ToString();
            buttonSet[i].transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = buttonSet[i].name;
            buttonSet[i].transform.GetChild(0).gameObject.SetActive(false);
        }
    }

    public void On3ExtraClick()
    {
        SoundManger.instance.btnClick.Play();
        SoundManger.instance.Vibrate();
        if (RewardAddShow.instance.rewardBasedVideo.IsLoaded())
        {
            isRewardKeyClick = true;
            RewardAddShow.instance.ShowVideo();
        }
        else
        {
            GameManager.instance.noAdsPanel.SetActive(true);
            RewardAddShow.instance.RequestRewardBasedVideo();
            Invoke("CloseNoAddPanel", 2);
        }
    }
    public void RewardDone()
    {
        isRewardKeyClick = false;
        if (isRewardKeyDone)
        {
            isRewardKeyDone = false;
            totalExtra--;
            extraBtn.GetComponent<Button>().interactable = false;
            noThanksbtn.SetActive(false);

            if (totalExtra != 0)
            {
                totalCount = 3;
                for (int i = 0; i < keySet.Length; i++)
                {
                    keySet[i].SetActive(true);
                }
            }
        }
    }
    void CloseNoAddPanel()
    {
        GameManager.instance.noAdsPanel.SetActive(false);
    }

    public void OnChestClick(GameObject btn)
    {
        SoundManger.instance.btnClick.Play();
        SoundManger.instance.Vibrate();

        if (totalCount != 0)
        {
            totalCount--;
            GameManager.instance.coinGetparticles.SetActive(false);
            btn.GetComponent<Button>().interactable = false;
            Destroy(btn.GetComponent<Animator>());
            btn.GetComponent<RectTransform>().localScale = Vector3.one;
            btn.transform.GetChild(0).gameObject.SetActive(true);
            PlayerPrefs.SetInt("Coins", PlayerPrefs.GetInt("Coins") + int.Parse(btn.name));
            keySet[totalCount].SetActive(false);
            btn.GetComponent<Image>().sprite = unLock;
            PlayerPrefs.SetInt("KeyCount", totalCount);
            GameManager.instance.coinGetparticles.SetActive(true);
        }

        if (totalCount == 0 && totalExtra != 1)
        {
            extraBtn.GetComponent<Button>().interactable = true;
        }
        if (totalCount == 0)
        {
            noThanksbtn.SetActive(true);
        }
    }
    public void OnNoThanksClick()
    {
        SoundManger.instance.btnClick.Play();
        SoundManger.instance.Vibrate();
        GameManager.instance.levelCompleted.SetActive(true);
        GameManager.instance.keyBase.SetActive(true);
        GameManager.instance.chestBase.SetActive(false);
        GameManager.instance.giftPanel.SetActive(false);
        GameManager.instance.ActiveKey();
        if (GameManager.instance.distanceImage.fillAmount > 0.75f)
        {
            GameManager.instance.finishStar.Play("3StarFinish");
        }
        else if (GameManager.instance.distanceImage.fillAmount > 0.5f)
        {
            GameManager.instance.finishStar.Play("2StarFinish");
        }
        else
        {
            GameManager.instance.finishStar.Play("1StarFinish");
        }
    }
}
