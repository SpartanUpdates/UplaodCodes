package com.esc.socialmediacleaner.util;

public interface OnAdClosed {
    void adClosed();

    void adLoadedOrFailed(boolean z);
}
