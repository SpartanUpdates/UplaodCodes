package com.example.lyricsvideo.Utils;


import android.content.Context;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.TextView;

public class AppFont {

    public static void Textfont(final Context mContext, final TextView tv) {
        final Typeface typeFacecategory = Typeface.createFromAsset(mContext.getAssets(), "fonts/biko_regular.otf");
        tv.setTypeface(typeFacecategory);
    }

    public static void Buttonfont(final Context mContext, final Button btn) {
        final Typeface typeFacecategory = Typeface.createFromAsset(mContext.getAssets(), "fonts/biko_regular.otf");
        btn.setTypeface(typeFacecategory);
    }
}
