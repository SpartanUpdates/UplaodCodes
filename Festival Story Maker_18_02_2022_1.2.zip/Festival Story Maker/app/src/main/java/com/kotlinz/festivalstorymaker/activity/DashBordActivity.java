package com.kotlinz.festivalstorymaker.activity;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.kotlinz.festivalstorymaker.Adapter.DashBord.AllModuleAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModule;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModuleResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashBordActivity extends AppCompatActivity {

    Activity activity = DashBordActivity.this;

    private final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private final int REQUEST_PERMISSION_SETTING = 101;
    public AlertDialog alertDialog;

    @BindView(R.id.rl_main_Data)
    RelativeLayout rlMainData;

    @BindView(R.id.llRetry)
    LinearLayout llRetry;

    @BindView(R.id.iv_menu)
    ImageView ivMenu;

    APIInterface apiInterface;

    RecyclerView rvAllModule;

    ArrayList<AllModule> allModulesList = new ArrayList<>();
    AllModuleAdapter allModuleAdapter;
    public GridLayoutManager mLayoutManager;

    public int ModuleId;

    Gson gson = new Gson();

    private FirebaseRemoteConfig firebaseRemoteConfig;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashbord);
        ButterKnife.bind(this);
        rvAllModule = findViewById(R.id.rv_all_module);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        ForceUpdate();
        SetDashboardsAllModuleData();
        RequestPermission(false, true);
        PutAnalyticsEvent();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "DashBordActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private float getCurrentVersionCode() {
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return Float.parseFloat(packageInfo.versionName);
    }

    private void ForceUpdate() {
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(5).build();
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                if (task.isSuccessful()) {
                    final String newVersion = firebaseRemoteConfig.getString("new_version_code");
                    if (Float.parseFloat(newVersion) > getCurrentVersionCode()) {
                        showDialogForUpdate(activity);
                    }
                }
            }
        });
    }

    public void showDialogForUpdate(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.update_dialog);
        dialog.show();

        Button update = dialog.findViewById(R.id.update);
        TextView updateTxt = dialog.findViewById(R.id.updateTxt);
        TextView updateTxt2 = dialog.findViewById(R.id.updateTxt2);
        LinearLayout mainLayout = dialog.findViewById(R.id.mainLayout);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse(activity.getString(R.string.rate_us_url)
                                    + activity.getPackageName())));
                    ;
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (Utils.checkConnectivity(activity, false)) {
            rlMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetAllModule();
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }

    @OnClick(R.id.iv_menu)
    public void PopUpDialog() {
        PopupMenu popup = new android.widget.PopupMenu(activity, ivMenu);
        popup.getMenuInflater().inflate(R.menu.menu_dialog, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.privacy_policy:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                        startActivity(intent1);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
                case R.id.rate_us:
                    try {
                        startActivity(new Intent("android.intent.action.VIEW", Uri
                                .parse("market://details?id=" + getApplicationContext().getPackageName())));
                    } catch (ActivityNotFoundException ex) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri
                                .parse("http://play.google.com/store/apps/details?id="
                                        + getApplicationContext().getPackageName())));
                    }
                    break;
                case R.id.feedback:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.feedback)));
                        startActivity(intent1);
                    } catch (ActivityNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
            }
            return true;
        });
        popup.show();
    }


    private void SetDashboardsAllModuleData() {
        if (Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                GetAllModule();
            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.AllModuleDataResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetAllModule();
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                SetOfflineData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                rlMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);

            } else {
                SetOfflineData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData));
            }
        }
    }

    private void GetAllModule() {
        Call<AllModuleResponse> call = apiInterface.getAllModule(AppConstant.token, AppConstant.ApplicationId);
        call.enqueue(new Callback<AllModuleResponse>() {
            @Override
            public void onResponse(Call<AllModuleResponse> call, Response<AllModuleResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.AllModuleData);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.AllModuleDataResponseTime);
                    SetOfflineData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<AllModuleResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.AllModuleData).equalsIgnoreCase("")) {
                    rlMainData.setVisibility(View.GONE);
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void SetOfflineData(String response) {
        AllModuleResponse allModuleResponse = gson.fromJson(response, AllModuleResponse.class);
        allModulesList = allModuleResponse.getData();
        allModuleAdapter = new AllModuleAdapter(activity, allModulesList);
        mLayoutManager = new GridLayoutManager(activity, 2, GridLayoutManager.VERTICAL, false);
        rvAllModule.setLayoutManager(mLayoutManager);
        rvAllModule.setAdapter(allModuleAdapter);
    }

    private void RequestPermission(boolean z, boolean isFromFirst) {
        if ((ActivityCompat.checkSelfPermission(activity, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            if (isFromFirst) {
                Utils.CreateDirectory();
            }
        } else if (z) {
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
            alertDialogBuilder.setTitle("Necessary permission");
            alertDialogBuilder.setMessage("Allow Required Permission");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    PremissionFromSetting();
                }
            });
            alertDialogBuilder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
            } else {
                RequestPermission(true, true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    Utils.CreateDirectory();
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    RequestPermission(true, true);
                }
            }
        }
    }

    public void PremissionFromSetting() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }


    public void PosterMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 1;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, PosterMakerActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, PosterMakerActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void StoryMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 2;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsFrom", "Story Maker");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsFrom", "Story Maker");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void PreDesignArtbord() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 7;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsFrom", "PreDesign ArtBord");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsFrom", "PreDesign ArtBord");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void ThematicTemplate() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsFrom", "Thematic Template");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsFrom", "Thematic Template");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void WishMaker() {
       /* if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 10;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsFrom", "Wish Maker");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsFrom", "Wish Maker");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }*/
        Toast.makeText(activity, "Coming Soon...", Toast.LENGTH_SHORT).show();
    }


    public void OfferPoster() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 11;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, StoryMakerActivity.class);
                intent.putExtra("IsFrom", "Offer Poster");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, StoryMakerActivity.class);
            intent.putExtra("IsFrom", "Offer Poster");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void FestivalPoster() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 12;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, FestivalTemplateActivity.class);
                intent.putExtra("IsFrom", "Festival");
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, FestivalTemplateActivity.class);
            intent.putExtra("IsFrom", "Festival");
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void CollageMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 3;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, CollageMakerActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, CollageMakerActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    public void ZoomCollage() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 8;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, CollageMakerActivity.class);
                intent.putExtra("moduleid", AppConstant.CollageBackgroundId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, CollageMakerActivity.class);
            intent.putExtra("moduleid",AppConstant. CollageBackgroundId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }


    public void QuoteMaker() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 6;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                Intent intent = new Intent(activity, QuoteMakerDetailActivity.class);
                intent.putExtra("moduleid", ModuleId);
                startActivity(intent);
            }
        } else {
            Intent intent = new Intent(activity, QuoteMakerDetailActivity.class);
            intent.putExtra("moduleid", ModuleId);
            startActivity(intent);
            MyApplication.isShowAd = 0;
        }
    }

    @Override
    public void onBackPressed() {
        if (MyApplication.isShowAd == 0) {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.ModuleId = ModuleId;
                MyApplication.AdsId = 13;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                GoToExit();
            }
        } else {
            GoToExit();
            MyApplication.isShowAd = 0;
        }

    }

    private void GoToExit() {
        startActivity(new Intent(activity, ExitActivity.class));
        finish();
    }
}