package com.mbit.VideoMaker.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Fragment.OnlineCategoryWiseSongFragment;
import com.mbit.VideoMaker.Handler.HttpHandler;
import com.mbit.VideoMaker.Model.SongCatModel;
import com.mbit.VideoMaker.R;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class OnlineSongActivity extends AppCompatActivity {

    public int id;
    public String FinalSongPath;
    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    Activity activity = OnlineSongActivity.this;
    String SongAllCatUrl = "https://raw.githubusercontent.com/PKMasterBundle/MBitMusic/master/MainCategory.txt";
    NewsPagerAdapterNew adp;
    ArrayList<SongCatModel> SongList = new ArrayList<>();
    String offlienResopnseData;
    SharedPreferences ThemeCategoryPreference;
    String MY_PREF = "Song_pref";
    RelativeLayout rlLoadingTheme;
    LinearLayout layoutSongSdCard;
    ImageView ivBack;
    //    private LinearLayout adContainer;
//    private AdView adView;
    AdRequest adRequest;
    AdView adView;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private boolean IsofflineResopnse = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online_song);
        ThemeCategoryPreference = getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        ivBack = findViewById(R.id.ivBack);
        tabLayout = findViewById(R.id.tab_layout_song_online);
        viewPager = findViewById(R.id.vp_song_online);
        layoutSongSdCard = findViewById(R.id.ll_from_storage);
        rlLoadingTheme = findViewById(R.id.rl_load_song_online);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "OnlineSongActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        loadAd();
        InterstitialAd();
        adListener();
        if (ThemeCategoryPreference.getBoolean("ThemeFirstTime", true)) {
            if (Utils.checkConnectivity(activity, false)) {
                ThemeCategoryPreference.edit().putBoolean("ThemeFirstTime", false).apply();
                new GetSongCategory().execute(SongAllCatUrl);
            } else {
                Toast.makeText(activity, "No Internet Connecation !", Toast.LENGTH_LONG).show();
            }
        } else {
            if (Utils.checkConnectivity(activity, false)) {
                new GetSongCategory().execute(SongAllCatUrl);
            } else {
                IsofflineResopnse = true;
                new GetSongCategory().execute(SongAllCatUrl);
            }
        }
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

//        adContainer = findViewById(R.id.templateContainer);
//        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
//        adContainer.addView(adView);
//        adView.loadAd();
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 203:
                        UnityPlayer.UnitySendMessage("SelectMusic", "GetSelectedMusicPath", FinalSongPath);
                        finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }

    private void adListener() {
        layoutSongSdCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(activity, LocalSongActivity.class), 101);
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }


    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
            View customView = tab.getCustomView();
            if (tab.getPosition() == 0) {
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
                StopSong();
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.black));
                LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_normal));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.custom_text)).setTextColor(getResources().getColor(R.color.white));
                    LinearLayout linearLayout = customView.findViewById(R.id.ll_tab_main);
                    linearLayout.setBackground(getResources().getDrawable(R.drawable.rounded_song_bg_selected));
                }
            }
        });


    }

    private void StopSong() {
        try {
            if (OnlineCategoryWiseSongFragment.mediaPlayer != null) {
                OnlineCategoryWiseSongFragment.mediaPlayer.stop();
                OnlineCategoryWiseSongFragment.mediaPlayer.release();
                OnlineCategoryWiseSongFragment.mediaPlayer = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpPagerNew() {
        adp = new NewsPagerAdapterNew(getSupportFragmentManager());
        for (int i = 0; i < SongList.size(); i++) {
            adp.addFrag(OnlineCategoryWiseSongFragment.getInstance(SongList.get(i).getSongCatLnk(), Integer.parseInt(SongList.get(i).getSongCatId())), SongList.get(i).getSongCatName());
        }
        viewPager.setAdapter(adp);
        tabLayout.setupWithViewPager(viewPager);
    }

    public void SetOfflineCategory(Context c, String userObject, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    public void getOfflineCategory(Context ctx, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }

    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        final StringBuilder sb = new StringBuilder();
        sb.append("onlinemusic act onact result requestcode ");
        sb.append(n);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("onlinemusic act onact result resultcode ");
        sb2.append(n2);
        if (n2 == -1) {
            if (n != 101) {
                return;
            }
            intent.getExtras().getString("audio_path");
//            Log.e("TAG", "SongPath" + intent.getExtras().getString("audio_path"));
            UnityPlayer.UnitySendMessage("SelectMusic", "GetSelectedMusicPath", intent.getExtras().getString("audio_path"));
            this.setResult(-1);
            this.finish();
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class GetSongCategory extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(arg0[0]);
            if (jsonStr != null) {
                System.out.println("success");
            } else {
                System.out.println("failed");
            }

            return jsonStr;

        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObj;
                if (IsofflineResopnse) {
                    getOfflineCategory(activity, "SongCategory");
                    jsonObj = new JSONObject(offlienResopnseData);

                } else {
                    jsonObj = new JSONObject(result);
                    if (activity != null) {
                        SetOfflineCategory(activity, jsonObj.toString(), "SongCategory");
                    }
                }
                JSONArray tabcategory = jsonObj.getJSONArray("data");
                for (int i = 0; i < tabcategory.length(); i++) {
                    JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                    SongCatModel songCatModel = new SongCatModel();
                    songCatModel.setSongCatId(tabcategoryJSONObject.getString("Sound_Category_Id"));
                    songCatModel.setSongCatName(tabcategoryJSONObject.getString("Category_Name"));
                    songCatModel.setSongCatLnk(tabcategoryJSONObject.getString("Category_Link"));
                    songCatModel.setApplicationId(tabcategoryJSONObject.getString("Application_id"));
                    SongList.add(songCatModel);
                }
                setUpPagerNew();
                SetTabLayout();
                rlLoadingTheme.setVisibility(View.GONE);
            } catch (final JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class NewsPagerAdapterNew extends FragmentPagerAdapter {
        List<Fragment> fragList = new ArrayList<>();
        List<String> titleList = new ArrayList<>();

        public NewsPagerAdapterNew(FragmentManager fm) {
            super(fm);
        }

        public void addFrag(Fragment f, String title) {
            fragList.add(f);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragList.get(position);
        }

        @Override
        public int getCount() {
            return fragList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(activity).inflate(
                    R.layout.row_song_cat, null);
            TextView tv = tab.findViewById(R.id.custom_text);
            tv.setText(SongList.get(position).getSongCatName());
            return tab;
        }
    }

}
