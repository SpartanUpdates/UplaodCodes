package com.vidsoft.uvideostatus.Fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.vidsoft.uvideostatus.Activity.LanguageActivity;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.vidsoft.uvideostatus.Models.CustomCategoryItem;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnClickListener {
    ViewPagerAdapter adapter;
    Context context;
    CardView langauge_menu;
    private List<VideoData> mParam1;
    TabLayout tabLayout;
    ViewPager viewPager;

    class ViewPagerAdapter extends FragmentStatePagerAdapter {
        public final int PAGE_COUNT = Utility.CATEGORYLIST.size();
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();
        final HomeFragment this$0;

        public int getItemPosition(@NonNull Object obj) {
            return -2;
        }

        public ViewPagerAdapter(HomeFragment homeFragment, FragmentActivity fragmentActivity, FragmentManager fragmentManager) {
            super(fragmentManager);
            this.this$0 = homeFragment;
        }

        public Fragment getItem(int i) {
            Bundle bundle = new Bundle();
            String str = "catogory";
            String str2 = TtmlNode.ATTR_ID;
            CatogoryFragment catogoryFragment;
            switch (i) {
                case 0:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    Log.e("IdCategory", ""+Utility.CATEGORYLIST.get(i).getID());
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("getItem: ");
                    stringBuilder.append(((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    stringBuilder.append(">>");
                    stringBuilder.append(((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    Log.d("getcatogoryvideo", stringBuilder.toString());
                    return catogoryFragment;
                case 1:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 2:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 3:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 4:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 5:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 6:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 7:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 8:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 9:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 10:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 11:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 12:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 13:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 14:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 15:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 16:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 17:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 18:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 19:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 20:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 21:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 22:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 23:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 24:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 25:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 26:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 27:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;
                case 28:
                    catogoryFragment = new CatogoryFragment();
                    bundle.putString(str2, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getID());
                    bundle.putString(str, ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName());
                    catogoryFragment.setArguments(bundle);
                    return catogoryFragment;

                default:
                    return null;
            }
        }

        public int getCount() {
            return this.PAGE_COUNT;
        }

        public void addFrag(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return ((CustomCategoryItem) Utility.CATEGORYLIST.get(i)).getCategoryName();
        }
    }


    public void onClick(View view) {
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.home_fragment, viewGroup, false);
        initview(inflate);
        return inflate;
    }

    private void initview(View view) {
        this.context = getActivity();
        this.langauge_menu = (CardView) view.findViewById(R.id.langauge_menu);
        this.tabLayout = (TabLayout) view.findViewById(R.id.sliding_tabs);
        this.viewPager = (ViewPager) view.findViewById(R.id.viewpager);
        this.adapter = new ViewPagerAdapter(this, getActivity(), getChildFragmentManager());
        ViewPager viewPager = this.viewPager;
        if (viewPager != null) {
            viewPager.setAdapter(this.adapter);
        }
        TabLayout tabLayout = this.tabLayout;
        if (tabLayout != null) {
            tabLayout.setupWithViewPager(this.viewPager);
            Typeface createFromAsset = Typeface.createFromAsset(getContext().getAssets(), "google_sans_medium.ttf");
            for (int i = 0; i < this.tabLayout.getTabCount(); i++) {
                TextView view2 = (TextView) LayoutInflater.from(getActivity()).inflate(R.layout.tab_custom, null);
                view2.setTypeface(createFromAsset);
                this.tabLayout.getTabAt(i).setCustomView(view2);
            }
        }
        this.tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.tab));
        this.tabLayout.setTabTextColors(Color.parseColor("#727272"), getResources().getColor(R.color.tab));
        this.langauge_menu.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HomeFragment.this.startActivity(new Intent(HomeFragment.this.getActivity(), LanguageActivity.class));
            }
        });
    }
}