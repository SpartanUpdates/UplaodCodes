package com.kotlinz.videoCollage.other;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

import androidx.exifinterface.media.ExifInterface;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ImageCompress {
    public static ImageCompress mInstant;

    public static ImageCompress getInstant() {
        if (mInstant == null) {
            mInstant = new ImageCompress();
        }
        return mInstant;
    }

    public Bitmap getCompressedBitmap(String str, float f, float f2) {
        Bitmap createBitmap;
        Options options = new Options();
        options.inJustDecodeBounds = true;
        Bitmap decodeFile = BitmapFactory.decodeFile(str, options);
        int i = options.outHeight;
        int i2 = options.outWidth;
        float f3 = (float) i2;
        float f4 = (float) i;
        float f5 = f3 / f4;
        float f6 = f2 / f;
        if (f4 > f || f3 > f2) {
            if (f5 < f6) {
                i2 = (int) ((f / f4) * f3);
                i = (int) f;
            } else {
                if (f5 > f6) {
                    f = (f2 / f3) * f4;
                }
                i = (int) f;
                i2 = (int) f2;
            }
        }
        options.inSampleSize = calculateInSampleSize(options, i2, i);
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inTempStorage = new byte[16384];
        try {
            decodeFile = BitmapFactory.decodeFile(str, options);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
        try {
            createBitmap = Bitmap.createBitmap(i2, i, Config.ARGB_8888);
        } catch (OutOfMemoryError e2) {
            e2.printStackTrace();
            createBitmap = null;
        }
        float f7 = (float) i2;
        float f8 = f7 / ((float) options.outWidth);
        float f9 = (float) i;
        float f10 = f9 / ((float) options.outHeight);
        f7 /= 2.0f;
        f9 /= 2.0f;
        Matrix matrix = new Matrix();
        matrix.setScale(f8, f10, f7, f9);
        Canvas canvas = new Canvas(createBitmap);
        canvas.setMatrix(matrix);
        canvas.drawBitmap(decodeFile, f7 - ((float) (decodeFile.getWidth() / 2)), f9 - ((float) (decodeFile.getHeight() / 2)), new Paint(2));
        try {
            int attributeInt = new ExifInterface(str).getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
            Matrix matrix2 = new Matrix();
            if (attributeInt == 6) {
                matrix2.postRotate(90.0f);
            } else if (attributeInt == 3) {
                matrix2.postRotate(180.0f);
            } else if (attributeInt == 8) {
                matrix2.postRotate(270.0f);
            }
            createBitmap = Bitmap.createBitmap(createBitmap, 0, 0, createBitmap.getWidth(), createBitmap.getHeight(), matrix2, true);
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        createBitmap.compress(CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] toByteArray = byteArrayOutputStream.toByteArray();
        return BitmapFactory.decodeByteArray(toByteArray, 0, toByteArray.length);
    }

    private int calculateInSampleSize(Options options, int i, int i2) {
        int round;
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        if (i3 > i2 || i4 > i) {
            round = Math.round(((float) i3) / ((float) i2));
            int round2 = Math.round(((float) i4) / ((float) i));
            if (round >= round2) {
                round = round2;
            }
        } else {
            round = 1;
        }
        while (((float) (i4 * i3)) / ((float) (round * round)) > ((float) ((i * i2) * 2))) {
            round++;
        }
        return round;
    }
}
