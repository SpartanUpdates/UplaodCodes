package com.esc.beautymackupselficlam.collage;

import android.content.Intent;

public class Action
{

  public static final String ACTION_MULTIPLE_PICK = "com.esc.beautymackupselficlam.ACTION_MULTIPLE_PICK";
  public static final String ACTION_PICK = Intent.ACTION_PICK;
}
