package com.vidsoft.collagemaker.Model;

public class Ratio
{
  int image;
  String title;

  public Ratio(int paramInt, String paramString)
  {
    this.image = paramInt;
    this.title = paramString;
  }

  public int getImage()
  {
    return this.image;
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setImage(int paramInt)
  {
    this.image = paramInt;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
}