package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class RtoOfficeInfoDetail
{
    @SerializedName("name")
    public String name;
    @SerializedName("rtoList")
    public ArrayList<RtoOfficeInfolist> rtoList = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<RtoOfficeInfolist> getRtoList() {
        return rtoList;
    }

    public void setRtoList(ArrayList<RtoOfficeInfolist> rtoList) {
        this.rtoList = rtoList;
    }
}
