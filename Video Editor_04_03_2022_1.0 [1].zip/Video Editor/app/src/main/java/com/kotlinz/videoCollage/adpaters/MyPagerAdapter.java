package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.kotlinz.videoCollage.fragments.VideosFragmentNew;

public class MyPagerAdapter extends FragmentPagerAdapter {

    private int totalTabs;
    private VideosFragmentNew videosFragmentNew;

    public MyPagerAdapter(Context context, FragmentManager fragmentManager, int i) {
        super(fragmentManager);
        this.totalTabs = i;
//        this.videosFragmentNew = new VideosFragmentNew(context);
    }

    public Fragment getItem(int i) {
        return this.videosFragmentNew;
    }

    public int getCount() {
        return this.totalTabs;
    }
}
