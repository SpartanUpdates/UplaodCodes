package com.esc.beautymackupselficlam.Activity;

import android.Manifest;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.beautymackupselficlam.R;
import  com.esc.beautymackupselficlam.collage.GallerySelection;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import  com.esc.beautymackupselficlam.library.Toaster;
import  com.esc.beautymackupselficlam.library.UriToUrl;
import  com.esc.beautymackupselficlam.library.Utility;
import com.esc.beautymackupselficlam.pref.EPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private boolean camera_permission = false;
    private Uri imageUri;
    private int int_camera = 0;
    private int int_image_select = 0;
    private boolean storage_permission = false;
    ImageView imgPipeffects;
    ImageView imgPixeleffects;
    ImageView imgwattereffects;
    ImageView ivMyCreation;
    EPreferences ePreferences;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private UnifiedNativeAd nativeAd;
    private KProgressHUD hud;
    private int id;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CheckPermissions();
        BindView();
        initView();
        loadAd();
        BannerAds();
        this.ePreferences = EPreferences.getInstance(this);
    }

    private void initView() {
        imgPipeffects.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = R.id.img_pipeffect;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startPiP();
                }
            }
        });

        imgPixeleffects.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = R.id.img_pixeleffexts;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startPixels();
                }
            }
        });

        imgwattereffects.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = R.id.img_Wattereffects;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startWater();
                }
            }
        });
        ivMyCreation = (ImageView) findViewById(R.id.ivMyCreation);
        ivMyCreation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(MainActivity.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = R.id.ivMyCreation;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startActivity(new Intent(MainActivity.this, MyCreationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });
    }

    private void BindView() {
        imgPipeffects = (ImageView) findViewById(R.id.img_pipeffect);
        imgPixeleffects = (ImageView) findViewById(R.id.img_pixeleffexts);
        imgwattereffects = (ImageView) findViewById(R.id.img_Wattereffects);
        ivMyCreation = (ImageView) findViewById(R.id.ivMyCreation);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.rate_us:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse(getString(R.string.rate_us)
                                    + getApplicationContext().getPackageName())));
                    return true;
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(this, "You don't have Google Play installed",
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
            case R.id.Share:
                final Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject test");
                intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_msg) + getPackageName());
                MainActivity.this.startActivity(Intent.createChooser(intent, (CharSequence) "Share via"));
                return true;

            case R.id.privacy:
                try {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                    startActivity(intent1);
                }catch (ActivityNotFoundException e)
                {
                }
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private void CheckPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != 0 && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != 0) {
            this.camera_permission = false;
            this.storage_permission = false;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != 0) {
            this.camera_permission = false;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != 0) {
            this.storage_permission = false;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            this.camera_permission = true;
            this.storage_permission = true;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 0) {
            if (grantResults.length > 0 && grantResults[0] == 0) {
                this.camera_permission = true;
                Utility.int_image_type = 1;
                if (this.int_image_select == 1) {
                } else if (this.int_image_select == 2) {
                    Utility.int_image_type = 1;
                    startActivity(new Intent(getApplicationContext(), PiPEditCategory.class));
                } else if (this.int_image_select == 3) {
                    Utility.int_image_type = 1;
                    startActivity(new Intent(getApplicationContext(), PixelEffectEditorActivity.class));
                } else if (this.int_image_select == 4) {
                    Utility.int_image_type = 1;
                    startActivity(new Intent(getApplicationContext(), WaterEffectEditorActivity.class));
                }
            }
        } else if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == 0) {
                this.storage_permission = true;
                if (this.int_camera == 0) {
                    if (Utility.int_image_type == 2) {
                        if (this.int_image_select == 1) {
                        } else if (this.int_image_select == 2) {
                            Utility.int_image_type = 2;
                            startActivity(new Intent(getApplicationContext(), PiPEditCategory.class));
                        } else if (this.int_image_select == 3) {
                            Utility.int_image_type = 2;
                            startActivity(new Intent(getApplicationContext(), PixelEffectEditorActivity.class));
                        } else if (this.int_image_select == 4) {
                            Utility.int_image_type = 2;
                            startActivity(new Intent(getApplicationContext(), WaterEffectEditorActivity.class));
                        }
                    } else if (Utility.int_image_type == 3) {
                        startActivity(new Intent(getApplicationContext(), GallerySelection.class));
                    }
                } else if (this.int_camera == 1) {
                    this.int_camera = 0;
                    if (this.int_image_select == 1) {
                    } else if (this.int_image_select == 2) {
                        Utility.int_image_type = 1;
                        startActivity(new Intent(getApplicationContext(), PiPEditCategory.class));
                    } else if (this.int_image_select == 3) {
                        Utility.int_image_type = 1;
                        startActivity(new Intent(getApplicationContext(), PixelEffectEditorActivity.class));
                    } else if (this.int_image_select == 4) {
                        Utility.int_image_type = 1;
                        startActivity(new Intent(getApplicationContext(), WaterEffectEditorActivity.class));
                    }
                }
            }
        } else if (requestCode == 2 && grantResults.length > 0) {
            for (int i = 0; i <= grantResults.length; i++) {
                if (i == 0) {
                    if (grantResults[i] == 0) {
                        this.camera_permission = true;
                    } else {
                        this.camera_permission = false;
                    }
                } else if (i == 1) {
                    if (grantResults[i] == 0) {
                        this.storage_permission = true;
                    } else {
                        this.storage_permission = false;
                    }
                }
            }
        }
    }

    protected void onStart() {
        overridePendingTransition(0, 0);
        super.onStart();
    }

    protected void onStop() {
        overridePendingTransition(0, 0);
        super.onStop();
    }


    public void startPixels() {
        this.int_image_select = 3;
        pick_image();
    }

    public void startWater() {
        this.int_image_select = 4;
        pick_image();
    }

    public void startPiP() {
        this.int_image_select = 2;
        pick_image();
    }

    private void startGallery() {
        Utility.int_image_type = 2;
    }

    private void startCamera() {
        Utility.int_image_type = 1;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (resultCode == -1) {
                try { return;
                } catch (Exception e) {
                    Toaster.make(getApplicationContext(), (int) R.string.error_img_not_found);
                    return;
                }
            }
            UriToUrl.deleteUri(getApplicationContext(), this.imageUri);
        } else if (resultCode == -1 && requestCode == 1) {
            try {
                this.imageUri = data.getData();
            } catch (Exception e2) {
                Toaster.make(getApplicationContext(), (int) R.string.error_img_not_found);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void pick_image() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_custom);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        ImageView img_cam = (ImageView) dialog.findViewById(R.id.Btncamera);
        ImageView img_gallery = (ImageView) dialog.findViewById(R.id.btngallery);

        img_cam.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (MainActivity.this.camera_permission && MainActivity.this.storage_permission) {
                    if (MainActivity.this.int_image_select == 1) {
                        MainActivity.this.startCamera();
                    } else if (MainActivity.this.int_image_select == 2) {
                        Utility.int_image_type = 1;
                        MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), PiPEditCategory.class));
                    } else if (MainActivity.this.int_image_select == 3) {
                        Utility.int_image_type = 1;
                        MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), PixelEffectEditorActivity.class));
                    } else if (MainActivity.this.int_image_select == 4) {
                        Utility.int_image_type = 1;
                        MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), WaterEffectEditorActivity.class));
                    }
                } else if (MainActivity.this.camera_permission) {
                    if (!MainActivity.this.storage_permission) {
                        MainActivity.this.int_camera = 1;
                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != 0) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                        }
                    }
                } else if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != 0) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, 0);
                }
                dialog.dismiss();
            }
        });
        img_gallery.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (!MainActivity.this.storage_permission) {
                    MainActivity.this.int_camera = 0;
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != 0) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                    }
                } else if (MainActivity.this.int_image_select == 1) {
                    MainActivity.this.startGallery();
                } else if (MainActivity.this.int_image_select == 2) {
                    Utility.int_image_type = 2;
                    MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), PiPEditCategory.class));
                } else if (MainActivity.this.int_image_select == 3) {
                    Utility.int_image_type = 2;
                    MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), PixelEffectEditorActivity.class));
                } else if (MainActivity.this.int_image_select == 4) {
                    Utility.int_image_type = 2;
                    MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), WaterEffectEditorActivity.class));
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void loadAd() {

        //interstitial FullScreenAd
        interstitial = new InterstitialAd(MainActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.img_pipeffect:
                        startPiP();
                        break;
                    case R.id.img_pixeleffexts:
                        startPixels();
                        break;
                    case R.id.img_Wattereffects:
                        startWater();
                        break;
                    case R.id.ivMyCreation:
                        startActivity(new Intent(MainActivity.this, MyCreationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(MainActivity.this);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(MainActivity.this);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.Ad_mob_native_advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    protected void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }
}
