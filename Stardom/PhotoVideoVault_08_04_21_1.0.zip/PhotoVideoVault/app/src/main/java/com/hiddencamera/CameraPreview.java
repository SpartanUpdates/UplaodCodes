package com.hiddencamera;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.hiddencamera.config.CameraResolution;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

@SuppressLint({"ViewConstructor"})
class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {
    private Camera mCamera;
    private CameraCallbacks mCameraCallbacks;
    private CameraConfig mCameraConfig;
    private SurfaceHolder mHolder;
    private volatile boolean safeToTakePicture;

    CameraPreview(@NonNull final Context context, final CameraCallbacks mCameraCallbacks) {
        super(context);
        this.safeToTakePicture = false;
        this.mCameraCallbacks = mCameraCallbacks;
        this.initSurfaceView();
    }

    private void initSurfaceView() {
        (this.mHolder = this.getHolder()).addCallback((SurfaceHolder.Callback) this);
        this.mHolder.setType(3);
    }

    private boolean safeCameraOpen(final int n) {
        try {
            this.stopPreviewAndFreeCamera();
            this.mCamera = Camera.open(n);
            return this.mCamera != null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    boolean isSafeToTakePictureInternal() {
        return this.safeToTakePicture;
    }

    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
    }

    void startCameraInternal(@NonNull final CameraConfig mCameraConfig) {
        this.mCameraConfig = mCameraConfig;
        if (this.safeCameraOpen(this.mCameraConfig.getFacing())) {
            if (this.mCamera == null) {
                return;
            }
            this.requestLayout();
            try {
                this.mCamera.setPreviewDisplay(this.mHolder);
                this.mCamera.startPreview();
                return;
            } catch (IOException ex) {
                ex.printStackTrace();
                this.mCameraCallbacks.onCameraError(1122);
                return;
            }
        }
        this.mCameraCallbacks.onCameraError(1122);
    }

    void stopPreviewAndFreeCamera() {
        this.safeToTakePicture = false;
        if (this.mCamera != null) {
            this.mCamera.stopPreview();
            this.mCamera.release();
            this.mCamera = null;
        }
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        if (this.mCamera == null) {
            this.mCameraCallbacks.onCameraError(CameraError.ERROR_CAMERA_OPEN_FAILED);
        } else if (surfaceHolder.getSurface() == null) {
            this.mCameraCallbacks.onCameraError(CameraError.ERROR_CAMERA_OPEN_FAILED);
        } else {
            Camera.Size cameraSize;
            try {
                this.mCamera.stopPreview();
            } catch (Exception e) {
            }
            Camera.Parameters parameters = this.mCamera.getParameters();
            List<Camera.Size> pictureSizes = this.mCamera.getParameters().getSupportedPictureSizes();
            Collections.sort(pictureSizes, new PictureSizeComparator());
            switch (this.mCameraConfig.getResolution()) {
                case 2006:
                    cameraSize = (Camera.Size) pictureSizes.get(0);
                    break;
                case CameraResolution.LOW_RESOLUTION:
                    cameraSize = (Camera.Size) pictureSizes.get(pictureSizes.size() - 1);
                    break;
                case CameraResolution.MEDIUM_RESOLUTION:
                    cameraSize = (Camera.Size) pictureSizes.get(pictureSizes.size() / 2);
                    break;
                default:
                    throw new RuntimeException("Invalid camera resolution.");
            }
            parameters.setPictureSize(cameraSize.width, cameraSize.height);
            requestLayout();
            this.mCamera.setParameters(parameters);
            try {
                this.mCamera.setDisplayOrientation(90);
                this.mCamera.setPreviewDisplay(surfaceHolder);
                this.mCamera.startPreview();
                this.safeToTakePicture = true;
            } catch (IOException e2) {
                this.mCameraCallbacks.onCameraError(CameraError.ERROR_CAMERA_OPEN_FAILED);
            } catch (NullPointerException e3) {
                this.mCameraCallbacks.onCameraError(CameraError.ERROR_CAMERA_OPEN_FAILED);
            }
        }
    }

    public void surfaceCreated(final SurfaceHolder surfaceHolder) {
    }

    public void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
        if (this.mCamera != null) {
            this.mCamera.stopPreview();
        }
    }

    void takePictureInternal() {
        this.safeToTakePicture = false;
        if (this.mCamera != null) {
            this.mCamera.takePicture((Camera.ShutterCallback) null, (Camera.PictureCallback) null, (Camera.PictureCallback) new Camera.PictureCallback() {
                public void onPictureTaken(final byte[] array, final Camera camera) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(array, 0, array.length);
                            if (CameraPreview.this.mCameraConfig.getmImageRotation() != 0) {
                                bitmap = HiddenCameraUtils.rotateBitmap(bitmap, CameraPreview.this.mCameraConfig.getmImageRotation());
                            }
                            if (HiddenCameraUtils.saveImageFromFile(bitmap, CameraPreview.this.mCameraConfig.getImageFile(), CameraPreview.this.mCameraConfig.getImageFormat())) {
                                new Handler(Looper.getMainLooper()).post((Runnable) new Runnable() {
                                    @Override
                                    public void run() {
                                        CameraPreview.this.mCameraCallbacks.onImageCapture(CameraPreview.this.mCameraConfig.getImageFile());
                                    }
                                });
                            } else {
                                new Handler(Looper.getMainLooper()).post((Runnable) new Runnable() {
                                    @Override
                                    public void run() {
                                        CameraPreview.this.mCameraCallbacks.onCameraError(9854);
                                    }
                                });
                            }
                            CameraPreview.this.safeToTakePicture = true;
                            if (mCamera != null) {
                                CameraPreview.this.mCamera.startPreview();
                            }

                        }
                    }).start();
                }
            });
            return;
        }
        this.mCameraCallbacks.onCameraError(1122);
        this.safeToTakePicture = true;
    }
}
