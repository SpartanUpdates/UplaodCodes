package com.kotlinz.puzzlecreator.solver;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.google.android.material.tabs.TabLayout;
import com.kotlinz.puzzlecreator.R;
import static com.kotlinz.puzzlecreator.activity.MainActivity.appBarLayout;

public class SolverFragment extends Fragment {
    TabLayout tabLayout;
    LinearLayout frameLayout;

   /* private KProgressHUD hud;
    public InterstitialAd mInterstitialAd;*/

    public SolverFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_solver, container, false);

        tabLayout = view.findViewById(R.id.tabLayout);
        frameLayout = view.findViewById(R.id.frameLayout);

        replaceFragment(new SolverAllFragment());
        /*interstitialAd();*/
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                appBarLayout.setExpanded(true);
                switch (tab.getPosition()) {
                    case 0:
                        /*if (mInterstitialAd != null) {
                            try {
                                hud = KProgressHUD.create(getActivity()).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                                hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (mInterstitialAd != null) {
                                        MyApplication.AdsId = 1;
                                        mInterstitialAd.show(getActivity());
                                    }
                                }
                            }, 2000);
                        } else {
                            replaceFragment(new SolverAllFragment());
                        }*/
                        replaceFragment(new SolverAllFragment());
                        break;
                    case 1:
                        /*if (mInterstitialAd != null) {
                            try {
                                hud = KProgressHUD.create(getActivity()).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                                hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (mInterstitialAd != null) {
                                        MyApplication.AdsId = 2;
                                        mInterstitialAd.show(getActivity());
                                    }
                                }
                            }, 2000);
                        } else {
                            replaceFragment(new SolverAnsweredFragment());
                        }*/
                        replaceFragment(new SolverAnsweredFragment());
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        return view;
    }

    public void replaceFragment(Fragment fragment) {
        getChildFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit();
    }

//    private void interstitialAd() {
//        AdRequest adRequest = new AdRequest.Builder().build();
//        InterstitialAd.load(getActivity(), getResources().getString(R.string.InterstitialAd_id), adRequest,
//                new InterstitialAdLoadCallback() {
//                    @Override
//                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
//                        mInterstitialAd = interstitialAd;
//                        mInterstitialAd.setFullScreenContentCallback(
//                                new FullScreenContentCallback() {
//                                    @Override
//                                    public void onAdDismissedFullScreenContent() {
//                                        requestNewInterstitial();
//                                        switch (MyApplication.AdsId) {
//                                            case 1:
//                                                replaceFragment(new SolverAllFragment());
//                                                break;
//                                            case 2:
//                                                replaceFragment(new SolverAnsweredFragment());
//                                                break;
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onAdFailedToShowFullScreenContent(AdError adError) {
//
//                                    }
//
//                                    @Override
//                                    public void onAdShowedFullScreenContent() {
//
//                                    }
//                                });
//                    }
//
//                    @Override
//                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                    }
//                });
//
//    }
//
//    private void requestNewInterstitial() {
//        interstitialAd();
//    }
}