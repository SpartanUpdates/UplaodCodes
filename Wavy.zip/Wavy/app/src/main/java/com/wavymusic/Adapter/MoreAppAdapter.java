//package com.wavymusic.Adapter;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.wavymusic.Model.MoreAppModel;
//import com.wavymusic.R;
//
//import java.util.ArrayList;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//public class MoreAppAdapter extends RecyclerView.Adapter<MoreAppAdapter.MyViewHolder> {
//
//    private Context context;
//    private ArrayList<MoreAppModel> moreAppList;
//
//    public MoreAppAdapter(Context context, ArrayList<MoreAppModel> moreAppList) {
//        this.context = context;
//        this.moreAppList = moreAppList;
//    }
//
//    @NonNull
//    @Override
//    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_more_app_ads_item, parent, false);
//        return new MyViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return moreAppList.size();
//    }
//
//    public class MyViewHolder extends RecyclerView.ViewHolder {
//        private ImageView ivAds;
//        private TextView tvAppName;
//        private Button btnOpen;
//        private Button btnInstall;
//
//        public MyViewHolder(@NonNull View itemView) {
//            super(itemView);
//            ivAds = itemView.findViewById(R.id.ivAds);
//            tvAppName = itemView.findViewById(R.id.tvAppName);
//            btnOpen = itemView.findViewById(R.id.btnOpen);
//            btnInstall = itemView.findViewById(R.id.btnInstall);
//
//        }
//    }
//}
