package com.esc.tarotcardreading;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.net.URL;

public class PublishOnFbActivity extends AppCompatActivity {
    private static final String APP_ID = "297958600302080";
    private static final String EXPIRES = "expires_in";
    private static final String KEY = "facebook-credentials";
    private static final String[] PERMISSIONS = new String[]{"publish_stream"};
    private static final String TOKEN = "access_token";
    private Facebook facebook;
    private String messageToPost;
    String response;



    private class DownloadFilesTask extends AsyncTask<URL, Integer, String> {
        private DownloadFilesTask() {
        }


        public String doInBackground(URL... urlArr) {
            postToWall(messageToPost);
            return PublishOnFbActivity.this.response;
        }


        public void onPostExecute(String str) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("got response: ");
            stringBuilder.append(PublishOnFbActivity.this.response);
            Log.d("Tests", stringBuilder.toString());
            if (PublishOnFbActivity.this.response == null || PublishOnFbActivity.this.response.equals("") || PublishOnFbActivity.this.response.equals("false")) {
                PublishOnFbActivity.this.showToast("Blank response.");
            } else {
                PublishOnFbActivity.this.showToast("Message posted to your facebook wall!");
            }
            super.onPostExecute(str);
        }
    }

    class LoginDialogListener implements Facebook.DialogListener {
        LoginDialogListener() {
        }

        public void onComplete(Bundle bundle) {
            saveCredentials(facebook);
            if (PublishOnFbActivity.this.messageToPost != null) {
                postToWall(messageToPost);
            }
        }

        public void onFacebookError(FacebookError facebookError) {
            PublishOnFbActivity.this.showToast("Authentication with Facebook failed!");
            String str = "fb error";
            Log.e(str, str);
            PublishOnFbActivity.this.finish();
        }

        public void onError(DialogError dialogError) {
            PublishOnFbActivity.this.showToast("Authentication with Facebook failed!");
            String str = "dl error";
            Log.e(str, str);
            PublishOnFbActivity.this.finish();
        }

        public void onCancel() {
            PublishOnFbActivity.this.showToast("Authentication with Facebook cancelled!");
            String str = "au error";
            Log.e(str, str);
            PublishOnFbActivity.this.finish();
        }
    }

    public boolean saveCredentials(Facebook facebook) {
        Editor edit = getApplicationContext().getSharedPreferences(KEY, 0).edit();
        edit.putString("access_token", facebook.getAccessToken());
        edit.putLong("expires_in", facebook.getAccessExpires());
        return edit.commit();
    }

    public boolean restoreCredentials(Facebook facebook) {
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(KEY, 0);
        facebook.setAccessToken(sharedPreferences.getString("access_token", null));
        facebook.setAccessExpires(sharedPreferences.getLong("expires_in", 0));
        return facebook.isSessionValid();
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView((int) R.layout.facebook_dialog);
        Facebook facebook = new Facebook(APP_ID);
        this.facebook = facebook;
        restoreCredentials(facebook);
        String stringExtra = getIntent().getStringExtra("facebookMessage");
        StringBuilder stringBuilder = new StringBuilder();
        String str = "";
        stringBuilder.append(str);
        stringBuilder.append(stringExtra);
        Log.e("msg passed", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(stringExtra);
        Log.e("msg passed1", stringBuilder.toString());
        this.messageToPost = stringExtra;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append(this.messageToPost);
        Log.e("messageToPost", stringBuilder2.toString());
    }

    public void doNotShare(View view) {
        finish();
    }

    public void share(View view) {
        if (this.facebook.isSessionValid()) {
            new DownloadFilesTask().execute(new URL[]{null, null, null});
            return;
        }
        loginAndPostToWall();
    }

    public void loginAndPostToWall() {
        this.facebook.authorize(this, PERMISSIONS, -1, new LoginDialogListener());
    }

    public void postToWall(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("message", str);
        bundle.putString("description", "topic share");
        try {
            this.facebook.request("me");
            this.response = this.facebook.request("me/feed", bundle, "POST");
            finish();
        } catch (Exception e) {
            showToast("Failed to post to wall!");
            e.printStackTrace();
            finish();
        }
    }

    private void showToast(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
