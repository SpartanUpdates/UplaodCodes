package com.esc.howtomakeschoolsupplies.adapter;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.esc.howtomakeschoolsupplies.activity.MainActivity;
import com.esc.howtomakeschoolsupplies.R;
import java.util.List;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import com.esc.howtomakeschoolsupplies.pojo.Article;
import com.squareup.picasso.Picasso;

public class ListAdapter extends Adapter<ListAdapter.ViewHolder> {
    private final Display display;
    private long duration;
    private final Context mContext;
    private final EventListFragment mEventListFragment;
    private final List<Integer> mListDBFavorites;
    private final List<Integer> mListDBLikes;
    private final List<Object> mListObject;
    public final MediaPlayer mp;
    private final MediaPlayer mpClick;
    private boolean onAttach;
    public Article marticle;

    public interface EventListFragment {
        void onClickBtnArticle(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements OnClickListener {
        CardView layout_item;
        TextView description;
        TextView text_like;
        ImageView image_like;
        ImageView image_favorite;
        ImageView img_icon;

        public ViewHolder(View view) {
            super(view);
            Intrinsics.checkParameterIsNotNull(view, "itemView");
            layout_item = view.findViewById(R.id.layout_item);
            description = view.findViewById(R.id.description);
            text_like = view.findViewById(R.id.text_like);
            image_like = view.findViewById(R.id.image_like);
            image_favorite = view.findViewById(R.id.image_favorite);
            img_icon = view.findViewById(R.id.img_icon);
            itemView.setOnClickListener(this);
        }

        public final Article getArticle() {

            if (marticle == null) {
                Intrinsics.throwUninitializedPropertyAccessException("article");
            }
            return marticle;
        }

        public final void setArticle(Article article) {
            Intrinsics.checkParameterIsNotNull(article, "<set-?>");
            marticle = article;
        }

        @Override
        public void onClick(View view) {
            Intrinsics.checkParameterIsNotNull(view, "view");
            mpClick.start();

            if (MainActivity.Companion.isEnabledInternet()) {
                EventListFragment mEventListFragment = getMEventListFragment();

                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("article");
                }
                mEventListFragment.onClickBtnArticle(((Article) getMListCategory().get(getAdapterPosition())).getId());
                return;
            }
            Toast.makeText(mContext, R.string.turn_internet, Toast.LENGTH_SHORT).show();
        }
    }

    public ListAdapter(Context context, Display display, List<Object> list, List<Integer> list2, List<Integer> list3) {
        Intrinsics.checkParameterIsNotNull(context, "mContext");
        Intrinsics.checkParameterIsNotNull(display, "display");
        Intrinsics.checkParameterIsNotNull(list, "mListObject");
        Intrinsics.checkParameterIsNotNull(list2, "mListDBLikes");
        Intrinsics.checkParameterIsNotNull(list3, "mListDBFavorites");
        this.mContext = context;
        this.display = display;
        this.mListObject = list;
        this.mListDBLikes = list2;
        this.mListDBFavorites = list3;
        marticle = new Article();
        if (context != null) {
            this.mEventListFragment = (EventListFragment) context;
            this.duration = 500;
            this.onAttach = true;
            String str = "raw";
            MediaPlayer create = MediaPlayer.create(context, context.getResources().getIdentifier("wave", str, context.getPackageName()));
            Intrinsics.checkExpressionValueIsNotNull(create, "MediaPlayer.create(mCont…\", mContext.packageName))");
            this.mp = create;
            this.mpClick = MediaPlayer.create(context, context.getResources().getIdentifier("click2", str, context.getPackageName()));
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type com.esc.howtomakeschoolsupplies.adapter.ListAdapter.EventListFragment");
    }

    public final EventListFragment getMEventListFragment() {
        return this.mEventListFragment;
    }

    public final boolean getOnAttach() {
        return this.onAttach;
    }

    public final void setOnAttach(boolean z) {
        this.onAttach = z;
    }

    public final List<Object> getMListCategory() {
        return this.mListObject;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewtype) {
        Intrinsics.checkParameterIsNotNull(viewGroup, "parent");
        LayoutInflater from = LayoutInflater.from(this.mContext);
        String str = "inflater";
        Intrinsics.checkExpressionValueIsNotNull(from, str);
        return new ViewHolder(from.inflate(R.layout.recycler_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int position) {


        if (mListObject.get(position) instanceof Article) {
            Intrinsics.checkParameterIsNotNull(viewHolder, "holder");
            ViewHolder viewholder = (ViewHolder) viewHolder;
            View view = viewHolder.itemView;
            String str = "itemView";
            String str2 = "article";
            Intrinsics.checkExpressionValueIsNotNull(view, str);
            Object obj = mListObject.get(position);
            if (obj != null) {
                marticle = (Article) obj;
                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }
                Intrinsics.checkExpressionValueIsNotNull(view, str);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.description, "itemView.description");
                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }
                viewholder.description.setText(marticle.getDescription());
                StringBuilder img_path = new StringBuilder().append("http://167.172.217.101:8080/chancellery/img/preview/");
                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }

                Picasso.get().load("http://167.172.217.101:8080/chancellery/img/preview/" + marticle.getPreview())
                        .into(viewholder.img_icon);
                Intrinsics.checkExpressionValueIsNotNull(view, str);
                view = viewholder.itemView;
                Intrinsics.checkExpressionValueIsNotNull(view, str);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.text_like, "itemView.text_like");
                img_path = new StringBuilder().append("");
                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }
                viewholder.text_like.setText(img_path.append(marticle.getLikes()).toString());

                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }
                if (checkLikeAndFavorite(mListDBLikes, marticle.getId())) {
                    Intrinsics.checkExpressionValueIsNotNull(view, str);
                    viewholder.image_like.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_like_fill));
                } else {
                    Intrinsics.checkExpressionValueIsNotNull(view, str);
                    viewholder.image_like.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_like_unfill));
                }
                if (marticle == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str2);
                }
                if (checkLikeAndFavorite(mListDBFavorites, marticle.getId())) {
                    Intrinsics.checkExpressionValueIsNotNull(view, str);
                    viewholder.image_favorite.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_rate_fill));
                } else {
                    Intrinsics.checkExpressionValueIsNotNull(view, str);
                    viewholder.image_favorite.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_rate_unfill));
                }
                return;
            }
            throw new TypeCastException("null cannot be cast to non-null type com.esc.howtomakeschoolsupplies.pojo.Article");
        }
    }

    public int getItemCount() {
        return this.mListObject.size();
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        Intrinsics.checkParameterIsNotNull(recyclerView, "recyclerView");
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                Intrinsics.checkParameterIsNotNull(recyclerView, "recyclerView");
                setOnAttach(false);
            }
        });
        super.onAttachedToRecyclerView(recyclerView);
    }

    public final boolean checkLikeAndFavorite(List<Integer> list, int i) {
        Intrinsics.checkParameterIsNotNull(list, "list");
        for (Number intValue : list) {
            if (intValue.intValue() == i) {
                return true;
            }
        }
        return false;
    }
}
