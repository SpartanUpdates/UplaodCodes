package com.esc.photoslideshow.sidemenu.interfaces;

public interface Resourceble {
    int getImageRes();

    String getName();
}
