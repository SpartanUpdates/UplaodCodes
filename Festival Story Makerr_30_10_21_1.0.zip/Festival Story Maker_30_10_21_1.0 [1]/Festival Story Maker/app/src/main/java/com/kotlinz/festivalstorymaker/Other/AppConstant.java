package com.kotlinz.festivalstorymaker.Other;

import android.app.Activity;
import android.util.Log;

import com.kotlinz.festivalstorymaker.Utils.Constant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

public class AppConstant {
    public static String D1 = "logo";
    public static int G = 624;
    public static int H = 7924;
    public static String H1 = null;
    public static int K = 724;
    public static String K1 = "20";
    public static int L = 6709;
    public static String L1 = "34";
    public static String LogoList = "Logo_list";
    public static String FontList = "Font_list";
    public static String P1 = null;
    public static String Q1 = "80";
    public static String R1 = "79";
    public static String V1 = "103";
    public static String X1 = "86";
    public static String Y1 = "89";
    public static String d2 = "35";
    public static String e2 = "55";
    public static String Categoryid = "categoryid";
    public static String SuggetionCount = "suggetion_count";
    public ArrayList<com.kotlinz.festivalstorymaker.Models.b> a;
    public JSONObject jsonObject;
    public JSONObject jsonObjectResponse;
    public JSONObject jsonObjectEdit;
    public JSONArray jsonArray;
    public com.kotlinz.festivalstorymaker.Models.b f;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> g;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> h;
    public com.kotlinz.festivalstorymaker.Models.g editmodel;
    public String j;
    public String k;
    public com.kotlinz.festivalstorymaker.Models.a editMainModel;

    static {
        String str = "28";
        H1 = str;
        P1 = str;
    }

    public void a(com.kotlinz.festivalstorymaker.Other.g.a aVar, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i2);
        stringBuilder.append("");
    }

    public ArrayList b(Activity activity, String str) {
        this.a = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.jsonObject = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                JSONObject jSONObject2 = jsonObject.getJSONObject("response");
                this.jsonObjectEdit = jSONObject2;
                this.jsonArray = jSONObject2.getJSONArray("data");
                for (int i = 0; i < this.jsonArray.length(); i++) {
                    this.jsonObjectResponse = this.jsonArray.getJSONObject(i);
                    this.f = new com.kotlinz.festivalstorymaker.Models.b();
                    this.jsonObjectResponse.getString("id");
                    this.f.g = this.jsonObjectResponse.getString("image");
                    this.f.h = this.jsonObjectResponse.getString("is_premium");
                    this.f.f = this.jsonObjectEdit.getString("total_pages");
                    this.f.e = this.jsonObjectEdit.getString("total_records");
                    this.a.add(this.f);
                }
            } else {
                Utils.N(activity, jsonObject.getString("error"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this.a;
    }

    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> getEditThemFileData(Activity activity, String str) {
        String str2 = "0x";
        String str3 = "color";
        String str4 = "";
        String str5 = "#";
        h = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.jsonObjectResponse = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                JSONArray jSONArray = this.jsonObjectResponse.getJSONArray("response");
                for (int i = 0; i < jSONArray.length(); i++) {
                    editMainModel = new com.kotlinz.festivalstorymaker.Models.a();
                    g = new ArrayList();
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                    editMainModel.b = jSONObject2.getString("type_id");
                    editMainModel.c = jSONObject2.getString("type_name");
                    jsonArray = jSONObject2.getJSONArray("data");
                    for (int i2 = 0; i2 < jsonArray.length(); i2++) {
                        StringBuilder stringBuilder;
                        jsonObjectEdit = jsonArray.getJSONObject(i2);
                        com.kotlinz.festivalstorymaker.Models.g gVar = new com.kotlinz.festivalstorymaker.Models.g();
                        this.editmodel = gVar;
                        gVar.e = this.jsonObjectEdit.getString("type");

                        String filename = this.jsonObjectEdit.getString("src");
                        String filenameArray[] = filename.split("\\.");
                        String extension = filenameArray[filenameArray.length - 1];
                       /* if (extension.equals(".png")) {
                            if (editMainModel.c.equals("Square Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Square" + File.separator + this.jsonObjectEdit.getString("src");
                            } else if (editMainModel.c.equals("Vertical Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Vertical" + File.separator + this.jsonObjectEdit.getString("src");
                            } else if (editMainModel.c.equals("Story Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Story" + File.separator + this.jsonObjectEdit.getString("src");
                            }
                        } else {
                            String FilenameJpg = this.jsonObjectEdit.getString("src");
                            if (FilenameJpg.indexOf(".") > 0)
                                FilenameJpg = FilenameJpg.substring(0, FilenameJpg.lastIndexOf("."));
                            if (editMainModel.c.equals("Square Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Square" + File.separator + FilenameJpg + ".jpg";
                            } else if (editMainModel.c.equals("Vertical Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Vertical" + File.separator + FilenameJpg + ".jpg";
                            } else if (editMainModel.c.equals("Story Post")) {
                                this.editmodel.f = Constant.FolderPath + File.separator + "Story" + File.separator + FilenameJpg + ".jpg";
                            }
                        }*/

                        if (editMainModel.c.equals("Square Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Square" + File.separator + this.jsonObjectEdit.getString("src");
                        } else if (editMainModel.c.equals("Vertical Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Vertical" + File.separator + this.jsonObjectEdit.getString("src");
                        } else if (editMainModel.c.equals("Story Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Story" + File.separator + this.jsonObjectEdit.getString("src");
                        }
                        /* this.editmodel.f = this.jsonObjectEdit.getString("src"); */
                        this.editmodel.g = this.jsonObjectEdit.getString("name");
                        this.editmodel.j = this.jsonObjectEdit.getString("width");
                        this.editmodel.k = this.jsonObjectEdit.getString("height");
                        this.editmodel.h = this.jsonObjectEdit.getString("x");
                        this.editmodel.i = this.jsonObjectEdit.getString("y");
                        this.editmodel.l = this.jsonObjectEdit.getString("is_lock");
                        this.editmodel.m = this.jsonObjectEdit.getString("is_color");
                        this.editmodel.p = this.jsonObjectEdit.getString("is_hue");
                        this.editmodel.q = this.jsonObjectEdit.getString("is_mask");
                        this.editmodel.A = this.jsonObjectEdit.getString("font_name");
                        this.editmodel.C = this.jsonObjectEdit.getString("is_object");
                        this.editmodel.B = this.jsonObjectEdit.getString("is_shape");
                        this.editmodel.I = this.jsonObjectEdit.getString("is_zoom");
                        this.editmodel.H = this.jsonObjectEdit.getString("is_logo");
                        this.editmodel.r = this.jsonObjectEdit.getString("font_spacing");
                        this.editmodel.s = this.jsonObjectEdit.getString("spacing");
                        this.editmodel.t = this.jsonObjectEdit.getString("justification");
                        this.editmodel.G = this.jsonObjectEdit.getString("is_pt");
                        this.editmodel.D = this.jsonObjectEdit.getString("is_st");
                        if (this.jsonObjectEdit.getString("type").equals("text")) {
                            this.editmodel.E = "1";
                        } else {
                            this.editmodel.E = this.jsonObjectEdit.getString("is_bt");
                        }
                        this.editmodel.F = this.jsonObjectEdit.getString("is_wt");
                        this.editmodel.u = this.jsonObjectEdit.getString("lineheight");
                        String string = this.jsonObjectEdit.getString(str3);
                        this.j = string;
                        string = string.replace(str2, str4);
                        this.j = string;
                        if (string.contains(str5)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.jsonObjectEdit.getString(str3).split(str5)[1]);
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.j);
                        }
                        string = stringBuilder.toString();
                        this.j = string;
                        this.editmodel.v = string;
                        this.editmodel.w = this.jsonObjectEdit.getString("size");
                        this.editmodel.x = this.jsonObjectEdit.getString("text").replace("\r", str4);
                        this.editmodel.y = this.jsonObjectEdit.getString("rotation");
                        this.editmodel.z = this.jsonObjectEdit.getString("position");
                        this.editmodel.o = this.jsonObjectEdit.getString("border_size");
                        string = this.jsonObjectEdit.getString("border_color");
                        this.k = string;
                        if (string.length() <= 0 || this.k.equalsIgnoreCase("0")) {
                            this.editmodel.n = str4;
                        } else {
                            String str6;
                            gVar = this.editmodel;
                            if (this.k.contains(str5)) {
                                str6 = str4;
                            } else {
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(str5);
                                stringBuilder2.append(this.k.replace(str2, str4));
                                str6 = stringBuilder2.toString();
                            }
                            gVar.n = str6;
                        }
                        this.g.add(this.editmodel);
                    }
                    this.editMainModel.a = g;
                    this.h.add(editMainModel);
                }
            } else {
                Utils.N(activity, jsonObjectResponse.getString("error"));
            }
            return this.h;
        } catch (JSONException e) {
            e.printStackTrace();
            return this.h;
        }
    }

    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> getCollageEditThemeData(Activity activity, String str) {
        String str2 = "0x";
        String str3 = "color";
        String str4 = "";
        String str5 = "#";
        g = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            jsonObjectResponse = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                jsonArray = jsonObjectResponse.getJSONArray("response");
                for (int i = 0; i < this.jsonArray.length(); i++) {
                    JSONObject jSONObject2 = this.jsonArray.getJSONObject(i);
                    jsonArray = jSONObject2.getJSONArray("data");
                    for (int i2 = 0; i2 < this.jsonArray.length(); i2++) {
                        StringBuilder stringBuilder;
                        this.jsonObjectEdit = this.jsonArray.getJSONObject(i2);
                        com.kotlinz.festivalstorymaker.Models.g gVar = new com.kotlinz.festivalstorymaker.Models.g();
                        this.editmodel = gVar;
                        gVar.e = this.jsonObjectEdit.getString("type");
                        this.editmodel.f = this.jsonObjectEdit.getString("src");
                        this.editmodel.g = this.jsonObjectEdit.getString("name");
                        this.editmodel.j = this.jsonObjectEdit.getString("width");
                        this.editmodel.k = this.jsonObjectEdit.getString("height");
                        this.editmodel.h = this.jsonObjectEdit.getString("x");
                        this.editmodel.i = this.jsonObjectEdit.getString("y");
                        this.editmodel.l = this.jsonObjectEdit.getString("is_lock");
                        this.editmodel.m = this.jsonObjectEdit.getString("is_color");
                        this.editmodel.p = this.jsonObjectEdit.getString("is_hue");
                        this.editmodel.q = this.jsonObjectEdit.getString("is_mask");
                        this.editmodel.A = this.jsonObjectEdit.getString("font_name");
                        this.editmodel.C = this.jsonObjectEdit.getString("is_object");
                        this.editmodel.B = this.jsonObjectEdit.getString("is_shape");
                        this.editmodel.I = this.jsonObjectEdit.getString("is_zoom");
                        this.editmodel.H = this.jsonObjectEdit.getString("is_logo");
                        this.editmodel.r = this.jsonObjectEdit.getString("font_spacing");
                        this.editmodel.s = this.jsonObjectEdit.getString("spacing");
                        this.editmodel.t = this.jsonObjectEdit.getString("justification");
                        this.editmodel.G = this.jsonObjectEdit.getString("is_pt");
                        this.editmodel.D = this.jsonObjectEdit.getString("is_st");
                        this.editmodel.E = this.jsonObjectEdit.getString("is_bt");
                        this.editmodel.F = this.jsonObjectEdit.getString("is_wt");
                        this.editmodel.u = this.jsonObjectEdit.getString("lineheight");
                        str = this.jsonObjectEdit.getString(str3);
                        this.j = str;
                        str = str.replace(str2, str4);
                        this.j = str;
                        if (str.contains(str5)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.jsonObjectEdit.getString(str3).split(str5)[1]);
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.j);
                        }
                        str = stringBuilder.toString();
                        this.j = str;
                        this.editmodel.v = str;
                        this.editmodel.w = this.jsonObjectEdit.getString("size");
                        this.editmodel.x = this.jsonObjectEdit.getString("text").replace("\r", str4);
                        this.editmodel.y = this.jsonObjectEdit.getString("rotation");
                        this.editmodel.z = this.jsonObjectEdit.getString("position");
                        this.editmodel.o = this.jsonObjectEdit.getString("border_size");
                        str = this.jsonObjectEdit.getString("border_color");
                        this.k = str;
                        if (str.length() <= 0 || this.k.equalsIgnoreCase("0")) {
                            this.editmodel.n = str4;
                        } else {
                            String str6;
                            gVar = this.editmodel;
                            if (this.k.contains(str5)) {
                                str6 = str4;
                            } else {
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(str5);
                                stringBuilder2.append(this.k.replace(str2, str4));
                                str6 = stringBuilder2.toString();
                            }
                            gVar.n = str6;
                        }
                        this.g.add(this.editmodel);
                    }
                }
            } else {
                Utils.N(activity, this.jsonObjectResponse.getString("error"));
            }
            return this.g;
        } catch (JSONException e) {
            e.printStackTrace();
            return this.g;
        }
    }
}
