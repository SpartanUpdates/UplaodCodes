class MyRoutes {
  static String myFuelModule = "/myfuel";
  static String myMainModule = "/main";
  static String myTest= "/test";
  static String ownerInfo="/ownerinfo";
}
