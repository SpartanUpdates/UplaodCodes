package com.esc.motivationquotes.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import com.esc.motivationquotes.R;
import com.esc.motivationquotes.model.Pref;
import com.esc.motivationquotes.reminders.RemindersUtils;
import com.esc.motivationquotes.util.Constants;
import com.google.gson.Gson;
import com.esc.motivationquotes.util.AppUtils;
import com.esc.motivationquotes.managers.CategoryManager;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.model.Information;
import com.esc.motivationquotes.util.TrackerEventUtils;
import com.esc.motivationquotes.util.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class SplashScreenActivity extends BaseActivity {

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        checkDate();
        saveLanguage();
        Utils.systemUpgrade(this);
        AppUtils.hasSoftKeys(this);
        showDefaultStart();
    }

    private void showDefaultStart() {
        String str = "1";
        if (Pref.getValue(this, Constants.IS_SLIDER_ON, str).equals(str)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                RemindersUtils.setAlarmOnTime(this);
            }
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                finish();
            }
        }, 2000);
    }

    private void checkDate() {
        String dateOpen = SettingsManager.getDateOpen();
        if (dateOpen == null) {
            SettingsManager.setDateOpen(getCurrentDate());
            return;
        }
        if (getDaysBetweenDates(dateOpen) > 14) {
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_14_DAY, null, null);
        } else if (getDaysBetweenDates(dateOpen) >= 1) {
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_1_DAY, null, null);
            TrackerEventUtils.registerAction(TrackerEventUtils.ACTION_OPEN_1_DAY_MIXPANEL, null, null);
        }
        SettingsManager.setDateOpen(getCurrentDate());
    }

    private String getCurrentDate() {
        return new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
    }

    private int getDaysBetweenDates(String str) {
        try {
            return (int) TimeUnit.DAYS.convert(new Date().getTime() - new SimpleDateFormat("dd-MM-yyyy").parse(str).getTime(), TimeUnit.MILLISECONDS);
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private void saveLanguage() {
        if (SettingsManager.isLanguageFirstTime()) {
            String str = "es";
            String str2 = "_es";
            if (Locale.getDefault().getLanguage().equals(str)) {
                SettingsManager.setLanguage(str);
                if (!CategoryManager.getCategorySelected().contains(str2)) {
                    resetCategory();
                }
            } else {
                SettingsManager.setLanguage("en");
                if (CategoryManager.getCategorySelected().contains(str2)) {
                    resetCategory();
                }
            }
            updateLocale(new Locale(SettingsManager.getLanguage()));
            SettingsManager.setLanguageFirstTime();
        }
    }

    private void resetCategory() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getString(R.string.default_category));
        stringBuilder.append(SettingsManager.getLanguageFiles());
        CategoryManager.setCategorySelected(stringBuilder.toString());
        Information informationJson = getInformationJson();
        CategoryManager.clearCategoriesReminder();
        CategoryManager.addCategoryReminder(informationJson.getCategories().get(0));
    }

    public Information getInformationJson() {
        try {
            AssetManager assets = getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("information");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            stringBuilder.append(".json");
            InputStream open = assets.open(stringBuilder.toString());
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                return new Gson().fromJson(new String(bArr, StandardCharsets.UTF_8), Information.class);
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
        return null;
    }
}
