package com.esc.phoneheart.utility;

import android.os.Environment;
import android.os.StatFs;

import java.io.File;
import java.io.PrintStream;

public class DiskUtils {

    public static long getTotalMemorySize(File file) {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("path.getPath() = ");
        stringBuilder.append(file.getPath());
        printStream.println(stringBuilder.toString());
        StatFs statFs = new StatFs(file.getPath());
        return ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
    }
}
