package com.example.lyricsvideo.videolib.libffmpeg;







class Log
{
  private static String TAG = FFmpeg.class.getSimpleName();
  private static boolean DEBUG = false;
  
  Log() {}
  
  static void setDEBUG(boolean DEBUG) { DEBUG = DEBUG; }
  
  static void d(Object obj)
  {
    if (DEBUG) {
      android.util.Log.d(TAG, null);
    }
  }
  
  static void i(Object obj) {
    if (DEBUG) {
      android.util.Log.i(TAG, null);
    }
  }
  
  static void e(Object obj, Throwable throwable) {
    if (DEBUG) {
      android.util.Log.e(TAG, null, throwable);
    }
  }
  
  static void e(Throwable throwable) {
    if (DEBUG) {
      android.util.Log.e(TAG, "", throwable);
    }
  }
}
