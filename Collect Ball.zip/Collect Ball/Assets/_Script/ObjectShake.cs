﻿using UnityEngine;
using System.Collections;
namespace BallCollect
{
    public class ObjectShake : MonoBehaviour
    {
        Vector3 orignalPosition;

        public bool isX = false, isY = false, isZ = false;
        public float speed = 0.1f;
        public GameObject tempObje;
        Vector3 startPos;
        private void Awake()
        {
            startPos= transform.localPosition;
        }
        private void OnEnable()
        {
            StartCoroutine(Shake(0.5f));
        }

        float elapsed = 0f;
        Vector3 tempPos;
        public IEnumerator Shake(float duration)
        {
            orignalPosition = transform.localPosition;
            tempObje.SetActive(false);
            while (elapsed < duration)
            {
                if (isX)
                {
                    tempPos.x = Random.Range(orignalPosition.x - speed, orignalPosition.x + speed);
                }
                else
                {
                    tempPos.x = orignalPosition.x;
                }

                if (isY)
                {
                    tempPos.y = Random.Range(orignalPosition.y - speed, orignalPosition.y + speed);
                }
                else
                {
                    tempPos.y = orignalPosition.y;
                }

                if (isZ)
                {
                    tempPos.z = Random.Range(orignalPosition.z - speed, orignalPosition.z + speed);
                }
                else
                {
                    tempPos.z = orignalPosition.z;
                }

                transform.localPosition = tempPos;
                elapsed += Time.deltaTime;
                yield return 0;
            }
            transform.localPosition = orignalPosition;
            yield return new WaitForSecondsRealtime(1f);
            this.gameObject.SetActive(false);
            tempObje.SetActive(true);

        }
        void OnDisable()
        {
            this.gameObject.SetActive(false);
            tempObje.SetActive(true);
            transform.localPosition= startPos;
            elapsed = 00;
        }
    }
}