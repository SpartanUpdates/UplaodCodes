package com.UnitedVideos.CropImage.bitmapUtil;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

import com.wavymusic.App.MyApplication;

import java.lang.reflect.Array;

public class a {
    @SuppressLint({"NewApi"})
    public static Bitmap a(final Bitmap bitmap, final int n, final Context context) {
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final RenderScript create = RenderScript.create(context);
        final ScriptIntrinsicBlur create2 = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        final Allocation fromBitmap = Allocation.createFromBitmap(create, bitmap);
        final Allocation fromBitmap2 = Allocation.createFromBitmap(create, bitmap2);
        create2.setRadius((float) n);
        create2.setInput(fromBitmap);
        create2.forEach(fromBitmap2);
        fromBitmap2.copyTo(bitmap2);
        create.destroy();
        return bitmap2;
    }

    public static Bitmap a(Bitmap copy, final int n, final boolean b) {
        final Bitmap bitmap = copy;
        if (Build.VERSION.SDK_INT >= 17) {
            return a(bitmap, n, (Context) MyApplication.getInstance());
        }
        if (b) {
            copy = bitmap;
        } else {
            copy = bitmap.copy(copy.getConfig(), true);
        }
        if (n < 1) {
            return null;
        }
        final int width = copy.getWidth();
        final int height = copy.getHeight();
        final int n2 = width * height;
        final int[] array = new int[n2];
        copy.getPixels(array, 0, width, 0, 0, width, height);
        final int n3 = width - 1;
        int n4 = height - 1;
        final int n5 = n + n + 1;
        final int[] array2 = new int[n2];
        final int[] array3 = new int[n2];
        final int[] array4 = new int[n2];
        final int[] array5 = new int[Math.max(width, height)];
        final int n6 = n5 + 1 >> 1;
        final int n7 = n6 * n6;
        final int n8 = 256 * n7;
        final int[] array6 = new int[n8];
        for (int i = 0; i < n8; ++i) {
            array6[i] = i / n7;
        }
        final int[][] array7 = (int[][]) Array.newInstance(Integer.TYPE, n5, 3);
        final int n9 = n + 1;
        int j = 0;
        int n10 = 0;
        int n11 = 0;
        int n12;
        int n23;
        int n24;
        for (n12 = height; j < n12; j = n24 + 1, n4 = n23) {
            final int n13 = -n;
            int n14 = 0;
            int n15 = 0;
            int n16 = 0;
            int n17 = 0;
            int n18 = 0;
            int n19 = 0;
            int n20 = 0;
            int n21 = 0;
            int n22 = 0;
            n23 = n4;
            n24 = j;
            for (int k = n13; k <= n; ++k) {
                final int n25 = array[n10 + Math.min(n3, Math.max(k, 0))];
                final int[] array8 = array7[k + n];
                array8[0] = (n25 & 0xFF0000) >> 16;
                array8[1] = (n25 & 0xFF00) >> 8;
                array8[2] = (n25 & 0xFF);
                final int n26 = n9 - Math.abs(k);
                n14 += array8[0] * n26;
                n15 += array8[1] * n26;
                n16 += array8[2] * n26;
                if (k > 0) {
                    n17 += array8[0];
                    n18 += array8[1];
                    n19 += array8[2];
                } else {
                    n20 += array8[0];
                    n21 += array8[1];
                    n22 += array8[2];
                }
            }
            final int n27 = 0;
            int n28 = n17;
            int n29 = n;
            int n30 = n18;
            int n31 = n14;
            for (int l = n27; l < width; ++l) {
                array2[n10] = array6[n31];
                array3[n10] = array6[n15];
                array4[n10] = array6[n16];
                final int[] array9 = array7[(n29 - n + n5) % n5];
                final int n32 = array9[0];
                final int n33 = array9[1];
                final int n34 = array9[2];
                if (n24 == 0) {
                    array5[l] = Math.min(l + n + 1, n3);
                }
                final int n35 = array[n11 + array5[l]];
                array9[0] = (n35 & 0xFF0000) >> 16;
                array9[1] = (n35 & 0xFF00) >> 8;
                array9[2] = (n35 & 0xFF);
                final int n36 = n28 + array9[0];
                final int n37 = n30 + array9[1];
                final int n38 = n19 + array9[2];
                n31 = n31 - n20 + n36;
                n15 = n15 - n21 + n37;
                n16 = n16 - n22 + n38;
                n29 = (n29 + 1) % n5;
                final int[] array10 = array7[n29 % n5];
                n20 = n20 - n32 + array10[0];
                n21 = n21 - n33 + array10[1];
                n22 = n22 - n34 + array10[2];
                n28 = n36 - array10[0];
                n30 = n37 - array10[1];
                n19 = n38 - array10[2];
                ++n10;
            }
            n11 += width;
        }
        final int n39 = 0;
        final int n40 = n12;
        for (int n41 = n39; n41 < width; ++n41) {
            int n42 = -n;
            int n43 = n42 * width;
            int n44 = 0;
            int n45 = 0;
            int n46 = 0;
            int n47 = 0;
            int n48 = 0;
            int n49 = 0;
            int n50 = 0;
            int n51 = 0;
            int n52 = 0;
            while (n42 <= n) {
                final int n53 = Math.max(0, n43) + n41;
                final int[] array11 = array7[n42 + n];
                array11[0] = array2[n53];
                array11[1] = array3[n53];
                array11[2] = array4[n53];
                final int n54 = n9 - Math.abs(n42);
                final int n55 = n44 + array2[n53] * n54;
                n45 += array3[n53] * n54;
                n46 += array4[n53] * n54;
                if (n42 > 0) {
                    n47 += array11[0];
                    n48 += array11[1];
                    n49 += array11[2];
                } else {
                    n50 += array11[0];
                    n51 += array11[1];
                    n52 += array11[2];
                }
                int n56 = n43;
                if (n42 < n4) {
                    n56 = n43 + width;
                }
                ++n42;
                n43 = n56;
                n44 = n55;
            }
            final int n57 = n41;
            final int n58 = 0;
            int n59 = n47;
            int n60 = n;
            int n61 = n49;
            int n62 = n48;
            int n63 = n44;
            int n64 = n57;
            for (int n65 = n58; n65 < n40; ++n65) {
                array[n64] = ((0xFF000000 & array[n64]) | array6[n63] << 16 | array6[n45] << 8 | array6[n46]);
                final int[] array12 = array7[(n60 - n + n5) % n5];
                final int n66 = array12[0];
                final int n67 = array12[1];
                final int n68 = array12[2];
                if (n41 == 0) {
                    array5[n65] = Math.min(n65 + n9, n4) * width;
                }
                final int n69 = array5[n65] + n41;
                array12[0] = array2[n69];
                array12[1] = array3[n69];
                array12[2] = array4[n69];
                final int n70 = n59 + array12[0];
                final int n71 = n62 + array12[1];
                final int n72 = n61 + array12[2];
                n63 = n63 - n50 + n70;
                n45 = n45 - n51 + n71;
                n46 = n46 - n52 + n72;
                n60 = (n60 + 1) % n5;
                final int[] array13 = array7[n60];
                n50 = n50 - n66 + array13[0];
                n51 = n51 - n67 + array13[1];
                n52 = n52 - n68 + array13[2];
                n59 = n70 - array13[0];
                n62 = n71 - array13[1];
                n61 = n72 - array13[2];
                n64 += width;
            }
        }
        copy.setPixels(array, 0, width, 0, 0, width, n40);
        return copy;
    }
}
