package com.libffmpeg;

class CommandResult
{
    final String output;
    final boolean success;

    CommandResult(final boolean success, final String output) {
        this.success = success;
        this.output = output;
    }

    static CommandResult getDummyFailureResponse() {
        return new CommandResult(false, "");
    }

    static CommandResult getOutputFromProcess(final Process process) {
        String s;
        if (success(process.exitValue())) {
            s = Util.convertInputStreamToString(process.getInputStream());
        }
        else {
            s = Util.convertInputStreamToString(process.getErrorStream());
        }
        return new CommandResult(success(process.exitValue()), s);
    }

    static boolean success(final Integer n) {
        return n != null && n == 0;
    }
}
