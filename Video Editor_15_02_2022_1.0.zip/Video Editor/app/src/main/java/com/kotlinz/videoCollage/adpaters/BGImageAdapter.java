package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.BGImageAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class BGImageAdapter extends Adapter<BGImageAdapter.ViewHolder> {
    private Context context;
    private ArrayList<String> listImage;
    private BGImageAdapterCallBackInterface listener;
    private int pos = 0;

    class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        ImageView imgBgImage;
        ImageView imgBgImageSelector;

        ViewHolder(View view) {
            super(view);
            this.imgBgImage = (ImageView) view.findViewById(R.id.img_bg_image);
            this.imgBgImageSelector = (ImageView) view.findViewById(R.id.img_bg_image_selector);
        }
    }

    public BGImageAdapter(ArrayList<String> arrayList, Context context, BGImageAdapterCallBackInterface bGImageAdapterCallBackInterface) {
        this.listImage = arrayList;
        this.listener = bGImageAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_image_bg, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        InputStream open;
        String str = (String) this.listImage.get(i);
        try {
            AssetManager assets = this.context.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("background/");
            stringBuilder.append(str);
            open = assets.open(stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
            open = null;
        }
        viewHolder.imgBgImage.setImageBitmap(BitmapFactory.decodeStream(open));
        viewHolder.imgBgImage.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                BGImageAdapter.this.pos = i;
                BGImageAdapter.this.listener.itemClick(i);
                BGImageAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgBgImageSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgBgImageSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" pos :: ");
        stringBuilder.append(i);
        Log.e("colimg", stringBuilder.toString());
        this.pos = i;
    }

    public int getItemCount() {
        return this.listImage.size();
    }
}
