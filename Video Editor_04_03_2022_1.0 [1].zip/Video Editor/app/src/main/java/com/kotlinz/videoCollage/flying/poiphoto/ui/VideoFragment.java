package com.kotlinz.videoCollage.flying.poiphoto.ui;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.flying.poiphoto.Configure;
import com.kotlinz.videoCollage.flying.poiphoto.VideoManager;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.VideoAdapter;
import com.kotlinz.videoeditor.R;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class VideoFragment extends Fragment {
    ImageView back;
    ImageView done;
    private VideoAdapter mAdapter;
    RecyclerView mVideoList;
    private VideoManager mVideoManager;

    private class VideoTask extends AsyncTask<String, Integer, List<Video>> {
        private VideoTask() {
        }

        VideoTask(VideoFragment videoFragment) {
            this();
        }


        public List<Video> doInBackground(String... strArr) {
            return VideoFragment.this.mVideoManager.getVideo(strArr[0]);
        }


        public void onPostExecute(List<Video> list) {
            super.onPostExecute(list);
            VideoFragment.this.refreshVideoList(list);
        }
    }

    public static VideoFragment newInstance(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("bucketId", str);
        VideoFragment videoFragment = new VideoFragment();
        videoFragment.setArguments(bundle);
        return videoFragment;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mVideoManager = new VideoManager(getContext());
        ActionBar supportActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.poivideo_fragment_video, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        init(view);
        String string = getArguments().getString("bucketId");
        new VideoTask(this).execute(new String[]{string});
    }

    private void init(final View view) {
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        final Configure configure = ((PickVideoActivity) getActivity()).getConfigure();
        if (toolbar != null) {
            initToolbar(toolbar, configure);
        }
        this.back = (ImageView) view.findViewById(R.id.img_video_tool_back);
        this.done = (ImageView) view.findViewById(R.id.img_video_tool_done);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.video_list);
        this.mVideoList = recyclerView;
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        VideoAdapter videoAdapter = new VideoAdapter(getActivity(), "replace");
        this.mAdapter = videoAdapter;
        videoAdapter.setMaxCount(configure.getMaxCount());
        this.mAdapter.setOnSelectedMaxListener(new VideoAdapter.OnSelectedMaxListener() {
            public void onSelectedMax() {
                Snackbar.make(view, configure.getMaxNotice(), BaseTransientBottomBar.LENGTH_SHORT).show();
            }
        });
        this.mAdapter.setOnVideoSelectedListener(new VideoAdapter.OnVideoSelectedListener() {
            public void onVideoSelected(Video video, int i) {
            }
        });
        this.mAdapter.setOnVideoUnSelectedListener(new  VideoAdapter.OnVideoUnSelectedListener() {
            public void onVideoUnSelected(Video video, int i) {
            }
        });
        this.mVideoList.setHasFixedSize(true);
        this.mVideoList.setAdapter(this.mAdapter);
        this.back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                VideoFragment.this.getActivity().onBackPressed();
            }
        });
        this.done.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (VideoFragment.this.mAdapter.getSelectedVideoPaths().size() > 0) {
                    Intent intent = new Intent();
                    intent.putExtra("video_path", (String) VideoFragment.this.mAdapter.getSelectedVideoPaths().get(0));
                    VideoFragment.this.getActivity().setResult(-1, intent);
                    VideoFragment.this.getActivity().finish();
                    return;
                }
                Toast.makeText(VideoFragment.this.getContext(), "Select any one video", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initToolbar(Toolbar toolbar, Configure configure) {
        if (configure != null) {
            toolbar.setTitle(configure.getVideoTitle());
            toolbar.setBackgroundColor(configure.getToolbarColor());
            toolbar.setTitleTextColor(configure.getToolbarTitleColor());
        }
    }

    private void refreshVideoList(List<Video> list) {
        this.mAdapter.refreshData(list);
    }
}
