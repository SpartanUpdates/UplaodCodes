package com.videozoneinc.musicvideoeditor.videolib.libffmpeg;

interface ResponseHandler {
    void onFinish();

    void onStart();
}
