package com.esc.motivationquotes.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;

public class Section implements Serializable {
    @SerializedName("category_ids")
    private ArrayList<String> categoriesId;
    @SerializedName("name")
    private String name;

    public String getName() {
        return this.name;
    }

    public ArrayList<String> getCategoriesId() {
        return this.categoriesId;
    }
}
