package com.esc.phoneheart.activity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.StrictMode;
import android.text.TextUtils;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.esc.phoneheart.OpenAds.AppOpenManager;
import com.esc.phoneheart.model.JunkData;
import com.esc.phoneheart.duplicatefiles.DuplicateFilesData;
import com.esc.phoneheart.model.DownloadsData;
import com.esc.phoneheart.model.FileManagerModule;
import com.esc.phoneheart.utility.ForegroundCheck;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread.UncaughtExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

public class PhoneCleaner extends MultiDexApplication {

    AppOpenManager appOpenManager;

    public static final String TAG = PhoneCleaner.class.getSimpleName();
    public static volatile PhoneCleaner mInstance;
    public ArrayList<String> advancedCleaningList = new ArrayList();
    public DownloadsData downloadsData;
    public DuplicateFilesData duplicateFilesData;
    public JunkData junkData;
    public FileManagerModule socialModule;
    public FileManagerModule spaceManagerModule;
    private RequestQueue mRequestQueue;

    public BroadcastReceiver myLanguageChangeReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            try {
                PhoneCleaner.this.a(context);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    public static synchronized PhoneCleaner getInstance() {
        PhoneCleaner phoneCleaner;
        synchronized (PhoneCleaner.class) {
            if (mInstance == null) {
                mInstance = new PhoneCleaner();
            }
            phoneCleaner = mInstance;
        }
        return phoneCleaner;
    }

    @SuppressLint("WrongConstant")
    private void handleUncaughtException(Thread thread, Throwable th) {
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        th.printStackTrace();
        String format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(Calendar.getInstance().getTime());
        String str = "CRASH2.txt";
        Util.appendLog(stringWriter.toString(), str);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(format);
        stringBuilder.append(" ");
        stringBuilder.append(stringWriter.toString());
        Util.appendLogphonecleaner("<<<<<<<CRASH>>>>>>", stringBuilder.toString(), str);
        System.exit(0);
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(getPackageName());
        launchIntentForPackage.addFlags(268435456);
        startActivity(launchIntentForPackage);
    }

    public void onCreate() {
        super.onCreate();
        mInstance = this;
        MultiDex.install(getApplicationContext());
        AudienceNetworkAds.initialize(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        ForegroundCheck.init(this);
        GlobalData.SETAPPLAnguage(this);
        try {
            registerReceiver(this.myLanguageChangeReceiver, new IntentFilter("android.intent.action.LOCALE_CHANGED"));
        } catch (Exception e22) {
            e22.printStackTrace();
        }

        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            public void uncaughtException(Thread thread, Throwable th) {
                PhoneCleaner.this.handleUncaughtException(thread, th);
            }
        });

        MobileAds.initialize(getApplicationContext());
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public void a(Context context) {
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

}
