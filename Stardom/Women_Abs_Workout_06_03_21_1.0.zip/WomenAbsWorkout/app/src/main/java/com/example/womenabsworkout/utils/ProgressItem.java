package com.example.womenabsworkout.utils;

public class ProgressItem {
    public int color;
    public float progressItemPercentage;
}
