package com.xyz.vehiclemanager.bike.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.adapter.BikeColorAdapter;
import com.xyz.vehiclemanager.bike.adapter.BikeVariantAdapter;
import com.xyz.vehiclemanager.bike.model.BikeDetailsRoot;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeVariantActivity extends AppCompatActivity {
    private Activity activity = BikeVariantActivity.this;
    private String modelId, modelName, imageUrl;
    private ImageView iv_back, iv_bikemodel;
    private TextView tv_title, tvbikemodelname, tv_bikeprice;
    private RecyclerView rv_color;
    private RecyclerView rv_variant;
    private BikeVariantAdapter bikeVarientAdapter;
    private BikeColorAdapter bikeColorAdapter;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bike_variant);

        modelId = getIntent().getStringExtra("modelId");
        modelName = getIntent().getStringExtra("modelName");
        imageUrl = getIntent().getStringExtra("imageUrl");
        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        PutAnalyticsEvent();
        BindView();
        DialogAnimation();
        if (Utils.isOnline(activity)) {
            getBikeVariantData();
        } else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView() {
        tvbikemodelname = findViewById(R.id.tv_carname);
        tv_title = findViewById(R.id.tv_title);
        tv_bikeprice = findViewById(R.id.tv_bikeprice);
        iv_bikemodel = findViewById(R.id.iv_bikemodel);
        iv_back = findViewById(R.id.iv_back);
        rv_color = findViewById(R.id.rv_color);
        rv_variant = findViewById(R.id.rv_variant);
        tv_title.setText(modelName);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeVariantActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void getBikeVariantData() {
        Call<BikeDetailsRoot> call = rtoDetailsInterface.getbikevariantdata(modelId);
        call.enqueue(new Callback<BikeDetailsRoot>() {
            @Override
            public void onResponse(Call<BikeDetailsRoot> call, Response<BikeDetailsRoot> response) {
                if (response.isSuccessful()) {
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    String exShowroomPrice = response.body().getDetails().getExShowroomPrice();
                    tvbikemodelname.setText(modelName);
                    tv_bikeprice.setText(exShowroomPrice);

                    Glide.with(BikeVariantActivity.this)
                            .load(imageUrl)
                            .placeholder(R.drawable.ic_bike)
                            .into(iv_bikemodel);

                    //BikeColor Adapter Set
                    ArrayList<BikeDetailsRoot.Details.Color> colorlist = response.body().getDetails().getColors();
                    bikeColorAdapter = new BikeColorAdapter(activity, colorlist);
                    rv_color.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false));
                    rv_color.setAdapter(bikeColorAdapter);

                    //BikeVariantData Adapter Set
                    ArrayList<BikeDetailsRoot.Details.Variant> variantlist = response.body().getDetails().getVariants();
                    bikeVarientAdapter = new BikeVariantAdapter(activity, variantlist);
                    rv_variant.setLayoutManager(new LinearLayoutManager(activity));
                    rv_variant.setAdapter(bikeVarientAdapter);
                }
            }

            @Override
            public void onFailure(Call<BikeDetailsRoot> call, Throwable t) {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}