package com.kotlinz.videoeditor.MyCreation.activity;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.kotlinz.videoeditor.MyCreation.fragment.MyVideoFragment;
import com.kotlinz.videoeditor.MyCreation.fragment.SelectVideoFragment;
import com.google.android.material.tabs.TabLayout;

import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.ArrayList;
import java.util.List;

public class MyAlbumActivity extends AppCompatActivity {
    static final boolean a = true;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private final int[] d = {R.drawable.icon_video, R.drawable.icon_myalbum};

    class a extends FragmentPagerAdapter {
        private final List<Fragment> b = new ArrayList();
        private final List<String> c = new ArrayList();

        public a(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public Fragment getItem(int i) {
            return b.get(i);
        }

        public int getCount() {
            return b.size();
        }

        public void a(Fragment fragment, String str) {
            b.add(fragment);
            c.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return c.get(i);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.liststatusactivity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText("Create Video");
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        PutAnalyticsEvent();
        if (a || supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(a);
            supportActionBar.setDisplayShowTitleEnabled(false);
            viewPager = findViewById(R.id.viewpager);
            a(viewPager);
            tabLayout = findViewById(R.id.tabs);
            tabLayout.setupWithViewPager(viewPager);
            a();
            return;
        }
        throw new AssertionError();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyAlbumActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void a() {
        tabLayout.getTabAt(0).setIcon(d[0]);
        tabLayout.getTabAt(1).setIcon(d[1]);
    }

    private void a(ViewPager viewPager) {
        a aVar = new a(getSupportFragmentManager());
        aVar.a(new SelectVideoFragment(), "VIDEO");
        aVar.a(new MyVideoFragment(), "MY ALBUM");
        viewPager.setAdapter(aVar);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), StartActivity.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return a;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return a;
        }
        if (itemId == R.id.shareapp) {
            StringBuilder sb = new StringBuilder();

            String sb2 = sb.toString();
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.TEXT", sb2);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public boolean isOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager.getActiveNetworkInfo() == null || !connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting()) {
            return false;
        }
        return a;
    }
}
