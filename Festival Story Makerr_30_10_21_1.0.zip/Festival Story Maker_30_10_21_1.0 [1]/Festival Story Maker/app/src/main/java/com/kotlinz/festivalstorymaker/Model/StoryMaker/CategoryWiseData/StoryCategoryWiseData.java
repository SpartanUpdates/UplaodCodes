package com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData;

import com.google.gson.annotations.SerializedName;

public class StoryCategoryWiseData {

	@SerializedName("is_image_count")
	private String isImageCount;

	@SerializedName("mask_image")
	private String maskImage;

	@SerializedName("type_id")
	private String typeId;

	@SerializedName("theme_id")
	private int themeId;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("application_id")
	private String applicationId;

	@SerializedName("datafile")
	private String datafile;

	@SerializedName("version")
	private String version;

	@SerializedName("child_category")
	private String childCategory;

	@SerializedName("theme_thumbnail")
	private String themeThumbnail;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("is_pro")
	private String isPro;

	@SerializedName("parent_category")
	private String parentCategory;

	@SerializedName("is_mask")
	private String isMask;

	@SerializedName("module_name")
	private String moduleName;

	public String getIsImageCount(){
		return isImageCount;
	}

	public String getMaskImage(){
		return maskImage;
	}

	public String getTypeId(){
		return typeId;
	}

	public int getThemeId(){
		return themeId;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getApplicationId(){
		return applicationId;
	}

	public String getDatafile(){
		return datafile;
	}

	public String getVersion(){
		return version;
	}

	public String getChildCategory(){
		return childCategory;
	}

	public String getThemeThumbnail(){
		return themeThumbnail;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getIsPro(){
		return isPro;
	}

	public String getParentCategory(){
		return parentCategory;
	}

	public String getIsMask(){
		return isMask;
	}

	public String getModuleName(){
		return moduleName;
	}
}