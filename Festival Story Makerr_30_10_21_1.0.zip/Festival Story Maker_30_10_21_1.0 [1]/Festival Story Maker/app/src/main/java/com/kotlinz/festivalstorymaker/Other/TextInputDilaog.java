package com.kotlinz.festivalstorymaker.Other;


import android.widget.*;
import android.view.inputmethod.*;
import android.content.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.*;
import androidx.fragment.app.DialogFragment;

import android.os.*;
import android.graphics.*;
import android.view.*;
import android.text.*;

import com.kotlinz.festivalstorymaker.R;


public class TextInputDilaog extends DialogFragment {
    public static final String o0;
    public static EditText etEnterText;
    public static boolean isDialog;
    public static String editData;
    public static boolean isEmpty;
    public InputMethodManager inputmanager;
    public int ColorCode;
    public d m0;
    public c n0;

    static {
        o0 = TextInputDilaog.class.getSimpleName();
        TextInputDilaog.isEmpty = false;
    }

    public static TextInputDilaog q0(final Context context, final String s, final boolean q0, final String r0) {
        TextInputDilaog.isEmpty = false;
        TextInputDilaog.isDialog = q0;
        TextInputDilaog.editData = r0;
        return r0((AppCompatActivity) context, s, a.c(context, R.color.white));
    }

    public static TextInputDilaog r0(final AppCompatActivity appCompatActivity, final String s, final int n) {
        final Bundle bundle = new Bundle();
        bundle.putString("extra_input_text", s);
        bundle.putInt("extra_color_code", n);
        final TextInputDilaog h = new TextInputDilaog();
        h.setArguments(bundle);
        h.showNow(appCompatActivity.getSupportFragmentManager(), TextInputDilaog.o0);
        return h;
    }

    public static TextInputDilaog s0(final Context context, final String s, final boolean q0, final String r0) {
        TextInputDilaog.isEmpty = true;
        TextInputDilaog.isDialog = q0;
        TextInputDilaog.editData = r0;
        return r0((AppCompatActivity) context, s, a.c(context, R.color.white));
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle Bundle) {
        return layoutInflater.inflate(R.layout.add_text_dialog, viewGroup, false);
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextInputDilaog.etEnterText = (EditText) view.findViewById(R.id.add_text_edit_text);
        this.inputmanager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        TextInputDilaog.etEnterText.requestFocus();
        TextInputDilaog.etEnterText.setText((CharSequence) getArguments().getString("extra_input_text"));
        TextInputDilaog.etEnterText.setSelection(getArguments().getString("extra_input_text").length());
        this.ColorCode = getArguments().getInt("extra_color_code");

        if (TextInputDilaog.isEmpty) {
            TextInputDilaog.etEnterText.setHint((CharSequence) "Enter Price Here");
        }
        TextInputDilaog.etEnterText.setTextColor(Color.parseColor("#000000"));
        this.inputmanager.toggleSoftInput(2, 0);
        view.findViewById(R.id.add_text_done_tv).setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                TextInputDilaog.this.inputmanager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                dismiss();
                final String string = TextInputDilaog.etEnterText.getText().toString();
                TextInputDilaog h = TextInputDilaog.this;
                c c = h.n0;
                if (c != null) {
                    if (!TextInputDilaog.isEmpty) {
                        if (TextUtils.isEmpty((CharSequence) string)) {
                            return;
                        }
                        h = TextInputDilaog.this;
                        c = h.n0;
                    }
                    /*d.a(string, h.l0);*/
                    return;
                }
                d d = h.m0;
                if (d != null) {
                    if (!TextInputDilaog.isEmpty) {
                        if (TextUtils.isEmpty((CharSequence) string)) {
                            return;
                        }
                        h = TextInputDilaog.this;
                        d = h.m0;
                    }
                    d.a(string, h.ColorCode);
                }
            }
        });
        view.findViewById(R.id.add_text_cancel_tv).setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                TextInputDilaog.this.inputmanager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                final String string = TextInputDilaog.etEnterText.getText().toString();
                dismiss();
                final TextInputDilaog f = TextInputDilaog.this;
                final c n0 = f.n0;
                if (n0 != null) {
                    final c c = n0;
                    return;
                }
                f.m0.b(string);
            }
        });
        if (TextInputDilaog.isDialog) {
            TextInputDilaog.etEnterText.setFilters(new InputFilter[]{(InputFilter) new InputFilter.LengthFilter(TextInputDilaog.editData.length() + 5)});
        }
    }


    public interface c {
    }

    public interface d {
        void a(final String p0, final int p1);

        void b(final String p0);
    }
}
