package com.root.UnitySendValue;

import android.content.Context;
import android.util.Log;

import com.intel.inde.mp.GLCapture;
import com.intel.inde.mp.IProgressListener;
import com.intel.inde.mp.VideoFormat;
import com.intel.inde.mp.android.AndroidMediaObjectFactory;
import com.intel.inde.mp.android.VideoFormatAndroid;

import java.io.IOException;

public class VideoCapture {
    private static final String TAG = "VideoCapture";
    private static final String Codec = "video/avc";
    private static int IFrameInterval;
    private static final Object syncObject;
    private static volatile VideoCapture videoCapture;
    private static VideoFormat videoFormat;
    private static int videoWidth;
    private static int videoHeight;
    private GLCapture capturer;
    private boolean isConfigured;
    private boolean isStarted;
    private long framesCaptured;
    private Context context;
    private IProgressListener progressListener;

    static {
        VideoCapture.IFrameInterval = 1;
        syncObject = new Object();
    }

    public VideoCapture(final Context context, final IProgressListener progressListener) {
        this.context = context;
        this.progressListener = progressListener;
    }

    public static void init(final int width, final int height, final int frameRate, final int bitRate) {
        int biratenew = 5000;
        try {
            VideoCapture.videoWidth = width;
            VideoCapture.videoHeight = height;
            (VideoCapture.videoFormat = new VideoFormatAndroid("video/avc", VideoCapture.videoWidth, VideoCapture.videoHeight)).setVideoFrameRate(frameRate);
            VideoCapture.videoFormat.setVideoBitRateInKBytes(biratenew);
            VideoCapture.videoFormat.setVideoIFrameInterval(VideoCapture.IFrameInterval);
//            setVideoBitRateInKBytes(biratenew);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setVideoBitRateInKBytes(int bitRate) {
        if ((double) (videoWidth * videoHeight * 30 * 2) * 7.0E-5D < (double) bitRate) {
            bitRate = (int) ((double) (videoWidth * videoHeight * 30 * 2) * 7.0E-5D);
        }
        setInteger("bitrate", bitRate * 1024);
    }

    public static void setInteger(String var1, int var2) {

    }

    public void start(final String videoPath) throws IOException {
        try {
            if (this.isStarted()) {
                throw new IllegalStateException("VideoCapture already started!");
            }
//            Toast.makeText(this.context, "Video Cap Start", Toast.LENGTH_SHORT).show();
            (this.capturer = new GLCapture(new AndroidMediaObjectFactory(this.context), this.progressListener)).setTargetFile(videoPath);
            this.capturer.setTargetVideoFormat(VideoCapture.videoFormat);
            this.capturer.start();
            this.isStarted = true;
            this.isConfigured = false;
            this.framesCaptured = 0L;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stop() {
        try {
            if (!this.isStarted()) {
                throw new IllegalStateException("VideoCapture not started or already stopped!");
            }
            try {
                this.capturer.stop();
                this.isStarted = false;
            } catch (Exception ex) {
            }
            this.capturer = null;
            this.isConfigured = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configure() {
        if (this.isConfigured()) {
            return;
        }
        try {
            this.capturer.setSurfaceSize(VideoCapture.videoWidth, VideoCapture.videoHeight);
            this.isConfigured = true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void beginCaptureFrame() {
        try {
            if (!this.isStarted()) {
                return;
            }
            this.configure();
            if (!this.isConfigured()) {
                return;
            }
            this.capturer.beginCaptureFrame();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void endCaptureFrame() {
        try {
            if (!this.isStarted() || !this.isConfigured()) {
                return;
            }
            this.capturer.endCaptureFrame();
            ++this.framesCaptured;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isStarted() {
        return this.isStarted;
    }

    public boolean isConfigured() {
        return this.isConfigured;
    }
}
