package com.esc.lovemessages;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.ads.AdRequest;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.snackbar.Snackbar.SnackbarLayout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GifViewAdapter extends RecyclerView.Adapter<GifViewAdapter.GifViewHolder> {
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    Activity activity;
    GifDataBaseHelper db = new GifDataBaseHelper(this.mContext);
    ArrayList<Integer> favorite;
    ArrayList<Integer> gifid;
    CoordinatorLayout giflayout;
    ArrayList<String> giftext;
    ArrayList<String> gifurl;
    Context mContext;
    Typeface typeface = Typeface.createFromAsset(this.mContext.getAssets(), "fonts/CormorantGaramond-Bold.ttf");

    public class GifViewHolder extends ViewHolder {
        public ImageView copyImageView;
        public ImageView download_imageView;
        public ImageView favorite_imageView;
        public ImageView gif_imageView;
        RelativeLayout gif_lock;
        public TextView gif_textView;
        public CoordinatorLayout gifactionlayout;
        public TextView saveTextView;
        public TextView shareTextView;
        public ImageView share_imageView;

        public GifViewHolder(View view) {
            super(view);
            this.shareTextView = view.findViewById(R.id.save_image_textview);
            this.saveTextView = view.findViewById(R.id.share_image_textview);
            this.gif_textView = view.findViewById(R.id.gif_textview);
            this.gif_imageView = view.findViewById(R.id.gif_imageview);
            this.gif_lock = view.findViewById(R.id.gif_lock);
            this.download_imageView = view.findViewById(R.id.gif_download);
            this.share_imageView = view.findViewById(R.id.gif_share);
            this.copyImageView = view.findViewById(R.id.gif_copy);
            this.favorite_imageView = view.findViewById(R.id.gif_favorite);
            this.gifactionlayout = view.findViewById(R.id.snackbar_messageview);
            this.gif_textView.setTypeface(GifViewAdapter.this.typeface);
        }
    }

    public GifViewAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<Integer> arrayList3, ArrayList<Integer> arrayList4, Activity activity) {
        this.activity = activity;
        this.mContext = context;
        this.giftext = arrayList;
        this.gifurl = arrayList2;
        this.gifid = arrayList3;
        this.favorite = arrayList4;
    }

    public GifViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new GifViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gifcard_view, viewGroup, false));
    }

    public void onBindViewHolder(final GifViewHolder gifViewHolder, final int i) {
        gifViewHolder.gif_textView.setText(Html.fromHtml(this.giftext.get(i)));
        ((RequestBuilder) Glide.with(this.mContext).asGif().load(this.gifurl.get(i)).placeholder(R.drawable.loadinggif)).into(gifViewHolder.gif_imageView);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GifViewAdaptor gifurl");
        stringBuilder.append(this.gifurl);
        Log.e("GifViewActivity", stringBuilder.toString());
        if ((i + 1) % 4 != 0) {
            gifViewHolder.gif_lock.setVisibility(View.INVISIBLE);
            gifViewHolder.download_imageView.setVisibility(View.VISIBLE);
            gifViewHolder.share_imageView.setVisibility(View.VISIBLE);
            gifViewHolder.shareTextView.setVisibility(View.INVISIBLE);
            gifViewHolder.saveTextView.setVisibility(View.VISIBLE);
        } else {
            SharedPreferences sharedPreferences = GifViewActivity.sharedPreferencesgif;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("gif_");
            stringBuilder2.append(this.gifid.get(i));
            if (sharedPreferences.getBoolean(stringBuilder2.toString(), false)) {
                gifViewHolder.gif_lock.setVisibility(View.INVISIBLE);
                gifViewHolder.download_imageView.setVisibility(View.VISIBLE);
                gifViewHolder.share_imageView.setVisibility(View.INVISIBLE);
                gifViewHolder.shareTextView.setVisibility(View.VISIBLE);
                gifViewHolder.saveTextView.setVisibility(View.VISIBLE);
            } else {
                gifViewHolder.gif_lock.setVisibility(View.VISIBLE);
                gifViewHolder.download_imageView.setVisibility(View.INVISIBLE);
                gifViewHolder.share_imageView.setVisibility(View.INVISIBLE);
                gifViewHolder.shareTextView.setVisibility(View.INVISIBLE);
                gifViewHolder.saveTextView.setVisibility(View.INVISIBLE);
            }
        }
        if (this.favorite.get(i).intValue() == 1) {
            gifViewHolder.favorite_imageView.setImageResource(R.drawable.ic_favorite_black_24dp);
        } else {
            gifViewHolder.favorite_imageView.setImageResource(R.drawable.ic_favorite_border_black_24dp);
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.gifurl.get(i));
        Log.e("URL", stringBuilder.toString());
        gifViewHolder.download_imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(GifViewAdapter.this.mContext, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                    Toast.makeText(GifViewAdapter.this.mContext, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                    GifViewAdapter.this.checkAndRequestPermissions();
                    return;
                }
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("gif url ");
                stringBuilder.append(GifViewAdapter.this.gifurl.get(i));
                Log.e("GifViewAdaptor", stringBuilder.toString());
                Glide.with(GifViewAdapter.this.mContext).download(GifViewAdapter.this.gifurl.get(i)).listener(new RequestListener<File>() {
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        GifViewAdapter.this.ShowSnackBar(GifViewAdapter.this.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.errortitle));
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            GifViewAdapter.this.saveGifImage(GifViewAdapter.this.mContext, GifViewAdapter.this.getBytesFromFile(file), GifViewAdapter.this.createName(GifViewAdapter.this.gifurl.get(i)), "", "save");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return true;
                    }
                }).submit();
                GifViewActivity.AddRateClicks();
            }
        });
        gifViewHolder.share_imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(GifViewAdapter.this.mContext, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                    Toast.makeText(GifViewAdapter.this.mContext, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                    GifViewAdapter.this.checkAndRequestPermissions();
                    return;
                }
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                Glide.with(GifViewAdapter.this.mContext).download(GifViewAdapter.this.gifurl.get(i)).listener(new RequestListener<File>() {
                    public boolean onLoadFailed(GlideException glideException, Object obj, Target<File> target, boolean z) {
                        GifViewAdapter.this.ShowSnackBar(GifViewAdapter.this.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.errortitle));
                        return false;
                    }

                    public boolean onResourceReady(File file, Object obj, Target<File> target, DataSource dataSource, boolean z) {
                        try {
                            GifViewAdapter.this.saveGifImage(GifViewAdapter.this.mContext, GifViewAdapter.this.getBytesFromFile(file), GifViewAdapter.this.createName(GifViewAdapter.this.gifurl.get(i)), (String) GifViewAdapter.this.giftext.get(i), "share");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return true;
                    }
                }).submit();
                GifViewActivity.AddRateClicks();
            }
        });
        gifViewHolder.gif_textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                hashMap.put("Message", GifViewAdapter.this.giftext.get(i));
                ((ClipboardManager) GifViewAdapter.this.mContext.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BirthdayGifText", GifViewAdapter.this.giftext.get(i)));
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                GifViewAdapter gifViewAdapter = GifViewAdapter.this;
                gifViewAdapter.ShowSnackBar(gifViewAdapter.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.copiedtoclipboard));
            }
        });
        gifViewHolder.gif_lock.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                GifViewAdapter gifViewAdapter = GifViewAdapter.this;
                gifViewAdapter.ShowSnackBar(gifViewAdapter.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.tryagain));
            }
        });
        gifViewHolder.favorite_imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                String str = "Favorite";
                GifViewAdapter gifViewAdapter;
                if (GifViewAdapter.this.favorite.get(i).intValue() == 0) {
                    gifViewHolder.favorite_imageView.setImageResource(R.drawable.ic_favorite_black_24dp);
                    GifViewAdapter.this.db.updateFavorite(1, GifViewAdapter.this.gifid.get(i).intValue());
                    gifViewAdapter = GifViewAdapter.this;
                    gifViewAdapter.ShowSnackBar(gifViewAdapter.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.marked));
                    gifViewHolder.favorite_imageView.invalidate();
                    GifViewAdapter.this.favorite.set(i, Integer.valueOf(1));
                    String str2 = "Marked";
                    hashMap.put(str, str2);
                    hashMap.put(str2, GifViewAdapter.this.gifid.get(i).toString());
                } else if (GifViewAdapter.this.favorite.get(i).intValue() == 1) {
                    gifViewHolder.favorite_imageView.setImageResource(R.drawable.ic_favorite_border_black_24dp);
                    GifViewAdapter.this.db.updateFavorite(0, GifViewAdapter.this.gifid.get(i).intValue());
                    gifViewAdapter = GifViewAdapter.this;
                    gifViewAdapter.ShowSnackBar(gifViewAdapter.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.Unmarked));
                    gifViewHolder.favorite_imageView.invalidate();
                    GifViewAdapter.this.favorite.set(i, Integer.valueOf(0));
                    hashMap.put(str, "UnMarked");
                    hashMap.put("Unmarked", GifViewAdapter.this.gifid.get(i).toString());
                }
            }
        });
        gifViewHolder.copyImageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                hashMap.put("Subcategory", GifViewActivity.subcategory);
                hashMap.put("MessageId", GifViewAdapter.this.gifid.get(i).toString());
                hashMap.put("Message", GifViewAdapter.this.giftext.get(i));
                ClipboardManager clipboardManager = (ClipboardManager) GifViewAdapter.this.mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(GifViewAdapter.this.giftext.get(i));
                StringBuilder stringBuilder2 = new StringBuilder();
                String str = "<br>";
                stringBuilder2.append(str);
                stringBuilder2.append(GifViewAdapter.this.mContext.getResources().getString(R.string.fromshare));
                stringBuilder2.append(str);
                stringBuilder2.append("https://play.google.com/store/apps/details?id=" + activity.getPackageName());
                stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                clipboardManager.setPrimaryClip(ClipData.newPlainText("BirthdayGifText", stringBuilder.toString()));
                GifViewAdapter.this.giflayout = gifViewHolder.gifactionlayout;
                GifViewAdapter gifViewAdapter = GifViewAdapter.this;
                gifViewAdapter.ShowSnackBar(gifViewAdapter.giflayout, GifViewAdapter.this.mContext.getResources().getString(R.string.copiedtoclipboard));
            }
        });
    }

    private boolean checkAndRequestPermissions() {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        int checkSelfPermission = ContextCompat.checkSelfPermission(this.mContext, str);
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission != 0) {
            arrayList.add(str);
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this.activity, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
        return false;
    }

    public int getItemCount() {
        return this.gifid.size();
    }

    public void saveGifImage(Context context, byte[] bArr, String str, String str2, String str3) {
        String str4 = "<br>";
        String str5 = "save";
        try {
            File externalStoragePublicDirectory;
            if (str3.equals(str5)) {
                externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
            } else {
                externalStoragePublicDirectory = this.mContext.getCacheDir();
            }
            File file = new File(externalStoragePublicDirectory, "lovegifs");
            if (!file.exists()) {
                file.mkdirs();
            }
            if (file.exists()) {
                externalStoragePublicDirectory = new File(file, str);
                FileOutputStream fileOutputStream = new FileOutputStream(externalStoragePublicDirectory);
                fileOutputStream.write(bArr);
                fileOutputStream.flush();
                fileOutputStream.close();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("file path = ");
                stringBuilder.append(externalStoragePublicDirectory.getAbsolutePath());
                Log.e("GIf", stringBuilder.toString());
                boolean equals = str3.equals(str5);
                str = "image/gif";
                str3 = "";
                if (equals) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("title", externalStoragePublicDirectory.getName());
                    contentValues.put("_display_name", externalStoragePublicDirectory.getName());
                    contentValues.put("description", str3);
                    contentValues.put("mime_type", str);
                    contentValues.put("date_added", Long.valueOf(System.currentTimeMillis()));
                    contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
                    contentValues.put("_data", externalStoragePublicDirectory.getAbsolutePath());
                    context.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, contentValues);
                    ShowSnackBar(this.giflayout, this.mContext.getResources().getString(R.string.gifsaved));
                    return;
                }
                Uri uriForFile = FileProvider.getUriForFile(this.mContext, String.valueOf(activity.getPackageName()) + ".provider", externalStoragePublicDirectory);
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setDataAndType(uriForFile, this.mContext.getContentResolver().getType(uriForFile));
                intent.putExtra("android.intent.extra.TITLE", this.mContext.getResources().getString(R.string.appname));
                intent.putExtra("android.intent.extra.SUBJECT", "Love Messages For Wife");
                intent.putExtra("android.intent.extra.STREAM", uriForFile);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str2);
                stringBuilder2.append(str3);
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(str4);
                stringBuilder3.append(this.mContext.getResources().getString(R.string.fromshare));
                stringBuilder3.append(str4);
                stringBuilder3.append("https://play.google.com/store/apps/details?id=" + activity.getPackageName());
                stringBuilder2.append(Html.fromHtml(stringBuilder3.toString()));
                intent.putExtra("android.intent.extra.TEXT", stringBuilder2.toString());
                intent.setType(str);
                this.mContext.startActivity(Intent.createChooser(intent, this.mContext.getResources().getString(R.string.sharevia)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public byte[] getBytesFromFile(File file) throws IOException {
        long length = file.length();
        if (length <= 2147483647L) {
            byte[] bArr = new byte[((int) length)];
            int i = 0;
            FileInputStream fileInputStream = new FileInputStream(file);
            while (i < bArr.length) {
                try {
                    int read = fileInputStream.read(bArr, i, bArr.length - i);
                    if (read < 0) {
                        break;
                    }
                    i += read;
                } catch (Throwable th) {
                    fileInputStream.close();
                }
            }
            fileInputStream.close();
            if (i >= bArr.length) {
                return bArr;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not completely read file ");
            stringBuilder.append(file.getName());
            throw new IOException(stringBuilder.toString());
        }
        throw new IOException("File is too large!");
    }

    public String createName(String str) {
        return str.substring(str.lastIndexOf(47) + 1);
    }

    public void ShowSnackBar(View view, String str) {
        Snackbar make = Snackbar.make(view, str, Snackbar.LENGTH_SHORT);
        SnackbarLayout snackbarLayout = (SnackbarLayout) make.getView();
        snackbarLayout.setLayoutParams(new LayoutParams(-1, -2));
        TextView textView = snackbarLayout.findViewById(R.id.snackbar_text);
        if ((this.mContext.getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(24.0f);
        } else if ((this.mContext.getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(20.0f);
        } else {
            textView.setTextSize(14.0f);
        }
        int i = 0;
        while (i < snackbarLayout.getChildCount() && !(snackbarLayout.getChildAt(i) instanceof LinearLayout)) {
            i++;
        }
        make.show();
    }
}
