package com.unikapp.faceappeditor.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.unikapp.faceappeditor.Utils.FrameModel;
import com.unikapp.faceage.editorapp.R;

import java.util.ArrayList;

public class Adapter_Frame extends BaseAdapter {
	public ArrayList<FrameModel> frames = new ArrayList();
	private Context context;

	static class Viewholder {
		ImageView imageView;

		Viewholder() {
		}
	}

	public Adapter_Frame(Context c, ArrayList<FrameModel> frame) {
		this.context = c;
		this.frames = frame;
	}

	public int getCount() {
		return this.frames.size();
	}

	public Object getItem(int i) {
		return null;
	}

	public long getItemId(int i) {
		return 0;
	}

	public View getView(int Position, View convertView, ViewGroup viewGroup) {
		Viewholder holder;
		View row = convertView;
		if (row == null) {
			row = LayoutInflater.from(this.context).inflate(
					R.layout.framelayout, viewGroup, false);
			holder = new Viewholder();
			holder.imageView = (ImageView) row.findViewById(R.id.img);
			row.setTag(holder);
		} else {
			holder = (Viewholder) row.getTag();
		}
		Glide.with(this.context)
				.load(Integer.valueOf(((FrameModel) this.frames.get(Position))
						.getFrameID())).centerCrop()
				.placeholder((int) R.mipmap.ic_launcher).crossFade()
				.into(holder.imageView);
		return row;
	}
}
