package com.wavymusic.mp3Cutter.Services;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.MediaPlayer;

import com.wavymusic.mp3Cutter.activity.SongCropActivity;

public class SongMediaPlayer {

    private AssetManager f6062a;
    private String f6063b = null;
    private MediaPlayer f6064c = new MediaPlayer();

    public SongMediaPlayer(Context context) {
        this.f6062a = context.getAssets();
    }

    public String a() {
        return this.f6063b;
    }

    public void a(long j) {
        this.f6064c.seekTo((int) j);
    }

    public void a(String str) {
        this.f6063b = str;
    }

    public void b() {
        this.f6064c.reset();
        try {
            this.f6064c.setDataSource(this.f6063b);
            this.f6064c.prepare();
            this.f6064c.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer mediaPlayer) {
                    if (SongCropActivity.l) {
                        mediaPlayer.start();
                    } else {
                        SongCropActivity.l = true;
                    }
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public int c() {
        return this.f6064c.getCurrentPosition();
    }

    public void d() {
        if (this.f6064c.isPlaying()) {
            this.f6064c.pause();
        }
    }

    public boolean e() {
        return this.f6064c.isPlaying();
    }

    public void f() {
        if (!this.f6064c.isPlaying()) {
            this.f6064c.start();
        }
    }

    public void g() {
        if (this.f6064c.isPlaying()) {
            this.f6064c.stop();
        }
    }
}