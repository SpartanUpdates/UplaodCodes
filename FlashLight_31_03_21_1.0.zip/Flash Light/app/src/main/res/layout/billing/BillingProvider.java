package flash.light.shine.com.billing;

public interface BillingProvider {
    BillingManager getBillingManager();
}
