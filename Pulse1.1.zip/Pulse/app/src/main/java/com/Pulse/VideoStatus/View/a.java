package com.Pulse.VideoStatus.View;

public class a {
    public static String ThemeCategoryWiseDataUrl = "http://trendinganimations.com/api/category/fullscreen/theme";
    public static String ThemeCategoryUrl = "http://trendinganimations.com/api/get/categories";
    public static String DownloadCountUrl = "http://trendinganimations.com/api/download/theme";
    public static String UpdateDataUrl = "https://raw.githubusercontent.com/githubupdatesdemo/BeatsMusic/master/ForceUpdatesBeats.txt";
}
