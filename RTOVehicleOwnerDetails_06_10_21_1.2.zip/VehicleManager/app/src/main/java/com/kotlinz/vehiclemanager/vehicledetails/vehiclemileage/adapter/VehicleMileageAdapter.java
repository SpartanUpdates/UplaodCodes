package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room.MileageDatabase;
import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;

import java.text.DecimalFormat;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class VehicleMileageAdapter extends RecyclerView.Adapter<VehicleMileageAdapter.ViewHolder> {

    Context context;
    Boolean darkMode;
    List<Mileage> arrayList;

    public VehicleMileageAdapter(Context context, Boolean darkMode, List<Mileage> arrayList) {
        this.context = context;
        this.darkMode = darkMode;
        this.arrayList = arrayList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_from_kms, tv_to_kms, tv_pricefuel, tv_date, tv_kmperltr, tv_inrperkm, tv_inrperltr,distance;
        LinearLayout ll_click, ll_mainLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_from_kms = itemView.findViewById(R.id.tv_from_kms);
            tv_to_kms = itemView.findViewById(R.id.tv_to_kms);
            tv_pricefuel = itemView.findViewById(R.id.tv_pricefuel);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_kmperltr = itemView.findViewById(R.id.tv_kmperltr);
            tv_inrperkm = itemView.findViewById(R.id.tv_inrperkm);
            tv_inrperltr = itemView.findViewById(R.id.tv_inrperltr);
            ll_click = itemView.findViewById(R.id.ll_click);
            ll_mainLayout = itemView.findViewById(R.id.ll_mainLayout);
            distance=itemView.findViewById(R.id.distance);
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.layout_mileage, null, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (darkMode) {
            holder.ll_mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
            holder.ll_click.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        }
        Mileage mileage = arrayList.get(position);

        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("You spend ");
        stringBuilder.append(mileage.getFuel());
        stringBuilder.append(" Rs. for ");
        stringBuilder.append(mileage.getPrice());
        stringBuilder.append(" ");
        stringBuilder.append(" liter fuel.");

        holder.tv_from_kms.setText(arrayList.get(position).getLastReserve());
        holder.tv_to_kms.setText(arrayList.get(position).getCurrentReserve());
        holder.distance.setText(" = "+(Integer.valueOf(arrayList.get(position).getCurrentReserve())-Integer.valueOf(arrayList.get(position).getLastReserve())+" Km You Traveled."));
        holder.tv_pricefuel.setText(stringBuilder.toString());
        holder.tv_date.setText(mileage.getDate());
        holder.tv_kmperltr.setText(mileage.getMileageKm() + " Km/ltr || ");
        holder.tv_inrperltr.setText(mileage.getMileageInrLtr() + " Rs/km");
        holder.tv_inrperkm.setText(mileage.getMileageInrKm() + " Rs/ltr || ");

        holder.ll_click.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View v) {
                View view = ((LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_delete_itemdialog, null);
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(view);
                builder.setCancelable(true);
                final AlertDialog dialog = builder.create();
                dialog.show();

                TextView tv_delete = view.findViewById(R.id.tv_delete);
                TextView tv_cancel = view.findViewById(R.id.tv_cancel);
                TextView deleteMsg=view.findViewById(R.id.deleteMsg);
                LinearLayout mainLayout=view.findViewById(R.id.mainLayout);

                DarkTheame darkTheame=new DarkTheame(context);
                if(darkTheame.modeData().equals("nightMode"))
                {
                    mainLayout.setBackgroundColor(Color.parseColor("#4E4E4E"));
                    deleteMsg.setTextColor(Color.parseColor("#FFFFFF"));
                }
                tv_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MileageDatabase mileageDatabase= Room.databaseBuilder(context, MileageDatabase.class, "MileageDatabase").allowMainThreadQueries().build();
                        mileageDatabase.mileageDao().deleteMileage(arrayList.get(position).getId());
                        deleteItem(position);
                        Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });

                tv_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
        });

    }

    private void deleteItem(int position2) {
        arrayList.remove(position2);
        notifyItemRemoved(position2);
        notifyItemRangeChanged(position2, arrayList.size());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }
}
