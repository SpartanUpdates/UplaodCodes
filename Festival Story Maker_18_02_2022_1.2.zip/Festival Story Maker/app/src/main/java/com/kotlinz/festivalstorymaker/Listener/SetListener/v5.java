package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.widget.FrameLayout;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class v5 implements TextStickerViewNew1.a {
    public final FrameLayout a;
    public final TextStickerViewNew1 b;
    public final FrameEditorNewDesign c;

    public v5(final FrameEditorNewDesign c, final FrameLayout a, final TextStickerViewNew1 b) {
        this.c = c;
        this.a = a;
        this.b = b;
    }

    @Override
    public void a(final TextStickerViewNew1 s1) {
        this.c.scroll.requestDisallowInterceptTouchEvent(true);
        final TextStickerViewNew1 s2 = this.c.s1;
        if (s2 != null) {
            s2.setInEdit(false);
            this.c.s1.setShowHelpBox(false);
        }
        (this.c.s1 = s1).setInEdit(true);
        this.c.s1.setShowHelpBox(true);
    }

    @Override
    public void b(final TextStickerViewNew1 textStickerViewNew1) {
        /*FrameEditorNewDesign.i0(this.c, this.a, this.b);*/
    }

    @Override
    public void c(final TextStickerViewNew1 textStickerViewNew1) {
        if (this.c.s1 != null && textStickerViewNew1.getTag().equals(this.c.s1.getTag()) && textStickerViewNew1.u) {
            this.a.removeView((View) textStickerViewNew1);
        }
    }

    @Override
    public void d(final TextStickerViewNew1 s1) {
        final FrameEditorNewDesign c = this.c;
        c.t1 = true;
        c.s1 = s1;
        c.B0(true);
    }
}
