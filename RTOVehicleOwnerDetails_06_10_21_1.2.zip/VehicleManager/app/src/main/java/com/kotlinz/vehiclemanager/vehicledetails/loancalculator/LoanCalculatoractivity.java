package com.kotlinz.vehiclemanager.vehicledetails.loancalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import org.jetbrains.annotations.NotNull;
import java.math.BigDecimal;
import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;

public class LoanCalculatoractivity extends AppCompatActivity {

    private Activity activity = LoanCalculatoractivity.this;
    private EditText totalAmmount, rate, year, month;
    private ImageView findEmi, reset, iv_back;
    private TextView monthlyEmi, interestCharge, totalAmount_tv, title_tv;
    private LinearLayout ll_emiDataLayout;
    private Float fTotal = 00f, fRate = 00f, fTime = 00f;
    String sTotalAmmount;
    String sRate;
    String sYear;
    String sMonth;

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(LoanCalculatoractivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_calculatoractivity);
        bindView();
        BannerAds();
        InterAds();
        DarkTheame darkTheame = new DarkTheame(LoanCalculatoractivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 3;
                    interstitialAd.show();
                } else {
                    resetData();
                }
            }
        });
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findEmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                caluculateEmi();
            }
        });
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(LoanCalculatoractivity.this, MainActivity.class));
                        finish();
                        break;
                    case 2:
                        finalCalculation(sTotalAmmount, sRate, sYear, sMonth);
                        break;
                    case 3:
                        resetData();
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void resetData() {
        totalAmmount.setFocusable(true);
        totalAmmount.getText().clear();
        rate.getText().clear();
        year.getText().clear();
        month.getText().clear();
        monthlyEmi.setText("0000");
        interestCharge.setText("0.0 %");
        totalAmount_tv.setText("0000");
    }

    private void caluculateEmi() {

        sTotalAmmount = totalAmmount.getText().toString().trim();
        sRate = rate.getText().toString().trim();
        sYear = year.getText().toString().trim();
        sMonth = month.getText().toString().trim();

        if (!TextUtils.isEmpty(sTotalAmmount) && !TextUtils.isEmpty(sRate)) {
            if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                id = 2;
                interstitialAd.show();
            } else {
                finalCalculation(sTotalAmmount, sRate, sYear, sMonth);
            }
        } else {
            Toast.makeText(LoanCalculatoractivity.this, "Please Fill Up All The Fields ! ", Toast.LENGTH_SHORT).show();
        }
    }

    private void finalCalculation(String sTotalAmmount, String sRate, String sYear, String sMonth) {
        if (sYear.isEmpty() && !sMonth.isEmpty()) {
            try {

                month.setCursorVisible(false);
                year.setCursorVisible(false);

                fTotal = Float.parseFloat(sTotalAmmount);
                fRate = Float.parseFloat(sRate);
                fTime = Float.parseFloat(sMonth);
                fRate = fRate / (12 * 100);
                /* fTime=fTime*12;*/
                double emi = (fTotal * fRate * Math.pow(1 + fRate, fTime)) / (Math.pow(1 + fRate, fTime) - 1);

                int interest = (int) ((emi * fTime) - fTotal);
                int iEmi = (int) Math.abs(emi);
                int iTotal = (int) (fTotal + interest);

                Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                monthlyEmi.setText(format.format(new BigDecimal(iEmi).setScale(0, BigDecimal.ROUND_DOWN)) + "");
                interestCharge.setText(format.format(new BigDecimal(interest).toBigInteger()) + "");
                totalAmount_tv.setText(format.format(new BigDecimal(iTotal).toBigInteger()) + "");

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        } else if (sMonth.isEmpty() && !sYear.isEmpty()) {
            try {

                month.setCursorVisible(false);
                year.setCursorVisible(false);

                fTotal = Float.parseFloat(sTotalAmmount);
                fRate = Float.parseFloat(sRate);
                fTime = Float.parseFloat(sYear) * 12;
                fRate = fRate / (12 * 100);
                /* fTime=fTime*12;*/
                double emi = (fTotal * fRate * Math.pow(1 + fRate, fTime)) / (Math.pow(1 + fRate, fTime) - 1);

                int interest = (int) ((emi * fTime) - fTotal);
                int iEmi = (int) Math.abs(emi);
                int iTotal = (int) (fTotal + interest);

                Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                monthlyEmi.setText(format.format(new BigDecimal(iEmi).toBigInteger()) + "");
                interestCharge.setText(format.format(new BigDecimal(interest).toBigInteger()) + "");
                totalAmount_tv.setText(format.format(new BigDecimal(iTotal).toBigInteger()) + "");

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        } else if (!sYear.isEmpty() && !sMonth.isEmpty()) {
            try {

                month.setCursorVisible(false);
                year.setCursorVisible(false);

                fTotal = Float.parseFloat(sTotalAmmount);
                fRate = Float.parseFloat(sRate);
                fTime = Float.parseFloat(sYear) * 12 + Float.parseFloat(sMonth);
                fRate = fRate / (12 * 100);
                /* fTime=fTime*12;*/
                double emi = (fTotal * fRate * Math.pow(1 + fRate, fTime)) / (Math.pow(1 + fRate, fTime) - 1);

                int interest = (int) ((emi * fTime) - fTotal);
                int iEmi = (int) Math.abs(emi);
                int iTotal = (int) (fTotal + interest);

                Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                monthlyEmi.setText(format.format(new BigDecimal(iEmi).toBigInteger()) + "");
                interestCharge.setText(format.format(new BigDecimal(interest).toBigInteger()) + "");
                totalAmount_tv.setText(format.format(new BigDecimal(iTotal).toBigInteger()) + "");

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Please enter year or months !", Toast.LENGTH_SHORT).show();
        }

    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_emiDataLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        totalAmmount.setTextColor(Color.parseColor("#FFFFFF"));
        rate.setTextColor(Color.parseColor("#FFFFFF"));
        year.setTextColor(Color.parseColor("#FFFFFF"));
        month.setTextColor(Color.parseColor("#FFFFFF"));
        monthlyEmi.setTextColor(Color.parseColor("#C1C1C1"));
        interestCharge.setTextColor(Color.parseColor("#C1C1C1"));
        totalAmount_tv.setTextColor(Color.parseColor("#C1C1C1"));
    }

    private void bindView() {
        totalAmmount = findViewById(R.id.principal);
        rate = findViewById(R.id.rate);
        year = findViewById(R.id.year);
        month = findViewById(R.id.months);
        findEmi = findViewById(R.id.findEmi);
        monthlyEmi = findViewById(R.id.monthlyEmi);
        interestCharge = findViewById(R.id.interestCharge);
        totalAmount_tv = findViewById(R.id.totalAmount);
        reset = findViewById(R.id.reset);
        title_tv = findViewById(R.id.title_tv);
        iv_back = findViewById(R.id.iv_back);
        ll_emiDataLayout = findViewById(R.id.ll_emiDataLayout);
    }
}