package com.vidsoft.Filters.AllStickerSupports;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.SystemClock;
import androidx.core.content.ContextCompat;
import androidx.core.view.MotionEventCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.FrameLayout;

import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class StickerView extends FrameLayout {
    private static final int DEFAULT_MIN_CLICK_DELAY_TIME = 200;
    private static final String TAG = "StickerView";
    private Paint borderPaint;
    Canvas canvas;
    private boolean constrained;
    private ActionMode currentMode;
    private BitmapStickerIcon deleteIcon;
    private Matrix downMatrix;
    private float downX;
    private float downY;
    private BitmapStickerIcon flipIcon;
    private Sticker handlingSticker;
    private long lastClickTime;
    private boolean locked;
    private PointF midPoint;
    private int minClickDelayTime;
    private Matrix moveMatrix;
    private float oldDistance;
    private float oldRotation;
    private OnStickerOperationListener onStickerOperationListener;
    private Matrix sizeMatrix;
    private RectF stickerRect;
    private List<Sticker> stickers;
    private int touchSlop;
    private BitmapStickerIcon zoomIcon;

    static class switchClass1 {
        static final int[] $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode;

        static {
            $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode = new int[ActionMode.values().length];
            try {
                $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode[ActionMode.NONE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode[ActionMode.DRAG.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode[ActionMode.ZOOM_WITH_TWO_FINGER.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode[ActionMode.ZOOM_WITH_ICON.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    private enum ActionMode {
        NONE,
        DRAG,
        ZOOM_WITH_TWO_FINGER,
        ZOOM_WITH_ICON,
        DELETE,
        FLIP_HORIZONTAL,
        CLICK
    }

    public interface OnStickerOperationListener {
        void onStickerClicked(Sticker sticker);

        void onStickerDeleted(Sticker sticker);

        void onStickerDoubleTapped(Sticker sticker);

        void onStickerDragFinished(Sticker sticker);

        void onStickerFlipped(Sticker sticker);

        void onStickerZoomFinished(Sticker sticker);
    }

    public StickerView(Context context) {
        this(context, null);
    }

    public StickerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StickerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.oldDistance = 0.0f;
        this.oldRotation = 0.0f;
        this.currentMode = ActionMode.NONE;
        this.stickers = new ArrayList();
        this.touchSlop = 3;
        this.lastClickTime = 0;
        this.minClickDelayTime = DEFAULT_MIN_CLICK_DELAY_TIME;
        this.borderPaint = new Paint();
        this.borderPaint.setAntiAlias(true);
        this.borderPaint.setColor(getResources().getColor(R.color.Sticker_Border_Color));
        this.borderPaint.setStrokeWidth(2.0f);
        this.sizeMatrix = new Matrix();
        this.downMatrix = new Matrix();
        this.moveMatrix = new Matrix();
        this.stickerRect = new RectF();
        this.deleteIcon = new BitmapStickerIcon(ContextCompat.getDrawable(getContext(), R.mipmap.icon_delete));
        this.zoomIcon = new BitmapStickerIcon(ContextCompat.getDrawable(getContext(), R.mipmap.icon_resize));
        this.flipIcon = new BitmapStickerIcon(ContextCompat.getDrawable(getContext(), R.mipmap.icon_flip));
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            this.stickerRect.left = (float) left;
            this.stickerRect.top = (float) top;
            this.stickerRect.right = (float) right;
            this.stickerRect.bottom = (float) bottom;
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        drawStickers(canvas);
    }

    private void drawStickers(Canvas canvas) {
        for (int i = 0; i < this.stickers.size(); i++) {
            Sticker sticker = (Sticker) this.stickers.get(i);
            if (sticker != null) {
                sticker.draw(canvas);
            }
        }
        if (this.handlingSticker != null && !this.locked) {
            float[] bitmapPoints = getStickerPoints(this.handlingSticker);
            float x1 = bitmapPoints[0];
            float y1 = bitmapPoints[1];
            float x2 = bitmapPoints[2];
            float y2 = bitmapPoints[3];
            float x3 = bitmapPoints[4];
            float y3 = bitmapPoints[5];
            float x4 = bitmapPoints[6];
            float y4 = bitmapPoints[7];
            canvas.drawLine(x1, y1, x2, y2, this.borderPaint);
            canvas.drawLine(x1, y1, x3, y3, this.borderPaint);
            Canvas canvas2 = canvas;
            float f = x2;
            float f2 = y2;
            canvas2.drawLine(f, f2, x4, y4, this.borderPaint);
            Canvas canvas3 = canvas;
            float f3 = x3;
            float f4 = y3;
            canvas3.drawLine(x4, y4, f3, f4, this.borderPaint);
            float rotation = calculateRotation(x3, y3, x4, y4);
            configIconMatrix(this.deleteIcon, x2, y2, rotation);
            this.deleteIcon.draw(canvas, this.borderPaint);
            configIconMatrix(this.zoomIcon, x4, y4, rotation);
            this.zoomIcon.draw(canvas, this.borderPaint);
            configIconMatrix(this.flipIcon, x3, y3, rotation);
            this.flipIcon.draw(canvas, this.borderPaint);
        }
    }

    private void configIconMatrix(BitmapStickerIcon icon, float x, float y, float rotation) {
        icon.setX(x);
        icon.setY(y);
        icon.getMatrix().reset();
        icon.getMatrix().postRotate(rotation, (float) (icon.getWidth() / 2), (float) (icon.getHeight() / 2));
        icon.getMatrix().postTranslate(x - ((float) (icon.getWidth() / 2)), y - ((float) (icon.getHeight() / 2)));
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (this.locked) {
            return super.onInterceptTouchEvent(ev);
        }
        switch (ev.getAction()) {
            case R.styleable.View_android_theme :
                this.downX = ev.getX();
                this.downY = ev.getY();
                return checkIconTouched(this.deleteIcon) || checkIconTouched(this.zoomIcon) || checkIconTouched(this.flipIcon) || findHandlingSticker() != null;
            default:
                return super.onInterceptTouchEvent(ev);
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        Log.e("CALL", "TOUCH=====1");
        if (this.locked) {
            return super.onTouchEvent(event);
        }
        switch (MotionEventCompat.getActionMasked(event)) {
            case 0:
                Log.e("CALL", "TOUCH=====2");
                this.currentMode = ActionMode.DRAG;
                this.downX = event.getX();
                this.downY = event.getY();
                if (checkIconTouched(this.deleteIcon)) {
                    this.currentMode = ActionMode.DELETE;
                } else if (checkIconTouched(this.flipIcon)) {
                    this.currentMode = ActionMode.FLIP_HORIZONTAL;
                } else if (!checkIconTouched(this.zoomIcon) || this.handlingSticker == null) {
                    this.handlingSticker = findHandlingSticker();
                } else {
                    this.currentMode = ActionMode.ZOOM_WITH_ICON;
                    this.midPoint = calculateMidPoint();
                    this.oldDistance = calculateDistance(this.midPoint.x, this.midPoint.y, this.downX, this.downY);
                    this.oldRotation = calculateRotation(this.midPoint.x, this.midPoint.y, this.downX, this.downY);
                }
                if (this.handlingSticker != null) {
                    this.downMatrix.set(this.handlingSticker.getMatrix());
                }
                invalidate();
                return true;
            case 1  :
                Log.e("CALL", "TOUCH=====3");
                long currentTime = SystemClock.uptimeMillis();
                if (this.currentMode == ActionMode.DELETE && this.handlingSticker != null) {
                    if (this.onStickerOperationListener != null) {
                        this.onStickerOperationListener.onStickerDeleted(this.handlingSticker);
                    }
                    this.stickers.remove(this.handlingSticker);
                    this.handlingSticker.release();
                    this.handlingSticker = null;
                    invalidate();
                }
                if (this.currentMode == ActionMode.FLIP_HORIZONTAL && this.handlingSticker != null) {
                    this.handlingSticker.getMatrix().preScale(-1.0f, 1.0f, this.handlingSticker.getCenterPoint().x, this.handlingSticker.getCenterPoint().y);
                    this.handlingSticker.setFlipped(!this.handlingSticker.isFlipped());
                    if (this.onStickerOperationListener != null) {
                        this.onStickerOperationListener.onStickerFlipped(this.handlingSticker);
                    }
                    invalidate();
                }
                if (!((this.currentMode != ActionMode.ZOOM_WITH_ICON && this.currentMode != ActionMode.ZOOM_WITH_TWO_FINGER) || this.handlingSticker == null || this.onStickerOperationListener == null)) {
                    this.onStickerOperationListener.onStickerZoomFinished(this.handlingSticker);
                }
                if (this.currentMode == ActionMode.DRAG && Math.abs(event.getX() - this.downX) < ((float) this.touchSlop) && Math.abs(event.getY() - this.downY) < ((float) this.touchSlop) && this.handlingSticker != null) {
                    this.currentMode = ActionMode.CLICK;
                    if (this.onStickerOperationListener != null) {
                        this.onStickerOperationListener.onStickerClicked(this.handlingSticker);
                    }
                    if (currentTime - this.lastClickTime < ((long) this.minClickDelayTime) && this.onStickerOperationListener != null) {
                        this.onStickerOperationListener.onStickerDoubleTapped(this.handlingSticker);
                    }
                }
                if (!(this.currentMode != ActionMode.DRAG || this.handlingSticker == null || this.onStickerOperationListener == null)) {
                    this.onStickerOperationListener.onStickerDragFinished(this.handlingSticker);
                }
                this.currentMode = ActionMode.NONE;
                this.lastClickTime = currentTime;
                return true;
            case 2  :
                Log.e("CALL", "TOUCH=====3");
                handleCurrentMode(event);
                invalidate();
                return true;
            case 5 /*5*/:
                Log.e("CALL", "TOUCH=====4");
                this.oldDistance = calculateDistance(event);
                this.oldRotation = calculateRotation(event);
                this.midPoint = calculateMidPoint(event);
                if (this.handlingSticker == null || !isInStickerArea(this.handlingSticker, event.getX(1), event.getY(1)) || checkIconTouched(this.deleteIcon)) {
                    return true;
                }
                this.currentMode = ActionMode.ZOOM_WITH_TWO_FINGER;
                return true;
            case 6  :
                Log.e("CALL", "TOUCH=====5");
                if (!(this.currentMode != ActionMode.ZOOM_WITH_TWO_FINGER || this.handlingSticker == null || this.onStickerOperationListener == null)) {
                    this.onStickerOperationListener.onStickerDragFinished(this.handlingSticker);
                }
                this.currentMode = ActionMode.NONE;
                return true;
            default:
                return true;
        }
    }

    public void endSticker() {
        this.deleteIcon.setIconRadius(0.0f);
    }

    private void handleCurrentMode(MotionEvent event) {
        float newDistance;
        float newRotation;
        switch (switchClass1.$SwitchMap$com$lib$dwi$stickerview$StickerView$ActionMode[this.currentMode.ordinal()]) {
            case 2  :
                if (this.handlingSticker != null) {
                    float moveX = event.getX() - this.downX;
                    float moveY = event.getY() - this.downY;
                    this.moveMatrix.set(this.downMatrix);
                    this.moveMatrix.postTranslate(event.getX() - this.downX, event.getY() - this.downY);
                    this.handlingSticker.getMatrix().set(this.moveMatrix);
                    if (this.constrained) {
                        constrainSticker();
                    }
                }
                break;
            case 3 :
                if (this.handlingSticker != null) {
                    newDistance = calculateDistance(event);
                    newRotation = calculateRotation(event);
                    this.moveMatrix.set(this.downMatrix);
                    this.moveMatrix.postScale(newDistance / this.oldDistance, newDistance / this.oldDistance, this.midPoint.x, this.midPoint.y);
                    this.moveMatrix.postRotate(newRotation - this.oldRotation, this.midPoint.x, this.midPoint.y);
                    this.handlingSticker.getMatrix().set(this.moveMatrix);
                }
                break;
            case 4:
                if (this.handlingSticker != null) {
                    newDistance = calculateDistance(this.midPoint.x, this.midPoint.y, event.getX(), event.getY());
                    newRotation = calculateRotation(this.midPoint.x, this.midPoint.y, event.getX(), event.getY());
                    this.moveMatrix.set(this.downMatrix);
                    this.moveMatrix.postScale(newDistance / this.oldDistance, newDistance / this.oldDistance, this.midPoint.x, this.midPoint.y);
                    this.moveMatrix.postRotate(newRotation - this.oldRotation, this.midPoint.x, this.midPoint.y);
                    this.handlingSticker.getMatrix().set(this.moveMatrix);
                }
                break;
            default:
                break;
        }
    }

    private void constrainSticker() {
        float moveX = 0.0f;
        float moveY = 0.0f;
        PointF currentCenterPoint = this.handlingSticker.getMappedCenterPoint();
        if (currentCenterPoint.x < 0.0f) {
            moveX = -currentCenterPoint.x;
        }
        if (currentCenterPoint.x > ((float) getWidth())) {
            moveX = ((float) getWidth()) - currentCenterPoint.x;
        }
        if (currentCenterPoint.y < 0.0f) {
            moveY = -currentCenterPoint.y;
        }
        if (currentCenterPoint.y > ((float) getHeight())) {
            moveY = ((float) getHeight()) - currentCenterPoint.y;
        }
        this.handlingSticker.getMatrix().postTranslate(moveX, moveY);
    }

    private boolean checkIconTouched(BitmapStickerIcon icon) {
        float x = icon.getX() - this.downX;
        float y = icon.getY() - this.downY;
        return ((double) ((x * x) + (y * y))) <= Math.pow((double) (icon.getIconRadius() + icon.getIconRadius()), 2.0d);
    }

    private Sticker findHandlingSticker() {
        for (int i = this.stickers.size() - 1; i >= 0; i--) {
            if (isInStickerArea((Sticker) this.stickers.get(i), this.downX, this.downY)) {
                return (Sticker) this.stickers.get(i);
            }
        }
        return null;
    }

    private boolean isInStickerArea(Sticker sticker, float downX, float downY) {
        return sticker.contains(downX, downY);
    }

    private PointF calculateMidPoint(MotionEvent event) {
        if (event == null || event.getPointerCount() < 2) {
            return new PointF();
        }
        return new PointF((event.getX(0) + event.getX(1)) / 2.0f, (event.getY(0) + event.getY(1)) / 2.0f);
    }

    private PointF calculateMidPoint() {
        if (this.handlingSticker == null) {
            return new PointF();
        }
        return this.handlingSticker.getMappedCenterPoint();
    }

    private float calculateRotation(MotionEvent event) {
        if (event == null || event.getPointerCount() < 2) {
            return 0.0f;
        }
        return (float) Math.toDegrees(Math.atan2((double) (event.getY(0) - event.getY(1)), (double) (event.getX(0) - event.getX(1))));
    }

    private float calculateRotation(float x1, float y1, float x2, float y2) {
        return (float) Math.toDegrees(Math.atan2((double) (y1 - y2), (double) (x1 - x2)));
    }

    private float calculateDistance(MotionEvent event) {
        if (event == null || event.getPointerCount() < 2) {
            return 0.0f;
        }
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    private float calculateDistance(float x1, float y1, float x2, float y2) {
        double x = (double) (x1 - x2);
        double y = (double) (y1 - y2);
        return (float) Math.sqrt((x * x) + (y * y));
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        for (int i = 0; i < this.stickers.size(); i++) {
            Sticker sticker = (Sticker) this.stickers.get(i);
            if (sticker != null) {
                transformSticker(sticker);
            }
        }
    }

    private void transformSticker(Sticker sticker) {
        if (sticker == null) {
            Log.e(TAG, "transformSticker: the bitmapSticker is null or the bitmapSticker bitmap is null");
            return;
        }
        float scaleFactor;
        if (this.sizeMatrix != null) {
            this.sizeMatrix.reset();
        }
        this.sizeMatrix.postTranslate((float) ((getWidth() - sticker.getWidth()) / 2), (float) ((getHeight() - sticker.getHeight()) / 2));
        if (getWidth() < getHeight()) {
            scaleFactor = ((float) getWidth()) / ((float) sticker.getWidth());
        } else {
            scaleFactor = ((float) getHeight()) / ((float) sticker.getHeight());
        }
        this.sizeMatrix.postScale(scaleFactor / 2.0f, scaleFactor / 2.0f, (float) (getWidth() / 2), (float) (getHeight() / 2));
        sticker.getMatrix().reset();
        sticker.getMatrix().set(this.sizeMatrix);
        invalidate();
    }

    public boolean replace(Sticker sticker) {
        return replace(sticker, true);
    }

    public boolean replace(Sticker sticker, boolean needStayState) {
        if (this.handlingSticker == null || sticker == null) {
            return false;
        }
        if (needStayState) {
            sticker.getMatrix().set(this.handlingSticker.getMatrix());
            sticker.setFlipped(this.handlingSticker.isFlipped());
        } else {
            float scaleFactor;
            this.handlingSticker.getMatrix().reset();
            sticker.getMatrix().postTranslate((float) ((getWidth() - this.handlingSticker.getWidth()) / 2), (float) ((getHeight() - this.handlingSticker.getHeight()) / 2));
            if (getWidth() < getHeight()) {
                scaleFactor = ((float) getWidth()) / ((float) this.handlingSticker.getDrawable().getIntrinsicWidth());
            } else {
                scaleFactor = ((float) getHeight()) / ((float) this.handlingSticker.getDrawable().getIntrinsicHeight());
            }
            sticker.getMatrix().postScale(scaleFactor / 2.0f, scaleFactor / 2.0f, (float) (getWidth() / 2), (float) (getHeight() / 2));
        }
        this.stickers.set(this.stickers.indexOf(this.handlingSticker), sticker);
        this.handlingSticker = sticker;
        invalidate();
        return true;
    }

    public boolean remove(Sticker sticker) {
        if (this.stickers.contains(sticker)) {
            this.stickers.remove(sticker);
            if (this.onStickerOperationListener != null) {
                this.onStickerOperationListener.onStickerDeleted(sticker);
            }
            if (this.handlingSticker == sticker) {
                this.handlingSticker = null;
            }
            invalidate();
            return true;
        }
        Log.d(TAG, "remove: the sticker is not in this StickerView");
        return false;
    }

    public boolean removeCurrentSticker() {
        return remove(this.handlingSticker);
    }

    public void removeAllStickers() {
        this.stickers.clear();
        if (this.handlingSticker != null) {
            this.handlingSticker.release();
            this.handlingSticker = null;
        }
        invalidate();
    }

    public void addSticker(Sticker sticker) {
        if (sticker == null) {
            Log.e(TAG, "StickerData to be added is null!");
            return;
        }
        float scaleFactor;
        sticker.getMatrix().postTranslate((float) ((getWidth() - sticker.getWidth()) / 2), (float) ((getHeight() - sticker.getHeight()) / 2));
        if (getWidth() < getHeight()) {
            scaleFactor = ((float) getWidth()) / ((float) sticker.getDrawable().getIntrinsicWidth());
        } else {
            scaleFactor = ((float) getHeight()) / ((float) sticker.getDrawable().getIntrinsicHeight());
        }
        sticker.getMatrix().postScale(scaleFactor / 2.0f, scaleFactor / 2.0f, (float) (getWidth() / 2), (float) (getHeight() / 2));
        this.handlingSticker = sticker;
        this.stickers.add(sticker);
        invalidate();
    }

    public float[] getStickerPoints(Sticker sticker) {
        if (sticker == null) {
            return new float[8];
        }
        return sticker.getMappedBoundPoints();
    }

    public void save(File file) {
        StickerUtils.saveImageToGallery(file, createBitmap());
        StickerUtils.notifySystemGallery(getContext(), file);
    }

    public Bitmap createBitmap() {
        this.handlingSticker = null;
        Bitmap bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Config.ARGB_8888);
        this.canvas = new Canvas(bitmap);
        draw(this.canvas);
        return bitmap;
    }

    public int getStickerCount() {
        return this.stickers.size();
    }

    public boolean isNoneSticker() {
        return getStickerCount() == 0;
    }

    public boolean isLocked() {
        return this.locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
        invalidate();
    }

    public BitmapStickerIcon getFlipIcon() {
        return this.flipIcon;
    }

    public void setFlipIcon(BitmapStickerIcon flipIcon) {
        this.flipIcon = flipIcon;
        postInvalidate();
    }

    public BitmapStickerIcon getZoomIcon() {
        return this.zoomIcon;
    }

    public void setZoomIcon(BitmapStickerIcon zoomIcon) {
        this.zoomIcon = zoomIcon;
        postInvalidate();
    }

    public BitmapStickerIcon getDeleteIcon() {
        return this.deleteIcon;
    }

    public void setDeleteIcon(BitmapStickerIcon deleteIcon) {
        this.deleteIcon = deleteIcon;
        postInvalidate();
    }

    public void setMinClickDelayTime(int minClickDelayTime) {
        this.minClickDelayTime = minClickDelayTime;
    }

    public int getMinClickDelayTime() {
        return this.minClickDelayTime;
    }

    public boolean isConstrained() {
        return this.constrained;
    }

    public void setConstrained(boolean constrained) {
        this.constrained = constrained;
        postInvalidate();
    }

    public void setOnStickerOperationListener(OnStickerOperationListener onStickerOperationListener) {
        this.onStickerOperationListener = onStickerOperationListener;
    }
}
