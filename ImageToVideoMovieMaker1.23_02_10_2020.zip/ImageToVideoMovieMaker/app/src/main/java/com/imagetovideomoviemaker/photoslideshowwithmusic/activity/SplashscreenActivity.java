package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.xyz.imagetovideomoviewmaker.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;


public class SplashscreenActivity extends Activity {
    TextView imgReady;
    ImageView ivSplashBottom;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitity_splash);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SplashscreenActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        addListener();
//        loadAd();
    }

    private void bindView() {
        imgReady = findViewById(R.id.tvLetsStart);
        ivSplashBottom=findViewById(R.id.iv_splash_bottom);
    }

    private void init() {
        Utils.setFont(this, R.id.tvCreateAccurateFastVideo);
        Utils.setFont(this, imgReady);
    }

    private void addListener() {
        this.ivSplashBottom.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
//                id = R.id.tvLetsStart;
//                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    interstitialAd.show();
//                } else {
                SplashscreenActivity.this.startActivity(new Intent(SplashscreenActivity.this.getApplicationContext(), LauncherActivity.class));
                SplashscreenActivity.this.finish();
//                }
            }
        });
    }
}