package com.esc.mynameringtonemaker.Common;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Environment;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.downloader.Error;
import com.downloader.OnDownloadListener;
import com.downloader.OnProgressListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.esc.mynameringtonemaker.R;
import com.esc.mynameringtonemaker.myApp.MyApplication;
import java.io.File;

public class Methods {
    private Activity activity;
    DownloadListener downloadListener;
    DialogCreated listener;

    public interface DialogCreated {
        void onDialogCreated(AlertDialog alertDialog);
    }

    public interface DownloadListener {
        void onComplete();

        void onProgress(long j);
    }

    public Methods(Activity activity) {
        this.activity = activity;
    }

    public static void toolbar(final Activity activity, String str) {
        AppCompatActivity appCompatActivity = (AppCompatActivity) activity;
        Toolbar toolbar = (Toolbar) activity.findViewById(R.id.toolbar);
        toolbar.setTitle((CharSequence) str);
        appCompatActivity.setSupportActionBar(toolbar);
        appCompatActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        appCompatActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public static String getDirectory(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        stringBuilder.append(File.separator);
        stringBuilder.append(MyApplication.getContext().getResources().getString(R.string.app_name));
        stringBuilder.append(File.separator);
        stringBuilder.append(str);
        stringBuilder.append(File.separator);
        File file = new File(stringBuilder.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        return stringBuilder.toString();
    }

    public static void alertDialog(Activity activity, int i, DialogCreated dialogCreated) {
        new Methods(activity).listener = dialogCreated;
        Builder builder = new Builder(activity);
        builder.setView(activity.getLayoutInflater().inflate(i, null));
        builder.setCancelable(false);
        AlertDialog create = builder.create();
        create.getWindow().getAttributes().windowAnimations = R.style.MyDialogTheme;
        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        create.show();
        dialogCreated.onDialogCreated(create);
    }

    public static int dpToPx(int i) {
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    public static void download(Activity activity, String str, String str2, String str3, final DownloadListener downloadListener) {
        new Methods(activity).downloadListener = downloadListener;
        try {
            PRDownloader.initialize(activity);
            PRDownloader.initialize(activity, PRDownloaderConfig.newBuilder().setDatabaseEnabled(true).build());
            PRDownloader.initialize(activity, PRDownloaderConfig.newBuilder().setReadTimeout(30000).setConnectTimeout(30000).build());
        } catch (Exception e) {
            e.printStackTrace();
        }
        PRDownloader.download(str, str2, str3).build().setOnProgressListener(new OnProgressListener() {
            public void onProgress(Progress progress) {
                downloadListener.onProgress((progress.currentBytes * 100) / progress.totalBytes);
            }
        }).start(new OnDownloadListener() {
            public void onError(Error error) {
            }

            public void onDownloadComplete() {
                downloadListener.onComplete();
            }
        });
    }

}
