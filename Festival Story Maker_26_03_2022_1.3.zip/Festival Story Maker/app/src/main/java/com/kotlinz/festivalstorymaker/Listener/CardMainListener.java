package com.kotlinz.festivalstorymaker.Listener;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;

public class CardMainListener implements View.OnClickListener
{
    public final  SelectLogoAdapter.ViewHolder e;
    public final SelectLogoAdapter f;

    public CardMainListener(final SelectLogoAdapter f, final SelectLogoAdapter.ViewHolder e) {
        this.f = f;
        this.e = e;
    }

    public void onClick(final View view) {
        this.f.logoInterface.K(this.e.ivThumb.getTag().toString(), false);
    }
}
