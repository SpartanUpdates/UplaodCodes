package com.kotlinz.puzzlecreator.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.transition.Explode;
import android.view.animation.DecelerateInterpolator;

import com.airbnb.lottie.LottieAnimationView;
import com.kotlinz.puzzlecreator.R;

public class TransitAnimationActivity extends AppCompatActivity {
    LottieAnimationView lottieAnimationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setAnimation();
        setContentView(R.layout.transition_layout);

        lottieAnimationView = (LottieAnimationView) findViewById(R.id.anim_success);
        lottieAnimationView.playAnimation();

        final int from = ContextCompat.getColor(TransitAnimationActivity.this, R.color.dark_purple);
        final int mid = ContextCompat.getColor(TransitAnimationActivity.this, R.color.colorPrimaryDark);
        final int to = ContextCompat.getColor(TransitAnimationActivity.this, R.color.white);

        ValueAnimator anim = new ValueAnimator();
        anim.setIntValues(from, mid, to);
        anim.setEvaluator(new ArgbEvaluator());

        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                lottieAnimationView.setBackgroundColor((Integer) valueAnimator.getAnimatedValue());
            }
        });

        anim.setDuration(1000);
        anim.start();
        startCheckAnimationLogo();
    }

    private void startCheckAnimationLogo() {
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f).setDuration(3000);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
            }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Intent i = new Intent(TransitAnimationActivity.this, LoginActivity.class);
                startActivity(i);
                finish();

            }
        });
        if (lottieAnimationView.getProgress() == 0f) {
            animator.start();
        } else {
            lottieAnimationView.setProgress(0f);
        }
    }

    public void setAnimation() {
        if (Build.VERSION.SDK_INT > 20) {
            Explode explode = new Explode();
            explode.setDuration(1000);
            explode.setInterpolator(new DecelerateInterpolator());
            getWindow().setEnterTransition(explode);
             getWindow().setExitTransition(explode);
        }
    }
}