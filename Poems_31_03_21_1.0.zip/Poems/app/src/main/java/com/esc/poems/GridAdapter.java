package com.esc.poems;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class GridAdapter extends BaseAdapter {
    private int[] gimg;
    private ViewHolder holder;
    private ImageView imageView;
    private LayoutInflater inflater = null;

    class ViewHolder {
        public ImageView image;

        ViewHolder() {
        }
    }

    public long getItemId(int i) {
        return i;
    }

    public GridAdapter(Context context, int[] iArr) {
        this.gimg = iArr;
        this.inflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return this.gimg.length;
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.grid_list, null);
            ViewHolder viewHolder = new ViewHolder();
            this.holder = viewHolder;
            viewHolder.image = view.findViewById(R.id.gridicon);
            view.setTag(this.holder);
        } else {
            this.holder = (ViewHolder) view.getTag();
        }
        ImageView imageView = this.holder.image;
        this.imageView = imageView;
        imageView.getLayoutParams().width = MainActivity.sw / 3;
        this.imageView.getLayoutParams().height = MainActivity.sw / 3;
        this.holder.image.setImageResource(this.gimg[i]);
        return view;
    }
}
