package com.kotlinz.videoeditor.Utils;

import com.kotlinz.videoeditor.R;

public class Styleable {

    public static final int[] HorizontalListView = {16842976, 16843049, 16843685, R.attr.dividerWidth};
}
