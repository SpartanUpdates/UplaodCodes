package com.kotlinz.videoCollage.other;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import androidx.annotation.RequiresApi;
import androidx.loader.content.CursorLoader;

import com.google.android.exoplayer2.util.MimeTypes;


public class RealPathUtil {
    public static String getRealPath(Context context, Uri uri) {
        if (VERSION.SDK_INT < 11) {
            return getRealPathFromURI_BelowAPI11(context, uri);
        }
        if (VERSION.SDK_INT < 19) {
            return getRealPathFromURI_API11to18(context, uri);
        }
        return getRealPathFromURI_API19(context, uri);
    }

    public static String getRealPathFromURI_API11to18(Context context, Uri uri) {
        String str = "_data";
        Cursor loadInBackground = new CursorLoader(context, uri, new String[]{str}, null, null, null).loadInBackground();
        if (loadInBackground == null) {
            return null;
        }
        int columnIndexOrThrow = loadInBackground.getColumnIndexOrThrow(str);
        loadInBackground.moveToFirst();
        String string = loadInBackground.getString(columnIndexOrThrow);
        loadInBackground.close();
        return string;
    }

    public static String getRealPathFromURI_BelowAPI11(Context context, Uri uri) {
        String str = "_data";
        Cursor query = context.getContentResolver().query(uri, new String[]{str}, null, null, null);
        if (query == null) {
            return "";
        }
        int columnIndexOrThrow = query.getColumnIndexOrThrow(str);
        query.moveToFirst();
        String string = query.getString(columnIndexOrThrow);
        query.close();
        return string;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static String getRealPathFromURI_API19(Context context, Uri uri) {
        Uri uri2 = null;
        if (!(VERSION.SDK_INT >= 19) || !DocumentsContract.isDocumentUri(context, uri)) {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                if (isGooglePhotosUri(uri)) {
                    return uri.getLastPathSegment();
                }
                return getDataColumn(context, String.valueOf(uri), (String) null, (String[]) null);
            } else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        } else if (isExternalStorageDocument(uri)) {
            String[] split = DocumentsContract.getDocumentId(uri).split(":");
            if ("primary".equalsIgnoreCase(split[0])) {
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            }
        } else if (isDownloadsDocument(uri)) {
            return getDataColumn(context, String.valueOf(ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(DocumentsContract.getDocumentId(uri)).longValue())), (String) null, (String[]) null);
        } else if (isMediaDocument(uri)) {
            String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
            String str = split2[0];
            if ("image".equals(str)) {
                uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            } else if ("video".equals(str)) {
                uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            } else if (MimeTypes.BASE_TYPE_AUDIO.equals(str)) {
                uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            }
            return getDataColumn(context, String.valueOf(uri2), "_id=?", new String[]{split2[1]});
        }
        return null;
    }


    public static String getDataColumn(Context context, String uri, String str, String[] strArr) {
        String str2 = "_data";
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(Uri.parse(uri), new String[]{str2}, str, strArr, null);
            if (context != null) {
                try {
                    if (cursor != null) {
                        if (cursor.moveToFirst()) {
                            uri = context.getString(cursor.getColumnIndexOrThrow(str2));
                            if (context != null) {
                                cursor.close();
                            }
                            return uri;
                        }
                    }
                } catch (Throwable th) {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
            if (context != null) {
                cursor.close();
            }
            return null;
        } catch (Throwable th2) {
            if (cursor != null) {
                cursor.close();
            }
            throw th2;
        }
    }


    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }
}
