package com.kotlinz.puzzlecreator.retrofit;

import com.kotlinz.puzzlecreator.model.Credentials;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface APIInterface {
    @POST("api/v1/user/register")
    Call<ResponseBody> RegisterUser(@Body Credentials credentials);

    @POST("api/v1/user/login")
    Call<ResponseBody> loginUser(@Body Credentials credentials);

    @POST("api/v1/user/reset-password")
    Call<ResponseBody> ForgotPassword(@Body Credentials credentials);

    @POST("api/v1/reviewer/puzzle/add-to-profile")
    Call<ResponseBody> AddToMyList(@Header("Authorization") String token, @Body Credentials credentials);

    @POST("api/v1/reviewer/profile/puzzle/manage")
    Call<ResponseBody> AcceptReject(@Header("Authorization") String token, @Body Credentials credentials);

    @POST("api/v1/creator/puzzle/remove")
    Call<ResponseBody> Delete(@Header("Authorization") String token, @Body Credentials credentials);

    @POST("api/v1/solver/solve/puzzle")
    Call<ResponseBody> Answer_Puzzle(@Header("Authorization") String token, @Body Credentials credentials);

    @POST("api/v1/solver/manage/points")
    Call<ResponseBody> Manage_Points(@Header("Authorization") String token, @Body Credentials credentials);

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> mcqPuzzle(@Header("Authorization") String token,
                                 @Part MultipartBody.Part filePart,
                                 @Part("question") RequestBody question,
                                 @Part("question_type") RequestBody questiontype,
                                 @Part("options[0]") RequestBody opt1,
                                 @Part("options[1]") RequestBody opt2,
                                 @Part("options[2]") RequestBody opt3,
                                 @Part("options[3]") RequestBody opt4,
                                 @Part("true_answer") RequestBody tans,
                                 @Part("hint") RequestBody hint,
                                 @Part("difficulty_level") RequestBody dlevel,
                                 @Part("view") RequestBody view
    );

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> menualyPuzzle(@Header("Authorization") String token,
                                     @Part MultipartBody.Part filePart,
                                     @Part("question") RequestBody question,
                                     @Part("question_type") RequestBody questiontype,
                                     @Part("options[0]") RequestBody opt1,
                                     @Part("true_answer") RequestBody tans,
                                     @Part("hint") RequestBody hint,
                                     @Part("difficulty_level") RequestBody dlevel,
                                     @Part("view") RequestBody view
    );

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> booleanPuzzle(@Header("Authorization") String token,
                                     @Part MultipartBody.Part filePart,
                                     @Part("question") RequestBody question,
                                     @Part("question_type") RequestBody questiontype,
                                     @Part("options[0]") RequestBody opt1,
                                     @Part("options[1]") RequestBody opt2,
                                     @Part("true_answer") RequestBody tans,
                                     @Part("hint") RequestBody hint,
                                     @Part("difficulty_level") RequestBody dlevel,
                                     @Part("view") RequestBody view
    );

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> updatemcqPuzzle(@Header("Authorization") String token,
                                       @Part("puzzle_id") RequestBody id,
                                       @Part MultipartBody.Part filePart,
                                       @Part("question") RequestBody question,
                                       @Part("question_type") RequestBody questiontype,
                                       @Part("options[0]") RequestBody opt1,
                                       @Part("options[1]") RequestBody opt2,
                                       @Part("options[2]") RequestBody opt3,
                                       @Part("options[3]") RequestBody opt4,
                                       @Part("true_answer") RequestBody tans,
                                       @Part("hint") RequestBody hint,
                                       @Part("difficulty_level") RequestBody dlevel,
                                       @Part("view") RequestBody view
    );

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> updatemenualyPuzzle(@Header("Authorization") String token,
                                           @Part("puzzle_id") RequestBody id,
                                           @Part MultipartBody.Part filePart,
                                           @Part("question") RequestBody question,
                                           @Part("question_type") RequestBody questiontype,
                                           @Part("options[0]") RequestBody opt1,
                                           @Part("true_answer") RequestBody tans,
                                           @Part("hint") RequestBody hint,
                                           @Part("difficulty_level") RequestBody dlevel,
                                           @Part("view") RequestBody view
    );

    @Multipart
    @POST("api/v1/creator/puzzle/manage")
    Call<ResponseBody> updatebooleanPuzzle(@Header("Authorization") String token,
                                           @Part("puzzle_id") RequestBody id,
                                           @Part MultipartBody.Part filePart,
                                           @Part("question") RequestBody question,
                                           @Part("question_type") RequestBody questiontype,
                                           @Part("options[0]") RequestBody opt1,
                                           @Part("options[1]") RequestBody opt2,
                                           @Part("true_answer") RequestBody tans,
                                           @Part("hint") RequestBody hint,
                                           @Part("difficulty_level") RequestBody dlevel,
                                           @Part("view") RequestBody view
    );

    @GET("api/v1/reviewer/puzzle/list")
    Call<ResponseBody> GetReviewerAll(@Header("Authorization") String token,
                                      @Query("page_no") int page);

    @GET("api/v1/reviewer/profile/puzzles")
    Call<ResponseBody> GetReviewerMy(@Header("Authorization") String token,
                                     @Query("page_no") int page);

    @GET("api/v1/creator/puzzle/list")
    Call<ResponseBody> GetCreatorPuzzle(@Header("Authorization") String token,
                                        @Query("status") String status,
                                        @Query("page_no") int page);

    @GET("/api/v1/solver/puzzle/list")
    Call<ResponseBody> GetSolverPuzzle(@Header("Authorization") String token,
                                       @Query("page_no") int page);

    @GET("/api/v1/solver/puzzle/list")
    Call<ResponseBody> GetSolveransPuzzle(@Header("Authorization") String token,
                                          @Query("page_no") int page,
                                          @Query("answer_only") boolean ans);

    @GET("/api/v1/user/logout")
    Call<ResponseBody> Logout(@Header("Authorization") String token);
}
