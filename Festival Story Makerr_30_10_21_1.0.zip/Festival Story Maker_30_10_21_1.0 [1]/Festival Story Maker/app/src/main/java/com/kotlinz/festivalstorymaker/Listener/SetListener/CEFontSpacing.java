package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;


public class CEFontSpacing implements SeekBar.OnSeekBarChangeListener
{
    public final CanvasEditorActivity e;

    public CEFontSpacing(final CanvasEditorActivity e) {
        this.e = e;
    }

    public void onProgressChanged(final SeekBar seekBar, final int a, final boolean b) {
        if (b) {
            this.e.t1.setLetterSpacing((float)a);
            this.e.t1.requestLayout();
            final CanvasEditorActivity e = this.e;
            final com.kotlinz.festivalstorymaker.Models.z.c c = e.s1.get((int)e.t1.getTag());
            c.a = a;
            final CanvasEditorActivity e2 = this.e;
            e2.s1.set((int)e2.t1.getTag(), c);
        }
    }

    public void onStartTrackingTouch(final SeekBar seekBar) {
    }

    public void onStopTrackingTouch(final SeekBar seekBar) {
    }
}
