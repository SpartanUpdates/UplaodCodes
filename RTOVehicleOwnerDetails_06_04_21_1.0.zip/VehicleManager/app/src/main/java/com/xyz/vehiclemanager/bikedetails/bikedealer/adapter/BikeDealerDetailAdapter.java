package com.xyz.vehiclemanager.bikedetails.bikedealer.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikedealer.model.BikeDealer;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BikeDealerDetailAdapter extends RecyclerView.Adapter<BikeDealerDetailAdapter.MyViewHodlder> {

    Context mcontext;
    ArrayList<BikeDealer> bikeDealerDetailList;

    public class MyViewHodlder extends RecyclerView.ViewHolder
    {
        TextView tv_dealername;
        TextView tv_dealeraddress;
        TextView tv_dealercontact;
        public MyViewHodlder(@NonNull View itemView)
        {
            super(itemView);
            tv_dealername = itemView.findViewById(R.id.tv_dealername);
            tv_dealeraddress = itemView.findViewById(R.id.tv_dealeraddress);
            tv_dealercontact = itemView.findViewById(R.id.tv_dealercontact);
        }
    }

    public BikeDealerDetailAdapter(Context mcontext, ArrayList<BikeDealer> bikeDealerDetailList) {
        this.mcontext = mcontext;
        this.bikeDealerDetailList = bikeDealerDetailList;
    }

    @Override
    public MyViewHodlder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_bikedealer,parent,false);
        return new MyViewHodlder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHodlder holder, int position)
    {
        BikeDealer bikeDealerDetail = bikeDealerDetailList.get(position);
        holder.tv_dealername.setText(bikeDealerDetail.getDealerName());
        holder.tv_dealeraddress.setText(bikeDealerDetail.getDealerAddress());
        holder.tv_dealercontact.setText(bikeDealerDetail.getDealerContactNo());
    }

    @Override
    public int getItemCount() {
        return bikeDealerDetailList.size();
    }
}
