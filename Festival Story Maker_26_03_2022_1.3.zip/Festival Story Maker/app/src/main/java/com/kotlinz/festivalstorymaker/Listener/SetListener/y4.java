package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.ViewTreeObserver;
import android.widget.ImageView;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class y4 implements ViewTreeObserver.OnGlobalLayoutListener {
    public final ImageView e;
    public final Float f;
    public final int g;
    public final Float h;
    public final int i;

    public y4(final FrameEditorNewDesign frameEditorNewDesign, final ImageView e, final Float f, final int g, final Float h, final int i) {
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
    }

    public void onGlobalLayout() {
        this.e.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener) this);
        this.e.setX(this.f + this.g - this.e.getWidth());
        this.e.setY(this.h + this.i - this.e.getHeight());
    }
}
