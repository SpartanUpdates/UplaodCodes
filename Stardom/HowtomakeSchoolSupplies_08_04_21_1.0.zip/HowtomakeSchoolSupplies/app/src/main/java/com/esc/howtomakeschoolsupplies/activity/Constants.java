package com.esc.howtomakeschoolsupplies.activity;

public class Constants {
    public static final String APP_PREFERENCES = "mysettings";
    public static final String APP_PREFERENCES_NEW_ARTICLES = "new_articles";
    public static final String APP_PREFERENCES_NEW_ARTICLES_CATEGORY = "new_articles_in_category";
    public static final String SERVER_ADDRESS = "http://167.172.217.101:8080/chancellery/";
    public static final String SERVER_ADDRESS_RECOMMENDED = "http://167.172.217.101:8080/recommended/";

    private Constants() {
    }
}
