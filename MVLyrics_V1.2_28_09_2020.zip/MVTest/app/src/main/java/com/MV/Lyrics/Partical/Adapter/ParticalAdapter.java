package com.MV.Lyrics.Partical.Adapter;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.MV.Lyrics.UnityPlayerActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.Partical.Download.DownloadTask;
import com.MV.Lyrics.Partical.Model.ParticalModel;
import com.MV.Lyrics.R;
import com.unity3d.player.UnityPlayer;

import java.io.File;

import static android.graphics.Color.parseColor;

public class ParticalAdapter extends RecyclerView.Adapter<ParticalAdapter.ViewHolder> {

    public Context context;
    private String AllFilePath;
    public int selectedPosition = -1;
    private ColorDrawable[] e = new ColorDrawable[]{new ColorDrawable(parseColor("#9ACCCD")), new ColorDrawable(parseColor("#8FD8A0")), new ColorDrawable(parseColor("#CBD890")), new ColorDrawable(parseColor("#DACC8F")), new ColorDrawable(parseColor("#D9A790")), new ColorDrawable(parseColor("#D18FD9")), new ColorDrawable(parseColor("#FF6772")), new ColorDrawable(parseColor("#DDFB5C"))};

    public ParticalAdapter(Context c) {
        this.context = c;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_particle_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final ParticalModel particalModel = ((UnityPlayerActivity) this.context).particalModels.get(position);
        holder.tvName.setText(((UnityPlayerActivity) this.context).particalModels.get(position).getThemeName());
        if (particalModel.isFromAsset()) {
            holder.ivDownoad.setVisibility(View.GONE);
            if (new File(Utils.INSTANCE.getAssetUnityPath() + particalModel.getThemeName() + ".png").exists()) {
                Glide.with(context).load(Utils.INSTANCE.getAssetUnityPath() + particalModel.getThemeName() + ".png").diskCacheStrategy(DiskCacheStrategy.ALL).into(holder.ivThumb);
            } else {
                Glide.with(context).load(particalModel.getThumbImage()).diskCacheStrategy(DiskCacheStrategy.ALL).into(holder.ivThumb);
            }
        } else {
            holder.ivDownoad.setVisibility(View.VISIBLE);
            if (new File(Utils.INSTANCE.getAssetUnityPath() + particalModel.getThemeName() + ".png").exists()) {
                Glide.with(context).load(Utils.INSTANCE.getAssetUnityPath() + particalModel.getThemeName() + ".png").diskCacheStrategy(DiskCacheStrategy.ALL).into(holder.ivThumb);
            } else {
                Glide.with(context).load(particalModel.getThumbImage()).diskCacheStrategy(DiskCacheStrategy.ALL).into(holder.ivThumb);
            }
        }
        if (!particalModel.isAvailableOffline) {
            if (particalModel.isDownloading) {
                holder.ivDownoad.setVisibility(View.GONE);
                holder.tvCounter.setVisibility(View.VISIBLE);
            } else {
                holder.tvCounter.setVisibility(View.GONE);
                holder.ivDownoad.setVisibility(View.VISIBLE);
            }
        } else {
            holder.tvCounter.setVisibility(View.GONE);
            holder.ivDownoad.setVisibility(View.GONE);
        }

        if (selectedPosition == position) {
            holder.llborder.setSelected(true);
        } else {
            holder.llborder.setSelected(false);
            if (particalModel.IsAssetSelected) {
                holder.llborder.setSelected(true);
            }
        }
        holder.llborder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DownloadThemeFiles(position, holder.ivDownoad, holder.tvCounter, particalModel);

            }
        });
    }

    private void DownloadThemeFiles(int position, ImageView ivDownload, TextView tvThemeDownprogress, ParticalModel particalModel) {
        int UnityBundelSize = particalModel.getBundelSize();
        File BundelPath = new File(Utils.INSTANCE.getAssetUnityPath() + particalModel.getBundelName());
        int BundelFileSize = Integer.parseInt(String.valueOf(BundelPath.length()));
        AllFilePath = particalModel.getThemeUnity3dPath() + MyApplication.SPLIT_PATTERN + particalModel.getGmaeObjName();
        if (new File(Utils.INSTANCE.getAssetUnityPath() + particalModel.getBundelName()).exists()) {
            if (BundelFileSize == UnityBundelSize) {
                UnityPlayer.UnitySendMessage("AppManager", "GetLyricsTheme", AllFilePath);
                selectedPosition = position;
                Utils.INSTANCE.particalAssetModels.get(MyApplication.ThemeAssetSelectedPosition).IsAssetSelected = false;
                notifyDataSetChanged();
            }else {
                if (Utils.checkConnectivity(context, true)) {
                    ivDownload.setVisibility(View.GONE);
                    tvThemeDownprogress.setVisibility(View.VISIBLE);
                    new DownloadTask(context, ivDownload, tvThemeDownprogress, particalModel);
                } else {
                    Toast.makeText(context, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(context, true)) {
                ivDownload.setVisibility(View.GONE);
                tvThemeDownprogress.setVisibility(View.VISIBLE);
                new DownloadTask(context, ivDownload, tvThemeDownprogress, particalModel);
            } else {
                Toast.makeText(context, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }


    @Override
    public int getItemCount() {
        return ((UnityPlayerActivity) this.context).particalModels.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivThumb;
        private ImageView ivLoack;
        private ImageView ivDownoad;
        private TextView tvCounter;
        private TextView tvName;
        private LinearLayout llborder;
        RelativeLayout rlMain;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.ivThumb = view.findViewById(R.id.ivThumb);
            this.ivLoack = view.findViewById(R.id.ivLock);
            this.ivDownoad = view.findViewById(R.id.icDownload);
            this.tvCounter = view.findViewById(R.id.tvCounter);
            this.tvName = view.findViewById(R.id.tvName);
            this.llborder = view.findViewById(R.id.llBorder);
            rlMain = view.findViewById(R.id.rl_main);

        }
    }
}
