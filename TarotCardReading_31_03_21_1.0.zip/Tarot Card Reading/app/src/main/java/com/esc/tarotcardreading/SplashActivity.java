package com.esc.tarotcardreading;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SplashActivity extends AppCompatActivity implements View.OnClickListener {


    public static Boolean applaunched;
    public static Boolean call_to_main_frm_splash;
    public static Boolean showanimation = Boolean.valueOf(true);
    private Runnable changeAdBool = new Runnable() {
        public void run() {
            mHandler.postDelayed(SplashActivity.this.changeAdBool, 200);
        }
    };
    ConsentInformation consentInformation;
    SharedPreferences.Editor editor;
    SharedPreferences.Editor editor1;
    public String locale = "";
    private Handler mHandler = new Handler();
    int sh;
    SharedPreferences sharedPreferences;
    SharedPreferences sharedPreferences1;
    private String source = "Tarot_Card_Reading";
    private boolean startbool = false;
    int sw;

    static {
        Boolean valueOf = Boolean.valueOf(false);
        call_to_main_frm_splash = valueOf;
        applaunched = valueOf;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        String language = getResources().getConfiguration().locale.getLanguage();
        this.locale = language;
        if (language.contains("hi")) {
        } else {
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        sw = displayMetrics.widthPixels;
        this.sh = displayMetrics.heightPixels;
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
        sharedPreferences = getSharedPreferences(TaroQuestionsActivity.MyPREFERENCES, 0);
        this.sharedPreferences1 = sharedPreferences;
        this.editor1 = sharedPreferences.edit();
        if (!applaunched) {
            applaunched = Boolean.TRUE;
            String str = "applaunched";
            this.editor1.putInt(str, this.sharedPreferences1.getInt(str, 0) + 1);
            this.editor1.apply();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" Applaunched value ->");
            stringBuilder.append(this.sharedPreferences1.getInt(str, 0));
        }
        ConsentInformation instance = ConsentInformation.getInstance(getApplicationContext());
        this.consentInformation = instance;
        stopRunnable();
        startActivity(new Intent(this, TaroQuestionsActivity.class));
        call_to_main_frm_splash = Boolean.TRUE;
    }


    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            default:
                return;
        }
    }

    public void onResume() {
        super.onResume();
        if (TaroQuestionsActivity.exitbool) {
            TaroQuestionsActivity.exitbool = false;
        } else if (showanimation) {
            TranslateAnimation translateAnimation = new TranslateAnimation(-1000.0f, 0.0f, 0.0f, 0.0f);
            translateAnimation.setStartTime(1500);
            translateAnimation.setDuration(2000);
            showanimation = Boolean.FALSE;
        }
    }



    private void stopRunnable() {
        if (this.startbool) {
            this.mHandler.removeCallbacks(this.changeAdBool);
            this.startbool = false;
        }
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE).getString("languagetoload", "en")));
    }
}