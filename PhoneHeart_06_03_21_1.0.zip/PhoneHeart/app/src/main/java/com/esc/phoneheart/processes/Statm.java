package com.esc.phoneheart.processes;

import android.os.Parcel;

import java.io.IOException;

public class Statm extends ProcFile {
    public static final Creator<Statm> CREATOR = new Creator<Statm>() {
        public Statm createFromParcel(Parcel parcel) {
            return new Statm(parcel);
        }

        public Statm[] newArray(int i) {
            return new Statm[i];
        }
    };
    public final String[] fields;

    public static Statm get(int i) throws IOException {
        return new Statm(String.format("/proc/%d/statm", new Object[]{Integer.valueOf(i)}));
    }

    public long getResidentSetSize() {
        return Long.parseLong(this.fields[1]) * 1024;
    }

    public long getSize() {
        return Long.parseLong(this.fields[0]) * 1024;
    }

    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeStringArray(this.fields);
    }

    public Statm(String str) throws IOException {
        super(str);
        this.fields = this.content.split("\\s+");
    }

    public Statm(Parcel parcel) {
        super(parcel);
        this.fields = parcel.createStringArray();
    }
}
