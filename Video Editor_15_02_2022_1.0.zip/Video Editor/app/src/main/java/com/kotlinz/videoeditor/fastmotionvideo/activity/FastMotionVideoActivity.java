package com.kotlinz.videoeditor.fastmotionvideo.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.bumptech.glide.Glide;
import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.kotlinz.videoeditor.fastmotionvideo.Utils.FileUtils;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xw.repo.BubbleSeekBar;
import com.xw.repo.BubbleSeekBar.OnProgressChangedListener;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

@SuppressLint({"WrongConstant"})
public class FastMotionVideoActivity extends AppCompatActivity {
    Activity activity = FastMotionVideoActivity.this;
    static final boolean BOOLEAN = true;
    String a;
    String b = null;
    Boolean c = Boolean.valueOf(false);
    String d = "00";
    ImageView e;
    VideoSliceSeekBar f;
    BubbleSeekBar g;
    public float aFloat;
    int h;
    StringBuilder i = new StringBuilder();
    private CheckBox k;
    private PowerManager l;

    public TextView m;

    public TextView n;


    public VideoPlayerState p = new VideoPlayerState();
    private final a q = new a();

    public VideoView r;
    private WakeLock s;

    ImageView ivback, ivDone;
    TextView tvToolbarName;

    private ImageView ivThumbnail;


    private class a extends Handler {
        private boolean b;
        private final Runnable c;

        private a() {
            this.b = false;
            this.c = new Runnable() {
                public void run() {
                    FastMotionVideoActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.b) {
                this.b = FastMotionVideoActivity.BOOLEAN;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.b = false;
            FastMotionVideoActivity.this.f.videoPlayingProgress(FastMotionVideoActivity.this.r.getCurrentPosition());
            if (!FastMotionVideoActivity.this.r.isPlaying() || FastMotionVideoActivity.this.r.getCurrentPosition() >= FastMotionVideoActivity.this.f.getRightProgress()) {
                if (FastMotionVideoActivity.this.r.isPlaying()) {
                    FastMotionVideoActivity.this.r.pause();
                    FastMotionVideoActivity.this.c = Boolean.valueOf(false);
                    FastMotionVideoActivity.this.e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                FastMotionVideoActivity.this.f.setSliceBlocked(false);
                FastMotionVideoActivity.this.f.removeVideoStatusThumb();
                return;
            }
            postDelayed(this.c, 50);
        }
    }

    @SuppressLint({"ClickableViewAccessibility", "InvalidWakeLockTag"})
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.fastmotionvideoactivity);
        PutAnalyticsEvent();
        d();
        tvToolbarName = findViewById(R.id.tv_app_name);
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        ivThumbnail = findViewById(R.id.iv_thumbnail);
        this.l = (PowerManager) getSystemService(Context.POWER_SERVICE);
        this.s = this.l.newWakeLock(6, "My Tag");
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            this.p = (VideoPlayerState) lastNonConfigurationInstance;
        } else {
            Bundle extras = getIntent().getExtras();
            this.p.setFilename(extras.getString("videofilename"));
            this.b = extras.getString("videofilename");
            MyApplication.getInstance().VideoFileName = b;
        }
        tvToolbarName.setText("Preview");
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                FastMotion();
            }
        });
        r.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                c = Boolean.valueOf(false);
                e.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
        r.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (c.booleanValue()) {
                    r.pause();
                    c = Boolean.valueOf(false);
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                }
                return FastMotionVideoActivity.BOOLEAN;
            }
        });
        g();
    }


    private void FastMotion() {
        if (r.isPlaying()) {
            r.pause();
            e.setBackgroundResource(R.drawable.ic_play_upress);
        }
        if (p.isValid()) {
            fastmotioncommand();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FastMotionVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    public void c() {
        Intent intent = new Intent(activity, TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", b);
        startActivity(intent);
        finish();
    }

    public void fastmotioncommand() {
        String[] strArr;
        String str = "";
        float f2 = this.h == 2 ? 0.5f : this.h == 3 ? 0.33333334f : this.h == 4 ? 0.25f : this.h == 5 ? 0.2f : this.h == 6 ? 0.16666667f : this.h == 7 ? 0.14285715f : this.h == 8 ? 0.125f : 2.0f;
        String valueOf = String.valueOf(this.p.getStart() / 1000);
        String valueOf2 = String.valueOf(this.p.getDuration() / 1000);
        String filename = this.p.getFilename();
        this.b = FileUtils.getTargetFileName(this, filename);
        if (this.k.isChecked()) {
            if (this.h == 2) {
                str = "atempo=2.0";
            } else if (this.h == 3) {
                str = "atempo=3.0";
            } else if (this.h == 4) {
                str = "atempo=4.0";
            } else if (this.h == 5) {
                str = "atempo=5.0";
            } else if (this.h == 6) {
                str = "atempo=6.0";
            } else if (this.h == 7) {
                str = "atempo=7.0";
            } else if (this.h == 8) {
                str = "atempo=8.0";
            }
        }
        try {
            if (k.isChecked()) {
                StringBuilder sb = new StringBuilder();
                sb.append("setpts=");
                sb.append(f2);
                sb.append("*PTS");
                strArr = new String[]{"-y", "-ss", valueOf, "-i", filename, "-filter:v", sb.toString(), "-filter:a", str, "-r", "15", "-b:v", "2500k", "-strict", "experimental", "-t", valueOf2, b};
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("setpts=");
                sb2.append(f2);
                sb2.append("*PTS");
                strArr = new String[]{"-y", "-ss", valueOf, "-i", filename, "-filter:v", sb2.toString(), "-an", "-r", "15", "-ab", "128k", "-vcodec", "mpeg4", "-b:v", "2500k", "-sample_fmt", "s16", "-strict", "experimental", "-t", valueOf2, b};
            }
            a(strArr, b);
        } catch (Exception unused) {
            File file = new File(this.b);
            if (file.exists()) {
                file.delete();
                finish();
                return;
            }
            Toast.makeText(this, "please select Quality", Toast.LENGTH_SHORT).show();
        }
    }

    private void a(String[] strArr, final String str) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                Config.printLastCommandOutput(Log.INFO);
                progressDialog.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    progressDialog.dismiss();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(FastMotionVideoActivity.this.b)));
                    sendBroadcast(intent);
                    c();
                    progressDialog.dismiss();
                    refreshGallery(str);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });

        getWindow().clearFlags(16);
    }

    private void d() {
        this.m = findViewById(R.id.left_pointer);
        this.n = findViewById(R.id.right_pointer);
        this.e = findViewById(R.id.buttonply1);
        this.r = findViewById(R.id.videoView1);
        this.k = findViewById(R.id.checkBox1);
        this.f = findViewById(R.id.seek_bar);
        this.g = findViewById(R.id.seekBar);
        this.k.setChecked(false);

        e.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                r.setVisibility(View.VISIBLE);
                ivThumbnail.setVisibility(View.INVISIBLE);
                if (c.booleanValue()) {
                    e.setBackgroundResource(R.drawable.ic_play_upress);
                    c = Boolean.valueOf(false);
                } else {
                    e.setBackgroundResource(R.drawable.ic_pause_unpresss);
                    c = Boolean.valueOf(FastMotionVideoActivity.BOOLEAN);
                }
                h();
            }
        });

        this.g.setOnProgressChangedListener(new OnProgressChangedListener() {

            @Override
            public void onProgressChanged(BubbleSeekBar bubbleSeekBar, int i, float f, boolean fromUser) {
                aFloat = i;
                FastMotionVideoActivity.this.i.delete(0, FastMotionVideoActivity.this.i.length());
                StringBuilder sb = FastMotionVideoActivity.this.i;
                sb.append("(listener) int:");
                sb.append(i);
                FastMotionVideoActivity.this.h = i;
                g();
            }

            public void getProgressOnActionUp(BubbleSeekBar bubbleSeekBar, int i, float f) {

            }

            public void getProgressOnFinally(BubbleSeekBar bubbleSeekBar, int i, float f, boolean b) {
                /*if (c.booleanValue() || r.isPlaying()) {
                    r.pause();
                    c = Boolean.valueOf(false);
                    e.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (r.isPlaying()) {
                                r.pause();
                                e.setImageResource(R.drawable.ic_play_upress);
                            } else {
                                e.setImageResource(R.drawable.ic_pause_unpresss);
                                r.start();
                            }
                        }
                    });
                } else {
                    e.setBackgroundResource(R.drawable.ic_pause_unpresss);
                    c = Boolean.valueOf(BOOLEAN);
                    e.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (r.isPlaying()) {
                                r.pause();
                                e.setImageResource(R.drawable.ic_play_upress);
                            } else {
                                r.start();
                                e.setImageResource(R.drawable.ic_pause_unpresss);
                            }
                        }
                    });
                }*/
            }

        });
    }

    public void f() {
        new AlertDialog.Builder(this).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FastMotionVideoActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

    private void g() {
        Glide.with(activity).asBitmap().load((p.getFilename())).into(ivThumbnail);
        r.setVideoURI(Uri.parse(p.getFilename()));

        r.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {

                if (aFloat == 2) {
                    float speed1 = 2.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed1));
                } else if (aFloat == 3) {
                    float speed2 = 3.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed2));
                } else if (aFloat == 4) {
                    float speed3 = 4.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed3));
                } else if (aFloat == 5) {
                    float speed4 = 5.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed4));
                } else if (aFloat == 6) {
                    float speed5 = 6.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed5));
                } else if (aFloat == 7) {
                    float speed6 = 7.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed6));
                } else if (aFloat == 8) {
                    float speed7 = 8.0f;
                    mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed7));
                }

                f.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (f.getSelectedThumb() == 1) {
                            r.seekTo(f.getLeftProgress());
                        }
                        m.setText(getTimeForTrackFormat(i));
                        n.setText(getTimeForTrackFormat(i2));
                        d = getTimeForTrackFormat(i);
                        p.setStart(i);
                        a = getTimeForTrackFormat(i2);
                        p.setStop(i2);
                    }
                });
                a = FastMotionVideoActivity.getTimeForTrackFormat(mediaPlayer.getDuration());
                f.setMaxValue(mediaPlayer.getDuration());
                f.setLeftProgress(0);
                f.setRightProgress(mediaPlayer.getDuration());
                f.setProgressMinDiff(0);
            }
        });
        a = getTimeForTrackFormat(r.getDuration());
    }


    public void h() {
        if (this.r.isPlaying()) {
            this.r.pause();
            this.f.setSliceBlocked(false);
            this.f.removeVideoStatusThumb();
            return;
        }
        this.r.seekTo(this.f.getLeftProgress());
        this.r.start();
        this.f.videoPlayingProgress(this.f.getLeftProgress());
        this.q.a();
    }

    public static String getTimeForTrackFormat(int i2) {
        long j2 = i2;
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @Override
    public void onResume() {
        super.onResume();
        this.s.acquire();
        if (!this.r.isPlaying()) {
            this.c = Boolean.valueOf(false);
            this.e.setBackgroundResource(R.drawable.ic_play_upress);
        }
        this.r.seekTo(this.p.getCurrentTime());
    }

    @Override
    public void onPause() {
        this.s.release();
        super.onPause();
        this.p.setCurrentTime(this.r.getCurrentPosition());
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        File file = new File(b);
        MediaScannerConnection.scanFile(this, new String[]{file.getPath()},
                null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // now visible in gallery
                    }
                });
        if (MyApplication.isShowAd == 1) {
            Intent intent = new Intent(activity, EditActivity.class);
            intent.putExtra("videofilename", b);
            startActivity(intent);
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 9;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                Intent intent = new Intent(activity, EditActivity.class);
                intent.putExtra("videofilename", b);
                startActivity(intent);
                finish();
            }
        }
    }
}
