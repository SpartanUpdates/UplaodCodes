package com.hiddencamera;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.os.Build;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.WorkerThread;
import com.hiddencamera.config.CameraImageFormat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public final class HiddenCameraUtils {
    @SuppressLint({"NewApi"})
    public static boolean canOverDrawOtherApps(final Context context) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
    }

    @NonNull
    static File getCacheDir(final Context context) {
        if (context.getExternalCacheDir() == null) {
            return context.getCacheDir();
        }
        return context.getExternalCacheDir();
    }

    public static boolean isFrontCameraAvailable(@NonNull final Context context) {
        return Camera.getNumberOfCameras() > 0 && context.getPackageManager().hasSystemFeature("android.hardware.camera.front");
    }

    public static void openDrawOverPermissionSetting(final Context context) {
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        final Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
        intent.addFlags(268435456);
        context.startActivity(intent);
    }

    @WorkerThread
    static Bitmap rotateBitmap(@NonNull final Bitmap bitmap, final int n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate((float) n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    static boolean saveImageFromFile(@NonNull Bitmap bitmap, @NonNull File fileToSave, int imageFormat) {
        Bitmap.CompressFormat compressFormat;
        boolean isSuccess = false;
        Exception e;
        Throwable th;
        FileOutputStream out = null;
        switch (imageFormat) {
            case CameraImageFormat.FORMAT_WEBP /*563*/:
                compressFormat = Bitmap.CompressFormat.WEBP;
                break;
            case CameraImageFormat.FORMAT_JPEG /*849*/:
                compressFormat = Bitmap.CompressFormat.JPEG;
                break;
            default:
                compressFormat = Bitmap.CompressFormat.PNG;
                break;
        }
        try {
            if (!fileToSave.exists()) {
                fileToSave.createNewFile();
            }
            FileOutputStream out2 = new FileOutputStream(fileToSave);
            try {
                bitmap.compress(compressFormat, 100, out2);
                isSuccess = true;
                if (out2 != null) {
                    try {
                        out2.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        out = out2;
                    }
                }
                out = out2;
            } catch (Exception e3) {
                e = e3;
                out = out2;
                try {
                    e.printStackTrace();
                    isSuccess = false;
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e22) {
                            e22.printStackTrace();
                        }
                    }
                    return isSuccess;
                } catch (Throwable th2) {
                    th = th2;
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e222) {
                            e222.printStackTrace();
                        }
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                if (out != null) {
                    out.close();
                }
            }
        } catch (Exception e4) {
            e = e4;
            e.printStackTrace();
            isSuccess = false;
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            return isSuccess;
        }
        return isSuccess;
    }
}
