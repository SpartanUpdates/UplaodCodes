package com.esc.motivationquotes.customviews;

import android.content.Context;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.widget.TextView;
import com.esc.motivationquotes.model.HrdTextView;

public class AutoResizeTextView extends HrdTextView {
    public static final float MIN_TEXT_SIZE = 20.0f;
    private static final String mEllipsis = "...";
    private boolean mAddEllipsis;
    private float mMaxTextSize;
    private float mMinTextSize;
    private boolean mNeedsResize;
    private float mSpacingAdd;
    private float mSpacingMult;
    private OnTextResizeListener mTextResizeListener;
    private float mTextSize;

    public interface OnTextResizeListener {
        void onTextResize(TextView textView, float f, float f2);
    }

    public AutoResizeTextView(Context context) {
        this(context, null);
    }

    public AutoResizeTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AutoResizeTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mNeedsResize = false;
        this.mMaxTextSize = 0.0f;
        this.mMinTextSize = 20.0f;
        this.mSpacingMult = 1.0f;
        this.mSpacingAdd = 0.0f;
        this.mAddEllipsis = true;
        this.mTextSize = getTextSize();
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.mNeedsResize = true;
        resetTextSize();
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        if (i != i3 || i2 != i4) {
            this.mNeedsResize = true;
        }
    }

    public void setOnResizeListener(OnTextResizeListener onTextResizeListener) {
        this.mTextResizeListener = onTextResizeListener;
    }

    public void setTextSize(float f) {
        super.setTextSize(f);
        this.mTextSize = getTextSize();
    }

    public void setTextSize(int i, float f) {
        super.setTextSize(i, f);
        this.mTextSize = getTextSize();
    }

    public void setLineSpacing(float f, float f2) {
        super.setLineSpacing(f, f2);
        this.mSpacingMult = f2;
        this.mSpacingAdd = f;
    }

    public void setMaxTextSize(float f) {
        this.mMaxTextSize = f;
        requestLayout();
        invalidate();
    }

    public float getMaxTextSize() {
        return this.mMaxTextSize;
    }

    public void setMinTextSize(float f) {
        this.mMinTextSize = f;
        requestLayout();
        invalidate();
    }

    public float getMinTextSize() {
        return this.mMinTextSize;
    }

    public void setAddEllipsis(boolean z) {
        this.mAddEllipsis = z;
    }

    public boolean getAddEllipsis() {
        return this.mAddEllipsis;
    }

    public void resetTextSize() {
        float f = this.mTextSize;
        if (f > 0.0f) {
            super.setTextSize(0, f);
            this.mMaxTextSize = this.mTextSize;
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (z || this.mNeedsResize) {
            resizeText(((i3 - i) - getCompoundPaddingLeft()) - getCompoundPaddingRight(), ((i4 - i2) - getCompoundPaddingBottom()) - getCompoundPaddingTop());
        }
        super.onLayout(z, i, i2, i3, i4);
    }

    public void resizeText() {
        resizeText((getWidth() - getPaddingLeft()) - getPaddingRight(), (getHeight() - getPaddingBottom()) - getPaddingTop());
    }

    public void resizeText(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        CharSequence text = getText();
        if (text != null && text.length() != 0 && i4 > 0 && i3 > 0 && this.mTextSize != 0.0f) {
            boolean z;
            int lineStart;
            if (getTransformationMethod() != null) {
                text = getTransformationMethod().getTransformation(text, this);
            }
            CharSequence charSequence = text;
            TextPaint paint = getPaint();
            float textSize = paint.getTextSize();
            float f = this.mMaxTextSize;
            f = f > 0.0f ? Math.min(this.mTextSize, f) : this.mTextSize;
            int textHeight = getTextHeight(charSequence, paint, i3, f);
            float f2 = f;
            while (textHeight > i4) {
                f = this.mMinTextSize;
                if (f2 <= f) {
                    break;
                }
                f2 = Math.max(f2 - 2.0f, f);
                textHeight = getTextHeight(charSequence, paint, i3, f2);
            }
            if (this.mAddEllipsis && f2 == this.mMinTextSize && textHeight > i4) {
                StaticLayout staticLayout = new StaticLayout(charSequence, new TextPaint(paint), i, Alignment.ALIGN_NORMAL, this.mSpacingMult, this.mSpacingAdd, false);
                z = true;
                StaticLayout staticLayout2 = new StaticLayout(charSequence, new TextPaint(paint), i, Alignment.ALIGN_NORMAL, this.mSpacingMult, this.mSpacingAdd, false);
                if (staticLayout.getLineCount() > 0) {
                    staticLayout2 = staticLayout;
                    textHeight = staticLayout2.getLineForVertical(i4) - 1;
                    if (textHeight < 0) {
                        setText("");
                    } else {
                        lineStart = staticLayout2.getLineStart(textHeight);
                        int lineEnd = staticLayout2.getLineEnd(textHeight);
                        f = staticLayout2.getLineWidth(textHeight);
                        String str = mEllipsis;
                        float measureText = paint.measureText(str);
                        while (((float) i3) < f + measureText) {
                            lineEnd--;
                            f = paint.measureText(charSequence.subSequence(lineStart, lineEnd + 1).toString());
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        lineStart = 0;
                        stringBuilder.append(charSequence.subSequence(0, lineEnd));
                        stringBuilder.append(str);
                        setText(stringBuilder.toString());
                    }
                }
                lineStart = 0;
            } else {
                lineStart = 0;
                z = true;
            }
            setTextSize(lineStart, f2);
            setLineSpacing(this.mSpacingAdd, this.mSpacingMult);
            OnTextResizeListener onTextResizeListener = this.mTextResizeListener;
            if (onTextResizeListener != null) {
                onTextResizeListener.onTextResize(this, textSize, f2);
            }
            this.mNeedsResize = z;
        }
    }

    private int getTextHeight(CharSequence charSequence, TextPaint textPaint, int i, float f) {
        TextPaint textPaint2 = new TextPaint(textPaint);
        textPaint2.setTextSize(f);
        return new StaticLayout(charSequence, textPaint2, i, Alignment.ALIGN_NORMAL, this.mSpacingMult, this.mSpacingAdd, true).getHeight();
    }
}
