package com.kotlinz.festivalstorymaker.Model.ThemeEdit;

public class EditTypeItem {
    public String TypeId;
    public String TypeName;

    public String getTypeId() {
        return TypeId;
    }

    public void setTypeId(String typeId) {
        TypeId = typeId;
    }

    public String getTypeName() {
        return TypeName;
    }

    public void setTypeName(String typeName) {
        TypeName = typeName;
    }
}
