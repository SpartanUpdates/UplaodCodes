package com.esc.phoneheart.interfaceclass;

public interface DialogListners {
    void clickOK();
}
