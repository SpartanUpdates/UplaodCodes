﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeSingle : MonoBehaviour
{
    public GameObject bannerAds, interstitialAd, rewaredAds;

    public void Start()
    {
        GameObject go = GameObject.FindGameObjectWithTag("bannerAds");
        {
            if (go == null)
            {
                Instantiate(bannerAds);
            }
        }
        GameObject go1 = GameObject.FindGameObjectWithTag("interstitialAd");
        {
            if (go == null)
            {
                Instantiate(interstitialAd);
            }
        }
        GameObject go2 = GameObject.FindGameObjectWithTag("rewaredAds");
        {
            if (go == null)
            {
                Instantiate(rewaredAds);
            }
        }
    }
}
