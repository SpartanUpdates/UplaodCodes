package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;

import com.kotlinz.videostatusmaker.Utils.AppPreferences;

public class ActivitySetting extends AppCompatActivity {
    Activity activity = ActivitySetting.this;
    ImageView ivBack;
    ImageView imgAllCap;
    LinearLayout linearLayout;
    AppPreferences appPreferences;
    TextView tvTitle;
    TextView txtAllcap;
    int width;
    Typeface typeface;
    int height;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_setting);
        this.appPreferences = new AppPreferences(this);
        getWindow().addFlags(1024);
        BannerAds();
        PutAnalyticsEvent();
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        this.linearLayout = (LinearLayout) findViewById(R.id.lay1);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.imgAllCap = (ImageView) findViewById(R.id.img_all_cap);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.txtAllcap = (TextView) findViewById(R.id.txt_allcap);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.txtAllcap.setTypeface(this.typeface);
        check();
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.linearLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityPreview.complete = false;
                if (ActivitySetting.this.appPreferences.get_ALL_CAPS()) {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(false);
                } else {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(true);
                }
                ActivitySetting.this.check();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySetting");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   public void check() {
        if (this.appPreferences.get_ALL_CAPS()) {
            this.imgAllCap.setImageResource(R.drawable.toggle1_on);
        } else {
            this.imgAllCap.setImageResource(R.drawable.toggle1_off);
        }
    }
}
