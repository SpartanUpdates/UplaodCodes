package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class QuoteText implements ImageStickerViewNew.c {
    public final QuoteMakerDetailActivity activity;

    public QuoteText(QuoteMakerDetailActivity quoteMakerDetailActivity) {
        this.activity = quoteMakerDetailActivity;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        ImageStickerViewNew imageStickerViewNew2 = this.activity.imageStickerViewNew;
        if (imageStickerViewNew2 != null) {
            imageStickerViewNew2.setInEdit(false);
        }
        activity.imageStickerViewNew = imageStickerViewNew;
        imageStickerViewNew.setInEdit(true);
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        this.activity.flStickerView.removeView(imageStickerViewNew);
        this.activity.flStickerView.requestLayout();
    }

    public void c(Boolean bool) {
        this.activity.svScroll.requestDisallowInterceptTouchEvent(bool);
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {
    }
}