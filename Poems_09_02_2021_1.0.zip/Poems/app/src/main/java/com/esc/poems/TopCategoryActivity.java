package com.esc.poems;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TopCategoryActivity extends AppCompatActivity implements TopCategoryAdapter.ItemClickListener {
    Activity activity = TopCategoryActivity.this;
    private static Editor editor1 = null;
    private static SharedPreferences prefs = null;
    private DataBaseHelper DBhelper;
    private String TAG = "TopCategoryActivity";
    private ArrayList<String> cat;
    private RecyclerView recyclerView;
    private TopCategoryAdapter topCategoryAdapter;
    private ArrayList<String> unlockkey;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_top_category);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#ffffff'>Poems</font>"));
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("bdaymsg", 0);
        prefs = sharedPreferences;
        editor1 = sharedPreferences.edit();
        DataBaseHelper dataBaseHelper = new DataBaseHelper(this);
        this.DBhelper = dataBaseHelper;
        try {
            dataBaseHelper.createDataBase();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
        this.cat = this.DBhelper.getTopCategories();
        this.unlockkey = this.DBhelper.getTopCategoriesUnlockKey();
        this.recyclerView = findViewById(R.id.recycler_view);
        TopCategoryAdapter topCategoryAdapter = new TopCategoryAdapter(this, this.cat, this.unlockkey);
        this.topCategoryAdapter = topCategoryAdapter;
        topCategoryAdapter.setClickListener(this);
        this.recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        this.recyclerView.setAdapter(this.topCategoryAdapter);
        int i = 0;
        while (i < this.unlockkey.size()) {
            if (prefs.getBoolean(this.unlockkey.get(i), false)) {
                i++;
            }
        }
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onItemClick(View view, int i) {
        if (prefs.getBoolean(this.unlockkey.get(i), false)) {
            showTopMessages(i);
        }
    }

    private void showTopMessages(int i) {
        String str = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        int i2 = i + 1;
        stringBuilder.append(i2);
        stringBuilder.append("    ");
        stringBuilder.append(this.cat.get(i));
        Log.e(str, stringBuilder.toString());
        Map hashMap = new HashMap();
        String str2 = "cat";
        hashMap.put(str2, this.cat.get(i));
        Intent intent = new Intent(this, TopMessagesActivity.class);
        Bundle bundle = new Bundle();
        bundle.putInt("pos", i2);
        bundle.putString(str2, this.cat.get(i));
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            System.gc();
            startActivity(new Intent(this, FavoriteActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        super.onBackPressed();
    }


    public void onResume() {
        super.onResume();
        this.DBhelper.close();
    }

}
