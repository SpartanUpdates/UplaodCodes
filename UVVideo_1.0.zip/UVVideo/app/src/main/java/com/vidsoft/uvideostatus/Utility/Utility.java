package com.vidsoft.uvideostatus.Utility;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore.Video.Media;
import com.google.android.exoplayer2.upstream.DefaultLoadErrorHandlingPolicy;
import com.vidsoft.uvideostatus.clasees.CustomCategoryItem;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Utility {
    public static ArrayList<CustomCategoryItem> CATEGORYLIST = new ArrayList<>();
    public static String apiKey = "bRr4KD3gns45gh4PA4pS2hpcgO-adLMU";
    public static String baseUrl = "https://api.mlab.com/api/1/databases/dp_status/";
    public static ArrayList<String> videoduration = new ArrayList<>();

    public static String getFileSize(long j) {
        if (j <= 0) {
            return "0";
        }
        String[] strArr = {"B", "KB", "MB", "GB", "TB"};
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder sb = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double pow = Math.pow(1024.0d, (double) log10);
        Double.isNaN(d);
        sb.append(decimalFormat.format(d / pow));
        sb.append(" ");
        sb.append(strArr[log10]);
        return sb.toString();
    }

    public static List<File> getListFiles(File file) {
        File[] listFiles;
        ArrayList arrayList = new ArrayList();
        for (File file2 : file.listFiles()) {
            if (file2.isDirectory()) {
                arrayList.addAll(getListFiles(file2));
            } else if (file2.getName().endsWith(".mp4") || file2.getName().endsWith(".3gp") || file2.getName().endsWith(".mkv") || file2.getName().endsWith(".flv")) {
                arrayList.add(file2);
            }
        }
        return arrayList;
    }

    public static List<File> getFiles(File file) {
        ArrayList arrayList = new ArrayList();
        try {
            File[] listFiles = file.listFiles();
            if (listFiles != null && listFiles.length > 0) {
                for (File file2 : listFiles) {
                    if (!file2.isDirectory()) {
                        if (file2.getName().endsWith(".mp4") || file2.getName().endsWith(".3gp") || file2.getName().endsWith(".mkv") || file2.getName().endsWith(".flv")) {
                            arrayList.add(file2);
                        }
                    }
                }
            }
            Collections.sort(arrayList, new Comparator<File>() {
                public int compare(File file, File file2) {
                    return new Date(file2.lastModified()).compareTo(new Date(file.lastModified()));
                }
            });
        } catch (Exception unused) {
        }
        return arrayList;
    }

    public static String millisecondsToTime(long j) {
        long j2 = j / 1000;
        long j3 = (j2 / 60) % 60;
        return String.format("%d:%02d:%02d", new Object[]{Long.valueOf((j2 / 3600) % 24), Long.valueOf(j3), Long.valueOf(j2 % 60)});
    }

    public static String getVideoDuration(String str, Context context) {
        int i;
        try {
            MediaPlayer create = MediaPlayer.create(context, Uri.parse(str));
            i = create.getDuration();
            create.release();
        } catch (Exception unused) {
            i = 0;
        }
        long j = (long) i;
        return String.format("%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j)))});
    }

    public static String getViews(double d) {
        double d2 = d / 1000000.0d;
        String str = "##.##";
        if (Math.abs(d2) > 1.0d) {
            StringBuilder sb = new StringBuilder();
            sb.append(new DecimalFormat(str).format(d2));
            sb.append("m");
            return sb.toString();
        }
        double d3 = d / 1000.0d;
        if (Math.abs(d3) <= 1.0d) {
            return String.valueOf(d);
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(new DecimalFormat(str).format(d3));
        sb2.append("k");
        return sb2.toString();
    }

    public static String bitmapForDirectory(String str) {
        List files = getFiles(new File(str));
        return files.size() > 0 ? ((File) files.get(0)).getAbsolutePath() : "";
    }

    public static long createRandomInteger(int i, long j, Random random) {
        long j2 = (long) i;
        if (j2 <= j) {
            double d = (double) ((j - j2) + 1);
            double nextDouble = random.nextDouble();
            Double.isNaN(d);
            return ((long) (d * nextDouble)) + j2;
        }
        throw new IllegalArgumentException("Start cannot exceed End.");
    }

    public static String[] getAllVideoPath(Context context) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        String str = "duration";
        String[] strArr = {"_data", str};
        ContentResolver contentResolver = context.getContentResolver();
        StringBuilder sb = new StringBuilder();
        sb.append("datetaken");
        sb.append(" DESC");
        Cursor query = contentResolver.query(uri, strArr, null, null, sb.toString());
        ArrayList arrayList = new ArrayList();
        if (query != null) {
            while (query.moveToNext()) {
                arrayList.add(query.getString(0));
                videoduration.add(formateMilliSeccond(query.getLong(query.getColumnIndex(str))));
            }
            query.close();
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    public static String formateMilliSeccond(long j) {
        String str;
        String str2;
        int i = (int) (j / 3600000);
        long j2 = j % 3600000;
        int i2 = ((int) j2) / 60000;
        int i3 = (int) ((j2 % DefaultLoadErrorHandlingPolicy.DEFAULT_TRACK_BLACKLIST_MS) / 1000);
        String str3 = ":";
        String str4 = "";
        if (i > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(i);
            sb.append(str3);
            str = sb.toString();
        } else {
            str = str4;
        }
        if (i3 < 10) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("0");
            sb2.append(i3);
            str2 = sb2.toString();
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str4);
            sb3.append(i3);
            str2 = sb3.toString();
        }
        StringBuilder sb4 = new StringBuilder();
        sb4.append(str);
        sb4.append(i2);
        sb4.append(str3);
        sb4.append(str2);
        return sb4.toString();
    }

    public static void DeleteContentResolverValue(Context context, String str) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        context.getContentResolver().delete(uri, "_data=?", new String[]{str});
    }

    public static String getRealPathFromURI(Context context, Uri uri) {
        String str = "_data";
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(uri, new String[]{str}, null, null, null);
            int columnIndexOrThrow = cursor.getColumnIndexOrThrow(str);
            cursor.moveToFirst();
            return cursor.getString(columnIndexOrThrow);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
