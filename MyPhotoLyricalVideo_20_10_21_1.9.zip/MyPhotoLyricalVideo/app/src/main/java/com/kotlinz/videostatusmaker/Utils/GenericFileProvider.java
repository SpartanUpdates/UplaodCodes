package com.kotlinz.videostatusmaker.Utils;

import androidx.core.content.FileProvider;
public class GenericFileProvider extends FileProvider {
}
