﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class LevelLockCheck : MonoBehaviour
{
    public int Levelno = 1;
    void OnEnable()
    {
        if (PlayerPrefs.GetInt("Level" + (Levelno - 1)) == 0)
        {
            this.GetComponent<Button>().interactable = false;
            this.gameObject.transform.GetChild(0).gameObject.SetActive(false);
        }
        else
        {
            this.GetComponent<Button>().interactable = true;
        }
    }
}
