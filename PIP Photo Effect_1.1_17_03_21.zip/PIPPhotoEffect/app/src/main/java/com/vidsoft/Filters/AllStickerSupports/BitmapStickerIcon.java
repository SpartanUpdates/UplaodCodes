package com.vidsoft.Filters.AllStickerSupports;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;

public class BitmapStickerIcon extends DrawableSticker {
    public static final float DEFAULT_ICON_EXTRA_RADIUS = 10.0f;
    public static final float DEFAULT_ICON_RADIUS = 10.0f;
    private float iconExtraRadius;
    private float iconRadius;
    private float x;
    private float y;

    public BitmapStickerIcon(Drawable drawable) {
        super(drawable);
        this.iconRadius = DEFAULT_ICON_RADIUS;
        this.iconExtraRadius = DEFAULT_ICON_RADIUS;
    }

    public void draw(Canvas canvas, Paint paint) {
        canvas.drawCircle(this.x, this.y, this.iconRadius, paint);
        super.draw(canvas);
    }

    public float getX() {
        return this.x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return this.y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getIconRadius() {
        return this.iconRadius;
    }

    public void setIconRadius(float iconRadius) {
        this.iconRadius = iconRadius;
    }

    public float getIconExtraRadius() {
        return this.iconExtraRadius;
    }

    public void setIconExtraRadius(float iconExtraRadius) {
        this.iconExtraRadius = iconExtraRadius;
    }
}
