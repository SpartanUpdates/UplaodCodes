package com.kotlinz.vehiclemanager.history.Model;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "LicenseHistory",indices = @Index(value = {"licenseNo"},unique = true))
public class LicenseHistory {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String licenseNo;
    public String dob;
    public String holderName;
    public String dateOfIssue;
    public String currentStatus;
    public String lastTransactionAt;
    public String validFrom;
    public String validTo;
    public String vehicleClass;

    public LicenseHistory(String licenseNo, String dob, String holderName, String dateOfIssue, String currentStatus, String lastTransactionAt, String validFrom, String validTo, String vehicleClass) {
        this.licenseNo = licenseNo;
        this.dob = dob;
        this.holderName = holderName;
        this.dateOfIssue = dateOfIssue;
        this.currentStatus = currentStatus;
        this.lastTransactionAt = lastTransactionAt;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.vehicleClass = vehicleClass;
    }
    public String getLicenseNo() {
        return licenseNo;
    }
    public String getDob() {
        return dob;
    }
    public String getHolderName() {
        return holderName;
    }
    public String getDateOfIssue() {
        return dateOfIssue;
    }
    public String getCurrentStatus() {
        return currentStatus;
    }
    public String getLastTransactionAt() {
        return lastTransactionAt;
    }
    public String getValidFrom() {
        return validFrom;
    }
    public String getValidTo() {
        return validTo;
    }
    public String getVehicleClass() {
        return vehicleClass;
    }
}
