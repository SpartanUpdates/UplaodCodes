package com.rtovehicleinformation.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class RToCredentialsModelResponse {

	@SerializedName("response")
	private ArrayList<RToCredentialsModel> response;

	@SerializedName("message")
	private String message;

	@SerializedName("errors")
	private ArrayList<Object> errors;

	@SerializedName("status")
	private boolean status;

	public ArrayList<RToCredentialsModel> getResponse(){
		return response;
	}

	public String getMessage(){
		return message;
	}

	public ArrayList<Object> getErrors(){
		return errors;
	}

	public boolean isStatus(){
		return status;
	}
}