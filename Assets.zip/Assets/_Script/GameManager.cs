﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public GameObject[] pencilEnemy, eraserPlayer;

    [HideInInspector]
    public Transform enemyTransform, playerTransfrom;

    [Header("Way Point Script")]
    public WayPoints[] wayPointsContainer;

    [HideInInspector]
    public List<GameObject> waypoints1;

    [Space(2)]
    [Header("Number Of Particles Maximum In Level")]
    public int maxParticles;

    [Space(2)]
    [Header("Number Of Particles Mininum In Level(400)")]
    public int minParticles;

    [Space(2)]
    [Header("Power Up Data For Life Line")]
    public GameObject powerUp;

    public Image lifeLineBlur;
    public PowerUpData[] powerUpdata;
    [System.Serializable]
    public class PowerUpData
    {
        [Range(0, 1)]
        public float min, max;
        [HideInInspector]
        public bool isDone = false;
    }
    int cntPData = 0;

    public GameObject finishparticles;

    public GameObject pressMeText;

    public Image distanceImage;

    [HideInInspector]
    public bool isGameOver = false, isGameFinish = false, isGamePause = false;

    public GameObject pausePanel;

    [Space(2)]
    [Header("Key")]
    public GameObject keyPrefab;

    public int minKeyPos, maxKeyPos;

    [HideInInspector]
    public bool isKeyOneTime = false, isKeyInsti = false;

    int keyZpos;

    public GameObject[] KeySet;

    [Space(2)]
    [Header("Game Over Component")]
    public GameObject gameoverPanel;

    public GameObject longPanel, shortPanel, longStar, shortStar;

    bool startTimer = false;

    public Image timerBar;

    public Button btnGORestart, btnGoHome;

    public Button btnContinue;

    public TextMeshProUGUI txtTimer, levelName1, levelName4;

    bool isVideoShow = false;

    [Space(2)]
    [Header("Level Completed Component")]
    public GameObject levelCompleted, congratulationsPanel;

    public TextMeshProUGUI levelName2, levelScore;

    public GameObject giftPanel;

    public Animator finishStar;

    public Button btnGet50;

    [Space(2)]
    [Header("Coin Data")]
    public TextMeshProUGUI txtCoins;

    public GameObject gameMain, keyBase, chestBase;

    public TextMeshProUGUI levelName3;

    int cntActiveParticle;

    float remParticles, fillAmontValue, preFillValue = 1;

    bool isStopFalse = true;

    Vector3 playerStartPos;

    public Color[] particleColors;

    public GameObject bannerViewPanel;

    public GameObject loadingText1, loadingText2, loadingText3;

    [HideInInspector]
    public bool isRewardCoinClick = false, isRewardCoinDone = false;

    public GameObject coinGetparticles, noAdsPanel;

    bool isGet50Done = false;

    [HideInInspector]
    public bool isRewardSaveClick = false, isRewardSaveDone = false;

    Vector3 tempCoinPos;

    public CanvasScaler canvas1;

    void Awake()
    {
        instance = this;
        if (GetAspectRatio(Screen.width, Screen.height) > 0.6f)
        {
            canvas1.matchWidthOrHeight = 1;
        }

        if (!GameObject.FindGameObjectWithTag("Enemy"))
        {
            Instantiate(pencilEnemy[PlayerPrefs.GetInt("Pencil")], pencilEnemy[PlayerPrefs.GetInt("Pencil")].transform.position, Quaternion.identity);
            Instantiate(eraserPlayer[PlayerPrefs.GetInt("Eraser")], eraserPlayer[PlayerPrefs.GetInt("Eraser")].transform.position, Quaternion.identity);
        }
        enemyTransform = GameObject.FindGameObjectWithTag("Enemy").transform;
        playerTransfrom = GameObject.FindGameObjectWithTag("Player").transform;
        playerStartPos = playerTransfrom.position;

        keyZpos = Random.Range(minKeyPos, maxKeyPos);

        if (PlayerPrefs.GetInt("KeyLevel0" + PlayerPrefs.GetInt("LevelNumber")) == 0)
        {
            isKeyOneTime = true;
            isKeyInsti = true;
        }
        else
        {
            isKeyOneTime = false;
        }
        if (SoundManger.instance.bgMainMusic.isPlaying)
            SoundManger.instance.bgMainMusic.Stop();

        if (!SoundManger.instance.bgPlayMusic.isPlaying)
            SoundManger.instance.bgPlayMusic.Play();

        gameoverPanel.SetActive(false);
        levelCompleted.SetActive(false);
        gameMain.SetActive(true);
        if(Manager.instance.isOneTimePlay)
            pressMeText.SetActive(false);
        finishparticles.SetActive(false);
        lifeLineBlur.gameObject.SetActive(false);
        btnGORestart.interactable = false;
        btnGoHome.interactable = false;
        timerBar.fillAmount = 1;
        btnContinue.interactable = true;
        levelName1.text = levelName2.text = levelName3.text = levelName4.text = "Level " + PlayerPrefs.GetInt("LevelNumber");
    }

    void Start()
    {
        bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, CalculateBannerHeight());
        if (Manager.instance.isNetWorkOn)
            bannerViewPanel.SetActive(true);
        else
            bannerViewPanel.SetActive(false);
    }
    int CalculateBannerHeight()
    {
        if (Screen.height <= 400 * Screen.dpi / 160)
            return Mathf.RoundToInt(32 * Screen.dpi / 160) + 8;
        else if (Screen.height <= 720 * Screen.dpi / 160)
            return Mathf.RoundToInt(50 * Screen.dpi / 160 * 1.5f) + 8;
        else
            return Mathf.RoundToInt(90 * Screen.dpi / 160) - 10;
    }

    void Update()
    {
        txtCoins.text = PlayerPrefs.GetInt("Coins").ToString();
        if (!isGameFinish && !isGameOver)
        {
            if (powerUpdata.Length >= 1)
            {
                if (distanceImage.fillAmount > powerUpdata[cntPData].min && distanceImage.fillAmount < powerUpdata[cntPData].max)
                {
                    if (!powerUpdata[cntPData].isDone)
                    {
                        powerUpdata[cntPData].isDone = true;
                        tempCoinPos = enemyTransform.position;
                        tempCoinPos.y = enemyTransform.position.y - 2.5f;
                        Instantiate(powerUp, tempCoinPos, Quaternion.identity);
                        cntPData++;
                        if (cntPData >= powerUpdata.Length)
                            cntPData = (powerUpdata.Length - 1);
                    }
                }
            }
            //Life Line Bar
            cntActiveParticle = enemyTransform.GetComponent<WayMover>().lineParticle[0].particleCount + enemyTransform.GetComponent<WayMover>().lineParticle[1].particleCount;

            remParticles = maxParticles - cntActiveParticle;
            fillAmontValue = remParticles / minParticles;
            if (preFillValue > fillAmontValue || (preFillValue + 0.05f) < fillAmontValue)
            {
                distanceImage.fillAmount = fillAmontValue;
                preFillValue = fillAmontValue;
                if (distanceImage.fillAmount < 0.3f)
                {
                    lifeLineBlur.gameObject.SetActive(true);
                    float temp = 1.1f - (float)(distanceImage.fillAmount / 0.3);
                    lifeLineBlur.color = new Color(255, 0, 0, temp);

                    distanceImage.GetComponentInParent<Animator>().Play("barDistance1");
                    if (distanceImage.fillAmount == 0)
                    {
                        GameOver();
                        playerTransfrom.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
                        playerTransfrom.GetComponent<Rigidbody>().AddRelativeForce(-Vector3.forward * 5, ForceMode.Impulse);
                        PlayerController.instance.endPos = playerTransfrom.position;
                        SoundManger.instance.gameOver.Play();
                        if (SoundManger.instance.bgPlayMusic.isPlaying)
                            SoundManger.instance.bgPlayMusic.Stop();
                    }
                }
                else
                {
                    if (isStopFalse)
                        lifeLineBlur.gameObject.SetActive(false);
                }
            }
            //Keycode
            if (isKeyOneTime)
            {
                if (enemyTransform.position.z > keyZpos && isKeyInsti)
                {
                    isKeyInsti = false;
                    isKeyOneTime = false;
                    tempCoinPos = enemyTransform.position;
                    tempCoinPos.y = keyPrefab.gameObject.transform.position.y;
                    Instantiate(keyPrefab, tempCoinPos, Quaternion.identity);
                }
            }
        }
        else
        {
            if (startTimer)
            {
                timerBar.fillAmount -= 0.1f * Time.deltaTime;
                txtTimer.text = Mathf.RoundToInt(timerBar.fillAmount * 10).ToString();

                if (timerBar.fillAmount < 0.65)
                {
                    if (!btnGoHome.IsInteractable())
                    {
                        btnGORestart.interactable = true;
                        btnGoHome.interactable = true;
                    }
                }
                if (timerBar.fillAmount == 0)
                {
                    btnContinue.interactable = false;
                    Destroy(btnContinue.GetComponent<Animator>());
                    btnGORestart.GetComponent<Animator>().enabled = true;
                    btnContinue.GetComponent<RectTransform>().localScale = Vector3.one;
                    startTimer = false;
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!isGameOver && !isGameFinish && !isGamePause)
                OnPauseClick();
            else if (!isGameOver && !isGameFinish && isGamePause)
                OnResumeClick();
        }
    }

    IEnumerator LifeLinePowerUp(float temp = 0.3f)
    {
        isStopFalse = false;
        lifeLineBlur.color = new Color32(131, 245, 243, 255);
        WaitForSecondsRealtime delay = new WaitForSecondsRealtime(temp);
        lifeLineBlur.gameObject.SetActive(true);
        yield return delay;
        lifeLineBlur.gameObject.SetActive(false);
        yield return delay;
        lifeLineBlur.gameObject.SetActive(true);
        yield return delay;
        lifeLineBlur.gameObject.SetActive(false);
        yield return delay;
        lifeLineBlur.gameObject.SetActive(true);
        yield return delay;
        lifeLineBlur.gameObject.SetActive(false);
        lifeLineBlur.color = new Color32(255, 18, 0, 0);
        isStopFalse = true;
    }
    public void GameFinished()
    {
        if (!isGameFinish)
        {
            isGameFinish = true;
            ActiveKey();
            Camera.main.GetComponent<SmoothCameraFollow>().enabled = false;
            this.finishparticles.SetActive(true);
            pressMeText.gameObject.SetActive(false);
            gameMain.SetActive(false);
            StartCoroutine(WaitForFinished());

            if (PlayerPrefs.GetInt("Level" + PlayerPrefs.GetInt("LevelNumber")) == 0)
            {
                PlayerPrefs.SetInt("Level" + PlayerPrefs.GetInt("LevelNumber"), 1);
                PlayerPrefs.SetInt("PlayLevel", PlayerPrefs.GetInt("PlayLevel") + 1);
                if (PlayerPrefs.GetInt("PlayLevel") == 21)
                {
                    PlayerPrefs.SetInt("IsGameOneTimeFinished", 1);
                    PlayerPrefs.SetInt("PlayLevel", 1);
                }
            }
            else {
                if (PlayerPrefs.GetInt("IsGameOneTimeFinished") == 1)
                {
                    PlayerPrefs.SetInt("PlayLevel", PlayerPrefs.GetInt("PlayLevel") + 1);
                    if(PlayerPrefs.GetInt("PlayLevel")>=21)
                        PlayerPrefs.SetInt("PlayLevel", 1);
                }
            }
            lifeLineBlur.gameObject.SetActive(false);
        }
    }

    IEnumerator WaitForFinished()
    {
        yield return new WaitForSecondsRealtime(2f);
        if (PlayerPrefs.GetInt("KeyCount") == 3)
        {
            giftPanel.SetActive(true);
            chestBase.SetActive(true);
        }
        else
        {
            keyBase.SetActive(true);

            if (PlayerPrefs.GetInt("LevelNumber") == 20)
                congratulationsPanel.SetActive(true);
            else
                levelCompleted.SetActive(true);

            if (distanceImage.fillAmount > 0.75f)
                finishStar.Play("3StarFinish");
            else if (distanceImage.fillAmount > 0.5f)
                finishStar.Play("2StarFinish");
            else
                finishStar.Play("1StarFinish");
        }
    }
    public void ActiveKey()
    {
        for (int i = 0; i < KeySet.Length; i++)
            KeySet[i].SetActive(false);

        for (int i = 0; i < PlayerPrefs.GetInt("KeyCount"); i++)
            KeySet[i].SetActive(true);
    }
    public void GameOver()
    {
        isGameOver = true;
        lifeLineBlur.gameObject.SetActive(false);
        Camera.main.GetComponent<CameraShake>().enabled = true;
        gameMain.SetActive(false);
        pressMeText.gameObject.SetActive(false);
        ActiveKey();
        StartCoroutine(GameOverWait());
    }
    IEnumerator GameOverWait()
    {
        yield return new WaitForSecondsRealtime(1.5f);
        gameoverPanel.SetActive(true);
        keyBase.SetActive(true);
        float endDistance1 = Vector3.Distance(playerStartPos, finishparticles.transform.position);
        float startDistance1 = Vector3.Distance(playerTransfrom.position, finishparticles.transform.position);
        startDistance1 = startDistance1 / endDistance1;
        if (isVideoShow)
        {
            shortPanel.SetActive(true);
            if (startDistance1 > 0.5)
                shortStar.GetComponent<Animator>().Play("1StarFinish");
            else
                shortStar.GetComponent<Animator>().Play("2StarFinish");
        }
        else
        {
            startTimer = true;
            longPanel.SetActive(true);
            if (startDistance1 > 0.5)
                longStar.GetComponent<Animator>().Play("1StarFinish");
            else
                longStar.GetComponent<Animator>().Play("2StarFinish");
        }
    }

    public void SaveMe()
    {
        ButtonClickSound();
        if (RewardAddShow.instance.rewardBasedVideo.IsLoaded())
        {
            RewardAddShow.instance.ShowVideo();
            isRewardSaveClick = true;
        }
        else
        {
            noAdsPanel.SetActive(true);
            RewardAddShow.instance.RequestRewardBasedVideo();
            Invoke("CloseNoAddPanel", 2);
        }
    }
    public void SaveMeDone()
    {
        isRewardSaveClick = false;
        if (isRewardSaveDone)
        {
            isRewardSaveDone = false;

            isVideoShow = true;
            playerTransfrom.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotation;
            playerTransfrom.position = PlayerController.instance.endPos;
            playerTransfrom.localEulerAngles = Vector3.zero;
            if (remParticles < maxParticles / 2)
                maxParticles += (maxParticles / 3) + 500;
            else
            {
                maxParticles += UnityEngine.Random.Range(750, 1500);
                if (((float)maxParticles - cntActiveParticle) / minParticles > 1.02f)
                    maxParticles = minParticles + cntActiveParticle + 200;
            }

            if (PlayerController.instance.isObstacleTouch)
                PlayerController.instance.lastTouchObject.SetActive(false);
            else if (PlayerController.instance.isBaseObstacle)
                playerTransfrom.position = new Vector3(PlayerController.instance.platfromPos.x, playerStartPos.y, playerTransfrom.position.z);
            isGameOver = false;
            gameMain.SetActive(true);
            gameoverPanel.SetActive(false);
            keyBase.SetActive(false);
            Camera.main.GetComponent<CameraShake>().enabled = false;
            shortPanel.SetActive(false);
            longPanel.SetActive(false);
            SoundManger.instance.bgPlayMusic.Play();
        }
    }
    public void OnPauseClick()
    {
        if (!isGameOver && !isPauseWait)
        {
            ButtonClickSound();
            pausePanel.SetActive(true);
            Time.timeScale = 0;
            pausePanel.GetComponent<Animator>().Play("PausePanel");
            isGamePause = true;
            StartCoroutine(OnPauseWait());
        }
    }
    bool isPauseWait = false;
    IEnumerator OnPauseWait()
    {
        isPauseWait = true;
        yield return new WaitForSecondsRealtime(0.8f);
        isPauseWait = false;
    }

    public void OnResumeClick()
    {
        if (!isGameOver && !isPauseWait)
        {
            ButtonClickSound();
            pausePanel.GetComponent<Animator>().Play("PausePanelClose");
            StartCoroutine(OnResumeWait());
        }
    }
    IEnumerator OnResumeWait()
    {
        isPauseWait = true;
        yield return new WaitForSecondsRealtime(0.8f);
        Time.timeScale = 1;
        pausePanel.SetActive(false);
        isGamePause = false;
        isPauseWait = false;
    }
    public void OnRestartClick()
    {
        ButtonClickSound();
        Time.timeScale = 1;
        SoundManger.instance.gameFinish.Stop();
        Manager.instance.restartLevel++;
        if (Manager.instance.restartLevel == 2)
        {
            Manager.instance.restartLevel = 0;
            if (InterstitialAddShow.instance.interstitial.IsLoaded())
            {
                isRestartClick = true;
                ClosePanel();
                InterstitialAddShow.instance.ShowInterstitial();
            }
            else
            {
                Manager.instance.restartLevel = 1;
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        }
        else
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    [HideInInspector]
    public bool isHomeAdsClick = false, isNextLevelClick = false, isRestartClick = false;

    public void OnHomeClick()
    {
        ButtonClickSound();
        SoundManger.instance.gameFinish.Stop();
        if (InterstitialAddShow.instance.interstitial.IsLoaded())
        {
            isHomeAdsClick = true;
            ClosePanel();
            InterstitialAddShow.instance.ShowInterstitial();
        }
        else
            SceneManager.LoadScene("MainScene");
    }

    public void OnNextLevelClick()
    {
        ButtonClickSound();
        PlayerPrefs.SetInt("LevelNumber", PlayerPrefs.GetInt("LevelNumber") + 1);
        SoundManger.instance.gameFinish.Stop();

        if (InterstitialAddShow.instance.interstitial.IsLoaded() && !isGet50Done)
        {
            isNextLevelClick = true;
            ClosePanel();
            InterstitialAddShow.instance.ShowInterstitial();
        }
        else
            SceneManager.LoadScene("Level" + PlayerPrefs.GetInt("LevelNumber"));
    }

    void ClosePanel()
    {
        loadingText1.SetActive(true);
        loadingText2.SetActive(true);
        loadingText3.SetActive(true);
        longPanel.SetActive(false);
        shortPanel.SetActive(false);
        levelCompleted.transform.GetChild(1).gameObject.SetActive(false);
        pausePanel.transform.GetChild(1).gameObject.SetActive(false);
    }
    void OnDestroy()
    {
        Time.timeScale = 1;
    }

    public void OnGet50Extra()
    {
        coinGetparticles.SetActive(false);
        ButtonClickSound();
        if (RewardAddShow.instance.rewardBasedVideo.IsLoaded())
        {
            RewardAddShow.instance.ShowVideo();
            isRewardCoinClick = true;
        }
        else
        {
            noAdsPanel.SetActive(true);
            RewardAddShow.instance.RequestRewardBasedVideo();
            Invoke("CloseNoAddPanel", 2);
        }
    }
    public void RewardDone()
    {
        isRewardCoinClick = false;
        if (isRewardCoinDone)
        {
            StartCoroutine(CoinAdd());
            isRewardCoinDone = false;
            isGet50Done = true;
            btnGet50.interactable = false;
            btnGet50.GetComponent<Animator>().enabled = false;
        }
    }
    IEnumerator CoinAdd()
    {
        int a = 0;
        WaitForSecondsRealtime delay = new WaitForSecondsRealtime(0.1f);
        while (a != 50)
        {
            a += 5;
            PlayerPrefs.SetInt("Coins", PlayerPrefs.GetInt("Coins") + 5);
            if (a > 10 && !coinGetparticles.activeSelf)
            {
                coinGetparticles.SetActive(true);
            }
            yield return 0;
        }
        yield return delay;
        a = 0;
    }
    void CloseNoAddPanel()
    {
        noAdsPanel.SetActive(false);
    }
    private float GetAspectRatio(float width, float height)
    {
        return (width / height);
    }

    void ButtonClickSound()
    {
        SoundManger.instance.Vibrate();
        if (!SoundManger.instance.btnClick.isPlaying)
            SoundManger.instance.btnClick.Play();
    }
}
