package com.vidsoft.collagemaker.GridThreeD;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Process;
import android.provider.MediaStore.Images.Media;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.appcompat.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.Model.Album;
import com.vidsoft.collagemaker.Model.Image;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

public class ImageSelectionthreeDActivity extends AppCompatActivity {
    Activity activity;
    ArrayList<Album> albumArrayList;
    AlbumSelectAdapter albumSelectAdapter;
    int currentCount;
    int currentGrid;
    GridView gridView;
    ArrayList<Image> imageArrayList;
    ImageSelectAdapter imageSelectAdapter;
    String imgId;
    String imgSource;
    LinearLayoutManager linearLayoutManager;
    ListView listView;
    private final String[] projection;
    RecyclerView recyclerView;
    SelectedImageAdapter selectedImageAdapter;
    ArrayList<String> selectedImageList;
    TextView textView;
    int totalCount;
    TextView textView1;

    public class AlbumSelectAdapter extends BaseAdapter {
        ArrayList<Album> albumArrayList;
        Context context;

        public AlbumSelectAdapter(final Context context, final ArrayList<Album> albumArrayList) {
            this.albumArrayList = albumArrayList;
            this.context = context;
        }

        public int getCount() {
            return this.albumArrayList.size();
        }

        public Object getItem(final int n) {
            return n;
        }

        public long getItemId(final int n) {
            return n;
        }

        public View getView(final int n, View inflate, final ViewGroup viewGroup) {
            inflate = LayoutInflater.from(this.context).inflate(R.layout.album_select_adapter, viewGroup, false);
            final Holder holder = new Holder();
            holder.album_img = (ImageView) inflate.findViewById(R.id.album_img);
            holder.album_name = (TextView) inflate.findViewById(R.id.tv_albumname);
            holder.album_total = (TextView) inflate.findViewById(R.id.tv_albumtotal);
            holder.album_name.setText((CharSequence) this.albumArrayList.get(n).getName());
            Glide.with(this.context).load(this.albumArrayList.get(n).getCover()).placeholder(R.drawable.placeholder).into(holder.album_img);
            holder.album_total.setText((CharSequence) ("(" + this.albumArrayList.get(n).getCount() + ")"));
            return inflate;
        }

        public class Holder {
            ImageView album_img;
            TextView album_name;
            TextView album_total;
        }
    }


    public class ImageSelectAdapter extends BaseAdapter {
        Context context;
        ArrayList<Image> imageArrayList;

        public class Holder {
            ImageView imageView;
        }

        public ImageSelectAdapter(Context context, ArrayList<Image> imageArrayList) {
            this.imageArrayList = imageArrayList;
            this.context = context;
        }

        public int getCount() {
            return this.imageArrayList.size();
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int position, View view, ViewGroup viewGroup) {
            view = LayoutInflater.from(this.context).inflate(R.layout.adapter_image_select, viewGroup, false);
            Holder holder = new Holder();
            holder.imageView = (ImageView) view.findViewById(R.id.imageView);
            Glide.with(this.context).load(((Image) this.imageArrayList.get(position)).path).placeholder((int) R.drawable.placeholder).into(holder.imageView);
            return view;
        }
    }

    public class SelectedImageAdapter extends Adapter<SelectedImageAdapter.ViewHolder> {
        Context context;
        ArrayList<String> selectedImageList;


        public class ViewHolder extends RecyclerView.ViewHolder {
            RelativeLayout delete_img;
            ImageView imageView;

            public ViewHolder(View itemView) {
                super(itemView);
                this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
                this.delete_img = (RelativeLayout) itemView.findViewById(R.id.delete_img);
            }
        }

        public SelectedImageAdapter(Context context, ArrayList<String> selectedImageList) {
            this.selectedImageList = selectedImageList;
            this.context = context;
        }

        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.adapter_selected_image, parent, false));
        }

        public void onBindViewHolder(ViewHolder holder, final int position) {
            Glide.with(this.context).load((String) this.selectedImageList.get(position)).placeholder((int) R.drawable.placeholder).into(holder.imageView);
            holder.delete_img.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    SelectedImageAdapter.this.selectedImageList.remove(position);
                    SelectedImageAdapter.this.notifyDataSetChanged();
                    ImageSelectionthreeDActivity imageSelectionActivity = ImageSelectionthreeDActivity.this;
                    imageSelectionActivity.currentCount--;
                    ImageSelectionthreeDActivity.this.textView1.setText(ImageSelectionthreeDActivity.this.currentCount + "/" + ImageSelectionthreeDActivity.this.totalCount);

                }
            });
        }

        public int getItemCount() {
            return this.selectedImageList.size();
        }
    }

    public ImageSelectionthreeDActivity() {
        this.activity = this;
        this.currentCount = 0;
        this.imageArrayList = new ArrayList();
        this.albumArrayList = new ArrayList();
        this.selectedImageList = new ArrayList();
        this.projection = new String[]{"bucket_id", "bucket_display_name", "_data"};
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.act_imageselection);
        bindToolbar();
        bindControls();
        fetchAlbumData();
        clickEvent();
    }

    private void bindToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator((int) R.drawable.back_btn_selector);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.textView = (TextView) toolbar.findViewById(R.id.toolbar_title);
        this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
    }


    private void fetchAlbumData() {
        Process.setThreadPriority(10);
        Cursor cursor = this.activity.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, null, null, "date_added");
        if (cursor == null) {
            AlertDialog.Builder alertDialogbuilder = new AlertDialog.Builder(this.activity);
            alertDialogbuilder.setMessage(getResources().getString(R.string.sdcard_error));
            alertDialogbuilder.setPositiveButton((CharSequence) "Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    ImageSelectionthreeDActivity.this.finish();
                }
            });
            alertDialogbuilder.setCancelable(false);
            alertDialogbuilder.show();
            return;
        }
        ArrayList<Album> arrayList = new ArrayList(cursor.getCount());
        HashSet<Long> albumSet = new HashSet();
        while (cursor.moveToLast()) {
            while (!Thread.interrupted()) {
                long albumId = cursor.getLong(cursor.getColumnIndex(this.projection[0]));
                String album = cursor.getString(cursor.getColumnIndex(this.projection[1]));
                String image = cursor.getString(cursor.getColumnIndex(this.projection[2]));
                if (!albumSet.contains(Long.valueOf(albumId)) && new File(image).exists()) {
                    Cursor tempCursor = getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, "bucket_display_name =?", new String[]{album}, "date_added");
                    arrayList.add(new Album(album, image, tempCursor.getCount() + ""));
                    albumSet.add(Long.valueOf(albumId));
                    tempCursor.close();
                }
                if (!cursor.moveToPrevious()) {
                    cursor.close();
                    if (this.albumArrayList == null) {
                        this.albumArrayList = new ArrayList();
                    }
                    this.albumArrayList.clear();
                    this.albumArrayList.addAll(arrayList);
                    this.albumSelectAdapter = new AlbumSelectAdapter(this.activity, this.albumArrayList);
                    this.listView.setAdapter(this.albumSelectAdapter);
                    return;
                }
            }
        }
    }

    private void fetchImageData(String album) {
        HashSet<Long> selectedImages = new HashSet();
        if (this.imageArrayList != null) {
            int l = this.imageArrayList.size();
            for (int i = 0; i < l; i++) {
                Image image = (Image) this.imageArrayList.get(i);
                if (new File(image.path).exists() && image.isSelected) {
                    selectedImages.add(Long.valueOf(image.id));
                }
            }
        }
        Cursor cursor = getContentResolver().query(Media.EXTERNAL_CONTENT_URI, this.projection, "bucket_display_name =?", new String[]{album}, "date_added");
        int tempCountSelected = 0;
        ArrayList<Image> temp = new ArrayList(cursor.getCount());
        if (cursor.moveToLast()) {
            while (!Thread.interrupted()) {
                long id = cursor.getLong(cursor.getColumnIndex(this.projection[0]));
                String name = cursor.getString(cursor.getColumnIndex(this.projection[1]));
                String path = cursor.getString(cursor.getColumnIndex(this.projection[2]));
                boolean isSelected = selectedImages.contains(Long.valueOf(id));
                if (isSelected) {
                    tempCountSelected++;
                }
                if (new File(path).exists()) {
                    temp.add(new Image(id, name, path, isSelected));
                }
                if (!cursor.moveToPrevious()) {
                    this.imageArrayList.clear();
                    this.imageArrayList.addAll(temp);
                    this.imageSelectAdapter = new ImageSelectAdapter(this.activity, this.imageArrayList);
                    this.gridView.setAdapter(this.imageSelectAdapter);
                    return;
                }
            }
            return;
        }
        cursor.close();
        if (this.imageArrayList == null) {
            this.imageArrayList = new ArrayList();
        }
        this.imageArrayList.clear();
        this.imageArrayList.addAll(temp);
        this.imageSelectAdapter = new ImageSelectAdapter(this.activity, this.imageArrayList);
        this.gridView.setAdapter(this.imageSelectAdapter);
    }

    private void clickEvent() {
        this.textView1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (ImageSelectionthreeDActivity.this.textView1.getText().equals(ImageSelectionthreeDActivity.this.getResources().getString(R.string.done))) {
                    Intent intent = new Intent(ImageSelectionthreeDActivity.this.activity, GridEditActivity.class);
                    intent.putExtra(Const.imgId, ImageSelectionthreeDActivity.this.imgId);
                    intent.putExtra(Const.imgSource, ImageSelectionthreeDActivity.this.imgSource);
                    intent.putExtra(Const.currentGrid, ImageSelectionthreeDActivity.this.currentGrid);
                    intent.putStringArrayListExtra(Const.imgList, ImageSelectionthreeDActivity.this.selectedImageList);
                    ImageSelectionthreeDActivity.this.startActivity(intent);
                    ImageSelectionthreeDActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    return;
                }
                Toast.makeText(ImageSelectionthreeDActivity.this.activity, "Please select " + ImageSelectionthreeDActivity.this.totalCount + " image(s)", Toast.LENGTH_SHORT).show();
            }
        });
        this.listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ImageSelectionthreeDActivity.this.listView.setVisibility(View.GONE);
                ImageSelectionthreeDActivity.this.textView.setText(((Album) ImageSelectionthreeDActivity.this.albumArrayList.get(position)).getName());
                ImageSelectionthreeDActivity.this.fetchImageData(((Album) ImageSelectionthreeDActivity.this.albumArrayList.get(position)).getName());
            }
        });
        this.gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if (ImageSelectionthreeDActivity.this.textView1.getText().equals(ImageSelectionthreeDActivity.this.getResources().getString(R.string.done))) {
                    Toast.makeText(ImageSelectionthreeDActivity.this.activity, "Can't select more than " + ImageSelectionthreeDActivity.this.totalCount + " image(s)", Toast.LENGTH_SHORT).show();
                    return;
                }
                ImageSelectionthreeDActivity imageSelectionActivity;
                if (ImageSelectionthreeDActivity.this.currentCount == ImageSelectionthreeDActivity.this.totalCount - 1) {
                    imageSelectionActivity = ImageSelectionthreeDActivity.this;
                    imageSelectionActivity.currentCount++;
                    ImageSelectionthreeDActivity.this.textView1.setText(ImageSelectionthreeDActivity.this.getResources().getString(R.string.done));
                } else {
                    imageSelectionActivity = ImageSelectionthreeDActivity.this;
                    imageSelectionActivity.currentCount++;
                    ImageSelectionthreeDActivity.this.textView1.setText(ImageSelectionthreeDActivity.this.currentCount + "/" + ImageSelectionthreeDActivity.this.totalCount);
                }
                ImageSelectionthreeDActivity.this.selectedImageList.add(((Image) ImageSelectionthreeDActivity.this.imageArrayList.get(position)).path);
                if (ImageSelectionthreeDActivity.this.selectedImageList.size() == 1) {
                    ImageSelectionthreeDActivity.this.selectedImageAdapter = new SelectedImageAdapter(ImageSelectionthreeDActivity.this.activity, ImageSelectionthreeDActivity.this.selectedImageList);
                    ImageSelectionthreeDActivity.this.recyclerView.setAdapter(ImageSelectionthreeDActivity.this.selectedImageAdapter);
                    return;
                }
                ImageSelectionthreeDActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
    }

    private void bindControls() {
        this.totalCount = Integer.parseInt(getIntent().getExtras().getString(Const.imgId));
        this.imgId = getIntent().getExtras().getString(Const.imgId);
        this.imgSource = getIntent().getExtras().getString(Const.imgSource);
        this.currentGrid = getIntent().getExtras().getInt(Const.currentGrid);
        this.textView1 = (TextView) findViewById(R.id.txtTotalImg);
        this.gridView = (GridView) findViewById(R.id.gridView);
        this.listView = (ListView) findViewById(R.id.imglistView);
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.linearLayoutManager = new LinearLayoutManager(this, 0, false);
        this.recyclerView.setLayoutManager(this.linearLayoutManager);
        this.textView1.setText(this.currentCount + "/" + this.totalCount);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                if (this.textView.getText().equals(getResources().getString(R.string.ImageSelectionActivity_Title))) {
                    finish();
                    overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                }
                this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
                this.listView.setVisibility(View.VISIBLE);
                return true;
            default:
                return false;
        }
    }

    public void onBackPressed() {
        if (this.textView.getText().equals(getResources().getString(R.string.ImageSelectionActivity_Title))) {
            finish();
            overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
            super.onBackPressed();
            return;
        }
        this.textView.setText(getResources().getString(R.string.ImageSelectionActivity_Title));
        this.listView.setVisibility(View.VISIBLE);
    }

}