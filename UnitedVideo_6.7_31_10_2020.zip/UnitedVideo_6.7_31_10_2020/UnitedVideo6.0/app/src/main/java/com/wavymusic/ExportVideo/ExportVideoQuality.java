package com.wavymusic.ExportVideo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wavymusic.Preferance.LanguagePref;
import com.wavymusic.R;
import androidx.appcompat.app.AppCompatActivity;

public class ExportVideoQuality extends AppCompatActivity {

    Activity activity = ExportVideoQuality.this;
    ImageView ivback;
    RadioButton rbHigh;
    RadioButton rbMedium;
    RadioButton rbLow;
    RadioButton rbUltra;
    String VideoQuality;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export_video_quality);
        VideoQuality = LanguagePref.a(this).a("pref_key_export_quality", "High");
        PutAnalyticsEvent();
        BindView();
        SetListener();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExportVideoQuality");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        rbHigh = findViewById(R.id.rbHigh);
        rbMedium = findViewById(R.id.rbMedium);
        rbUltra = findViewById(R.id.rbUltra);
        rbLow = findViewById(R.id.rbLow);
        if (VideoQuality.equalsIgnoreCase("High")) {
            rbHigh.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Medium")) {
            rbMedium.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Low")) {
            rbLow.setChecked(true);
        }
    }

    private void SetListener() {
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        rbHigh.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "High");
                    onBackPressed();
                }
            }
        });
        rbMedium.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Medium");
                    onBackPressed();
                }
            }
        });
        rbLow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Low");
                    onBackPressed();
                }
            }
        });
        rbUltra.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Ultra");
                    onBackPressed();
                }
            }
        });

    }

    public void onBackPressed() {
        finish();
    }
}
