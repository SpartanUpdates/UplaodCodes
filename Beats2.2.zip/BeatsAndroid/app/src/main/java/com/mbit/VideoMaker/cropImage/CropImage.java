package com.mbit.VideoMaker.cropImage;

public class CropImage {
    public String a;
    public String b;

    public String a() {
        return this.b;
    }

    public void a(String str) {
        this.b = str;
    }

    public String b() {
        return this.a;
    }

    public void b(String str) {
        this.a = str;
    }

}
