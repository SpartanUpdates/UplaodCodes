package com.kotlinz.festivalstorymaker.Model.CollageMaker.Element;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class ElementResponse {

	@SerializedName("data")
	private ArrayList<ElementMainResponse> data;

	@SerializedName("status")
	private String status;

	public ArrayList<ElementMainResponse> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}