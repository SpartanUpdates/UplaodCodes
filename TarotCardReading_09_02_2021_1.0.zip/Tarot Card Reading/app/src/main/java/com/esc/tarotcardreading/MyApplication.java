package com.esc.tarotcardreading;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.util.Log;
import androidx.multidex.MultiDex;
import java.util.Locale;

public class MyApplication extends Application {

    public void onCreate() {
        updateLanguage(getApplicationContext());
        super.onCreate();
    }

    public static void updateLanguage(Context context) {
        String string;
        SharedPreferences sharedPreferences = context.getApplicationContext().getSharedPreferences("MyPref", 0);
        Editor edit = sharedPreferences.edit();
        String str = "      s = ";
        String str2 = "AAAAAAAAAAAAAAAAAAAAAAA";
        String str3 = "en";
        String str4 = "languagetoload";
        StringBuilder stringBuilder;
        if (Locale.getDefault().getLanguage().contains("hi") || Locale.getDefault().getLanguage().contains("nb") || Locale.getDefault().getLanguage().contains("sv") || Locale.getDefault().getLanguage().contains("es") || Locale.getDefault().getLanguage().contains("de") || Locale.getDefault().getLanguage().contains("it") || Locale.getDefault().getLanguage().contains("ms") || Locale.getDefault().getLanguage().contains("ru") || Locale.getDefault().getLanguage().contains("nl") || Locale.getDefault().getLanguage().contains("fi") || Locale.getDefault().getLanguage().contains("el") || Locale.getDefault().getLanguage().contains("in") || Locale.getDefault().getLanguage().contains("vi") || Locale.getDefault().getLanguage().contains("tl") || Locale.getDefault().getLanguage().contains("fr") || Locale.getDefault().getLanguage().contains("pt") || Locale.getDefault().getLanguage().contains("tr") || Locale.getDefault().getLanguage().contains("zh") || Locale.getDefault().getLanguage().contains("ko") || Locale.getDefault().getLanguage().contains("da") || Locale.getDefault().getLanguage().contains("pl") || Locale.getDefault().getLanguage().contains("ja") || Locale.getDefault().getLanguage().contains("th")) {
            String str5 = "languagetoloadoncedone";
            if (!sharedPreferences.getBoolean(str5, false)) {
                edit.putString(str4, Locale.getDefault().getLanguage());
                edit.apply();
                edit.putBoolean(str5, true);
                edit.apply();
            }
            string = sharedPreferences.getString(str4, Locale.getDefault().getLanguage());
            stringBuilder = new StringBuilder();
            stringBuilder.append("if  ");
            stringBuilder.append(Locale.getDefault().getLanguage());
            stringBuilder.append(str);
            stringBuilder.append(sharedPreferences.getString(str4, str3));
            Log.e(str2, stringBuilder.toString());
        } else {
            string = sharedPreferences.getString(str4, str3);
            stringBuilder = new StringBuilder();
            stringBuilder.append("else  ");
            stringBuilder.append(Locale.getDefault().getLanguage());
            stringBuilder.append(str);
            stringBuilder.append(sharedPreferences.getString(str4, str3));
            Log.e(str2, stringBuilder.toString());
        }
        updateLanguage(context, string);
    }

    public static void updateLanguage(Context context, String str) {
        Locale locale = new Locale(str);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        if (VERSION.SDK_INT >= 24) {
            configuration.setLocale(locale);
        } else {
            configuration.locale = locale;
        }
        if (VERSION.SDK_INT >= 17) {
            context.createConfigurationContext(configuration);
        } else {
            context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        updateLanguage(getApplicationContext());
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }
}
