package com.kotlinz.videoCollage;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.LogCallback;
import com.arthenica.mobileffmpeg.LogMessage;
import com.kotlinz.videoCollage.cmd.ThemeFiveAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeFiveAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeFiveTop2HorizontalBottom3HorizontalAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeFourAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeFourAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeFourBottomHorizontalAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeFourFour;
import com.kotlinz.videoCollage.cmd.ThemeFourLeftVerticalAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeFourRightVerticalAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeFourTopHorizontalAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeThreeAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeThreeAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeThreeBottomHorizontalAllVertical;
import com.kotlinz.videoCollage.cmd.ThemeThreeLeftVerticalAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeThreeRightVerticalAllHorizontal;
import com.kotlinz.videoCollage.cmd.ThemeThreeTopHorizontalAllVertical;
import com.kotlinz.videoCollage.flying.puzzle.PuzzlePiece;
import com.kotlinz.videoCollage.flying.puzzle.PuzzleView;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.views.TextureVideoView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProcessVideo extends AsyncTask<Void, Void, Integer> {
    private String allImagePath;
    private int baseViewHeight;
    private int baseViewPadding;
    private int baseViewWidth;
    private String bgPath;
    private List<String> bitmapPaint;
    int cnt;
    private Context context;
    private boolean inOrder;
    private int last;
    private int length;
    private String musicPath;
    private double percentage;
    private ProgressDialog progressDialog;
    private PuzzleView puzzleView;
    String screenBase;
    private String stickerPath;
    private int themeId;
    private String timeRe;
    private int totalDuration;
    private float totalSecond;
    private String videoName;
    private List<View> viewPieces;

    public ProcessVideo(final Context context, final List<String> bitmapPaint, final List<View> viewPieces, final PuzzleView puzzleView, final int baseViewWidth, final int baseViewHeight, final int baseViewPadding, final int totalDuration, final String stickerPath, final String musicPath, final String bgPath, final String allImagePath, final boolean inOrder, final int themeId) {
        this.videoName = "";
        this.last = 0;
        this.timeRe = "\\btime=\\b\\d\\d:\\d\\d:\\d\\d.\\d\\d";
        this.percentage = 0.0;
        this.screenBase = "1080";
        this.cnt = 0;
        this.context = context;
        this.bitmapPaint = bitmapPaint;
        this.viewPieces = viewPieces;
        this.puzzleView = puzzleView;
        this.baseViewWidth = baseViewWidth;
        this.baseViewHeight = baseViewHeight;
        this.baseViewPadding = baseViewPadding;
        this.totalDuration = totalDuration;
        this.stickerPath = stickerPath;
        this.musicPath = musicPath;
        this.bgPath = bgPath;
        this.allImagePath = allImagePath;
        this.inOrder = inOrder;
        this.themeId = themeId;
        this.length = bitmapPaint.size();
        final StringBuilder sb = new StringBuilder();
        sb.append(" baseViewWidth :: ");
        sb.append(baseViewWidth);
        Log.e("save", sb.toString());
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(" baseViewHeight :: ");
        sb2.append(baseViewHeight);
        Log.e("save", sb2.toString());
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(" baseViewPadding :: ");
        sb3.append(baseViewPadding);
        Log.e("save", sb3.toString());
        final StringBuilder sb4 = new StringBuilder();
        sb4.append(" totalDuration :: ");
        sb4.append(totalDuration);
        Log.e("save", sb4.toString());
        final StringBuilder sb5 = new StringBuilder();
        sb5.append(" stickerPath :: ");
        sb5.append(stickerPath);
        Log.e("save", sb5.toString());
        final StringBuilder sb6 = new StringBuilder();
        sb6.append(" musicPath :: ");
        sb6.append(musicPath);
        Log.e("save", sb6.toString());
        final StringBuilder sb7 = new StringBuilder();
        sb7.append(" bgColor :: ");
        sb7.append(bgPath);
        Log.e("save", sb7.toString());
        final StringBuilder sb8 = new StringBuilder();
        sb8.append(" allImagePath :: ");
        sb8.append(allImagePath);
        Log.e("save", sb8.toString());
        final StringBuilder sb9 = new StringBuilder();
        sb9.append(" length :: ");
        sb9.append(this.length);
        Log.e("save", sb9.toString());
        final StringBuilder sb10 = new StringBuilder();
        sb10.append(" inOrder :: ");
        sb10.append(inOrder);
        Log.e("save", sb10.toString());
        final StringBuilder sb11 = new StringBuilder();
        sb11.append(" themeId :: ");
        sb11.append(themeId);
        Log.e("save", sb11.toString());
        Config.enableLogCallback(new LogCallback() {
            @Override
            public void apply(final LogMessage logMessage) {
                Log.e("mobile-ffmpeg", logMessage.getText());
                durationToProgress(logMessage.getText());
            }
        });
    }

    private void durationToProgress(String group) {
        final Matcher matcher = Pattern.compile(this.timeRe).matcher(group);
        if (!TextUtils.isEmpty((CharSequence) group)) {
            if (group.contains("time=")) {
                int last = 0;
                while (matcher.find()) {
                    group = matcher.group();
                    final String[] split = group.substring(group.lastIndexOf(61) + 1).split(":");
                    final float n = Float.valueOf(split[0]) * 3600 + Float.valueOf(split[1]) * 60 + Float.valueOf(split[2]);
                    last = (int) (100.0f * n / (this.totalSecond / 1000.0f));
                    this.updateInMillisecond(n);
                }
                this.last = last;
            }
        }
    }

    private String[] five(final ArrayList<String> list, final StringBuilder sb, String s, final String s2, final String s3, final String s4, String s5, final StringBuilder sb2, int n, final StringBuilder sb3, int i) {
        ArrayList<String> list2 = list;
        final ArrayList<Integer> list3 = new ArrayList<Integer>();
        final ArrayList<Integer> list4 = new ArrayList<Integer>();
        list2.add("-y");
        int n2 = n;
        n = 0;
        int n3 = 0;
        int n4 = 0;
        int n5;
        while (true) {
            n5 = i;
            if (n >= this.length) {
                break;
            }
            final PuzzlePiece puzzlePiece = this.puzzleView.getPuzzlePieces().get(n);
            final float matrixAngle = puzzlePiece.getMatrixAngle();
            final StringBuilder sb4 = new StringBuilder();
            final ArrayList<Integer> list5 = list3;
            sb4.append(" befor rotateAngle :: ");
            sb4.append(matrixAngle);
            final double n6 = matrixAngle;
            float n7;
            if (n6 == 90.0) {
                n7 = 90.0f;
            } else if (n6 != -180.0 && n6 != 180.0) {
                if (n6 == -90.0) {
                    n7 = 270.0f;
                } else {
                    n7 = 0.0f;
                }
            } else {
                n7 = 180.0f;
            }
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("  after rAngle :: ");
            sb5.append(n7);
            final int width = puzzlePiece.getWidth();
            final int height = puzzlePiece.getHeight();
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(" ");
            sb6.append(n);
            sb6.append(" pieceWidth :: ");
            sb6.append(width);
            final StringBuilder sb7 = new StringBuilder();
            sb7.append(" ");
            sb7.append(n);
            sb7.append(" pieceHeight :: ");
            sb7.append(height);
            final StringBuilder sb8 = new StringBuilder();
            sb8.append(" ");
            sb8.append(n);
            sb8.append(" (int)(puzzleView.getPiecePadding() :: ");
            sb8.append((int) this.puzzleView.getPiecePadding());
            final int n8 = (int) puzzlePiece.getArea().left();
            final int n9 = (int) puzzlePiece.getArea().top();
            final int n10 = (int) puzzlePiece.getArea().right() - n8;
            final int n11 = (int) puzzlePiece.getArea().bottom() - n9;
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(" ");
            sb9.append(n);
            sb9.append("-areaX       original  --- :: ");
            sb9.append((int) puzzlePiece.getArea().left());
            sb9.append("   --> custom :: ");
            sb9.append(n8);
            Log.e("save", sb9.toString());
            final StringBuilder sb10 = new StringBuilder();
            sb10.append(" ");
            sb10.append(n);
            sb10.append("-areaY       original  --- :: ");
            sb10.append((int) puzzlePiece.getArea().top());
            sb10.append("    --> custom :: ");
            sb10.append(n9);
            Log.e("save", sb10.toString());
            final StringBuilder sb11 = new StringBuilder();
            sb11.append(" ");
            sb11.append(n);
            sb11.append("-areaWidth   original  --- :: ");
            sb11.append((int) puzzlePiece.getArea().right());
            sb11.append("  --> custom :: ");
            sb11.append(n10);
            Log.e("save", sb11.toString());
            final StringBuilder sb12 = new StringBuilder();
            sb12.append(" ");
            sb12.append(n);
            sb12.append("-areaHeight  original  --- :: ");
            sb12.append((int) puzzlePiece.getArea().bottom());
            sb12.append(" --> custom :: ");
            sb12.append(n11);
            final float[] array = new float[9];
            final double n12 = n7;
            final double n13 = 0;
            float n14;
            float n15;
            float n16;
            float n17;
            if (n13 != 0) {
                final StringBuilder sb13 = new StringBuilder();
                sb13.append(" ");
                sb13.append(n);
                sb13.append("- if rAngle != 0.0  --- :: ");
                sb13.append(n7);
                puzzlePiece.getMatrix().postRotate(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            } else {
                final StringBuilder sb14 = new StringBuilder();
                sb14.append(" ");
                sb14.append(n);
                sb14.append("- else rAngle == 0.0  --- :: ");
                sb14.append(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            }
            final float n18 = n17 * height;
            final StringBuilder sb15 = new StringBuilder();
            sb15.append("globalx :: ");
            sb15.append(n14);
            final StringBuilder sb16 = new StringBuilder();
            sb16.append("globaly :: ");
            sb16.append(n15);
            final StringBuilder sb17 = new StringBuilder();
            sb17.append("width :: ");
            sb17.append(n16);
            final StringBuilder sb18 = new StringBuilder();
            sb18.append("height :: ");
            sb18.append(n18);
            final int n19 = (int) Math.abs(n16);
            final int n20 = (int) Math.abs(n18);
            final StringBuilder sb19 = new StringBuilder();
            sb19.append(" ");
            sb19.append(n);
            sb19.append("-currentItemWidth  --- :: ");
            sb19.append(n19);
            final StringBuilder sb20 = new StringBuilder();
            sb20.append(" ");
            sb20.append(n);
            sb20.append("-currentItemHeight   --- :: ");
            sb20.append(n20);
            int n25 = 0;
            int n30 = 0;
            int n31 = 0;
            String s6 = null;
            int n32 = 0;
            Label_2172:
            {
                int n26 = 0;
                int n28 = 0;
                Label_1933:
                {
                    if (n13 != 0) {
                        int n22;
                        if (n12 == 90.0) {
                            final StringBuilder sb21 = new StringBuilder();
                            sb21.append(" ");
                            sb21.append(n);
                            sb21.append("- else if rAngle == 90.0  --- :: ");
                            float n23;
                            if (n == 0) {
                                float n21;
                                if (n14 > 0.0f) {
                                    n21 = Math.abs(Math.abs(n14) + Math.abs(n8));
                                } else {
                                    n21 = Math.abs(Math.abs(n14) - Math.abs(n8));
                                }
                                n22 = (int) n21;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n9));
                            } else {
                                float n24;
                                if (n14 > 0.0f) {
                                    n24 = Math.abs(Math.abs(n14) + Math.abs(n9));
                                } else {
                                    n24 = Math.abs(Math.abs(n14) - Math.abs(n9));
                                }
                                n22 = (int) n24;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n8));
                            }
                            n25 = (int) n23;
                            s = "transpose=1";
                        } else {
                            if (n12 == 180.0) {
                                final StringBuilder sb22 = new StringBuilder();
                                sb22.append(" ");
                                sb22.append(n);
                                sb22.append("- else if rAngle == 180.0  --- :: ");
                                float n27;
                                if (n == 0) {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n8));
                                } else {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n9));
                                }
                                n28 = (int) n27;
                                s = "transpose=2,transpose=2";
                                break Label_1933;
                            }
                            final StringBuilder sb23 = new StringBuilder();
                            sb23.append(" ");
                            sb23.append(n);
                            sb23.append("- else rAngle == 270.0  --- :: ");
                            float n29;
                            if (n == 0) {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n11)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n9));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n9));
                                }
                            } else {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n8));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n8));
                                }
                            }
                            n25 = (int) n29;
                            s = "transpose=2";
                        }
                        n30 = n10;
                        n31 = n11;
                        s6 = s;
                        n32 = n22;
                        break Label_2172;
                    }
                    final StringBuilder sb24 = new StringBuilder();
                    sb24.append(" ");
                    sb24.append(n);
                    sb24.append("- if rAngle == 0.0  --- :: ");
                    float n34;
                    if (n == 0) {
                        float n33;
                        if (n14 > 0.0f) {
                            n33 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n33 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n33;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    } else {
                        float n35;
                        if (n14 > 0.0f) {
                            n35 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n35 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n35;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    }
                    n28 = (int) n34;
                    s = "transpose=2,transpose=2,transpose=2,transpose=2";
                }
                n31 = n10;
                n30 = n11;
                n32 = n26;
                n25 = n28;
                s6 = s;
            }
            final StringBuilder sb25 = new StringBuilder();
            sb25.append(" ");
            sb25.append(n);
            sb25.append("-cropWidth   original  --- :: ");
            sb25.append(n31);
            final StringBuilder sb26 = new StringBuilder();
            sb26.append(" ");
            sb26.append(n);
            sb26.append("-cropHeight  original  --- :: ");
            sb26.append(n30);
            final StringBuilder sb27 = new StringBuilder();
            sb27.append(" ");
            sb27.append(n);
            sb27.append(" cropX :: ");
            sb27.append(n32);
            final StringBuilder sb28 = new StringBuilder();
            sb28.append(" ");
            sb28.append(n);
            sb28.append(" cropY :: ");
            sb28.append(n25);
            final int n36 = n10 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            final int n37 = n11 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            String s8;
            String s7;
            int n38;
            if (Util.isImageFile(this.bitmapPaint.get(n))) {
                s = this.saveTransparentImage();
                list.add("-i");
                list.add(s);
                final StringBuilder sb29 = new StringBuilder();
                sb29.append("[");
                sb29.append(n4);
                sb29.append(":v] scale=");
                sb29.append(n19);
                sb29.append("x");
                sb29.append(n20);
                sb29.append(", crop=w= 'if(gte(");
                sb29.append(n31);
                sb29.append(",");
                sb29.append(n19);
                sb29.append("),");
                sb29.append(n19);
                sb29.append(",");
                sb29.append(n31);
                sb29.append(")':h='if(gte(");
                sb29.append(n30);
                sb29.append(",");
                sb29.append(n20);
                sb29.append("),");
                sb29.append(n20);
                sb29.append(",");
                sb29.append(n30);
                sb29.append(")':x=");
                sb29.append(n32);
                sb29.append(":y=");
                sb29.append(n25);
                sb29.append(", ");
                sb29.append(s6);
                sb29.append(", pad=width=");
                sb29.append(n36);
                sb29.append(":height=");
                sb29.append(n37);
                sb29.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb29.append(n4);
                sb29.append("];");
                s = sb29.toString();
                list4.add(n4);
                s7 = (s8 = "");
                n38 = n4;
            } else {
                list.add("-i");
                list.add(this.bitmapPaint.get(n));
                final StringBuilder sb30 = new StringBuilder();
                sb30.append("[");
                sb30.append(n4);
                sb30.append(":v] scale=");
                sb30.append(n19);
                sb30.append("x");
                sb30.append(n20);
                sb30.append(", crop=w= 'if(gte(");
                sb30.append(n31);
                sb30.append(",");
                sb30.append(n19);
                sb30.append("),");
                sb30.append(n19);
                sb30.append(",");
                sb30.append(n31);
                sb30.append(")':h='if(gte(");
                sb30.append(n30);
                sb30.append(",");
                sb30.append(n20);
                sb30.append("),");
                sb30.append(n20);
                sb30.append(",");
                sb30.append(n30);
                sb30.append(")':x=");
                sb30.append(n32);
                sb30.append(":y=");
                sb30.append(n25);
                sb30.append(", ");
                sb30.append(s6);
                sb30.append(", pad=width=");
                sb30.append(n36);
                sb30.append(":height=");
                sb30.append(n37);
                sb30.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb30.append(n4);
                sb30.append("];");
                final String string = sb30.toString();
                TextureVideoView textureVideoView = null;
                final int n39 = n;
                if (this.viewPieces.get(n39) instanceof RelativeLayout) {
                    final View child = ((RelativeLayout) this.viewPieces.get(n39)).getChildAt(0);
                    if (child instanceof TextureVideoView) {
                        textureVideoView = (TextureVideoView) child;
                    }
                }
                final StringBuilder sb31 = new StringBuilder();
                sb31.append("view.isMute() :: ");
                sb31.append(textureVideoView.isMute());
                if (textureVideoView.isMute()) {
                    final StringBuilder sb32 = new StringBuilder();
                    sb32.append("[");
                    sb32.append(n4);
                    sb32.append(":a]volume=0.0[sound");
                    sb32.append(n4);
                    sb32.append("];");
                    s = sb32.toString();
                } else {
                    final StringBuilder sb33 = new StringBuilder();
                    sb33.append("[");
                    sb33.append(n4);
                    sb33.append(":a]volume=1.0[sound");
                    sb33.append(n4);
                    sb33.append("];");
                    s = sb33.toString();
                }
                list4.add(n4);
                list5.add(n4);
                String string2;
                if (!this.inOrder) {
                    final StringBuilder sb34 = new StringBuilder();
                    sb34.append("pos1 :: ");
                    sb34.append(n4);
                    ++n4;
                    final String saveVideoThumb = this.saveVideoThumb(this.bitmapPaint.get(n39));
                    list.add("-i");
                    list.add(saveVideoThumb);
                    final StringBuilder sb35 = new StringBuilder();
                    sb35.append("[");
                    sb35.append(n4);
                    sb35.append(":v] scale=");
                    sb35.append(n19);
                    sb35.append("x");
                    sb35.append(n20);
                    sb35.append(", crop=w= 'if(gte(");
                    sb35.append(n31);
                    sb35.append(",");
                    sb35.append(n19);
                    sb35.append("),");
                    sb35.append(n19);
                    sb35.append(",");
                    sb35.append(n31);
                    sb35.append(")':h='if(gte(");
                    sb35.append(n30);
                    sb35.append(",");
                    sb35.append(n20);
                    sb35.append("),");
                    sb35.append(n20);
                    sb35.append(",");
                    sb35.append(n30);
                    sb35.append(")':x=");
                    sb35.append(n32);
                    sb35.append(":y=");
                    sb35.append(n25);
                    sb35.append(", ");
                    sb35.append(s6);
                    sb35.append(", pad=width=");
                    sb35.append(n36);
                    sb35.append(":height=");
                    sb35.append(n37);
                    sb35.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                    sb35.append(n4);
                    sb35.append("];");
                    string2 = sb35.toString();
                    final StringBuilder sb36 = new StringBuilder();
                    sb36.append("pos 2:: ");
                    sb36.append(n4);
                } else {
                    string2 = "";
                }
                final String s9 = s;
                s = string;
                n38 = n4;
                s8 = string2;
                s7 = s9;
            }
            final int n40 = n;
            final int n41 = i;
            n = n36;
            int n42 = 0;
            Label_3904:
            {
                Label_3900:
                {
                    if (n41 != 0) {
                        if (n41 != 1) {
                            if (n41 != 2) {
                                if (n41 == 3) {
                                    if (n40 != 0) {
                                        if (n40 != 1) {
                                            break Label_3900;
                                        }
                                    }
                                } else if ((n41 != 4) ? ((n41 != 5) ? ((n41 != 6 && n41 != 7) || n40 != 0) : (n40 != 1)) : (n40 != 3)) {
                                    break Label_3900;
                                }
                                n42 = n;
                                break Label_3904;
                            }
                            if (n40 == 0 || n40 == 1) {
                                n42 = n3 + n;
                                break Label_3904;
                            }
                        }
                    }
                }
                n42 = n3;
            }
            final StringBuilder sb37 = new StringBuilder();
            sb37.append("11111 wid:: ");
            sb37.append(n42);
            Log.e("wid1111", sb37.toString());
            final StringBuilder sb38 = new StringBuilder();
            sb38.append("22222 wid:: ");
            sb38.append(n42);
            final int n43 = n38 + 1;
            final StringBuilder sb39 = new StringBuilder();
            sb39.append("pos 3:: ");
            sb39.append(n43);
            sb2.append(s7);
            sb.append(s);
            sb.append(s8);
            n = n40 + 1;
            list2 = list;
            n2 = n43;
            n3 = n42;
            n4 = n43;
        }
        final String s10 = "[";
        final String s11 = "-i";
        final StringBuilder sb40 = new StringBuilder();
        sb40.append("j is :: ");
        sb40.append(n2);
        list2.add(s11);
        list2.add(this.bgPath);
        final StringBuilder sb41 = new StringBuilder();
        sb41.append(s3);
        sb41.append(s10);
        sb41.append(n2);
        sb41.append(":v] scale=");
        sb41.append(this.baseViewWidth);
        sb41.append("x");
        sb41.append(this.baseViewHeight);
        sb41.append(" [base];");
        final String string3 = sb41.toString();
        n = n2 + 1;
        list2.add(s11);
        list2.add(this.allImagePath);
        final StringBuilder sb42 = new StringBuilder();
        sb42.append(s10);
        sb42.append(n);
        sb42.append(":v] scale=");
        sb42.append(this.puzzleView.getWidth());
        sb42.append("x");
        sb42.append(this.puzzleView.getHeight());
        sb42.append(" [allImage];");
        final String string4 = sb42.toString();
        ++n;
        final StringBuilder sb43 = new StringBuilder();
        StringBuilder sb44;
        for (i = 0; i < list3.size(); ++i) {
            sb44 = new StringBuilder();
            sb44.append("[sound");
            sb44.append(list3.get(i));
            sb44.append("]");
            sb43.append(sb44.toString());
        }
        if (!this.musicPath.equals("")) {
            if (!this.inOrder) {
                final StringBuilder sb45 = new StringBuilder();
                sb2.append((CharSequence) sb43);
                sb45.append((Object) sb2);
                sb45.append("concat=n=");
                sb45.append(list3.size());
                sb45.append(":v=0:a=1[a1]; amovie=");
                sb45.append(this.musicPath);
                sb45.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb45.toString();
            } else {
                final StringBuilder sb46 = new StringBuilder();
                sb46.append(s5);
                sb46.append((Object) sb2);
                sb46.append((Object) sb43);
                sb46.append("amix=inputs=");
                sb46.append(list3.size());
                sb46.append("[a1]; amovie=");
                sb46.append(this.musicPath);
                sb46.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb46.toString();
            }
        } else if (!this.inOrder) {
            final StringBuilder sb47 = new StringBuilder();
            sb2.append((CharSequence) sb43);
            sb47.append((Object) sb2);
            sb47.append("concat=n=");
            sb47.append(list3.size());
            sb47.append(":v=0:a=1[a];");
            s = sb47.toString();
        } else {
            final StringBuilder sb48 = new StringBuilder();
            sb2.append((CharSequence) sb43);
            sb48.append((Object) sb2);
            sb48.append("amix=inputs=");
            sb48.append(list3.size());
            sb48.append("[a];");
            s = sb48.toString();
        }
        final StringBuilder sb49 = new StringBuilder();
        i = 0;
        s5 = s11;
        while (i < list4.size()) {
            final StringBuilder sb50 = new StringBuilder();
            sb50.append("[scale");
            sb50.append(list4.get(i));
            sb50.append("]");
            sb49.append(sb50.toString());
            ++i;
        }
        Object o = null;
        if (n5 == 0) {
            o = ThemeFiveAllVertical.getOrderString(this.inOrder, list4, list3);
        } else if (n5 == 1) {
            o = ThemeFiveAllHorizontal.getOrderString(this.inOrder, list4, list3);
        } else if (n5 == 2) {
            o = ThemeFiveTop2HorizontalBottom3HorizontalAllVertical.getOrderString(this.inOrder, list4, list3, n3);
        } else if (n5 != 3) {
            if (n5 != 4) {
                if (n5 == 5) {
                }
            }
        }
        final StringBuilder sb51 = new StringBuilder();
        sb51.append((Object) sb);
        sb51.append(string3);
        sb51.append(string4);
        sb51.append(s);
        sb51.append(o);
        sb51.append(" [vidCombine] pad=width=");
        sb51.append(this.baseViewWidth);
        sb51.append(":height=");
        sb51.append(this.baseViewHeight);
        sb51.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000 [viewPadding]; [viewPadding][allImage] overlay=x=");
        sb51.append(this.baseViewPadding);
        sb51.append(":y=");
        sb51.append(this.baseViewPadding);
        sb51.append(" [allView]; [base][allView] overlay=x=0:y=0");
        s = sb51.toString();
        String string5;
        if (!this.stickerPath.equals("")) {
            list2.add(s5);
            list2.add(this.stickerPath);
            final StringBuilder sb52 = new StringBuilder();
            sb52.append(s10);
            sb52.append((Object) sb3);
            sb52.append("];[");
            sb52.append((Object) sb3);
            sb52.append("][");
            sb52.append(n);
            sb52.append(":v] overlay=x=0:y=0");
            string5 = sb52.toString();
        } else {
            string5 = s2;
        }
        list2.add("-filter_complex");
        final StringBuilder sb53 = new StringBuilder();
        sb53.append("");
        sb53.append(s);
        sb53.append(string5);
        list2.add(sb53.toString());
        list2.add("-map");
        list2.add("0:v");
        list2.add("-map");
        list2.add("[a]");
        list2.add("-b:v");
        list2.add("1M");
        list2.add("-ss");
        list2.add("00:00:00");
        list2.add("-t");
        final StringBuilder sb54 = new StringBuilder();
        sb54.append("");
        sb54.append(this.convertSecondsToHMmSs(this.totalDuration));
        list2.add(sb54.toString());
        final StringBuilder sb55 = new StringBuilder();
        sb55.append("");
        sb55.append(this.videoName);
        list2.add(sb55.toString());
        final StringBuilder sb56 = new StringBuilder();
        sb56.append("1 vertical upperArr :: ");
        sb56.append(list.toString());
        final StringBuilder sb57 = new StringBuilder();
        sb57.append("1 vertical upperArr :: ");
        sb57.append(list.toString());
        return list2.toArray(new String[list.size()]);
    }

    private String[] four(final ArrayList<String> list, final StringBuilder sb, String s, final String s2, String s3, final String s4, String s5, final StringBuilder sb2, int i, final StringBuilder sb3, int j) {
        ProcessVideo processVideo = this;
        ArrayList<String> list2 = list;
        int n = j;
        final ArrayList<Integer> list3 = new ArrayList<Integer>();
        final ArrayList<Integer> list4 = new ArrayList<Integer>();
        list2.add("-y");
        int n2 = i;
        i = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        while (i < processVideo.length) {
            final PuzzlePiece puzzlePiece = processVideo.puzzleView.getPuzzlePieces().get(i);
            final float matrixAngle = puzzlePiece.getMatrixAngle();
            final StringBuilder sb4 = new StringBuilder();
            final ArrayList<Integer> list5 = list3;
            sb4.append(" befor rotateAngle :: ");
            sb4.append(matrixAngle);
            Log.e("save1", sb4.toString());
            final double n6 = matrixAngle;
            float n7;
            if (n6 == 90.0) {
                n7 = 90.0f;
            } else if (n6 != -180.0 && n6 != 180.0) {
                if (n6 == -90.0) {
                    n7 = 270.0f;
                } else {
                    n7 = 0.0f;
                }
            } else {
                n7 = 180.0f;
            }
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("  after rAngle :: ");
            sb5.append(n7);
            final int width = puzzlePiece.getWidth();
            final int height = puzzlePiece.getHeight();
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(" ");
            sb6.append(i);
            sb6.append(" pieceWidth :: ");
            sb6.append(width);
            final StringBuilder sb7 = new StringBuilder();
            sb7.append(" ");
            sb7.append(i);
            sb7.append(" pieceHeight :: ");
            sb7.append(height);
            final StringBuilder sb8 = new StringBuilder();
            sb8.append(" ");
            sb8.append(i);
            sb8.append(" (int)(puzzleView.getPiecePadding() :: ");
            sb8.append((int) processVideo.puzzleView.getPiecePadding());
            Log.e("save", sb8.toString());
            final int n8 = (int) puzzlePiece.getArea().left();
            final int n9 = (int) puzzlePiece.getArea().top();
            final int n10 = (int) puzzlePiece.getArea().right() - n8;
            final int n11 = (int) puzzlePiece.getArea().bottom() - n9;
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(" ");
            sb9.append(i);
            sb9.append("-areaX       original  --- :: ");
            sb9.append((int) puzzlePiece.getArea().left());
            sb9.append("   --> custom :: ");
            sb9.append(n8);
            final StringBuilder sb10 = new StringBuilder();
            sb10.append(" ");
            sb10.append(i);
            sb10.append("-areaY       original  --- :: ");
            sb10.append((int) puzzlePiece.getArea().top());
            sb10.append("    --> custom :: ");
            sb10.append(n9);
            final StringBuilder sb11 = new StringBuilder();
            sb11.append(" ");
            sb11.append(i);
            sb11.append("-areaWidth   original  --- :: ");
            sb11.append((int) puzzlePiece.getArea().right());
            sb11.append("  --> custom :: ");
            sb11.append(n10);
            final StringBuilder sb12 = new StringBuilder();
            sb12.append(" ");
            sb12.append(i);
            sb12.append("-areaHeight  original  --- :: ");
            sb12.append((int) puzzlePiece.getArea().bottom());
            sb12.append(" --> custom :: ");
            sb12.append(n11);
            final float[] array = new float[9];
            final double n12 = n7;
            final double n13 = 0;
            float n14;
            float n15;
            float n16;
            float n17;
            if (n13 != 0) {
                final StringBuilder sb13 = new StringBuilder();
                sb13.append(" ");
                sb13.append(i);
                sb13.append("- if rAngle != 0.0  --- :: ");
                sb13.append(n7);
                puzzlePiece.getMatrix().postRotate(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            } else {
                final StringBuilder sb14 = new StringBuilder();
                sb14.append(" ");
                sb14.append(i);
                sb14.append("- else rAngle == 0.0  --- :: ");
                sb14.append(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            }
            final float n18 = n17 * height;
            final StringBuilder sb15 = new StringBuilder();
            sb15.append("globalx :: ");
            sb15.append(n14);
            final StringBuilder sb16 = new StringBuilder();
            sb16.append("globaly :: ");
            sb16.append(n15);
            final StringBuilder sb17 = new StringBuilder();
            sb17.append("width :: ");
            sb17.append(n16);
            final StringBuilder sb18 = new StringBuilder();
            sb18.append("height :: ");
            sb18.append(n18);
            Log.e("save", sb18.toString());
            final int n19 = (int) Math.abs(n16);
            final int n20 = (int) Math.abs(n18);
            final StringBuilder sb19 = new StringBuilder();
            sb19.append(" ");
            sb19.append(i);
            sb19.append("-currentItemWidth  --- :: ");
            sb19.append(n19);
            final StringBuilder sb20 = new StringBuilder();
            sb20.append(" ");
            sb20.append(i);
            sb20.append("-currentItemHeight   --- :: ");
            sb20.append(n20);
            int n25 = 0;
            int n30 = 0;
            int n31 = 0;
            String s6 = null;
            int n32 = 0;
            Label_2179:
            {
                int n26 = 0;
                int n28 = 0;
                Label_1940:
                {
                    if (n13 != 0) {
                        int n22;
                        if (n12 == 90.0) {
                            final StringBuilder sb21 = new StringBuilder();
                            sb21.append(" ");
                            sb21.append(i);
                            sb21.append("- else if rAngle == 90.0  --- :: ");
                            float n23;
                            if (i == 0) {
                                float n21;
                                if (n14 > 0.0f) {
                                    n21 = Math.abs(Math.abs(n14) + Math.abs(n8));
                                } else {
                                    n21 = Math.abs(Math.abs(n14) - Math.abs(n8));
                                }
                                n22 = (int) n21;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n9));
                            } else {
                                float n24;
                                if (n14 > 0.0f) {
                                    n24 = Math.abs(Math.abs(n14) + Math.abs(n9));
                                } else {
                                    n24 = Math.abs(Math.abs(n14) - Math.abs(n9));
                                }
                                n22 = (int) n24;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n8));
                            }
                            n25 = (int) n23;
                            s = "transpose=1";
                        } else {
                            if (n12 == 180.0) {
                                final StringBuilder sb22 = new StringBuilder();
                                sb22.append(" ");
                                sb22.append(i);
                                sb22.append("- else if rAngle == 180.0  --- :: ");
                                float n27;
                                if (i == 0) {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n8));
                                } else {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n9));
                                }
                                n28 = (int) n27;
                                s = "transpose=2,transpose=2";
                                break Label_1940;
                            }
                            final StringBuilder sb23 = new StringBuilder();
                            sb23.append(" ");
                            sb23.append(i);
                            sb23.append("- else rAngle == 270.0  --- :: ");
                            float n29;
                            if (i == 0) {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n11)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n9));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n9));
                                }
                            } else {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n8));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n8));
                                }
                            }
                            n25 = (int) n29;
                            s = "transpose=2";
                        }
                        n30 = n10;
                        n31 = n11;
                        s6 = s;
                        n32 = n22;
                        break Label_2179;
                    }
                    final StringBuilder sb24 = new StringBuilder();
                    sb24.append(" ");
                    sb24.append(i);
                    sb24.append("- if rAngle == 0.0  --- :: ");
                    float n34;
                    if (i == 0) {
                        float n33;
                        if (n14 > 0.0f) {
                            n33 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n33 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n33;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    } else {
                        float n35;
                        if (n14 > 0.0f) {
                            n35 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n35 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n35;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    }
                    n28 = (int) n34;
                    s = "transpose=2,transpose=2,transpose=2,transpose=2";
                }
                n31 = n10;
                n30 = n11;
                n32 = n26;
                n25 = n28;
                s6 = s;
            }
            final StringBuilder sb25 = new StringBuilder();
            sb25.append(" ");
            sb25.append(i);
            sb25.append("-cropWidth   original  --- :: ");
            sb25.append(n31);
            final StringBuilder sb26 = new StringBuilder();
            sb26.append(" ");
            sb26.append(i);
            sb26.append("-cropHeight  original  --- :: ");
            sb26.append(n30);
            final StringBuilder sb27 = new StringBuilder();
            sb27.append(" ");
            sb27.append(i);
            sb27.append(" cropX :: ");
            sb27.append(n32);
            Log.e("save", sb27.toString());
            final StringBuilder sb28 = new StringBuilder();
            sb28.append(" ");
            sb28.append(i);
            sb28.append(" cropY :: ");
            sb28.append(n25);
            final int n36 = n10 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            final int n37 = n11 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            String string;
            int n38;
            String s7;
            int n39;
            if (Util.isImageFile(this.bitmapPaint.get(i))) {
                s = this.saveTransparentImage();
                list.add("-i");
                list.add(s);
                final StringBuilder sb29 = new StringBuilder();
                sb29.append("[");
                sb29.append(n4);
                sb29.append(":v] scale=");
                sb29.append(n19);
                sb29.append("x");
                sb29.append(n20);
                sb29.append(", crop=w='if(gte(");
                sb29.append(n31);
                sb29.append(",");
                sb29.append(n19);
                sb29.append("),");
                sb29.append(n19);
                sb29.append(",");
                sb29.append(n31);
                sb29.append(")':h='if(gte(");
                sb29.append(n30);
                sb29.append(",");
                sb29.append(n20);
                sb29.append("),");
                sb29.append(n20);
                sb29.append(",");
                sb29.append(n30);
                sb29.append(")':x=");
                sb29.append(n32);
                sb29.append(":y=");
                sb29.append(n25);
                sb29.append(", ");
                sb29.append(s6);
                sb29.append(", pad=width=");
                sb29.append(n36);
                sb29.append(":height=");
                sb29.append(n37);
                sb29.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb29.append(n4);
                sb29.append("];");
                string = sb29.toString();
                list4.add(n4);
                n38 = n4;
                s7 = (s = "");
                n39 = n36;
            } else {
                list.add("-i");
                list.add(this.bitmapPaint.get(i));
                final StringBuilder sb30 = new StringBuilder();
                sb30.append("[");
                sb30.append(n4);
                sb30.append(":v] scale=");
                sb30.append(n19);
                sb30.append("x");
                sb30.append(n20);
                sb30.append(", crop=w='if(gte(");
                sb30.append(n31);
                sb30.append(",");
                sb30.append(n19);
                sb30.append("),");
                sb30.append(n19);
                sb30.append(",");
                sb30.append(n31);
                sb30.append(")':h='if(gte(");
                sb30.append(n30);
                sb30.append(",");
                sb30.append(n20);
                sb30.append("),");
                sb30.append(n20);
                sb30.append(",");
                sb30.append(n30);
                sb30.append(")':x=");
                sb30.append(n32);
                sb30.append(":y=");
                sb30.append(n25);
                sb30.append(", ");
                sb30.append(s6);
                sb30.append(", pad=width=");
                sb30.append(n36);
                sb30.append(":height=");
                sb30.append(n37);
                sb30.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb30.append(n4);
                sb30.append("];");
                final String string2 = sb30.toString();
                TextureVideoView textureVideoView = null;
                final int n40 = i;
                if (this.viewPieces.get(n40) instanceof RelativeLayout) {
                    final View child = ((RelativeLayout) this.viewPieces.get(n40)).getChildAt(0);
                    if (child instanceof TextureVideoView) {
                        textureVideoView = (TextureVideoView) child;
                    }
                }
                final StringBuilder sb31 = new StringBuilder();
                sb31.append("view.isMute() :: ");
                sb31.append(textureVideoView.isMute());
                Log.e("save", sb31.toString());
                if (textureVideoView.isMute()) {
                    final StringBuilder sb32 = new StringBuilder();
                    sb32.append("[");
                    sb32.append(n4);
                    sb32.append(":a]volume=0.0[sound");
                    sb32.append(n4);
                    sb32.append("];");
                    s = sb32.toString();
                } else {
                    final StringBuilder sb33 = new StringBuilder();
                    sb33.append("[");
                    sb33.append(n4);
                    sb33.append(":a]volume=1.0[sound");
                    sb33.append(n4);
                    sb33.append("];");
                    s = sb33.toString();
                }
                list4.add(n4);
                list5.add(n4);
                String string3;
                if (!this.inOrder) {
                    final StringBuilder sb34 = new StringBuilder();
                    sb34.append("pos1 :: ");
                    sb34.append(n4);
                    ++n4;
                    final String saveVideoThumb = this.saveVideoThumb(this.bitmapPaint.get(n40));
                    list.add("-i");
                    list.add(saveVideoThumb);
                    final StringBuilder sb35 = new StringBuilder();
                    sb35.append("[");
                    sb35.append(n4);
                    sb35.append(":v] scale=");
                    sb35.append(n19);
                    sb35.append("x");
                    sb35.append(n20);
                    sb35.append(", crop=w='if(gte(");
                    sb35.append(n31);
                    sb35.append(",");
                    sb35.append(n19);
                    sb35.append("),");
                    sb35.append(n19);
                    sb35.append(",");
                    sb35.append(n31);
                    sb35.append(")':h='if(gte(");
                    sb35.append(n30);
                    sb35.append(",");
                    sb35.append(n20);
                    sb35.append("),");
                    sb35.append(n20);
                    sb35.append(",");
                    sb35.append(n30);
                    sb35.append(")':x=");
                    sb35.append(n32);
                    sb35.append(":y=");
                    sb35.append(n25);
                    sb35.append(", ");
                    sb35.append(s6);
                    sb35.append(", pad=width=");
                    sb35.append(n36);
                    sb35.append(":height=");
                    sb35.append(n37);
                    sb35.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                    sb35.append(n4);
                    sb35.append("];");
                    string3 = sb35.toString();
                    final StringBuilder sb36 = new StringBuilder();
                    sb36.append("pos 2:: ");
                    sb36.append(n4);
                } else {
                    string3 = "";
                }
                n38 = n4;
                n39 = n36;
                s7 = string3;
                string = string2;
            }
            final int n41 = i;
            n = j;
            Label_3886:
            {
                Label_3882:
                {
                    if (n != 0 && n != 1) {
                        if (n != 2) {
                            if (n == 3) {
                                if (n41 != 3) {
                                    break Label_3882;
                                }
                            } else if (n == 4) {
                                if (n41 != 0) {
                                    break Label_3882;
                                }
                            } else if (n == 5) {
                                if (n41 != 1) {
                                    break Label_3882;
                                }
                            } else if ((n != 6 && n != 7) || n41 != 0) {
                                break Label_3882;
                            }
                            n5 = n37;
                            i = n39;
                            break Label_3886;
                        }
                    }
                }
                i = n3;
            }
            n4 = 1 + n38;
            final StringBuilder sb37 = new StringBuilder();
            sb37.append("pos 3:: ");
            sb37.append(n4);
            sb2.append(s);
            sb.append(string);
            sb.append(s7);
            n3 = i;
            processVideo = this;
            i = n41 + 1;
            list2 = list;
            n2 = n4;
        }
        final String s8 = "save";
        final String s9 = "-i";
        s = "[";
        final StringBuilder sb38 = new StringBuilder();
        sb38.append("j is :: ");
        sb38.append(n2);
        Log.e(s8, sb38.toString());
        list2.add(s9);
        list2.add(processVideo.bgPath);
        final StringBuilder sb39 = new StringBuilder();
        sb39.append(s3);
        sb39.append(s);
        sb39.append(n2);
        sb39.append(":v] scale=");
        sb39.append(processVideo.baseViewWidth);
        sb39.append("x");
        sb39.append(processVideo.baseViewHeight);
        sb39.append(" [base];");
        final String string4 = sb39.toString();
        i = n2 + 1;
        list2.add(s9);
        list2.add(processVideo.allImagePath);
        final StringBuilder sb40 = new StringBuilder();
        sb40.append(s);
        sb40.append(i);
        sb40.append(":v] scale=");
        sb40.append(processVideo.puzzleView.getWidth());
        sb40.append("x");
        sb40.append(processVideo.puzzleView.getHeight());
        sb40.append(" [allImage];");
        final String string5 = sb40.toString();
        ++i;
        final StringBuilder sb41 = new StringBuilder();
        StringBuilder sb42;
        for (j = 0; j < list3.size(); ++j) {
            sb42 = new StringBuilder();
            sb42.append("[sound");
            sb42.append(list3.get(j));
            sb42.append("]");
            sb41.append(sb42.toString());
        }
        if (!processVideo.musicPath.equals("")) {
            if (!processVideo.inOrder) {
                final StringBuilder sb43 = new StringBuilder();
                sb2.append((CharSequence) sb41);
                sb43.append((Object) sb2);
                sb43.append("concat=n=");
                sb43.append(list3.size());
                sb43.append(":v=0:a=1[a1]; amovie=");
                sb43.append(processVideo.musicPath);
                sb43.append(":loop=0[extra]; [a1][extra]amix[a];");
                s3 = sb43.toString();
            } else {
                final StringBuilder sb44 = new StringBuilder();
                sb44.append(s5);
                sb44.append((Object) sb2);
                sb44.append((Object) sb41);
                sb44.append("amix=inputs=");
                sb44.append(list3.size());
                sb44.append("[a1]; amovie=");
                sb44.append(processVideo.musicPath);
                sb44.append(":loop=0[extra]; [a1][extra]amix[a];");
                s3 = sb44.toString();
            }
        } else if (!processVideo.inOrder) {
            final StringBuilder sb45 = new StringBuilder();
            sb2.append((CharSequence) sb41);
            sb45.append((Object) sb2);
            sb45.append("concat=n=");
            sb45.append(list3.size());
            sb45.append(":v=0:a=1[a];");
            s3 = sb45.toString();
        } else {
            final StringBuilder sb46 = new StringBuilder();
            sb2.append((CharSequence) sb41);
            sb46.append((Object) sb2);
            sb46.append("amix=inputs=");
            sb46.append(list3.size());
            sb46.append("[a];");
            s3 = sb46.toString();
        }
        final StringBuilder sb47 = new StringBuilder();
        j = 0;
        s5 = s;
        while (j < list4.size()) {
            final StringBuilder sb48 = new StringBuilder();
            sb48.append("[scale");
            sb48.append(list4.get(j));
            sb48.append("]");
            sb47.append(sb48.toString());
            ++j;
        }
        Object o = null;
        if (n == 0) {
            o = ThemeFourAllVertical.getOrderString(processVideo.inOrder, list4, list3);
        } else if (n == 1) {
            o = ThemeFourAllHorizontal.getOrderString(processVideo.inOrder, list4, list3);
        } else if (n == 2) {
            o = ThemeFourFour.getOrderString(processVideo.inOrder, list4, list3);
        } else if (n == 3) {
            o = ThemeFourTopHorizontalAllVertical.getOrderString(processVideo.inOrder, list4, list3, n3);
        } else if (n == 4) {
            o = ThemeFourBottomHorizontalAllVertical.getOrderString(processVideo.inOrder, list4, list3, n3);
        } else if (n == 5) {
            o = ThemeFourLeftVerticalAllHorizontal.getOrderString(processVideo.inOrder, list4, list3, n5);
        } else if (n == 6 || n == 7) {
            o = ThemeFourRightVerticalAllHorizontal.getOrderString(processVideo.inOrder, list4, list3, n5);
        }
        final StringBuilder sb49 = new StringBuilder();
        sb49.append((Object) sb);
        sb49.append(string4);
        sb49.append(string5);
        sb49.append(s3);
        sb49.append(o);
        sb49.append(" [vidCombine] pad=width=");
        sb49.append(processVideo.baseViewWidth);
        sb49.append(":height=");
        sb49.append(processVideo.baseViewHeight);
        sb49.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000 [viewPadding]; [viewPadding][allImage] overlay=x=");
        sb49.append(processVideo.baseViewPadding);
        sb49.append(":y=");
        sb49.append(processVideo.baseViewPadding);
        sb49.append(" [allView]; [base][allView] overlay=x=0:y=0");
        s = sb49.toString();
        String string6;
        if (!processVideo.stickerPath.equals("")) {
            list2.add(s9);
            list2.add(processVideo.stickerPath);
            final StringBuilder sb50 = new StringBuilder();
            sb50.append(s5);
            sb50.append((Object) sb3);
            sb50.append("];[");
            sb50.append((Object) sb3);
            sb50.append("][");
            sb50.append(i);
            sb50.append(":v] overlay=x=0:y=0");
            string6 = sb50.toString();
        } else {
            string6 = s2;
        }
        list2.add("-filter_complex");
        final StringBuilder sb51 = new StringBuilder();
        sb51.append("");
        sb51.append(s);
        sb51.append(string6);
        list2.add(sb51.toString());
        list2.add("-map");
        list2.add("0:v");
        list2.add("-map");
        list2.add("[a]");
        list2.add("-b:v");
        list2.add("1M");
        list2.add("-ss");
        list2.add("00:00:00");
        list2.add("-t");
        final StringBuilder sb52 = new StringBuilder();
        sb52.append("");
        sb52.append(processVideo.convertSecondsToHMmSs(processVideo.totalDuration));
        list2.add(sb52.toString());
        final StringBuilder sb53 = new StringBuilder();
        sb53.append("");
        sb53.append(processVideo.videoName);
        list2.add(sb53.toString());
        final StringBuilder sb54 = new StringBuilder();
        sb54.append("1 vertical upperArr :: ");
        sb54.append(list.toString());
        final StringBuilder sb55 = new StringBuilder();
        sb55.append("1 vertical upperArr :: ");
        sb55.append(list.toString());
        return list2.toArray(new String[list.size()]);
    }

    private String[] three(final ArrayList<String> list, final StringBuilder sb, String s, final String s2, String s3, final String s4, String s5, final StringBuilder sb2, int i, final StringBuilder sb3, int j) {
        ProcessVideo processVideo = this;
        ArrayList<String> list2 = list;
        int n = j;
        final ArrayList<Integer> list3 = new ArrayList<Integer>();
        final ArrayList<Integer> list4 = new ArrayList<Integer>();
        list2.add("-y");
        int n2 = i;
        i = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        while (i < processVideo.length) {
            final PuzzlePiece puzzlePiece = processVideo.puzzleView.getPuzzlePieces().get(i);
            final float matrixAngle = puzzlePiece.getMatrixAngle();
            final StringBuilder sb4 = new StringBuilder();
            final ArrayList<Integer> list5 = list3;
            sb4.append(" befor rotateAngle :: ");
            sb4.append(matrixAngle);
            Log.e("save1", sb4.toString());
            final double n6 = matrixAngle;
            float n7;
            if (n6 == 90.0) {
                n7 = 90.0f;
            } else if (n6 != -180.0 && n6 != 180.0) {
                if (n6 == -90.0) {
                    n7 = 270.0f;
                } else {
                    n7 = 0.0f;
                }
            } else {
                n7 = 180.0f;
            }
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("  after rAngle :: ");
            sb5.append(n7);
            final int width = puzzlePiece.getWidth();
            final int height = puzzlePiece.getHeight();
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(" ");
            sb6.append(i);
            sb6.append(" pieceWidth :: ");
            sb6.append(width);
            final StringBuilder sb7 = new StringBuilder();
            sb7.append(" ");
            sb7.append(i);
            sb7.append(" pieceHeight :: ");
            sb7.append(height);
            final int n8 = (int) puzzlePiece.getArea().left();
            final int n9 = (int) puzzlePiece.getArea().top();
            final int n10 = (int) puzzlePiece.getArea().right() - n8;
            final int n11 = (int) puzzlePiece.getArea().bottom() - n9;
            final StringBuilder sb8 = new StringBuilder();
            sb8.append(" ");
            sb8.append(i);
            sb8.append("-areaX       original  --- :: ");
            sb8.append((int) puzzlePiece.getArea().left());
            sb8.append("   --> custom :: ");
            sb8.append(n8);
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(" ");
            sb9.append(i);
            sb9.append("-areaY       original  --- :: ");
            sb9.append((int) puzzlePiece.getArea().top());
            sb9.append("    --> custom :: ");
            sb9.append(n9);
            final StringBuilder sb10 = new StringBuilder();
            sb10.append(" ");
            sb10.append(i);
            sb10.append("-areaWidth   original  --- :: ");
            sb10.append((int) puzzlePiece.getArea().right());
            sb10.append("  --> custom :: ");
            sb10.append(n10);
            final StringBuilder sb11 = new StringBuilder();
            sb11.append(" ");
            sb11.append(i);
            sb11.append("-areaHeight  original  --- :: ");
            sb11.append((int) puzzlePiece.getArea().bottom());
            sb11.append(" --> custom :: ");
            sb11.append(n11);
            final float[] array = new float[9];
            final double n12 = n7;
            final double n13 = 0;
            float n14;
            float n15;
            float n16;
            float n17;
            if (n13 != 0) {
                final StringBuilder sb12 = new StringBuilder();
                sb12.append(" ");
                sb12.append(i);
                sb12.append("- if rAngle != -0.0  --- :: ");
                sb12.append(n7);
                puzzlePiece.getMatrix().postRotate(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            } else {
                final StringBuilder sb13 = new StringBuilder();
                sb13.append(" ");
                sb13.append(i);
                sb13.append("- else rAngle == -0.0  --- :: ");
                sb13.append(n7);
                puzzlePiece.getMatrix().getValues(array);
                n14 = array[2];
                n15 = array[5];
                n16 = array[0] * width;
                n17 = array[4];
            }
            final float n18 = n17 * height;
            final StringBuilder sb14 = new StringBuilder();
            sb14.append("globalx :: ");
            sb14.append(n14);
            final StringBuilder sb15 = new StringBuilder();
            sb15.append("globaly :: ");
            sb15.append(n15);
            final StringBuilder sb16 = new StringBuilder();
            sb16.append("width :: ");
            sb16.append(n16);
            final StringBuilder sb17 = new StringBuilder();
            sb17.append("height :: ");
            sb17.append(n18);
            Log.e("save", sb17.toString());
            final int n19 = (int) Math.abs(n16);
            final int n20 = (int) Math.abs(n18);
            final StringBuilder sb18 = new StringBuilder();
            sb18.append(" ");
            sb18.append(i);
            sb18.append("-currentItemWidth  --- :: ");
            sb18.append(n19);
            final StringBuilder sb19 = new StringBuilder();
            sb19.append(" ");
            sb19.append(i);
            sb19.append("-currentItemHeight   --- :: ");
            sb19.append(n20);
            int n25 = 0;
            int n30 = 0;
            int n31 = 0;
            String s6 = null;
            int n32 = 0;
            Label_2118:
            {
                int n26 = 0;
                int n28 = 0;
                Label_1879:
                {
                    if (n13 != 0) {
                        int n22;
                        if (n12 == 90.0) {
                            final StringBuilder sb20 = new StringBuilder();
                            sb20.append(" ");
                            sb20.append(i);
                            sb20.append("- else if rAngle == 90.0  --- :: ");
                            float n23;
                            if (i == 0) {
                                float n21;
                                if (n14 > 0.0f) {
                                    n21 = Math.abs(Math.abs(n14) + Math.abs(n8));
                                } else {
                                    n21 = Math.abs(Math.abs(n14) - Math.abs(n8));
                                }
                                n22 = (int) n21;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n9));
                            } else {
                                float n24;
                                if (n14 > 0.0f) {
                                    n24 = Math.abs(Math.abs(n14) + Math.abs(n9));
                                } else {
                                    n24 = Math.abs(Math.abs(n14) - Math.abs(n9));
                                }
                                n22 = (int) n24;
                                n23 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n10)) - Math.abs(n8));
                            }
                            n25 = (int) n23;
                            s = "transpose=1";
                        } else {
                            if (n12 == 180.0) {
                                final StringBuilder sb21 = new StringBuilder();
                                sb21.append(" ");
                                sb21.append(i);
                                sb21.append("- else if rAngle == 180.0  --- :: ");
                                float n27;
                                if (i == 0) {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n8));
                                } else {
                                    n26 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                    n27 = Math.abs(Math.abs(Math.abs(n15) - Math.abs(n11)) - Math.abs(n9));
                                }
                                n28 = (int) n27;
                                s = "transpose=2,transpose=2";
                                break Label_1879;
                            }
                            final StringBuilder sb22 = new StringBuilder();
                            sb22.append(" ");
                            sb22.append(i);
                            sb22.append("- else rAngle == 270.0  --- :: ");
                            float n29;
                            if (i == 0) {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n11)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n9));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n9));
                                }
                            } else {
                                n22 = (int) Math.abs(Math.abs(Math.abs(n14) - Math.abs(n10)) - Math.abs(n8));
                                if (n15 > 0.0f) {
                                    n29 = Math.abs(Math.abs(n15) + Math.abs(n8));
                                } else {
                                    n29 = Math.abs(Math.abs(n15) - Math.abs(n8));
                                }
                            }
                            n25 = (int) n29;
                            s = "transpose=2";
                        }
                        n30 = n10;
                        n31 = n11;
                        s6 = s;
                        n32 = n22;
                        break Label_2118;
                    }
                    final StringBuilder sb23 = new StringBuilder();
                    sb23.append(" ");
                    sb23.append(i);
                    sb23.append("- if rAngle == 0.0  --- :: ");
                    float n34;
                    if (i == 0) {
                        float n33;
                        if (n14 > 0.0f) {
                            n33 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n33 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n33;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    } else {
                        float n35;
                        if (n14 > 0.0f) {
                            n35 = Math.abs(Math.abs(n14) - Math.abs(n8));
                        } else {
                            n35 = Math.abs(Math.abs(n14) + Math.abs(n8));
                        }
                        n26 = (int) n35;
                        if (n15 > 0.0f) {
                            n34 = Math.abs(Math.abs(n15) - Math.abs(n9));
                        } else {
                            n34 = Math.abs(Math.abs(n15) + Math.abs(n9));
                        }
                    }
                    n28 = (int) n34;
                    s = "transpose=2,transpose=2,transpose=2,transpose=2";
                }
                n31 = n10;
                n30 = n11;
                n32 = n26;
                n25 = n28;
                s6 = s;
            }
            final StringBuilder sb24 = new StringBuilder();
            sb24.append(" ");
            sb24.append(i);
            sb24.append("-cropWidth   original  --- :: ");
            sb24.append(n31);
            final StringBuilder sb25 = new StringBuilder();
            sb25.append(" ");
            sb25.append(i);
            sb25.append("-cropHeight  original  --- :: ");
            sb25.append(n30);
            final StringBuilder sb26 = new StringBuilder();
            sb26.append(" ");
            sb26.append(i);
            sb26.append(" cropX :: ");
            sb26.append(n32);
            Log.e("save", sb26.toString());
            final StringBuilder sb27 = new StringBuilder();
            sb27.append(" ");
            sb27.append(i);
            sb27.append(" cropY :: ");
            sb27.append(n25);
            final int n36 = n10 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            final int n37 = n11 + (int) (this.puzzleView.getPiecePadding() * 2.0f);
            String string;
            String s7;
            if (Util.isImageFile(this.bitmapPaint.get(i))) {
                s = this.saveTransparentImage();
                list.add("-i");
                list.add(s);
                final StringBuilder sb28 = new StringBuilder();
                sb28.append("[");
                sb28.append(n4);
                sb28.append(":v] scale=");
                sb28.append(n19);
                sb28.append("x");
                sb28.append(n20);
                sb28.append(", crop=w='if(gte(");
                sb28.append(n31);
                sb28.append(",");
                sb28.append(n19);
                sb28.append("),");
                sb28.append(n19);
                sb28.append(",");
                sb28.append(n31);
                sb28.append(")':h='if(gte(");
                sb28.append(n30);
                sb28.append(",");
                sb28.append(n20);
                sb28.append("),");
                sb28.append(n20);
                sb28.append(",");
                sb28.append(n30);
                sb28.append(")':x=");
                sb28.append(n32);
                sb28.append(":y=");
                sb28.append(n25);
                sb28.append(", ");
                sb28.append(s6);
                sb28.append(", pad=width=");
                sb28.append(n36);
                sb28.append(":height=");
                sb28.append(n37);
                sb28.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb28.append(n4);
                sb28.append("];");
                string = sb28.toString();
                list4.add(n4);
                s7 = (s = "");
            } else {
                list.add("-i");
                list.add(this.bitmapPaint.get(i));
                final StringBuilder sb29 = new StringBuilder();
                sb29.append("[");
                sb29.append(n4);
                sb29.append(":v] scale=");
                sb29.append(n19);
                sb29.append("x");
                sb29.append(n20);
                sb29.append(", crop=w='if(gte(");
                sb29.append(n31);
                sb29.append(",");
                sb29.append(n19);
                sb29.append("),");
                sb29.append(n19);
                sb29.append(",");
                sb29.append(n31);
                sb29.append(")':h='if(gte(");
                sb29.append(n30);
                sb29.append(",");
                sb29.append(n20);
                sb29.append("),");
                sb29.append(n20);
                sb29.append(",");
                sb29.append(n30);
                sb29.append(")':x=");
                sb29.append(n32);
                sb29.append(":y=");
                sb29.append(n25);
                sb29.append(", ");
                sb29.append(s6);
                sb29.append(", pad=width=");
                sb29.append(n36);
                sb29.append(":height=");
                sb29.append(n37);
                sb29.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb29.append(n4);
                sb29.append("];");
                final String string2 = sb29.toString();
                TextureVideoView textureVideoView = null;
                final int n38 = i;
                if (this.viewPieces.get(n38) instanceof RelativeLayout) {
                    final View child = ((RelativeLayout) this.viewPieces.get(n38)).getChildAt(0);
                    if (child instanceof TextureVideoView) {
                        textureVideoView = (TextureVideoView) child;
                    }
                }
                final StringBuilder sb30 = new StringBuilder();
                sb30.append("view.isMute() :: ");
                sb30.append(textureVideoView.isMute());
                if (textureVideoView.isMute()) {
                    final StringBuilder sb31 = new StringBuilder();
                    sb31.append("[");
                    sb31.append(n4);
                    sb31.append(":a]volume=0.0[sound");
                    sb31.append(n4);
                    sb31.append("];");
                    s = sb31.toString();
                } else {
                    final StringBuilder sb32 = new StringBuilder();
                    sb32.append("[");
                    sb32.append(n4);
                    sb32.append(":a]volume=1.0[sound");
                    sb32.append(n4);
                    sb32.append("];");
                    s = sb32.toString();
                }
                list4.add(n4);
                list5.add(n4);
                String string3;
                if (!this.inOrder) {
                    final StringBuilder sb33 = new StringBuilder();
                    sb33.append("pos1 :: ");
                    sb33.append(n4);
                    ++n4;
                    final String saveVideoThumb = this.saveVideoThumb(this.bitmapPaint.get(n38));
                    list.add("-i");
                    list.add(saveVideoThumb);
                    final StringBuilder sb34 = new StringBuilder();
                    sb34.append("[");
                    sb34.append(n4);
                    sb34.append(":v] scale=");
                    sb34.append(n19);
                    sb34.append("x");
                    sb34.append(n20);
                    sb34.append(", crop=w='if(gte(");
                    sb34.append(n31);
                    sb34.append(",");
                    sb34.append(n19);
                    sb34.append("),");
                    sb34.append(n19);
                    sb34.append(",");
                    sb34.append(n31);
                    sb34.append(")':h='if(gte(");
                    sb34.append(n30);
                    sb34.append(",");
                    sb34.append(n20);
                    sb34.append("),");
                    sb34.append(n20);
                    sb34.append(",");
                    sb34.append(n30);
                    sb34.append(")':x=");
                    sb34.append(n32);
                    sb34.append(":y=");
                    sb34.append(n25);
                    sb34.append(", ");
                    sb34.append(s6);
                    sb34.append(", pad=width=");
                    sb34.append(n36);
                    sb34.append(":height=");
                    sb34.append(n37);
                    sb34.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                    sb34.append(n4);
                    sb34.append("];");
                    string3 = sb34.toString();
                    final StringBuilder sb35 = new StringBuilder();
                    sb35.append("pos 2:: ");
                    sb35.append(n4);
                } else {
                    string3 = "";
                }
                s7 = string3;
                string = string2;
            }
            final int n39 = i;
            i = j;
            Label_3791:
            {
                if (i != 0) {
                    if (i != 1) {
                        if (i == 2) {
                            if (n39 != 2) {
                                break Label_3791;
                            }
                        } else if (i == 3) {
                            if (n39 != 0) {
                                break Label_3791;
                            }
                        } else if (i == 4) {
                            if (n39 != 1) {
                                break Label_3791;
                            }
                        } else if (i != 5 || n39 != 0) {
                            break Label_3791;
                        }
                        n3 = n36;
                        n5 = n37;
                    }
                }
            }
            ++n4;
            final StringBuilder sb36 = new StringBuilder();
            sb36.append("pos 3:: ");
            sb36.append(n4);
            sb2.append(s);
            sb.append(string);
            sb.append(s7);
            final int n40 = n39 + 1;
            processVideo = this;
            list2 = list;
            n2 = n4;
            n = i;
            i = n40;
        }
        final String s8 = "-i";
        s = "[";
        final String s9 = "save";
        final StringBuilder sb37 = new StringBuilder();
        sb37.append("j is :: ");
        sb37.append(n2);
        Log.e(s9, sb37.toString());
        list2.add(s8);
        list2.add(processVideo.bgPath);
        final StringBuilder sb38 = new StringBuilder();
        sb38.append(s3);
        sb38.append(s);
        sb38.append(n2);
        sb38.append(":v] scale=");
        sb38.append(processVideo.baseViewWidth);
        sb38.append("x");
        sb38.append(processVideo.baseViewHeight);
        sb38.append(" [base];");
        final String string4 = sb38.toString();
        i = n2 + 1;
        list2.add(s8);
        list2.add(processVideo.allImagePath);
        final StringBuilder sb39 = new StringBuilder();
        sb39.append(s);
        sb39.append(i);
        sb39.append(":v] scale=");
        sb39.append(processVideo.puzzleView.getWidth());
        sb39.append("x");
        sb39.append(processVideo.puzzleView.getHeight());
        sb39.append(" [allImage];");
        final String string5 = sb39.toString();
        ++i;
        final StringBuilder sb40 = new StringBuilder();
        StringBuilder sb41;
        for (j = 0; j < list3.size(); ++j) {
            sb41 = new StringBuilder();
            sb41.append("[sound");
            sb41.append(list3.get(j));
            sb41.append("]");
            sb40.append(sb41.toString());
        }
        if (!processVideo.musicPath.equals("")) {
            if (!processVideo.inOrder) {
                final StringBuilder sb42 = new StringBuilder();
                sb2.append((CharSequence) sb40);
                sb42.append((Object) sb2);
                sb42.append("concat=n=");
                sb42.append(list3.size());
                sb42.append(":v=0:a=1[a1]; amovie=");
                sb42.append(processVideo.musicPath);
                sb42.append(":loop=0[extra]; [a1][extra]amix[a];");
                s3 = sb42.toString();
            } else {
                final StringBuilder sb43 = new StringBuilder();
                sb43.append(s5);
                sb43.append((Object) sb2);
                sb43.append((Object) sb40);
                sb43.append("amix=inputs=");
                sb43.append(list3.size());
                sb43.append("[a1]; amovie=");
                sb43.append(processVideo.musicPath);
                sb43.append(":loop=0[extra]; [a1][extra]amix[a];");
                s3 = sb43.toString();
            }
        } else if (!processVideo.inOrder) {
            final StringBuilder sb44 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb44.append((Object) sb2);
            sb44.append("concat=n=");
            sb44.append(list3.size());
            sb44.append(":v=0:a=1[a];");
            s3 = sb44.toString();
        } else {
            final StringBuilder sb45 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb45.append((Object) sb2);
            sb45.append("amix=inputs=");
            sb45.append(list3.size());
            sb45.append("[a];");
            s3 = sb45.toString();
        }
        final StringBuilder sb46 = new StringBuilder();
        j = 0;
        s5 = s;
        while (j < list4.size()) {
            final StringBuilder sb47 = new StringBuilder();
            sb47.append("[scale");
            sb47.append(list4.get(j));
            sb47.append("]");
            sb46.append(sb47.toString());
            ++j;
        }
        Object o = null;
        if (n == 0) {
            o = ThemeThreeAllVertical.getOrderString(processVideo.inOrder, list4, list3);
        } else if (n == 1) {
            o = ThemeThreeAllHorizontal.getOrderString(processVideo.inOrder, list4, list3);
        } else if (n == 2) {
            o = ThemeThreeTopHorizontalAllVertical.getOrderString(processVideo.inOrder, list4, list3, n3);
        } else if (n == 3) {
            o = ThemeThreeBottomHorizontalAllVertical.getOrderString(processVideo.inOrder, list4, list3, n3);
        } else if (n == 4) {
            o = ThemeThreeLeftVerticalAllHorizontal.getOrderString(processVideo.inOrder, list4, list3, n5);
        } else if (n == 5) {
            o = ThemeThreeRightVerticalAllHorizontal.getOrderString(processVideo.inOrder, list4, list3, n5);
        }
        final StringBuilder sb48 = new StringBuilder();
        sb48.append((Object) sb);
        sb48.append(string4);
        sb48.append(string5);
        sb48.append(s3);
        sb48.append(o);
        sb48.append(" [vidCombine] pad=width=");
        sb48.append(processVideo.baseViewWidth);
        sb48.append(":height=");
        sb48.append(processVideo.baseViewHeight);
        sb48.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000 [viewPadding]; [viewPadding][allImage] overlay=x=");
        sb48.append(processVideo.baseViewPadding);
        sb48.append(":y=");
        sb48.append(processVideo.baseViewPadding);
        sb48.append(" [allView]; [base][allView] overlay=x=0:y=0");
        s = sb48.toString();
        String string6;
        if (!processVideo.stickerPath.equals("")) {
            list2.add(s8);
            list2.add(processVideo.stickerPath);
            final StringBuilder sb49 = new StringBuilder();
            sb49.append(s5);
            sb49.append((Object) sb3);
            sb49.append("];[");
            sb49.append((Object) sb3);
            sb49.append("][");
            sb49.append(i);
            sb49.append(":v] overlay=x=0:y=0");
            string6 = sb49.toString();
        } else {
            string6 = s2;
        }
        list2.add("-filter_complex");
        final StringBuilder sb50 = new StringBuilder();
        sb50.append("");
        sb50.append(s);
        sb50.append(string6);
        list2.add(sb50.toString());
        list2.add("-map");
        list2.add("0:v");
        list2.add("-map");
        list2.add("[a]");
        list2.add("-c:v");
        list2.add("mpeg4");
        list2.add("-b:v");
        list2.add("1M");
        list2.add("-ss");
        list2.add("00:00:00");
        list2.add("-t");
        final StringBuilder sb51 = new StringBuilder();
        sb51.append("");
        sb51.append(processVideo.convertSecondsToHMmSs(processVideo.totalDuration));
        list2.add(sb51.toString());
        final StringBuilder sb52 = new StringBuilder();
        sb52.append("");
        sb52.append(processVideo.videoName);
        list2.add(sb52.toString());
        final StringBuilder sb53 = new StringBuilder();
        sb53.append("1 vertical upperArr :: ");
        sb53.append(list.toString());
        final StringBuilder sb54 = new StringBuilder();
        sb54.append("1 vertical upperArr :: ");
        sb54.append(list.toString());
        return list2.toArray(new String[list.size()]);
    }

    private String[] twoXTwoHorizontal(final ArrayList<String> list, final StringBuilder sb, String s, final String s2, String s3, String s4, final String s5, final StringBuilder sb2, int i, final StringBuilder sb3) {
        ArrayList<String> list2 = list;
        final ArrayList<Integer> list3 = new ArrayList<Integer>();
        final ArrayList<Integer> list4 = new ArrayList<Integer>();
        list2.add("-y");
        int n = i;
        int n2 = 0;
        i = 0;
        String s6;
        while (true) {
            final int length = this.length;
            s6 = "save";
            if (n2 >= length) {
                break;
            }
            final PuzzlePiece puzzlePiece = this.puzzleView.getPuzzlePieces().get(n2);
            final float matrixAngle = puzzlePiece.getMatrixAngle();
            final StringBuilder sb4 = new StringBuilder();
            final ArrayList<Integer> list5 = list3;
            sb4.append(" befor rotateAngle :: ");
            sb4.append(matrixAngle);
            final double n3 = matrixAngle;
            float n4;
            if (n3 == 90.0) {
                n4 = 90.0f;
            } else if (n3 != -180.0 && n3 != 180.0) {
                if (n3 == -90.0) {
                    n4 = 270.0f;
                } else {
                    n4 = 0.0f;
                }
            } else {
                n4 = 180.0f;
            }
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("  after rAngle :: ");
            sb5.append(n4);
            Log.e("save1", sb5.toString());
            final int width = puzzlePiece.getWidth();
            final int height = puzzlePiece.getHeight();
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(" ");
            sb6.append(n2);
            sb6.append(" pieceWidth :: ");
            sb6.append(width);
            Log.e("save", sb6.toString());
            final StringBuilder sb7 = new StringBuilder();
            sb7.append(" ");
            sb7.append(n2);
            sb7.append(" pieceHeight :: ");
            sb7.append(height);
            Log.e("save", sb7.toString());
            final int n5 = (int) puzzlePiece.getArea().left();
            final int n6 = (int) puzzlePiece.getArea().top();
            final int n7 = (int) puzzlePiece.getArea().right() - n5;
            final int n8 = (int) puzzlePiece.getArea().bottom() - n6;
            final StringBuilder sb8 = new StringBuilder();
            sb8.append(" ");
            sb8.append(n2);
            sb8.append("-areaX       original  --- :: ");
            sb8.append((int) puzzlePiece.getArea().left());
            sb8.append("   --> custom :: ");
            sb8.append(n5);
            final StringBuilder sb9 = new StringBuilder();
            sb9.append(" ");
            sb9.append(n2);
            sb9.append("-areaY       original  --- :: ");
            sb9.append((int) puzzlePiece.getArea().top());
            sb9.append("    --> custom :: ");
            sb9.append(n6);
            final StringBuilder sb10 = new StringBuilder();
            sb10.append(" ");
            sb10.append(n2);
            sb10.append("-areaWidth   original  --- :: ");
            sb10.append((int) puzzlePiece.getArea().right());
            sb10.append("  --> custom :: ");
            sb10.append(n7);
            final StringBuilder sb11 = new StringBuilder();
            sb11.append(" ");
            sb11.append(n2);
            sb11.append("-areaHeight  original  --- :: ");
            sb11.append((int) puzzlePiece.getArea().bottom());
            sb11.append(" --> custom :: ");
            sb11.append(n8);
            final float[] array = new float[9];
            final double n9 = n4;
            final double n10 = 0;
            float n11;
            float n12;
            float n13;
            float n14;
            if (n10 != 0) {
                final StringBuilder sb12 = new StringBuilder();
                sb12.append(" ");
                sb12.append(n2);
                sb12.append("- if rAngle != -0.0  --- :: ");
                sb12.append(n4);
                puzzlePiece.getMatrix().postRotate(n4);
                puzzlePiece.getMatrix().getValues(array);
                n11 = array[2];
                n12 = array[5];
                n13 = array[0] * width;
                n14 = array[4];
            } else {
                final StringBuilder sb13 = new StringBuilder();
                sb13.append(" ");
                sb13.append(n2);
                sb13.append("- else rAngle == -0.0  --- :: ");
                sb13.append(n4);
                puzzlePiece.getMatrix().getValues(array);
                n11 = array[2];
                n12 = array[5];
                n13 = array[0] * width;
                n14 = array[4];
            }
            final float n15 = n14 * height;
            final StringBuilder sb14 = new StringBuilder();
            sb14.append("globalx :: ");
            sb14.append(n11);
            Log.e("save", sb14.toString());
            final StringBuilder sb15 = new StringBuilder();
            sb15.append("globaly :: ");
            sb15.append(n12);
            Log.e("save", sb15.toString());
            final StringBuilder sb16 = new StringBuilder();
            sb16.append("width :: ");
            sb16.append(n13);
            Log.e("save", sb16.toString());
            final StringBuilder sb17 = new StringBuilder();
            sb17.append("height :: ");
            sb17.append(n15);
            final int n16 = (int) Math.abs(n13);
            final int n17 = (int) Math.abs(n15);
            final StringBuilder sb18 = new StringBuilder();
            sb18.append(" ");
            sb18.append(n2);
            sb18.append("-currentItemWidth  --- :: ");
            sb18.append(n16);
            final StringBuilder sb19 = new StringBuilder();
            sb19.append(" ");
            sb19.append(n2);
            sb19.append("-currentItemHeight   --- :: ");
            sb19.append(n17);
            Log.e("save", sb19.toString());
            int n22 = 0;
            int n27 = 0;
            int n28 = 0;
            String s7 = null;
            int n29 = 0;
            Label_2183:
            {
                int n23 = 0;
                int n25 = 0;
                Label_1936:
                {
                    if (n10 != 0) {
                        int n19;
                        if (n9 == 90.0) {
                            final StringBuilder sb20 = new StringBuilder();
                            sb20.append(" ");
                            sb20.append(n2);
                            sb20.append("- else if rAngle == 90.0  --- :: ");
                            float n20;
                            if (n2 == 0) {
                                float n18;
                                if (n11 > 0.0f) {
                                    n18 = Math.abs(Math.abs(n11) + Math.abs(n5));
                                } else {
                                    n18 = Math.abs(Math.abs(n11) - Math.abs(n5));
                                }
                                n19 = (int) n18;
                                n20 = Math.abs(Math.abs(Math.abs(n12) - Math.abs(n7)) - Math.abs(n6));
                            } else {
                                float n21;
                                if (n11 > 0.0f) {
                                    n21 = Math.abs(Math.abs(n11) + Math.abs(n6));
                                } else {
                                    n21 = Math.abs(Math.abs(n11) - Math.abs(n6));
                                }
                                n19 = (int) n21;
                                n20 = Math.abs(Math.abs(Math.abs(n12) - Math.abs(n7)) - Math.abs(n5));
                            }
                            n22 = (int) n20;
                            s4 = "transpose=1";
                        } else {
                            if (n9 == 180.0) {
                                final StringBuilder sb21 = new StringBuilder();
                                sb21.append(" ");
                                sb21.append(n2);
                                sb21.append("- else if rAngle == 180.0  --- :: ");
                                float n24;
                                if (n2 == 0) {
                                    n23 = (int) Math.abs(Math.abs(Math.abs(n11) - Math.abs(n7)) - Math.abs(n5));
                                    n24 = Math.abs(Math.abs(Math.abs(n12) - Math.abs(n8)) - Math.abs(n5));
                                } else {
                                    n23 = (int) Math.abs(Math.abs(Math.abs(n11) - Math.abs(n7)) - Math.abs(n5));
                                    n24 = Math.abs(Math.abs(Math.abs(n12) - Math.abs(n8)) - Math.abs(n6));
                                }
                                n25 = (int) n24;
                                s4 = "transpose=2,transpose=2";
                                break Label_1936;
                            }
                            final StringBuilder sb22 = new StringBuilder();
                            sb22.append(" ");
                            sb22.append(n2);
                            sb22.append("- else rAngle == 270.0  --- :: ");
                            float n26;
                            if (n2 == 0) {
                                n19 = (int) Math.abs(Math.abs(Math.abs(n11) - Math.abs(n8)) - Math.abs(n5));
                                if (n12 > 0.0f) {
                                    n26 = Math.abs(Math.abs(n12) + Math.abs(n6));
                                } else {
                                    n26 = Math.abs(Math.abs(n12) - Math.abs(n6));
                                }
                            } else {
                                n19 = (int) Math.abs(Math.abs(Math.abs(n11) - Math.abs(n7)) - Math.abs(n5));
                                if (n12 > 0.0f) {
                                    n26 = Math.abs(Math.abs(n12) + Math.abs(n5));
                                } else {
                                    n26 = Math.abs(Math.abs(n12) - Math.abs(n5));
                                }
                            }
                            n22 = (int) n26;
                            s4 = "transpose=2";
                        }
                        n27 = n7;
                        n28 = n8;
                        s7 = s4;
                        n29 = n19;
                        break Label_2183;
                    }
                    final StringBuilder sb23 = new StringBuilder();
                    sb23.append(" ");
                    sb23.append(n2);
                    sb23.append("- if rAngle == 0.0  --- :: ");
                    float n31;
                    if (n2 == 0) {
                        float n30;
                        if (n11 > 0.0f) {
                            n30 = Math.abs(Math.abs(n11) - Math.abs(n5));
                        } else {
                            n30 = Math.abs(Math.abs(n11) + Math.abs(n5));
                        }
                        n23 = (int) n30;
                        if (n12 > 0.0f) {
                            n31 = Math.abs(Math.abs(n12) - Math.abs(n6));
                        } else {
                            n31 = Math.abs(Math.abs(n12) + Math.abs(n6));
                        }
                    } else {
                        float n32;
                        if (n11 > 0.0f) {
                            n32 = Math.abs(Math.abs(n11) - Math.abs(n5));
                        } else {
                            n32 = Math.abs(Math.abs(n11) + Math.abs(n5));
                        }
                        n23 = (int) n32;
                        if (n12 > 0.0f) {
                            n31 = Math.abs(Math.abs(n12) - Math.abs(n6));
                        } else {
                            n31 = Math.abs(Math.abs(n12) + Math.abs(n6));
                        }
                    }
                    n25 = (int) n31;
                    s4 = "transpose=2,transpose=2,transpose=2,transpose=2";
                }
                n28 = n7;
                n27 = n8;
                n29 = n23;
                n22 = n25;
                s7 = s4;
            }
            final StringBuilder sb24 = new StringBuilder();
            sb24.append(" ");
            sb24.append(n2);
            sb24.append("-cropWidth   original  --- :: ");
            sb24.append(n28);
            Log.e("save", sb24.toString());
            final StringBuilder sb25 = new StringBuilder();
            sb25.append(" ");
            sb25.append(n2);
            sb25.append("-cropHeight  original  --- :: ");
            sb25.append(n27);
            final StringBuilder sb26 = new StringBuilder();
            sb26.append(" ");
            sb26.append(n2);
            sb26.append(" cropX :: ");
            sb26.append(n29);
            Log.e("save", sb26.toString());
            final StringBuilder sb27 = new StringBuilder();
            sb27.append(" ");
            sb27.append(n2);
            sb27.append(" cropY :: ");
            sb27.append(n22);
            final int n33 = n7 + n6;
            String s8;
            String string;
            if (Util.isImageFile(this.bitmapPaint.get(n2))) {
                s4 = this.saveTransparentImage();
                list.add("-loop");
                list.add("1");
                list.add("-i");
                list.add(s4);
                final StringBuilder sb28 = new StringBuilder();
                sb28.append("[");
                sb28.append(i);
                sb28.append(":v] scale=");
                sb28.append(n16);
                sb28.append("x");
                sb28.append(n17);
                sb28.append(", crop=w='if(gte(");
                sb28.append(n28);
                sb28.append(",");
                sb28.append(n16);
                sb28.append("),");
                sb28.append(n16);
                sb28.append(",");
                sb28.append(n28);
                sb28.append(")':h='if(gte(");
                sb28.append(n27);
                sb28.append(",");
                sb28.append(n17);
                sb28.append("),");
                sb28.append(n17);
                sb28.append(",");
                sb28.append(n27);
                sb28.append(")':x=");
                sb28.append(n29);
                sb28.append(":y=");
                sb28.append(n22);
                sb28.append(", ");
                sb28.append(s7);
                sb28.append(", pad=width=");
                sb28.append(n33);
                sb28.append(":height=");
                sb28.append(n8);
                sb28.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb28.append(i);
                sb28.append("];");
                s4 = sb28.toString();
                list4.add(i);
                string = (s8 = "");
            } else {
                list.add("-i");
                list.add(this.bitmapPaint.get(n2));
                final StringBuilder sb29 = new StringBuilder();
                sb29.append("[");
                sb29.append(i);
                sb29.append(":v] scale=");
                sb29.append(n16);
                sb29.append("x");
                sb29.append(n17);
                sb29.append(", crop=w='if(gte(");
                sb29.append(n28);
                sb29.append(",");
                sb29.append(n16);
                sb29.append("),");
                sb29.append(n16);
                sb29.append(",");
                sb29.append(n28);
                sb29.append(")':h='if(gte(");
                sb29.append(n27);
                sb29.append(",");
                sb29.append(n17);
                sb29.append("),");
                sb29.append(n17);
                sb29.append(",");
                sb29.append(n27);
                sb29.append(")':x=");
                sb29.append(n29);
                sb29.append(":y=");
                sb29.append(n22);
                sb29.append(", ");
                sb29.append(s7);
                sb29.append(", pad=width=");
                sb29.append(n33);
                sb29.append(":height=");
                sb29.append(n8);
                sb29.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb29.append(i);
                sb29.append("];");
                final String string2 = sb29.toString();
                TextureVideoView textureVideoView = null;
                final int n34 = n2;
                if (this.viewPieces.get(n34) instanceof RelativeLayout) {
                    final View child = ((RelativeLayout) this.viewPieces.get(n34)).getChildAt(0);
                    if (child instanceof TextureVideoView) {
                        textureVideoView = (TextureVideoView) child;
                    }
                }
                final StringBuilder sb30 = new StringBuilder();
                sb30.append("view.isMute() :: ");
                sb30.append(textureVideoView.isMute());
                Log.e("save", sb30.toString());
                if (textureVideoView.isMute()) {
                    final StringBuilder sb31 = new StringBuilder();
                    sb31.append("[");
                    sb31.append(i);
                    sb31.append(":a]volume=0.0[sound");
                    sb31.append(i);
                    sb31.append("];");
                    s4 = sb31.toString();
                } else {
                    final StringBuilder sb32 = new StringBuilder();
                    sb32.append("[");
                    sb32.append(i);
                    sb32.append(":a]volume=1.0[sound");
                    sb32.append(i);
                    sb32.append("];");
                    s4 = sb32.toString();
                }
                list4.add(i);
                list5.add(i);
                if (!this.inOrder) {
                    final StringBuilder sb33 = new StringBuilder();
                    sb33.append("pos1 :: ");
                    sb33.append(i);
                    final String string3 = sb33.toString();
                    final String s9 = "savepos";
                    Log.e(s9, string3);
                    ++i;
                    final String saveVideoThumb = this.saveVideoThumb(this.bitmapPaint.get(n34));
                    list.add("-i");
                    list.add(saveVideoThumb);
                    final StringBuilder sb34 = new StringBuilder();
                    sb34.append("[");
                    sb34.append(i);
                    sb34.append(":v] scale=");
                    sb34.append(n16);
                    sb34.append("x");
                    sb34.append(n17);
                    sb34.append(", crop=w='if(gte(");
                    sb34.append(n28);
                    sb34.append(",");
                    sb34.append(n16);
                    sb34.append("),");
                    sb34.append(n16);
                    sb34.append(",");
                    sb34.append(n28);
                    sb34.append(")':h='if(gte(");
                    sb34.append(n27);
                    sb34.append(",");
                    sb34.append(n17);
                    sb34.append("),");
                    sb34.append(n17);
                    sb34.append(",");
                    sb34.append(n27);
                    sb34.append(")':x=");
                    sb34.append(n29);
                    sb34.append(":y=");
                    sb34.append(n22);
                    sb34.append(", ");
                    sb34.append(s7);
                    sb34.append(", pad=width=");
                    sb34.append(n33);
                    sb34.append(":height=");
                    sb34.append(n8);
                    sb34.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                    sb34.append(i);
                    sb34.append("];");
                    string = sb34.toString();
                    final StringBuilder sb35 = new StringBuilder();
                    sb35.append("pos 2:: ");
                    sb35.append(i);
                    Log.e(s9, sb35.toString());
                } else {
                    string = "";
                }
                s8 = s4;
                s4 = string2;
            }
            ++i;
            final StringBuilder sb36 = new StringBuilder();
            sb36.append("pos 3:: ");
            sb36.append(i);
            Log.e("savepos", sb36.toString());
            sb2.append(s8);
            sb.append(s4);
            sb.append(string);
            ++n2;
            list2 = list;
            final int n35 = i;
            n = i;
            i = n35;
        }
        final StringBuilder sb37 = new StringBuilder();
        sb37.append("j is :: ");
        sb37.append(n);
        Log.e("save", sb37.toString());
        list2.add("-i");
        list2.add(this.bgPath);
        final StringBuilder sb38 = new StringBuilder();
        sb38.append(s3);
        sb38.append("[");
        sb38.append(n);
        sb38.append(":v] scale=");
        sb38.append(this.baseViewWidth);
        sb38.append("x");
        sb38.append(this.baseViewHeight);
        sb38.append(" [base];");
        final String string4 = sb38.toString();
        i = n + 1;
        list2.add("-i");
        list2.add(this.allImagePath);
        final StringBuilder sb39 = new StringBuilder();
        sb39.append("[");
        sb39.append(i);
        sb39.append(":v] scale=");
        sb39.append(this.puzzleView.getWidth());
        sb39.append("x");
        sb39.append(this.puzzleView.getHeight());
        sb39.append(" [allImage];");
        final String string5 = sb39.toString();
        final int n36 = i + 1;
        final StringBuilder sb40 = new StringBuilder();
        i = 0;
        s3 = s6;
        while (i < list3.size()) {
            final StringBuilder sb41 = new StringBuilder();
            sb41.append("[sound");
            sb41.append(list3.get(i));
            sb41.append("]");
            sb40.append(sb41.toString());
            ++i;
        }
        if (!this.musicPath.equals("")) {
            if (!this.inOrder) {
                final StringBuilder sb42 = new StringBuilder();
                sb2.append((CharSequence) sb40);
                sb42.append((Object) sb2);
                sb42.append("concat=n=");
                sb42.append(list3.size());
                sb42.append(":v=0:a=1[a1]; amovie=");
                sb42.append(this.musicPath);
                sb42.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb42.toString();
            } else {
                final StringBuilder sb43 = new StringBuilder();
                sb43.append(s5);
                sb43.append((Object) sb2);
                sb43.append((Object) sb40);
                sb43.append("amix=inputs=");
                sb43.append(list3.size());
                sb43.append("[a1]; amovie=");
                sb43.append(this.musicPath);
                sb43.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb43.toString();
            }
        } else if (!this.inOrder) {
            final StringBuilder sb44 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb44.append((Object) sb2);
            sb44.append("concat=n=");
            sb44.append(list3.size());
            sb44.append(":v=0:a=1[a];");
            s = sb44.toString();
        } else {
            final StringBuilder sb45 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb45.append((Object) sb2);
            sb45.append("amix=inputs=");
            sb45.append(list3.size());
            sb45.append("[a];");
            s = sb45.toString();
        }
        final StringBuilder sb46 = new StringBuilder();
        StringBuilder sb47;
        for (i = 0; i < list4.size(); ++i) {
            sb47 = new StringBuilder();
            sb47.append("[scale");
            sb47.append(list4.get(i));
            sb47.append("]");
            sb46.append(sb47.toString());
        }
        final StringBuilder sb48 = new StringBuilder();
        if (!this.inOrder) {
            sb48.append(" [scale0][scale3] hstack [imgVidCombine1]; [scale1][scale2] hstack [imgVidCombine2]; [imgVidCombine1][imgVidCombine2] concat=n=2 [vidCombine];");
        } else {
            final StringBuilder sb49 = new StringBuilder();
            sb49.append((Object) sb46);
            sb49.append(" hstack=inputs=");
            sb49.append(this.bitmapPaint.size());
            sb49.append(" [vidCombine];");
            sb48.append(sb49.toString());
        }
        final StringBuilder sb50 = new StringBuilder();
        sb50.append((Object) sb);
        sb50.append(string4);
        sb50.append(string5);
        sb50.append(s);
        sb50.append((Object) sb48);
        sb50.append(" [vidCombine] pad=width=");
        sb50.append(this.baseViewWidth);
        sb50.append(":height=");
        sb50.append(this.baseViewHeight);
        sb50.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000 [viewPadding]; [viewPadding][allImage] overlay=x=");
        sb50.append(this.baseViewPadding);
        sb50.append(":y=");
        sb50.append(this.baseViewPadding);
        sb50.append(" [allView]; [base][allView] overlay=x=0:y=0");
        s = sb50.toString();
        String string6;
        if (!this.stickerPath.equals("")) {
            list2.add("-i");
            list2.add(this.stickerPath);
            final StringBuilder sb51 = new StringBuilder();
            sb51.append("[");
            sb51.append((Object) sb3);
            sb51.append("];[");
            sb51.append((Object) sb3);
            sb51.append("][");
            sb51.append(n36);
            sb51.append(":v] overlay=x=0:y=0");
            string6 = sb51.toString();
        } else {
            string6 = s2;
        }
        list2.add("-filter_complex");
        final StringBuilder sb52 = new StringBuilder();
        sb52.append("");
        sb52.append(s);
        sb52.append(string6);
        list2.add(sb52.toString());
        list2.add("-map");
        list2.add("0:v");
        list2.add("-map");
        list2.add("[a]");
        list2.add("-c:v");
        list2.add("mpeg4");
        list2.add("-b:v");
        list2.add("1M");
        list2.add("-ss");
        list2.add("00:00:00");
        list2.add("-t");
        final StringBuilder sb53 = new StringBuilder();
        sb53.append("");
        sb53.append(this.convertSecondsToHMmSs(this.totalDuration));
        list2.add(sb53.toString());
        final StringBuilder sb54 = new StringBuilder();
        sb54.append("");
        sb54.append(this.videoName);
        list2.add(sb54.toString());
        final StringBuilder sb55 = new StringBuilder();
        sb55.append("1 vertical upperArr :: ");
        sb55.append(list.toString());
        final StringBuilder sb56 = new StringBuilder();
        sb56.append("1 vertical upperArr :: ");
        sb56.append(list.toString());
        return list2.toArray(new String[list.size()]);
    }


    private String[] twoXTwoVertical(final ArrayList<String> list, final StringBuilder sb, String s, final String s2, String s3, String s4, final String s5, final StringBuilder sb2, int i, final StringBuilder sb3) {
        ArrayList<String> list2 = list;
        final ArrayList<Integer> list3 = new ArrayList<Integer>();
        final ArrayList<Integer> list4 = new ArrayList<Integer>();
        list2.add("-y");
        int n = i;
        int j;
        PuzzlePiece puzzlePiece;
        float matrixAngle;
        StringBuilder sb4;
        ArrayList<Integer> list5;
        double n2;
        float n3;
        StringBuilder sb5;
        int width;
        int height;
        StringBuilder sb6;
        StringBuilder sb7;
        int n4;
        int n5;
        int n6;
        int n7;
        StringBuilder sb8;
        StringBuilder sb9;
        StringBuilder sb10;
        StringBuilder sb11;
        float[] array;
        double n8;
        double n9 = 0;
        StringBuilder sb12;
        float n10;
        float n11;
        float n12;
        float n13;
        StringBuilder sb13;
        float n14;
        StringBuilder sb14;
        StringBuilder sb15;
        StringBuilder sb16;
        StringBuilder sb17;
        int n15;
        int n16;
        StringBuilder sb18;
        StringBuilder sb19;
        StringBuilder sb20;
        float n17;
        int n18;
        float n19;
        float n20;
        int n21;
        StringBuilder sb21;
        int n22 = 0;
        float n23;
        int n24 = 0;
        StringBuilder sb22;
        float n25;
        int n26 = 0;
        int n27 = 0;
        String s6 = null;
        int n28 = 0;
        StringBuilder sb23;
        float n29;
        float n30;
        float n31;
        StringBuilder sb24;
        StringBuilder sb25;
        StringBuilder sb26;
        StringBuilder sb27;
        int n32;
        StringBuilder sb28;
        String string;
        String s7;
        StringBuilder sb29;
        String string2;
        TextureVideoView textureVideoView;
        int n33;
        View child;
        StringBuilder sb30;
        StringBuilder sb31;
        StringBuilder sb32;
        StringBuilder sb33;
        String string3;
        String s8;
        String saveVideoThumb;
        StringBuilder sb34;
        String string4;
        StringBuilder sb35;
        StringBuilder sb36;
        for (j = 0, i = 0; j < this.length; ++j, list2 = list, n = i) {
            puzzlePiece = this.puzzleView.getPuzzlePieces().get(j);
            matrixAngle = puzzlePiece.getMatrixAngle();
            sb4 = new StringBuilder();
            list5 = list3;
            sb4.append(" befor rotateAngle :: ");
            sb4.append(matrixAngle);
            n2 = matrixAngle;
            if (n2 == 90.0) {
                n3 = 90.0f;
            } else if (n2 != -180.0 && n2 != 180.0) {
                if (n2 == -90.0) {
                    n3 = 270.0f;
                } else {
                    n3 = 0.0f;
                }
            } else {
                n3 = 180.0f;
            }
            sb5 = new StringBuilder();
            sb5.append("  after rAngle :: ");
            sb5.append(n3);
            width = puzzlePiece.getWidth();
            height = puzzlePiece.getHeight();
            sb6 = new StringBuilder();
            sb6.append(" ");
            sb6.append(j);
            sb6.append(" pieceWidth :: ");
            sb6.append(width);
            Log.e("save", sb6.toString());
            sb7 = new StringBuilder();
            sb7.append(" ");
            sb7.append(j);
            sb7.append(" pieceHeight :: ");
            sb7.append(height);
            n4 = (int) puzzlePiece.getArea().left();
            n5 = (int) puzzlePiece.getArea().top();
            n6 = (int) puzzlePiece.getArea().right() - n4;
            n7 = (int) puzzlePiece.getArea().bottom() - n5;
            sb8 = new StringBuilder();
            sb8.append(" ");
            sb8.append(j);
            sb8.append("-areaX       original  --- :: ");
            sb8.append((int) puzzlePiece.getArea().left());
            sb8.append("   --> custom :: ");
            sb8.append(n4);
            sb9 = new StringBuilder();
            sb9.append(" ");
            sb9.append(j);
            sb9.append("-areaY       original  --- :: ");
            sb9.append((int) puzzlePiece.getArea().top());
            sb9.append("    --> custom :: ");
            sb9.append(n5);
            sb10 = new StringBuilder();
            sb10.append(" ");
            sb10.append(j);
            sb10.append("-areaWidth   original  --- :: ");
            sb10.append((int) puzzlePiece.getArea().right());
            sb10.append("  --> custom :: ");
            sb10.append(n6);
            sb11 = new StringBuilder();
            sb11.append(" ");
            sb11.append(j);
            sb11.append("-areaHeight  original  --- :: ");
            sb11.append((int) puzzlePiece.getArea().bottom());
            sb11.append(" --> custom :: ");
            sb11.append(n7);
            array = new float[9];
            n8 = n3;
            if (n9 != 0) {
                sb12 = new StringBuilder();
                sb12.append(" ");
                sb12.append(j);
                sb12.append("- if rAngle != -0.0  --- :: ");
                sb12.append(n3);
                puzzlePiece.getMatrix().postRotate(n3);
                puzzlePiece.getMatrix().getValues(array);
                n10 = array[2];
                n11 = array[5];
                n12 = array[0] * width;
                n13 = array[4];
            } else {
                sb13 = new StringBuilder();
                sb13.append(" ");
                sb13.append(j);
                sb13.append("- else rAngle == -0.0  --- :: ");
                sb13.append(n3);
                puzzlePiece.getMatrix().getValues(array);
                n10 = array[2];
                n11 = array[5];
                n12 = array[0] * width;
                n13 = array[4];
            }
            n14 = n13 * height;
            sb14 = new StringBuilder();
            sb14.append("globalx :: ");
            sb14.append(n10);
            sb15 = new StringBuilder();
            sb15.append("globaly :: ");
            sb15.append(n11);
            sb16 = new StringBuilder();
            sb16.append("width :: ");
            sb16.append(n12);
            sb17 = new StringBuilder();
            sb17.append("height :: ");
            sb17.append(n14);
            n15 = (int) Math.abs(n12);
            n16 = (int) Math.abs(n14);
            sb18 = new StringBuilder();
            sb18.append(" ");
            sb18.append(j);
            sb18.append("-currentItemWidth  --- :: ");
            sb18.append(n15);
            sb19 = new StringBuilder();
            sb19.append(" ");
            sb19.append(j);
            sb19.append("-currentItemHeight   --- :: ");
            sb19.append(n16);
            Label_2175:
            {
                Label_1928:
                {
                    if (n9 != 0) {
                        if (n8 == 90.0) {
                            sb20 = new StringBuilder();
                            sb20.append(" ");
                            sb20.append(j);
                            sb20.append("- else if rAngle == 90.0  --- :: ");
                            if (j == 0) {
                                if (n10 > 0.0f) {
                                    n17 = Math.abs(Math.abs(n10) + Math.abs(n4));
                                } else {
                                    n17 = Math.abs(Math.abs(n10) - Math.abs(n4));
                                }
                                n18 = (int) n17;
                                n19 = Math.abs(Math.abs(Math.abs(n11) - Math.abs(n6)) - Math.abs(n5));
                            } else {
                                if (n10 > 0.0f) {
                                    n20 = Math.abs(Math.abs(n10) + Math.abs(n5));
                                } else {
                                    n20 = Math.abs(Math.abs(n10) - Math.abs(n5));
                                }
                                n18 = (int) n20;
                                n19 = Math.abs(Math.abs(Math.abs(n11) - Math.abs(n6)) - Math.abs(n4));
                            }
                            n21 = (int) n19;
                            s4 = "transpose=1";
                        } else {
                            if (n8 == 180.0) {
                                sb21 = new StringBuilder();
                                sb21.append(" ");
                                sb21.append(j);
                                sb21.append("- else if rAngle == 180.0  --- :: ");
                                if (j == 0) {
                                    n22 = (int) Math.abs(Math.abs(Math.abs(n10) - Math.abs(n6)) - Math.abs(n4));
                                    n23 = Math.abs(Math.abs(Math.abs(n11) - Math.abs(n7)) - Math.abs(n4));
                                } else {
                                    n22 = (int) Math.abs(Math.abs(Math.abs(n10) - Math.abs(n6)) - Math.abs(n4));
                                    n23 = Math.abs(Math.abs(Math.abs(n11) - Math.abs(n7)) - Math.abs(n5));
                                }
                                n24 = (int) n23;
                                s4 = "transpose=2,transpose=2";
                                break Label_1928;
                            }
                            sb22 = new StringBuilder();
                            sb22.append(" ");
                            sb22.append(j);
                            sb22.append("- else rAngle == 270.0  --- :: ");
                            if (j == 0) {
                                n18 = (int) Math.abs(Math.abs(Math.abs(n10) - Math.abs(n7)) - Math.abs(n4));
                                if (n11 > 0.0f) {
                                    n25 = Math.abs(Math.abs(n11) + Math.abs(n5));
                                } else {
                                    n25 = Math.abs(Math.abs(n11) - Math.abs(n5));
                                }
                            } else {
                                n18 = (int) Math.abs(Math.abs(Math.abs(n10) - Math.abs(n6)) - Math.abs(n4));
                                if (n11 > 0.0f) {
                                    n25 = Math.abs(Math.abs(n11) + Math.abs(n4));
                                } else {
                                    n25 = Math.abs(Math.abs(n11) - Math.abs(n4));
                                }
                            }
                            n21 = (int) n25;
                            s4 = "transpose=2";
                        }
                        n26 = n6;
                        n27 = n7;
                        s6 = s4;
                        n28 = n21;
                        n22 = n18;
                        break Label_2175;
                    }
                    sb23 = new StringBuilder();
                    sb23.append(" ");
                    sb23.append(j);
                    sb23.append("- if rAngle == 0.0  --- :: ");
                    if (j == 0) {
                        if (n10 > 0.0f) {
                            n29 = Math.abs(Math.abs(n10) - Math.abs(n4));
                        } else {
                            n29 = Math.abs(Math.abs(n10) + Math.abs(n4));
                        }
                        n22 = (int) n29;
                        if (n11 > 0.0f) {
                            n30 = Math.abs(Math.abs(n11) - Math.abs(n5));
                        } else {
                            n30 = Math.abs(Math.abs(n11) + Math.abs(n5));
                        }
                    } else {
                        if (n10 > 0.0f) {
                            n31 = Math.abs(Math.abs(n10) - Math.abs(n4));
                        } else {
                            n31 = Math.abs(Math.abs(n10) + Math.abs(n4));
                        }
                        n22 = (int) n31;
                        if (n11 > 0.0f) {
                            n30 = Math.abs(Math.abs(n11) - Math.abs(n5));
                        } else {
                            n30 = Math.abs(Math.abs(n11) + Math.abs(n5));
                        }
                    }
                    n24 = (int) n30;
                    s4 = "transpose=2,transpose=2,transpose=2,transpose=2";
                }
                n27 = n6;
                n26 = n7;
                n28 = n24;
                s6 = s4;
            }
            sb24 = new StringBuilder();
            sb24.append(" ");
            sb24.append(j);
            sb24.append("-cropWidth   original  --- :: ");
            sb24.append(n27);
            Log.e("save", sb24.toString());
            sb25 = new StringBuilder();
            sb25.append(" ");
            sb25.append(j);
            sb25.append("-cropHeight  original  --- :: ");
            sb25.append(n26);
            sb26 = new StringBuilder();
            sb26.append(" ");
            sb26.append(j);
            sb26.append(" cropX :: ");
            sb26.append(n22);
            Log.e("save", sb26.toString());
            sb27 = new StringBuilder();
            sb27.append(" ");
            sb27.append(j);
            sb27.append(" cropY :: ");
            sb27.append(n28);
            Log.e("save", sb27.toString());
            n32 = n7 + n4;
            if (Util.isImageFile(this.bitmapPaint.get(j))) {
                s4 = this.saveTransparentImage();
                list.add("-loop");
                list.add("1");
                list.add("-i");
                list.add(s4);
                sb28 = new StringBuilder();
                sb28.append("[");
                sb28.append(i);
                sb28.append(":v] scale=");
                sb28.append(n15);
                sb28.append("x");
                sb28.append(n16);
                sb28.append(", crop=w='if(gte(");
                sb28.append(n27);
                sb28.append(",");
                sb28.append(n15);
                sb28.append("),");
                sb28.append(n15);
                sb28.append(",");
                sb28.append(n27);
                sb28.append(")':h='if(gte(");
                sb28.append(n26);
                sb28.append(",");
                sb28.append(n16);
                sb28.append("),");
                sb28.append(n16);
                sb28.append(",");
                sb28.append(n26);
                sb28.append(")':x=");
                sb28.append(n22);
                sb28.append(":y=");
                sb28.append(n28);
                sb28.append(", ");
                sb28.append(s6);
                sb28.append(", pad=width=");
                sb28.append(n6);
                sb28.append(":height=");
                sb28.append(n32);
                sb28.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb28.append(i);
                sb28.append("];");
                string = sb28.toString();
                list4.add(i);
                s7 = (s4 = "");
            } else {
                list.add("-i");
                list.add(this.bitmapPaint.get(j));
                sb29 = new StringBuilder();
                sb29.append("[");
                sb29.append(i);
                sb29.append(":v] scale=");
                sb29.append(n15);
                sb29.append("x");
                sb29.append(n16);
                sb29.append(", crop=w='if(gte(");
                sb29.append(n27);
                sb29.append(",");
                sb29.append(n15);
                sb29.append("),");
                sb29.append(n15);
                sb29.append(",");
                sb29.append(n27);
                sb29.append(")':h='if(gte(");
                sb29.append(n26);
                sb29.append(",");
                sb29.append(n16);
                sb29.append("),");
                sb29.append(n16);
                sb29.append(",");
                sb29.append(n26);
                sb29.append(")':x=");
                sb29.append(n22);
                sb29.append(":y=");
                sb29.append(n28);
                sb29.append(", ");
                sb29.append(s6);
                sb29.append(", pad=width=");
                sb29.append(n6);
                sb29.append(":height=");
                sb29.append(n32);
                sb29.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                sb29.append(i);
                sb29.append("];");
                string2 = sb29.toString();
                textureVideoView = null;
                n33 = j;
                if (this.viewPieces.get(n33) instanceof RelativeLayout) {
                    child = ((RelativeLayout) this.viewPieces.get(n33)).getChildAt(0);
                    if (child instanceof TextureVideoView) {
                        textureVideoView = (TextureVideoView) child;
                    }
                }
                sb30 = new StringBuilder();
                sb30.append("view.isMute() :: ");
                sb30.append(textureVideoView.isMute());
                if (textureVideoView.isMute()) {
                    sb31 = new StringBuilder();
                    sb31.append("[");
                    sb31.append(i);
                    sb31.append(":a]volume=0.0[sound");
                    sb31.append(i);
                    sb31.append("];");
                    s4 = sb31.toString();
                } else {
                    sb32 = new StringBuilder();
                    sb32.append("[");
                    sb32.append(i);
                    sb32.append(":a]volume=1.0[sound");
                    sb32.append(i);
                    sb32.append("];");
                    s4 = sb32.toString();
                }
                list4.add(i);
                list5.add(i);
                if (!this.inOrder) {
                    sb33 = new StringBuilder();
                    sb33.append("pos1 :: ");
                    sb33.append(i);
                    string3 = sb33.toString();
                    s8 = "savepos";
                    ++i;
                    saveVideoThumb = this.saveVideoThumb(this.bitmapPaint.get(n33));
                    list.add("-i");
                    list.add(saveVideoThumb);
                    sb34 = new StringBuilder();
                    sb34.append("[");
                    sb34.append(i);
                    sb34.append(":v] scale=");
                    sb34.append(n15);
                    sb34.append("x");
                    sb34.append(n16);
                    sb34.append(", crop=w='if(gte(");
                    sb34.append(n27);
                    sb34.append(",");
                    sb34.append(n15);
                    sb34.append("),");
                    sb34.append(n15);
                    sb34.append(",");
                    sb34.append(n27);
                    sb34.append(")':h='if(gte(");
                    sb34.append(n26);
                    sb34.append(",");
                    sb34.append(n16);
                    sb34.append("),");
                    sb34.append(n16);
                    sb34.append(",");
                    sb34.append(n26);
                    sb34.append(")':x=");
                    sb34.append(n22);
                    sb34.append(":y=");
                    sb34.append(n28);
                    sb34.append(", ");
                    sb34.append(s6);
                    sb34.append(", pad=width=");
                    sb34.append(n6);
                    sb34.append(":height=");
                    sb34.append(n32);
                    sb34.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000, setsar=sar=1/1 [scale");
                    sb34.append(i);
                    sb34.append("];");
                    string4 = sb34.toString();
                    sb35 = new StringBuilder();
                    sb35.append("pos 2:: ");
                    sb35.append(i);
                } else {
                    string4 = "";
                }
                s7 = string4;
                string = string2;
            }
            ++i;
            sb36 = new StringBuilder();
            sb36.append("pos 3:: ");
            sb36.append(i);
            sb2.append(s4);
            sb.append(string);
            sb.append(s7);
        }
        final String s9 = "save";
        final StringBuilder sb37 = new StringBuilder();
        sb37.append("j is :: ");
        sb37.append(n);
        Log.e(s9, sb37.toString());
        list2.add("-i");
        list2.add(this.bgPath);
        final StringBuilder sb38 = new StringBuilder();
        sb38.append(s3);
        sb38.append("[");
        sb38.append(n);
        sb38.append(":v] scale=");
        sb38.append(this.baseViewWidth);
        sb38.append("x");
        sb38.append(this.baseViewHeight);
        sb38.append(" [base];");
        final String string5 = sb38.toString();
        i = n + 1;
        list2.add("-i");
        list2.add(this.allImagePath);
        final StringBuilder sb39 = new StringBuilder();
        sb39.append("[");
        sb39.append(i);
        sb39.append(":v] scale=");
        sb39.append(this.puzzleView.getWidth());
        sb39.append("x");
        sb39.append(this.puzzleView.getHeight());
        sb39.append(" [allImage];");
        final String string6 = sb39.toString();
        final int n34 = i + 1;
        final StringBuilder sb40 = new StringBuilder();
        i = 0;
        s3 = s9;
        while (i < list3.size()) {
            final StringBuilder sb41 = new StringBuilder();
            sb41.append("[sound");
            sb41.append(list3.get(i));
            sb41.append("]");
            sb40.append(sb41.toString());
            ++i;
        }
        if (!this.musicPath.equals("")) {
            if (!this.inOrder) {
                final StringBuilder sb42 = new StringBuilder();
                sb2.append((CharSequence) sb40);
                sb42.append((Object) sb2);
                sb42.append("concat=n=");
                sb42.append(list3.size());
                sb42.append(":v=0:a=1[a1]; amovie=");
                sb42.append(this.musicPath);
                sb42.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb42.toString();
            } else {
                final StringBuilder sb43 = new StringBuilder();
                sb43.append(s5);
                sb43.append((Object) sb2);
                sb43.append((Object) sb40);
                sb43.append("amix=inputs=");
                sb43.append(list3.size());
                sb43.append("[a1]; amovie=");
                sb43.append(this.musicPath);
                sb43.append(":loop=0[extra]; [a1][extra]amix[a];");
                s = sb43.toString();
            }
        } else if (!this.inOrder) {
            final StringBuilder sb44 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb44.append((Object) sb2);
            sb44.append("concat=n=");
            sb44.append(list3.size());
            sb44.append(":v=0:a=1[a];");
            s = sb44.toString();
        } else {
            final StringBuilder sb45 = new StringBuilder();
            sb2.append((CharSequence) sb40);
            sb45.append((Object) sb2);
            sb45.append("amix=inputs=");
            sb45.append(list3.size());
            sb45.append("[a];");
            s = sb45.toString();
        }
        final StringBuilder sb46 = new StringBuilder();
        int k = 0;
        i = n34;
        while (k < list4.size()) {
            final StringBuilder sb47 = new StringBuilder();
            sb47.append("[scale");
            sb47.append(list4.get(k));
            sb47.append("]");
            sb46.append(sb47.toString());
            ++k;
        }
        final StringBuilder sb48 = new StringBuilder();
        if (!this.inOrder) {
            sb48.append(" [scale0][scale3] vstack [imgVidCombine1]; [scale1][scale2] vstack [imgVidCombine2]; [imgVidCombine1][imgVidCombine2] concat=n=2 [vidCombine];");
        } else {
            final StringBuilder sb49 = new StringBuilder();
            sb49.append((Object) sb46);
            sb49.append(" vstack=inputs=");
            sb49.append(this.bitmapPaint.size());
            sb49.append(" [vidCombine];");
            sb48.append(sb49.toString());
        }
        final StringBuilder sb50 = new StringBuilder();
        sb50.append((Object) sb);
        sb50.append(string5);
        sb50.append(string6);
        sb50.append(s);
        sb50.append((Object) sb48);
        sb50.append(" [vidCombine] pad=width=");
        sb50.append(this.baseViewWidth);
        sb50.append(":height=");
        sb50.append(this.baseViewHeight);
        sb50.append(":x=(ow-iw)/2:y=(oh-ih)/2:color=#00000000 [viewPadding]; [viewPadding][allImage] overlay=x=");
        sb50.append(this.baseViewPadding);
        sb50.append(":y=");
        sb50.append(this.baseViewPadding);
        sb50.append(" [allView]; [base][allView] overlay=x=0:y=0");
        s = sb50.toString();
        String string7;
        if (!this.stickerPath.equals("")) {
            list2.add("-i");
            list2.add(this.stickerPath);
            final StringBuilder sb51 = new StringBuilder();
            sb51.append("[");
            sb51.append((Object) sb3);
            sb51.append("];[");
            sb51.append((Object) sb3);
            sb51.append("][");
            sb51.append(i);
            sb51.append(":v] overlay=x=0:y=0");
            string7 = sb51.toString();
        } else {
            string7 = s2;
        }
        list2.add("-filter_complex");
        final StringBuilder sb52 = new StringBuilder();
        sb52.append("");
        sb52.append(s);
        sb52.append(string7);
        list2.add(sb52.toString());
        list2.add("-map");
        list2.add("0:v");
        list2.add("-map");
        list2.add("[a]");
        list2.add("-c:v");
        list2.add("mpeg4");
        list2.add("-b:v");
        list2.add("1M");
        list2.add("-ss");
        list2.add("00:00:00");
        list2.add("-t");
        final StringBuilder sb53 = new StringBuilder();
        sb53.append("");
        sb53.append(this.convertSecondsToHMmSs(this.totalDuration));
        list2.add(sb53.toString());
        final StringBuilder sb54 = new StringBuilder();
        sb54.append("");
        sb54.append(this.videoName);
        list2.add(sb54.toString());
        final StringBuilder sb55 = new StringBuilder();
        sb55.append("1 vertical upperArr :: ");
        sb55.append(list.toString());
        final StringBuilder sb56 = new StringBuilder();
        sb56.append("1 vertical upperArr :: ");
        sb56.append(list.toString());
        return list2.toArray(new String[list.size()]);
    }

    private void updateInMillisecond(final float n) {
        new Handler(Looper.getMainLooper()).post((Runnable) new Runnable() {
            @Override
            public void run() {
                final ProcessVideo this$0 = ProcessVideo.this;
                this$0.percentage = n * 100.0 / (this$0.totalSecond / 1000.0f);
                if (ProcessVideo.this.percentage + 2.0 > 100.0) {
                    ProcessVideo.this.percentage = 100.0;
                } else {
                    final ProcessVideo this$2 = ProcessVideo.this;
                    this$2.percentage += 2.0;
                }
                Window window = progressDialog.getWindow();
                window.setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
                final ProgressDialog access$300 = ProcessVideo.this.progressDialog;

                final StringBuilder sb = new StringBuilder();
                sb.append("Creating Collage...");
                sb.append(String.format("%.0f", ProcessVideo.this.percentage));
                sb.append("%");
                access$300.setMessage((CharSequence) sb.toString());
            }
        });
    }

    public String convertSecondsToHMmSs(final long n) {
        return String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(n), TimeUnit.MILLISECONDS.toMinutes(n) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(n)), TimeUnit.MILLISECONDS.toSeconds(n) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n)));
    }

    protected Integer doInBackground(final Void... array) {
        if (this.cnt == this.length) {
            return 1;
        }
        final ArrayList<String> list = new ArrayList<String>();
        final StringBuilder sb = new StringBuilder();
        final StringBuilder sb2 = new StringBuilder();
        final StringBuilder sb3 = new StringBuilder("out");
        String[] array2 = null;
        Label_0957:
        {
            if (this.bitmapPaint.size() == 2) {
                final int themeId = this.themeId;
                if (themeId == 0 || themeId == 2 || themeId == 3) {
                    array2 = this.twoXTwoVertical(list, sb, "", "", "", "", "", sb2, 0, sb3);
                    break Label_0957;
                }
            }
            if (this.bitmapPaint.size() == 2) {
                final int themeId2 = this.themeId;
                if (themeId2 == 1 || themeId2 == 4 || themeId2 == 5) {
                    array2 = this.twoXTwoHorizontal(list, sb, "", "", "", "", "", sb2, 0, sb3);
                    break Label_0957;
                }
            }
            if (this.bitmapPaint.size() == 3 && this.themeId == 0) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 3 && this.themeId == 1) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 3 && this.themeId == 2) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 3 && this.themeId == 3) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 3 && this.themeId == 4) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 3 && this.themeId == 5) {
                array2 = this.three(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 0) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 1) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 2) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 3) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 4) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else if (this.bitmapPaint.size() == 4 && this.themeId == 5) {
                array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
            } else {
                if (this.bitmapPaint.size() == 4) {
                    final int themeId3 = this.themeId;
                    if (themeId3 == 6 || themeId3 == 7) {
                        array2 = this.four(list, sb, "", "", "", "", "", sb2, 0, sb3, this.themeId);
                        break Label_0957;
                    }
                }
                array2 = null;
            }
        }
        final int execute = FFmpeg.execute(array2);
        if (execute == 0) {
        } else if (execute == 255) {
        } else {
            Config.printLastCommandOutput(4);
        }
        return 0;
    }

    protected void onPostExecute(final Integer n) {
        final ProgressDialog progressDialog = this.progressDialog;
        if (progressDialog != null && progressDialog.isShowing()) {
            this.progressDialog.dismiss();
        }
        if (n == 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.context.getCacheDir());
            sb.append("/tempstikerimages");
            Util.deleteTempDir(new File(sb.toString()));
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(this.context.getCacheDir());
            sb2.append("/tempbgimages");
            Util.deleteTempDir(new File(sb2.toString()));
            final StringBuilder sb3 = new StringBuilder();
            sb3.append(this.context.getCacheDir());
            sb3.append("/tempgridimages");
            Util.deleteTempDir(new File(sb3.toString()));
            final StringBuilder sb4 = new StringBuilder();
            sb4.append(this.context.getCacheDir());
            sb4.append("/temptrimvideo");
            Util.deleteTempDir(new File(sb4.toString()));
            final StringBuilder sb5 = new StringBuilder();
            sb5.append(this.context.getCacheDir());
            sb5.append("/temptransparentimages");
            Util.deleteTempDir(new File(sb5.toString()));
            final StringBuilder sb6 = new StringBuilder();
            sb6.append(this.context.getCacheDir());
            sb6.append("/tempvidthumbimages");
            Util.deleteTempDir(new File(sb6.toString()));
            Util.deleteCache(this.context);
            MediaScannerConnection.scanFile(this.context, new String[]{this.videoName}, new String[]{"mp4"}, (MediaScannerConnection.OnScanCompletedListener) null);
            final File file = new File(this.videoName);
            ((GridActivity) this.context).sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
            final Intent intent = new Intent(this.context, (Class) ShareActivity.class);
            intent.putExtra("SELECTED_PATH", file.getAbsolutePath());
            intent.putExtra("FROM", "GRID");
            context.startActivity(intent);
            ((GridActivity) this.context).finish();
            Toast.makeText(this.context, (CharSequence) "save successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this.context, (CharSequence) "something want wrong", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("ResourceType")
    protected void onPreExecute() {
        ((GridActivity) this.context).getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        final StringBuilder sb = new StringBuilder();
        sb.append(this.baseViewWidth);
        sb.append("X");
        sb.append(this.baseViewHeight);
        this.screenBase = sb.toString();

        (this.progressDialog = new ProgressDialog(this.context, 2131886083)).setMessage((CharSequence) "Creating Collage...");
        this.progressDialog.setCancelable(false);
        Window window = progressDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        this.progressDialog.show();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append("VEditor");
        sb2.append("/Video");
        final String string = sb2.toString();
        final File file = new File(string);
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append(string);
        sb3.append("/Video_Collage_");
        sb3.append(System.currentTimeMillis());
        sb3.append(".mp4");
        this.videoName = sb3.toString();
        this.totalSecond = (float) this.totalDuration;
    }

    public String saveTransparentImage() {
        final Bitmap decodeResource = BitmapFactory.decodeResource(this.context.getResources(), 2131231172);
        final int nextInt = new Random().nextInt(10000);
        final StringBuilder sb = new StringBuilder();
        sb.append("Img-");
        sb.append(nextInt);
        sb.append(".png");
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(this.context.getCacheDir());
        sb2.append("/temptransparentimages");
        final File file = new File(sb2.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        final File file2 = new File(file, string);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            decodeResource.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream) fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return file2.getAbsolutePath();
    }

    public String saveVideoThumb(final String s) {
        final Bitmap videoThumbnail = ThumbnailUtils.createVideoThumbnail(s, 2);
        final int nextInt = new Random().nextInt(10000);
        final StringBuilder sb = new StringBuilder();
        sb.append("Vidthum-");
        sb.append(nextInt);
        sb.append(".png");
        final String string = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(this.context.getCacheDir());
        sb2.append("/tempvidthumbimages");
        final File file = new File(sb2.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        final File file2 = new File(file, string);
        if (file2.exists()) {
            file2.delete();
        }
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            videoThumbnail.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream) fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return file2.getAbsolutePath();
    }
}
