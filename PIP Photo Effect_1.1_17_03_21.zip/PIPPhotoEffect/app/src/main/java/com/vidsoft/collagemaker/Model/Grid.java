package com.vidsoft.collagemaker.Model;

public class Grid
{
  int layout;
  int thumb;
  int title;
  int type;

  public Grid(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.thumb = paramInt1;
    this.layout = paramInt2;
    this.title = paramInt3;
    this.type = paramInt4;
  }

  public int getLayout()
  {
    return this.layout;
  }

  public int getThumb()
  {
    return this.thumb;
  }

  public int getTitle()
  {
    return this.title;
  }

  public int getType()
  {
    return this.type;
  }

  public void setLayout(int paramInt)
  {
    this.layout = paramInt;
  }

  public void setThumb(int paramInt)
  {
    this.thumb = paramInt;
  }

  public void setTitle(int paramInt)
  {
    this.title = paramInt;
  }

  public void setType(int paramInt)
  {
    this.type = paramInt;
  }
}