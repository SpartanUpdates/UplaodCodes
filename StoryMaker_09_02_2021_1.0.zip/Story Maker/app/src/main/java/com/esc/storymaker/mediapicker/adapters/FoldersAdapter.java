package com.esc.storymaker.mediapicker.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.esc.storymaker.R;
import com.esc.storymaker.mediapicker.utils.ScreenUtil;

import java.util.List;

public class FoldersAdapter extends RecyclerView.Adapter<FoldersAdapter.MyViewHolder> {
    private Activity activity;
    private List<String> bitmapList;
    private List<String> folderNames;

    public class MyViewHolder extends ViewHolder {
        public TextView count;
        public ImageView thumbnail;
        public TextView title;

        public MyViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.tv_title);
            this.count = (TextView) view.findViewById(R.id.tv_count);
            this.thumbnail = (ImageView) view.findViewById(R.id.iv_thumb);
        }
    }

    public FoldersAdapter(Activity activity, List<String> list, List<String> list2) {
        this.folderNames = list;
        this.bitmapList = list2;
        this.activity = activity;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_folder, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.thumbnail.getLayoutParams().width = ScreenUtil.getScreenWidth(this.activity) / 3;
        myViewHolder.thumbnail.getLayoutParams().height = ScreenUtil.getScreenWidth(this.activity) / 3;
        myViewHolder.title.setText((CharSequence) this.folderNames.get(i));
        RequestManager with = Glide.with(this.activity);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file://");
        stringBuilder.append((String) this.bitmapList.get(i));
        with.load(stringBuilder.toString()).into(myViewHolder.thumbnail);
    }

    public int getItemCount() {
        return this.folderNames.size();
    }
}
