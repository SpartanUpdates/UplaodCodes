﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeSingle : MonoBehaviour
{
    public GameObject InterstitialAds, BannerAds, RewaredAds;

    public void Awake()
    {
        GameObject go = GameObject.FindGameObjectWithTag("AddManager");
        {
            if (go == null)
                Instantiate(BannerAds);
        }
        GameObject go1 = GameObject.FindGameObjectWithTag("AddManager2");
        {
            if (go1 == null)
                Instantiate(InterstitialAds);
        }
        GameObject go2 = GameObject.FindGameObjectWithTag("AddManager3");
        {
            if (go2 == null)
                Instantiate(RewaredAds);
        }
    }
}
