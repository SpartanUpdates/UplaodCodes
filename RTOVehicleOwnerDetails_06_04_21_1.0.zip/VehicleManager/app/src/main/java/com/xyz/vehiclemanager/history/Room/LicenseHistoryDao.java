package com.xyz.vehiclemanager.history.Room;

import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.xyz.vehiclemanager.history.Model.LicenseHistory;

import java.util.List;

@androidx.room.Dao
public interface LicenseHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertLicenseData(LicenseHistory licenseHistory);

    @Query("select * from LicenseHistory")
    List<LicenseHistory> getLicenseHistory();

    @Query(" Delete from LicenseHistory where licenseNo=:licenseNo")
    void deleteOwnerDetails(String licenseNo);

}
