package com.jenilcreation.photomusicvideo.mask;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Xfermode;

import java.lang.reflect.Array;
import java.util.Random;

public class MaskBitmap {
//	public static float ANIMATED_FRAME;
//	public static int ANIMATED_FRAME_CAL;
//	public static int ORIGANAL_FRAME;
//	public static int TOTAL_FRAME;
//	static final Paint pnt;
//	static int[][] rand_rect;
//	static Random random;
//	static final int HORIZONTAL = 0;
//	static final int VERTICALE = 1;
//	private static int averageHeight;
//	private static int averageWidth;
//	private static float axisX;
//	private static float axisY;
//	private static Bitmap[][] bitmaps;
//	private static Camera camera = new Camera();
//	public static int direction = 0;
//	private static Matrix matrix = new Matrix();
//	static final Paint paint = new Paint();
//	private static int partNumber = 8;
//	static int[][] randRect;
//	public static EFFECT rollMode;
//	private static float rotateDegree;
//
//	public enum EFFECT {
//		CIRCLE_LEFT_TOP("CIRCLE LEFT TOP") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawCircle(
//						0.0f,
//						0.0f,
//						(((float) Math.sqrt((double) ((w * w) + (h * h)))) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//								* ((float) factor), paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CIRCLE_RIGHT_TOP("Circle right top") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawCircle(
//						(float) w,
//						0.0f,
//						(((float) Math.sqrt((double) ((w * w) + (h * h)))) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//								* ((float) factor), paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CIRCLE_LEFT_BOTTOM("Circle left bottom") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawCircle(
//						0.0f,
//						(float) h,
//						(((float) Math.sqrt((double) ((w * w) + (h * h)))) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//								* ((float) factor), paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CIRCLE_RIGHT_BOTTOM("Circle right bottom") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawCircle(
//						(float) w,
//						(float) h,
//						(((float) Math.sqrt((double) ((w * w) + (h * h)))) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//								* ((float) factor), paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CIRCLE_IN("Circle in") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint(1);
//				paint.setColor(-16777216);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float r = MaskBitmap.getRad(w * 2, h * 2);
//				float f = (r / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				paint.setColor(-16777216);
//				canvas.drawColor(-16777216);
//				paint.setColor(0);
//				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
//				canvas.drawCircle(((float) w) / 2.0f, ((float) h) / 2.0f,
//						r - f, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CIRCLE_OUT("Circle out") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawCircle(
//						((float) w) / 2.0f,
//						((float) h) / 2.0f,
//						(MaskBitmap.getRad(w * 2, h * 2) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//								* ((float) factor), paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CROSS_IN("Cross in") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float fx = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float fy = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, 0.0f);
//				path.lineTo(fx, 0.0f);
//				path.lineTo(fx, fy);
//				path.lineTo(0.0f, fy);
//				path.lineTo(0.0f, 0.0f);
//				path.close();
//				path.moveTo((float) w, 0.0f);
//				path.lineTo(((float) w) - fx, 0.0f);
//				path.lineTo(((float) w) - fx, fy);
//				path.lineTo((float) w, fy);
//				path.lineTo((float) w, 0.0f);
//				path.close();
//				path.moveTo((float) w, (float) h);
//				path.lineTo(((float) w) - fx, (float) h);
//				path.lineTo(((float) w) - fx, ((float) h) - fy);
//				path.lineTo((float) w, ((float) h) - fy);
//				path.lineTo((float) w, (float) h);
//				path.close();
//				path.moveTo(0.0f, (float) h);
//				path.lineTo(fx, (float) h);
//				path.lineTo(fx, ((float) h) - fy);
//				path.lineTo(0.0f, ((float) h) - fy);
//				path.lineTo(0.0f, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		CROSS_OUT("Cross out") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float fx = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float fy = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo((((float) w) / 2.0f) + fx, 0.0f);
//				path.lineTo((((float) w) / 2.0f) + fx, (((float) h) / 2.0f)
//						- fy);
//				path.lineTo((float) w, (((float) h) / 2.0f) - fy);
//				path.lineTo((float) w, (((float) h) / 2.0f) + fy);
//				path.lineTo((((float) w) / 2.0f) + fx, (((float) h) / 2.0f)
//						+ fy);
//				path.lineTo((((float) w) / 2.0f) + fx, (float) h);
//				path.lineTo((((float) w) / 2.0f) - fx, (float) h);
//				path.lineTo((((float) w) / 2.0f) - fx, (((float) h) / 2.0f)
//						- fy);
//				path.lineTo(0.0f, (((float) h) / 2.0f) - fy);
//				path.lineTo(0.0f, (((float) h) / 2.0f) + fy);
//				path.lineTo((((float) w) / 2.0f) - fx, (((float) h) / 2.0f)
//						+ fy);
//				path.lineTo((((float) w) / 2.0f) - fx, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		DIAMOND_IN("Diamond in") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				Path path = new Path();
//				float fx = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float fy = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				path.moveTo(((float) w) / 2.0f, (((float) h) / 2.0f) - fy);
//				path.lineTo((((float) w) / 2.0f) + fx, ((float) h) / 2.0f);
//				path.lineTo(((float) w) / 2.0f, (((float) h) / 2.0f) + fy);
//				path.lineTo((((float) w) / 2.0f) - fx, ((float) h) / 2.0f);
//				path.lineTo(((float) w) / 2.0f, (((float) h) / 2.0f) - fy);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		DIAMOND_OUT("Diamond out") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint(1);
//				paint.setColor(-16777216);
//				paint.setColor(0);
//				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				canvas.drawColor(-16777216);
//				Path path = new Path();
//				float fx = ((float) w)
//						- ((((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL)) * ((float) factor));
//				float fy = ((float) h)
//						- ((((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL)) * ((float) factor));
//				path.moveTo(((float) w) / 2.0f, (((float) h) / 2.0f) - fy);
//				path.lineTo((((float) w) / 2.0f) + fx, ((float) h) / 2.0f);
//				path.lineTo(((float) w) / 2.0f, (((float) h) / 2.0f) + fy);
//				path.lineTo((((float) w) / 2.0f) - fx, ((float) h) / 2.0f);
//				path.lineTo(((float) w) / 2.0f, (((float) h) / 2.0f) - fy);
//				path.close();
//				paint.setColor(0);
//				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
//				canvas.drawPath(path, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		ECLIPSE_IN("Eclipse in") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float hf = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float wf = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				RectF rectFL = new RectF(-wf, 0.0f, wf, (float) h);
//				RectF rectFT = new RectF(0.0f, -hf, (float) w, hf);
//				RectF rectFR = new RectF(((float) w) - wf, 0.0f, ((float) w)
//						+ wf, (float) h);
//				RectF rectFB = new RectF(0.0f, ((float) h) - hf, (float) w,
//						((float) h) + hf);
//				canvas.drawOval(rectFL, MaskBitmap.pnt);
//				canvas.drawOval(rectFT, MaskBitmap.pnt);
//				canvas.drawOval(rectFR, MaskBitmap.pnt);
//				canvas.drawOval(rectFB, MaskBitmap.pnt);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		FOUR_TRIANGLE("Four triangle") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float ratioY = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, ratioY);
//				path.lineTo(0.0f, 0.0f);
//				path.lineTo(ratioX, 0.0f);
//				path.lineTo((float) w, ((float) h) - ratioY);
//				path.lineTo((float) w, (float) h);
//				path.lineTo(((float) w) - ratioX, (float) h);
//				path.lineTo(0.0f, ratioY);
//				path.close();
//				path.moveTo(((float) w) - ratioX, 0.0f);
//				path.lineTo((float) w, 0.0f);
//				path.lineTo((float) w, ratioY);
//				path.lineTo(ratioX, (float) h);
//				path.lineTo(0.0f, (float) h);
//				path.lineTo(0.0f, ((float) h) - ratioY);
//				path.lineTo(((float) w) - ratioX, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		HORIZONTAL_RECT("Horizontal rect") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				float wf = ((float) w) / 10.0f;
//				float rectW = (wf / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				for (int i = 0; i < 10; i++) {
//					canvas.drawRect(new Rect((int) (((float) i) * wf), 0,
//							(int) ((((float) i) * wf) + rectW), h), paint);
//				}
//				drawText(canvas);
//				return mask;
//			}
//		},
//		HORIZONTAL_COLUMN_DOWNMASK("Horizontal column downmask") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float factorX = ((float) MaskBitmap.ANIMATED_FRAME_CAL) / 2.0f;
//				canvas.drawRoundRect(
//						new RectF(
//								0.0f,
//								0.0f,
//								(((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) / 2.0f))
//										* ((float) factor), ((float) h) / 2.0f),
//						0.0f, 0.0f, paint);
//				if (((float) factor) >= 0.5f + factorX) {
//					canvas.drawRoundRect(
//							new RectF(
//									((float) w)
//											- ((((float) w) / (((float) (MaskBitmap.ANIMATED_FRAME_CAL - 1)) / 2.0f)) * ((float) ((int) (((float) factor) - factorX)))),
//									((float) h) / 2.0f, (float) w, (float) h),
//							0.0f, 0.0f, paint);
//				}
//				return mask;
//			}
//		},
//		LEAF("LEAF") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setStrokeCap(Cap.BUTT);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				float fx = (float) ((w / MaskBitmap.ANIMATED_FRAME_CAL) * factor);
//				float fy = (float) ((h / MaskBitmap.ANIMATED_FRAME_CAL) * factor);
//				Canvas canvas = new Canvas(mask);
//				Path path = new Path();
//				path.moveTo(0.0f, (float) h);
//				path.cubicTo(0.0f, (float) h, (((float) w) / 2.0f) - fx,
//						(((float) h) / 2.0f) - fy, (float) w, 0.0f);
//				path.cubicTo((float) w, 0.0f, (((float) w) / 2.0f) + fx,
//						(((float) h) / 2.0f) + fy, 0.0f, (float) h);
//				path.close();
//				canvas.drawPath(path, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		OPEN_DOOR("OPEN_DOOR") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setStrokeCap(Cap.BUTT);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				float fx = (float) ((w / MaskBitmap.ANIMATED_FRAME_CAL) * factor);
//				float fy = (float) ((h / MaskBitmap.ANIMATED_FRAME_CAL) * factor);
//				Canvas canvas = new Canvas(mask);
//				Path path = new Path();
//				path.moveTo((float) (w / 2), 0.0f);
//				path.lineTo(((float) (w / 2)) - fx, 0.0f);
//				path.lineTo(((float) (w / 2)) - (fx / 2.0f), (float) (h / 6));
//				path.lineTo(((float) (w / 2)) - (fx / 2.0f),
//						(float) (h - (h / 6)));
//				path.lineTo(((float) (w / 2)) - fx, (float) h);
//				path.lineTo(((float) (w / 2)) + fx, (float) h);
//				path.lineTo(((float) (w / 2)) + (fx / 2.0f),
//						(float) (h - (h / 6)));
//				path.lineTo(((float) (w / 2)) + (fx / 2.0f), (float) (h / 6));
//				path.lineTo(((float) (w / 2)) + fx, 0.0f);
//				path.lineTo(((float) (w / 2)) - fx, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				drawText(canvas);
//				return mask;
//			}
//		},
//		PIN_WHEEL("PIN_WHEEL") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float rationX = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float rationY = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(((float) w) / 2.0f, ((float) h) / 2.0f);
//				path.lineTo(0.0f, (float) h);
//				path.lineTo(rationX, (float) h);
//				path.close();
//				path.moveTo(((float) w) / 2.0f, ((float) h) / 2.0f);
//				path.lineTo((float) w, (float) h);
//				path.lineTo((float) w, ((float) h) - rationY);
//				path.close();
//				path.moveTo(((float) w) / 2.0f, ((float) h) / 2.0f);
//				path.lineTo((float) w, 0.0f);
//				path.lineTo(((float) w) - rationX, 0.0f);
//				path.close();
//				path.moveTo(((float) w) / 2.0f, ((float) h) / 2.0f);
//				path.lineTo(0.0f, 0.0f);
//				path.lineTo(0.0f, rationY);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		RECT_RANDOM("RECT_RANDOM") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				float wf = (float) (w / MaskBitmap.ANIMATED_FRAME_CAL);
//				float hf = (float) (h / MaskBitmap.ANIMATED_FRAME_CAL);
//				for (int i = 0; i < MaskBitmap.rand_rect.length; i++) {
//					int rand = MaskBitmap.random
//							.nextInt(MaskBitmap.rand_rect[i].length);
//					while (MaskBitmap.rand_rect[i][rand] == 1) {
//						rand = MaskBitmap.random
//								.nextInt(MaskBitmap.rand_rect[i].length);
//					}
//					MaskBitmap.rand_rect[i][rand] = 1;
//					for (int j = 0; j < MaskBitmap.rand_rect[i].length; j++) {
//						if (MaskBitmap.rand_rect[i][j] == 1) {
//							canvas.drawRoundRect(
//									new RectF(
//											((float) i) * wf,
//											((float) j) * hf,
//											(((float) i) + 1.0f)
//													* wf,
//											(((float) j) + 1.0f)
//													* hf), 0.0f, 0.0f, paint);
//						}
//					}
//				}
//				drawText(canvas);
//				return mask;
//			}
//		},
//		SKEW_LEFT_MEARGE("SKEW_LEFT_MEARGE") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float ratioY = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, ratioY);
//				path.lineTo(ratioX, 0.0f);
//				path.lineTo(0.0f, 0.0f);
//				path.close();
//				path.moveTo(((float) w) - ratioX, (float) h);
//				path.lineTo((float) w, ((float) h) - ratioY);
//				path.lineTo((float) w, (float) h);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		SKEW_LEFT_SPLIT("SKEW_LEFT_SPLIT") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float ratioY = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, ratioY);
//				path.lineTo(0.0f, 0.0f);
//				path.lineTo(ratioX, 0.0f);
//				path.lineTo((float) w, ((float) h) - ratioY);
//				path.lineTo((float) w, (float) h);
//				path.lineTo(((float) w) - ratioX, (float) h);
//				path.lineTo(0.0f, ratioY);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		SKEW_RIGHT_SPLIT("SKEW_RIGHT_SPLIT") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float ratioY = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(((float) w) - ratioX, 0.0f);
//				path.lineTo((float) w, 0.0f);
//				path.lineTo((float) w, ratioY);
//				path.lineTo(ratioX, (float) h);
//				path.lineTo(0.0f, (float) h);
//				path.lineTo(0.0f, ((float) h) - ratioY);
//				path.lineTo(((float) w) - ratioX, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		SKEW_RIGHT_MEARGE("SKEW_RIGHT_MEARGE") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				float ratioY = (((float) h) / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, ((float) h) - ratioY);
//				path.lineTo(ratioX, (float) h);
//				path.lineTo(0.0f, (float) h);
//				path.close();
//				path.moveTo(((float) w) - ratioX, 0.0f);
//				path.lineTo((float) w, ratioY);
//				path.lineTo((float) w, 0.0f);
//				path.close();
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		SQUARE_IN("SQUARE_IN") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				float ratioX = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float ratioY = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				Path path = new Path();
//				path.moveTo(0.0f, 0.0f);
//				path.lineTo(0.0f, (float) h);
//				path.lineTo(ratioX, (float) h);
//				path.lineTo(ratioX, 0.0f);
//				path.moveTo((float) w, (float) h);
//				path.lineTo((float) w, 0.0f);
//				path.lineTo(((float) w) - ratioX, 0.0f);
//				path.lineTo(((float) w) - ratioX, (float) h);
//				path.moveTo(ratioX, ratioY);
//				path.lineTo(ratioX, 0.0f);
//				path.lineTo(((float) w) - ratioX, 0.0f);
//				path.lineTo(((float) w) - ratioX, ratioY);
//				path.moveTo(ratioX, ((float) h) - ratioY);
//				path.lineTo(ratioX, (float) h);
//				path.lineTo(((float) w) - ratioX, (float) h);
//				path.lineTo(((float) w) - ratioX, ((float) h) - ratioY);
//				canvas.drawPath(path, paint);
//				return mask;
//			}
//		},
//		SQUARE_OUT("SQUARE_OUT") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				float ratioX = (((float) w) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				float ratioY = (((float) h) / (((float) MaskBitmap.ANIMATED_FRAME_CAL) * 2.0f))
//						* ((float) factor);
//				new Canvas(mask).drawRect(new RectF(((float) (w / 2)) - ratioX,
//						((float) (h / 2)) - ratioY, ((float) (w / 2)) + ratioX,
//						((float) (h / 2)) + ratioY), paint);
//				return mask;
//			}
//		},
//		VERTICAL_RECT("VERTICAL_RECT") {
//			public Bitmap getMask(int w, int h, int factor) {
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				float hf = ((float) h) / 10.0f;
//				float rectH = (((float) factor) * hf)
//						/ ((float) MaskBitmap.ANIMATED_FRAME_CAL);
//				for (int i = 0; i < 10; i++) {
//					canvas.drawRect(new Rect(0, (int) (((float) i) * hf), w,
//							(int) ((((float) i) * hf) + rectH)), paint);
//				}
//				drawText(canvas);
//				return mask;
//			}
//		},
//		WIND_MILL("WIND_MILL") {
//			public Bitmap getMask(int w, int h, int factor) {
//				float r = MaskBitmap.getRad(w, h);
//				Paint paint = new Paint();
//				paint.setColor(-16777216);
//				paint.setAntiAlias(true);
//				paint.setStyle(Style.FILL_AND_STROKE);
//				Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//				Canvas canvas = new Canvas(mask);
//				RectF oval = new RectF();
//				oval.set((((float) w) / 2.0f) - r, (((float) h) / 2.0f) - r,
//						(((float) w) / 2.0f) + r, (((float) h) / 2.0f) + r);
//				float angle = (90.0f / ((float) MaskBitmap.ANIMATED_FRAME_CAL))
//						* ((float) factor);
//				canvas.drawArc(oval, 90.0f, angle, true, paint);
//				canvas.drawArc(oval, 180.0F, angle,
//						true, paint);
//				canvas.drawArc(oval, 270.0F, angle,
//						true, paint);
//				canvas.drawArc(oval, 360.0f, angle, true, paint);
//				drawText(canvas);
//				return mask;
//			}
//		};
//
//		String name;
//
//		public abstract Bitmap getMask(int i, int i2, int i3);
//
//		private EFFECT(String name) {
//			this.name = "";
//			this.name = name;
//		}
//
//		public void drawText(Canvas canvas) {
//			Paint paint = new Paint();
//			paint.setTextSize(50.0f);
//			paint.setColor(SupportMenu.CATEGORY_MASK);
//		}
//	}
//
//	public static void setRotateDegree(int factor) {
//		int i = 90;
//		rotateDegree = (((float) factor) * 90.0f)
//				/ ((float) ANIMATED_FRAME_CAL);
//		if (direction == 1) {
//			float f = rotateDegree;
//			axisY = (f / ((float) i)) * ((float) MyApplication.VIDEO_HEIGHT);
//			return;
//		}
//		float f = rotateDegree;
//		axisX = (f / ((float) i)) * ((float) MyApplication.VIDEO_HEIGHT);
//	}
//
//	static {
//		TOTAL_FRAME = 30;
//		ORIGANAL_FRAME = 8;
//		ANIMATED_FRAME = 22.0f;
//		ANIMATED_FRAME_CAL = (int) (ANIMATED_FRAME - 1.0f);
//		rand_rect = (int[][]) Array.newInstance(Integer.TYPE, new int[] { 20,
//				20 });
//		random = new Random();
//		pnt = new Paint();
//		pnt.setColor(-16777216);
//		pnt.setAntiAlias(true);
//		pnt.setStyle(Style.FILL_AND_STROKE);
//	}
//
//	public static void reintRect() {
//		rand_rect = (int[][]) Array.newInstance(Integer.TYPE, new int[] {
//				(int) ANIMATED_FRAME, (int) ANIMATED_FRAME });
//		for (int i = 0; i < rand_rect.length; i++) {
//			for (int j = 0; j < rand_rect[i].length; j++) {
//				rand_rect[i][j] = 0;
//			}
//		}
//	}
//
//	public static Paint getPaint() {
//		pnt.setColor(-16777216);
//		pnt.setAntiAlias(true);
//		pnt.setStyle(Style.FILL_AND_STROKE);
//		return pnt;
//	}
//
//	static float getRad(int w, int h) {
//		return (float) Math.sqrt((double) (((w * w) + (h * h)) / 4));
//	}
//
//	static Bitmap getHorizontalColumnDownMask(int w, int h, int factor) {
//		Paint paint = new Paint();
//		paint.setColor(-16777216);
//		paint.setAntiAlias(true);
//		paint.setStyle(Style.FILL_AND_STROKE);
//		Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//		Canvas canvas = new Canvas(mask);
//		float factorX = ((float) ANIMATED_FRAME_CAL) / 2.0f;
//		canvas.drawRoundRect(new RectF(0.0f, 0.0f,
//				(((float) w) / (((float) ANIMATED_FRAME_CAL) / 2.0f))
//						* ((float) factor), ((float) h) / 2.0f), 0.0f, 0.0f,
//				paint);
//		if (((float) factor) >= 0.5f + factorX) {
//			canvas.drawRoundRect(
//					new RectF(
//							((float) w)
//									- ((((float) w) / (((float) (ANIMATED_FRAME_CAL - 1)) / 2.0f)) * ((float) ((int) (((float) factor) - factorX)))),
//							((float) h) / 2.0f, (float) w, (float) h), 0.0f,
//					0.0f, paint);
//		}
//		return mask;
//	}
//
//	static Bitmap getRandomRectHoriMask(int w, int h, int factor) {
//		Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//		Canvas canvas = new Canvas(mask);
//		Paint paint = new Paint();
//		paint.setColor(-16777216);
//		paint.setAntiAlias(true);
//		paint.setStyle(Style.FILL_AND_STROKE);
//		float wf = ((float) w) / 10.0f;
//		float rectW = factor == 0 ? 0.0f : (((float) factor) * wf) / 9.0f;
//		for (int i = 0; i < 10; i++) {
//			canvas.drawRect(new Rect((int) (((float) i) * wf), 0,
//					(int) ((((float) i) * wf) + rectW), h), paint);
//		}
//		return mask;
//	}
//
//	static Bitmap getNewMask(int w, int h, int factor) {
//		Paint paint = new Paint();
//		paint.setColor(-16777216);
//		paint.setAntiAlias(true);
//		paint.setStyle(Style.FILL_AND_STROKE);
//		Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//		Canvas canvas = new Canvas(mask);
//		float ratioX = (((float) w) / 18.0f) * ((float) factor);
//		float ratioY = (((float) h) / 18.0f) * ((float) factor);
//		Path path = new Path();
//		path.moveTo((float) (w / 2), (float) (h / 2));
//		path.lineTo(((float) (w / 2)) + ratioX, (float) (h / 2));
//		path.lineTo((float) w, 0.0f);
//		path.lineTo((float) (w / 2), ((float) (h / 2)) - ratioY);
//		path.lineTo((float) (w / 2), (float) (h / 2));
//		path.moveTo((float) (w / 2), (float) (h / 2));
//		path.lineTo(((float) (w / 2)) - ratioX, (float) (h / 2));
//		path.lineTo(0.0f, 0.0f);
//		path.lineTo((float) (w / 2), ((float) (h / 2)) - ratioY);
//		path.lineTo((float) (w / 2), (float) (h / 2));
//		path.moveTo((float) (w / 2), (float) (h / 2));
//		path.lineTo(((float) (w / 2)) - ratioX, (float) (h / 2));
//		path.lineTo(0.0f, (float) h);
//		path.lineTo((float) (w / 2), ((float) (h / 2)) + ratioY);
//		path.lineTo((float) (w / 2), (float) (h / 2));
//		path.moveTo((float) (w / 2), (float) (h / 2));
//		path.lineTo(((float) (w / 2)) + ratioX, (float) (h / 2));
//		path.lineTo((float) w, (float) h);
//		path.lineTo((float) (w / 2), ((float) (h / 2)) + ratioY);
//		path.lineTo((float) (w / 2), (float) (h / 2));
//		path.close();
//		canvas.drawCircle(((float) w) / 2.0f, ((float) h) / 2.0f,
//				(((float) w) / 18.0f) * ((float) factor), paint);
//		canvas.drawPath(path, paint);
//		return mask;
//	}
//
//	public static Bitmap getRadialBitmap(int w, int h, int factor) {
//		Bitmap mask = Bitmap.createBitmap(w, h, Config.ARGB_8888);
//		if (factor != 0) {
//			Canvas canvas = new Canvas(mask);
//			if (factor == 9) {
//				canvas.drawColor(-16777216);
//			} else {
//				pnt.setStyle(Style.STROKE);
//				float radius = getRad(w, h);
//				pnt.setStrokeWidth((radius / 80.0f) * ((float) factor));
//				for (int i = 0; i < 11; i++) {
//					canvas.drawCircle(((float) w) / 2.0f, ((float) h) / 2.0f,
//							(radius / 10.0f) * ((float) i), pnt);
//				}
//			}
//		}
//		return mask;
//	}
//}


    public static float ANIMATED_FRAME = 22.0f;
    public static int ANIMATED_FRAME_CAL;
    public static int ORIGANAL_FRAME;
    public static int TOTAL_FRAME;
    static final Paint a;
    static int[][] b;
    static Random c;

    static {
        MaskBitmap.ANIMATED_FRAME_CAL = (int) (MaskBitmap.ANIMATED_FRAME - 1.0f);
        MaskBitmap.ORIGANAL_FRAME = 8;
        MaskBitmap.TOTAL_FRAME = 30;
        a = new Paint();
        MaskBitmap.b = (int[][]) Array.newInstance(Integer.TYPE, 20, 20);
        MaskBitmap.c = new Random();
        MaskBitmap.a.setColor(-16777216);
        MaskBitmap.a.setAntiAlias(true);
        MaskBitmap.a.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    static float a(final int n, final int n2) {
        return (float) Math.sqrt((n * n + n2 * n2) / 4);
    }

    public static Paint getPaint() {
        MaskBitmap.a.setColor(-16777216);
        MaskBitmap.a.setAntiAlias(true);
        MaskBitmap.a.setStyle(Paint.Style.FILL_AND_STROKE);
        return MaskBitmap.a;
    }

    public static Bitmap getRadialBitmap(final int n, final int n2, int i) {
        final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
        if (i != 0) {
            final Canvas canvas = new Canvas(bitmap);
            if (i == 9) {
                canvas.drawColor(-16777216);
                return bitmap;
            }
            MaskBitmap.a.setStyle(Paint.Style.STROKE);
            final float a = a(n, n2);
            MaskBitmap.a.setStrokeWidth(a / 80.0f * i);
            for (i = 0; i < 11; ++i) {
                canvas.drawCircle(n / 2.0f, n2 / 2.0f, a / 10.0f * i, MaskBitmap.a);
            }
        }
        return bitmap;
    }

    public static void reintRect() {
        MaskBitmap.b = (int[][]) Array.newInstance(Integer.TYPE, (int) MaskBitmap.ANIMATED_FRAME, (int) MaskBitmap.ANIMATED_FRAME);
        for (int i = 0; i < MaskBitmap.b.length; ++i) {
            for (int j = 0; j < MaskBitmap.b[i].length; ++j) {
                MaskBitmap.b[i][j] = 0;
            }
        }
    }

    public enum EFFECT {
        CIRCLE_IN("Circle in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint(1);
                paint.setColor(-16777216);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float a = MaskBitmap.a(n * 2, n2 * 2);
                final float n4 = a / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n5 = n3;
                paint.setColor(-16777216);
                canvas.drawColor(-16777216);
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                canvas.drawCircle(n / 2.0f, n2 / 2.0f, a - n4 * n5, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_LEFT_BOTTOM("Circle left bottom") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(0.0f, (float) n2, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_LEFT_TOP("CIRCLE LEFT TOP") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(0.0f, 0.0f, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_OUT("Circle out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle(n / 2.0f, n2 / 2.0f, MaskBitmap.a(n * 2, n2 * 2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_RIGHT_BOTTOM("Circle right bottom") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle((float) n, (float) n2, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CIRCLE_RIGHT_TOP("Circle right top") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawCircle((float) n, 0.0f, (float) Math.sqrt(n * n + n2 * n2) / MaskBitmap.ANIMATED_FRAME_CAL * n3, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CROSS_IN("Cross in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                path.lineTo(n7, n9);
                path.lineTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.close();
                path.moveTo(n4, 0.0f);
                final float n10 = n4 - n7;
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n9);
                path.lineTo(n4, n9);
                path.lineTo(n4, 0.0f);
                path.close();
                path.moveTo(n4, n8);
                path.lineTo(n10, n8);
                final float n11 = n8 - n9;
                path.lineTo(n10, n11);
                path.lineTo(n4, n11);
                path.lineTo(n4, n8);
                path.close();
                path.moveTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.lineTo(n7, n11);
                path.lineTo(0.0f, n11);
                path.lineTo(0.0f, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        CROSS_OUT("Cross out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                final float n10 = n4 / 2.0f;
                final float n11 = n10 + n7;
                path.moveTo(n11, 0.0f);
                final float n12 = n8 / 2.0f;
                final float n13 = n12 - n9;
                path.lineTo(n11, n13);
                path.lineTo(n4, n13);
                final float n14 = n12 + n9;
                path.lineTo(n4, n14);
                path.lineTo(n11, n14);
                path.lineTo(n11, n8);
                final float n15 = n10 - n7;
                path.lineTo(n15, n8);
                path.lineTo(n15, n13);
                path.lineTo(0.0f, n13);
                path.lineTo(0.0f, n14);
                path.lineTo(n15, n14);
                path.lineTo(n15, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        DIAMOND_IN("Diamond in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                final float n12 = n11 - n9;
                path.moveTo(n10, n12);
                path.lineTo(n10 + n7, n11);
                path.lineTo(n10, n9 + n11);
                path.lineTo(n10 - n7, n11);
                path.lineTo(n10, n12);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        DIAMOND_OUT("Diamond out") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint(1);
                paint.setColor(-16777216);
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                canvas.drawColor(-16777216);
                final Path path = new Path();
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n4 - n5 * n6;
                final float n8 = n2;
                final float n9 = n8 - n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                final float n12 = n11 - n9;
                path.moveTo(n10, n12);
                path.lineTo(n10 + n7, n11);
                path.lineTo(n10, n9 + n11);
                path.lineTo(n10 - n7, n11);
                path.lineTo(n10, n12);
                path.close();
                paint.setColor(0);
                paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        ECLIPSE_IN("Eclipse in") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n2;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final RectF rectF = new RectF(-n9, 0.0f, n9, n4);
                final RectF rectF2 = new RectF(0.0f, -n7, n8, n7);
                final RectF rectF3 = new RectF(n8 - n9, 0.0f, n9 + n8, n4);
                final RectF rectF4 = new RectF(0.0f, n4 - n7, n8, n4 + n7);
                canvas.drawOval(rectF, MaskBitmap.a);
                canvas.drawOval(rectF2, MaskBitmap.a);
                canvas.drawOval(rectF3, MaskBitmap.a);
                canvas.drawOval(rectF4, MaskBitmap.a);
                this.drawText(canvas);
                return bitmap;
            }
        },
        FOUR_TRIANGLE("Four triangle") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                final float n10 = n8 - n9;
                path.lineTo(n4, n10);
                path.lineTo(n4, n8);
                final float n11 = n4 - n7;
                path.lineTo(n11, n8);
                path.lineTo(0.0f, n9);
                path.close();
                path.moveTo(n11, 0.0f);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.lineTo(0.0f, n10);
                path.lineTo(n11, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        HORIZONTAL_COLUMN_DOWNMASK("Horizontal column downmask") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = MaskBitmap.ANIMATED_FRAME_CAL / 2.0f;
                final float n5 = n;
                final float n6 = n5 / (MaskBitmap.ANIMATED_FRAME_CAL / 2.0f);
                final float n7 = n3;
                final float n8 = n2;
                final float n9 = n8 / 2.0f;
                canvas.drawRoundRect(new RectF(0.0f, 0.0f, n6 * n7, n9), 0.0f, 0.0f, paint);
                if (n7 >= 0.5f + n4) {
                    canvas.drawRoundRect(new RectF(n5 - n5 / ((MaskBitmap.ANIMATED_FRAME_CAL - 1) / 2.0f) * (int) (n7 - n4), n9, n5, n8), 0.0f, 0.0f, paint);
                }
                return bitmap;
            }
        },
        HORIZONTAL_RECT("Horizontal rect") {
            @Override
            public Bitmap getMask(int i, final int n, final int n2) {
                final Bitmap bitmap = Bitmap.createBitmap(i, n, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n3 = i / 10.0f;
                final float n4 = n3 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n5 = n2;
                float n6;
                for (i = 0; i < 10; ++i) {
                    n6 = i * n3;
                    canvas.drawRect(new Rect((int) n6, 0, (int) (n6 + n4 * n5), n), paint);
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        LEAF("LEAF") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setStrokeCap(Paint.Cap.BUTT);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                final float n5 = n2 / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n6 = n2;
                path.moveTo(0.0f, n6);
                final float n7 = n;
                final float n8 = n7 / 2.0f;
                final float n9 = n6 / 2.0f;
                path.cubicTo(0.0f, n6, n8 - n4, n9 - n5, n7, 0.0f);
                path.cubicTo(n7, 0.0f, n8 + n4, n9 + n5, 0.0f, n6);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        OPEN_DOOR("OPEN_DOOR") {
            @Override
            public Bitmap getMask(int n, final int n2, int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setStrokeCap(Paint.Cap.BUTT);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / MaskBitmap.ANIMATED_FRAME_CAL * n3;
                n3 = n2 / MaskBitmap.ANIMATED_FRAME_CAL;
                final Canvas canvas = new Canvas(bitmap);
                final Path path = new Path();
                final float n5 = n / 2;
                path.moveTo(n5, 0.0f);
                final float n6 = n5 - n4;
                path.lineTo(n6, 0.0f);
                final float n7 = n4 / 2.0f;
                final float n8 = n5 - n7;
                n = n2 / 6;
                final float n9 = n;
                path.lineTo(n8, n9);
                final float n10 = n2 - n;
                path.lineTo(n8, n10);
                final float n11 = n2;
                path.lineTo(n6, n11);
                final float n12 = n4 + n5;
                path.lineTo(n12, n11);
                final float n13 = n5 + n7;
                path.lineTo(n13, n10);
                path.lineTo(n13, n9);
                path.lineTo(n12, 0.0f);
                path.lineTo(n6, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                this.drawText(canvas);
                return bitmap;
            }
        },
        PIN_WHEEL("PIN_WHEEL") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                final float n10 = n4 / 2.0f;
                final float n11 = n8 / 2.0f;
                path.moveTo(n10, n11);
                path.lineTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(n4, n8);
                path.lineTo(n4, n8 - n9);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4 - n7, 0.0f);
                path.close();
                path.moveTo(n10, n11);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(0.0f, n9);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        RECT_RANDOM("RECT_RANDOM") {
            @Override
            public Bitmap getMask(int i, int j, final int n) {
                final Bitmap bitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n2 = i / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n3 = j / MaskBitmap.ANIMATED_FRAME_CAL;
                float n4;
                float n5;
                for (i = 0; i < MaskBitmap.b.length; ++i) {
                    for (j = MaskBitmap.c.nextInt(MaskBitmap.b[i].length); MaskBitmap.b[i][j] == 1; j = MaskBitmap.c.nextInt(MaskBitmap.b[i].length)) {
                    }
                    MaskBitmap.b[i][j] = 1;
                    for (j = 0; j < MaskBitmap.b[i].length; ++j) {
                        if (MaskBitmap.b[i][j] == 1) {
                            n4 = i;
                            n5 = j;
                            canvas.drawRoundRect(new RectF(n4 * n2, n5 * n3, (n4 + 1.0f) * n2, (n5 + 1.0f) * n3), 0.0f, 0.0f, paint);
                        }
                    }
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        SKEW_LEFT_MEARGE("SKEW_LEFT_MEARGE") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(n7, 0.0f);
                path.lineTo(0.0f, 0.0f);
                path.close();
                path.moveTo(n4 - n7, n8);
                path.lineTo(n4, n8 - n9);
                path.lineTo(n4, n8);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_LEFT_SPLIT("SKEW_LEFT_SPLIT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n9);
                path.lineTo(0.0f, 0.0f);
                path.lineTo(n7, 0.0f);
                path.lineTo(n4, n8 - n9);
                path.lineTo(n4, n8);
                path.lineTo(n4 - n7, n8);
                path.lineTo(0.0f, n9);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_RIGHT_MEARGE("SKEW_RIGHT_MEARGE") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                path.moveTo(0.0f, n8 - n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.close();
                path.moveTo(n4 - n7, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n4, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SKEW_RIGHT_SPLIT("SKEW_RIGHT_SPLIT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / MaskBitmap.ANIMATED_FRAME_CAL;
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / MaskBitmap.ANIMATED_FRAME_CAL * n6;
                final Path path = new Path();
                final float n10 = n4 - n7;
                path.moveTo(n10, 0.0f);
                path.lineTo(n4, 0.0f);
                path.lineTo(n4, n9);
                path.lineTo(n7, n8);
                path.lineTo(0.0f, n8);
                path.lineTo(0.0f, n8 - n9);
                path.lineTo(n10, 0.0f);
                path.close();
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SLIDESHOW("Slideshow") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                new Paint(1).setColor(-16777216);
                return Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
            }
        },
        SQUARE_IN("SQUARE_IN") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final float n4 = n;
                final float n5 = n4 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n6 = n3;
                final float n7 = n5 * n6;
                final float n8 = n2;
                final float n9 = n8 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n6;
                final Path path = new Path();
                path.moveTo(0.0f, 0.0f);
                path.lineTo(0.0f, n8);
                path.lineTo(n7, n8);
                path.lineTo(n7, 0.0f);
                path.moveTo(n4, n8);
                path.lineTo(n4, 0.0f);
                final float n10 = n4 - n7;
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n8);
                path.moveTo(n7, n9);
                path.lineTo(n7, 0.0f);
                path.lineTo(n10, 0.0f);
                path.lineTo(n10, n9);
                final float n11 = n8 - n9;
                path.moveTo(n7, n11);
                path.lineTo(n7, n8);
                path.lineTo(n10, n8);
                path.lineTo(n10, n11);
                canvas.drawPath(path, paint);
                return bitmap;
            }
        },
        SQUARE_OUT("SQUARE_OUT") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final float n4 = n / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f);
                final float n5 = n3;
                final float n6 = n4 * n5;
                final float n7 = n2 / (MaskBitmap.ANIMATED_FRAME_CAL * 2.0f) * n5;
                final Canvas canvas = new Canvas(bitmap);
                final float n8 = n / 2;
                final float n9 = n2 / 2;
                canvas.drawRect(new RectF(n8 - n6, n9 - n7, n8 + n6, n9 + n7), paint);
                return bitmap;
            }
        },
        VERTICAL_RECT("VERTICAL_RECT") {
            @Override
            public Bitmap getMask(final int n, int i, final int n2) {
                final Bitmap bitmap = Bitmap.createBitmap(n, i, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final float n3 = i / 10.0f;
                final float n4 = n2 * n3 / MaskBitmap.ANIMATED_FRAME_CAL;
                float n5;
                for (i = 0; i < 10; ++i) {
                    n5 = i * n3;
                    canvas.drawRect(new Rect(0, (int) n5, n, (int) (n5 + n4)), paint);
                }
                this.drawText(canvas);
                return bitmap;
            }
        },
        WIND_MILL("WIND_MILL") {
            @Override
            public Bitmap getMask(final int n, final int n2, final int n3) {
                final float a = MaskBitmap.a(n, n2);
                final Paint paint = new Paint();
                paint.setColor(-16777216);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                final Bitmap bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
                final Canvas canvas = new Canvas(bitmap);
                final RectF rectF = new RectF();
                final float n4 = n / 2.0f;
                final float n5 = n2 / 2.0f;
                rectF.set(n4 - a, n5 - a, n4 + a, n5 + a);
                final float n6 = n3 * (90.0f / MaskBitmap.ANIMATED_FRAME_CAL);
                canvas.drawArc(rectF, 90.0f, n6, true, paint);
                canvas.drawArc(rectF, 180.0f, n6, true, paint);
                canvas.drawArc(rectF, 270.0f, n6, true, paint);
                canvas.drawArc(rectF, 360.0f, n6, true, paint);
                this.drawText(canvas);
                return bitmap;
            }
        };

        String a;

        private EFFECT(final String a) {
            this.a = "";
            this.a = a;
        }

        public void drawText(final Canvas canvas) {
            final Paint paint = new Paint();
            paint.setTextSize(50.0f);
            paint.setColor(-65536);
        }

        public abstract Bitmap getMask(final int p0, final int p1, final int p2);
    }
}