package com.wavymusic.notification.Download;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.Partical.DownloadPartical.CheckForSDCard;
import com.wavymusic.notification.Model.NotificcationModel;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DownloadFile {

    private static final String TAG = "DownloadPartical";
    private Context context;
    private ImageView ivDownload;
    private ImageView ivUse;
    private TextView tvProgress;
    ArrayList<NotificcationModel> notificcationModels;

    public DownloadFile(Context context, ImageView ivDownload, ImageView ivUse, TextView tvThemeDownprogress, ArrayList<NotificcationModel> notificcationModels) {
        this.context = context;
        this.ivDownload = ivDownload;
        this.ivUse = ivUse;
        this.tvProgress = tvThemeDownprogress;
        this.notificcationModels = notificcationModels;

        /*Start Theme Download*/
        new DownloadingTask().execute();
        new DownloadingimageTask().execute();

        /*Download Partical*/
        new DownloadingPartical().execute();
        new DownloadingParticalimage().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingTask extends AsyncTask<String, Integer, String> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (outputFile != null) {
                    ivDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                    ivUse.setVisibility(View.VISIBLE);
                    tvProgress.setText("0");
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + notificcationModels.get(0).getSongFileName());
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + notificcationModels.get(0).getSongFileName());
            }
            super.onPostExecute(result);
        }

        protected void onProgressUpdate(Integer... progress) {
            tvProgress.setText(String.valueOf(progress[0]));
        }

        @Override
        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(notificcationModels.get(0).getSongUrl());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP" + c.getResponseCode() + " " + c.getResponseMessage());
                }
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getThemeFolderPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }
                outputFile = new File(apkStorage, MyApplication.notificcationModels.get(0).getSongFileName());
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }
                int fileLength = c.getContentLength();
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                long total = 0;
                int count;
                while ((count = is.read(buffer)) != -1) {
                    if (isCancelled()) {
                        is.close();
                        return null;
                    }
                    total += count;
                    if (fileLength > 0)
                        publishProgress((int) (total * 100 / fileLength));
                    fos.write(buffer, 0, count);
                }

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingimageTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                    ivDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                    ivUse.setVisibility(View.VISIBLE);
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(0).getThemeName() + ".png");
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + notificcationModels.get(0).getThemeName() + ".png");
            }
            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(notificcationModels.get(0).getThemeThumbnail());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getThemeFolderPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }
                outputFile = new File(apkStorage, notificcationModels.get(0).getThemeName() + ".png");
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingPartical extends AsyncTask<String, Integer, String> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (outputFile != null) {
                    ivDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                    tvProgress.setText("0");
                    ivUse.setVisibility(View.VISIBLE);
                    try {
                        unzipTheme(Utils.INSTANCE.getAssetUnityPath() + MyApplication.notificcationModels.get(0).getParticalName() + ".zip", Utils.INSTANCE.getAssetUnityPath() + MyApplication.notificcationModels.get(0).getParticalName());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(0).getParticalBundelName());
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(0).getParticalBundelName());
            }
            super.onPostExecute(result);
        }

        protected void onProgressUpdate(Integer... progress) {
            tvProgress.setText(String.valueOf(progress[0]));
        }

        @Override
        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(MyApplication.notificcationModels.get(0).getParticalBundel());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getAssetUnityPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }
                outputFile = new File(apkStorage, MyApplication.notificcationModels.get(0).getParticalBundelName());
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }
                int fileLength = c.getContentLength();
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                long total = 0;
                int count;
                while ((count = is.read(buffer)) != -1) {
                    if (isCancelled()) {
                        is.close();
                        return null;
                    }
                    total += count;
                    if (fileLength > 0)
                        publishProgress((int) (total * 100 / fileLength));
                    fos.write(buffer, 0, count);
                }

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class DownloadingParticalimage extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                    ivDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.GONE);
                    ivUse.setVisibility(View.VISIBLE);
                } else {
                    DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(0).getParticalName() + ".png");
                }
            } catch (Exception e) {
                e.printStackTrace();
                DeleteFileIfInterupt(Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(0).getParticalName() + ".png");
            }
            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(MyApplication.notificcationModels.get(0).getParticalThumbnail());
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.connect();
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());
                }
                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Utils.INSTANCE.getAssetUnityPath());
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                }
                outputFile = new File(apkStorage, MyApplication.notificcationModels.get(0).getParticalName() + ".png");
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();

            } catch (Exception e) {
                e.printStackTrace();
                outputFile = null;
            }
            return null;
        }
    }

    private void DeleteFileIfInterupt(final String s) {
        final File file = new File(s);
        if (file.exists()) {
            file.delete();
        }
    }

    public void unzipTheme(String zipFilePath, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdir();
        }
        ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();
        while (entry != null) {
            String filePath = destDirectory + File.separator + entry.getName();
            if (!entry.isDirectory()) {
                extractFile(zipIn, filePath);
            } else {
                File dir = new File(filePath);
                dir.mkdir();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
    }

    private static final int BUFFER_SIZE = 4096;

    private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }
}
