package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.xyz.imagetovideomoviewmaker.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.AlbumAdapterById;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.ImageByAlbumAdapter;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.OnItemClickListner;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.SelectedImageAdapter;
import com.imagetovideomoviemaker.photoslideshowwithmusic.data.ImageData;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.EmptyRecyclerView;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.ExpandIconView;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.VerticalSlidingPanel;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.VerticalSlidingPanel.PanelSlideListener;

import java.io.File;
import java.util.ArrayList;

public class ImageSelectionActivity extends AppCompatActivity implements PanelSlideListener {
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isForFirst = false;
    public static ArrayList<ImageData> tempImage = new ArrayList();
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private TextView tvClear;
    private ExpandIconView expandIcon;
    public boolean isFromCameraNotification = false;
    public boolean isFromPreview = false;
    boolean isPause = false;
    private VerticalSlidingPanel panel;
    private View parent;
    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    private EmptyRecyclerView rvSelectedImage;
    private SelectedImageAdapter selectedImageAdapter;
    private TextView tvImageCount;
    public static CheckBox chbAllSelect;
    ImageView ivDownarrow;

    ImageView ivback, ivnext;
    TextView tvToolbarTitle;

    public void onPanelAnchored(View view) {
    }

    public void onPanelShown(View view) {
    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_select_activity);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageSelectionActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        this.application = MyApplication.getInstance();
        this.isFromPreview = getIntent().hasExtra("extra_from_preview");
        this.isFromCameraNotification = getIntent().hasExtra("isFromCameraNotification");
        bindView();
        init();
        addListner();
        loadNativeAds();
    }

    public void scrollToPostion(final int i) {
        this.rvAlbum.postDelayed(new Runnable() {
            public void run() {
                ImageSelectionActivity.this.rvAlbum.scrollToPosition(i);
            }
        }, 300);
    }

    private void init() {
//        setSupportActionBar(this.toolbar);
//        TextView textView = (TextView) this.toolbar.findViewById(R.id.toolbar_title);
//        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        textView.setText(getString(R.string.select_images));
        Utils.setFont(this, tvToolbarTitle);
        Utils.setFont(this, tvImageCount);
        Utils.setFont(this, tvClear);
        if (this.isFromCameraNotification) {
            this.application.getFolderList();
        }
        this.albumAdapter = new AlbumAdapterById(this);
        this.albumImagesAdapter = new ImageByAlbumAdapter(this);
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvAlbum.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        this.rvAlbum.setHasFixedSize(true);
        this.rvAlbum.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.rvAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbum.setAdapter(this.albumAdapter);
        this.rvAlbumImages.setLayoutManager(new GridLayoutManager(getApplicationContext(), 3));
        this.rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbumImages.setAdapter(this.albumImagesAdapter);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
//        getSupportActionBar().setHomeButtonEnabled(true);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
    }

    private void bindView() {
        ivback = findViewById(R.id.iv_back);
        ivnext = findViewById(R.id.iv_next);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        this.tvImageCount = (TextView) findViewById(R.id.tvImageCount);
        this.expandIcon = (ExpandIconView) findViewById(R.id.settings_drag_arrow);
        this.rvAlbum = (RecyclerView) findViewById(R.id.rvAlbum);
        this.rvAlbumImages = (RecyclerView) findViewById(R.id.rvImageAlbum);
        this.rvSelectedImage = (EmptyRecyclerView) findViewById(R.id.rvSelectedImagesList);
        this.panel = (VerticalSlidingPanel) findViewById(R.id.overview_panel);
        this.panel.setEnableDragViewTouchEvents(true);
        this.panel.setDragView(findViewById(R.id.settings_pane_header));
        this.panel.setPanelSlideListener(this);
        this.parent = findViewById(R.id.default_home_screen_panel);
        this.tvClear = (TextView) findViewById(R.id.tv_clear);
        this.chbAllSelect = (CheckBox) findViewById(R.id.chbAllSelect);
        this.ivDownarrow = (ImageView) findViewById(R.id.ivDownarrow);
        chbAllSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean bb) {
                if (chbAllSelect.isChecked()) {
                    Allselect();
                    ivDownarrow.setVisibility(View.VISIBLE);
                }
            }
        });
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivnext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (application.getSelectedImages().size() > 2) {
//                    id = R.id.menu_done;
//                    if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                        interstitialAd.show();
//                    }
//                    else {
                    loadDone();
//                    }

                }else {
                    Toast.makeText(ImageSelectionActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (this.isFromPreview) {
            tvClear.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }

    int ii;

    private void Allselect() {
        ii = 0;
        while (getItemCount() != ii) {
            final ImageData item = this.getItem(ii);
            this.application.addSelectedImage(item);
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            albumImagesAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
            ++ii;
        }

        Animation animation = AnimationUtils.loadAnimation(ImageSelectionActivity.this, R.anim.bottom_down_slow);
        ivDownarrow.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ivDownarrow.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    private void addListner() {
        this.tvClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageSelectionActivity.this.clearData();
            }
        });
        this.albumAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object o) {
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                ImageSelectionActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 999 && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData imgData = new ImageData();
            imgData.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, imgData);
            setupAdapter();
        }
    }

    private void setupAdapter() {
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
    }

    protected void onResume() {
        super.onResume();
        if (this.isPause) {
            this.isPause = false;
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            this.albumImagesAdapter.notifyDataSetChanged();
            this.selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        this.isPause = true;
    }

//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_selection, menu);
//        if (this.isFromPreview) {
//            menu.removeItem(R.id.menu_clear);
//        }
//        for (int i = 0; i < menu.size(); i++) {
//            MenuItem item = menu.getItem(i);
//            SubMenu subMenu = item.getSubMenu();
//            if (subMenu != null && subMenu.size() > 0) {
//                for (int i2 = 0; i2 < subMenu.size(); i2++) {
//                    Utils.applyFontToMenuItem(getApplicationContext(), subMenu.getItem(i2));
//                }
//            }
////            Utils.applyFontToMenuItem(getApplicationContext(), item);
//        }
//        return true;
//    }

    private boolean isEndFrameExist() {
        if (EndFrameFrag.lastsaveTempPath == null) {
            return false;
        }
        return new File(EndFrameFrag.lastsaveTempPath).exists();
    }

//    public boolean onOptionsItemSelected(final MenuItem menuItem) {
//        final int itemId = menuItem.getItemId();
//        if (itemId != android.R.id.home) {
//            switch (itemId) {
//                case R.id.menu_done: {
//                    if (this.application.getSelectedImages().size() > 2) {
////                        id = R.id.menu_done;
////                        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
////                            interstitialAd.show();
////                        } else {
//                        loadDone();
////                        }
//
//                        break;
//                    }
//                    Toast.makeText(this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
//
//                    break;
//                }
//                case R.id.menu_clear: {
//                    this.clearData();
//                    break;
//                }
//            }
//        } else {
//            this.onBackPressed();
//        }
//        return super.onOptionsItemSelected(menuItem);
//    }

    private boolean loadDone() {
        final boolean isFromPreview = this.isFromPreview;
        int i = 0;
        if (isFromPreview) {
            if (this.isEndFrameExist()) {
                ImageData imageData = null;
                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                list.addAll(this.application.selectedImages);
                this.application.selectedImages.clear();
                while (i < list.size()) {
                    if (list.get(i).imagePath.equals(EndFrameFrag.lastsaveTempPath)) {
                        imageData = list.get(i);
                    } else {
                        this.application.selectedImages.add(list.get(i));
                    }
                    ++i;
                }
                if (imageData != null) {
                    this.application.selectedImages.add(imageData);
                }
            }
            this.setResult(-1);
            this.finish();
            return true;
        } else {
            final Intent intent = new Intent((Context) this, (Class) ImageEditActivity.class);
            intent.putExtra("isFromCameraNotification", false);
            intent.putExtra("KEY", "FromImageSelection");
            this.startActivity(intent);
        }
        return false;
    }


    public void onBackPressed() {
        if (this.panel.isExpanded()) {
            this.panel.collapsePane();
        } else if (this.isFromCameraNotification) {
            startActivity(new Intent(this, LauncherActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            this.application.clearAllSelection();
            finish();
        } else if (this.isFromPreview) {
            setResult(-1);
            finish();
        } else {
            this.application.videoImages.clear();
            this.application.clearAllSelection();
            startActivity(new Intent(this, LauncherActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
            super.onBackPressed();
        }
    }

    public void onPanelSlide(final View view, final float n) {
        if (this.expandIcon != null) {
            this.expandIcon.setFraction(n, false);
        }
        if (n >= 0.005f) {
            if (this.parent != null && this.parent.getVisibility() != View.VISIBLE) {
                this.parent.setVisibility(View.VISIBLE);
            }
        } else if (this.parent != null && this.parent.getVisibility() == View.VISIBLE) {
            this.parent.setVisibility(View.GONE);
        }
    }

    public void onPanelCollapsed(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.VISIBLE);
        }
        this.selectedImageAdapter.isExpanded = false;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.GONE);
        }
        this.selectedImageAdapter.isExpanded = true;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    private void clearData() {
        for (int size = this.application.getSelectedImages().size() - 1; size >= 0; size--) {
            this.application.removeSelectedImage(size);
        }
        this.tvImageCount.setText("0");
        this.chbAllSelect.setChecked(false);
        this.selectedImageAdapter.notifyDataSetChanged();
        this.albumImagesAdapter.notifyDataSetChanged();
    }

    private UnifiedNativeAd nativeAd;

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                LinearLayout frameLayout = findViewById(R.id.fl_nativead);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(nativeAd);

    }
}
