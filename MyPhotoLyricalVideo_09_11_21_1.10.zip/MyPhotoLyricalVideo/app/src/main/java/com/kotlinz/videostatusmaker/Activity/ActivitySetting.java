package com.kotlinz.videostatusmaker.Activity;

import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;

import com.kotlinz.videostatusmaker.Utils.AppPreferences;

public class ActivitySetting extends AppCompatActivity {
    Activity activity = ActivitySetting.this;
    ImageView ivBack;
    ImageView imgAllCap;
    LinearLayout linearLayout;
    AppPreferences appPreferences;
    TextView tvTitle;
    TextView txtAllcap;
    int width;
    Typeface typeface;
    int height;

    private NativeAd nativeAd;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_setting);
        this.appPreferences = new AppPreferences(this);
        getWindow().addFlags(1024);
        LoadNativeAds();
        PutAnalyticsEvent();
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        this.linearLayout = (LinearLayout) findViewById(R.id.lay1);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.imgAllCap = (ImageView) findViewById(R.id.img_all_cap);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.txtAllcap = (TextView) findViewById(R.id.txt_allcap);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.txtAllcap.setTypeface(this.typeface);
        check();
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null ) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.linearLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityPreview.complete = false;
                if (ActivitySetting.this.appPreferences.get_ALL_CAPS()) {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(false);
                } else {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(true);
                }
                ActivitySetting.this.check();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySetting");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ActivitySetting.this.nativeAd != null) {
                            ActivitySetting.this.nativeAd.destroy();
                        }
                        ActivitySetting.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

   public void check() {
        if (this.appPreferences.get_ALL_CAPS()) {
            this.imgAllCap.setImageResource(R.drawable.toggle1_on);
        } else {
            this.imgAllCap.setImageResource(R.drawable.toggle1_off);
        }
    }
}
