package com.kotlinz.festivalstorymaker.sticker;

import android.graphics.Rect;
import android.graphics.drawable.Drawable;

public class c extends e {
    public Drawable j;
    public Rect k;

    public c(final Drawable j) {
        this.j = j;
        this.k = new Rect(0, 0, this.i(), this.g());
    }

    @Override
    public int g() {
        return this.j.getIntrinsicHeight();
    }

    @Override
    public int i() {
        return this.j.getIntrinsicWidth();
    }
}
