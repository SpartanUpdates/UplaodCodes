package com.claptoflashlightonoff.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import com.example.speaktourchtight.R;
import androidx.core.view.ViewCompat;

public class SoundLevelView extends View {
    private Paint mBackgroundPaint;
    private Drawable mGreen;
    private int mHeight;
    private Drawable mRed;
    private int mThreshold = 0;
    private int mVol = 0;
    private int mWidth;

    public SoundLevelView(Context context, AttributeSet set) {
        super(context, set);
        this.mGreen = context.getResources().getDrawable(R.drawable.flash_light1);
        this.mRed = context.getResources().getDrawable(R.drawable.police_light1);
        this.mWidth = this.mGreen.getIntrinsicWidth();
        setMinimumWidth(this.mWidth * 10);
        int intrinsicHeight = this.mGreen.getIntrinsicHeight();
        this.mHeight = intrinsicHeight;
        setMinimumHeight(intrinsicHeight);
        Paint paint = new Paint();
        this.mBackgroundPaint = paint;
        paint.setColor(ViewCompat.MEASURED_STATE_MASK);
    }

    public void onDraw(Canvas canvas) {
        canvas.drawPaint(this.mBackgroundPaint);
        for (int i = 0; i <= this.mVol; i++) {
            Drawable drawable;
            if (i < this.mThreshold) {
                drawable = this.mGreen;
            } else {
                drawable = this.mRed;
            }
            drawable.setBounds((10 - i) * this.mWidth, 0, ((10 - i) + 1) * this.mWidth, this.mHeight);
            drawable.draw(canvas);
        }
    }

    public void setLevel(int mVol, int mThreshold) {
        if (mVol != this.mVol || mThreshold != this.mThreshold) {
            this.mVol = mVol;
            this.mThreshold = mThreshold;
            invalidate();
        }
    }
}
