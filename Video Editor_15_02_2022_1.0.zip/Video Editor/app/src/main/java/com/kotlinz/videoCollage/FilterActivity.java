package com.kotlinz.videoCollage;

import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.adpaters.FilterAdapter;
import com.kotlinz.videoCollage.interfaces.FilterAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import net.alhazmy13.imagefilter.ImageFilter;
import net.alhazmy13.imagefilter.ImageFilter.Filter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class FilterActivity extends AppCompatActivity {
    private Context context;
    private FilterAdapter filterAdapter;
    private String filterPath;
    private int filterPosition = 0;
    private ImageView imgBack;
    private ImageView imgDone;
    private ImageView imgFilter;
    private ArrayList<String> listThumb;
    private String path;
    private RecyclerView recyclerviewFilter;
    private String[] thumbImageList;

    private class FilterAsyncTask extends AsyncTask<Void, Void, String> {
        private Bitmap bitmapOrg;
        private int position;
        private ProgressDialog progressDialog;


        public FilterAsyncTask(int i) {
            this.position = i;
        }


        public void onPreExecute() {
            super.onPreExecute();
            ProgressDialog progressDialog = new ProgressDialog(FilterActivity.this.context);
            this.progressDialog = progressDialog;
            progressDialog.setMessage("Please wait...It is applying filter");
            this.progressDialog.setIndeterminate(false);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setCanceledOnTouchOutside(false);
            this.progressDialog.show();
        }


        public String doInBackground(Void... voidArr) {
            Bitmap decodeFile = BitmapFactory.decodeFile(FilterActivity.this.path);
            this.bitmapOrg = decodeFile;
            int i = this.position;
            if (i == 0) {
                this.bitmapOrg = BitmapFactory.decodeFile(FilterActivity.this.path);
            } else if (i == 1) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GRAY, new Object[0]);
            } else if (i == 2) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.NEON, Integer.valueOf(Callback.DEFAULT_DRAG_ANIMATION_DURATION), Integer.valueOf(50), Integer.valueOf(100));
            } else if (i == 3) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.TV, new Object[0]);
            } else if (i == 4) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.INVERT, new Object[0]);
            } else if (i == 5) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.BLOCK, new Object[0]);
            } else if (i == 6) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.OLD, new Object[0]);
            } else if (i == 7) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SKETCH, new Object[0]);
            } else if (i == 8) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GOTHAM, new Object[0]);
            } else if (i == 9) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.OIL, Integer.valueOf(10));
            } else if (i == 10) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.AVERAGE_BLUR, Integer.valueOf(9));
            } else if (i == 11) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SHARPEN, new Object[0]);
            } else if (i == 12) {
                int width = decodeFile.getWidth();
                i = this.bitmapOrg.getHeight();
                Bitmap bitmap = this.bitmapOrg;
                Filter filter = Filter.LIGHT;
                Object[] objArr = new Object[3];
                width /= 2;
                objArr[0] = Integer.valueOf(width);
                i /= 2;
                objArr[1] = Integer.valueOf(i);
                objArr[2] = Integer.valueOf(Math.min(width, i));
                this.bitmapOrg = ImageFilter.applyFilter(bitmap, filter, objArr);
            } else if (i == 13) {
                double width2 = (double) (((decodeFile.getWidth() / 2) * 95) / 100);
                this.bitmapOrg = ImageFilter.applyFilter(this.bitmapOrg, Filter.LOMO, Double.valueOf(width2));
            } else if (i == 14) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.HDR, new Object[0]);
            } else if (i == 15) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.GAUSSIAN_BLUR, Double.valueOf(1.2d));
            } else if (i == 16) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.SOFT_GLOW, Double.valueOf(0.6d));
            } else if (i == 17) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.PIXELATE, Integer.valueOf(9));
            } else if (i == 18) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.MOTION_BLUR, Integer.valueOf(5), Integer.valueOf(1));
            } else if (i == 19) {
                this.bitmapOrg = ImageFilter.applyFilter(decodeFile, Filter.RELIEF, new Object[0]);
            }
            decodeFile = this.bitmapOrg;
            i = new Random().nextInt(10000);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Image-");
            stringBuilder.append(i);
            stringBuilder.append(".jpg");
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(context.getCacheDir());
            stringBuilder3.append("/filtertemp");
            File file = new File(stringBuilder3.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file, stringBuilder2);
            if (file2.exists()) {
                file2.delete();
            }
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                decodeFile.compress(CompressFormat.JPEG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return file2.getAbsolutePath();
        }


        public void onPostExecute(String str) {
            super.onPostExecute(str);
            FilterActivity.this.imgFilter.setImageBitmap(BitmapFactory.decodeFile(str));
            FilterActivity.this.filterPath = str;
            this.progressDialog.dismiss();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_filter);
        this.context = this;
        PutAnalyticsEvent();
        inIt();
        String string = getIntent().getExtras().getString("path");
        this.path = string;
        this.imgFilter.setImageBitmap(BitmapFactory.decodeFile(string));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.recyclerviewFilter.setLayoutManager(linearLayoutManager);
        try {
            this.thumbImageList = getAssets().list("effectthumb");
            this.listThumb = new ArrayList(Arrays.asList(this.thumbImageList));
        } catch (IOException e) {
            e.printStackTrace();
        }
        FilterAdapter filterAdapter = new FilterAdapter(this.listThumb, this, new FilterAdapterCallBackInterface() {
            public void itemClick(int i) {
                if (filterPosition != i) {
                    filterPosition = i;
                    new FilterAsyncTask(i).execute(new Void[0]);
                }
            }
        });
        this.filterAdapter = filterAdapter;
        this.recyclerviewFilter.setAdapter(filterAdapter);
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FilterActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public void onBackPressed() {
        String str = "Cancel";
        new Builder(this).setMessage("All changes will be discarded.").setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                FilterActivity.this.setResult(0, new Intent());
                FilterActivity.this.finish();
            }
        }).setNegativeButton(str, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void inIt() {
        setSupportActionBar((Toolbar) findViewById(R.id.filter_toolbar));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(false);
        this.imgFilter = (ImageView) findViewById(R.id.img_filter);
        this.recyclerviewFilter = (RecyclerView) findViewById(R.id.img_filter_recycler);
        this.imgBack = (ImageView) findViewById(R.id.img_filter_tool_back);
        this.imgDone = (ImageView) findViewById(R.id.img_filter_tool_done);
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                FilterActivity.this.onBackPressed();
            }
        });
        this.imgDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("filter_path", FilterActivity.this.filterPath);
                FilterActivity.this.setResult(-1, intent);
                FilterActivity.this.finish();
            }
        });
    }
}
