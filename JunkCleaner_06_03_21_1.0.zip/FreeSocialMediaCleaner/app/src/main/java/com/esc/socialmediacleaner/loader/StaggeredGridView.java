package com.esc.socialmediacleaner.loader;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import com.esc.socialmediacleaner.R;
import com.google.common.primitives.Ints;
import androidx.collection.SparseArrayCompat;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.VelocityTrackerCompat;
import androidx.core.view.ViewCompat;
import androidx.core.widget.EdgeEffectCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class StaggeredGridView extends ViewGroup {
    public static final int COLUMN_COUNT_AUTO = -1;
    private static final int INVALID_POSITION = -1;
    private static final String TAG = "StaggeredGridView";
    private static final int TOUCH_MODE_DONE_WAITING = 5;
    private static final int TOUCH_MODE_DOWN = 3;
    private static final int TOUCH_MODE_DRAGGING = 1;
    private static final int TOUCH_MODE_FLINGING = 2;
    private static final int TOUCH_MODE_IDLE = 0;
    private static final int TOUCH_MODE_REST = 6;
    private static final int TOUCH_MODE_TAP = 4;
    private int mActivePointerId;
    private ListAdapter mAdapter;
    private boolean mBeginClick;
    private final EdgeEffectCompat mBottomEdge;
    private int mColCount;
    private int mColCountSetting;
    private ArrayList<ArrayList<Integer>> mColMappings;
    private int mColWidth;
    private ContextMenuInfo mContextMenuInfo;
    private boolean mDataChanged;
    boolean mDrawSelectorOnTop;
    private boolean mFastChildLayout;
    private long mFirstAdapterId;
    private int mFirstPosition;
    private int mFlingVelocity;
    private boolean mHasStableIds;
    private boolean mInLayout;
    private boolean mIsChildViewEnabled;
    private int[] mItemBottoms;
    private int mItemCount;
    private int mItemMargin;
    private int[] mItemTops;
    private float mLastTouchX;
    private float mLastTouchY;
    private final SparseArrayCompat<LayoutRecord> mLayoutRecords;
    private int mMaximumVelocity;
    private int mMinColWidth;
    private int mMotionPosition;
    private int mNumCols;
    private final AdapterDataSetObserver mObserver;
    OnItemClickListener mOnItemClickListener;
    OnItemLongClickListener mOnItemLongClickListener;
    private CheckForLongPress mPendingCheckForLongPress;
    private Runnable mPendingCheckForTap;
    private PerformClick mPerformClick;
    private boolean mPopulating;
    private final RecycleBin mRecycler;
    private int[] mRestoreOffsets;
    private final ScrollerCompat mScroller;
    int mSelectionBottomPadding;
    int mSelectionLeftPadding;
    int mSelectionRightPadding;
    int mSelectionTopPadding;
    Drawable mSelector;
    int mSelectorPosition;
    Rect mSelectorRect;
    private final EdgeEffectCompat mTopEdge;
    private Rect mTouchFrame;
    private int mTouchMode;
    private Runnable mTouchModeReset;
    private float mTouchRemainderY;
    private int mTouchSlop;
    private final VelocityTracker mVelocityTracker;

    public static class AdapterContextMenuInfo implements ContextMenuInfo {
        public long id;
        public int position;
        public View targetView;

        public AdapterContextMenuInfo(View view, int i, long j) {
            this.targetView = view;
            this.position = i;
            this.id = j;
        }
    }

    private class AdapterDataSetObserver extends DataSetObserver {
        public void onInvalidated() {
        }

        private AdapterDataSetObserver() {
        }

        public void onChanged() {
            StaggeredGridView.this.mDataChanged = true;
            StaggeredGridView staggeredGridView = StaggeredGridView.this;
            staggeredGridView.mItemCount = staggeredGridView.mAdapter.getCount();
            StaggeredGridView.this.mRecycler.clearTransientViews();
            if (!StaggeredGridView.this.mHasStableIds) {
                StaggeredGridView.this.mLayoutRecords.clear();
                StaggeredGridView.this.recycleAllViews();
                int access$1300 = StaggeredGridView.this.mColCount;
                for (int i = 0; i < access$1300; i++) {
                    StaggeredGridView.this.mItemBottoms[i] = StaggeredGridView.this.mItemTops[i];
                }
            }
            if (StaggeredGridView.this.mFirstPosition > StaggeredGridView.this.mItemCount - 1 || StaggeredGridView.this.mAdapter.getItemId(StaggeredGridView.this.mFirstPosition) != StaggeredGridView.this.mFirstAdapterId) {
                StaggeredGridView.this.mFirstPosition = 0;
                Arrays.fill(StaggeredGridView.this.mItemTops, 0);
                Arrays.fill(StaggeredGridView.this.mItemBottoms, 0);
                if (StaggeredGridView.this.mRestoreOffsets != null) {
                    Arrays.fill(StaggeredGridView.this.mRestoreOffsets, 0);
                }
            }
            StaggeredGridView.this.requestLayout();
        }
    }

    final class CheckForTap implements Runnable {
        CheckForTap() {
        }

        public void run() {
            if (StaggeredGridView.this.mTouchMode == 3) {
                StaggeredGridView.this.mTouchMode = 4;
                StaggeredGridView staggeredGridView = StaggeredGridView.this;
                View childAt = staggeredGridView.getChildAt(staggeredGridView.mMotionPosition - StaggeredGridView.this.mFirstPosition);
                if (childAt != null && !childAt.hasFocusable()) {
                    if (StaggeredGridView.this.mDataChanged) {
                        StaggeredGridView.this.mTouchMode = 5;
                        return;
                    }
                    childAt.setSelected(true);
                    childAt.setPressed(true);
                    StaggeredGridView.this.setPressed(true);
                    StaggeredGridView.this.layoutChildren(true);
                    StaggeredGridView staggeredGridView2 = StaggeredGridView.this;
                    staggeredGridView2.positionSelector(staggeredGridView2.mMotionPosition, childAt);
                    StaggeredGridView.this.refreshDrawableState();
                    int longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    boolean isLongClickable = StaggeredGridView.this.isLongClickable();
                    if (StaggeredGridView.this.mSelector != null) {
                        Drawable current = StaggeredGridView.this.mSelector.getCurrent();
                        if (current instanceof TransitionDrawable) {
                            if (isLongClickable) {
                                ((TransitionDrawable) current).startTransition(longPressTimeout);
                            } else {
                                ((TransitionDrawable) current).resetTransition();
                            }
                        }
                    }
                    if (isLongClickable) {
                        if (StaggeredGridView.this.mPendingCheckForLongPress == null) {
                            StaggeredGridView.this.mPendingCheckForLongPress = new CheckForLongPress();
                        }
                        StaggeredGridView.this.mPendingCheckForLongPress.rememberWindowAttachCount();
                        staggeredGridView2 = StaggeredGridView.this;
                        staggeredGridView2.postDelayed(staggeredGridView2.mPendingCheckForLongPress, (long) longPressTimeout);
                    } else {
                        StaggeredGridView.this.mTouchMode = 5;
                    }
                    StaggeredGridView.this.postInvalidate();
                }
            }
        }
    }

    static class ColMap implements Parcelable {
        public static final Creator<ColMap> CREATOR = new Creator<ColMap>() {
            public ColMap createFromParcel(Parcel parcel) {
                return new ColMap(parcel);
            }

            public ColMap[] newArray(int i) {
                return new ColMap[i];
            }
        };
        int[] tempMap;
        private ArrayList<Integer> values;

        public int describeContents() {
            return 0;
        }


        public ColMap(ArrayList<Integer> arrayList) {
            this.values = arrayList;
        }

        private ColMap(Parcel parcel) {
            parcel.readIntArray(this.tempMap);
            this.values = new ArrayList();
            int i = 0;
            while (true) {
                int[] iArr = this.tempMap;
                if (i < iArr.length) {
                    this.values.add(Integer.valueOf(iArr[i]));
                    i++;
                } else {
                    return;
                }
            }
        }

        public void writeToParcel(Parcel parcel, int i) {
            int[] toIntArray = toIntArray(this.values);
            this.tempMap = toIntArray;
            parcel.writeIntArray(toIntArray);
        }

        public int[] toIntArray(ArrayList<Integer> arrayList) {
            int size = arrayList.size();
            int[] iArr = new int[size];
            for (int i = 0; i < size; i++) {
                iArr[i] = ((Integer) arrayList.get(i)).intValue();
            }
            return iArr;
        }
    }

    public static class LayoutParams extends ViewGroup.LayoutParams {
        private static final int[] LAYOUT_ATTRS = new int[]{16843085};
        private static final int SPAN_INDEX = 0;
        int column;
        long id = -1;
        int position;
        public int span = 1;
        int viewType;

        public LayoutParams(int i) {
            super(-1, i);
            if (this.height == -1) {
                Log.w(StaggeredGridView.TAG, "Constructing LayoutParams with height FILL_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            int i = this.width;
            String str = StaggeredGridView.TAG;
            if (i != -1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Inflation setting LayoutParams width to ");
                stringBuilder.append(this.width);
                stringBuilder.append(" - must be MATCH_PARENT");
                Log.w(str, stringBuilder.toString());
                this.width = -1;
            }
            if (this.height == -1) {
                Log.w(str, "Inflation setting LayoutParams height to MATCH_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, LAYOUT_ATTRS);
            this.span = obtainStyledAttributes.getInteger(0, 1);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            int i = this.width;
            String str = StaggeredGridView.TAG;
            if (i != -1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Constructing LayoutParams with width ");
                stringBuilder.append(this.width);
                stringBuilder.append(" - must be MATCH_PARENT");
                Log.w(str, stringBuilder.toString());
                this.width = -1;
            }
            if (this.height == -1) {
                Log.w(str, "Constructing LayoutParams with height MATCH_PARENT - impossible! Falling back to WRAP_CONTENT");
                this.height = -2;
            }
        }
    }

    private static final class LayoutRecord {
        public int column;
        public int height;
        public long id;
        private int[] mMargins;
        public int span;

        private LayoutRecord() {
            this.id = -1;
        }

        private final void ensureMargins() {
            if (this.mMargins == null) {
                this.mMargins = new int[(this.span * 2)];
            }
        }

        public final int getMarginAbove(int i) {
            int[] iArr = this.mMargins;
            if (iArr == null) {
                return 0;
            }
            return iArr[i * 2];
        }

        public final int getMarginBelow(int i) {
            int[] iArr = this.mMargins;
            if (iArr == null) {
                return 0;
            }
            return iArr[(i * 2) + 1];
        }

        public final void setMarginAbove(int i, int i2) {
            if (this.mMargins != null || i2 != 0) {
                ensureMargins();
                this.mMargins[i * 2] = i2;
            }
        }

        public final void setMarginBelow(int i, int i2) {
            if (this.mMargins != null || i2 != 0) {
                ensureMargins();
                this.mMargins[(i * 2) + 1] = i2;
            }
        }

        public String toString() {
            StringBuilder stringBuilder;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("LayoutRecord{c=");
            stringBuilder2.append(this.column);
            stringBuilder2.append(", id=");
            stringBuilder2.append(this.id);
            stringBuilder2.append(" h=");
            stringBuilder2.append(this.height);
            stringBuilder2.append(" s=");
            stringBuilder2.append(this.span);
            String stringBuilder3 = stringBuilder2.toString();
            if (this.mMargins != null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(" margins[above, below](");
                stringBuilder3 = stringBuilder.toString();
                for (int i = 0; i < this.mMargins.length; i += 2) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(stringBuilder3);
                    stringBuilder4.append("[");
                    stringBuilder4.append(this.mMargins[i]);
                    stringBuilder4.append(", ");
                    stringBuilder4.append(this.mMargins[i + 1]);
                    stringBuilder4.append("]");
                    stringBuilder3 = stringBuilder4.toString();
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(")");
                stringBuilder3 = stringBuilder.toString();
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append(stringBuilder3);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public interface OnItemClickListener {
        void onItemClick(StaggeredGridView staggeredGridView, View view, int i, long j);
    }

    public interface OnItemLongClickListener {
        boolean onItemLongClick(StaggeredGridView staggeredGridView, View view, int i, long j);
    }

    private class RecycleBin {
        private int mMaxScrap;
        private ArrayList<View>[] mScrapViews;
        private SparseArray<View> mTransientStateViews;
        private int mViewTypeCount;

        private RecycleBin() {
        }

        public void setViewTypeCount(int i) {
            if (i < 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Must have at least one view type (");
                stringBuilder.append(i);
                stringBuilder.append(" types reported)");
                throw new IllegalArgumentException(stringBuilder.toString());
            } else if (i != this.mViewTypeCount) {
                ArrayList[] arrayListArr = new ArrayList[i];
                for (int i2 = 0; i2 < i; i2++) {
                    arrayListArr[i2] = new ArrayList();
                }
                this.mViewTypeCount = i;
                this.mScrapViews = arrayListArr;
            }
        }

        public void clear() {
            int i = this.mViewTypeCount;
            for (int i2 = 0; i2 < i; i2++) {
                this.mScrapViews[i2].clear();
            }
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray != null) {
                sparseArray.clear();
            }
        }

        public void clearTransientViews() {
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray != null) {
                sparseArray.clear();
            }
        }

        public void addScrap(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            if (ViewCompat.hasTransientState(view)) {
                if (this.mTransientStateViews == null) {
                    this.mTransientStateViews = new SparseArray();
                }
                this.mTransientStateViews.put(layoutParams.position, view);
                return;
            }
            int childCount = StaggeredGridView.this.getChildCount();
            if (childCount > this.mMaxScrap) {
                this.mMaxScrap = childCount;
            }
            ArrayList arrayList = this.mScrapViews[layoutParams.viewType];
            if (arrayList.size() < this.mMaxScrap) {
                arrayList.add(view);
            }
        }

        public View getTransientStateView(int i) {
            SparseArray sparseArray = this.mTransientStateViews;
            if (sparseArray == null) {
                return null;
            }
            View view = (View) sparseArray.get(i);
            if (view != null) {
                this.mTransientStateViews.remove(i);
            }
            return view;
        }

        public View getScrapView(int i) {
            ArrayList arrayList = this.mScrapViews[i];
            if (arrayList.isEmpty()) {
                return null;
            }
            int size = arrayList.size() - 1;
            View view = (View) arrayList.get(size);
            arrayList.remove(size);
            return view;
        }
    }

    static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public SavedState[] newArray(int i) {
                return new SavedState[i];
            }
        };
        long firstId;
        ArrayList<ColMap> mapping;
        int position;
        int[] topOffsets;


        SavedState(Parcelable parcelable) {
            super(parcelable);
            this.firstId = -1;
        }

        private SavedState(Parcel parcel) {
            super(parcel);
            this.firstId = -1;
            this.firstId = parcel.readLong();
            this.position = parcel.readInt();
            parcel.readIntArray(this.topOffsets);
            parcel.readTypedList(this.mapping, ColMap.CREATOR);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeLong(this.firstId);
            parcel.writeInt(this.position);
            parcel.writeIntArray(this.topOffsets);
            parcel.writeTypedList(this.mapping);
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("StaggereGridView.SavedState{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" firstId=");
            stringBuilder.append(this.firstId);
            stringBuilder.append(" position=");
            stringBuilder.append(this.position);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public interface SelectionBoundsAdjuster {
        void adjustListItemSelectionBounds(Rect rect);
    }

    private class WindowRunnnable {
        private int mOriginalAttachCount;

        private WindowRunnnable() {
        }

        public void rememberWindowAttachCount() {
            this.mOriginalAttachCount = StaggeredGridView.this.getWindowAttachCount();
        }

        public boolean sameWindow() {
            return StaggeredGridView.this.hasWindowFocus() && StaggeredGridView.this.getWindowAttachCount() == this.mOriginalAttachCount;
        }
    }

    private class CheckForLongPress extends WindowRunnnable implements Runnable {
        private CheckForLongPress() {
            super();
        }

        public void run() {
            int access$2300 = StaggeredGridView.this.mMotionPosition;
            StaggeredGridView staggeredGridView = StaggeredGridView.this;
            View childAt = staggeredGridView.getChildAt(access$2300 - staggeredGridView.mFirstPosition);
            if (childAt != null) {
                boolean performLongPress = (!sameWindow() || StaggeredGridView.this.mDataChanged) ? false : StaggeredGridView.this.performLongPress(childAt, StaggeredGridView.this.mMotionPosition, StaggeredGridView.this.mAdapter.getItemId(StaggeredGridView.this.mMotionPosition));
                if (performLongPress) {
                    StaggeredGridView.this.mTouchMode = 6;
                    StaggeredGridView.this.setPressed(false);
                    childAt.setPressed(false);
                    return;
                }
                StaggeredGridView.this.mTouchMode = 5;
            }
        }
    }

    private class PerformClick extends WindowRunnnable implements Runnable {
        int mClickMotionPosition;

        private PerformClick() {
            super();
        }

        public void run() {
            if (!StaggeredGridView.this.mDataChanged) {
                ListAdapter access$800 = StaggeredGridView.this.mAdapter;
                int i = this.mClickMotionPosition;
                if (access$800 != null && StaggeredGridView.this.mItemCount > 0 && i != -1 && i < access$800.getCount() && sameWindow()) {
                    StaggeredGridView staggeredGridView = StaggeredGridView.this;
                    View childAt = staggeredGridView.getChildAt(i - staggeredGridView.mFirstPosition);
                    if (childAt != null) {
                        StaggeredGridView.this.performItemClick(childAt, i, access$800.getItemId(i));
                    }
                }
            }
        }
    }

    public void hideSelector() {
    }

    public StaggeredGridView(Context context) {
        this(context, null);
    }

    public StaggeredGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public StaggeredGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mColCountSetting = 2;
        this.mColCount = 2;
        this.mMinColWidth = 0;
        this.mRecycler = new RecycleBin();
        this.mObserver = new AdapterDataSetObserver();
        this.mVelocityTracker = VelocityTracker.obtain();
        this.mColMappings = new ArrayList();
        this.mContextMenuInfo = null;
        this.mDrawSelectorOnTop = false;
        this.mSelectionLeftPadding = 0;
        this.mSelectionTopPadding = 0;
        this.mSelectionRightPadding = 0;
        this.mSelectionBottomPadding = 0;
        this.mSelectorRect = new Rect();
        this.mSelectorPosition = -1;
        this.mLayoutRecords = new SparseArrayCompat();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.StaggeredGridView);
            this.mColCount = obtainStyledAttributes.getInteger(9, 2);
            this.mDrawSelectorOnTop = obtainStyledAttributes.getBoolean(3, false);
        } else {
            this.mColCount = 2;
            this.mDrawSelectorOnTop = false;
        }
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        this.mFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mScroller = ScrollerCompat.from(context);
        this.mTopEdge = new EdgeEffectCompat(context);
        this.mBottomEdge = new EdgeEffectCompat(context);
        setWillNotDraw(false);
        setClipToPadding(false);
        setFocusableInTouchMode(false);
        if (this.mSelector == null) {
            useDefaultSelector();
        }
    }

    public void setColumnCount(int i) {
        Object obj = 1;
        if (i >= 1 || i == -1) {
            if (i == this.mColCount) {
                obj = null;
            }
            this.mColCountSetting = i;
            this.mColCount = i;
            if (obj != null) {
                populate(false);
                return;
            }
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Column count must be at least 1 - received ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public int getColumnCount() {
        return this.mColCount;
    }

    public void setMinColumnWidth(int i) {
        this.mMinColWidth = i;
        setColumnCount(-1);
    }

    public void setItemMargin(int i) {
        Object obj = i != this.mItemMargin ? 1 : null;
        this.mItemMargin = i;
        if (obj != null) {
            populate(false);
        }
    }

    public int getFirstPosition() {
        return this.mFirstPosition;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        this.mVelocityTracker.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.mVelocityTracker.clear();
            this.mScroller.abortAnimation();
            this.mLastTouchY = motionEvent.getY();
            this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent, 0);
            this.mTouchRemainderY = 0.0f;
            if (this.mTouchMode == 2) {
                this.mTouchMode = 1;
                return true;
            }
        } else if (action == 2) {
            action = MotionEventCompat.findPointerIndex(motionEvent, this.mActivePointerId);
            if (action < 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onInterceptTouchEvent could not find pointer with id ");
                stringBuilder.append(this.mActivePointerId);
                stringBuilder.append(" - did StaggeredGridView receive an inconsistent event stream?");
                Log.e(TAG, stringBuilder.toString());
                return false;
            }
            float y = (MotionEventCompat.getY(motionEvent, action) - this.mLastTouchY) + this.mTouchRemainderY;
            this.mTouchRemainderY = y - ((float) ((int) y));
            if (Math.abs(y) > ((float) this.mTouchSlop)) {
                this.mTouchMode = 1;
                return true;
            }
        }
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        this.mVelocityTracker.addMovement(motionEvent2);
        int action = motionEvent.getAction() & 255;
        int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        float x;
        float x2;
        if (action == 0) {
            this.mVelocityTracker.clear();
            this.mScroller.abortAnimation();
            this.mLastTouchY = motionEvent.getY();
            x = motionEvent.getX();
            this.mLastTouchX = x;
            action = pointToPosition((int) x, (int) this.mLastTouchY);
            this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent2, 0);
            this.mTouchRemainderY = 0.0f;
            if (this.mTouchMode != 2 && !this.mDataChanged && action >= 0 && getAdapter().isEnabled(action)) {
                this.mTouchMode = 3;
                this.mBeginClick = true;
                if (this.mPendingCheckForTap == null) {
                    this.mPendingCheckForTap = new CheckForTap();
                }
                postDelayed(this.mPendingCheckForTap, (long) ViewConfiguration.getTapTimeout());
            }
            this.mMotionPosition = action;
            invalidate();
        } else if (action == 1) {
            this.mVelocityTracker.computeCurrentVelocity(1000, (float) this.mMaximumVelocity);
            x = VelocityTrackerCompat.getYVelocity(this.mVelocityTracker, this.mActivePointerId);
            int i = this.mTouchMode;
            if (Math.abs(x) > ((float) this.mFlingVelocity)) {
                this.mTouchMode = 2;
                this.mScroller.fling(0, 0, 0, (int) x, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
                this.mLastTouchY = 0.0f;
                invalidate();
            } else {
                this.mTouchMode = 0;
            }
            if (this.mDataChanged || !this.mAdapter.isEnabled(pointToPosition)) {
                this.mTouchMode = 6;
            } else {
                this.mTouchMode = 4;
            }
            if (i == 3 || i == 4 || i == 5) {
                final View childAt = getChildAt(pointToPosition - this.mFirstPosition);
                x2 = motionEvent.getX();
                Object obj = (x2 <= ((float) getPaddingLeft()) || x2 >= ((float) (getWidth() - getPaddingRight()))) ? null : 1;
                if (!(childAt == null || childAt.hasFocusable() || obj == null)) {
                    if (this.mTouchMode != 3) {
                        childAt.setPressed(false);
                    }
                    if (this.mPerformClick == null) {
                        invalidate();
                        this.mPerformClick = new PerformClick();
                    }
                    final PerformClick performClick = this.mPerformClick;
                    performClick.mClickMotionPosition = pointToPosition;
                    performClick.rememberWindowAttachCount();
                    i = this.mTouchMode;
                    if (i == 3 || i == 4) {
                        Handler handler = getHandler();
                        if (handler != null) {
                            handler.removeCallbacks(this.mTouchMode == 3 ? this.mPendingCheckForTap : this.mPendingCheckForLongPress);
                        }
                        if (this.mDataChanged || !this.mAdapter.isEnabled(pointToPosition)) {
                            this.mTouchMode = 6;
                        } else {
                            this.mTouchMode = 4;
                            layoutChildren(this.mDataChanged);
                            childAt.setPressed(true);
                            positionSelector(this.mMotionPosition, childAt);
                            setPressed(true);
                            Drawable drawable = this.mSelector;
                            if (drawable != null) {
                                drawable = drawable.getCurrent();
                                if (drawable != null && (drawable instanceof TransitionDrawable)) {
                                    ((TransitionDrawable) drawable).resetTransition();
                                }
                            }
                            Runnable runnable = this.mTouchModeReset;
                            if (runnable != null) {
                                removeCallbacks(runnable);
                            }
                            Runnable run = new Runnable() {
                                public void run() {
                                    StaggeredGridView.this.mTouchMode = 6;
                                    childAt.setPressed(false);
                                    StaggeredGridView.this.setPressed(false);
                                    if (!StaggeredGridView.this.mDataChanged) {
                                        performClick.run();
                                    }
                                }
                            };
                            this.mTouchModeReset = run;
                            postDelayed(run, (long) ViewConfiguration.getPressedStateDuration());
                        }
                        return true;
                    } else if (!this.mDataChanged && this.mAdapter.isEnabled(pointToPosition)) {
                        performClick.run();
                    }
                }
                this.mTouchMode = 6;
            }
            this.mBeginClick = false;
            updateSelectorState();
        } else if (action == 2) {
            action = MotionEventCompat.findPointerIndex(motionEvent2, this.mActivePointerId);
            if (action < 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onInterceptTouchEvent could not find pointer with id ");
                stringBuilder.append(this.mActivePointerId);
                stringBuilder.append(" - did StaggeredGridView receive an inconsistent event stream?");
                Log.e(TAG, stringBuilder.toString());
                return false;
            }
            x2 = MotionEventCompat.getY(motionEvent2, action);
            x = (x2 - this.mLastTouchY) + this.mTouchRemainderY;
            pointToPosition = (int) x;
            this.mTouchRemainderY = x - ((float) pointToPosition);
            if (Math.abs(x) > ((float) this.mTouchSlop)) {
                this.mTouchMode = 1;
            }
            if (this.mTouchMode == 1) {
                this.mLastTouchY = x2;
                if (!trackMotionScroll(pointToPosition, true)) {
                    this.mVelocityTracker.clear();
                }
            }
            updateSelectorState();
        } else if (action == 3) {
            this.mTouchMode = 0;
            updateSelectorState();
            setPressed(false);
            View childAt2 = getChildAt(this.mMotionPosition - this.mFirstPosition);
            if (childAt2 != null) {
                childAt2.setPressed(false);
            }
            Handler handler2 = getHandler();
            if (handler2 != null) {
                handler2.removeCallbacks(this.mPendingCheckForLongPress);
            }
            EdgeEffectCompat edgeEffectCompat = this.mTopEdge;
            if (edgeEffectCompat != null) {
                edgeEffectCompat.onRelease();
                this.mBottomEdge.onRelease();
            }
            this.mTouchMode = 0;
        }
        return true;
    }

    private boolean trackMotionScroll(int i, boolean z) {
        int overScrollMode;
        boolean contentFits = contentFits();
        int abs = Math.abs(i);
        int i2;
        if (contentFits) {
            i2 = 0;
        } else {
            int fillUp;
            Object obj;
            this.mPopulating = true;
            if (i > 0) {
                fillUp = fillUp(this.mFirstPosition - 1, abs) + this.mItemMargin;
                obj = 1;
            } else {
                fillUp = fillDown(this.mFirstPosition + getChildCount(), abs) + this.mItemMargin;
                obj = null;
            }
            i2 = Math.min(fillUp, abs);
            offsetChildren(obj != null ? i2 : -i2);
            recycleOffscreenViews();
            this.mPopulating = false;
            abs -= fillUp;
        }
        if (z) {
            overScrollMode = ViewCompat.getOverScrollMode(this);
            if ((overScrollMode == 0 || (overScrollMode == 1 && !contentFits)) && abs > 0) {
                (i > 0 ? this.mTopEdge : this.mBottomEdge).onPull(((float) Math.abs(i)) / ((float) getHeight()));
                invalidate();
            }
        }
        overScrollMode = this.mSelectorPosition;
        if (overScrollMode != -1) {
            overScrollMode -= this.mFirstPosition;
            if (overScrollMode >= 0 && overScrollMode < getChildCount()) {
                positionSelector(-1, getChildAt(overScrollMode));
            }
        } else {
            this.mSelectorRect.setEmpty();
        }
        if (i == 0 || i2 != 0) {
            return true;
        }
        return false;
    }

    private final boolean contentFits() {
        if (this.mFirstPosition != 0 || getChildCount() != this.mItemCount) {
            return false;
        }
        int i = Integer.MAX_VALUE;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = 0; i3 < this.mColCount; i3++) {
            int[] iArr = this.mItemTops;
            if (iArr[i3] < i) {
                i = iArr[i3];
            }
            iArr = this.mItemBottoms;
            if (iArr[i3] > i2) {
                i2 = iArr[i3];
            }
        }
        if (i < getPaddingTop() || i2 > getHeight() - getPaddingBottom()) {
            return false;
        }
        return true;
    }

    private void recycleAllViews() {
        for (int i = 0; i < getChildCount(); i++) {
            this.mRecycler.addScrap(getChildAt(i));
        }
        if (this.mInLayout) {
            removeAllViewsInLayout();
        } else {
            removeAllViews();
        }
    }

    private void recycleOffscreenViews() {
        View childAt;
        int height = getHeight();
        int i = this.mItemMargin;
        int i2 = -i;
        height += i;
        for (i = getChildCount() - 1; i >= 0; i--) {
            childAt = getChildAt(i);
            if (childAt.getTop() <= height) {
                break;
            }
            if (this.mInLayout) {
                removeViewsInLayout(i, 1);
            } else {
                removeViewAt(i);
            }
            this.mRecycler.addScrap(childAt);
        }
        while (getChildCount() > 0) {
            View childAt2 = getChildAt(0);
            if (childAt2.getBottom() >= i2) {
                break;
            }
            if (this.mInLayout) {
                removeViewsInLayout(0, 1);
            } else {
                removeViewAt(0);
            }
            this.mRecycler.addScrap(childAt2);
            this.mFirstPosition++;
        }
        height = getChildCount();
        if (height > 0) {
            Arrays.fill(this.mItemTops, Integer.MAX_VALUE);
            Arrays.fill(this.mItemBottoms, Integer.MIN_VALUE);
            for (i2 = 0; i2 < height; i2++) {
                childAt = getChildAt(i2);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int top = childAt.getTop() - this.mItemMargin;
                int bottom = childAt.getBottom();
                LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(this.mFirstPosition + i2);
                int min = layoutParams.column + Math.min(this.mColCount, layoutParams.span);
                for (int i3 = layoutParams.column; i3 < min; i3++) {
                    int marginAbove = top - layoutRecord.getMarginAbove(i3 - layoutParams.column);
                    int marginBelow = layoutRecord.getMarginBelow(i3 - layoutParams.column) + bottom;
                    int[] iArr = this.mItemTops;
                    if (marginAbove < iArr[i3]) {
                        iArr[i3] = marginAbove;
                    }
                    int[] iArr2 = this.mItemBottoms;
                    if (marginBelow > iArr2[i3]) {
                        iArr2[i3] = marginBelow;
                    }
                }
            }
            for (height = 0; height < this.mColCount; height++) {
                int[] iArr3 = this.mItemTops;
                if (iArr3[height] == Integer.MAX_VALUE) {
                    iArr3[height] = 0;
                    this.mItemBottoms[height] = 0;
                }
            }
        }
    }

    public void computeScroll() {
        if (this.mScroller.computeScrollOffset()) {
            float currY = (float) this.mScroller.getCurrY();
            int i = (int) (currY - this.mLastTouchY);
            this.mLastTouchY = currY;
            boolean trackMotionScroll = !trackMotionScroll(i, false);
            if (trackMotionScroll || this.mScroller.isFinished()) {
                if (trackMotionScroll) {
                    if (ViewCompat.getOverScrollMode(this) != 2) {
                        EdgeEffectCompat edgeEffectCompat;
                        if (i > 0) {
                            edgeEffectCompat = this.mTopEdge;
                        } else {
                            edgeEffectCompat = this.mBottomEdge;
                        }
                        edgeEffectCompat.onAbsorb(Math.abs((int) this.mScroller.getCurrVelocity()));
                        postInvalidate();
                    }
                    this.mScroller.abortAnimation();
                }
                this.mTouchMode = 0;
                return;
            }
            postInvalidate();
        }
    }

    public void dispatchDraw(Canvas canvas) {
        boolean z = this.mDrawSelectorOnTop;
        if (!z) {
            drawSelector(canvas);
        }
        super.dispatchDraw(canvas);
        if (z) {
            drawSelector(canvas);
        }
    }

    private void drawSelector(Canvas canvas) {
        if (!this.mSelectorRect.isEmpty()) {
            Drawable drawable = this.mSelector;
            if (drawable != null && this.mBeginClick) {
                drawable.setBounds(this.mSelectorRect);
                drawable.draw(canvas);
            }
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        EdgeEffectCompat edgeEffectCompat = this.mTopEdge;
        if (edgeEffectCompat != null) {
            Object obj = null;
            Object obj2 = 1;
            if (!edgeEffectCompat.isFinished()) {
                this.mTopEdge.draw(canvas);
                obj = 1;
            }
            if (this.mBottomEdge.isFinished()) {
                obj2 = obj;
            } else {
                int save = canvas.save();
                int width = getWidth();
                canvas.translate((float) (-width), (float) getHeight());
                canvas.rotate(180.0f, (float) width, 0.0f);
                this.mBottomEdge.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (obj2 != null) {
                invalidate();
            }
        }
    }

    public void beginFastChildLayout() {
        this.mFastChildLayout = true;
    }

    public void endFastChildLayout() {
        this.mFastChildLayout = false;
        populate(false);
    }

    public void requestLayout() {
        if (!this.mPopulating && !this.mFastChildLayout) {
            super.requestLayout();
        }
    }

    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        i = MeasureSpec.getSize(i);
        setMeasuredDimension(i, MeasureSpec.getSize(i2));
        if (this.mColCountSetting == -1) {
            i /= this.mMinColWidth;
            if (i != this.mColCount) {
                this.mColCount = i;
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.mInLayout = true;
        populate(false);
        this.mInLayout = false;
        i3 -= i;
        i4 -= i2;
        this.mTopEdge.setSize(i3, i4);
        this.mBottomEdge.setSize(i3, i4);
    }

    private void populate(boolean z) {
        if (getWidth() != 0 && getHeight() != 0) {
            int width;
            int i;
            if (this.mColCount == -1) {
                width = getWidth() / this.mMinColWidth;
                if (width != this.mColCount) {
                    this.mColCount = width;
                }
            }
            width = this.mColCount;
            if (this.mColMappings.size() != this.mColCount) {
                this.mColMappings.clear();
                for (i = 0; i < this.mColCount; i++) {
                    this.mColMappings.add(new ArrayList());
                }
            }
            int[] iArr = this.mItemTops;
            if (iArr == null || iArr.length != width) {
                this.mItemTops = new int[width];
                this.mItemBottoms = new int[width];
                this.mLayoutRecords.clear();
                if (this.mInLayout) {
                    removeAllViewsInLayout();
                } else {
                    removeAllViews();
                }
            }
            i = getPaddingTop();
            int i2 = 0;
            while (i2 < width) {
                int[] iArr2 = this.mRestoreOffsets;
                int min = (iArr2 != null ? Math.min(iArr2[i2], 0) : 0) + i;
                int[] iArr3 = this.mItemTops;
                iArr3[i2] = min == 0 ? iArr3[i2] : min;
                iArr3 = this.mItemBottoms;
                if (min == 0) {
                    min = iArr3[i2];
                }
                iArr3[i2] = min;
                i2++;
            }
            this.mPopulating = true;
            layoutChildren(this.mDataChanged);
            fillDown(this.mFirstPosition + getChildCount(), 0);
            fillUp(this.mFirstPosition - 1, 0);
            this.mPopulating = false;
            this.mDataChanged = false;
            if (z) {
                int[] iArr4 = this.mRestoreOffsets;
                if (iArr4 != null) {
                    Arrays.fill(iArr4, 0);
                }
            }
        }
    }

    public final void offsetChildren(int i) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            childAt.layout(childAt.getLeft(), childAt.getTop() + i, childAt.getRight(), childAt.getBottom() + i);
        }
        childCount = this.mColCount;
        for (int i3 = 0; i3 < childCount; i3++) {
            int[] iArr = this.mItemTops;
            iArr[i3] = iArr[i3] + i;
            iArr = this.mItemBottoms;
            iArr[i3] = iArr[i3] + i;
        }
    }

    public final void layoutChildren(boolean z) {
        int i;
        int makeMeasureSpec;
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int i2 = this.mItemMargin;
        int width = (getWidth() - paddingLeft) - paddingRight;
        paddingRight = this.mColCount;
        width = (width - ((paddingRight - 1) * i2)) / paddingRight;
        this.mColWidth = width;
        Arrays.fill(this.mItemBottoms, Integer.MIN_VALUE);
        paddingRight = getChildCount();
        int i3 = 0;
        int i4 = -1;
        int i5 = -1;
        int i6 = 0;
        while (i3 < paddingRight) {
            int i7;
            int i8;
            int i9;
            View childAt = getChildAt(i3);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            int i10 = layoutParams.column;
            int i11 = this.mFirstPosition + i3;
            Object obj = (z || childAt.isLayoutRequested()) ? 1 : null;
            if (z) {
                View obtainView = obtainView(i11, childAt);
                if (obtainView == null) {
                    removeViewAt(i3);
                    i7 = i3 - 1;
                    if (i7 >= 0) {
                        invalidateLayoutRecordsAfterPosition(i7);
                    }
                    i6++;
                    i8 = paddingLeft;
                    i = paddingRight;
                    i3++;
                    paddingLeft = i8;
                    paddingRight = i;
                } else {
                    if (obtainView != childAt) {
                        removeViewAt(i3);
                        addView(obtainView, i3);
                        childAt = obtainView;
                    }
                    layoutParams = (LayoutParams) childAt.getLayoutParams();
                }
            }
            int min = Math.min(this.mColCount, layoutParams.span);
            i7 = (width * min) + ((min - 1) * i2);
            if (obj != null) {
                i7 = MeasureSpec.makeMeasureSpec(i7, Ints.MAX_POWER_OF_TWO);
                i = paddingRight;
                if (layoutParams.height == -2) {
                    makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
                } else {
                    makeMeasureSpec = MeasureSpec.makeMeasureSpec(layoutParams.height, Ints.MAX_POWER_OF_TWO);
                }
                childAt.measure(i7, makeMeasureSpec);
            } else {
                i = paddingRight;
            }
            int[] iArr = this.mItemBottoms;
            i7 = iArr[i10] > Integer.MIN_VALUE ? iArr[i10] + this.mItemMargin : childAt.getTop();
            if (min > 1) {
                for (makeMeasureSpec = i10 + 1; makeMeasureSpec < i10 + min; makeMeasureSpec++) {
                    i9 = this.mItemBottoms[makeMeasureSpec] + this.mItemMargin;
                    if (i9 > i7) {
                        i7 = i9;
                    }
                }
            }
            paddingRight = childAt.getMeasuredHeight();
            makeMeasureSpec = i7 + paddingRight;
            i9 = ((width + i2) * i10) + paddingLeft;
            i8 = paddingLeft;
            childAt.layout(i9, i7, i9 + childAt.getMeasuredWidth(), makeMeasureSpec);
            for (paddingLeft = i10; paddingLeft < i10 + min; paddingLeft++) {
                this.mItemBottoms[paddingLeft] = makeMeasureSpec;
            }
            LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(i11);
            if (!(layoutRecord == null || layoutRecord.height == paddingRight)) {
                layoutRecord.height = paddingRight;
                i4 = i11;
            }
            if (!(layoutRecord == null || layoutRecord.span == min)) {
                layoutRecord.span = min;
                i5 = i11;
            }
            i3++;
            paddingLeft = i8;
            paddingRight = i;
        }
        i = paddingRight;
        for (paddingLeft = 0; paddingLeft < this.mColCount; paddingLeft++) {
            int[] iArr2 = this.mItemBottoms;
            if (iArr2[paddingLeft] == Integer.MIN_VALUE) {
                iArr2[paddingLeft] = this.mItemTops[paddingLeft];
            }
        }
        if (i4 >= 0 || i5 >= 0) {
            if (i4 >= 0) {
                invalidateLayoutRecordsBeforePosition(i4);
            }
            if (i5 >= 0) {
                invalidateLayoutRecordsAfterPosition(i5);
            }
            for (makeMeasureSpec = 0; makeMeasureSpec < i - i6; makeMeasureSpec++) {
                paddingLeft = this.mFirstPosition + makeMeasureSpec;
                View childAt2 = getChildAt(makeMeasureSpec);
                LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                LayoutRecord layoutRecord2 = (LayoutRecord) this.mLayoutRecords.get(paddingLeft);
                if (layoutRecord2 == null) {
                    layoutRecord2 = new LayoutRecord();
                    this.mLayoutRecords.put(paddingLeft, layoutRecord2);
                }
                layoutRecord2.column = layoutParams2.column;
                layoutRecord2.height = childAt2.getHeight();
                layoutRecord2.id = layoutParams2.id;
                layoutRecord2.span = Math.min(this.mColCount, layoutParams2.span);
            }
        }
        View childAt3;
        if (this.mSelectorPosition != -1) {
            childAt3 = getChildAt(this.mMotionPosition - this.mFirstPosition);
            if (childAt3 != null) {
                positionSelector(this.mMotionPosition, childAt3);
            }
        } else if (this.mTouchMode > 3) {
            childAt3 = getChildAt(this.mMotionPosition - this.mFirstPosition);
            if (childAt3 != null) {
                positionSelector(this.mMotionPosition, childAt3);
            }
        } else {
            this.mSelectorRect.setEmpty();
        }
    }

    /* Access modifiers changed, original: final */
    public final void invalidateLayoutRecordsBeforePosition(int i) {
        int i2 = 0;
        while (i2 < this.mLayoutRecords.size() && this.mLayoutRecords.keyAt(i2) < i) {
            i2++;
        }
        this.mLayoutRecords.removeAtRange(0, i2);
    }

    /* Access modifiers changed, original: final */
    public final void invalidateLayoutRecordsAfterPosition(int i) {
        int size = this.mLayoutRecords.size() - 1;
        while (size >= 0 && this.mLayoutRecords.keyAt(size) > i) {
            size--;
        }
        size++;
        SparseArrayCompat sparseArrayCompat = this.mLayoutRecords;
        sparseArrayCompat.removeAtRange(size + 1, sparseArrayCompat.size() - size);
    }

    /* Access modifiers changed, original: final */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00e4  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ed  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x012a  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0118  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0140 A:{LOOP_END, LOOP:3: B:64:0x013c->B:66:0x0140} */
    public final int fillUp(int r19, int r20) {
        /*
        r18 = this;
        r0 = r18;
        r1 = r18.getPaddingLeft();
        r2 = r18.getPaddingRight();
        r3 = r0.mItemMargin;
        r4 = r18.getWidth();
        r4 = r4 - r1;
        r4 = r4 - r2;
        r2 = r0.mColCount;
        r5 = r2 + -1;
        r5 = r5 * r3;
        r4 = r4 - r5;
        r4 = r4 / r2;
        r0.mColWidth = r4;
        r2 = r18.getPaddingTop();
        r5 = r2 - r20;
        r6 = r18.getNextColumnUp();
        r7 = r6;
        r6 = r19;
    L_0x0029:
        r8 = 0;
        if (r7 < 0) goto L_0x015b;
    L_0x002c:
        r9 = r0.mItemTops;
        r9 = r9[r7];
        if (r9 <= r5) goto L_0x015b;
    L_0x0032:
        if (r6 < 0) goto L_0x015b;
    L_0x0034:
        r9 = r0.mColMappings;
        r9 = r9.get(r7);
        r9 = (java.util.ArrayList) r9;
        r10 = java.lang.Integer.valueOf(r6);
        r9 = r9.contains(r10);
        if (r9 != 0) goto L_0x0066;
    L_0x0046:
        r9 = 0;
    L_0x0047:
        r10 = r0.mColMappings;
        r10 = r10.size();
        if (r9 >= r10) goto L_0x0066;
    L_0x004f:
        r10 = r0.mColMappings;
        r10 = r10.get(r9);
        r10 = (java.util.ArrayList) r10;
        r11 = java.lang.Integer.valueOf(r6);
        r10 = r10.contains(r11);
        if (r10 == 0) goto L_0x0063;
    L_0x0061:
        r7 = r9;
        goto L_0x0066;
    L_0x0063:
        r9 = r9 + 1;
        goto L_0x0047;
    L_0x0066:
        r9 = 0;
        r10 = r0.obtainView(r6, r9);
        if (r10 != 0) goto L_0x006e;
    L_0x006d:
        goto L_0x0029;
    L_0x006e:
        r11 = r10.getLayoutParams();
        r11 = (social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.LayoutParams) r11;
        if (r11 != 0) goto L_0x007d;
    L_0x0076:
        r11 = r18.generateDefaultLayoutParams();
        r10.setLayoutParams(r11);
    L_0x007d:
        r12 = r10.getParent();
        if (r12 == r0) goto L_0x008e;
    L_0x0083:
        r12 = r0.mInLayout;
        if (r12 == 0) goto L_0x008b;
    L_0x0087:
        r0.addViewInLayout(r10, r8, r11);
        goto L_0x008e;
    L_0x008b:
        r0.addView(r10, r8);
    L_0x008e:
        r12 = r0.mColCount;
        r13 = r11.span;
        r12 = java.lang.Math.min(r12, r13);
        r13 = r4 * r12;
        r14 = r12 + -1;
        r14 = r14 * r3;
        r13 = r13 + r14;
        r14 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r14);
        r15 = 1;
        if (r12 <= r15) goto L_0x00ab;
    L_0x00a6:
        r16 = r0.getNextRecordUp(r6, r12);
        goto L_0x00b5;
    L_0x00ab:
        r15 = r0.mLayoutRecords;
        r15 = r15.get(r6);
        r16 = r15;
        r16 = (social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.LayoutRecord) r16;
    L_0x00b5:
        r15 = r16;
        if (r15 != 0) goto L_0x00c8;
    L_0x00b9:
        r15 = new social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView$LayoutRecord;
        r15.<init>(r9);
        r9 = r0.mLayoutRecords;
        r9.put(r6, r15);
        r15.column = r7;
        r15.span = r12;
        goto L_0x00d2;
    L_0x00c8:
        r9 = r15.span;
        if (r12 == r9) goto L_0x00d2;
    L_0x00cc:
        r15.span = r12;
        r15.column = r7;
        r9 = 1;
        goto L_0x00d3;
    L_0x00d2:
        r9 = 0;
    L_0x00d3:
        r14 = r0.mHasStableIds;
        if (r14 == 0) goto L_0x00e4;
    L_0x00d7:
        r14 = r0.mAdapter;
        r17 = r9;
        r8 = r14.getItemId(r6);
        r15.id = r8;
        r11.id = r8;
        goto L_0x00e6;
    L_0x00e4:
        r17 = r9;
    L_0x00e6:
        r11.column = r7;
        r8 = r11.height;
        r9 = -2;
        if (r8 != r9) goto L_0x00f3;
    L_0x00ed:
        r8 = 0;
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r8);
        goto L_0x00fb;
    L_0x00f3:
        r8 = r11.height;
        r9 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r9);
    L_0x00fb:
        r10.measure(r13, r8);
        r8 = r10.getMeasuredHeight();
        if (r17 != 0) goto L_0x010c;
    L_0x0104:
        r9 = r15.height;
        if (r8 == r9) goto L_0x010f;
    L_0x0108:
        r9 = r15.height;
        if (r9 <= 0) goto L_0x010f;
    L_0x010c:
        r0.invalidateLayoutRecordsBeforePosition(r6);
    L_0x010f:
        r15.height = r8;
        r9 = r0.mItemTops;
        r11 = r9[r7];
        r13 = 1;
        if (r12 <= r13) goto L_0x012a;
    L_0x0118:
        r9 = r9[r7];
        r11 = r7 + 1;
    L_0x011c:
        r13 = r7 + r12;
        if (r11 >= r13) goto L_0x012c;
    L_0x0120:
        r13 = r0.mItemTops;
        r13 = r13[r11];
        if (r13 >= r9) goto L_0x0127;
    L_0x0126:
        r9 = r13;
    L_0x0127:
        r11 = r11 + 1;
        goto L_0x011c;
    L_0x012a:
        r9 = r9[r7];
    L_0x012c:
        r8 = r9 - r8;
        r11 = r4 + r3;
        r11 = r11 * r7;
        r11 = r11 + r1;
        r13 = r10.getMeasuredWidth();
        r13 = r13 + r11;
        r10.layout(r11, r8, r13, r9);
        r9 = r7;
    L_0x013c:
        r10 = r7 + r12;
        if (r9 >= r10) goto L_0x0150;
    L_0x0140:
        r10 = r0.mItemTops;
        r11 = r9 - r7;
        r11 = r15.getMarginAbove(r11);
        r11 = r8 - r11;
        r11 = r11 - r3;
        r10[r9] = r11;
        r9 = r9 + 1;
        goto L_0x013c;
    L_0x0150:
        r7 = r18.getNextColumnUp();
        r8 = r6 + -1;
        r0.mFirstPosition = r6;
        r6 = r8;
        goto L_0x0029;
    L_0x015b:
        r1 = r18.getHeight();
        r3 = 0;
    L_0x0160:
        r4 = r0.mColCount;
        if (r3 >= r4) goto L_0x0175;
    L_0x0164:
        r4 = r0.getFirstChildAtColumn(r3);
        if (r4 != 0) goto L_0x016b;
    L_0x016a:
        goto L_0x0176;
    L_0x016b:
        r4 = r4.getTop();
        if (r4 >= r1) goto L_0x0172;
    L_0x0171:
        r1 = r4;
    L_0x0172:
        r3 = r3 + 1;
        goto L_0x0160;
    L_0x0175:
        r8 = r1;
    L_0x0176:
        r2 = r2 - r8;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.fillUp(int, int):int");
    }

    private View getFirstChildAtColumn(int i) {
        if (getChildCount() > i) {
            for (int i2 = 0; i2 < this.mColCount; i2++) {
                View childAt = getChildAt(i2);
                int left = childAt.getLeft();
                if (childAt != null) {
                    int i3 = 0;
                    while (left > ((this.mColWidth + (this.mItemMargin * 2)) * i3) + getPaddingLeft()) {
                        i3++;
                    }
                    if (i3 == i) {
                        return childAt;
                    }
                }
            }
        }
        return null;
    }

    /* Access modifiers changed, original: final */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00b7  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00aa  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00fb  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00e7  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0120  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0158 A:{LOOP_END, LOOP:3: B:64:0x0154->B:66:0x0158} */
    public final int fillDown(int r19, int r20) {
        /*
        r18 = this;
        r0 = r18;
        r1 = r18.getPaddingLeft();
        r2 = r18.getPaddingRight();
        r3 = r0.mItemMargin;
        r4 = r18.getWidth();
        r4 = r4 - r1;
        r4 = r4 - r2;
        r2 = r0.mColCount;
        r5 = r2 + -1;
        r5 = r5 * r3;
        r4 = r4 - r5;
        r4 = r4 / r2;
        r2 = r18.getHeight();
        r5 = r18.getPaddingBottom();
        r2 = r2 - r5;
        r5 = r2 + r20;
        r6 = r18.getNextColumnDown(r19);
        r7 = r6;
        r6 = r19;
    L_0x002c:
        if (r7 < 0) goto L_0x016e;
    L_0x002e:
        r9 = r0.mItemBottoms;
        r9 = r9[r7];
        if (r9 >= r5) goto L_0x016e;
    L_0x0034:
        r9 = r0.mItemCount;
        if (r6 >= r9) goto L_0x016e;
    L_0x0038:
        r9 = 0;
        r10 = r0.obtainView(r6, r9);
        if (r10 != 0) goto L_0x0040;
    L_0x003f:
        goto L_0x002c;
    L_0x0040:
        r11 = r10.getLayoutParams();
        r11 = (social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.LayoutParams) r11;
        if (r11 != 0) goto L_0x004f;
    L_0x0048:
        r11 = r18.generateDefaultLayoutParams();
        r10.setLayoutParams(r11);
    L_0x004f:
        r12 = r10.getParent();
        if (r12 == r0) goto L_0x0061;
    L_0x0055:
        r12 = r0.mInLayout;
        if (r12 == 0) goto L_0x005e;
    L_0x0059:
        r12 = -1;
        r0.addViewInLayout(r10, r12, r11);
        goto L_0x0061;
    L_0x005e:
        r0.addView(r10);
    L_0x0061:
        r12 = r0.mColCount;
        r13 = r11.span;
        r12 = java.lang.Math.min(r12, r13);
        r13 = r4 * r12;
        r14 = r12 + -1;
        r14 = r14 * r3;
        r13 = r13 + r14;
        r14 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r13 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r14);
        r15 = 1;
        if (r12 <= r15) goto L_0x007e;
    L_0x0079:
        r16 = r0.getNextRecordDown(r6, r12);
        goto L_0x0088;
    L_0x007e:
        r15 = r0.mLayoutRecords;
        r15 = r15.get(r6);
        r16 = r15;
        r16 = (social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.LayoutRecord) r16;
    L_0x0088:
        r15 = r16;
        if (r15 != 0) goto L_0x009b;
    L_0x008c:
        r15 = new social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView$LayoutRecord;
        r15.<init>(r9);
        r9 = r0.mLayoutRecords;
        r9.put(r6, r15);
        r15.column = r7;
        r15.span = r12;
        goto L_0x00a5;
    L_0x009b:
        r9 = r15.span;
        if (r12 == r9) goto L_0x00a5;
    L_0x009f:
        r15.span = r12;
        r15.column = r7;
        r9 = 1;
        goto L_0x00a6;
    L_0x00a5:
        r9 = 0;
    L_0x00a6:
        r14 = r0.mHasStableIds;
        if (r14 == 0) goto L_0x00b7;
    L_0x00aa:
        r14 = r0.mAdapter;
        r17 = r9;
        r8 = r14.getItemId(r6);
        r15.id = r8;
        r11.id = r8;
        goto L_0x00b9;
    L_0x00b7:
        r17 = r9;
    L_0x00b9:
        r11.column = r7;
        r8 = r11.height;
        r9 = -2;
        if (r8 != r9) goto L_0x00c6;
    L_0x00c0:
        r8 = 0;
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r8);
        goto L_0x00ce;
    L_0x00c6:
        r8 = r11.height;
        r9 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r9);
    L_0x00ce:
        r10.measure(r13, r8);
        r8 = r10.getMeasuredHeight();
        if (r17 != 0) goto L_0x00df;
    L_0x00d7:
        r9 = r15.height;
        if (r8 == r9) goto L_0x00e2;
    L_0x00db:
        r9 = r15.height;
        if (r9 <= 0) goto L_0x00e2;
    L_0x00df:
        r0.invalidateLayoutRecordsAfterPosition(r6);
    L_0x00e2:
        r15.height = r8;
        r9 = 1;
        if (r12 <= r9) goto L_0x00fb;
    L_0x00e7:
        r9 = r0.mItemBottoms;
        r9 = r9[r7];
        r11 = r7 + 1;
    L_0x00ed:
        r13 = r7 + r12;
        if (r11 >= r13) goto L_0x00ff;
    L_0x00f1:
        r13 = r0.mItemBottoms;
        r13 = r13[r11];
        if (r13 <= r9) goto L_0x00f8;
    L_0x00f7:
        r9 = r13;
    L_0x00f8:
        r11 = r11 + 1;
        goto L_0x00ed;
    L_0x00fb:
        r9 = r0.mItemBottoms;
        r9 = r9[r7];
    L_0x00ff:
        r9 = r9 + r3;
        r8 = r8 + r9;
        r11 = r4 + r3;
        r11 = r11 * r7;
        r11 = r11 + r1;
        r13 = r10.getMeasuredWidth();
        r13 = r13 + r11;
        r10.layout(r11, r9, r13, r8);
        r9 = r0.mColMappings;
        r9 = r9.get(r7);
        r9 = (java.util.ArrayList) r9;
        r10 = java.lang.Integer.valueOf(r6);
        r9 = r9.contains(r10);
        if (r9 != 0) goto L_0x0153;
    L_0x0120:
        r9 = r0.mColMappings;
        r9 = r9.iterator();
    L_0x0126:
        r10 = r9.hasNext();
        if (r10 == 0) goto L_0x0144;
    L_0x012c:
        r10 = r9.next();
        r10 = (java.util.ArrayList) r10;
        r11 = java.lang.Integer.valueOf(r6);
        r11 = r10.contains(r11);
        if (r11 == 0) goto L_0x0126;
    L_0x013c:
        r11 = java.lang.Integer.valueOf(r6);
        r10.remove(r11);
        goto L_0x0126;
    L_0x0144:
        r9 = r0.mColMappings;
        r9 = r9.get(r7);
        r9 = (java.util.ArrayList) r9;
        r10 = java.lang.Integer.valueOf(r6);
        r9.add(r10);
    L_0x0153:
        r9 = r7;
    L_0x0154:
        r10 = r7 + r12;
        if (r9 >= r10) goto L_0x0166;
    L_0x0158:
        r10 = r0.mItemBottoms;
        r11 = r9 - r7;
        r11 = r15.getMarginBelow(r11);
        r11 = r11 + r8;
        r10[r9] = r11;
        r9 = r9 + 1;
        goto L_0x0154;
    L_0x0166:
        r6 = r6 + 1;
        r7 = r0.getNextColumnDown(r6);
        goto L_0x002c;
    L_0x016e:
        r8 = 0;
        r1 = 0;
    L_0x0170:
        r3 = r0.mColCount;
        if (r8 >= r3) goto L_0x017f;
    L_0x0174:
        r3 = r0.mItemBottoms;
        r4 = r3[r8];
        if (r4 <= r1) goto L_0x017c;
    L_0x017a:
        r1 = r3[r8];
    L_0x017c:
        r8 = r8 + 1;
        goto L_0x0170;
    L_0x017f:
        r1 = r1 - r2;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: social.junk.media.cleaner.whatsapp.photo.manager.status.downloader.loader.StaggeredGridView.fillDown(int, int):int");
    }

    private void displayMapping() {
        String str = "DISPLAY";
        Log.w(str, "MAP ****************");
        StringBuilder stringBuilder = new StringBuilder();
        Iterator it = this.mColMappings.iterator();
        int i = 0;
        while (it.hasNext()) {
            ArrayList arrayList = (ArrayList) it.next();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("COL");
            stringBuilder2.append(i);
            stringBuilder2.append(":");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(' ');
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                stringBuilder.append((Integer) it2.next());
                stringBuilder.append(" , ");
            }
            Log.w(str, stringBuilder.toString());
            stringBuilder = new StringBuilder();
            i++;
        }
        Log.w(str, "MAP END ****************");
    }

    /* Access modifiers changed, original: final */
    public final int getNextColumnUp() {
        int i = -1;
        int i2 = Integer.MIN_VALUE;
        for (int i3 = this.mColCount - 1; i3 >= 0; i3--) {
            int i4 = this.mItemTops[i3];
            if (i4 > i2) {
                i = i3;
                i2 = i4;
            }
        }
        return i;
    }

    /* Access modifiers changed, original: final */
    public final LayoutRecord getNextRecordUp(int i, int i2) {
        int i3;
        LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(i);
        if (layoutRecord == null) {
            layoutRecord = new LayoutRecord();
            layoutRecord.span = i2;
            this.mLayoutRecords.put(i, layoutRecord);
        } else if (layoutRecord.span != i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid LayoutRecord! Record had span=");
            stringBuilder.append(layoutRecord.span);
            stringBuilder.append(" but caller requested span=");
            stringBuilder.append(i2);
            stringBuilder.append(" for position=");
            stringBuilder.append(i);
            throw new IllegalStateException(stringBuilder.toString());
        }
        i = Integer.MIN_VALUE;
        int i4 = -1;
        for (i3 = this.mColCount - i2; i3 >= 0; i3--) {
            int i5 = Integer.MAX_VALUE;
            for (int i6 = i3; i6 < i3 + i2; i6++) {
                int i7 = this.mItemTops[i6];
                if (i7 < i5) {
                    i5 = i7;
                }
            }
            if (i5 > i) {
                i4 = i3;
                i = i5;
            }
        }
        layoutRecord.column = i4;
        for (i3 = 0; i3 < i2; i3++) {
            layoutRecord.setMarginBelow(i3, this.mItemTops[i3 + i4] - i);
        }
        return layoutRecord;
    }

    /* Access modifiers changed, original: final */
    public final int getNextColumnDown(int i) {
        i = this.mColCount;
        int i2 = -1;
        int i3 = Integer.MAX_VALUE;
        for (int i4 = 0; i4 < i; i4++) {
            int i5 = this.mItemBottoms[i4];
            if (i5 < i3) {
                i2 = i4;
                i3 = i5;
            }
        }
        return i2;
    }

    /* Access modifiers changed, original: final */
    public final LayoutRecord getNextRecordDown(int i, int i2) {
        LayoutRecord layoutRecord = (LayoutRecord) this.mLayoutRecords.get(i);
        if (layoutRecord == null) {
            layoutRecord = new LayoutRecord();
            layoutRecord.span = i2;
            this.mLayoutRecords.put(i, layoutRecord);
        } else if (layoutRecord.span != i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid LayoutRecord! Record had span=");
            stringBuilder.append(layoutRecord.span);
            stringBuilder.append(" but caller requested span=");
            stringBuilder.append(i2);
            stringBuilder.append(" for position=");
            stringBuilder.append(i);
            throw new IllegalStateException(stringBuilder.toString());
        }
        i = -1;
        int i3 = Integer.MAX_VALUE;
        int i4 = this.mColCount;
        for (int i5 = 0; i5 <= i4 - i2; i5++) {
            int i6 = Integer.MIN_VALUE;
            for (int i7 = i5; i7 < i5 + i2; i7++) {
                int i8 = this.mItemBottoms[i7];
                if (i8 > i6) {
                    i6 = i8;
                }
            }
            if (i6 < i3) {
                i = i5;
                i3 = i6;
            }
        }
        layoutRecord.column = i;
        for (int i9 = 0; i9 < i2; i9++) {
            layoutRecord.setMarginAbove(i9, i3 - this.mItemBottoms[i9 + i]);
        }
        return layoutRecord;
    }

    /* Access modifiers changed, original: final */
    public final View obtainView(int i, View view) {
        View transientStateView = this.mRecycler.getTransientStateView(i);
        if (transientStateView != null) {
            return transientStateView;
        }
        if (i >= this.mAdapter.getCount()) {
            return null;
        }
        int i2 = view != null ? ((LayoutParams) view.getLayoutParams()).viewType : -1;
        int itemViewType = this.mAdapter.getItemViewType(i);
        if (i2 != itemViewType) {
            view = this.mRecycler.getScrapView(itemViewType);
        }
        transientStateView = this.mAdapter.getView(i, view, this);
        if (!(transientStateView == view || view == null)) {
            this.mRecycler.addScrap(view);
        }
        ViewGroup.LayoutParams layoutParams = transientStateView.getLayoutParams();
        if (transientStateView.getParent() != this) {
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
            } else if (!checkLayoutParams(layoutParams)) {
                layoutParams = generateLayoutParams(layoutParams);
            }
        }
        LayoutParams layoutParams2 = (LayoutParams) layoutParams;
        layoutParams2.position = i;
        layoutParams2.viewType = itemViewType;
        return transientStateView;
    }

    public ListAdapter getAdapter() {
        return this.mAdapter;
    }

    public void setAdapter(ListAdapter listAdapter) {
        ListAdapter listAdapter2 = this.mAdapter;
        if (listAdapter2 != null) {
            listAdapter2.unregisterDataSetObserver(this.mObserver);
        }
        clearAllState();
        this.mAdapter = listAdapter;
        boolean z = true;
        this.mDataChanged = true;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.mObserver);
            this.mRecycler.setViewTypeCount(listAdapter.getViewTypeCount());
            this.mHasStableIds = listAdapter.hasStableIds();
        } else {
            this.mHasStableIds = false;
        }
        if (listAdapter == null) {
            z = false;
        }
        populate(z);
    }

    private void clearAllState() {
        this.mLayoutRecords.clear();
        removeAllViews();
        resetStateForGridTop();
        this.mRecycler.clear();
        this.mSelectorRect.setEmpty();
        this.mSelectorPosition = -1;
    }

    private void resetStateForGridTop() {
        int i = this.mColCount;
        int[] iArr = this.mItemTops;
        if (iArr == null || iArr.length != i) {
            this.mItemTops = new int[i];
            this.mItemBottoms = new int[i];
        }
        i = getPaddingTop();
        Arrays.fill(this.mItemTops, i);
        Arrays.fill(this.mItemBottoms, i);
        this.mFirstPosition = 0;
        iArr = this.mRestoreOffsets;
        if (iArr != null) {
            Arrays.fill(iArr, 0);
        }
    }

    public void setSelectionToTop() {
        removeAllViews();
        resetStateForGridTop();
        populate(false);
    }

    /* Access modifiers changed, original: protected */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2);
    }

    /* Access modifiers changed, original: protected */
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    /* Access modifiers changed, original: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        int i = this.mFirstPosition;
        savedState.position = i;
        if (i >= 0) {
            ListAdapter listAdapter = this.mAdapter;
            if (listAdapter != null && i < listAdapter.getCount()) {
                savedState.firstId = this.mAdapter.getItemId(i);
            }
        }
        if (getChildCount() > 0) {
            int[] iArr = new int[this.mColCount];
            if (this.mColWidth > 0) {
                for (int i2 = 0; i2 < this.mColCount; i2++) {
                    if (getChildAt(i2) != null) {
                        int left = getChildAt(i2).getLeft();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(this.mColWidth);
                        stringBuilder.append(" ");
                        stringBuilder.append(left);
                        Log.w("mColWidth", stringBuilder.toString());
                        int i3 = 0;
                        while (left > ((this.mColWidth + (this.mItemMargin * 2)) * i3) + getPaddingLeft()) {
                            i3++;
                        }
                        iArr[i3] = (getChildAt(i2).getTop() - this.mItemMargin) - getPaddingTop();
                    }
                }
            }
            savedState.topOffsets = iArr;
            ArrayList arrayList = new ArrayList();
            Iterator it = this.mColMappings.iterator();
            while (it.hasNext()) {
                arrayList.add(new ColMap((ArrayList) it.next()));
            }
            savedState.mapping = arrayList;
        }
        return savedState;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.mDataChanged = true;
        this.mFirstPosition = savedState.position;
        this.mRestoreOffsets = savedState.topOffsets;
        ArrayList arrayList = savedState.mapping;
        if (arrayList != null) {
            this.mColMappings.clear();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                this.mColMappings.add(((ColMap) it.next()).values);
            }
        }
        if (savedState.firstId >= 0) {
            this.mFirstAdapterId = savedState.firstId;
            this.mSelectorPosition = -1;
        }
        requestLayout();
    }
    private void useDefaultSelector() {
        setSelector(getResources().getDrawable(17301602));
    }

    public void positionSelector(int i, View view) {
        if (i != -1) {
            this.mSelectorPosition = i;
        }
        Rect rect = this.mSelectorRect;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        if (view instanceof SelectionBoundsAdjuster) {
            ((SelectionBoundsAdjuster) view).adjustListItemSelectionBounds(rect);
        }
        positionSelector(rect.left, rect.top, rect.right, rect.bottom);
        boolean z = this.mIsChildViewEnabled;
        if (view.isEnabled() != z) {
            this.mIsChildViewEnabled = z;
            if (getSelectedItemPosition() != -1) {
                refreshDrawableState();
            }
        }
    }

    private int getSelectedItemPosition() {
        return this.mSelectorPosition;
    }

    public int[] onCreateDrawableState(int i) {
        if (this.mIsChildViewEnabled) {
            return super.onCreateDrawableState(i);
        }
        int i2 = ENABLED_STATE_SET[0];
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        int length = onCreateDrawableState.length - 1;
        while (length >= 0) {
            if (onCreateDrawableState[length] == i2) {
                break;
            }
            length--;
        }
        length = -1;
        if (length >= 0) {
            System.arraycopy(onCreateDrawableState, length + 1, onCreateDrawableState, length, (onCreateDrawableState.length - length) - 1);
        }
        return onCreateDrawableState;
    }

    private void positionSelector(int i, int i2, int i3, int i4) {
        this.mSelectorRect.set(i - this.mSelectionLeftPadding, i2 - this.mSelectionTopPadding, i3 + this.mSelectionRightPadding, i4 + this.mSelectionBottomPadding);
    }

    public boolean performItemClick(View view, int i, long j) {
        if (this.mOnItemClickListener == null) {
            return false;
        }
        playSoundEffect(0);
        if (view != null) {
            view.sendAccessibilityEvent(1);
        }
        this.mOnItemClickListener.onItemClick(this, view, i, j);
        return true;
    }

    /* Access modifiers changed, original: 0000 */
    public boolean performLongPress(View view, int i, long j) {
        OnItemLongClickListener onItemLongClickListener = this.mOnItemLongClickListener;
        boolean onItemLongClick = onItemLongClickListener != null ? onItemLongClickListener.onItemLongClick(this, view, i, j) : false;
        if (!onItemLongClick) {
            this.mContextMenuInfo = createContextMenuInfo(view, i, j);
            onItemLongClick = super.showContextMenuForChild(this);
        }
        if (onItemLongClick) {
            performHapticFeedback(0);
        }
        return onItemLongClick;
    }

    public ContextMenuInfo getContextMenuInfo() {
        return this.mContextMenuInfo;
    }

    public ContextMenuInfo createContextMenuInfo(View view, int i, long j) {
        return new AdapterContextMenuInfo(view, i, j);
    }

    public Drawable getSelector() {
        return this.mSelector;
    }

    public void setSelector(int i) {
        setSelector(getResources().getDrawable(i));
    }

    public boolean verifyDrawable(Drawable drawable) {
        return this.mSelector == drawable || super.verifyDrawable(drawable);
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.mSelector;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public void setSelector(Drawable drawable) {
        Drawable drawable2 = this.mSelector;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.mSelector);
        }
        this.mSelector = drawable;
        if (drawable != null) {
            Rect rect = new Rect();
            drawable.getPadding(rect);
            this.mSelectionLeftPadding = rect.left;
            this.mSelectionTopPadding = rect.top;
            this.mSelectionRightPadding = rect.right;
            this.mSelectionBottomPadding = rect.bottom;
            drawable.setCallback(this);
            updateSelectorState();
        }
    }

    public void updateSelectorState() {
        if (this.mSelector == null) {
            return;
        }
        if (shouldShowSelector()) {
            this.mSelector.setState(getDrawableState());
            return;
        }
        this.mSelector.setState(new int[]{0});
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        updateSelectorState();
    }

    public boolean shouldShowSelector() {
        return ((hasFocus() && !isInTouchMode()) || touchModeDrawsInPressedState()) && this.mBeginClick;
    }

    public boolean touchModeDrawsInPressedState() {
        int i = this.mTouchMode;
        return i == 4 || i == 5;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public final OnItemClickListener getOnItemClickListener() {
        return this.mOnItemClickListener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener onItemLongClickListener) {
        if (!isLongClickable()) {
            setLongClickable(true);
        }
        this.mOnItemLongClickListener = onItemLongClickListener;
    }

    public final OnItemLongClickListener getOnItemLongClickListener() {
        return this.mOnItemLongClickListener;
    }

    public int pointToPosition(int i, int i2) {
        Rect rect = this.mTouchFrame;
        if (rect == null) {
            rect = new Rect();
            this.mTouchFrame = rect;
        }
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (childAt.getVisibility() == VISIBLE) {
                childAt.getHitRect(rect);
                if (rect.contains(i, i2)) {
                    return this.mFirstPosition + childCount;
                }
            }
        }
        return -1;
    }

    public boolean isDrawSelectorOnTop() {
        return this.mDrawSelectorOnTop;
    }

    public void setDrawSelectorOnTop(boolean z) {
        this.mDrawSelectorOnTop = z;
    }
}
