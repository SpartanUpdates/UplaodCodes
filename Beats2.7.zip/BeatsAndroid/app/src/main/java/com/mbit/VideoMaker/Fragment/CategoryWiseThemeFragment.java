package com.mbit.VideoMaker.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mbit.VideoMaker.Activity.HomeActivity;
import com.mbit.VideoMaker.Adapter.ThemeCategoryWiseAdapter;
import com.mbit.VideoMaker.DataBase.DatabaseHelper;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Extra.d;
import com.mbit.VideoMaker.Extra.kprogresshud.KProgressHUD;
import com.mbit.VideoMaker.Model.ThemelModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.UnityPlayerActivity;
import com.mbit.VideoMaker.application.MyApplication;
import com.mbit.VideoMaker.retrofit.APIClient;
import com.mbit.VideoMaker.retrofit.ApiInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryWiseThemeFragment extends Fragment {

    public static d sharedpreferences;
    public int id;
    public String ThemeCategoryWiseDataUrl = com.mbit.VideoMaker.View.a.ThemeCategoryWiseDataUrl;
    public Handler i;
    LinearLayout llInternetCheck;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    String offlienResopnseData;
    //    int AppId = -1;
    int CategoryId = -1;
    SharedPreferences pref;
    GridLayoutManager gridLayoutManager;
    KProgressHUD hud;
    Long timestamps;
    Date date = new Date();
    SwipeRefreshLayout mSwipeRefreshLayout;
    String[] split_AllLan;
    String[] split_selctedLan;
    private ArrayList<ThemelModel> ThemeListCategoryWise = new ArrayList<>();
    private ArrayList<ThemelModel> WhatsNewList = new ArrayList<>();
    private ThemeCategoryWiseAdapter themeAdapter;
    private DatabaseHelper db;

    public static CategoryWiseThemeFragment newInstance(int catid) {
        CategoryWiseThemeFragment fragment = new CategoryWiseThemeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CategoryId = getArguments().getInt("CategoryId");
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_wise_theme, container, false);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        db = new DatabaseHelper(getActivity());
        sharedpreferences = d.a(getActivity());
        split_AllLan = ("35,27,34,33,29,32,30,31,28,24,22,25,36").split(",");
        split_selctedLan = d.a(getActivity()).a("pref_key_language_list", "22").split(",");
        BindView(view);
        SetListener();
        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (Utils.checkConnectivity(getActivity(), false)) {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null && timestamps != null) {
                    if (offlienResopnseData != null) {
                        LoadOfflineData(offlienResopnseData);
                    }
                }
            } else {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null) {
                    LoadOfflineData(offlienResopnseData);
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            SetUpAdapter();
        }

        /*if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
            if (Utils.checkConnectivity(getActivity(), false)) {
                String id = pref.getString(String.valueOf(CategoryId), null);
                if (id != null && !id.equals("")) {
                    getOfflineCategory(getActivity(), String.valueOf(CategoryId));
                    if (offlienResopnseData != null && timestamps != null) {
                        if (Math.abs(System.currentTimeMillis() - timestamps) > 900000) {
                            GetCategoryOfTheme();
                        } else {
                            if (offlienResopnseData != null) {
                                LoadOfflineData(offlienResopnseData);
                            }
                        }
                    }
                } else {
                    GetCategoryOfTheme();
                }
            } else {
                String id = pref.getString(String.valueOf(CategoryId), null);
                if (id != null && !id.equals("")) {
                    getOfflineCategory(getActivity(), String.valueOf(CategoryId));
                    if (offlienResopnseData != null) {
                        LoadOfflineData(offlienResopnseData);
                    }
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            SetUpAdapter();
        }*/
        return view;
    }

    private void BindView(View view) {
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        rvVideos = view.findViewById(R.id.rvVideos);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                    getActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    ThemeListCategoryWise.clear();
                    GetCategoryOfTheme();
                    mSwipeRefreshLayout.setRefreshing(false);
                } else {
                    mSwipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void SetOfflineCategory(Context c, String userObject, String key, final Date date) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.putLong(key + "_value", date.getTime());
        editor.apply();
    }


    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }


    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        themeAdapter = new ThemeCategoryWiseAdapter(getActivity(), ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(themeAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                stringBuilder.append("");
                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();
            }
        });
        themeAdapter.notifyDataSetChanged();
        if (!MyApplication.aa && UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(getActivity())
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
                        MyApplication.aa = true;
                        UnityPlayerActivity.mInterstitialAd.show();
                    }
                }
            }, 2000);
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    private void LoadOfflineData(String result) {
        try {
            JSONObject jsonObj = new JSONObject(result);
            JSONArray jsonArray = jsonObj.getJSONArray("category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                if (CategoryId == 111) {
                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        ThemelModel themeModel = new ThemelModel();
                        JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                            themeModel.setThemeid(jsonobjecttheme.getString("id"));
                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                            if (themeModel.isNewRealise().equals("1")) {
                                ThemeListCategoryWise.add(themeModel);
                            }
                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                            themeModel.setThemeid(jsonobjecttheme.getString("id"));
                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                            if (themeModel.isNewRealise().equals("1")) {
                                ThemeListCategoryWise.add(themeModel);
                            }
                            if (Utils.checkConnectivity(getActivity(), false)) {
                                if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                    if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                        themeModel.setNativeAds(true);
                                        ThemeListCategoryWise.add(j, themeModel);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (CategoryId == Catid) {
                        JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                        for (int j = 0; j < jSONArray4.length(); j++) {
                            ThemelModel themeModel = new ThemelModel();
                            JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                            if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                ThemeListCategoryWise.add(themeModel);

                            } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                ThemeListCategoryWise.add(themeModel);
                            }
                            if (Utils.checkConnectivity(getActivity(), false)) {
                                if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                    if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                        themeModel.setNativeAds(true);
                                        ThemeListCategoryWise.add(j, themeModel);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            SetUpAdapter();
            rlLoadingTheme.setVisibility(View.GONE);
        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }

    private void GetCategoryOfTheme() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        APIClient.getRetrofit().create(ApiInterface.class).GetAllTheme("aciativtyksdfhal5215ajal", "5").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        if (getActivity() != null) {
                            SetOfflineCategory(getActivity(), jsonObj.toString(), "ThemeCategory", date);
                        }
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            if (CategoryId == 111) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    ThemelModel themeModel = new ThemelModel();
                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                        if (themeModel.isNewRealise().equals("1")) {
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                        if (themeModel.isNewRealise().equals("1")) {
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                    }

                                }
                            } else {
                                if (CategoryId == Catid) {
                                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                    for (int j = 0; j < jSONArray4.length(); j++) {
                                        ThemelModel themeModel = new ThemelModel();
                                        JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                            ThemeListCategoryWise.add(themeModel);
                                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                            ThemeListCategoryWise.add(themeModel);
                                        }

                                        if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                            if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                                themeModel.setNativeAds(true);
                                                ThemeListCategoryWise.add(j, themeModel);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        SetUpAdapter();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                rlLoadingTheme.setVisibility(View.VISIBLE);
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    public class SaveThumbnailIntoDb extends AsyncTask<ThemelModel, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(ThemelModel... params) {
            ThemelModel dataModel = params[0];
            try {
                InputStream inputStream = new URL(dataModel.getImage()).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                dataModel.setPicture(bitmap);
                db.addData(dataModel);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
