package com.esc.beautymackupselficlam.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import  com.esc.beautymackupselficlam.library.Imageutils;
import  com.esc.beautymackupselficlam.library.Imageutils.ImageAttachmentListener;
import  com.esc.beautymackupselficlam.library.Utility;
import  com.esc.beautymackupselficlam.utils.CustomStckerTextView;
import  com.esc.beautymackupselficlam.utils.CustomTextView;
import  com.esc.beautymackupselficlam.utils.FontStyleAdapter;
import  com.esc.beautymackupselficlam.utils.StickerAdapter;
import  com.esc.beautymackupselficlam.utils.StickerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class WaterEffectEditorActivity extends AppCompatActivity implements OnClickListener, ImageAttachmentListener {
    private static final String IMAGE_DIRECTORY_NAME = "SweetSelfie";
    public static int int_select_pip = 0;
    private ImageView Imgbtn_1;
    private ImageView Imgbtn_10;
    private ImageView Imgbtn_11;
    private ImageView Imgbtn_12;
    private ImageView Imgbtn_13;
    private ImageView Imgbtn_14;
    private ImageView Imgbtn_15;
    private ImageView Imgbtn_16;
    private ImageView Imgbtn_17;
    private ImageView Imgbtn_18;
    private ImageView Imgbtn_19;
    private ImageView Imgbtn_2;
    private ImageView Imgbtn_20;
    private ImageView Imgbtn_21;
    private ImageView Imgbtn_22;
    private ImageView Imgbtn_23;
    private ImageView Imgbtn_24;
    private ImageView Imgbtn_25;
    private ImageView Imgbtn_26;
    private ImageView Imgbtn_27;
    private ImageView Imgbtn_28;
    private ImageView Imgbtn_29;
    private ImageView Imgbtn_3;
    private ImageView Imgbtn_30;
    private ImageView Imgbtn_31;
    private ImageView Imgbtn_32;
    private ImageView Imgbtn_33;
    private ImageView Imgbtn_34;
    private ImageView Imgbtn_35;
    private ImageView Imgbtn_36;
    private ImageView Imgbtn_37;
    private ImageView Imgbtn_38;
    private ImageView Imgbtn_39;
    private ImageView Imgbtn_4;
    private ImageView Imgbtn_40;
    private ImageView Imgbtn_41;
    private ImageView Imgbtn_42;
    private ImageView Imgbtn_43;
    private ImageView Imgbtn_44;
    private ImageView Imgbtn_45;
    private ImageView Imgbtn_5;
    private ImageView Imgbtn_6;
    private ImageView Imgbtn_7;
    private ImageView Imgbtn_8;
    private ImageView Imgbtn_9;
    private LinearLayout ll_Stickers;
    private LinearLayout ll_pip;
    private LinearLayout ll_save;
    private LinearLayout ll_text;
    public static Uri contentUri;
    private Dialog dialog;
    private int height = 0;
    private Imageutils imageutils;
    private ImageView img_view;
    private int int_backPress = 0;
    private LinearLayout layout_pip;
    private LinearLayout layout_stickers;
    private ProgressDialog progress_dialog;
    private RelativeLayout rlmain;
    private CustomStckerTextView currentTextView;
    private StickerView currentView;
    InputMethodManager inputmethodmanager;
    GridView grid_colorlist;
    GridView grid_fontlist;
    String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
            "font4.TTF", "font5.ttf", "font6.TTF", "font9.ttf", "font11.ttf",
            "font12.ttf", "font14.TTF", "font16.TTF", "font17.ttf",
            "font20.ttf"};
    private Typeface type;
    private int pickedColor = -1;
    ImageView imageview_keyboard;
    ImageView imageview_fontstyle;
    ImageView imageview_color;
    ImageView imageview_gravity;
    ImageView imageview_done;
    public static Bitmap textBitmap;
    private ArrayList<View> stickers = new ArrayList();
    private int w = 0;
    public static Bitmap Bbitmap;
    public static Canvas canvas;
    private LinearLayout ll_colorlist;
    private LinearLayout ll_fontlist;
    private EditText edittext;
    private static int columnWidth = 80;
    private ArrayList<Integer> stickerlist;
    private StickerAdapter stickerAdapter;
    private ArrayList<View> views;
    HorizontalScrollView hl_effectList;
    ImageView back;
    private int width = 0;

    private class saves extends AsyncTask<String, Void, Boolean> {
        private saves() {
        }

        protected void onPreExecute() {
            WaterEffectEditorActivity.this.progress_dialog.show();
        }

        protected Boolean doInBackground(String... args) {
            WaterEffectEditorActivity.this.getScreenSnapShot();
            return Boolean.valueOf(true);
        }

        protected void onPostExecute(Boolean success) {
            id = R.id.ll_save;
            if (interstitial != null && interstitial.isLoaded()) {
                interstitial.show();
            } else {
                Intent i = new Intent(WaterEffectEditorActivity.this, shareActivity.class);
                i.putExtra("key", 3);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }
            WaterEffectEditorActivity.this.progress_dialog.hide();
        }
    }


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.watereffect_photoeditor_layout);
        loadAd();
        this.int_backPress = 0;
        this.views = new ArrayList();
        BindView();
        setListeners();
        initView();

    }

    private void initView() {
        this.progress_dialog = new ProgressDialog(this);
        this.progress_dialog.setMessage("Please wait...");
        this.progress_dialog.setCancelable(false);
        this.imageutils = new Imageutils(this);
        if (Utility.int_image_type == 1) {
            this.imageutils.launchCamera(1);
        } else if (Utility.int_image_type == 2) {
            this.imageutils.launchGallery(1);
        }
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    onBackPressed();
                }
            }
        });
    }

    private void setListeners() {
        this.Imgbtn_1.setOnClickListener(this);
        this.Imgbtn_2.setOnClickListener(this);
        this.Imgbtn_3.setOnClickListener(this);
        this.Imgbtn_4.setOnClickListener(this);
        this.Imgbtn_5.setOnClickListener(this);
        this.Imgbtn_6.setOnClickListener(this);
        this.Imgbtn_7.setOnClickListener(this);
        this.Imgbtn_8.setOnClickListener(this);
        this.Imgbtn_9.setOnClickListener(this);
        this.Imgbtn_10.setOnClickListener(this);
        this.Imgbtn_11.setOnClickListener(this);
        this.Imgbtn_12.setOnClickListener(this);
        this.Imgbtn_13.setOnClickListener(this);
        this.Imgbtn_14.setOnClickListener(this);
        this.Imgbtn_15.setOnClickListener(this);
        this.Imgbtn_16.setOnClickListener(this);
        this.Imgbtn_17.setOnClickListener(this);
        this.Imgbtn_18.setOnClickListener(this);
        this.Imgbtn_19.setOnClickListener(this);
        this.Imgbtn_20.setOnClickListener(this);
        this.Imgbtn_21.setOnClickListener(this);
        this.Imgbtn_22.setOnClickListener(this);
        this.Imgbtn_23.setOnClickListener(this);
        this.Imgbtn_24.setOnClickListener(this);
        this.Imgbtn_25.setOnClickListener(this);
        this.Imgbtn_26.setOnClickListener(this);
        this.Imgbtn_27.setOnClickListener(this);
        this.Imgbtn_28.setOnClickListener(this);
        this.Imgbtn_29.setOnClickListener(this);
        this.Imgbtn_30.setOnClickListener(this);
        this.Imgbtn_31.setOnClickListener(this);
        this.Imgbtn_32.setOnClickListener(this);
        this.Imgbtn_33.setOnClickListener(this);
        this.Imgbtn_34.setOnClickListener(this);
        this.Imgbtn_35.setOnClickListener(this);
        this.Imgbtn_36.setOnClickListener(this);
        this.Imgbtn_37.setOnClickListener(this);
        this.Imgbtn_38.setOnClickListener(this);
        this.Imgbtn_39.setOnClickListener(this);
        this.Imgbtn_40.setOnClickListener(this);
        this.Imgbtn_41.setOnClickListener(this);
        this.Imgbtn_42.setOnClickListener(this);
        this.Imgbtn_43.setOnClickListener(this);
        this.Imgbtn_44.setOnClickListener(this);
        this.Imgbtn_45.setOnClickListener(this);
    }

    private void BindView() {
        this.ll_pip = (LinearLayout) findViewById(R.id.ll_pipframe);
        this.ll_pip.setOnClickListener(this);
        this.ll_Stickers = (LinearLayout) findViewById(R.id.ll_Stickers);
        this.ll_Stickers.setOnClickListener(this);
        this.ll_text = (LinearLayout) findViewById(R.id.ll_text);
        this.ll_text.setOnClickListener(this);
        this.ll_save = (LinearLayout) findViewById(R.id.ll_save);
        this.ll_save.setOnClickListener(this);
        this.rlmain = (RelativeLayout) findViewById(R.id.rl_mainly);
        this.img_view = (ImageView) findViewById(R.id.imageview_main);
        this.width = img_view.getWidth();
        this.height = this.img_view.getHeight();
        this.layout_pip = (LinearLayout) findViewById(R.id.ll_pipframe);
        this.layout_stickers = (LinearLayout) findViewById(R.id.ll_stickers);
        hl_effectList = (HorizontalScrollView) findViewById(R.id.hl_effectList);
        back = (ImageView) findViewById(R.id.iv_back);
        this.Imgbtn_1 = (ImageView) findViewById(R.id.img_1);
        this.Imgbtn_2 = (ImageView) findViewById(R.id.img_2);
        this.Imgbtn_3 = (ImageView) findViewById(R.id.img_3);
        this.Imgbtn_4 = (ImageView) findViewById(R.id.img_4);
        this.Imgbtn_5 = (ImageView) findViewById(R.id.img_5);
        this.Imgbtn_6 = (ImageView) findViewById(R.id.img_6);
        this.Imgbtn_7 = (ImageView) findViewById(R.id.img_7);
        this.Imgbtn_8 = (ImageView) findViewById(R.id.img_8);
        this.Imgbtn_9 = (ImageView) findViewById(R.id.img_9);
        this.Imgbtn_10 = (ImageView) findViewById(R.id.img_10);
        this.Imgbtn_11 = (ImageView) findViewById(R.id.img_11);
        this.Imgbtn_12 = (ImageView) findViewById(R.id.img_12);
        this.Imgbtn_13 = (ImageView) findViewById(R.id.img_13);
        this.Imgbtn_14 = (ImageView) findViewById(R.id.img_14);
        this.Imgbtn_15 = (ImageView) findViewById(R.id.img_15);
        this.Imgbtn_16 = (ImageView) findViewById(R.id.img_16);
        this.Imgbtn_17 = (ImageView) findViewById(R.id.img_17);
        this.Imgbtn_18 = (ImageView) findViewById(R.id.img_18);
        this.Imgbtn_19 = (ImageView) findViewById(R.id.img_19);
        this.Imgbtn_20 = (ImageView) findViewById(R.id.img_20);
        this.Imgbtn_21 = (ImageView) findViewById(R.id.img_21);
        this.Imgbtn_22 = (ImageView) findViewById(R.id.img_22);
        this.Imgbtn_23 = (ImageView) findViewById(R.id.img_23);
        this.Imgbtn_24 = (ImageView) findViewById(R.id.img_24);
        this.Imgbtn_25 = (ImageView) findViewById(R.id.img_25);
        this.Imgbtn_26 = (ImageView) findViewById(R.id.img_26);
        this.Imgbtn_27 = (ImageView) findViewById(R.id.img_27);
        this.Imgbtn_28 = (ImageView) findViewById(R.id.img_28);
        this.Imgbtn_29 = (ImageView) findViewById(R.id.img_29);
        this.Imgbtn_30 = (ImageView) findViewById(R.id.img_30);
        this.Imgbtn_31 = (ImageView) findViewById(R.id.img_31);
        this.Imgbtn_32 = (ImageView) findViewById(R.id.img_32);
        this.Imgbtn_33 = (ImageView) findViewById(R.id.img_33);
        this.Imgbtn_34 = (ImageView) findViewById(R.id.img_34);
        this.Imgbtn_35 = (ImageView) findViewById(R.id.img_35);
        this.Imgbtn_36 = (ImageView) findViewById(R.id.img_36);
        this.Imgbtn_37 = (ImageView) findViewById(R.id.img_37);
        this.Imgbtn_38 = (ImageView) findViewById(R.id.img_38);
        this.Imgbtn_39 = (ImageView) findViewById(R.id.img_39);
        this.Imgbtn_40 = (ImageView) findViewById(R.id.img_40);
        this.Imgbtn_41 = (ImageView) findViewById(R.id.img_41);
        this.Imgbtn_42 = (ImageView) findViewById(R.id.img_42);
        this.Imgbtn_43 = (ImageView) findViewById(R.id.img_43);
        this.Imgbtn_44 = (ImageView) findViewById(R.id.img_44);
        this.Imgbtn_45 = (ImageView) findViewById(R.id.img_45);
    }


    private void PiPIcons() {
        this.Imgbtn_1.setImageResource(R.drawable.water_1s);
        this.Imgbtn_2.setImageResource(R.drawable.water_2s);
        this.Imgbtn_3.setImageResource(R.drawable.water_3s);
        this.Imgbtn_4.setImageResource(R.drawable.water_4s);
        this.Imgbtn_5.setImageResource(R.drawable.water_5s);
        this.Imgbtn_6.setImageResource(R.drawable.water_6s);
        this.Imgbtn_7.setImageResource(R.drawable.water_7s);
        this.Imgbtn_8.setImageResource(R.drawable.water_8s);
        this.Imgbtn_9.setImageResource(R.drawable.water_9s);
        this.Imgbtn_10.setImageResource(R.drawable.water_10s);
        this.Imgbtn_11.setImageResource(R.drawable.water_11s);
        this.Imgbtn_12.setImageResource(R.drawable.water_12s);
        this.Imgbtn_13.setImageResource(R.drawable.water_13s);
        this.Imgbtn_14.setImageResource(R.drawable.water_14s);
        this.Imgbtn_15.setImageResource(R.drawable.water_15s);
        this.Imgbtn_16.setImageResource(R.drawable.water_16s);
        this.Imgbtn_17.setImageResource(R.drawable.water_17s);
        this.Imgbtn_18.setImageResource(R.drawable.water_18s);
        this.Imgbtn_19.setImageResource(R.drawable.water_19s);
        this.Imgbtn_20.setImageResource(R.drawable.water_20s);
        this.Imgbtn_21.setImageResource(R.drawable.water_21s);
        this.Imgbtn_22.setImageResource(R.drawable.water_22s);
        this.Imgbtn_23.setImageResource(R.drawable.water_23s);
        this.Imgbtn_24.setImageResource(R.drawable.water_24s);
        this.Imgbtn_25.setImageResource(R.drawable.water_25s);
        this.Imgbtn_26.setImageResource(R.drawable.water_26s);
        this.Imgbtn_27.setImageResource(R.drawable.water_27s);
        this.Imgbtn_28.setImageResource(R.drawable.water_28s);
        this.Imgbtn_29.setImageResource(R.drawable.water_29s);
        this.Imgbtn_30.setImageResource(R.drawable.water_30s);
        this.Imgbtn_31.setImageResource(R.drawable.water_31s);
        this.Imgbtn_32.setImageResource(R.drawable.water_32s);
        this.Imgbtn_33.setImageResource(R.drawable.water_33s);
        this.Imgbtn_34.setImageResource(R.drawable.water_34s);
        this.Imgbtn_35.setImageResource(R.drawable.water_35s);
        this.Imgbtn_36.setImageResource(R.drawable.water_36s);
        this.Imgbtn_37.setImageResource(R.drawable.water_37s);
        this.Imgbtn_38.setImageResource(R.drawable.water_38s);
        this.Imgbtn_39.setImageResource(R.drawable.water_39s);
        this.Imgbtn_40.setImageResource(R.drawable.water_40s);
        this.Imgbtn_41.setImageResource(R.drawable.water_41s);
        this.Imgbtn_42.setImageResource(R.drawable.water_42s);
        this.Imgbtn_43.setImageResource(R.drawable.water_43s);
        this.Imgbtn_44.setImageResource(R.drawable.water_44s);
        this.Imgbtn_45.setImageResource(R.drawable.water_45s);
    }


    private void ShowPip() {
        PiPIcons();
        this.layout_pip.setVisibility(View.VISIBLE);
        this.layout_stickers.setVisibility(View.GONE);
    }


    public void onClick(View v) {
        BackValue();
        if (v == this.ll_pip) {
            hl_effectList.setVisibility(View.VISIBLE);
            ShowPip();
        } else if (v == this.ll_Stickers) {
            hl_effectList.setVisibility(View.INVISIBLE);
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            showStickerDialog();
        } else if (v == this.ll_text) {
            hl_effectList.setVisibility(View.INVISIBLE);
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            selecttext();

        } else if (v == this.ll_save) {
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            new saves().execute(new String[]{""});
        } else if (v == this.Imgbtn_1) {
            int_select_pip = 1;
            frame1();
        } else if (v == this.Imgbtn_2) {
            int_select_pip = 1;
            frame2();
        } else if (v == this.Imgbtn_3) {
            int_select_pip = 1;
            frame3();
        } else if (v == this.Imgbtn_4) {
            int_select_pip = 1;
            frame4();
        } else if (v == this.Imgbtn_5) {
            int_select_pip = 1;
            frame5();
        } else if (v == this.Imgbtn_6) {
            int_select_pip = 1;
            frame6();
        } else if (v == this.Imgbtn_7) {
            int_select_pip = 1;
            frame7();
        } else if (v == this.Imgbtn_8) {
            int_select_pip = 1;
            frame8();
        } else if (v == this.Imgbtn_9) {
            int_select_pip = 1;
            frame9();
        } else if (v == this.Imgbtn_10) {
            int_select_pip = 1;
            frame10();
        } else if (v == this.Imgbtn_11) {
            int_select_pip = 1;
            frame11();
        } else if (v == this.Imgbtn_12) {
            int_select_pip = 1;
            frame12();
        } else if (v == this.Imgbtn_13) {
            int_select_pip = 1;
            frame13();
        } else if (v == this.Imgbtn_14) {
            int_select_pip = 1;
            frame14();
        } else if (v == this.Imgbtn_15) {
            int_select_pip = 1;
            frame15();
        } else if (v == this.Imgbtn_16) {
            int_select_pip = 1;
            frame16();
        } else if (v == this.Imgbtn_17) {
            int_select_pip = 1;
            frame17();
        } else if (v == this.Imgbtn_18) {
            int_select_pip = 1;
            frame18();
        } else if (v == this.Imgbtn_19) {
            int_select_pip = 1;
            frame19();
        } else if (v == this.Imgbtn_20) {
            int_select_pip = 1;
            frame20();
        } else if (v == this.Imgbtn_21) {
            int_select_pip = 1;
            frame21();
        } else if (v == this.Imgbtn_22) {
            int_select_pip = 1;
            frame22();
        } else if (v == this.Imgbtn_23) {
            int_select_pip = 1;
            frame23();
        } else if (v == this.Imgbtn_24) {
            int_select_pip = 1;
            frame24();
        } else if (v == this.Imgbtn_25) {
            int_select_pip = 1;
            frame25();
        } else if (v == this.Imgbtn_26) {
            int_select_pip = 1;
            frame26();
        } else if (v == this.Imgbtn_27) {
            int_select_pip = 1;
            frame27();
        } else if (v == this.Imgbtn_28) {
            int_select_pip = 1;
            frame28();
        } else if (v == this.Imgbtn_29) {
            int_select_pip = 1;
            frame29();
        } else if (v == this.Imgbtn_30) {
            int_select_pip = 1;
            frame30();
        } else if (v == this.Imgbtn_31) {
            int_select_pip = 1;
            frame31();
        } else if (v == this.Imgbtn_32) {
            int_select_pip = 1;
            frame32();
        } else if (v == this.Imgbtn_33) {
            int_select_pip = 1;
            frame33();
        } else if (v == this.Imgbtn_34) {
            int_select_pip = 1;
            frame34();
        } else if (v == this.Imgbtn_35) {
            int_select_pip = 1;
            frame35();
        } else if (v == this.Imgbtn_36) {
            int_select_pip = 1;
            frame36();
        } else if (v == this.Imgbtn_37) {
            int_select_pip = 1;
            frame37();
        } else if (v == this.Imgbtn_38) {
            int_select_pip = 1;
            frame38();
        } else if (v == this.Imgbtn_39) {
            int_select_pip = 1;
            frame39();
        } else if (v == this.Imgbtn_40) {
            int_select_pip = 1;
            frame40();
        } else if (v == this.Imgbtn_41) {
            int_select_pip = 1;
            frame41();
        } else if (v == this.Imgbtn_42) {
            int_select_pip = 1;
            frame42();
        } else if (v == this.Imgbtn_43) {
            int_select_pip = 1;
            frame43();
        } else if (v == this.Imgbtn_44) {
            int_select_pip = 1;
            frame44();
        } else if (v == this.Imgbtn_45) {
            int_select_pip = 1;
            frame45();
        }
    }

    private void frame1() {
        this.rlmain.setBackgroundResource(R.drawable.water_1);
    }

    private void frame2() {
        this.rlmain.setBackgroundResource(R.drawable.water_2);
    }

    private void frame3() {
        this.rlmain.setBackgroundResource(R.drawable.water_3);
    }

    private void frame4() {
        this.rlmain.setBackgroundResource(R.drawable.water_4);
    }

    private void frame5() {
        this.rlmain.setBackgroundResource(R.drawable.water_5);
    }

    private void frame6() {
        this.rlmain.setBackgroundResource(R.drawable.water_6);
    }

    private void frame7() {
        this.rlmain.setBackgroundResource(R.drawable.water_7);
    }

    private void frame8() {
        this.rlmain.setBackgroundResource(R.drawable.water_8);
    }

    private void frame9() {
        this.rlmain.setBackgroundResource(R.drawable.water_9);
    }

    private void frame10() {
        this.rlmain.setBackgroundResource(R.drawable.water_10);
    }

    private void frame11() {
        this.rlmain.setBackgroundResource(R.drawable.water_11);
    }

    private void frame12() {
        this.rlmain.setBackgroundResource(R.drawable.water_12);
    }

    private void frame13() {
        this.rlmain.setBackgroundResource(R.drawable.water_13);
    }

    private void frame14() {
        this.rlmain.setBackgroundResource(R.drawable.water_14);
    }

    private void frame15() {
        this.rlmain.setBackgroundResource(R.drawable.water_15);
    }

    private void frame16() {
        this.rlmain.setBackgroundResource(R.drawable.water_16);
    }

    private void frame17() {
        this.rlmain.setBackgroundResource(R.drawable.water_17);
    }

    private void frame18() {
        this.rlmain.setBackgroundResource(R.drawable.water_18);
    }

    private void frame19() {
        this.rlmain.setBackgroundResource(R.drawable.water_19);
    }

    private void frame20() {
        this.rlmain.setBackgroundResource(R.drawable.water_20);
    }

    private void frame21() {
        this.rlmain.setBackgroundResource(R.drawable.water_21);
    }

    private void frame22() {
        this.rlmain.setBackgroundResource(R.drawable.water_22);
    }

    private void frame23() {
        this.rlmain.setBackgroundResource(R.drawable.water_23);
    }

    private void frame24() {
        this.rlmain.setBackgroundResource(R.drawable.water_24);
    }

    private void frame25() {
        this.rlmain.setBackgroundResource(R.drawable.water_25);
    }

    private void frame26() {
        this.rlmain.setBackgroundResource(R.drawable.water_26);
    }

    private void frame27() {
        this.rlmain.setBackgroundResource(R.drawable.water_27);
    }

    private void frame28() {
        this.rlmain.setBackgroundResource(R.drawable.water_28);
    }

    private void frame29() {
        this.rlmain.setBackgroundResource(R.drawable.water_29);
    }

    private void frame30() {
        this.rlmain.setBackgroundResource(R.drawable.water_30);
    }

    private void frame31() {
        this.rlmain.setBackgroundResource(R.drawable.water_31);
    }

    private void frame32() {
        this.rlmain.setBackgroundResource(R.drawable.water_32);
    }

    private void frame33() {
        this.rlmain.setBackgroundResource(R.drawable.water_33);
    }

    private void frame34() {
        this.rlmain.setBackgroundResource(R.drawable.water_34);
    }

    private void frame35() {
        this.rlmain.setBackgroundResource(R.drawable.water_35);
    }

    private void frame36() {
        this.rlmain.setBackgroundResource(R.drawable.water_36);
    }

    private void frame37() {
        this.rlmain.setBackgroundResource(R.drawable.water_37);
    }

    private void frame38() {
        this.rlmain.setBackgroundResource(R.drawable.water_38);
    }

    private void frame39() {
        this.rlmain.setBackgroundResource(R.drawable.water_39);
    }

    private void frame40() {
        this.rlmain.setBackgroundResource(R.drawable.water_40);
    }

    private void frame41() {
        this.rlmain.setBackgroundResource(R.drawable.water_41);
    }

    private void frame42() {
        this.rlmain.setBackgroundResource(R.drawable.water_42);
    }

    private void frame43() {
        this.rlmain.setBackgroundResource(R.drawable.water_43);
    }

    private void frame44() {
        this.rlmain.setBackgroundResource(R.drawable.water_44);
    }

    private void frame45() {
        this.rlmain.setBackgroundResource(R.drawable.water_45);
    }


    void getScreenSnapShot() {
        View content = findViewById(R.id.ll_main);
        content.setDrawingCacheEnabled(true);
        content.buildDrawingCache(true);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Bitmap myBitmap = content.getDrawingCache();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e2) {
            e2.printStackTrace();
        }
        saveBitmap(myBitmap);
        content.setDrawingCacheEnabled(false);
        content.destroyDrawingCache();
    }

    public void saveBitmap(Bitmap bitmap) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME);
        if (!(mediaStorageDir.exists() || mediaStorageDir.mkdirs())) {
            Log.d(IMAGE_DIRECTORY_NAME, "Oops! Failed create SweetSelfie directory");
        }
        String filepath = mediaStorageDir.getPath() + File.separator + "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".jpg";
        try {
            FileOutputStream fos = new FileOutputStream(new File(filepath));
            bitmap.compress(CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
        } catch (IOException e2) {
        }
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        this.contentUri = Uri.fromFile(new File(filepath));
        mediaScanIntent.setData(this.contentUri);
        sendBroadcast(mediaScanIntent);
    }

    public void onBackPressed() {
        int_select_pip = 0;
        id = R.id.iv_back;
        super.onBackPressed();
    }

    private void BackValue() {
        if (this.int_backPress == 1) {
            this.int_backPress = 0;
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1) {
            this.imageutils.onActivityResult(requestCode, resultCode, data);
        } else if (resultCode == 0) {
            finish();
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        this.imageutils.request_permission_result(requestCode, permissions, grantResults);
    }

    public void image_attachment(int from, String filename, Bitmap file, Uri uri) {
        this.img_view.setImageBitmap(Utility.getResizedBitmap(file, 600));
        frame1();
        PiPIcons();
        this.imageutils.createImage(file, filename, Environment.getExternalStorageDirectory() + File.separator + IMAGE_DIRECTORY_NAME + File.separator, false);
    }

    protected void selecttext() {
        this.dialog = new Dialog(this);
        this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.inputmethodmanager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        this.inputmethodmanager.toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        this.edittext = (EditText) this.dialog.findViewById(R.id.edittext);
        this.edittext.requestFocus();
        this.ll_fontlist = (LinearLayout) this.dialog
                .findViewById(R.id.llfontlist);
        this.ll_fontlist.setVisibility(View.GONE);
        this.grid_fontlist = (GridView) this.dialog.findViewById(R.id.grid_fontlist);
        this.grid_fontlist.setAdapter(new FontStyleAdapter(this, this.fonts));
        this.grid_fontlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                WaterEffectEditorActivity.this.type = Typeface.createFromAsset(
                        WaterEffectEditorActivity.this.getAssets(),
                        WaterEffectEditorActivity.this.fonts[i]);
                WaterEffectEditorActivity.this.edittext
                        .setTypeface(WaterEffectEditorActivity.this.type);
                textView.setTypeface(WaterEffectEditorActivity.this.type);
            }
        });
        this.ll_colorlist = (LinearLayout) this.dialog
                .findViewById(R.id.ll_colorlist);
        this.ll_colorlist.setVisibility(View.GONE);
        this.grid_colorlist = (GridView) this.dialog
                .findViewById(R.id.grid_colorlist);
        ArrayList colors = HSVColors();
        final ArrayList arrayList = colors;
        this.grid_colorlist.setAdapter(new ArrayAdapter<Integer>(
                getApplicationContext(), 17367043, colors) {
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView,
                        parent);
                view.setBackgroundColor(((Integer) arrayList.get(position))
                        .intValue());
                view.setText("");
                view.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
                AbsListView.LayoutParams params = (AbsListView.LayoutParams) view
                        .getLayoutParams();
                params.width = WaterEffectEditorActivity.columnWidth;
                params.height = WaterEffectEditorActivity.columnWidth;
                view.setLayoutParams(params);
                view.requestLayout();
                return view;
            }
        });
        this.grid_colorlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                WaterEffectEditorActivity.this.pickedColor = ((Integer) adapterView
                        .getItemAtPosition(i)).intValue();
                WaterEffectEditorActivity.this.edittext
                        .setTextColor(WaterEffectEditorActivity.this.pickedColor);
                textView.setTextColor(WaterEffectEditorActivity.this.pickedColor);
            }
        });
        this.imageview_keyboard = (ImageView) this.dialog
                .findViewById(R.id.imgview_keyboard);
        this.imageview_keyboard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) WaterEffectEditorActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(
                        WaterEffectEditorActivity.this.edittext, 2);
                WaterEffectEditorActivity.this.ll_fontlist.setVisibility(View.GONE);
                WaterEffectEditorActivity.this.ll_colorlist.setVisibility(View.GONE);
            }
        });
        this.imageview_fontstyle = (ImageView) this.dialog
                .findViewById(R.id.imgview_fontstyle);
        this.imageview_fontstyle.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                WaterEffectEditorActivity.this.ll_fontlist.setVisibility(View.VISIBLE);
                WaterEffectEditorActivity.this.ll_colorlist.setVisibility(View.GONE);
                ((InputMethodManager) WaterEffectEditorActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                WaterEffectEditorActivity.this.edittext
                                        .getWindowToken(), 0);
            }
        });
        this.imageview_color = (ImageView) this.dialog.findViewById(R.id.imgview_color);
        this.imageview_color.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) WaterEffectEditorActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                WaterEffectEditorActivity.this.edittext
                                        .getWindowToken(), 0);
                WaterEffectEditorActivity.this.ll_colorlist.setVisibility(View.VISIBLE);
                WaterEffectEditorActivity.this.ll_fontlist.setVisibility(View.GONE);
            }
        });
        this.imageview_gravity = (ImageView) this.dialog.findViewById(R.id.imgview_gravity);
        this.imageview_gravity.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (WaterEffectEditorActivity.this.w == 0) {
                    WaterEffectEditorActivity.this.w = 1;
                    WaterEffectEditorActivity.this.imageview_gravity
                            .setImageDrawable(WaterEffectEditorActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.alignright));
                    WaterEffectEditorActivity.this.edittext.setGravity(5);
                    textView.setGravity(5);
                } else if (WaterEffectEditorActivity.this.w == 1) {
                    WaterEffectEditorActivity.this.imageview_gravity
                            .setImageDrawable(WaterEffectEditorActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.alignleft));
                    WaterEffectEditorActivity.this.edittext.setGravity(3);
                    textView.setGravity(3);
                    WaterEffectEditorActivity.this.w = 2;
                } else if (WaterEffectEditorActivity.this.w == 2) {
                    WaterEffectEditorActivity.this.w = 0;
                    WaterEffectEditorActivity.this.imageview_gravity
                            .setImageDrawable(WaterEffectEditorActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.aligncenter));
                    WaterEffectEditorActivity.this.edittext.setGravity(17);
                    textView.setGravity(17);
                }
            }
        });
        this.imageview_done = (ImageView) this.dialog.findViewById(R.id.imgview_done);
        final TextView txtEnteredText = (TextView) this.dialog
                .findViewById(R.id.txtEnteredText);
        txtEnteredText.setDrawingCacheEnabled(true);
        this.imageview_done.setOnClickListener(new OnClickListener() {

            public void onClick(View view) {
                WaterEffectEditorActivity.this.inputmethodmanager.hideSoftInputFromWindow(
                        view.getWindowToken(), 0);
                String st = WaterEffectEditorActivity.this.edittext.getText()
                        .toString();
                if (st.isEmpty()) {
                    Toast.makeText(WaterEffectEditorActivity.this, "text empty",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                txtEnteredText.setText(st);
                txtEnteredText.setTypeface(WaterEffectEditorActivity.this.type);
                txtEnteredText
                        .setTextColor(WaterEffectEditorActivity.this.pickedColor);
                txtEnteredText.setGravity(17);
                ImageView textImg = new ImageView(WaterEffectEditorActivity.this);
                txtEnteredText.buildDrawingCache();
                textImg.setImageBitmap(txtEnteredText.getDrawingCache());
                WaterEffectEditorActivity.textBitmap = WaterEffectEditorActivity
                        .loadBitmapFromView(textImg);
                WaterEffectEditorActivity.textBitmap = WaterEffectEditorActivity.this
                        .CropBitmapTransparency(WaterEffectEditorActivity.textBitmap);
                txtEnteredText.setDrawingCacheEnabled(false);
                ((InputMethodManager) WaterEffectEditorActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                WaterEffectEditorActivity.this.edittext
                                        .getWindowToken(), 0);
                final CustomStckerTextView stickerTextView = new CustomStckerTextView(
                        WaterEffectEditorActivity.this);
                stickerTextView.setBitmap(WaterEffectEditorActivity.textBitmap);
                WaterEffectEditorActivity.this.rlmain.addView(stickerTextView,
                        new FrameLayout.LayoutParams(-1, -1, 17));
                WaterEffectEditorActivity.this.stickers.add(stickerTextView);
                stickerTextView.setInEdit(true);
                WaterEffectEditorActivity.this
                        .setCurrentEditForText(stickerTextView);
                stickerTextView
                        .setOperationListener(new CustomStckerTextView.OperationListener() {
                            public void onDeleteClick() {
                                WaterEffectEditorActivity.this.stickers
                                        .remove(stickerTextView);
                                WaterEffectEditorActivity.this.rlmain
                                        .removeView(stickerTextView);
                            }

                            public void onEdit(
                                    CustomStckerTextView customTextView) {
                                WaterEffectEditorActivity.this.currentTextView
                                        .setInEdit(false);
                                WaterEffectEditorActivity.this.currentTextView = customTextView;
                                WaterEffectEditorActivity.this.currentTextView
                                        .setInEdit(true);
                            }

                            public void onTop(
                                    CustomStckerTextView customTextView) {
                                int position = WaterEffectEditorActivity.this.stickers
                                        .indexOf(customTextView);
                                if (position != WaterEffectEditorActivity.this.stickers
                                        .size() - 1) {
                                    WaterEffectEditorActivity.this.stickers
                                            .add(WaterEffectEditorActivity.this.stickers
                                                            .size(),
                                                    (CustomTextView) WaterEffectEditorActivity.this.stickers
                                                            .remove(position));
                                }
                            }
                        });
                WaterEffectEditorActivity.this.dialog.dismiss();
            }
        });
        this.dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            public boolean onKey(DialogInterface dialogInterface, int i,
                                 KeyEvent keyEvent) {
                if (i != 4 || keyEvent.getAction() != 1
                        || keyEvent.isCanceled()) {
                    return false;
                }
                WaterEffectEditorActivity.this.dialog.cancel();
                return true;
            }
        });
        this.dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        Window window2 = this.dialog.getWindow();
        layoutParams.copyFrom(window2.getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -1;
        window2.setAttributes(layoutParams);
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    public static ArrayList HSVColors() {
        final ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i <= 360; i += 20) {
            list.add(HSVColor(i, 1.0f, 1.0f));
        }
        for (int j = 0; j <= 360; j += 20) {
            list.add(HSVColor(j, 0.25f, 1.0f));
            list.add(HSVColor(j, 0.5f, 1.0f));
            list.add(HSVColor(j, 0.75f, 1.0f));
        }
        for (int k = 0; k <= 360; k += 20) {
            list.add(HSVColor(k, 1.0f, 0.5f));
            list.add(HSVColor(k, 1.0f, 0.75f));
        }
        for (float n = 0.0f; n <= 1.0f; n += 0.1f) {
            list.add(HSVColor(0.0f, 0.0f, n));
        }
        return list;
    }

    Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                if (((sourceBitmap.getPixel(x, y) >> 24) & 255) > 0) {
                    if (x < minX) {
                        minX = x;
                    }
                    if (x > maxX) {
                        maxX = x;
                    }
                    if (y < minY) {
                        minY = y;
                    }
                    if (y > maxY) {
                        maxY = y;
                    }
                }
            }
        }
        if (maxX < minX || maxY < minY) {
            return null;
        }
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1,
                (maxY - minY) + 1);
    }

    private void setCurrentEditForText(CustomStckerTextView stickerTextView) {
        this.currentTextView = stickerTextView;
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(true);
        }
    }

    public static Bitmap loadBitmapFromView(View v) {
        if (v.getMeasuredHeight() <= 0) {
            v.measure(-2, -2);
            Bbitmap = Bitmap.createBitmap(v.getMeasuredWidth(),
                    v.getMeasuredHeight(), Config.ARGB_8888);
            canvas = new Canvas(Bbitmap);
            v.layout(0, 0, v.getMeasuredWidth(), v.getMeasuredHeight());
            v.draw(canvas);
            return Bbitmap;
        }
        Bbitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(),
                Config.ARGB_8888);
        canvas = new Canvas(Bbitmap);
        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(canvas);
        return Bbitmap;
    }

    public void showStickerDialog() {
        final Dialog dial = new Dialog(this, android.R.style.Theme_Translucent);
        dial.requestWindowFeature(1);
        dial.setContentView(R.layout.sticker_dialog);
        dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dial.setCanceledOnTouchOutside(true);
        ((ImageView) dial.findViewById(R.id.back_dialog))
                .setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        dial.dismiss();
                    }
                });
        this.stickerlist = new ArrayList();
        GridView grid_sticker = (GridView) dial
                .findViewById(R.id.gridStickerList);
        setStickerList1();
        this.stickerAdapter = new StickerAdapter(getApplicationContext(),
                this.stickerlist);
        grid_sticker.setAdapter(this.stickerAdapter);
        grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                WaterEffectEditorActivity.this
                        .addStickerView(((Integer) WaterEffectEditorActivity.this.stickerlist
                                .get(i)).intValue());
                dial.dismiss();
            }
        });
        dial.show();
    }

    private void setStickerList1() {
        this.stickerlist.add(Integer.valueOf(R.drawable.ss1));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss2));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss3));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss4));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss5));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss6));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss7));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss8));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss9));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss10));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss11));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss12));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss13));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss14));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss15));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss16));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss17));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss18));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss19));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss20));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss21));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss22));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss23));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss24));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss25));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss26));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss27));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss28));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss29));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s29));
        this.stickerlist.add(Integer.valueOf(R.drawable.s30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s31));
        this.stickerlist.add(Integer.valueOf(R.drawable.s32));
        this.stickerlist.add(Integer.valueOf(R.drawable.s33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s34));
        this.stickerlist.add(Integer.valueOf(R.drawable.s35));
        this.stickerlist.add(Integer.valueOf(R.drawable.s36));
        this.stickerlist.add(Integer.valueOf(R.drawable.s37));
        this.stickerlist.add(Integer.valueOf(R.drawable.s38));
        this.stickerlist.add(Integer.valueOf(R.drawable.s39));
        this.stickerlist.add(Integer.valueOf(R.drawable.s40));
        this.stickerlist.add(Integer.valueOf(R.drawable.s41));
        this.stickerlist.add(Integer.valueOf(R.drawable.s42));
        this.stickerlist.add(Integer.valueOf(R.drawable.s43));
        this.stickerlist.add(Integer.valueOf(R.drawable.s44));
        this.stickerlist.add(Integer.valueOf(R.drawable.s45));
        this.stickerlist.add(Integer.valueOf(R.drawable.s46));
        this.stickerlist.add(Integer.valueOf(R.drawable.s47));
        this.stickerlist.add(Integer.valueOf(R.drawable.s48));
        this.stickerlist.add(Integer.valueOf(R.drawable.s49));
        this.stickerlist.add(Integer.valueOf(R.drawable.s50));
        this.stickerlist.add(Integer.valueOf(R.drawable.s51));
        this.stickerlist.add(Integer.valueOf(R.drawable.s52));
        this.stickerlist.add(Integer.valueOf(R.drawable.s53));
        this.stickerlist.add(Integer.valueOf(R.drawable.s54));
        this.stickerlist.add(Integer.valueOf(R.drawable.s55));

    }

    private void addStickerView(int id) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                WaterEffectEditorActivity.this.views.remove(stickerView);
                WaterEffectEditorActivity.this.rlmain.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                if (WaterEffectEditorActivity.this.currentTextView != null) {
                    WaterEffectEditorActivity.this.currentTextView.setInEdit(false);
                }
                WaterEffectEditorActivity.this.currentView.setInEdit(false);
                WaterEffectEditorActivity.this.currentView = stickerView;
                WaterEffectEditorActivity.this.currentView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = WaterEffectEditorActivity.this.views
                        .indexOf(stickerView);
                if (position != WaterEffectEditorActivity.this.views.size() - 1) {
                    WaterEffectEditorActivity.this.views.add(
                            WaterEffectEditorActivity.this.views.size(),
                            (StickerView) WaterEffectEditorActivity.this.views
                                    .remove(position));
                }
            }
        });
        this.rlmain.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.views.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(false);
        }
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

    private InterstitialAd interstitial;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {
        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(WaterEffectEditorActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        onBackPressed();
                        break;
                    case R.id.ll_save:
                        Intent i = new Intent(WaterEffectEditorActivity.this, shareActivity.class);
                        i.putExtra("key", 3);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(WaterEffectEditorActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
