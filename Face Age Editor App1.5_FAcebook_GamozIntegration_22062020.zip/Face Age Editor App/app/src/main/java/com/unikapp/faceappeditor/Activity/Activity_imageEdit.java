package com.unikapp.faceappeditor.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
//import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.unikapp.faceappeditor.Adapters.Adapter_Effects;
import com.unikapp.faceappeditor.Adapters.Adapter_Frame;
import com.unikapp.faceappeditor.Adapters.Adapter_Sticker;
import com.unikapp.faceappeditor.Adapters.fontStyle_Adapter;
import com.unikapp.faceappeditor.Utils.CustomTextView;
import com.unikapp.faceappeditor.Utils.CustomTextView.OperationListener;
import com.unikapp.faceappeditor.Utils.Effect;
import com.unikapp.faceappeditor.Utils.FrameModel;
import com.unikapp.faceappeditor.Utils.HorizontalListView;
import com.unikapp.faceappeditor.Utils.StickerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.unikapp.faceage.editorapp.R;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

import static com.unikapp.faceappeditor.Utils.nativeadsmethod.populateUnifiedNativeAdViewSmall;

public class Activity_imageEdit extends AppCompatActivity {
    public static Uri str_url;
    public static Bitmap bitmap;
    public static Bitmap final_bitmap = null;
    public static Canvas canvas;
    public static FrameLayout frameLayout;
    public static int intCounter = 0;
    public static Bitmap text_bitmap;
    LinearLayout ll_brightness;
    private SeekBar brightness_seekbar;
    private Dialog dialog;
    EditText edittext;
    ImageView img_color;
    ImageView img_done;
    ImageView img_fontstyle;
    ImageView img_gravity;
    ImageView img_keyboard;
    LinearLayout ll_linear;
    private HorizontalListView Hl_effect_list;
    private boolean flag_brightness = true;
    boolean flagforeffect = true;
    String fileName;
    String[] fonatarr = new String[]{"Select font", "Albatross",
            "Impregnable", "Asphaltic Grain", "Papercutting", "Sans serif",
            "Akhenaton", "Jeboy Free", "Script", "ShindlerFont",
            "Always Forever", "Rondelle", "Crochet", "Polsku"};
    String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
            "font4.TTF", "font5.ttf", "font6.TTF", "font9.ttf", "font11.ttf",
            "font12.ttf", "font14.TTF", "font16.TTF", "font17.ttf",
            "font20.ttf"};
    GridView gridview;
    private ArrayList<FrameModel> list_frame1;
    private ArrayList<Integer> list_frame2;
    private ArrayList<Integer> list_frame3;
    private ArrayList<Integer> list_frame4;
    private ArrayList<Integer> list_frame5;
    private ArrayList<Integer> list_frame6;
    private ArrayList<Integer> list_frame7;
    private ArrayList<Integer> list_frame8;
    private HorizontalListView listview;
    private LinearLayout ll_colorlist;
    private LinearLayout ll_fontlist;
    private CustomTextView current_textView;
    private StickerView currentView;
    private int picked_color = -1;
    GridView grid_colorlist;
    GridView grid_fontlist;
    private ImageView img_back;
    LinearLayout ll_img_effect;
    private static ImageView img_gallrey1;
    InputMethodManager input_method_manager;
    private boolean isFrame = true;
    private ArrayList<View> stickers = new ArrayList();
    LinearLayout ll_opacity;
    private SeekBar seekbar_opacity;
    private ImageView img_save;
    LinearLayout ll_sticker;
    LinearLayout ll_flip;
    private int stickerId;
    private ArrayList<Integer> sticker_list = new ArrayList();
    LinearLayout ll_text;
    private Typeface typeface;
    private int w = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_activity_main);
        BindView();
        setArryListOfFrame();
        setArraylistForSticker();
        setArryListOfGoggles();
        setArraylistForMustache();
        setArraylistForTurban();
        setArraylistForTatoo();
        setArraylistForCap();
        setArraylistForHair();
        setArraylistForBeard();
        effectselection();
        loadAd();
        initView();
    }

    private void initView() {
        this.img_gallrey1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Activity_imageEdit.this.currentView != null) {
                    Activity_imageEdit.this.currentView.setInEdit(false);
                }
                if (Activity_imageEdit.this.current_textView != null) {
                    Activity_imageEdit.this.current_textView.setInEdit(false);
                }
            }
        });
        this.img_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity_imageEdit.this.startActivity(new Intent(
                        Activity_imageEdit.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                Activity_imageEdit.this.finish();

            }
        });
        this.seekbar_opacity
                .setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress,
                                                  boolean fromUser) {
                        Activity_imageEdit.this.currentView
                                .setAlpha(((float) progress) / 255.0f);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
        this.ll_opacity.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity_imageEdit.this.brightness_seekbar.setVisibility(View.GONE);
                Activity_imageEdit.this.listview.setVisibility(View.GONE);
                Activity_imageEdit.this.Hl_effect_list.setVisibility(View.GONE);
                if (Activity_imageEdit.this.currentView == null) {
                    Toast.makeText(Activity_imageEdit.this.getApplicationContext(),
                            "Please Insert Sticker First", Toast.LENGTH_SHORT).show();
                } else if (Activity_imageEdit.this.flag_brightness) {
                    Activity_imageEdit.this.seekbar_opacity.setVisibility(View.VISIBLE);
                    Activity_imageEdit.this.flag_brightness = false;
                } else {
                    Activity_imageEdit.this.seekbar_opacity.setVisibility(View.GONE);
                    Activity_imageEdit.this.flag_brightness = true;
                }
            }
        });
        frameLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Activity_imageEdit.this.currentView != null) {
                    Activity_imageEdit.this.currentView.setInEdit(false);
                }
                if (Activity_imageEdit.this.current_textView != null) {
                    Activity_imageEdit.this.current_textView.setInEdit(false);
                }
            }
        });
        this.ll_img_effect.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Activity_imageEdit.this.currentView != null) {
                    Activity_imageEdit.this.currentView.setInEdit(false);
                }
                if (Activity_imageEdit.this.current_textView != null) {
                    Activity_imageEdit.this.current_textView.setInEdit(false);
                }
                Activity_imageEdit.this.seekbar_opacity.setVisibility(View.GONE);
                Activity_imageEdit.this.brightness_seekbar.setVisibility(View.GONE);
                Activity_imageEdit.this.listview.setVisibility(View.GONE);
                Activity_imageEdit.this.Hl_effect_list.setVisibility(View.VISIBLE);
                if (Activity_imageEdit.this.flagforeffect) {
                    Activity_imageEdit.this.brightness_seekbar.setVisibility(View.GONE);
                    Activity_imageEdit.this.Hl_effect_list.setVisibility(View.VISIBLE);
                    Activity_imageEdit.this.flagforeffect = false;
                    return;
                }
                Activity_imageEdit.this.Hl_effect_list.setVisibility(View.GONE);
                Activity_imageEdit.this.flagforeffect = true;
            }
        });
        this.img_save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Activity_imageEdit.this.currentView != null) {
                    Activity_imageEdit.this.currentView.setInEdit(false);
                }
                if (Activity_imageEdit.this.current_textView != null) {
                    Activity_imageEdit.this.current_textView.setInEdit(false);
                }
                new SaveImage(true).execute(new Void[0]);
            }
        });
        this.ll_brightness.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Activity_imageEdit.this.seekbar_opacity.setVisibility(View.GONE);
                Activity_imageEdit.this.listview.setVisibility(View.GONE);
                Activity_imageEdit.this.Hl_effect_list.setVisibility(View.GONE);
                if (Activity_imageEdit.this.flag_brightness) {
                    Activity_imageEdit.this.brightness_seekbar.setVisibility(View.VISIBLE);
                    Activity_imageEdit.this.flag_brightness = false;
                    return;
                }
                Activity_imageEdit.this.brightness_seekbar.setVisibility(View.GONE);
                Activity_imageEdit.this.flag_brightness = true;
            }
        });
        this.brightness_seekbar
                .setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress,
                                                  boolean fromUser) {
                        Activity_imageEdit.this.setBrightness(
                                Activity_imageEdit.this.img_gallrey1, progress + 100);
                        Activity_imageEdit.this.brightness_seekbar.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
        this.ll_sticker.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Activity_imageEdit.this.FrameVisible();

            }
        });
        this.ll_text.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Activity_imageEdit.this.openDialog();
            }
        });
        this.ll_flip.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (isFrame) {
                    Activity_imageEdit.img_gallrey1.setRotationY(180.0f);
                    isFrame = false;
                    return;
                }
                img_gallrey1.setRotationY(360.0f);
                isFrame = true;
            }
        });
    }

    private void BindView() {
        this.ll_sticker = (LinearLayout) findViewById(R.id.sticker);
        this.ll_flip = (LinearLayout) findViewById(R.id.ll_flip);
        this.img_back = (ImageView) findViewById(R.id.imgg_back);
        this.ll_img_effect = (LinearLayout) findViewById(R.id.img_effect);
        this.ll_opacity = (LinearLayout) findViewById(R.id.ll_opacity);
        this.ll_brightness = (LinearLayout) findViewById(R.id.ll_brightness);
        this.img_save = (ImageView) findViewById(R.id.imgsave);
        this.brightness_seekbar = (SeekBar) findViewById(R.id.brightness_bar);
        this.seekbar_opacity = (SeekBar) findViewById(R.id.opacity_bar);
        this.listview = (HorizontalListView) findViewById(R.id.listview);
        this.Hl_effect_list = (HorizontalListView) findViewById(R.id.effect_list);
        this.ll_linear = (LinearLayout) findViewById(R.id.linear);
        this.img_gallrey1 = (ImageView) findViewById(R.id.img_gallrey1);
        this.ll_text = (LinearLayout) findViewById(R.id.text);
        frameLayout = (FrameLayout) findViewById(R.id.framelayout);
        this.img_gallrey1.setImageBitmap(Activity_Crop.bitmap_cropped);
    }

    private InterstitialAd mInterstitialAd;

    private void loadAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_inter));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                Intent emailIntent1 = new Intent(Activity_imageEdit.this, Activity_Share.class);
                emailIntent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                emailIntent1.putExtra("image_path", fileName);
                startActivity(emailIntent1);
                finish();
                requestNewInterstitial();
            }
        });
    }

    private void requestNewInterstitial() {
        this.mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    public void effectselection() {
        ArrayList<Integer> effectList = new ArrayList();
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        effectList.add(Integer.valueOf(R.drawable.flower));
        this.Hl_effect_list.setAdapter(new Adapter_Effects(this, effectList));
        this.Hl_effect_list.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int position, long l) {
                if (position == 0) {
                    Effect.applyEffectNone(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 1) {
                    Effect.applyEffect1(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 2) {
                    Effect.applyEffect2(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 3) {
                    Effect.applyEffect4(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 4) {
                    Effect.applyEffect5(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 5) {
                    Effect.applyEffect6(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 6) {
                    Effect.applyEffect7(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 7) {
                    Effect.applyEffect9(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 8) {
                    Effect.applyEffect11(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 9) {
                    Effect.applyEffect12(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 10) {
                    Effect.applyEffect14(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 11) {
                    Effect.applyEffect15(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 12) {
                    Effect.applyEffect16(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 13) {
                    Effect.applyEffect17(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 14) {
                    Effect.applyEffect18(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 15) {
                    Effect.applyEffect19(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 16) {
                    Effect.applyEffect20(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 17) {
                    Effect.applyEffect21(Activity_imageEdit.this.img_gallrey1);
                }
                if (position == 18) {
                    Effect.applyEffect22(Activity_imageEdit.this.img_gallrey1);
                }
            }
        });
    }


    class SaveImage extends AsyncTask<Void, Void, Void> {
        Bitmap bmp = null;
        boolean isSaved = false;
        boolean isShare = false;
        ProgressDialog pd;

        public SaveImage(boolean b) {
            this.isShare = b;
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd = new ProgressDialog(Activity_imageEdit.this);
            this.pd.setTitle("Please Wait.....");
            this.pd.show();
            try {
                frameLayout.setDrawingCacheEnabled(true);
                frameLayout.buildDrawingCache();
                bmp = frameLayout.getDrawingCache();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @SuppressLint({"SimpleDateFormat"})
        protected Void doInBackground(Void... params) {
            Exception e;
            Throwable th;
            File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + getResources().getString(R.string.app_name));
            if (!file.exists()) {
                file.mkdirs();
            }

            try {
                fileName = file.getAbsolutePath() + "/" + new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date())
                        + ".jpg";
            } catch (Exception e2) {
            }
            FileOutputStream out = null;
            try {
                FileOutputStream out2 = new FileOutputStream(fileName);
                try {
                    this.bmp.compress(Bitmap.CompressFormat.PNG, 90, out2);
                    try {
                        out2.close();
                        out = out2;
                    } catch (Throwable th2) {
                        out = out2;
                    }
                } catch (Exception e3) {
                    e = e3;
                    out = out2;
                    try {
                        e.printStackTrace();
                        try {
                            out.close();
                        } catch (Throwable th3) {
                        }
                        return null;
                    } catch (Throwable th4) {
                        th = th4;
                        try {
                            out.close();
                        } catch (Throwable th5) {
                        }
                    }
                } catch (Throwable th6) {
                    th = th6;
                    out = out2;
                    out.close();
                }
            } catch (Exception e4) {
                e = e4;
                e.printStackTrace();
                return null;
            }
            return null;
        }

        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            this.pd.dismiss();
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Intent emailIntent1 = new Intent(Activity_imageEdit.this, Activity_Share.class);
                emailIntent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                emailIntent1.putExtra("image_path", fileName);
                startActivity(emailIntent1);
                finish();
            }
        }
    }


    private void setBrightness(ImageView image, int value) {
        float[] mainMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 0.0f};
        float brightness = (float) (value - 255);
        mainMatrix[4] = brightness;
        mainMatrix[9] = brightness;
        mainMatrix[14] = brightness;
        image.setColorFilter(new ColorMatrixColorFilter(mainMatrix));
    }

    private void setArryListOfFrame() {
        this.list_frame1 = new ArrayList();

        this.list_frame1.add(new FrameModel(R.drawable.rage_1,
                R.drawable.rage_1));
        this.list_frame1.add(new FrameModel(R.drawable.cat_face_01, R.drawable.cat_face_01));
        this.list_frame1
                .add(new FrameModel(R.drawable.img_1, R.drawable.img_1));


        this.list_frame1.add(new FrameModel(R.drawable.mustachi1,
                R.drawable.mustachi1));
        this.list_frame1.add(new FrameModel(R.drawable.m1, R.drawable.m1));
        this.list_frame1.add(new FrameModel(R.drawable.t_1, R.drawable.t_1));

        this.list_frame1.add(new FrameModel(R.drawable.cap1, R.drawable.cap1));
        this.list_frame1.add(new FrameModel(R.drawable.s11, R.drawable.s11));
    }

    private void setArryListOfGoggles() {
        this.list_frame2 = new ArrayList();
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_01));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_02));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_03));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_04));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_05));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_06));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_07));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_08));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_09));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_10));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_11));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_12));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_13));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_14));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_15));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_16));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_17));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_18));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_19));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_20));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_21));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_22));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_23));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_24));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_25));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_26));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_27));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_28));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_29));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_30));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_31));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_32));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_33));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_34));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_35));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_36));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_37));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_38));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_39));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_40));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_41));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_42));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_43));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_44));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_45));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_46));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_47));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_48));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_49));
        this.list_frame2.add(Integer.valueOf(R.drawable.cat_face_50));

    }

    private void setArraylistForMustache() {
        this.list_frame3 = new ArrayList();
        this.list_frame3.add(Integer.valueOf(R.drawable.m34));
        this.list_frame3.add(Integer.valueOf(R.drawable.m35));
        this.list_frame3.add(Integer.valueOf(R.drawable.m36));
        this.list_frame3.add(Integer.valueOf(R.drawable.m37));
        this.list_frame3.add(Integer.valueOf(R.drawable.m38));
        this.list_frame3.add(Integer.valueOf(R.drawable.m39));
        this.list_frame3.add(Integer.valueOf(R.drawable.m1));
        this.list_frame3.add(Integer.valueOf(R.drawable.m2));
        this.list_frame3.add(Integer.valueOf(R.drawable.m9));
        this.list_frame3.add(Integer.valueOf(R.drawable.m10));
        this.list_frame3.add(Integer.valueOf(R.drawable.m30));
        this.list_frame3.add(Integer.valueOf(R.drawable.m3));
        this.list_frame3.add(Integer.valueOf(R.drawable.m4));
        this.list_frame3.add(Integer.valueOf(R.drawable.m5));
        this.list_frame3.add(Integer.valueOf(R.drawable.m31));
        this.list_frame3.add(Integer.valueOf(R.drawable.m32));
        this.list_frame3.add(Integer.valueOf(R.drawable.m33));
        this.list_frame3.add(Integer.valueOf(R.drawable.m11));
        this.list_frame3.add(Integer.valueOf(R.drawable.m12));
        this.list_frame3.add(Integer.valueOf(R.drawable.m13));
        this.list_frame3.add(Integer.valueOf(R.drawable.m14));
        this.list_frame3.add(Integer.valueOf(R.drawable.m15));
        this.list_frame3.add(Integer.valueOf(R.drawable.m16));
        this.list_frame3.add(Integer.valueOf(R.drawable.m17));
        this.list_frame3.add(Integer.valueOf(R.drawable.m18));
        this.list_frame3.add(Integer.valueOf(R.drawable.m19));
        this.list_frame3.add(Integer.valueOf(R.drawable.m20));
        this.list_frame3.add(Integer.valueOf(R.drawable.m21));
        this.list_frame3.add(Integer.valueOf(R.drawable.m47));
        this.list_frame3.add(Integer.valueOf(R.drawable.m48));
        this.list_frame3.add(Integer.valueOf(R.drawable.m22));
        this.list_frame3.add(Integer.valueOf(R.drawable.m23));
        this.list_frame3.add(Integer.valueOf(R.drawable.m40));
        this.list_frame3.add(Integer.valueOf(R.drawable.m41));
        this.list_frame3.add(Integer.valueOf(R.drawable.m42));
        this.list_frame3.add(Integer.valueOf(R.drawable.m43));
        this.list_frame3.add(Integer.valueOf(R.drawable.m44));
        this.list_frame3.add(Integer.valueOf(R.drawable.m25));
        this.list_frame3.add(Integer.valueOf(R.drawable.m28));
        this.list_frame3.add(Integer.valueOf(R.drawable.m29));
        this.list_frame3.add(Integer.valueOf(R.drawable.m45));
        this.list_frame3.add(Integer.valueOf(R.drawable.m46));

    }

    private void setArraylistForTurban() {
        this.list_frame4 = new ArrayList();

        this.list_frame4.add(Integer.valueOf(R.drawable.turban21));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban22));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban23));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_10));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_1));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_2));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_26));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_3));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_25));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_5));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_6));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_11));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_27));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban24));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban25));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban26));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_7));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_8));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_9));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_12));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban29));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban30));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban31));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_4));
        this.list_frame4.add(Integer.valueOf(R.drawable.t_13));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban16));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban17));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban18));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban19));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban20));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban27));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban28));
        this.list_frame4.add(Integer.valueOf(R.drawable.turban32));

    }

    private void setArraylistForHair() {
        this.list_frame5 = new ArrayList();
        this.list_frame5.add(Integer.valueOf(R.drawable.img_1));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_2));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_3));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_4));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_34));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_10));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_11));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_12));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_13));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_14));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_15));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_16));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_17));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_18));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_19));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_20));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_21));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_22));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_23));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_5));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_6));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_7));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_8));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_24));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_25));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_26));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_27));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_9));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_28));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_29));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_30));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_31));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_32));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_33));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_35));
        this.list_frame5.add(Integer.valueOf(R.drawable.img_36));
    }

    private void setArraylistForCap() {
        this.list_frame6 = new ArrayList();
        this.list_frame6.add(Integer.valueOf(R.drawable.cap1));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap2));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap3));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap4));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap5));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap6));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap7));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap8));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap9));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap10));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap11));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap12));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap13));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap14));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap15));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap16));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap17));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap18));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap19));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap20));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap21));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap22));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap23));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap24));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap25));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap26));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap27));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap28));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap29));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap31));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap32));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap33));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap34));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap35));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap36));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap37));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap38));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap39));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap40));

        this.list_frame6.add(Integer.valueOf(R.drawable.cap41));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap42));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap43));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap44));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap45));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap46));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap47));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap48));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap49));
        this.list_frame6.add(Integer.valueOf(R.drawable.cap50));
    }

    private void setArraylistForTatoo() {
        this.list_frame7 = new ArrayList();
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_1));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_2));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_3));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_4));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_5));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_6));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_7));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_8));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_9));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_10));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_11));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_12));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_13));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_14));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_15));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_16));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_17));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_18));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_19));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_20));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_21));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_22));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_23));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_24));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_25));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_26));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_27));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_28));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_29));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_30));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_31));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_32));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_33));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_34));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_35));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_36));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_37));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_38));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_39));
        this.list_frame7.add(Integer.valueOf(R.drawable.rage_40));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_01));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_21));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_22));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_23));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_24));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_25));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_26));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_27));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_28));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_29));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_30));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_31));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_32));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_33));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_34));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_35));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_36));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_37));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_38));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_39));
        this.list_frame7.add(Integer.valueOf(R.drawable.accessory_40));

    }

    private void setArraylistForBeard() {
        this.list_frame8 = new ArrayList();
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi1));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi2));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi3));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi4));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi6));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi7));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi8));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi10));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi11));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi12));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi13));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi14));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi15));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi16));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_38));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_39));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_40));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_41));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi20));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi21));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi22));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi23));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi24));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi25));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi26));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi27));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi28));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi29));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi30));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi31));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi32));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi33));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi34));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi35));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi36));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_37));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_42));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_43));
        this.list_frame8.add(Integer.valueOf(R.drawable.mustachi_44));
    }

    private void setArraylistForSticker() {
        this.sticker_list.add(Integer.valueOf(R.drawable.s31));
        this.sticker_list.add(Integer.valueOf(R.drawable.s32));
        this.sticker_list.add(Integer.valueOf(R.drawable.s33));
        this.sticker_list.add(Integer.valueOf(R.drawable.s34));
        this.sticker_list.add(Integer.valueOf(R.drawable.s35));
        this.sticker_list.add(Integer.valueOf(R.drawable.s36));
        this.sticker_list.add(Integer.valueOf(R.drawable.s37));
        this.sticker_list.add(Integer.valueOf(R.drawable.s38));
        this.sticker_list.add(Integer.valueOf(R.drawable.s39));
        this.sticker_list.add(Integer.valueOf(R.drawable.s40));
        this.sticker_list.add(Integer.valueOf(R.drawable.s41));
        this.sticker_list.add(Integer.valueOf(R.drawable.s42));
        this.sticker_list.add(Integer.valueOf(R.drawable.s43));
        this.sticker_list.add(Integer.valueOf(R.drawable.s44));
        this.sticker_list.add(Integer.valueOf(R.drawable.s1));
        this.sticker_list.add(Integer.valueOf(R.drawable.s2));
        this.sticker_list.add(Integer.valueOf(R.drawable.s3));
        this.sticker_list.add(Integer.valueOf(R.drawable.s4));
        this.sticker_list.add(Integer.valueOf(R.drawable.s5));
        this.sticker_list.add(Integer.valueOf(R.drawable.s6));
        this.sticker_list.add(Integer.valueOf(R.drawable.s7));
        this.sticker_list.add(Integer.valueOf(R.drawable.s9));
        this.sticker_list.add(Integer.valueOf(R.drawable.s10));
        this.sticker_list.add(Integer.valueOf(R.drawable.s11));
        this.sticker_list.add(Integer.valueOf(R.drawable.s12));
        this.sticker_list.add(Integer.valueOf(R.drawable.s13));
        this.sticker_list.add(Integer.valueOf(R.drawable.s14));
        this.sticker_list.add(Integer.valueOf(R.drawable.s15));
        this.sticker_list.add(Integer.valueOf(R.drawable.s16));
        this.sticker_list.add(Integer.valueOf(R.drawable.s17));
        this.sticker_list.add(Integer.valueOf(R.drawable.s19));
        this.sticker_list.add(Integer.valueOf(R.drawable.s22));
        this.sticker_list.add(Integer.valueOf(R.drawable.s23));
        this.sticker_list.add(Integer.valueOf(R.drawable.s24));
        this.sticker_list.add(Integer.valueOf(R.drawable.s25));
        this.sticker_list.add(Integer.valueOf(R.drawable.s26));
        this.sticker_list.add(Integer.valueOf(R.drawable.s27));
        this.sticker_list.add(Integer.valueOf(R.drawable.s28));
    }

    public void openDialog() {
        this.dialog = new Dialog(this);
        this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.input_method_manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        this.input_method_manager.toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        this.edittext = (EditText) this.dialog.findViewById(R.id.edit_text);
        this.edittext.requestFocus();
        this.ll_fontlist = (LinearLayout) this.dialog
                .findViewById(R.id.ll_fontlist);
        this.ll_fontlist.setVisibility(View.GONE);
        this.grid_fontlist = (GridView) this.dialog
                .findViewById(R.id.grid_fontlist);
        this.grid_fontlist.setAdapter(new fontStyle_Adapter(this, this.fonts));
        this.grid_fontlist.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                Activity_imageEdit.this.typeface = Typeface.createFromAsset(
                        Activity_imageEdit.this.getAssets(),
                        Activity_imageEdit.this.fonts[i]);
                Activity_imageEdit.this.edittext
                        .setTypeface(Activity_imageEdit.this.typeface);
                textView.setTypeface(Activity_imageEdit.this.typeface);
            }
        });
        this.ll_colorlist = (LinearLayout) this.dialog
                .findViewById(R.id.ll_colorlist);
        this.ll_colorlist.setVisibility(View.GONE);
        this.grid_colorlist = (GridView) this.dialog
                .findViewById(R.id.grid_colorlist);
        ArrayList colors = HSVColors();
        final ArrayList arrayList = colors;
        this.grid_colorlist.setAdapter(new ArrayAdapter<Integer>(
                getApplicationContext(), 17367043, colors) {
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView,
                        parent);
                view.setBackgroundColor(((Integer) arrayList.get(position))
                        .intValue());
                view.setText("");
                view.setLayoutParams(new LayoutParams(-1, -1));
                LayoutParams params = (LayoutParams) view.getLayoutParams();
                params.width = 80;
                params.height = 80;
                view.setLayoutParams(params);
                view.requestLayout();
                return view;
            }
        });
        this.grid_colorlist.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                Activity_imageEdit.this.picked_color = ((Integer) adapterView
                        .getItemAtPosition(i)).intValue();
                Activity_imageEdit.this.edittext
                        .setTextColor(Activity_imageEdit.this.picked_color);
                textView.setTextColor(Activity_imageEdit.this.picked_color);
            }
        });
        this.img_keyboard = (ImageView) this.dialog
                .findViewById(R.id.img_keyboard);
        this.img_keyboard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) Activity_imageEdit.this
                        .getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(
                        Activity_imageEdit.this.edittext, 2);
                Activity_imageEdit.this.ll_fontlist.setVisibility(View.GONE);
                Activity_imageEdit.this.ll_colorlist.setVisibility(View.GONE);
            }
        });
        this.img_fontstyle = (ImageView) this.dialog
                .findViewById(R.id.img_fontstyle);
        this.img_fontstyle.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Activity_imageEdit.this.ll_fontlist.setVisibility(View.VISIBLE);
                Activity_imageEdit.this.ll_colorlist.setVisibility(View.GONE);
                ((InputMethodManager) Activity_imageEdit.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                Activity_imageEdit.this.edittext
                                        .getWindowToken(), 0);
            }
        });
        this.img_color = (ImageView) this.dialog.findViewById(R.id.img_color);
        this.img_color.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) Activity_imageEdit.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                Activity_imageEdit.this.edittext
                                        .getWindowToken(), 0);
                Activity_imageEdit.this.ll_colorlist.setVisibility(View.VISIBLE);
                Activity_imageEdit.this.ll_fontlist.setVisibility(View.GONE);
            }
        });
        this.img_gravity = (ImageView) this.dialog
                .findViewById(R.id.img_gravity);
        this.img_gravity.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (Activity_imageEdit.this.w == 0) {
                    Activity_imageEdit.this.w = 1;
                    Activity_imageEdit.this.img_gravity
                            .setImageDrawable(Activity_imageEdit.this
                                    .getResources().getDrawable(
                                            R.drawable.alignright));
                    Activity_imageEdit.this.edittext.setGravity(5);
                    textView.setGravity(5);
                } else if (Activity_imageEdit.this.w == 1) {
                    Activity_imageEdit.this.img_gravity
                            .setImageDrawable(Activity_imageEdit.this
                                    .getResources().getDrawable(
                                            R.drawable.alignleft));
                    Activity_imageEdit.this.edittext.setGravity(3);
                    textView.setGravity(3);
                    Activity_imageEdit.this.w = 2;
                } else if (Activity_imageEdit.this.w == 2) {
                    Activity_imageEdit.this.w = 0;
                    Activity_imageEdit.this.img_gravity
                            .setImageDrawable(Activity_imageEdit.this
                                    .getResources().getDrawable(
                                            R.drawable.aligncenter));
                    Activity_imageEdit.this.edittext.setGravity(17);
                    textView.setGravity(17);
                }
            }
        });
        this.img_done = (ImageView) this.dialog.findViewById(R.id.img_done);
        final TextView txtEnteredText = (TextView) this.dialog
                .findViewById(R.id.txtEntered_Text);
        txtEnteredText.setDrawingCacheEnabled(true);
        this.img_done.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Activity_imageEdit.this.input_method_manager
                        .hideSoftInputFromWindow(view.getWindowToken(), 0);
                String st = Activity_imageEdit.this.edittext.getText()
                        .toString();
                if (st.isEmpty()) {
                    Toast.makeText(Activity_imageEdit.this, "text empty", Toast.LENGTH_SHORT)
                            .show();
                    return;
                }
                txtEnteredText.setText(st);
                txtEnteredText.setTypeface(Activity_imageEdit.this.typeface);
                txtEnteredText
                        .setTextColor(Activity_imageEdit.this.picked_color);
                txtEnteredText.setGravity(17);
                ImageView textImg = new ImageView(Activity_imageEdit.this);
                txtEnteredText.buildDrawingCache();
                textImg.setImageBitmap(txtEnteredText.getDrawingCache());
                Activity_imageEdit.text_bitmap = Activity_imageEdit
                        .loadBitmapFromView(textImg);
                Activity_imageEdit.text_bitmap = Activity_imageEdit.this
                        .CropBitmapTransparency(Activity_imageEdit.text_bitmap);
                txtEnteredText.setDrawingCacheEnabled(false);
                ((InputMethodManager) Activity_imageEdit.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                Activity_imageEdit.this.edittext
                                        .getWindowToken(), 0);
                final CustomTextView stickerTextView = new CustomTextView(
                        Activity_imageEdit.this);
                stickerTextView.setBitmap(Activity_imageEdit.text_bitmap);
                Activity_imageEdit.frameLayout.addView(stickerTextView,
                        new FrameLayout.LayoutParams(-1, -1, 17));
                Activity_imageEdit.this.stickers.add(stickerTextView);
                stickerTextView.setInEdit(true);
                Activity_imageEdit.this.setCurrentEditForText(stickerTextView);
                stickerTextView.setOperationListener(new OperationListener() {
                    public void onDeleteClick() {
                        Activity_imageEdit.this.stickers
                                .remove(stickerTextView);
                        Activity_imageEdit.frameLayout
                                .removeView(stickerTextView);
                    }

                    public void onEdit(CustomTextView customTextView) {
                        Activity_imageEdit.this.current_textView
                                .setInEdit(false);
                        Activity_imageEdit.this.current_textView = customTextView;
                        Activity_imageEdit.this.current_textView
                                .setInEdit(true);
                    }

                    public void onTop(CustomTextView customTextView) {
                        int position = Activity_imageEdit.this.stickers
                                .indexOf(customTextView);
                        if (position != Activity_imageEdit.this.stickers.size() - 1) {
                            Activity_imageEdit.this.stickers.add(
                                    Activity_imageEdit.this.stickers.size(),
                                    (CustomTextView) Activity_imageEdit.this.stickers
                                            .remove(position));
                        }
                    }
                });
                Activity_imageEdit.this.dialog.dismiss();
            }
        });
        this.dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        Window window2 = this.dialog.getWindow();
        layoutParams.copyFrom(window2.getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -1;
        window2.setAttributes(layoutParams);
    }

    protected void onResume() {
        super.onResume();
    }

    private void setCurrentEditForText(CustomTextView customTextView) {
        if (this.current_textView != null) {
            this.current_textView.setInEdit(false);
        }
        this.current_textView = customTextView;
        customTextView.setInEdit(true);
    }

    Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                if (((sourceBitmap.getPixel(x, y) >> 24) & 255) > 0) {
                    if (x < minX) {
                        minX = x;
                    }
                    if (x > maxX) {
                        maxX = x;
                    }
                    if (y < minY) {
                        minY = y;
                    }
                    if (y > maxY) {
                        maxY = y;
                    }
                }
            }
        }
        if (maxX < minX || maxY < minY) {
            return null;
        }
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1,
                (maxY - minY) + 1);
    }

    public static Bitmap loadBitmapFromView(View v) {
        if (v.getMeasuredHeight() <= 0) {
            v.measure(-2, -2);
            bitmap = Bitmap.createBitmap(v.getMeasuredWidth(),
                    v.getMeasuredHeight(), Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            v.layout(0, 0, v.getMeasuredWidth(), v.getMeasuredHeight());
            v.draw(canvas);
            return bitmap;
        }
        bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(),
                Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(canvas);
        return bitmap;
    }

    public static ArrayList HSVColors() {
        final ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i <= 360; i += 20) {
            list.add(HSVColor(i, 1.0f, 1.0f));
        }
        for (int j = 0; j <= 360; j += 20) {
            list.add(HSVColor(j, 0.25f, 1.0f));
            list.add(HSVColor(j, 0.5f, 1.0f));
            list.add(HSVColor(j, 0.75f, 1.0f));
        }
        for (int k = 0; k <= 360; k += 20) {
            list.add(HSVColor(k, 1.0f, 0.5f));
            list.add(HSVColor(k, 1.0f, 0.75f));
        }
        for (float n = 0.0f; n <= 1.0f; n += 0.1f) {
            list.add(HSVColor(0.0f, 0.0f, n));
        }
        return list;
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    public void onBackPressed() {
        startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    private UnifiedNativeAd nativeAd;

    public void Frame0() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Cat Face");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame2));
        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame2.get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView.setOperationListener(new StickerView.OperationListener() {
                    public void onDeleteClick() {
                        Activity_imageEdit.this.stickers
                                .remove(stickerView);
                        Activity_imageEdit.frameLayout
                                .removeView(stickerView);
                    }

                    public void onEdit(StickerView stickerView) {
                        if (Activity_imageEdit.this.currentView != null) {
                            Activity_imageEdit.this.currentView
                                    .setInEdit(false);
                        }
                        Activity_imageEdit.this.currentView = stickerView;
                        Activity_imageEdit.this.currentView
                                .setInEdit(true);
                    }

                    public void onTop(StickerView stickerView) {
                        int position = Activity_imageEdit.this.stickers
                                .indexOf(stickerView);
                        if (position != Activity_imageEdit.this.stickers
                                .size() - 1) {
                            Activity_imageEdit.this.stickers.add(
                                    Activity_imageEdit.this.stickers
                                            .size(),
                                    (StickerView) Activity_imageEdit.this.stickers
                                            .remove(position));
                        }
                    }
                });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public void Frame1() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Mustache");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame3));

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());


        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame3
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame2() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Turban");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame4));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame4
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame3() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Hair");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame5));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame5
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame4() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Beard");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame8));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame8
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame5() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Accessory");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame7));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame7
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame6() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Caps");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        gridview.setAdapter(new Adapter_Sticker(this, this.list_frame6));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.list_frame6
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Frame7() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.frames);
        ((TextView) dialog.findViewById(R.id.txt_name)).setText("Smiley");
        GridView gridview = (GridView) dialog.findViewById(R.id.gridview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        gridview.setAdapter(new Adapter_Sticker(this, this.sticker_list));
        gridview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                final StickerView stickerView = new StickerView(
                        Activity_imageEdit.this);
                Activity_imageEdit.this.stickerId = ((Integer) Activity_imageEdit.this.sticker_list
                        .get(i)).intValue();
                stickerView.setImageResource(Activity_imageEdit.this.stickerId);
                stickerView
                        .setOperationListener(new StickerView.OperationListener() {
                            public void onDeleteClick() {
                                Activity_imageEdit.this.stickers
                                        .remove(stickerView);
                                Activity_imageEdit.frameLayout
                                        .removeView(stickerView);
                            }

                            public void onEdit(StickerView stickerView) {
                                if (Activity_imageEdit.this.currentView != null) {
                                    Activity_imageEdit.this.currentView
                                            .setInEdit(false);
                                }
                                Activity_imageEdit.this.currentView = stickerView;
                                Activity_imageEdit.this.currentView
                                        .setInEdit(true);
                            }

                            public void onTop(StickerView stickerView) {
                                int position = Activity_imageEdit.this.stickers
                                        .indexOf(stickerView);
                                if (position != Activity_imageEdit.this.stickers
                                        .size() - 1) {
                                    Activity_imageEdit.this.stickers.add(
                                            Activity_imageEdit.this.stickers
                                                    .size(),
                                            (StickerView) Activity_imageEdit.this.stickers
                                                    .remove(position));
                                }
                            }
                        });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,
                        -1, 17);
                stickerView.setLayoutParams(new FrameLayout.LayoutParams(200,
                        200, 17));
                Activity_imageEdit.frameLayout.addView(stickerView, lp);
                Activity_imageEdit.this.stickers.add(stickerView);
                Activity_imageEdit.this.setCurrentEdit(stickerView);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void FrameVisible() {
        if (this.isFrame) {
            this.Hl_effect_list.setVisibility(View.GONE);
            this.seekbar_opacity.setVisibility(View.GONE);
            this.brightness_seekbar.setVisibility(View.GONE);
            this.listview.setVisibility(View.VISIBLE);
            this.listview.setAdapter(new Adapter_Frame(this, this.list_frame1));
            this.listview.setOnItemClickListener(new OnItemClickListener() {
                public void onItemClick(AdapterView<?> adapterView, View view,
                                        int i, long l) {
                    int frameid = ((FrameModel) Activity_imageEdit.this.list_frame1
                            .get(i)).getFrameID();
                    if (i == 0) {
                        Activity_imageEdit.this.Frame5();


                    } else if (i == 1) {
                        Activity_imageEdit.this.Frame0();

                    } else if (i == 2) {

                        Activity_imageEdit.this.Frame3();

                    } else if (i == 3) {
                        Activity_imageEdit.this.Frame4();
                    } else if (i == 4) {
                        Activity_imageEdit.this.Frame1();

                    } else if (i == 5) {
                        Activity_imageEdit.this.Frame2();

                    } else if (i == 6) {
                        Activity_imageEdit.this.Frame6();
                    } else if (i == 7) {
                        Activity_imageEdit.this.Frame7();
                    }
                }
            });
            this.isFrame = false;
            return;
        }
        this.listview.setVisibility(View.GONE);
        this.isFrame = true;
    }
}
