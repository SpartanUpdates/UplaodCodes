package com.kotlinz.vehiclemanager.fuel.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FuelCityStateActivity extends AppCompatActivity implements View.OnClickListener {

    private Activity activity = FuelCityStateActivity.this;
    private ImageView iv_back;
    private Button btn_getdetails;
    private Spinner stateListSpinner;
    private Spinner cityListSpinner;
    private AppCompatDialog dialog;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private TextView title_tv;
    private RelativeLayout city_layout;
    private Boolean checkDark = false;
    private int statePosition = 11, cityPosition = 0;

    private NativeAd nativeAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fuel_city_state);
        sharedPreferences = getApplicationContext().getSharedPreferences("stateName", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        statePosition = sharedPreferences.getInt("statePosition", 0);
        cityPosition = sharedPreferences.getInt("cityPosition", 0);
        PutAnalyticsEvent();
        BindView();
        DialogAnimation();
        LoadNativeAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            checkDark = true;
            setupNightMode();
        }

        DarkTheame darkTheame = new DarkTheame(FuelCityStateActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            checkDark = true;
            setupNightMode();
        }
        if (Utils.isOnline(activity)) {
            getStateCityData();

        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "FuelCityStateActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (FuelCityStateActivity.this.nativeAd != null) {
                            FuelCityStateActivity.this.nativeAd.destroy();
                        }
                        FuelCityStateActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void setupNightMode() {
        city_layout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void getStateCityData() {
        String cityStateJsonData = Utils.getStateCityFromJson(FuelCityStateActivity.this, "rtoofficeinfo.json");
        ArrayList<String> stateList = new ArrayList<>();
        ArrayList<String> cityList = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(cityStateJsonData);
            JSONArray mainArray = obj.getJSONArray("details");
            for (int i = 0; i < mainArray.length(); i++) {
                JSONObject stateObj = mainArray.getJSONObject(i);
                String stateName = stateObj.getString("name");
                stateList.add(String.valueOf(stateName));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayAdapter stateAdapter;
        if (checkDark) {
            stateAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner, stateList);
            stateAdapter.setDropDownViewResource(R.layout.city_list_background_spinner);
        } else {
            stateAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner_dark, stateList);
            stateAdapter.setDropDownViewResource(R.layout.city_list_background_spinner_dark);
        }
        stateListSpinner.setAdapter(stateAdapter);
        stateListSpinner.setSelection(statePosition);

        stateListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cityList.clear();
                String selectedState = (String) stateListSpinner.getSelectedItem();
                editor.putString("stateName", selectedState);
                editor.putInt("statePosition", stateListSpinner.getSelectedItemPosition());
                editor.commit();
                try {
                    JSONObject obj = new JSONObject(cityStateJsonData);
                    JSONArray mainArray = obj.getJSONArray("details");
                    for (int i = 0; i < mainArray.length(); i++) {
                        JSONObject stateObj = mainArray.getJSONObject(i);
                        String stateName = stateObj.getString("name");
                        JSONArray cityArray = stateObj.getJSONArray("rtoList");
                        if (stateName.equals(selectedState)) {
                            for (int j = 0; j < cityArray.length(); j++) {
                                JSONObject cityObj = cityArray.getJSONObject(j);
                                String cityName = cityObj.getString("district");
                                cityList.add(cityName);
                            }
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ArrayAdapter cityAdapter;
                if (checkDark) {
                    cityAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner, cityList);
                    cityAdapter.setDropDownViewResource(R.layout.city_list_background_spinner);
                } else {
                    cityAdapter = new ArrayAdapter(activity, R.layout.city_list_background_spinner_dark, cityList);
                    cityAdapter.setDropDownViewResource(R.layout.city_list_background_spinner_dark);
                }
                cityListSpinner.setAdapter(cityAdapter);
                cityListSpinner.setSelection(cityPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        dialog.dismiss();

        cityListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String cityName = (String) cityListSpinner.getSelectedItem();
                editor.putString("cityName", cityName);
                editor.putInt("cityPosition", cityListSpinner.getSelectedItemPosition());
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        stateListSpinner = findViewById(R.id.spinnerstatelist);
        cityListSpinner = findViewById(R.id.spinnercitylist);
        btn_getdetails = findViewById(R.id.btn_get_details);
        title_tv = findViewById(R.id.title_tv);
        city_layout = findViewById(R.id.city_layout);
        iv_back.setOnClickListener(this);
        btn_getdetails.setOnClickListener(this);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_fuelcitydialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.btn_get_details:
                if (MyApplication.isShowAd == 1) {
                    Intent intent = new Intent(FuelCityStateActivity.this, MainActivity.class);
                    intent.putExtra("cityname", String.valueOf(cityListSpinner.getSelectedItem()));
                    intent.putExtra("statename", String.valueOf(stateListSpinner.getSelectedItem()));
                    intent.putExtra("data", "data");
                    startActivity(intent);
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 21;
                        MyApplication.cityname = String.valueOf(cityListSpinner.getSelectedItem());
                        MyApplication.statename =String.valueOf(stateListSpinner.getSelectedItem());
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        Intent intent = new Intent(FuelCityStateActivity.this, MainActivity.class);
                        intent.putExtra("cityname", String.valueOf(cityListSpinner.getSelectedItem()));
                        intent.putExtra("statename", String.valueOf(stateListSpinner.getSelectedItem()));
                        intent.putExtra("data", "data");
                        startActivity(intent);
                    }
                }
                break;
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(FuelCityStateActivity.this, MainActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 20;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(FuelCityStateActivity.this, MainActivity.class));
                finish();
            }
        }
    }
}