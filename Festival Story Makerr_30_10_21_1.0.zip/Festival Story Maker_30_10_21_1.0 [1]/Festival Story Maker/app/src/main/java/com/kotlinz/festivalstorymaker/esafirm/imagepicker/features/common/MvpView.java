package com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.common;

public interface MvpView {
}
