package com.esc.tarotcardreading;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;


public class OptionsActivity extends Activity {
    Activity activity = OptionsActivity.this;
    Typeface face;
    Button onecard;
    Button threecard;
    String type;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.options);
        if (VERSION.SDK_INT >= 21) {
            getWindow().addFlags(Integer.MIN_VALUE);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_1));
        }
        this.face = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        Button button = findViewById(R.id.card1r);
        this.onecard = button;
        button.setTypeface(this.face);
        this.onecard.getBackground().setAlpha(150);
        this.onecard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                OptionsActivity.this.type = "one";
                Intent intent = new Intent(OptionsActivity.this, TaroQuestionsActivity.class);
                intent.putExtra("type", OptionsActivity.this.type);
                OptionsActivity.this.startActivity(intent);
            }
        });
        button = findViewById(R.id.card3r);
        this.threecard = button;
        button.setTypeface(this.face);
        this.threecard.getBackground().setAlpha(150);
        this.threecard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                OptionsActivity.this.type = "three";
                Intent intent = new Intent(OptionsActivity.this, TaroQuestionsActivity.class);
                intent.putExtra("type", OptionsActivity.this.type);
                OptionsActivity.this.startActivity(intent);
            }
        });
        BannerAds();
    }


    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onStart() {
        super.onStart();
    }

    public void onStop() {
        super.onStop();
    }


    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
