package com.Pulse.VideoStatus.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.Pulse.VideoStatus.Adapter.ChangeMessageAdapter;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.application.MyApplication;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unity3d.player.UnityPlayer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;


public class CustomizeTextActivity extends Activity {

    public RecyclerView rvdynamictext;
    Activity activity = CustomizeTextActivity.this;
    ArrayList<String> DynamicTextList = new ArrayList();
    ArrayList<String> DynamicTextJsonList = new ArrayList();
    ChangeMessageAdapter ChangeTextAdapter;
    String JsonResponse;
    ImageView ivInfoMessage;
    AlertDialog alertDialog;
    TextView tvtitle, tvchangemessage;
    ImageView ivBack;
    TextView tvDone;
    InterstitialAd mInterstitialAd;
    private UnifiedNativeAd nativeAd;
//    AdRequest adRequest;
//    AdView adView;

    public String GetJsonArray(ArrayList<String> arrayList) {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < arrayList.size()) {
                jSONArray.put(arrayList.get(i).equals("") ? DynamicTextJsonList.get(i) : arrayList.get(i));
                i++;
            }
            jSONObject.put("data", jSONArray);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FINAL Down Json:");
            stringBuilder.append(jSONObject.toString());
            return jSONObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    public void Init() {
        rvdynamictext = findViewById(R.id.rv_edit_Message);
        ivInfoMessage = findViewById(R.id.iv_message_info);
        ivInfoMessage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Aleartdialog("This messages will appear in video.");
            }
        });
    }
//
//    private void loadAd() {
//        adView = findViewById(R.id.adView);
//        adRequest = new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
//    }

    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.nativead));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unified, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(nativeAd);

    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                GetJsonResponse();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }


    public void Aleartdialog(String str) {
        Builder builder = new Builder(activity);
        builder.setMessage(str);
        builder.setPositiveButton("OK", new AleartDialog(this));
        alertDialog = builder.create();
        alertDialog.show();
        alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent));
    }

    public ArrayList<String> Calender(String str) {
        ArrayList<String> arrayList = new ArrayList();
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                for (int i = 0; i < jSONArray.length(); i++) {
                    arrayList.add(jSONArray.getString(i));
                }
                return arrayList;
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void Calender() {
        EditTextInputResponse();
        ChangeTextAdapter = new ChangeMessageAdapter(DynamicTextList, this);
        GridLayoutManager manager = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        rvdynamictext.setLayoutManager(manager);
        rvdynamictext.setHasFixedSize(true);
        rvdynamictext.setAdapter(ChangeTextAdapter);
    }


    public void GetJsonResponse() {
        String ChangeTextResponse = GetJsonArray(this.DynamicTextList);
        UnityPlayer.UnitySendMessage("GameManager", "ReturnTextResponce", ChangeTextResponse);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FinalJson =");
        stringBuilder.append(ChangeTextResponse);
        finish();
    }

    public void EditTextInputResponse() {
        JsonResponse = getIntent().getStringExtra("JsonStr");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InputJson = ");
        stringBuilder.append(JsonResponse);
        DynamicTextList.addAll(Calender(JsonResponse));
        DynamicTextJsonList.addAll(DynamicTextList);
    }

    //    @Override
//    protected void onDestroy() {
//        adView.removeView(this.adView);
//        AdView adView = this.adView;
//        if (adView != null) {
//            adView.destroy();
//            this.adView = null;
//        }
//        super.onDestroy();
//    }
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_change_text);
        tvtitle = findViewById(R.id.tv_edit_message);
        tvDone = findViewById(R.id.tv_done);
        tvchangemessage = findViewById(R.id.tv_change_message);
        ivBack = findViewById(R.id.ivBack);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CustomizeTextActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
//        loadAd();
        loadNativeAds();
        InterstitialAd();
        Init();
        Calender();
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    GetJsonResponse();
                }
            }
        });
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    class AleartDialog implements DialogInterface.OnClickListener {

        final CustomizeTextActivity context;

        AleartDialog(CustomizeTextActivity customizeTextActivity) {
            context = customizeTextActivity;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            context.alertDialog.dismiss();
        }
    }
}