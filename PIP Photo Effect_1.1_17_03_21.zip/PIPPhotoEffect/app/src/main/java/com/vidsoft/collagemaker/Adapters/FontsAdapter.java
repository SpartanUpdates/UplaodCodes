package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;

import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.vidsoft.Filters.AllStickerSupports.FontProvider;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import java.util.List;

public class FontsAdapter extends Adapter<FontsAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    List<String> fontNames;
    FontProvider fontProvider;
    LayoutInflater inflater;

    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout border;
        TextView textView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.textView = (TextView) itemView.findViewById(R.id.tvView);
            this.border = (RelativeLayout) itemView.findViewById(R.id.rl_border);
        }
    }

    public FontsAdapter(Activity activity, List<String> fontNames, FontProvider fontProvider) {
        this.Selection = BuildConfig.FLAVOR;
        this.inflater = LayoutInflater.from(activity);
        this.fontProvider = fontProvider;
        this.activity = activity;
        this.fontNames = fontNames;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.font_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        if (this.Selection.equals(BuildConfig.FLAVOR)) {
            holder.border.setVisibility(View.GONE);
        } else if (position == Integer.parseInt(this.Selection)) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.GONE);
        }
        holder.textView.setTypeface(this.fontProvider.getTypeface((String) this.fontNames.get(position)));
    }

    public int getItemCount() {
        return this.fontNames.size();
    }

    public void setSelection(int position) {
        this.Selection = String.valueOf(position);
        notifyDataSetChanged();
    }
}