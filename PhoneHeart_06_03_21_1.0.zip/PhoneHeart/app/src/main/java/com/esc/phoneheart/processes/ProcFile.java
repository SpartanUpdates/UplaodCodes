package com.esc.phoneheart.processes;

import android.os.Parcel;
import android.os.Parcelable;

import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ProcFile extends File implements Parcelable {
    public static final Creator<ProcFile> CREATOR = new Creator<ProcFile>() {
        public ProcFile createFromParcel(Parcel parcel) {
            return new ProcFile(parcel);
        }

        public ProcFile[] newArray(int i) {
            return new ProcFile[i];
        }
    };
    public final String content;

    public ProcFile(String str) throws IOException {
        super(str);
        this.content = readFile(str);
    }

    public static String readFile(String str) throws IOException {
        BufferedReader bufferedReader = null;

        StringBuilder sb = new StringBuilder();
        BufferedReader bufferedReader2 = new BufferedReader(new FileReader(str));

        String str2 = "";
        for (String readLine = bufferedReader2.readLine(); readLine != null; readLine = bufferedReader2.readLine()) {
            sb.append(str2);
            sb.append(readLine);
            str2 = IOUtils.LINE_SEPARATOR_UNIX;
        }
        String sb2 = sb.toString();
        try {
            bufferedReader2.close();
        } catch (IOException unused) {
        }
        return sb2;
    }

    public int describeContents() {
        return 0;
    }

    public long length() {
        return (long) this.content.length();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(getAbsolutePath());
        parcel.writeString(this.content);
    }

    public ProcFile(Parcel parcel) {
        super(parcel.readString());
        this.content = parcel.readString();
    }
}
