package com.esc.flashlight.App;

import android.app.Application;

import com.esc.flashlight.OpenAds.AppOpenManager;
import com.esc.flashlight.util.PrefManager;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class APP extends Application {

    AppOpenManager appOpenManager;

    public static volatile APP APP;
    private volatile PrefManager sPref;

    public void onCreate() {
        super.onCreate();
        APP = this;
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
    }

    public static PrefManager getPrefManager() {
        if (APP.sPref == null) {
            APP.sPref = new PrefManager(APP);
        }
        return APP.sPref;
    }
}
