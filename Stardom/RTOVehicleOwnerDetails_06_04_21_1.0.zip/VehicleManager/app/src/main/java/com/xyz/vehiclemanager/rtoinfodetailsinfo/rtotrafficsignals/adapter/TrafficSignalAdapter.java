package com.xyz.vehiclemanager.rtoinfodetailsinfo.rtotrafficsignals.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.rtoinfodetailsinfo.rtotrafficsignals.model.TrafficSignal;

import java.util.ArrayList;

public class TrafficSignalAdapter extends RecyclerView.Adapter<TrafficSignalAdapter.ViewHolder> {
    private Context mcontext;
    private ArrayList<TrafficSignal> trafficSignals;

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView symbolName,symbolDescription;
        ImageView imageUrl;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            symbolName=itemView.findViewById(R.id.symbolName);
            symbolDescription=itemView.findViewById(R.id.symbolDescription);
            imageUrl=itemView.findViewById(R.id.symbolImage);
        }
    }

    public TrafficSignalAdapter(Context context, ArrayList<TrafficSignal> trafficSignallist) {
        this.mcontext = context;
        this.trafficSignals = trafficSignallist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_trafficsignals,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        TrafficSignal trafficSignal = trafficSignals.get(position);
        holder.symbolName.setText(trafficSignal.getName());
        holder.symbolDescription.setText(trafficSignal.getDescription());
        Glide.with(mcontext)
                .load(trafficSignal.getImageUrl())
                .into(holder.imageUrl);
    }
    @Override
    public int getItemCount() {
        return trafficSignals.size();
    }
}
