package com.kotlinz.videoCollage.interfaces;

public interface MyAlbumPhotoAdapterCallBackInterface {
    void itemClick(int i, String str);

    void itemDelete(int i, String str);

    void itemShare(int i, String str);
}
