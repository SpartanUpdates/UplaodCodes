package com.example.lyricsvideo.application;

import android.app.Application;
import android.content.Context;
import android.database.Cursor;
import android.os.Handler;
import android.provider.MediaStore;
import com.danikula.videocache.HttpProxyCacheServer;
import com.example.lyricsvideo.Model.CropImage;
import com.example.lyricsvideo.Model.ImageInfo;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.Utils.kprogresshud.KProgressHUD;
import com.facebook.ads.AdSettings;
import java.util.ArrayList;
import java.util.HashMap;


public class App extends Application {

    public static Context mContext;
    public static String MainFolderName = "Lyrics Video";
    public static int IS_EDITIMAGE;
    public static int TotalSelectedImage;
    public static String APP_SPLIT_PATTERN;
    public static boolean IsFromHomeUnity = false;
    public static KProgressHUD hud;
    public static ArrayList<ImageInfo> selectedImageslist = new ArrayList<>();
    public static int id;
    public static String passingString1;
    public static String passingString2;
    public static int ThemePosition = -1;
    public static int CatSelectedPosition = -1;
    private static App instance;

    static {
        App.IS_EDITIMAGE = 0;
        App.TotalSelectedImage = 5;
        App.APP_SPLIT_PATTERN = "?";

    }

    public final ArrayList<CropImage> cropimaglist;
    public boolean IsNativeAdsLoaded = false;
    public int posForAddMusicDialog;
    public boolean isEditModeEnable;
    public boolean isFromSdCardAudio;
    public HashMap<String, ArrayList<ImageInfo>> AllAlbumList;
    public ArrayList<String> videoImages;
    public ArrayList<String> welcomeImages;
    public int MinimumPosition;
    String SongDirPath;
    private String selectedFolderId;
    private ArrayList<String> AllFolderList;
    private HttpProxyCacheServer proxy;

    public App() {
        this.posForAddMusicDialog = 0;
        this.isEditModeEnable = false;
        this.isFromSdCardAudio = false;
        this.videoImages = new ArrayList<>();
        this.welcomeImages = new ArrayList<>();
        this.selectedImageslist = new ArrayList<>();
        this.cropimaglist = new ArrayList<>();
        this.selectedFolderId = "";
        this.MinimumPosition = Integer.MAX_VALUE;
        this.SongDirPath = "";
    }

    public static App getInstance() {
        return App.instance;
    }

    public static HttpProxyCacheServer getProxy(Context context) {
        App application = (App) context.getApplicationContext();
        return application.proxy == null ? (application.proxy = application.newProxy()) : application.proxy;
    }

    public static void ShowDialog(Context context) {
        hud = KProgressHUD.create(context)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Showing Ads")
                .setDetailsLabel("Please Wait...");
        hud.show();
        scheduleDismiss();
    }

    public static void scheduleDismiss() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
            }
        }, 1000);
    }


    private HttpProxyCacheServer newProxy() {
        return new HttpProxyCacheServer.Builder(this)
                .cacheDirectory(Utils.getVideoCacheDir(this))
                .build();
    }

    public void init() {
        this.getFolderList();
    }

    public void onCreate() {
        super.onCreate();
        App.instance = this;
        App.mContext = this.getApplicationContext();
    }

    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<ImageInfo>> getAllAlbumList() {
        return this.AllAlbumList;
    }

    public ArrayList<ImageInfo> getImageByAlbum(final String folderId) {
        ArrayList<ImageInfo> imageDatas = this.getAllAlbumList().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<ImageInfo>();
        }
        return imageDatas;
    }

    public ArrayList<ImageInfo> getSelectedImageslist() {
        return this.selectedImageslist;
    }

    public void addSelectedImage(final ImageInfo imageData) {
        this.selectedImageslist.add(imageData);
        ++imageData.NoOfImage;
    }

    public void removeSelectedImage(final int imageData) {
        if (imageData <= this.selectedImageslist.size()) {
            final ImageInfo imageData2 = this.selectedImageslist.remove(imageData);
            --imageData2.NoOfImage;
        }
    }

    public void ReplaceSelectedImage(ImageInfo imageData, int pos) {
        this.selectedImageslist.set(pos, imageData);
    }

    public ArrayList<CropImage> getCropImages() {
        return this.cropimaglist;
    }

    public void AddCropImages(CropImage imageData) {
        this.cropimaglist.add(imageData);

    }

    public void ReplaceCropImages(ImageInfo imageData, int pos) {
        this.selectedImageslist.set(pos, imageData);
    }

    public void removecropImage(int imageData) {
        cropimaglist.remove(imageData);

    }

    public void getFolderList() {
        this.AllFolderList = new ArrayList<String>();
        this.AllAlbumList = new HashMap<String, ArrayList<ImageInfo>>();
        String string = null;
        String string2;
        final Cursor query = this.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "_data"}, (String) null, (String[]) null, "_data DESC");
        if (query.moveToFirst()) {
            final int columnIndex = query.getColumnIndex("bucket_display_name");
            final int columnIndex2 = query.getColumnIndex("bucket_id");
            do {
                final ImageInfo imageData = new ImageInfo();
                imageData.ImagePath = query.getString(query.getColumnIndex("_data"));
                imageData.ThumbbailImage = query.getString(query.getColumnIndex("_data"));
                imageData.id = query.getInt(query.getColumnIndex("_id"));
                if (!imageData.ImagePath.endsWith(".gif")) {
                    string = query.getString(columnIndex);
                    string2 = query.getString(columnIndex2);
                    if (!this.AllFolderList.contains(string)) {
                        this.AllFolderList.add(string);

                    }
                    ArrayList<ImageInfo> list;
                    if ((list = this.AllAlbumList.get(string)) == null) {
                        list = new ArrayList<ImageInfo>();
                    }
                    imageData.folderName = string;
                    list.add(imageData);
                    this.AllAlbumList.put(string, list);
                }
            } while (query.moveToNext());
        }
    }

    public void clearAllSelection() {
        this.videoImages.clear();
        this.AllAlbumList = null;
        this.getSelectedImageslist().clear();
        System.gc();
        this.getFolderList();
    }

    public void Allclear() {
        getSelectedImageslist().clear();
        getCropImages().clear();
    }
}
