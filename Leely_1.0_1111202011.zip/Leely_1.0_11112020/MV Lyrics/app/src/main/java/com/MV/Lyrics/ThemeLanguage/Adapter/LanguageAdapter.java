package com.MV.Lyrics.ThemeLanguage.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.MV.Lyrics.R;
import com.MV.Lyrics.ThemeLanguage.Model.LanguageModel;
import java.util.ArrayList;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.VideoHolder> {

    Context context;
    private ArrayList<LanguageModel> languageList;

    public LanguageAdapter(Context context, ArrayList<LanguageModel> languageList) {
        this.context = context;
        this.languageList = languageList;
    }

    @NonNull
    @Override
    public VideoHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_language_item, viewGroup, false);
        return new VideoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final VideoHolder videoHolder, int position) {
        final LanguageModel languageModel = languageList.get(position);
        videoHolder.tvlangName.setText(languageModel.getLanName());
        videoHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoHolder.cblanguage.toggle();
            }
        });
        videoHolder.cblanguage.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                languageModel.isLanguage = isChecked;
            }
        });
        videoHolder.cblanguage.setChecked(languageModel.isLanguage);
    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }


    public class VideoHolder extends RecyclerView.ViewHolder {
        CheckBox cblanguage;
        TextView tvlangName;

        private VideoHolder(@NonNull View itemView) {
            super(itemView);
            cblanguage = itemView.findViewById(R.id.cbLanguage);
            tvlangName = itemView.findViewById(R.id.tvName);
        }
    }
}
