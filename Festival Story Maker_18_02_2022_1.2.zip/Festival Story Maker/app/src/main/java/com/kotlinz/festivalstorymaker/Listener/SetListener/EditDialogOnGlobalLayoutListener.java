package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.view.ViewTreeObserver;

import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class EditDialogOnGlobalLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener
{
    public final  View view;
    public final CanvasEditorActivity activity;

    public EditDialogOnGlobalLayoutListener(final CanvasEditorActivity f, final View e) {
        this.activity = f;
        this.view = e;
    }

    public void onGlobalLayout() {
        this.view.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
        final int size = this.activity.j0.size();
        final int h0 = activity.H0;
        if (size > h0) {
            this.view.setX((float)activity.j0.get(h0));
            final View e = this.view;
            final float floatValue = activity.k0.get(activity.H0);
            e.setY(activity.l0.get(activity.H0) + floatValue - this.view.getHeight());
        }
    }
}
