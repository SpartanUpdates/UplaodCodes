package com.xyz.vehiclemanager.car.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CarDetailsRoot
{
    @SerializedName("statusCode")
    public int statusCode;
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("details")
    public Details details;

    public class Details
    {
        @SerializedName("id")
        public String id;
        @SerializedName("brandId")
        public String brandId;
        @SerializedName("brandName")
        public String brandName;
        @SerializedName("carModelName")
        public String carModelName;
        @SerializedName("carModelSlug")
        public String carModelSlug;
        @SerializedName("exShowroomPrice")
        public String exShowroomPrice;
        @SerializedName("imageUrl")
        public String imageUrl;
        @SerializedName("colors")
        public ArrayList<Color> colors;
        @SerializedName("variants")
        public ArrayList<Variant> variants;
        @SerializedName("isDiscontinued")
        public String isDiscontinued;
        @SerializedName("isBS6Compliant")
        public String isBS6Compliant;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getBrandId() {
            return brandId;
        }

        public void setBrandId(String brandId) {
            this.brandId = brandId;
        }

        public String getBrandName() {
            return brandName;
        }

        public void setBrandName(String brandName) {
            this.brandName = brandName;
        }

        public String getCarModelName() {
            return carModelName;
        }

        public void setCarModelName(String carModelName) {
            this.carModelName = carModelName;
        }

        public String getCarModelSlug() {
            return carModelSlug;
        }

        public void setCarModelSlug(String carModelSlug) {
            this.carModelSlug = carModelSlug;
        }

        public String getExShowroomPrice() {
            return exShowroomPrice;
        }

        public void setExShowroomPrice(String exShowroomPrice) {
            this.exShowroomPrice = exShowroomPrice;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public ArrayList<Color> getColors() {
            return colors;
        }

        public void setColors(ArrayList<Color> colors) {
            this.colors = colors;
        }

        public ArrayList<Variant> getVariants() {
            return variants;
        }

        public void setVariants(ArrayList<Variant> variants) {
            this.variants = variants;
        }

        public String getIsDiscontinued() {
            return isDiscontinued;
        }

        public void setIsDiscontinued(String isDiscontinued) {
            this.isDiscontinued = isDiscontinued;
        }

        public String getIsBS6Compliant() {
            return isBS6Compliant;
        }

        public void setIsBS6Compliant(String isBS6Compliant) {
            this.isBS6Compliant = isBS6Compliant;
        }

        public class Color
        {
            @SerializedName("id")
            public int id;
            @SerializedName("colorName")
            public String colorName;
            @SerializedName("backgroundName")
            public String backgroundName;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getColorName() {
                return colorName;
            }

            public void setColorName(String colorName) {
                this.colorName = colorName;
            }

            public String getBackgroundName() {
                return backgroundName;
            }

            public void setBackgroundName(String backgroundName) {
                this.backgroundName = backgroundName;
            }
        }

        public class Variant {
            @SerializedName("id")
            public int id;
            @SerializedName("variantName")
            public String variantName;
            @SerializedName("variantSlug")
            public String variantSlug;
            @SerializedName("transmissionType")
            public String transmissionType;
            @SerializedName("fuelType")
            public String fuelType;
            @SerializedName("engineDisplacement")
            public String engineDisplacement;
            @SerializedName("mileage")
            public String mileage;
            @SerializedName("variantPrice")
            public String variantPrice;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getVariantName() {
                return variantName;
            }

            public void setVariantName(String variantName) {
                this.variantName = variantName;
            }

            public String getVariantSlug() {
                return variantSlug;
            }

            public void setVariantSlug(String variantSlug) {
                this.variantSlug = variantSlug;
            }

            public String getTransmissionType() {
                return transmissionType;
            }

            public void setTransmissionType(String transmissionType) {
                this.transmissionType = transmissionType;
            }

            public String getFuelType() {
                return fuelType;
            }

            public void setFuelType(String fuelType) {
                this.fuelType = fuelType;
            }

            public String getEngineDisplacement() {
                return engineDisplacement;
            }

            public void setEngineDisplacement(String engineDisplacement) {
                this.engineDisplacement = engineDisplacement;
            }

            public String getMileage() {
                return mileage;
            }

            public void setMileage(String mileage) {
                this.mileage = mileage;
            }

            public String getVariantPrice() {
                return variantPrice;
            }

            public void setVariantPrice(String variantPrice) {
                this.variantPrice = variantPrice;
            }
        }
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }
}
