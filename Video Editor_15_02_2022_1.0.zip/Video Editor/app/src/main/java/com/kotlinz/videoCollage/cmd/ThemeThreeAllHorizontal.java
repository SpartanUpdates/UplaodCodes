package com.kotlinz.videoCollage.cmd;

import android.util.Log;

import java.util.ArrayList;

public class ThemeThreeAllHorizontal {
    public static StringBuilder getOrderString(boolean z, ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2) {
        StringBuilder stringBuilder = new StringBuilder();
        if (z) {
            stringBuilder.append("[scale0][scale1][scale2] hstack=inputs=3 [vidCombine];");
        } else if (arrayList2.size() == 3) {
            stringBuilder.append("[scale1]split[scale1_1][scale1_2]; [scale3]split[scale3_1][scale3_2]; [scale5]split[scale5_1][scale5_2]; [scale0][scale3_1][scale5_1] hstack=inputs=3 [imgVidCombine1]; [scale1_1][scale2][scale5_2] hstack=inputs=3 [imgVidCombine2]; [scale1_2][scale3_2][scale4] hstack=inputs=3 [imgVidCombine3]; [imgVidCombine1][imgVidCombine2][imgVidCombine3] concat=n=3 [vidCombine];");
        } else {
            int i = 0;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("stackCount.get(i) :: ");
                stringBuilder2.append(arrayList.get(i2));
                String str = "save";
                Log.e(str, stringBuilder2.toString());
                if (!arrayList2.contains(arrayList.get(i2))) {
                    i = ((Integer) arrayList.get(i2)).intValue();
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("IMAGE stackCount.get(i) :: ");
                    stringBuilder2.append(arrayList.get(i2));
                    Log.e(str, stringBuilder2.toString());
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("imagePos :: ");
                    stringBuilder2.append(i);
                    Log.e(str, stringBuilder2.toString());
                }
            }
            if (i == 0) {
                stringBuilder.append("[scale1][scale4] hstack=inputs=2 [imgVidCombine1]; [scale2][scale3] hstack=inputs=2 [imgVidCombine2]; [imgVidCombine1][imgVidCombine2] concat=n=2 [imgVidCombine3];[scale0][imgVidCombine3] hstack=inputs=2 [vidCombine];");
            } else if (i == 2) {
                stringBuilder.append("[scale2]split[scale2_1][scale2_2]; [scale0][scale2_1][scale4] hstack=inputs=3 [imgVidCombine1]; [scale1][scale2_2][scale3] hstack=inputs=3 [imgVidCombine2]; [imgVidCombine1][imgVidCombine2] concat=n=2 [vidCombine];");
            } else {
                stringBuilder.append("[scale0][scale3] hstack=inputs=2 [imgVidCombine1]; [scale1][scale2] hstack=inputs=2 [imgVidCombine2]; [imgVidCombine1][imgVidCombine2] concat=n=2 [imgVidCombine3]; [imgVidCombine3][scale4] hstack=inputs=2 [vidCombine];");
            }
        }
        return stringBuilder;
    }
}
