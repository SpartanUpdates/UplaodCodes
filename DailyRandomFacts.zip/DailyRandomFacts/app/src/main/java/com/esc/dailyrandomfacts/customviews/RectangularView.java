package com.esc.dailyrandomfacts.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class RectangularView extends RelativeLayout {
    public RectangularView(Context context) {
        super(context);
    }

    public RectangularView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public RectangularView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = getMeasuredWidth();
        setMeasuredDimension(i, i);
    }
}
