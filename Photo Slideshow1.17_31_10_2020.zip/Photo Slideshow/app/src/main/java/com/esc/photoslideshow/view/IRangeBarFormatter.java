package com.esc.photoslideshow.view;

public interface IRangeBarFormatter {
    String format(String str);
}
