package com.UnitedVideos.CropImage.photoview;

import android.graphics.Rect;

public abstract interface IGetImageBounds {
    public abstract Rect getImageBounds();
}
