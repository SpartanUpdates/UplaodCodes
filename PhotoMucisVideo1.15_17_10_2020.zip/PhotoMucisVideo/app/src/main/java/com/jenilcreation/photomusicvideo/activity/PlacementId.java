package com.jenilcreation.photomusicvideo.activity;

public interface PlacementId {
    long YOUR_PLACEMENT_ID = 1553215100293L;
}
