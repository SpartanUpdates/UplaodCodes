package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.Model.Grid3D;
import com.vidsoft.collagemaker.pipphotoeffect.R;

import java.util.ArrayList;

public class Grid3DAdapter extends Adapter<Grid3DAdapter.ViewHolder> {
    int Selection;
    Activity activity;
    Grid3DCallback grid3DCallback;
    ArrayList<Grid3D> list;


    public interface Grid3DCallback {
        void Grid3DMethod(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView border;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
            this.border = (ImageView) itemView.findViewById(R.id.rl_border);
        }
    }

    public Grid3DAdapter(Activity activity, ArrayList<Grid3D> list, int currentGrid) {
        this.Selection = 0;
        this.list = list;
        this.activity = activity;
        this.Selection = currentGrid;
        this.grid3DCallback = (Grid3DCallback) activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.grid3d_adapter_, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, final int position) {
        if (this.Selection == position) {
            holder.border.setVisibility(View.VISIBLE);
        } else {
            holder.border.setVisibility(View.GONE);
        }
        Glide.with(this.activity).load(Integer.valueOf(((Grid3D) this.list.get(position)).getThumb())).into(holder.imageView);
        holder.imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Grid3DAdapter.this.Selection = position;
                Grid3DAdapter.this.notifyDataSetChanged();
                Grid3DAdapter.this.grid3DCallback.Grid3DMethod(position);

            }
        });
    }

    public int getItemCount() {
        return this.list.size();
    }
}