package com.videolib.libffmpeg;

public class LoadBinaryResponseHandler implements FFmpegLoadBinaryResponseHandler {
    public void onFailure() {
    }

    public void onFailure(String str) {
    }

    public void onFinish() {
    }

    public void onStart() {
    }

    public void onSuccess() {
    }

    public void onSuccess(String str) {
    }
}
