package com.kotlinz.videoCollage.other;

import android.media.ExifInterface;
import android.text.TextUtils;

import com.kotlinz.videoCollage.scal.SubSamplingScaleImageView;

public class ExifUtils {
    private ExifUtils() {
    }

    public static int getExifRotation(String str) {
        try {
            str = new ExifInterface(str).getAttribute(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION);
            if (TextUtils.isEmpty(str)) {
                return 0;
            }
            int parseInt = Integer.parseInt(str);
            if (parseInt == 3) {
                return SubSamplingScaleImageView.ORIENTATION_180;
            }
            if (parseInt == 6) {
                return 90;
            }
            if (parseInt != 8) {
                return 0;
            }
            return SubSamplingScaleImageView.ORIENTATION_270;
        } catch (Exception unused) {
            return 0;
        }
    }
}
