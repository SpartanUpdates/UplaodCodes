package com.example.knowledgetrivia.manager;


import android.content.Context;

import com.example.knowledgetrivia.models.Level;
import com.example.knowledgetrivia.models.Question;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;



public class QuestionManager {
    private static QuestionManager questionManager;
    private HashMap<Integer, Level> map = new HashMap<>();
    private HashMap<Integer, Question> questionsMap = new HashMap<>();

    private QuestionManager(Context context) {
        Level level;
        try {
            InputStream open = context.getAssets().open("questions.txt");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(open, Charset.forName("UTF-8")));
            bufferedReader.readLine();
            Level level2 = null;
            int i = -1;
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                String[] split = readLine.split(",");
                if (split.length == 8) {
                    int parseInt = Integer.parseInt(split[0]);
                    int parseInt2 = Integer.parseInt(split[1]);
                    String str = split[2];
                    String str2 = split[3];
                    String str3 = split[4];
                    String str4 = split[5];
                    String str5 = split[6];
                    int parseInt3 = Integer.parseInt(split[7]);
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(str2);
                    arrayList.add(str3);
                    arrayList.add(str4);
                    arrayList.add(str5);
                    Question question = new Question(parseInt, str, arrayList, parseInt3);
                    this.questionsMap.put(Integer.valueOf(question.getId()), question);
                    if (i != parseInt2) {
                        if (i == -1) {
                            level = new Level(parseInt2);
                        } else {
                            this.map.put(Integer.valueOf(i), level2);
                            level = new Level(parseInt2);
                        }
                        level.addQuestion(question);
                        level2 = level;
                        i = parseInt2;
                    } else if (level2 != null) {
                        level2.addQuestion(question);
                    }
                }
            }
            this.map.put(Integer.valueOf(i), level2);
            bufferedReader.close();
            if (open != null) {
                open.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static QuestionManager getInstance(Context context) {
        if (questionManager == null) {
            questionManager = new QuestionManager(context);
        }
        return questionManager;
    }

    public Level getLevel(int i) {
        return this.map.get(Integer.valueOf(i));
    }

    public ArrayList<String> getLevelString() {
        ArrayList<String> arrayList = new ArrayList<>();
        Integer[] numArr = (Integer[]) new ArrayList(this.map.keySet()).toArray(new Integer[0]);
        Arrays.sort(numArr);
        for (Integer num : numArr) {
            arrayList.add("Level " + num);
        }
        return arrayList;
    }

    public boolean isExist(int i) {
        return this.map.containsKey(Integer.valueOf(i));
    }

    public Question getQuestionById(int i) {
        return this.questionsMap.get(Integer.valueOf(i));
    }

    public ArrayList<Question> getTenRandomQuestion() {
        ArrayList<Question> arrayList = new ArrayList<>();
        ArrayList arrayList2 = new ArrayList();
        Random random = new Random();
        while (arrayList.size() != 10) {
            int nextInt = random.nextInt(this.questionsMap.size()) + 1;
            if (!arrayList2.contains(Integer.valueOf(nextInt))) {
                arrayList2.add(Integer.valueOf(nextInt));
                arrayList.add(this.questionsMap.get(Integer.valueOf(nextInt)));
            }
        }
        return arrayList;
    }
}
