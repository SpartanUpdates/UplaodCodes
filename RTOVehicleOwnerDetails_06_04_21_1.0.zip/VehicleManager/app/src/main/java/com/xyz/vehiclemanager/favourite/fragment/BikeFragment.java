package com.xyz.vehiclemanager.favourite.fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.favourite.Room.FavoriteDatabase;
import com.xyz.vehiclemanager.favourite.adapter.FavouriteBikeAdapter;
import com.xyz.vehiclemanager.favourite.model.FavoriteBikeModel;
import java.util.List;

public class BikeFragment extends Fragment
{
    private View view;
    private RecyclerView rv_favourite;
    private FavouriteBikeAdapter favouriteBikeAdapter;
    private LinearLayout ll_favourite, ll_car_bikefavourite;

    public BikeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        view =  inflater.inflate(R.layout.fragment_favourite, container, false);
        rv_favourite = view.findViewById(R.id.rv_favourite);
        ll_favourite = view.findViewById(R.id.ll_favourite);
        ll_car_bikefavourite = view.findViewById(R.id.ll_car_bikefavourite);
        getFavoriteBikeData();
        return view;
    }

    private void getFavoriteBikeData()
    {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        List<FavoriteBikeModel> favoriteBikeModelList = FavoriteDatabase.getFavoriteDatabase(getActivity()).favoriteBikeDao().getFavoriteBikeList();
                        if(favoriteBikeModelList.size()!= 0)
                        {
                            ll_car_bikefavourite.setVisibility(View.VISIBLE);
                            ll_favourite.setVisibility(View.GONE);
                            favouriteBikeAdapter = new FavouriteBikeAdapter(getActivity(), favoriteBikeModelList);
                            rv_favourite.setAdapter(favouriteBikeAdapter);
                            rv_favourite.setLayoutManager(new LinearLayoutManager(getActivity()));
                            rv_favourite.setHasFixedSize(true);
                        }
                    }
                });
            }
        });thread.start();
    }
}