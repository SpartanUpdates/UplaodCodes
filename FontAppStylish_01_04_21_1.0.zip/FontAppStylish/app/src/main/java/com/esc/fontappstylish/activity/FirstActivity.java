package com.esc.fontappstylish.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import com.esc.fontappstylish.kprogresshud.KProgressHUD;
import com.esc.fontappstylish.pref.EPreferences;
import com.esc.fontappstylish.utils.FontSet;
import com.esc.fontappstylish.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

public class FirstActivity extends AppCompatActivity implements OnClickListener {
    public static Activity activity;
    private Context context;
    private List<InputMethodInfo> list;
    private EPreferences ePreferences;
    private Switch setting_switch;
    private boolean overlayIsChecked;
    private ImageView iv_enablekeyboard;
    private ImageView iv_changeimage;
    private ImageView iv_updatekeyboard;
    private ImageView iv_setting;
    private SharedPreferences prefs;
    private Switch switch_sound;
    private ImageView iv_scroll;
    private ImageView iv_menuOption;
    private SharedPreferences.Editor edit;
    private SeekBar soundVolume;
    private UnifiedNativeAd nativeAd;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    public final Handler mGetBackHereHandler = new Handler() {
        public void handleMessage(Message message) {
            int i = message.what;
            if (i == 446) {
                Intent intent = FirstActivity.this.reLaunchTaskIntent;
            } else if (i == 447) {
                FirstActivity.this.unregisterSettingsObserverNow();
            } else {
                super.handleMessage(message);
            }
        }
    };

    private int mState;
    String packageLocal;
    public Intent reLaunchTaskIntent;
    private final ContentObserver secureSettingsChanged = new ContentObserver(null) {
        public boolean deliverSelfNotifications() {
            return false;
        }

        public void onChange(boolean z) {
            FirstActivity firstActivity = FirstActivity.this;
            if (firstActivity.isKeyboardEnabled(firstActivity.getApplicationContext())) {
                FirstActivity.this.mGetBackHereHandler.removeMessages(446);
                FirstActivity.this.mGetBackHereHandler.sendMessageDelayed(FirstActivity.this.mGetBackHereHandler.obtainMessage(446), 50);
            }
        }
    };

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_first);
        context = this;
        mState = 0;
        ePreferences = EPreferences.getInstance(this);
        overlayIsChecked = EPreferences.IsOverlayTimeAllow(getApplicationContext());

        packageLocal = getApplicationContext().getPackageName();
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager = inputMethodManager;
        list = inputMethodManager.getEnabledInputMethodList();
        Intent intent = new Intent(getBaseContext(), FirstActivity.class);
        reLaunchTaskIntent = intent;
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        intent = reLaunchTaskIntent;
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isThisKeyboardEnabled ");
        stringBuilder.append(FontSet.INSTANCE.isThisKeyboardEnabled(this));
        String str = "test";
        stringBuilder = new StringBuilder();
        stringBuilder.append("isThisKeyboardSetAsDefaultIME ");
        stringBuilder.append(FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(this));
        setupButtons();

        BindView();
        loadAd();

        if (isInputEnabled()) {
            overlayIsChecked = EPreferences.IsOverlayTimeAllow(getApplicationContext());
            setting_switch.setChecked(true);
        }
    }

    private void BindView() {
        setting_switch = findViewById(R.id.setting_switch);
        iv_enablekeyboard = findViewById(R.id.iv_enablekeyboard);
        iv_changeimage = findViewById(R.id.iv_changeimage);
        iv_updatekeyboard = findViewById(R.id.iv_updatekeyboard);
        iv_setting = findViewById(R.id.iv_setting);
        iv_menuOption = findViewById(R.id.iv_menuOption);

        iv_enablekeyboard.setOnClickListener(this);
        iv_changeimage.setOnClickListener(this);
        iv_updatekeyboard.setOnClickListener(this);
        iv_setting.setOnClickListener(this);
        iv_menuOption.setOnClickListener(this);

        setting_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean issetting) {
                if (issetting) {
                    overlayIsChecked = true;
                    EPreferences.setOverlayTimeAllow(getApplicationContext(), true);
                    setting_switch.setChecked(true);
                    overlayIsChecked = EPreferences.IsOverlayTimeAllow(getApplicationContext());
                    if (overlayIsChecked) {
                        setting_switch.setChecked(true);
                    } else {
                        setting_switch.setChecked(false);
                    }
                    if (!FirstActivity.this.isInputEnabled()) {
                        FirstActivity.this.enableKeyboard();
                    }
                } else {
                    overlayIsChecked = false;
                    EPreferences.setOverlayTimeAllow(getApplicationContext(), false);
                    setting_switch.setChecked(false);
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.iv_enablekeyboard:
                iv_enablekeyboard.startAnimation(AnimationUtils.loadAnimation(FirstActivity.this, R.anim.viewpush));
                if (FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(FirstActivity.this.context)) {
                    BackScreen();
                } else {
                    openKeyboardChooser();
                }
                break;

            case R.id.iv_changeimage:

                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    startActivity(new Intent(FirstActivity.this, ChangeImageActivity.class));
                    finish();
                }
                break;
            case R.id.iv_updatekeyboard:
                startActivity(new Intent(FirstActivity.this, UpdateActivity.class));
                finish();
                break;

            case R.id.iv_setting:
                SettingDialog();
                break;

            case R.id.iv_menuOption:
                PopupMenu popup = new PopupMenu(FirstActivity.this, iv_menuOption);
                popup.getMenuInflater().inflate(R.menu.option_menu, popup.getMenu());

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item)
                    {
                        switch (item.getItemId())
                        {
                            case R.id.share:
                                Intent intent = new Intent(Intent.ACTION_SEND);
                                intent.setType("text/plain");
                                intent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.share_msg) + getPackageName());
                                startActivity(Intent.createChooser(intent, "Share Via"));
                                break;

                            case R.id.rate:
                                try
                                {
                                    startActivity(new Intent(
                                            "android.intent.action.VIEW",
                                            Uri.parse(getResources().getString(R.string.rate_us)
                                                    + getPackageName())));
                                } catch (ActivityNotFoundException e) {
                                    Toast.makeText(FirstActivity.this, "You don't have Google Play Store installed",
                                            Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case R.id.privacy:
                                try {
                                    Intent intent1 = new Intent(Intent.ACTION_VIEW);
                                    intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy)));
                                    startActivity(intent1);
                                }catch (ActivityNotFoundException e)
                                {
                                    Toast.makeText(FirstActivity.this, "You don't have Google installed",
                                            Toast.LENGTH_SHORT).show();
                                }
                                break;
                        }

                        return true;
                    }
                });

                popup.show();
            break;
        }
    }

    private void SettingDialog() {
        final BottomSheetDialog dialog = new BottomSheetDialog(this,R.style.DialogStyleLight);
        dialog.setContentView(R.layout.setting_dialog);
        dialog.setCanceledOnTouchOutside(true);

        switch_sound = dialog.findViewById(R.id.switch_sound);
        soundVolume = dialog.findViewById(R.id.seekBar1);
        iv_scroll = dialog.findViewById(R.id.iv_scroll);

        SharedPreferences sharedPreferences = getSharedPreferences(Utils.THEME_PREFS, 0);
        this.prefs = sharedPreferences;
        this.edit = sharedPreferences.edit();

        if (Utils.isSoundOn) {
            switch_sound.setChecked(true);
        } else {
            switch_sound.setChecked(true);
        }

        dialog.getWindow().setLayout(-1, -2);

        switch_sound.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean sound) {
                edit.putBoolean("soundEnable", sound);
                edit.commit();
                Utils.isSoundOn = sound;
            }
        });

        this.soundVolume.setMax(100);
        this.soundVolume.setProgress(Utils.progress);
        soundVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                Utils.progress = soundVolume.getProgress();
                float f = ((float) Utils.progress) / 100.0f;
                Utils.mFxVolume = f;
                edit.putInt(NotificationCompat.CATEGORY_PROGRESS, Utils.progress);
                edit.putFloat("soundLevel", f);
                edit.commit();
            }
        });

        iv_scroll.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void loadAd() {

        interstitial = new InterstitialAd(FirstActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        startActivity(new Intent(FirstActivity.this, ChangeImageActivity.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(FirstActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                   finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(FirstActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setLayout(-1, -2);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void onResume() {
        super.onResume();
        if (isInputEnabled()) {
            setting_switch.setChecked(true);
        }
    }

    public void onStart() {
        super.onStart();
        Handler handler = this.mGetBackHereHandler;
        getClass();
        handler.removeMessages(446);
        unregisterSettingsObserverNow();
    }

    public boolean isInputEnabled() {
        List enabledInputMethodList = ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).getEnabledInputMethodList();
        int size = enabledInputMethodList.size();
        boolean z = false;
        for (int i = 0; i < size; i++) {
            InputMethodInfo inputMethodInfo = (InputMethodInfo) enabledInputMethodList.get(i);
            if (inputMethodInfo.getId().contains(getPackageName())) {
                z = true;
            }
        }
        return z;
    }

    public final void setupButtons() {
        if (this.mState == 2) {
            this.mState = 0;
            if (FontSet.INSTANCE.isThisKeyboardSetAsDefaultIME(this)) {
                Intent intent = new Intent(this, FontKeyboardTestingActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        }
    }

    public final void unregisterSettingsObserverNow() {
        Handler handler = this.mGetBackHereHandler;
        getClass();
        handler.removeMessages(447);
        getApplicationContext().getContentResolver().unregisterContentObserver(this.secureSettingsChanged);
    }

    public void openKeyboardChooser() {
        Object systemService = getSystemService(INPUT_METHOD_SERVICE);
        if (systemService != null) {
            this.mState = 1;
            ((InputMethodManager) systemService).showInputMethodPicker();
        }
    }

    public final void enableKeyboard() {
        getApplicationContext().getContentResolver().registerContentObserver(Secure.CONTENT_URI, true, this.secureSettingsChanged);
        Handler handler = this.mGetBackHereHandler;
        getClass();
        handler.removeMessages(447);
        handler = this.mGetBackHereHandler;
        getClass();
        handler.sendMessageDelayed(handler.obtainMessage(447), 45000);
        Intent intent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, R.string.setup_wizard_step_one_action_error_no_settings_activity, Toast.LENGTH_LONG).show();
        }
    }

    public final boolean isKeyboardEnabled(Context context) {
        return FontSet.INSTANCE.isThisKeyboardEnabled(context);
    }

    public void BackScreen() {
        Intent intent = new Intent(this, FontKeyboardTestingActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}
