package com.esc.palmreadingfuture.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.esc.palmreadingfuture.R;
import com.esc.palmreadingfuture.database.DataBaseHelper;
import com.esc.palmreadingfuture.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class ShowTypesOfLines extends AppCompatActivity {
    private Activity activity = ShowTypesOfLines.this;
    private static Editor editor = null;
    public static String trans;
    private DataBaseHelper baseHelper;
    private int cid;
    private Context context;
    private TextView txt_description;
    private TextView ftv;
    private ArrayList<String> handtitles;
    private int id = 0;
    private ImageView imageView;
    private int lblcnt = 0;
    private float left;
    private String line;
    private String line_eng;
    private Integer[] mImageIds;
    private float[] ml;
    private float[] mt;
    private RelativeLayout myrel;
    private Button btn_next;
    private ViewPager pager;
    private int pos;
    private Button btn_previous;
    private int resid;
    private View rowView;
    private int scid;
    private TextView txt_title;
    private ImageView iv_back;
    private float top;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    public class ViewPageAdapter extends PagerAdapter {
        TextView handtitletxt;

        ViewPageAdapter(Context context) {
            ShowTypesOfLines.this.context = context;
        }

        public int getCount() {
            return ShowTypesOfLines.this.mImageIds.length;
        }

        public boolean isViewFromObject(View view, Object obj) {
            return view == ((View) obj);
        }

        public Object instantiateItem(ViewGroup viewGroup, int i) {
            ViewGroup viewGroup2 = viewGroup;
            int i2 = i;
            pos = i2;
            LayoutInflater layoutInflater = getLayoutInflater();
            rowView = layoutInflater.inflate(R.layout.viewpage_item, viewGroup2, false);
            myrel = (RelativeLayout) rowView.findViewById(R.id.myrel);
            imageView = (ImageView) rowView.findViewById(R.id.gallery);
            handtitletxt = (TextView) rowView.findViewById(R.id.handtitle);
            ftv = (TextView) rowView.findViewById(R.id.ftv);
            if (imageView == null) {
            }
            imageView.setImageResource(mImageIds[i2].intValue());
            imageView.setTag(ShowTypesOfLines.this.mImageIds[i2]);
            String str = "";
            if (handtitles.get(i2) != null) {
                try {
                    if (this.handtitletxt == null) {
                        this.handtitletxt.setText(str);
                    } else {
                        TextView textView = this.handtitletxt;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append((String) ShowTypesOfLines.this.handtitles.get(i2));
                        textView.setText(stringBuilder.toString());
                    }
                } catch (NullPointerException unused) {
                    this.handtitletxt.setText(str);
                }
            } else {
                this.handtitletxt.setText(str);
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("position is ");
            stringBuilder2.append(i2);
            LayoutParams layoutParams = new LayoutParams(-2, -2);
            ftv.setGravity(1);
            ftv.setVisibility(View.VISIBLE);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            float f = (float) displayMetrics.widthPixels;
            TextView textView2;
            if (line.equals(getResources().getString(R.string.fatelinereading)) && pos == 0) {
                if ((getResources().getConfiguration().screenLayout & 15) == 1) {
                    ftv.setTextSize(10.0f);
                    top = 50.0f;
                    left = 0.703125f * f;
                    ftv.setMaxWidth(Math.round(100.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 2) {
                    ftv.setTextSize(11.0f);
                    top = 100.0f;
                    left = f * 0.625f;
                    ftv.setMaxWidth(Math.round(150.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 3) {
                    ftv.setTextSize(16.0f);
                    left = f * 0.625f;
                    top = 200.0f;
                    ftv.setMaxWidth(Math.round(200.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 4) {
                    ftv.setTextSize(20.0f);
                    left = f * 0.625f;
                    top = 250.0f;
                    ftv.setMaxWidth(Math.round(250.0f));
                }
                layoutParams.setMargins(Math.round(ShowTypesOfLines.this.left), Math.round(top), 0, 0);
                ftv.setLayoutParams(layoutParams);
                textView2 = ShowTypesOfLines.this.ftv;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(ShowTypesOfLines.this.getResources().getString(R.string.fate1));
                textView2.setText(stringBuilder2.toString());
            } else if (line.equals(getResources().getString(R.string.successlinereading)) && pos == 0) {
                if ((getResources().getConfiguration().screenLayout & 15) == 1) {
                    ftv.setTextSize(10.0f);
                    top = 0.0f;
                    left = 10.0f;
                    ftv.setMaxWidth(Math.round(70.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 2) {
                    ftv.setTextSize(11.0f);
                    left = 10.0f;
                    top = 220.0f;
                    ftv.setMaxWidth(Math.round(150.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 3) {
                    ftv.setTextSize(16.0f);
                    left = 50.0f;
                    top = 450.0f;
                    ftv.setMaxWidth(Math.round(200.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 4) {
                    ftv.setTextSize(20.0f);
                    left = 100.0f;
                    top = 450.0f;
                    ftv.setMaxWidth(Math.round(250.0f));
                }
                layoutParams.setMargins(Math.round(ShowTypesOfLines.this.left), Math.round(top), 0, 0);
                ftv.setLayoutParams(layoutParams);
                textView2 = ShowTypesOfLines.this.ftv;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                textView2.setText(stringBuilder2.toString());
            } else if (line.equals(ShowTypesOfLines.this.getResources().getString(R.string.travellinereading)) && pos == 0) {
                if ((getResources().getConfiguration().screenLayout & 15) == 1) {
                    ftv.setTextSize(10.0f);
                    left = 0.46875f * f;
                    top = 0.0f;
                    ftv.setMaxWidth(Math.round(70.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 2) {
                    ftv.setTextSize(11.0f);
                    left = f * 0.625f;
                    top = 100.0f;
                    ftv.setMaxWidth(Math.round(150.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 3) {
                    ftv.setTextSize(16.0f);
                    left = f * 0.625f;
                    top = 100.0f;
                    ftv.setMaxWidth(Math.round(200.0f));
                }
                if ((getResources().getConfiguration().screenLayout & 15) == 4) {
                    ftv.setTextSize(20.0f);
                    left = f * 0.625f;
                    top = 100.0f;
                    ftv.setMaxWidth(Math.round(250.0f));
                }
                layoutParams.setMargins(Math.round(ShowTypesOfLines.this.left), Math.round(top), 0, 0);
                ftv.setLayoutParams(layoutParams);
                textView2 = ShowTypesOfLines.this.ftv;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                textView2.setText(stringBuilder2.toString());
            }
            myrel.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    if (VERSION.SDK_INT >= 16) {
                        myrel.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    } else {
                        myrel.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    }
                    if (!RemoveTextViews()) {
                        return;
                    }
                    if (line.equals(ShowTypesOfLines.this.getResources().getString(R.string.fatelinereading))) {
                        if (pos == 0) {
                            setLabel(90.0f, 30.0f, ShowTypesOfLines.this.getResources().getString(R.string.fate1));
                            lblcnt = 1;
                        } else if (pos == 1) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.heartlabel));
                            lblcnt = 1;
                        } else if (pos == 2) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.headlabel1));
                            lblcnt = 1;
                        } else if (pos == 6) {
                            setLabel(10.0f, 50.0f, ShowTypesOfLines.this.getResources().getString(R.string.fate2));
                            lblcnt = 1;
                        } else if (pos == 7) {
                            setLabel(90.0f, 30.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            lblcnt = 1;
                        } else {
                            ftv.setVisibility(View.INVISIBLE);
                        }
                    } else if (line.equals(ShowTypesOfLines.this.getResources().getString(R.string.successlinereading))) {
                        if (pos == 0) {
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            lblcnt = 1;
                        } else if (pos == 1) {
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            lblcnt = 1;
                        } else if (pos == 2) {
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            lblcnt = 1;
                        } else if (pos == 3) {
                            setLabel(10.0f, 55.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            lblcnt = 1;
                        } else if (pos == 4) {
                            setLabel(10.0f, 40.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            setLabel(100.0f, 67.0f, ShowTypesOfLines.this.getResources().getString(R.string.success1));
                            lblcnt = 2;
                        } else if (pos == 5) {
                            setLabel(10.0f, 40.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.fate2));
                            lblcnt = 2;
                        } else if (pos == 6) {
                            setLabel(10.0f, 40.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            setLabel(95.0f, 55.0f, ShowTypesOfLines.this.getResources().getString(R.string.headlabel2));
                            lblcnt = 2;
                        } else if (pos == 7) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.heartlabel));
                            setLabel(10.0f, 40.0f, ShowTypesOfLines.this.getResources().getString(R.string.successlabel));
                            lblcnt = 2;
                        } else {
                            ftv.setVisibility(View.INVISIBLE);
                        }
                    } else if (line.equals(ShowTypesOfLines.this.getResources().getString(R.string.mountofmars))) {
                        setLabel(110.0f, 45.0f, ShowTypesOfLines.this.getResources().getString(R.string.marspositive));
                        setLabel(5.0f, 50.0f, ShowTypesOfLines.this.getResources().getString(R.string.marsnegative));
                        lblcnt = 2;
                    } else if (!line.equals(ShowTypesOfLines.this.getResources().getString(R.string.travellinereading))) {
                    } else {
                        if (pos == 0) {
                            setLabel(80.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            lblcnt = 1;
                        } else if (pos == 1) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.travellabel));
                            lblcnt = 2;
                        } else if (pos == 2) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            setLabel(10.0f, 70.0f, ShowTypesOfLines.this.getResources().getString(R.string.travellabel));
                            lblcnt = 2;
                        } else if (pos == 3) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.travellabel));
                            lblcnt = 2;
                        } else if (pos == 4) {
                            setLabel(90.0f, 20.0f, ShowTypesOfLines.this.getResources().getString(R.string.lifelabel));
                            setLabel(10.0f, 60.0f, ShowTypesOfLines.this.getResources().getString(R.string.travellabel));
                            lblcnt = 2;
                        } else {
                            ftv.setVisibility(View.INVISIBLE);
                        }
                    }
                }
            });
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    pos = pager.getCurrentItem();
                    String str = "resid";
                    String str2 = "line_eng";
                    String str3 = "line";
                    String str4 = "KKKKK ";
                    String str5 = "drawable";
                    if ((line.equals(ShowTypesOfLines.this.getResources().getString(R.string.fatelinereading)) && (pos == 3 || pos == 5 || pos == 6 || pos == 9 || pos == 10)) || line.equals(ShowTypesOfLines.this.getResources().getString(R.string.travellinereading))) {
                        String imgAns;
                        resid = getResources().getIdentifier(imageView.getTag().toString(), str5, getPackageName());
                        if (trans.contains("el") || trans.contains("ko") || trans.contains("da") || trans.contains("th") || trans.contains("ru") || trans.contains("ms") || trans.contains("de") || trans.contains("fr") || trans.contains("it") || trans.contains("zh") || trans.contains("hi") || trans.contains("en") || trans.contains("tr") || trans.contains("in") || trans.contains("pt") || trans.contains("es") || trans.contains("sk") || trans.contains("pl") || trans.contains("iw") || trans.contains("zu") || trans.contains("ro") || trans.contains("af")) {
                            imgAns = baseHelper.getImgAns(pos + 1, scid);
                        } else {
                            imgAns = "";
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("ifff  ");
                        stringBuilder.append(imgAns);
                        Intent intent = new Intent(ShowTypesOfLines.this, ShowResult.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("finalresult", imgAns);
                        bundle.putString(str3, line);
                        bundle.putString(str2, line_eng);
                        bundle.putInt(str, resid);
                        intent.putExtras(bundle);
                        ShowTypesOfLines.this.startActivity(intent);
                        return;
                    }
                    resid = getResources().getIdentifier(imageView.getTag().toString(), str5, getPackageName());
                    Intent intent2 = new Intent(ShowTypesOfLines.this, LineQuestions.class);
                    Bundle bundle2 = new Bundle();
                    bundle2.putString(str3, line);
                    bundle2.putString(str2, line_eng);
                    bundle2.putInt("pos", pos + 1);
                    bundle2.putInt("scid", scid);
                    bundle2.putInt("cid", cid);
                    bundle2.putInt(str, resid);
                    intent2.putExtras(bundle2);
                    ShowTypesOfLines.this.startActivity(intent2);
                }
            });
            ((ViewPager) viewGroup2).addView(rowView, 0);
            return rowView;
        }

        public int getItemPosition(Object obj) {
            return super.getItemPosition(obj);
        }

        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            ((ViewPager) viewGroup).removeView((View) obj);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.show_types_of_lines);
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("palmreading", 0);
        sharedPreferences = sharedPreferences;
        editor = sharedPreferences.edit();
        String str = "trans2";
        if (sharedPreferences.getString(str, null) == null || sharedPreferences.getString(str, null).equals(Locale.getDefault().getLanguage())) {
            String str2 = Locale.getDefault().getLanguage().toString();
            trans = str2;
            editor.putString(str, str2);
            editor.commit();
            Bundle extras = getIntent().getExtras();
            this.line = extras.getString("line").trim();
            this.line_eng = extras.getString("line_eng");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("selectline ");
            stringBuilder.append(this.line);
            this.scid = extras.getInt("scid");
            this.cid = extras.getInt("cid");
            txt_title = findViewById(R.id.txt_title);
            StringBuilder stringBuilder2 = new StringBuilder();
            str = "";
            stringBuilder2.append(str);
            stringBuilder2.append(this.line);
            txt_title.setText(stringBuilder2.toString());
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("inside ");
            stringBuilder3.append(this.line);
            DataBaseHelper dataBaseHelper = new DataBaseHelper(getApplicationContext(), getResources().getString(R.string.db_name));
            this.baseHelper = dataBaseHelper;
            try {
                dataBaseHelper.createDataBase();
            } catch (IOException e) {
                e.printStackTrace();
            }
            txt_description = (TextView) findViewById(R.id.txt_description);
            this.handtitles = new ArrayList();
            if (trans.contains("el") || trans.contains("ko") || trans.contains("da") || trans.contains("th") || trans.contains("ru") || trans.contains("ms") || trans.contains("de") || trans.contains("fr") || trans.contains("it") || trans.contains("zh") || trans.contains("hi") || trans.contains("en") || trans.contains("tr") || trans.contains("in") || trans.contains("pt") || trans.contains("es") || trans.contains("sk") || trans.contains("pl") || trans.contains("iw") || trans.contains("zu") || trans.contains("ro") || trans.contains("af")) {
                if (this.cid == 0) {
                    this.txt_description.setVisibility(View.VISIBLE);
                } else {
                    this.txt_description.setVisibility(View.GONE);
                }
                this.handtitles = this.baseHelper.getHandTitle(this.scid, this.cid);
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("handtitles  ");
                stringBuilder3.append(this.handtitles);
            }
            if (this.line.equals(getResources().getString(R.string.heartlinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.hlr1x), Integer.valueOf(R.drawable.hlr2x), Integer.valueOf(R.drawable.hlr3x), Integer.valueOf(R.drawable.hlr4x), Integer.valueOf(R.drawable.hlr5x), Integer.valueOf(R.drawable.hlr6x), Integer.valueOf(R.drawable.hlr7x)};
            } else if (this.line.equals(getResources().getString(R.string.lifelinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.llr1x), Integer.valueOf(R.drawable.llr2x), Integer.valueOf(R.drawable.llr3x), Integer.valueOf(R.drawable.llr4x)};
            } else if (this.line.equals(getResources().getString(R.string.headlinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.hdl1x), Integer.valueOf(R.drawable.hdl2x), Integer.valueOf(R.drawable.hdl3x), Integer.valueOf(R.drawable.hdl4x), Integer.valueOf(R.drawable.hdl5x), Integer.valueOf(R.drawable.hdl6x), Integer.valueOf(R.drawable.hdl7x), Integer.valueOf(R.drawable.hdl8x), Integer.valueOf(R.drawable.hdl9x), Integer.valueOf(R.drawable.hdl10x)};
            } else if (this.line.equals(getResources().getString(R.string.marriagelinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.mlr1x), Integer.valueOf(R.drawable.mlr2x), Integer.valueOf(R.drawable.mlr3x), Integer.valueOf(R.drawable.mlr4x), Integer.valueOf(R.drawable.mlr5x), Integer.valueOf(R.drawable.mlr6x), Integer.valueOf(R.drawable.mlr7x), Integer.valueOf(R.drawable.mlr8x), Integer.valueOf(R.drawable.mlr9x), Integer.valueOf(R.drawable.mlr10x), Integer.valueOf(R.drawable.mlr11x), Integer.valueOf(R.drawable.mlr12x)};
            } else if (this.line.equals(getResources().getString(R.string.fatelinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.ftl_1), Integer.valueOf(R.drawable.ftl_2), Integer.valueOf(R.drawable.ftl_3), Integer.valueOf(R.drawable.ftl_4), Integer.valueOf(R.drawable.ftl_5), Integer.valueOf(R.drawable.ftl_6), Integer.valueOf(R.drawable.ftl_7), Integer.valueOf(R.drawable.ftl_8), Integer.valueOf(R.drawable.ftl_9), Integer.valueOf(R.drawable.ftl_10)};
                this.ml = new float[]{70.0f, 70.0f, 70.0f, 0.0f, 0.0f, 0.0f, 0.0f, 70.0f};
                this.mt = new float[]{25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 50.0f, 25.0f};
            } else if (this.line.equals(getResources().getString(R.string.successlinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.scl1x), Integer.valueOf(R.drawable.scl2x), Integer.valueOf(R.drawable.scl3x), Integer.valueOf(R.drawable.scl4x), Integer.valueOf(R.drawable.scl5x), Integer.valueOf(R.drawable.scl6x), Integer.valueOf(R.drawable.scl7x), Integer.valueOf(R.drawable.scl8x)};
                this.ml = new float[]{10.0f, 20.0f, 30.0f, 10.0f, 10.0f, 10.0f, 100.0f};
                this.mt = new float[]{10.0f, 20.0f, 30.0f, 10.0f, 10.0f, 10.0f, 100.0f};
            } else if (this.line.equals(getResources().getString(R.string.travellinereading))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.trl_1), Integer.valueOf(R.drawable.trl_2), Integer.valueOf(R.drawable.trl_3), Integer.valueOf(R.drawable.trl_4), Integer.valueOf(R.drawable.trl_5)};
            } else if (this.line.equals(getResources().getString(R.string.mountofmars))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.mars)};
            } else if (this.line.equals(getResources().getString(R.string.mountofjupiter))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.jupiter)};
            } else if (this.line.equals(getResources().getString(R.string.mountofsaturn))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.saturn)};
            } else if (this.line.equals(getResources().getString(R.string.mountofsun))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.sun)};
            } else if (this.line.equals(getResources().getString(R.string.mountofmercury))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.mercury)};
            } else if (this.line.equals(getResources().getString(R.string.mountofmoon))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.moon)};
            } else if (this.line.equals(getResources().getString(R.string.mountofvenus))) {
                this.mImageIds = new Integer[]{Integer.valueOf(R.drawable.venus)};
            }
            this.resid = getResources().getIdentifier(this.line.toLowerCase().replaceAll(" ", str), "drawable", getPackageName());
            ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
            this.pager = viewPager;
            viewPager.setAdapter(new ViewPageAdapter(this));
            this.btn_next = (Button) findViewById(R.id.btn_next);
            this.btn_previous = (Button) findViewById(R.id.btn_previous);
            this.btn_next.setVisibility(View.INVISIBLE);
            this.btn_previous.setVisibility(View.INVISIBLE);

            this.btn_next.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    pager.setCurrentItem(pager.getCurrentItem() + 1);
                }
            });
            this.btn_previous.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    pager.setCurrentItem(pager.getCurrentItem() - 1);
                }
            });
            this.pager.setOnPageChangeListener(new OnPageChangeListener() {
                public void onPageScrollStateChanged(int i) {
                }

                public void onPageSelected(int i) {
                }

                public void onPageScrolled(int i, float f, int i2) {
                    if (i == 0 && mImageIds.length == 1) {
                        btn_next.setVisibility(View.INVISIBLE);
                        btn_previous.setVisibility(View.INVISIBLE);
                    } else if (i == ShowTypesOfLines.this.mImageIds.length - 1) {
                        btn_next.setVisibility(View.INVISIBLE);
                        btn_previous.setVisibility(View.VISIBLE);
                    } else if (i == 0) {
                        btn_next.setVisibility(View.VISIBLE);
                        btn_previous.setVisibility(View.INVISIBLE);
                    } else {
                        btn_next.setVisibility(View.VISIBLE);
                        btn_previous.setVisibility(View.VISIBLE);
                    }
                }
            });

            iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (interstitial !=null && interstitial.isLoaded()){
                        try {
                            hud = KProgressHUD.create(activity)
                                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                    .setLabel("Showing Ads")
                                    .setDetailsLabel("Please Wait...");
                            hud.show();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    hud.dismiss();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();

                                } catch (NullPointerException e2) {
                                    e2.printStackTrace();
                                } catch (Exception e3) {
                                    e3.printStackTrace();
                                }
                                if (interstitial != null && interstitial.isLoaded()) {
                                    Adid = 100;
                                    interstitial.show();
                                }
                            }
                        }, 2000);
                    }else {
                        editor.putString("trans2", null);
                        editor.commit();
                        startActivity(new Intent(ShowTypesOfLines.this, SelectLine.class));
                        finish();
                    }
                }
            });
            return;
        }
        loadAd();
        BannerAds();
        editor.putString(str, null);
        editor.commit();
        finish();
    }

    public boolean RemoveTextViews() {
        this.id = 0;
        while (true) {
            int i = this.id;
            if (i <= this.lblcnt) {
                View findViewById = findViewById(i);
                if (findViewById instanceof TextView) {
                    this.myrel.removeView(findViewById);
                }
                this.id++;
            } else {
                this.id = 0;
                return true;
            }
        }
    }

    public TextView setLabel(float f, float f2, String str) {
        this.ftv.setVisibility(View.INVISIBLE);
        TextView textView = new TextView(this.context);
        textView.setId(this.id);
        this.id++;
        textView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        this.myrel.addView(textView);
        textView.setTextColor(getResources().getColor(R.color.text_color1));
        textView.setVisibility(View.VISIBLE);
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) textView.getLayoutParams();
        if ((getResources().getConfiguration().screenLayout & 15) == 1) {
            textView.setTextSize(10.0f);
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 2) {
            textView.setTextSize(11.0f);
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(16.0f);
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(20.0f);
        }
        float width = (float) this.imageView.getWidth();
        float height = (float) this.imageView.getHeight();
        f = (f / 100.0f) * width;
        this.left = f;
        this.top = (f2 / 100.0f) * height;
        marginLayoutParams.setMargins(Math.round(f), Math.round(this.top), 0, 0);
        textView.setMaxWidth(Math.round(width / 2.7f));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(str);
        textView.setText(stringBuilder.toString());
        textView.setGravity(1);
        return textView;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    private void loadAd() {
        //InterstitialAd

        interstitial = new InterstitialAd(ShowTypesOfLines.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        editor.putString("trans2", null);
                        editor.commit();
                        startActivity(new Intent(ShowTypesOfLines.this, SelectLine.class));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        editor.putString("trans2", null);
        editor.commit();
        startActivity(new Intent(ShowTypesOfLines.this, SelectLine.class));
        finish();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }
}
