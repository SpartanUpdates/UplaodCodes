package com.kotlinz.videoCollage.adpaters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.kotlinz.videoCollage.interfaces.BGColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class BgColorAdapter extends Adapter<BgColorAdapter.ViewHolder> {
    private String[] bgColorList;
    private Context context;
    private BGColorAdapterCallBackInterface listener;
    private int pos = -1;

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgBGColor;
        ImageView imgSelector;

        ViewHolder(View view) {
            super(view);
            this.imgBGColor = view.findViewById(R.id.img_bg_color);
            this.imgSelector = view.findViewById(R.id.img_bg_selector);
        }
    }

    public BgColorAdapter(String[] strArr, Context context, BGColorAdapterCallBackInterface bGColorAdapterCallBackInterface) {
        this.bgColorList = strArr;
        this.listener = bGColorAdapterCallBackInterface;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bg_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        String str = bgColorList[i];
        viewHolder.imgBGColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgBGColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgBGColor.setBackground(gradientDrawable);
        viewHolder.imgBGColor.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                pos = i;
                listener.itemClick(i);
                notifyDataSetChanged();
            }
        });
        if (pos == i) {
            viewHolder.imgSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.bgColorList.length;
    }
}
