package com.esc.beautymackupselficlam.library;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.Random;

import androidx.annotation.RequiresApi;

public class Utility {
  private static final float BITMAP_SCALE = 0.4f;
  private static final float BLUR_RADIUS = 10.0f;
  public static Bitmap CropBitmap = null;
  private static String MY_PREFS_NAME = "ShareData";
  public static Bitmap inputBitmap = null;
  public static int int_image_type = 0;
  public static int int_pip_type = 0;
  public static int int_selected_type = 0;
  private static SharedPreferences nped;
  public static Bitmap resultBitmap = null;

  public static void makeMaskImage(Context c, ImageView mImageView, Bitmap bg, int s_mask, int s_frame, int width, int height) {
    Bitmap original = null;
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
      original = blur(c, bg);
    }
    Bitmap mask = BitmapFactory.decodeResource(c.getResources(), s_mask);
    Bitmap frame = BitmapFactory.decodeResource(c.getResources(), s_frame);
    Bitmap result = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    Canvas mCanvas = new Canvas(result);
    Paint paint = new Paint(1);
    paint.setXfermode(new PorterDuffXfermode(Mode.DST_OUT));
    mCanvas.drawBitmap(original, new Rect(0, 0, original.getWidth(), original.getHeight()), new Rect(0, 0, width, height), null);
    mCanvas.drawBitmap(mask, new Rect(0, 0, mask.getWidth(), mask.getHeight()), new Rect(0, 0, width, height), paint);
    mCanvas.drawBitmap(frame, new Rect(0, 0, frame.getWidth(), frame.getHeight()), new Rect(0, 0, width, height), null);
    paint.setXfermode(null);
    mImageView.setImageBitmap(result);
    mImageView.setScaleType(ScaleType.CENTER);
  }

  @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
  public static Bitmap blur(Context context, Bitmap image) {
    Bitmap inputBitmap = Bitmap.createScaledBitmap(image, Math.round(((float) image.getWidth()) * BITMAP_SCALE), Math.round(((float) image.getHeight()) * BITMAP_SCALE), false);
    Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
    RenderScript rs = RenderScript.create(context);
    ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
    Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
    theIntrinsic.setRadius(BLUR_RADIUS);
    theIntrinsic.setInput(tmpIn);
    theIntrinsic.forEach(tmpOut);
    tmpOut.copyTo(outputBitmap);
    return outputBitmap;
  }

  public static Bitmap rotate(Bitmap bitmap, float degrees) {
    Matrix matrix = new Matrix();
    matrix.postRotate(degrees);
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
  }

  public static Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical) {
    float f;
    float f2 = -1.0f;
    Matrix matrix = new Matrix();
    if (horizontal) {
      f = -1.0f;
    } else {
      f = 1.0f;
    }
    if (!vertical) {
      f2 = 1.0f;
    }
    matrix.preScale(f, f2);
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
  }

  public static Bitmap modifyOrientation(Bitmap bitmap, String image_url) throws IOException {
    switch (new ExifInterface(image_url).getAttributeInt("Orientation", 1)) {
      case 2:
        return flip(bitmap, true, false);
      case 3:
        return rotate(bitmap, 180.0f);
      case 4:
        return flip(bitmap, false, true);
      case 6:
        return rotate(bitmap, 90.0f);
      case 8:
        return rotate(bitmap, 270.0f);
      default:
        return bitmap;
    }
  }

  public static Bitmap getResizedBitmap(Bitmap image, int maxSize) {
    int width;
    int height;
    float bitmapRatio = ((float) image.getWidth()) / ((float) image.getHeight());
    if (bitmapRatio > 0.0f) {
      width = maxSize;
      height = (int) (((float) width) / bitmapRatio);
    } else {
      height = maxSize;
      width = (int) (((float) height) * bitmapRatio);
    }
    return Bitmap.createScaledBitmap(image, width, height, true);
  }

  @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
  public static ImageView MakeMaskAlphabetsImage(Context c, int bg_bitmap, int s_mask, int s_frame, int width, int height) {
    ImageView img = new ImageView(c);
    Bitmap original = blur(c, BitmapFactory.decodeResource(c.getResources(), bg_bitmap));
    Bitmap mask = BitmapFactory.decodeResource(c.getResources(), s_mask);
    Bitmap frame = BitmapFactory.decodeResource(c.getResources(), s_frame);
    Bitmap result = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    Canvas mCanvas = new Canvas(result);
    Paint paint = new Paint(1);
    paint.setXfermode(new PorterDuffXfermode(Mode.DST_OUT));
    mCanvas.drawBitmap(original, new Rect(0, 0, original.getWidth(), original.getHeight()), new Rect(0, 0, width, height), null);
    mCanvas.drawBitmap(mask, new Rect(0, 0, mask.getWidth(), mask.getHeight()), new Rect(0, 0, width, height), paint);
    paint.setXfermode(null);
    img.setImageBitmap(result);
    img.setScaleType(ScaleType.CENTER);
    return img;
  }

  public static String main(String id) throws Exception {
    String result = "";
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    md.update(id.getBytes());
    byte[] byteData = md.digest();
    StringBuffer sb = new StringBuffer();
    for (byte b : byteData) {
      sb.append(Integer.toString((b & 255) + 256, 16).substring(1));
    }
    StringBuffer hexString = new StringBuffer();
    for (byte b2 : byteData) {
      String hex = Integer.toHexString(b2 & 255);
      if (hex.length() == 1) {
        hexString.append('0');
      }
      hexString.append(hex);
    }
    return hexString.toString();
  }
}
