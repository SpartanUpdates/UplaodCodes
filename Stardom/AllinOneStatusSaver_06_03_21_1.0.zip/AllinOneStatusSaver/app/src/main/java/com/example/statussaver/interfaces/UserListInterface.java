package com.example.statussaver.interfaces;


import com.example.statussaver.model.story.TrayModel;

public interface UserListInterface {
    void userListClick(int position, TrayModel trayModel);
}
