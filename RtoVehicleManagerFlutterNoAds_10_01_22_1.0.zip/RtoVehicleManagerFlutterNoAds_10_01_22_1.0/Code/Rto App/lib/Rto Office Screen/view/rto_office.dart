import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:rto_app/Home%20Screen/themes.dart';
import 'package:rto_app/Owner%20Info%20Screen/controllers/controllers.dart';
import 'package:rto_app/Rto%20Office%20Screen/controllers/rto_office_controller.dart';
import 'package:rto_app/Rto%20Office%20Screen/model/fuel_model.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/main.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:velocity_x/src/extensions/context_ext.dart';
import 'package:velocity_x/src/extensions/string_ext.dart';
import 'package:velocity_x/src/flutter/center.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/text.dart';

class RtoOfficeInfo extends StatelessWidget {
  String moduleName;
  static bool isOpened = true;
  RtoOfficeInfo(this.moduleName);

  static String cityName = "Ahmedabad";
  RtoOfficeController controller = Get.put(RtoOfficeController());
  TextEditingController searchTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    print("code ${ScreenStart.mode}");
    controller.fetchStateAndCityData();
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.white));
    /*SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: MyThemes.statucBar,
        systemNavigationBarColor: MyThemes.statucBar));*/
    return WillPopScope(
      onWillPop: () {
        controller.scrollIndex = 0;
        controller.searchList.clear();
        Future.delayed(const Duration(milliseconds: 350), () {
          Navigator.pop(context);
        });
        return Future.value(false);
      },
      child: GetBuilder<RtoOfficeController>(
        builder: (controller) {
          return Material(
            child: SafeArea(
              child: Scaffold(
                backgroundColor: Theme.of(context).backgroundColor,
                body: NestedScrollView(
                  physics: BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics()),
                  floatHeaderSlivers: true,
                  headerSliverBuilder:
                      (BuildContext context, bool innerBoxIsScrolled) {
                    return <Widget>[
                      SliverAppBar(
                        backgroundColor: Theme.of(context).cardColor,
                        title: Text(
                          "",
                          style: TextStyle(
                              fontSize: 16.5,
                              color: Theme.of(context).accentColor,
                              fontFamily: "Circular Bold"),
                        ).centered(),
                        leading: Container(
                          padding: EdgeInsets.all(10),
                          child: Material(
                            color: Colors.transparent,
                            shape: CircleBorder(),
                            clipBehavior: Clip.hardEdge,
                            child: IconButton(
                                padding: EdgeInsets.zero,
                                onPressed: () {
                                  Future.delayed(
                                      const Duration(milliseconds: 350), () {
                                    controller.scrollIndex = 0;
                                    controller.searchList.clear();
                                    Navigator.pop(context);
                                  });
                                },
                                icon: Icon(
                                  Icons.arrow_back_ios_rounded,
                                  color: Theme.of(context).accentColor,
                                  size: 20,
                                )),
                          ),
                        ),
                        actions: [
                          IconButton(
                            onPressed: () {},
                            icon: Hero(
                              tag: "rtooffice",
                              transitionOnUserGestures: true,
                              child: Opacity(
                                opacity: 0.7,
                                child: (Image.asset(
                                  'assets/images/india.png',
                                )),
                              ),
                            ),
                            iconSize: 50,
                          ).pOnly(right: 10),
                        ],
                      )
                    ];
                  },
                  body: Container(
                    color: Theme.of(context).backgroundColor,
                    child: Column(
                      children: [
                        Container(
                          height: 120,
                          width: double.infinity,
                          decoration: BoxDecoration(
                              color: Theme.of(context).cardColor,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.only(
                                  bottomRight: Radius.circular(30.0),
                                  bottomLeft: Radius.circular(30.0))),
                          child: Column(
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Hi,",
                                  style: TextStyle(
                                      fontSize: 14.5,
                                      color: Theme.of(context).accentColor,
                                      fontFamily: "Circular Medium"),
                                ),
                              ).pOnly(left: 20),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Please choose the city",
                                  style: TextStyle(
                                      fontSize: 16.5,
                                      color: Theme.of(context).accentColor,
                                      fontFamily: "Circular Bold"),
                                ),
                              ).py(5).pOnly(left: 20, bottom: 5),
                              Container(
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                    padding: EdgeInsets.all(0.0),
                                    height: 40,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(25),
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child: Align(
                                          alignment: Alignment.centerLeft,
                                          child: CupertinoSearchTextField(
                                            onTap: () {
                                              controller
                                                  .fetchStateAndCityData();
                                            },
                                            controller: searchTextController,
                                            itemSize: 21,
                                            prefixIcon:
                                                Icon(CupertinoIcons.search),
                                            suffixIcon: Icon(CupertinoIcons
                                                .clear_circled_solid),
                                            onSuffixTap: () {
                                              controller.searchList.clear();
                                              searchTextController.text = "";
                                              StateListDisplay.isDataAvailable =
                                                  false;
                                              controller
                                                  .fetchStateAndCityData();
                                              /*controller.scrollIndex = 0;
                                                  controller.searchList.clear();
                                                  searchTextController.text = "";
                                                  controller.fetchStateAndCityData();*/
                                            },
                                            prefixInsets: EdgeInsets.fromLTRB(
                                                10, 2, 0, 2),
                                            suffixInsets: EdgeInsets.fromLTRB(
                                                0, 2, 10, 2),
                                            padding: EdgeInsets.fromLTRB(
                                                15, 7, 15, 7),
                                            backgroundColor:
                                                context.backgroundColor,
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            autofocus: false,
                                            placeholder: 'search by city name',
                                            placeholderStyle: TextStyle(
                                                letterSpacing: 1,
                                                fontSize: 18,
                                                color: Theme.of(context)
                                                    .indicatorColor,
                                                fontFamily: "Circular Medium"),
                                            style: TextStyle(
                                                letterSpacing: 1,
                                                fontSize: 18,
                                                color: Colors.grey,
                                                fontFamily: "Circular Medium"),
                                            onChanged: (value) {
                                              controller.scrollIndex = 0;
                                              if (value.length >= 1) {
                                                controller.searchList.clear();
                                                controller.searchData(value);
                                              } else {
                                                controller.searchList.clear();
                                              }
                                            },
                                          ),
                                        ))
                                      ],
                                    ),
                                  ),
                                ).px(10),
                              ).pOnly(left: 5, right: 5).pOnly(top: 8),
                            ],
                          ).pOnly(top: 10),
                        ),
                        PopularCities(controller.fuelDataList, moduleName),
                        StateListDisplay(controller, moduleName)
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class PopularCities extends StatelessWidget {
  MainControllers mainControllers = Get.put(MainControllers());
  List<StateList> fuelDataList;
  String fuelName;
  PopularCities(this.fuelDataList, this.fuelName);
  @override
  Widget build(BuildContext context) {
    List<Map> popularCityList = [
      {
        'name': 'Mumbai',
      },
      {
        'name': 'Pune',
      },
      {'name': 'Delhi'},
      {
        'name': 'Chennai',
      },
      {
        'name': 'Kolkata',
      },
      {
        'name': 'Hyderabad',
      },
      {
        'name': 'Ahmedabad',
      },
      {
        'name': 'Surat',
      },
      {
        'name': 'Jaipur',
      },
      {
        'name': 'Lucknow',
      },
    ];

    return Container(
      color: Theme.of(context).backgroundColor,
      width: double.infinity,
      height: 90,
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text("Popular cities",
                    style: TextStyle(fontFamily: "Circular Medium"))
                .text
                .size(15)
                .make()
                .pOnly(left: 20, top: 13),
          ),
          Container(
              margin: EdgeInsets.all(10),
              child: SizedBox(
                  height: 35,
                  child: ListView.builder(
                      physics: BouncingScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: popularCityList.length,
                      itemBuilder: (context, index) {
                        return SizedBox(
                          child: Card(
                            color: Theme.of(context).backgroundColor,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(13),
                                side: BorderSide(
                                    width: 0.3,
                                    color: Theme.of(context).accentColor)),
                            child: InkWell(
                              customBorder: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(13)),
                              onTap: () {
                                if (fuelName == "Fuel") {
                                  mainControllers.fetchFuelData(
                                      context,
                                      popularCityList[index]['name'],
                                      "cityList");
                                } else {
                                  if (RtoOfficeInfo.isOpened == true) {
                                    RtoOfficeInfo.isOpened = false;
                                    String rtoCode = "",
                                        district = "",
                                        state = "",
                                        address = "",
                                        phone = "",
                                        website = "";

                                    String cityName =
                                        popularCityList[index]['name'];
                                    if (cityName == "Mumbai") {
                                      cityName = "Mumbai West";
                                    }
                                    if (cityName == "Delhi") {
                                      cityName = "Delhi Central";
                                    }
                                    if (cityName == "Chennai") {
                                      cityName = "Chennai Central";
                                    }
                                    if (cityName == "Jaipur") {
                                      cityName = "Jaipur South";
                                    }

                                    fuelDataList.forEach((element) {
                                      element.rto_list.forEach((element2) {
                                        if (element2['district']!
                                                .toLowerCase() ==
                                            (cityName.toLowerCase())) {
                                          Future.delayed(
                                              Duration(milliseconds: 350), () {
                                            rtoCode = element2['rto_code'];
                                            district = element2['district'];
                                            state = element2['state'];
                                            address = element2['address'];
                                            phone = element2['phone'];
                                            website = element2['website'];
                                            getBottomSheet(
                                                context,
                                                rtoCode,
                                                district,
                                                state,
                                                address,
                                                phone,
                                                website);
                                          });
                                          throw "";
                                        }
                                      });
                                      return;
                                    });
                                  }
                                }
                              },
                              splashColor: MyThemes.skyBlue,
                              child: Stack(
                                children: [
                                  Container(
                                      child: Text(
                                              popularCityList[index]['name'],
                                              style: TextStyle(
                                                  fontFamily: "Circular Medium",
                                                  color: Colors.blueGrey))
                                          .text
                                          .size(10)
                                          .make()
                                          .px(10)
                                          .py(5)),
                                ],
                              ),
                            ),
                          ).px(5),
                        );
                      })))
        ],
      ),
    );
  }
}

class StateListDisplay extends StatelessWidget {
  final controllers;
  String moduleName;
  StateListDisplay(this.controllers, this.moduleName);

  static bool isDataAvailable = false;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GetBuilder<RtoOfficeController>(
        builder: (controllers) {
          return isDataAvailable
              ? displayExpandableList(controllers, context, moduleName)
              : Center(
                  child: CircularProgressIndicator(
                    color: MyThemes.bluishColor,
                  ),
                );
        },
      ),
    );
  }
}

displayExpandableList(
    RtoOfficeController controllers, BuildContext context, String moduleName) {
  MainControllers mainControllers = Get.put(MainControllers());
  bool _customTileExpanded = false;
  /*final ItemPositionsListener itemPositionsListener =
      ItemPositionsListener.create();
  itemScrollController.jumpTo(index: 10);*/
  final GlobalKey expansionTileKey = GlobalKey();
  return GetBuilder<RtoOfficeController>(builder: (controllers) {
    return Container(
      padding: EdgeInsets.all(10),
      color: Theme.of(context).backgroundColor,
      child: ScrollablePositionedList.builder(
          shrinkWrap: true,
          itemScrollController: controllers.scrollController,
          physics: BouncingScrollPhysics(),
          itemCount: controllers.searchList.isNotEmpty
              ? controllers.searchList.length
              : controllers.fuelDataList.length,
          itemBuilder: (context, index) {
            var stateListModel = controllers.searchList.isNotEmpty
                ? controllers.searchList
                : controllers.fuelDataList;
            return Card(
              color: Theme.of(context).buttonColor,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              child: InkWell(
                customBorder: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                splashColor: MyThemes.skyBlue,
                child: Theme(
                  data: Theme.of(context)
                      .copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    initiallyExpanded: controllers.expand == false
                        ? index == 0
                            ? false
                            : index == controllers.scrollIndex
                                ? true
                                : false
                        : false,
                    title: Text(
                      stateListModel[index].name,
                      style: TextStyle(
                          fontSize: 15.5,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Medium"),
                    ),
                    trailing: Icon(
                      _customTileExpanded
                          ? Icons.arrow_drop_down_circle
                          : Icons.arrow_drop_down,
                    ),
                    children: <Widget>[
                      ListView.builder(
                        physics: BouncingScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: stateListModel[index].rto_list.length,
                        itemBuilder: (context, index2) {
                          return Card(
                            color: Theme.of(context).backgroundColor,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: InkWell(
                              customBorder: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                              onTap: () {
                                String cityName = stateListModel[index]
                                    .rto_list[index2]['district'];
                                if (moduleName == "Fuel") {
                                  controllers.searchList.clear();
                                  mainControllers.fetchFuelData(
                                      context, cityName, "cityList");
                                } else {
                                  if (RtoOfficeInfo.isOpened == false) {
                                    RtoOfficeInfo.isOpened = true;
                                  } else {
                                    getBottomSheet(
                                        context,
                                        stateListModel[index].rto_list[index2]
                                            ['rto_code'],
                                        stateListModel[index].rto_list[index2]
                                            ['district'],
                                        stateListModel[index].rto_list[index2]
                                            ['state'],
                                        stateListModel[index].rto_list[index2]
                                            ['address'],
                                        stateListModel[index].rto_list[index2]
                                            ['phone'],
                                        stateListModel[index].rto_list[index2]
                                            ['website']);
                                  }
                                }
                              },
                              splashColor: MyThemes.skyBlue,
                              child: Container(
                                  padding: EdgeInsets.all(8),
                                  child: Row(
                                    children: [
                                      Text(
                                        "${stateListModel[index].rto_list[index2]['district']}  - ",
                                        style: TextStyle(
                                            fontSize: 13.5,
                                            color: Colors.blueGrey,
                                            fontFamily: "Circular Medium"),
                                      ),
                                      Text(
                                        stateListModel[index].rto_list[index2]
                                            ['rto_code'],
                                        style: TextStyle(
                                            fontSize: 13.5,
                                            color: Colors.redAccent,
                                            fontFamily: "Circular Medium"),
                                      ),
                                    ],
                                  )),
                            ),
                          ).px(5).pOnly(bottom: 5);
                        },
                      )
                    ],
                    onExpansionChanged: (bool expanded) {
                      FocusScope.of(context).unfocus();
                      if (expanded) {
                        controllers.changeSateList(index);
                      }
                    },
                  ),
                ),
              ),
            );
          }),
    );
  });
}

getBottomSheet(BuildContext context, String rto_code, String district,
    String state, String address, String phone, String website) {
  FocusScope.of(context).unfocus();
  RtoOfficeInfo.isOpened == false;
  return showMaterialModalBottomSheet(
      context: context,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: new Icon(CupertinoIcons.building_2_fill).pOnly(top: 10),
              title: new Text('RTO code',
                  style:
                      TextStyle(fontSize: 15, fontFamily: "Circular Medium")),
              subtitle: Text("${rto_code} ${state},${district}",
                  style:
                      TextStyle(fontSize: 14, fontFamily: "Circular Medium")),
              onTap: () {},
            ),
            phone.length > 0
                ? ListTile(
                    leading: new Icon(CupertinoIcons.phone_arrow_up_right)
                        .pOnly(top: 10),
                    title: new Text('Contact',
                        style: TextStyle(
                            fontSize: 15, fontFamily: "Circular Medium")),
                    subtitle: Text(phone,
                        style: TextStyle(
                            fontSize: 14, fontFamily: "Circular Medium")),
                    onTap: () {},
                    trailing: Card(
                      color: Theme.of(context).backgroundColor,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                          side: BorderSide(
                              width: 0.3,
                              color: Theme.of(context).primaryColor)),
                      child: InkWell(
                        customBorder: new CircleBorder(),
                        onTap: () {
                          launch("tel://${phone}");
                        },
                        splashColor: Colors.red,
                        child: Padding(
                          padding: EdgeInsets.all(5),
                          child: new Icon(
                            Icons.call,
                            size: 20,
                            color: Colors.blueGrey,
                          ),
                        ),
                      ),
                    ).pOnly(top: 10),
                  )
                : Container(),
            ListTile(
              leading: new Icon(Icons.map).pOnly(top: 10),
              title: new Text('Website',
                  style:
                      TextStyle(fontSize: 15, fontFamily: "Circular Medium")),
              subtitle: RichText(
                text: TextSpan(
                  children: [
                    new TextSpan(
                      text: "${website}  ",
                      style: TextStyle(
                          color: Colors.blueGrey,
                          fontSize: 15,
                          fontFamily: "Circular Medium"),
                    ),
                    new TextSpan(
                      text: 'tap here',
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 14,
                          fontFamily: "Circular Medium"),
                      recognizer: new TapGestureRecognizer()
                        ..onTap = () {
                          launch(website);
                        },
                    ),
                  ],
                ),
              ),
            ).py(10),
            ListTile(
              leading: new Icon(CupertinoIcons.location).pOnly(top: 10),
              title: new Text('Address',
                  style:
                      TextStyle(fontSize: 15, fontFamily: "Circular Medium")),
              subtitle: Text(address,
                  style:
                      TextStyle(fontSize: 14, fontFamily: "Circular Medium")),
              onTap: () {},
              trailing: Card(
                color: Theme.of(context).backgroundColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                    side: BorderSide(
                        width: 0.3, color: Theme.of(context).primaryColor)),
                child: InkWell(
                  customBorder: new CircleBorder(),
                  onTap: () {
                    Navigator.pop(context);
                    MapsLauncher.launchQuery(address);
                  },
                  splashColor: Colors.red,
                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child: new Icon(
                      Icons.location_on,
                      size: 20,
                      color: Colors.blueGrey,
                    ),
                  ),
                ),
              ).pOnly(top: 10),
            ).pOnly(bottom: 10),
          ],
        );
      }).whenComplete(() => RtoOfficeInfo.isOpened = true);
}

_launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch ${url}';
  }
}
