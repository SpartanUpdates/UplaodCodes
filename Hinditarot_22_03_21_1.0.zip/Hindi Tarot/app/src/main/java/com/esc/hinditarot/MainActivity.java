package com.esc.hinditarot;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import com.esc.hinditarot.kprogresshud.KProgressHUD;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.ironsource.mediationsdk.IronSource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public static final String SELECTED_CATEGORY = "com.waf.hinditarot.SELECTED_CATEGORY";
    public Activity activity = MainActivity.this;
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (MainActivity.i == 0) {
                MainActivity.i++;
                MainActivity.startbool = true;
                MainActivity.handler.postDelayed(MainActivity.changeAdBool, i);
                return;
            }
            MainActivity.showbool = true;
            MainActivity.i = 0;
            MainActivity.stopbool = true;
            MainActivity.stopRunnable();
        }
    };
    public static Editor editor;
    public static Typeface georgiar;
    public static Handler handler = new Handler();
    static int i = 0;
    public static Typeface roboto;
    public static SharedPreferences sharedPreferences;
    public static boolean showbool = false;
    public static int showcnt = 0;
    public static boolean startbool = false;
    public static boolean stopbool = false;
    ImageView btnFamily;
    ImageView btnHealth;
    ImageView btnLife;
    ImageView btnLove;
    ImageView btnMoney;
    Intent intent;
    public String selectedCategory;

    private int id;
    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        sharedPreferences = getApplicationContext().getSharedPreferences("MYPREF", 0);
        editor = sharedPreferences.edit();
        georgiar = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        roboto = Typeface.createFromAsset(getAssets(), "fonts/RobotoSlab-Regular.ttf");
        this.btnLove = findViewById(R.id.ivLove);
        BannerAds();
        interstitialAd();
        this.btnLove.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }
                else {
                    Love();
                }

            }
        });
        this.btnMoney = findViewById(R.id.ivMoney);
        this.btnMoney.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 102;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }
                else {
                    Money();
                }
            }
        });
        this.btnLife = findViewById(R.id.ivlife);
        this.btnLife.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 103;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }
                else {
                    Life();
                }
            }
        });
        this.btnFamily = findViewById(R.id.ivfamily);
        this.btnFamily.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 104;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    Family();
                }
            }
        });
        this.btnHealth = findViewById(R.id.ivHealth);
        this.btnHealth.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd!=null&&mInterstitialAd.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 10;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                }else {
                    Health();
                }
            }
        });
    }

    private void Love(){
        intent = new Intent(activity, ChooseCard.class);
        intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.loveNrel));
        selectedCategory = "Love & Relationships";
        intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
        Map hashMap = new HashMap();
        hashMap.put(MainActivity.this.selectedCategory, "Hindi Tarot");
        startActivity(intent);
    }
    private void Money(){
        intent = new Intent(activity, ChooseCard.class);
        intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.money));
        selectedCategory = "Money";
        intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
        Map hashMap = new HashMap();
        hashMap.put(selectedCategory, "Hindi Tarot");
        startActivity(intent);
    }
    private void Life(){
        intent = new Intent(activity, ChooseCard.class);
        intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.life));
        selectedCategory = "Life";
        intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
        Map hashMap = new HashMap();
        hashMap.put(selectedCategory, "Hindi Tarot");
        startActivity(intent);
    }
    private void Family(){
        intent = new Intent(activity, ChooseCard.class);
        intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.familyNfriends));
        selectedCategory = "Family & Friends";
        intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
        Map hashMap = new HashMap();
        hashMap.put(selectedCategory, "Hindi Tarot");
        startActivity(intent);
    }
    private void Health(){
        intent = new Intent(activity, ChooseCard.class);
        intent.putExtra(MainActivity.SELECTED_CATEGORY, MainActivity.this.getResources().getString(R.string.health));
        selectedCategory = "Health";
        intent.putExtra("SELECTED_CATEGORY_EN", MainActivity.this.selectedCategory);
        Map hashMap = new HashMap();
        hashMap.put(selectedCategory, "Hindi Tarot");
        startActivity(intent);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 101:
                        Love();
                        break;
                    case 102:
                        Money();
                        break;
                    case 103:
                        Life();
                        break;
                    case 104:
                        Family();
                        break;
                    case 105:
                        Health();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.admob_interstitial));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void stopRunnable() {
        if (stopbool) {
            handler.removeCallbacks(changeAdBool);
        }
    }


    public void onBackPressed() {
        showcnt = 0;
        Intent intent = new Intent(this, SplashActivity.class);
        startActivity(intent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
