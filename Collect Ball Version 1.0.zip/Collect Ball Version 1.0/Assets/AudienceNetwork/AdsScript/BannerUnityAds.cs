﻿using System.Collections;
using UnityEngine;
using UnityEngine.Advertisements;
using UnityEngine.Analytics;


namespace BallCollect
{
    public class BannerUnityAds : MonoBehaviour
    {
        public static BannerUnityAds instance;

        bool testMode1 = true;

        void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }

        void Start()
        {
            Advertisement.Initialize(Manager.instance.unityGameId, testMode1);
            StartCoroutine(ShowBannerWhenReady());
        }

        bool isBannerLoad = false;

        public IEnumerator ShowBannerWhenReady()
        {
            while (!Advertisement.IsReady(Manager.instance.unityBannerId))
            {
                yield return new WaitForSeconds(0.5f);
            }
            isBannerLoad = true;
            if (isBannerLoad && !Manager.instance.isFbAdsShow && !MainMenu.instance.shopPanel.activeSelf)
            {
                Analytics.CustomEvent("UnityBannerAdsShow");
                MainMenu.instance.bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, 158);
                Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_CENTER);
                Advertisement.Banner.Show(Manager.instance.unityBannerId);
                Manager.instance.isUnityAdsShow = true;
            }
        }

        public void BannerAdsUnityShow()
        {
            if (isBannerLoad && !Manager.instance.isFbAdsShow && !MainMenu.instance.shopPanel.activeSelf)
            {
                Analytics.CustomEvent("UnityBannerAdsShow");
                MainMenu.instance.bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, 158);
                Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_CENTER);
                Advertisement.Banner.Show(Manager.instance.unityBannerId);
                Manager.instance.isUnityAdsShow = true;
            }
        }
        public void BannerAdsUnityHide()
        {
           Advertisement.Banner.Hide();
        }
    }
}