import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:package_info/package_info.dart';
import 'package:rto_app/Home%20Screen/controller/ThemeController.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:rto_app/Utils/utils.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'package:velocity_x/velocity_x.dart';

class MyDrawer extends StatelessWidget {
  var info;
  Future<void> _initPackageInfo() async {
    info = await PackageInfo.fromPlatform();
  }

  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    _initPackageInfo();
    Color skyBlue = Color(0xff9AB0DB);
    ThemeController themeController = Get.put(ThemeController());
    return Container(
      margin: EdgeInsets.symmetric(vertical: 40),
      width: 250,
      child: ClipRRect(
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(10), bottomRight: Radius.circular(10)),
          child: Drawer(
            key: _scaffoldKey,
            child: Material(
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      color: context.primaryColor,
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.topCenter,
                            child: Column(
                              children: [
                                Container(
                                  child: Material(
                                    color: Theme.of(context).highlightColor,
                                    child: Ink(
                                      decoration: BoxDecoration(),
                                      child: InkWell(
                                        customBorder: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(10),
                                                bottomRight:
                                                    Radius.circular(10))),
                                        splashColor: skyBlue,
                                        onTap: () {
                                          Share.share(
                                              'https://play.google.com/store/apps/details?id=${info.packageName}',
                                              subject:
                                                  "Tap on link to download this app");
                                        },
                                        child: ListTile(
                                          leading: ConstrainedBox(
                                            constraints: BoxConstraints(
                                              minWidth: 22,
                                              minHeight: 22,
                                              maxWidth: 22,
                                              maxHeight: 22,
                                            ),
                                            child: Image.asset(
                                                'assets/images/share.png',
                                                color: Colors.grey,
                                                fit: BoxFit.cover),
                                          ),
                                          title: Text(
                                            "Share App",
                                            style: TextStyle(
                                                color: context.accentColor,
                                                fontFamily: "Circular Medium"),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ).cornerRadius(10).px(10).pOnly(top: 10),
                                ),
                                Material(
                                  color: Theme.of(context).highlightColor,
                                  child: Ink(
                                    decoration: BoxDecoration(),
                                    child: InkWell(
                                      customBorder: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10),
                                              bottomRight:
                                                  Radius.circular(10))),
                                      splashColor: skyBlue,
                                      onTap: () {
                                        Links.rateDialog = false;
                                        CommanDialog.showRatingDialog(context);
                                        _scaffoldKey
                                            .currentState!.isEndDrawerOpen;
                                      },
                                      child: ListTile(
                                        leading: ConstrainedBox(
                                          constraints: BoxConstraints(
                                            minWidth: 25,
                                            minHeight: 25,
                                            maxWidth: 25,
                                            maxHeight: 25,
                                          ),
                                          child: Image.asset(
                                              'assets/images/rate.png',
                                              color: Colors.grey,
                                              fit: BoxFit.cover),
                                        ),
                                        title: Text(
                                          "Rate App",
                                          style: TextStyle(
                                              color: context.accentColor,
                                              fontFamily: "Circular Medium"),
                                        ),
                                      ),
                                    ),
                                  ),
                                ).cornerRadius(10).px(10).pOnly(top: 10),
                                Material(
                                  color: Theme.of(context).highlightColor,
                                  child: Ink(
                                    decoration: BoxDecoration(),
                                    child: InkWell(
                                      customBorder: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10),
                                              bottomRight:
                                                  Radius.circular(10))),
                                      splashColor: skyBlue,
                                      onTap: () {
                                        Share.share('link here',
                                            subject: "Give feedback");
                                      },
                                      child: ListTile(
                                        leading: ConstrainedBox(
                                          constraints: BoxConstraints(
                                            minWidth: 25,
                                            minHeight: 25,
                                            maxWidth: 25,
                                            maxHeight: 25,
                                          ),
                                          child: Image.asset(
                                              'assets/images/feedback.png',
                                              color: Colors.grey,
                                              fit: BoxFit.cover),
                                        ),
                                        title: Text(
                                          "FeedBack",
                                          style: TextStyle(
                                              color: context.accentColor,
                                              fontFamily: "Circular Medium"),
                                        ),
                                      ),
                                    ),
                                  ),
                                ).cornerRadius(10).px(10).pOnly(top: 10),
                                Material(
                                  color: Theme.of(context).highlightColor,
                                  child: Ink(
                                    decoration: BoxDecoration(),
                                    child: InkWell(
                                      customBorder: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(10),
                                              bottomRight:
                                                  Radius.circular(10))),
                                      splashColor: skyBlue,
                                      onTap: () {
                                        Share.share(Links.privacyLink);
                                      },
                                      child: ListTile(
                                          leading: ConstrainedBox(
                                            constraints: BoxConstraints(
                                              minWidth: 25,
                                              minHeight: 25,
                                              maxWidth: 25,
                                              maxHeight: 25,
                                            ),
                                            child: Image.asset(
                                                'assets/images/privacy.png',
                                                color: Colors.grey,
                                                fit: BoxFit.cover),
                                          ),
                                          title: Text(
                                            "Privacy Policy",
                                            style: TextStyle(
                                                color: context.accentColor,
                                                fontFamily: "Circular Medium"),
                                          )),
                                    ),
                                  ),
                                ).cornerRadius(10).px(10).pOnly(top: 10),
                                ToggleSwitch(
                                  minHeight: 35,
                                  cornerRadius: 20.0,
                                  activeBgColors: [
                                    [Colors.green],
                                    [Colors.black87]
                                  ],
                                  activeFgColor: Colors.white,
                                  inactiveBgColor:
                                      Theme.of(context).highlightColor,
                                  inactiveFgColor:
                                      Theme.of(context).accentColor,
                                  initialLabelIndex: themeController.dayOrNight,
                                  totalSwitches: 2,
                                  labels: ['Day', 'Night'],
                                  radiusStyle: true,
                                  onToggle: (index) {
                                    changing(context, themeController, index);
                                  },
                                ).py(20)
                              ],
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Opacity(
                              opacity: 0.7,
                              child: Image.asset(
                                "assets/images/ic_drawer_bg.png",
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ).cornerRadius(12),
          )),
    ).pOnly(top: 30);
  }
}

Future<void> setThemeMode(String mode) async {
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.setString('mode', mode);
}

Future<void> changing(
    BuildContext context, ThemeController themeController, int index) async {
  if (index == 1) {
    setThemeMode("light");
    themeController.getThemeMode(context);
    themeController.changeTheme(context, ThemeMode.light);
  } else {
    setThemeMode("dark");
    themeController.getThemeMode(context);
    themeController.changeTheme(context, ThemeMode.dark);
  }
}
