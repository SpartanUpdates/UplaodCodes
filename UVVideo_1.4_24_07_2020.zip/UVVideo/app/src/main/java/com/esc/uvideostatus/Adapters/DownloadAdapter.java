package com.esc.uvideostatus.Adapters;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.esc.uvideostatus.Fragments.DownloadFragment;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.FontTextView;
import java.util.ArrayList;
import java.util.List;

public class DownloadAdapter extends Adapter<RecyclerView.ViewHolder> {
    public List<VideoData> VideoList = new ArrayList();
    public Activity context;
    DownloadFragment downloadFragment;
    private boolean isLoading;
    private boolean loading;

    public class ViewHolder extends RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;
        public FontTextView tvlike;
        public FontTextView tvtitle;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvlike = view.findViewById(R.id.tvlike);
        }
    }

    public DownloadAdapter(Activity activity, ArrayList<VideoData> arrayList, DownloadFragment downloadFragment2) {
        this.VideoList = arrayList;
        this.context = activity;
        this.downloadFragment = downloadFragment2;
        notifyDataSetChanged();
        this.isLoading = false;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.download_layout, viewGroup, false);
        return new ViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, final int i) {

        VideoData videoData = this.VideoList.get(i);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.tvVideoListingName.setText(videoData.getTitle());
        viewHolder2.tvlike.setText(videoData.getSize());
        viewHolder2.llVideoList.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DownloadAdapter.this.downloadFragment.playVideo(DownloadAdapter.this.VideoList.get(i));
            }
        });
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.video_placeholder);
        requestOptions.error(R.drawable.video_placeholder);
        Glide.with(this.context).load(videoData.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
    }


    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        this.VideoList = new ArrayList();
        StringBuilder sb = new StringBuilder();
        sb.append("addAll12346: ");
        sb.append(this.VideoList.size());
        Log.d("TAG", sb.toString());
        int i = 3;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 10;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.VideoList.add(videoData);
                this.VideoList.add(list.get(i2));
            } else {
                this.VideoList.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("getItemCount: ");
        sb.append(this.VideoList.size());
        Log.d("TAG", sb.toString());
        return this.VideoList.size();
    }
}
