package com.esc.phoneheart.animations;

import android.animation.TimeInterpolator;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.esc.phoneheart.interfaceclass.AnimationStateChangedListener;

import java.lang.ref.WeakReference;

public class AnimationHandling extends Handler {
    public long mAnimationStartTime;
    public final WeakReference<CircleProgressView> mCircleViewWeakReference;
    public long mFrameStartTime = 0;
    public TimeInterpolator mInterpolator = new AccelerateDecelerateInterpolator();
    public double mLengthChangeAnimationDuration;
    public long mLengthChangeAnimationStartTime;
    public TimeInterpolator mLengthChangeInterpolator = new DecelerateInterpolator();
    public float mSpinningBarLengthStart;

    public static  class Animationhandling {
        public static final int[] a;
        public static final int[] b;

        static {
            int[] iArr = new int[AnimationState.values().length];
            b = iArr;
            try {
                iArr[AnimationState.IDLE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[AnimationState.SPINNING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[AnimationState.END_SPINNING.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                b[AnimationState.END_SPINNING_START_ANIMATING.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                b[AnimationState.ANIMATING.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr2 = new int[AnimationText.values().length];
            a = iArr2;
            iArr2[AnimationText.START_SPINNING.ordinal()] = 1;
            a[AnimationText.STOP_SPINNING.ordinal()] = 2;
            a[AnimationText.SET_VALUE.ordinal()] = 3;
            a[AnimationText.SET_VALUE_ANIMATED.ordinal()] = 4;
            try {
                a[AnimationText.TICK.ordinal()] = 5;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    public AnimationHandling(CircleProgressView circleProgressView) {
        super(circleProgressView.getContext().getMainLooper());
        this.mCircleViewWeakReference = new WeakReference(circleProgressView);
    }

    private boolean calcNextAnimationValue(CircleProgressView circleProgressView) {
        float currentTimeMillis = (float) (((double) (System.currentTimeMillis() - this.mAnimationStartTime)) / circleProgressView.m);
        if (currentTimeMillis > 1.0f) {
            currentTimeMillis = 1.0f;
        }
        float interpolation = this.mInterpolator.getInterpolation(currentTimeMillis);
        float f = circleProgressView.d;
        circleProgressView.b = f + ((circleProgressView.c - f) * interpolation);
        return currentTimeMillis >= 1.0f;
    }

    private void enterEndSpinning(CircleProgressView circleProgressView) {
        circleProgressView.q = AnimationState.END_SPINNING;
        initReduceAnimation(circleProgressView);
        AnimationStateChangedListener animationStateChangedListener = circleProgressView.r;
        if (animationStateChangedListener != null) {
            animationStateChangedListener.onAnimationStateChanged(circleProgressView.q);
        }
        sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
    }

    private void enterEndSpinningStartAnimating(CircleProgressView circleProgressView, Message message) {
        AnimationState animationState = AnimationState.END_SPINNING_START_ANIMATING;
        circleProgressView.q = animationState;
        AnimationStateChangedListener animationStateChangedListener = circleProgressView.r;
        if (animationStateChangedListener != null) {
            animationStateChangedListener.onAnimationStateChanged(animationState);
        }
        circleProgressView.d = 0.0f;
        circleProgressView.c = ((float[]) message.obj)[1];
        this.mLengthChangeAnimationStartTime = System.currentTimeMillis();
        this.mSpinningBarLengthStart = circleProgressView.h;
        sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
    }

    private void enterSetValueAnimated(Message message, CircleProgressView circleProgressView) {
        Object obj = message.obj;
        circleProgressView.d = ((float[]) obj)[0];
        circleProgressView.c = ((float[]) obj)[1];
        this.mAnimationStartTime = System.currentTimeMillis();
        AnimationState animationState = AnimationState.ANIMATING;
        circleProgressView.q = animationState;
        AnimationStateChangedListener animationStateChangedListener = circleProgressView.r;
        if (animationStateChangedListener != null) {
            animationStateChangedListener.onAnimationStateChanged(animationState);
        }
        sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
    }

    private void enterSpinning(CircleProgressView circleProgressView) {
        AnimationState animationState = AnimationState.SPINNING;
        circleProgressView.q = animationState;
        AnimationStateChangedListener animationStateChangedListener = circleProgressView.r;
        if (animationStateChangedListener != null) {
            animationStateChangedListener.onAnimationStateChanged(animationState);
        }
        float f = circleProgressView.e;
        float f2 = 360.0f / f;
        float f3 = circleProgressView.b;
        circleProgressView.h = f2 * f3;
        circleProgressView.j = (360.0f / f) * f3;
        this.mLengthChangeAnimationStartTime = System.currentTimeMillis();
        this.mSpinningBarLengthStart = circleProgressView.h;
        this.mLengthChangeAnimationDuration = (double) (((circleProgressView.i / circleProgressView.k) * ((float) circleProgressView.n)) * 2.0f);
        sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
    }

    private void initReduceAnimation(CircleProgressView circleProgressView) {
        this.mLengthChangeAnimationDuration = (double) (((circleProgressView.h / circleProgressView.k) * ((float) circleProgressView.n)) * 2.0f);
        this.mLengthChangeAnimationStartTime = System.currentTimeMillis();
        this.mSpinningBarLengthStart = circleProgressView.h;
    }

    private void setValue(Message message, CircleProgressView circleProgressView) {
        circleProgressView.d = circleProgressView.c;
        float f = ((float[]) message.obj)[0];
        circleProgressView.c = f;
        circleProgressView.b = f;
        AnimationState animationState = AnimationState.IDLE;
        circleProgressView.q = animationState;
        AnimationStateChangedListener animationStateChangedListener = circleProgressView.r;
        if (animationStateChangedListener != null) {
            animationStateChangedListener.onAnimationStateChanged(animationState);
        }
        circleProgressView.invalidate();
    }

    public void handleMessage(Message message) {
        CircleProgressView circleProgressView = (CircleProgressView) this.mCircleViewWeakReference.get();
        if (circleProgressView != null) {
            Enum enumR = AnimationText.values()[message.what];
            Enum enumR2 = AnimationText.TICK;
            if (enumR == enumR2) {
                removeMessages(enumR2.ordinal());
            }
            this.mFrameStartTime = SystemClock.uptimeMillis();
            int i = Animationhandling.b[circleProgressView.q.ordinal()];
            int i2;
            float f;
            float currentTimeMillis;
            AnimationState animationState;
            AnimationStateChangedListener animationStateChangedListener;
            if (i == 1) {
                i2 = Animationhandling.a[enumR.ordinal()];
                if (i2 == 1) {
                    enterSpinning(circleProgressView);
                } else if (i2 == 3) {
                    setValue(message, circleProgressView);
                } else if (i2 == 4) {
                    enterSetValueAnimated(message, circleProgressView);
                } else if (i2 == 5) {
                    removeMessages(AnimationText.TICK.ordinal());
                }
            } else if (i == 2) {
                i2 = Animationhandling.a[enumR.ordinal()];
                if (i2 == 2) {
                    enterEndSpinning(circleProgressView);
                } else if (i2 == 3) {
                    setValue(message, circleProgressView);
                } else if (i2 == 4) {
                    enterEndSpinningStartAnimating(circleProgressView, message);
                } else if (i2 == 5) {
                    f = circleProgressView.h - circleProgressView.i;
                    currentTimeMillis = (float) (((double) (System.currentTimeMillis() - this.mLengthChangeAnimationStartTime)) / this.mLengthChangeAnimationDuration);
                    if (currentTimeMillis > 1.0f) {
                        currentTimeMillis = 1.0f;
                    }
                    currentTimeMillis = this.mLengthChangeInterpolator.getInterpolation(currentTimeMillis);
                    if (Math.abs(f) < 1.0f) {
                        circleProgressView.h = circleProgressView.i;
                    } else {
                        f = circleProgressView.h;
                        float f2 = circleProgressView.i;
                        if (f < f2) {
                            f = this.mSpinningBarLengthStart;
                            circleProgressView.h = f + ((f2 - f) * currentTimeMillis);
                        } else {
                            f = this.mSpinningBarLengthStart;
                            circleProgressView.h = f - ((f - f2) * currentTimeMillis);
                        }
                    }
                    f = circleProgressView.j + circleProgressView.k;
                    circleProgressView.j = f;
                    if (f > 360.0f) {
                        circleProgressView.j = 0.0f;
                    }
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                    circleProgressView.invalidate();
                }
            } else if (i == 3) {
                i2 = Animationhandling.a[enumR.ordinal()];
                if (i2 == 1) {
                    animationState = AnimationState.SPINNING;
                    circleProgressView.q = animationState;
                    animationStateChangedListener = circleProgressView.r;
                    if (animationStateChangedListener != null) {
                        animationStateChangedListener.onAnimationStateChanged(animationState);
                    }
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                } else if (i2 == 3) {
                    setValue(message, circleProgressView);
                } else if (i2 == 4) {
                    enterEndSpinningStartAnimating(circleProgressView, message);
                } else if (i2 == 5) {
                    f = (float) (((double) (System.currentTimeMillis() - this.mLengthChangeAnimationStartTime)) / this.mLengthChangeAnimationDuration);
                    if (f > 1.0f) {
                        f = 1.0f;
                    }
                    currentTimeMillis = this.mSpinningBarLengthStart * (1.0f - this.mLengthChangeInterpolator.getInterpolation(f));
                    circleProgressView.h = currentTimeMillis;
                    circleProgressView.j += circleProgressView.k;
                    if (currentTimeMillis < 0.01f) {
                        animationState = AnimationState.IDLE;
                        circleProgressView.q = animationState;
                        animationStateChangedListener = circleProgressView.r;
                        if (animationStateChangedListener != null) {
                            animationStateChangedListener.onAnimationStateChanged(animationState);
                        }
                    }
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                    circleProgressView.invalidate();
                }
            } else if (i == 4) {
                i2 = Animationhandling.a[enumR.ordinal()];
                if (i2 == 1) {
                    circleProgressView.o = false;
                    enterSpinning(circleProgressView);
                } else if (i2 == 3) {
                    circleProgressView.o = false;
                    setValue(message, circleProgressView);
                } else if (i2 == 4) {
                    circleProgressView.d = 0.0f;
                    circleProgressView.c = ((float[]) message.obj)[1];
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                } else if (i2 == 5) {
                    if (circleProgressView.h > circleProgressView.i && !circleProgressView.o) {
                        f = (float) (((double) (System.currentTimeMillis() - this.mLengthChangeAnimationStartTime)) / this.mLengthChangeAnimationDuration);
                        if (f > 1.0f) {
                            f = 1.0f;
                        }
                        circleProgressView.h = this.mSpinningBarLengthStart * (1.0f - this.mLengthChangeInterpolator.getInterpolation(f));
                    }
                    f = circleProgressView.j + circleProgressView.k;
                    circleProgressView.j = f;
                    if (f > 360.0f && !circleProgressView.o) {
                        this.mAnimationStartTime = System.currentTimeMillis();
                        circleProgressView.o = true;
                        initReduceAnimation(circleProgressView);
                        AnimationStateChangedListener animationStateChangedListener2 = circleProgressView.r;
                        if (animationStateChangedListener2 != null) {
                            animationStateChangedListener2.onAnimationStateChanged(AnimationState.START_ANIMATING_AFTER_SPINNING);
                        }
                    }
                    if (circleProgressView.o) {
                        circleProgressView.j = 360.0f;
                        circleProgressView.h -= circleProgressView.k;
                        calcNextAnimationValue(circleProgressView);
                        f = (float) (((double) (System.currentTimeMillis() - this.mLengthChangeAnimationStartTime)) / this.mLengthChangeAnimationDuration);
                        if (f > 1.0f) {
                            f = 1.0f;
                        }
                        circleProgressView.h = this.mSpinningBarLengthStart * (1.0f - this.mLengthChangeInterpolator.getInterpolation(f));
                    }
                    if (((double) circleProgressView.h) < 0.1d) {
                        animationState = AnimationState.ANIMATING;
                        circleProgressView.q = animationState;
                        animationStateChangedListener = circleProgressView.r;
                        if (animationStateChangedListener != null) {
                            animationStateChangedListener.onAnimationStateChanged(animationState);
                        }
                        circleProgressView.invalidate();
                        circleProgressView.o = false;
                        circleProgressView.h = circleProgressView.i;
                    } else {
                        circleProgressView.invalidate();
                    }
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                }
            } else if (i == 5) {
                i2 = Animationhandling.a[enumR.ordinal()];
                if (i2 == 1) {
                    enterSpinning(circleProgressView);
                } else if (i2 == 3) {
                    setValue(message, circleProgressView);
                } else if (i2 == 4) {
                    this.mAnimationStartTime = System.currentTimeMillis();
                    circleProgressView.d = circleProgressView.b;
                    circleProgressView.c = ((float[]) message.obj)[1];
                } else if (i2 == 5) {
                    if (calcNextAnimationValue(circleProgressView)) {
                        animationState = AnimationState.IDLE;
                        circleProgressView.q = animationState;
                        animationStateChangedListener = circleProgressView.r;
                        if (animationStateChangedListener != null) {
                            animationStateChangedListener.onAnimationStateChanged(animationState);
                        }
                        circleProgressView.b = circleProgressView.c;
                    }
                    sendEmptyMessageDelayed(AnimationText.TICK.ordinal(), ((long) circleProgressView.n) - (SystemClock.uptimeMillis() - this.mFrameStartTime));
                    circleProgressView.invalidate();
                }
            }
        }
    }

    public void setLengthChangeInterpolator(TimeInterpolator timeInterpolator) {
        this.mLengthChangeInterpolator = timeInterpolator;
    }

    public void setValueInterpolator(TimeInterpolator timeInterpolator) {
        this.mInterpolator = timeInterpolator;
    }
}
