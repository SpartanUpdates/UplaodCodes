package com.esc.photovault.activity;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.esc.photovault.service.GPSTracker;
import com.esc.photovault.util.Utils.permission;

public class MainActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT = 1;
    Double latitude = Double.valueOf(0.0d);
    Double longitude = Double.valueOf(0.0d);

    class C06141 implements OnClickListener {
        C06141() {
        }

        public void onClick(DialogInterface dialog, int which) {
            MainActivity.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        }
    }

    class C06152 implements Runnable {
        C06152() {
        }

        public void run() {
            MainActivity.this.startActivity(new Intent(MainActivity.this, LockScreenActivity.class));
            MainActivity.this.finish();
        }
    }

    class C06163 implements Runnable {
        C06163() {
        }

        public void run() {
            MainActivity.this.startActivity(new Intent(MainActivity.this, LockScreenActivity.class));
            MainActivity.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != 1) {
        } else if (permissions.length == 1 && permissions[0] == permission.ACCESS_FINE_LOCATION && grantResults[0] == 0 && permissions.length == 1 && permissions[1] == permission.WRITE_EXTERNAL_STORAGE && grantResults[2] == 0 && permissions[2] == permission.CAMERA && grantResults[2] == 0 && permissions[2] == permission.READ_EXTERNAL_STORAGE && grantResults[2] == 0) {
        }
    }

    public void currentlocation() {
        GPSTracker tracker = new GPSTracker(this);
        if (tracker.canGetLocation()) {
            this.latitude = Double.valueOf(tracker.getLatitude());
            this.longitude = Double.valueOf(tracker.getLongitude());
            check_permission();
            return;
        }
        Builder alertDialog = new Builder(this);
        alertDialog.setTitle("Failed to fetch user location!");
        alertDialog.setMessage("Please enable user location for app, location is required for app to work properly");
        alertDialog.setPositiveButton("OK", new C06141());
        alertDialog.show();
    }

    protected void onResume() {
        if (this.latitude.doubleValue() == 0.0d) {
            currentlocation();
        } else {
            check_permission();
        }
        super.onResume();
    }

    public void check_permission() {
        if (ContextCompat.checkSelfPermission(this, permission.ACCESS_COARSE_LOCATION) == 0 || ContextCompat.checkSelfPermission(this, permission.ACCESS_FINE_LOCATION) == 0 || ContextCompat.checkSelfPermission(this, permission.CAMERA) == 0) {
            if (this.latitude.doubleValue() != 0.0d) {
                new Handler().postDelayed(new C06163(), 2000);
            } else {
                currentlocation();
            }
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission.ACCESS_COARSE_LOCATION) && ActivityCompat.shouldShowRequestPermissionRationale(this, permission.ACCESS_FINE_LOCATION) && ActivityCompat.shouldShowRequestPermissionRationale(this, permission.WRITE_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(this, permission.CAMERA)) {
            new Handler().postDelayed(new C06152(), (long) SPLASH_TIME_OUT);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{permission.ACCESS_COARSE_LOCATION, permission.ACCESS_FINE_LOCATION, permission.WRITE_EXTERNAL_STORAGE, permission.CAMERA, permission.READ_EXTERNAL_STORAGE}, 1);
        }
    }
}
