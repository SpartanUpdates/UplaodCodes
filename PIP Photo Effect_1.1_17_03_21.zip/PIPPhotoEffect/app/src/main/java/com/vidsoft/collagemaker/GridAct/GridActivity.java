package com.vidsoft.collagemaker.GridAct;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import com.google.android.material.snackbar.Snackbar;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.MaterialDialog.Builder;
import com.afollestad.materialdialogs.MaterialDialog.InputCallback;
import com.afollestad.materialdialogs.MaterialDialog.SingleButtonCallback;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.michael.easydialog.EasyDialog;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.vidsoft.Filters.AllStickerSupports.DrawableSticker;
import com.vidsoft.Filters.AllStickerSupports.FontProvider;
import com.vidsoft.Filters.AllStickerSupports.StickerView;
import com.vidsoft.Filters.AllStickerSupports.TextSticker;
import com.vidsoft.Filters.scrollgalleryview.Grid3DFilter.PorterShapeImageView;
import com.vidsoft.collagemaker.Activity.MainActivity;
import com.vidsoft.collagemaker.Activity.PhotoEditingActivity;
import com.vidsoft.collagemaker.Activity.ShareActivity;
import com.vidsoft.collagemaker.Adapters.BottomAdapter;
import com.vidsoft.collagemaker.Adapters.BottomAdapter.BottomCallback;
import com.vidsoft.collagemaker.Adapters.ColorAdapter;
import com.vidsoft.collagemaker.Adapters.FontStickerAdapter;
import com.vidsoft.collagemaker.Adapters.FontStickerAdapter.FontStickerCallBack;
import com.vidsoft.collagemaker.Adapters.FontsAdapter;
import com.vidsoft.collagemaker.Adapters.FontsPatternAdapter;
import com.vidsoft.collagemaker.Adapters.FrameAdapter;
import com.vidsoft.collagemaker.Adapters.GridAdapter;
import com.vidsoft.collagemaker.Adapters.GridAdapter.GridCallback;
import com.vidsoft.collagemaker.Adapters.PatternAdapter;
import com.vidsoft.collagemaker.Adapters.RatioAdapter;
import com.vidsoft.collagemaker.Adapters.SubPatternAdapter;
import com.vidsoft.collagemaker.Model.Frame;
import com.vidsoft.collagemaker.Model.Grid;
import com.vidsoft.collagemaker.Model.Margin;
import com.vidsoft.collagemaker.Model.Ratio;
import com.vidsoft.collagemaker.Model.StickerData;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.CompressImage;
import com.vidsoft.collagemaker.Utils.Const;
import com.vidsoft.collagemaker.Utils.DataBinder;
import com.vidsoft.collagemaker.Utils.MyDragShadowBuilder;
import com.vidsoft.collagemaker.Utils.RecyclerItemClickListener;
import com.vidsoft.collagemaker.Utils.Stickers.CustomStckerTextView;
import com.vidsoft.collagemaker.Utils.Stickers.StickerAdapter;
import com.vidsoft.collagemaker.Utils.Stickers.StickerViewnew;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import carbon.widget.FrameLayout;
import id.zelory.compressor.Compressor;
import me.zhanghai.android.materialprogressbar.BuildConfig;

public class GridActivity extends AppCompatActivity implements OnSeekBarChangeListener, OnTouchListener, OnClickListener, GridCallback, BottomCallback, FontStickerCallBack {

    RecyclerView rvFontlist;
    RecyclerView rvFontpattern_list;
    RecyclerView rvFontshadow_color;
    ColorAdapter fontColorAdapter;
    ColorAdapter fontColoradapter1;
    List<String> fonts;
    FontsAdapter fontsAdapter;
    FontsPatternAdapter fontsPatternAdapter;
    ColorAdapter Adapter_fontshadow;
    FrameAdapter frameAdapter;
    ArrayList<Frame> frameArrayList;
    FrameLayout[] frameLayoutArray;
    int fullMargin;
    LinearLayout ll_goBackPattern;
    GridAdapter gridAdapter;
    ArrayList<Grid> gridArrayList;
    int gridType;
    RecyclerView rvViewcolor;
    RecyclerView rvColor1;
    ColorAdapter gridcolorAdapter;
    ColorAdapter gridcolorAdapter1;
    View layoutView;
    LinearLayout ll_border_main;
    LinearLayout ll_color_main;
    LinearLayout ll_frameborder_main;
    LinearLayout ll_grid_main;
    LinearLayout ll_pattern_main;
    LinearLayout ll_ratio_main;
    LinearLayout ll_text_main;
    LayoutParams[] ll_LayoutParamses;
    LinearLayout linearFontView;
    int anInt;
    int anInt1;
    Activity activity;
    int backgroundPattern;
    Blur blur;
    int blur_effects;
    SeekBar blurFontstickerseekbar;
    int blurVal;
    RelativeLayout borderrelative;
    int borderWidth;
    BottomAdapter bottom_adapter;
    RelativeLayout captureMain_RLayout;
    ArrayList<Integer> colors11;
    ArrayList<Integer> colors22;
    ArrayList<Integer> colors33;
    int cornerRadius;
    int currentLayout;
    FontProvider fontprovider;
    FontStickerAdapter fontStickerAdapter;
    RecyclerView rvFontcolor;
    RecyclerView rvFontcolor1;
    ArrayList<Ratio> ratioArrayList;
    RecyclerView rc_MainView;
    LinearLayoutManager ll_Manager_grid_color;
    LinearLayoutManager ll_Manager_grid_color1;
    LinearLayoutManager ll_Manager_main;
    SeekBar border_SeekBar;
    RecyclerView rc_PatternSub;
    RecyclerView rc_Ratio;
    RelativeLayout[] relativeLayoutArray;
    int[] resourceFrameLayout;
    int[] resourceRelativeLayout;
    int[] resourceTouchImageView;
    LinearLayoutManager linearLayoutManager;
    LinearLayoutManager ll_ManagerBottom;
    LinearLayoutManager ll_ManagerFrame;
    LinearLayoutManager ll_grid;
    LinearLayoutManager ll_ManagerRatio;
    LinearLayoutManager ll_ManagerSub;
    LinearLayoutManager ll_Manager_font;
    LinearLayoutManager ll_Manager_font_color;
    RecyclerView rc_Bottom;
    RecyclerView rc_Frame;
    RecyclerView rc_Grid;
    RecyclerView rc_Pattern;
    TextView tvInner;
    SubPatternAdapter subPatternAdapter;
    TextSticker tempSticker;
    LinearLayout textBlurView;
    LinearLayout textBlurViewBack;
    LinearLayout textColorView;
    LinearLayout textColorViewBack;
    LinearLayout textFontView;
    LinearLayout textFontViewBack;
    LinearLayout textPatternView;
    TextView tvNormal;
    TextView tvOriginal;
    TextView tvOuter;
    TextView tvSolid;
    ViewPager viewPager;
    SmartTabLayout smartTabLayout;
    private ArrayList<Integer> stickerlist;
    private StickerAdapter stickerAdapter;
    private ArrayList<View> views;
    private CustomStckerTextView currentTextView;
    private StickerViewnew currentView;
    public static Bitmap mBitmap;
    public static String str_urlShareimg;
    int marginLayout;
    PatternAdapter patternAdapter;
    LinearLayoutManager ll_Manager_font_color1;
    LinearLayoutManager ll_Manager_font_pattern_list;
    LinearLayoutManager ll_Manager_font_shadow_color;
    SeekBar cornerSeekbar;
    int mHeight;
    LayoutParams mainviewParams;
    int mPicFrameCount;
    SeekBar spaceSeekbar;
    int mWidth;
    LinearLayout ll_mainFrame;
    LinearLayout ll_mainFrameLayout;
    LinearLayout ll_mainLayout;
    ArrayList<Margin> marginArrayList;
    LinearLayout text_pattern_view_back;
    LinearLayout text_shadow_view;
    LinearLayout text_shadow_view_back;
    PorterShapeImageView[] touchImageViewArray;
    TextView tvDeboss;
    TextView tvEmboss;
    int[] patternData;
    int patternImage;
    int picChangePosition;
    int positionMainPattern;
    SeekBar radiusSeekbar;
    RatioAdapter ratioAdapter;
    int[] rotationUnits;
    int space;
    TextSticker txt_sticker;
    LinearLayout ll_stickerCheck;
    TextView txt_stickerCount;
    LinearLayout ll_stickerCross;
    LinearLayout ll_stickerFullLayout;
    StickerView stickerView;
    ArrayList<String> stringArrayList;
    LinearLayout ll_subPattern;

    ImageView ivback;
    TextView tvSave;

    public class fetchSticker extends AsyncTask<String, Void, Void> {
        protected Void doInBackground(String... params) {
            int j = 0;
            while (j <= 391) {
                try {
                    MainActivity.stickerArrayList.add(new StickerData("s" + j, false));
                    j++;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        protected void onPreExecute() {
            MainActivity.stickerArrayList.clear();
            super.onPreExecute();
        }

        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    public class swapImages extends AsyncTask<String, Void, Void> {
        Bitmap bitmap;
        Bitmap bitmap1;
        PorterShapeImageView from;
        String path;
        String path1;
        ProgressDialog progressDialog;
        PorterShapeImageView to;

        public swapImages(String path, String path1, PorterShapeImageView from, PorterShapeImageView to) {
            this.path = path;
            this.path1 = path1;
            this.from = from;
            this.to = to;
        }

        protected Void doInBackground(String... params) {
            try {
                this.bitmap = Compressor.getDefault(GridActivity.this.activity).compressToBitmap(new File(this.path));
                this.bitmap1 = Compressor.getDefault(GridActivity.this.activity).compressToBitmap(new File(this.path1));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPreExecute() {
            this.progressDialog = new ProgressDialog(GridActivity.this.activity);
            this.progressDialog.setCancelable(false);
            this.progressDialog.setMessage("Please wait...");
            this.progressDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(Void aVoid) {
            this.from.setImageBitmap(this.bitmap);
            this.to.setImageBitmap(this.bitmap1);
            this.progressDialog.dismiss();
            super.onPostExecute(aVoid);
        }
    }

    public GridActivity() {
        this.activity = this;
        this.stringArrayList = new ArrayList();
        this.fullMargin = 6;
        this.gridArrayList = new ArrayList();
        this.resourceFrameLayout = new int[]{R.id.framely_1, R.id.frame_2, R.id.frame_3, R.id.frame_4, R.id.frame_5, R.id.frame_6, R.id.frame_7, R.id.frame_8, R.id.frame_9};
        this.resourceRelativeLayout = new int[]{R.id.rel_1, R.id.rel_2, R.id.rel_3, R.id.rel_4, R.id.rel_5, R.id.rel_6, R.id.rel_7, R.id.rel_8, R.id.rel_9};
        this.resourceTouchImageView = new int[]{R.id.image_1, R.id.image_2, R.id.image_3, R.id.image_4, R.id.image_5, R.id.image_6, R.id.image_7, R.id.image_8, R.id.image_9};
        this.marginArrayList = new ArrayList();
        this.cornerRadius = 10;
        this.borderWidth = 6;
        this.space = 6;
        this.ratioArrayList = new ArrayList();
        this.patternImage = Color.parseColor("#ffffff");
        this.backgroundPattern = 0;
        this.frameArrayList = new ArrayList();
        this.tempSticker = null;
        this.anInt = R.color.BG_Color;
        this.anInt1 = 2;
        this.blur_effects = 0;
        this.blurVal = 8;
        this.blur = Blur.NORMAL;
        this.patternData = DataBinder.fetchPatternData();
        this.colors11 = new ArrayList();
        this.colors22 = new ArrayList();
        this.colors33 = new ArrayList();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grid_act);
        this.views = new ArrayList();
        bindToolbar();
        bindContols();
        loadAd();
        addBottomLayoutData();
        clickEvents();
        addGrid();
        setupLayout();
        openDialog();
        textSticker();
    }

    public void addGrid() {
        this.stringArrayList = getIntent().getExtras().getStringArrayList(Const.imgList);
        this.mPicFrameCount = this.stringArrayList.size();
        this.gridArrayList.clear();
        this.gridArrayList = DataBinder.fetchGridData(this.mPicFrameCount);
        this.gridAdapter = new GridAdapter(this.activity, this.gridArrayList);
        this.rc_Grid.setAdapter(this.gridAdapter);
        this.currentLayout = this.gridArrayList.get(0).getLayout();
        this.marginLayout = this.gridArrayList.get(0).getTitle();
        this.gridType = this.gridArrayList.get(0).getType();
    }

    private void addBottomLayoutData() {
        changeVisibility(Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
        this.bottom_adapter = new BottomAdapter(this.activity, new int[]{
                R.drawable.gridlayout,
                R.drawable.adjust_btn,
                R.drawable.gridbackground,
                R.drawable.colorpicer_back,
                R.drawable.grid_frame,
                R.drawable.smile,
                R.drawable.font,
                R.drawable.image_ratio});
        this.rc_Bottom.setAdapter(this.bottom_adapter);
        this.gridcolorAdapter = new ColorAdapter(this.activity, DataBinder.fetchPrimaryColor());
        this.gridcolorAdapter.setSelection(19);
        this.rvViewcolor.setAdapter(this.gridcolorAdapter);
        this.gridcolorAdapter1 = new ColorAdapter(this.activity, DataBinder.fetchSecondaryColor(0));
        this.rvColor1.setAdapter(this.gridcolorAdapter1);
        this.patternAdapter = new PatternAdapter(this.activity, DataBinder.fetchMainPattern());
        this.rc_Pattern.setAdapter(this.patternAdapter);
        this.frameArrayList.clear();
        this.frameArrayList = DataBinder.fetchFrame();
        this.frameAdapter = new FrameAdapter(this.activity, this.frameArrayList);
        this.rc_Frame.setAdapter(this.frameAdapter);
        this.ratioArrayList.clear();
        this.ratioArrayList = DataBinder.fetchRatio();
        this.ratioAdapter = new RatioAdapter(this.activity, this.ratioArrayList);
        this.rc_Ratio.setAdapter(this.ratioAdapter);
    }

    private void setupLayout() {
        int i;
        this.layoutView = getLayoutInflater().inflate(this.currentLayout, this.ll_mainFrameLayout, false);
        this.ll_mainFrameLayout.addView(this.layoutView);
        this.ll_mainFrame = this.layoutView.findViewById(R.id.mainFrame);
        this.rotationUnits = new int[this.mPicFrameCount];
        this.touchImageViewArray = new PorterShapeImageView[this.mPicFrameCount];
        this.frameLayoutArray = new FrameLayout[this.mPicFrameCount];
        for (i = 0; i < this.mPicFrameCount; i++) {
            this.rotationUnits[i] = 0;
            this.touchImageViewArray[i] = this.layoutView.findViewById(this.resourceTouchImageView[i]);
            this.frameLayoutArray[i] = this.layoutView.findViewById(this.resourceFrameLayout[i]);
            frameLayoutArray[i].setCornerRadius(this.cornerRadius);
        }
        for (i = 0; i < this.mPicFrameCount; i++) {
            this.touchImageViewArray[i].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.stringArrayList.get(i))));
            this.touchImageViewArray[i].setTag(this.stringArrayList.get(i));
            this.touchImageViewArray[i].setOnClickListener(this);
        }
        if (this.gridType == 1) {
            this.ll_LayoutParamses = new LayoutParams[this.mPicFrameCount];
            for (i = 0; i < this.mPicFrameCount; i++) {
                this.ll_LayoutParamses[i] = (LayoutParams) this.frameLayoutArray[i].getLayoutParams();
            }
        } else {
            this.relativeLayoutArray = new RelativeLayout[this.mPicFrameCount];
            for (i = 0; i < this.mPicFrameCount; i++) {
                this.relativeLayoutArray[i] = this.layoutView.findViewById(this.resourceRelativeLayout[i]);
            }
        }
        dragdrop();
        addMargins(this.marginLayout);
        setSpace(this.space);
    }

    private void addMargins(int position) {
        this.marginArrayList.clear();
        this.marginArrayList = DataBinder.fetchMargins(position);
        int i;
        if (this.gridType == 1) {
            for (i = 0; i < this.mPicFrameCount; i++) {
                this.ll_LayoutParamses[i].setMargins(this.marginArrayList.get(i).getLeft(), this.marginArrayList.get(i).getTop(), this.marginArrayList.get(i).getRight(), this.marginArrayList.get(i).getBottom());
                this.frameLayoutArray[i].setLayoutParams(this.ll_LayoutParamses[i]);
            }
            return;
        }
        for (i = 0; i < this.mPicFrameCount; i++) {
            this.relativeLayoutArray[i].setPadding(this.fullMargin, this.fullMargin, this.fullMargin, this.fullMargin);
        }
    }

    private void setBorder(int paramInt) {
        for (int i = 0; i < this.mPicFrameCount; i++) {
            int left;
            int top;
            int right;
            int bottom;
            if (this.marginArrayList.get(i).getLeft() == 6) {
                left = 1;
            } else {
                left = 2;
            }
            if (this.marginArrayList.get(i).getTop() == 6) {
                top = 1;
            } else {
                top = 2;
            }
            if (this.marginArrayList.get(i).getRight() == 6) {
                right = 1;
            } else {
                right = 2;
            }
            if (this.marginArrayList.get(i).getBottom() == 6) {
                bottom = 1;
            } else {
                bottom = 2;
            }
            float f_left = ((float) paramInt) / ((float) left);
            float f_top = ((float) paramInt) / ((float) top);
            float f_right = ((float) paramInt) / ((float) right);
            float f_bottom = ((float) paramInt) / ((float) bottom);
            if (this.gridType == 1) {
                this.ll_LayoutParamses[i].setMargins(paramInt / left, paramInt / top, paramInt / right, paramInt / bottom);
                this.frameLayoutArray[i].setLayoutParams(this.ll_LayoutParamses[i]);
            } else {
                this.relativeLayoutArray[i].setPadding(paramInt, paramInt, paramInt, paramInt);
            }
        }
    }

    public void dragdrop() {
        for (int i = 0; i < this.touchImageViewArray.length; i++) {
            this.touchImageViewArray[i].setOnLongClickListener(new OnLongClickListener() {
                public boolean onLongClick(View v) {
                    v.startDrag(ClipData.newPlainText("test", "drag:"), new MyDragShadowBuilder(v), v, 0);
                    return true;
                }
            });
            this.touchImageViewArray[i].setOnDragListener(new OnDragListener() {

                class AnonymousClass1 implements Runnable {
                    final String val$path;
                    final String val$path1;

                    AnonymousClass1(String str, String str2) {
                        this.val$path = str;
                        this.val$path1 = str2;
                    }

                    public void run() {
                        int i = 0;
                        while (i < GridActivity.this.stringArrayList.size()) {
                            if (GridActivity.this.stringArrayList.get(i).equals(this.val$path) || GridActivity.this.stringArrayList.get(i).equals(this.val$path1)) {
                                GridActivity.this.rotationUnits[i] = 0;
                            }
                            i++;
                        }
                    }
                }

                public boolean onDrag(View v, DragEvent event) {
                    PorterShapeImageView from = (PorterShapeImageView) event.getLocalState();
                    PorterShapeImageView to = (PorterShapeImageView) v;
                    switch (event.getAction()) {
                        case 1:
                            return from != to;
                        case 2:
                            return true;
                        case 3:
                            String path = to.getTag().toString();
                            String path1 = from.getTag().toString();
                            to.setTag(path1);
                            from.setTag(path);
                            new swapImages(path, path1, from, to).execute();
                            AsyncTask.execute(new AnonymousClass1(path, path1));
                            return true;
                        case 4:
                            if (!event.getResult()) {
                                from.setImageBitmap(Compressor.getDefault(GridActivity.this.activity).compressToBitmap(new File(from.getTag().toString())));
                            }
                            return true;
                        case 5:
                            return true;
                        case 6:
                            return true;
                        default:
                            return false;
                    }
                }
            });
        }
    }

    public void GridMethod(int position) {
        this.ll_mainFrameLayout.removeAllViews();
        this.currentLayout = this.gridArrayList.get(position).getLayout();
        this.marginLayout = this.gridArrayList.get(position).getTitle();
        this.gridType = this.gridArrayList.get(position).getType();
        setupLayout();
        if (this.backgroundPattern == 1) {
            BitmapDrawable bitmapDrawable = new BitmapDrawable(BitmapFactory.decodeResource(getResources(), this.patternImage));
            if (this.positionMainPattern != 0) {
                bitmapDrawable.setTileModeXY(TileMode.REPEAT, TileMode.REPEAT);
            }
            this.ll_mainFrame.setBackgroundDrawable(bitmapDrawable);
        } else {
            this.ll_mainFrame.setBackgroundColor(this.patternImage);
        }
        for (int i = 0; i < this.mPicFrameCount; i++) {
            this.frameLayoutArray[i].setCornerRadius(this.cornerRadius);
            this.frameLayoutArray[i].invalidate();
        }
        setBorder(this.borderWidth);
    }

    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (seekBar.getId() == R.id.borderSeekBar) {
            this.borderWidth = progress;
            setBorder(this.borderWidth);
        } else if (seekBar.getId() == R.id.cornerSeekbar) {
            this.cornerRadius = progress;
            for (int i = 0; i < this.mPicFrameCount; i++) {
                this.frameLayoutArray[i].setCornerRadius(this.cornerRadius);
                this.frameLayoutArray[i].invalidate();
            }
        } else if (seekBar.getId() == R.id.spaceSeekbar) {
            this.space = progress;
            setSpace(this.space);
        }
    }

    public void setSpace(int progress) {
        this.ll_mainFrame.setPadding(progress, progress, progress, progress);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    private void bindContols() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.mHeight = displayMetrics.heightPixels;
        this.mWidth = displayMetrics.widthPixels;
        this.ll_mainFrameLayout = findViewById(R.id.mainFrameLayout);
        this.captureMain_RLayout = findViewById(R.id.rl_MaincaptureLayout);
        this.mainviewParams = (LayoutParams) this.captureMain_RLayout.getLayoutParams();
        this.mainviewParams.height = this.mWidth;
        this.mainviewParams.width = this.mWidth;
        this.captureMain_RLayout = findViewById(R.id.rl_MaincaptureLayout);
        this.rc_Bottom = findViewById(R.id.recyclerViewBottom);
        this.ll_ManagerBottom = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_Bottom.setLayoutManager(this.ll_ManagerBottom);
        this.rc_Grid = findViewById(R.id.recyclerViewGrid);
        this.ll_grid = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_Grid.setLayoutManager(this.ll_grid);
        this.ll_grid_main = findViewById(R.id.layout_grid_main);
        this.ll_pattern_main = findViewById(R.id.ll_patternmain);
        this.ll_color_main = findViewById(R.id.ll_Color);
        this.ll_border_main = findViewById(R.id.ll_bordermain);
        this.ll_ratio_main = findViewById(R.id.ll_ratiomain);
        this.ll_frameborder_main = findViewById(R.id.ll_frameborder);
        this.ll_text_main = findViewById(R.id.ll_text);
        this.border_SeekBar = findViewById(R.id.borderSeekBar);
        this.border_SeekBar.setOnSeekBarChangeListener(this);
        this.cornerSeekbar = findViewById(R.id.cornerSeekbar);
        this.cornerSeekbar.setOnSeekBarChangeListener(this);
        this.spaceSeekbar = findViewById(R.id.spaceSeekbar);
        this.spaceSeekbar.setOnSeekBarChangeListener(this);
        this.rvViewcolor = findViewById(R.id.color_grid);
        this.ll_Manager_grid_color = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvViewcolor.setLayoutManager(this.ll_Manager_grid_color);
        this.rvColor1 = findViewById(R.id.grid_color1);
        this.ll_Manager_grid_color1 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvColor1.setLayoutManager(this.ll_Manager_grid_color1);
        this.rc_Ratio = findViewById(R.id.recyclerViewRatio);
        this.ll_ManagerRatio = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_Ratio.setLayoutManager(this.ll_ManagerRatio);
        this.rc_Pattern = findViewById(R.id.recyclerViewPattern);
        this.linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_Pattern.setLayoutManager(this.linearLayoutManager);
        this.rc_PatternSub = findViewById(R.id.recyclerViewPatternSub);
        this.ll_ManagerSub = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_PatternSub.setLayoutManager(this.ll_ManagerSub);
        this.ll_subPattern = findViewById(R.id.ll_subPattern);
        this.ll_goBackPattern = findViewById(R.id.ll_goFromPattern);
        this.rc_Frame = findViewById(R.id.recyclerViewFrame);
        this.ll_ManagerFrame = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_Frame.setLayoutManager(this.ll_ManagerFrame);
        this.borderrelative = findViewById(R.id.Rl_border);
        this.ll_stickerCross = findViewById(R.id.stickerCross);
        this.ll_stickerCheck = findViewById(R.id.stickerCheck);
        this.txt_stickerCount = findViewById(R.id.stickerCount);
        this.ll_mainLayout = findViewById(R.id.mainLayout);
        this.ll_mainLayout.setVisibility(View.VISIBLE);
        this.ll_stickerFullLayout = findViewById(R.id.ll_sticker);
        this.ll_stickerFullLayout.setVisibility(View.GONE);
        this.stickerView = findViewById(R.id.stickerview);
        this.stickerView.setBackgroundColor(-1);
        this.stickerView.setLocked(false);
        this.stickerView.setConstrained(true);
        this.rc_MainView = findViewById(R.id.recyclerMainView);
        this.ll_Manager_main = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rc_MainView.setLayoutManager(this.ll_Manager_main);
        this.rvFontcolor = findViewById(R.id.font_color);
        this.ll_Manager_font_color = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvFontcolor.setLayoutManager(this.ll_Manager_font_color);
        this.rvFontcolor1 = findViewById(R.id.font_color1);
        this.ll_Manager_font_color1 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvFontcolor1.setLayoutManager(this.ll_Manager_font_color1);
        this.rvFontshadow_color = findViewById(R.id.rc_fontshadow);
        this.ll_Manager_font_shadow_color = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvFontshadow_color.setLayoutManager(this.ll_Manager_font_shadow_color);
        this.rvFontpattern_list = findViewById(R.id.rc_patternlist);
        this.ll_Manager_font_pattern_list = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvFontpattern_list.setLayoutManager(this.ll_Manager_font_pattern_list);
        this.rvFontlist = findViewById(R.id.rc_fontlist);
        this.ll_Manager_font = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.rvFontlist.setLayoutManager(this.ll_Manager_font);
        this.linearFontView = findViewById(R.id.Font_ll);
        this.textFontViewBack = findViewById(R.id.ll_textfontview_back);
        this.textFontView = findViewById(R.id.ll_textfont);
        this.textColorViewBack = findViewById(R.id.text_color_view_back);
        this.textColorView = findViewById(R.id.ll_textcolorview);
        this.text_shadow_view_back = findViewById(R.id.text_shadow_view_back);
        this.text_shadow_view = findViewById(R.id.ll_textshadow);
        this.radiusSeekbar = findViewById(R.id.radiusSeekbar);
        this.blurFontstickerseekbar = findViewById(R.id.blurFontStickerSeekbar);
        this.textBlurView = findViewById(R.id.text_blur_view);
        this.textBlurViewBack = findViewById(R.id.text_blur_view_back);
        this.textPatternView = findViewById(R.id.ll_textpattern);
        this.text_pattern_view_back = findViewById(R.id.textpatternview_back);
        this.tvOriginal = findViewById(R.id.tvOriginal);
        this.tvEmboss = findViewById(R.id.tvEmboss);
        this.tvDeboss = findViewById(R.id.tvDeboss);
        this.tvNormal = findViewById(R.id.tvNormal);
        this.tvSolid = findViewById(R.id.tvSolid);
        this.tvInner = findViewById(R.id.tvInner);
        this.tvOuter = findViewById(R.id.tvOuter);
    }

    private void bindToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        ivback = findViewById(R.id.iv_back);
        tvSave = findViewById(R.id.tv_save);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(getResources().getString(R.string.app_name));
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                GoBack();
            }
        });
        tvSave.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                saveprogress();
            }
        });
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    private void textSticker() {
        ArrayList<Integer> integerArrayList = new ArrayList();
        integerArrayList.add(Integer.valueOf(R.drawable.fonttexticon));
        integerArrayList.add(Integer.valueOf(R.drawable.textcoloricon));
        integerArrayList.add(Integer.valueOf(R.drawable.fonts));
        integerArrayList.add(Integer.valueOf(R.drawable.textshadow));
        integerArrayList.add(Integer.valueOf(R.drawable.text_pattern_btn));
        integerArrayList.add(Integer.valueOf(R.drawable.text_bg_btn));
        this.blurFontstickerseekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                } else if (GridActivity.this.blur_effects == 1) {
                    GridActivity.this.blurVal = progress + 1;
                    GridActivity.this.stickerView.setLayerType(1, null);
                    GridActivity.this.tempSticker.applyFilter(GridActivity.this.blur, GridActivity.this.blurVal);
                    GridActivity.this.stickerView.invalidate();
                }
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.radiusSeekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (GridActivity.this.tempSticker != null) {
                    GridActivity.this.anInt1 = progress;
                    GridActivity.this.tempSticker.setTextShadowColor(GridActivity.this.anInt1, GridActivity.this.anInt);
                    GridActivity.this.stickerView.invalidate();
                }
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.tvEmboss.setLayerType(1, null);
        this.tvEmboss.getPaint().setMaskFilter(new EmbossMaskFilter(new float[]{1.0f, 5.0f, 1.0f}, 0.8f, 8.0f, 7.0f));
        this.tvDeboss.setLayerType(1, null);
        this.tvDeboss.getPaint().setMaskFilter(new EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 13.0f, 7.0f));
        this.tvNormal.setLayerType(1, null);
        this.tvNormal.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.NORMAL));
        this.tvSolid.setLayerType(1, null);
        this.tvSolid.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.SOLID));
        this.tvInner.setLayerType(1, null);
        this.tvInner.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.INNER));
        this.tvOuter.setLayerType(1, null);
        this.tvOuter.getPaint().setMaskFilter(new BlurMaskFilter(8.0f, Blur.OUTER));
        for (int h = 0; h <= 360; h += 10) {
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.25f, 1.0f)));
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.5f, 1.0f)));
            this.colors22.add(Integer.valueOf(HSVColor((float) h, 0.75f, 1.0f)));
        }
        this.colors11 = DataBinder.fetchPrimaryColor();
        this.fontColorAdapter = new ColorAdapter(this.activity, this.colors11);
        this.fontColorAdapter.setSelection(20);
        this.rvFontcolor.setAdapter(this.fontColorAdapter);
        this.colors33 = DataBinder.fetchSecondaryColor(0);
        this.fontColoradapter1 = new ColorAdapter(this.activity, this.colors33);
        this.rvFontcolor1.setAdapter(this.fontColoradapter1);
        this.Adapter_fontshadow = new ColorAdapter(this.activity, this.colors22);
        this.rvFontshadow_color.setAdapter(this.Adapter_fontshadow);
        this.fontStickerAdapter = new FontStickerAdapter(this.activity, integerArrayList);
        this.rc_MainView.setAdapter(this.fontStickerAdapter);
        this.fontsPatternAdapter = new FontsPatternAdapter(this.activity, this.patternData);
        this.rvFontpattern_list.setAdapter(this.fontsPatternAdapter);
        this.fontprovider = new FontProvider(getResources());
        this.fonts = this.fontprovider.getFontNames();
        this.fontsAdapter = new FontsAdapter(this, this.fonts, this.fontprovider);
        this.rvFontlist.setAdapter(this.fontsAdapter);
        this.rvFontlist.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridActivity.this.tempSticker.setTypeface(GridActivity.this.fontprovider.getTypeface(GridActivity.this.fonts.get(position)));
                GridActivity.this.stickerView.invalidate();
                GridActivity.this.fontsAdapter.setSelection(position);
            }
        }));
        this.rvFontcolor1.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridActivity.this.tempSticker.setTextColor(GridActivity.this.colors33.get(position).intValue());
                GridActivity.this.stickerView.invalidate();
                GridActivity.this.fontColoradapter1.setSelection(position);
            }
        }));
        this.rvFontcolor.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridActivity.this.tempSticker.setTextColor(GridActivity.this.colors11.get(position).intValue());
                GridActivity.this.stickerView.invalidate();
                GridActivity.this.fontColorAdapter.setSelection(position);
                if (GridActivity.this.colors11.get(position).intValue() != Color.parseColor("#ffffff") && GridActivity.this.colors11.get(position).intValue() != Color.parseColor("#000000")) {
                    GridActivity.this.colors33 = DataBinder.fetchSecondaryColor(position);
                    GridActivity.this.fontColoradapter1 = new ColorAdapter(GridActivity.this.activity, GridActivity.this.colors33);
                    GridActivity.this.rvFontcolor1.setAdapter(GridActivity.this.fontColoradapter1);
                }
            }
        }));
        this.rvFontshadow_color.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridActivity.this.anInt = GridActivity.this.colors22.get(position).intValue();
                GridActivity.this.stickerView.setLayerType(2, null);
                GridActivity.this.tempSticker.setTextShadowColor(GridActivity.this.anInt1, GridActivity.this.anInt);
                GridActivity.this.stickerView.invalidate();
                GridActivity.this.Adapter_fontshadow.setSelection(position);
            }
        }));
        this.rvFontpattern_list.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (GridActivity.this.tempSticker == null) {
                    Snackbar.make(GridActivity.this.captureMain_RLayout, GridActivity.this.getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
                    return;
                }
                GridActivity.this.tempSticker.setShader(GridActivity.this.activity, BitmapFactory.decodeResource(GridActivity.this.getResources(), GridActivity.this.patternData[position]));
                GridActivity.this.stickerView.invalidate();
                GridActivity.this.fontsPatternAdapter.setSelection(position);
            }
        }));
        this.textColorViewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridActivity.this.textColorView.setVisibility(View.GONE);
                GridActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.text_shadow_view_back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GridActivity.this.text_shadow_view.setVisibility(View.GONE);
                GridActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.textBlurViewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GridActivity.this.textBlurView.setVisibility(View.GONE);
                GridActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.textFontViewBack.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridActivity.this.textFontView.setVisibility(View.GONE);
                GridActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
        this.text_pattern_view_back.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridActivity.this.textPatternView.setVisibility(View.GONE);
                GridActivity.this.linearFontView.setVisibility(View.VISIBLE);
            }
        });
    }

    public void FontStickerMethod(int position) {
        switch (position) {
            case 0:
                addTextSticker();
                break;
            case 1:
                colorFont();
                break;
            case 2:
                typeFont();
                break;
            case 3:
                shadowFont();
                break;
            case 4:
                blurFont();
                break;
            case 5:
                patternFont();
                break;
            default:
                break;
        }
    }

    public void addTextSticker() {
        new Builder(this.activity).title("Set Text").inputType(8289).inputRange(2, 100).onNegative(new SingleButtonCallback() {
            public void onClick(MaterialDialog dialog, DialogAction which) {
                dialog.dismiss();
            }
        }).negativeText("Cancel").positiveText("Set").input(BuildConfig.FLAVOR, BuildConfig.FLAVOR, false, new InputCallback() {
            public void onInput(MaterialDialog dialog, CharSequence input) {
                GridActivity.this.loadSticker(input.toString());
            }
        }).show();
    }

    public void shadowFont() {
        this.text_shadow_view.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void patternFont() {
        this.textPatternView.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void blurFont() {
        this.textBlurView.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void colorFont() {
        this.textColorView.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void typeFont() {
        this.textFontView.setVisibility(View.VISIBLE);
        this.linearFontView.setVisibility(View.GONE);
    }

    public void originalFontSticker(View view) {
        this.blur_effects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(2, null);
            this.tempSticker.originalEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void embossFontSticker(View view) {
        this.blur_effects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(1, null);
            this.tempSticker.embossEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void debossFontSticker(View view) {
        this.blur_effects = 0;
        if (this.tempSticker != null) {
            this.stickerView.setLayerType(1, null);
            this.tempSticker.debossEffect();
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void normalFontSticker(View view) {
        this.blur_effects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.NORMAL;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void solidFontSticker(View view) {
        this.blur_effects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.SOLID;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void innerFontSticker(View view) {
        this.blur_effects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.INNER;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void outerFontSticker(View view) {
        this.blur_effects = 1;
        if (this.tempSticker != null) {
            this.blur = Blur.OUTER;
            this.stickerView.setLayerType(1, null);
            this.tempSticker.applyFilter(this.blur, this.blurVal);
            this.stickerView.invalidate();
            return;
        }
        Snackbar.make(this.captureMain_RLayout, getString(R.string.alert), Snackbar.LENGTH_SHORT).show();
    }

    public void loadSticker(String string) {
        Drawable bubble = ContextCompat.getDrawable(getApplicationContext(), R.drawable.transparent_background);
        this.txt_sticker = new TextSticker(getApplicationContext());
        this.txt_sticker.setDrawable(bubble);
        this.txt_sticker.setText(string);
        this.txt_sticker.resizeText();
        this.stickerView.addSticker(this.txt_sticker);
        this.tempSticker = this.txt_sticker;
    }

    private void clickEvents() {
        this.rvColor1.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                GridActivity.this.backgroundPattern = 0;
                GridActivity.this.patternImage = GridActivity.this.colors33.get(position).intValue();
                GridActivity.this.ll_mainFrame.setBackgroundColor(GridActivity.this.colors33.get(position).intValue());
                GridActivity.this.gridcolorAdapter1.setSelection(position);
            }
        }));
        this.rvViewcolor.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                GridActivity.this.ll_mainFrame.setBackgroundColor(GridActivity.this.colors11.get(position).intValue());
                GridActivity.this.gridcolorAdapter.setSelection(position);
                GridActivity.this.backgroundPattern = 0;
                GridActivity.this.patternImage = GridActivity.this.colors11.get(position).intValue();
                if (GridActivity.this.colors11.get(position).intValue() != Color.parseColor("#ffffff") && GridActivity.this.colors11.get(position).intValue() != Color.parseColor("#000000")) {
                    GridActivity.this.colors33 = DataBinder.fetchSecondaryColor(position);
                    GridActivity.this.gridcolorAdapter1 = new ColorAdapter(GridActivity.this.activity, GridActivity.this.colors33);
                    GridActivity.this.rvColor1.setAdapter(GridActivity.this.gridcolorAdapter1);
                }
            }
        }));
        this.rc_Ratio.addOnItemTouchListener(new RecyclerItemClickListener(this.activity, new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                GridActivity.this.setRatio(position);
                GridActivity.this.ratioAdapter.selection(String.valueOf(position));
                GridActivity.this.ratioAdapter.notifyDataSetChanged();
            }
        }));
        this.ll_goBackPattern.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GridActivity.this.ll_subPattern.setVisibility(View.GONE);
                GridActivity.this.rc_Pattern.setVisibility(View.VISIBLE);
            }
        });
        this.rc_Pattern.addOnItemTouchListener(new RecyclerItemClickListener(this.activity, new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                GridActivity.this.subPatternAdapter = new SubPatternAdapter(GridActivity.this.activity, DataBinder.fetchSubPattern(position));
                GridActivity.this.rc_PatternSub.setAdapter(GridActivity.this.subPatternAdapter);
                GridActivity.this.ll_subPattern.setVisibility(View.VISIBLE);
                GridActivity.this.rc_Pattern.setVisibility(View.GONE);
                GridActivity.this.positionMainPattern = position;
                GridActivity.this.patternAdapter.selection(String.valueOf(position));
                GridActivity.this.patternAdapter.notifyDataSetChanged();
            }
        }));
        this.rc_PatternSub.addOnItemTouchListener(new RecyclerItemClickListener(this.activity, new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                int[] subPattern = DataBinder.fetchSubPattern(GridActivity.this.positionMainPattern);
                BitmapDrawable bitmapDrawable = new BitmapDrawable(BitmapFactory.decodeResource(GridActivity.this.getResources(), subPattern[position]));
                if (GridActivity.this.positionMainPattern != 0) {
                    bitmapDrawable.setTileModeXY(TileMode.REPEAT, TileMode.REPEAT);
                }
                GridActivity.this.ll_mainFrame.setBackgroundDrawable(bitmapDrawable);
                GridActivity.this.backgroundPattern = 1;
                GridActivity.this.patternImage = subPattern[position];
                GridActivity.this.subPatternAdapter.selection(String.valueOf(position));
                GridActivity.this.subPatternAdapter.notifyDataSetChanged();
            }
        }));
        this.rc_Frame.addOnItemTouchListener(new RecyclerItemClickListener(this.activity, new RecyclerItemClickListener.OnItemClickListener() {
            public void onItemClick(View view, int position) {
                if (position == 0) {
                    GridActivity.this.borderrelative.setBackgroundResource(R.drawable.transparent_background);
                } else {
                    GridActivity.this.borderrelative.setBackgroundResource(GridActivity.this.frameArrayList.get(position).getImage());
                }
                GridActivity.this.frameAdapter.selection(String.valueOf(position));
                GridActivity.this.frameAdapter.notifyDataSetChanged();
            }
        }));
        this.ll_stickerCheck.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                for (int i = 0; i < 391; i++) {
                    if (MainActivity.stickerArrayList.get(i).isSelected()) {
                        GridActivity.this.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(GridActivity.this.getApplicationContext(), GridActivity.this.getResources().getIdentifier(MainActivity.stickerArrayList.get(i).getName(), "drawable", GridActivity.this.getPackageName()))));
                    }
                }
                GridActivity.this.stickerLayout();
            }
        });
        this.ll_stickerCross.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                GridActivity.this.stickerLayout();
            }
        });
    }

    public void setRatio(int pos) {
        switch (pos) {
            case 0:
                this.mainviewParams.width = this.mWidth;
                this.mainviewParams.height = this.mWidth;
                break;
            case 1:
                this.mainviewParams.width = this.mWidth;
                this.mainviewParams.height = (this.mWidth * 2) / 3;
                break;
            case 2:
                this.mainviewParams.width = (this.mWidth * 2) / 3;
                this.mainviewParams.height = this.mWidth;
                break;
            case 3:
                this.mainviewParams.width = this.mWidth;
                this.mainviewParams.height = (this.mWidth * 3) / 4;
                break;
            case 4:
                this.mainviewParams.width = (this.mWidth * 3) / 4;
                this.mainviewParams.height = this.mWidth;
                break;
            case 5:
                this.mainviewParams.width = this.mWidth;
                this.mainviewParams.height = (this.mWidth * 1) / 2;
                break;
            case 6:
                this.mainviewParams.width = (this.mWidth * 1) / 2;
                this.mainviewParams.height = this.mWidth;
                break;
            default:
                this.captureMain_RLayout.setLayoutParams(this.mainviewParams);
                this.captureMain_RLayout.invalidate();
                break;
        }
    }

    private void openDialog() {
        ViewGroup tab = findViewById(R.id.frametab);
        tab.addView(LayoutInflater.from(this).inflate(R.layout.demo_custom_tab_icons, tab, false));
        this.viewPager = findViewById(R.id.viewpager);
        this.smartTabLayout = findViewById(R.id.viewpagertab);
    }

    public void stickerLayout() {
        this.ll_stickerFullLayout.setVisibility(View.GONE);
        this.ll_mainLayout.setVisibility(View.VISIBLE);
        this.txt_stickerCount.setText("0");
        MainActivity.stickerValue = 0;
        new fetchSticker().execute();
    }

    public boolean onTouch(View v, MotionEvent event) {
        return false;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.image_1:
                openQuickAction(view, 0);
                break;
            case R.id.image_2:
                openQuickAction(view, 1);
                break;
            case R.id.image_3:
                openQuickAction(view, 2);
                break;
            case R.id.image_4:
                openQuickAction(view, 3);
                break;
            case R.id.image_5:
                openQuickAction(view, 4);
                break;
            case R.id.image_6:
                openQuickAction(view, 5);
                break;
            case R.id.image_7:
                openQuickAction(view, 6);
                break;
            case R.id.image_8:
                openQuickAction(view, 7);
                break;
            case R.id.image_9:
                openQuickAction(view, 8);
                break;
            default:
                break;
        }
    }

    public void openQuickAction(View view, int position) {
        this.picChangePosition = position;
        final EasyDialog easyDialog = new EasyDialog(this.activity);
        easyDialog.setLayoutResourceId(R.layout.popup_quick).setBackgroundColor(getResources().getColor(R.color.Popup_Color)).setLocationByAttachedView(view).setAnimationTranslationShow(1, 1000, -800.0f, 100.0f, -50.0f, 50.0f, 0.0f).setAnimationAlphaDismiss(14, 1.0f, 0.0f).setGravity(0).setTouchOutsideDismiss(true).setMatchParent(false).setMarginLeftAndRight(24, 24).setOutsideColor(Color.parseColor("#66444444"));
        int screenHeight = getScreenHeight(this.activity);
        int statusBarHeight = getStatusBarHeight(getApplicationContext());
        int dialogHeight = screenHeight - statusBarHeight;
        if (easyDialog.getDialog() != null) {
            WindowManager.LayoutParams params = easyDialog.getDialog().getWindow().getAttributes();
            params.gravity = 48;
            params.y = statusBarHeight;
            params.width = -1;
            params.height = dialogHeight;
            easyDialog.getDialog().getWindow().setAttributes(params);
        }
        easyDialog.show();
        if (easyDialog.getDialog() != null) {
            LinearLayout btnPicChange = easyDialog.getDialog().findViewById(R.id.btnChangePic);
            LinearLayout btnClose = easyDialog.getDialog().findViewById(R.id.btnClosedialog);
            LinearLayout btnEdit = easyDialog.getDialog().findViewById(R.id.btnEditimage);
            easyDialog.getDialog().findViewById(R.id.btnRotateimage).setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    Bitmap bitmap = BitmapFactory.decodeFile(GridActivity.this.touchImageViewArray[GridActivity.this.picChangePosition].getTag().toString());
                    int unit = GridActivity.this.rotationUnits[GridActivity.this.picChangePosition] + 90;
                    GridActivity.this.rotationUnits[GridActivity.this.picChangePosition] = unit;
                    GridActivity.this.touchImageViewArray[GridActivity.this.picChangePosition].setImageBitmap(CompressImage.rotateBitmap(bitmap, (float) unit));
                }
            });
            btnEdit.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(GridActivity.this.getApplicationContext(), PhotoEditingActivity.class);
                    intent.putExtra(Const.editedImg, GridActivity.this.touchImageViewArray[GridActivity.this.picChangePosition].getTag().toString());
                    GridActivity.this.startActivityForResult(intent, 6);
                    GridActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                    if (easyDialog.getDialog().isShowing()) {
                        easyDialog.dismiss();
                    }
                }
            });
            btnPicChange.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent photoPickerIntent = new Intent("android.intent.action.PICK");
                    photoPickerIntent.setType("image/*");
                    GridActivity.this.startActivityForResult(photoPickerIntent, 1);
                    if (easyDialog.getDialog().isShowing()) {
                        easyDialog.dismiss();
                    }
                }
            });
            btnClose.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    easyDialog.dismiss();
                }
            });
        }
    }

    private static int getScreenHeight(Activity activity) {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        return displaymetrics.heightPixels;
    }

    private static int getStatusBarHeight(Context context) {
        Resources res = context.getResources();
        int resourceId = res.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return res.getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    @SuppressLint("NonConstantResourceId")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == -1) {
            switch (requestCode) {
                case me.zhanghai.android.materialprogressbar.R.styleable.View_android_focusable:
                    this.stringArrayList.set(this.picChangePosition, CompressImage.getPath(getApplicationContext(), data.getData()));
                    this.touchImageViewArray[this.picChangePosition].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.stringArrayList.get(this.picChangePosition))));
                    this.rotationUnits[this.picChangePosition] = 0;
                    this.touchImageViewArray[this.picChangePosition].setTag(this.stringArrayList.get(this.picChangePosition));
                    break;
                case me.zhanghai.android.materialprogressbar.R.styleable.Toolbar_subtitle:
                    if (Const.editedImagePath != null) {
                        this.stringArrayList.set(this.picChangePosition, Const.editedImagePath);
                        this.touchImageViewArray[this.picChangePosition].setImageBitmap(Compressor.getDefault(this.activity).compressToBitmap(new File(this.stringArrayList.get(this.picChangePosition))));
                        this.rotationUnits[this.picChangePosition] = 0;
                        this.touchImageViewArray[this.picChangePosition].setTag(this.stringArrayList.get(this.picChangePosition));
                        break;
                    }
                    break;
            }
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void changeVisibility(int grid, int adjust, int background, int frame, int font, int ratio, int color) {
        this.ll_grid_main.setVisibility(grid);
        this.ll_pattern_main.setVisibility(background);
        this.ll_color_main.setVisibility(color);
        this.ll_border_main.setVisibility(adjust);
        this.ll_ratio_main.setVisibility(ratio);
        this.ll_text_main.setVisibility(font);
        this.ll_frameborder_main.setVisibility(frame);
    }

    public void BottomMethod(int position) {
        switch (position) {
            case 0:
                changeVisibility(Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
                break;
            case 1:
                changeVisibility(Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
                break;
            case 2:
                changeVisibility(Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
                break;
            case 3:
                changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout);
                break;
            case 4:
                changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout);
                break;
            case 5:
                showStickerDialog();
                break;
            case 6:
                changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout, Const.goneLayout);
                break;
            case 7:
                changeVisibility(Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.goneLayout, Const.visibleLayout, Const.goneLayout);
                break;
            default:
        }
    }

    private void setStickerList1() {
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_2));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_3));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_10));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_12));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_15));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_17));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_18));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_19));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_20));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_21));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_22));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_23));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_24));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_25));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_27));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_28));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_29));
        this.stickerlist.add(Integer.valueOf(R.drawable.emotion_33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s29));
        this.stickerlist.add(Integer.valueOf(R.drawable.s30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s31));
        this.stickerlist.add(Integer.valueOf(R.drawable.s32));
        this.stickerlist.add(Integer.valueOf(R.drawable.s33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s34));
        this.stickerlist.add(Integer.valueOf(R.drawable.s35));
        this.stickerlist.add(Integer.valueOf(R.drawable.s36));
        this.stickerlist.add(Integer.valueOf(R.drawable.s37));
        this.stickerlist.add(Integer.valueOf(R.drawable.s38));
        this.stickerlist.add(Integer.valueOf(R.drawable.s39));
        this.stickerlist.add(Integer.valueOf(R.drawable.s40));
        this.stickerlist.add(Integer.valueOf(R.drawable.s41));
        this.stickerlist.add(Integer.valueOf(R.drawable.s42));
        this.stickerlist.add(Integer.valueOf(R.drawable.s43));
        this.stickerlist.add(Integer.valueOf(R.drawable.s44));
        this.stickerlist.add(Integer.valueOf(R.drawable.s45));
        this.stickerlist.add(Integer.valueOf(R.drawable.s46));
        this.stickerlist.add(Integer.valueOf(R.drawable.s47));
        this.stickerlist.add(Integer.valueOf(R.drawable.s48));
        this.stickerlist.add(Integer.valueOf(R.drawable.s49));
        this.stickerlist.add(Integer.valueOf(R.drawable.s50));
        this.stickerlist.add(Integer.valueOf(R.drawable.s51));
        this.stickerlist.add(Integer.valueOf(R.drawable.s52));
        this.stickerlist.add(Integer.valueOf(R.drawable.s53));
        this.stickerlist.add(Integer.valueOf(R.drawable.s54));
        this.stickerlist.add(Integer.valueOf(R.drawable.s55));
    }

    public void showStickerDialog() {
        final Dialog dial = new Dialog(this, android.R.style.Theme_Translucent);
        dial.requestWindowFeature(1);
        dial.setContentView(R.layout.sticker_dialog);
        dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dial.setCanceledOnTouchOutside(false);
        dial.findViewById(R.id.back_dialog).setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        bottom_adapter.Selection="0";
                        bottom_adapter.notifyDataSetChanged();
                        dial.dismiss();
                    }
                });
        dial.setOnKeyListener(new Dialog.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface arg0, int keyCode,
                                 KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e("TAG","Dialog Close");
                    bottom_adapter.Selection="0";
                    bottom_adapter.notifyDataSetChanged();
                    dial.dismiss();
                }
                return true;
            }
        });
        this.stickerlist = new ArrayList();
        GridView grid_sticker = dial.findViewById(R.id.gridStickerList);
        setStickerList1();
        this.stickerAdapter = new StickerAdapter(getApplicationContext(), this.stickerlist);
        grid_sticker.setAdapter(this.stickerAdapter);
        grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GridActivity.this.addStickerView(stickerlist.get(position));
                bottom_adapter.Selection="0";
                bottom_adapter.notifyDataSetChanged();
                dial.dismiss();
            }
        });
        dial.show();
    }

    private void addStickerView(int id) {
        final StickerViewnew stickerView = new StickerViewnew(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerViewnew.OperationListener() {
            public void onDeleteClick() {
                GridActivity.this.views.remove(stickerView);
                GridActivity.this.captureMain_RLayout.removeView(stickerView);
            }

            public void onEdit(StickerViewnew stickerView) {
                if (GridActivity.this.currentTextView != null) {
                    GridActivity.this.currentTextView.setInEdit(false);
                }
                GridActivity.this.currentView.setInEdit(false);
                GridActivity.this.currentView = stickerView;
                GridActivity.this.currentView.setInEdit(true);
            }

            public void onTop(StickerViewnew stickerView) {
                int position = GridActivity.this.views
                        .indexOf(stickerView);
                if (position != GridActivity.this.views.size() - 1) {
                    GridActivity.this.views.add(
                            GridActivity.this.views.size(),
                            GridActivity.this.views
                                    .remove(position));
                }
            }
        });
        this.captureMain_RLayout.addView(stickerView, new LayoutParams(-1, -1));
        this.views.add(stickerView);
        setCurrentEdit(stickerView);
    }


    private void setCurrentEdit(StickerViewnew stickerView) {
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(false);
        }
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

   /* public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_done, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                if (this.ll_stickerFullLayout.getVisibility() == View.GONE) {
                    AlertDialog.Builder alertDialogbuilder = new AlertDialog.Builder(this.activity);
                    alertDialogbuilder.setMessage((CharSequence) "You have unsaved changes, do you want to exit and return to the previous screen?");
                    alertDialogbuilder.setPositiveButton((CharSequence) "Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            GridActivity.this.finish();
                            GridActivity.this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                        }
                    });
                    alertDialogbuilder.setNegativeButton((CharSequence) "No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alertDialogbuilder.setCancelable(false);
                    alertDialogbuilder.show();
                }
                stickerLayout();

                return true;
            case R.id.menu_done:

                saveprogress();

                return true;
            default:
                return false;
        }
    }*/

    private void GoBack() {
        if (ll_stickerFullLayout.getVisibility() == View.GONE) {
            AlertDialog.Builder alertDialogbuilder = new AlertDialog.Builder(activity);
            alertDialogbuilder.setMessage("You have unsaved changes, do you want to exit and return to the previous screen?");
            alertDialogbuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    GridActivity.this.finish();
                    GridActivity.this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
                }
            });
            alertDialogbuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            alertDialogbuilder.setCancelable(false);
            alertDialogbuilder.show();
        }
        stickerLayout();

    }

    private void saveprogress() {
        if (currentTextView != null) {
            currentTextView.setInEdit(false);
        }
        if (currentView != null) {
            currentView.setInEdit(false);

        }
        if (!this.stickerView.isLocked()) {
            this.stickerView.setLocked(true);
        }
        captureMain_RLayout.setDrawingCacheEnabled(true);
        File imgFile = CompressImage.tempImage(getApplicationContext(), captureMain_RLayout.getDrawingCache());
        try {
            File f = new File(imgFile.getAbsolutePath());
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 10;
            opts.inMutable = true;
            mBitmap = BitmapFactory.decodeStream(new FileInputStream(f));
            mBitmap = mBitmap.copy(Bitmap.Config.ARGB_8888, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        takeScreenshot(mBitmap, getResources().getString(R.string.app_name));
        id = 100;
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            dialogAd.show();
            AdsDialogShow();
        } else {
            startActivity(new Intent(GridActivity.this, ShareActivity.class).putExtra("key", 2));
            finish();
        }
        if (!this.stickerView.isLocked()) {
        }
        this.stickerView.setLocked(false);
    }

    private void takeScreenshot(Bitmap bitmap, String storePath) {

        File file = null;
        if (Environment.getExternalStorageState().equals("mounted")) {
            File directory = new File(new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString())).append(File.separator).append(getResources().getString(R.string.app_name)).toString());

            if (!directory.exists()) {
                directory.mkdirs();
            }
            file = new File(directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png");
            str_urlShareimg = directory.getAbsolutePath() + "/" + storePath + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".png";
        }
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
    }

    public void onBackPressed() {
        GoBack();
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.show();
                dialogAd.dismiss();
            }
        }, 2000);
    }

    private int id;
    private InterstitialAd interstitialAd;
    Dialog dialogAd;

    private void loadAd() {
        dialogAd = new Dialog(GridActivity.this);
        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogAd.getWindow().setGravity(Gravity.CENTER);
        dialogAd.setContentView(R.layout.dialog_layout_progress);
        dialogAd.setCanceledOnTouchOutside(false);
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.FB_inter));
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                dialogAd.dismiss();
                switch (id) {
                    case 100:
                        startActivity(new Intent(GridActivity.this, ShareActivity.class).putExtra("key", 2));
                        finish();
                        break;

                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        interstitialAd.loadAd();

    }

    private void requestNewInterstitial() {
        interstitialAd.loadAd();
    }
}