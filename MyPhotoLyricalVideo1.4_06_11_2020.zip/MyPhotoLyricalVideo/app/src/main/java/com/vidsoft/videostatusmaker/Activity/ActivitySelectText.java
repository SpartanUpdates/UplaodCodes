package com.vidsoft.videostatusmaker.Activity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;

import com.vidsoft.videostatusmaker.adapter.TextAdapter;

public class ActivitySelectText extends AppCompatActivity {
    TextAdapter textAdapter;
    ImageView ivBack;
    Typeface typeface;
    GridView gridView;
    String[] styles;
    TextView title;

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        loadAd();
        init();
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivitySelectText.this.onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.gridView = this.findViewById(R.id.stylelist);
        try {
            this.styles = this.getResources().getAssets().list("fonts");
            this.textAdapter = new TextAdapter(this.getApplicationContext(), this.styles);
            this.gridView.setAdapter((ListAdapter) this.textAdapter);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.gridView.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                ActivityPreview.complete = false;
                final TextView lyric_txt1 = ActivityPreview.lyricTxt1;
                final AssetManager assets = ActivitySelectText.this.getAssets();
                final StringBuilder sb = new StringBuilder();
                sb.append("fonts/");
                sb.append(ActivitySelectText.this.styles[n]);
                lyric_txt1.setTypeface(Typeface.createFromAsset(assets, sb.toString()));
                final TextView lyric_txt2 = ActivityPreview.lyricTxt2;
                final AssetManager assets2 = ActivitySelectText.this.getAssets();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("fonts/");
                sb2.append(ActivitySelectText.this.styles[n]);
                lyric_txt2.setTypeface(Typeface.createFromAsset(assets2, sb2.toString()));
                ActivitySelectText.this.setResult(-1, new Intent(ActivitySelectText.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectText.this.finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private NativeBannerAd mNativeBannerAd;

    private void loadAd() {
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("AD", "======ERROR");
            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(ActivitySelectText.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
    }

}
