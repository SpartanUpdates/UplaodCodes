package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import androidx.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import com.vidsoft.videostatusmaker.adapter.MyCreationAdapter;

public class ActivityMyCreations extends Activity {
    public static ArrayList<String> photoArrayList;
    Typeface typeface;
    TextView tvTitle;
    public static int pos;
    MyCreationAdapter myCreationAdapter;
    ImageView ivBack;
    String strFolderName;
    GridView gridView;
    File[] listFile;

    static {
        ActivityMyCreations.photoArrayList = new ArrayList<String>();
    }

    public ActivityMyCreations() {
        this.listFile = null;
    }


    public void delete(final int n) {
        final AlertDialog.Builder dialogobj = new AlertDialog.Builder((Context) this);
        dialogobj.setTitle((CharSequence) "Confirm Delete !");
        dialogobj.setMessage((CharSequence) "Are you sure to delete Image??");
        dialogobj.setPositiveButton((CharSequence) "YES", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
                if (new File(ActivityMyCreations.photoArrayList.get(n)).delete()) {
                    ActivityMyCreations.photoArrayList.remove(n);
                    Toast.makeText((Context) ActivityMyCreations.this, (CharSequence) "File Deleted", Toast.LENGTH_SHORT).show();
                    ActivityMyCreations.this.myCreationAdapter.notifyDataSetChanged();
                }
            }
        });
        dialogobj.setNegativeButton((CharSequence) "NO", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
            }
        });
        dialogobj.show();
    }

    public void getFromSdcard() {
        final File externalStorageDirectory = Environment.getExternalStorageDirectory();
        final StringBuilder sb = new StringBuilder();
        sb.append(this.strFolderName);
        sb.append("/Video");
        final File file = new File(externalStorageDirectory, sb.toString());
        if (file.isDirectory()) {
            Arrays.sort(this.listFile = file.listFiles(), new Comparator() {
                @Override
                public int compare(final Object o, final Object o2) {
                    final File file = (File) o;
                    final long lastModified = file.lastModified();
                    final File file2 = (File) o2;
                    if (lastModified > file2.lastModified()) {
                        return -1;
                    }
                    if (file.lastModified() < file2.lastModified()) {
                        return 1;
                    }
                    return 0;
                }
            });
            for (int i = 0; i < this.listFile.length; ++i) {
                if (this.listFile[i].getName().contains("temp")) {
                    this.listFile[i].delete();
                } else {
                    ActivityMyCreations.photoArrayList.add(this.listFile[i].getAbsolutePath());
                }
            }
        }
    }

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.mywork);
        this.getWindow().addFlags(1024);

        this.strFolderName = this.getResources().getString(R.string.app_name);
        loadAd();
        final StrictMode.VmPolicy.Builder strictMode$VmPolicy$Builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(strictMode$VmPolicy$Builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            strictMode$VmPolicy$Builder.detectFileUriExposure();
        }

        bindview();
        init();
    }


    private void bindview() {
        this.gridView = (GridView) this.findViewById(R.id.gridview);
        this.ivBack = (ImageView) this.findViewById(R.id.back);
        this.tvTitle = (TextView) this.findViewById(R.id.title);

    }

    private NativeBannerAd mNativeBannerAd;

    private void loadAd() {
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(ActivityMyCreations.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.setVisibility(View.VISIBLE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();
    }

    protected void onResume() {
        super.onResume();
        this.myCreationAdapter.notifyDataSetChanged();
    }

    public void preview(final int pos) {
        ActivityMyCreations.pos = pos;
        this.startActivity(new Intent(this.getApplicationContext(), (Class) ActivityMyCreationVideoplay.class));
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(ActivityMyCreations.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    private void init() {
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                startActivity(new Intent(ActivityMyCreations.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();
            }
        });
        ActivityMyCreations.photoArrayList.clear();
        this.getFromSdcard();
        this.myCreationAdapter = new MyCreationAdapter((Context) this, ActivityMyCreations.photoArrayList);
        this.gridView.setAdapter((ListAdapter) this.myCreationAdapter);
        this.myCreationAdapter.notifyDataSetChanged();
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
    }

    void setLayout() {
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 70 / 1080, this.getResources().getDisplayMetrics().heightPixels * 70 / 1920);
        layoutParams.addRule(15);
        layoutParams.setMargins(widthPixels * 40 / 1080, 0, 0, 0);
        this.ivBack.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
    }
}
