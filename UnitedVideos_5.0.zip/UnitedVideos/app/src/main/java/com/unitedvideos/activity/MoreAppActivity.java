//package com.unitedvideos.activity;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.Toast;
//
//import com.google.firebase.analytics.FirebaseAnalytics;
//import com.unitedvideos.Adapter.MoreAppAdapter;
//import com.unitedvideos.Model.MoreAppModel;
//import com.unitedvideos.R;
//import com.unitedvideos.Retrofit.APIClient;
//import com.unitedvideos.Retrofit.APIInterface;
//import com.unitedvideos.Utils.Utils;
//
//import java.util.ArrayList;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//public class MoreAppActivity extends AppCompatActivity {
//
//    Activity activity = MoreAppActivity.this;
//    LinearLayout llRetry;
//    RelativeLayout rlLoadingMoreApp;
//    Button btnRetry;
//    ImageView ivBack;
//    RecyclerView rvMoreApp;
//    private ArrayList<MoreAppModel> moreAppList = new ArrayList<>();
//    private MoreAppAdapter moreAppAdapter;
//    APIInterface apiInterface;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_more_app);
//        apiInterface = APIClient.getClient().create(APIInterface.class);
//        FirebaseAnalytics mFirebaseAnalytics;
//        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
//        Bundle bundle = new Bundle();
//        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MoreAppActivity");
//        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
//        BindView();
//        adListener();
//    }
//
//    private void BindView() {
//        ivBack = findViewById(R.id.ivBack);
//        rlLoadingMoreApp = findViewById(R.id.rl_loading_pager);
//        llRetry = findViewById(R.id.llRetry);
//        btnRetry = findViewById(R.id.btnRetry);
//        rvMoreApp = findViewById(R.id.rvMoreApp);
//    }
//
//    private void adListener() {
//        ivBack.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
//        btnRetry.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (Utils.checkConnectivity(activity, false)) {
//                    llRetry.setVisibility(View.GONE);
//                    GetMoreApp();
//                } else {
//                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
//                }
//            }
//        });
//    }
//
//    private void SetAdapter() {
//        moreAppAdapter = new MoreAppAdapter(activity, moreAppList);
//        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false);
//        rvMoreApp.setLayoutManager(mLayoutManager);
//        rvMoreApp.setAdapter(moreAppAdapter);
//        moreAppAdapter.notifyDataSetChanged();
//    }
//
//    private void GetMoreApp() {
//        rlLoadingMoreApp.setVisibility(View.VISIBLE);
//        SetAdapter();
//    }
//
//    public void onBackPressed() {
//        Intent intent = new Intent(activity, HomeActivity.class);
//        startActivity(intent);
//        finish();
//    }
//}
