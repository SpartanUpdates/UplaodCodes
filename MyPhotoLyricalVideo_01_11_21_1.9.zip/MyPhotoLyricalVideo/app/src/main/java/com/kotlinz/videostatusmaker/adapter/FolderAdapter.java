package com.kotlinz.videostatusmaker.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.kotlinz.videostatusmaker.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import java.util.ArrayList;
import java.util.List;
import com.kotlinz.videostatusmaker.Others.gallery.ImageData;
import com.kotlinz.videostatusmaker.Utils.RoundedImageView;

public class FolderAdapter extends ArrayAdapter<ImageData> {
    private final Typeface typeface;
    ViewHolder viewHolder;
    ArrayList<ImageData> array_album;
    Context context;

    public FolderAdapter(final Context context, final ArrayList<ImageData> array_album) {
        super(context, R.layout.photosfolder_layout, (List) array_album);
        this.array_album = new ArrayList<ImageData>();
        this.array_album = array_album;
        this.context = context;
        this.typeface = Typeface.createFromAsset(context.getAssets(), "Montserrat-Light_0.otf");
    }

    public int getCount() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.array_album.size());
        sb.append("");
        return this.array_album.size();
    }

    public long getItemId(final int n) {
        return n;
    }

    public int getItemViewType(final int n) {
        return n;
    }

    public View getView(int n, View inflate, final ViewGroup viewGroup) {
        if (inflate == null) {
            this.viewHolder = new ViewHolder();
            inflate = LayoutInflater.from(this.getContext()).inflate(R.layout.photosfolder_layout, viewGroup, false);
            this.viewHolder.tv_foldern = (TextView) inflate.findViewById(R.id.tv_folder);
            this.viewHolder.tv_foldersize = (TextView) inflate.findViewById(R.id.tv_folder2);
            this.viewHolder.iv_image = (RoundedImageView) inflate.findViewById(R.id.iv_image);
            this.viewHolder.mainLay = (RelativeLayout) inflate.findViewById(R.id.mainLay);
            this.viewHolder.bot_lay = (LinearLayout) inflate.findViewById(R.id.bot_lay);
            inflate.setTag((Object) this.viewHolder);
        } else {
            this.viewHolder = (ViewHolder) inflate.getTag();
        }
        this.viewHolder.tv_foldern.setText((CharSequence) this.array_album.get(n).getStr_folder());
        final TextView tv_foldersize = this.viewHolder.tv_foldersize;
        final StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(this.array_album.get(n).getAl_imagepath().size());
        tv_foldersize.setText((CharSequence) sb.toString());
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 301 / 1080, heightPixels * 301 / 1920);
        layoutParams.addRule(13);
        final int n2 = widthPixels * 10 / 1080;
        layoutParams.setMargins(n2, n2, n2, n2);
        this.viewHolder.mainLay.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(widthPixels * 274 / 1080, heightPixels * 63 / 1920);
        layoutParams2.addRule(14);
        layoutParams2.addRule(12);
        layoutParams2.setMargins(0, 0, 0, n2);
        this.viewHolder.bot_lay.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        this.viewHolder.tv_foldern.setTypeface(this.typeface);
        this.viewHolder.tv_foldersize.setTypeface(this.typeface);
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(widthPixels * 275 / 1080, heightPixels * 275 / 1920);
        layoutParams3.addRule(13);
        this.viewHolder.iv_image.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        this.viewHolder.iv_image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("file:///");
        sb2.append(this.array_album.get(n).getAl_imagepath().get(0));
        instance.displayImage(sb2.toString(), this.viewHolder.iv_image, build);
        n = widthPixels * 12 / 1080;
        this.viewHolder.iv_image.setCornerRadius(n);
        return inflate;
    }

    public int getViewTypeCount() {
        if (this.array_album.size() > 0) {
            return this.array_album.size();
        }
        return 1;
    }

    private static class ViewHolder {
        LinearLayout bot_lay;
        RoundedImageView iv_image;
        RelativeLayout mainLay;
        TextView tv_foldern;
        TextView tv_foldersize;
    }
}
