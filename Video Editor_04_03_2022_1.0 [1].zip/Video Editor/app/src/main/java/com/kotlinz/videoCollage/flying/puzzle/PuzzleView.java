package com.kotlinz.videoCollage.flying.puzzle;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.kotlinz.videoeditor.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PuzzleView extends View {
    private static final String TAG = "PuzzleView";
    private Map<Area, PuzzlePiece> areaPieceMap;
    private RectF bounds;
    private boolean canDrag;
    private boolean canMoveLine;
    private boolean canSwap;
    private boolean canZoom;
    private ActionMode currentMode;
    private float downX;
    private float downY;
    private int duration;
    private int handleBarColor;
    private Paint handleBarPaint;
    private Line handlingLine;
    private PuzzlePiece handlingPiece;
    private PuzzleLayout.Info initialInfo;
    private int lineColor;
    private Paint linePaint;
    private int lineSize;
    private PointF midPoint;
    private List<PuzzlePiece> needChangePieces;
    private boolean needDrawLine;
    private boolean needDrawOuterLine;
    private boolean needResetPieceMatrix;
    private OnPieceSelectedListener onPieceSelectedListener;
    private OnPieceSwapListener onPieceSwapListener;
    private float piecePadding;
    private float pieceRadian;
    private float previousDistance;
    private PuzzlePiece previousHandlingPiece;
    private PuzzleLayout puzzleLayout;
    private List<PuzzlePiece> puzzlePieces;
    private boolean quickMode;
    private PuzzlePiece replacePiece;
    private Paint selectedAreaPaint;
    private int selectedLineColor;
    private Runnable switchToSwapAction;
    private boolean touchEnable;


    static  class AnonymousClass3 {
        static {

        }
    }

    private enum ActionMode {
        NONE,
        DRAG,
        ZOOM,
        MOVE,
        SWAP
    }

    public interface OnPieceSelectedListener {
        void onPieceSelected(PuzzlePiece puzzlePiece, int i);

        void onPieceUnSelected();
    }

    public interface OnPieceSwapListener {
        void onPieceSwap(int i, int i2);
    }

    public PuzzleView(Context context) {
        this(context, null);
    }

    public PuzzleView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PuzzleView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.currentMode = ActionMode.NONE;
        this.puzzlePieces = new ArrayList();
        this.needChangePieces = new ArrayList();
        this.areaPieceMap = new HashMap();
        this.touchEnable = true;
        this.needResetPieceMatrix = true;
        this.quickMode = false;
        this.canDrag = true;
        this.canMoveLine = true;
        this.canZoom = true;
        this.canSwap = true;
        this.switchToSwapAction = new Runnable() {
            public void run() {
                if (PuzzleView.this.canSwap) {
                    PuzzleView.this.currentMode = ActionMode.SWAP;
                    PuzzleView.this.invalidate();
                }
            }
        };
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.PuzzleView);
        this.lineSize = obtainStyledAttributes.getInt(R.styleable.PuzzleView_line_size, 4);
        this.lineColor = obtainStyledAttributes.getColor(R.styleable.PuzzleView_line_color, -1);
        String str = "#99BBFB";
        this.selectedLineColor = obtainStyledAttributes.getColor(R.styleable.PuzzleView_selected_line_color, Color.parseColor(str));
        this.handleBarColor = obtainStyledAttributes.getColor(R.styleable.PuzzleView_handle_bar_color, Color.parseColor(str));
        this.piecePadding = (float) obtainStyledAttributes.getDimensionPixelSize(R.styleable.PuzzleView_piece_padding, 0);
        this.needDrawLine = obtainStyledAttributes.getBoolean(R.styleable.PuzzleView_need_draw_line, false);
        this.needDrawOuterLine = obtainStyledAttributes.getBoolean(R.styleable.PuzzleView_need_draw_outer_line, false);
        this.duration = obtainStyledAttributes.getInt(R.styleable.PuzzleView_animation_duration, 300);
        this.pieceRadian = obtainStyledAttributes.getFloat(R.styleable.PuzzleView_radian, 0.0f);
        obtainStyledAttributes.recycle();
        this.bounds = new RectF();
        Paint paint = new Paint();
        this.linePaint = paint;
        paint.setAntiAlias(true);
        this.linePaint.setColor(this.lineColor);
        this.linePaint.setStrokeWidth((float) this.lineSize);
        this.linePaint.setStyle(Style.STROKE);
        this.linePaint.setStrokeJoin(Join.ROUND);
        this.linePaint.setStrokeCap(Cap.SQUARE);
        paint = new Paint();
        this.selectedAreaPaint = paint;
        paint.setAntiAlias(true);
        this.selectedAreaPaint.setStyle(Style.STROKE);
        this.selectedAreaPaint.setStrokeJoin(Join.ROUND);
        this.selectedAreaPaint.setStrokeCap(Cap.ROUND);
        this.selectedAreaPaint.setColor(this.selectedLineColor);
        this.selectedAreaPaint.setStrokeWidth((float) this.lineSize);
        paint = new Paint();
        this.handleBarPaint = paint;
        paint.setAntiAlias(true);
        this.handleBarPaint.setStyle(Style.FILL);
        this.handleBarPaint.setColor(this.handleBarColor);
        this.handleBarPaint.setStrokeWidth((float) (this.lineSize * 4));
        this.midPoint = new PointF();
    }

    /* Access modifiers changed, original: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        resetPuzzleBounds();
        this.areaPieceMap.clear();
        if (this.puzzlePieces.size() != 0) {
            for (i = 0; i < this.puzzlePieces.size(); i++) {
                PuzzlePiece puzzlePiece = (PuzzlePiece) this.puzzlePieces.get(i);
                Area area = this.puzzleLayout.getArea(i);
                puzzlePiece.setArea(area);
                this.areaPieceMap.put(area, puzzlePiece);
                if (this.needResetPieceMatrix) {
                    puzzlePiece.set(MatrixUtils.generateMatrix(puzzlePiece, 0.0f));
                } else {
                    puzzlePiece.fillArea(this, true);
                }
            }
        }
        invalidate();
    }

    private void resetPuzzleBounds() {
        this.bounds.left = (float) getPaddingLeft();
        this.bounds.top = (float) getPaddingTop();
        this.bounds.right = (float) (getWidth() - getPaddingRight());
        this.bounds.bottom = (float) (getHeight() - getPaddingBottom());
        PuzzleLayout puzzleLayout = this.puzzleLayout;
        if (puzzleLayout != null) {
            puzzleLayout.reset();
            this.puzzleLayout.setOuterBounds(this.bounds);
            this.puzzleLayout.layout();
            this.puzzleLayout.setPadding(this.piecePadding);
            this.puzzleLayout.setRadian(this.pieceRadian);
            PuzzleLayout.Info info = this.initialInfo;
            if (info != null) {
                int size = info.lineInfos.size();
                for (int i = 0; i < size; i++) {
                    PuzzleLayout.LineInfo lineInfo = (PuzzleLayout.LineInfo) this.initialInfo.lineInfos.get(i);
                    Line line = (Line) this.puzzleLayout.getLines().get(i);
                    line.startPoint().x = lineInfo.startX;
                    line.startPoint().y = lineInfo.startY;
                    line.endPoint().x = lineInfo.endX;
                    line.endPoint().y = lineInfo.endY;
                }
            }
            this.puzzleLayout.sortAreas();
            this.puzzleLayout.update();
        }
    }


    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.puzzleLayout != null) {
            this.linePaint.setStrokeWidth((float) this.lineSize);
            this.selectedAreaPaint.setStrokeWidth((float) this.lineSize);
            this.handleBarPaint.setStrokeWidth((float) (this.lineSize * 4));
            int i = 0;
            while (i < this.puzzleLayout.getAreaCount() && i < this.puzzlePieces.size()) {
                PuzzlePiece puzzlePiece = (PuzzlePiece) this.puzzlePieces.get(i);
                if (!(puzzlePiece == this.handlingPiece && this.currentMode == ActionMode.SWAP) && this.puzzlePieces.size() > i) {
                    puzzlePiece.setPosition(i);
                    puzzlePiece.draw(canvas, this.quickMode);
                }
                i++;
            }
            if (this.needDrawOuterLine) {
                for (Line drawLine : this.puzzleLayout.getOuterLines()) {
                    drawLine(canvas, drawLine);
                }
            }
            if (this.needDrawLine) {
                for (Line drawLine2 : this.puzzleLayout.getLines()) {
                    drawLine(canvas, drawLine2);
                }
            }
            if (!(this.handlingPiece == null || this.currentMode == ActionMode.SWAP)) {
                drawSelectedArea(canvas, this.handlingPiece);
            }
            if (this.handlingPiece != null && this.currentMode == ActionMode.SWAP) {
                this.handlingPiece.draw(canvas, 128, this.quickMode);
                PuzzlePiece puzzlePiece2 = this.replacePiece;
                if (puzzlePiece2 != null) {
                    drawSelectedArea(canvas, puzzlePiece2);
                }
            }
        }
    }

    private void drawSelectedArea(Canvas canvas, PuzzlePiece puzzlePiece) {
        Area area = puzzlePiece.getArea();
        canvas.drawPath(area.getAreaPath(), this.selectedAreaPaint);
        for (Line line : area.getLines()) {
            if (this.puzzleLayout.getLines().contains(line)) {
                PointF[] handleBarPoints = area.getHandleBarPoints(line);
                canvas.drawLine(handleBarPoints[0].x, handleBarPoints[0].y, handleBarPoints[1].x, handleBarPoints[1].y, this.handleBarPaint);
                canvas.drawCircle(handleBarPoints[0].x, handleBarPoints[0].y, (float) ((this.lineSize * 4) / 2), this.handleBarPaint);
                canvas.drawCircle(handleBarPoints[1].x, handleBarPoints[1].y, (float) ((this.lineSize * 4) / 2), this.handleBarPaint);
            }
        }
    }

    private void drawLine(Canvas canvas, Line line) {
        canvas.drawLine(line.startPoint().x, line.startPoint().y, line.endPoint().x, line.endPoint().y, this.linePaint);
    }

    public void setPuzzleLayout(PuzzleLayout puzzleLayout) {
        clearPieces();
        this.puzzleLayout = puzzleLayout;
        puzzleLayout.setOuterBounds(this.bounds);
        puzzleLayout.layout();
        invalidate();
    }

    public void setPuzzleLayout(PuzzleLayout.Info info) {
        this.initialInfo = info;
        clearPieces();
        this.puzzleLayout = PuzzleLayoutParser.parse(info);
        this.piecePadding = info.padding;
        this.pieceRadian = info.radian;
        setBackgroundColor(info.color);
        invalidate();
    }

    public PuzzleLayout getPuzzleLayout() {
        return this.puzzleLayout;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.touchEnable) {
            return super.onTouchEvent(motionEvent);
        }
        int action = motionEvent.getAction() & 255;
        if (action != 0) {
            if (action != 1) {
                if (action == 2) {
                    performAction(motionEvent);
                    if ((Math.abs(motionEvent.getX() - this.downX) > 10.0f || Math.abs(motionEvent.getY() - this.downY) > 10.0f) && this.currentMode != ActionMode.SWAP) {
                        removeCallbacks(this.switchToSwapAction);
                    }
                } else if (action != 3) {
                    if (action == 5) {
                        this.previousDistance = calculateDistance(motionEvent);
                        calculateMidPoint(motionEvent, this.midPoint);
                        decideActionMode(motionEvent);
                    }
                }
            }
            finishAction(motionEvent);
            this.currentMode = ActionMode.NONE;
            removeCallbacks(this.switchToSwapAction);
        } else {
            this.downX = motionEvent.getX();
            this.downY = motionEvent.getY();
            decideActionMode(motionEvent);
            prepareAction(motionEvent);
        }
        invalidate();
        return true;
    }

    private void decideActionMode(MotionEvent motionEvent) {
        for (PuzzlePiece isAnimateRunning : this.puzzlePieces) {
            if (isAnimateRunning.isAnimateRunning()) {
                this.currentMode = ActionMode.NONE;
                return;
            }
        }
        if (motionEvent.getPointerCount() == 1) {
            Line findHandlingLine = findHandlingLine();
            this.handlingLine = findHandlingLine;
            if (findHandlingLine == null || !this.canMoveLine) {
                PuzzlePiece findHandlingPiece = findHandlingPiece();
                this.handlingPiece = findHandlingPiece;
                if (findHandlingPiece != null && this.canDrag) {
                    this.currentMode = ActionMode.DRAG;
                    postDelayed(this.switchToSwapAction, 500);
                }
            } else {
                this.currentMode = ActionMode.MOVE;
            }
        } else if (motionEvent.getPointerCount() > 1) {
            PuzzlePiece puzzlePiece = this.handlingPiece;
            if (puzzlePiece != null && puzzlePiece.contains(motionEvent.getX(1), motionEvent.getY(1)) && this.currentMode == ActionMode.DRAG && this.canZoom) {
                this.currentMode = ActionMode.ZOOM;
            }
        }
    }

    private void prepareAction(MotionEvent motionEvent) {
//        int i = AnonymousClass3.$SwitchMap$com$xiaopo$flying$puzzle$PuzzleView$ActionMode[this.currentMode.ordinal()];
        int i=0;
        if (i == 2) {
            this.handlingPiece.record();
        } else if (i == 3) {
            this.handlingPiece.record();
        } else if (i == 4) {
            this.handlingLine.prepareMove();
            this.needChangePieces.clear();
            this.needChangePieces.addAll(findNeedChangedPieces());
            for (PuzzlePiece puzzlePiece : this.needChangePieces) {
                puzzlePiece.record();
                puzzlePiece.setPreviousMoveX(this.downX);
                puzzlePiece.setPreviousMoveY(this.downY);
            }
        }
    }

    private void performAction(MotionEvent motionEvent) {
//        int i = AnonymousClass3.$SwitchMap$com$xiaopo$flying$puzzle$PuzzleView$ActionMode[this.currentMode.ordinal()];
        int i = 0;
        if (i == 2) {
            dragPiece(this.handlingPiece, motionEvent);
        } else if (i == 3) {
            zoomPiece(this.handlingPiece, motionEvent);
        } else if (i == 4) {
            moveLine(this.handlingLine, motionEvent);
        } else if (i == 5) {
            dragPiece(this.handlingPiece, motionEvent);
            this.replacePiece = findReplacePiece(motionEvent);
        }
    }

    private void finishAction(MotionEvent motionEvent) {
        PuzzlePiece puzzlePiece;
//        int i = AnonymousClass3.$SwitchMap$com$xiaopo$flying$puzzle$PuzzleView$ActionMode[this.currentMode.ordinal()];
        int i=0;
        if (i == 2) {
            PuzzlePiece puzzlePiece2 = this.handlingPiece;
            if (!(puzzlePiece2 == null || puzzlePiece2.isFilledArea())) {
                this.handlingPiece.moveToFillArea(this);
            }
            if (this.previousHandlingPiece == this.handlingPiece && Math.abs(this.downX - motionEvent.getX()) < 3.0f && Math.abs(this.downY - motionEvent.getY()) < 3.0f) {
                this.handlingPiece = null;
            }
            this.previousHandlingPiece = this.handlingPiece;
        } else if (i == 3) {
            puzzlePiece = this.handlingPiece;
            if (!(puzzlePiece == null || puzzlePiece.isFilledArea())) {
                if (this.handlingPiece.canFilledArea()) {
                    this.handlingPiece.moveToFillArea(this);
                } else {
                    this.handlingPiece.fillArea(this, false);
                }
            }
            this.previousHandlingPiece = this.handlingPiece;
        } else if (!(i != 5 || this.handlingPiece == null || this.replacePiece == null)) {
            swapPiece();
            this.handlingPiece = null;
            this.replacePiece = null;
            this.previousHandlingPiece = null;
        }
        puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            OnPieceSelectedListener onPieceSelectedListener = this.onPieceSelectedListener;
            if (onPieceSelectedListener != null) {
                onPieceSelectedListener.onPieceSelected(puzzlePiece, this.puzzlePieces.indexOf(puzzlePiece));
                this.handlingLine = null;
                this.needChangePieces.clear();
            }
        }
        this.onPieceSelectedListener.onPieceUnSelected();
        this.handlingLine = null;
        this.needChangePieces.clear();
    }

    private void swapPiece() {
        View view = this.handlingPiece.getView();
        String path = this.handlingPiece.getPath();
        this.handlingPiece.setView(this.replacePiece.getView());
        this.handlingPiece.setPath(this.replacePiece.getPath());
        this.replacePiece.setView(view);
        this.replacePiece.setPath(path);
        this.handlingPiece.fillArea(this, true);
        this.replacePiece.fillArea(this, true);
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            OnPieceSwapListener onPieceSwapListener = this.onPieceSwapListener;
            if (onPieceSwapListener != null) {
                onPieceSwapListener.onPieceSwap(puzzlePiece.getPosition(), this.replacePiece.getPosition());
            }
        }
    }

    public void swapPiece(int i, int i2) {
        this.handlingPiece = (PuzzlePiece) this.puzzlePieces.get(i);
        this.replacePiece = (PuzzlePiece) this.puzzlePieces.get(i2);
        View view = this.handlingPiece.getView();
        String path = this.handlingPiece.getPath();
        this.handlingPiece.setView(this.replacePiece.getView());
        this.handlingPiece.setPath(this.replacePiece.getPath());
        this.replacePiece.setView(view);
        this.replacePiece.setPath(path);
        this.handlingPiece.fillArea(this, true);
        this.replacePiece.fillArea(this, true);
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            OnPieceSwapListener onPieceSwapListener = this.onPieceSwapListener;
            if (onPieceSwapListener != null) {
                onPieceSwapListener.onPieceSwap(puzzlePiece.getPosition(), this.replacePiece.getPosition());
            }
        }
    }

    private void moveLine(Line line, MotionEvent motionEvent) {
        if (line != null && motionEvent != null) {
            boolean move;
            if (line.direction() == Line.Direction.HORIZONTAL) {
                move = line.move(motionEvent.getY() - this.downY, 80.0f);
            } else {
                move = line.move(motionEvent.getX() - this.downX, 80.0f);
            }
            if (move) {
                this.puzzleLayout.update();
                this.puzzleLayout.sortAreas();
                updatePiecesInArea(line, motionEvent);
            }
        }
    }

    private void updatePiecesInArea(Line line, MotionEvent motionEvent) {
        for (int i = 0; i < this.needChangePieces.size(); i++) {
            ((PuzzlePiece) this.needChangePieces.get(i)).updateWith(motionEvent, line);
        }
    }

    private void zoomPiece(PuzzlePiece puzzlePiece, MotionEvent motionEvent) {
        if (puzzlePiece != null && motionEvent != null && motionEvent.getPointerCount() >= 2) {
            float calculateDistance = calculateDistance(motionEvent) / this.previousDistance;
            puzzlePiece.zoomAndTranslate(calculateDistance, calculateDistance, this.midPoint, motionEvent.getX() - this.downX, motionEvent.getY() - this.downY);
        }
    }

    private void dragPiece(PuzzlePiece puzzlePiece, MotionEvent motionEvent) {
        if (puzzlePiece != null && motionEvent != null) {
            puzzlePiece.translate(motionEvent.getX() - this.downX, motionEvent.getY() - this.downY);
        }
    }

    public void replace(View view, String str) {
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            puzzlePiece.setPath(str);
            this.handlingPiece.setView(view);
            PuzzlePiece puzzlePiece2 = this.handlingPiece;
            puzzlePiece2.set(MatrixUtils.generateMatrix(puzzlePiece2, 0.0f));
            invalidate();
        }
    }

    public void flipVertically() {
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            puzzlePiece.postFlipVertically();
            this.handlingPiece.record();
            invalidate();
        }
    }

    public void flipHorizontally() {
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            puzzlePiece.postFlipHorizontally();
            this.handlingPiece.record();
            invalidate();
        }
    }

    public void rotate(float f) {
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece != null) {
            puzzlePiece.postRotate(f);
            this.handlingPiece.record();
            invalidate();
        }
    }

    private PuzzlePiece findHandlingPiece() {
        for (PuzzlePiece puzzlePiece : this.puzzlePieces) {
            if (puzzlePiece.contains(this.downX, this.downY)) {
                return puzzlePiece;
            }
        }
        return null;
    }

    private Line findHandlingLine() {
        for (Line line : this.puzzleLayout.getLines()) {
            if (line.contains(this.downX, this.downY, 40.0f)) {
                return line;
            }
        }
        return null;
    }

    private PuzzlePiece findReplacePiece(MotionEvent motionEvent) {
        for (PuzzlePiece puzzlePiece : this.puzzlePieces) {
            if (puzzlePiece.contains(motionEvent.getX(), motionEvent.getY())) {
                return puzzlePiece;
            }
        }
        return null;
    }

    private List<PuzzlePiece> findNeedChangedPieces() {
        if (this.handlingLine == null) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        for (PuzzlePiece puzzlePiece : this.puzzlePieces) {
            if (puzzlePiece.contains(this.handlingLine)) {
                arrayList.add(puzzlePiece);
            }
        }
        return arrayList;
    }

    private float calculateDistance(MotionEvent motionEvent) {
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    private void calculateMidPoint(MotionEvent motionEvent, PointF pointF) {
        pointF.x = (motionEvent.getX(0) + motionEvent.getX(1)) / 2.0f;
        pointF.y = (motionEvent.getY(0) + motionEvent.getY(1)) / 2.0f;
    }

    public void reset() {
        clearPieces();
        PuzzleLayout puzzleLayout = this.puzzleLayout;
        if (puzzleLayout != null) {
            puzzleLayout.reset();
        }
    }

    public void clearPieces() {
        clearHandlingPieces();
        this.puzzlePieces.clear();
        invalidate();
    }

    public void clearHandlingPieces() {
        this.handlingLine = null;
        this.handlingPiece = null;
        this.replacePiece = null;
        this.needChangePieces.clear();
        invalidate();
    }

    public void addPieces(List<View> list) {
        for (View addPiece : list) {
            addPiece(addPiece);
        }
        postInvalidate();
    }

    public void addPiece(View view) {
        addPiece(view, null);
    }

    public void addPiece(View view, Matrix matrix) {
        addPiece(view, matrix, "");
    }

    public void addPiece(View view, Matrix matrix, String str) {
        int size = this.puzzlePieces.size();
        if (size >= this.puzzleLayout.getAreaCount()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("addPiece: can not add more. the current puzzle layout can contains ");
            stringBuilder.append(this.puzzleLayout.getAreaCount());
            stringBuilder.append(" puzzle piece.");
            Log.e(TAG, stringBuilder.toString());
            return;
        }
        Matrix matrix2;
        Area area = this.puzzleLayout.getArea(size);
        area.setPadding(this.piecePadding);
        PuzzlePiece puzzlePiece = new PuzzlePiece(view, area, new Matrix());
        if (matrix != null) {
            matrix2 = new Matrix(matrix);
        } else {
            matrix2 = MatrixUtils.generateMatrix(area, view, 0.0f);
        }
        puzzlePiece.set(matrix2);
        puzzlePiece.setAnimateDuration(this.duration);
        puzzlePiece.setPath(str);
        this.puzzlePieces.add(puzzlePiece);
        this.areaPieceMap.put(area, puzzlePiece);
        setPiecePadding(this.piecePadding);
        setPieceRadian(this.pieceRadian);
        invalidate();
    }

    public void setSelected(final int i) {
        post(new Runnable() {
            public void run() {
                if (i < PuzzleView.this.puzzlePieces.size()) {
                    PuzzleView puzzleView = PuzzleView.this;
                    puzzleView.previousHandlingPiece = puzzleView.handlingPiece = (PuzzlePiece) puzzleView.puzzlePieces.get(i);
                    if (PuzzleView.this.onPieceSelectedListener != null) {
                        PuzzleView.this.onPieceSelectedListener.onPieceSelected(PuzzleView.this.handlingPiece, i);
                    }
                    PuzzleView.this.invalidate();
                }
            }
        });
    }

    public PuzzlePiece getHandlingPiece() {
        return this.handlingPiece;
    }

    public int getHandlingPiecePosition() {
        PuzzlePiece puzzlePiece = this.handlingPiece;
        if (puzzlePiece == null) {
            return -1;
        }
        return this.puzzlePieces.indexOf(puzzlePiece);
    }

    public boolean hasPieceSelected() {
        return this.handlingPiece != null;
    }

    public void setAnimateDuration(int i) {
        this.duration = i;
        for (PuzzlePiece animateDuration : this.puzzlePieces) {
            animateDuration.setAnimateDuration(i);
        }
    }

    public boolean isNeedDrawLine() {
        return this.needDrawLine;
    }

    public void setNeedDrawLine(boolean z) {
        this.needDrawLine = z;
        this.handlingPiece = null;
        this.previousHandlingPiece = null;
        invalidate();
    }

    public boolean isNeedDrawOuterLine() {
        return this.needDrawOuterLine;
    }

    public void setNeedDrawOuterLine(boolean z) {
        this.needDrawOuterLine = z;
        invalidate();
    }

    public int getLineColor() {
        return this.lineColor;
    }

    public void setLineColor(int i) {
        this.lineColor = i;
        this.linePaint.setColor(i);
        invalidate();
    }

    public int getLineSize() {
        return this.lineSize;
    }

    public void setLineSize(int i) {
        this.lineSize = i;
        invalidate();
    }

    public int getSelectedLineColor() {
        return this.selectedLineColor;
    }

    public void setSelectedLineColor(int i) {
        this.selectedLineColor = i;
        this.selectedAreaPaint.setColor(i);
        invalidate();
    }

    public int getHandleBarColor() {
        return this.handleBarColor;
    }

    public void setHandleBarColor(int i) {
        this.handleBarColor = i;
        this.handleBarPaint.setColor(i);
        invalidate();
    }

    public boolean isTouchEnable() {
        return this.touchEnable;
    }

    public void setTouchEnable(boolean z) {
        this.touchEnable = z;
    }

    public void clearHandling() {
        this.handlingPiece = null;
        this.handlingLine = null;
        this.replacePiece = null;
        this.previousHandlingPiece = null;
        this.needChangePieces.clear();
    }

    public void setPiecePadding(float f) {
        this.piecePadding = f;
        PuzzleLayout puzzleLayout = this.puzzleLayout;
        if (puzzleLayout != null) {
            puzzleLayout.setPadding(f);
            int size = this.puzzlePieces.size();
            for (int i = 0; i < size; i++) {
                PuzzlePiece puzzlePiece = (PuzzlePiece) this.puzzlePieces.get(i);
                if (puzzlePiece.canFilledArea()) {
                    puzzlePiece.moveToFillArea(null);
                } else {
                    puzzlePiece.fillArea(this, true);
                }
            }
        }
        invalidate();
    }

    public void setPieceRadian(float f) {
        this.pieceRadian = f;
        PuzzleLayout puzzleLayout = this.puzzleLayout;
        if (puzzleLayout != null) {
            puzzleLayout.setRadian(f);
        }
        invalidate();
    }

    public void setQuickMode(boolean z) {
        this.quickMode = z;
        invalidate();
    }

    public void setBackgroundColor(int i) {
        super.setBackgroundColor(i);
        PuzzleLayout puzzleLayout = this.puzzleLayout;
        if (puzzleLayout != null) {
            puzzleLayout.setColor(i);
        }
    }

    public void setNeedResetPieceMatrix(boolean z) {
        this.needResetPieceMatrix = z;
    }

    public float getPiecePadding() {
        return this.piecePadding;
    }

    public float getPieceRadian() {
        return this.pieceRadian;
    }

    public List<PuzzlePiece> getPuzzlePieces() {
        int size = this.puzzlePieces.size();
        ArrayList arrayList = new ArrayList(size);
        this.puzzleLayout.sortAreas();
        for (int i = 0; i < size; i++) {
            arrayList.add((PuzzlePiece) this.areaPieceMap.get(this.puzzleLayout.getArea(i)));
        }
        return arrayList;
    }

    public boolean canDrag() {
        return this.canDrag;
    }

    public void setCanDrag(boolean z) {
        this.canDrag = z;
    }

    public boolean canMoveLine() {
        return this.canMoveLine;
    }

    public void setCanMoveLine(boolean z) {
        this.canMoveLine = z;
    }

    public boolean canZoom() {
        return this.canZoom;
    }

    public void setCanZoom(boolean z) {
        this.canZoom = z;
    }

    public boolean canSwap() {
        return this.canSwap;
    }

    public void setCanSwap(boolean z) {
        this.canSwap = z;
    }

    public void setOnPieceSelectedListener(OnPieceSelectedListener onPieceSelectedListener) {
        this.onPieceSelectedListener = onPieceSelectedListener;
    }

    public void setOnPieceSwapListener(OnPieceSwapListener onPieceSwapListener) {
        this.onPieceSwapListener = onPieceSwapListener;
    }
}
