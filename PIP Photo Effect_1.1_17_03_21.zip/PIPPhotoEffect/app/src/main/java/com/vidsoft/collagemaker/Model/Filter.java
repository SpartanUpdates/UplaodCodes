package com.vidsoft.collagemaker.Model;

public class Filter
{
  int thumb;
  String title;

  public Filter(int paramInt, String paramString)
  {
    this.thumb = paramInt;
    this.title = paramString;
  }

  public int getThumb()
  {
    return this.thumb;
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setThumb(int paramInt)
  {
    this.thumb = paramInt;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
}
