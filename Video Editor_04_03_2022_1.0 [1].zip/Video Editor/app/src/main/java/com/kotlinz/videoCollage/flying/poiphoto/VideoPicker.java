package com.kotlinz.videoCollage.flying.poiphoto;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import com.kotlinz.videoCollage.flying.poiphoto.ui.PickVideoActivity;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.VideoAdapter;

import java.util.List;

public class VideoPicker {
    private Configure mConfigure;

    private VideoPicker() {
        this.mConfigure = new Configure();
    }

    private VideoPicker(Configure configure) {
        this.mConfigure = configure;
    }

    public static VideoPicker newInstance() {
        return new VideoPicker();
    }

    public static VideoPicker newInstance(Configure configure) {
        return new VideoPicker(configure);
    }

    public VideoPicker setToolbarColor(int i) {
        this.mConfigure.setToolbarColor(i);
        return this;
    }

    public VideoPicker setToolbarTitleColor(int i) {
        this.mConfigure.setToolbarTitleColor(i);
        return this;
    }

    public VideoPicker setAlbumTitle(String str) {
        this.mConfigure.setAlbumTitle(str);
        return this;
    }

    public VideoPicker setPhotoTitle(String str) {
        this.mConfigure.setPhotoTitle(str);
        return this;
    }

    public VideoPicker setNavIcon(int i) {
        this.mConfigure.setNavIcon(i);
        return this;
    }

    public VideoPicker setStatusBarColor(int i) {
        this.mConfigure.setStatusBarColor(i);
        return this;
    }

    public VideoPicker setMaxNotice(String str) {
        this.mConfigure.setMaxNotice(str);
        return this;
    }

    public VideoPicker setMaxCount(int i) {
        this.mConfigure.setMaxCount(i);
        return this;
    }

    public void pickVideo(Context context) {
        Intent intent = new Intent(context, PickVideoActivity.class);
        intent.putExtra(Define.CONFIGURE, this.mConfigure);
        if (context instanceof Activity) {
            ((Activity) context).startActivityForResult(intent, 95);
            return;
        }
        throw new IllegalStateException("the context need to use activity");
    }

    public void inflate(RecyclerView recyclerView, LayoutManager layoutManager) {
        final VideoAdapter videoAdapter = new VideoAdapter();
        recyclerView.setAdapter(videoAdapter);
        recyclerView.setLayoutManager(layoutManager);
        VideoManager videoManager = new VideoManager(recyclerView.getContext());
        new GetAllVideoTask() {
            public void onPostExecute(List<Video> list) {
                super.onPostExecute(list);
                videoAdapter.refreshData(list);
            }
        }.execute(new VideoManager[]{videoManager});
    }
}
