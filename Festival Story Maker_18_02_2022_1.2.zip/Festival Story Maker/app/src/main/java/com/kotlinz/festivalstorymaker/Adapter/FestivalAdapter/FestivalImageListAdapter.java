package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Models.festival.k;
import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FestivalImageListAdapter extends RecyclerView.Adapter<FestivalImageListAdapter.MyViewHolder> {

    public Activity p;
    public ArrayList<k> q;
    public a r;
    public int s;
    public int t = 0;

    public FestivalImageListAdapter(Activity activity, ArrayList<k> arrayList, a aVar, int i) {
        this.p = activity;
        this.q = arrayList;
        this.r = aVar;
        this.s = i;
    }


    public interface a {
        void a(int i, int i2);
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_festival_frame_list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.cardMain.setCardElevation(this.t == position ? 5.0f : 0.0f);
        holder.imgPro.setVisibility(View.GONE);
        if (q.get(position).p.length() > 0) {
            Glide.with(p).load(q.get(position).p).placeholder(R.drawable.ic_placehoder).into(holder.img);
        }
        holder.img.setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.n(this, position));
    }

    @Override
    public int getItemCount() {
        return q.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.cardMain)
        public CardView cardMain;

        @BindView(R.id.imgBg)
        public ImageView img;

        @BindView(R.id.imgPro)
        public ImageView imgPro;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
