package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.xyz.imagetovideomoviewmaker.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.AlbumAdapterById;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.ImageByAlbumAdapter;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.OnItemClickListner;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.SelectedImageAdapter;
import com.imagetovideomoviemaker.photoslideshowwithmusic.data.ImageData;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.EmptyRecyclerView;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.ExpandIconView;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.VerticalSlidingPanel;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.VerticalSlidingPanel.PanelSlideListener;

import java.io.File;
import java.util.ArrayList;

import static com.imagetovideomoviemaker.photoslideshowwithmusic.NativeAds.nativeads.populateUnifiedNativeAdView;

public class ImageSelectionActivity extends AppCompatActivity implements PanelSlideListener {
    Activity activity = ImageSelectionActivity.this;
    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static boolean isForFirst = false;
    public static ArrayList<ImageData> tempImage = new ArrayList();
    private AlbumAdapterById albumAdapter;
    private ImageByAlbumAdapter albumImagesAdapter;
    private MyApplication application;
    private TextView tvClear;
    private ExpandIconView expandIcon;
    public boolean isFromCameraNotification = false;
    public boolean isFromPreview = false;
    boolean isPause = false;
    private VerticalSlidingPanel panel;
    private View parent;
    private RecyclerView rvAlbum;
    private RecyclerView rvAlbumImages;
    private EmptyRecyclerView rvSelectedImage;
    private SelectedImageAdapter selectedImageAdapter;
    private TextView tvImageCount;
    public static CheckBox chbAllSelect;
    ImageView ivDownarrow;

    ImageView ivback, ivnext;
    TextView tvToolbarTitle;

    private NativeAd nativeAd;

    public void onPanelAnchored(View view) {

    }

    public void onPanelShown(View view) {

    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_select_activity);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageSelectionActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        application = MyApplication.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        isFromCameraNotification = getIntent().hasExtra("isFromCameraNotification");
        MyApplication.isFromPreviewImageSelection = isFromPreview;
        bindView();
        init();
        LoadNativeAds();
        addListner();
    }

    public void scrollToPostion(final int i) {
        this.rvAlbum.postDelayed(new Runnable() {
            public void run() {
                ImageSelectionActivity.this.rvAlbum.scrollToPosition(i);
            }
        }, 300);
    }

    private void init() {
        Utils.setFont(this, tvToolbarTitle);
        Utils.setFont(this, tvImageCount);
        Utils.setFont(this, tvClear);
        if (this.isFromCameraNotification) {
            this.application.getFolderList();
        }
        this.albumAdapter = new AlbumAdapterById(this);
        this.albumImagesAdapter = new ImageByAlbumAdapter(this);
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvAlbum.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        this.rvAlbum.setHasFixedSize(true);
        this.rvAlbum.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.rvAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbum.setAdapter(this.albumAdapter);
        this.rvAlbumImages.setLayoutManager(new GridLayoutManager(getApplicationContext(), 3));
        this.rvAlbumImages.setItemAnimator(new DefaultItemAnimator());
        this.rvAlbumImages.setAdapter(this.albumImagesAdapter);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
        this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
    }

    private void bindView() {
        ivback = findViewById(R.id.iv_back);
        ivnext = findViewById(R.id.iv_next);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        this.tvImageCount = (TextView) findViewById(R.id.tvImageCount);
        this.expandIcon = (ExpandIconView) findViewById(R.id.settings_drag_arrow);
        this.rvAlbum = (RecyclerView) findViewById(R.id.rvAlbum);
        this.rvAlbumImages = (RecyclerView) findViewById(R.id.rvImageAlbum);
        this.rvSelectedImage = (EmptyRecyclerView) findViewById(R.id.rvSelectedImagesList);
        this.panel = (VerticalSlidingPanel) findViewById(R.id.overview_panel);
        this.panel.setEnableDragViewTouchEvents(true);
        this.panel.setDragView(findViewById(R.id.settings_pane_header));
        this.panel.setPanelSlideListener(this);
        this.parent = findViewById(R.id.default_home_screen_panel);
        this.tvClear = (TextView) findViewById(R.id.tv_clear);
        this.chbAllSelect = (CheckBox) findViewById(R.id.chbAllSelect);
        this.ivDownarrow = (ImageView) findViewById(R.id.ivDownarrow);
        chbAllSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean bb) {
                if (chbAllSelect.isChecked()) {
                    Allselect();
                    ivDownarrow.setVisibility(View.VISIBLE);
                }
            }
        });
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivnext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (application.getSelectedImages().size() > 2) {
                    if (MyApplication.isShowAd == 1) {
                        loadDone();
                        MyApplication.isShowAd = 0;
                    } else {
                        if (MyApplication.mInterstitialAd != null) {
                            MyApplication.activity = activity;
                            MyApplication.AdsId = 107;
                            int i = 0;
                            if (isEndFrameExist()) {
                                ImageData imageData = null;
                                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                                list.addAll(application.selectedImages);
                                application.selectedImages.clear();
                                while (i < list.size()) {
                                    if (list.get(i).imagePath.equals(EndFrameFrag.lastsaveTempPath)) {
                                        imageData = list.get(i);
                                    } else {
                                        application.selectedImages.add(list.get(i));
                                    }
                                    ++i;
                                }
                                if (imageData != null) {
                                    application.selectedImages.add(imageData);
                                }
                            }
                            MyApplication.mInterstitialAd.show(activity);
                            MyApplication.isShowAd = 1;

                        } else {
                            loadDone();
                        }
                    }
                } else {
                    Toast.makeText(ImageSelectionActivity.this, R.string.select_more_than_2_images_for_create_video, Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (this.isFromPreview) {
            tvClear.setVisibility(View.GONE);
        }
    }

    public int getItemCount() {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).size();
    }

    public ImageData getItem(final int n) {
        return this.application.getImageByAlbum(this.application.getSelectedFolderId()).get(n);
    }

    int ii;

    private void Allselect() {
        ii = 0;
        while (getItemCount() != ii) {
            final ImageData item = this.getItem(ii);
            this.application.addSelectedImage(item);
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            albumImagesAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
            ++ii;
        }

        Animation animation = AnimationUtils.loadAnimation(ImageSelectionActivity.this, R.anim.bottom_down_slow);
        ivDownarrow.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                ivDownarrow.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    private void addListner() {
        this.tvClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageSelectionActivity.this.clearData();
            }
        });
        this.albumAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object o) {
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
        this.albumImagesAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                ImageSelectionActivity.this.selectedImageAdapter.notifyDataSetChanged();
            }
        });
        this.selectedImageAdapter.setOnItemClickListner(new OnItemClickListner() {
            @Override
            public void onItemClick(View view, Object obj) {
                ImageSelectionActivity.this.tvImageCount.setText(String.valueOf(ImageSelectionActivity.this.application.getSelectedImages().size()));
                ImageSelectionActivity.this.albumImagesAdapter.notifyDataSetChanged();
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 999 && i2 == -1) {
            this.application.selectedImages.remove(MyApplication.TEMP_POSITION);
            ImageData imgData = new ImageData();
            imgData.setImagePath(intent.getExtras().getString("ImgPath"));
            this.application.selectedImages.add(MyApplication.TEMP_POSITION, imgData);
            setupAdapter();
        }
    }

    private void setupAdapter() {
        this.selectedImageAdapter = new SelectedImageAdapter(this);
        this.rvSelectedImage.setLayoutManager(new GridLayoutManager(getApplicationContext(), 4));
        this.rvSelectedImage.setItemAnimator(new DefaultItemAnimator());
        this.rvSelectedImage.setAdapter(this.selectedImageAdapter);
        this.rvSelectedImage.setEmptyView(findViewById(R.id.list_empty));
    }

    protected void onResume() {
        super.onResume();
        if (this.isPause) {
            this.isPause = false;
            this.tvImageCount.setText(String.valueOf(this.application.getSelectedImages().size()));
            this.albumImagesAdapter.notifyDataSetChanged();
            this.selectedImageAdapter.notifyDataSetChanged();
        }
    }

    protected void onPause() {
        super.onPause();
        this.isPause = true;
    }


    private boolean isEndFrameExist() {
        if (EndFrameFrag.lastsaveTempPath == null) {
            return false;
        }
        return new File(EndFrameFrag.lastsaveTempPath).exists();
    }


    private boolean loadDone() {
        final boolean isFromPreview = this.isFromPreview;
        int i = 0;
        if (isFromPreview) {
            if (this.isEndFrameExist()) {
                ImageData imageData = null;
                final ArrayList<ImageData> list = new ArrayList<ImageData>();
                list.addAll(this.application.selectedImages);
                this.application.selectedImages.clear();
                while (i < list.size()) {
                    if (list.get(i).imagePath.equals(EndFrameFrag.lastsaveTempPath)) {
                        imageData = list.get(i);
                    } else {
                        this.application.selectedImages.add(list.get(i));
                    }
                    ++i;
                }
                if (imageData != null) {
                    this.application.selectedImages.add(imageData);
                }
            }
            this.setResult(-1);
            this.finish();
            return true;
        } else {
            final Intent intent = new Intent((Context) this, (Class) ImageEditActivity.class);
            intent.putExtra("isFromCameraNotification", false);
            intent.putExtra("KEY", "FromImageSelection");
            this.startActivity(intent);
        }
        return false;
    }


    public void onBackPressed() {
        if (this.panel.isExpanded()) {
            this.panel.collapsePane();
        } else if (this.isFromCameraNotification) {
            startActivity(new Intent(this, LauncherActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            this.application.clearAllSelection();
            finish();
        } else if (this.isFromPreview) {
            setResult(-1);
            finish();
        } else {
            this.application.videoImages.clear();
            this.application.clearAllSelection();
            startActivity(new Intent(this, LauncherActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
            super.onBackPressed();
        }
    }

    public void onPanelSlide(final View view, final float n) {
        if (this.expandIcon != null) {
            this.expandIcon.setFraction(n, false);
        }
        if (n >= 0.005f) {
            if (this.parent != null && this.parent.getVisibility() != View.VISIBLE) {
                this.parent.setVisibility(View.VISIBLE);
            }
        } else if (this.parent != null && this.parent.getVisibility() == View.VISIBLE) {
            this.parent.setVisibility(View.GONE);
        }
    }

    public void onPanelCollapsed(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.VISIBLE);
        }
        this.selectedImageAdapter.isExpanded = false;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    public void onPanelExpanded(View view) {
        if (this.parent != null) {
            this.parent.setVisibility(View.GONE);
        }
        this.selectedImageAdapter.isExpanded = true;
        this.selectedImageAdapter.notifyDataSetChanged();
    }

    private void clearData() {
        for (int size = this.application.getSelectedImages().size() - 1; size >= 0; size--) {
            this.application.removeSelectedImage(size);
        }
        this.tvImageCount.setText("0");
        this.chbAllSelect.setChecked(false);
        this.selectedImageAdapter.notifyDataSetChanged();
        this.albumImagesAdapter.notifyDataSetChanged();
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ImageSelectionActivity.this.nativeAd != null) {
                            ImageSelectionActivity.this.nativeAd.destroy();
                        }
                        ImageSelectionActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }
}
