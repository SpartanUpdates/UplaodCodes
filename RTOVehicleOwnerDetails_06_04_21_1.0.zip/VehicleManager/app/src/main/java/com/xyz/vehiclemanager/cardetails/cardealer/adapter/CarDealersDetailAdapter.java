package com.xyz.vehiclemanager.cardetails.cardealer.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.cardealer.model.CarDealers;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarDealersDetailAdapter extends RecyclerView.Adapter<CarDealersDetailAdapter.ViewHolder> {

    Context context;
    ArrayList<CarDealers> carDealersList;

    public CarDealersDetailAdapter(Context context, ArrayList<CarDealers> carDealersList) {
        this.context = context;
        this.carDealersList = carDealersList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_cardealers,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.dealerName.setText(carDealersList.get(position).getDealerName());
        holder.dealerAddress.setText(carDealersList.get(position).getDealerAddress());
        holder.dealerContactNumber.setText(carDealersList.get(position).getDealerContactNo());
    }

    @Override
    public int getItemCount() {
        return carDealersList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView dealerName,dealerAddress,dealerContactNumber;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dealerName=itemView.findViewById(R.id.dealerName);
            dealerAddress=itemView.findViewById(R.id.dealerAddress);
            dealerContactNumber=itemView.findViewById(R.id.dealerContactNumber);
        }
    }
}
