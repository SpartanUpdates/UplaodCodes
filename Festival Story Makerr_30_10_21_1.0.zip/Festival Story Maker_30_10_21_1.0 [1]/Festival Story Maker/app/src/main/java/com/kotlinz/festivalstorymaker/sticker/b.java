package com.kotlinz.festivalstorymaker.sticker;

import android.view.MotionEvent;

public class b implements f {
    @Override
    public void a(final StickerView stickerView, final MotionEvent motionEvent) {
        final e b = stickerView.B;
        if (stickerView.h.contains(b)) {
            stickerView.h.remove(b);
            final StickerView.a c = stickerView.C;
            if (c != null) {
                c.e(b);
            }
            if (stickerView.B == b) {
                stickerView.B = null;
            }
            stickerView.invalidate();
        }
    }

    @Override
    public void b(final StickerView stickerView, final MotionEvent motionEvent) {
    }

    @Override
    public void c(final StickerView stickerView, final MotionEvent motionEvent) {
    }
}
