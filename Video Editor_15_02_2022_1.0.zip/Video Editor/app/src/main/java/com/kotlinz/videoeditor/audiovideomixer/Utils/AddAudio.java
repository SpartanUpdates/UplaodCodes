package com.kotlinz.videoeditor.audiovideomixer.Utils;

import android.app.Application;

public class AddAudio extends Application {
    public static String audioName;
    public static String audioPath;
    public static int status;
}
