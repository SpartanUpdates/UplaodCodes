package com.esc.palmreadingfuture.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.legacy.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.esc.palmreadingfuture.database.DataBaseHelper;
import com.esc.palmreadingfuture.adapter.ExpandableListAdapter;
import com.esc.palmreadingfuture.R;
import com.esc.palmreadingfuture.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class SelectLine extends AppCompatActivity {
    private static AppCompatActivity activity;
    private static SharedPreferences.Editor editor;
    public static boolean exitbool = false;
    public static SharedPreferences sharedPreferences;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private DataBaseHelper baseHelper;
    private ImageView button;
    private ArrayList<String> cat;
    private ArrayList<String> cat_eng;
    private ArrayList<String> catid;
    private int cid;
    private RelativeLayout dl;
    private DrawerLayout drawer;
    private ExpandableListView expandablelistview;
    private TextView firstbtntext;
    private ImageView firstbutton;
    private String handimage;
    private int id = 0;
    private ImageView ihand;
    private int lblcnt;
    private float left;
    private LinearLayout lin1;
    private LinearLayout lin2;
    private ExpandableListAdapter listAdapter;
    private HashMap<Integer, List<Integer>> listDataChild;
    private List<Integer> listDataHeader;
    private ListView listview1;
    private FrameLayout main;
    private TextView mountdesc;
    private LinearLayout mountlinear;
    private RelativeLayout myrel;
    private TextView palmdesc;
    public boolean resumebool = false;
    private ArrayList<String> scatid;
    private int scid;
    private String selectedline;
    private String selectedline_eng;
    private TextView tbutton;
    private TextView tdes;
    private float top;
    public String trans;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.main);
        editor = (sharedPreferences = this.getApplicationContext().getSharedPreferences("palmreading", 0)).edit();
        activity = this;
        editor.putInt("visitcount", sharedPreferences.getInt("visitcount", 0) + 1);
        editor.commit();
        trans = Locale.getDefault().getLanguage().toString();
        getSupportActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_toolbar));
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_action_toggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        View inflate = LayoutInflater.from(this).inflate(R.layout.titleview, (ViewGroup) null);
        ((TextView) inflate.findViewById(R.id.title)).setText(getTitle());
        getSupportActionBar().setCustomView(inflate);
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getApplicationContext(), getResources().getString(R.string.db_name));
        baseHelper = dataBaseHelper;
        try {
            dataBaseHelper.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
        cat = new ArrayList<>();
        scatid = new ArrayList<>();
        catid = new ArrayList<>();
        myrel = (RelativeLayout) findViewById(R.id.myrel);
        dl = (RelativeLayout) findViewById(R.id.navlayout);
        lin1 = (LinearLayout) findViewById(R.id.lin1);
        lin2 = (LinearLayout) findViewById(R.id.lin2);
        palmdesc = (TextView) findViewById(R.id.firstviewdescription);
        mountdesc = (TextView) findViewById(R.id.mountdescription);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        main = (FrameLayout) findViewById(R.id.main);
        loadAd();

        if (trans.contains("el") || trans.contains("ko") || trans.contains("da") || trans.contains("th") || trans.contains("ru") || trans.contains("ms") || trans.contains("de") || trans.contains("fr") || trans.contains("it") || trans.contains("zh") || trans.contains("hi") || trans.contains("en") || trans.contains("tr") || trans.contains("in") || trans.contains("pt") || trans.contains("es") || trans.contains("sk") || trans.contains("pl") || trans.contains("iw") || trans.contains("zu") || trans.contains("ro") || trans.contains("af")) {

            lin2.setVisibility(View.INVISIBLE);
        }

        ActionBarDrawerToggle actiontoggle = new ActionBarDrawerToggle(this, this.drawer, R.drawable.ic_action_toggle, R.string.drawer_open, R.string.drawer_close) {

            public void onDrawerClosed(View view) {
                SelectLine.this.getSupportActionBar().setTitle("");
                SelectLine.this.invalidateOptionsMenu();
            }

            @Override
            public void onDrawerOpened(View view) {
                SelectLine.this.getSupportActionBar().setTitle("");
                SelectLine.this.invalidateOptionsMenu();
            }
        };
        this.actionBarDrawerToggle = actiontoggle;
        this.drawer.setDrawerListener(actiontoggle);
        this.drawer.setDrawerListener(new DrawerLayout.SimpleDrawerListener() {

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

            public void onDrawerSlide(View view, float f) {
                super.onDrawerSlide(view, f);
                if (SelectLine.exitbool) {
                    SelectLine.this.drawer.closeDrawers();
                }
            }

            public void onDrawerOpened(View view) {
                super.onDrawerOpened(view);
                if (SelectLine.exitbool) {
                    SelectLine.this.drawer.closeDrawers();
                }
            }
        });
        this.drawer.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
        this.drawer.openDrawer(this.dl);
        this.ihand = (ImageView) findViewById(R.id.handline);
        this.button = (ImageView) findViewById(R.id.button);
        this.firstbutton = (ImageView) findViewById(R.id.firstbutton);
        this.firstbtntext = (TextView) findViewById(R.id.firstbtntext);
        this.tbutton = (TextView) findViewById(R.id.txt_start);
        TextView textView2 = (TextView) findViewById(R.id.txt_description);
        this.tdes = textView2;
        textView2.setMovementMethod(new ScrollingMovementMethod());
        this.main.setVisibility(View.VISIBLE);
        this.listview1 = (ListView) findViewById(R.id.listview);
        this.mountlinear = (LinearLayout) findViewById(R.id.mountlinear);
        this.expandablelistview = (ExpandableListView) findViewById(R.id.expandableList);
        if (!this.trans.contains("el") || this.trans.contains("ko") || this.trans.contains("da") || this.trans.contains("th") || this.trans.contains("ru") || this.trans.contains("ms") || this.trans.contains("de") || this.trans.contains("fr") || this.trans.contains("it") || this.trans.contains("zh") || this.trans.contains("hi") || this.trans.contains("en") || this.trans.contains("en") || this.trans.contains("in") || this.trans.contains("pt") || this.trans.contains("es")) {
            this.listview1.setVisibility(View.INVISIBLE);
            this.expandablelistview.setVisibility(View.VISIBLE);
            prepareListData();
            ExpandableListAdapter expandableListAdapter = new ExpandableListAdapter(this, this.listDataHeader, this.listDataChild);
            this.listAdapter = expandableListAdapter;
            this.expandablelistview.setAdapter(expandableListAdapter);
            this.mountlinear.setVisibility(View.GONE);
        } else {
            this.listview1.setVisibility(View.INVISIBLE);
            this.expandablelistview.setVisibility(View.VISIBLE);
            prepareListData();
            ExpandableListAdapter expandableListAdapter2 = new ExpandableListAdapter(this, this.listDataHeader, this.listDataChild);
            this.listAdapter = expandableListAdapter2;
            this.expandablelistview.setAdapter(expandableListAdapter2);
        }
        this.expandablelistview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i2, long j) {
                try {
                    SelectLine.this.cat = SelectLine.this.baseHelper.getSubCategory(i);
                    SelectLine.this.cat_eng = SelectLine.this.baseHelper.getImagename(i);
                    SelectLine.this.drawer.closeDrawer(SelectLine.this.dl);
                    SelectLine.this.tdes.setVisibility(View.VISIBLE);
                    SelectLine.this.ihand.setVisibility(View.VISIBLE);
                    SelectLine.this.scatid = SelectLine.this.baseHelper.getSubCategoryId(i);
                    SelectLine.this.catid = SelectLine.this.baseHelper.getCategoryId();
                    SelectLine.this.tbutton.setText(SelectLine.this.getResources().getString(R.string.btn_continue));
                    SelectLine.this.selectedline = SelectLine.this.cat.get(i2);
                    SelectLine.this.selectedline_eng = SelectLine.this.cat_eng.get(i2);
                    SelectLine.this.lin1.setVisibility(View.INVISIBLE);
                    SelectLine.this.lin2.setVisibility(View.VISIBLE);
                    String imgName = SelectLine.this.baseHelper.getImgName(i2 + 1, i);
                    SelectLine.this.scid = Integer.parseInt(SelectLine.this.scatid.get(i2));
                    SelectLine.this.cid = Integer.parseInt(SelectLine.this.catid.get(i));

                    if (i == 1) {
                            SelectLine.this.lin2.setVisibility(View.VISIBLE);
                            SelectLine.this.lin1.setVisibility(View.INVISIBLE);
                            final Intent intent = new Intent(view.getContext(), (Class) ShowTypesOfLines.class);
                            final Bundle bundle = new Bundle();
                            bundle.putString("line", SelectLine.this.selectedline);
                            bundle.putString("line_eng", SelectLine.this.selectedline_eng);
                            final StringBuilder sb2 = new StringBuilder();
                            sb2.append("");
                            sb2.append(SelectLine.this.selectedline_eng);
                            bundle.putInt("scid", SelectLine.this.scid);
                            bundle.putInt("cid", SelectLine.this.cid);
                            intent.putExtras(bundle);
                            SelectLine.this.startActivity(intent);
                    }else {
                        SelectLine.this.handimage = imgName;
                        SelectLine.this.handimage = handimage.toLowerCase().replaceAll(" ", "").replaceAll("reading", "");
                        int identifier = getResources().getIdentifier(handimage.toLowerCase().replaceAll(" ", ""), "drawable", getPackageName());
                        String categoryHead = SelectLine.this.baseHelper.getCategoryHead(SelectLine.this.scid, SelectLine.this.cid);
                        TextView textView = SelectLine.this.tdes;
                        textView.setText("" + categoryHead);
                        ihand.setImageResource(identifier);
                        if (RemoveTextViews()) {
                            if (selectedline.equals(SelectLine.this.getResources().getString(R.string.heartlinereading))) {
                                setLabel(70.0f, 25.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                                lblcnt = 1;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.lifelinereading))) {
                                setLabel(70.0f, 33.0f, SelectLine.this.getResources().getString(R.string.lifelabel));
                                SelectLine.this.lblcnt = 1;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.headlinereading))) {
                                setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                                setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                                lblcnt = 2;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.marriagelinereading))) {
                                setLabel(75.0f, 30.0f, SelectLine.this.getResources().getString(R.string.marriagelabel1));
                                setLabel(0.0f, 55.0f, SelectLine.this.getResources().getString(R.string.marriagelabel2));
                                lblcnt = 2;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.fatelinereading))) {
                                setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                                setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                                setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                                setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.fatelabel4));
                                lblcnt = 4;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.successlinereading))) {
                                setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                                setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                                setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                                setLabel(75.0f, 70.0f, SelectLine.this.getResources().getString(R.string.fatelabel4));
                                setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.successlabel));
                                lblcnt = 5;
                            } else if (selectedline.equals(SelectLine.this.getResources().getString(R.string.travellinereading))) {
                                setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.marriagelabel2));
                                setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.travellabel));
                                setLabel(70.0f, 25.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                                lblcnt = 3;
                            }
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    e.getCause();
                    e.getMessage();
                    return true;
                }
                return true;
            }
        });
        this.listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    SelectLine.this.drawer.closeDrawer(SelectLine.this.dl);
                    SelectLine.this.tdes.setVisibility(View.VISIBLE);
                    SelectLine.this.ihand.setVisibility(View.VISIBLE);
                    SelectLine.this.tbutton.setText(SelectLine.this.getResources().getString(R.string.btn_continue));
                    SelectLine.this.selectedline = SelectLine.this.cat.get(i);
                    SelectLine.this.selectedline_eng = SelectLine.this.cat_eng.get(i);
                    String imgName = SelectLine.this.baseHelper.getImgName(i + 1);
                    SelectLine.this.handimage = imgName;
                    SelectLine.this.handimage = SelectLine.this.handimage.toLowerCase().replaceAll(" ", "").replaceAll("reading", "");
                    int identifier = SelectLine.this.getResources().getIdentifier(SelectLine.this.handimage.toLowerCase().replaceAll(" ", ""), "drawable", SelectLine.this.getPackageName());
                    SelectLine.this.cid = Integer.parseInt(SelectLine.this.catid.get(i));
                    String categoryHead = SelectLine.this.baseHelper.getCategoryHead(SelectLine.this.cid);
                    TextView textView = SelectLine.this.tdes;
                    textView.setText("" + categoryHead);
                    SelectLine.this.ihand.setImageResource(identifier);

                    if (SelectLine.this.RemoveTextViews()) {

                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.heartlinereading))) {
                            SelectLine.this.setLabel(70.0f, 25.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                            SelectLine.this.lblcnt = 1;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.lifelinereading))) {
                            SelectLine.this.setLabel(70.0f, 33.0f, SelectLine.this.getResources().getString(R.string.lifelabel));
                            SelectLine.this.lblcnt = 1;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.headlinereading))) {
                            SelectLine.this.setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                            SelectLine.this.setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                            SelectLine.this.lblcnt = 2;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.marriagelinereading))) {
                            SelectLine.this.setLabel(75.0f, 30.0f, SelectLine.this.getResources().getString(R.string.marriagelabel1));
                            SelectLine.this.setLabel(0.0f, 55.0f, SelectLine.this.getResources().getString(R.string.marriagelabel2));
                            SelectLine.this.lblcnt = 2;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.fatelinereading))) {
                            SelectLine.this.setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                            SelectLine.this.setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                            SelectLine.this.setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                            SelectLine.this.setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.fatelabel4));
                            SelectLine.this.lblcnt = 4;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.successlinereading))) {
                            SelectLine.this.setLabel(80.0f, 35.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                            SelectLine.this.setLabel(75.0f, 60.0f, SelectLine.this.getResources().getString(R.string.headlabel2));
                            SelectLine.this.setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.heartlabel));
                            SelectLine.this.setLabel(75.0f, 70.0f, SelectLine.this.getResources().getString(R.string.fatelabel4));
                            SelectLine.this.setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.successlabel));
                            SelectLine.this.lblcnt = 5;
                            return;
                        }
                        if (SelectLine.this.selectedline.equals(SelectLine.this.getResources().getString(R.string.travellinereading))) {
                            SelectLine.this.setLabel(0.0f, 45.0f, SelectLine.this.getResources().getString(R.string.marriagelabel2));
                            SelectLine.this.setLabel(0.0f, 60.0f, SelectLine.this.getResources().getString(R.string.travellabel));
                            SelectLine.this.setLabel(70.0f, 25.0f, SelectLine.this.getResources().getString(R.string.headlabel1));
                            SelectLine.this.lblcnt = 3;
                            return;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    e.getCause();
                    e.getMessage();
                    Toast.makeText(SelectLine.this.getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        this.firstbtntext.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                SelectLine.this.drawer.openDrawer(SelectLine.this.dl);
            }
        });
        this.tbutton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    if (SelectLine.this.tbutton.getText().equals(SelectLine.this.getResources().getString(R.string.start))) {
                        SelectLine.this.drawer.openDrawer(SelectLine.this.dl);
                        return;
                    }
                    SelectLine.this.button.setEnabled(false);
                    Intent intent = new Intent(SelectLine.this, ShowTypesOfLines.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("line", SelectLine.this.selectedline);
                    bundle.putString("line_eng", SelectLine.this.selectedline_eng);
                    bundle.putInt("scid", SelectLine.this.scid);
                    bundle.putInt("cid", SelectLine.this.cid);
                    intent.putExtras(bundle);
                    SelectLine.this.startActivity(intent);
                }
            }
        });
        this.lin1.setVisibility(View.VISIBLE);
        this.lin2.setVisibility(View.INVISIBLE);

        TextView textView22 = (TextView) findViewById(R.id.txt_description);
        this.tdes = textView22;
        textView22.setMovementMethod(new ScrollingMovementMethod());
        this.main.setVisibility(View.VISIBLE);

        if (!this.trans.contains("el")) {
        }
        this.listview1.setVisibility(View.INVISIBLE);
        this.expandablelistview.setVisibility(View.VISIBLE);
        prepareListData();
        ExpandableListAdapter expandableListAdapter3 = new ExpandableListAdapter(this, this.listDataHeader, this.listDataChild);
        this.listAdapter = expandableListAdapter3;
        this.expandablelistview.setAdapter(expandableListAdapter3);
    }

    private void prepareListData() {
        this.listDataHeader = new ArrayList<Integer>();
        this.listDataChild = new HashMap<Integer, List<Integer>>();
        final boolean contains = this.trans.contains("el");
        final String s = "pt";
        if (!contains && !this.trans.contains("ko") && !this.trans.contains("da") && !this.trans.contains("th") && !this.trans.contains("ru") && !this.trans.contains("ms") && !this.trans.contains("de") && !this.trans.contains("fr") && !this.trans.contains("it") && !this.trans.contains("zh") && !this.trans.contains("hi") && !this.trans.contains("en") && !this.trans.contains("tr") && !this.trans.contains("in")) {
            if (!this.trans.contains(s)) {
                if (!this.trans.contains("es")) {
                    this.listDataHeader.add(R.string.palmreading);
                }
            }
        }
        this.listDataHeader.add(R.string.palmreading);
        this.listDataHeader.add(R.string.mountreading);

        final ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(R.string.heartlinereading);
        list.add(R.string.lifelinereading);
        list.add(R.string.headlinereading);
        list.add(R.string.marriagelinereading);
        list.add(R.string.fatelinereading);
        list.add(R.string.successlinereading);
        list.add(R.string.travellinereading);
        final ArrayList<Integer> list2 = new ArrayList<Integer>();
        list2.add(R.string.mountofmars);
        list2.add(R.string.mountofjupiter);
        list2.add(R.string.mountofsaturn);
        list2.add(R.string.mountofsun);
        list2.add(R.string.mountofmercury);
        list2.add(R.string.mountofmoon);
        list2.add(R.string.mountofvenus);
        this.listDataChild.put(this.listDataHeader.get(0), list);
        this.listDataChild.put(this.listDataHeader.get(1), list2);
    }

    public boolean isOnline() {
        NetworkInfo netInfo = ((ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            return false;
        }
        return true;
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(SelectLine.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        if (SelectLine.this.tbutton.getText().equals(SelectLine.this.getResources().getString(R.string.start))) {
                            SelectLine.this.drawer.openDrawer(SelectLine.this.dl);
                            return;
                        }
                        SelectLine.this.button.setEnabled(false);
                        Intent intent = new Intent(SelectLine.this, ShowTypesOfLines.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("line", SelectLine.this.selectedline);
                        bundle.putString("line_eng", SelectLine.this.selectedline_eng);
                        bundle.putInt("scid", SelectLine.this.scid);
                        bundle.putInt("cid", SelectLine.this.cid);
                        intent.putExtras(bundle);
                        SelectLine.this.startActivity(intent);
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onResume() {
        this.button.setEnabled(true);
        if (this.trans.contains("el") || this.trans.contains("ko") || this.trans.contains("da") || this.trans.contains("th") || this.trans.contains("ru") || this.trans.contains("ms") || this.trans.contains("de") || this.trans.contains("fr") || this.trans.contains("it") || this.trans.contains("zh") || this.trans.contains("hi") || this.trans.contains("en") || this.trans.contains("tr") || this.trans.contains("in") || this.trans.contains("pt") || this.trans.contains("es") || this.trans.contains("sk") || this.trans.contains("pl") || this.trans.contains("iw") || this.trans.contains("zu") || this.trans.contains("ro") || this.trans.contains("af")) {
            if (this.resumebool) {
                Intent intent = new Intent(getApplicationContext(), ShowTypesOfLines.class);
                Bundle bundle = new Bundle();
                bundle.putString("line", this.selectedline);
                bundle.putString("line_eng", this.selectedline_eng);
                bundle.putInt("scid", this.scid);
                bundle.putInt("cid", this.cid);
                intent.putExtras(bundle);
                startActivity(intent);
                this.resumebool = false;
            }
            this.expandablelistview.setAdapter(this.listAdapter);
            this.lin1.setVisibility(View.VISIBLE);
            this.lin2.setVisibility(View.INVISIBLE);
        }
        if (exitbool) {
            this.main.setVisibility(View.INVISIBLE);
        }
        super.onResume();
    }

    public void onBackPressed() {
        if (this.drawer.isDrawerOpen((int) GravityCompat.START)) {
            this.drawer.closeDrawer((int) GravityCompat.START);
        }
        exitbool = true;
        startActivity(new Intent(SelectLine.this, HomeActivity.class));
        finish();
    }

    public boolean RemoveTextViews() {
        this.id = 0;
        while (true) {
            int i2 = this.id;
            if (i2 <= this.lblcnt) {
                View findViewById = findViewById(i2);
                if (findViewById instanceof TextView) {
                    this.myrel.removeView(findViewById);
                }
                this.id++;
            } else {
                this.id = 0;
                return true;
            }
        }
    }

    public void setLabel(float f, float f2, String str) {
        TextView textView = new TextView(getApplicationContext());
        textView.setId(this.id);
        this.id++;
        textView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        this.myrel.addView(textView);
        textView.setTextColor(getResources().getColor(R.color.text_color1));
        textView.setVisibility(View.VISIBLE);
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) textView.getLayoutParams();
        float width = (float) this.ihand.getWidth();
        float height = (float) this.ihand.getHeight();
        if ((getResources().getConfiguration().screenLayout & 15) == 1) {
            textView.setTextSize(10.0f);
            textView.setMaxWidth(Math.round(width / 3.0f));
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 2) {
            textView.setTextSize(11.0f);
            textView.setMaxWidth(Math.round(width / 3.0f));
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(16.0f);
            textView.setMaxWidth(Math.round(width / 3.3f));
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(18.0f);
            textView.setMaxWidth(Math.round(width / 2.5f));
        }
        float f3 = (f / 100.0f) * width;
        this.left = f3;
        this.top = (f2 / 100.0f) * height;
        marginLayoutParams.setMargins(Math.round(f3), Math.round(this.top), 0, 0);
        textView.setText("" + str);
        textView.setGravity(1);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        this.actionBarDrawerToggle.onConfigurationChanged(configuration);
    }

    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        this.actionBarDrawerToggle.syncState();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (this.actionBarDrawerToggle.onOptionsItemSelected(menuItem)) {
            return true;
        }
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }
}
