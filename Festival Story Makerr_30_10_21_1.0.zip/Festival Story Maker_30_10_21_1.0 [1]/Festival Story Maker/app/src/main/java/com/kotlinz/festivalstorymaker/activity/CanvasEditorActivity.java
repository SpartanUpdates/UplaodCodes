package com.kotlinz.festivalstorymaker.activity;


import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.LoginFilter;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Interface.g;
import com.kotlinz.festivalstorymaker.Interface.x8;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.StickerView.BitmapStickerIcon;
import com.kotlinz.festivalstorymaker.StickerView.DeleteIconEvent;
import com.kotlinz.festivalstorymaker.StickerView.FlipHorizontallyEvent;
import com.kotlinz.festivalstorymaker.StickerView.Sticker;
import com.kotlinz.festivalstorymaker.StickerView.StickerView;
import com.kotlinz.festivalstorymaker.StickerView.TextSticker;
import com.kotlinz.festivalstorymaker.StickerView.ZoomIconEvent;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.Utils.MagnifierView;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePicker;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerActivity;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ImagePickerSavePath;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.ReturnMode;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.features.cameraonly.CameraOnlyConfig;
import com.kotlinz.festivalstorymaker.esafirm.imagepicker.model.Image;
import com.kotlinz.festivalstorymaker.Other.g.c;
import com.kotlinz.festivalstorymaker.Listener.SetListener.AddWaterMark;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CEBorderedTextViewTouchListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CEFontHeight;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CEFontListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CEFontSpacing;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CanvadEditorColorListListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CanvasEditorGestureListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CardEditor;
import com.kotlinz.festivalstorymaker.Listener.SetListener.ECOperationListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.ImageListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CanvasEditTouch;
import com.kotlinz.festivalstorymaker.Listener.SetListener.l2;
import com.kotlinz.festivalstorymaker.Listener.SetListener.EditDialogOnGlobalLayoutListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CanvasEditorDilogGestureListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CanvasEditDailogTouchListener;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CETextSticker;
import com.kotlinz.festivalstorymaker.Listener.SetListener.CETextStickerView;
import com.kotlinz.festivalstorymaker.multiTouch.Vector2D;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.squareup.picasso.Picasso;
import com.yalantis.ucrop.UCropActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CanvasEditorActivity extends BaseActivity implements c, MagnifierView.c, FontListAdapter.a, ColorListAdapter.a, g, x8, ImageStickerViewNew.b {
    Activity activity = CanvasEditorActivity.this;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView imgAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView imgAlignCenter;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView imgAlignLeft;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView imgAlignRight;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView imgAllCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView imgCaps;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView imgColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView imgFirstCap;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView imgFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView imgLine;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView imgSmall;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView imgSpace;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSquareSize)
    public ImageView imgSquareSize;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgStorySize)
    public ImageView imgStorySize;
    @BindView(com.kotlinz.festivalstorymaker.R.id.imgVerticalSize)
    public ImageView imgVerticalSize;


    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView listColor;
    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView listFont;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout llCaps;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llChangeViewType)
    public LinearLayout llChangeViewType;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llColors;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llList)
    public LinearLayout llList;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;
    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog)
    public RelativeLayout rlBottomMoveDeleteDialog;
    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;

    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView scroll;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar seekBarFontHeight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar seekBarFontSpacing;

    public static int A1 = 0;
    public static float B1 = 0.0f;
    public static float C1 = 0.0f;
    public static float D1 = -1.0f;
    public static float E1 = 0.0f;
    public static ArrayList<com.kotlinz.festivalstorymaker.Models.g> F1;
    public static ArrayList<com.kotlinz.festivalstorymaker.Models.g> G1;
    public static ArrayList<ImageView> H1;
    public static ImageView I1;
    public static RecyclerView J1;
    public static RecyclerView K1;
    public static RecyclerView L1;
    public static RecyclerView M1;
    public static String N1;
    public static boolean O1 = false;
    public static boolean P1 = false;
    public static boolean Q1 = false;
    public static boolean R1 = false;
    public static boolean S1 = false;
    public static boolean T1 = false;
    public static boolean U1;
    public static boolean V1;
    public static boolean W1;
    public static MagnifierView.c X1;
    public static MagnifierView Y1;
    public static RelativeLayout x1;
    public static ImageView y1;
    public static TextView z1;
    public String D0;
    public String E0;
    public String F0;
    public int G0;
    public int H0;
    public com.kotlinz.festivalstorymaker.Models.h I = new com.kotlinz.festivalstorymaker.Models.h();
    public int I0;
    public CardView cardView;
    public int J0;
    public CardView K;
    public int K0;
    public x8 L;
    public int L0;
    public int M0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> N;
    public int N0;
    public List<View> O;
    public AppConstant O0;
    public List<View> P;
    public boolean P0;
    public ArrayList<StickerView> Q;
    public boolean Q0;
    public ArrayList<Boolean> R;
    public boolean R0;
    public ArrayList<Boolean> S;
    public boolean S0;
    public ArrayList<ArrayList<ImageView>> T;
    public boolean T0;
    public ArrayList<ArrayList<View>> U;
    public boolean U0;
    public ArrayList<ArrayList<View>> V;
    public boolean V0;
    public ArrayList<ArrayList<View>> W;
    public ArrayList<ArrayList<View>> X;
    public boolean X0;
    public RelativeLayout Y;
    public double Y0;
    public double Z0;
    public float a1;
    public FrameLayout b0;
    public float b1;
    public FrameLayout c0;
    public int[][] c1;
    public FrameLayout d0;
    public int[] d1;
    public FrameLayout e0;
    public ArrayList<Integer> e1;
    public RelativeLayout f0;
    public boolean f1;
    public ImageView g0;
    public View g1;
    public ArrayList<String> h0;
    public float h1;
    public ArrayList<ArrayList<Integer>> i0;
    public float i1;
    public com.kotlinz.festivalstorymaker.Other.g.a M;

    public ArrayList<Float> j0;
    public ImageStickerViewNew j1;
    public ArrayList<Float> k0;
    public ImageStickerViewNew k1;
    public ArrayList<Float> l0;
    public ImageStickerViewNew.b l1;

    public ArrayList<ImageView> m0;
    public boolean m1;
    public ArrayList<View> n0;
    public Dialog n1;
    public ArrayList<View> o0;
    public FontListAdapter o1;
    public ArrayList<View> p0;
    public com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter p1;
    public ArrayList<View> q0;
    public int q1;
    public ArrayList<FrameLayout> r0;
    public int r1;
    public ArrayList<RelativeLayout> s0;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.z.c> s1;

    public ArrayList<FrameLayout> t0;
    public TextStickerViewNew1 t1;

    public ArrayList<FrameLayout> u0;
    public boolean u1;
    public ArrayList<FrameLayout> v0;
    public com.kotlinz.festivalstorymaker.Models.z.c v1;
    public ArrayList<String> w0;
    public Font w1;
    public Utils y0;
    public String z0;

    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> W0;
    public ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>> Z;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> a0;

    APIInterface apiInterface;

    String FilePath;

    public String IsFrom;

    public CanvasEditorActivity() {
        this.E0 = "NEW_ARRIVAL_STICKER";
        this.F0 = "";
        this.G0 = 0;
        this.K0 = -1;
        this.L0 = -1;
        this.M0 = 0;
        this.N0 = 7;
        this.P0 = false;
        this.Q0 = false;
        this.R0 = false;
        this.S0 = false;
        this.T0 = false;
        this.U0 = false;
        this.V0 = true;
        this.W0 = new ArrayList<com.kotlinz.festivalstorymaker.Models.a>();
        this.X0 = false;
        this.f1 = false;
        this.m1 = false;
        this.q1 = -1;
        this.r1 = -1;
        this.s1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.z.c>();
        this.u1 = false;
    }

    public static void j0(final CanvasEditorActivity canvasEditorActivity) {
        if (!canvasEditorActivity.S0) {
            for (int i = 0; i < canvasEditorActivity.t0.size(); ++i) {
                for (int j = 0; j < canvasEditorActivity.t0.get(i).getChildCount(); ++j) {
                    if (canvasEditorActivity.t0.get(i).getChildAt(j) instanceof ImageStickerViewNew) {
                        canvasEditorActivity.t0.get(i).removeViewAt(j);
                    }
                }
                canvasEditorActivity.t0.get(i).requestLayout();
            }
        }
    }

    public static void k0(final CanvasEditorActivity canvasEditorActivity, final View view) {
        if (canvasEditorActivity != null) {
            final AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation.setDuration(700L);
            alphaAnimation.setStartOffset(100L);
            alphaAnimation.setRepeatMode(2);
            alphaAnimation.setRepeatCount(2);
            view.startAnimation(alphaAnimation);
            return;
        }
        throw null;
    }

    public void A0(final Bitmap bitmap, Bitmap scaledBitmap, final ImageView imageView) {
        scaledBitmap = Bitmap.createScaledBitmap(scaledBitmap, bitmap.getWidth(), bitmap.getHeight(), true);
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bitmap2);
        final Paint paint = new Paint(1);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(scaledBitmap, 0.0f, 0.0f, paint);
        paint.setXfermode(null);
        imageView.setImageBitmap(bitmap2);
        imageView.requestLayout();
        imageView.invalidate();
    }

    @Override
    public void B(final Typeface c, final int f) {
        final Font font = this.t1.getFont();
        this.w1 = font;
        font.c = c;
        this.t1.setFont(font);
        final com.kotlinz.festivalstorymaker.Models.z.c v1 = this.s1.get((int) this.t1.getTag());
        this.v1 = v1;
        v1.f = f;
        this.s1.set((int) this.t1.getTag(), this.v1);
    }

    public final void B0(final boolean b) {
        final RelativeLayout rlFull = this.rlFull;
        final int n = 0;
        int visibility;
        if (b) {
            visibility = 0;
        } else {
            visibility = 8;
        }
        rlFull.setVisibility(visibility);
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, 2131296827, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        int visibility2;
        if (b) {
            visibility2 = n;
        } else {
            visibility2 = 8;
        }
        viewById.setVisibility(visibility2);
    }

    public final void C0(final FrameLayout frameLayout, final View view, final TextView textView) {
        this.w0();
        if (!this.m1) {
            TextInputDilaog.s0(this, textView.getText().toString(), false, "").m0 = new TextInputDilaog.d() {
                @Override
                public void a(final String text, final int n) {
                    textView.setBackground(null);
                    if (text.length() == 0) {
                        frameLayout.removeView(view);
                        frameLayout.requestLayout();
                        return;
                    }
                    textView.setText(text);
                }

                @Override
                public void b(final String text) {
                    textView.setBackground(null);
                    if (text.length() == 0) {
                        frameLayout.removeView(view);
                        frameLayout.requestLayout();
                        return;
                    }
                    textView.setText(text);
                }
            };
            return;
        }
        this.m1 = false;
    }

    @Override
    public void D(final int d) {
        final Font font = this.t1.getFont();
        this.w1 = font;
        font.a = Color.parseColor(super.colorList[d]);
        this.t1.setFont(this.w1);
        final com.kotlinz.festivalstorymaker.Models.z.c v1 = this.s1.get((int) this.t1.getTag());
        this.v1 = v1;
        v1.d = d;
        this.s1.set((int) this.t1.getTag(), this.v1);
    }

    public final void D0(final boolean b) {
        if (b) {
            this.r0(this.imgFont);
            final com.kotlinz.festivalstorymaker.Models.z.c c = this.s1.get((int) this.t1.getTag());
            this.q1 = c.d;
            this.r1 = c.f;
            this.seekBarFontSpacing.setProgress(c.a);
            this.seekBarFontHeight.setProgress(c.b);
            this.p1.k(this.q1);
            this.o1.k(this.r1);
            this.o0(c.c);
            this.p0(c.e);
        }
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, com.kotlinz.festivalstorymaker.R.id.llTextEditor, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        int visibility;
        if (b) {
            visibility = 0;
        } else {
            visibility = 8;
        }
        viewById.setVisibility(visibility);
    }


    public class l implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            CanvasEditorActivity.L1.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            CanvasEditorActivity.L1.getLayoutParams().height = CanvasEditorActivity.L1.getWidth();
            CanvasEditorActivity.L1.requestLayout();
            RecyclerView recyclerView = CanvasEditorActivity.L1;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(canvasEditorActivity, canvasEditorActivity.e1, canvasEditorActivity.H0, canvasEditorActivity.L, false, recyclerView.getWidth()));
        }
    }

    public class m implements ViewTreeObserver.OnGlobalLayoutListener {
        public void onGlobalLayout() {
            CanvasEditorActivity.J1.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            CanvasEditorActivity.J1.getLayoutParams().height = CanvasEditorActivity.J1.getWidth();
            CanvasEditorActivity.J1.requestLayout();
            RecyclerView recyclerView = CanvasEditorActivity.J1;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(canvasEditorActivity, canvasEditorActivity.e1, canvasEditorActivity.H0, canvasEditorActivity.L, true, recyclerView.getWidth()));
        }
    }

    public final void F0(String var1, int var2, boolean var3) {
        Bitmap var7 = Utils.g(this, Uri.fromFile(new File(var1)));
        var7.compress(Bitmap.CompressFormat.PNG, 100, new ByteArrayOutputStream());
        int[][] var8 = Utils.s(var7);
        this.c1 = var8;
        this.d1 = com.kotlinz.festivalstorymaker.Other.l.n.a.a.a.aa.a(var8, 25);
        this.e1 = new ArrayList();
        int[] var9 = this.d1;
        int var4 = var9.length;

        int var5;
        for (var5 = 0; var5 < var4; ++var5) {
            int var6 = var9[var5];
            this.e1.add(var6);
        }

        this.e1.add(-1);
        this.e1.add(-16777216);
        this.e1.add(null);
        ArrayList var10 = this.i0;
        if (var3) {
            var5 = var10.size();
            var2 = this.H0;
            if (var5 > var2) {
                this.i0.set(var2, this.e1);
            } else {
                this.i0.add(this.e1);
            }

            L1.getViewTreeObserver().addOnGlobalLayoutListener(new l());
            J1.getViewTreeObserver().addOnGlobalLayoutListener(new m());
        } else {
            var10.add(this.e1);
            ++var2;
            List var11 = this.h0;
            if (var11 != null && var11.size() > var2) {
                Utils.d();
                this.F0(this.h0.get(var2), var2, false);
            }
        }

    }


    public class k implements ViewTreeObserver.OnGlobalLayoutListener {
        public final RecyclerView e;
        public final int f;

        public k(RecyclerView recyclerView, int i) {
            this.e = recyclerView;
            this.f = i;
        }

        public void onGlobalLayout() {
            this.e.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            this.e.getLayoutParams().height = this.e.getWidth() + 10;
            this.e.requestLayout();
            RecyclerView recyclerView = this.e;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(canvasEditorActivity, canvasEditorActivity.i0.get(this.f), this.f, CanvasEditorActivity.this.L, false, this.e.getWidth()));
        }
    }

    public class o implements ViewTreeObserver.OnGlobalLayoutListener {
        public final RecyclerView e;
        public final int f;

        public o(RecyclerView recyclerView, int i) {
            this.e = recyclerView;
            this.f = i;
        }

        public void onGlobalLayout() {
            this.e.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            this.e.getLayoutParams().height = this.e.getWidth() + 10;
            this.e.requestLayout();
            RecyclerView recyclerView = this.e;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            recyclerView.setAdapter(new com.kotlinz.festivalstorymaker.Adapter.a0(canvasEditorActivity, canvasEditorActivity.i0.get(this.f), this.f, CanvasEditorActivity.this.L, true, this.e.getWidth()));
        }
    }

    public class s implements View.OnClickListener {
        public final int e;
        public final FrameLayout f;
        public final RelativeLayout g;
        public final ImageView h;
        public final FrameLayout i;
        public final RecyclerView j;
        public final RecyclerView k;
        public final CardView l;
        public final CardView m;
        public final RelativeLayout n;
        public final TextView o;

        public s(int i, FrameLayout frameLayout, RelativeLayout relativeLayout, ImageView imageView, FrameLayout frameLayout2, RecyclerView recyclerView, RecyclerView recyclerView2, CardView cardView, CardView cardView2, RelativeLayout relativeLayout2, TextView textView) {
            this.e = i;
            this.f = frameLayout;
            this.g = relativeLayout;
            this.h = imageView;
            this.i = frameLayout2;
            this.j = recyclerView;
            this.k = recyclerView2;
            this.l = cardView;
            this.m = cardView2;
            this.n = relativeLayout2;
            this.o = textView;
        }

        public void onClick(View view) {
            boolean y;
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            int i = canvasEditorActivity.J0;
            if (i >= 10) {
                y = Utils.y(canvasEditorActivity, true);
            } else {
                canvasEditorActivity.J0 = i + 1;
                com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().g(AppConstant.SuggetionCount, CanvasEditorActivity.this.J0);
                y = true;
            }
            if (y) {
                canvasEditorActivity = CanvasEditorActivity.this;
                boolean z = false;
                if (canvasEditorActivity.m1) {
                    canvasEditorActivity.m1 = false;
                } else if (canvasEditorActivity.h0.get(this.e) != null) {
                    canvasEditorActivity = CanvasEditorActivity.this;
                    canvasEditorActivity.I0 = this.e;
                    canvasEditorActivity.c0 = this.f;
                    canvasEditorActivity.f0 = this.g;
                    canvasEditorActivity.g0 = this.h;
                    canvasEditorActivity.d0 = this.i;
                    CanvasEditorActivity.K1 = this.j;
                    CanvasEditorActivity.M1 = this.k;
                    canvasEditorActivity.cardView = this.l;
                    canvasEditorActivity.K = this.m;
                    canvasEditorActivity.Y = this.n;
                    TextView textView = this.o;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(10 - CanvasEditorActivity.this.J0);
                    stringBuilder.append(" FREE");
                    textView.setText(stringBuilder.toString());
                    StringBuilder stringBuilder2 = new StringBuilder();
//                    stringBuilder2.append(CanvasEditorActivity.this.C0 == null);
                    String str = "";
                    stringBuilder2.append(str);
                    String str2 = "------ subCatId :";
                    Log.d(str2, stringBuilder2.toString());
                    stringBuilder2 = new StringBuilder();
                  /*  if (CanvasEditorActivity.this.C0 == null) {
                        z = true;
                    }*/
                    stringBuilder2.append(z);
                    stringBuilder2.append(str);
                    Log.d(str2, stringBuilder2.toString());
                    canvasEditorActivity = CanvasEditorActivity.this;
                   /* Intent putExtra = new Intent(CanvasEditorActivity.this, SuggestionActivity.class).putExtra("colorsArrays", CanvasEditorActivity.this.i0.get(this.e)).putExtra("image", CanvasEditorActivity.this.h0.get(this.e));
                    String str3 = CanvasEditorActivity.this.C0;
                    if (str3 != null) {
                        str = str3;
                    }*/
                    String str4 = "categoryid";
                    /*Intent putExtra2 = putExtra.putExtra("subCatId", str).putExtra("content_id", CanvasEditorActivity.this.I.t).putExtra("type_id", CanvasEditorActivity.this.F0).putExtra("type", CanvasEditorActivity.this.B0).putExtra("count", 1).putExtra(str4, CanvasEditorActivity.this.A0);
                    int i2 = com.esc.socially.a0.a.G;
                    canvasEditorActivity.startActivityForResult(putExtra2, 624);*/
                } else {
                    Utils.N(CanvasEditorActivity.this, "Select Image First");
                }
            }
        }
    }

    public class r implements View.OnClickListener {
        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
        }
    }


    public class v implements View.OnClickListener {
        public final int e;
        public final CardView f;

        public v(int i, CardView cardView) {
            this.e = i;
            this.f = cardView;
        }

        public void onClick(View view) {
            int i;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            canvasEditorActivity.T0 = true;
            canvasEditorActivity.w0();
            CanvasEditorActivity.this.H0 = this.e;
            int i2 = 0;
            while (true) {
                i = -1;
                if (i2 >= CanvasEditorActivity.this.X.get(this.e).size()) {
                    break;
                }
                if (((ArrayList) CanvasEditorActivity.this.X.get(this.e)).get(i2) instanceof ImageView) {
                    ImageView imageView = (ImageView) ((ArrayList) CanvasEditorActivity.this.X.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.R.get(this.e).booleanValue()) {
                        i = -16777216;
                    }
                    imageView.setColorFilter(i);
                } else if (((ArrayList) CanvasEditorActivity.this.X.get(this.e)).get(i2) instanceof BorderedTextView) {
                    BorderedTextView borderedTextView = (BorderedTextView) ((ArrayList) CanvasEditorActivity.this.X.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.R.get(this.e).booleanValue()) {
                        i = -16777216;
                    }
                    borderedTextView.setBorderedColor(i);
                } else {
                    TextView textView = (TextView) ((ArrayList) CanvasEditorActivity.this.X.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.R.get(this.e).booleanValue()) {
                        i = -16777216;
                    }
                    textView.setTextColor(i);
                }
                i2++;
            }
            ArrayList arrayList = CanvasEditorActivity.this.R;
            int i3 = this.e;
            arrayList.set(i3, Boolean.valueOf(((Boolean) arrayList.get(i3)).booleanValue() ^ true));
            CardView cardView = this.f;
            if (CanvasEditorActivity.this.R.get(this.e).booleanValue()) {
                i = -16777216;
            }
            cardView.setCardBackgroundColor(i);
        }
    }

    public class w implements View.OnClickListener {
        public final int e;
        public final CardView f;

        public w(int i, CardView cardView) {
            this.e = i;
            this.f = cardView;
        }

        public void onClick(View view) {
            int i;
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            canvasEditorActivity.U0 ^= true;
            canvasEditorActivity.w0();
            CanvasEditorActivity.this.H0 = this.e;
            int i2 = 0;
            while (true) {
                i = -16777216;
                if (i2 >= CanvasEditorActivity.this.W.get(this.e).size()) {
                    break;
                }
                if (((ArrayList) CanvasEditorActivity.this.W.get(this.e)).get(i2) instanceof ImageView) {
                    ImageView imageView = (ImageView) ((ArrayList) CanvasEditorActivity.this.W.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.S.get(this.e).booleanValue()) {
                        i = -1;
                    }
                    imageView.setColorFilter(i);
                } else if (((ArrayList) CanvasEditorActivity.this.W.get(this.e)).get(i2) instanceof BorderedTextView) {
                    BorderedTextView borderedTextView = (BorderedTextView) ((ArrayList) CanvasEditorActivity.this.W.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.S.get(this.e).booleanValue()) {
                        i = -1;
                    }
                    borderedTextView.setBorderedColor(i);
                } else {
                    TextView textView = (TextView) ((ArrayList) CanvasEditorActivity.this.W.get(this.e)).get(i2);
                    if (!CanvasEditorActivity.this.S.get(this.e).booleanValue()) {
                        i = -1;
                    }
                    textView.setTextColor(i);
                }
                i2++;
            }
            ArrayList arrayList = CanvasEditorActivity.this.S;
            int i3 = this.e;
            arrayList.set(i3, Boolean.valueOf(((Boolean) arrayList.get(i3)).booleanValue() ^ true));
            CardView cardView = this.f;
            if (CanvasEditorActivity.this.S.get(this.e).booleanValue()) {
                i = -1;
            }
            cardView.setCardBackgroundColor(i);
        }
    }

    public class a implements View.OnClickListener {
        public final int e;
        public final FrameLayout f;
        public final FrameLayout g;

        public a(int i, FrameLayout frameLayout, FrameLayout frameLayout2) {
            this.e = i;
            this.f = frameLayout;
            this.g = frameLayout2;
        }

        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            if (canvasEditorActivity.m1) {
                canvasEditorActivity.m1 = false;
                return;
            }
            canvasEditorActivity.H0 = this.e;
            canvasEditorActivity.b0 = this.f;
            canvasEditorActivity.e0 = this.g;
            if (canvasEditorActivity != null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                Utils.z(canvasEditorActivity).compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                Intent putExtra = new Intent(canvasEditorActivity.getApplicationContext(), SelectLogoActivity.class).putExtra("image", byteArrayOutputStream.toByteArray());
                int i = AppConstant.H;
                canvasEditorActivity.startActivityForResult(putExtra, 7924);
                return;
            }
            throw null;
        }
    }

    public class b implements View.OnClickListener {
        public final FrameLayout e;

        public b(FrameLayout frameLayout) {
            this.e = frameLayout;
        }

        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity context = CanvasEditorActivity.this;
            if (m1) {
                m1 = false;
                return;
            }
            FrameLayout frameLayout = this.e;
            b0 = frameLayout;
            TextStickerViewNew1 d0 = d0(context, scroll, frameLayout.getWidth(), frameLayout.getHeight(), "");
            g0(frameLayout, d0);
            d0.setOperationListener(new CETextSticker(context, frameLayout, d0));
            d0.setOnOutSideTouchListner(new CETextStickerView(context));
            com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.G(context.s1, d0);
            s1.add(new com.kotlinz.festivalstorymaker.Models.z.c());
            frameLayout.addView(d0);
            frameLayout.requestLayout();
        }
    }

    public class c implements View.OnClickListener {
        public final int e;

        public c(int i) {
            this.e = i;
        }

        public void onClick(View view) {
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            canvasEditorActivity.H0 = this.e;
            canvasEditorActivity.P0 = true;
            ImagePicker.ImagePickerWithActivity aVar = new ImagePicker.ImagePickerWithActivity(activity);
            ImagePickerConfig imagePickerConfig = aVar.config;
            imagePickerConfig.folderMode = true;
            imagePickerConfig.returnMode = ReturnMode.GALLERY_ONLY;
            aVar.single();
            aVar.config.showCamera = false;
            aVar.start();
        }
    }

    public class d implements View.OnClickListener {
        public final int e;

        public d(int i) {
            this.e = i;
        }

        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            if (canvasEditorActivity.m1) {
                canvasEditorActivity.m1 = false;
                return;
            }
            int i = this.e;
            canvasEditorActivity.H0 = i;
            FrameLayout frameLayout = canvasEditorActivity.u0.get(i);
            View inflate = LayoutInflater.from(canvasEditorActivity).inflate(com.kotlinz.festivalstorymaker.R.layout.custom_price_tag_sticker, null);

            TextView textView = inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.txtPrice);
            inflate.getViewTreeObserver().addOnGlobalLayoutListener(new EditDialogOnGlobalLayoutListener(canvasEditorActivity, inflate));
            inflate.setOnTouchListener(new CanvasEditDailogTouchListener(canvasEditorActivity, new GestureDetector(new CanvasEditorDilogGestureListener(canvasEditorActivity, textView, frameLayout, inflate)), textView));
            frameLayout.addView(inflate);
            frameLayout.requestLayout();
            TextView textView2 = CanvasEditorActivity.z1;
            canvasEditorActivity.C0(frameLayout, inflate, textView);
        }
    }

    public class e implements View.OnClickListener {
        public final int e;

        public e(int i) {
            this.e = i;
        }

        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            int i = this.e;
            canvasEditorActivity.G0 = i;
            Utils.J(AppConstant.X1, canvasEditorActivity.w0.get(i));
            BaseActivity.b bVar = new BaseActivity.b();
            View[] viewArr = new View[1];
            CanvasEditorActivity canvasEditorActivity2 = CanvasEditorActivity.this;
            viewArr[0] = canvasEditorActivity2.s0.get(canvasEditorActivity2.G0);
            bVar.execute(viewArr);
        }
    }

    public class f implements View.OnClickListener {
        public final int e;
        public final FrameLayout f;
        public final FrameLayout g;
        public final View h;

        public f(int i, FrameLayout frameLayout, FrameLayout frameLayout2, View view) {
            this.e = i;
            this.f = frameLayout;
            this.g = frameLayout2;
            this.h = view;
        }

        public void onClick(View view) {
            CanvasEditorActivity.this.w0();
            CanvasEditorActivity.this.h0.remove(this.e);
            CanvasEditorActivity.this.r0.remove(this.f);
            CanvasEditorActivity.this.t0.remove(this.g);
            CanvasEditorActivity.this.llList.removeView(this.h);
            CanvasEditorActivity.this.llList.requestLayout();
        }
    }

    public class t implements ViewTreeObserver.OnGlobalLayoutListener {
        public final CardView e;

        public t(CanvasEditorActivity canvasEditorActivity, CardView cardView) {
            this.e = cardView;
        }

        public void onGlobalLayout() {
            this.e.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            this.e.getLayoutParams().height = this.e.getWidth();
            this.e.requestLayout();
        }
    }

    public class u implements ViewTreeObserver.OnGlobalLayoutListener {
        public final CardView e;

        public u(CanvasEditorActivity canvasEditorActivity, CardView cardView) {
            this.e = cardView;
        }

        public void onGlobalLayout() {
            this.e.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            this.e.getLayoutParams().height = this.e.getWidth();
            this.e.requestLayout();
        }
    }

    public class g implements ViewTreeObserver.OnPreDrawListener {
        public final CardView e;
        public final int f;
        public final ImageView g;
        public final RelativeLayout h;
        public final FrameLayout i;
        public final FrameLayout j;
        public final RecyclerView k;
        public final RecyclerView l;
        public final CardView m;
        public final CardView n;
        public final boolean o;
        public final RelativeLayout p;

        public g(CardView cardView, int i, ImageView imageView, RelativeLayout relativeLayout, FrameLayout frameLayout, FrameLayout frameLayout2, RecyclerView recyclerView, RecyclerView recyclerView2, CardView cardView2, CardView cardView3, boolean z, RelativeLayout relativeLayout2) {
            this.e = cardView;
            this.f = i;
            this.g = imageView;
            this.h = relativeLayout;
            this.i = frameLayout;
            this.j = frameLayout2;
            this.k = recyclerView;
            this.l = recyclerView2;
            this.m = cardView2;
            this.n = cardView3;
            this.o = z;
            this.p = relativeLayout2;
        }

        public boolean onPreDraw() {
            int i;
            if (this.e.getViewTreeObserver().isAlive()) {
                this.e.getViewTreeObserver().removeOnPreDrawListener(this);
            }
            D1 = (float) this.e.getWidth();
            m0 = new ArrayList();
            p0 = new ArrayList();
            q0 = new ArrayList();
            n0 = new ArrayList();
            o0 = new ArrayList();
            RelativeLayout relativeLayout = new RelativeLayout(CanvasEditorActivity.this);
            relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            if (CanvasEditorActivity.this.Z.size() > this.f) {
                for (i = 0; i < CanvasEditorActivity.this.Z.get(this.f).size(); i++) {
                    CanvasEditorActivity.this.H0(this.g, this.h, relativeLayout, this.i, this.j, i, this.f, this.k, this.l, this.m, this.n, this.o);
                }
            }
            this.j.addView(relativeLayout);
            W.add(p0);
            X.add(q0);
            U.add(o0);
            V.add(n0);
            T.add(m0);
            ArrayList arrayList = CanvasEditorActivity.this.T;
            if (arrayList != null) {
                int size = arrayList.size();
                i = this.f;
                if (size > i && CanvasEditorActivity.this.T.get(i).size() > 0) {
                    relativeLayout = this.p;
                    i = 0;
                    relativeLayout.setVisibility(i);
                    return true;
                }
            }
            relativeLayout = this.p;
            i = 8;
            relativeLayout.setVisibility(i);
            return true;
        }
    }

    public class h implements SeekBar.OnSeekBarChangeListener {
        public final int e;

        public h(int i) {
            this.e = i;
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            for (int i2 = 0; i2 < CanvasEditorActivity.this.T.get(this.e).size(); i2++) {
                ((ImageView) ((ArrayList) CanvasEditorActivity.this.T.get(this.e)).get(i2)).setColorFilter(new BaseActivity.a().a((float) (i - 180)));
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    }

    public StickerView stickerView;

    public final void G0(int var1, boolean var2) {
        View var3 = ((LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(com.kotlinz.festivalstorymaker.R.layout.canvas_edit_list_item, null);
        StickerView var4 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.sticker_view);
        stickerView = var4;
        FrameLayout var5 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMain);
        FrameLayout var6 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlLogo);
        FrameLayout var7 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlPriceTag);
        FrameLayout var8 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlTextSticker);
        RelativeLayout var9 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView);
        RelativeLayout var10 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainFrameView);
        ImageView var11 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.imgWaterMark);
        SeekBar var12 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.seekBar);
        View var13 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.viewVCenter);
        View var14 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.viewHCenter);
        CardView var15 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardPrice);
        CardView var16 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardAddText);
        CardView var17 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardLogo);
        CardView var18 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardEditor);
        CardView var19 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardWt);
        CardView var20 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardAddImage);
        CardView var21 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardBt);
        CardView var23 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardShare);
        CardView var24 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardDelete);
        var3.findViewById(com.kotlinz.festivalstorymaker.R.id.cardNewArrival).setVisibility(View.GONE);
        RecyclerView var25 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rvPrimaryColor);
        RecyclerView var26 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rvSecondaryColor);
        RelativeLayout var27 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.rlSeekBar);
        CardView var28 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextGroup1);
        CardView var29 = var3.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextGroup2);
        byte var32 = 0;
        if (Utils.y(this, false)) {
            var32 = 8;
        }

        StringBuilder var54 = new StringBuilder();
        var54.append(10 - this.J0);
        var54.append(" FREE");
        if (Utils.y(this, false)) {
            var32 = 8;
        } else {
            var32 = 0;
        }

        var11.setVisibility(var32);
        ArrayList var55 = this.i0;
        if (var55 != null && var55.size() > var1 && this.i0.get(var1) != null) {
            var26.getViewTreeObserver().addOnGlobalLayoutListener(new k(var26, var1));
            var25.getViewTreeObserver().addOnGlobalLayoutListener(new o(var25, var1));
        }
        var9.setOnClickListener(new r());
//        var22.setOnClickListener(new s(var1, var5, var10, var11, var6, var25, var26, var28, var29, var27, var30));
        var19.getViewTreeObserver().addOnGlobalLayoutListener(new t(this, var19));
        var21.getViewTreeObserver().addOnGlobalLayoutListener(new u(this, var21));
        var19.setOnClickListener(new v(var1, var19));
        var21.setOnClickListener(new w(var1, var21));
        var17.setOnClickListener(new a(var1, var5, var6));
        var16.setOnClickListener(new b(var8));
        var20.setOnClickListener(new c(var1));
        var15.setOnClickListener(new d(var1));
        var23.setOnClickListener(new e(var1));
        var24.setOnClickListener(new f(var1, var5, var6, var3));
        int var33;
        int var56;
        if (D1 == -1.0F) {
            var18.getViewTreeObserver().addOnPreDrawListener(new g(var18, var1, var11, var10, var6, var5, var25, var26, var28, var29, var2, var27));
        } else {
            ArrayList var49 = new ArrayList();
            CanvasEditorActivity var46 = this;
            this.m0 = var49;
            this.p0 = new ArrayList();
            this.q0 = new ArrayList();
            this.n0 = new ArrayList();
            this.o0 = new ArrayList();
            RelativeLayout var50 = new RelativeLayout(this);
            var50.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            var56 = this.Z.size();
            var33 = var1;
            if (var56 > var1) {
                for (var56 = 0; var56 < var46.Z.get(var33).size(); ++var56) {
                    this.H0(var11, var10, var50, var6, var5, var56, var1, var25, var26, var28, var29, var2);
                }
            }

            var5.addView(var50);
            var46.W.add(var46.p0);
            var46.X.add(var46.q0);
            var46.U.add(var46.o0);
            var46.V.add(var46.n0);
            var46.T.add(var46.m0);
            ArrayList var52 = var46.T;
            if (var52 != null && var52.size() > var33 && var46.T.get(var33).size() > 0) {
                var27.setVisibility(View.VISIBLE);
            } else {
                var27.setVisibility(View.GONE);
            }
        }

        var56 = var1;
        CanvasEditorActivity var51 = this;
        var12.setMax(180);
        var12.setOnSeekBarChangeListener(new h(var1));
        Boolean var38;
        ArrayList var47;
        if (this.R0) {
            this.R.add(this.T0);
            var47 = this.S;
            var38 = this.U0;
        } else {
            this.R.add(Boolean.FALSE);
            var47 = this.S;
            var38 = Boolean.FALSE;
        }

        var47.add(var38);
        BitmapStickerIcon deleteIcon = new BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.kotlinz.festivalstorymaker.R.drawable.ic_delete_sticker_canvas),
                BitmapStickerIcon.LEFT_TOP);
        deleteIcon.setIconEvent(new DeleteIconEvent());

        BitmapStickerIcon zoomIcon = new BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.kotlinz.festivalstorymaker.R.drawable.ic_resize_sticker_canvas),
                BitmapStickerIcon.RIGHT_BOTOM);
        zoomIcon.setIconEvent(new ZoomIconEvent());

        BitmapStickerIcon flipIcon = new BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.kotlinz.festivalstorymaker.R.drawable.icon_flip),
                BitmapStickerIcon.RIGHT_TOP);
        flipIcon.setIconEvent(new FlipHorizontallyEvent());
        var4.setIcons(Arrays.asList(deleteIcon, zoomIcon, flipIcon));

        this.Q.add(var4);
        this.O.add(var13);
        this.P.add(var14);
        this.llList.addView(var3);
        this.s0.add(var10);
        this.r0.add(var5);
        this.t0.add(var6);
        this.u0.add(var7);
        this.v0.add(var8);
        this.llList.requestLayout();
        List var40 = this.h0;
        if (var40 != null) {
            var1 = var40.size();
            ++var56;
            if (var1 > var56) {
                this.G0(var56, var2);
            }
        }

        if (this.r0.size() > this.M0) {
            ImageStickerViewNew var41 = this.k1;
            if (var41 != null) {
                float var34 = var41.getLayoutLastX();
                float var35 = ((float) this.k1.getBitmaps().getWidth() - this.k1.getWidths()) / 2.0F;
                float var36 = this.k1.getLayoutLastY();
                float var37 = ((float) this.k1.getBitmaps().getHeight() - this.k1.getHeights()) / 2.0F;
                this.I0(this.M0, this.k1.getStickerPath(), var34 - var35, var36 - var37, this.k1.getHeights(), true);
            }
        }

        if (this.R0 || this.Q0) {
            var56 = 0;

            while (true) {
                var33 = var51.X.get(0).size();
                var1 = -16777216;
                StringBuilder var42;
                ImageView var43;
                BorderedTextView var44;
                TextView var45;
                if (var56 >= var33) {
                    for (var1 = 0; var1 < var51.W.get(0).size(); ++var1) {
                        var42 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.v(" isBtClick :- ");
                        var42.append(var51.U0);
                        Log.d("-------", var42.toString());
                        if (((ArrayList) var51.W.get(0)).get(var1) instanceof ImageView) {
                            var43 = (ImageView) ((ArrayList) var51.W.get(0)).get(var1);
                            if (var51.U0) {
                                var56 = -1;
                            } else {
                                var56 = -16777216;
                            }

                            var43.setColorFilter(var56);
                        } else if (((ArrayList) var51.W.get(0)).get(var1) instanceof BorderedTextView) {
                            var44 = (BorderedTextView) ((ArrayList) var51.W.get(0)).get(var1);
                            if (var51.U0) {
                                var56 = -1;
                            } else {
                                var56 = -16777216;
                            }

                            var44.setBorderedColor(var56);
                        } else {
                            var45 = (TextView) ((ArrayList) var51.W.get(0)).get(var1);
                            if (var51.U0) {
                                var56 = -1;
                            } else {
                                var56 = -16777216;
                            }

                            var45.setTextColor(var56);
                        }
                    }

                    var1 = var51.K0;
                    if (var1 != -1) {
                        var51.u0(true, 0, var1);
                    }

                    var1 = var51.L0;
                    if (var1 != -1) {
                        var51.u0(false, 0, var1);
                    }

                    var51.R0 = false;
                    var51.Q0 = false;
                    break;
                }

                var42 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.v(" isWtClick :- ");
                var42.append(var51.T0);
                if (((ArrayList) var51.X.get(0)).get(var56) instanceof ImageView) {
                    var43 = (ImageView) ((ArrayList) var51.X.get(0)).get(var56);
                    if (!var51.T0) {
                        var1 = -1;
                    }

                    var43.setColorFilter(var1);
                } else if (((ArrayList) var51.X.get(0)).get(var56) instanceof BorderedTextView) {
                    var44 = (BorderedTextView) ((ArrayList) var51.X.get(0)).get(var56);
                    if (!var51.T0) {
                        var1 = -1;
                    }

                    var44.setBorderedColor(var1);
                } else {
                    var45 = (TextView) ((ArrayList) var51.X.get(0)).get(var56);
                    if (!var51.T0) {
                        var1 = -1;
                    }

                    var45.setTextColor(var1);
                }

                ++var56;
            }
        }

    }

    public class i implements StickerView.OnStickerOperationListener {
        public final int a;
        public final FrameLayout b;
        public final View c;
        public final View d;

        public i(int i, FrameLayout frameLayout, View view, View view2) {
            this.a = i;
            this.b = frameLayout;
            this.c = view;
            this.d = view2;
        }

        public void a(com.kotlinz.festivalstorymaker.sticker.e eVar) {
        }

        public void b(com.kotlinz.festivalstorymaker.sticker.e eVar) {
            CanvasEditorActivity.this.scroll.requestDisallowInterceptTouchEvent(true);
        }

        public void c(com.kotlinz.festivalstorymaker.sticker.e eVar) {
            CanvasEditorActivity.this.G0 = this.a;
        }

        public void d(com.kotlinz.festivalstorymaker.sticker.e eVar) {
        }

        public void e(com.kotlinz.festivalstorymaker.sticker.e eVar) {
        }

        public void f(com.kotlinz.festivalstorymaker.sticker.e eVar) {
            CanvasEditorActivity.this.scroll.requestDisallowInterceptTouchEvent(false);
            this.d.setVisibility(View.GONE);
            this.c.setVisibility(View.GONE);
        }

        public void g(com.kotlinz.festivalstorymaker.sticker.e eVar) {
            CanvasEditorActivity.this.scroll.requestDisallowInterceptTouchEvent(true);
            CanvasEditorActivity.this.G0 = this.a;
        }

        public void h(com.kotlinz.festivalstorymaker.sticker.e eVar, float[] fArr) {
            CanvasEditorActivity.this.scroll.requestDisallowInterceptTouchEvent(true);
            if (this.b.getHeight() / 2 == ((int) (fArr[1] + fArr[7])) / 2) {
                this.c.setVisibility(View.VISIBLE);
            } else {
                this.c.setVisibility(View.GONE);
            }
            if (this.b.getWidth() / 2 == ((int) (fArr[0] + fArr[6])) / 2) {
                this.d.setVisibility(View.VISIBLE);
            } else {
                this.d.setVisibility(View.GONE);
            }
        }

        public void i(com.kotlinz.festivalstorymaker.sticker.e eVar) {
        }

        @Override
        public void onStickerAdded(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerClicked(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerDeleted(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerDragFinished(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerTouchedDown(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerZoomFinished(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerFlipped(@NonNull Sticker sticker) {

        }

        @Override
        public void onStickerDoubleTapped(@NonNull Sticker sticker) {

        }
    }

    public final void H0(ImageView var1, RelativeLayout var2, RelativeLayout var3, FrameLayout var4, FrameLayout var5, int var6, int var7, RecyclerView var8, RecyclerView var9, CardView var10, CardView var11, boolean var12) {
        float var13;
        if (var6 == 0) {
            C1 = (float) ((int) Float.parseFloat(((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6)).j));
            var13 = (float) ((int) Float.parseFloat(((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6)).k));
            B1 = var13;
            E1 = var13 * D1 / C1;
            var5.getLayoutParams().width = (int) D1;
            var5.getLayoutParams().height = (int) E1;
            var5.requestLayout();
            var4.getLayoutParams().width = (int) D1;
            var4.getLayoutParams().height = (int) E1;
            var4.requestLayout();
            var2.getLayoutParams().width = (int) D1;
            var2.getLayoutParams().height = (int) E1;
            var2.requestLayout();
        }

        if (((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6)).e.equalsIgnoreCase("image")) {
            F1.add((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6));
            var6 = F1.size();
            this.m0(var1, F1.get(var6 - 1), var5, var7, var8, var9, var10, var11);
        } else if (((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6)).e.equalsIgnoreCase("text")) {
            G1.add((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6));
            int var14 = G1.size() - 1;
            var13 = Float.parseFloat(G1.get(var14).w) * D1 / C1;
            this.N.add((com.kotlinz.festivalstorymaker.Models.g) ((ArrayList) this.Z.get(var7)).get(var6));
            com.kotlinz.festivalstorymaker.Models.g var22 = this.N.get(var14);
            Font var20 = new Font();
            if (var22.v.length() > 0) {
                var20.a = Color.parseColor(var22.v);
            }
            Object var21;
            label63:
            {
                var20.b = var13 / Resources.getSystem().getDisplayMetrics().density;
                AssetManager var25 = this.getAssets();
                StringBuilder var23 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.v("fonts/");
                var23.append(Utils.k(this, G1.get(var14).A));
                com.kotlinz.festivalstorymaker.Models.g var27 = this.N.get(A1);
                var20.c = Typeface.createFromAsset(var25, var23.toString());
                this.a1 = Float.parseFloat(var27.h) * D1 / C1;
                this.b1 = Float.parseFloat(var27.i) * D1 / C1;
                this.Y0 = Double.parseDouble(var27.j) * (double) D1 / (double) C1;
                this.Z0 = Double.parseDouble(var27.k) * (double) E1 / (double) B1;
                var6 = var27.n.length();
                float var15 = this.a1;
                var13 = this.b1;
                double var16 = this.Y0;
                double var18 = this.Z0;
                if (var6 <= 0) {
                    TextView var24 = Utils.f(this, var27, var15, var13, var16, var18, var20, true, true);
                    var24.setOnTouchListener(new l2(this, new GestureDetector(new CanvasEditTouch(this, var24, var27, var5))));
                    if (var27.y.length() > 0 && Integer.parseInt(var27.y) > 0) {
                        var16 = this.a1;
                        var18 = this.Z0 / 2.0D;
                        var24.setX((float) (this.Y0 / 2.0D + (var16 - var18)));
                        var18 = this.b1;
                        var16 = this.Y0 / 2.0D;
                        var24.setY((float) (this.Z0 / 2.0D + (var18 - var16)));
                        var24.setRotation((float) Integer.parseInt(var27.y));
                        var24.getLayoutParams().height = (int) this.Y0;
                        var24.getLayoutParams().width = (int) this.Z0;
                        var24.requestLayout();
                    }

                    if (var27.E.equals("1")) {
                        this.p0.add(var24);
                    }

                    if (var27.F.equals("1")) {
                        this.q0.add(var24);
                    }

                    if (var27.G.equals("1")) {
                        this.n0.add(var24);
                    }

                    var21 = var24;
                    if (!var27.D.equals("1")) {
                        break label63;
                    }
                    var21 = var24;
                } else {
                    BorderedTextView var26 = Utils.h(this, var27, var15, var13, var16, var18, var20, true);
                    var26.setOnTouchListener(new CEBorderedTextViewTouchListener(this, new GestureDetector(new CanvasEditorGestureListener(this, var26, var27, var5))));
                    if (var27.y.length() > 0 && Integer.parseInt(var27.y) > 0) {
                        var16 = this.a1;
                        var18 = this.Z0 / 2.0D;
                        var26.setX((float) (this.Y0 / 2.0D + (var16 - var18)));
                        var16 = this.b1;
                        var18 = this.Y0 / 2.0D;
                        var26.setY((float) (this.Z0 / 2.0D + (var16 - var18)));
                        var26.setRotation((float) Integer.parseInt(var27.y));
                        var26.getLayoutParams().height = (int) this.Y0;
                        var26.getLayoutParams().width = (int) this.Z0;
                        var26.requestLayout();
                    }

                    if (var27.E.equals("1")) {
                        this.p0.add(var26);
                    }

                    if (var27.F.equals("1")) {
                        this.q0.add(var26);
                    }

                    if (var27.G.equals("1")) {
                        this.n0.add(var26);
                    }

                    var21 = var26;
                    if (!var27.D.equals("1")) {
                        break label63;
                    }

                    var21 = var26;
                }

                this.o0.add((View) var21);
            }

            var5.addView((View) var21);
            var5.requestLayout();
            ++A1;
        }

    }

    public class p implements ImageStickerViewNew.c {
        public final int a;
        public final ImageStickerViewNew b;

        public p(int i, ImageStickerViewNew imageStickerViewNew) {
            this.a = i;
            this.b = imageStickerViewNew;
        }

        public void a(ImageStickerViewNew imageStickerViewNew) {
            ImageStickerViewNew imageStickerViewNew2 = CanvasEditorActivity.this.j1;
            if (imageStickerViewNew2 != null) {
                imageStickerViewNew2.setInEdit(false);
            }
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            canvasEditorActivity.j1 = imageStickerViewNew;
            if (this.a == 0) {
                canvasEditorActivity.k1 = this.b;
            }
            CanvasEditorActivity.this.j1.setInEdit(true);
        }

        public void b(ImageStickerViewNew imageStickerViewNew) {
            CanvasEditorActivity.this.t0.get(this.a).removeView(CanvasEditorActivity.this.j1);
        }

        public void c(Boolean bool) {
            CanvasEditorActivity.this.scroll.requestDisallowInterceptTouchEvent(bool.booleanValue());
            if (bool.booleanValue()) {
                CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
                ImageStickerViewNew imageStickerViewNew = this.b;
                canvasEditorActivity.j1 = imageStickerViewNew;
                if (this.a == 0) {
                    canvasEditorActivity.k1 = imageStickerViewNew;
                }
            }
        }

        public void d(ImageStickerViewNew imageStickerViewNew) {
        }
    }

    public void I0(int i, String str, float f, float f2, float f3, boolean z) {
        int i2 = i;
        File file = new File(str);
        if (file.exists()) {
            try {
                Bitmap decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, str, f, f2, 1.0f, 0.0f, 2, true);
                int i3 = 0;
                imageStickerViewNew.setGif(false);
                imageStickerViewNew.setTag(Integer.valueOf(0));
                imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                imageStickerViewNew.setOperationListener(new p(i, imageStickerViewNew));
                imageStickerViewNew.setInEdit(false);
                imageStickerViewNew.setSize(f3);
                imageStickerViewNew.setListner(this.l1, "");
                if (this.t0.size() > i2) {
                    while (i3 < this.t0.get(i).getChildCount()) {
                        if (this.t0.get(i).getChildAt(i3) instanceof ImageStickerViewNew) {
                            this.t0.get(i).removeViewAt(i3);
                        }
                        i3++;
                    }
                    this.t0.get(i).addView(imageStickerViewNew);
                    this.t0.get(i).requestLayout();
                }
                if (z) {
                    int i4 = i2 + 1;
                    if (this.t0.size() > i4) {
                        I0(i4, str, f, f2, f3, z);
                    }
                }
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            }
        }
    }

    public final void J0(final boolean b) {
        int visibility = 0;
        if (!b) {
            final TextView z1 = CanvasEditorActivity.z1;
            if (z1 != null) {
                z1.setBackground(null);
            }
            final ImageView i1 = CanvasEditorActivity.I1;
            if (i1 != null) {
                i1.setBackground(null);
            }
        } else if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            this.D0(false);
        }
        final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog);
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.B(80, 500L, com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog, this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView));
        if (!b) {
            visibility = 8;
        }
        viewById.setVisibility(visibility);
    }

    @Override
    public void L(final int n, final String s) {
    }

    @Override
    public void N(final int n) {
    }

    @Override
    public void P(final float n) {
        CanvasEditorActivity.Y1 = null;
        this.rlFull.setVisibility(View.GONE);
        this.q0((int) n);
    }

    @Override
    public void Q(final int n, final int n2) {
        this.w0();
        if (!this.m1) {
            this.q0(n2);
            return;
        }
        this.m1 = false;
    }

    @Override
    public Bitmap e0(final View view) {
        final boolean b = view.getHeight() > 1000 || view.getWidth() > 1000;
        final int height = view.getHeight();
        final int n = 2;
        int n2;
        if (b) {
            n2 = 2;
        } else {
            n2 = 3;
        }
        final int n3 = height * n2;
        final int width = view.getWidth();
        int n4;
        if (b) {
            n4 = n;
        } else {
            n4 = 3;
        }
        final int n5 = width * n4;
        view.measure(View.MeasureSpec.makeMeasureSpec(n5, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(n3, View.MeasureSpec.EXACTLY));
        Bitmap bitmap = null;
        try {
            final Bitmap bitmap2 = bitmap = Bitmap.createBitmap(n5, n3, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap2);
            bitmap = bitmap2;
            canvas.translate(0.0f, 0.0f);
            bitmap = bitmap2;
            canvas.drawColor(-1, PorterDuff.Mode.CLEAR);
            bitmap = bitmap2;
            canvas.scale((float) (n5 / view.getWidth()), (float) (n3 / view.getHeight()));
            bitmap = bitmap2;
            view.draw(canvas);
            return bitmap2;
        } catch (Exception ex) {
            ex.printStackTrace();
            return bitmap;
        }
    }

    public final void g0(final FrameLayout frameLayout, final TextStickerViewNew1 textStickerViewNew1) {
        TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new TextInputDilaog.d() {
            @Override
            public void a(final String text, final int n) {
                if (text.length() == 0) {
                    frameLayout.removeView(textStickerViewNew1);
                    frameLayout.requestLayout();
                    return;
                }
                textStickerViewNew1.setText(text);
                stickerView.addSticker(new TextSticker(getApplicationContext()).setText(textStickerViewNew1.getText()).setMaxTextSize(14).resizeText(), Sticker.Position.CENTER);
            }

            @Override
            public void b(final String s) {
            }
        };
    }

    @Override
    public void h(final boolean b, final boolean b2, int n, final int n2) {
        this.w0();
        final boolean m1 = this.m1;
        final int n3 = 0;
        if (m1) {
            this.m1 = false;
            return;
        }
        U1 = false;
        V1 = false;
        W1 = false;
        if (b) {
            if (b2) {
                U1 = true;
            } else {
                V1 = true;
            }
            this.H0 = n;
            this.J0(true);
            ((RecyclerView) findViewById(com.kotlinz.festivalstorymaker.R.id.rlColor)).setAdapter(new ColorListAdapter(this, getResources().getStringArray(com.kotlinz.festivalstorymaker.R.array.colors_list)));
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setVisibility(View.GONE);
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setVisibility(View.INVISIBLE);
            final View viewById = this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableMove);
            if (!P1) {
                n = n3;
            } else {
                n = 8;
            }
            viewById.setVisibility(n);
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableMove).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDisableDelete).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.txtCancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    w0();

                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.txtDone).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    w0();
                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.llColorPicker).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    w0();
                    /*new f();
                    final int[] e0 = f.E0;
                    new f.j().b(this.e);*/

                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.llPickColor).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    w0();
                    rlFull.setVisibility(View.VISIBLE);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            final MagnifierView.b b = new MagnifierView.b(getApplicationContext(), x1);
                            b.c((int) D1 / 2 - 60, (int) E1 / 2 - 60);
                            b.d = 250;
                            b.e = 250;
                            b.f = 4.0f;
                            b.g = 4.0f;
                            b.a(16);
                            b.h = 17170445;
                            (Y1 = b.b()).setListner(X1);
                            Y1.a();
                        }
                    }, 600L);
                }
            });
            this.findViewById(com.kotlinz.festivalstorymaker.R.id.viewDelete).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    w0();
                    if (P1) {
                        final boolean r1 = R1;
                        z1.setVisibility(View.GONE);
                        return;
                    }
                    y1.setVisibility(View.GONE);
                }
            });
            return;
        }
        if (b2) {
            this.u0(true, n, n2);
            return;
        }
        this.u0(false, n, n2);
    }


    public final void m0(ImageView var1, com.kotlinz.festivalstorymaker.Models.g var2, FrameLayout var3, int var4, RecyclerView var5, RecyclerView var6, CardView var7, CardView var8) {
        Float var9 = Float.parseFloat(var2.h) * D1 / C1;
        Float var10 = Float.parseFloat(var2.i) * D1 / C1;
        float var11;
        if (var2.B.equals("1")) {
//            var11 = 900.0F;
            var11 = Float.parseFloat(var2.j);
        } else {
            var11 = Float.parseFloat(var2.k);
        }
        int var12 = (int) (var11 * D1 / C1);
        if (var2.B.equals("1")) {
            var11 = 1000.0F;
        } else {
            var11 = Float.parseFloat(var2.k);
        }

        int var13 = (int) (var11 * D1 / C1);
        ImageView var14 = new ImageView(this);
        var14.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        var14.getLayoutParams().width = Integer.parseInt(var2.j);
        var14.getLayoutParams().height = Integer.parseInt(var2.k);
        if (!var2.B.equals("1") && !var2.q.equals("1")) {
            var14.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            var14.setX(var9);
            var14.setY(var10);
            var14.getLayoutParams().width = var12;
            var14.getLayoutParams().height = var13;
            var14.requestLayout();
            var14.setAdjustViewBounds(true);
            var14.setScaleType(ImageView.ScaleType.CENTER_CROP);
            var14.requestLayout();
            if (var2.C.equalsIgnoreCase("1")) {
                var14.setOnClickListener(new ImageListener(this, var4, var14, var2));
            }
            Glide.with(activity).load(var2.f).into(var14);
            H1.add(var14);
            var3.addView(var14);
            var3.requestLayout();
            var1 = var14;
        } else {
            List var15;
            label140:
            {
                if (var2.B.equals("1")) {
                    var15 = this.h0;
                    if (var15 == null || var15.size() <= var4 || this.h0.get(var4) == null) {
                        Glide.with(activity).load(com.kotlinz.festivalstorymaker.R.drawable.add_mask_image).into(var14);
                        break label140;
                    }
                    var14.setImageBitmap(Utils.B(h0.get(var4)));
                    var14.setX(Float.parseFloat(var2.h));
                    var14.setY(Float.parseFloat(var2.i));
//                    var11 = (E1 - (float) var13) / 2.0F;

                } else {
                    if (!var2.q.equals("1")) {
                        break label140;
                    }
                    var14.setX(var9);
                    var11 = var10;
                    var14.setY(var11);
                }
            }

            if (this.j0.size() > var4) {
                this.l0.set(var4, (float) var13);
                this.j0.set(var4, var9);
                this.k0.set(var4, var10);
            } else {
                this.l0.add((float) var13);
                this.j0.add(var9);
                this.k0.add(var10);
                this.V0 = false;
            }

            var15 = Utils.n(this);
            boolean var20;
            if (var15.size() <= 0) {
                var20 = false;
            } else {
                Bitmap var16 = BitmapFactory.decodeFile((new File((String) var15.get(0))).getAbsolutePath());
                float var17;
                float var18;
                String var24;
                if (var16 != null) {
                    var17 = (float) var16.getWidth() * 150.0F / (float) var16.getHeight();
                    var24 = (String) var15.get(0);
                    var11 = var9;
                    var18 = (float) (var16.getWidth() / 2);
                    var17 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var16.getWidth(), var17, 2.0F, var11 + var18, 20.0F);
                    var18 = var10;
                    var11 = (float) (var16.getHeight() / 2);
                    this.I0(var4, var24, var17, com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var16.getHeight(), 150.0F, 2.0F, var18 + var11, 20.0F), 150.0F, false);
                } else {
                    label162:
                    {
                        boolean var10001;
                        try {
                            ContentResolver var19 = this.getContentResolver();
                            File var25 = new File((String) var15.get(0));
                            var16 = BitmapFactory.decodeStream(var19.openInputStream(Uri.parse(var25.getAbsolutePath())));
                            var18 = (float) var16.getWidth() * 150.0F / (float) var16.getHeight();
                            var24 = (String) var15.get(0);
                            var11 = var9;
                            var17 = (float) (var16.getWidth() / 2);
                            var11 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var16.getWidth(), var18, 2.0F, var11 + var17, 20.0F);
                        } catch (Exception var22) {
                            var10001 = false;
                            break label162;
                        }
                        var17 = var10;
                        try {
                            var18 = (float) (var16.getHeight() / 2);
                            var17 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var16.getHeight(), 150.0F, 2.0F, var17 + var18, 20.0F);
                        } catch (Exception var21) {
                            var10001 = false;
                            break label162;
                        }
                        this.I0(var4, var24, var11, var17, 150.0F, false);
                    }
                }

                var20 = false;
            }

            var14.setAdjustViewBounds(true);
            var14.setScaleType(ImageView.ScaleType.FIT_CENTER);
            var14.setTag(this.h0.get(var4));
            if (var2.q.equals("0") && /*(this.B0.equalsIgnoreCase(com.esc.socially.a0.a.Q1) || this.B0.equalsIgnoreCase(com.esc.socially.a0.a.K1)) &&*/ !Utils.y(this, var20)) {
                var1.getViewTreeObserver().addOnGlobalLayoutListener(new com.kotlinz.festivalstorymaker.Listener.SetListener.z1(this, var1, var9, var12, var10, var13));
            }

            if (var2.q.equalsIgnoreCase("1")) {
                Utils.O();
                I1 = var14;
                J1 = var5;
                L1 = var6;
                this.D0 = var2.f;
                this.x0(this.h0.get(var4), var12, var13);
            }

            var14.requestLayout();
//            var14.setOnTouchListener(new z(this, this.scroll, var14, var4, var2, var5, var6));
            var1 = var14;
            var3.addView(var14);
            var3.requestLayout();
        }

        if (var2.p.equals("1")) {
            this.m0.add(var1);
        }

        if (var2.E.equals("1")) {
            this.p0.add(var1);
        }

        if (var2.F.equals("1")) {
            this.q0.add(var1);
        }

        if (var2.G.equals("1")) {
            this.n0.add(var1);
        }

        if (var2.D.equals("1")) {
            this.o0.add(var1);
        }

        if (var2.D.equals("1") || var2.G.equals("1") || var2.F.equals("1") || var2.E.equals("1")) {
            var1.setOnClickListener(new CardEditor(this, var4, var1, var2, var7, var8, var5, var6));
        }

        if (!var2.B.equals("1") || !var2.q.equals("1")) {
            var1.setOnLongClickListener(new AddWaterMark(this, var3, var1));
        }

    }


    public void n0(final int n, final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(" addImageSticker :- ");
        sb.append(s);
        final Drawable fromPath = Drawable.createFromPath(s);
        final StickerView stickerView = this.Q.get(n);
        final com.kotlinz.festivalstorymaker.sticker.c c = new com.kotlinz.festivalstorymaker.sticker.c(fromPath);
        if (stickerView == null) {
            throw null;
        }
     /*   if (n.I((View) stickerView)) {
            stickerView.a(c, 6);
            return;
        }*/
        stickerView.post(new com.kotlinz.festivalstorymaker.sticker.g(stickerView, c, 6));
    }

    @SuppressLint({"NewApi"})
    public final void o0(final int c) {
        final ImageView imgAlignCenter = this.imgAlignCenter;
        final int n = -16777216;
        int color;
        if (c == 0) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignCenter.setColorFilter(color);
        final ImageView imgAlignLeft = this.imgAlignLeft;
        int color2;
        if (c == -1) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignLeft.setColorFilter(color2);
        final ImageView imgAlignRight = this.imgAlignRight;
        int color3;
        if (c == 1) {
            color3 = n;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlignRight.setColorFilter(color3);
        final TextStickerViewNew1 t1 = this.t1;
        Layout.Alignment align;
        if (c == 0) {
            align = Layout.Alignment.ALIGN_CENTER;
        } else if (c == 1) {
            align = Layout.Alignment.ALIGN_OPPOSITE;
        } else {
            align = Layout.Alignment.ALIGN_NORMAL;
        }
        t1.setAlign(align);
        final TextStickerViewNew1 t2 = this.t1;
        t2.setText(t2.getText());
        this.t1.requestLayout();
        final com.kotlinz.festivalstorymaker.Models.z.c v1 = this.s1.get((int) this.t1.getTag());
        this.v1 = v1;
        v1.c = c;
        this.s1.set((int) this.t1.getTag(), this.v1);
    }


    public void onActivityResult(int var1, int var2, Intent var3) {
        int var4 = AppConstant.K;
        if (724 == var1) {
            if (Utils.b) {
                this.finish();
            }
        } else if (var1 == 90 && var3 != null) {
            (new b0(var3.getStringExtra("url"), var3.getIntExtra("pos", 0))).execute();
        } else {
            var4 = AppConstant.H;
            String var23;
            Bitmap var34;
            if (var1 == 7924 && var3 != null) {
                var23 = var3.getStringExtra("path");
                if (var23 != null && var23.length() > 0) {
                    this.e0.removeAllViews();

                    for (var4 = 0; var4 < this.e0.getChildCount(); ++var4) {
                        if (this.e0.getChildAt(var4).getTag() != null && this.e0.getChildAt(var4).getTag().equals(0)) {
                            this.e0.removeViewAt(var4);
                        }
                    }

                    var34 = BitmapFactory.decodeFile((new File(var23)).getAbsolutePath());
                    float var7 = (float) var34.getWidth() * 150.0F / (float) var34.getHeight();
                    float var8 = this.j0.get(this.H0);
                    float var9 = (float) (var34.getWidth() / 2);
                    var9 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var34.getWidth(), var7, 2.0F, var8 + var9, 20.0F);
                    var8 = this.k0.get(this.H0);
                    var7 = (float) (var34.getHeight() / 2);
                    var7 = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.x((float) var34.getHeight(), 150.0F, 2.0F, var8 + var7, 20.0F);
                    boolean var10;
                    if (this.V0) {
                        this.V0 = false;
                        var4 = 0;
                        var10 = true;
                    } else {
                        var4 = this.H0;
                        var10 = false;
                    }

                    this.I0(var4, var23, var9, var7, 150.0F, var10);
                }
            } else {
                var4 = AppConstant.G;
                int var12;
                ArrayList var22;
                String var28;
                if (624 == var1 && var3 != null) {
                    this.Q0 = true;
                    if (this.h0.size() == 1) {
                        this.v0();
                    }

                    int var11 = var3.getIntExtra("primaryColor", -1);
                    var4 = var3.getIntExtra("secondaryColor", -1);
                    var28 = var3.getStringExtra("design_id");
                    var22 = (ArrayList) var3.getSerializableExtra("list");
                    var12 = this.w0.size();
                    int var13 = this.I0;
                    if (var12 > var13) {
                        this.w0.set(var13, var3.getStringExtra("frame_id"));
                    } else {
                        this.w0.add(var3.getStringExtra("frame_id"));
                    }

                    var12 = this.Z.size();
                    var13 = this.I0;
                    if (var12 > var13) {
                        this.Z.set(var13, var22);
                    } else {
                        this.Z.add(var22);
                    }

                    if (this.I0 == 0) {
                        this.a0 = var22;
                    }

                    FrameLayout var35 = this.c0;
                    if (var35 != null) {
                        var35.removeAllViews();
                    }

                    this.m0 = new ArrayList();
                    this.p0 = new ArrayList();
                    this.q0 = new ArrayList();
                    this.n0 = new ArrayList();
                    this.o0 = new ArrayList();
                    if (this.h0.size() < 2) {
                        this.y0(var28);
                    } else {
                        RelativeLayout var37 = new RelativeLayout(this);
                        var37.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
                        Paint var36 = new Paint();
                        var36.setColor(-65536);
                        var36.setAntiAlias(true);
                        var36.setDither(true);
                        var36.setStyle(Paint.Style.STROKE);
                        var36.setStrokeWidth(3.0F);
                        var36.setPathEffect(new DashPathEffect(new float[]{10.0F, 15.0F}, 0.0F));
                        var37.setLayerPaint(var36);

                        for (var12 = 0; var12 < this.Z.get(this.I0).size(); ++var12) {
                            this.d0.removeAllViews();
                            this.H0(this.g0, this.f0, var37, this.d0, this.c0, var12, this.I0, K1, M1, cardView, this.K, false);
                        }

                        this.c0.addView(var37);
                        this.W.set(this.I0, this.p0);
                        this.X.set(this.I0, this.q0);
                        this.U.set(this.I0, this.o0);
                        this.V.set(this.I0, this.n0);
                        this.T.set(this.I0, this.m0);
                        var37 = this.Y;
                        byte var41;
                        if (this.m0.size() > 0) {
                            var41 = 0;
                        } else {
                            var41 = 8;
                        }

                        var37.setVisibility(var41);
                        if (var11 != -1) {
                            this.u0(true, this.I0, var11);
                        }

                        if (var4 != -1) {
                            this.u0(false, this.I0, var4);
                        }

                        this.llList.requestLayout();
                    }
                } else {
                    this.M0 = this.h0.size();
                    Bitmap var5;
                    if (ImagePicker.shouldHandle(var1, var2, var3)) {
                        Image var6 = ImagePicker.getFirstImageOrNull(var3);
                        if (this.P0) {
                            this.P0 = false;
                            var5 = BitmapFactory.decodeFile((new File(var6.path)).getAbsolutePath());
                            var5.getWidth();
                            var5.getHeight();
                            var4 = var5.getWidth() / 2;
                            var5.getWidth();
                            var4 = var5.getHeight() / 2;
                            var5.getHeight();
                            this.n0(this.H0, var6.path);
                        } else {
                            byte var24;
                            if (T1) {
                                T1 = false;
                                var22 = new ArrayList();
                                Iterator var25 = ImagePicker.getImages(var3).iterator();
                                ;
                                while (var25.hasNext()) {
                                    var22.add(((Image) var25.next()).getPath());
                                    ArrayList var14 = this.Z;
                                    var14.add(var14.get(0));
                                }

                                this.h0.addAll(var22);
                                LinearLayout var27 = this.llChangeViewType;
                                if (this.h0.size() == 1) {
                                    var24 = 0;
                                } else {
                                    var24 = 8;
                                }

                                var27.setVisibility(var24);
                                if (this.h0.size() > 0) {
                                    (new a0(true)).execute(new URL[0]);
                                }
                            } else {
                                label182:
                                {
                                    I1.setTag(var6.path);
                                    if (S1) {
                                        this.x0(var6.path, I1.getWidth(), I1.getHeight());
                                        Utils.d();
                                        var23 = var6.path;
                                        var12 = this.h0.size();
                                        var4 = this.H0;
                                        var28 = var23;
                                        if (var12 > var4) {
                                            var28 = var23;
                                            break label182;
                                        }
                                    } else {
                                        var5 = Utils.B(var6.path);
                                        I1.setImageBitmap(var5);
                                        I1.setBackgroundColor(this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
                                        var12 = this.h0.size();
                                        var4 = this.H0;
                                        if (var12 > var4) {
                                            this.h0.set(var4, var6.path);
                                        } else {
                                            this.h0.add(var6.path);
                                            LinearLayout var26 = this.llChangeViewType;
                                            if (this.h0.size() == 1) {
                                                var24 = 0;
                                            } else {
                                                var24 = 8;
                                            }

                                            var26.setVisibility(var24);
                                            var22 = this.Z;
                                            var22.add(var22.get(0));
                                        }

                                        var23 = var6.path;
                                        var12 = this.h0.size();
                                        var4 = this.H0;
                                        var28 = var23;
                                        if (var12 > var4) {
                                            var28 = var23;
                                            break label182;
                                        }
                                    }

                                    var4 = 0;
                                }
                                this.F0(var28, var4, true);
                            }
                        }
                    } else {
                        label214:
                        {
                            label212:
                            {

                                Uri var29;
                                if (var2 == -1 && var1 == 69) {
                                    var29 = var3.getParcelableExtra("com.yalantis.ucrop.OutputUri");

                                    if (this.D0.length() > 0) {
                                        try {
                                            Utils.O();
                                            URL var30 = new URL(this.D0);
                                            HttpURLConnection var31 = (HttpURLConnection) ((URLConnection) (var30.openConnection()));
                                            var31.setDoInput(true);
                                            var31.connect();
                                            Bitmap var39 = BitmapFactory.decodeStream(var31.getInputStream());
                                            ContentResolver var40 = this.getContentResolver();
                                            File var32 = new File(var29.getPath());
                                            this.A0(var39, MediaStore.Images.Media.getBitmap(var40, Uri.fromFile(var32)), I1);
                                            this.D0 = "";
                                        } catch (Exception var20) {
                                            var20.printStackTrace();
                                        }
                                        break label214;
                                    }

                                    I1.setImageURI(var29);
                                    Utils.d();
                                    var23 = var29.getPath();
                                    var12 = this.h0.size();
                                    var4 = this.H0;
                                    var28 = var23;
                                    if (var12 > var4) {
                                        var28 = var23;
                                        break label212;
                                    }
                                } else {
                                    var12 = AppConstant.L;
                                    if (var1 != 6709 || var3 == null) {
                                        if (var1 == 1234) {
                                            byte[] var33 = this.getIntent().getByteArrayExtra("image");
                                            Utils.O();
                                            ImageView var38 = I1;
                                            Bitmap var15 = BitmapFactory.decodeByteArray(var33, 0, var33.length);
                                            var23 = N1;
                                            var34 = null;

                                            label155:
                                            {
                                                try {
                                                    Utils.O();
                                                    URL var16 = new URL(var23);
                                                    Bitmap var42 = BitmapFactory.decodeStream(((URLConnection) (var16.openConnection())).getInputStream());
                                                    var5 = Bitmap.createBitmap(var15.getWidth(), var15.getHeight(), Bitmap.Config.ARGB_8888);
                                                    Canvas var17 = new Canvas(var5);
                                                    Paint var18 = new Paint(1);
                                                    PorterDuffXfermode var19 = new PorterDuffXfermode(PorterDuff.Mode.DST_IN);
                                                    var18.setXfermode(var19);
                                                    var17.drawBitmap(var15, 0.0F, 0.0F, null);
                                                    var17.drawBitmap(var42, 0.0F, 0.0F, var18);
                                                    var18.setXfermode(null);
                                                } catch (IOException var21) {
                                                    System.out.println(var21);
                                                    break label155;
                                                }

                                                var34 = var5;
                                            }

                                            var38.setImageBitmap(var34);
                                        }
                                        break label214;
                                    }

                                    var29 = Uri.parse(var3.getStringExtra("uri"));
                                    I1.setImageURI(var29);
                                    Utils.d();
                                    var23 = var29.getPath();
                                    var12 = this.h0.size();
                                    var4 = this.H0;
                                    var28 = var23;
                                    if (var12 > var4) {
                                        var28 = var23;
                                        break label212;
                                    }
                                }

                                var4 = 0;
                            }

                            this.F0(var28, var4, true);
                        }
                    }
                }
            }
        }

        super.onActivityResult(var1, var2, var3);
    }


    @Override
    public void onBackPressed() {
     /*
        if (IsFrom.equals(Constant.IsFromPoster)) {
            startActivity(new Intent(activity, PosterMakerActivity.class));
        } else {
            startActivity(new Intent(activity, StoryMakerActivity.class));
        }*/
        finish();
        w0();
    }

    @OnClick
    public void onClick(final View view) {
        ImageView imageView = null;
        switch (view.getId()) {
            default: {
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgSpace: {
                imageView = this.imgSpace;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgSmall: {
                this.p0(0);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgLine: {
                imageView = this.imgLine;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgFont: {
                imageView = this.imgFont;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap: {
                this.p0(1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgColor: {
                imageView = this.imgColor;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgCaps: {
                imageView = this.imgCaps;
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap: {
                this.p0(2);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight: {
                this.o0(1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft: {
                this.o0(-1);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter: {
                this.o0(0);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.imgAlign: {
                imageView = this.imgAlign;
                break;
            }
        }
        this.r0(imageView);
    }

    @Override
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_new_design_edit_frame);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        IsFrom = getIntent().getStringExtra("IsFrom");
        this.y0 = new Utils(this);
        com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);
        int visibility = 0;
        this.K0 = -1;
        this.L0 = -1;
        this.O = new ArrayList<View>();
        this.Q = new ArrayList<StickerView>();
        this.P = new ArrayList<View>();
        this.w0 = new ArrayList<String>();
        this.s0 = new ArrayList<RelativeLayout>();
        this.R = new ArrayList<Boolean>();
        this.S = new ArrayList<Boolean>();
        this.r0 = new ArrayList<FrameLayout>();
        this.t0 = new ArrayList<FrameLayout>();
        this.u0 = new ArrayList<FrameLayout>();
        this.v0 = new ArrayList<FrameLayout>();
        this.h0 = new ArrayList<String>();
        this.i0 = new ArrayList<ArrayList<Integer>>();
        this.Z = new ArrayList<ArrayList<com.kotlinz.festivalstorymaker.Models.g>>();
        this.m0 = new ArrayList<ImageView>();
        this.p0 = new ArrayList<View>();
        this.q0 = new ArrayList<View>();
        this.n0 = new ArrayList<View>();
        this.o0 = new ArrayList<View>();
        this.j0 = new ArrayList<Float>();
        this.k0 = new ArrayList<Float>();
        this.l0 = new ArrayList<Float>();
        F1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.g>();
        G1 = new ArrayList<com.kotlinz.festivalstorymaker.Models.g>();
        this.N = new ArrayList<com.kotlinz.festivalstorymaker.Models.g>();
        H1 = new ArrayList<ImageView>();
        this.W = new ArrayList<ArrayList<View>>();
        this.X = new ArrayList<ArrayList<View>>();
        this.U = new ArrayList<ArrayList<View>>();
        this.V = new ArrayList<ArrayList<View>>();
        this.T = new ArrayList<ArrayList<ImageView>>();
        this.l1 = this;
        this.h0 = (ArrayList<String>) this.getIntent().getSerializableExtra("images");
        imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_press);
        FilePath = getIntent().getStringExtra("FilePath");
        x1 = this.findViewById(com.kotlinz.festivalstorymaker.R.id.rlMainView);
        this.O0 = new AppConstant();
        this.L = this;
        X1 = this;
        this.rlFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                if (findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage).isShown()) {
                    B0(false);
                }
            }
        });
        this.y0("");
        this.imgFont.setColorFilter(-16777216);
        this.llFonts.bringToFront();
        final FontListAdapter fontListAdapter = new FontListAdapter(this, super.fontList, new CEFontListener(), this.r1);
        this.o1 = fontListAdapter;
        this.listFont.setAdapter(fontListAdapter);
        final com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter colorListAdapter = new com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter(this, super.colorList, new CanvadEditorColorListListener(), this.q1);
        this.p1 = colorListAdapter;
        this.listColor.setAdapter(colorListAdapter);
        this.seekBarFontSpacing.setOnSeekBarChangeListener(new CEFontSpacing(this));
        this.seekBarFontHeight.setOnSeekBarChangeListener(new CEFontHeight(this));
        final LinearLayout llChangeViewType = this.llChangeViewType;
        if (this.h0.size() != 1) {
            visibility = 8;
        }
        llChangeViewType.setVisibility(visibility);
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CanvasEditorActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    @Override
    public void onDestroy() {
        this.llList.removeAllViews();
        this.llList.requestLayout();
        final Utils y0 = this.y0;
        if (y0 != null) {
            y0.u();
        }
        super.onDestroy();
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.cardCancelImage, com.kotlinz.festivalstorymaker.R.id.cardDeleteImage})
    public void onViewClick(View g1) {
        final int id = g1.getId();
        if (id != com.kotlinz.festivalstorymaker.R.id.cardCancelImage) {
            if (id != com.kotlinz.festivalstorymaker.R.id.cardDeleteImage) {
                return;
            }
            g1 = this.g1;
            if (g1 != null) {
                this.b0.removeView(g1);
                this.b0.requestLayout();
                this.g1 = null;
            } else {
                this.q0.remove(I1);
                this.p0.remove(I1);
                H1.remove(I1);
                this.b0.removeView(I1);
                this.b0.requestLayout();
            }
        }
        this.B0(false);
    }


    @OnClick({com.kotlinz.festivalstorymaker.R.id.iv_my_creation, com.kotlinz.festivalstorymaker.R.id.llVerticalSize, com.kotlinz.festivalstorymaker.R.id.llStorySize, com.kotlinz.festivalstorymaker.R.id.llSquareSize, com.kotlinz.festivalstorymaker.R.id.rlTop, com.kotlinz.festivalstorymaker.R.id.llGallery, com.kotlinz.festivalstorymaker.R.id.llCamera, com.kotlinz.festivalstorymaker.R.id.iv_back})
    public void onViewClicked(final View view) {
        final int id = view.getId();
        final int n = 1;
        switch (id) {
            default: {
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.iv_my_creation: {
                this.S0 = true;
                this.w0();
                new y().execute();
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llVerticalSize: {
                this.t0(2);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_unpress);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_press);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_unpress);
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.llStorySize: {
                this.t0(3);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_unpress);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_unpress);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_press);
                break;
            }
            case com.kotlinz.festivalstorymaker.R.id.llSquareSize: {
                this.t0(1);
                imgSquareSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_square_press);
                imgVerticalSize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_vertical_unpress);
                imgStorySize.setImageResource(com.kotlinz.festivalstorymaker.R.drawable.ic_story_unpress);
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llScroll:
            case com.kotlinz.festivalstorymaker.R.id.rlBottomMoveDeleteDialog:
            case com.kotlinz.festivalstorymaker.R.id.rlTop: {
                this.w0();
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llGallery: {
                final List<String> h0 = this.h0;
                if (h0 == null) {
                    return;
                }
                this.M0 = h0.size();
                T1 = true;
                if (this.a0 != null) {
                    for (int i = 0; i < this.a0.size(); ++i) {
                        if (this.a0.get(i).q.equals("0")) {
                            final boolean b = true;
                            final ImagePicker.ImagePickerWithActivity a = new ImagePicker.ImagePickerWithActivity(this);
                            a.config.folderMode = true;
                            int n3;
                            if (b) {
                                n3 = n;
                            } else {
                                n3 = 20;
                            }
                            final ImagePickerConfig a2 = a.config;
                            a2.limit = n3;
                            a2.showCamera = false;
                            a.start();
                            return;
                        }
                    }
                    final boolean b = false;
                }
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.llCamera: {
                final List<String> h2 = this.h0;
                if (h2 != null) {
                    this.M0 = h2.size();
                    T1 = true;
                    final CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                    cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                    cameraOnlyConfig.returnMode = ReturnMode.ALL;
                    final Intent intent = new Intent(this, ImagePickerActivity.class);
                    intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                    this.startActivityForResult(intent, 553);
                }
                return;
            }
            case com.kotlinz.festivalstorymaker.R.id.iv_back: {
                finish();
                return;
            }
        }

    }

    public final void p0(final int e) {
        final ImageView imgFirstCap = this.imgFirstCap;
        final int n = -16777216;
        int color;
        if (e == 1) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgFirstCap.setColorFilter(color);
        final ImageView imgAllCap = this.imgAllCap;
        int color2;
        if (e == 2) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAllCap.setColorFilter(color2);
        final ImageView imgSmall = this.imgSmall;
        int color3;
        if (e == 0) {
            color3 = n;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgSmall.setColorFilter(color3);
        final String string = this.t1.getText();
        if (e != -1) {
            final TextStickerViewNew1 t1 = this.t1;
            String text;
            if (e == 2) {
                text = string.toUpperCase();
            } else if (e == 0) {
                text = string.toLowerCase();
            } else {
                text = this.f0(string);
            }
            t1.setText(text);
        }
        final com.kotlinz.festivalstorymaker.Models.z.c c = this.s1.get((int) this.t1.getTag());
        c.e = e;
        this.s1.set((int) this.t1.getTag(), c);
    }


    public final void q0(int i) {
        boolean z = false;
        int i2;
        if (W1) {
            for (i2 = 0; i2 < this.W.get(this.H0).size(); i2++) {
                if (((ArrayList) this.W.get(this.H0)).get(i2) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.W.get(this.H0)).get(i2)).setColorFilter(i);
                } else {
                    ((TextView) ((ArrayList) this.W.get(this.H0)).get(i2)).setTextColor(i);
                }
            }
            int i3 = 0;
            while (i3 < this.X.get(this.H0).size()) {
                if (((ArrayList) this.X.get(this.H0)).get(i3) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.X.get(this.H0)).get(i3)).setColorFilter(i);
                } else {
                    ((TextView) ((ArrayList) this.X.get(this.H0)).get(i3)).setTextColor(i);
                }
                i3++;
            }
            return;
        }
        if (U1) {
            i2 = this.H0;
            z = true;
        } else if (V1) {
            i2 = this.H0;
        } else if (P1) {
            z1.setTextColor(i);
            return;
        } else {
            I1.setColorFilter(i);
            return;
        }
        u0(z, i2, i);
    }


    public final void r0(final ImageView imageView) {
        final ImageView imgFont = this.imgFont;
        final int n = -16777216;
        int color;
        if (imageView == imgFont) {
            color = -16777216;
        } else {
            color = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgFont.setColorFilter(color);
        final ImageView imgColor = this.imgColor;
        int color2;
        if (imageView == imgColor) {
            color2 = -16777216;
        } else {
            color2 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgColor.setColorFilter(color2);
        final ImageView imgAlign = this.imgAlign;
        int color3;
        if (imageView == imgAlign) {
            color3 = -16777216;
        } else {
            color3 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgAlign.setColorFilter(color3);
        final ImageView imgSpace = this.imgSpace;
        int color4;
        if (imageView == imgSpace) {
            color4 = -16777216;
        } else {
            color4 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgSpace.setColorFilter(color4);
        final ImageView imgLine = this.imgLine;
        int color5;
        if (imageView == imgLine) {
            color5 = -16777216;
        } else {
            color5 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgLine.setColorFilter(color5);
        final ImageView imgCaps = this.imgCaps;
        int color6;
        if (imageView == imgCaps) {
            color6 = n;
        } else {
            color6 = this.getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imgCaps.setColorFilter(color6);
        LinearLayout linearLayout;
        if (imageView == this.imgFont) {
            linearLayout = this.llFonts;
        } else if (imageView == this.imgColor) {
            linearLayout = this.llColors;
        } else if (imageView == this.imgAlign) {
            linearLayout = this.llAlign;
        } else if (imageView == this.imgSpace) {
            linearLayout = this.llSpacing;
        } else if (imageView == this.imgLine) {
            linearLayout = this.llLine;
        } else {
            if (imageView != this.imgCaps) {
                return;
            }
            linearLayout = this.llCaps;
        }
        linearLayout.bringToFront();
    }


    @Override
    public void t(final float n, final float n2, final Bitmap bitmap, final String s) {
        this.m1 = true;
        if (this.t0.size() > 1) {
            final float n3 = (bitmap.getWidth() - this.j1.getWidths()) / 2.0f;
            final float n4 = (bitmap.getHeight() - this.j1.getHeights()) / 2.0f;
            (this.n1 = new Dialog(this)).setContentView(com.kotlinz.festivalstorymaker.R.layout.dialog_apply_logo_conformation);
            this.n1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtOnlythis).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    n1.dismiss();
                }
            });
            this.n1.findViewById(com.kotlinz.festivalstorymaker.R.id.txtAll).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    j0(CanvasEditorActivity.this);
                    I0(0, j1.getStickerPath(), n, n3, j1.getHeights(), true);
                    n1.dismiss();
                }
            });
            this.n1.show();
        }
    }

    public final void t0(int i) {
        this.R0 = true;
        this.v0();
        final ArrayList<com.kotlinz.festivalstorymaker.Models.g> a = this.W0.get(i - 1).a;
        this.a0 = a;
        if (a.size() > 0) {
            this.scroll.setVisibility(View.VISIBLE);
            for (i = 0; i < this.h0.size(); ++i) {
                this.Z.add(this.a0);
            }
            new a0(false).execute();
            return;
        }
        this.scroll.setVisibility(View.GONE);
    }

    public final void u0(boolean var1, int var2, int var3) {
        if (var1) {
            this.K0 = var3;
        } else {
            this.L0 = var3;
        }

        int var4 = 0;
        byte var5 = 0;
        if (var1) {
            for (var4 = var5; var4 < this.V.get(var2).size(); ++var4) {
                if (((ArrayList) this.V.get(var2)).get(var4) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.V.get(var2)).get(var4)).setColorFilter(var3);
                } else if (((ArrayList) this.V.get(var2)).get(var4) instanceof BorderedTextView) {
                    ((BorderedTextView) ((ArrayList) this.V.get(var2)).get(var4)).setBorderedColor(var3);
                } else {
                    ((TextView) ((ArrayList) this.V.get(var2)).get(var4)).setTextColor(var3);
                }
            }
        } else {
            for (; var4 < this.U.get(var2).size(); ++var4) {
                if (((ArrayList) this.U.get(var2)).get(var4) instanceof ImageView) {
                    ((ImageView) ((ArrayList) this.U.get(var2)).get(var4)).setColorFilter(var3);
                } else if (((ArrayList) this.U.get(var2)).get(var4) instanceof BorderedTextView) {
                    ((BorderedTextView) ((ArrayList) this.U.get(var2)).get(var4)).setBorderedColor(var3);
                } else {
                    ((TextView) ((ArrayList) this.U.get(var2)).get(var4)).setTextColor(var3);
                }
            }
        }

    }


    public final void v0() {
        A1 = 0;
        this.s0.clear();
        this.R.clear();
        this.S.clear();
        this.r0.clear();
        this.t0.clear();
        this.Z.clear();
        this.m0.clear();
        this.p0.clear();
        this.q0.clear();
        this.n0.clear();
        this.o0.clear();
        this.j0.clear();
        this.k0.clear();
        this.l0.clear();
        F1.clear();
        G1.clear();
        this.N.clear();
        H1.clear();
        this.W.clear();
        this.X.clear();
        this.U.clear();
        this.V.clear();
        this.T.clear();
        this.llList.removeAllViews();
        this.llList.requestLayout();
        this.Z.clear();
        this.N.clear();
        this.M0 = 0;
        this.Q.clear();
        this.u0.clear();
    }

    public void w0() {
        for (int i = 0; i < this.Q.size(); ++i) {
            final StickerView stickerView = this.Q.get(i);
            stickerView.showIcons = false;
            stickerView.invalidate();
        }
        if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage).isShown()) {
            this.B0(false);
        }
        if (this.rlBottomMoveDeleteDialog.isShown()) {
            this.J0(false);
        }
        final ImageStickerViewNew j1 = this.j1;
        if (j1 != null) {
            j1.setInEdit(false);
        }
        final TextStickerViewNew1 t1 = this.t1;
        if (t1 != null) {
            t1.setInEdit(false);
        }
        final TextView z1 = CanvasEditorActivity.z1;
        if (z1 != null) {
            z1.setBackground(null);
        }
        if (this.findViewById(com.kotlinz.festivalstorymaker.R.id.llTextEditor).isShown()) {
            this.D0(false);
        }
    }

    public final void x0(final String s, final int n, final int n2) {
        Utils.d();
        final Bundle bundle = new Bundle();
        bundle.putString("com.yalantis.ucrop.CompressionFormatName", Bitmap.CompressFormat.JPEG.name());
        bundle.putInt("com.yalantis.ucrop.CompressionQuality", 100);
        bundle.putString("com.yalantis.ucrop.UcropToolbarTitleText", "Crop");
        bundle.putBoolean("com.yalantis.ucrop.HideBottomControls", true);
        bundle.putBoolean("com.yalantis.ucrop.FreeStyleCrop", false);
        final Uri fromFile = Uri.fromFile(new File(s));
        final File cacheDir = this.getCacheDir();
        final StringBuilder sb = new StringBuilder();
        sb.append(System.currentTimeMillis());
        sb.append(".png");
        final Uri fromFile2 = Uri.fromFile(new File(cacheDir, sb.toString()));
        final Intent intent = new Intent();
        final Bundle bundle2 = new Bundle();
        bundle2.putParcelable("com.yalantis.ucrop.InputUri", fromFile);
        bundle2.putParcelable("com.yalantis.ucrop.OutputUri", fromFile2);
        final float n3 = (float) n;
        final float n4 = (float) n2;
        bundle2.putFloat("com.yalantis.ucrop.AspectRatioX", n3);
        bundle2.putFloat("com.yalantis.ucrop.AspectRatioY", n4);
        bundle2.putInt("com.yalantis.ucrop.MaxSizeX", 2200);
        bundle2.putInt("com.yalantis.ucrop.MaxSizeY", 2200);
        bundle2.putAll(bundle);
        intent.setClass(this, UCropActivity.class);
        intent.putExtras(bundle2);
        startActivityForResult(intent, 69);
    }


    public final void y0(String s) {
        this.M = new com.kotlinz.festivalstorymaker.Other.g.a(this, this);
        if (s.length() <= 0) {
            s = this.I.r;
        }
        if (this.F0.length() > 0) {
            s = this.F0;
        } else {
            s = this.I.s;
        }
        for (int i = 0; i < this.h0.size(); ++i) {
            this.w0.add(this.I.e);
        }
        if (Utils.x(this)) {
            GetEditData();
        }
    }

    private void GetEditData() {
        File fileEvents = new File(FilePath);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileEvents));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String Response = text.toString();
        M.a.z(0, Response);
    }

    @Override
    public void z(int var1, String var2) {
        int var3 = this.N0;
        byte var4 = 0;
        if (var1 == var3) {
            JSONException var10000;
            label87:
            {
                JSONArray var15;
                boolean var10001;
                try {
                    JSONObject var5 = new JSONObject(var2);
                    if (!var5.getString("success").equalsIgnoreCase("1")) {
                        return;
                    }

                    var15 = var5.getJSONArray("response");
                } catch (JSONException var10) {
                    var10000 = var10;
                    var10001 = false;
                    break label87;
                }

                var1 = var4;

                while (true) {
                    try {
                        if (var1 >= var15.length()) {
                            break;
                        }
                        JSONObject var11 = var15.getJSONObject(var1);
                        com.kotlinz.festivalstorymaker.Models.o var6 = new com.kotlinz.festivalstorymaker.Models.o();
                        var6.e = var11.getString("category_id");
                        var6.g = var11.getString("name");
                        var6.i = var11.getString("video");
                        var6.f = var11.getString("image");
                        var11.getString("youtube_url");
                    } catch (JSONException var9) {
                        var10000 = var9;
                        var10001 = false;
                        break label87;
                    }

                    ++var1;
                }
                return;
            }
            JSONException var12 = var10000;
            var12.printStackTrace();
        } else {
            ArrayList var13;
            Object var14;
            label91:
            {
                this.z0 = var2;
                F1.clear();
                G1.clear();
                H1.clear();
                this.llList.removeAllViews();
                this.llList.requestLayout();
                A1 = 0;
                this.W0 = this.O0.getEditThemFileData(this, this.z0);
                if (this.Q0 && this.F0.length() > 0) {
                    var13 = this.W0;
                    var1 = Integer.parseInt(this.F0) - 1;
                } else {
                    boolean var7 = com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.K1);
                    var1 = 2;
                    if (var7 || com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.Y1) || com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.R1) || com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.X1) || com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.Q1)) {
                        var14 = this.W0.get(1);
                        break label91;
                    }
                    if (!com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b().d(AppConstant.Categoryid, "").equalsIgnoreCase(AppConstant.H1)) {
                        var14 = this.W0.get(0);
                        break label91;
                    }
                    var13 = this.W0;
                }
                var14 = var13.get(var1);
            }
            var13 = ((com.kotlinz.festivalstorymaker.Models.a) var14).a;
            this.a0 = var13;
            if (var13.size() > 0) {
                this.scroll.setVisibility(View.VISIBLE);
                for (var1 = 0; var1 < this.h0.size(); ++var1) {
                    this.Z.add(this.a0);
                }
                (new a0(false)).execute();
            } else {
                this.scroll.setVisibility(View.GONE);
            }
        }

    }


    public File z0() {
        final String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post";
        final String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        final File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(file);
        sb.append(File.separator);
        sb.append(s);
        sb.append(".jpg");
        final String string = sb.toString();
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        return new File(string);
    }


    public class ColorListAdapter extends RecyclerView.Adapter<ColorListAdapter.ViewHolder> {
        public Activity g;
        public String[] h;

        public ColorListAdapter(final Activity g, final String[] h) {
            this.g = g;
            this.h = h;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(com.kotlinz.festivalstorymaker.R.layout.adapter_color_list_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
//            holder.card.setCardBackgroundColor(Color.parseColor(this.h[position]));
            LinearLayout linearLayout;
            Drawable drawable;
            if (this.h[position].contains("FFFFFF")) {
                linearLayout = holder.llbg;
                drawable = this.g.getResources().getDrawable(com.kotlinz.festivalstorymaker.R.drawable.rounded_corner_black_border);
            } else {
                linearLayout = holder.llbg;
                drawable = null;
            }
            linearLayout.setBackground(drawable);
            holder.card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    q0(Color.parseColor(h[position]));
                }
            });
        }


        @Override
        public int getItemCount() {
            return this.h.length;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            @BindView(com.kotlinz.festivalstorymaker.R.id.card)
            public CardView card;
            @BindView(com.kotlinz.festivalstorymaker.R.id.llbg)
            public LinearLayout llbg;

            public ViewHolder(final View view) {
                super(view);
                ButterKnife.bind(this, view);
            }
        }
    }


    public class a0 extends AsyncTask<URL, Integer, Bitmap> {
        public boolean a;

        public a0(boolean z) {
            this.a = z;
        }

        public Bitmap doInBackground(URL... objArr) {
            URL[] urlArr = objArr;
            List list = CanvasEditorActivity.this.h0;
            if (list != null && list.size() > CanvasEditorActivity.this.M0) {
                Utils.d();
                CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
                canvasEditorActivity.F0(canvasEditorActivity.h0.get(canvasEditorActivity.M0), CanvasEditorActivity.this.M0, false);
            }
            return null;
        }

        public void onPostExecute(Bitmap obj) {
            super.onPostExecute(obj);
            CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
            canvasEditorActivity.G0(canvasEditorActivity.M0, a);
        }

        public void onPreExecute() {
            super.onPreExecute();
        }
    }


    public class b0 extends AsyncTask<Void, Void, Void> {
        public String a;
        public Bitmap b;

        public b0(final String a, final int n) {
            this.a = a;
        }


        public void onPostExecute(Void o) {
            super.onPostExecute(o);
            int n = 0;
            while (true) {
                final CanvasEditorActivity c = CanvasEditorActivity.this;
                if (n >= c.r0.get(c.H0).getChildCount()) {
                    break;
                }
                final CanvasEditorActivity c2 = CanvasEditorActivity.this;
                if (c2.r0.get(c2.H0).getChildAt(n) instanceof ImageStickerViewNew) {
                    final CanvasEditorActivity c3 = CanvasEditorActivity.this;
                    if (c3.r0.get(c3.H0).getChildAt(n).getTag() != null) {
                        final CanvasEditorActivity c4 = CanvasEditorActivity.this;
                        if (c4.r0.get(c4.H0).getChildAt(n).getTag().equals(CanvasEditorActivity.this.E0)) {
                            final CanvasEditorActivity c5 = CanvasEditorActivity.this;
                            c5.r0.get(c5.H0).removeViewAt(n);
                            final CanvasEditorActivity c6 = CanvasEditorActivity.this;
                            c6.r0.get(c6.H0).requestLayout();
                        }
                    }
                }
                ++n;
            }
            CanvasEditorActivity.this.y0.u();
            ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(CanvasEditorActivity.this, this.a, D1 / 2.0f, (float) (this.b.getHeight() + 50), 1.0f, 0.0f, 2, true);
            imageStickerViewNew.setGif(false);
            imageStickerViewNew.setTag(CanvasEditorActivity.this.E0);
            imageStickerViewNew.setBitmap(this.b, Boolean.TRUE);
            imageStickerViewNew.setSize(250.0f);
            imageStickerViewNew.setOperationListener(new ECOperationListener(CanvasEditorActivity.this));
            final CanvasEditorActivity c7 = CanvasEditorActivity.this;
            c7.r0.get(c7.H0).addView(imageStickerViewNew);
            final CanvasEditorActivity c8 = CanvasEditorActivity.this;
            c8.r0.get(c8.H0).requestLayout();
        }

        @Override
        protected Void doInBackground(Void... array) {
            final Void[] array2 = array;
            Utils.O();
            try {
                this.b = BitmapFactory.decodeStream(new URL(this.a).openConnection().getInputStream());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return null;
        }

        public void onPreExecute() {
            super.onPreExecute();
            CanvasEditorActivity.this.y0 = new Utils(CanvasEditorActivity.this);
            final CanvasEditorActivity c = CanvasEditorActivity.this;
            c.y0.c(c.getResources().getString(com.kotlinz.festivalstorymaker.R.string.loading));
            if (!CanvasEditorActivity.this.isFinishing()) {
                CanvasEditorActivity.this.y0.M();
            }
        }
    }


    public class y extends AsyncTask<String, Boolean, File> {
        public final void a(int n) {
            try {
                final Bitmap e0 = e0(CanvasEditorActivity.this.s0.get(n));
                final File z0 = z0();
                if (z0 != null) {
                    final FileOutputStream fileOutputStream = new FileOutputStream(z0.getAbsolutePath());
                    e0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                    ++n;
                    Utils.K(CanvasEditorActivity.this, z0);
                    if (CanvasEditorActivity.this.s0.size() > n) {
                        this.a(n);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }


        public void onPostExecute(final File o) {
            final File file = o;
            final CanvasEditorActivity a = CanvasEditorActivity.this;
            a.S0 = false;
            a.y0.u();
            Toast.makeText(CanvasEditorActivity.this.getApplicationContext(), getResources().getString(com.kotlinz.festivalstorymaker.R.string.download_sucess), Toast.LENGTH_LONG).show();
        }

        @Override
        protected File doInBackground(String... array) {
            final String[] array2 = array;
            for (int i = 0; i < w0.size(); ++i) {
                Utils.J(AppConstant.X1, w0.get(i));
            }
            this.a(0);
            return new File("");
        }

        public void onPreExecute() {
            super.onPreExecute();
            y0 = new Utils(CanvasEditorActivity.this);
            final CanvasEditorActivity a = CanvasEditorActivity.this;
            a.y0.c(a.getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            y0.M();
        }
    }


    public class j implements View.OnClickListener {
        public void onClick(View view) {
            if (CanvasEditorActivity.this.findViewById(com.kotlinz.festivalstorymaker.R.id.llDeleteImage).isShown()) {
                CanvasEditorActivity.this.B0(false);
            }
        }
    }

    public class x extends BottomSheetDialogFragment {
        public CoordinatorLayout.Behavior k0;

        public class a implements View.OnClickListener {
            public void onClick(View view) {
                CoordinatorLayout.Behavior behavior = x.this.k0;
                if (behavior != null && (behavior instanceof BottomSheetBehavior)) {
                    ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                O1 = false;
                CameraOnlyConfig cameraOnlyConfig = new CameraOnlyConfig();
                cameraOnlyConfig.savePath = ImagePickerSavePath.DEFAULT;
                cameraOnlyConfig.returnMode = ReturnMode.ALL;
                FragmentActivity c = getActivity();
                Intent intent = new Intent(c, ImagePickerActivity.class);
                intent.putExtra(CameraOnlyConfig.class.getSimpleName(), cameraOnlyConfig);
                c.startActivityForResult(intent, 553);
            }
        }
    }

    public class z implements View.OnTouchListener {
        public boolean e = false;
        public boolean f = true;
        public boolean g = true;
        public float h = 0.5f;
        public float i = 10.0f;
        public int j = -1;
        public float k;
        public float l;
        public com.kotlinz.festivalstorymaker.Other.b m;
        public GestureDetector n;
        public ScrollView o;
        public int p;
        public ImageView q;
        public RecyclerView r;
        public RecyclerView s;
        public int t = 0;
        public float u = 0.0f;
        public float v = 0.0f;

        public class b extends GestureDetector.SimpleOnGestureListener {
            public com.kotlinz.festivalstorymaker.Models.g e;

            public b(com.kotlinz.festivalstorymaker.Models.g gVar) {
                this.e = gVar;
            }

            public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
                CanvasEditorActivity canvasEditorActivity = CanvasEditorActivity.this;
                if (canvasEditorActivity.u1) {
                    canvasEditorActivity.u1 = false;
                } else {
                    canvasEditorActivity.w0();
                    z zVar = z.this;
                    CanvasEditorActivity canvasEditorActivity2 = CanvasEditorActivity.this;
                    if (canvasEditorActivity2.m1) {
                        canvasEditorActivity2.m1 = false;
                    } else {
                        Fragment xVar;
                        FragmentManager U;
                        com.kotlinz.festivalstorymaker.Models.g gVar = this.e;
                        CanvasEditorActivity.N1 = gVar.f;
                        CanvasEditorActivity.I1 = zVar.q;
                        CanvasEditorActivity.J1 = zVar.r;
                        CanvasEditorActivity.L1 = zVar.s;
                        canvasEditorActivity2.H0 = zVar.p;
                        if (gVar.q.equalsIgnoreCase("1")) {
                            CanvasEditorActivity.S1 = true;
                            CanvasEditorActivity.Q1 = false;
                            xVar = new x();
                            U = getSupportFragmentManager();
                        } else {
                            CanvasEditorActivity.S1 = false;
                            CanvasEditorActivity.Q1 = false;
                            xVar = new x();
                            U = getSupportFragmentManager();
                        }
//                        xVar.p0(U, xVar.B);
                    }
                }
                return false;
            }
        }

        public class a implements com.kotlinz.festivalstorymaker.Other.b.a {
            public float a;
            public float b;
            public Vector2D c = new Vector2D();

            public a(j jVar) {
            }


            public boolean a(View view, com.kotlinz.festivalstorymaker.Other.b bVar) {
                float b = z.this.g ? bVar.b() : 1.0f;
                float f = 0.0f;
                float a = z.this.e ? Vector2D.a(this.c, com.kotlinz.festivalstorymaker.Other.b.e) : 0.0f;
                float f2 = z.this.f ? bVar.f - this.a : 0.0f;
                if (z.this.f) {
                    f = bVar.g - this.b;
                }
                float f3 = this.a;
                float f4 = this.b;
                z zVar = z.this;
                float f5 = zVar.h;
                float f6 = zVar.i;
                if (!(view.getPivotX() == f3 && view.getPivotY() == f4)) {
                    float[] fArr = new float[]{0.0f, 0.0f};
                    view.getMatrix().mapPoints(fArr);
                    view.setPivotX(f3);
                    view.setPivotY(f4);
                    float[] fArr2 = new float[]{0.0f, 0.0f};
                    view.getMatrix().mapPoints(fArr2);
                    f4 = fArr2[0] - fArr[0];
                    f3 = fArr2[1] - fArr[1];
                    view.setTranslationX(view.getTranslationX() - f4);
                    view.setTranslationY(view.getTranslationY() - f3);
                }
                zVar.a(view, f2, f);
                f3 = Math.max(f5, Math.min(f6, view.getScaleX() * b));
                view.setScaleX(f3);
                view.setScaleY(f3);
                f3 = view.getRotation() + a;
                if (f3 > 180.0f) {
                    f3 -= 360.0f;
                } else if (f3 < -180.0f) {
                    f3 += 360.0f;
                }
                view.setRotation(f3);
                return false;
            }

            public boolean b(View view, com.kotlinz.festivalstorymaker.Other.b bVar) {
                this.a = bVar.f;
                this.b = bVar.g;
                this.c.set(com.kotlinz.festivalstorymaker.Other.b.e);
                return true;
            }
        }

        public z(Activity activity, ScrollView scrollView, ImageView imageView, int i, com.kotlinz.festivalstorymaker.Models.g gVar, RecyclerView recyclerView, RecyclerView recyclerView2) {
            this.q = imageView;
            this.r = recyclerView;
            this.s = recyclerView2;
            this.o = scrollView;
            this.p = i;
            this.m = new com.kotlinz.festivalstorymaker.Other.b(new a(null));
            this.n = new GestureDetector(activity, new b(gVar));
        }

        public final void a(View view, float f, float f2) {
            float[] fArr = new float[]{f, f2};
            view.getMatrix().mapVectors(fArr);
            view.setTranslationX(view.getTranslationX() + fArr[0]);
            view.setTranslationY(view.getTranslationY() + fArr[1]);
        }

        public final float b(MotionEvent motionEvent) {
            return (float) Math.toDegrees(Math.atan2(motionEvent.getY(0) - motionEvent.getY(1), motionEvent.getX(0) - motionEvent.getX(1)));
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (this.n.onTouchEvent(motionEvent)) {
                return true;
            }
            this.m.c(view, motionEvent);
            ImageView imageView = (ImageView) view;
            int action = motionEvent.getAction() & 255;
            int i = 0;
            if (action != 0) {
                ViewPropertyAnimator duration;
                TimeInterpolator linearInterpolator = new LinearInterpolator();
                if (action != 2) {
                    if (action == 5) {
                        this.o.requestDisallowInterceptTouchEvent(true);
                        float x = motionEvent.getX(0) - motionEvent.getX(1);
                        float y = motionEvent.getY(0) - motionEvent.getY(1);
                        if (((float) Math.sqrt((y * y) + (x * x))) > 10.0f) {
                            this.t = 2;
                        }
                        this.u = b(motionEvent);
                    } else if (action == 6) {
                        this.o.requestDisallowInterceptTouchEvent(false);
                        this.t = 0;
                        if (view.getRotation() > -10.0f && view.getRotation() < 10.0f) {
                            duration = view.animate().rotation(0.0f).setDuration(0);
                            linearInterpolator = new LinearInterpolator();
                        }
                    }
                } else if (this.t == 2) {
                    if (motionEvent.getPointerCount() == 2) {
                        this.v = b(motionEvent) - this.u;
                    }
                    duration = view.animate().rotationBy(this.v).setDuration(0);
                    linearInterpolator = new LinearInterpolator();
                }
//                    duration.setInterpolator(linearInterpolator).start();
            } else {
                this.o.requestDisallowInterceptTouchEvent(true);
                this.t = 1;
            }
            if (!this.f) {
                return true;
            }
            action = motionEvent.getAction();
            int actionMasked = motionEvent.getActionMasked() & action;
            if (actionMasked != 0) {
                if (actionMasked == 1) {
                    this.o.requestDisallowInterceptTouchEvent(false);
                    this.j = -1;
                } else if (actionMasked == 2) {
                    if (CanvasEditorActivity.this.r0.get(this.p).getHeight() / 2 == ((int) (view.getY() + ((float) (view.getHeight() / 2))))) {
                        CanvasEditorActivity.this.P.get(this.p).setVisibility(View.VISIBLE);
                    } else {
                        CanvasEditorActivity.this.P.get(this.p).setVisibility(View.GONE);
                    }
                    if (CanvasEditorActivity.this.r0.get(this.p).getWidth() / 2 == ((int) (view.getX() + ((float) (view.getWidth() / 2))))) {
                        CanvasEditorActivity.this.O.get(this.p).setVisibility(View.VISIBLE);
                    } else {
                        CanvasEditorActivity.this.O.get(this.p).setVisibility(View.GONE);
                    }
                    this.o.requestDisallowInterceptTouchEvent(true);
                    action = motionEvent.findPointerIndex(this.j);
                    if (action != -1) {
                        float x2 = motionEvent.getX(action);
                        float y2 = motionEvent.getY(action);
                        if (!this.m.b) {
                            a(view, x2 - this.k, y2 - this.l);
                        }
                    }
                } else if (actionMasked == 3) {
                    this.j = -1;
                } else if (actionMasked == 6) {
                    this.o.requestDisallowInterceptTouchEvent(false);
                    int i2 = (65280 & action) >> 8;
                    if (motionEvent.getPointerId(i2) == this.j) {
                        if (i2 == 0) {
                            i = 1;
                        }
                        this.k = motionEvent.getX(i);
                        this.l = motionEvent.getY(i);
                        this.j = motionEvent.getPointerId(i);
                    }
                }
                CanvasEditorActivity.this.O.get(this.p).setVisibility(View.GONE);
                CanvasEditorActivity.this.P.get(this.p).setVisibility(View.GONE);
            } else {
                this.o.requestDisallowInterceptTouchEvent(true);
                this.k = motionEvent.getX();
                this.l = motionEvent.getY();
                this.j = motionEvent.getPointerId(0);
            }
            return true;
        }
    }
}
