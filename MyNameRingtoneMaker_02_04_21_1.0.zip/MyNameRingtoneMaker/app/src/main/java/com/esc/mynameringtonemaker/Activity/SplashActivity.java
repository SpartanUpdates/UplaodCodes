package com.esc.mynameringtonemaker.Activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.mynameringtonemaker.R;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;
import com.nabinbhandari.android.permissions.Permissions.Options;

public class SplashActivity extends AppCompatActivity {


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);

        Permissions.check((Context) this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, "storage permissions are required because...", new Options().setSettingsDialogTitle("Warning!").setRationaleDialogTitle("Info"), new PermissionHandler() {
            public void onGranted() {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                        finish();
                    }
                }, 2000);
            }
        });
    }
}
