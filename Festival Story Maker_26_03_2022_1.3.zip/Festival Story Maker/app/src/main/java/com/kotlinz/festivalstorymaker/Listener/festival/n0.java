package com.kotlinz.festivalstorymaker.Listener.festival;

import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;

public class n0 implements ColorListAdapter.a {
    public final  FestivalDetailActivity_New n;

    public  n0(FestivalDetailActivity_New festivalDetailActivity_New) {
        this.n = festivalDetailActivity_New;
    }


    @Override
    public void D(int p0) {
        this.n.M(p0);
    }
}
