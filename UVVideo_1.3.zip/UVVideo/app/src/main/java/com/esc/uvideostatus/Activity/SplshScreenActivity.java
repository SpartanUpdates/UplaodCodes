package com.esc.uvideostatus.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.esc.uvideostatus.kprogresshud.KProgressHUD;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.exoplayer2.C;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.PrefManager;

public class SplshScreenActivity extends AppCompatActivity {
    TextView PRIVACY;
    public Button btn_start;
    CheckBox checkbox;
    private PrefManager prefManager;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.prefManager = new PrefManager(this);
        requestWindowFeature(1);
        setContentView(R.layout.activity_splsh_screen);
        init();
        loadAd();
    }

    @SuppressLint("WrongConstant")
    public void init() {
        if (prefManager.isFirstTimeLaunch()) {
            LinearLayout linearLayout = findViewById(R.id.lnt_text);
            btn_start = findViewById(R.id.btn_start);
            PRIVACY = findViewById(R.id.PRIVACY_txt);
            checkbox = findViewById(R.id.checkbox);
            btn_start.setVisibility(0);
            PRIVACY.setVisibility(0);
            checkbox.setVisibility(0);
            linearLayout.setVisibility(0);
            btn_start.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    id = 100;
                    if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                        DialogShow();
                        AdsDialogShow();
                    } else {
                        Intent intent = new Intent(SplshScreenActivity.this.getApplicationContext(), HomeActivity.class);
                        intent.setFlags(C.ENCODING_PCM_MU_LAW);
                        SplshScreenActivity.this.startActivity(intent);
                        SplshScreenActivity.this.finish();
                    }
                }
            });
            PRIVACY.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    SplshScreenActivity.this.privacy();
                }
            });
            btn_start.setBackgroundResource(R.drawable.ic_roundcorner_bgwhite);
            btn_start.setClickable(false);
            btn_start.setEnabled(false);
            checkbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        SplshScreenActivity.this.btn_start.setBackgroundResource(R.drawable.ic_roundcorner_bgorange);
                        SplshScreenActivity.this.btn_start.setClickable(true);
                        SplshScreenActivity.this.btn_start.setEnabled(true);
                        return;
                    }
                    SplshScreenActivity.this.btn_start.setBackgroundResource(R.drawable.ic_roundcorner_bgwhite);
                    SplshScreenActivity.this.btn_start.setClickable(false);
                    SplshScreenActivity.this.btn_start.setEnabled(false);
                }
            });
            btn_start.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {

                    SplshScreenActivity.this.launchHomeScreen();

                }
            });
            return;
        }
        LinearLayout linearLayout2 = findViewById(R.id.lnt_text);
        btn_start = findViewById(R.id.btn_start);
        PRIVACY = findViewById(R.id.PRIVACY_txt);
        checkbox = findViewById(R.id.checkbox);
        btn_start.setVisibility(View.GONE);
        PRIVACY.setVisibility(View.GONE);
        checkbox.setVisibility(View.GONE);
        linearLayout2.setVisibility(View.GONE);
        launchHomeScreen();
    }

    public void privacy() {
        String str = getResources().getString(R.string.privacy_policy);
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str));
            startActivity(intent);
        } catch (Exception unused) {
        }
    }

    public void launchHomeScreen() {
        prefManager.setFirstTimeLaunch(false);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                Intent intent = new Intent(SplshScreenActivity.this.getApplicationContext(), HomeActivity.class);
                intent.setFlags(C.ENCODING_PCM_MU_LAW);
                SplshScreenActivity.this.startActivity(intent);
                SplshScreenActivity.this.finish();
            }
        }, 3000);
    }

    private InterstitialAd fbinterstitialAd;
    private KProgressHUD hud;
    private int id;

    public void loadAd() {

        //FaceBookInterstitialAd
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed...");

                switch (id) {
                    case 100:
                        if (prefManager.isFirstTimeLaunch()) {
                            Intent intent = new Intent(SplshScreenActivity.this.getApplicationContext(), HomeActivity.class);
                            intent.setFlags(C.ENCODING_PCM_MU_LAW);
                            SplshScreenActivity.this.startActivity(intent);
                            SplshScreenActivity.this.finish();
                        } else {
                            launchHomeScreen();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.e("TAG", "FBInterstitial Load");
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.loadAd();
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(SplshScreenActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                fbinterstitialAd.show();
            }
        }, 1000);
    }
}
