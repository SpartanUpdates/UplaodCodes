package com.xyz.vehiclemanager.history.Fragment;

import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.history.Adapter.OwnerInfoHistoryAdapter;
import com.xyz.vehiclemanager.history.Model.OwnerHistory;
import com.xyz.vehiclemanager.history.Room.HistoryDatabase;
import com.xyz.vehiclemanager.rtoownerdetails.rtoowner.model.OwnerRoot;

import java.util.ArrayList;
import java.util.List;

public class OwnerInfoFragment extends Fragment {
    private View view;
    private RecyclerView rv_owner;
    private OwnerInfoHistoryAdapter ownerInfoHistoryAdapter;
    private HistoryDatabase historyDatabase;
    private  List<OwnerHistory> ownerHistoryList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ownerhistory, container, false);
        rv_owner = view.findViewById(R.id.rv_owner);
        setupDb();
        gettingDataFromDb();
        return view;
    }

    private void setupDb() {
        historyDatabase= Room.databaseBuilder(getActivity(),HistoryDatabase.class,"VehicleDetailsHistory").allowMainThreadQueries().build();
    }
    private void gettingDataFromDb()
    {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run()
                    {
                        ownerHistoryList = historyDatabase.ownerHistoryDao().getOwnerHistory();
                        ownerInfoHistoryAdapter = new OwnerInfoHistoryAdapter(getActivity(), ownerHistoryList);
                        rv_owner.setLayoutManager(new LinearLayoutManager(getActivity()));
                        rv_owner.setAdapter(ownerInfoHistoryAdapter);
                    }
                });
            }
        });thread.start();
    }
}
