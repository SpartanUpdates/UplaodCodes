package com.unitedvideos.Model;

public class ThemeHorizontalModel {

    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
    public boolean IsNativeAds = false;
    private String categoryid;
    private String themeid;
    private String VideoType;
    private String image;
    private String ThemeName;
    private String Animsoundurl;
    private String AnimSoundPath;
    private String AnimSoundname;
    private int AnimSoundfilesize;
    private String BundelUrl;
    private String BundelPath;
    private String BundelName;
    private String PrefebName;
    private String BundelSize;
    private int img_no_of;
    private int ImageWidht;
    private int ImageHeight;

    private String GameobjectName;
    private String ThemeCounter;
    private String isNewRealise;

    public String getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(String categoryid) {
        this.categoryid = categoryid;
    }

    public String getThemeid() {
        return themeid;
    }

    public void setThemeid(String themeid) {
        this.themeid = themeid;
    }

    public String getVideoType() {
        return VideoType;
    }

    public void setVideoType(String videoType) {
        VideoType = videoType;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public String getAnimsoundurl() {
        return Animsoundurl;
    }

    public void setAnimsoundurl(String animsoundurl) {
        Animsoundurl = animsoundurl;
    }

    public String getAnimSoundPath() {
        return AnimSoundPath;
    }

    public void setAnimSoundPath(String animSoundPath) {
        AnimSoundPath = animSoundPath;
    }

    public String getAnimSoundname() {
        return AnimSoundname;
    }

    public void setAnimSoundname(String animSoundname) {
        AnimSoundname = animSoundname;
    }

    public int getAnimSoundfilesize() {
        return AnimSoundfilesize;
    }

    public void setAnimSoundfilesize(int animSoundfilesize) {
        AnimSoundfilesize = animSoundfilesize;
    }

    public String getBundelUrl() {
        return BundelUrl;
    }

    public void setBundelUrl(String bundelUrl) {
        BundelUrl = bundelUrl;
    }

    public String getBundelPath() {
        return BundelPath;
    }

    public void setBundelPath(String bundelPath) {
        BundelPath = bundelPath;
    }

    public String getBundelName() {
        return BundelName;
    }

    public void setBundelName(String bundelName) {
        BundelName = bundelName;
    }


    public String getPrefebName() {
        return PrefebName;
    }

    public void setPrefebName(String prefebName) {
        PrefebName = prefebName;
    }

    public String getBundelSize() {
        return BundelSize;
    }

    public void setBundelSize(String bundelSize) {
        BundelSize = bundelSize;
    }

    public int getImg_no_of() {
        return img_no_of;
    }

    public void setImg_no_of(int img_no_of) {
        this.img_no_of = img_no_of;
    }

    public int getImageWidht() {
        return ImageWidht;
    }

    public void setImageWidht(int imageWidht) {
        ImageWidht = imageWidht;
    }

    public int getImageHeight() {
        return ImageHeight;
    }

    public void setImageHeight(int imageHeight) {
        ImageHeight = imageHeight;
    }

    public String getGameobjectName() {
        return GameobjectName;
    }

    public void setGameobjectName(String gameobjectName) {
        GameobjectName = gameobjectName;
    }

    public String getThemeCounter() {
        return ThemeCounter;
    }

    public void setThemeCounter(String themeCounter) {
        ThemeCounter = themeCounter;
    }

    public String getIsNewRealise() {
        return isNewRealise;
    }

    public void setIsNewRealise(String isNewRealise) {
        this.isNewRealise = isNewRealise;
    }

}
