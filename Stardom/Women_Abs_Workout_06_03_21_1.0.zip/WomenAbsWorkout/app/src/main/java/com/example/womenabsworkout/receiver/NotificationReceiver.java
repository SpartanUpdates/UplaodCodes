package com.example.womenabsworkout.receiver;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.provider.Settings.System;
import androidx.core.app.NotificationCompat.BigPictureStyle;
import androidx.core.app.NotificationCompat.Builder;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.activities.Start_Activity;

public class NotificationReceiver extends BroadcastReceiver {
    public final String CHANNEL_ID = "reminder_notification";
    public Context receiverContext;
    public String[] text;
    public String[] text1;
    public String title;
    public String title1;

    private void createNotificationChannel(Context context) {
        if (VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = null;
            if (VERSION.SDK_INT >= 26) {
                notificationChannel = new NotificationChannel("reminder_notification", "Reminder Notification", NotificationManager.IMPORTANCE_DEFAULT);
            }
            if (VERSION.SDK_INT >= 26) {
                notificationChannel.setDescription("Include all the notifications");
            }
            if (VERSION.SDK_INT >= 26) {
                ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(notificationChannel);
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        createNotificationChannel(context);
        ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(100, new Builder(context, "reminder_notification").setContentIntent(PendingIntent.getActivity(context, 100, new Intent(context, Start_Activity.class), PendingIntent.FLAG_CANCEL_CURRENT)).setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.logo_72)).setSmallIcon(R.mipmap.logo_72).setContentTitle("Hey! it's Workout time").setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}).setSound(System.DEFAULT_NOTIFICATION_URI).setContentText("Let's do Abs workout.").setStyle(new BigPictureStyle().bigPicture(BitmapFactory.decodeResource(context.getResources(), R.mipmap.noto_banner)).setBigContentTitle("Hi guys! Let's start").setSummaryText("Let's get ready to do Abs Exercise")).setAutoCancel(true).build());
    }
}
