package com.kotlinz.videostatusmaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import com.kotlinz.videostatusmaker.R;

public class ThemeAdapter extends BaseAdapter {
    private String[] strArray_image;
    LayoutInflater layoutInflater;
    private Context context;

    public ThemeAdapter(final Context context, final String[] array) {
        this.layoutInflater = null;
        this.context = context;
        this.strArray_image = array;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.strArray_image = array;
    }

    public int getCount() {
        return this.strArray_image.length;
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(int n, final View view, final ViewGroup viewGroup) {
        View inflate = view;
        if (view == null) {
            inflate = this.layoutInflater.inflate(R.layout.theme_adapter, (ViewGroup) null);
        }
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.img);
        final ImageView imageView2 = (ImageView) inflate.findViewById(R.id.thumb_bg);
        final RelativeLayout relativeLayout = (RelativeLayout) inflate.findViewById(R.id.mainlay);
        final String s = this.strArray_image[n];
        final int widthPixels = this.context.getResources().getDisplayMetrics().widthPixels;
        final int heightPixels = this.context.getResources().getDisplayMetrics().heightPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 500 / 1080, heightPixels * 500 / 1920);
        layoutParams.addRule(13);
        imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        final RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(widthPixels * 502 / 1080, heightPixels * 502 / 1920);
        layoutParams2.addRule(13);
        imageView2.setLayoutParams((ViewGroup.LayoutParams) layoutParams2);
        final RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(widthPixels / 2, heightPixels * 504 / 1920);
        if (n == this.strArray_image.length - 1) {
            n = widthPixels * 35 / 1080;
            layoutParams3.setMargins(0, n, 0, n);
        } else {
            layoutParams3.setMargins(0, widthPixels * 35 / 1080, 0, 0);
        }
        relativeLayout.setLayoutParams((ViewGroup.LayoutParams) layoutParams3);
        final DisplayImageOptions build = new DisplayImageOptions.Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("assets://theme/");
        sb.append(s);
        instance.displayImage(sb.toString(), imageView, build);
        return inflate;
    }
}
