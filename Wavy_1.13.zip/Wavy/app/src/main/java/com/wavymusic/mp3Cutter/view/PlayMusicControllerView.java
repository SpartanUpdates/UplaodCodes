package com.wavymusic.mp3Cutter.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import com.wavymusic.R;

public class PlayMusicControllerView extends View {
    private float A;
    private Drawable B;
    private boolean C;

    private boolean f6247a;
    private int f6248b;
    private float f6249c;
    private int f6250d;
    private float f6251e;
    private Drawable f;
    private a g;
    private Paint h;
    private Paint i;
    private Paint j;
    private int k;
    private int l;
    private float m;
    private float n;
    private Paint o;
    private float p;
    private float q;
    private float r;
    private float s;
    private float t;
    private float u;
    private float v;
    private int w;
    private int x;
    private long y;
    private float z;

    public interface a {
        void a(long j);

        void b(long j);

        void t();

        void u();
    }

    public PlayMusicControllerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PlayMusicControllerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.k = -1;
        this.f6250d = getResources().getColor(R.color.white);
        this.f6248b = getResources().getColor(R.color.barColor);
        this.f6249c = 2.0f;
        this.A = 16.0f;
        this.z = 25.0f;
        this.C = true;
        this.x = 10;
        this.f6249c = (float) MusicControlerContext.a(context, this.f6249c);
        this.A = (float) MusicControlerContext.a(context, this.A);
        this.z = (float) MusicControlerContext.a(context, this.z);
        this.x = MusicControlerContext.a(context, (float) this.x);
        this.f = getResources().getDrawable(R.drawable.icon_player_seekbar);
        this.B = getResources().getDrawable(R.drawable.icon_player_seekbar);
        this.o = new Paint(1);
        this.o.setColor(getResources().getColor(R.color.barColorBlack));
        this.o.setShader(new LinearGradient(0.0f, 0.0f, 30.0f, -110.0f, new int[]{getResources().getColor(R.color.app_gradiant_start), getResources().getColor(R.color.app_gradiant_end)}, (float[]) null, Shader.TileMode.MIRROR));
        this.o.setStyle(Paint.Style.STROKE);
        this.o.setStrokeWidth(this.f6249c);
        this.i = new Paint(1);
        this.h = new Paint(1);
        this.j = new Paint(1);
        this.j.setColor(-1);
        this.i.setStrokeWidth(this.f6249c);
        this.i.setStyle(Paint.Style.STROKE);
        this.h.setStyle(Paint.Style.STROKE);
        this.h.setStrokeWidth(this.f6249c);
        float f2 = this.z;
        this.m = f2 / 1.07374182E9f;
        this.t = this.m + (f2 / 1.07374182E9f);
    }

    private void a(Canvas canvas) {
        float f2 = this.z;
        int i2 = this.l;
        canvas.drawLine(f2 / 2.0f, (float) (i2 / 2), ((float) this.w) - (f2 / 2.0f), (float) (i2 / 2), this.i);
    }

    private boolean a(MotionEvent motionEvent) {
        if (!this.C) {
            float f2 = this.m;
            float f3 = this.z;
            float f4 = this.n;
            if (new RectF(f2 - f3, f4 - f3, f2 + f3, f4 + f3).contains(motionEvent.getX(), motionEvent.getY())) {
                return true;
            }
        }
        return false;
    }

    private void b(Canvas canvas) {
        canvas.drawLine(this.m, this.n, this.t, this.u, this.h);
    }

    private boolean b(MotionEvent motionEvent) {
        if (!this.C) {
            float f2 = this.t;
            float f3 = this.z;
            float f4 = this.u;
            if (new RectF(f2 - f3, f4 - f3, f2 + f3, f4 + f3).contains(motionEvent.getX(), motionEvent.getY())) {
                return true;
            }
        }
        return false;
    }

    private void c(Canvas canvas) {
        this.q = this.p;
        canvas.drawLine(this.m, this.n, this.q, this.r, this.o);
    }

    private void d(Canvas canvas) {
        Drawable drawable = this.f;
        if (drawable != null) {
            float f2 = this.m;
            float f3 = this.z;
            float f4 = this.n;
            drawable.setBounds((int) (f2 - (f3 / 4.0f)), (int) (f4 - (f3 / 2.0f)), (int) (f2 + (f3 / 4.0f)), (int) (f4 + (f3 / 2.0f)));
            this.f.draw(canvas);
        }
    }

    private void e(Canvas canvas) {
        Drawable drawable = this.B;
        if (drawable != null) {
            float f2 = this.t;
            float f3 = this.z;
            float f4 = this.u;
            drawable.setBounds((int) (f2 - (f3 / 4.0f)), (int) (f4 - (f3 / 2.0f)), (int) (f2 + (f3 / 4.0f)), (int) (f4 + (f3 / 2.0f)));
            this.B.draw(canvas);
        }
    }

    public void a() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            invalidate();
        } else {
            postInvalidate();
        }
    }

    public void a(long j2, long j3) {
        float f2;
        this.y = j2;
        Log.e("TAG", "j : " + j2 + "j2 : " + j3);
        this.C = false;
        this.m = this.z / 2.0f;
        this.p = this.m;
        if (j3 >= this.y) {
            f2 = this.f6251e;
        } else {
            float f3 = 0.0f;
            if (j2 != 0) {
                f3 = ((float) j3) / ((float) j2);
            }
            f2 = this.f6251e * f3;
        }
        this.v = f2;
        this.t = this.m + this.v;
        a aVar = this.g;
        if (aVar != null) {
            aVar.b(0);
            this.g.a((long) (((this.t - (this.z / 2.0f)) / this.f6251e) * ((float) j2)));
        }
        a();
    }

    public int getBarColor() {
        return this.f6248b;
    }

    public float getBarHeight() {
        return this.f6249c;
    }

    public int getBgBarColor() {
        return this.f6250d;
    }

    public void onDraw(Canvas canvas) {
        this.i.setColor(getResources().getColor(R.color.white));
        this.h.setShader(new LinearGradient(0.0f, 0.0f, 30.0f, -110.0f, new int[]{getResources().getColor(R.color.barColorBlack), getResources().getColor(R.color.barColorBlack)}, (float[]) null, Shader.TileMode.MIRROR));
        a(canvas);
        b(canvas);
        c(canvas);
        if (this.C) {
            return;
        }
        if (this.f6247a) {
            d(canvas);
            e(canvas);
            return;
        }
        e(canvas);
        d(canvas);
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.w = (View.MeasureSpec.getSize(i2) - getPaddingLeft()) - getPaddingRight();
        this.l = (View.MeasureSpec.getSize(i3) - getPaddingTop()) - getPaddingBottom();
        this.f6251e = ((float) this.w) - this.z;
        this.n = (float) (this.l / 2);
        float f2 = this.n;
        this.u = f2;
        this.s = f2;
        this.r = f2;
    }

    public boolean onTouchEvent(final MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            default: {
                return false;
            }
            case 2: {
                final int k = this.k;
                if (k == 1) {
                    final float x = motionEvent.getX();
                    final float z = this.z;
                    Label_0174: {
                        float m;
                        if (x <= z / 2.0f) {
                            m = z / 2.0f;
                        }
                        else {
                            if (this.t - motionEvent.getX() >= this.v && motionEvent.getX() >= this.z / 2.0f) {
                                this.m = motionEvent.getX();
                                this.t = this.m + this.v;
                                break Label_0174;
                            }
                            final float x2 = motionEvent.getX();
                            final float t = this.t;
                            final int x3 = this.x;
                            if (x2 < t - x3) {
                                this.m = motionEvent.getX();
                                break Label_0174;
                            }
                            m = t - x3;
                        }
                        this.m = m;
                    }
                    final float i = this.m;
                    this.p = i;
                    final a g = this.g;
                    if (g != null) {
                        g.b((long)((i - this.z / 2.0f) / this.f6251e * this.y));
                        this.g.a((long)((this.t - this.z / 2.0f) / this.f6251e * this.y));
                    }
                    this.a();
                    return true;
                }
                if (k == 2) {
                    final float x4 = motionEvent.getX();
                    final float j = this.m;
                    final int x5 = this.x;
                    if (x4 <= x5 + j) {
                        this.t = j + x5;
                        this.f6247a = true;
                    }
                    else {
                        final float x6 = motionEvent.getX();
                        final float e = this.f6251e;
                        final float z2 = this.z;
                        if (x6 >= z2 / 2.0f + e) {
                            this.t = e + z2 / 2.0f;
                        }
                        else if (motionEvent.getX() - this.m >= this.v && motionEvent.getX() <= this.f6251e + this.z / 2.0f) {
                            this.t = motionEvent.getX();
                            this.m = this.t - this.v;
                        }
                        else {
                            this.t = motionEvent.getX();
                        }
                        f6247a = false;
                    }
                    final float l = this.m;
                    this.p = l;
                    final a g2 = this.g;
                    if (g2 != null) {
                        g2.b((long)((l - this.z / 2.0f) / this.f6251e * this.y));
                        this.g.a((long)((this.t - this.z / 2.0f) / this.f6251e * this.y));
                    }
                    this.a();
                }
                return true;
            }
            case 1: {
                final int k2 = this.k;
                if (k2 == 1 || k2 == 2) {
                    final a g3 = this.g;
                    if (g3 != null) {
                        g3.t();
                    }
                }
                this.a();
                return false;
            }
            case 0: {
                if (this.a(motionEvent)) {
                    if (!this.f6247a) {
                        this.k = 1;
                    }
                    final a g4 = this.g;
                    if (g4 != null) {
                        g4.u();
                    }
                    return true;
                }
                if (this.b(motionEvent)) {
                    this.p = this.m;
                    this.k = 2;
                    final a g5 = this.g;
                    if (g5 != null) {
                        g5.u();
                    }
                    return true;
                }
                return false;
            }
        }
    }


    public void setBarColor(int i2) {
        this.f6248b = i2;
    }

    public void setBarHeight(float f2) {
        this.f6249c = f2;
    }

    public void setBgBarColor(int i2) {
        this.f6250d = i2;
    }

    public void setOnMusicPlayControllerListener(a aVar) {
        this.g = aVar;
    }

    public void setPlayProgress(int i2) {
        this.p = ((((float) i2) / ((float) this.y)) * this.f6251e) + (this.z / 2.0f);
        a();
    }
}