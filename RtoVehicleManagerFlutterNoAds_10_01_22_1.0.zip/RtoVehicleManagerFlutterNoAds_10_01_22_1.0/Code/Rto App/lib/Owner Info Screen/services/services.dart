import 'package:flutter/cupertino.dart';
import 'package:rto_app/Fuel%20Screen/model/fuel_response_model.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import '../model/owner_info_model.dart';
import 'package:http/http.dart' as http;

class ApiCall {
  Future<OwnerInfoModel> getRequest(BuildContext context, number) async {
    http.Response response;
    try {
      response = await http.post(
          Uri.parse("https://api.apiclub.in/api/v1/vehicle_info"),
          headers: {
            "Referer":
                "https://play.google.com/store/apps/details?id=com.info.vehicle",
            "API-KEY": "2cea27c0986adc4cb8e644219035262d",
            "Content-Type": "application/x-www-form-urlencoded"
          },
          body: {
            "vehicleId": "${number}"
          });
    } on Exception catch (e) {
      throw e;
    }
    final result = ownerInfoModelFromJson(response.body);
    return result;
  }

  Future<FuelResponseModel> getFuelData(BuildContext context, city) async {
    http.Response response;
    try {
      response = await http
          .post(Uri.parse("https://api.apiclub.in/api/v1/fuel_info"), headers: {
        "Referer":
            "https://play.google.com/store/apps/details?id=com.info.vehicle",
        "API-KEY": "2cea27c0986adc4cb8e644219035262d",
        "Content-Type": "application/x-www-form-urlencoded"
      }, body: {
        "citystate": "${city}"
      });
    } on Exception catch (e) {
      print("result : ${e}");
      throw e;
    }
    if (response.statusCode == 400) {
      CommanDialog.showNoInternetDialog(
          context, "Please check your internet connection !");
    }
    final result = FuelResponseModelFromJson(response.body);
    return result;
  }
}
