package com.kotlinz.videoCollage.crop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class CropAdapter extends Adapter<CropAdapter.CropAdapterViewHolder> {
    Context context;
    ArrayList<String> list;
    int pos = 1;

    public static class CropAdapterViewHolder extends ViewHolder {
        Button button;

        public CropAdapterViewHolder(View view) {
            super(view);
            this.button = (Button) view.findViewById(R.id.button);
        }
    }

    public CropAdapter(Context context, ArrayList<String> arrayList) {
        this.context = context;
        this.list = arrayList;
    }

    public CropAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new CropAdapterViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_crop_list, viewGroup, false));
    }

    public void onBindViewHolder(CropAdapterViewHolder cropAdapterViewHolder, final int i) {
        cropAdapterViewHolder.button.setText((CharSequence) this.list.get(i));
        cropAdapterViewHolder.button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CropAdapter.this.pos = i;
                CropAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            cropAdapterViewHolder.button.setBackgroundResource(R.drawable.crop_button_bg_press);
        } else {
            cropAdapterViewHolder.button.setBackgroundResource(R.drawable.crop_button_bg_unpress);
        }
    }

    public int getItemCount() {
        return this.list.size();
    }
}
