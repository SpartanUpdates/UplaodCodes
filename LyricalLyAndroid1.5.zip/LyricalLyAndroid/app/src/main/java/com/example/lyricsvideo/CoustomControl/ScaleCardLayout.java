package com.example.lyricsvideo.CoustomControl;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.CardView;
import android.util.AttributeSet;
import com.example.lyricsvideo.R;


public class ScaleCardLayout
        extends CardView {
    public int mAspectRatioWidth = 640;
    public int mAspectRatioHeight = 360;

    public ScaleCardLayout(Context context) {
        super(context);
    }

    public ScaleCardLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        Init(context, attrs);
    }

    public ScaleCardLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        Init(context, attrs);
    }

    private void Init(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ScaleCardLayout);

        mAspectRatioWidth = a.getInt(
                R.styleable.ScaleCardLayout_aspectRatioWidth, 480);
        mAspectRatioHeight = a.getInt(
                R.styleable.ScaleCardLayout_aspectRatioHeight, 720);
        a.recycle();
    }

    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        if (this.mAspectRatioHeight == this.mAspectRatioWidth) {
            super.onMeasure(widthMeasureSpec, widthMeasureSpec);
        }
        final int originalWidth = MeasureSpec.getSize(widthMeasureSpec);
        final int originalHeight = MeasureSpec.getSize(heightMeasureSpec);
        final int calculatedHeight = originalWidth * this.mAspectRatioHeight / this.mAspectRatioWidth;
        int finalWidth;
        int finalHeight;
        if (calculatedHeight > originalHeight) {
            finalWidth = originalHeight * this.mAspectRatioWidth / this.mAspectRatioHeight;
            finalHeight = originalHeight;
        } else {
            finalWidth = originalWidth;
            finalHeight = calculatedHeight;
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(finalWidth, 1073741824), MeasureSpec.makeMeasureSpec(finalHeight, 1073741824));
    }
}
