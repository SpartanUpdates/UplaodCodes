package com.kotlinz.videoCollage.other;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.util.Log;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;

public class Util {
    public static boolean bgColorSelected = false;
    public static boolean bgImageSelected = false;
    public static int selectedTab;
    public static int selectedVid;

    public static Bitmap scaleBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Width and height are ");
        stringBuilder.append(width);
        String str = "--";
        stringBuilder.append(str);
        stringBuilder.append(height);
        String str2 = "play";
        Log.e(str2, stringBuilder.toString());
        int i = 50;
        if (width > height) {
            width = (int) (((float) height) / (((float) width) / 50.0f));
        } else {
            if (height > width) {
                i = (int) (((float) width) / (((float) height) / 50.0f));
            }
            width = 50;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("after scaling Width and height are ");
        stringBuilder2.append(i);
        stringBuilder2.append(str);
        stringBuilder2.append(width);
        Log.e(str2, stringBuilder2.toString());
        return Bitmap.createScaledBitmap(bitmap, i, width, true);
    }

    public static Bitmap rotateBitmapSam(Bitmap bitmap, String str) {
        ExifInterface exifInterface;
        try {
            exifInterface = new ExifInterface(str);
        } catch (IOException e) {
            e.printStackTrace();
            exifInterface = null;
        }
        int attributeInt = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
        if (attributeInt == 3) {
            return rotateImage(bitmap, 180.0f);
        }
        if (attributeInt == 6) {
            return rotateImage(bitmap, 90.0f);
        }
        if (attributeInt != 8) {
            return bitmap;
        }
        return rotateImage(bitmap, 270.0f);
    }

    public static Bitmap rotateImage(Bitmap bitmap, float f) {
        Matrix matrix = new Matrix();
        matrix.postRotate(f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static void deleteTempDir(File file) {
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
            file.delete();
        }
    }

    public static void deleteCache(Context context) {
        try {
            deleteDir(context.getCacheDir());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteDir(File file) {
        if (file != null && file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                if (!deleteDir(new File(file, file2))) {
                    return false;
                }
            }
            return file.delete();
        } else if (file == null || !file.isFile()) {
            return false;
        } else {
            return file.delete();
        }
    }

    public static boolean isImageFile(String str) {
        str = URLConnection.guessContentTypeFromName(str);
        return str != null && str.startsWith("image");
    }

    public static boolean isVideoFile(String str) {
        str = URLConnection.guessContentTypeFromName(str);
        return str != null && str.startsWith("video");
    }

    public static int dpToPx(Context context, int i) {
        float f = (float) i;
        context.getResources();
        return (int) (f * Resources.getSystem().getDisplayMetrics().density);
    }



    public static Bitmap resize(Bitmap bitmap, String str) {
        if (bitmap.getWidth() > 4096 && bitmap.getHeight() > 4096) {
            return ImageCompress.getInstant().getCompressedBitmap(str, 4096.0f, 4096.0f);
        }
        if (bitmap.getWidth() > 4096) {
            return ImageCompress.getInstant().getCompressedBitmap(str, 4096.0f, (float) bitmap.getHeight());
        }
        return bitmap.getHeight() > 4096 ? ImageCompress.getInstant().getCompressedBitmap(str, (float) bitmap.getWidth(), 4096.0f) : bitmap;
    }
}
