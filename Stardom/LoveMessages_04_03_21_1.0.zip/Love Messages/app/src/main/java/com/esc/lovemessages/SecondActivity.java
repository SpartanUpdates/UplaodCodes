package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Typeface;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;

import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SecondActivity extends AppCompatActivity implements OnClickListener {
    Activity activity = SecondActivity.this;
    public static boolean isTextSelected = false;
    Button btnProcessing;
    FrameLayout canvas1;
    String[] color = new String[]{"#601919", "#FF2875", "#513A07", "#FE7A04", "#FEDE02", "#FF76B0", "#FF6E02", "#AC0919"};
    Dialog dialogR;
    float[] eX = new float[]{1.45f, 1.25f, 1.15f, 1.1f, 1.1f, 1.06f, 1.35f, 1.25f};
    float[] eY = new float[]{2.0f, 1.8f, 1.6f, 2.1f, 1.5f, 1.8f, 1.2f, 1.8f};
    EditText editTextCaption;
    public Editor editor;
    public Editor editorAds;
    private FloatingActionButton fab;
    private FloatingActionButton fab1;
    private FloatingActionButton fab2;
    private Animation fab_close;
    private Animation fab_open;
    String[] fonts;
    int id;
    String imageName;
    ImageView imageView;
    int index;
    private Boolean isFabOpen;
    Uri link;
    ReviewManager manager;
    DisplayMetrics metrics;
    private ProgressDialog progress;
    ReviewInfo reviewInfo;
    RelativeLayout rootView;
    private Animation rotate_backward;
    private Animation rotate_forward;
    String s;
    float[] sX = new float[]{5.5f, 4.2f, 15.5f, 9.0f, 9.9f, 13.0f, 27.0f, 4.0f};
    float[] sY = new float[]{2.6f, 2.3f, 2.3f, 3.1f, 2.2f, 2.5f, 1.6f, 2.4f};
    public int sh;
    public SharedPreferences sharedPreferences;
    public SharedPreferences sharedPreferencesAds;
    String str;
    public int sw;
    int[] textSize = new int[]{15, 12, 8, 9, 6, 7, 6, 9};
    StickerTextView tv_sticker;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private class SaveImageTask extends AsyncTask<String, Void, Void> {
        boolean result;

        private SaveImageTask() {
            this.result = false;
        }

        SaveImageTask(SecondActivity secondActivity) {
            this();
        }


        public void onPreExecute() {
            SecondActivity secondActivity = SecondActivity.this;
            secondActivity.progress = new ProgressDialog(secondActivity);
            SecondActivity.this.progress.setMessage("Please Wait");
            SecondActivity.this.progress.setProgressStyle(0);
            SecondActivity.this.progress.setIndeterminate(true);
            SecondActivity.this.progress.setCancelable(false);
            SecondActivity.this.progress.setProgress(0);
            SecondActivity.this.progress.show();
        }


        public Void doInBackground(String... strArr) {
            Log.e("wallpaper1", "doInBackground");
            this.result = SecondActivity.this.saveImage();
            return null;
        }


        public void onPostExecute(Void voidR) {
            try {
                SecondActivity.this.progress.cancel();
                if (this.result) {
                    Toast.makeText(SecondActivity.this, "Image saved successfully", Toast.LENGTH_SHORT).show();
                }
                if (!this.result) {
                    Toast.makeText(SecondActivity.this.getApplicationContext(), "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                }
                SecondActivity.this.checkAndRequestPermissions();
            } catch (Exception unused) {
            }
        }
    }

    private class ShareImageTask extends AsyncTask<String, Void, Void> {
        boolean result;

        private ShareImageTask() {
            this.result = false;
        }

        ShareImageTask(SecondActivity secondActivity) {
            this();
        }


        public void onPreExecute() {
            SecondActivity secondActivity = SecondActivity.this;
            secondActivity.progress = new ProgressDialog(secondActivity);
            SecondActivity.this.progress.setMessage("Please Wait");
            SecondActivity.this.progress.setProgressStyle(0);
            SecondActivity.this.progress.setIndeterminate(true);
            SecondActivity.this.progress.setCancelable(false);
            SecondActivity.this.progress.setProgress(0);
            SecondActivity.this.progress.show();
        }


        public Void doInBackground(String... strArr) {
            this.result = SecondActivity.this.saveImage();
            return null;
        }


        public void onPostExecute(Void voidR) {
            try {
                SecondActivity.this.progress.cancel();
                if (this.result) {
                    SecondActivity.this.Share();
                    return;
                }
                Toast.makeText(SecondActivity.this.getApplicationContext(), "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                SecondActivity.this.checkAndRequestPermissions();
            } catch (Exception unused) {
            }
        }
    }

    public SecondActivity() {
        String[] strings = new String[8];
        String str = "Cookie-Regular.ttf";
        strings[6] = str;
        strings[7] = str;
        this.fonts = strings;
        this.isFabOpen = Boolean.valueOf(false);
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_second);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        CharSequence charSequence = "";
        getSupportActionBar().setTitle(charSequence);
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText("Name On Birthday Cake");
        textView.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf"));
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        String str = "MYPREFERENCE";
        this.sharedPreferences = getSharedPreferences(str, 0);
        this.sharedPreferencesAds = getSharedPreferences(str, 0);
        this.editorAds = this.sharedPreferencesAds.edit();
        this.editor = this.sharedPreferences.edit();
        String str2 = "inappreview";
        this.editorAds.putInt(str2, this.sharedPreferences.getInt(str2, 0) + 1).apply();
        if (this.sharedPreferences.getInt(str2, 0) > 6 || this.sharedPreferences.getInt(str2, 0) == 1) {
            RateAndReview1(getApplicationContext());
        }
        this.rootView = findViewById(R.id.addresses_confirm_root_view);
        this.imageView = findViewById(R.id.imageView);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("cake");
        str2 = "image";
        stringBuilder.append(getIntent().getStringExtra(str2));
        this.s = stringBuilder.toString();
        this.id = getResources().getIdentifier(this.s, "drawable", getPackageName());
        this.imageView.setImageResource(this.id);
        this.canvas1 = findViewById(R.id.canvasView1);
        this.editTextCaption = findViewById(R.id.caption);
        this.btnProcessing = findViewById(R.id.processing);
        this.btnProcessing.setTypeface(NameCakeActivity.typeface);
        this.tv_sticker = new StickerTextView(this);
        this.tv_sticker.setControlItemsHidden(true);
        isTextSelected = false;
        this.index = Integer.parseInt(getIntent().getStringExtra(str2)) - 1;
        setEditTextMaxLength(this.editTextCaption, 11);
        LayoutParams layoutParams = (LayoutParams) this.editTextCaption.getLayoutParams();
        layoutParams.setMargins(0, 0, 0, 0);
        this.editTextCaption.setLayoutParams(layoutParams);
        this.metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.metrics);
        this.sw = this.metrics.widthPixels;
        this.sh = this.metrics.heightPixels;
        ViewGroup.LayoutParams layoutParams2;
        double d;
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            layoutParams2 = this.imageView.getLayoutParams();
            double d2 = this.sw;
            Double.isNaN(d2);
            layoutParams2.height = (int) (d2 * 0.8d);
            layoutParams2 = this.imageView.getLayoutParams();
            d2 = this.sw;
            Double.isNaN(d2);
            layoutParams2.width = (int) (d2 * 0.8d);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            layoutParams2 = this.imageView.getLayoutParams();
            d = this.sw;
            Double.isNaN(d);
            layoutParams2.height = (int) (d * 0.9d);
            layoutParams2 = this.imageView.getLayoutParams();
            d = this.sw;
            Double.isNaN(d);
            layoutParams2.width = (int) (d * 0.9d);
        } else {
            layoutParams2 = this.imageView.getLayoutParams();
            d = this.sw;
            Double.isNaN(d);
            layoutParams2.height = (int) (d * 0.9d);
            layoutParams2 = this.imageView.getLayoutParams();
            d = this.sw;
            Double.isNaN(d);
            layoutParams2.width = (int) (d * 0.9d);
        }
        this.tv_sticker.setTextLines();
        stringBuilder = new StringBuilder();
        stringBuilder.append(System.currentTimeMillis());
        stringBuilder.append(charSequence);
        this.imageName = stringBuilder.toString();
        this.fab = findViewById(R.id.fab);
        this.fab1 = findViewById(R.id.fab1);
        this.fab2 = findViewById(R.id.fab2);
        this.fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        this.fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);
        this.rotate_forward = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_forward);
        this.rotate_backward = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_backward);
        this.fab.setOnClickListener(this);
        this.fab1.setOnClickListener(this);
        this.fab2.setOnClickListener(this);
        this.btnProcessing.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.setText();
            }
        });
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setText() {
        StickerTextView stickerTextView = this.tv_sticker;
        if (stickerTextView != null) {
            stickerTextView.removeTextView();
        }
        this.tv_sticker = new StickerTextView(this);
        String obj = this.editTextCaption.getText().toString();
        String str = "";
        obj.split(str);
        this.str = obj;
        isTextSelected = !obj.replace(" ", str).isEmpty();
        if (this.index == 2) {
            this.tv_sticker.setRotation(13.0f);
        }
        if (this.index == 4) {
            this.tv_sticker.setRotation(352.0f);
        }
        this.tv_sticker.setTextLines();
        if (this.tv_sticker.getParent() != null) {
            ((ViewGroup) this.tv_sticker.getParent()).removeView(this.tv_sticker);
        }
        this.canvas1.addView(this.tv_sticker);
        this.tv_sticker.setControlItemsHidden(true);
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(this.tv_sticker.getWindowToken(), 0);
        this.tv_sticker.setColor(this.color[this.index]);
        float height = (float) (this.imageView.getHeight() / this.textSize[this.index]);
        this.tv_sticker.reCenter(((float) this.imageView.getWidth()) / this.sX[this.index], ((float) this.imageView.getWidth()) / this.eX[this.index], ((float) this.imageView.getHeight()) / this.sY[this.index], ((float) this.imageView.getHeight()) / this.eY[this.index]);
        this.tv_sticker.setTextSize((int) height);
        this.tv_sticker.setText(obj);
    }

    public void setEditTextMaxLength(EditText editText, int i) {
        editText.setFilters(new InputFilter[]{new LengthFilter(i)});
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 111 && iArr.length > 0) {
            i = iArr[0];
        }
    }

    public void onClick(View view) {
        if (isTextSelected) {
            switch (view.getId()) {
                case R.id.fab:
                    animateFAB();
                    return;
                case R.id.fab1:
                    new ShareImageTask(this).execute();
                    AddRateClicks();
                    return;
                case R.id.fab2:
                    new SaveImageTask(this).execute();
                    AddRateClicks();
                    return;
                default:
                    return;
            }
        }
        Toast.makeText(this, "Please Enter Name", Toast.LENGTH_SHORT).show();
    }

    public void animateFAB() {
        String str = "Raj";
        if (this.isFabOpen.booleanValue()) {
            isTextSelected = !this.str.replace(" ", "").isEmpty();
            this.fab.startAnimation(this.rotate_backward);
            this.fab1.startAnimation(this.fab_close);
            this.fab2.startAnimation(this.fab_close);
            this.fab1.setClickable(false);
            this.fab2.setClickable(false);
            this.isFabOpen = Boolean.valueOf(false);
            return;
        }
        this.fab.startAnimation(this.rotate_forward);
        this.fab1.startAnimation(this.fab_open);
        this.fab2.startAnimation(this.fab_open);
        this.fab1.setClickable(true);
        this.fab2.setClickable(true);
        this.isFabOpen = Boolean.valueOf(true);
    }

    public boolean saveImage() {
        Boolean valueOf = Boolean.valueOf(true);
        try {
            saveImage(getBitmap());
        } catch (Exception unused) {
            valueOf = Boolean.valueOf(false);
        }
        return valueOf.booleanValue();
    }

    private void saveImage(Bitmap bitmap) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Toast.makeText(getApplicationContext(), "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
            checkAndRequestPermissions();
            return;
        }
        File file = new File(Environment.getExternalStorageDirectory(), "Birthday Cake");
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.imageName);
        stringBuilder.append(".jpg");
        File file2 = new File(file, stringBuilder.toString());
        this.link = FileProvider.getUriForFile(this, activity.getPackageName() + ".provider", file2);
        file2.getAbsolutePath();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            MediaScannerConnection.scanFile(getApplicationContext(), new String[]{file2.toString()}, null, new OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            Toast.makeText(this, "Image is saved in your gallery", Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException unused) {
            Toast.makeText(getApplicationContext(), "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
          e.printStackTrace();
        }
    }

    public void Share() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Toast.makeText(getApplicationContext(), "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
            checkAndRequestPermissions();
            return;
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.SUBJECT", "Love Messages for Wife - Birthday Cake");
        intent.putExtra("android.intent.extra.STREAM", this.link);
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(getApplicationContext().getResources().getString(R.string.sharemsg));
        stringBuilder2.append("<br>");
        stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
        stringBuilder.append("https://play.google.com/store/apps/details?id=" + getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(this.link);
        stringBuilder.append("");
        startActivity(Intent.createChooser(intent, "Share via..."));
    }

    private boolean checkAndRequestPermissions() {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        int checkSelfPermission = ContextCompat.checkSelfPermission(getApplicationContext(), str);
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission != 0) {
            arrayList.add(str);
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
        return false;
    }

    public Bitmap getBitmap() {
        this.canvas1.setDrawingCacheEnabled(false);
        this.canvas1.buildDrawingCache();
        return trim(this.canvas1.getDrawingCache());
    }

    static Bitmap trim(Bitmap bitmap) {
        int i;
        int i2;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] iArr = new int[(bitmap.getWidth() * bitmap.getHeight())];
        bitmap.getPixels(iArr, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        int i3 = 0;
        int i4 = 0;
        loop0:
        while (i4 < bitmap.getWidth()) {
            for (i = 0; i < bitmap.getHeight(); i++) {
                if (iArr[(bitmap.getWidth() * i) + i4] != 0) {
                    break loop0;
                }
            }
            i4++;
        }
        i4 = 0;
        loop2:
        for (i = 0; i < bitmap.getHeight(); i++) {
            for (i2 = i4; i2 < bitmap.getHeight(); i2++) {
                if (iArr[(bitmap.getWidth() * i) + i2] != 0) {
                    i3 = i;
                    break loop2;
                }
            }
        }
        loop4:
        for (i = bitmap.getWidth() - 1; i >= i4; i--) {
            for (i2 = bitmap.getHeight() - 1; i2 >= i3; i2--) {
                if (iArr[(bitmap.getWidth() * i2) + i] != 0) {
                    width = i;
                    break loop4;
                }
            }
        }
        loop6:
        for (i = bitmap.getHeight() - 1; i >= i3; i--) {
            for (i2 = bitmap.getWidth() - 1; i2 >= i4; i2--) {
                if (iArr[(bitmap.getWidth() * i) + i2] != 0) {
                    height = i;
                    break loop6;
                }
            }
        }
        return Bitmap.createBitmap(bitmap, i4, i3, width - i4, height - i3);
    }


    public void RateAndReview1(Context context) {
        this.manager = ReviewManagerFactory.create(context);
        this.manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            public void onComplete(Task<ReviewInfo> task) {
                String str = "inapp reivew";
                if (task.isSuccessful()) {
                    SecondActivity.this.reviewInfo = task.getResult();
                    return;
                }
            }
        });
    }

    public void RateAndReview() {
        String str = "inapp reivew";
        String str2 = "inappreview";
        if (this.sharedPreferences.getInt(str2, 0) > 6) {
            this.editorAds.putInt(str2, 1).apply();
        }
        try {
            if (this.manager != null) {
                if (this.reviewInfo != null) {
                    this.manager.launchReviewFlow(this, this.reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(Task<Void> task) {
                            Log.e("inapp reivew", "In-app REVIEW SUCCESSFUL");
                            SecondActivity.this.finish();
                        }
                    });
                    return;
                }
            }
            RATE_DIALOG();
        } catch (Exception unused) {
            RATE_DIALOG();
        }
    }

    public void onBackPressed() {
        String str = "inappreview";
        if (this.sharedPreferences.getInt(str, 0) > 6 || this.sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview();
            return;
        }
        str = "rateagain";
        if (this.sharedPreferences.getInt(str, 0) > 12 || this.sharedPreferences.getInt("applaunched", 0) == 0) {
            this.editorAds.putInt(str, 0);
            this.editorAds.commit();
            RATE_DIALOG();
            return;
        }
        super.onBackPressed();
    }


    public void AddRateClicks() {
        String str = "rateagain";
        if (this.sharedPreferences.getInt(str, 0) < 13) {
            int i = this.sharedPreferences.getInt(str, 0) + 1;
            this.editorAds.putInt(str, i);
            this.editorAds.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        Button button = this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                SecondActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                SecondActivity.this.finish();
                SecondActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                SecondActivity.this.finish();
                SecondActivity.this.dialogR.cancel();
            }
        });
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
