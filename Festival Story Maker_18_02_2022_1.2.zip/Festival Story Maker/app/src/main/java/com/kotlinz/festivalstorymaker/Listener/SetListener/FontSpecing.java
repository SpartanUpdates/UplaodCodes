package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.widget.SeekBar;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;

public class FontSpecing implements SeekBar.OnSeekBarChangeListener {
    public final  QuoteMakerDetailActivity activity;

    public FontSpecing(QuoteMakerDetailActivity quoteMakerDetailActivity) {
        this.activity = quoteMakerDetailActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (z) {
            this.activity.stickerViewNew1.setLineSpacing((float) i);
            this.activity.stickerViewNew1.requestLayout();

            com.kotlinz.festivalstorymaker.Models.z.c cVar = (com.kotlinz.festivalstorymaker.Models.z.c) activity.U.get(((Integer) activity.stickerViewNew1.getTag()).intValue());
            cVar.b = i + 5;
            QuoteMakerDetailActivity quoteMakerDetailActivity2 = this.activity;
            quoteMakerDetailActivity2.U.set(((Integer) quoteMakerDetailActivity2.stickerViewNew1.getTag()).intValue(), cVar);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
