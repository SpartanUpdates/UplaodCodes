package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Thobda3 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"♕", "␈", "𐂃", "𐂂", "𓀬", "𓆈", "𓃗", "𓃱", "𓀡", "𓀿", "𓅷", "𓆏", "𓃰", "𓄁", "𓃠", "𓅿", "𓃟", "𓂻", "♔", "𓆙", "𓃒", "𐂊", "𓂉", "⚣", "ଈ", "𖠌"};
    }

    public String getName() {
        return "♕␈𐂃";
    }

    public float getSizeFactorKeys() {
        return 0.95f;
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"♕", "␈", "𐂃", "𐂂", "𓀬", "𓆈", "𓃗", "𓃱", "𓀡", "𓀿", "𓅷", "𓆏", "𓃰", "𓄁", "𓃠", "𓅿", "𓃟", "𓂻", "♔", "𓆙", "𓃒", "𐂊", "𓂉", "⚣", "ଈ", "𖠌"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
