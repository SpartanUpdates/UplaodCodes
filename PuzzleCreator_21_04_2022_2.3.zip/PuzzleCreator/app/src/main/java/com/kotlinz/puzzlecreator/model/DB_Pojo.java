package com.kotlinz.puzzlecreator.model;

public class DB_Pojo {
    private String id;
    private String points;
    private String puzzleId;
    private String viewby;
    private String solveby;
    private String isnew;

    public DB_Pojo() {
    }

    public DB_Pojo( String puzzleId) {
                this.puzzleId = puzzleId;
    }

    public DB_Pojo(String puzzleId, String viewby, String solveby, String isnew) {
        this.puzzleId = puzzleId;
        this.viewby = viewby;
        this.solveby = solveby;
        this.isnew = isnew;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public String getPuzzleId() {
        return puzzleId;
    }

    public void setPuzzleId(String puzzleId) {
        this.puzzleId = puzzleId;
    }

    public String getViewby() {
        return viewby;
    }

    public void setViewby(String viewby) {
        this.viewby = viewby;
    }

    public String getSolveby() {
        return solveby;
    }

    public void setSolveby(String solveby) {
        this.solveby = solveby;
    }

    public String getIsnew() {
        return isnew;
    }

    public void setIsnew(String isnew) {
        this.isnew = isnew;
    }
}
