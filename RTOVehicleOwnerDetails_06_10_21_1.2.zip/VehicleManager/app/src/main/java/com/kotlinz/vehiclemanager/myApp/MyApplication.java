package com.kotlinz.vehiclemanager.myApp;

import android.app.Application;
import android.content.Context;
import android.util.Base64;

import com.facebook.ads.AudienceNetworkAds;
import com.greedygame.core.AppConfig;
import com.greedygame.core.GreedyGameAds;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.utils.Utils;

public class MyApplication extends Application {

    private static MyApplication mInstance;
    private static Context context;
    public static String id;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        id = (new String(Base64.decode(Utils.id + Utils.id2, Base64.DEFAULT)));
        AppConfig appConfig = new AppConfig.Builder(context)
                .withAppId(getResources().getString(R.string.gg_app_id))
                .enableFacebookAds(true)//Replace the app ID with your app's ID
                .build();
        GreedyGameAds.initWith(appConfig, null);
        AudienceNetworkAds.initialize(this);
    }

    public static Context getContext() {
        return context;
    }

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }
}
