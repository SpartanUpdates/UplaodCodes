package com.unitedvideos.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.Preferences.LanguagePref;
import com.unitedvideos.R;

import androidx.appcompat.app.AppCompatActivity;

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = SettingActivity.this;
    LinearLayout llFeedback;
    LinearLayout llRateUs;
    LinearLayout llShareApp;
    LinearLayout llExportVideoQuality;
    LinearLayout llMyLyrics;
    LinearLayout llPrivacypolicy;
    TextView tvSelectVideoQuality;
    TextView tvVersionCode;
    ImageView ivback;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        BindView();
        BannerAds();
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SettingActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        try {
            String str = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            StringBuilder stringBuilder = new StringBuilder("Version ");
            stringBuilder.append(str);
            stringBuilder.append("  ");
            tvVersionCode.setText(stringBuilder.toString());
        } catch (PackageManager.NameNotFoundException e2) {
            e2.printStackTrace();
        }
        tvSelectVideoQuality.setText(LanguagePref.a(this).a("pref_key_export_quality", "High"));
    }

    private void BindView() {
        ivback = findViewById(R.id.ivBack);
        llFeedback = findViewById(R.id.llFeedback);
        llRateUs = findViewById(R.id.llRateUs);
        llShareApp = findViewById(R.id.llShareApp);
        llExportVideoQuality = findViewById(R.id.exportQuality);
        llMyLyrics = findViewById(R.id.llMyLyrics);
        llPrivacypolicy = findViewById(R.id.llPrivacy_policy);
        tvSelectVideoQuality = findViewById(R.id.tvSelectedQuality);
        tvVersionCode = findViewById(R.id.tvVersionCode);

        ivback.setOnClickListener(this);
        llFeedback.setOnClickListener(this);
        llRateUs.setOnClickListener(this);
        llShareApp.setOnClickListener(this);
        llExportVideoQuality.setOnClickListener(this);
        llMyLyrics.setOnClickListener(this);
        llPrivacypolicy.setOnClickListener(this);
    }

    private void BannerAds() {
//        adView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        adView.loadAd(adRequest);
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.exportQuality:
                startActivity(new Intent(this, ExportVideoQuality.class));
                break;
            case R.id.llFeedback:
                Feedback();
                return;
            case R.id.llMyLyrics:
                intent = new Intent(this, MyVideoActivity.class);
                startActivity(intent);
                finish();
                return;
            case R.id.llRateUs:
                RateApp();
                return;
            case R.id.llShareApp:
                ShareAPP();
                return;
            case R.id.ivBack:
                onBackPressed();
                break;
            case R.id.llPrivacy_policy:
                PrivacyPolicy();
                break;
        }
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }


    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "United Videos");
            String shareMessage = "\nGet free United Videos at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void PrivacyPolicy() {
        try {
            Intent intent1 = new Intent("android.intent.action.VIEW");
            intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
            startActivity(intent1);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void onResume() {
        super.onResume();
        if (tvSelectVideoQuality != null) {
            tvSelectVideoQuality.setText(LanguagePref.a(this).a("pref_key_export_quality", "High"));
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }
}
