package com.kotlinz.videoCollage.flying.poiphoto;

public class Util {
    public static int selectedItemsCount;
}
