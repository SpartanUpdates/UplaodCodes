package com.esc.phoneheart.processes;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.util.Hashtable;

public class AppNames {
    public static final Hashtable<String, String> a = new Hashtable();

    public static String getLabel(PackageManager packageManager, PackageInfo packageInfo) {
        if (a.containsKey(packageInfo.packageName)) {
            return (String) a.get(packageInfo.packageName);
        }
        String charSequence = packageInfo.applicationInfo.loadLabel(packageManager).toString();
        a.put(packageInfo.packageName, charSequence);
        return charSequence;
    }
}
