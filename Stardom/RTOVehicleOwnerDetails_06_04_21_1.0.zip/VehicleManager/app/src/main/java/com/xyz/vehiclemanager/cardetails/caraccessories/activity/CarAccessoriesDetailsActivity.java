package com.xyz.vehiclemanager.cardetails.caraccessories.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.cardetails.caraccessories.adapter.CarAccessoriesDetailAdapter;
import com.xyz.vehiclemanager.cardetails.caraccessories.model.CarAccessories;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarAccessoriesDetailsActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = CarAccessoriesDetailsActivity.this;
    private String brandName, brandId;
    private RecyclerView rv_carAccessoriesDetals;
    private CarAccessoriesDetailAdapter carAccessoriesDetailAdapter;
    private ImageView iv_back;
    private TextView tv_title;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public CarAccessoriesDetailsActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caraccessories_details);

        Intent intent = getIntent();
        brandId = intent.getStringExtra("id");
        brandName = intent.getStringExtra("brandName");

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);

        BindView();
        PutAnalyticsEvent();
        BannerAds();
        DialogAnimation();
        if (Utils.isOnline(activity)) {
            getCarAccessories();
        } else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView() {
        iv_back = findViewById(R.id.iv_back);
        tv_title = findViewById(R.id.tv_title);
        rv_carAccessoriesDetals = findViewById(R.id.rv_carAccessoriesDetails);

        iv_back.setOnClickListener(this);
        tv_title.setText(brandName);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "CarAccessoriesDetailsActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_cardialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    private void getCarAccessories() {
        Call<CarAccessories> call = rtoDetailsInterface.getCarDetailAccessories(brandId);
        call.enqueue(new Callback<CarAccessories>() {
            @Override
            public void onResponse(Call<CarAccessories> call, Response<CarAccessories> response) {
                if (response.isSuccessful()) {
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    ArrayList<CarAccessories> carAccessorielist = response.body().getData();
                    carAccessoriesDetailAdapter = new CarAccessoriesDetailAdapter(activity, carAccessorielist);
                    rv_carAccessoriesDetals.setLayoutManager(new LinearLayoutManager(activity));
                    rv_carAccessoriesDetals.setAdapter(carAccessoriesDetailAdapter);
                }
            }

            @Override
            public void onFailure(Call<CarAccessories> call, Throwable t) {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}