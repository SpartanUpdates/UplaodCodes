package com.kotlinz.festivalstorymaker.Listener.festival;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatTextView;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Utils.BorderedTextView;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class d5 extends GestureDetector.SimpleOnGestureListener
{
    public final  BorderedTextView n;
    public final  com.kotlinz.festivalstorymaker.Models.g o;
    public final  FestivalDetailActivity_New p;

    public d5(final FestivalDetailActivity_New p3, final BorderedTextView n, final com.kotlinz.festivalstorymaker.Models.g o) {
        this.p = p3;
        this.n = n;
        this.o = o;
    }
    public class a implements TextInputDilaog.d {
        public void a(String str, int i) {
            d5.this.n.setText(str);
        }

        public void b(String str) {
        }
    }

    public void onLongPress(final MotionEvent motionEvent) {
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        this.p.K0();
        TextInputDilaog.q0((Context)this.p, ((AppCompatTextView)this.n).getText().toString(), true, this.o.G).m0 = new a(); {

        };
        return true;
    }
}
