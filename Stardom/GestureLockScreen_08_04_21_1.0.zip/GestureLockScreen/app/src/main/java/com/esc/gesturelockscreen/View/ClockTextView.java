package com.esc.gesturelockscreen.View;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import androidx.annotation.RequiresApi;

public class ClockTextView extends TextView {
    static Map<String, Typeface> cachedFonts;
    private String format;

    static {
        ClockTextView.cachedFonts = new HashMap<String, Typeface>();
    }

    public ClockTextView(final Context context) {
        super(context, (AttributeSet) null);
        this.applyCustomFont(context);
    }

    public ClockTextView(final Context context, final AttributeSet set) {
        super(context, set, 0);
        this.applyCustomFont(context);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ClockTextView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n, 0);
        this.applyCustomFont(context);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ClockTextView(final Context context, final AttributeSet set, final int n, final int n2) {
        super(context, set, n, n2);
        this.handleStyleable(context, set, n, n2);
        this.format = this.getTag().toString();
    }

    private void applyCustomFont(final Context context) {
        this.setTypeface(get(context, "SourceSansPro-Regular.ttf"));
        if (this.getTag() != null) {
            this.format = this.getTag().toString();
        }
    }

    public static Typeface get(final Context context, final String s) {
        if (ClockTextView.cachedFonts.containsKey(s)) {
            return ClockTextView.cachedFonts.get(s);
        }
        try {
            final Typeface fromAsset = Typeface.createFromAsset(context.getAssets(), "fonts/" + s + ".ttf");
            ClockTextView.cachedFonts.put(s, fromAsset);
            return fromAsset;
        } catch (RuntimeException ex) {
            return null;
        }
    }

    private void handleStyleable(final Context context, final AttributeSet set, final int n, final int n2) {
        if (this.getTag() != null) {
            this.format = this.getTag().toString();
        }
        this.updateValue();
    }

    public void updateValue() {
        if (this.format != null) {
            this.setText((CharSequence) new SimpleDateFormat(this.format, Locale.getDefault()).format(new Date()));
        }
    }
}
