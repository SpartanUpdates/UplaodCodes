package com.vidsoft.collagemaker.Activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.vidsoft.collagemaker.Adapters.CreationAdapter;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Utils;

import java.io.File;
import java.util.Collections;
public class MyCreationActivity extends Activity {
    private static final int MY_REQUEST_CODE = 5;
    private ImageView bback;
    private CreationAdapter galleryAdapter;
    private GridView gridview_imagelist;
    private ImageView noImage;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_creation);
        loadAd();
    }


    protected void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {

        this.noImage = (ImageView) findViewById(R.id.novideoimg);
        this.gridview_imagelist = (GridView) findViewById(R.id.gridimgList);
        getImages();
        if (Utils.Constant.IMAGEALLARY.size() <= 0) {
            this.noImage.setVisibility(View.VISIBLE);
            this.gridview_imagelist.setVisibility(View.GONE);
        } else {
            this.noImage.setVisibility(View.GONE);
            this.gridview_imagelist.setVisibility(View.VISIBLE);
        }
        this.bback = (ImageView) findViewById(R.id.Imageback);
        this.bback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent i = new Intent(MyCreationActivity.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);

            }
        });
        Collections.sort(Utils.Constant.IMAGEALLARY);
        Collections.reverse(Utils.Constant.IMAGEALLARY);
        this.galleryAdapter = new CreationAdapter(this, Utils.Constant.IMAGEALLARY);
        this.gridview_imagelist.setAdapter(this.galleryAdapter);
        gridview_imagelist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent i = new Intent(MyCreationActivity.this,
                        ActivityDisplayImage.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });

    }

    private void getImages() {
        if (VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                    5);
        }
    }

    private void fetchImage() {
        Utils.Constant.IMAGEALLARY.clear();
        Utils.Constant.listAllImages(new File("/storage/emulated/0/" + getString(R.string.app_name) + "/"));
    }

    public void onBackPressed() {
            Intent i = new Intent(MyCreationActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);

    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 5:
                if (grantResults[0] == 0) {
                    fetchImage();
                    return;
                } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                            5);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private NativeBannerAd mNativeBannerAd;

    private void loadAd() {
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(MyCreationActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.setVisibility(View.VISIBLE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });

        mNativeBannerAd.loadAd();

    }

}
