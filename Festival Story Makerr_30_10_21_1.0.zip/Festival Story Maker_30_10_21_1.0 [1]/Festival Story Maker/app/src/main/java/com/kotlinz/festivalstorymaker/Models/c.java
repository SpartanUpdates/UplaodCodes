package com.kotlinz.festivalstorymaker.Models;

public class c {
    public String a;
    public String b;
}
