package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.MyVideoView;
import com.libffmpeg.FileUtils;
import com.org.codechimp.apprater.AppRater;
import com.squareup.picasso.Picasso;
import com.xyz.imagetovideomoviewmaker.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Activity_VideoPlay extends AppCompatActivity implements
        MyVideoView.PlayPauseListner, OnClickListener, OnSeekBarChangeListener {
    Activity activity = Activity_VideoPlay.this;
    private int currentVideoDuration;
    private ImageView ivPlayPause;
    private Handler Handler;
    private boolean Complate;
    private File videoFile;
    private String StrVideoPath;
    private String strVideoName;
    private String videoDurationation;
    private String date;
    private Runnable runnable;
    private SeekBar SbVideo;
    private Long CaptureTime;
    private Toolbar toolbar;
    private MyVideoView myVideoView;
    private TextView tvDuration;
    private TextView tvEndDuration;
    private ImageView imgFacebook;
    private ImageView imgInstagram;
    private ImageView imgShare;
    private ImageView imgTwitter;
    private ImageView imgWhatsApp;
    ImageView ivAppIcon1, ivAppIcon2, ivAppIcon3, ivAppIcon4;

    ImageView ivback;
    TextView tvToolbarTitle;
    private NativeAdLayout nativeAdLayout;
    private LinearLayout adView;
    private NativeAd nativeAd;
    public Activity_VideoPlay() {
        this.Handler = new Handler();
        this.CaptureTime = Long.valueOf(0);
        this.runnable = new Runnable() {
            @Override
            public void run() {
                if (!Activity_VideoPlay.this.Complate) {
                    Activity_VideoPlay.this.currentVideoDuration = Activity_VideoPlay.this.myVideoView
                            .getCurrentPosition();
                    Activity_VideoPlay videoPlayActivity = Activity_VideoPlay.this;
                    videoPlayActivity.CaptureTime = Long.valueOf(videoPlayActivity.CaptureTime.longValue() + 100);
                    Activity_VideoPlay.this.tvDuration.setText(FileUtils
                            .getDuration((long) Activity_VideoPlay.this.myVideoView
                                    .getCurrentPosition()));
                    Activity_VideoPlay.this.tvEndDuration.setText(FileUtils
                            .getDuration((long) Activity_VideoPlay.this.myVideoView
                                    .getDuration()));
                    Activity_VideoPlay.this.SbVideo
                            .setProgress(Activity_VideoPlay.this.currentVideoDuration);
                    Activity_VideoPlay.this.Handler.postDelayed(this, 100);
                }
            }
        };
    }

    public void openApp(View v) {
        try {
            startActivity(new Intent(
                    "android.intent.action.VIEW",
                    Uri.parse(v.getTag().toString())));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getApplicationContext(), "You don't have Google Play installed",
                    Toast.LENGTH_SHORT).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_creationvideo);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "Activity_VideoPlay");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        this.toolbar = findViewById(R.id.toolbar);
        this.myVideoView = findViewById(R.id.MyvideoView);
        this.tvDuration = findViewById(R.id.tvStartDuration);
        this.tvEndDuration = findViewById(R.id.tvEndDuration);
        this.ivPlayPause = findViewById(R.id.ivPlayPause);
        this.SbVideo = findViewById(R.id.VideoSeekbar);
        this.StrVideoPath = getIntent().getStringExtra("android.intent.extra.TEXT");
        this.strVideoName = getIntent().getStringExtra("Name");
        this.videoDurationation = getIntent().getStringExtra("Duration");
        this.date = getIntent().getStringExtra("Date");
        this.videoFile = new File(this.StrVideoPath);
        this.myVideoView.setVideoPath(this.StrVideoPath);
        ivback = findViewById(R.id.iv_back);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        tvToolbarTitle.setText(R.string.sharemycreation);
        Utils.setFont(activity, tvToolbarTitle);
        Utils.setFont(activity, tvDuration);
        Utils.setFont(activity, tvEndDuration);
        this.myVideoView.setOnPlayPauseListner(this);
        this.myVideoView.setOnPreparedListener(new OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.seekTo(100);
                Activity_VideoPlay.this.SbVideo.setMax(mp.getDuration());
                Activity_VideoPlay.this.progressToTimer(mp.getDuration(), mp.getDuration());
                Activity_VideoPlay.this.tvDuration.setText(FileUtils
                        .getDuration((long) mp.getCurrentPosition()));
                Activity_VideoPlay.this.tvEndDuration.setText(FileUtils.getDuration((long) mp.getDuration()));
            }
        });
        findViewById(R.id.ClickVideo).setOnClickListener(this);
        this.myVideoView.setOnClickListener(this);
        this.ivPlayPause.setOnClickListener(this);
        this.SbVideo.setOnSeekBarChangeListener(this);
        this.myVideoView.setOnCompletionListener(new OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Activity_VideoPlay.this.Complate = true;
                Activity_VideoPlay.this.Handler
                        .removeCallbacks(Activity_VideoPlay.this.runnable);
                Activity_VideoPlay.this.tvDuration.setText(FileUtils
                        .getDuration((long) mp.getDuration()));
                Activity_VideoPlay.this.tvEndDuration.setText(FileUtils.getDuration((long) mp.getDuration()));
            }
        });
        LoadNativeAds();
        this.imgWhatsApp = findViewById(R.id.imgFacebook);
        this.imgFacebook = findViewById(R.id.imgWhatsApp);
        this.imgInstagram = findViewById(R.id.imgInstagram);
        this.imgShare = findViewById(R.id.imgShare);
        this.imgTwitter = findViewById(R.id.imgTwitter);
        this.imgFacebook.setOnClickListener(this);
        this.imgInstagram.setOnClickListener(this);
        this.imgWhatsApp.setOnClickListener(this);
        this.imgTwitter.setOnClickListener(this);
        this.imgShare.setOnClickListener(this);
        ivAppIcon1 = findViewById(R.id.imgApp1);
        ivAppIcon2 = findViewById(R.id.imgApp2);
        ivAppIcon3 = findViewById(R.id.imgApp3);
        ivAppIcon4 = findViewById(R.id.imgApp4);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_my);
        ivAppIcon1.startAnimation(animation);
        ivAppIcon2.startAnimation(animation);
        ivAppIcon3.startAnimation(animation);
        ivAppIcon4.startAnimation(animation);
        if (Utils.Utility.listName != null && Utils.Utility.listIcon != null && Utils.Utility.isNetworkAvailable(Activity_VideoPlay.this)) {
            if (Utils.Utility.listIcon.size() >= 6 && Utils.Utility.listName.size() >= 6 && Utils.Utility.listUrl.size() >= 6) {
                ivAppIcon1.setTag(Utils.Utility.listUrl.get(2));
                ivAppIcon2.setTag(Utils.Utility.listUrl.get(3));
                ivAppIcon3.setTag(Utils.Utility.listUrl.get(4));
                ivAppIcon4.setTag(Utils.Utility.listUrl.get(5));
                Picasso.with(Activity_VideoPlay.this).load(Utils.Utility.listIcon.get(2)).into(ivAppIcon1);
                Picasso.with(Activity_VideoPlay.this).load(Utils.Utility.listIcon.get(3)).into(ivAppIcon2);
                Picasso.with(Activity_VideoPlay.this).load(Utils.Utility.listIcon.get(4)).into(ivAppIcon3);
                Picasso.with(Activity_VideoPlay.this).load(Utils.Utility.listIcon.get(5)).into(ivAppIcon4);

            }
        }
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    private void LoadNativeAds() {
        nativeAd = new NativeAd(this, getResources().getString(R.string.fb_nativeBanner));
        nativeAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (nativeAd == null || nativeAd != ad) {
                    return;
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                inflateAd(nativeAd);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeAd.loadAd();
    }

    private void inflateAd(NativeAd nativeAd) {
        nativeAd.unregisterView();

        // Add the Ad view into the ad container.
        nativeAdLayout = findViewById(R.id.native_ad_container);
        LayoutInflater inflater = LayoutInflater.from(activity);
        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
        adView = (LinearLayout) inflater.inflate(R.layout.layout_fb_nativead, nativeAdLayout, false);
        nativeAdLayout.addView(adView);

        // Add the AdOptionsView
        LinearLayout adChoicesContainer = findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(activity, nativeAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();
        adChoicesContainer.addView(adOptionsView, 0);

        // Create native UI using the ad metadata.
        AdIconView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Set the Text.
        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

        // Create a list of clickable views
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
                adView,
                nativeAdMedia,
                nativeAdIcon,
                clickableViews);
    }



    protected void onPause() {
        super.onPause();
        this.myVideoView.pause();
    }

    public View onCreateView(View view, String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context,
                             AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    public void onVideoPause() {
        if (!(this.Handler == null || this.runnable == null)) {
            this.Handler.removeCallbacks(this.runnable);
        }
        Animation animation = new AlphaAnimation(0.0f,
                1.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Activity_VideoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }
        });
    }

    public void onVideoPlay() {
        updateProgressBar();
        Animation animation = new AlphaAnimation(1.0f, 0.0f);
        animation.setDuration(500);
        animation.setFillAfter(true);
        this.ivPlayPause.startAnimation(animation);
        animation.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                Activity_VideoPlay.this.ivPlayPause.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Activity_VideoPlay.this.ivPlayPause.setVisibility(View.INVISIBLE);
            }
        });
    }

    public void updateProgressBar() {
        try {
            this.Handler.removeCallbacks(this.runnable);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.Handler.postDelayed(this.runnable, 100);
    }


    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.MyvideoView:
            case R.id.ClickVideo:
            case R.id.ivPlayPause:
                if (this.myVideoView.isPlaying()) {
                    this.myVideoView.pause();
                    return;
                }
                this.myVideoView.start();
                this.Complate = false;
                break;
            case R.id.imgFacebook:
                shareImageWhatsApp("com.facebook.katana", "Facebook");
                return;
            case R.id.imgInstagram:
                shareImageWhatsApp("com.instagram.android", "Instagram");
                return;
            case R.id.imgShare:
//                final Intent intent = new Intent("android.intent.action.SEND");
//                intent.setType("video/mp4");
//                intent.putExtra("android.intent.extra.STREAM",
//                        Uri.fromFile(this.videoFile));
//                startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
//                Parcelable fromFile;
                Uri ShareUri;
                if (Build.VERSION.SDK_INT <= 19) {
//                    fromFile = Uri.fromFile(new File(this.StrVideoPath));
                    ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
//                    fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.StrVideoPath));
                    ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/mp4");
                intent.putExtra("android.intent.extra.STREAM", ShareUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
                return;
            case R.id.imgTwitter:
                shareImageWhatsApp("com.twitter.android", "Twitter");
                return;
            case R.id.imgWhatsApp:
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
                return;
            default:
        }
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    public void shareImageWhatsApp(String str, String str2) {
//        Parcelable fromFile;
        Uri ShareUri;
        if (Build.VERSION.SDK_INT <= 19) {
//            fromFile = Uri.fromFile(new File(this.StrVideoPath));
            ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            ShareUri = FileProvider.getUriForFile(activity, String.valueOf(getPackageName()) + ".provider", new File(this.StrVideoPath));

        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("video/mp4");
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_LONG).show();
    }

    public void onProgressChanged(SeekBar seekBar, int progress,
                                  boolean fromUser) {
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.Handler.removeCallbacks(this.runnable);
        this.currentVideoDuration = progressToTimer(seekBar.getProgress(), this.myVideoView.getDuration());
        this.myVideoView.seekTo(seekBar.getProgress());
        if (this.myVideoView.isPlaying()) {
            updateProgressBar();
        }
    }

    public int progressToTimer(int progress, int totalDuration) {
        return ((int) ((((double) progress) / 100.0d) * ((double) (totalDuration / 1000))))
                * 1000;
    }

    protected void onDestroy() {
        this.myVideoView.stopPlayback();
        this.Handler.removeCallbacks(this.runnable);
        super.onDestroy();
    }

//    public boolean onCreateOptionsMenu(final Menu menu) {
//        this.getMenuInflater().inflate(R.menu.delete_video, menu);
//        return true;
//    }
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                Intent intent = new Intent(this, VideoAlbumActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                intent.putExtra(VideoAlbumActivity.EXTRA_FROM_VIDEO, true);
//                animUtil.startActivitySafely(this.toolbar, intent);
//                finish();
//                break;
//            case R.id.action_delete:
//                if (this.myVideoView.isPlaying()) {
//                    this.myVideoView.pause();
//                }
//                AlertDialog.Builder builder = new AlertDialog.Builder(Activity_VideoPlay.this,
//                        R.style.Theme_MovieMaker_AlertDialog);
//                builder.setTitle("Delete Video !");
//                builder.setMessage("Are you sure to delete?");
//                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        FileUtils.deleteFile(new File(
//                                StrVideoPath));
//                        startActivity(new Intent(Activity_VideoPlay.this, VideoAlbumActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                        finish();
//                    }
//                });
//                builder.setNegativeButton("Cancel", null);
//                builder.show();
//                break;
//        }
//        return super.onOptionsItemSelected(item);
//    }


    @Override
    public void onBackPressed() {
        Intent intent;
        if (getIntent().getExtras().get("KEY").equals("FromVideoAlbum")) {
            if (new Random().nextInt(100) > 50) {
                AppRater.showRateDialog(this);
                AppRater.setCallback(new AppRater.Callback() {
                    @Override
                    public void onCancelClicked() {
                        final Intent intent = new Intent(Activity_VideoPlay.this, VideoAlbumActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("EXTRA_FROM_VIDEO", true);
                        Activity_VideoPlay.this.startActivity(intent);
                        Activity_VideoPlay.this.finish();
                    }

                    @Override
                    public void onNoClicked() {
                    }

                    @Override
                    public void onYesClicked() {
                    }
                });
                return;
            }
            intent = new Intent(this, VideoAlbumActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra(VideoAlbumActivity.EXTRA_FROM_VIDEO, true);
            startActivity(intent);
            finish();
        } else if (getIntent().getExtras().get("KEY").equals("FromProgress")) {
            intent = new Intent(this, VideoAlbumActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra(VideoAlbumActivity.EXTRA_FROM_VIDEO, true);
            intent.putExtra("KEY", VideoAlbumActivity.EXTRA_FROM_VIDEO);
            startActivity(intent);
            finish();
        } else if (getIntent().getExtras().get("KEY").equals("FromNotify")) {
            intent = new Intent(this, LauncherActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra(VideoAlbumActivity.EXTRA_FROM_VIDEO, true);
            startActivity(intent);
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
