package com.name.nameart.MyUtils;


import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.name.nameart.ThropicalData.Myapplication;

public final class MyPreference {
    public static final Companion Companion = new Companion();
    public static final String FONT_STYLE = "FONT_STYLE";
    private static final String PREFS_NAME = "myapp";

    public static final class Companion {
        private Companion() {
        }

        public static String getAppPrefString$default(Companion companion, String str, String str2, int i, Object obj) {
            if ((i & 2) != 0) {
                str2 = "";
            }
            return companion.getAppPrefString(str, str2);
        }

        private final SharedPreferences get() {
            return Myapplication.Companion.instance().getSharedPreferences(MyPreference.PREFS_NAME, 0);
        }

        public final void writeSharedPreferences(String str, String str2) {
            Editor edit = get().edit();
            edit.putString(str, str2);
            edit.apply();
        }

        public final void writeSharedPreferencesBool(String str, boolean z) {
            get().edit().putBoolean(str, z).apply();
        }

        public final String getAppPrefString(String str, String str2) {
            return get().getString(str, str2);
        }

        public final boolean getAppPrefBool(String str, boolean z) {
            return get().getBoolean(str, z);
        }

        public final void clearAll() {
            get().edit().clear().commit();
        }
    }
}