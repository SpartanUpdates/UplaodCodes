package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.CollageMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class CollageText implements TextStickerViewNew1.b {
    public final  CollageMakerDetailActivity activity;

    public CollageText(CollageMakerDetailActivity collageMakerDetailActivity) {
        this.activity = collageMakerDetailActivity;
    }

    public void a(boolean z, TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.llTextEditor.isShown() && !z) {
            TextStickerViewNew1 textStickerViewNew12 = activity.n0;
            if (textStickerViewNew12 == null || textStickerViewNew12 == textStickerViewNew1) {
                activity.r0(z);
            }
        }
    }
}
