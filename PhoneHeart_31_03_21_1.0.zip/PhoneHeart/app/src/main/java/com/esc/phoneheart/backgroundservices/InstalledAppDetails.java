package com.esc.phoneheart.backgroundservices;

import android.app.IntentService;
import android.content.Intent;
import com.esc.phoneheart.pref.SharedPrefUtil;

public class InstalledAppDetails extends IntentService {
    public SharedPrefUtil sharedPrefUtil;
    public String token;

    public InstalledAppDetails() {
        super("SendInstallDetail");
    }

    public void onHandleIntent(Intent intent) {
        try {
            SharedPrefUtil sharedPrefUtil = new SharedPrefUtil(getBaseContext());
            this.sharedPrefUtil = sharedPrefUtil;
            String string = sharedPrefUtil.getString(SharedPrefUtil.PUSHTOKEN);
            this.token = string;
            if (string == null) {
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
