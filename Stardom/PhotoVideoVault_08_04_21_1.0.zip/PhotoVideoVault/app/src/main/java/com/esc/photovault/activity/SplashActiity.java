package com.esc.photovault.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.photovault.R;
import com.esc.photovault.pref.SharedPreference;

public class SplashActiity extends AppCompatActivity {
    private static boolean First_time = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
                if (SharedPreference.getFirstTime(SplashActiity.this, "first_time_enter")) {
                    First_time = false;
                    SharedPreference.storeFirstTime(SplashActiity.this, "first_time_enter", First_time);
                    Intent intent1 = new Intent(SplashActiity.this, FirstTimeSecurityActivity.class);
                    startActivity(intent1);
                    finish();
                } else {
                    Intent intent1 = new Intent(SplashActiity.this, LockScreenActivity.class);
                    startActivity(intent1);
                    finish();
                }
            }
        },2000);
    }
}
