package flash.light.shine.com.billing;

import com.android.billingclient.api.PurchaseHistoryRecord;
import java.util.List;

public interface HistoryFetcher {
    void ongetHistory(int i, List<PurchaseHistoryRecord> list);
}
