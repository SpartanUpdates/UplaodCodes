﻿using UnityEngine;
using UnityEngine.UI;
using AudienceNetwork;
using AudienceNetwork.Utility;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class InterstitialFbAds : MonoBehaviour
    {
        public static InterstitialFbAds instance;

        private InterstitialAd interstitialAd;

        [HideInInspector]
        public bool isIntertitialFBLoaded, isValid = false;

        private bool didClose;

        private void Awake()
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        private void Start()
        {
            AudienceNetworkAds.Initialize();
            LoadInterstitial();
        }
        public void LoadInterstitial()
        {
            interstitialAd = new InterstitialAd(Manager.instance.fbInterstitialId);

            interstitialAd.Register(gameObject);
            Analytics.CustomEvent("FbInterstitalLoad");
            interstitialAd.InterstitialAdDidLoad = delegate ()
            {
                isIntertitialFBLoaded = true;
                didClose = false;
                isValid = interstitialAd.IsValid() ? true : false;
            };

            interstitialAd.InterstitialAdDidFailWithError = delegate (string error)
            {
                Analytics.CustomEvent("FbInterstitalFail");
            };

            interstitialAd.InterstitialAdWillLogImpression = delegate ()
            {
            };

            interstitialAd.InterstitialAdDidClick = delegate ()
            {
            };

            interstitialAd.InterstitialAdDidClose = delegate ()
            {
                GameController.instance.noAddInter.SetActive(true);
                if (GameController.instance.isLCompleteClick)
                {
                    GameController.instance.LevelCompletedAfter();
                    Analytics.CustomEvent("FbInterstitalLevelCompletedDone");
                }
                if (GameController.instance.isRestartClick)
                {
                    GameController.instance.BtnRestartAfter();
                    Analytics.CustomEvent("FbInterstitalRestartDone");
                }
                if (GameController.instance.isHomeClick)
                {
                    GameController.instance.BtnHomeAfter();
                    Analytics.CustomEvent("FbInterstitalHomeDone");
                }

                isIntertitialFBLoaded = false;

                didClose = true;

                if (interstitialAd != null)
                {
                    interstitialAd.Dispose();
                }
                LoadInterstitial();
            };

#if UNITY_ANDROID
            interstitialAd.interstitialAdActivityDestroyed = delegate ()
            {
                GameController.instance.noAddInter.SetActive(true);
                if (GameController.instance.isLCompleteClick)
                {
                    GameController.instance.LevelCompletedAfter();
                    Analytics.CustomEvent("FbInterstitalLevelCompletedDone");
                }
                if (GameController.instance.isRestartClick)
                {
                    GameController.instance.BtnRestartAfter();
                    Analytics.CustomEvent("FbInterstitalRestartDone");
                }
                if (GameController.instance.isHomeClick)
                {
                    GameController.instance.BtnHomeAfter();
                    Analytics.CustomEvent("FbInterstitalHomeDone");
                }

                isIntertitialFBLoaded = false;

                if (!didClose)
                {
                }
            };
#endif
            interstitialAd.LoadAd();
        }

        public void ShowInterstitial()
        {
            interstitialAd.Show();
        }
        void OnDestroy()
        {
            if (interstitialAd != null)
            {
                interstitialAd.Dispose();
            }
        }
    }
}