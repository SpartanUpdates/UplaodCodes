package com.xyz.vehiclemanager.bike.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.model.BikeDetailsRoot;

import java.util.ArrayList;

public class BikeColorAdapter extends RecyclerView.Adapter<BikeColorAdapter.ViewHolder> {
    Context context;
    ArrayList<BikeDetailsRoot.Details.Color> bikeColorlist;

    public BikeColorAdapter(Context context, ArrayList<BikeDetailsRoot.Details.Color> bikeColorlist) {
        this.context = context;
        this.bikeColorlist = bikeColorlist;
    }
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView colorName;
        ImageView bgColor;
        ImageView iv_smallbgcolor;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            colorName=itemView.findViewById(R.id.colorName);
            bgColor=itemView.findViewById(R.id.bgColor);
            iv_smallbgcolor = itemView.findViewById(R.id.iv_smallbgcolor);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.layout_color, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BikeDetailsRoot.Details.Color bikeColorModel = bikeColorlist.get(position);
        holder.colorName.setText(bikeColorModel.getColorName());
        String str = "#";
        String str2 = "/";
        StringBuilder stringBuilder;

        if (bikeColorModel.getBackgroundName().contains(str2)){

            holder.bgColor.setVisibility(View.VISIBLE);
            holder.iv_smallbgcolor.setVisibility(View.VISIBLE);
            String[] split = bikeColorModel.getBackgroundName().split(str2);
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(split[0].trim());
            holder.bgColor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));

            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(split[1].trim());
            holder.iv_smallbgcolor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));
        }else {
            holder.bgColor.setVisibility(View.VISIBLE);
            holder.iv_smallbgcolor.setVisibility(View.GONE);
            holder.bgColor.getLayoutParams().height=60;
            holder.bgColor.getLayoutParams().width=60;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(bikeColorModel.getBackgroundName());
            holder.bgColor.setBackgroundColor(Color.parseColor(stringBuilder.toString()));
        }
    }
    @Override
    public int getItemCount() {
        return bikeColorlist.size();
    }
}
