package com.name.nameart.ThropicalData;

import android.content.Context;
import android.os.Build;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy.Builder;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.name.nameart.OpenAds.AppOpenManager;

public class Myapplication extends MultiDexApplication {

    AppOpenManager appOpenManager;

    public static final Companion Companion = new Companion();
    private static Myapplication mInstance;

    public static final class Companion {


        private Companion() {
        }

        public final Context instance() {
            if (Myapplication.mInstance == null) {
                Myapplication.mInstance = new Myapplication();
            }
            return Myapplication.mInstance;
        }
    }

    public Myapplication() {
        mInstance = this;
    }

    public void onCreate() {
        super.onCreate();
        mInstance = this;
        MultiDex.install(this);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus)
            {

            }
        });
        appOpenManager = new AppOpenManager(this);

        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }
}