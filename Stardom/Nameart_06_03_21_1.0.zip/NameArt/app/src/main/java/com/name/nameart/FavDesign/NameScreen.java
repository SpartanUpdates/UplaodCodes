package com.name.nameart.FavDesign;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.name.nameart.R;
import com.name.nameart.kprogresshud.KProgressHUD;


public class NameScreen extends AppCompatActivity {

    Activity activity = NameScreen.this;
    Context context;
    EditText inputtext;

    TextView next_btn;
    Toolbar toolbar;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.screen_name);

        interstitialAd();

        this.context = this;
        this.inputtext = (EditText) findViewById(R.id.inputtext);

        TextView textView = (TextView) findViewById(R.id.next_btn);
        this.next_btn = textView;
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

                try {
                    String obj = NameScreen.this.inputtext.getText().toString();
                    if (obj.equals("")) {
                        Toast.makeText(NameScreen.this, "Please enter your name !", Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                            try {
                                hud = KProgressHUD.create(activity)
                                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                        .setLabel("Showing Ads")
                                        .setDetailsLabel("Please Wait...");
                                hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }

                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                        id = 100;
                                        mInterstitialAd.show();
                                    }
                                }
                            }, 2000);
                        } else {
                            Log.e("JJJJJJJ", "KKKKK");
                            Intent intent = new Intent(NameScreen.this, NameEditing.class);
                            intent.putExtra("real_txt", obj.trim());
                            NameScreen.this.startActivity(intent);
                            finish();
                            ((InputMethodManager) NameScreen.this.context.getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        try {
                            String obj = NameScreen.this.inputtext.getText().toString();
                            if (obj.equals("")) {
                                Toast.makeText(NameScreen.this, "Please enter your name !", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Log.e("kkkkk", "jjjjj");
                            Intent intent = new Intent(NameScreen.this, NameEditing.class);
                            intent.putExtra("real_txt", obj.trim());
                            NameScreen.this.startActivity(intent);
                            finish();
                            ((InputMethodManager) NameScreen.this.context.getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
