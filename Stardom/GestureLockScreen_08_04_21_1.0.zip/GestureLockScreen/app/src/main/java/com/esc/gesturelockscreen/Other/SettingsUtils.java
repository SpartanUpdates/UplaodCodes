package com.esc.gesturelockscreen.Other;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import java.io.File;
import androidx.core.view.InputDeviceCompat;

public class SettingsUtils implements SettingsKeys {
  private static SettingsUtils _instance = new SettingsUtils();
  private SharedPreferences mPreferences;

  private SettingsUtils() {
  }

  public static boolean notInitialized() {
    return _instance.mPreferences == null;
  }

  public static int getPasscodeLengthValue() {
    if (_instance.mPreferences == null) {
      return 4;
    }
    return _instance.mPreferences.getInt(SettingsKeys.KEY_PASSCODE_LENGTH, 4);
  }

  public static void savePasscodeLengthValue(int value) {
    if (_instance.mPreferences != null) {
      _instance.mPreferences.edit().putInt(SettingsKeys.KEY_PASSCODE_LENGTH, value).apply();
    }
  }

  public static void init(Context c) {
    if (_instance.mPreferences == null) {
      _instance.mPreferences = PreferenceManager.getDefaultSharedPreferences(c);
    }
  }

  public static void saveRecoveryPasscode(String pass, int value) {
    if (_instance.mPreferences != null) {
      _instance.mPreferences.edit().putString("KEY_PASSCODE_" + value, pass).commit();
    }
  }

  public static String getRecoveryPasscode(int value) {
    if (_instance.mPreferences == null) {
      return null;
    }
    return _instance.mPreferences.getString("KEY_PASSCODE_" + value, null);
  }

  public static String getRecoveryPasscode() {
    if (_instance.mPreferences == null) {
      return null;
    }
    return _instance.mPreferences.getString("KEY_PASSCODE_" + getPasscodeLengthValue(), null);
  }

  public static float getDifficultyLevel() {
    if (_instance.mPreferences == null) {
      return 1.0f;
    }
    return new float[]{1.0f, 2.0f, 4.0f}[_instance.mPreferences.getInt(SettingsKeys.KEY_GESTURE_LEVEL, 1)];
  }

  public static int getInt(String key, int defValue) {
    return _instance.mPreferences == null ? defValue : _instance.mPreferences.getInt(key, defValue);
  }

  public static void putInt(String key, int defValue) {
    if (_instance.mPreferences != null) {
      _instance.mPreferences.edit().putInt(key, defValue).commit();
    }
  }

  public static boolean getBoolean(String key, boolean defValue) {
    return _instance.mPreferences == null ? defValue : _instance.mPreferences.getBoolean(key, defValue);
  }

  public static void putBoolean(String key, boolean defValue) {
    if (_instance.mPreferences != null) {
      _instance.mPreferences.edit().putBoolean(key, defValue).commit();
    }
  }

  public static boolean hideGesture() {
    if (_instance.mPreferences == null) {
      return false;
    }
    return getBoolean(SettingsKeys.KEY_HIDE_GESTURE, false);
  }

  public static void saveGestureColor(int color) {
    if (_instance.mPreferences != null) {
      putInt(SettingsKeys.KEY_GESTURE_COLOR, color);
    }
  }

  public static int getGestureColor() {
    if (_instance.mPreferences == null) {
      return InputDeviceCompat.SOURCE_ANY;
    }
    return getInt(SettingsKeys.KEY_GESTURE_COLOR, InputDeviceCompat.SOURCE_ANY);
  }

  public static int getUncertainGestureColor() {
    int color = getGestureColor();
    return Color.argb(72, Color.red(color), Color.green(color), Color.blue(color));
  }

  public static void saveUserWallpaper(String avatarPath) {
    if (_instance.mPreferences != null) {
      File f = getUserWallpaper();
      if (f != null && f.exists()) {
        f.delete();
      }
      _instance.mPreferences.edit().putString(SettingsKeys.KEY_CUSTOM_WALLPAPER, avatarPath).commit();
    }
  }

  public static File getUserWallpaper() {
    if (_instance.mPreferences == null) {
      return null;
    }
    String path = _instance.mPreferences.getString(SettingsKeys.KEY_CUSTOM_WALLPAPER, null);
    if (path != null) {
      File f = new File(path);
      if (f.exists()) {
        return f;
      }
    }
    return null;
  }
}
