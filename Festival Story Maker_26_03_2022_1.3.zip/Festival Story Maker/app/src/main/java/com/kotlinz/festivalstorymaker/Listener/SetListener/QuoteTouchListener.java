package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class QuoteTouchListener implements com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1.b {
    public final  QuoteMakerDetailActivity activity;

    public QuoteTouchListener(QuoteMakerDetailActivity quoteMakerDetailActivity) {
        this.activity = quoteMakerDetailActivity;
    }

    public void a(boolean z, TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.findViewById(R.id.llTextEditor).isShown() && !z) {
            TextStickerViewNew1 textStickerViewNew12 = activity.stickerViewNew1;
            if (textStickerViewNew12 == null || textStickerViewNew12 == textStickerViewNew1) {
                QuoteMakerDetailActivity.i0(activity, z);
            }
        }
    }
}
