package com.example.postermaker.textitems;

public class eaz_TextShapeStaticValues {
    public static int bordercolor;
    public static int textbgbordersize;
    public static int textbgborderspace;
    public static int textbgcolor;
    public static int textbgradius;
    public static int textcolor;
}
