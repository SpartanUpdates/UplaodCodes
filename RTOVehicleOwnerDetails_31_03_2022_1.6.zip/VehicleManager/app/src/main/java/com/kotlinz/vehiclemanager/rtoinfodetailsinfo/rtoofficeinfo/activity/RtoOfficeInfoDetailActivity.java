package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class RtoOfficeInfoDetailActivity extends AppCompatActivity {

    private Activity activity = RtoOfficeInfoDetailActivity.this;
    private String cityCode, cityName, StateName, address, contact, website;
    private TextView tv_district;
    private TextView tv_rtoCode;
    private TextView tv_address;
    private TextView tv_phone;
    private TextView tv_website;
    private TextView tv_state;
    private TextView title_tv;
    private LottieAnimationView call, map;
    private ImageView iv_back, iv_home;
    private LinearLayout ll_rtoOfficeData;
    private LinearLayout ll_address;
    private LinearLayout ll_contact;

    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo_detail);
        cityCode = getIntent().getStringExtra("cityCode");
        cityName = getIntent().getStringExtra("cityName");
        StateName = getIntent().getStringExtra("StateName");
        address = getIntent().getStringExtra("address");
        contact = getIntent().getStringExtra("contact");
        website = getIntent().getStringExtra("website");
        PutAnalyticsEvent();
        BindView();
        LoadNativeAds();
        getPermission();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(RtoOfficeInfoDetailActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        if (Utils.isOnline(activity)) {
            setCityData();
        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        iv_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(RtoOfficeInfoDetailActivity.this, MainActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(RtoOfficeInfoDetailActivity.this, MainActivity.class));
                        finish();
                    }
                }
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void getPermission() {
        if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
        }
    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_rtoOfficeData.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        tv_website.setLinkTextColor(Color.parseColor("#FAFAD2"));
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (RtoOfficeInfoDetailActivity.this.nativeAd != null) {
                            RtoOfficeInfoDetailActivity.this.nativeAd.destroy();
                        }
                        RtoOfficeInfoDetailActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void BindView() {
        tv_district = findViewById(R.id.tv_district);
        tv_rtoCode = findViewById(R.id.tv_rtoCode);
        tv_state = findViewById(R.id.tv_state);
        tv_address = findViewById(R.id.tv_address);
        tv_phone = findViewById(R.id.tv_contact);
        tv_website = findViewById(R.id.tv_website);
        iv_back = findViewById(R.id.iv_back);
        ll_address = findViewById(R.id.ll_address);
        ll_contact = findViewById(R.id.ll_contact);
        ll_rtoOfficeData = findViewById(R.id.ll_rtoOfficeData);
        title_tv = findViewById(R.id.title_tv);
        iv_home = findViewById(R.id.iv_home);
        call = findViewById(R.id.call);
        map = findViewById(R.id.map);

    }

    private void setCityData() {
        tv_district.setText(cityName);
        tv_rtoCode.setText(cityCode);
        tv_address.setText(address);
        tv_state.setText(StateName);
        tv_website.setText(website);
        if (contact.equals("null")) {
            ll_contact.setVisibility(View.GONE);
        } else {
            contact = contact.replace("-", " ");
            tv_phone.setText(contact);
            call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                    } else {
                        if (MyApplication.isShowAd == 1) {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + contact));
                            startActivity(intent);
                            MyApplication.isShowAd = 0;
                        } else {
                            if (MyApplication.mInterstitialAd != null) {
                                MyApplication.activity = activity;
                                MyApplication.AdsId = 22;
                                MyApplication.contact = contact;
                                MyApplication.mInterstitialAd.show(activity);
                                MyApplication.isShowAd = 1;

                            } else {
                                Intent intent = new Intent(Intent.ACTION_DIAL);
                                intent.setData(Uri.parse("tel:" + contact));
                                startActivity(intent);
                            }
                        }
                    }
                }
            });
            tv_phone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                    } else {
                        if (MyApplication.isShowAd == 1) {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + contact));
                            startActivity(intent);
                            MyApplication.isShowAd = 0;
                        } else {
                            if (MyApplication.mInterstitialAd != null) {
                                MyApplication.activity = activity;
                                MyApplication.AdsId = 22;
                                MyApplication.contact = contact;
                                MyApplication.mInterstitialAd.show(activity);
                                MyApplication.isShowAd = 1;

                            } else {
                                Intent intent = new Intent(Intent.ACTION_DIAL);
                                intent.setData(Uri.parse("tel:" + contact));
                                startActivity(intent);
                            }
                        }

                    }
                }
            });
        }

        if (address.equals("null")) {
            ll_address.setVisibility(View.GONE);
        } else {
            tv_address.setText(address);
            map.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MyApplication.isShowAd == 1) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:0,0?q=" + address));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        MyApplication.isShowAd = 0;
                    } else {
                        if (MyApplication.mInterstitialAd != null) {
                            MyApplication.activity = activity;
                            MyApplication.AdsId = 23;
                            MyApplication.address = address;
                            MyApplication.mInterstitialAd.show(activity);
                            MyApplication.isShowAd = 1;
                        } else {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW);
                                intent.setData(Uri.parse("geo:0,0?q=" + address));
                                startActivity(intent);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            });
            tv_address.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MyApplication.isShowAd == 1) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:0,0?q=" + address));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        MyApplication.isShowAd = 0;
                    } else {
                        if (MyApplication.mInterstitialAd != null) {
                            MyApplication.activity = activity;
                            MyApplication.AdsId = 23;
                            MyApplication.address = address;
                            MyApplication.mInterstitialAd.show(activity);
                            MyApplication.isShowAd = 1;

                        } else {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW);
                                intent.setData(Uri.parse("geo:0,0?q=" + address));
                                startActivity(intent);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            });
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(RtoOfficeInfoDetailActivity.this, RtoOfficeInfoActivity.class));
            finish();;
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 24;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(RtoOfficeInfoDetailActivity.this, RtoOfficeInfoActivity.class));
                finish();;
            }
        }
    }
}