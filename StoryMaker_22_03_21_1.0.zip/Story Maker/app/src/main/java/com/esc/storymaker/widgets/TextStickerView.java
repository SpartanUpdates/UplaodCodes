package com.esc.storymaker.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.SweepGradient;
import android.os.Build.VERSION;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.core.view.ViewCompat;
import com.esc.storymaker.R;
import com.esc.storymaker.models.Font;
import com.esc.storymaker.utils.BitmapUtil;
import com.esc.storymaker.utils.FontProvider;
import com.esc.storymaker.utils.RectUtil;

public class TextStickerView extends View {
    private static final int DELETE_MODE = 5;
    private static final int EDIT_MODE = 6;
    private static final int IDLE_MODE = 2;
    private static final int MOVE_MODE = 3;
    private static final int ROTATE_MODE = 4;
    private static final int SCALE_MODE = 7;
    public int PADDING;
    public int STICKER_BTN_HALF_SIZE;
    private Alignment align = Alignment.ALIGN_CENTER;
    private int canvasHeight;
    private int canvasWidth;
    private Context context;
    private Paint debugPaint = new Paint();
    private float dx;
    private float dy;
    private boolean editText = true;
    private int finalPaddingLeft;
    private int finalPaddingRight;
    private Font font;
    private FontProvider fontProvider;
    private boolean isInEdit = true;
    private boolean isInitLayout = true;
    private boolean isShowHelpBox = true;
    private float last_x = 0.0f;
    private float last_y = 0.0f;
    private int layoutX;
    private int layoutY;
    private float letterSpacing = 0.0f;
    private float lineSpacing = 10.0f;
    private int mCurrentMode = 2;
    private Bitmap mDeleteBitmap;
    private RectF mDeleteDstRect = new RectF();
    private Rect mDeleteRect = new Rect();
    private Bitmap mEditBitmap;
    private RectF mEditDstRect = new RectF();
    private Rect mEditRect = new Rect();
    private RectF mHelpBoxRect = new RectF();
    private Paint mHelpPaint = new Paint();
    private Point mPoint = new Point(0, 0);
    private Bitmap mRotateBitmap;
    private RectF mRotateDstRect = new RectF();
    private Rect mRotateRect = new Rect();
    private Bitmap mScaleBitmap;
    private RectF mScaleDstRect = new RectF();
    private Rect mScaleRect = new Rect();
    private Rect mTextRect = new Rect();
    private int opacity = 255;
    private OperationListener operationListener;
    private int paddingLeft = 0;
    private int paddingRight = 0;
    private float rotateAngle;
    private float scale;
    private StaticLayout staticLayout;
    private boolean strikethrough = false;
    private String text;
    private int textHeight = 0;
    private TextPaint textPaint = new TextPaint();
    private int textWidth;
    private int totalPadding;
    private boolean underLine = false;

    public interface OperationListener {
        void onDelete(TextStickerView textStickerView);

        void onEdit(TextStickerView textStickerView);

        void onSelect(TextStickerView textStickerView);

        void onTouch(TextStickerView textStickerView);

        void onUnselect(TextStickerView textStickerView);
    }

    public TextStickerView(Context context, int i, int i2, FontProvider fontProvider) {
        super(context);
        this.context = context;
        this.fontProvider = fontProvider;
        this.canvasWidth = i;
        this.canvasHeight = i2;
        initView(context);
    }

    public TextStickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initView(context);
    }

    public TextStickerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        initView(context);
    }

    private void initView(Context context) {
        this.debugPaint.setColor(Color.parseColor("#66ff0000"));
        this.mDeleteBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.icon_delete);
        this.mEditBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.icon_edit);
        this.mRotateBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.icon_rotate);
        this.mScaleBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.icon_resize);
        this.STICKER_BTN_HALF_SIZE = this.mDeleteBitmap.getWidth() / 6;
        this.PADDING = this.STICKER_BTN_HALF_SIZE + 4;
        this.mDeleteRect.set(0, 0, this.mDeleteBitmap.getWidth(), this.mDeleteBitmap.getHeight());
        this.mEditRect.set(0, 0, this.mEditBitmap.getWidth(), this.mEditBitmap.getHeight());
        this.mRotateRect.set(0, 0, this.mRotateBitmap.getWidth(), this.mRotateBitmap.getHeight());
        this.mScaleRect.set(0, 0, this.mScaleBitmap.getWidth(), this.mScaleBitmap.getHeight());
        float f = (float) (this.STICKER_BTN_HALF_SIZE << 1);
        this.mDeleteDstRect = new RectF(0.0f, 0.0f, f, f);
        f = (float) (this.STICKER_BTN_HALF_SIZE << 1);
        this.mEditDstRect = new RectF(0.0f, 0.0f, f, f);
        f = (float) (this.STICKER_BTN_HALF_SIZE << 1);
        this.mRotateDstRect = new RectF(0.0f, 0.0f, f, f);
        f = (float) (this.STICKER_BTN_HALF_SIZE << 1);
        this.mScaleDstRect = new RectF(0.0f, 0.0f, f, f);
    }


    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.isInitLayout && !this.editText) {
            this.isInitLayout = false;
            resetView();
        }
    }


    public void onDraw(Canvas canvas) {
        if (!TextUtils.isEmpty(getText())) {
            initTextPaint();
            canvas.save();
            float f = this.scale;
            canvas.scale(f, f, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY());
            canvas.rotate(this.rotateAngle, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY());
            canvas.translate(((this.mHelpBoxRect.centerX() - ((float) (this.staticLayout.getWidth() / 2))) + ((float) (this.finalPaddingLeft / 2))) - ((float) (this.finalPaddingRight / 2)), this.mHelpBoxRect.centerY() - ((float) (this.staticLayout.getHeight() / 2)));
            this.staticLayout.draw(canvas);
            canvas.restore();
            super.onDraw(canvas);
            drawContent(canvas);
        }
    }

    private void initTextPaint() {
        this.textPaint.setShader(null);
        this.textPaint.setStyle(Style.FILL);
        this.textPaint.setTextSize(this.font.getSize() * ((float) this.canvasWidth));
        this.textPaint.setColor(this.font.getColor());
        this.textPaint.setTypeface(this.fontProvider.getTypeface(this.font.getCategory(), this.font.getTypeface()));
        if (VERSION.SDK_INT >= 21) {
            this.textPaint.setLetterSpacing(getLetterSpacing() / 10.0f);
        }
        this.textPaint.setUnderlineText(this.underLine);
        this.textPaint.setAlpha(this.opacity);
        this.textPaint.setStrikeThruText(this.strikethrough);
        this.mHelpPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
        this.mHelpPaint.setStyle(Style.STROKE);
        this.mHelpPaint.setAntiAlias(true);
        this.mHelpPaint.setStrokeWidth(1.0f);
        this.mHelpPaint.setPathEffect(new DashPathEffect(new float[]{5.0f, 20.0f}, 0.0f));
        TextPaint textPaint = this.textPaint;
        String str = this.text;
        textPaint.getTextBounds(str, 0, str.length(), this.mTextRect);
        Rect rect = this.mTextRect;
        rect.offset(this.layoutX - (rect.width() >> 1), this.layoutY);
        this.textWidth = this.mTextRect.width();
        int i = this.textWidth;
        int i2 = this.PADDING * 4;
        int i3 = i2 + i;
        int i4 = this.canvasWidth;
        if (i3 > i4) {
            i4 = (i4 - i2) / 2;
            this.finalPaddingLeft = (this.paddingLeft * i4) / 100;
            this.finalPaddingRight = (i4 * this.paddingRight) / 100;
            i = (this.mTextRect.left + this.PADDING) + ((this.textWidth - this.canvasWidth) / 2);
            i2 = (this.mTextRect.right - this.PADDING) - ((this.textWidth - this.canvasWidth) / 2);
        } else {
            i /= 2;
            this.finalPaddingLeft = (this.paddingLeft * i) / 100;
            this.finalPaddingRight = (i * this.paddingRight) / 100;
            i = this.mTextRect.left - this.PADDING;
            i2 = this.mTextRect.right + this.PADDING;
        }
        this.totalPadding = this.finalPaddingLeft + this.finalPaddingRight;
        i3 = this.totalPadding;
        i4 = i2 - i;
        if ((this.PADDING * 2) + i3 >= i4) {
            this.totalPadding = i3 - ((this.textWidth / this.text.length()) - this.PADDING);
        }
        this.staticLayout = new StaticLayout(this.text, this.textPaint, (i4 - this.totalPadding) - this.PADDING, this.align, this.lineSpacing / 10.0f, 1.0f, true);
        if (this.font.getGradient() != null) {
            this.textPaint.setShader(generateGradient());
        }
        if (this.font.getPatternPath() != null) {
            this.textPaint.setShader(generatePattern());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("textLeft: ");
        stringBuilder.append(i);
        this.mHelpBoxRect.set((float) i, (float) ((this.layoutY - (this.staticLayout.getHeight() / 2)) - this.PADDING), (float) i2, (float) ((this.layoutY + (this.staticLayout.getHeight() / 2)) + this.PADDING));
        RectUtil.scaleRect(this.mHelpBoxRect, this.scale);
    }

    private void drawContent(Canvas canvas) {
        float width = (float) (((int) this.mDeleteDstRect.width()) >> 1);
        this.mDeleteDstRect.offsetTo(this.mHelpBoxRect.left - width, this.mHelpBoxRect.top - width);
        this.mEditDstRect.offsetTo(this.mHelpBoxRect.left - width, this.mHelpBoxRect.bottom - width);
        this.mRotateDstRect.offsetTo(this.mHelpBoxRect.right - width, this.mHelpBoxRect.top - width);
        this.mScaleDstRect.offsetTo(this.mHelpBoxRect.right - width, this.mHelpBoxRect.bottom - width);
        RectUtil.rotateRect(this.mDeleteDstRect, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY(), this.rotateAngle);
        RectUtil.rotateRect(this.mEditDstRect, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY(), this.rotateAngle);
        RectUtil.rotateRect(this.mRotateDstRect, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY(), this.rotateAngle);
        RectUtil.rotateRect(this.mScaleDstRect, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY(), this.rotateAngle);
        if (this.isShowHelpBox && this.isInEdit) {
            canvas.save();
            canvas.rotate(this.rotateAngle, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY());
            canvas.drawRoundRect(this.mHelpBoxRect, 10.0f, 10.0f, this.mHelpPaint);
            canvas.restore();
            canvas.drawBitmap(this.mDeleteBitmap, this.mDeleteRect, this.mDeleteDstRect, null);
            canvas.drawBitmap(this.mEditBitmap, this.mEditRect, this.mEditDstRect, null);
            canvas.drawBitmap(this.mRotateBitmap, this.mRotateRect, this.mRotateDstRect, null);
            canvas.drawBitmap(this.mScaleBitmap, this.mScaleRect, this.mScaleDstRect, null);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        int action = motionEvent.getAction();
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        OperationListener operationListener;
        if (action != 0) {
            if (action != 1) {
                if (action == 2) {
                    int i = this.mCurrentMode;
                    if (i == 3) {
                        this.mCurrentMode = 3;
                        float f = y - this.last_y;
                        this.layoutX = (int) (((float) this.layoutX) + (x - this.last_x));
                        this.layoutY = (int) (((float) this.layoutY) + f);
                        invalidate();
                        this.last_x = x;
                        this.last_y = y;
                    } else if (i == 4) {
                        this.mCurrentMode = 4;
                        updateRotateAndScale(x - this.last_x, y - this.last_y, false);
                        invalidate();
                        this.last_x = x;
                        this.last_y = y;
                    } else if (i == 7) {
                        this.mCurrentMode = 7;
                        updateRotateAndScale(x - this.last_x, y - this.last_y, true);
                        invalidate();
                        this.last_x = x;
                        this.last_y = y;
                    }
                    operationListener = this.operationListener;
                    if (operationListener != null) {
                        operationListener.onSelect(this);
                    }
                    return true;
                } else if (action != 3) {
                    return onTouchEvent;
                }
            }
            this.mCurrentMode = 2;
            return false;
        }
        if (this.mDeleteDstRect.contains(x, y)) {
            this.isShowHelpBox = true;
            this.mCurrentMode = 5;
            operationListener = this.operationListener;
            if (operationListener != null) {
                operationListener.onDelete(this);
            }
        } else {
            if (this.mRotateDstRect.contains(x, y)) {
                this.isShowHelpBox = true;
                this.mCurrentMode = 4;
                this.last_x = this.mRotateDstRect.centerX();
                this.last_y = this.mRotateDstRect.centerY();
            } else if (this.mScaleDstRect.contains(x, y)) {
                this.isShowHelpBox = true;
                this.mCurrentMode = 7;
                this.last_x = this.mScaleDstRect.centerX();
                this.last_y = this.mScaleDstRect.centerY();
            } else if (this.mEditDstRect.contains(x, y)) {
                this.isShowHelpBox = true;
                this.mCurrentMode = 6;
                operationListener = this.operationListener;
                if (operationListener != null) {
                    operationListener.onEdit(this);
                }
                invalidate();
            } else if (detectInHelpBox(x, y)) {
                this.isShowHelpBox = true;
                this.mCurrentMode = 3;
                this.last_x = x;
                this.last_y = y;
            } else {
                this.isShowHelpBox = false;
                invalidate();
            }
            onTouchEvent = true;
        }
        if (this.mCurrentMode != 5) {
            return onTouchEvent;
        }
        this.mCurrentMode = 2;
        clearTextContent();
        invalidate();
        return onTouchEvent;
    }

    private boolean detectInHelpBox(float f, float f2) {
        this.mPoint.set((int) f, (int) f2);
        RectUtil.rotatePoint(this.mPoint, this.mHelpBoxRect.centerX(), this.mHelpBoxRect.centerY(), -this.rotateAngle);
        return this.mHelpBoxRect.contains((float) this.mPoint.x, (float) this.mPoint.y);
    }

    public void clearTextContent() {
        setText(null);
    }

    public void updateRotateAndScale(float f, float f2, boolean z) {
        float centerX = this.mHelpBoxRect.centerX();
        float centerY = this.mHelpBoxRect.centerY();
        float centerX2 = this.mRotateDstRect.centerX();
        float centerY2 = this.mRotateDstRect.centerY();
        f += centerX2;
        f2 += centerY2;
        centerX2 -= centerX;
        centerY2 -= centerY;
        f -= centerX;
        f2 -= centerY;
        centerX = (float) Math.sqrt((double) ((centerX2 * centerX2) + (centerY2 * centerY2)));
        centerY = (float) Math.sqrt((double) ((f * f) + (f2 * f2)));
        if (z) {
            centerY /= centerX;
            this.scale *= centerY;
            f = this.mHelpBoxRect.width() * this.scale;
            int i = this.canvasWidth;
            int i2 = (i * 10) / 100;
            if (f < ((float) i2) || f > ((float) (i + i2))) {
                this.scale /= centerY;
                return;
            }
            return;
        }
        double d = (double) (((centerX2 * f) + (centerY2 * f2)) / (centerX * centerY));
        if (d <= 1.0d && d >= -1.0d) {
            this.rotateAngle += ((float) ((centerX2 * f2) - (f * centerY2) > 0.0f ? 1 : -1)) * ((float) Math.toDegrees(Math.acos(d)));
        }
    }

    public void resetView() {
        this.layoutX = getMeasuredWidth() / 2;
        this.layoutY = getMeasuredHeight() / 3;
        this.rotateAngle = 0.0f;
        this.scale = 1.0f;
    }

    public boolean isShowHelpBox() {
        return this.isShowHelpBox;
    }

    public void setShowHelpBox(boolean z) {
        this.isShowHelpBox = z;
        invalidate();
    }

    public void setOperationListener(OperationListener operationListener) {
        this.operationListener = operationListener;
    }

    public void setInEdit(boolean z) {
        this.isInEdit = z;
        invalidate();
    }

    private Shader generateGradient() {
        String[] gradient = this.font.getGradient();
        TileMode tileMode = TileMode.MIRROR;
        int[] iArr = new int[gradient.length];
        for (int i = 0; i < gradient.length; i++) {
            iArr[i] = Color.parseColor(gradient[i]);
        }
        if (this.font.getGradientType().equals("Linear")) {
            Shader linearGradient;
            if (this.font.getLinearDirection().equals("Horizontal")) {
                linearGradient = new LinearGradient(0.0f, 0.0f, (float) this.staticLayout.getWidth(), 0.0f, iArr, null, tileMode);
            } else if (this.font.getLinearDirection().equals("Vertical")) {
                linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, (float) this.staticLayout.getHeight(), iArr, null, tileMode);
            }
        } else if (this.font.getGradientType().equals("Radial")) {
            return new RadialGradient((float) (this.staticLayout.getWidth() / 2), (float) (this.staticLayout.getHeight() / 2), (float) this.staticLayout.getWidth(), iArr, null, tileMode);
        } else {
            if (this.font.getGradientType().equals("Sweep")) {
                return new SweepGradient((float) (this.staticLayout.getWidth() / 2), (float) (this.staticLayout.getHeight() / 2), iArr, null);
            }
        }
        Shader shader = null;
        return shader;
    }

    private Shader generatePattern() {
        return new BitmapShader(BitmapUtil.createFitBitmap(this.font.getPatternPath(), this.canvasWidth / this.font.getPatternRepeats()), this.font.getPatternMode(), TileMode.MIRROR);
    }

    public String getText() {
        return this.text;
    }

    public void setText(String str) {
        this.text = str;
        invalidate();
    }

    public int getLayoutX() {
        return this.layoutX;
    }

    public void setLayoutX(int i) {
        this.layoutX = i;
        invalidate();
    }

    public int getLayoutY() {
        return this.layoutY;
    }

    public void setLayoutY(int i) {
        this.layoutY = i;
        invalidate();
    }

    public int getOpacity() {
        return this.opacity;
    }

    public void setOpacity(int i) {
        this.opacity = i;
        invalidate();
    }

    public float getRotateAngle() {
        return this.rotateAngle;
    }

    public void setRotateAngle(float f) {
        this.rotateAngle = f;
        invalidate();
    }

    public float getScale() {
        return this.scale;
    }

    public void setScale(float f) {
        this.scale = f;
        invalidate();
    }

    public float getLetterSpacing() {
        return this.letterSpacing;
    }

    public void setLetterSpacing(float f) {
        this.letterSpacing = f;
        invalidate();
    }

    public float getLineSpacing() {
        return this.lineSpacing;
    }

    public void setLineSpacing(float f) {
        this.lineSpacing = f;
        invalidate();
    }

    public Font getFont() {
        return this.font;
    }

    public void setFont(Font font) {
        this.font = font;
    }

    public Alignment getAlign() {
        return this.align;
    }

    public void setAlign(Alignment alignment) {
        this.align = alignment;
        invalidate();
    }

    public boolean isEditText() {
        return this.editText;
    }

    public void setEditText(boolean z) {
        this.editText = z;
        invalidate();
    }

    public boolean isUnderLine() {
        return this.underLine;
    }

    public void setUnderLine(boolean z) {
        this.underLine = z;
        invalidate();
    }

    public boolean isStrikethrough() {
        return this.strikethrough;
    }

    public void setStrikethrough(boolean z) {
        this.strikethrough = z;
        invalidate();
    }

    public int getPaddingLeft() {
        return this.paddingLeft;
    }

    public void setPaddingLeft(int i) {
        this.paddingLeft = i;
        invalidate();
    }

    public int getPaddingRight() {
        return this.paddingRight;
    }

    public void setPaddingRight(int i) {
        this.paddingRight = i;
        invalidate();
    }

    public int getTextHeight() {
        initTextPaint();
        return this.staticLayout.getHeight() + (this.PADDING * 2);
    }

    public float getTextCenterY() {
        initTextPaint();
        return this.mHelpBoxRect.centerY();
    }
}
