package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.mbit.VideoMaker.Activity.ImageSelectActivity;
import com.mbit.VideoMaker.Interface.OnItemClickListner;
import com.mbit.VideoMaker.Model.ImageInfo;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.View.CircleImageView;
import com.mbit.VideoMaker.application.MyApplication;

import java.util.ArrayList;

public class SelectedImageAdapter extends RecyclerView.Adapter<SelectedImageAdapter.MyViewHolder> {
    public MyApplication application;
    public LayoutInflater layoutInflater;
    public boolean e = false;
    public ImageSelectActivity activity;
    public Context context;
    private OnItemClickListner<Object> itemClickListner;

    public SelectedImageAdapter(Context context) {
        this.context = context;
        this.application = MyApplication.getInstance();
        this.activity = (ImageSelectActivity) context;
        this.application = MyApplication.e();
        this.layoutInflater = LayoutInflater.from(context);
    }

    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }


    @NonNull
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(this, this.layoutInflater.inflate(R.layout.recycler_selected_item_view, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final SelectedImageAdapter.MyViewHolder viewHolder, @SuppressLint("RecyclerView") final int pos) {
        viewHolder.view.setVisibility(View.VISIBLE);
        final ImageInfo imageInfo = getItem(pos);
        Glide.with(activity).load(imageInfo.getThumbbailImage()).into(viewHolder.ivThumb);
        if (IsHideRemove()) {
            viewHolder.ivRemove.setVisibility(View.GONE);
        } else {
            viewHolder.ivRemove.setVisibility(View.VISIBLE);
        }
        viewHolder.ivRemove.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                if (activity.isFromPreview) {
                    application.MinimumPosition = Math.min(application.MinimumPosition, Math.max(0, pos - 1));
                }
                if (ImageSelectActivity.isFirstImage && pos <= ImageSelectActivity.tempImage.size() && application.getSelectedImageslist().contains(ImageSelectActivity.tempImage.get(pos).ImagePath)) {
                    ImageSelectActivity.tempImage.remove(pos);
                }
                SelectedImageAdapter.this.application.removeSelectedImage(pos);
                if (SelectedImageAdapter.this.itemClickListner != null) {
                    SelectedImageAdapter.this.itemClickListner.onItemClick(v, pos);
                }
                SelectedImageAdapter.this.notifyDataSetChanged();
            }
        });
    }

    public int getItemCount() {
        final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
        return list.size();
    }


    public ImageInfo getItem(final int pos) {
        final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
        if (list.size() <= pos) {
            return new ImageInfo();
        }
        return list.get(pos);
    }


    public final boolean IsHideRemove() {
        return this.application.getSelectedImageslist().size() <= 3 && this.activity.v;
    }


    public int getItemViewType(int i) {
        super.getItemViewType(i);
        return i;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public View view;
        public ImageView ivRemove;
        public CircleImageView ivThumb;

        public MyViewHolder(SelectedImageAdapter mVar, View view) {
            super(view);
            this.view = view;
            this.ivThumb = view.findViewById(R.id.ivThumb);
            this.ivRemove = view.findViewById(R.id.ivRemove);
        }

        public void onItemClick(final View view, final Object item) {
            if (SelectedImageAdapter.this.itemClickListner != null) {
                SelectedImageAdapter.this.itemClickListner.onItemClick(view, item);
            }
        }

    }
}
