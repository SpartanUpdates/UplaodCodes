package com.xyz.vehiclemanager.car.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.CarVarianDetails.activity.CarVariantTabActivity;
import com.xyz.vehiclemanager.car.model.CarDetailsRoot;

import java.util.ArrayList;

public class CarVariantAdapter extends RecyclerView.Adapter<CarVariantAdapter.ViewHolder> {
    Context context;
    ArrayList<CarDetailsRoot.Details.Variant> carVariantlist;

    public CarVariantAdapter(Context context, ArrayList<CarDetailsRoot.Details.Variant> bikeVariantlist) {
        this.context = context;
        this.carVariantlist = bikeVariantlist;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tv_variantName, tv_transmissiontype, tv_fuelType, tv_engine, tv_variantPrice;
        LinearLayout ll_main;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_variantName = itemView.findViewById(R.id.tv_variantName);
            tv_transmissiontype = itemView.findViewById(R.id.tv_transmissionType);
            tv_fuelType = itemView.findViewById(R.id.tv_fuelType);
            tv_engine = itemView.findViewById(R.id.tv_engine);
            tv_variantPrice = itemView.findViewById(R.id.tv_variantPrice);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.layout_carvariant, parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CarDetailsRoot.Details.Variant carVarient = carVariantlist.get(position);
        holder.tv_variantName.setText(carVarient.getVariantName());
        holder.tv_transmissiontype.setText(carVarient.getTransmissionType());
        holder.tv_fuelType.setText(carVarient.getFuelType());
        holder.tv_engine.setText(carVarient.getEngineDisplacement());
        holder.tv_variantPrice.setText(carVarient.getVariantPrice());

        final String id= String.valueOf(carVarient.getId());

        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CarVariantTabActivity.class);
                intent.putExtra("VarientId",id);
                intent.putExtra("VarientName", carVarient.getVariantName());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carVariantlist.size();
    }
}
