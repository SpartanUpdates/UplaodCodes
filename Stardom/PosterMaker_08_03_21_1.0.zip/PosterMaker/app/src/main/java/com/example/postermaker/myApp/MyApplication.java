package com.example.postermaker.myApp;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.StrictMode;

import com.example.postermaker.OpenAds.AppOpenManager;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyApplication extends Application {

    private static com.example.postermaker.myApp.MyApplication mInstance;
    private static Context context;
    private ExecutorService executorService = Executors.newCachedThreadPool();

    AppOpenManager appOpenManager;

    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
        if (Build.VERSION.SDK_INT >= 24) {
            final StrictMode.VmPolicy.Builder strictModeVmPolicyBuilder = new StrictMode.VmPolicy.Builder();
            strictModeVmPolicyBuilder.detectFileUriExposure();
            StrictMode.setVmPolicy(strictModeVmPolicyBuilder.build());
        }
    }

    public ExecutorService getExecutorService() {
        return this.executorService;
    }

    public static com.example.postermaker.myApp.MyApplication getApplication() {
        return mInstance;
    }

    public static final String TAG = com.example.postermaker.myApp.MyApplication.class.getSimpleName();


    public static Context getContext() {
        return context;
    }

    public static synchronized com.example.postermaker.myApp.MyApplication getInstance() {
        return mInstance;
    }

}
