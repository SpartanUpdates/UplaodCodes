package com.kotlinz.photoslideshow.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.kotlinz.photoslideshow.R;
import com.kotlinz.photoslideshow.activity.videoPlay;
import com.kotlinz.photoslideshow.data.VideoData;
import com.kotlinz.photoslideshow.util.ActivityAnimUtil;
import com.kotlinz.photoslideshow.video.FileUtils;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;

public class AllVideoAlbumAdapter extends Adapter<AllVideoAlbumAdapter.Holder> {
    public static ArrayList<VideoData> mVideoDatas;
    private Context mContext;
    View view;


    public class Holder extends ViewHolder {
        private ImageView ivPreview;
        private ImageView ivShare, ivDelete;
        private TextView tvDuration;
        private TextView tvFileName;
        private TextView tvVideoDate;
        private RelativeLayout rlPlayVideo;

        public Holder(View view) {
            super(view);
            this.ivPreview = view.findViewById(R.id.Video_thumb);
            this.tvDuration = view.findViewById(R.id.list_item_video_duration);
            this.tvFileName = view.findViewById(R.id.list_item_video_title);
            this.tvVideoDate = view.findViewById(R.id.list_item_video_date);
            this.rlPlayVideo = view.findViewById(R.id.list_item_published_video_info_container);
            this.ivShare = view.findViewById(R.id.ivShare);
            this.ivDelete = view.findViewById(R.id.ivDelete);
        }
    }


    public AllVideoAlbumAdapter(Context context, ArrayList<VideoData> arrayList) {
        mVideoDatas = arrayList;
        this.mContext = context;
    }

    public int getItemCount() {
        return mVideoDatas.size();
    }

    public void onBindViewHolder(Holder holder, final int i) {
        holder.tvDuration.setText(FileUtils.getDuration(mVideoDatas.get(i).videoDuration));
        Glide.with(this.mContext).load(mVideoDatas.get(i).videoFullPath).into(holder.ivPreview);
        TextView access$200 = holder.tvFileName;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(mVideoDatas.get(i).videoName);
        stringBuilder.append(".mp4");
        access$200.setText(stringBuilder.toString());
        holder.tvVideoDate.setText(DateFormat.getDateInstance().format(Long.valueOf(mVideoDatas.get(i).dateTaken)));
        holder.tvDuration.setVisibility(View.INVISIBLE);
        holder.tvFileName.setVisibility(View.INVISIBLE);
        holder.tvVideoDate.setVisibility(View.INVISIBLE);
        holder.rlPlayVideo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AllVideoAlbumAdapter.this.id = i;
                AllVideoAlbumAdapter.this.view = view;
                AllVideoAlbumAdapter.this.loadVideoPlayer(view);
            }
        });
        holder.ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final File file = new File(AllVideoAlbumAdapter.mVideoDatas.get(i).videoFullPath);
                final Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/*");
                intent.putExtra("android.intent.extra.SUBJECT", AllVideoAlbumAdapter.mVideoDatas.get(i).videoName);
                intent.putExtra("android.intent.extra.TITLE", AllVideoAlbumAdapter.mVideoDatas.get(i).videoName);
                final Uri ShareUri = FileProvider.getUriForFile(mContext, String.valueOf(mContext.getPackageName()) + ".provider", file);
                intent.putExtra("android.intent.extra.STREAM", ShareUri);
                AllVideoAlbumAdapter.this.mContext.startActivity(Intent.createChooser(intent, "Share Video"));
            }
        });
        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(AllVideoAlbumAdapter.this.mContext, R.style.Theme_MovieMaker_AlertDialog);
                alertDialog$Builder.setTitle(R.string.delete_video_);
                final StringBuilder sb = new StringBuilder();
                sb.append(AllVideoAlbumAdapter.this.mContext.getResources().getString(R.string.are_you_sure_to_delete_));
                sb.append(AllVideoAlbumAdapter.mVideoDatas.get(i).videoName);
                sb.append(".mp4 ?");
                alertDialog$Builder.setMessage(sb.toString());
                alertDialog$Builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialogInterface, final int n) {
                        FileUtils.deleteFile(new File(AllVideoAlbumAdapter.mVideoDatas.remove(i).videoFullPath));
                        AllVideoAlbumAdapter.this.notifyDataSetChanged();
                    }
                });
                alertDialog$Builder.setNegativeButton("Cancel", null);
                alertDialog$Builder.show();
            }
        });
    }


    private int id;

    private void loadVideoPlayer(View view) {
        Intent intent = new Intent(this.mContext, videoPlay.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("KEY", "FromVideoAlbum");
        intent.putExtra("android.intent.extra.TEXT", mVideoDatas.get(this.id).videoFullPath);
        intent.putExtra(this.mContext.getResources().getString(R.string.video_position_key), this.id);
        ActivityAnimUtil.startActivitySafely(view, intent);
    }

    @NonNull
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(this.mContext).inflate(R.layout.list_item_published_video, viewGroup, false));
    }

}
