package com.wavymusic.mp3Cutter.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.wavymusic.mp3Cutter.Fragment.SongCropFragment;
import com.wavymusic.mp3Cutter.Model.SongCropModel;
import com.wavymusic.mp3Cutter.activity.SongCropActivity;
import com.wavymusic.mp3Cutter.view.PlayMusicControllerView;
import com.wavymusic.R;
import com.wavymusic.WidgetView.Indicator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SongCropAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements PlayMusicControllerView.a {
    SongCropFragment fragment;
    List<SongCropModel> songCropList;
    Context context;
    public SongCropActivity ActivityofSongCrop;
    private Glide glide;
    public MyViewHolder viewHolder;

    public SongCropAdapter(final SongCropFragment SongCropFragment, final Context context, List<SongCropModel> songCroplist) {
        this.fragment = SongCropFragment;
        this.context = context;
        ActivityofSongCrop= (SongCropActivity) context;
        this.songCropList = songCroplist;
        String s;
        if (this.fragment == null) {
            s = "mFragment == null";
        } else {
            s = "mFragment != null";
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("FRG = ");
        sb.append(s);
        Log.e("EPEP", sb.toString());
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("ID = ");
        sb2.append(this.fragment.getFolderid());
        Log.e("EPEP", sb2.toString());
        glide = Glide.get(ActivityofSongCrop);
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public long A;
        public PlayMusicControllerView playMusicControllerView;
        public Indicator indicator;
        public long D = 0;
        protected TextView tvMusicName;
        protected TextView tvUseMusic;
        protected TextView tvMusicEndTime;
        protected ImageView Imagecontent;
        protected LinearLayout Imagelayout;
        ImageView IvPopularPlayPause;
        RelativeLayout rlcuttermain;
        TextView tvendtime;
        public TextView tvplaytime;
        public long z;

        @SuppressLint("ClickableViewAccessibility")
        public MyViewHolder(View view) {
            super(view);
            tvMusicName = view.findViewById(R.id.tvMusicName);
            tvUseMusic = view.findViewById(R.id.tvUseMusic);
            rlcuttermain = view.findViewById(R.id.rl_cuttor_main);
            tvMusicEndTime = view.findViewById(R.id.tvMusicEndTime);
            Imagecontent = view.findViewById(R.id.image_content);
            Imagelayout = view.findViewById(R.id.image_layout);
            IvPopularPlayPause= view.findViewById(R.id.ivPopularPlayPause);
            tvendtime = view.findViewById(R.id.txt_end_time);
            tvplaytime= view.findViewById(R.id.txt_play_time);
            playMusicControllerView = view.findViewById(R.id.music_controller_view);
            indicator = view.findViewById(R.id.indicator);
            playMusicControllerView.setOnTouchListener(new View.OnTouchListener() {
                /* class com.example.videostatus.mp3cutter.a.a.b.AnonymousClass1 */

                public boolean onTouch(View view, MotionEvent motionEvent) {
                    switch (motionEvent.getAction()) {
                        case 0:
                        case 1:
                            view.getParent().requestDisallowInterceptTouchEvent(true);
                            break;
                    }
                    view.onTouchEvent(motionEvent);
                    return true;
                }
            });
        }
    }


    private void a(MyViewHolder myViewHolder, final long j2) {
        viewHolder = myViewHolder;
        viewHolder.rlcuttermain.setVisibility(View.VISIBLE);
        viewHolder.playMusicControllerView.setOnMusicPlayControllerListener(this);
        viewHolder.Imagelayout.setBackgroundColor(ActivityofSongCrop.getResources().getColor(R.color.crop_audio_bg_color));
        viewHolder.tvUseMusic.setBackground(context.getResources().getDrawable(R.drawable.bg_song_phone_use_noraml));
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            /* class com.example.videostatus.mp3cutter.a.a.AnonymousClass4 */

            public void run() {
                PlayMusicControllerView playMusicControllerView = SongCropAdapter.this.viewHolder.playMusicControllerView;
                long j = j2;
                playMusicControllerView.a(j, j);
            }
        }, 100);
        ActivityofSongCrop.r = false;
        handler.postDelayed(new Runnable() {

            public void run() {
                SongCropAdapter.this.ActivityofSongCrop.a(SongCropAdapter.this.viewHolder);
                com.wavymusic.mp3Cutter.Adapter.SongCropAdapter.this.ActivityofSongCrop.a(SongCropAdapter.this.viewHolder);
            }
        }, 1025);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_audio_crop_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        final MyViewHolder viewholder = (MyViewHolder) holder;
        final SongCropModel songCropModel = this.songCropList.get(position);
        viewholder.D = songCropModel.g();
        viewholder.tvMusicEndTime.setText(getTimeDuration(songCropModel.g()));
//        if (songCropModel.b()) {
//            textView = viewholder.tvMusicName;
//            str = "Search";
//        } else {
//            textView = viewholder.tvMusicName;
//            str = songCropModel.f();
//        }
        viewholder.tvMusicName.setText(songCropModel.f());
//        Log.e("TAG", "SongName" + songCropModel.f());
        if (!songCropModel.b()) {
            if (SongCropActivity.k != songCropList.get(position).c()) {
                viewholder.Imagecontent.setSelected(false);
                viewholder.rlcuttermain.setVisibility(View.GONE);
                viewholder.Imagelayout.setBackgroundColor(ActivityofSongCrop.getResources().getColor(R.color.app_main_bg_color));
                Log.e("TAG", "setSelected(false)");
                viewholder.tvUseMusic.setBackground(context.getResources().getDrawable(R.drawable.bg_song_phone_use_noraml));
                viewholder.tvUseMusic.setText("Cut");
                viewholder.tvUseMusic.setSelected(false);
                viewholder.indicator.setVisibility(View.GONE);
                viewholder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
                viewholder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
            } else {
                Log.e("TAG", "setSelected(true)");
                viewholder.tvUseMusic.setBackground(context.getResources().getDrawable(R.drawable.bg_song_phone_use_selected));
                viewholder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_pause);
                viewholder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
                viewholder.Imagecontent.setSelected(true);
                viewholder.rlcuttermain.setVisibility(View.GONE);
                viewholder.tvUseMusic.setText("Save");
                viewholder.tvUseMusic.setSelected(true);
                viewholder.indicator.setVisibility(View.VISIBLE);
                viewholder.Imagelayout.setBackgroundColor(ActivityofSongCrop.getResources().getColor(R.color.card_bg_color));
                a(viewholder, songCropModel.g());
            }
        }
        viewholder.tvUseMusic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!viewholder.tvUseMusic.isSelected()) {
                   ActivityofSongCrop.LayoutDataChnage();
                   ActivityofSongCrop.a(songCropList.get(position), position);
                    notifyDataSetChanged();
                } else if (viewholder.z == 0 && viewholder.A == viewholder.D) {
                    Toast.makeText(context, "Please select some song portion.", Toast.LENGTH_SHORT).show();
                } else {
                    viewholder.tvUseMusic.setEnabled(false);
                    ActivityofSongCrop.a(songCropModel.e(), songCropModel.f(), viewholder.z, viewholder.A);
                    new Handler().postDelayed(new Runnable() {

                        public void run() {
                            viewholder.tvUseMusic.setEnabled(true);
                        }
                    }, 1000);
                }
            }
        });
        viewholder.Imagelayout.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int Songcolor;
                Drawable drawable;
                Resources resources;
                Drawable drawable2;
                Drawable drawable3;
                if (!songCropModel.b()) {
                    if (viewholder.Imagecontent.isSelected()) {
                        ActivityofSongCrop.t();
                        if (ActivityofSongCrop.isSongPlay()) {
                            viewholder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_pause);
                            viewholder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
                            if (SongCropAdapter.this.viewHolder.z == 0 && SongCropAdapter.this.viewHolder.A == SongCropAdapter.this.viewHolder.D) {
                                drawable3 = context.getResources().getDrawable(R.drawable.bg_song_phone_use_noraml);
                            } else {
                                drawable3 = context.getResources().getDrawable(R.drawable.bg_song_phone_use_selected);
                            }
                            viewholder.tvUseMusic.setBackground(drawable3);
                            viewholder.tvUseMusic.setText("Save");
                            viewholder.rlcuttermain.setVisibility(View.VISIBLE);
                            resources = ActivityofSongCrop.getResources();
                            Songcolor = R.color.crop_audio_bg_color;
                        } else {
                            viewholder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
                            viewholder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
                            if (SongCropAdapter.this.viewHolder.z == 0 && SongCropAdapter.this.viewHolder.A == SongCropAdapter.this.viewHolder.D) {
                                drawable2 = context.getResources().getDrawable(R.drawable.bg_song_phone_use_noraml);
                            } else {
                                drawable2 = context.getResources().getDrawable(R.drawable.bg_song_phone_use_selected);
                            }
                            viewholder.tvUseMusic.setBackground(drawable2);
                            viewholder.tvUseMusic.setText("Cut");
                            viewholder.tvUseMusic.setSelected(false);
                            viewholder.indicator.setVisibility(View.GONE);
                            viewholder.rlcuttermain.setVisibility(View.GONE);
                            resources = ActivityofSongCrop.getResources();
                            Songcolor = R.color.app_main_bg_color;
                        }
                        viewholder.Imagelayout.setBackgroundColor(resources.getColor(Songcolor));
                        return;
                    }
                    viewholder.Imagecontent.setSelected(true);
                    if (SongCropActivity.m == SongCropAdapter.this.fragment.getTabIndex()) {
                        if (SongCropActivity.n == position) {
                            viewholder.Imagecontent.setSelected(true);
                            if (SongCropAdapter.this.viewHolder.z == 0 && SongCropAdapter.this.viewHolder.A == SongCropAdapter.this.viewHolder.D) {
                                drawable = context.getResources().getDrawable(R.drawable.bg_song_phone_use_noraml);
                            } else {
                                drawable = context.getResources().getDrawable(R.drawable.bg_song_phone_use_selected);
                            }
                            viewholder.tvUseMusic.setBackground(drawable);
                            viewholder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
                            viewholder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
                            viewholder.tvUseMusic.setText("Save");
                            viewholder.tvUseMusic.setSelected(true);
                            viewholder.indicator.setVisibility(View.VISIBLE);
                            return;
                        }
                    }
                    ActivityofSongCrop.LayoutDataChnage();
                    ActivityofSongCrop.a(songCropList.get(position), position);
                    notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return songCropList.size();

    }

    @Override
    public void a(long j2) {
        int drawable;
        if (viewHolder != null) {
            viewHolder.A = j2;
            viewHolder.tvendtime.setText(getTimeDuration(j2));
            if (this.viewHolder.z == 0 && this.viewHolder.A == this.viewHolder.D) {
                drawable = R.drawable.bg_song_phone_use_noraml;
            } else {
                drawable = R.drawable.bg_song_phone_use_selected;
            }
            viewHolder.tvUseMusic.setBackground(context.getResources().getDrawable(drawable));
        }
    }

    @Override
    public void b(long n) {
        final MyViewHolder l = this.viewHolder;
        if (l != null) {
            l.z = n;
            ActivityofSongCrop.s = n;
            final StringBuilder sb = new StringBuilder();
            sb.append(getTimeDuration(n));
            sb.append(" - ");
            viewHolder.tvplaytime.setText(sb.toString());
            int drawable;
            if (this.viewHolder.z == 0L && this.viewHolder.A == this.viewHolder.D) {
                drawable = R.drawable.bg_song_phone_use_noraml;
            }
            else {
                drawable = R.drawable.bg_song_phone_use_selected;
            }
            viewHolder.tvUseMusic.setBackground(context.getResources().getDrawable(drawable));
        }
    }

    @SuppressLint("DefaultLocale")
    public String getTimeDuration(long j2) {
        return String.format("%02d:%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toHours(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }


    @Override
    public void t() {
        if (viewHolder != null) {
            ActivityofSongCrop.s = viewHolder.z;
            ActivityofSongCrop.v();
        }
    }

    @Override
    public void u() {
        if (this.viewHolder != null) {
            ActivityofSongCrop.u();
        }
    }

}
