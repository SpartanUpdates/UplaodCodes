package com.kotlinz.videoCollage.flying.poiphoto;

import android.os.AsyncTask;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import java.util.List;

public class GetAllVideoTask extends AsyncTask<VideoManager, Integer, List<Video>> {
    private static final String TAG = "GetAllPhotoTask";


    public List<Video> doInBackground(VideoManager... videoManagerArr) {
        return videoManagerArr[0].getAllVideo();
    }
}
