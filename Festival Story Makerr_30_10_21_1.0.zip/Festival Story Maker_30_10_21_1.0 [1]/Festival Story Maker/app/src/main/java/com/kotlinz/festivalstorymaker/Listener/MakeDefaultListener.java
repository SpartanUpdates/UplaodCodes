package com.kotlinz.festivalstorymaker.Listener;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;


public class MakeDefaultListener implements View.OnClickListener
{
    public final int e;
    public final SelectLogoAdapter f;

    public MakeDefaultListener(final SelectLogoAdapter f, final int e) {
        this.f = f;
        this.e = e;
    }

    public void onClick(final View view) {
        this.f.logoInterface.u(this.e, 0);
    }
}
