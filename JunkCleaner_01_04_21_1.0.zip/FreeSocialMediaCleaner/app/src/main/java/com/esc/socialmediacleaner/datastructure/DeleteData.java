package com.esc.socialmediacleaner.datastructure;

import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import com.esc.socialmediacleaner.util.MediaUtil;
import java.io.File;
import java.util.ArrayList;

public class DeleteData extends AsyncTask<String, Integer, String> {
    private Context context;
    private ArrayList<FileDataWrapper> dataList;

    public DeleteData(Context context, ArrayList<FileDataWrapper> arrayList) {
        this.context = context;
        this.dataList = arrayList;
    }

    public void onPreExecute() {
        super.onPreExecute();
    }

    public void onProgressUpdate(Integer... numArr) {
        super.onProgressUpdate(numArr);
    }

    private boolean isDeleted(File file) {
        if (!file.exists()) {
            return true;
        }
        file.delete();
        return file.exists();
    }

    public String doInBackground(String... strArr) {
        try {
            int size = this.dataList.size();
            int i = 0;
            while (i < size) {
                FileDataWrapper fileDataWrapper = (FileDataWrapper) this.dataList.get(i);
                if (fileDataWrapper.ischecked && isDeleted(new File(fileDataWrapper.path))) {
                    sendDeleteBroadcast(new File(fileDataWrapper.path));
                    this.dataList.remove(i);
                    size--;
                } else {
                    i++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void sendDeleteBroadcast(File file) {
        if (FileUtil.isKitKat()) {
            Uri uriFromFile = MediaUtil.getUriFromFile(this.context, file.getAbsolutePath());
            if (uriFromFile != null) {
                this.context.getContentResolver().delete(uriFromFile, null, null);
            }
        } else if (FileUtil.isSystemAndroid5()) {
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(file));
            this.context.sendBroadcast(intent);
        } else {
            MediaScannerConnection.scanFile(this.context, new String[]{file.getAbsolutePath()}, null, null);
        }
    }
}
