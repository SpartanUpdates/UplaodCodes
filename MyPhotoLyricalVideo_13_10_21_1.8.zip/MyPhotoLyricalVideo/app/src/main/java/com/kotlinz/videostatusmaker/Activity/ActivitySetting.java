package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;

import com.kotlinz.videostatusmaker.Utils.AppPreferences;

import org.jetbrains.annotations.NotNull;

public class ActivitySetting extends AppCompatActivity {
    Activity activity = ActivitySetting.this;
    ImageView ivBack;
    ImageView imgAllCap;
    LinearLayout linearLayout;
    AppPreferences appPreferences;
    TextView tvTitle;
    TextView txtAllcap;
    int width;
    Typeface typeface;
    int height;

    GGAdview gg_banner;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_setting);
        this.appPreferences = new AppPreferences(this);
        getWindow().addFlags(1024);
        PutAnalyticsEvent();
        BannerAds();
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.height = getResources().getDisplayMetrics().heightPixels;
        this.linearLayout = (LinearLayout) findViewById(R.id.lay1);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.imgAllCap = (ImageView) findViewById(R.id.img_all_cap);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.txtAllcap = (TextView) findViewById(R.id.txt_allcap);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.txtAllcap.setTypeface(this.typeface);
        check();
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        this.linearLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityPreview.complete = false;
                if (ActivitySetting.this.appPreferences.get_ALL_CAPS()) {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(false);
                } else {
                    ActivitySetting.this.appPreferences.set_ALL_CAPS(true);
                }
                ActivitySetting.this.check();
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySetting");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    void check() {
        if (this.appPreferences.get_ALL_CAPS()) {
            this.imgAllCap.setImageResource(R.drawable.toggle1_on);
        } else {
            this.imgAllCap.setImageResource(R.drawable.toggle1_off);
        }
    }
}
