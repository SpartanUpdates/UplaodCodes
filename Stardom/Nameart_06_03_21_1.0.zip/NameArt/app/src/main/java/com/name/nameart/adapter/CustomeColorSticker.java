package com.name.nameart.adapter;

import android.content.Context;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.internal.view.SupportMenu;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.FavDesign.NameEditing;
import com.name.nameart.R;
import com.name.nameart.sticker.StickerView;


public class CustomeColorSticker extends RecyclerView.Adapter<CustomeColorSticker.ViewHolder> {
    public final int[] colorarray;
    Context context;
    ColorFilter filter;
    int index = -1;
    boolean z = true;

    public CustomeColorSticker(Context context2) {
        this.context = context2;
        this.colorarray = context2.getResources().getIntArray(R.array.allcolors);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custome_color_sticker, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i)
    {
        try
        {
            viewHolder.color_img_row.setImageDrawable(null);
            viewHolder.color_img_row.setBackgroundColor(this.colorarray[i]);
            this.filter = new PorterDuffColorFilter(SupportMenu.CATEGORY_MASK, PorterDuff.Mode.SRC_IN);

            viewHolder.color_img_row.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    CustomeColorSticker.this.index = i;
                    CustomeColorSticker.this.notifyDataSetChanged();
                    int i = 0;
                    while (true) {
                        if (CustomeColorSticker.this.z) {
                            if (i < NameEditing.contain_sticker.getChildCount()) {
                                if ((NameEditing.contain_sticker.getChildAt(i) instanceof StickerView) && ((StickerView) NameEditing.contain_sticker.getChildAt(i)).getEditMode()) {
                                    StickerAdapter.mCurrentView.recolor(CustomeColorSticker.this.colorarray[i]);
                                    z = true;
                                    break;
                                }
                                i++;
                            } else {
                                    z = false;
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                    if (!CustomeColorSticker.this.z) {
                        Toast.makeText(CustomeColorSticker.this.context, "Please Add or Select Sticker", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            if (this.index == i) {
                viewHolder.row_bg.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.row_bg.setBackgroundColor(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.colorarray.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView color_img_row;
        public View parentLayout;
        public ConstraintLayout row_bg;

        public ViewHolder(View view) {
            super(view);
            this.color_img_row = (ImageView) view.findViewById(R.id.color_img_row);
            this.row_bg = (ConstraintLayout) view.findViewById(R.id.row_bg);
        }

        public ImageView getImage() {
            return this.color_img_row;
        }
    }

}
