package com.kotlinz.videoCollage.fragments;

import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Video.Media;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.SelectActivity;
import com.kotlinz.videoCollage.ShareActivity;
import com.kotlinz.videoCollage.adpaters.MyAlbumVideoAdapter;
import com.kotlinz.videoCollage.interfaces.MyAlbumVideoAdapterCallBackInterface;
import com.kotlinz.videoCollage.models.Videos;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.FileUtils;
import com.kotlinz.videoeditor.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class MyAlbumVideosFragment extends Fragment {
    private MyAlbumVideoAdapter adapter;
    private ImageView create;
    private LinearLayout lineEmpty;
    private LinearLayout mainLinear;
    private Context myContext;
    private ArrayList<Videos> videoPaths = new ArrayList();
    private RecyclerView videoRecycler;

    public MyAlbumVideosFragment(Context context) {
        this.myContext = context;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.my_album_fragment_video, viewGroup, false);
        this.mainLinear = (LinearLayout) inflate.findViewById(R.id.myalbum_main_lin);
        this.videoRecycler = (RecyclerView) inflate.findViewById(R.id.myalbum_video_list);
        this.lineEmpty = (LinearLayout) inflate.findViewById(R.id.myalbum_line_empty);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.img_album_create);
        this.create = imageView;
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumVideosFragment.this.startActivity(new Intent(MyAlbumVideosFragment.this.myContext, SelectActivity.class));
            }
        });
        Context context = getContext();
        this.myContext = context;
        getCreationFiles(FileUtils.getFolderName(context, "Video"));
        this.videoRecycler.setLayoutManager(new GridLayoutManager(this.myContext, 2));
        MyAlbumVideoAdapter myAlbumVideoAdapter = new MyAlbumVideoAdapter(this.myContext, this.videoPaths, new MyAlbumVideoAdapterCallBackInterface() {
            public void itemClick(int i, String str) {
                Util.selectedTab = 1;
                Intent intent = new Intent(MyAlbumVideosFragment.this.myContext, ShareActivity.class);
                intent.putExtra("SELECTED_PATH", str);
                intent.putExtra("FROM", "MY ALBUM");
                MyAlbumVideosFragment.this.startActivity(intent);
            }

            public void itemShare(int i, String str) {
                MyAlbumVideosFragment.this.shareImage(str);
            }

            public void itemDelete(int i, String str) {
                MyAlbumVideosFragment.this.deleteConfirmationDialog(i, str);
            }
        });
        this.adapter = myAlbumVideoAdapter;
        this.videoRecycler.setAdapter(myAlbumVideoAdapter);
        if (this.videoPaths.size() <= 0) {
            this.videoRecycler.setVisibility(View.GONE);
            this.lineEmpty.setVisibility(View.VISIBLE);
        } else {
            this.videoRecycler.setVisibility(View.VISIBLE);
            this.lineEmpty.setVisibility(View.GONE);
        }
        return inflate;
    }

    public void getCreationFiles(String str) {
        File[] listFiles = new File(str).listFiles();
        if (listFiles != null && listFiles.length > 1) {
            Collections.sort(Arrays.asList(listFiles), new Comparator<File>() {
                public int compare(File file, File file2) {
                    long lastModified = file.lastModified();
                    long lastModified2 = file2.lastModified();
                    if (lastModified2 < lastModified) {
                        return -1;
                    }
                    return lastModified > lastModified2 ? 1 : 0;
                }
            });
        }
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                Videos videos = new Videos();
                videos.setPath(listFiles[i].getPath());
                videos.setChecked(false);
                if (videoFileIsCorrupted(listFiles[i].getPath())) {
                    this.videoPaths.add(videos);
                } else {
                    File file = new File(listFiles[i].getPath());
                    if (file.exists()) {
                        file.delete();
                    }
                }
            }
        }
    }

    private boolean videoFileIsCorrupted(String str) {
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            mediaMetadataRetriever.setDataSource(this.myContext, Uri.parse(str));
            return "yes".equals(mediaMetadataRetriever.extractMetadata(17));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void deleteConfirmationDialog(final int i, final String str) {
        String str2 = "No";
        new Builder(this.myContext).setMessage("Do you want to delete?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                if (new File(str).exists()) {
                    MyAlbumVideosFragment.this.videoPaths.remove(i);
                    if (MyAlbumVideosFragment.this.videoPaths.size() <= 0) {
                        MyAlbumVideosFragment.this.videoRecycler.setVisibility(View.GONE);
                        MyAlbumVideosFragment.this.lineEmpty.setVisibility(View.VISIBLE);
                    } else {
                        MyAlbumVideosFragment.this.videoRecycler.setVisibility(View.VISIBLE);
                        MyAlbumVideosFragment.this.lineEmpty.setVisibility(View.GONE);
                    }
                    MyAlbumVideosFragment.this.adapter.notifyDataSetChanged();
                    String str = "_id";
                    String[] strArr = new String[]{str};
                    String[] strArr2 = new String[]{str};
                    Uri uri = Media.EXTERNAL_CONTENT_URI;
                    ContentResolver contentResolver = MyAlbumVideosFragment.this.getActivity().getContentResolver();
                    Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
                    if (query != null) {
                        String str2 = "test";
                        if (query.moveToFirst()) {
                            contentResolver.delete(ContentUris.withAppendedId(uri, query.getLong(query.getColumnIndexOrThrow(str))), null, null);
                            Log.e(str2, " file deleted...");
                        } else {
                            Log.e(str2, " file not deleted or not found...");
                        }
                        query.close();
                    }
                }
            }
        }).setNegativeButton(str2, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    private void shareImage(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", "Video Maker");
        intent.setType("video/*");
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this.myContext, "com.esc.videoeditoo.provider", new File(str)));
        startActivity(Intent.createChooser(intent, "Where to Share?"));
    }
}
