package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoquestion.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;

public class ExamPassActivity extends AppCompatActivity {
    private TextView yourScore, rightAns, wrongAns, questionAttended, title_tv, yourScore_text, questionAttended_text, rightAns_text, wrongAns_text;
    private LinearLayout ll_mainLayout;
    private ImageView back_iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam_pass);
        bindView();

        int rA = Integer.parseInt(getIntent().getStringExtra("rightAns"));
        int wA = Integer.parseInt(getIntent().getStringExtra("wrongAns"));

        yourScore.setText(getIntent().getStringExtra("yourScore"));
        rightAns.setText(getIntent().getStringExtra("rightAns"));
        wrongAns.setText(getIntent().getStringExtra("wrongAns"));
        questionAttended.setText(String.valueOf(rA + wA));

        DarkTheame darkTheame = new DarkTheame(ExamPassActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
                setupDarkMode();
            }
        }

        back_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void setupDarkMode() {
        ll_mainLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        yourScore_text.setTextColor(Color.parseColor("#FFFFFF"));
        questionAttended_text.setTextColor(Color.parseColor("#c1c1c1"));
        rightAns_text.setTextColor(Color.parseColor("#c1c1c1"));
        wrongAns_text.setTextColor(Color.parseColor("#c1c1c1"));
        questionAttended.setTextColor(Color.parseColor("#c1c1c1"));
        rightAns.setTextColor(Color.parseColor("#c1c1c1"));
        wrongAns.setTextColor(Color.parseColor("#c1c1c1"));
    }

    private void bindView() {
        yourScore = findViewById(R.id.yourScore);
        rightAns = findViewById(R.id.rightAns);
        wrongAns = findViewById(R.id.wrongAns);
        questionAttended = findViewById(R.id.questionAttended);
        ll_mainLayout = findViewById(R.id.ll_main_layout);
        title_tv = findViewById(R.id.title_tv);
        back_iv = findViewById(R.id.iv_back);
        yourScore_text = findViewById(R.id.yourScore_text);
        questionAttended_text = findViewById(R.id.questionAttend_text);
        rightAns_text = findViewById(R.id.rightAnswer_text);
        wrongAns_text = findViewById(R.id.wrongAnswer_text);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ExamPassActivity.this, MainActivity.class));
        finish();
        super.onBackPressed();
    }
}