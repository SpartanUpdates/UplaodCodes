package com.kotlinz.festivalstorymaker.AppUtils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;

public class Utils {
    public static final Utils INSTANCE;
    public static long mDeleteFileCount;
    static {
        INSTANCE = new Utils();
        Utils.mDeleteFileCount = 0L;
    }

    public static void CreateDirectory() {
      /*  try {
            String rootPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/Festival Story Maker /";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    public final String getAPPFOLDER() {
        return "Festival Story Maker";
    }

    public final String getOutputPath() {
        final String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath() {
        final String path = this.getOutputPath() + "ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }


    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }


}
