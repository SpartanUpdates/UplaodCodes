﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MenuEditor : MonoBehaviour
{
    [MenuItem("DJ Tool/Clear PlayerPrefs")]
    static void DoSomething()
    {
        PlayerPrefs.DeleteAll();
    }
}
