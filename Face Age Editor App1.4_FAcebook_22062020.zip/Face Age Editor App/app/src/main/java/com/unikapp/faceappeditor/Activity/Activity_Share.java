package com.unikapp.faceappeditor.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
//import android.support.v4.content.FileProvider;
//import android.support.v7.app.AppCompatActivity;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.squareup.picasso.Picasso;
import com.unikapp.faceage.editorapp.R;

import java.io.File;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import static com.unikapp.faceappeditor.Utils.nativeadsmethod.populateUnifiedNativeAdViewSmall;

public class Activity_Share extends AppCompatActivity implements OnClickListener {

    private ImageView imgFinalImg_act_share;
    private LinearLayout llFacebook_act_share;
    private LinearLayout llInstagram_act_share;
    private LinearLayout llShareMore_act_share;
    private LinearLayout llWhatsapp_act_share;
    private String pathSaved_act_save;
    private ImageView ic_back, ic_home;
    private int id;
    public InterstitialAd fbinterstitialAd;

    private void clickEvent() {
        llWhatsapp_act_share.setOnClickListener(this);
        llFacebook_act_share.setOnClickListener(this);
        llInstagram_act_share.setOnClickListener(this);
        llShareMore_act_share.setOnClickListener(this);
        ic_home.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
                    id = 201;
                    fbinterstitialAd.show();
                } else {
                    directHome();
                }
            }
        });
        ic_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_share);
        bindview();
        clickEvent();
        loadAd();
        LoadfbInterstitialAds();
    }

    //    private UnifiedNativeAd nativeAd;
    private NativeBannerAd mNativeBannerAd;

    private void loadAd() {
//        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
//        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
//            @Override
//            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
//                if (nativeAd != null) {
//                    nativeAd.destroy();
//                }
//                nativeAd = unifiedNativeAd;
//                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
//                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
//                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
//                populateUnifiedNativeAdViewSmall(unifiedNativeAd, adView);
//                frameLayout.removeAllViews();
//                frameLayout.addView(adView);
//            }
//        });
//        VideoOptions videoOptions = new VideoOptions.Builder().build();
//        NativeAdOptions adOptions = new NativeAdOptions.Builder()
//                .setVideoOptions(videoOptions)
//                .build();
//        builder.withNativeAdOptions(adOptions);
//        AdLoader adLoader = builder.withAdListener(new AdListener() {
//            @Override
//            public void onAdFailedToLoad(int errorCode) {
//            }
//        }).build();
//        adLoader.loadAd(new AdRequest.Builder().build());
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_NativeBanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(Activity_Share.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                FrameLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }

    private void LoadfbInterstitialAds() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e("TAG", "onInterstitialDismissed...");
                switch (id) {
                    case 201:
                        directHome();
                        break;
                    case 202:
                        GoBack();
                        break;
                }
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        fbinterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        fbinterstitialAd = new InterstitialAd(this, getResources().getString(R.string.fb_interstitial));
        fbinterstitialAd.loadAd();
    }

    private void bindview() {
        imgFinalImg_act_share = findViewById(R.id.imgFinalImg_act_share);
        llWhatsapp_act_share = findViewById(R.id.llWhatsapp_act_share);
        llFacebook_act_share = findViewById(R.id.llFacebook_act_share);
        llInstagram_act_share = findViewById(R.id.llInstagram_act_share);
        llShareMore_act_share = findViewById(R.id.llShareMore_act_share);
        this.pathSaved_act_save = (getIntent().getExtras().getString("image_path"));
        ic_back = findViewById(R.id.back_image);
        ic_home = findViewById(R.id.btn_home);
        File file = new File(pathSaved_act_save);
        Picasso.with(Activity_Share.this)
                .load(file)
                .into(imgFinalImg_act_share);

    }

    public void onBackPressed() {
        if (fbinterstitialAd != null && fbinterstitialAd.isAdLoaded()) {
            id = 202;
            fbinterstitialAd.show();
        } else {
            GoBack();
        }
    }

    private void GoBack() {
        final Intent intent = new Intent(this, Activity_Creation.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    public void onClick(final View view) {
        switch (view.getId()) {
            default: {
            }
            case R.id.llWhatsapp_act_share: {
                shareImageWhatsApp("com.whatsapp", "Whatsapp");
            }
            break;
            case R.id.llFacebook_act_share: {
                shareImageWhatsApp("com.facebook.katana", "Facebook");
            }
            break;
            case R.id.llInstagram_act_share: {
                shareImageWhatsApp("com.instagram.android", "Instagram");
            }
            break;
            case R.id.llShareMore_act_share: {
                Parcelable fromFile;
                if (Build.VERSION.SDK_INT <= 19) {
                    fromFile = Uri.fromFile(new File(pathSaved_act_save));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
                    fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(pathSaved_act_save));
                }
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("image/*");
                intent2.putExtra("android.intent.extra.STREAM", fromFile);
                intent2.putExtra("android.intent.extra.TEXT", "created by : https://play.google.com/store/apps/details?id=" + getPackageName());
                intent2.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent2, getString(R.string.share_your_story)));
                return;
            }
        }
    }

    public void shareImageWhatsApp(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(pathSaved_act_save));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(pathSaved_act_save));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        intent.putExtra("android.intent.extra.TEXT", "created by : https://play.google.com/store/apps/details?id=" + getPackageName());
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }

    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }

    private void directHome() {
        Intent intent = new Intent(Activity_Share.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}

