package com.xyz.vehiclemanager.rtoownerdetails.rtovehiclelicense.model;

import com.google.gson.annotations.SerializedName;

public class  VehicleLicenseRoot
{
    @SerializedName("statusCode")
    public String statusCode;
    @SerializedName("statusMessage")
    public String statusMessage;
    @SerializedName("details")
    public VehicleLicense details;

    public class VehicleLicense
    {
        @SerializedName("id")
        public String id;
        @SerializedName("licenseNo")
        public String licenseNo;
        @SerializedName("dob")
        public String dob;
        @SerializedName("holderName")
        public String holderName;
        @SerializedName("dateOfIssue")
        public String dateOfIssue;
        @SerializedName("currentStatus")
        public String currentStatus;
        @SerializedName("lastTransactionAt")
        public String lastTransactionAt;
        @SerializedName("validFrom")
        public String validFrom;
        @SerializedName("validTo")
        public String validTo;
        @SerializedName("vehicleClass")
        public String vehicleClass;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getLicenseNo() {
            return licenseNo;
        }

        public void setLicenseNo(String licenseNo) {
            this.licenseNo = licenseNo;
        }

        public String getDob() {
            return dob;
        }

        public void setDob(String dob) {
            this.dob = dob;
        }

        public String getHolderName() {
            return holderName;
        }

        public void setHolderName(String holderName) {
            this.holderName = holderName;
        }

        public String getDateOfIssue() {
            return dateOfIssue;
        }

        public void setDateOfIssue(String dateOfIssue) {
            this.dateOfIssue = dateOfIssue;
        }

        public String getCurrentStatus() {
            return currentStatus;
        }

        public void setCurrentStatus(String currentStatus) {
            this.currentStatus = currentStatus;
        }

        public String getLastTransactionAt() {
            return lastTransactionAt;
        }

        public void setLastTransactionAt(String lastTransactionAt) {
            this.lastTransactionAt = lastTransactionAt;
        }

        public String getValidFrom() {
            return validFrom;
        }

        public void setValidFrom(String validFrom) {
            this.validFrom = validFrom;
        }

        public String getValidTo() {
            return validTo;
        }

        public void setValidTo(String validTo) {
            this.validTo = validTo;
        }

        public String getVehicleClass() {
            return vehicleClass;
        }

        public void setVehicleClass(String vehicleClass) {
            this.vehicleClass = vehicleClass;
        }
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public VehicleLicense getDetails() {
        return details;
    }

    public void setDetails(VehicleLicense details) {
        this.details = details;
    }
}
