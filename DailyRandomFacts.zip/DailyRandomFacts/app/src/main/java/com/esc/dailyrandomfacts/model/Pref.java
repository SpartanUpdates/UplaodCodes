package com.esc.dailyrandomfacts.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.esc.dailyrandomfacts.util.Constants;

public class Pref {
    private static SharedPreferences sharedPreferences;

    public static void openPref(Context context) {
        sharedPreferences = context.getSharedPreferences(Constants.PREF_FILE, 0);
    }

    public static String getValue(Context context, String str, String str2) {
        openPref(context);
        String string = sharedPreferences.getString(str, str2);
        sharedPreferences = null;
        return string;
    }

    public static int getValue(Context context, String str, int i) {
        openPref(context);
        int i2 = sharedPreferences.getInt(str, i);
        sharedPreferences = null;
        return i2;
    }

    public static void setValue(Context context, String str, String str2) {
        openPref(context);
        Editor edit = sharedPreferences.edit();
        edit.putString(str, str2);
        edit.commit();
        sharedPreferences = null;
    }

    public static void setValue(Context context, String str, int i) {
        openPref(context);
        Editor edit = sharedPreferences.edit();
        edit.putInt(str, i);
        edit.commit();
        sharedPreferences = null;
    }
}
