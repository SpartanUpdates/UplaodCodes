package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;


public class s6 implements OnTouchListener {
    public final  ImageView imageView;
    public final GestureDetector gestureDetector;
    public final  HighlightDetailsDetailActivity activity;

    public s6(HighlightDetailsDetailActivity highlightDetailsDetailActivity, ImageView imageView, GestureDetector gestureDetector) {
        this.activity = highlightDetailsDetailActivity;
        this.imageView = imageView;
        this.gestureDetector = gestureDetector;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        this.activity.e0 = this.imageView;
        boolean onTouchEvent = this.gestureDetector.onTouchEvent(motionEvent);
        return true;
    }
}
