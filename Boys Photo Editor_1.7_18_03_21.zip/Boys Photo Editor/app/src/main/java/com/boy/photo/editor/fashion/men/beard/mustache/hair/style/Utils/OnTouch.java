package com.boy.photo.editor.fashion.men.beard.mustache.hair.style.Utils;

public abstract interface OnTouch {
	public abstract void removeBorder();
}
