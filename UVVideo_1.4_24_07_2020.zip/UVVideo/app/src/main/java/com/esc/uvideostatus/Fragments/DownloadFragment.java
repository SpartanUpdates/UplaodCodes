package com.esc.uvideostatus.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esc.uvideostatus.Activity.DownloadPlayActivity;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.esc.uvideostatus.Adapters.DownloadAdapter;
import com.esc.uvideostatus.Models.VideoData;
import com.esc.uvideostatus.R;
import com.esc.uvideostatus.Utility.Utility;
import cz.msebera.android.httpclient.Header;
import java.io.File;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DownloadFragment extends Fragment implements OnClickListener {
    RecyclerView album_recyclerview;
    DownloadAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    String main_url;
    String path;
    ArrayList<VideoData> videoData = new ArrayList<>();
    VideoData videoDataobj = new VideoData();
    String vurl;

    class dataTrendingHandler extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataTrendingHandler() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            try {
                JSONObject jSONObject = new JSONObject(new String(bArr));
                jSONObject.getString("error");
                try {
                    JSONArray jSONArray = jSONObject.getJSONArray("data");
                    if (jSONArray.length() != 0) {
                        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                            DownloadFragment.this.videoDataobj = new VideoData();
                            DownloadFragment.this.videoDataobj.setVideo_id(jSONObject2.getLong(TtmlNode.ATTR_ID));
//                            DownloadFragment.this.videoDataobj.setTitle(jSONObject2.getString(NotificationTable.COLUMN_NAME_TITLE));
                            videoDataobj.setTitle(jSONObject.getString("title"));
                            DownloadFragment.this.videoDataobj.setUrl(jSONObject2.getString(str));
                            VideoData videoData = DownloadFragment.this.videoDataobj;
                            StringBuilder sb = new StringBuilder();
                            sb.append(DownloadFragment.this.vurl);
                            sb.append(jSONObject2.getString(str));
                            sb.append(".mp4");
                            videoData.setReal_videopath(sb.toString());
                            VideoData videoData2 = DownloadFragment.this.videoDataobj;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(DownloadFragment.this.vurl);
                            sb2.append(jSONObject2.getString(str));
                            videoData2.setThumbnail(sb2.toString());
                            videoDataobj.setCatagory(jSONObject2.getString("category"));
                            videoDataobj.setSub_catagory(jSONObject2.getString("subcategory"));
                            videoDataobj.setLikes(jSONObject2.getString("likes"));
                            videoDataobj.setViews(jSONObject2.getString("view"));
                            DownloadFragment.this.videoData.add(DownloadFragment.this.videoDataobj);
                        }

                        DownloadFragment.this.mAdapter.addAll(DownloadFragment.this.videoData);
                    }
                    DownloadFragment.this.mAdapter.setLoaded();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (Exception unused2) {
            }
        }
    }

    public void onClick(View view) {
    }

    public DownloadFragment() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append("/Video_player");
        this.path = sb.toString();
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.downloaded_fragment, viewGroup, false);
        initViews(inflate);
        listFiles(this.path);
        return inflate;
    }

    private void initViews(View view) {
        this.album_recyclerview = (RecyclerView) view.findViewById(R.id.album_recyclerview);
        this.mLayoutManager = new LinearLayoutManager(getActivity());
        this.album_recyclerview.setLayoutManager(this.mLayoutManager);
        this.mAdapter = new DownloadAdapter(getActivity(), this.videoData, this);
        this.album_recyclerview.setAdapter(this.mAdapter);
        mAdapter.notifyDataSetChanged();
    }


    public void listFiles(String str) {
        File[] listFiles = new File(str).listFiles();
        if (listFiles != null && listFiles.length != 0) {
            for (File file : listFiles) {
                if (file.isFile()) {
                    System.out.println(file.getName());
                    VideoData videoData2 = new VideoData();
                    videoData2.setReal_videopath(file.getPath());
                    videoData2.setTitle(file.getName());
                    videoData2.setThumbnail("");
                    videoData2.setThumbnail(file.getPath());
                    videoData2.setSize(Utility.getFileSize(file.length()));
                    this.videoData.add(videoData2);
                    this.mAdapter.addAll(this.videoData);
                }
            }
        }
    }

    public void playVideo(VideoData videoData2) {
        Intent intent = new Intent(getActivity(), DownloadPlayActivity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("main_url", this.main_url);
        intent.putExtra("vurl", this.vurl);
        intent.putExtra("list", videoData2);
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        startActivity(intent);
    }

    public void setUserVisibleHint(boolean z) {
        super.setUserVisibleHint(z);
        if (z && this.mAdapter != null) {
            this.videoData = new ArrayList<>();
            listFiles(this.path);
            this.mAdapter.notifyDataSetChanged();
        }
    }
}
