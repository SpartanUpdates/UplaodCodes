package com.unikapp.faceappeditor.Utils;

//import android.support.v4.content.FileProvider;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
