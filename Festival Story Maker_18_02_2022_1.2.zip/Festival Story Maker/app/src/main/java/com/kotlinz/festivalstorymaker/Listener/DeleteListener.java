package com.kotlinz.festivalstorymaker.Listener;

import android.view.View;
import com.kotlinz.festivalstorymaker.Adapter.SelectLogoAdapter;


public class DeleteListener implements View.OnClickListener
{
    public final  int anInt;
    public final SelectLogoAdapter selectLogoAdapter;

    public DeleteListener(final SelectLogoAdapter f, final int e) {
        this.selectLogoAdapter = f;
        this.anInt = e;
    }

    public void onClick(final View view) {
        final SelectLogoAdapter f = this.selectLogoAdapter;
        f.logoInterface.K(f.logoList.get(this.anInt), true);
    }
}
