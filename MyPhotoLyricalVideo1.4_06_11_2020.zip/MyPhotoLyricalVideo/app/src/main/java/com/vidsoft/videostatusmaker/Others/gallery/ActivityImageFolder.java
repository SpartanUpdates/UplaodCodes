package com.vidsoft.videostatusmaker.Others.gallery;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Images.Media;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.DisplayImageOptions.Builder;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.util.ArrayList;

import com.vidsoft.videostatusmaker.Activity.ActivityViewAlImages;
import com.vidsoft.videostatusmaker.Utils.Utils;
import com.vidsoft.videostatusmaker.adapter.FolderAdapter;
import com.vidsoft.videostatusmaker.Utils.RoundedImageView;

public class ActivityImageFolder extends AppCompatActivity {
    private static final int REQUEST_PERMISSIONS = 100;
    TextView listtotal;
    FolderAdapter folderAdapter;
    ProgressDialog progressDialog;
    TextView tvTitle;
    TextView tvDone;
    Typeface typeface;
    Typeface typeface1;
    GridView GridVFolder;
    public static ArrayList<ImageData> AllFolderImages = new ArrayList();
    public static Activity activity;
    LinearLayout linearLayout;
    ImageLoader imageLoader;
    ImageView ivBack;
    boolean booleanFolder;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_folder);
        getWindow().addFlags(1024);
        activity = this;
        initImageLoader();
        this.progressDialog = new ProgressDialog(this);
        this.progressDialog.setMessage("Loading...");
        this.progressDialog.setCancelable(false);
        this.ivBack = (ImageView) findViewById(R.id.back);
        this.linearLayout = (LinearLayout) findViewById(R.id.addlay);
        this.tvDone = (TextView) findViewById(R.id.done);
        this.listtotal = (TextView) findViewById(R.id.listtotal);
        this.tvTitle = (TextView) findViewById(R.id.title);
        this.typeface = Typeface.createFromAsset(getAssets(), "Montserrat-Regular_0.otf");
        this.typeface1 = Typeface.createFromAsset(getAssets(), "Montserrat-Light_0.otf");
        this.tvTitle.setTypeface(this.typeface);
        this.tvTitle.setTextSize(18.0f);
        this.listtotal.setTypeface(this.typeface1);
        gridClick();
    }

    public ArrayList<ImageData> getAllImagePath() {
        AllFolderImages.clear();
        try {
            Cursor query = getApplicationContext().getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "bucket_display_name"}, null, null, "datetaken DESC");
            int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
            int columnIndexOrThrow2 = query.getColumnIndexOrThrow("bucket_display_name");
            int i = 0;
            while (query.moveToNext()) {
                String string = query.getString(columnIndexOrThrow);
                for (int i2 = 0; i2 < AllFolderImages.size(); i2++) {
                    if (((ImageData) AllFolderImages.get(i2)).getStr_folder().equals(query.getString(columnIndexOrThrow2))) {
                        this.booleanFolder = true;
                        i = i2;
                        break;
                    }
                    this.booleanFolder = false;
                }
                ArrayList arrayList;
                if (this.booleanFolder) {
                    arrayList = new ArrayList();
                    arrayList.addAll(((ImageData) AllFolderImages.get(i)).getAl_imagepath());
                    arrayList.add(string);
                    ((ImageData) AllFolderImages.get(i)).setAl_imagepath(arrayList);
                } else {
                    arrayList = new ArrayList();
                    arrayList.add(string);
                    ImageData imageData = new ImageData();
                    imageData.setStr_folder(query.getString(columnIndexOrThrow2));
                    imageData.setAl_imagepath(arrayList);
                    AllFolderImages.add(imageData);
                }
            }
            for (int i3 = 0; i3 < AllFolderImages.size(); i3++) {
                for (columnIndexOrThrow = 0; columnIndexOrThrow < ((ImageData) AllFolderImages.get(i3)).getAl_imagepath().size(); columnIndexOrThrow++) {
                }
            }
            this.folderAdapter = new FolderAdapter(getApplicationContext(), AllFolderImages);
            this.GridVFolder.setAdapter(this.folderAdapter);
        } catch (Exception e) {
            e.toString();
        }
        this.progressDialog.dismiss();
        return AllFolderImages;
    }


    private void LayoutAdd(final String s) {
        final View inflate = LayoutInflater.from(this.getApplicationContext()).inflate(R.layout.trail, (ViewGroup) null, false);
        final RoundedImageView roundedImageView = (RoundedImageView) inflate.findViewById(R.id.imgtrail);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.closetrail);
        final DisplayImageOptions build = new Builder().build();
        final ImageLoader instance = ImageLoader.getInstance();
        final StringBuilder sb = new StringBuilder();
        sb.append("file:///");
        sb.append(s);
        instance.displayImage(sb.toString(), roundedImageView, build);
        roundedImageView.setCornerRadius(this.getResources().getDisplayMetrics().widthPixels * 25 / 1080);
        roundedImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.getResources().getDisplayMetrics().widthPixels * 60 / 1080, this.getResources().getDisplayMetrics().heightPixels * 60 / 1920);
        layoutParams.addRule(11);
        imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        imageView.setOnClickListener((OnClickListener) new OnClickListener() {
            public void onClick(final View view) {
                Utils.photos.remove(ActivityImageFolder.this.linearLayout.indexOfChild(inflate));
                final TextView listtotal = ActivityImageFolder.this.listtotal;
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(Utils.photos.size());
                listtotal.setText((CharSequence) sb.toString());
                ActivityImageFolder.this.linearLayout.removeView(inflate);
            }
        });
        this.linearLayout.addView(inflate);
    }

    private void gridClick() {
        this.GridVFolder = (GridView) findViewById(R.id.gv_folder);
        (this.GridVFolder = this.findViewById(R.id.gv_folder)).setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                final Intent intent = new Intent(ActivityImageFolder.this.getApplicationContext(), (Class) ActivityAllPhotos.class);
                intent.putExtra("value", n);
                ActivityImageFolder.this.startActivity(intent);
            }
        });
        this.ivBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityImageFolder.this.onBackPressed();
            }
        });
        this.progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityImageFolder.this.getAllImagePath();
            }
        }, 200);

    }

    protected void onResume() {
        TextView textView = this.listtotal;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(Utils.photos.size());
        stringBuilder.append("");
        textView.setText(stringBuilder.toString());
        this.tvTitle.setText("Gallery");
        this.linearLayout.removeAllViews();
        for (int i = 0; i < Utils.photos.size(); i++) {
            LayoutAdd((String) Utils.photos.get(i));
        }
        this.tvDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.photos.size() == 8) {
                    ActivityImageFolder.this.startActivity(new Intent(ActivityImageFolder.this.getApplicationContext(), ActivityViewAlImages.class));

                } else {
                    Toast.makeText(ActivityImageFolder.this.getApplicationContext(), "Add 8 pics", Toast.LENGTH_SHORT).show();
                }
            }
        });
        super.onResume();
    }

    private void initImageLoader() {
        this.imageLoader = ImageLoader.getInstance();
        this.imageLoader.init(new ImageLoaderConfiguration.Builder(this).defaultDisplayImageOptions(new Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }
}
