package com.wavymusic.SongSelection.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.wavymusic.R;
import com.wavymusic.SongSelection.Fragment.PhoneSongByCatFragment;
import com.wavymusic.SongSelection.Model.PhoneSongModel;
import com.wavymusic.SongSelection.View.CircleImageView;
import com.wavymusic.SongSelection.activity.PhoneSongActivity;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class PhoneSongAdapter extends RecyclerView.Adapter<PhoneSongAdapter.MyViewHolder> {

    Context ctx;
    private List<PhoneSongModel> localTracks;
    private PhoneSongActivity ActivityOfsong;
    PhoneSongByCatFragment fragment;

    public PhoneSongAdapter(PhoneSongByCatFragment phoneSongByCatFragment, Context ctx, List<PhoneSongModel> localTracks) {
        this.fragment = phoneSongByCatFragment;
        this.ctx = ctx;
        this.ActivityOfsong = (PhoneSongActivity) ctx;
        this.localTracks = localTracks;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_phone_song, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        if (this.localTracks != null) {
            final PhoneSongModel track = localTracks.get(position);
            holder.Songname.setText(track.m5778d());
            if (!track.l()) {
                if (ActivityOfsong.SelectedPosition != localTracks.get(position).a()) {
                    holder.ivThumb.setSelected(false);
                    holder.tvuseSong.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
                    holder.IvplayPause.setImageResource(R.drawable.icon_player_play);
                    holder.ivThumb.setBackgroundResource(R.drawable.ic_song_select);
                } else {
                    holder.tvuseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                    holder.IvplayPause.setImageResource(R.drawable.icon_player_pause_selected);
                    holder.ivThumb.setBackgroundResource(R.drawable.ic_song_select_press);
                    holder.ivThumb.setSelected(true);
                }
            }

            holder.llMain.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    if (!track.l()) {
                        if (holder.ivThumb.isSelected()) {
                            ActivityOfsong.t();
                            if (ActivityOfsong.isSongPlay()) {
                                holder.IvplayPause.setImageResource(R.drawable.icon_player_pause_selected);
                                holder.ivThumb.setImageResource(R.drawable.icon_song_thumb);
                            } else {
                                holder.IvplayPause.setImageResource(R.drawable.icon_player_play);
                                holder.ivThumb.setImageResource(R.drawable.icon_song_thumb);
                            }
                        } else {
                            holder.ivThumb.setSelected(true);
                            if (ActivityOfsong.SelectedTabPosition == fragment.getTabIndex()) {
                                if (ActivityOfsong.SelectedSongposition == position) {
                                    holder.ivThumb.setSelected(true);
                                    holder.tvuseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                                    holder.IvplayPause.setImageResource(R.drawable.icon_player_play);
                                    holder.ivThumb.setImageResource(R.drawable.icon_song_thumb);
                                    return;
                                }
                            }
                            ActivityOfsong.setSong(localTracks.get(position), position);
                            notifyDataSetChanged();
                        }
                    }
                }
            });

            holder.tvuseSong.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View v) {
                    if (ActivityOfsong.SelectedPosition != localTracks.get(position).a()) {
                        Toast.makeText(ctx, "Select Song First", Toast.LENGTH_SHORT).show();
                    } else {
                        if (ActivityOfsong.getMaxDuration() > 3000L) {
                            if (ActivityOfsong.mInterstitialAdWavy != null && ActivityOfsong.mInterstitialAdWavy.isLoaded()) {
                                ActivityOfsong.mediacontroler.isSongStop();
                                ActivityOfsong.id = 202;
                                ActivityOfsong.mInterstitialAdWavy.show();
                            } else if (ActivityOfsong.fbinterstitialAd != null && ActivityOfsong.fbinterstitialAd.isAdLoaded()) {
                                ActivityOfsong.mediacontroler.isSongStop();
                                ActivityOfsong.id = 202;
                                ActivityOfsong.fbinterstitialAd.show();
                            } else {
                                ActivityOfsong.Done();
                            }
                        } else {
                            Toast.makeText(ctx, "Please Select Appropriate Song Duration Up To 3 Second", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            });
        }
    }

    @Override
    public int getItemCount() {
        return localTracks.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llMain;
        CircleImageView ivThumb;
        TextView Songname, tvSongtime, tvuseSong;
        ImageView IvplayPause;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.image_layout);
            ivThumb = itemView.findViewById(R.id.image_content);
            IvplayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            Songname = itemView.findViewById(R.id.tvMusicName);
            tvuseSong = itemView.findViewById(R.id.tvUseMusic);
            tvSongtime = itemView.findViewById(R.id.tvMusicEndTime);
        }
    }

    @SuppressLint("DefaultLocale")
    public String getTimeDuration(final long n) {
        return String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(n), TimeUnit.MILLISECONDS.toMinutes(n), TimeUnit.MILLISECONDS.toSeconds(n) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(n)));
    }
}
