package com.example.logomaker.utilities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Save extends AsyncTask<Void, Void, String>
{
    private File fileTosave;
    private Bitmap imageToSave;
    private View imageView;
    private ProgressDialog progressDialog;

    public Save(View view) {
        this.imageView = view;
        view.setDrawingCacheEnabled(true);
        this.imageToSave = view.getDrawingCache();
    }

    public void onPreExecute() {
        ProgressDialog progressDialog = new ProgressDialog(this.imageView.getContext());
        this.progressDialog = progressDialog;
        progressDialog.requestWindowFeature(1);
        this.progressDialog.setMessage("Saving........");
        this.progressDialog.show();
    }

    public String doInBackground(Void... voidArr) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath());
        stringBuilder.append(File.separator);
        stringBuilder.append(Constants.D_NAME);
        File file = new File(stringBuilder.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(System.currentTimeMillis());
        stringBuilder2.append(".png");
        this.fileTosave = new File(file, stringBuilder2.toString());
        try
        {
            FileOutputStream fileOutputStream = new FileOutputStream(this.fileTosave);
            this.imageToSave.compress(CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            Constants.filetosave = this.fileTosave;
            return "Image Saved Successfully";
        }
        catch (IOException e)
        {
            return e.getMessage();
        }
    }

    public void onPostExecute(String str)
    {
        this.progressDialog.dismiss();
        Toast.makeText(this.imageView.getContext(), str, Toast.LENGTH_SHORT).show();
        this.imageView.getContext().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(this.fileTosave)));
        this.imageView.setDrawingCacheEnabled(false);
    }
}
