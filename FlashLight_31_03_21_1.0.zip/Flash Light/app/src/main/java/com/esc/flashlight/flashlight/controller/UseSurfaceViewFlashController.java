package com.esc.flashlight.flashlight.controller;

import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import java.io.IOException;

public class UseSurfaceViewFlashController extends BaseFlashController {
    private static UseSurfaceViewFlashController mBack;
    private static UseSurfaceViewFlashController mFront;

    class C01871 implements Callback {
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        }

        public void surfaceCreated(SurfaceHolder surfaceHolder) {
        }

        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        }

        C01871() {
        }
    }


    public void onStartUse() {
    }

    public static UseSurfaceViewFlashController getInstanceBack() {
        UseSurfaceViewFlashController useSurfaceViewFlashController = mBack;
        if (useSurfaceViewFlashController == null && useSurfaceViewFlashController == null) {
            mBack = new UseSurfaceViewFlashController(-1);
        }
        return mBack;
    }

    public static UseSurfaceViewFlashController getInstanceFront(int i) {
        UseSurfaceViewFlashController useSurfaceViewFlashController = mFront;
        if (useSurfaceViewFlashController == null && useSurfaceViewFlashController == null) {
            mFront = new UseSurfaceViewFlashController(i);
        }
        return mFront;
    }

    private UseSurfaceViewFlashController(int i) {
        super(i);
    }

    public void useStart(SurfaceView surfaceView) {
        Log.d(getClass().getSimpleName(), "invoke: useStart");
        initCamera();
        onStartUse(surfaceView);
        flashOff();
    }

    public void afterCameraOpen() {
        this.mCamera.startPreview();
    }

    public void beforeCameraRelease() {
        try {
            this.mCamera.stopPreview();
            this.mCamera.setPreviewDisplay(null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void onStartUse(SurfaceView surfaceView) {
        try {
            SurfaceHolder holder = surfaceView.getHolder();
            holder.addCallback(getDummyCallback());
            this.mCamera.setPreviewDisplay(holder);
            Parameters parameters = this.mCamera.getParameters();
            Size size = (Size) parameters.getSupportedPreviewSizes().get(0);
            parameters.setPreviewSize(size.width, size.height);
            this.mCamera.setParameters(parameters);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Callback getDummyCallback() {
        Log.d(getClass().getSimpleName(), "invoke: getDummyCallBack");
        return new C01871();
    }
}
