﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System;
public class MainSceneManager : MonoBehaviour
{
    public static MainSceneManager instance;

    public Slider swapSensitive;

    public GameObject levelpanel;

    [HideInInspector]
    public bool isLevelbtnClick = false;

    [HideInInspector]
    public int levelNumber;

    [HideInInspector]
    public int currentLevel;

    public TextMeshProUGUI coinText, txtIntensity;

    public GameObject settingPanel, shopPanel, levelPanel, mainPanel, quitPanel, informationPanel, bannerViewPanel, loadingPanel;

    bool isSettingOpen = false, isShopOpen = false, isLevelOpen = false, isQuitOpen = false;

    public Button btnMusic, btnSound, btnVibrate;

    public Sprite musicOn, musicOff, soundOn, soundOff, vibrateOn, vibrateOff;

    bool isMusicOn, isSoundOn, isVibrateOn;

    public Canvas canvas;

    bool isQuitWait = false, isInfoWait = false;

    [HideInInspector]
    public bool isStartPlay = false, isLevelPanel = false;

    public GameObject privacyPolicy;

    public CanvasScaler canvas1;
    void Awake()
    {
        instance = this;

        if (GetAspectRatio(Screen.width, Screen.height) > 0.6f)
        {
            canvas1.matchWidthOrHeight = 1;
        }
        settingPanel.SetActive(false);
        shopPanel.SetActive(false);
        levelpanel.SetActive(false);
        informationPanel.SetActive(false);
        mainPanel.SetActive(true);
        loadingPanel.SetActive(false);
        privacyPolicy.SetActive(false);

        if (PlayerPrefs.GetInt("iAgree") == 0)
        {
            privacyPolicy.SetActive(true);
        }
        if (!PlayerPrefs.HasKey("SwapSensitive"))
        {
            swapSensitive.value = 5;
            PlayerPrefs.SetInt("PlayerSelect0", 1);
            PlayerPrefs.SetInt("PlayLevel", 1);
            PlayerPrefs.SetInt("Coins", 0);
        }
        else
        {
            swapSensitive.value = PlayerPrefs.GetInt("SwapSensitive");
        }
        if (PlayerPrefs.GetInt("IsGameOneTimeFinished") == 0)
        {
            for (int i = 1; i < 20; i++)
            {
                if (PlayerPrefs.GetInt("Level" + i) == 1)
                    PlayerPrefs.SetInt("PlayLevel", i + 1);
            }
        }

        if (PlayerPrefs.GetInt("MusicOn") == 0)
        {
            isMusicOn = true;
            btnMusic.GetComponent<Image>().sprite = musicOn;
        }
        else
        {
            isMusicOn = false;
            btnMusic.GetComponent<Image>().sprite = musicOff;
        }


        if (PlayerPrefs.GetInt("SoundOn") == 0)
        {
            isSoundOn = true;
            btnSound.GetComponent<Image>().sprite = soundOn;
        }
        else
        {
            isSoundOn = false;
            btnSound.GetComponent<Image>().sprite = soundOff;
        }

        if (PlayerPrefs.GetInt("VibrateOn") == 0)
        {
            isVibrateOn = true;
            btnVibrate.GetComponent<Image>().sprite = vibrateOn;
        }
        else
        {
            isVibrateOn = false;
            btnVibrate.GetComponent<Image>().sprite = vibrateOff;
        }
    }
    int CalculateBannerHeight()
    {
        if (Screen.height <= 400 * Screen.dpi / 160)
            return Mathf.RoundToInt(32 * Screen.dpi / 160) + 8;
        else if (Screen.height <= 720 * Screen.dpi / 160)
            return Mathf.RoundToInt(50 * Screen.dpi / 160 * 1.5f) + 8;
        else
            return Mathf.RoundToInt(90 * Screen.dpi / 160) - 10;
    }
    void Start()
    {
        if (!SoundManger.instance.bgMainMusic.isPlaying)
            SoundManger.instance.bgMainMusic.Play();
        if (SoundManger.instance.bgPlayMusic.isPlaying)
            SoundManger.instance.bgPlayMusic.Stop();

        bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, CalculateBannerHeight());
        if (Manager.instance.isNetWorkOn)
            bannerViewPanel.SetActive(true);
        else
            bannerViewPanel.SetActive(false);
    }
    void Update()
    {
        coinText.text = PlayerPrefs.GetInt("Coins").ToString();

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isInfoWait)
                return;

            if (PlayerSelection.instane.noAdsPanel.activeSelf)
                return;

            if (privacyPolicy.activeSelf)
            {
                OnQuitYes();
                return;
            }
            if (isShopOpen)
            {
                OnShopBackClick();
                return;
            }
            else if (isLevelOpen)
            {
                OnLevelBackClick(); return;
            }
            else if (isSettingOpen)
            {
                OnSettingBackClick(); return;
            }
            else if (isInformation)
            {
                OnInformationClick(); return;
            }
            else if (isQuitOpen)
            {
                OnStayClick(); return;
            }
            else if (!isQuitOpen)
            {
                OnQuitClick(); return;
            }
        }
    }
    public void SensitiveChange()
    {
        PlayerPrefs.SetInt("SwapSensitive", (int)(swapSensitive.value));
        txtIntensity.text = swapSensitive.value * 10 + "%";
    }

    public void StartGame()
    {
        ButtonClickSound();
        if (InterstitialAddShow.instance.interstitial.IsLoaded())
        {
            isStartPlay = true;
            loadingPanel.SetActive(true);
            mainPanel.SetActive(false);
            InterstitialAddShow.instance.ShowInterstitial();
        }
        else
        {
            AfterAdsStartGame();
        }
    }
    public void AfterAdsStartGame()
    {
        isStartPlay = false;
        PlayerPrefs.SetInt("LevelNumber", PlayerPrefs.GetInt("PlayLevel"));
        SceneManager.LoadScene("Level" + PlayerPrefs.GetInt("PlayLevel"));
    }

    string levelName;
    public void LevelButton(string name)
    {
        ButtonClickSound();
        levelName = name;
        if (InterstitialAddShow.instance.interstitial.IsLoaded())
        {
            loadingPanel.SetActive(true);
            levelPanel.SetActive(false);
            InterstitialAddShow.instance.ShowInterstitial();
            isLevelPanel = true;
        }
        else
        {
            AfterAdsLevelbtn();
        }
    }
    public void AfterAdsLevelbtn()
    {
        PlayerPrefs.SetInt("LevelNumber", int.Parse(levelName));
        if (PlayerPrefs.GetInt("IsGameOneTimeFinished") == 1)
        {
            PlayerPrefs.SetInt("PlayLevel", int.Parse(levelName));
        }
        SceneManager.LoadScene("Level" + levelName);
        isLevelPanel = false;
    }
    public void OnSettingClick()
    {
        ButtonClickSound();
        mainPanel.SetActive(false);
        settingPanel.SetActive(true);
        isSettingOpen = true;
    }
    public void OnSettingBackClick()
    {
        ButtonClickSound();
        mainPanel.SetActive(true);
        settingPanel.SetActive(false);
        isSettingOpen = false;
    }
    public void OnShopPanelClick()
    {
        ButtonClickSound();
        PlayerSelection.instane.OnStart();
        PlayerSelection.instane.OnStartEraser();
        mainPanel.SetActive(false);
        shopPanel.SetActive(true);
        canvas.worldCamera = Camera.main;
        isShopOpen = true;
        BannerAddView.instance.DestroyBannerAdd();
        bannerViewPanel.SetActive(false);
    }
    public void OnShopBackClick()
    {
        ButtonClickSound();
        mainPanel.SetActive(true);
        shopPanel.SetActive(false);
        isShopOpen = false;
        canvas.worldCamera = null;
        BannerAddView.instance.ShowBannerAdd();
        bannerViewPanel.SetActive(true);

    }
    public void OnLevelClick()
    {
        ButtonClickSound();
        mainPanel.SetActive(false);
        levelpanel.SetActive(true);
        isLevelOpen = true;
    }
    public void OnLevelBackClick()
    {
        ButtonClickSound();
        mainPanel.SetActive(true);
        levelpanel.SetActive(false);
        isLevelOpen = false;
    }
    bool isInformation = false;
    public void OnInformationClick()
    {
        if (!isInfoWait)
        {
            ButtonClickSound();
            if (!isInformation)
            {
                isInformation = true;
                informationPanel.SetActive(true);
                informationPanel.GetComponent<Animator>().Play("InformationPanel");
                StartCoroutine(OnInformationWait());
            }
            else
            {
                isInformation = false;
                informationPanel.GetComponent<Animator>().Play("InformationPanelClose");
                StartCoroutine(OnInformationWait());
            }
        }
    }

    IEnumerator OnInformationWait()
    {
        isInfoWait = true;
        yield return new WaitForSecondsRealtime(0.6f);
        isInfoWait = false;
        if (!isInformation)
            informationPanel.SetActive(false);
    }

    public void OnQuitClick()
    {
        if (!isQuitWait)
        {
            ButtonClickSound();
            StartCoroutine(OnQuitWait());
            isQuitOpen = true;
            quitPanel.SetActive(true);
            quitPanel.GetComponent<Animator>().Play("PausePanel");
        }
    }
    public void OnQuitYes()
    {
        ButtonClickSound();
        Application.Quit();
        if (SoundManger.instance.bgMainMusic.isPlaying)
            SoundManger.instance.bgMainMusic.Stop();
    }
    public void OnStayClick()
    {
        if (!isQuitWait)
        {
            ButtonClickSound();
            StartCoroutine(OnQuitWait());
            isQuitOpen = false;
            quitPanel.GetComponent<Animator>().Play("PausePanelClose");
        }
    }
    IEnumerator OnQuitWait()
    {
        isQuitWait = true;
        yield return new WaitForSecondsRealtime(0.8f);
        isQuitWait = false;
        if (!isQuitOpen)
            quitPanel.SetActive(false);
    }
    public void OnMusicClick()
    {
        ButtonClickSound();
        if (isMusicOn)
        {
            isMusicOn = false;
            btnMusic.GetComponent<Image>().sprite = musicOff;
            PlayerPrefs.SetInt("MusicOn", 1);
        }
        else
        {
            isMusicOn = true;
            btnMusic.GetComponent<Image>().sprite = musicOn;
            PlayerPrefs.SetInt("MusicOn", 0);
        }
        SoundManger.instance.MuteMusic();
    }

    public void OnSoundClick()
    {
        if (isSoundOn)
        {
            isSoundOn = false;
            btnSound.GetComponent<Image>().sprite = soundOff;
            PlayerPrefs.SetInt("SoundOn", 1);
            SoundManger.instance.MuteSound();
        }
        else
        {
            isSoundOn = true;
            btnSound.GetComponent<Image>().sprite = soundOn;
            PlayerPrefs.SetInt("SoundOn", 0);
            SoundManger.instance.MuteSound();
        }
        ButtonClickSound();
    }

    public void OnVibrateClick()
    {
        if (isVibrateOn)
        {
            isVibrateOn = false;
            btnVibrate.GetComponent<Image>().sprite = vibrateOff;
            PlayerPrefs.SetInt("VibrateOn", 1);
            SoundManger.instance.isVibrate = false;
        }
        else
        {
            isVibrateOn = true;
            btnVibrate.GetComponent<Image>().sprite = vibrateOn;
            PlayerPrefs.SetInt("VibrateOn", 0);
            SoundManger.instance.isVibrate = true;
        }
        ButtonClickSound();
    }
    public void BtnLike()
    {
        //ButtonClickSound();
        Application.OpenURL(Manager.instance.strLike);

    }
    public void BtbnPP()
    {
        // ButtonClickSound();
        Application.OpenURL(Manager.instance.strPrivacyPolicy);
    }

    public void BtnShareApp()
    {
        // ButtonClickSound();

#if UNITY_ANDROID
        // Get the required Intent and UnityPlayer classes.
        AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
        AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

        // Construct the intent.
        AndroidJavaObject intent = new AndroidJavaObject("android.content.Intent");
        intent.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_SEND"));
        intent.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_TEXT"), Manager.instance.strShareApp);
        intent.Call<AndroidJavaObject>("setType", "text/plain");

        // Display the chooser.
        AndroidJavaObject currentActivity = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
        AndroidJavaObject chooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", intent, "Share");
        currentActivity.Call("startActivity", chooser);
#endif
    }

    public void PPAgree()
    {
        ButtonClickSound();
        privacyPolicy.SetActive(false);
        PlayerPrefs.SetInt("iAgree", 1);
    }

    private float GetAspectRatio(float width, float height)
    {
        return (width / height);
    }

    void ButtonClickSound()
    {
        SoundManger.instance.Vibrate();
        if (!SoundManger.instance.btnClick.isPlaying)
            SoundManger.instance.btnClick.Play();
    }
}
