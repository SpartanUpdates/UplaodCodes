package com.kotlinz.videoCollage.puzzleview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.Environment;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.kotlinz.videoCollage.flying.puzzle.PuzzleView;
import com.kotlinz.videoeditor.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FileUtils {
    private static final String TAG = "FileUtils";

    public static String getFolderName(Context context, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        stringBuilder.append("/");
        stringBuilder.append(context.getResources().getString(R.string.app_folder_name));
        File file = new File(stringBuilder.toString(), str);
        if (file.exists() || file.mkdirs()) {
            return file.getAbsolutePath();
        }
        return "";
    }

    private static boolean isSDAvailable() {
        return Environment.getExternalStorageState().equals("mounted");
    }

    public static File getNewFile(Context context, String str) {
        CharSequence stringBuilder;
        String format = new SimpleDateFormat("ddMMyyyy_HHmmss", Locale.ENGLISH).format(new Date());
        String str2 = ".jpg";
        String str3 = "PhotoCollage ";
        if (isSDAvailable()) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(getFolderName(context, str));
            stringBuilder2.append(File.separator);
            stringBuilder2.append(str3);
            stringBuilder2.append(format);
            stringBuilder2.append(str2);
            stringBuilder = stringBuilder2.toString();
        } else {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(context.getFilesDir().getPath());
            stringBuilder3.append(File.separator);
            stringBuilder3.append(str3);
            stringBuilder3.append(format);
            stringBuilder3.append(str2);
            stringBuilder = stringBuilder3.toString();
        }
        if (TextUtils.isEmpty(stringBuilder)) {
            return null;
        }
        return new File(String.valueOf(stringBuilder));
    }

    public static Bitmap createBitmap(PuzzleView puzzleView) {
        puzzleView.clearHandling();
        puzzleView.invalidate();
        Bitmap createBitmap = Bitmap.createBitmap(puzzleView.getWidth(), puzzleView.getHeight(), Config.ARGB_8888);
        puzzleView.draw(new Canvas(createBitmap));
        return createBitmap;
    }




    public static Bitmap createBitmap(PuzzleView puzzleView, FrameLayout frameLayout) {
        puzzleView.clearHandling();
        frameLayout.invalidate();
        Bitmap createBitmap = Bitmap.createBitmap(frameLayout.getWidth(), frameLayout.getHeight(), Config.ARGB_8888);
        frameLayout.draw(new Canvas(createBitmap));
        return createBitmap;
    }


    public static void savePuzzle(PuzzleView r3, FrameLayout r4, File r5, int r6, Callback r7) {
        /*
        r0 = 0;
        r3 = createBitmap(r3, r4);	 Catch:{ FileNotFoundException -> 0x005d, all -> 0x005a }
        r1 = new java.io.FileOutputStream;	 Catch:{ FileNotFoundException -> 0x0056, all -> 0x0052 }
        r1.<init>(r5);	 Catch:{ FileNotFoundException -> 0x0056, all -> 0x0052 }
        r0 = android.graphics.Bitmap.CompressFormat.JPEG;	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r3.compress(r0, r6, r1);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r6 = r5.exists();	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        if (r6 != 0) goto L_0x002a;
    L_0x0015:
        r4 = "FileUtils";
        r5 = "notifySystemGallery: the file do not exist.";
        android.util.Log.e(r4, r5);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        if (r3 == 0) goto L_0x0021;
    L_0x001e:
        r3.recycle();
    L_0x0021:
        r1.close();	 Catch:{ IOException -> 0x0025 }
        goto L_0x0029;
    L_0x0025:
        r3 = move-exception;
        r3.printStackTrace();
    L_0x0029:
        return;
    L_0x002a:
        r4 = r4.getContext();	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r6 = new android.content.Intent;	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r0 = "android.intent.action.MEDIA_SCANNER_SCAN_FILE";
        r2 = android.net.Uri.fromFile(r5);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r6.<init>(r0, r2);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r4.sendBroadcast(r6);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        if (r7 == 0) goto L_0x0045;
    L_0x003e:
        r4 = r5.getAbsolutePath();	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
        r7.onSuccess(r4);	 Catch:{ FileNotFoundException -> 0x0050, all -> 0x004e }
    L_0x0045:
        if (r3 == 0) goto L_0x004a;
    L_0x0047:
        r3.recycle();
    L_0x004a:
        r1.close();	 Catch:{ IOException -> 0x0072 }
        goto L_0x0076;
    L_0x004e:
        r4 = move-exception;
        goto L_0x0054;
    L_0x0050:
        r4 = move-exception;
        goto L_0x0058;
    L_0x0052:
        r4 = move-exception;
        r1 = r0;
    L_0x0054:
        r0 = r3;
        goto L_0x0078;
    L_0x0056:
        r4 = move-exception;
        r1 = r0;
    L_0x0058:
        r0 = r3;
        goto L_0x005f;
    L_0x005a:
        r4 = move-exception;
        r1 = r0;
        goto L_0x0078;
    L_0x005d:
        r4 = move-exception;
        r1 = r0;
    L_0x005f:
        r4.printStackTrace();	 Catch:{ all -> 0x0077 }
        if (r7 == 0) goto L_0x0067;
    L_0x0064:
        r7.onFailed();	 Catch:{ all -> 0x0077 }
    L_0x0067:
        if (r0 == 0) goto L_0x006c;
    L_0x0069:
        r0.recycle();
    L_0x006c:
        if (r1 == 0) goto L_0x0076;
    L_0x006e:
        r1.close();	 Catch:{ IOException -> 0x0072 }
        goto L_0x0076;
    L_0x0072:
        r3 = move-exception;
        r3.printStackTrace();
    L_0x0076:
        return;
    L_0x0077:
        r4 = move-exception;
    L_0x0078:
        if (r0 == 0) goto L_0x007d;
    L_0x007a:
        r0.recycle();
    L_0x007d:
        if (r1 == 0) goto L_0x0087;
    L_0x007f:
        r1.close();	 Catch:{ IOException -> 0x0083 }
        goto L_0x0087;
    L_0x0083:
        r3 = move-exception;
        r3.printStackTrace();
    L_0x0087:
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: fcom.collage.imagevideo.puzzleview.FileUtils.savePuzzle(com.xiaopo.flying.puzzle.PuzzleView, android.widget.FrameLayout, java.io.File, int, fcom.collage.imagevideo.puzzleview.Callback):void");
    }
}
