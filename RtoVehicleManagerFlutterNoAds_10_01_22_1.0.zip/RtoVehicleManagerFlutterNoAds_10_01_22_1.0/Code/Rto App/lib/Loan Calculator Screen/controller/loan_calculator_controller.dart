import 'dart:math';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class LoanCalcController extends GetxController {
  String? monthlyEmi = "00";
  String? totalInterest = "00";
  String? totalPayble = "00";

  Future<void> calculation(String loanAmount, String annualInterestRate,
      String year, String month) async {
    double emi = 0.0;
    double interest = 0.0;
    double payble = 0.0;
    int P = int.parse(loanAmount);
    double r = double.parse(annualInterestRate) / 12 / 100;
    double y = int.parse(year) * 12;
    double n = (int.parse(month)) + y;

    emi = (P * r * pow((1 + r), n) / (pow((1 + r), n) - 1));
    interest = ((emi * n) - P);
    payble = P + interest;

    var format = NumberFormat.currency(locale: 'en_IN');

    List<String> sEmi = format.format(emi).split("INR");
    List<String> sInterest = format.format(interest).split("INR");
    List<String> sPayble = format.format(payble).split("INR");

    List<String> ssEmi = sEmi[1].split(".");
    List<String> ssInterest = sInterest[1].split(".");
    List<String> ssPayble = sPayble[1].split(".");

    monthlyEmi = "₹${ssEmi[0]}";
    totalInterest = "₹${ssInterest[0]}";
    totalPayble = "₹${ssPayble[0]}";

    update();
  }
}
