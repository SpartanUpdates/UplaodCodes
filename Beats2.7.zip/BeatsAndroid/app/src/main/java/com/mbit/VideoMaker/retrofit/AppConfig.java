package com.mbit.VideoMaker.retrofit;

public class AppConfig {
    public static final String Token="aciativtyksdfhal5215ajal";
    public static final String ApplicationId="11";
}
