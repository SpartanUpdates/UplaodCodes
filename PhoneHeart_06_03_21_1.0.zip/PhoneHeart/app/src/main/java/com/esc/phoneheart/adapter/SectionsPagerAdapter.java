package com.esc.phoneheart.adapter;

import android.content.Context;

import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.fragment.AudFileFragment;
import com.esc.phoneheart.fragment.DocFileFragment;
import com.esc.phoneheart.fragment.ImgFileFragment;
import com.esc.phoneheart.fragment.VidFileFragment;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SectionsPagerAdapter extends FragmentPagerAdapter {
    @StringRes
    public static int[] TAB_TITLES = new int[]{R.string.images, R.string.videos, R.string.audios, R.string.documents};
    public final Context mContext;

    public SectionsPagerAdapter(Context context, FragmentManager fragmentManager) {
        super(fragmentManager);
        this.mContext = context;
    }

    public int getCount() {
        return TAB_TITLES.length;
    }

    public Fragment getItem(int i) {
        String string = this.mContext.getString(TAB_TITLES[i]);
        if (string.equalsIgnoreCase(this.mContext.getString(R.string.images))) {
            return new ImgFileFragment(this.mContext, PhoneCleaner.getInstance().duplicateFilesData.getPerticulerDupFileDataList(this.mContext.getString(R.string.images)));
        }
        if (string.equalsIgnoreCase(this.mContext.getString(R.string.videos))) {
            return new VidFileFragment(this.mContext, PhoneCleaner.getInstance().duplicateFilesData.getPerticulerDupFileDataList(this.mContext.getString(R.string.videos)));
        }
        if (string.equalsIgnoreCase(this.mContext.getString(R.string.audios))) {
            return new AudFileFragment(this.mContext, PhoneCleaner.getInstance().duplicateFilesData.getPerticulerDupFileDataList(this.mContext.getString(R.string.audios)));
        }
        return new DocFileFragment(this.mContext, PhoneCleaner.getInstance().duplicateFilesData.getPerticulerDupFileDataList(this.mContext.getString(R.string.documents)));
    }

    @Nullable
    public CharSequence getPageTitle(int i) {
        return this.mContext.getResources().getString(TAB_TITLES[i]);
    }
}
