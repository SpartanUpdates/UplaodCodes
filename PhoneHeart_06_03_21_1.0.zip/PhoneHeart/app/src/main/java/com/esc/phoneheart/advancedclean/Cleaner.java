package com.esc.phoneheart.advancedclean;

import android.content.Context;
import android.content.Intent;

public class Cleaner {
    public static final String TAG = "Cleaner";
    public static Step sHead;

    public static void exit(Context context) {
        try {
            Intent intent = new Intent(context, CleanMasterAccessbilityService.class);
            intent.setAction(CleanMasterAccessbilityService.ACT_EXIT);
            context.startService(intent);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public static void start(BaseActivity baseActivity) {
        Step next = new StepCheckAccessPermission(baseActivity).setNext(new StepCheckOverlayPermission(baseActivity).setNext(new StepCheckReadProcPermission(baseActivity).setNext(new StepClean(baseActivity))));
        sHead = next;
        next.doAction();
    }

    public static void stop(Context context) {
        try {
            Intent intent = new Intent(context, CleanMasterAccessbilityService.class);
            intent.setAction(CleanMasterAccessbilityService.ACT_STOP);
            context.startService(intent);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
