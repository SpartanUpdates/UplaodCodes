package com.example.postermaker.savelayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_ShareActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class eaz_Save extends AsyncTask<Void, Void, String>
{
    public static File fileTosave;
    Context context;
    private Bitmap imageToSave;
    private View imageView;
    private ProgressDialog progressDialog;

    public eaz_Save(View view, Context context)
    {
        this.context = context;
        this.imageView = view;
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        this.imageToSave = view.getDrawingCache();
    }

    public void onPreExecute()
    {
        ProgressDialog progressDialog = new ProgressDialog(this.imageView.getContext());
        this.progressDialog = progressDialog;
        progressDialog.requestWindowFeature(1);
        this.progressDialog.setMessage("Saving........");
    }

    public String doInBackground(Void... voidArr)
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath());
        stringBuilder.append(File.separator);
        stringBuilder.append(eaz_ConstantValues.D_NAME);
        File file = new File(stringBuilder.toString());

        if (!file.exists())
        {
            file.mkdir();
        }

        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(System.currentTimeMillis());
        stringBuilder2.append(".png");
        fileTosave = new File(file, stringBuilder2.toString());
        try
        {
            FileOutputStream fileOutputStream = new FileOutputStream(fileTosave);
            this.imageToSave.compress(CompressFormat.PNG, 0, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            context.startActivity(new Intent(this.context, eaz_ShareActivity.class));
            ((Activity) this.context).finish();
            return "Share Image...";
        }
        catch (IOException e)
        {
            return e.getMessage();
        }
    }
    public void onPostExecute(String str)
    {
        Toast.makeText(this.imageView.getContext(), str, Toast.LENGTH_SHORT).show();
        this.imageView.getContext().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(fileTosave)));
        this.imageView.setDrawingCacheEnabled(false);
        ((Activity) this.context).finish();
    }
}
