package com.kotlinz.videoeditor.activity;

public class FileModel {
    private String fileName;
    private String filePath;
    private int image;
    private boolean isChecked;

    public int getImage() {
        return this.image;
    }

    public String getFileName() {
        return this.fileName;
    }

    public String getFilePath() {
        return this.filePath;
    }

    public FileModel(int i, String str, String str2, boolean z) {
        this.image = i;
        this.fileName = str;
        this.filePath = str2;
        this.isChecked = z;
    }

    public FileModel(int i, String str, String str2) {
        this.image = i;
        this.fileName = str;
        this.filePath = str2;
    }

    public FileModel(String str, String str2, boolean z) {
        this.fileName = str;
        this.filePath = str2;
        this.isChecked = z;
    }

    public boolean isChecked() {
        return this.isChecked;
    }

    public void setChecked(boolean z) {
        this.isChecked = z;
    }

}
