package com.xyz.vehiclemanager.cardetails.carservice.model;

import com.google.gson.annotations.SerializedName;

public class ServiceCenterDetail {
    @SerializedName("name")
    public String name;
    @SerializedName("address")
    public String address;
    @SerializedName("contactNo")
    public String contactNo;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

}
