package com.esc.phoneheart.advancedclean;

import android.view.View;
import android.view.View.OnClickListener;

public class ClickHandler {
    public int mClick = 0;
    public IOnMuliClickListener mListener;
    public OnClickListener mOnClickListener;
    public Runnable mPerformMultiClick = new Runnable() {
        public void run() {
            ClickHandler.this.mWaiting = false;
            ClickHandler clickHandler = ClickHandler.this;
            clickHandler.performClick(clickHandler.mClick);
        }
    };
    public View mView;
    public boolean mWaiting = false;

    public interface IOnMuliClickListener {
        void onMultiClick(View view, int i);
    }

    public ClickHandler(View view, IOnMuliClickListener iOnMuliClickListener) {
        OnClickListener onClick = new OnClickListener() {
            public void onClick(View view) {
                if (!ClickHandler.this.mWaiting) {
                    ClickHandler.this.mClick = 1;
                    ClickHandler.this.mWaiting = true;
                    ClickHandler.this.mView.postDelayed(ClickHandler.this.mPerformMultiClick, 300);
                } else if (ClickHandler.this.mClick >= 5) {
                    ClickHandler.this.mView.removeCallbacks(ClickHandler.this.mPerformMultiClick);
                    ClickHandler.this.mWaiting = false;
                    ClickHandler clickHandler = ClickHandler.this;
                    clickHandler.performClick(clickHandler.mClick);
                    ClickHandler.this.mClick = 0;
                } else {
                    ClickHandler.c(ClickHandler.this);
                    ClickHandler.this.mView.removeCallbacks(ClickHandler.this.mPerformMultiClick);
                    ClickHandler.this.mView.postDelayed(ClickHandler.this.mPerformMultiClick, 300);
                }
            }
        };
        this.mOnClickListener = onClick;
        this.mListener = iOnMuliClickListener;
        this.mView = view;
        view.setOnClickListener(onClick);
    }

    public static int c(ClickHandler clickHandler) {
        int i = clickHandler.mClick + 1;
        clickHandler.mClick = i;
        return i;
    }

    private void performClick(int i) {
        this.mListener.onMultiClick(this.mView, i);
    }

    public OnClickListener getOnClickListener() {
        return this.mOnClickListener;
    }
}
