package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import com.kotlinz.videostatusmaker.adapter.TextAdapter;
import org.jetbrains.annotations.NotNull;

public class ActivitySelectText extends AppCompatActivity {
    Activity activity = ActivitySelectText.this;
    TextAdapter textAdapter;
    ImageView ivBack;
    Typeface typeface;
    GridView gridView;
    String[] styles;
    TextView title;

    GGAdview gg_native;


    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        PutAnalyticsEvent();
        CallNativeAds();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySelectText");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.interstitialAd != null && MyApplication.interstitialAd.isAdLoaded()) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 18;
                        MyApplication.interstitialAd.show();
                        MyApplication.isShowAd = 1;
                    } else {

                    }
                }
                onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.gridView = this.findViewById(R.id.stylelist);
        try {
            this.styles = this.getResources().getAssets().list("fonts");
            this.textAdapter = new TextAdapter(this.getApplicationContext(), this.styles);
            this.gridView.setAdapter((ListAdapter) this.textAdapter);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.gridView.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                ActivityPreview.complete = false;
                final TextView lyric_txt1 = ActivityPreview.lyricTxt1;
                final AssetManager assets = ActivitySelectText.this.getAssets();
                final StringBuilder sb = new StringBuilder();
                sb.append("fonts/");
                sb.append(ActivitySelectText.this.styles[n]);
                lyric_txt1.setTypeface(Typeface.createFromAsset(assets, sb.toString()));
                final TextView lyric_txt2 = ActivityPreview.lyricTxt2;
                final AssetManager assets2 = ActivitySelectText.this.getAssets();
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("fonts/");
                sb2.append(ActivitySelectText.this.styles[n]);
                lyric_txt2.setTypeface(Typeface.createFromAsset(assets2, sb2.toString()));
                ActivitySelectText.this.setResult(-1, new Intent(ActivitySelectText.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectText.this.finish();
            }
        });
    }

    private void CallNativeAds() {
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }
}
