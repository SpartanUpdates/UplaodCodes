package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model;

import java.util.ArrayList;

public class VehicleExpense {

    ArrayList<VehicleExpense> expenseModels;
    int caticon;
    int bid;
    String amount;
    String catname;
    String payee;
    String notes;
    String duedate;

    public VehicleExpense(final String str, final String str2, final String str3, final String str4, final String str5, final int i) {
        this.amount = str;
        this.catname = str2;
        this.payee = str3;
        this.notes = str4;
        this.duedate = str5;
        this.caticon = i;
    }

    public ArrayList<VehicleExpense> getExpenseModels() {
        return this.expenseModels;
    }

    public int getCaticon() {
        return this.caticon;
    }

    public int getBid() {
        return this.bid;
    }

    public String getAmount() {
        return this.amount;
    }

    public String getCatname() {
        return this.catname;
    }

    public String getPayee() {
        return this.payee;
    }

    public String getNotes() {
        return this.notes;
    }

    public String getDuedate() {
        return this.duedate;
    }

    public void setExpenseModels(final ArrayList<VehicleExpense> expenseModels) {
        this.expenseModels = expenseModels;
    }

    public void setCaticon(final int caticon) {
        this.caticon = caticon;
    }

    public void setBid(final int bid) {
        this.bid = bid;
    }

    public void setAmount(final String amount) {
        this.amount = amount;
    }

    public void setCatname(final String catname) {
        this.catname = catname;
    }

    public void setPayee(final String payee) {
        this.payee = payee;
    }

    public void setNotes(final String notes) {
        this.notes = notes;
    }

    public void setDuedate(final String duedate) {
        this.duedate = duedate;
    }

    public void setTotalAmount(final String s) {
    }
}
