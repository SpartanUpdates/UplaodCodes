package com.esc.motivationquotes.receivers;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.media.RingtoneManager;
import android.os.Build.VERSION;
import androidx.core.app.NotificationCompat;
import androidx.core.internal.view.SupportMenu;

import com.esc.motivationquotes.R;
import com.google.gson.Gson;
import com.esc.motivationquotes.Quotes;
import com.esc.motivationquotes.managers.CategoryManager;
import com.esc.motivationquotes.managers.FavoritesManager;
import com.esc.motivationquotes.managers.OwnQuotesManager;
import com.esc.motivationquotes.managers.PastQuotesManager;
import com.esc.motivationquotes.managers.QuotesManager;
import com.esc.motivationquotes.managers.RemindersManager;
import com.esc.motivationquotes.managers.SettingsManager;
import com.esc.motivationquotes.model.Category;
import com.esc.motivationquotes.model.Information;
import com.esc.motivationquotes.model.Pref;
import com.esc.motivationquotes.model.Quote;
import com.esc.motivationquotes.usecases.AddReadQuoteUsecase;
import com.esc.motivationquotes.util.Constants;
import com.esc.motivationquotes.util.QuoteUtils;
import com.esc.motivationquotes.activity.QuotesHomeActivity;
import com.esc.motivationquotes.reminders.RemindersUtils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class AlarmReceiver extends BroadcastReceiver {
    private static final int FAVORITES_RESOURCE_ID = 100;
    private static final int MY_OWN_RESOURCE_ID = 101;
    private static final String NOTIFICATION_CHANNEL_ID = "my_notification_channel";
    private ArrayList<String> quotesList = new ArrayList();

    public void onReceive(Context context, Intent intent) {
        if (Quotes.isInBackground) {
            manageNotification(context);
        }
        RemindersManager.addRemindersLaunched();
        if (RemindersManager.getRemindersLaunched() >= 35) {
            RemindersUtils.setAlarmOnTime(context);
        }
    }

    private void manageNotification(Context context) {
        if (Pref.getValue(context, Constants.IS_SLIDER_ON, "0").equals("1")) {
            int quoteFromType = getQuoteFromType(context);
            if (quoteFromType == 0) {
                Resources resources = context.getResources();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("quotes");
                stringBuilder.append(SettingsManager.getLanguageFiles());
                quoteFromType = resources.getIdentifier(stringBuilder.toString(), "raw", context.getPackageName());
            }
            String randomQuote = getRandomQuote(context, quoteFromType);
            Quote quote = QuoteUtils.getQuote(1, randomQuote, true);
            /*if (SettingsManager.isPremium()) {
                generateNotification(context, quote.getText(), quote.getText());
            } else {
                generateNotification(context, QuoteUtils.cutReminderQuote(quote.getText()), randomQuote);
            }*/
        }
    }

    @SuppressLint("WrongConstant")
    private static void generateNotification(Context context, String str, String str2) {
        PastQuotesManager.addPastQuote(str2);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        Intent intent = new Intent(context, QuotesHomeActivity.class);
        intent.putExtra(Constants.NOTIFICATION_MESSAGE, str2);
        intent.addFlags(603979776);
        PendingIntent activity = PendingIntent.getActivity(context, (int) System.currentTimeMillis(), intent, 134217728);
        int i = VERSION.SDK_INT;
        String str3 = NOTIFICATION_CHANNEL_ID;
        if (i >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(str3, "My Notifications", 3);
            notificationChannel.setDescription("Channel description");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(SupportMenu.CATEGORY_MASK);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(false);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        notificationManager.notify(createID(), new NotificationCompat.Builder(context, str3).setSound(RingtoneManager.getDefaultUri(2)).setSmallIcon(R.drawable.ic_notification).setContentTitle(context.getResources().getString(R.string.app_name)).setContentIntent(activity).setAutoCancel(true).setPriority(0).setStyle(new NotificationCompat.BigTextStyle().bigText(str)).setContentText(str).build());
    }

    private String getRandomQuote(Context context, int i) {
        loadQuotes(context, i);
        if (this.quotesList.isEmpty()) {
            QuotesManager.removeQuotesRead();
            loadQuotes(context, i);
        }
        int quoteReminderPosition = QuotesManager.getQuoteReminderPosition();
        if (quoteReminderPosition >= this.quotesList.size()) {
            quoteReminderPosition = 0;
        }
        String str = (String) this.quotesList.get(quoteReminderPosition);
        QuotesManager.setQuoteReminderPosition(quoteReminderPosition + 1);
        new AddReadQuoteUsecase(str).execute();
        return str;
    }

    private void loadQuotes(Context context, int i) {
        ArrayList arrayList = new ArrayList();
        this.quotesList = arrayList;
        if (i == 100) {
            arrayList.addAll(FavoritesManager.getFavorites());
        } else if (i == 101) {
            arrayList.addAll(OwnQuotesManager.getOwnQuotes());
        } else {
            Resources resources = context.getResources();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("quotes");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            if (i == resources.getIdentifier(stringBuilder.toString(), "raw", context.getPackageName())) {
                addQuotesByApp(context);
            } else {
                addQuotesFromFile(context, i);
            }
        }
        removeReadQuotesAndSort();
    }

    public static int createID() {
        return Integer.parseInt(new SimpleDateFormat("ddHHmmss", Locale.US).format(new Date()));
    }

    private int getQuoteFromType(Context context) {
        ArrayList categoriesReminders = CategoryManager.getCategoriesReminders();
        String str = "quotes";
        String str2 = "raw";
        Resources resources;
        StringBuilder stringBuilder;
        if (categoriesReminders.isEmpty()) {
            resources = context.getResources();
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(SettingsManager.getLanguageFiles());
            return resources.getIdentifier(stringBuilder.toString(), str2, context.getPackageName());
        }
        Resources resources2;
        StringBuilder stringBuilder2;
        int nextInt = new Random().nextInt(((categoriesReminders.size() - 1) + 0) + 1) + 0;
        if (categoriesReminders.get(nextInt) == null || ((Category) categoriesReminders.get(nextInt)).getId() == null) {
            resetCategoryReminders(context);
        } else {
            String str3 = "favorites";
            String str4 = "my_affirmations";
            if (((Category) categoriesReminders.get(nextInt)).getId().equals(str3) || ((Category) categoriesReminders.get(nextInt)).getId().equals(str4)) {
                if (((Category) categoriesReminders.get(nextInt)).getId().equals(str3) && FavoritesManager.getFavorites().size() > 0) {
                    return 100;
                }
                if (((Category) categoriesReminders.get(nextInt)).getId().equals(str4) && OwnQuotesManager.getOwnQuotes().size() > 0) {
                    return 101;
                }
                if (categoriesReminders.size() == 1) {
                    resources = context.getResources();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(SettingsManager.getLanguageFiles());
                    return resources.getIdentifier(stringBuilder.toString(), str2, context.getPackageName());
                }
                categoriesReminders.remove(nextInt);
                nextInt = new Random().nextInt(((categoriesReminders.size() - 1) + 0) + 1) + 0;
                resources2 = context.getResources();
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(((Category) categoriesReminders.get(nextInt)).getId());
                stringBuilder2.append(SettingsManager.getLanguageFiles());
                return resources2.getIdentifier(stringBuilder2.toString(), str2, context.getPackageName());
            }
        }
        resources2 = context.getResources();
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(((Category) categoriesReminders.get(nextInt)).getId());
        stringBuilder2.append(SettingsManager.getLanguageFiles());
        return resources2.getIdentifier(stringBuilder2.toString(), str2, context.getPackageName());
    }

    public void addQuotesFromFile(Context context, int i) {
        if (i == 0) {
            Resources resources = context.getResources();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("quotes");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            i = resources.getIdentifier(stringBuilder.toString(), "raw", context.getPackageName());
        }
        ArrayList arrayList = new ArrayList();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(context.getResources().openRawResource(i), "utf-8"));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    this.quotesList.addAll(arrayList);
                    return;
                } else if (!(arrayList.contains(readLine) || this.quotesList.contains(readLine))) {
                    arrayList.add(readLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removeReadQuotesAndSort() {
        ArrayList readQuotes = QuotesManager.getReadQuotes();
        if (readQuotes != null) {
            this.quotesList.removeAll(readQuotes);
        }
        readQuotes = new ArrayList();
        ArrayList arrayList = new ArrayList();
        readQuotes.addAll(this.quotesList);
        Iterator it = readQuotes.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            int min = Math.min(10, arrayList.size());
            arrayList.add(Math.max(0, arrayList.size() - (min != 0 ? new Random().nextInt(min) : 0)), str);
        }
        this.quotesList.clear();
        this.quotesList.addAll(arrayList);
    }

    private void addQuotesByApp(Context context) {
        String languageFiles = SettingsManager.getLanguageFiles();
        Resources resources = context.getResources();
        String packageName = context.getPackageName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("quotes");
        stringBuilder.append(languageFiles);
        addQuotesFromFile(context, resources.getIdentifier(stringBuilder.toString(), "raw", packageName));
    }

    private void resetCategoryReminders(Context context) {
        Information informationJson = getInformationJson(context);
        CategoryManager.clearCategoriesReminder();
        CategoryManager.addCategoryReminder((Category) informationJson.getCategories().get(0));
    }

    public Information getInformationJson(Context context) {
        try {
            AssetManager assets = context.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("information");
            stringBuilder.append(SettingsManager.getLanguageFiles());
            stringBuilder.append(".json");
            InputStream open = assets.open(stringBuilder.toString());
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return (Information) new Gson().fromJson(new String(bArr, "UTF-8"), Information.class);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
