package com.kotlinz.festivalstorymaker.Other.l.a.b.a;


import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import androidx.transition.Slide;
import androidx.transition.Transition;
import androidx.transition.TransitionManager;
import com.appizona.yehiahd.fastsave.FastSave;
import com.kotlinz.festivalstorymaker.Other.AppConstant;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class a {

    public static double a(final double n, final double n2, final double n3, final double n4) {
        return (n + n2 + n3) / n4;
    }

    public static float m(final float n, final float n2, final float n3, final float n4) {
        return n * n2 + n3 + n4;
    }

    public static void B(final int n, final long duration, final int n2, final ViewGroup viewGroup) {
        final Slide slide = new Slide(n);
        ((Transition) slide).setDuration(duration);
        ((Transition) slide).addTarget(n2);
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) slide);
    }

    public static String r(StringBuilder stringBuilder, String str, String str2) {
        stringBuilder.append(str);
        stringBuilder.append(str2);
        return stringBuilder.toString();
    }


    public static void G(final ArrayList list, final TextStickerViewNew1 textStickerViewNew1) {
        textStickerViewNew1.setTag((Object) list.size());
    }

    public static View K(final int n, final int n2, final View view, final int n3) {
        view.setLayoutParams((ViewGroup.LayoutParams) new RelativeLayout.LayoutParams(n, n2));
        return view.findViewById(n3);
    }


    public static String s(SimpleDateFormat simpleDateFormat) {
        return simpleDateFormat.format(new Date());
    }

    public static StringBuilder v(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        return sb;
    }


    public static StringBuilder z(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(str2);
        return stringBuilder;
    }

    public static float x(final float n, final float n2, final float n3, final float n4, final float n5) {
        return n4 - (n - n2) / n3 + n5;
    }


    public static boolean h0() {
        return new AppConstant().j();
    }

    public static FastSave j(final FastSave fastSave, final String s, final String s2, final EditText editText) {
        editText.setText((CharSequence) FastSave.getInstance().getString(s, s2));
        return FastSave.getInstance();
    }

}
