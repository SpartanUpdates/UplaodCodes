package com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.kotlinz.vehiclemanager.vehicledetails.vehiclemileage.model.Mileage;

@Database(entities = {Mileage.class},version = 1 ,exportSchema = false)
public abstract class MileageDatabase extends RoomDatabase {
    public static MileageDatabase mileageDatabase;
    public abstract MileageDao mileageDao();

    public static MileageDatabase getMileageDatabase(final  Context context)
    {
        if(mileageDatabase==null)
        {
            synchronized (MileageDatabase.class)
            {
                if(mileageDatabase==null)
                {
                    mileageDatabase=Room.databaseBuilder(context,MileageDatabase.class,"MileageDatabase").allowMainThreadQueries().build();
                }
            }
        }
        return mileageDatabase;
    }
}
