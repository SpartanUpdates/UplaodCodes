package com.esc.gesturelockscreen.Other;


import com.esc.gesturelockscreen.R;

public class Constant {

    public static Integer[] arrBG = new Integer[]{Integer.valueOf(R.drawable.music_bg1), Integer.valueOf(R.drawable.music_bg2), Integer.valueOf(R.drawable.music_bg3), Integer.valueOf(R.drawable.music_bg4), Integer.valueOf(R.drawable.music_bg5), Integer.valueOf(R.drawable.music_bg6), Integer.valueOf(R.drawable.music_bg7), Integer.valueOf(R.drawable.music_bg8), Integer.valueOf(R.drawable.music_bg9), Integer.valueOf(R.drawable.music_bg10), Integer.valueOf(R.drawable.music_bg11), Integer.valueOf(R.drawable.music_bg12), Integer.valueOf(R.drawable.music_bg13), Integer.valueOf(R.drawable.music_bg14), Integer.valueOf(R.drawable.music_bg15), Integer.valueOf(R.drawable.music_bg16), Integer.valueOf(R.drawable.music_bg17), Integer.valueOf(R.drawable.music_bg18), Integer.valueOf(R.drawable.music_bg19), Integer.valueOf(R.drawable.music_bg20)};
    public static Integer[] arrThumb = new Integer[]{Integer.valueOf(R.drawable.thumbmusic_bg1), Integer.valueOf(R.drawable.thumbmusic_bg2), Integer.valueOf(R.drawable.thumbmusic_bg3), Integer.valueOf(R.drawable.thumbmusic_bg4), Integer.valueOf(R.drawable.thumbmusic_bg5), Integer.valueOf(R.drawable.thumbmusic_bg6), Integer.valueOf(R.drawable.thumbmusic_bg7), Integer.valueOf(R.drawable.thumbmusic_bg8), Integer.valueOf(R.drawable.thumbmusic_bg9), Integer.valueOf(R.drawable.thumbmusic_bg10), Integer.valueOf(R.drawable.thumbmusic_bg11), Integer.valueOf(R.drawable.thumbmusic_bg12), Integer.valueOf(R.drawable.thumbmusic_bg13), Integer.valueOf(R.drawable.thumbmusic_bg14), Integer.valueOf(R.drawable.thumbmusic_bg15), Integer.valueOf(R.drawable.thumbmusic_bg16), Integer.valueOf(R.drawable.thumbmusic_bg17), Integer.valueOf(R.drawable.thumbmusic_bg18), Integer.valueOf(R.drawable.thumbmusic_bg19), Integer.valueOf(R.drawable.thumbmusic_bg20)};
}
