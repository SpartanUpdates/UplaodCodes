package com.esc.mynameringtonemaker.Common;

public enum ToneType {
    RINGTONE,
    SMS_TONE,
    ALARM_TONE
}
