package com.esc.dailyrandomfacts.util;

import com.esc.dailyrandomfacts.model.Quote;
import java.util.ArrayList;

public class QuoteUtils {
    public static final int AVERAGE_LINES = 5;

    public static Quote getQuote(int i, String str, boolean z) {
        String str2;
        Quote quote = new Quote();
        if (i == 0) {
            i = 5;
        }
        String str3 = "";
        if (str.contains("@@")) {
            str2 = " @@ ";
            String str4 = str.split(str2)[0];
            str2 = str.split(str2).length > 1 ? str.split(str2)[1] : str3;
            str = str4;
        } else {
            str2 = str3;
        }
        if (!z) {
            str = addBreakLinesAfterDot(i, str, str3);
        }
        if (str.contains("SHOW AD #")) {
            str = str.split("#")[1];
        }
        quote.setText(str);
        quote.setAuthor(str3);
        quote.setLink(str2);
        return quote;
    }

    public static String getQuoteLink(String str) {
        return str.contains("@@") ? str.split(" @@ ")[1] : null;
    }

    public static String cutReminderQuote(String str) {
        if (str.length() > 80) {
            String substring;
            String str2 = "...";
            if (str.length() > 95) {
                substring = str.substring(0, 95);
                String str3 = " is ";
                if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                    str3 = " and ";
                    if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                        str3 = " for ";
                        if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                            str3 = " to ";
                            if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                str3 = " from ";
                                if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                    str3 = " the ";
                                    if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                        str3 = " as ";
                                        if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                            str3 = " will ";
                                            if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                                str3 = " with ";
                                                if (!substring.contains(str3) || substring.indexOf(str3) <= 70) {
                                                    str3 = " are ";
                                                    substring = (!substring.contains(str3) || substring.indexOf(str3) <= 70) ? "" : substring.substring(0, substring.indexOf(str3) + 4);
                                                } else {
                                                    substring = substring.substring(0, substring.indexOf(str3) + 5);
                                                }
                                            } else {
                                                substring = substring.substring(0, substring.indexOf(str3) + 5);
                                            }
                                        } else {
                                            substring = substring.substring(0, substring.indexOf(str3) + 3);
                                        }
                                    } else {
                                        substring = substring.substring(0, substring.indexOf(str3) + 4);
                                    }
                                } else {
                                    substring = substring.substring(0, substring.indexOf(str3) + 5);
                                }
                            } else {
                                substring = substring.substring(0, substring.indexOf(str3) + 3);
                            }
                        } else {
                            substring = substring.substring(0, substring.indexOf(str3) + 4);
                        }
                    } else {
                        substring = substring.substring(0, substring.indexOf(str3) + 4);
                    }
                } else {
                    substring = substring.substring(0, substring.indexOf(str3) + 3);
                }
                if (!substring.isEmpty()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(substring);
                    stringBuilder.append(str2);
                    return stringBuilder.toString();
                }
            }
            substring = str.substring(80);
            if (substring.contains(" ")) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str.substring(0, 80));
                stringBuilder2.append(substring.substring(0, substring.indexOf(32)));
                str = stringBuilder2.toString();
            }
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(str);
            stringBuilder3.append(str2);
            str = stringBuilder3.toString();
        }
        return str;
    }

    public static String addBreakLinesAfterDot(int i, String str, String str2) {
        String replaceAll;
        String str3 = "...";
        String str4 = "_Ç_";
        String str5 = "$0\n";
        str = str.replace(str3, str4).replaceAll("[.]", str5);
        if (i < 5) {
            replaceAll = str.replaceAll("[!?;:,]", str5);
        } else {
            replaceAll = str.replaceAll("[!?;:]", str5);
        }
        if (str2.isEmpty()) {
            replaceAll = replaceAll.trim();
        }
        return replaceAll.replace(str4, str3);
    }

    private void doRandomQuotes(ArrayList<Quote> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
        }
    }
}
