package com.esc.hinditarot;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.ironsource.sdk.constants.Constants.ParametersKeys;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class DisplayResult extends AppCompatActivity {
    public  Activity activity = DisplayResult.this;
    public static Editor editor = null;
    public static Typeface georgiar = null;
    public static SharedPreferences sharedPreferences = null;
    private static boolean showPopupAds = false;
    Bundle b;
    ImageView card1;
    String cardname;
    String cardname2;
    String category;
    String ccb;
    Dialog dialogR;
    int[] resids = new int[5];
    public Boolean result_backpreesed;
    String[] results = new String[5];
    Boolean shareclickResume;
    TextView thead;
    TextView trestext;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public DisplayResult() {
        Boolean valueOf = Boolean.valueOf(false);
        this.shareclickResume = valueOf;
        this.result_backpreesed = valueOf;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_display_result);
        georgiar = Typeface.createFromAsset(getAssets(), "fonts/georgiar.ttf");
        getSupportActionBar().setHomeButtonEnabled(true);
        String charSequence = "";
        getSupportActionBar().setTitle(charSequence);
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_actionbar_layout, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        showPopupAds = false;
        textView.setTypeface(georgiar);
        sharedPreferences = getApplicationContext().getSharedPreferences("MYPREF", 0);
        editor = sharedPreferences.edit();
        this.b = getIntent().getExtras();
        this.cardname = this.b.getString("SELECTED_CARD");
        this.cardname2 = this.b.getString("SELECTED_CARD_E");
        this.category = this.b.getString("SELECTED_CATEGORY");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("cardname ");
        stringBuilder.append(this.cardname);
        stringBuilder.append("cardname2 ");
        stringBuilder.append(this.cardname2);
        stringBuilder.append("category ");
        stringBuilder.append(this.category);
        String str = "card";
        Log.d(str, stringBuilder.toString());
        textView.setText(this.category);
        setTitle(this.category);
        String str2 = " ";
        String str3 = "-";
        this.resids[0] = getResources().getIdentifier(this.cardname2.toLowerCase().replaceAll(str2, charSequence).replaceAll(str3, charSequence), "drawable", getPackageName());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(charSequence);
        stringBuilder2.append(this.cardname.toLowerCase().replaceAll(str2, charSequence).replaceAll(str3, charSequence));
        Log.e("*****", stringBuilder2.toString());
        this.trestext = (TextView) findViewById(R.id.restext);
        this.thead = (TextView) findViewById(R.id.cardname1);
        this.card1 = (ImageView) findViewById(R.id.card1);
        this.card1.setImageResource(this.resids[0]);
        this.ccb = this.b.getString("SELECTED_CATEGORY_EN");
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("cbb value is:");
        stringBuilder2.append(this.ccb);
        Log.d(str, stringBuilder2.toString());
        this.trestext.setTypeface(georgiar);
        this.thead.setTypeface(georgiar);
        String[] strArr = new String[]{this.cardname2};
        stringBuilder = new StringBuilder();
        stringBuilder.append(getResources().getString(R.string.fetchingfile));
        stringBuilder.append(this.ccb);
        stringBuilder.append("/");
        stringBuilder.append(this.ccb.replace(str2, charSequence));
        stringBuilder.append(".xml");
        boolean resultString = resultString(stringBuilder.toString(), strArr);
        String str4 = "XML";
        if (resultString) {
            this.thead.setText(this.cardname);
            this.trestext.setText(this.results[0]);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(charSequence);
            stringBuilder2.append(this.cardname2);
            stringBuilder2.append("\n");
            stringBuilder2.append(this.results[0]);
            Log.e(ParametersKeys.DISPLAY, stringBuilder2.toString());
        }
        str4 = "inappreview";
        editor.putInt(str4, sharedPreferences.getInt(str4, 0) + 1).apply();
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return true;
        } else if (itemId != R.id.imgShare) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            shareclick();
            return true;
        }
    }

    public void shareclick() {
        AddRateClicks();
        TextView textView = new TextView(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getResources().getString(R.string.share1));
        stringBuilder.append(" \"");
        stringBuilder.append(this.category);
        stringBuilder.append("\" ");
        stringBuilder.append(getResources().getString(R.string.sharer));
        stringBuilder.append("<br><br><b>");
        stringBuilder.append(this.cardname);
        stringBuilder.append("</b><br>");
        String str = "<br>";
        String str2 = "\n";
        stringBuilder.append(this.results[0].replaceAll(str2, str));
        String str3 = "<br><br>";
        stringBuilder.append(str3);
        stringBuilder.append(getResources().getString(R.string.share2));
        stringBuilder.append(str3);
        stringBuilder.append("https://play.google.com/store/apps/details?id="+  getApplicationContext().getPackageName());
        textView.setText(Html.fromHtml(stringBuilder.toString()));
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", textView.getText().toString().replaceAll(str, str2));
        intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share3)));
        Map hashMap = new HashMap();
        String str4 = "Share";
        hashMap.put(str4, "SELECTED_CATEGORY_EN");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.share_resource, menu);
        return true;
    }

    public boolean resultString(String str, String[] strArr) {
        boolean z;
        XmlPullParserException e;
        IOException e2;
        String str2 = "tag error";
        String str3 = "";
        String[] strArr2 = new String[5];
        String[] strArr3 = new String[5];
        String[] strArr4 = new String[5];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(".............");
        stringBuilder.append(str);
        Log.e("filename", stringBuilder.toString());
        for (int i = 0; i < strArr.length; i++) {
            strArr3[i] = strArr[i].toUpperCase().replace(" ", "-");
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("cname = ");
            stringBuilder2.append(strArr3[i]);
        }
        String[] strArr5 = new String[]{"-ONE"};
        try {
            XmlPullParser newPullParser = XmlPullParserFactory.newInstance().newPullParser();
            InputStream open = getApplicationContext().getAssets().open(str);
            newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
            newPullParser.setInput(open, null);
            int i2 = 0;
            z = false;
            while (i2 < 5) {
                try {
                    for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.next()) {
                        String name;
                        StringBuilder stringBuilder3;
                        if (eventType == 0) {
                            name = newPullParser.getName();
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("************** ");
                            stringBuilder3.append(name);
                            Log.e(str3, stringBuilder3.toString());
                        } else if (eventType == 2) {
                            name = newPullParser.getName();
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("tag name ");
                            stringBuilder3.append(name);
                            Log.e(str3, stringBuilder3.toString());
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(strArr3[0]);
                            stringBuilder3.append(strArr5[0]);
                            if (name.contains(stringBuilder3.toString())) {
                                strArr2[0] = newPullParser.nextText();
                            }
                        } else if (eventType == 3) {
                            if (newPullParser.getName().contains("ROOT")) {
                                int i3 = 0;
                                while (i3 < strArr2.length) {
                                    this.results[i3] = strArr2[i3];
                                    i3++;
                                }
                                z = true;
                            }
                        }
                    }
                    i2++;
                } catch (XmlPullParserException e5) {
                    e = e5;
                    e.printStackTrace();
                    Log.e(str3, str2);
                    return z;
                } catch (IOException e6) {
                    e2 = e6;
                    e2.printStackTrace();
                    Log.e(str3, str2);
                    return z;
                }
            }
        } catch (XmlPullParserException e7) {
            e = e7;
            z = false;
            e.printStackTrace();
            Log.e(str3, str2);
            return z;
        } catch (IOException e8) {
            e2 = e8;
            z = false;
            e2.printStackTrace();
            Log.e(str3, str2);
            return z;
        }
        return z;
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public void AddRateClicks() {
        String str = "count";
        if (sharedPreferences.getInt(str, 0) < 13) {
            int i = sharedPreferences.getInt(str, 0) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
        }
    }
}
