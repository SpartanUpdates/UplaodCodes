package com.kotlinz.videoeditor.videosplitter.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.ConnectivityManager;
import android.net.ParseException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Video.Media;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.concurrent.TimeUnit;



@SuppressLint({"WrongConstant"})
public class VideoSplitPreviewActivity extends AppCompatActivity implements OnSeekBarChangeListener {
    static final boolean r = true;
    Bundle a;
    ImageView imageView;
    int c = 0;
    Handler handler = new Handler();
    boolean e = false;
    int f = 0;
    SeekBar seekBar;
    Uri h;
    TextView i;
    TextView j;
    TextView k;
    String m = "";
    VideoView videoView;
    Uri o;
    Runnable p = new Runnable() {
        public void run() {
            if (videoView.isPlaying()) {
                int currentPosition = videoView.getCurrentPosition();
                seekBar.setProgress(currentPosition);
                try {
                    i.setText(formatTimeUnit(currentPosition));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (currentPosition == c) {
                    seekBar.setProgress(0);
                    i.setText("00:00");
                    handler.removeCallbacks(VideoSplitPreviewActivity.this.p);
                    return;
                }
                handler.postDelayed(p, 200);
                return;
            }
            seekBar.setProgress(c);
            try {
                i.setText(formatTimeUnit(c));
            } catch (ParseException e2) {
                e2.printStackTrace();
            }
            handler.removeCallbacks(p);
        }
    };
    OnClickListener q = new OnClickListener() {
        @Override public void onClick(View view) {
            if (e) {
                try {
                    videoView.pause();
                    handler.removeCallbacks(p);
                    imageView.setBackgroundResource(R.drawable.ic_play_upress);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    videoView.seekTo(seekBar.getProgress());
                    videoView.start();
                    handler.postDelayed(p, 200);
                    videoView.setVisibility(0);
                    imageView.setBackgroundResource(R.drawable.ic_pause_unpresss);
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            e ^= r;
        }
    };


    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }


    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView( R.layout.videoplayer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText("Splitter Preview");
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        PutAnalyticsEvent();
        if (r || supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(r);
            supportActionBar.setDisplayShowTitleEnabled(false);
            a = getIntent().getExtras();
            if (a != null) {
                m = a.getString("song");
                f = a.getInt("position", 0);
            }
            try {
                GetVideo(getApplicationContext(), m);
            } catch (Exception unused) {
                unused.printStackTrace();
            }
            k = findViewById(R.id.Filename);
            videoView = findViewById(R.id.videoView);
            seekBar = findViewById(R.id.sbVideo);
            seekBar.setOnSeekBarChangeListener(this);
            i = findViewById(R.id.left_pointer);
            j = findViewById(R.id.right_pointer);
            imageView = findViewById(R.id.btnPlayVideo);
            k.setText(new File(m).getName());
            videoView.setVideoPath(m);
            videoView.seekTo(100);
            videoView.setOnErrorListener(new OnErrorListener() {
                public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                    Toast.makeText(getApplicationContext(), "Video Player Not Supproting", 0).show();
                    return VideoSplitPreviewActivity.r;
                }
            });
            videoView.setOnPreparedListener(new OnPreparedListener() {
                public void onPrepared(MediaPlayer mediaPlayer) {
                    c = videoView.getDuration();
                    seekBar.setMax(c);
                    i.setText("00:00");
                    try {
                        StringBuilder sb = new StringBuilder();
                        sb.append("duration : ");
                        sb.append(formatTimeUnit(c));
                        j.setText(formatTimeUnit(c));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            });
            videoView.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    videoView.setVisibility(0);
                    imageView.setBackgroundResource(R.drawable.ic_play_upress);
                    videoView.seekTo(0);
                    seekBar.setProgress(0);
                    i.setText("00:00");
                    handler.removeCallbacks(p);
                    e ^= VideoSplitPreviewActivity.r;
                }
            });
            imageView.setOnClickListener(q);


        } else {
            throw new AssertionError();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoSplitPreviewActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public boolean isOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager.getActiveNetworkInfo() == null || !connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting()) {
            return false;
        }
        return r;
    }

    public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
        if (z) {
            videoView.seekTo(i2);
            try {
                i.setText(formatTimeUnit(i2));
            } catch (ParseException e2) {
                e2.printStackTrace();
            }
        }
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    public void GetVideo(Context context, String str) {
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        String[] strArr = {"_id", "_data", "_display_name", "_size", "duration", "date_added", "album"};
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        sb.append(str);
        sb.append("%");
        String[] strArr2 = {sb.toString()};
        Cursor managedQuery = managedQuery(uri, strArr, "_data  like ?", strArr2, " _id DESC");
        if (managedQuery.moveToFirst()) {
            try {
                Uri withAppendedPath = Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, getLong(managedQuery));
                o = withAppendedPath;
                h = withAppendedPath;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public static String getLong(Cursor cursor) {
        return String.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("_id")));
    }

    public void Delete() {
        new AlertDialog.Builder(this).setMessage("Are you sure you want to delete this file ?").setPositiveButton("delete", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialogInterface, int i) {
                File file = new File(m);
                if (file.exists()) {
                    file.delete();
                    try {
                        ContentResolver contentResolver = getContentResolver();
                        Uri uri = o;
                        StringBuilder sb = new StringBuilder();
                        sb.append("_data=\"");
                        sb.append(m);
                        sb.append("\"");
                        contentResolver.delete(uri, sb.toString(), null);
                    } catch (Exception unused) {
                    }
                }
                onBackPressed();
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).setCancelable(r).show();
    }

    @Override public void onBackPressed() {
        super.onBackPressed();
         {
            Intent intent9 = new Intent(this, MyAlbumActivity.class);
            intent9.setFlags(67108864);
            startActivity(intent9);
            finish();
        }
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_deleteshare, menu);
        return r;
    }

   @Override public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return r;
        }
        if (menuItem.getItemId() == R.id.Delete) {
            if (videoView.isPlaying()) {
                try {
                    videoView.pause();
                    handler.removeCallbacks(p);
                    imageView.setBackgroundResource(R.drawable.play2);
                    e = false;
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
            Delete();
        } else if (menuItem.getItemId() == R.id.Share) {
            if (videoView.isPlaying()) {
                videoView.pause();
                handler.removeCallbacks(p);
                imageView.setBackgroundResource(R.drawable.play2);
                e = false;
            }
            try {
                File file = new File(m);

                Uri screenshotUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file);
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("video/*");
                intent.putExtra("android.intent.extra.STREAM", screenshotUri);
                startActivity(Intent.createChooser(intent, "Share File"));

            } catch (Exception unused) {
                unused.printStackTrace();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
