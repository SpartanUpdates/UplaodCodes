package com.esc.lovemessages;

import android.graphics.Bitmap;
import android.util.Log;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MemoryCache {
    private static final String TAG = "MemoryCache";
    private Map<String, Bitmap> cache = Collections.synchronizedMap(new LinkedHashMap(10, 1.5f, true));
    private long limit = 1000000;
    private long size = 0;

    public MemoryCache() {
        setLimit(Runtime.getRuntime().maxMemory() / 4);
    }

    public void setLimit(long j) {
        this.limit = j;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MemoryCache will use up to ");
        double d = (double) this.limit;
        Double.isNaN(d);
        stringBuilder.append((d / 1024.0d) / 1024.0d);
        stringBuilder.append("MB");
        Log.i(TAG, stringBuilder.toString());
    }

    public Bitmap get(String str) {
        try {
            if (this.cache.containsKey(str)) {
                return (Bitmap) this.cache.get(str);
            }
            return null;
        } catch (NullPointerException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void put(String str, Bitmap bitmap) {
        try {
            if (this.cache.containsKey(str)) {
                this.size -= getSizeInBytes((Bitmap) this.cache.get(str));
            }
            this.cache.put(str, bitmap);
            this.size += getSizeInBytes(bitmap);
            checkSize();
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    private void checkSize() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("cache size=");
        stringBuilder.append(this.size);
        stringBuilder.append(" length=");
        stringBuilder.append(this.cache.size());
        String stringBuilder2 = stringBuilder.toString();
        String str = TAG;
        Log.i(str, stringBuilder2);
        if (this.size > this.limit) {
            Iterator it = this.cache.entrySet().iterator();
            while (it.hasNext()) {
                this.size -= getSizeInBytes((Bitmap) ((Entry) it.next()).getValue());
                it.remove();
                if (this.size <= this.limit) {
                    break;
                }
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append("Clean cache. New size ");
            stringBuilder.append(this.cache.size());
            Log.i(str, stringBuilder.toString());
        }
    }

    public void clear() {
        try {
            this.cache.clear();
            this.size = 0;
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }


    public long getSizeInBytes(Bitmap bitmap) {
        return bitmap == null ? 0 : (long) (bitmap.getRowBytes() * bitmap.getHeight());
    }
}
