package com.esc.phoneheart.advancedclean;

public class StepClean extends Step {
    public static final String TAG = "StepClean";
    public BaseActivity mActivity;

    public StepClean(BaseActivity baseActivity) {
        this.mActivity = baseActivity;
    }

    public void doAction() {
    }
}
