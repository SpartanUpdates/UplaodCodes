package com.esc.motivationquotes.managers;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import com.google.gson.Gson;
import com.esc.motivationquotes.Quotes;
import com.esc.motivationquotes.model.Theme;

public class ThemeManager {
    private static final String NUM_REWARDED_OFFLINE = "num_rewarded_offline";
    private static final String PREF_THEME = "pref_theme_com.esc.motivationquotes.motivation";

    public static void saveThemeData(Theme theme) {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        if (theme != null) {
            edit.putString(PREF_THEME, new Gson().toJson((Object) theme));
        }
        edit.commit();
    }

    public static Theme getTheme() {
        String string = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_THEME, null);
        if (string != null) {
            return (Theme) new Gson().fromJson(string, Theme.class);
        }
        return null;
    }

    public static void incrementNumberOfflineRewardeds() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        edit.putInt(NUM_REWARDED_OFFLINE, getNumberOfflineRewardeds() + 1);
        edit.commit();
    }

    public static int getNumberOfflineRewardeds() {
        return PreferenceManager.getDefaultSharedPreferences(getContext()).getInt(NUM_REWARDED_OFFLINE, 0);
    }

    private static Context getContext() {
        return Quotes.getInstance();
    }
}
