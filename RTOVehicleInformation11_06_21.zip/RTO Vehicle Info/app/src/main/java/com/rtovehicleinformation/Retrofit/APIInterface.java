package com.rtovehicleinformation.Retrofit;

import com.google.gson.JsonObject;
import com.rtovehicleinformation.Model.OwnerRootPaidModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface APIInterface {

   /* @POST("searchVehicleDetails")
    @FormUrlEncoded
    Call<JsonObject> GetVehicleDetail(@Field("registrationNo") String VehicleNo);*/


    @FormUrlEncoded
    @POST("v1/vehicle_info")
    Call<OwnerRootPaidModel> getVehicleOwnerDetails(@Header("Referer") String referee, @Header("API-KEY")String apikey, @Field("vehicleId")String vehicleId);

}
