package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew.c;

public class HighLightDetailsSticker implements c {
    public final  ImageStickerViewNew imageStickerViewNew;
    public final  HighlightDetailsDetailActivity b;

    public HighLightDetailsSticker(HighlightDetailsDetailActivity highlightDetailsDetailActivity, ImageStickerViewNew imageStickerViewNew) {
        this.b = highlightDetailsDetailActivity;
        this.imageStickerViewNew = imageStickerViewNew;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        this.b.svScroll.requestDisallowInterceptTouchEvent(true);
        ImageStickerViewNew imageStickerViewNew2 = this.b.T;
        if (imageStickerViewNew2 != null) {
            imageStickerViewNew2.setInEdit(false);
        }
        this.b.T = imageStickerViewNew;
        imageStickerViewNew.setInEdit(true);
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        this.b.flElements.removeView(imageStickerViewNew);
    }

    public void c(Boolean bool) {
        if (bool.booleanValue()) {
            this.b.T = this.imageStickerViewNew;
        }
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {

    }
}
