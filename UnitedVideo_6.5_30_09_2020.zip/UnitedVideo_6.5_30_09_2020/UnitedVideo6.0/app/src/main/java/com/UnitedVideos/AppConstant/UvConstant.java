package com.UnitedVideos.AppConstant;

public class UvConstant {
    public static String BundelPath;
    public static String PrefebName;
    public static String AudioPath;
    public static String VideoType;
    public static int ImageWidth ;
    public static int ImageHeight ;
    public static int NoofImage ;
}
