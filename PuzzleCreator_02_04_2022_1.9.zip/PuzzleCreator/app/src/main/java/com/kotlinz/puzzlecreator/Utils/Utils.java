package com.kotlinz.puzzlecreator.Utils;

import android.os.Environment;
import java.io.File;

public class Utils {
    public static final Utils INSTANCE;

    static {
        INSTANCE = new Utils();
    }


    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/ Puzzle /";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public final String getAPPFOLDER() {
        return "Puzzle";
    }

    public final String getOutputPathExternalStorage() {
        final String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getPuzzleImage() {
        final String path = this.getOutputPathExternalStorage() + "Share Puzzle Image" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

}
