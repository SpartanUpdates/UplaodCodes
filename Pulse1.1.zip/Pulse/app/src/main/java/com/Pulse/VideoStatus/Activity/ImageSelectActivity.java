package com.Pulse.VideoStatus.Activity;


import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.Pulse.VideoStatus.Adapter.AlbumWiseFolder;
import com.Pulse.VideoStatus.Adapter.ImageAlbumAdapter;
import com.Pulse.VideoStatus.Adapter.SelectedImageAdapter;
import com.Pulse.VideoStatus.Interface.OnItemClickListner;
import com.Pulse.VideoStatus.Model.ImageInfo;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.View.ExpandableView;
import com.Pulse.VideoStatus.application.MyApplication;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.util.ArrayList;


public class ImageSelectActivity extends AppCompatActivity {

    public static final String EXTRA_FROM_PREVIEW = "extra_from_preview";
    public static ArrayList<ImageInfo> tempImage = new ArrayList();
    public static boolean isFirstImage = false;
    public static AlbumWiseFolder albumWiseImageAdapter;
    public RelativeLayout rlRootlayout;
    public boolean isFromPreview = false;
    public String PathOfImage;
    public ExpandableView ViewexpandIcon;
    public boolean v = false;
    public Dialog Cropdialog;
    Activity activity = ImageSelectActivity.this;
    ImageView ivBack;
    TextView tvDone;
    int NOofImage;
    ArrayList<String> arrayList;
    String imageOrientation;
    boolean isPause = false;
    private RecyclerView rvAlbumByFolder;
    private RecyclerView rvAlbumByImages;
    private ImageAlbumAdapter imageAlbumAdapter;
    private SelectedImageAdapter selectedImageAdapter;
    private MyApplication application;
    private LinearLayout adContainer;
    private AdView adView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_select);
        application = MyApplication.getInstance();
        isFromPreview = getIntent().hasExtra("extra_from_preview");
        NOofImage = getIntent().getIntExtra("NoofImage", 0);
        MyApplication.TotalSelectedImage = NOofImage;
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ImageSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        application.init();
        init();
        loadAd();
        AllClickListener();
    }

    private void init() {
        this.tvDone = findViewById(R.id.tv_done);
        this.ivBack = findViewById(R.id.ivBack);
        this.rvAlbumByFolder = findViewById(R.id.rvAlbum);
        this.rvAlbumByImages = findViewById(R.id.rvImageAlbum);
        this.ViewexpandIcon = findViewById(R.id.selectedImagesList);
        this.rlRootlayout = findViewById(R.id.root_layout);


        imageAlbumAdapter = new ImageAlbumAdapter(this);
        albumWiseImageAdapter = new AlbumWiseFolder(this);
        selectedImageAdapter = new SelectedImageAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(
                getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        rvAlbumByFolder.setLayoutManager(mLayoutManager);
        rvAlbumByFolder.setItemAnimator(new DefaultItemAnimator());
        rvAlbumByFolder.setAdapter(imageAlbumAdapter);

        RecyclerView.LayoutManager gridLayputManager = new GridLayoutManager(
                getApplicationContext(), 3);
        rvAlbumByImages.setLayoutManager(gridLayputManager);
        rvAlbumByImages.setItemAnimator(new DefaultItemAnimator());
        rvAlbumByImages.setAdapter(albumWiseImageAdapter);


    }
    private void loadAd() {
        adContainer = findViewById(R.id.templateContainer);
        adView = new AdView(this, getResources().getString(R.string.FB_banner), AdSize.BANNER_HEIGHT_50);
        adContainer.addView(adView);
        adView.loadAd();
    }
    @Override
    protected void onDestroy() {
        this.adContainer.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }
    private void AllClickListener() {
        arrayList = new ArrayList<String>();
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                Done();
            }
        });

        imageAlbumAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                albumWiseImageAdapter.notifyDataSetChanged();
            }
        });
        albumWiseImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    ExpandableView.tvNoOfImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
                } else {
                    ExpandableView.tvNoOfImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImageslist().size())) + "/" + MyApplication.TotalSelectedImage);

                }
                selectedImageAdapter.notifyDataSetChanged();
            }
        });
        selectedImageAdapter.setOnItemClickListner(new OnItemClickListner<Object>() {
            @Override
            public void onItemClick(final View view, final Object item) {
                if (MyApplication.TotalSelectedImage >= 50) {
                    ExpandableView.tvNoOfImageCount.setText(String.valueOf(application.getSelectedImageslist().size()));
                } else {
                    ExpandableView.tvNoOfImageCount.setText(String.valueOf(String.valueOf(application.getSelectedImageslist().size())) + "/" + MyApplication.TotalSelectedImage);
                }
                albumWiseImageAdapter.notifyDataSetChanged();
            }
        });
    }

    private String getDropboxIMGSize(final String uri) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(new File(uri).getAbsolutePath(), options);
        final int imageHeight = options.outHeight;
        final int imageWidth = options.outWidth;
        if (imageHeight > imageWidth) {
            return "P";
        }
        return "L";
    }

    public void Done() {
        if (application.getSelectedImageslist().size() != 0) {
            if (application.getSelectedImageslist().size() <= MyApplication.TotalSelectedImage) {
                int i = 0;
                for (final ImageInfo d : application.getSelectedImageslist()) {
                    final String isLandOrPort = getDropboxIMGSize(d.getImagePath());
                    if (i == 0) {
                        PathOfImage = d.getImagePath();
                        imageOrientation = isLandOrPort;
                    } else {
                        PathOfImage = String.valueOf(String.valueOf(PathOfImage)) + MyApplication.APP_SPLIT_PATTERN + d.getImagePath();
                        imageOrientation = String.valueOf(String.valueOf(imageOrientation)) + "$" + isLandOrPort;
                    }
                    ++i;
                }
                final Intent intent = new Intent(activity, SampleCropActivity.class);
                intent.putExtra("path", PathOfImage);
                intent.putExtra("NoofImage", NOofImage);
                startActivity(intent);
                finish();

            } else if (application.getSelectedImageslist().size() > MyApplication.TotalSelectedImage) {
                new StringBuilder("Please Remove ").append(application.getSelectedImageslist().size() - MyApplication.TotalSelectedImage).append(" Images").toString();
            } else {
                Toast.makeText(activity, "Selected : " + MyApplication.TotalSelectedImage + " Image", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(activity, "Please Select Image!", Toast.LENGTH_SHORT).show();
        }
    }


    protected void onResume() {
        super.onResume();
        if (isPause) {
            isPause = false;
            if (MyApplication.TotalSelectedImage >= 50) {
                ExpandableView.tvNoOfImageCount.setText(String.valueOf(application
                        .getSelectedImageslist().size()));
            } else {
                ExpandableView.tvNoOfImageCount.setText(String.valueOf(application
                        .getSelectedImageslist().size()) + "/" +
                        MyApplication.TotalSelectedImage);
            }

            albumWiseImageAdapter.notifyDataSetChanged();
            selectedImageAdapter.notifyDataSetChanged();
        }
    }

    public void onBackPressed() {
        if (MyApplication.IsSelectImageFrom) {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        } else {
            UnityPlayer.UnitySendMessage("SelectMusic", "GetNullSong", "");
            finish();
        }
    }
}
