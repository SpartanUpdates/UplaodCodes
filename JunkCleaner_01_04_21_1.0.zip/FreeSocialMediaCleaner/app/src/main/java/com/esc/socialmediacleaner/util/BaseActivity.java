package com.esc.socialmediacleaner.util;

import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import java.util.regex.Pattern;

public class BaseActivity extends AppCompatActivity {
    public static DisplayMetrics displaymetrics;
    Context context;
    public long lastClickedTime = 0;

    public void onCreate(Bundle bundle) {
        displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        super.onCreate(bundle);
        this.context = this;
    }

    public void track(String str) {
        try {
            Bundle bundle = new Bundle();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(str);
            bundle.putString(str, stringBuilder.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    public boolean isEmailValid(String str) {
        return Pattern.compile("^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$", 2).matcher(str).matches();
    }
}
