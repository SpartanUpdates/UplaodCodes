package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.adapter.VehicleExpenseList;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.database.ExpenseSqlite;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import org.jetbrains.annotations.NotNull;

public class VehicleExpenseActivity extends AppCompatActivity implements View.OnClickListener {
    private Activity activity=VehicleExpenseActivity.this;
    ImageView iv_addexpense;
    LinearLayout ll_empty;
    ExpandableListView listView;
    TextView tvTotal,title_tv;
    ImageView iv_back;
    ExpenseSqlite sqlite;
    VehicleExpenseList expenseListAdapter;
    ArrayList<VehicleExpense> expenseModels = new ArrayList();

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense);
        sqlite = new ExpenseSqlite(getApplicationContext());
        BindView();
        TotalAmount();
        SetListener();
        BannerAds();
        InterAds();
        DarkTheame darkTheame=new DarkTheame(VehicleExpenseActivity.this);
        if(darkTheame.modeData().equals("nightMode"))
        {
            setupDarkMode();
        }
    }

    private void BannerAds() {
        gg_banner= findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback(){
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds(){
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity,getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(VehicleExpenseActivity.this, MainActivity.class));
                        finish();
                        break;
                    case 2:
                        startActivity(new Intent(VehicleExpenseActivity.this, VehicleExpenseCategory.class));
                        break;
                }
            }
            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed (AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_empty.setBackgroundResource(R.drawable.ic_expense_bg_dark);
        tvTotal.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        listView.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
    }

    public void BindView(){
        iv_addexpense = findViewById(R.id.iv_addexpense);
        ll_empty = findViewById(R.id.ll_emplty);
        listView = findViewById(R.id.listview);
        tvTotal = findViewById(R.id.tv_total);
        iv_back = findViewById(R.id.iv_back);
        title_tv=findViewById(R.id.title_tv);

        iv_addexpense.setOnClickListener(this);
        iv_back.setOnClickListener(this);
    }

    public void SetListener(){
        listView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                listView.setIndicatorBounds(listView.getMeasuredWidth() - 80, listView.getMeasuredWidth());
            }
        });

        listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long j) {
                return false;
            }
        });

        this.listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i2, long j) {
                try {
                    final VehicleExpense vehicleExpenseModel = VehicleExpenseActivity.this.expenseModels.get(i).getExpenseModels().get(i2);
                    view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_dialog, null);
                    AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                    builder.setView(view);
                    builder.setCancelable(true);
                    final AlertDialog create = builder.create();
                    create.show();

                    LinearLayout mainLayout=view.findViewById(R.id.mainLayout);
                    DarkTheame darkTheame=new DarkTheame(VehicleExpenseActivity.this);
                    if(darkTheame.modeData().equals("nightMode"))
                    {
                        mainLayout.setBackgroundColor(Color.parseColor("#4E4E4E"));
                    }

                    Button button = view.findViewById(R.id.btnDeleteBill);
                    view.findViewById(R.id.btnEditBill).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            create.dismiss();
                            Intent intent = new Intent(VehicleExpenseActivity.this, VehicleExpenseDetailAtivity.class);
                            intent.putExtra("BID", vehicleExpenseModel.getBid());
                            intent.putExtra("BPAYEE", vehicleExpenseModel.getPayee());
                            intent.putExtra("BAMOUNT", vehicleExpenseModel.getAmount());
                            intent.putExtra("BCATNAME", vehicleExpenseModel.getCatname());
                            intent.putExtra("BCATICON", vehicleExpenseModel.getCaticon());
                            intent.putExtra("BNOTE", vehicleExpenseModel.getNotes());
                            intent.putExtra("BDUEDATE", vehicleExpenseModel.getDuedate());
                            intent.putExtra("btn", "UPDATE");
                            VehicleExpenseActivity.this.startActivity(intent);
                        }
                    });
                    button.setOnClickListener(new View.OnClickListener() {

                        public void onClick(View view) {
                            create.dismiss();
                            view = ((LayoutInflater) VehicleExpenseActivity.this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.vehicleexpanse_delete_itemdialog, null);
                            AlertDialog.Builder builder = new AlertDialog.Builder(VehicleExpenseActivity.this);
                            builder.setView(view);
                            builder.setCancelable(true);
                            final AlertDialog dialog = builder.create();
                            dialog.show();

                            TextView tv_delete = view.findViewById(R.id.tv_delete);
                            TextView tv_cancel = view.findViewById(R.id.tv_cancel);

                            tv_delete.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (sqlite.dlt(vehicleExpenseModel.getBid()) > 0) {
                                        TotalAmount();
                                    }
                                    dialog.dismiss();
                                }
                            });

                            tv_cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                        }
                    });
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                return false;
            }
        });
    }

    public void TotalAmount(){
        String rawQuery = this.sqlite.rawQuery();
        int i = 0;
        if (rawQuery != null) {
            this.ll_empty.setVisibility(View.GONE);
            this.tvTotal.setVisibility(View.VISIBLE);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Total Amount: ");
            stringBuilder.append(getString(R.string.rs));
            stringBuilder.append(" ");
            stringBuilder.append(rawQuery);
            tvTotal.setText(stringBuilder.toString());
        } else {
            this.tvTotal.setVisibility(View.GONE);
            this.ll_empty.setVisibility(View.VISIBLE);
        }
        this.expenseModels = this.sqlite.list();
        this.expenseListAdapter = new VehicleExpenseList(this, this.expenseModels);
        this.listView.setAdapter(this.expenseListAdapter);
        while (i < this.expenseListAdapter.getGroupCount()) {
            try {
                this.listView.expandGroup(i);
                i++;
            } catch (Exception unused) {
                return;
            }
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.iv_addexpense:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 2;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(VehicleExpenseActivity.this, VehicleExpenseCategory.class));
                }
            break;

            case R.id.iv_back:
                onBackPressed();
            break;
        }
    }

    public void onResume() {
        super.onResume();
        TotalAmount();
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(VehicleExpenseActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}