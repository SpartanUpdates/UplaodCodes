package com.example.knowledgetrivia.models;

import java.util.ArrayList;

public class Question {
    private int id;
    private ArrayList<String> options;
    private String question;
    private int solutionIndex;

    public Question() {
        this.id = -1;
        this.question = null;
        this.solutionIndex = -1;
        this.options = new ArrayList();
    }

    public Question(int i, String str, ArrayList<String> arrayList, int i2) {
        this.id = i;
        this.question = str;
        this.options = arrayList;
        this.solutionIndex = i2;
    }

    public int getSolutionIndex() {
        return this.solutionIndex;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getQuestion() {
        return this.question;
    }

    public ArrayList<String> getOptions() {
        return this.options;
    }
}
