package com.unitedvideos.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.Preferences.LanguagePref;
import com.unitedvideos.R;
import androidx.appcompat.app.AppCompatActivity;

public class ExportVideoQuality extends AppCompatActivity {

    Activity activity = ExportVideoQuality.this;
    ImageView ivback;
    RadioButton rbHigh;
    RadioButton rbMedium;
    RadioButton rbLow;
    RadioButton rbUltra;
    String VideoQuality;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export_quality);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ExportVideoQuality");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        ivback = findViewById(R.id.ivBack);
        rbHigh = findViewById(R.id.rbHigh);
        rbMedium = findViewById(R.id.rbMedium);
        rbUltra = findViewById(R.id.rbUltra);
        rbLow = findViewById(R.id.rbLow);
        VideoQuality = LanguagePref.a(this).a("pref_key_export_quality", "High");
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        if (VideoQuality.equalsIgnoreCase("High")) {
            rbHigh.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Medium")) {
            rbMedium.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Low")) {
            rbLow.setChecked(true);
        }
        if (VideoQuality.equalsIgnoreCase("Ultra")) {
            rbUltra.setChecked(true);
        }
        rbHigh.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "High");
                    onBackPressed();
                }
            }
        });
        rbMedium.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Medium");
                    onBackPressed();
                }
            }
        });
        rbLow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Low");
                    onBackPressed();
                }
            }
        });
        rbUltra.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    LanguagePref.a(activity).b("pref_key_export_quality", "Ultra");
                    onBackPressed();
                }
            }
        });


    }

    public void onBackPressed() {
        finish();
    }
}
