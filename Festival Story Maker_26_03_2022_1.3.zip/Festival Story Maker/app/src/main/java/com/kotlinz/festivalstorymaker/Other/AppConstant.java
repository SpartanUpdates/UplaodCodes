package com.kotlinz.festivalstorymaker.Other;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.appizona.yehiahd.fastsave.FastSave;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

public class AppConstant {
    public static String D1 = "logo";
    public static int G = 624;
    public static int H = 7924;
    public static String H1 = null;
    public static int K = 724;
    public static String K1 = "20";
    public static int L = 6709;
    public static String L1 = "34";
    public static String LogoList = "Logo_list";
    public static String FontList = "Font_list";
    public static String P1 = null;
    public static String Q1 = "80";
    public static String R1 = "79";
    public static String V1 = "103";
    public static String X1 = "86";
    public static String Y1 = "89";
    public static String d2 = "35";
    public static String e2 = "55";
    public static String Z1 = "189";
    public static String Categoryid = "categoryid";
    public static String SuggetionCount = "suggetion_count";
    public static String A1 = "label_type";
    public static String T0 = "success";
    public static String k0 = "Festival_Frame_list";
    public static String i2 = "uniquekey";
    public static String festivalApiKey = "a12984dysdsl94923460bsdfsfs097wwendsfumklgdsdffsdj89753487dfskmflamfdh";

    public static String FestivalFrameId = "frame_id";
    public static String S0 = "frames/getframedatabyid";
    public static String j2 = "device_id";
    public static String V0 = "user/add_customer";
    public static String w2 = "phone_number";
    public static String x2 = "customer_email";
    public static String B1 = "success";
    public static String C1 = "response";
    public static String Data = "data";
    public static String Error = "error";
    public static int e0 = 724;
    public static int b0 = 7924;
    public static int c0 = 7024;
    public static String k2 = "categoryid";
    public static String i3 = "34";
    public static String b3 = "33";
    public static String q2 = "frame_id";
    public static String v2 = "customer";
    public static String y2 = "customer_occupation";
    public static String z2 = "customer_city";
    public static int d0 = 66;
    public static String A2 = "main_cat_pos";
    public static String C2 = "is_purchase";
    public static String R0 = "frames/getlist";


    public ArrayList<com.kotlinz.festivalstorymaker.Models.b> a;
    public JSONObject jsonObject;
    public JSONObject jsonObjectResponse;
    public JSONObject jsonObjectEdit;
    public JSONArray jsonArray;
    public com.kotlinz.festivalstorymaker.Models.b f;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> g;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> h;
    public com.kotlinz.festivalstorymaker.Models.g editmodel;
    public String j;
    public String k;
    public com.kotlinz.festivalstorymaker.Models.a editMainModel;



    public static String l2 = "categoryid_1";
    public static String s3 = "103";
    public static String m2 = "categoryid_2";
    public static String n2 = "categoryid_3";
    public static String o2 = "recordsperpage";
    public static String p2 = "currentpagenumber";
    public static String O2 = "328";
    public static String P2 = "329";
    public static String g4 = "x-api-key";
    public static String t1 = "mm_api_key";
    public static int kf;
    public static int lf;
    public static Bitmap m;
    public static Bitmap n;
    public static RenderScript o;
    public static ScriptIntrinsicBlur p;
    public static Allocation q;
    public static Allocation r;
    public static String f1 = "festival/getlistbyfestivalid";

    public com.kotlinz.festivalstorymaker.Models.festival.i i;

    static {
        String str = "28";
        H1 = str;
        P1 = str;
    }

    public void a(com.kotlinz.festivalstorymaker.Other.g.a aVar, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i2);
        stringBuilder.append("");
    }

    public ArrayList b(Activity activity, String str) {
        this.a = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.jsonObject = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                JSONObject jSONObject2 = jsonObject.getJSONObject("response");
                this.jsonObjectEdit = jSONObject2;
                this.jsonArray = jSONObject2.getJSONArray("data");
                for (int i = 0; i < this.jsonArray.length(); i++) {
                    this.jsonObjectResponse = this.jsonArray.getJSONObject(i);
                    this.f = new com.kotlinz.festivalstorymaker.Models.b();
                    this.jsonObjectResponse.getString("id");
                    this.f.g = this.jsonObjectResponse.getString("image");
                    this.f.h = this.jsonObjectResponse.getString("is_premium");
                    this.f.f = this.jsonObjectEdit.getString("total_pages");
                    this.f.e = this.jsonObjectEdit.getString("total_records");
                    this.a.add(this.f);
                }
            } else {
                Utils.N(activity, jsonObject.getString("error"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this.a;
    }

    public ArrayList<com.kotlinz.festivalstorymaker.Models.a> getEditThemeFileData(Activity activity, String str) {
        String str2 = "0x";
        String str3 = "color";
        String str4 = "";
        String str5 = "#";
        h = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.jsonObjectResponse = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                JSONArray jSONArray = this.jsonObjectResponse.getJSONArray("response");
                for (int i = 0; i < jSONArray.length(); i++) {
                    editMainModel = new com.kotlinz.festivalstorymaker.Models.a();
                    g = new ArrayList();
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                    editMainModel.b = jSONObject2.getString("type_id");
                    editMainModel.c = jSONObject2.getString("type_name");
                    jsonArray = jSONObject2.getJSONArray("data");
                    for (int i2 = 0; i2 < jsonArray.length(); i2++) {
                        StringBuilder stringBuilder;
                        jsonObjectEdit = jsonArray.getJSONObject(i2);
                        com.kotlinz.festivalstorymaker.Models.g gVar = new com.kotlinz.festivalstorymaker.Models.g();
                        this.editmodel = gVar;
                        gVar.e = this.jsonObjectEdit.getString("type");
//                        this.editmodel.f = this.jsonObjectEdit.getString("src");
                        if (editMainModel.c.equals("Square Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Square" + File.separator + this.jsonObjectEdit.getString("src");
                        } else if (editMainModel.c.equals("Vertical Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Vertical" + File.separator + this.jsonObjectEdit.getString("src");
                        } else if (editMainModel.c.equals("Story Post")) {
                            this.editmodel.f = Constant.FolderPath + File.separator + "Story" + File.separator + this.jsonObjectEdit.getString("src");
                        }

                        this.editmodel.g = this.jsonObjectEdit.getString("name");
                        this.editmodel.j = this.jsonObjectEdit.getString("width");
                        this.editmodel.k = this.jsonObjectEdit.getString("height");
                        this.editmodel.h = this.jsonObjectEdit.getString("x");
                        this.editmodel.i = this.jsonObjectEdit.getString("y");
                        this.editmodel.l = this.jsonObjectEdit.getString("is_lock");
                        this.editmodel.m = this.jsonObjectEdit.getString("is_color");
                        this.editmodel.p = this.jsonObjectEdit.getString("is_hue");
                        this.editmodel.q = this.jsonObjectEdit.getString("is_mask");
                        this.editmodel.A = this.jsonObjectEdit.getString("font_name");
                        this.editmodel.C = this.jsonObjectEdit.getString("is_object");
                        this.editmodel.B = this.jsonObjectEdit.getString("is_shape");
                        this.editmodel.I = this.jsonObjectEdit.getString("is_zoom");
                        this.editmodel.H = this.jsonObjectEdit.getString("is_logo");
                        this.editmodel.r = this.jsonObjectEdit.getString("font_spacing");
                        this.editmodel.s = this.jsonObjectEdit.getString("spacing");
                        this.editmodel.t = this.jsonObjectEdit.getString("justification");
                        this.editmodel.G = this.jsonObjectEdit.getString("is_pt");
                        this.editmodel.D = this.jsonObjectEdit.getString("is_st");
                        this.editmodel.u = this.jsonObjectEdit.getString("lineheight");
                        String string = this.jsonObjectEdit.getString(str3);
                        if (this.jsonObjectEdit.getString("type").equals("text")) {
                            if (string.equals("ffffff")) {
                                this.editmodel.F = "1";
                                this.editmodel.E = "0";
                            } else if (string.equals("000000")) {
                                this.editmodel.E = "1";
                                this.editmodel.F = "0";
                            } else {
                                this.editmodel.E = "";
                                this.editmodel.F = "";
                            }
                        } else {
                            this.editmodel.E = this.jsonObjectEdit.getString("is_bt");
                            this.editmodel.F = this.jsonObjectEdit.getString("is_wt");
                        }
                        this.j = string;
                        string = string.replace(str2, str4);
                        this.j = string;
                        if (string.contains(str5)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.jsonObjectEdit.getString(str3).split(str5)[1]);
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.j);
                        }
                        string = stringBuilder.toString();
                        this.j = string;
                        this.editmodel.v = string;
                        this.editmodel.w = this.jsonObjectEdit.getString("size");
                        this.editmodel.x = this.jsonObjectEdit.getString("text").replace("\r", str4);
                        this.editmodel.y = this.jsonObjectEdit.getString("rotation");
                        this.editmodel.z = this.jsonObjectEdit.getString("position");
                        this.editmodel.o = this.jsonObjectEdit.getString("border_size");
                        string = this.jsonObjectEdit.getString("border_color");
                        this.k = string;
                        if (string.length() <= 0 || this.k.equalsIgnoreCase("0")) {
                            this.editmodel.n = str4;
                        } else {
                            String str6;
                            gVar = this.editmodel;
                            if (this.k.contains(str5)) {
                                str6 = str4;
                            } else {
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(str5);
                                stringBuilder2.append(this.k.replace(str2, str4));
                                str6 = stringBuilder2.toString();
                            }
                            gVar.n = str6;
                        }
                        this.g.add(this.editmodel);
                    }
                    this.editMainModel.a = g;
                    this.h.add(editMainModel);
                }
            } else {
                Utils.N(activity, jsonObjectResponse.getString("error"));
            }
            return this.h;
        } catch (JSONException e) {
            e.printStackTrace();
            return this.h;
        }
    }


    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> getCollageEditThemeData(Activity activity, String str) {
        String str2 = "0x";
        String str3 = "color";
        String str4 = "";
        String str5 = "#";
        g = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            jsonObjectResponse = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                jsonArray = jsonObjectResponse.getJSONArray("response");
                for (int i = 0; i < this.jsonArray.length(); i++) {
                    JSONObject jSONObject2 = this.jsonArray.getJSONObject(i);
                    jsonArray = jSONObject2.getJSONArray("data");
                    for (int i2 = 0; i2 < this.jsonArray.length(); i2++) {
                        StringBuilder stringBuilder;
                        this.jsonObjectEdit = this.jsonArray.getJSONObject(i2);
                        com.kotlinz.festivalstorymaker.Models.g gVar = new com.kotlinz.festivalstorymaker.Models.g();
                        this.editmodel = gVar;
                        gVar.e = this.jsonObjectEdit.getString("type");
                        this.editmodel.f = this.jsonObjectEdit.getString("src");
                        this.editmodel.g = this.jsonObjectEdit.getString("name");
                        this.editmodel.j = this.jsonObjectEdit.getString("width");
                        this.editmodel.k = this.jsonObjectEdit.getString("height");
                        this.editmodel.h = this.jsonObjectEdit.getString("x");
                        this.editmodel.i = this.jsonObjectEdit.getString("y");
                        this.editmodel.l = this.jsonObjectEdit.getString("is_lock");
                        this.editmodel.m = this.jsonObjectEdit.getString("is_color");
                        this.editmodel.p = this.jsonObjectEdit.getString("is_hue");
                        this.editmodel.q = this.jsonObjectEdit.getString("is_mask");
                        this.editmodel.A = this.jsonObjectEdit.getString("font_name");
                        this.editmodel.C = this.jsonObjectEdit.getString("is_object");
                        this.editmodel.B = this.jsonObjectEdit.getString("is_shape");
                        this.editmodel.I = this.jsonObjectEdit.getString("is_zoom");
                        this.editmodel.H = this.jsonObjectEdit.getString("is_logo");
                        this.editmodel.r = this.jsonObjectEdit.getString("font_spacing");
                        this.editmodel.s = this.jsonObjectEdit.getString("spacing");
                        this.editmodel.t = this.jsonObjectEdit.getString("justification");
                        this.editmodel.G = this.jsonObjectEdit.getString("is_pt");
                        this.editmodel.D = this.jsonObjectEdit.getString("is_st");
                        this.editmodel.E = this.jsonObjectEdit.getString("is_bt");
                        this.editmodel.F = this.jsonObjectEdit.getString("is_wt");
                        this.editmodel.u = this.jsonObjectEdit.getString("lineheight");
                        str = this.jsonObjectEdit.getString(str3);
                        this.j = str;
                        str = str.replace(str2, str4);
                        this.j = str;
                        if (str.contains(str5)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.jsonObjectEdit.getString(str3).split(str5)[1]);
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str5);
                            stringBuilder.append(this.j);
                        }
                        str = stringBuilder.toString();
                        this.j = str;
                        this.editmodel.v = str;
                        this.editmodel.w = this.jsonObjectEdit.getString("size");
                        this.editmodel.x = this.jsonObjectEdit.getString("text").replace("\r", str4);
                        this.editmodel.y = this.jsonObjectEdit.getString("rotation");
                        this.editmodel.z = this.jsonObjectEdit.getString("position");
                        this.editmodel.o = this.jsonObjectEdit.getString("border_size");
                        str = this.jsonObjectEdit.getString("border_color");
                        this.k = str;
                        if (str.length() <= 0 || this.k.equalsIgnoreCase("0")) {
                            this.editmodel.n = str4;
                        } else {
                            String str6;
                            gVar = this.editmodel;
                            if (this.k.contains(str5)) {
                                str6 = str4;
                            } else {
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append(str5);
                                stringBuilder2.append(this.k.replace(str2, str4));
                                str6 = stringBuilder2.toString();
                            }
                            gVar.n = str6;
                        }
                        this.g.add(this.editmodel);
                    }
                }
            } else {
                Utils.N(activity, this.jsonObjectResponse.getString("error"));
            }
            return this.g;
        } catch (JSONException e) {
            e.printStackTrace();
            return this.g;
        }
    }

    public ArrayList<com.kotlinz.festivalstorymaker.Models.g> getFestivalEditThemeData(Activity activity, String str) {
        String str2 = "0x";
        String str3 = "color";
        String str4 = "";
        String str5 = "#";
        g = new ArrayList();
        try {
            JSONObject jSONObject = new JSONObject(str);
            this.jsonObjectResponse = jSONObject;
            if (jSONObject.getString("success").equals("1")) {
                JSONArray jSONArray = this.jsonObjectResponse.getJSONArray("response");
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    StringBuilder stringBuilder;
                    jsonObjectEdit = jSONArray.getJSONObject(i2);
                    com.kotlinz.festivalstorymaker.Models.g gVar = new com.kotlinz.festivalstorymaker.Models.g();
                    this.editmodel = gVar;
                    gVar.e = this.jsonObjectEdit.getString("type");
                    if (!jsonObjectEdit.getString("src").equals("")) {
                        editmodel.f = Constant.FolderPath + File.separator + "Template_Layer" + File.separator + jsonObjectEdit.getString("src");
                    } else {
                        editmodel.f = jsonObjectEdit.getString("src");
                    }
                    this.editmodel.g = this.jsonObjectEdit.getString("name");
                    this.editmodel.j = this.jsonObjectEdit.getString("width");
                    this.editmodel.k = this.jsonObjectEdit.getString("height");
                    this.editmodel.h = this.jsonObjectEdit.getString("x");
                    this.editmodel.i = this.jsonObjectEdit.getString("y");
                    this.editmodel.l = this.jsonObjectEdit.getString("is_lock");
                    this.editmodel.m = this.jsonObjectEdit.getString("is_color");
                    this.editmodel.p = this.jsonObjectEdit.getString("is_hue");
                    this.editmodel.q = this.jsonObjectEdit.getString("is_mask");
                    this.editmodel.A = this.jsonObjectEdit.getString("font_name");
                    this.editmodel.C = this.jsonObjectEdit.getString("is_object");
                    this.editmodel.B = this.jsonObjectEdit.getString("is_shape");
                    this.editmodel.I = this.jsonObjectEdit.getString("is_zoom");
                    this.editmodel.H = this.jsonObjectEdit.getString("is_logo");
                    this.editmodel.r = this.jsonObjectEdit.getString("font_spacing");
                    this.editmodel.s = this.jsonObjectEdit.getString("spacing");
                    this.editmodel.t = this.jsonObjectEdit.getString("justification");
                    this.editmodel.G = this.jsonObjectEdit.getString("is_pt");
                    this.editmodel.D = this.jsonObjectEdit.getString("is_st");
                    this.editmodel.u = this.jsonObjectEdit.getString("lineheight");
                    String string = this.jsonObjectEdit.getString(str3);
                    this.editmodel.E = this.jsonObjectEdit.getString("is_bt");
                    this.editmodel.F = this.jsonObjectEdit.getString("is_wt");
                    this.j = string;
                    string = string.replace(str2, str4);
                    this.j = string;
                    if (string.contains(str5)) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str5);
                        stringBuilder.append(this.jsonObjectEdit.getString(str3).split(str5)[1]);
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str5);
                        stringBuilder.append(this.j);
                    }
                    string = stringBuilder.toString();
                    this.j = string;
                    this.editmodel.v = string;
                    this.editmodel.w = this.jsonObjectEdit.getString("size");
                    this.editmodel.x = this.jsonObjectEdit.getString("text").replace("\r", str4);
                    this.editmodel.y = this.jsonObjectEdit.getString("rotation");
                    this.editmodel.z = this.jsonObjectEdit.getString("position");
                    this.editmodel.o = this.jsonObjectEdit.getString("border_size");
                    string = this.jsonObjectEdit.getString("border_color");
                    this.k = string;
                    if (string.length() <= 0 || this.k.equalsIgnoreCase("0")) {
                        this.editmodel.n = str4;
                    } else {
                        String str6;
                        gVar = this.editmodel;
                        if (this.k.contains(str5)) {
                            str6 = str4;
                        } else {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str5);
                            stringBuilder2.append(this.k.replace(str2, str4));
                            str6 = stringBuilder2.toString();
                        }
                        gVar.n = str6;
                    }
                    this.g.add(this.editmodel);
                }
            } else {
                Utils.N(activity, jsonObjectResponse.getString("error"));
            }
            return g;
        } catch (JSONException e) {
            e.printStackTrace();
            return this.g;
        }
    }

/*
    public ArrayList<com.kotlinz.festivalstorymaker.Models.festival.g> d(final Activity activity, final String s) {
        this.g = new ArrayList<g>();
        try {
            final JSONObject d = new JSONObject(s);
            this.jsonObjectEdit = d;
            if (d.getString(AppConstant.T0).equals("1")) {
                this.jsonArray = this.jsonObjectEdit.getJSONArray("response");
                for (int i = 0; i < this.e.length(); ++i) {
                    this.c = this.e.getJSONObject(i);
                    final g j = new g();
                    this.i = j;
                    j.e = this.c.getString("type");
                    this.i.f = this.c.getString("src");
                    this.i.g = this.c.getString("name");
                    this.i.j = this.c.getString("width");
                    this.i.k = this.c.getString("height");
                    this.i.h = this.c.getString("x");
                    this.i.i = this.c.getString("y");
                    this.i.l = this.c.getString("is_lock");
                    this.i.m = this.c.getString("is_color");
                    this.i.p = this.c.getString("is_hue");
                    this.i.q = this.c.getString("is_mask");
                    this.i.A = this.c.getString("font_name");
                    this.i.C = this.c.getString("is_object");
                    this.i.B = this.c.getString("is_shape");
                    this.i.I = this.c.getString("is_zoom");
                    this.i.H = this.c.getString("is_logo");
                    this.i.r = this.c.getString("font_spacing");
                    this.i.s = this.c.getString("spacing");
                    this.i.t = this.c.getString("justification");
                    this.i.G = this.c.getString("is_pt");
                    this.i.D = this.c.getString("is_st");
                    this.i.E = this.c.getString("is_bt");
                    this.i.F = this.c.getString("is_wt");
                    this.i.u = this.c.getString("lineheight");
                    final String string = this.c.getString("color");
                    this.j = string;
                    final String replace = string.replace("0x", "");
                    this.j = replace;
                    StringBuilder sb;
                    if (replace.contains("#")) {
                        sb = new StringBuilder();
                        sb.append("#");
                        sb.append(this.c.getString("color").split("#")[1]);
                    }
                    else {
                        sb = new StringBuilder();
                        sb.append("#");
                        sb.append(this.j);
                    }
                    final String string2 = sb.toString();
                    this.j = string2;
                    this.i.v = string2;
                    this.i.w = this.c.getString("size");
                    this.i.x = this.c.getString("text").replace("\r", "");
                    this.i.y = this.c.getString("rotation");
                    this.i.z = this.c.getString("position");
                    this.i.o = this.c.getString("border_size");
                    final String string3 = this.c.getString("border_color");
                    this.k = string3;
                    if (string3.length() > 0 && !this.k.equalsIgnoreCase("0")) {
                        final g k = this.i;
                        String string4;
                        if (this.k.contains("#")) {
                            string4 = "";
                        }
                        else {
                            final StringBuilder sb2 = new StringBuilder();
                            sb2.append("#");
                            sb2.append(this.k.replace("0x", ""));
                            string4 = sb2.toString();
                        }
                        k.n = string4;
                    }
                    else {
                        this.i.n = "";
                    }
                    this.g.add(this.i);
                }
            }
            else {
                a0.b.N((Context)activity, this.d.getString(a0.a.V0));
            }
            return this.g;
        }
        catch (JSONException ex) {
            ex.printStackTrace();
            return this.g;
        }
    }
*/

    public boolean j() {
        return FastSave.getInstance().getString("is_star", "0").equalsIgnoreCase("1");
    }

    public static boolean i(Activity activity) {
        if (FastSave.getInstance().getString(t1, "").length() <= 0) {
            a(activity);
            return false;
        } /*else if (b.I().length() > 0) {
            return true;
        } */ else {
            a(activity);
            return false;
        }
    }

    public static void a(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.dialog_select_account);
        dialog.setCancelable(true);
        ((ImageView) dialog.findViewById(R.id.imgBlur)).setImageBitmap(S(activity));
        dialog.findViewById(R.id.cardClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.llMain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public static Bitmap S(Activity activity) {
        String str = "";
        if (FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.i3) || FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.s3) || FastSave.getInstance().getString(AppConstant.k2, str).equalsIgnoreCase(AppConstant.b3)) {
            return BitmapFactory.decodeResource(activity.getResources(), R.drawable.ic_transparent_white_bg);
        }
        View decorView = activity.getWindow().getDecorView();
        decorView.setDrawingCacheEnabled(true);
        decorView.buildDrawingCache();
        Bitmap drawingCache = decorView.getDrawingCache();
        Rect rect = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        int i = rect.top;
        drawingCache = Bitmap.createBitmap(drawingCache, 0, i, activity.getWindowManager().getDefaultDisplay().getWidth(), activity.getWindowManager().getDefaultDisplay().getHeight() - i);
        decorView.destroyDrawingCache();
        return d(activity, drawingCache.copy(drawingCache.getConfig(), true));
    }

    @SuppressLint({"NewApi"})
    public static Bitmap d(Context context, Bitmap bitmap) {
        kf = Math.round(((float) bitmap.getWidth()) * 0.1f);
        int round = Math.round(((float) bitmap.getHeight()) * 0.1f);
        lf = round;
        bitmap = Bitmap.createScaledBitmap(bitmap, kf, round, true);
        m = bitmap;
        n = Bitmap.createBitmap(bitmap);
        RenderScript create = RenderScript.create(context);
        o = create;
        p = ScriptIntrinsicBlur.create(create, Element.U8_4(create));
        q = Allocation.createFromBitmap(o, m);
        r = Allocation.createFromBitmap(o, n);
        p.setRadius(25.0f);
        p.setInput(q);
        p.forEach(r);
        r.copyTo(n);
        return n;
    }

}
