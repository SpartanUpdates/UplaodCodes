package com.esc.motivationquotes.model;

public class AppBean {
    public String appDescr;
    public int appLogoName;
    public String appName;
    public String appPackageName;
}
