package com.jenilcreation.photomusicvideo.activity;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
