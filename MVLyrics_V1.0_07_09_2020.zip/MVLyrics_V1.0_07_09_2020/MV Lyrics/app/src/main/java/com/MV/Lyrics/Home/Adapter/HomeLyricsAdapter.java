package com.MV.Lyrics.Home.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.Home.Download.ThemeDownload;
import com.MV.Lyrics.Home.Model.ThemeHorizontalModel;
import com.MV.Lyrics.Home.activity.HomeActivity;
import com.MV.Lyrics.Home.fragment.ThemeFragmentByCategory;
import com.MV.Lyrics.LyricsSelect.view.CircleImageView;
import com.MV.Lyrics.LyricsSelect.view.DonutProgress;
import com.MV.Lyrics.R;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.util.ArrayList;

public class HomeLyricsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int ITEM_TYPE_DATA = 0;
    ThemeFragmentByCategory themefragment;
    public Context mContext;
    private ArrayList<ThemeHorizontalModel> themeCategoryList;
    private HomeActivity ActivityOfTheme;


    public HomeLyricsAdapter(Context mContext, ArrayList<ThemeHorizontalModel> themeCategoryList, ThemeFragmentByCategory themefragmnet) {
        this.mContext = mContext;
        ActivityOfTheme = (HomeActivity) mContext;
        this.themeCategoryList = themeCategoryList;
        this.themefragment = themefragmnet;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item, viewGroup, false);
        return new ThemeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof ThemeViewHolder) {
            final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
            final ThemeHorizontalModel themelModel = themeCategoryList.get(position);
            viewHolder.tvThemeName.setText(themelModel.getThemeName());
            viewHolder.cbSong.setChecked(ActivityOfTheme.selectedSongPosition == position);
            viewHolder.tvThemeName.setSelected(true);
            if (!themelModel.isAvailableOffline) {
                if (themelModel.isDownloading) {
                    viewHolder.layoutDownload.setVisibility(View.GONE);
                    viewHolder.layoutDownloadProgress.setVisibility(View.VISIBLE);
                    viewHolder.layoutUse.setVisibility(View.GONE);
                } else {
                    viewHolder.layoutDownload.setVisibility(View.VISIBLE);
                    viewHolder.layoutDownloadProgress.setVisibility(View.GONE);
                    viewHolder.layoutUse.setVisibility(View.GONE);
                }
            } else {
                viewHolder.layoutUse.setVisibility(View.VISIBLE);
                viewHolder.layoutDownload.setVisibility(View.GONE);
                viewHolder.layoutDownloadProgress.setVisibility(View.GONE);
            }

            if (ActivityOfTheme.selectedSongPosition != position) {
                viewHolder.ivThumb.setSelected(false);
                viewHolder.tvUse.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
                viewHolder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
            } else {
                viewHolder.tvUse.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                viewHolder.ivPlayPause.setImageResource(R.drawable.icon_player_pause);
                viewHolder.ivThumb.setSelected(true);
            }

            viewHolder.layoutMainTheme.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DownloadThemeFiles(position, viewHolder.layoutDownload, viewHolder.layoutDownloadProgress, viewHolder.layoutUse, viewHolder.donutProgress, themelModel,viewHolder);
                }
            });
            viewHolder.layoutPlayPause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getZipDownloadCatName() + File.separator + themelModel.getZipFolderName() + File.separator + themelModel.getBundelname()).exists()) {
                        if (viewHolder.ivThumb.isSelected()) {
                            ActivityOfTheme.SongPlayPause();
                            if (ActivityOfTheme.isSongPlay()) {
                                viewHolder.ivPlayPause.setImageResource(R.drawable.icon_player_pause);
                            } else {
                                viewHolder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
                            }
                        } else {
                            viewHolder.ivThumb.setSelected(true);
                            if (ActivityOfTheme.SelectedTabPosition == themefragment.getTabIndex()) {
                                if (ActivityOfTheme.selectedSongPosition == position) {
                                    viewHolder.ivThumb.setSelected(true);
                                    viewHolder.tvUse.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                                    viewHolder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
                                    return;
                                }
                            }
                            ActivityOfTheme.SetSong(themeCategoryList.get(position), position);
                            notifyDataSetChanged();
                        }
                    } else {
                        if (Utils.checkConnectivity(mContext, true)) {
                            viewHolder.layoutDownloadProgress.setVisibility(View.VISIBLE);
                            new ThemeDownload(mContext, themelModel.getBundelurl(), themelModel.getBundelname(), themelModel.getBundelfilesize(), viewHolder.layoutDownload, viewHolder.layoutDownloadProgress, viewHolder.layoutUse, viewHolder.donutProgress, themelModel);
                        } else {
                            Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return ITEM_TYPE_DATA;
    }


    private void DownloadThemeFiles(int position, LinearLayout layoutDownload, LinearLayout layoutDownloadProgress, LinearLayout layoutUse, DonutProgress donutProgress, ThemeHorizontalModel themelModel,ThemeViewHolder viewHolder) {
        int UnityBundeldSize = themelModel.getBundelfilesize();
        String SongName = themelModel.getBundelname();
        File SongPath = new File(Utils.INSTANCE.getThemeFolderPath() + themelModel.getZipDownloadCatName() + File.separator + themelModel.getZipFolderName() + File.separator + SongName);
        int BundelFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        if (new File(Utils.INSTANCE.getThemeFolderPath() + themelModel.getZipDownloadCatName() + File.separator + themelModel.getZipFolderName() + File.separator + SongName).exists()) {
            if (BundelFileSize == UnityBundeldSize) {
                MyApplication.isEditCall = true;
                MyApplication.ThemeAssetSelectedPosition = 0;
                Utils.INSTANCE.particalAssetModels.get(0).IsAssetSelected = true;
                MyApplication.AllFilePath = Utils.INSTANCE.getAssetUnityPath() + "Promise.unity3d" + MyApplication.SPLIT_PATTERN + "Promise" + MyApplication.SPLIT_PATTERN + Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getZipDownloadCatName() + File.separator + themelModel.getZipFolderName() + File.separator + "lyrics.json" + MyApplication.SPLIT_PATTERN + Utils.INSTANCE.getThemeFolderPath() + themelModel.getZipDownloadCatName() + File.separator + themelModel.getZipFolderName() + File.separator + "sound.mp3";
                /*if (!MyApplication.IsHomeInterstitialAdsDisplay && MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
                    MyApplication.AdsId = 7;
                    MyApplication.AdsShowContext = ActivityOfTheme;
                    MyApplication.mInterstitialAd.show();
                } else {
                    UnityPlayer.UnitySendMessage("AppManager", "GetBundleData", MyApplication.AllFilePath);
                    ActivityOfTheme.ShowBannerAds();
                    ActivityOfTheme.finish();
                }*/
                UnityPlayer.UnitySendMessage("AppManager", "GetBundleData", MyApplication.AllFilePath);
                ActivityOfTheme.ShowBannerAds();
                ActivityOfTheme.finish();
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    layoutDownloadProgress.setVisibility(View.VISIBLE);
                    new ThemeDownload(mContext, themelModel.getBundelurl(), themelModel.getBundelname(), themelModel.getBundelfilesize(), layoutDownload, layoutDownloadProgress, layoutUse, donutProgress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                layoutDownloadProgress.setVisibility(View.VISIBLE);
                new ThemeDownload(mContext, themelModel.getBundelurl(), themelModel.getBundelname(), themelModel.getBundelfilesize(), layoutDownload, layoutDownloadProgress, layoutUse, donutProgress, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }



    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout layoutMain;
        TextView tvThemeName, tvUse;
        public ImageView ivPlayPause;
        public CircleImageView ivThumb;
        public LinearLayout layoutDownloadProgress;
        public LinearLayout layoutUse;
        public LinearLayout layoutMainTheme;
        public LinearLayout layoutPlayPause;
        public LinearLayout layoutDownload;
        DonutProgress donutProgress;
        CheckBox cbSong;

        ThemeViewHolder(View itemView) {
            super(itemView);
            layoutMain = itemView.findViewById(R.id.rl_main);
            tvThemeName = itemView.findViewById(R.id.tv_theme_name);
            tvUse = itemView.findViewById(R.id.tv_create);
            layoutPlayPause = itemView.findViewById(R.id.LLplaypause);
            ivThumb = itemView.findViewById(R.id.iv_thumb);
            layoutMainTheme = itemView.findViewById(R.id.ll_main_theme);
            layoutDownloadProgress = itemView.findViewById(R.id.ll_download_progress);
            layoutUse = itemView.findViewById(R.id.llUseMusic);
            layoutDownload = itemView.findViewById(R.id.llDownload);
            ivPlayPause = itemView.findViewById(R.id.ivPlayPause);
            donutProgress = itemView.findViewById(R.id.donutProgress);
            cbSong = itemView.findViewById(R.id.cb_music);
        }
    }

}
