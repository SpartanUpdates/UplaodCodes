package com.esc.phoneheart.advancedclean;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build.VERSION;
import android.text.format.Formatter;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.esc.phoneheart.R;
import com.esc.phoneheart.advancedclean.CleanMasterAccessbilityService.TASK_STATE;
import com.esc.phoneheart.advancedclean.ClickHandler.IOnMuliClickListener;
import java.util.List;
import androidx.core.internal.view.SupportMenu;

public class CleanUI {
    public static final String TAG = "CleanUI";
    public Context mAppContext;
    public ClickHandler mClickHandler;
    public StringBuilder mContent = new StringBuilder(128);
    public Button mImageButton;
    public ImageView mImageView;
    public RelativeLayout mLayout;
    public long mNewAvaiableMen = 0;
    public long mOldAvaiableMem = 0;
    public int mProgress = 0;
    public SeekBar mProgressBar;
    public TextView mProgressTips;
    public boolean mShowing = false;
    public TextView mTextView;
    public int mTotal = 0;
    public LayoutParams mWLParams;

    public CleanUI(Context context) {
        this.mAppContext = context.getApplicationContext();
        initView();
    }

    private void initView() {
        LayoutParams layoutParams = new LayoutParams();
        this.mWLParams = layoutParams;
        if (VERSION.SDK_INT > 24) {
            layoutParams.type = 2038;
        } else {
            layoutParams.type = 2005;
        }
        layoutParams = this.mWLParams;
        layoutParams.format = 1;
        layoutParams.flags = 1800;
        layoutParams.gravity = 49;
        layoutParams.height = ScreenUtils.getScreenSize(this.mAppContext)[1];
        this.mWLParams.screenOrientation = 1;
        this.mLayout = new RelativeLayout(this.mAppContext);
        int[] screenSize = ScreenUtils.getScreenSize(this.mAppContext);
        this.mImageView = new ImageView(this.mAppContext);
        TextView textView = new TextView(this.mAppContext);
        this.mTextView = textView;
        textView.setTextSize(2, 14.0f);
        this.mTextView.setTextColor(-1);
        this.mTextView.setGravity(81);
        SeekBar seekBar = new SeekBar(this.mAppContext);
        this.mProgressBar = seekBar;
        seekBar.setBackgroundColor(SupportMenu.CATEGORY_MASK);
        this.mProgressBar.setPadding(0, 0, 0, 0);
        this.mProgressBar.setProgressDrawable(this.mAppContext.getResources().getDrawable(R.drawable.progress_drawable_advclean));
        this.mProgressBar.setThumb(null);
        this.mProgressBar.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });
        LinearLayout linearLayout = new LinearLayout(this.mAppContext);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, screenSize[0]);
        layoutParams2.bottomMargin = screenSize[1] / 10;
        layoutParams2.width = screenSize[1] / 5;
        layoutParams2.height = screenSize[1] / 5;
        linearLayout.addView(this.mImageView, layoutParams2);
        layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = ScreenUtils.dip2px(this.mAppContext, 12.0f);
        layoutParams2.leftMargin = screenSize[0] / 20;
        linearLayout.addView(this.mProgressBar, layoutParams2);
        layoutParams2 = new LinearLayout.LayoutParams(-1, screenSize[1] / 10);
        layoutParams2.topMargin = ScreenUtils.dip2px(this.mAppContext, 12.0f);
        layoutParams2.leftMargin = screenSize[0] / 10;
        layoutParams2.rightMargin = screenSize[0] / 10;
        linearLayout.addView(this.mTextView, layoutParams2);
        TextView textView2 = new TextView(this.mAppContext);
        this.mProgressTips = textView2;
        textView2.setGravity(17);
        this.mProgressTips.setTextColor(-1);
        this.mProgressTips.setTextSize(2, 13.0f);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = screenSize[1] / 10;
        linearLayout.addView(this.mProgressTips, layoutParams3);
        Button button = new Button(this.mAppContext);
        this.mImageButton = button;
        button.setText(this.mAppContext.getString(R.string.dialouge_cancel));
        this.mImageButton.setBackgroundColor(this.mAppContext.getResources().getColor(R.color.colorPrimaryDark));
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams4.addRule(13);
        this.mLayout.addView(linearLayout, layoutParams4);
        mClickHandler = new ClickHandler(this.mImageButton, new IOnMuliClickListener() {
            public void onMultiClick(View view, int i) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onMultiClick: ");
                stringBuilder.append(i);
                if (i == 2) {
                    Cleaner.stop(CleanUI.this.mAppContext);
                } else if (i >= 3) {
                    Cleaner.exit(CleanUI.this.mAppContext);
                }
            }
        });
        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(-1, -2);
        layoutParams5.addRule(12);
        layoutParams5.bottomMargin = screenSize[1] / 10;
        this.mLayout.addView(this.mImageButton, layoutParams5);
    }

    private void updateContent() {
    }

    public void onResult(TASK_STATE task_state) {
        if (task_state != null) {
            this.mContent.append(task_state.name());
        }
        this.mContent.append("\n");
    }

    public void onStart(int i) {
        this.mTotal = i;
        StringBuilder stringBuilder = new StringBuilder(128);
        this.mContent = stringBuilder;
        stringBuilder.append("start clean...\n\n");
        updateContent();
        this.mProgress = 0;
        this.mProgressBar.setMax(this.mTotal);
        this.mProgressBar.setProgress(this.mProgress);
        this.mProgressBar.setVisibility(View.VISIBLE);
        this.mOldAvaiableMem = SystemUtils.getMemoryInfo(this.mAppContext).availMem;
    }

    public void onStop(List<String> list) {
        StringBuilder stringBuilder = this.mContent;
        String str = "\n";
        stringBuilder.append(str);
        if (this.mProgress >= this.mTotal) {
            stringBuilder = this.mContent;
            stringBuilder.append("clean successed!");
            stringBuilder.append(str);
        } else {
            stringBuilder = this.mContent;
            stringBuilder.append("clean stoped!");
            stringBuilder.append(str);
        }
        this.mNewAvaiableMen = SystemUtils.getMemoryInfo(this.mAppContext).availMem;
        stringBuilder = new StringBuilder();
        stringBuilder.append("opt ");
        stringBuilder.append(Formatter.formatFileSize(this.mAppContext, this.mOldAvaiableMem));
        stringBuilder.append(" > ");
        stringBuilder.append(Formatter.formatFileSize(this.mAppContext, this.mNewAvaiableMen));
        stringBuilder.append(" freed: ");
        stringBuilder.append(this.mNewAvaiableMen < this.mOldAvaiableMem ? "-" : "");
        stringBuilder.append(Formatter.formatFileSize(this.mAppContext, Math.abs(this.mNewAvaiableMen - this.mOldAvaiableMem)));
        String stringBuilder2 = stringBuilder.toString();
        StringBuilder stringBuilder3 = this.mContent;
        stringBuilder3.append("\n\n");
        stringBuilder3.append(stringBuilder2);
        stringBuilder3.append(str);
        stringBuilder = this.mContent;
        stringBuilder3 = new StringBuilder();
        stringBuilder3.append("total memory: ");
        Context context = this.mAppContext;
        stringBuilder3.append(Formatter.formatFileSize(context, SystemUtils.getMemoryInfo(context).totalMem));
        stringBuilder.append(stringBuilder3.toString());
        stringBuilder.append(str);
        if (list != null && list.size() > 0) {
            stringBuilder = this.mContent;
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append("\n\nthose ");
            stringBuilder3.append(list.size());
            stringBuilder3.append(" packages stop failed: \n\n");
            stringBuilder.append(stringBuilder3.toString());
            for (String stringBuilder22 : list) {
                stringBuilder3 = this.mContent;
                stringBuilder3.append(stringBuilder22);
                stringBuilder3.append(str);
            }
        }
        updateContent();
    }

    public void onTaskStart(String str) {
        int i = this.mProgress + 1;
        this.mProgress = i;
        this.mProgressBar.setProgress(i);
        TextView textView = this.mProgressTips;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mProgress);
        stringBuilder.append("/");
        stringBuilder.append(this.mTotal);
        textView.setText(stringBuilder.toString());
        StringBuilder stringBuilder2 = this.mContent;
        stringBuilder2.append(str);
        stringBuilder2.append("...");
        this.mTextView.setText(str);
        try {
            Glide.with(this.mAppContext)
                    .load(this.mAppContext.getPackageManager().getApplicationInfo(str, 0))
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(this.mImageView);
        } catch (Exception e) {
            this.mImageView.setImageResource(R.mipmap.ic_launcher);
            e.printStackTrace();
        }
        updateContent();
    }

    public void show(boolean z) {
        if (this.mShowing != z) {
            @SuppressLint("WrongConstant") WindowManager windowManager = (WindowManager) this.mAppContext.getSystemService("window");
            if (z) {
                windowManager.addView(this.mLayout, this.mWLParams);
            } else {
                windowManager.removeView(this.mLayout);
            }
            this.mShowing = z;
        }
    }
}
