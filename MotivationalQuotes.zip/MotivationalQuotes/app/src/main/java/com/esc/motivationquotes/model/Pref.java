package com.esc.motivationquotes.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.esc.motivationquotes.util.Constants;

public class Pref {
    private static SharedPreferences sharedPreferences;

    public static void openPref(Context context) {
        sharedPreferences = context.getSharedPreferences(Constants.PREF_FILE, 0);
    }

    public static String getValue(Context context, String str, String str2) {
        openPref(context);
        String string = sharedPreferences.getString(str, str2);
        sharedPreferences = null;
        return string;
    }

    public static void setValue(Context context, String str, String str2) {
        openPref(context);
        Editor edit = sharedPreferences.edit();
        edit.putString(str, str2);
        edit.commit();
        sharedPreferences = null;
    }
}
