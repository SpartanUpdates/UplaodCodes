package com.wavymusic.RetrofitApiCall;

public class AppConstant {
    /*Wavy Music Start*/
    public static String BASEURL = "http://beatsadmin.trendinganimations.com/public/api/";
    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "30";
    /*Wavy Music End*/

    /*Particle Id*/
    public static String ParticleApplicationId = "36";

    /*United Viedeo Start*/

    public static String BASEURL_UV = "http://uvadmin.trendinganimations.com/public/api/";

    /*United Viedeo End*/

    /*Wavy Download Url*/
    public static String ThemeThumburlWavy = "";
    public static String SmallThemeThumbrlWavy = "";
    public static String SoundUrlWavy = "";

    /*Uv Download Url*/
    public static String ThemeThumbUv = "";
    public static String AnimUrlUv = "";
    public static String SoundUrlUv = "";


    /*Partical Url*/
    public static long ApiUpdateTime = 1800000L;

    public static String ThemeHome = "0";
    public static String ThemeViewAll = "1";

    /*InterstitialAdCountWavy*/
   /* public static int HomeThemeAdCountWavy = 0;
    public static int ThemeViewAllAdCountWavy = 0;
    public static int SongSelectAdCountWavy = 0;
    public static int TetxAdCountWavy = 0;
    public static int CropAdCountWavy = 0;
    public static int PhoneSeongAdCountWavy = 0;*/

    /*InterstitialAdCountUv*/
  /*  public static int HomeThemeAdCountUv = 0;
    public static int ThemeViewAllAdCountUv = 0;
    public static int TetxAdCountUv = 0;
    public static int ArrangeImageAdcountUv = 0;
    public static int PhoneSongActivityUv = 0;*/
}
