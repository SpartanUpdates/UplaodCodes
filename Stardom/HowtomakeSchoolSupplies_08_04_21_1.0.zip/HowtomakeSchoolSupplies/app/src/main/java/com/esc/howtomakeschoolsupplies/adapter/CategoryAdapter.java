package com.esc.howtomakeschoolsupplies.adapter;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.esc.howtomakeschoolsupplies.R;
import java.util.List;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import com.esc.howtomakeschoolsupplies.network.Recommended;
import com.esc.howtomakeschoolsupplies.pojo.Category;

public class CategoryAdapter extends Adapter<CategoryAdapter.ViewHolder> {
    private final Context mContext;
    private final EventCategoryFragment mEventCategoryFragment;
    private final FragmentManager mFragmentManager;
    private final List<Category> mListCategory;
    private final MediaPlayer mpClick;

    public interface EventCategoryFragment {
        void onClickBtnCategory(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements OnClickListener{
        TextView text_category;
        ImageView image_category;
        TextView category_size;
        ImageView image_new_article;

        public ViewHolder(View view) {
            super(view);
            text_category = (TextView) view.findViewById(R.id.text_category);
            image_category = view.findViewById(R.id.image_category);
            category_size = (TextView) view.findViewById(R.id.category_size);
            image_new_article = (ImageView) view.findViewById(R.id.image_new_article);
            itemView.setOnClickListener(this);
        }

        public void onClick(View view) {
            Intrinsics.checkParameterIsNotNull(view, "view");
            mpClick.start();
            if (getAdapterPosition() < getMListCategory().size()) {
               getMEventCategoryFragment().onClickBtnCategory(((Category) getMListCategory().get(getAdapterPosition())).getId());
            }
            if (getAdapterPosition() == getMListCategory().size()) {
                String packageName = getMContext().getPackageName();
                try {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                    String str = getMContext().getResources().getString(R.string.app_name) + "\n";
                    intent.putExtra(Intent.EXTRA_TEXT, str + mContext.getResources().getString(R.string.rate_us_url) + packageName + "\n\n");
                    getMContext().startActivity(Intent.createChooser(intent, getMContext().getResources().getString(R.string.share)));
                    return;
                } catch (Exception e) {
                    e.toString();
                }
            }if (getAdapterPosition() + 1 == getMListCategory().size() + 2) {
                try {
                    mContext.startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse(mContext.getResources().getString(R.string.rate_us_url)
                                    + mContext.getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(mContext, "You don't have Google Play store installed",
                            Toast.LENGTH_SHORT).show();
                }
            }

        }
    }

    public final Context getMContext() {
        return this.mContext;
    }

    public final List<Category> getMListCategory() {
        return this.mListCategory;
    }

    public CategoryAdapter(Context context, List<Category> list, FragmentManager fragmentManager) {
        Intrinsics.checkParameterIsNotNull(context, "mContext");
        Intrinsics.checkParameterIsNotNull(list, "mListCategory");
        Intrinsics.checkParameterIsNotNull(fragmentManager, "fragmentManager");
        this.mContext = context;
        this.mListCategory = list;
        if (context != null) {
            this.mEventCategoryFragment = (EventCategoryFragment) context;
            this.mFragmentManager = fragmentManager;
            this.mpClick = MediaPlayer.create(context, context.getResources().getIdentifier("click2", "raw", context.getPackageName()));
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type com.esc.howtomakeschoolsupplies.adapter.CategoryAdapter.EventCategoryFragment");
    }

    public final EventCategoryFragment getMEventCategoryFragment() {
        return this.mEventCategoryFragment;
    }

    public final void setRecommendedList(List<Recommended> list) {
        Intrinsics.checkParameterIsNotNull(list, "<set-?>");
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        Intrinsics.checkParameterIsNotNull(viewGroup, "parent");
        LayoutInflater from = LayoutInflater.from(this.mContext);
        String str = "inflater";
        Intrinsics.checkExpressionValueIsNotNull(from, str);
        return new ViewHolder(from.inflate(R.layout.category_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int position) {
        Intrinsics.checkParameterIsNotNull(viewHolder, "holder");
        String str = "itemView.image_new_article";
        String str2 = "itemView.text_category";
        String str3 = "itemView.category_size";
        String str4 = "itemView";
        View view ;
        ViewHolder viewholder = (ViewHolder) viewHolder;

        if (position < getMListCategory().size())
        {
            view = viewholder.itemView;
            Intrinsics.checkExpressionValueIsNotNull(view, str4);
            Intrinsics.checkExpressionValueIsNotNull(viewholder.text_category, str2);
            viewholder.text_category.setText(((Category) getMListCategory().get(position)).getDescription());
            Intrinsics.checkExpressionValueIsNotNull(view, str4);
            viewholder.image_category.setImageDrawable(ContextCompat.getDrawable(getMContext(), R.drawable.ic_btnbox));
            if (((Category) getMListCategory().get(position)).getNewArticleSize() == 0)
            {
                view = viewholder.itemView;
                Intrinsics.checkExpressionValueIsNotNull(view, str4);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.category_size, str3);
                viewholder.category_size.setVisibility(View.INVISIBLE);
                Intrinsics.checkExpressionValueIsNotNull(view, str4);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.image_new_article, str);
                viewholder.image_new_article.setVisibility(View.INVISIBLE);
            }
            else
            {
                view = viewholder.itemView;
                Intrinsics.checkExpressionValueIsNotNull(view, str4);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.category_size, str3);
                viewholder.category_size.setVisibility(View.VISIBLE);
                Intrinsics.checkExpressionValueIsNotNull(view, str4);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.image_new_article, str);
                viewholder.image_new_article.setVisibility(View.VISIBLE);
                view = viewHolder.itemView;
                Intrinsics.checkExpressionValueIsNotNull(view, str4);
                Intrinsics.checkExpressionValueIsNotNull(viewholder.category_size, str3);
                viewholder.category_size.setText(String.valueOf(((Category) getMListCategory().get(position)).getNewArticleSize()));
            }
            view = viewholder.itemView;
            Intrinsics.checkExpressionValueIsNotNull(view, str4);
            Intrinsics.checkExpressionValueIsNotNull(viewholder.text_category, str2);
            viewholder.text_category.setVisibility(View.VISIBLE);
            return;
        }
        position++;
        if (position == getMListCategory().size() + 1)
        {
            view = viewholder.itemView;
            Intrinsics.checkExpressionValueIsNotNull(view, str4);
            viewholder.image_category.setImageDrawable(ContextCompat.getDrawable(getMContext(), R.drawable.ic_share));
        }
        if (position == getMListCategory().size() + 2) {
            view = viewholder.itemView;
            Intrinsics.checkExpressionValueIsNotNull(view, str4);
            viewholder.image_category.setImageDrawable(ContextCompat.getDrawable(getMContext(), R.drawable.ic_like));
        }
        view = viewholder.itemView;
        Intrinsics.checkExpressionValueIsNotNull(view, str4);
        Intrinsics.checkExpressionValueIsNotNull(viewholder.image_new_article, str);
        viewholder.image_new_article.setVisibility(View.INVISIBLE);
        Intrinsics.checkExpressionValueIsNotNull(view, str4);
        Intrinsics.checkExpressionValueIsNotNull(viewholder.category_size, str3);
        viewholder.category_size.setVisibility(View.INVISIBLE);
        Intrinsics.checkExpressionValueIsNotNull(view, str4);
        Intrinsics.checkExpressionValueIsNotNull(viewholder.text_category, str2);
        viewholder.text_category.setVisibility(View.INVISIBLE);
    }

    public int getItemCount() {
        return this.mListCategory.size() + 2;
    }
}