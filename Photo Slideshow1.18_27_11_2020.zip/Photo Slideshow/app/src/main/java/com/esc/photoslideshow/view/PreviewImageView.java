package com.esc.photoslideshow.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;

import com.esc.photoslideshow.*;
import com.esc.photoslideshow.R;

public class PreviewImageView extends ImageView {
    public static int aspect_ratioHeight;
    public static int aspect_ratioWidth;

    static {
        aspect_ratioWidth = 720;
        aspect_ratioHeight = 360;
    }

    public PreviewImageView(Context context) {
        super(context);
    }

    public PreviewImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        Init(context, attrs);
    }

    public PreviewImageView(Context context, AttributeSet attrs,
                            int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        Init(context, attrs);
    }

    @SuppressLint({"NewApi"})
    public PreviewImageView(Context context, AttributeSet attrs,
                            int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        Init(context, attrs);
    }

    private void Init(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs,
                R.styleable.PreviewImageView);
        aspect_ratioWidth = a.getInt(0, MyApplication.VIDEO_WIDTH);
        aspect_ratioHeight = a.getInt(1, MyApplication.VIDEO_HEIGHT);
        Log.e("mAspectRatioWidth", "mAspectRatioWidth:" + aspect_ratioWidth
                + " mAspectRatioHeight:" + aspect_ratioHeight);
        a.recycle();
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int finalWidth;
        int finalHeight;
        int originalWidth = MeasureSpec.getSize(widthMeasureSpec);
        int originalHeight = MeasureSpec.getSize(heightMeasureSpec);
        int calculatedHeight = (int) (((float) (aspect_ratioHeight * originalWidth)) / ((float) aspect_ratioWidth));
        if (calculatedHeight > originalHeight) {
            finalWidth = (int) (((float) (aspect_ratioWidth * originalHeight)) / ((float) aspect_ratioHeight));
            finalHeight = originalHeight;
        } else {
            finalWidth = originalWidth;
            finalHeight = calculatedHeight;
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(finalWidth, 1073741824),
                MeasureSpec.makeMeasureSpec(finalHeight, 1073741824));
    }
}
