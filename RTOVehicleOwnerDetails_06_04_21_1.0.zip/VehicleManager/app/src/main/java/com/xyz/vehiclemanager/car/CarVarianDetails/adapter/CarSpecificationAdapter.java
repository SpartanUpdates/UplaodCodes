package com.xyz.vehiclemanager.car.CarVarianDetails.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.adapter.VariantItemAttrAdapter;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarSpecification;
import com.xyz.vehiclemanager.model.Item;

import java.util.ArrayList;

public class CarSpecificationAdapter extends RecyclerView.Adapter<CarSpecificationAdapter.ViewHolder> {
    private Context context;
    private ArrayList<CarSpecification> specificationKeyList;
    private ArrayList<Item> dimensionsAndWeight;
    private ArrayList<Item> capacity;
    private ArrayList<Item> engineAndTransmitionsuspensions;
    private ArrayList<Item> suspensions;
    private VariantItemAttrAdapter specificationAttrAdapter;

    public CarSpecificationAdapter(Context context, ArrayList<CarSpecification> specificationKeyList, ArrayList<Item> dimensionsAndWeight, ArrayList<Item> capacity, ArrayList<Item> engineAndTransmitionsuspensions, ArrayList<Item> suspensions) {
        this.context = context;
        this.specificationKeyList = specificationKeyList;
        this.dimensionsAndWeight = dimensionsAndWeight;
        this.capacity = capacity;
        this.engineAndTransmitionsuspensions = engineAndTransmitionsuspensions;
        this.suspensions = suspensions;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {   RecyclerView rv_variantKey;
        TextView tv_varinatKeyName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_varinatKeyName =itemView.findViewById(R.id.tv_varinatKeyName);
            rv_variantKey =itemView.findViewById(R.id.rv_variantKey);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_variantkey,parent,false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CarSpecification specification = specificationKeyList.get(position);
        holder.tv_varinatKeyName.setText(specification.getKey());
        String key = specification.getKey();

        if(key.equals("Dimensions & Weight "))
        {
            specificationAttrAdapter = new VariantItemAttrAdapter(context, dimensionsAndWeight);
            holder.rv_variantKey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_variantKey.setAdapter(specificationAttrAdapter);
        }
        else if(key.equals("Capacity "))
        {
            specificationAttrAdapter = new VariantItemAttrAdapter(context, capacity);
            holder.rv_variantKey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_variantKey.setAdapter(specificationAttrAdapter);
        }
        else if(key.equals("Engine & Transmission "))
        {
            specificationAttrAdapter = new VariantItemAttrAdapter(context, engineAndTransmitionsuspensions);
            holder.rv_variantKey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_variantKey.setAdapter(specificationAttrAdapter);
        }
        else if(key.equals("Suspensions, Brakes & Steering "))
        {
            specificationAttrAdapter = new VariantItemAttrAdapter(context, suspensions);
            holder.rv_variantKey.setLayoutManager(new LinearLayoutManager(context));
            holder.rv_variantKey.setAdapter(specificationAttrAdapter);
        }
    }
    @Override
    public int getItemCount() {
        return specificationKeyList.size();
    }
}
