package com.example.womenabsworkout.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenabsworkout.R;
import com.example.womenabsworkout.adapters.IndividualDayAdapter;
import com.example.womenabsworkout.adapters.WorkoutData;
import com.example.womenabsworkout.database.DatabaseOperations;
import com.example.womenabsworkout.kprogresshud.KProgressHUD;
import com.example.womenabsworkout.listners.RecyclerItemClickListener;
import com.example.womenabsworkout.newscreen.Library;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;


public class DayActivity extends AppCompatActivity {
    Activity activity = DayActivity.this;

    Library A;
    private LinearLayout container;
    private Editor editorDay;
    RecyclerView i;
    Button l;
    LinearLayoutManager m;
    private GridLayoutManager manager;
    IndividualDayAdapter n;
    String o;
    float p;
    private SharedPreferences preferencesDay;

    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    HashMap<String, Integer> q;
    HashMap<String, Integer> r;

    int[] s = new int[]{R.array.day1, R.array.day2, R.array.day3, R.array.day4, R.array.day5, R.array.day6, R.array.day7, R.array.day8, R.array.day9, R.array.day10, R.array.day11, R.array.day12, R.array.day13, R.array.day14, R.array.day15, R.array.day16, R.array.day17, R.array.day18, R.array.day19, R.array.day20, R.array.day21, R.array.day22, R.array.day23, R.array.day24, R.array.day25, R.array.day26, R.array.day27, R.array.day28, R.array.day29, R.array.day30};
    int[] t = new int[]{R.array.day1_cycles, R.array.day2_cycles, R.array.day3_cycles, R.array.day4_cycles, R.array.day5_cycles, R.array.day6_cycles, R.array.day7_cycles, R.array.day8_cycles, R.array.day9_cycles, R.array.day10_cycles, R.array.day11_cycles, R.array.day12_cycles, R.array.day13_cycles, R.array.day14_cycles, R.array.day15_cycles, R.array.day16_cycles, R.array.day17_cycles, R.array.day18_cycles, R.array.day19_cycles, R.array.day20_cycles, R.array.day21_cycles, R.array.day22_cycles, R.array.day23_cycles, R.array.day24_cycles, R.array.day25_cycles, R.array.day26_cycles, R.array.day27_cycles, R.array.day28_cycles, R.array.day29_cycles, R.array.day30_cycles};
    int u = -1;
    ArrayList<WorkoutData> v;

    Intent y;
    String z;

    public static void lambda$onCreate$1(DayActivity dayActivity, View view, int i) {
        if (i < dayActivity.v.size()) {
            Intent intent = new Intent(dayActivity, ExcDetailsActivity.class);
            Bundle bundle = new Bundle();
            bundle.putIntArray("framesIdArray", ((WorkoutData) dayActivity.v.get(i)).getImageIdList());
            bundle.putString("excName", ((WorkoutData) dayActivity.v.get(i)).getExcName());
            bundle.putInt("excNameDescResId", ((Integer) dayActivity.r.get(((WorkoutData) dayActivity.v.get(i)).getExcName())).intValue());
            bundle.putInt("excCycle", ((WorkoutData) dayActivity.v.get(i)).getExcCycles());
            intent.putExtras(bundle);
            dayActivity.startActivity(intent);
        }
    }

    public static void lambda$onCreate$2(DayActivity dayActivity, View view) {
        dayActivity.y = new Intent(dayActivity, MainExcerciseActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("workoutDataList", dayActivity.v);
        dayActivity.y.putExtras(bundle);
        dayActivity.y.putExtra("day", dayActivity.o);
        float excDayProgress = new DatabaseOperations(dayActivity).getExcDayProgress(dayActivity.o);
        dayActivity.p = excDayProgress;
        dayActivity.y.putExtra(NotificationCompat.CATEGORY_PROGRESS, excDayProgress);
        dayActivity.startActivity(dayActivity.y);
    }

    private void updateLocale(String str) {
        Locale locale = new Locale(str);
        Resources resources = getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        resources.updateConfiguration(configuration, displayMetrics);
    }

    public ArrayList<WorkoutData> b() {
        ArrayList arrayList = new ArrayList();
        String[] stringArray = getResources().getStringArray(this.s[this.u]);
        int[] intArray = getResources().getIntArray(this.t[this.u]);
        for (int i = 0; i < stringArray.length; i++) {
            TypedArray obtainTypedArray = getResources().obtainTypedArray(((Integer) this.q.get(stringArray[i])).intValue());
            int length = obtainTypedArray.length();
            int[] iArr = new int[length];
            WorkoutData workoutData = new WorkoutData();
            for (int i2 = 0; i2 < length; i2++) {
                iArr[i2] = obtainTypedArray.getResourceId(i2, -1);
            }
            workoutData.setExcName(stringArray[i]);
            workoutData.setExcDescResId(((Integer) this.r.get(stringArray[i])).intValue());
            workoutData.setExcCycles(intArray[i]);
            workoutData.setPosition(i);
            workoutData.setImageIdList(iArr);
            arrayList.add(workoutData);
        }
        return arrayList;
    }

    public void c() {
        HashMap hashMap = new HashMap();
        this.q = hashMap;
        hashMap.put(getString(R.string.trunk_rotation), Integer.valueOf(R.array.trunk_rotation));
        this.q.put(getString(R.string.mountain_climber), Integer.valueOf(R.array.mountain_climber));
        this.q.put(getString(R.string.clapping_crunches), Integer.valueOf(R.array.clapping_crunches));
        this.q.put(getString(R.string.swimming_and_superman), Integer.valueOf(R.array.swimming_and_superman));
        this.q.put(getString(R.string.butt_bridge), Integer.valueOf(R.array.butt_bridge));
        this.q.put(getString(R.string.flutter_kicks), Integer.valueOf(R.array.flutter_kicks));
        this.q.put(getString(R.string.plank), Integer.valueOf(R.array.plank));
        this.q.put(getString(R.string.reverse_crunches), Integer.valueOf(R.array.reverse_crunches));
        this.q.put(getString(R.string.bent_leg_twist), Integer.valueOf(R.array.bent_leg_twist));
        this.q.put(getString(R.string.bicycle_crunches), Integer.valueOf(R.array.bicycle_crunches));
        this.q.put(getString(R.string.russian_twist), Integer.valueOf(R.array.russian_twist));
        this.q.put(getString(R.string.reclined_oblique_twist), Integer.valueOf(R.array.reclined_oblique_twist));
        this.q.put(getString(R.string.cross_arm_crunches), Integer.valueOf(R.array.cross_arm_crunches));
        this.q.put(getString(R.string.standing_bicycle), Integer.valueOf(R.array.standing_bicycle));
        this.q.put(getString(R.string.leg_drops), Integer.valueOf(R.array.leg_drops));
        this.q.put(getString(R.string.side_leg_rise_left), Integer.valueOf(R.array.side_leg_rise_left));
        this.q.put(getString(R.string.side_leg_rise_right), Integer.valueOf(R.array.side_leg_rise_right));
        this.q.put(getString(R.string.long_arm_crunches), Integer.valueOf(R.array.long_arm_crunches));
        this.q.put(getString(R.string.dead_bug), Integer.valueOf(R.array.dead_bug));
        this.q.put(getString(R.string.cross_body_mountain_climber), Integer.valueOf(R.array.cross_body_mountain_climber));
        this.q.put(getString(R.string.roll_up), Integer.valueOf(R.array.roll_up));
        this.q.put(getString(R.string.side_plank_hip_lift_left), Integer.valueOf(R.array.Side_plank_hip_lift_left));
        this.q.put(getString(R.string.side_plank_hip_lift_right), Integer.valueOf(R.array.Side_plank_hip_lift_right));
        this.q.put(getString(R.string.v_sits), Integer.valueOf(R.array.V_sits));
        this.q.put(getString(R.string.windshield_wipers), Integer.valueOf(R.array.Windshield_wipers));
        this.q.put(getString(R.string.reverse_crunch), Integer.valueOf(R.array.reverse_crunch));
    }

    public void d() {
        HashMap hashMap = new HashMap();
        this.r = hashMap;
        hashMap.put(getString(R.string.trunk_rotation), Integer.valueOf(R.string.trunk_rotation_desc));
        this.r.put(getString(R.string.mountain_climber), Integer.valueOf(R.string.mountain_climber_desc));
        this.r.put(getString(R.string.clapping_crunches), Integer.valueOf(R.string.clapping_crunches_desc));
        this.r.put(getString(R.string.swimming_and_superman), Integer.valueOf(R.string.swimming_and_superman_desc));
        this.r.put(getString(R.string.butt_bridge), Integer.valueOf(R.string.butt_bridge_desc));
        this.r.put(getString(R.string.flutter_kicks), Integer.valueOf(R.string.flutter_kicks_desc));
        this.r.put(getString(R.string.plank), Integer.valueOf(R.string.plank_desc));
        this.r.put(getString(R.string.reverse_crunches), Integer.valueOf(R.string.reverse_crunches_desc));
        this.r.put(getString(R.string.bent_leg_twist), Integer.valueOf(R.string.bent_leg_twist_desc));
        this.r.put(getString(R.string.bicycle_crunches), Integer.valueOf(R.string.bicycle_crunches_desc));
        this.r.put(getString(R.string.russian_twist), Integer.valueOf(R.string.russian_twist_desc));
        this.r.put(getString(R.string.reclined_oblique_twist), Integer.valueOf(R.string.reclined_oblique_twist_desc));
        this.r.put(getString(R.string.cross_arm_crunches), Integer.valueOf(R.string.cross_arm_crunches_desc));
        this.r.put(getString(R.string.standing_bicycle), Integer.valueOf(R.string.standing_bicycle_desc));
        this.r.put(getString(R.string.leg_drops), Integer.valueOf(R.string.leg_drops_desc));
        this.r.put(getString(R.string.side_leg_rise_left), Integer.valueOf(R.string.side_leg_rise_left_desc));
        this.r.put(getString(R.string.side_leg_rise_right), Integer.valueOf(R.string.side_leg_rise_right_desc));
        this.r.put(getString(R.string.long_arm_crunches), Integer.valueOf(R.string.long_arm_crunches_desc));
        this.r.put(getString(R.string.dead_bug), Integer.valueOf(R.string.dead_bug_desc));
        this.r.put(getString(R.string.cross_body_mountain_climber), Integer.valueOf(R.string.cross_body_mountain_climber_desc));
        this.r.put(getString(R.string.roll_up), Integer.valueOf(R.string.roll_up_desc));
        this.r.put(getString(R.string.side_plank_hip_lift_left), Integer.valueOf(R.string.Side_plank_hip_lift_left_desc));
        this.r.put(getString(R.string.side_plank_hip_lift_right), Integer.valueOf(R.string.Side_plank_hip_lift_right_desc));
        this.r.put(getString(R.string.v_sits), Integer.valueOf(R.string.V_sits_desc));
        this.r.put(getString(R.string.windshield_wipers), Integer.valueOf(R.string.Windshield_wipers_desc));
        this.r.put(getString(R.string.reverse_crunch), Integer.valueOf(R.string.reverse_crunches_descip));
    }

    View view;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.preferencesDay = defaultSharedPreferences;
        String string = defaultSharedPreferences.getString("languageToLoad", "");
        this.z = string;
        updateLocale(string);

        setContentView(R.layout.day_layout);

        this.i = (RecyclerView) findViewById(R.id.recyclerAllDaysList);
        this.A = new Library(this);
        this.l = (Button) findViewById(R.id.buttonTwo);
        this.m = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        interstitialAd();
        c();
        d();

        bundle = getIntent().getExtras();
        this.o = bundle.getString("day");
        ((TextView) findViewById(R.id.mtoolbar_title)).setText(this.o);
        this.u = bundle.getInt("day_num");
        this.p = bundle.getFloat(NotificationCompat.CATEGORY_PROGRESS);
        Toolbar toolbar = (Toolbar) findViewById(R.id.mtoolbar);
        // ((TextView) toolbar.findViewById(R.id.mtoolbar_title)).setText(this.o);
        toolbar.setNavigationOnClickListener(new OnClickListener() {
            public final void onClick(View view) {
                DayActivity.this.finish();
            }
        });
        this.v = b();
        this.n = new IndividualDayAdapter(this, this.o, this.v, Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.i.setLayoutManager(this.m);
        this.i.setAdapter(this.n);
        this.i.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.onItemClickListener() {
            public final void OnItem(View view, int i) {
                DayActivity.lambda$onCreate$1(DayActivity.this, view, i);
            }
        }));
        this.l.setOnClickListener(new OnClickListener() {
            public final void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    DayActivity.lambda$onCreate$2(DayActivity.this, view);
                }

            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }

    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        DayActivity.lambda$onCreate$2(DayActivity.this, view);
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
