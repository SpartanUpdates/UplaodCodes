package com.example.womenabsworkout.utils;

public class AppUtils {
    public static String KEY_PROGRESS = "ArmWorkout";
    public static String WORKOUT_BROADCAST_FILTER = "com.android.armworkout";
    public static boolean ifTipUnlocked = false;
    public static boolean ifTipWatched = false;
}
