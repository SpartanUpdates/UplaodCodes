package com.jenilcreation.photomusicvideo.util;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class PermissionModelUtil1 implements OnClickListener {
    final  PermissionModelUtil this$0;

    PermissionModelUtil1(PermissionModelUtil permissionModelUtil) {
        this.this$0 = permissionModelUtil;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
    }
}
