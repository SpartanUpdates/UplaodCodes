package com.kotlinz.festivalstorymaker.Utils.a;

public class g {
    public static final int rate_dialog_cancel = 2131820925;
    public static final int rate_dialog_message = 2131820926;
    public static final int rate_dialog_no = 2131820927;
    public static final int rate_dialog_ok = 2131820928;
    public static final int rate_dialog_title = 2131820929;
}
