package com.esc.socialmediacleaner.util;

import android.os.Bundle;

public class AdParentScreen extends BaseActivity {

    private int height;
    private int width;

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public void onDestroy() {

        super.onDestroy();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }
}
