package com.wavymusic.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.widget.Toast;

import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.Model.VideoModel;
import com.wavymusic.R;
import com.wavymusic.application.MyApplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class Utils {
    public static final Utils INSTANCE;
    public static long mDeleteFileCount;
    public static String AssetPath = "asset_theam";
    public static String PathOfThemeFolder = Environment.getExternalStorageDirectory() + File.separator + "Wavy Music" + File.separator + ".ThemeDownload";
    public static String PathOfMusicFolder = Environment.getExternalStorageDirectory() + File.separator + "Wavy Music" + File.separator + "Online Song";
    static {
        INSTANCE = new Utils();
        Utils.mDeleteFileCount = 0L;
    }

    public static boolean checkConnectivity(Context lCon, final boolean show) {
        if (isNetworkConnected(lCon)) {
            return true;
        }
        if (show) {
            Toast.makeText(lCon, "Data/Wifi Not Available", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public static boolean isNetworkConnected(final Context lCon) {
        final ConnectivityManager cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    public static void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Wavy Music/";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Utils.INSTANCE.getStoryFolderPath();
    }

    public static boolean deleteFile(final File mFile) {
        boolean idDelete = false;
        if (mFile == null) {
            return idDelete;
        }
        if (mFile.exists()) {
            if (mFile.isDirectory()) {
                final File[] children = mFile.listFiles();
                if (children != null && children.length > 0) {
                    File[] array;
                    for (int length = (array = children).length, i = 0; i < length; ++i) {
                        final File child = array[i];
                        Utils.mDeleteFileCount += child.length();
                        idDelete = deleteFile(child);
                    }
                }
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            } else {
                Utils.mDeleteFileCount += mFile.length();
                idDelete = mFile.delete();
            }
        }
        return idDelete;
    }

    public void CopyFileToStorage(final String s, final String s2, final String s3) {
        try {
            final File file = new File(s3);
            if (!file.exists()) {
                file.mkdirs();
            }
            final FileInputStream fileInputStream = new FileInputStream(s);
            final FileOutputStream fileOutputStream = new FileOutputStream(s2);
            final byte[] array = new byte[1024];
            while (true) {
                final int read = fileInputStream.read(array);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException ex2) {
            ex2.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static float dp2px(final Resources resources, final float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(final Resources resources, final float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }

    public static ArrayList<VideoModel> getAllCreatedVideoList(Context context) {
        final ArrayList<VideoModel> AllVideoList = new ArrayList<>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = context.getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getAPPFOLDER() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoInfo = new VideoModel();
                videoInfo.videoDuration = cur.getLong(bucketColumn);
                videoInfo.videoFullPath = cur.getString(data);
                videoInfo.videoName = cur.getString(name);
                videoInfo.dateTaken = cur.getLong(dateTaken);
                if (new File(videoInfo.videoFullPath).exists()) {
                    AllVideoList.add(videoInfo);
                }
            } while (cur.moveToNext());
        }
        return AllVideoList;
    }

    public static byte[] getPictureByteOfArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public static Bitmap getBitmapFromByte(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    public static void AssetFilePath() {
        StringBuilder stringBuilder = new StringBuilder("/data/data/");
        stringBuilder.append(MyApplication.getInstance().getPackageName());
        stringBuilder.append("/");
        stringBuilder.append(AssetPath);
        AssetPathDir(new File(stringBuilder.toString()));
    }

    private static void AssetPathDir(File file) {
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
        }
    }

    public static String WhatsNewJson(ArrayList<ThemeHorizontalModel> ThemeListCategoryWise) {
        try {
            JSONObject jsonObj = new JSONObject();
            JSONArray jsonArr = new JSONArray();
            for (ThemeHorizontalModel pn : ThemeListCategoryWise) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", pn.getThemeid());
                jsonObject.put("theme_name", pn.getThemeName());
                jsonObject.put("category", pn.getCategoryid());
                jsonObject.put("theme_thumbnail", pn.getImage());
                jsonObject.put("sound_file", pn.getAnimsoundurl());
                jsonObject.put("sound_filename", pn.getAnimSoundname());
                jsonObject.put("sound_size", pn.getAnimSoundfilesize());
                jsonObject.put("game_object", pn.getGameobjectName());
                jsonObject.put("is_release", pn.isNewRealise());
                jsonArr.put(jsonObject);
                jsonObj.put("themes", jsonArr);
            }
            return jsonObj.toString();
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean SetPermission(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.System.canWrite(context)) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
                final StringBuilder sb = new StringBuilder("package:");
                sb.append(context.getPackageName());
                intent.setData(Uri.parse(sb.toString()));
                context.startActivityForResult(intent, 111);
            }
        }
        return false;
    }

    public final String getAPPFOLDER() {
        return "Wavy Music";
    }

    public final String getOutputPath() {
        final String path = Environment.getExternalStorageDirectory().toString() + File.separator + this.getAPPFOLDER() + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getCropSongPath() {
        final String path = this.getOutputPath() + "Crop Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getStoryFolderPath() {
        final String path = this.getOutputPath() + "My Story" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getMusicFolderPath() {
        final String path = this.getOutputPath() + "Online Song" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public final String getThemeFolderPath() {
        final String path = this.getOutputPath() + ".ThemeDownload" + File.separator;
        final File folder = new File(path);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return path;
    }

    public int CatThumb(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.icon_love : str.contains("festival") ? R.drawable.icon_festival : str.contains("krishna") ? R.drawable.icon_radhe_krishna : str.contains("ganesha") ? R.drawable.icon_ganesha : str.contains("balaji") ? R.drawable.icon_jay_balaji : str.contains("mahadev") ? R.drawable.icon_mahadev : str.contains("premium") ? R.drawable.icon_premium : str.contains("birthday") ? R.drawable.icon_birthday : str.contains("god") ? R.drawable.icon_gods : str.contains("shree ram") ? R.drawable.icon_shree_ram : str.contains("wedding") ? R.drawable.icon_wedding : str.contains("wish") ? R.drawable.icon_wish : str.contains("popular") ? R.drawable.icon_popular : str.contains("telugu") ? R.drawable.icon_telugu : str.contains("tamil") ? R.drawable.icon_tamil : str.contains("bhojpuri") ? R.drawable.icon_bhojpuri : str.contains("diwali") ? R.drawable.icon_diwali : str.contains("english") ? R.drawable.icon_eng : str.contains("friendship") ? R.drawable.icon_friendship : str.contains("gujarati") ? R.drawable.icon_gujarati : str.contains("hindi") ? R.drawable.icon_hindi : str.contains("kannada") ? R.drawable.icon_kannada : str.contains("malayalam") ? R.drawable.icon_malayalam : str.contains("marathi") ? R.drawable.icon_marathi : str.contains("navratri") ? R.drawable.icon_navratri : str.contains("sad") ? R.drawable.icon_sad : str.contains("day events") ? R.drawable.icon_dayevents : str.contains("patriotic") ? R.drawable.icon_patriotic : str.contains("christmas") ? R.drawable.icon_christmas : str.contains("rockstar") ? R.drawable.icon_rockstar : str.contains("islamic") ? R.drawable.icon_islamic : str.contains("bengali") ? R.drawable.icon_bengali : str.contains("punjabi") ? R.drawable.icon_punjabi : str.contains("tiktok") ? R.drawable.icon_tiktok : R.drawable.icon_new;
    }

    public int ThemeCatThumb(String str) {
        str = str.toLowerCase();
        return str.contains("love") ? R.drawable.ic_cat_love : str.contains("festival") ? R.drawable.ic_cat_festival : str.contains("krishna") ? R.drawable.ic_cat_krishna : str.contains("ganesha") ? R.drawable.ic_cat_ganesha : str.contains("balaji") ? R.drawable.ic_cat_balaji : str.contains("mahadev") ? R.drawable.ic_cat_mahadev : str.contains("premium") ? R.drawable.ic_cat_premium : str.contains("birthday") ? R.drawable.ic_cat_birthday : str.contains("god") ? R.drawable.ic_cat_god : str.contains("shree ram") ? R.drawable.ic_cat_shreeram : str.contains("wedding") ? R.drawable.ic_cat_wedding : str.contains("wish") ? R.drawable.ic_cat_wish : str.contains("popular") ? R.drawable.icon_popular : str.contains("telugu") ? R.drawable.ic_cat_telugu : str.contains("tamil") ? R.drawable.ic_cat_tamil : str.contains("bhojpuri") ? R.drawable.ic_cat_bhojpuri : str.contains("diwali") ? R.drawable.ic_cat_diwali : str.contains("english") ? R.drawable.ic_cat_english : str.contains("friendship") ? R.drawable.ic_cat_friends : str.contains("gujarati") ? R.drawable.ic_cat_gujrati : str.contains("hindi") ? R.drawable.ic_cat_hindi : str.contains("kannada") ? R.drawable.ic_cat_kannada : str.contains("malayalam") ? R.drawable.ic_cat_malayalam : str.contains("marathi") ? R.drawable.ic_cat_marathi : str.contains("navratri") ? R.drawable.ic_cat_navratri : str.contains("sad") ? R.drawable.ic_cat_sad : str.contains("day events") ? R.drawable.ic_cat_dayevents : str.contains("patriotic") ? R.drawable.ic_cat_patriotic : str.contains("christmas") ? R.drawable.ic_cat_christmas : str.contains("rockstar") ? R.drawable.ic_cat_rockstar : str.contains("islamic") ? R.drawable.ic_cat_islamic : str.contains("bengali") ? R.drawable.ic_cat_bengali : str.contains("punjabi") ? R.drawable.ic_cat_punjabi : str.contains("tiktok") ? R.drawable.ic_cat_tiktok : R.drawable.ic_cat_whatsnew;
    }


    public void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                this.deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }
}
