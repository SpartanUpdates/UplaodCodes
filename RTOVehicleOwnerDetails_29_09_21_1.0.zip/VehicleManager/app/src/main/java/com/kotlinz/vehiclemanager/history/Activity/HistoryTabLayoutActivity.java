package com.kotlinz.vehiclemanager.history.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.tabs.TabLayout;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.history.Adapter.HomeFragmentPageAdapter;
import com.kotlinz.vehiclemanager.history.Fragment.OwnerInfoFragment;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import org.jetbrains.annotations.NotNull;

public class HistoryTabLayoutActivity extends AppCompatActivity {
    private Activity activity = HistoryTabLayoutActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ImageView iv_back;
    private HomeFragmentPageAdapter homePageAdapter;
    private LinearLayout linearLayout;
    private TextView title_tv;

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_tab_layout);
        BannerAds();
        InterAds();
        iv_back = findViewById(R.id.iv_back);
        viewPager = findViewById(R.id.viewPager);
        linearLayout = findViewById(R.id.ll_tab);
        title_tv = findViewById(R.id.tv_title);
        setViewPager();
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
        CreateTab();
        DarkTheame darkTheame = new DarkTheame(HistoryTabLayoutActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(HistoryTabLayoutActivity.this, MainActivity.class));
                        finish();
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    private void setupDarkMode() {
        linearLayout.setBackgroundResource(R.drawable.ic_box_shadow_borderbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void setViewPager() {
        homePageAdapter = new HomeFragmentPageAdapter(getSupportFragmentManager());
        homePageAdapter.addFragment(new OwnerInfoFragment(), "Owner Info");
        viewPager.setAdapter(homePageAdapter);
    }

    private void CreateTab() {
        TextView OwnerInfo = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        OwnerInfo.setText("Owner Info");
        tabLayout.getTabAt(0).setCustomView(OwnerInfo);

    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(HistoryTabLayoutActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}