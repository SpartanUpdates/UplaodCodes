package com.esc.uvideostatus.Models;

public class TypeData {
    public String FolderPath;
    public String foldername;
    public int id;
    public String size;
    public int totalVideo = 0;
    int type;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public int getTotalVideo() {
        return this.totalVideo;
    }

    public void setTotalVideo(int i) {
        this.totalVideo = i;
    }

    public String getFoldername() {
        return this.foldername;
    }

    public void setFoldername(String str) {
        this.foldername = str;
    }

    public String getFolderPath() {
        return this.FolderPath;
    }

    public void setFolderPath(String str) {
        this.FolderPath = str;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("AlbumDetail{id=");
        sb.append(this.id);
        sb.append(", type=");
        sb.append(this.type);
        sb.append(", totalVideo=");
        sb.append(this.totalVideo);
        sb.append(", foldername='");
        sb.append(this.foldername);
        sb.append('\'');
        sb.append(", FolderPath='");
        sb.append(this.FolderPath);
        sb.append('\'');
        sb.append(", size='");
        sb.append(this.size);
        sb.append('\'');
        sb.append('}');
        return sb.toString();
    }
}
