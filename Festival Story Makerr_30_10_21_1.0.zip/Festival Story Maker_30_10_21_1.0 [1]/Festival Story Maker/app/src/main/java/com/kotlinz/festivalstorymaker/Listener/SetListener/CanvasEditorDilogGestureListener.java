package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

public class CanvasEditorDilogGestureListener extends GestureDetector.SimpleOnGestureListener
{
    public final  TextView textView;
    public final  FrameLayout f;
    public final  View g;
    public final CanvasEditorActivity h;

    public CanvasEditorDilogGestureListener(final CanvasEditorActivity h, final TextView e, final FrameLayout f, final View g) {
        this.h = h;
        this.textView = e;
        this.f = f;
        this.g = g;
    }

    public boolean onDoubleTap(final MotionEvent motionEvent) {
        final TextView textView = CanvasEditorActivity.z1 = this.textView;
        CanvasEditorActivity.P1 = true;
        this.h.C0(this.f, this.g, textView);
        return super.onDoubleTap(motionEvent);
    }

    public void onLongPress(final MotionEvent motionEvent) {
        final CanvasEditorActivity h = this.h;
        h.f1 = true;
        h.g1 = this.g;
        h.b0 = this.f;
        h.B0(true);
    }

    public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
        TextView textView;
        Drawable drawable;
        if ((CanvasEditorActivity.z1 = this.textView).getBackground() == null) {
            textView = this.textView;
            drawable = this.h.getResources().getDrawable(R.drawable.rounded_border_to_view);
        }
        else {
            textView = this.textView;
            drawable = null;
        }
        textView.setBackground(drawable);
        return true;
    }
}
