package com.kotlinz.puzzlecreator.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.introslider.IntroActivity;
import com.kotlinz.puzzlecreator.kprogresshud.KProgressHUD;
import com.kotlinz.puzzlecreator.login.LoginActivity;

public class SplashActivity extends BaseActivity {
    Activity activity = SplashActivity.this;
    private KProgressHUD hud;
    public InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_avtivity);
        interstitialAd();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sessionManager.isFirstTimeLaunch()) {
                    Intent intent = new Intent(SplashActivity.this, IntroActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    if (sessionManager.isLoggedIn()) {
                        if (mInterstitialAd != null) {
                            try {
                                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                                hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (mInterstitialAd != null) {
                                        mInterstitialAd.show(activity);
                                    }
                                }
                            }, 2000);
                        } else {
                            GoToNext();
                        }
                    } else {
                        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        }, 2000);

    }


    private void GoToNext() {
        Intent intent = new Intent(activity, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        GoToNext();
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }
}