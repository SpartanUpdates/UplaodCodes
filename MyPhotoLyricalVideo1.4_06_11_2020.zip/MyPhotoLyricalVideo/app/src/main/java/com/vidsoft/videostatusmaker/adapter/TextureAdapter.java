package com.vidsoft.videostatusmaker.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.io.IOException;

import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;

public class TextureAdapter extends BaseAdapter {
    LayoutInflater layoutInflater;
    private Context context;
    private String[] posterimgs;
    Shader shader;

    public TextureAdapter(final Context context, final String[] posterimgs) {
        this.layoutInflater = null;
        this.context = context;
        this.posterimgs = posterimgs;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.posterimgs.length;
    }

    public Object getItem(final int n) {
        return n;
    }

    public long getItemId(final int n) {
        return n;
    }

    public View getView(final int n, final View view, ViewGroup inflate) {
        inflate = (ViewGroup) view;
        if (view == null) {
            inflate = (ViewGroup) this.layoutInflater.inflate(R.layout.text_adapter, (ViewGroup) null);
        }
        final TextView textView = (TextView) ((View) inflate).findViewById(R.id.t);
        textView.setTypeface(Typeface.createFromAsset(this.context.getAssets(), "fonts/font25.ttf"));
        textView.setText((CharSequence) "Select Your Texture");
        try {
            final AssetManager assets = this.context.getAssets();
            final StringBuilder sb = new StringBuilder();
            sb.append("texture/");
            sb.append(this.posterimgs[n]);
            final Bitmap decodeStream = BitmapFactory.decodeStream(assets.open(sb.toString()));
            if (n == 0) {
                textView.setLayerType(0, (Paint) null);
                textView.getPaint().setShader((Shader) null);
                return (View) inflate;
            }
            this.shader = (Shader) new BitmapShader(decodeStream, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            textView.setLayerType(1, (Paint) null);
            textView.getPaint().setShader(this.shader);
            return (View) inflate;
        } catch (IOException ex) {
            ex.printStackTrace();
            return (View) inflate;
        }
    }
}
