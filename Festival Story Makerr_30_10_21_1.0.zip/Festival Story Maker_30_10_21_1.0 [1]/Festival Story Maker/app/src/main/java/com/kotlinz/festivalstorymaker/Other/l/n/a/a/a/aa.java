package com.kotlinz.festivalstorymaker.Other.l.n.a.a.a;

public class aa
{
    public static int[] a;
    public static int[] b;

    static {
        aa.a = new int[511];
        for (int i = -255; i <= 255; ++i) {
            aa.a[i + 255] = i * i;
        }
        aa.b = new int[9];
        for (int j = 0; j < 9; ++j) {
            aa.b[j] = 1 << 15 - j;
        }
    }

    public static int[] a(final int[][] array, int i) {
        final a a = new a(array, i);
        final int[][] a2 = a.a;
        i = a2.length;
        final int length = a2[0].length;
        while (true) {
            final int n = i - 1;
            if (i <= 0) {
                break;
            }
            i = length;
            while (true) {
                final int n2 = i - 1;
                if (i <= 0) {
                    break;
                }
                i = a2[n][n2];
                final int n3 = i >> 16 & 0xFF;
                final int n4 = i >> 8 & 0xFF;
                final int n5 = i >> 0 & 0xFF;
                if (a.g > 266817) {
                    System.out.println("pruning");
                    a.d.c();
                    --a.e;
                }
                aa.a.aaa d = a.d;
                int n6;
                int n7;
                int n8;
                int n9;
                for (i = 1; i <= a.e; ++i) {
                    if (n3 > d.g) {
                        n6 = 1;
                    }
                    else {
                        n6 = 0;
                    }
                    if (n4 > d.h) {
                        n7 = 1;
                    }
                    else {
                        n7 = 0;
                    }
                    if (n5 > d.i) {
                        n8 = 1;
                    }
                    else {
                        n8 = 0;
                    }
                    n9 = (n6 << 0 | n7 << 1 | n8 << 2);
                    if (d.c[n9] == null) {
                        new a.aaa(d, n9, i);
                    }
                    d = d.c[n9];
                    d.j += com.kotlinz.festivalstorymaker.Other.l.n.a.a.a.aa.b[i];
                }
                ++d.k;
                d.l += n3;
                d.m += n4;
                d.n += n5;
                i = n2;
            }
            i = n;
        }
        i = 1;
        int f;
        while (true) {
            f = a.f;
            if (f <= a.b) {
                break;
            }
            a.f = 0;
            i = a.d.d(i, Integer.MAX_VALUE);
        }
        a.c = new int[f];
        a.f = 0;
        a.d.a();
        final int[][] a3 = a.a;
        i = a3.length;
        final int length2 = a3[0].length;
        while (true) {
            final int n10 = i - 1;
            if (i <= 0) {
                break;
            }
            i = length2;
            while (true) {
                final int n11 = i - 1;
                if (i <= 0) {
                    break;
                }
                final int n12 = a3[n10][n11];
                aa.a.aaa d2 = a.d;
                while (true) {
                    if ((n12 >> 16 & 0xFF) > d2.g) {
                        i = 1;
                    }
                    else {
                        i = 0;
                    }
                    int n13;
                    if ((n12 >> 8 & 0xFF) > d2.h) {
                        n13 = 1;
                    }
                    else {
                        n13 = 0;
                    }
                    int n14;
                    if ((n12 >> 0 & 0xFF) > d2.i) {
                        n14 = 1;
                    }
                    else {
                        n14 = 0;
                    }
                    i = (i << 0 | n13 << 1 | n14 << 2);
                    final aa.a.aaa[] c = d2.c;
                    if (c[i] == null) {
                        break;
                    }
                    d2 = c[i];
                }
                a3[n10][n11] = d2.o;
                i = n11;
            }
            i = n10;
        }
        return a.c;
    }

    public static class a
    {
        public int[][] a;
        public int b;
        public int[] c;
        public aaa d;
        public int e;
        public int f;
        public int g;

        public a(final int[][] a, int i) {
            this.a = a;
            this.b = i;
            this.e = 1;
            while (i != 0) {
                i /= 4;
                ++this.e;
            }
            i = this.e;
            if (i > 1) {
                this.e = i - 1;
            }
            final int e = this.e;
            i = 8;
            Label_0089: {
                if (e <= 8) {
                    i = 2;
                    if (e >= 2) {
                        break Label_0089;
                    }
                }
                this.e = i;
            }
            this.d = new aaa(this);
        }

        public static class aaa
        {
            public aa.a a;
            public aaa b;
            public aaa[] c;
            public int d;
            public int e;
            public int f;
            public int g;
            public int h;
            public int i;
            public int j;
            public int k;
            public int l;
            public int m;
            public int n;
            public int o;

            public aaa(final aaa b, final int e, int f) {
                final aa.a a = b.a;
                this.a = a;
                this.b = b;
                this.c = new aaa[8];
                this.e = e;
                this.f = f;
                ++a.g;
                if (f == a.e) {
                    ++a.f;
                }
                ++b.d;
                b.c[e] = this;
                f = 1 << 8 - f >> 1;
                final int g = b.g;
                int n;
                if ((e & 0x1) > 0) {
                    n = f;
                }
                else {
                    n = -f;
                }
                this.g = g + n;
                final int h = b.h;
                int n2;
                if ((e & 0x2) > 0) {
                    n2 = f;
                }
                else {
                    n2 = -f;
                }
                this.h = h + n2;
                final int i = b.i;
                if ((e & 0x4) <= 0) {
                    f = -f;
                }
                this.i = i + f;
            }

            public aaa(final aa.a a) {
                this.a = a;
                this.b = this;
                this.c = new aaa[8];
                this.e = 0;
                this.f = 0;
                this.j = Integer.MAX_VALUE;
                this.g = 128;
                this.h = 128;
                this.i = 128;
            }

            public void a() {
                if (this.d != 0) {
                    for (int i = 0; i < 8; ++i) {
                        final aaa[] c = this.c;
                        if (c[i] != null) {
                            c[i].a();
                        }
                    }
                }
                final int k = this.k;
                if (k != 0) {
                    final int n = (this.l + (k >> 1)) / k;
                    final int n2 = (this.m + (k >> 1)) / k;
                    final int n3 = (this.n + (k >> 1)) / k;
                    final aa.a a = this.a;
                    final int[] c2 = a.c;
                    final int f = a.f;
                    c2[f] = ((n2 & 0xFF) << 8 | ((n & 0xFF) << 16 | 0xFF000000) | (n3 & 0xFF) << 0);
                    a.f = f + 1;
                    this.o = f;
                }
            }

            public void b() {
                final aaa b = this.b;
                --b.d;
                b.k += this.k;
                b.l += this.l;
                b.m += this.m;
                b.n += this.n;
                b.c[this.e] = null;
                final aa.a a = this.a;
                --a.g;
                this.a = null;
                this.b = null;
            }

            public void c() {
                if (this.d != 0) {
                    for (int i = 0; i < 8; ++i) {
                        final aaa[] c = this.c;
                        if (c[i] != null) {
                            c[i].c();
                        }
                    }
                }
                if (this.f == this.a.e) {
                    this.b();
                }
            }

            public int d(int n, int j) {
                int n2 = j;
                if (this.d != 0) {
                    int n3 = 0;
                    while (true) {
                        n2 = j;
                        if (n3 >= 8) {
                            break;
                        }
                        final aaa[] c = this.c;
                        int d = j;
                        if (c[n3] != null) {
                            d = c[n3].d(n, j);
                        }
                        ++n3;
                        j = d;
                    }
                }
                if (this.j <= n) {
                    this.b();
                    return n2;
                }
                if (this.k != 0) {
                    final aa.a a = this.a;
                    ++a.f;
                }
                j = this.j;
                if (j < (n = n2)) {
                    n = j;
                }
                return n;
            }

            @Override
            public String toString() {
                final StringBuffer sb = new StringBuffer();
                String s;
                if (this.b == this) {
                    s = "root";
                }
                else {
                    s = "node";
                }
                sb.append(s);
                sb.append(' ');
                sb.append(this.f);
                sb.append(" [");
                sb.append(this.g);
                sb.append(',');
                sb.append(this.h);
                sb.append(',');
                sb.append(this.i);
                sb.append(']');
                return new String(sb);
            }
        }
    }
}
