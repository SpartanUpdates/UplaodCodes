package com.wavymusic.ContentLanguage.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.ContentLanguage.Model.SongLanguageModel;
import com.wavymusic.R;
import java.util.ArrayList;

public class LanguageSelectAdapter extends RecyclerView.Adapter<LanguageSelectAdapter.VideoHolder> {

    Context context;
    private ArrayList<SongLanguageModel> languageList;

    public LanguageSelectAdapter(Context context, ArrayList<SongLanguageModel> languageList) {
        this.context = context;
        this.languageList = languageList;
    }

    @NonNull
    @Override
    public VideoHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_language_list, viewGroup, false);
        return new VideoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final VideoHolder videoHolder, int position) {
        final SongLanguageModel languageModel = languageList.get(position);
        videoHolder.tvlangName.setText(languageModel.getLanName());
        videoHolder.IvLangThumb.setImageResource(Utils.INSTANCE.CatThumb(languageList.get(position).getLanName()));
        videoHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoHolder.cblanguage.toggle();
            }
        });

        videoHolder.cblanguage.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                languageModel.IsLanguageSelected = isChecked;
            }
        });
        videoHolder.cblanguage.setChecked(languageModel.IsLanguageSelected);
    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }


    public class VideoHolder extends RecyclerView.ViewHolder {

        CheckBox cblanguage;
        ImageView IvLangThumb;
        TextView tvlangName;

        private VideoHolder(@NonNull View itemView) {
            super(itemView);
            cblanguage = itemView.findViewById(R.id.cbLanguage);
            IvLangThumb = itemView.findViewById(R.id.ivImage);
            tvlangName = itemView.findViewById(R.id.tvName);
        }
    }
}
