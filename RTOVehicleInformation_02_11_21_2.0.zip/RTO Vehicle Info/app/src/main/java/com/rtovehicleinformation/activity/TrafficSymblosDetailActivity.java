package com.rtovehicleinformation.activity;

import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.rtovehicleinformation.Adapter.TrafficDetailsAdapter;
import com.rtovehicleinformation.Adapter.TrafficDetailsAdapter1;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.application.AppController;
import com.rtovehicleinformation.utils.Const;
import com.rtovehicleinformation.utils.Pref;
import com.rtovehicleinformation.utils.Utils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TrafficSymblosDetailActivity extends AppCompatActivity {

    Activity activity = TrafficSymblosDetailActivity.this;
    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.tv_title)
    TextView tvTitle;

    @BindView(R.id.iv_back)
    ImageView ivback;

    @BindView(R.id.trafficSymbolsDetails)
    RecyclerView trafficSymbolsDetails;
    Boolean equals;
    String hindiText = "hi";
    TrafficDetailsAdapter trafficDetailsAdapter;
    TrafficDetailsAdapter1 trafficDetailsAdapter1;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traffic_symblos_detail);
        ButterKnife.bind(this);
        this.hindiText = Pref.getStringValue(this, "lan", "en");
        Const.getSet(this, this.hindiText);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.equals = this.hindiText.equals("hi");
        BannerAds();
        switch (getIntent().getExtras().getInt("POST")) {
            case 0:
                this.tvTitle.setText(this.equals.booleanValue() ? "अनिवार्य" : "Mandatory");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.mandatoryName, Utils.mandatoryImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
            case 1:
                this.tvTitle.setText(this.equals.booleanValue() ? "Traffic Light सिग्नल" : "Traffic Light Signals");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 1));
                this.trafficDetailsAdapter1 = new TrafficDetailsAdapter1(this, Utils.trafficLightSignals1, Utils.trafficLightSignals2, Utils.trafficLightSignalsImg);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter1);
                break;
            case 2:
                this.tvTitle.setText(this.equals.booleanValue() ? "चेतावनी देनेवाला" : "Cautionary");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.cautionaryName, Utils.cautionaryImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
            case 3:
                this.tvTitle.setText(this.equals.booleanValue() ? "ज्ञान बढ़ाने वाला" : "Informatory");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.informatoryName, Utils.informatoryImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
            case 4:
                this.tvTitle.setText(this.equals.booleanValue() ? "सड़क" : "Road");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.roadName, Utils.roadImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
            case 5:
                this.tvTitle.setText(this.equals.booleanValue() ? "नियम" : "Rules");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.rulesName, Utils.rulesImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
            case 6:
                this.tvTitle.setText(this.equals.booleanValue() ? "Traffic पुलिस" : "Traffic Police");
                this.trafficSymbolsDetails.setLayoutManager(new GridLayoutManager(this, 2));
                this.trafficDetailsAdapter = new TrafficDetailsAdapter(this, Utils.trafficPoliceName, Utils.trafficPoliceImage);
                this.trafficSymbolsDetails.setAdapter(this.trafficDetailsAdapter);
                break;
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.hi_en_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.action_language) {
            if (this.hindiText.equals("hi")) {
                Const.getSet(this, "en");
                Pref.setStringValue(this, "lan", "en");
            } else {
                Const.getSet(this, "hi");
                Pref.setStringValue(this, "lan", "hi");
            }
            finish();
            overridePendingTransition(0, 0);
            startActivity(getIntent());
            overridePendingTransition(0, 0);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void GoToBack() {
        finish();
    }

    public void onBackPressed() {
        if (AppController.mInterstitialAd != null) {
            AppController.activity = activity;
            AppController.AdsId = 10;
            AppController.mInterstitialAd.show(activity);

        } else {
            GoToBack();
        }
    }
}
