package com.example.knowledgetrivia.models;

import java.util.ArrayList;

public class LevelScore {
    private int level;
    private int score;

    public LevelScore(int i, int i2) {
        this.level = i;
        this.score = i2;
    }

    public static int getTotal(ArrayList<LevelScore> arrayList) {
        int i = 0;
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            i += ((LevelScore) arrayList.get(i2)).getScore();
        }
        return i;
    }

    public int getLevel() {
        return this.level;
    }

    public void setLevel(int i) {
        this.level = i;
    }

    public int getScore() {
        return this.score;
    }
}
