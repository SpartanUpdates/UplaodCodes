package com.esc.palmreadingfuture.database;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static String DB_NAME = "";
    private static String DB_PATH = "";
    private static String TAG = "DataBaseHelper";
    private static File dbFile;
    private final Context mContext;
    private SQLiteDatabase mDataBase;
    ArrayList<String> qid;

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public DataBaseHelper(Context context, String str) {
        super(context, str, null, 1);
        this.mContext = context;
        DB_NAME = str;
        String str2 = "/databases/";
        StringBuilder stringBuilder;
        if (VERSION.SDK_INT >= 17) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(context.getApplicationInfo().dataDir);
            stringBuilder.append(str2);
            DB_PATH = stringBuilder.toString();
            return;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("/data/data/");
        stringBuilder.append(context.getPackageName());
        stringBuilder.append(str2);
        DB_PATH = stringBuilder.toString();
    }

    public void createDataBase() throws IOException {
        if (this.checkDataBase()) {
            return;
        }
        try {
            this.getReadableDatabase();
            this.close();
            try {
                this.copyDataBase();
                Log.e(DataBaseHelper.TAG, "createDatabase database created");
            } catch (IOException ex) {
                ex.printStackTrace();
                throw new Error("ErrorCopyingDataBase");
            }
        } catch (Exception ex2) {

        }
    }

    private boolean checkDataBase() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        File file = new File(stringBuilder.toString());
        dbFile = file;
        file.exists();
        dbFile.delete();
        return dbFile.exists();
    }

    private void copyDataBase() throws IOException {
        InputStream open = this.mContext.getAssets().open(DB_NAME);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(stringBuilder.toString());
        byte[] bArr = new byte[1024];
        while (open.read(bArr) > 0) {
            fileOutputStream.write(bArr);
        }
        open.close();
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    public boolean openDataBase() throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        SQLiteDatabase openDatabase = SQLiteDatabase.openDatabase(stringBuilder.toString(), null, 268435456);
        this.mDataBase = openDatabase;
        return openDatabase != null;
    }

    public synchronized void close() {
        if (this.mDataBase != null) {
            this.mDataBase.close();
        }
        super.close();
    }

    public ArrayList<String> getCategory(String str) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery(str, null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public String getCategoryHead(int i, int i2) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sdesc from main where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND category =");
        stringBuilder.append(i2);
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public String getCategoryHead(int i) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sdesc from main where sid=");
        stringBuilder.append(i);
        String stringBuilder2 = stringBuilder.toString();
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder2, null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public String getImgName(int i, int i2) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select imgname from main where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND category=");
        stringBuilder.append(i2);
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public String getImgName(int i) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select imgname from main where sid=");
        stringBuilder.append(i);
        String stringBuilder2 = stringBuilder.toString();
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder2, null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public ArrayList<String> getHandTitle(int i, int i2) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("select handtitle from hands where sid=");
            stringBuilder.append(i);
            stringBuilder.append(" AND category=");
            stringBuilder.append(i2);
            Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
            while (rawQuery.moveToNext()) {
                arrayList.add(rawQuery.getString(0));
            }
            rawQuery.close();
        } catch (Exception unused) {
        }
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getHandTitle(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select handtitle from hands where sid=");
        stringBuilder.append(i);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getQuesNo(int i, int i2, int i3) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select qno from ques where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND cid=");
        stringBuilder.append(i3);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getQues(int i, int i2, int i3) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select que from ques where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND cid=");
        stringBuilder.append(i3);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getQues(int i, int i2) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select que from ques where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getQuesNo(int i, int i2) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select qno from ques where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public String getAns(int i, int i2, int i3, int i4, int i5) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select answ from ans where qid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND sid=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i4);
        stringBuilder.append(" AND optno=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND cid=");
        stringBuilder.append(i5);
        stringBuilder.append(" AND answ IS NOT NULL");
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public String getAns(int i, int i2, int i3, int i4) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select answ from ans where qid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND sid=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i4);
        stringBuilder.append(" AND optno=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND answ IS NOT NULL");
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public ArrayList<String> getOptNo(int i, int i2, int i3, int i4) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select optno from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND category=");
        stringBuilder.append(i4);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getOptTxt(int i, int i2, int i3) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select opttxt from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND opttxt IS NOT NULL");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getOptNo(int i, int i2, int i3) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select optno from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public int getOptCnt(int i, int i2, int i3) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select count(optno) from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        i3 = 0;
        while (rawQuery.moveToNext()) {
            i3 = rawQuery.getInt(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return i3;
    }

    public ArrayList<String> getSubCategory(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sname from main where category=");
        stringBuilder.append(i);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getSubCategoryId(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("select sid from main where category=");
            stringBuilder.append(i);
            Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
            while (rawQuery.moveToNext()) {
                arrayList.add(rawQuery.getString(0));
            }
            rawQuery.close();
        } catch (Exception unused) {
        }
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getCategoryId() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        try {
            Cursor rawQuery = readableDatabase.rawQuery("select DISTINCT category from main", null);
            while (rawQuery.moveToNext()) {
                arrayList.add(rawQuery.getString(0));
            }
            rawQuery.close();
        } catch (Exception unused) {
        }
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getImagename(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select imgname from main where category=");
        stringBuilder.append(i);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public ArrayList<String> getOptTxt(int i, int i2, int i3, int i4) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select opttxt from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND category=");
        stringBuilder.append(i4);
        stringBuilder.append(" AND opttxt IS NOT NULL");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }

    public String getImgAns(int i, int i2) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select imgans from hands where handid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND sid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND imgans IS NOT NULL");
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }

    public int getOptCnt(int i, int i2, int i3, int i4) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select count(optno) from opts where sid=");
        stringBuilder.append(i);
        stringBuilder.append(" AND hid=");
        stringBuilder.append(i2);
        stringBuilder.append(" AND qno=");
        stringBuilder.append(i3);
        stringBuilder.append(" AND category=");
        stringBuilder.append(i4);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        i3 = 0;
        while (rawQuery.moveToNext()) {
            i3 = rawQuery.getInt(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return i3;
    }
}
