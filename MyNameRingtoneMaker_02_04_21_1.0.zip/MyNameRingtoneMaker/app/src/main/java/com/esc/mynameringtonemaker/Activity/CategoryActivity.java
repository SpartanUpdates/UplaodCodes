package com.esc.mynameringtonemaker.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.esc.mynameringtonemaker.Model.Category;
import com.esc.mynameringtonemaker.R;
import com.esc.mynameringtonemaker.fragment.CategoryFragment;
import com.esc.mynameringtonemaker.kprogresshud.KProgressHUD;
import com.esc.mynameringtonemaker.myApp.MyApplication;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class CategoryActivity extends AppCompatActivity {
    private Activity activity = CategoryActivity.this;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ArrayList<Category> categorylist;
    private TextView txt_categorytitle;
    private ProgressDialog dialog;
    private ImageView iv_back;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int Adid;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_cetegory);
        categorylist = new ArrayList<>();
        viewPager = findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tablayout);
        txt_categorytitle = findViewById(R.id.txt_categorytitle);
        iv_back = findViewById(R.id.iv_back);
        makeJsonRequest(getResources().getString(R.string.ringtone_url));
        dialog = new ProgressDialog(this);
        dialog.setMessage("Plz Waite...");
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.setCancelable(false);
        dialog.show();
        loadAd();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitial != null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                Adid = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    startActivity(new Intent(CategoryActivity.this, HomeActivity.class));
                    finish();
                }
            }
        });
    }
    private void SetViewPager()
    {
        CategoryFragmentPagerAdapter pagerAdapter = new CategoryFragmentPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);

        // Iterate over all tabs and set the custom view
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(pagerAdapter.getTabView(i));
        }

        // customView = tab.getCustomView();
        TextView textView = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.txt_category);
        textView.setTextColor(getResources().getColor(R.color.text_color));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                TextView textView = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.txt_category);
                textView.setTextColor(getResources().getColor(R.color.text_color));
                txt_categorytitle.setText(categorylist.get(tab.getPosition()).getName());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                TextView textView = customView.findViewById(R.id.txt_category);
                textView.setTextColor(getResources().getColor(R.color.tabunselectext_color));
                txt_categorytitle.setText(categorylist.get(tab.getPosition()).getName());
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    TextView textView = customView.findViewById(R.id.txt_category);
                    txt_categorytitle.setText(categorylist.get(tab.getPosition()).getName());
                }
            }
        });
    }

    private class CategoryFragmentPagerAdapter extends FragmentPagerAdapter {

        public CategoryFragmentPagerAdapter(@NonNull FragmentManager fm)
        {
            super(fm);
        }

        public View getTabView(int position) {
            // Given you have a custom layout in `res/layout/custom_tab.xml` with a TextView and ImageView
            View v = LayoutInflater.from(activity).inflate(R.layout.item_categorytab, null);
            TextView tv = v.findViewById(R.id.txt_category);
            tv.setText(categorylist.get(position).getName());
            return v;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {

            return CategoryFragment.newInstance(categorylist.get(position).getId(), categorylist.get(position).getLink());
        }

        @Override
        public int getCount() {
            return categorylist.size();
        }
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            dialog.dismiss();
                            JSONArray jsonArray = response.getJSONArray("Category");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);

                                Category app_data = new Gson().fromJson(jsonArray.get(i).toString(), Category.class);
                                if (!app_data.getName().equalsIgnoreCase(getString(R.string.app_name))) {
                                    categorylist.add(app_data);
                                }
                            }
                            SetViewPager();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

    private void loadAd() {

        //InterstitialAd
        interstitial = new InterstitialAd(CategoryActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        startActivity(new Intent(CategoryActivity.this, HomeActivity.class));
                        finish();
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(CategoryActivity.this,HomeActivity.class));
        finish();
    }
}
