import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:rto_app/Rto%20Office%20Screen/model/fuel_model.dart';
import 'package:rto_app/Rto%20Office%20Screen/view/rto_office.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

class RtoOfficeController extends GetxController {
  List<StateList> fuelDataList = [];
  List<StateList> searchList = [];
  ItemScrollController scrollController = ItemScrollController();
  var scrollIndex = 0;
  bool expand = false;

  Future<void> changeSateList(int index) async {
    scrollController.jumpTo(index: index);
    scrollIndex = index;
    update();
  }

  Future<void> disableExpand() async {
    expand = true;
    update();
  }

  Future<void> fetchStateAndCityData() async {
    var response =
        await rootBundle.loadString('assets/data/rtoofficeinfo.json');
    final fuelData = jsonDecode(response);
    var list = List.from(fuelData)
        .map<StateList>((data) => StateList.fromJson(data))
        .toList();
    fuelDataList.assignAll(list);
    StateListDisplay.isDataAvailable = true;
    update();
  }

  Future<void> searchData(city) async {
    List<StateList> newList = [];
    fuelDataList.forEach((element) {
      element.rto_list.forEach((element2) {
        if (element2['district']!.toLowerCase().contains(city.toLowerCase())) {
          newList.add(element);
        }
      });
    });
    searchList = newList.toSet().toList();
    update();
  }

  Future<void> popularCity(city) async {
    List<StateList> newList = [];
    fuelDataList.forEach((element) {
      element.rto_list.forEach((element2) {
        if (element2['district']!.toLowerCase().contains(city.toLowerCase())) {}
      });
    });
    searchList = newList.toSet().toList();
  }
}
