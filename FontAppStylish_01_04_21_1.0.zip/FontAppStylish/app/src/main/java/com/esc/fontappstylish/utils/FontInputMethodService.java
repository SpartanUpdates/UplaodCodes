package com.esc.fontappstylish.utils;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.drawable.BitmapDrawable;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener;
import android.media.AudioManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.util.Pair;
import com.esc.fontappstylish.FontColl.Sadu;
import com.esc.fontappstylish.activity.FirstActivity;
import com.esc.fontappstylish.activity.Utils;
import com.esc.fontappstylish.R;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class FontInputMethodService extends InputMethodService implements OnKeyboardActionListener {
    public static int val;
    FontKeyboard2 aksharoNuMalkhu;
    public FontKeyboard aksharonuKeyboard;
    private Keyboard arabKeyboard;
    int backcheck = 0;
    private boolean bool = false;
    Button button6;
    private boolean capsLockOn;
    private Button changeKeyboardNotificationButton;
    public RelativeLayout changeKeyboardOverlay;
    public RelativeLayout container;
    private Keyboard currentKeyboard;
    public ArrayList<Pair<FontInter, Button>> fontButtons = new ArrayList();
    private Keyboard gujaratiKeyboard;
    private Keyboard hindiKeyboard;
    private HorizontalScrollView horizontalScrollView;
    private InputMethodManager inputMethodManager;
    ImageView iv_back;
    public FontKeyboard2 keyboardView;
    String language;
    private long lastShiftTime;
    LinearLayout linearLayout;
    private AudioManager mAudioManager;
    public FontKeyboard normalfontsKeyboard;
    private Button rateNowButton;
    private ConstraintLayout rateOverlay;
    private Button remindMeLaterButton;
    RelativeLayout rl_emoji;
    LinearLayout rl_first;
    RelativeLayout rl_font;
    RelativeLayout rl_second;
    RelativeLayout rl_share;
    RelativeLayout rl_update;
    private Button shareButton;
    public SharedPreferenceclass sharedPreferenceAapnar;
    private Keyboard symbolsKeyboard;
    private Keyboard symbolsShiftedKeyboard;
    private String wordSeparators;

    public void onRelease(int i) {
    }

    public void swipeDown() {
    }

    public void swipeLeft() {
    }

    public void swipeRight() {
    }

    public void swipeUp() {
    }

    public void onPress(int i) {
        if (Utils.isSoundOn) {
            playKeyClick(i);
        }
    }

    private void playKeyClick(int i) {
        if (Utils.isSoundOn && ((double) Utils.mFxVolume) != 0.0d) {
            this.mAudioManager.playSoundEffect(6, Utils.mFxVolume);
        }
    }

    public void onCreate() {
        FontService.INSTANCE.setContext(this);
        this.wordSeparators = getResources().getString(R.string.word_separators);
        this.sharedPreferenceAapnar = new SharedPreferenceclass(this);
        Object systemService = getSystemService(INPUT_METHOD_SERVICE);
        if (systemService != null) {
            this.inputMethodManager = (InputMethodManager) systemService;
            super.onCreate();
            return;
        }
    }

    public static final RelativeLayout access$getChangeKeyboardOverlay$p(FontInputMethodService fontInputMethodService) {
        RelativeLayout relativeLayout = fontInputMethodService.changeKeyboardOverlay;
        if (relativeLayout != null) {
            return relativeLayout;
        }
        throw new ExceptionInInitializerError("changeKeyboardOverlay");
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    public final void showChangeKeyboardNotificationOverlayView() {
        RelativeLayout relativeLayout = this.container;
        if (relativeLayout != null) {
            if (relativeLayout != null) {
                relativeLayout = (RelativeLayout) relativeLayout.findViewById(R.id.keyboard_switch_notification_overlay);
                this.changeKeyboardOverlay = relativeLayout;
                String str = "changeKeyboardOverlay";
                if (relativeLayout != null) {
                    relativeLayout.setVisibility(View.VISIBLE);
                    this.changeKeyboardOverlay.setOnClickListener(new OnClickListener() {
                        public void onClick(View view) {
                            view.setVisibility(View.INVISIBLE);
                        }
                    });
                    Button button = (Button) this.changeKeyboardOverlay.findViewById(R.id.keyboard_switch_notification_button);
                    this.changeKeyboardNotificationButton = button;
                    if (button != null) {
                        button.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                FontInputMethodService.access$getChangeKeyboardOverlay$p(FontInputMethodService.this).setVisibility(View.INVISIBLE);
                            }
                        });
                        return;
                    }
                    throw new ExceptionInInitializerError(str);
                }
                throw new ExceptionInInitializerError(str);
            }
            throw null;
        }
    }

    public final void showChangeKeyboardOverlayView() {
        RelativeLayout relativeLayout = this.container;
        if (relativeLayout != null) {
            if (relativeLayout != null) {
                relativeLayout = (RelativeLayout) relativeLayout.findViewById(R.id.keyboard_switch_overlay);
                this.changeKeyboardOverlay = relativeLayout;
                String str = "changeKeyboardOverlay";
                if (relativeLayout != null) {
                    relativeLayout.setVisibility(View.VISIBLE);
                    relativeLayout = this.changeKeyboardOverlay;
                    if (relativeLayout != null) {
                        relativeLayout.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                view.setVisibility(View.INVISIBLE);
                            }
                        });
                        return;
                    }
                    throw new ExceptionInInitializerError(str);
                }
                throw new ExceptionInInitializerError(str);
            }
            throw null;
        }
    }

    public final Button getRateNowButton() {
        return this.rateNowButton;
    }

    public final void setRateNowButton(Button button) {
        this.rateNowButton = button;
    }

    public final Button getRemindMeLaterButton() {
        return this.remindMeLaterButton;
    }

    public final void setRemindMeLaterButton(Button button) {
        this.remindMeLaterButton = button;
    }

    private final void initalizeKeyboard() {
        View inflate = getLayoutInflater().inflate(R.layout.style_container, null);
        if (inflate != null) {
            RelativeLayout relativeLayout = (RelativeLayout) inflate;
            this.container = relativeLayout;
            this.keyboardView = (FontKeyboard2) relativeLayout.findViewById(R.id.keyboard_view);
            String str = "imagePreferance";
            String image = this.sharedPreferenceAapnar.getImage(str, null);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("initalizeKeyboard: ");
            stringBuilder.append(image);
            if (image != null) {
                this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
            }
            this.sharedPreferenceAapnar.getLanguagepos().intValue();
            int i = 1;
            try {
                Spinner.class.getDeclaredField("mPopup").setAccessible(true);
            } catch (ClassCastException | NoClassDefFoundError | NoSuchFieldException unused) {
            }
            if (relativeLayout != null) {
                String image2 = this.sharedPreferenceAapnar.getImage(str, null);
                if (image2 != null) {
                    this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image2)));
                }
                this.iv_back = (ImageView) relativeLayout.findViewById(R.id.iv_back);
                this.rl_second = (RelativeLayout) relativeLayout.findViewById(R.id.rl_second);
                this.rl_first = (LinearLayout) relativeLayout.findViewById(R.id.rl_first);
                this.rl_font = (RelativeLayout) relativeLayout.findViewById(R.id.rl_font);
                this.rl_share = (RelativeLayout) relativeLayout.findViewById(R.id.rl_share);
                this.rl_update = (RelativeLayout) relativeLayout.findViewById(R.id.rl_update);
                this.rl_emoji = (RelativeLayout) relativeLayout.findViewById(R.id.rl_emoji);
                FontKeyboard2 fontKeyboard2 = this.keyboardView;
                this.aksharoNuMalkhu = fontKeyboard2;
                if (fontKeyboard2 != null) {
                    fontKeyboard2.setOnKeyboardActionListener(this);
                }
                this.rl_share.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        InputConnection currentInputConnection = FontInputMethodService.this.getCurrentInputConnection();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Best Font App for android  https://play.google.com/store/apps/details?id=");
                        stringBuilder.append(FontInputMethodService.this.getPackageName());
                        currentInputConnection.commitText(stringBuilder.toString(), 1);
                    }
                });
                this.rl_update.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        Intent intent = new Intent(FontInputMethodService.this.getApplicationContext(), FirstActivity.class);
                        intent.addFlags(268435456);
                        FontInputMethodService.this.startActivity(intent);
                    }
                });
                fontKeyboard2 = this.keyboardView;
                if (fontKeyboard2 != null) {
                    fontKeyboard2.setPreviewEnabled(false);
                }
                this.iv_back.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        if (FontInputMethodService.this.rl_second.getVisibility() == 0) {
                            FontInputMethodService.this.rl_second.setVisibility(View.GONE);
                            FontInputMethodService.this.rl_first.setVisibility(View.VISIBLE);
                            String str = "eng";
                            String str2 = "imagePreferance";
                            FontInputMethodService fontInputMethodService;
                            if (FontInputMethodService.this.backcheck == 1) {
                                FontInputMethodService fontInputMethodService2 = FontInputMethodService.this;
                                fontInputMethodService2.backcheck = 0;
                                int currentFontIndex = fontInputMethodService2.sharedPreferenceAapnar.getCurrentFontIndex();
                                if (currentFontIndex > 25) {
                                    FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(currentFontIndex);
                                } else {
                                    FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(1);
                                }
                                FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(FontInputMethodService.this.sharedPreferenceAapnar.getCurrentEmojiArray());
                                FontInputMethodService fontInputMethodService3 = FontInputMethodService.this;
                                fontInputMethodService3.setCurrentKeyboard(fontInputMethodService3.normalfontsKeyboard);
                                String image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                if (image != null) {
                                    FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                }
                                image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                if (image != null) {
                                    FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                }
                                if (FontService.INSTANCE.getInitialFont() instanceof Sadu) {
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals(str)) {
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                } else {
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                }
                            } else {
                                if (FontInputMethodService.this.sharedPreferenceAapnar.getCurrentFontIndex() < 25) {
                                    FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(FontInputMethodService.this.sharedPreferenceAapnar.getCurrentEmojiArray());
                                } else {
                                    FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(1);
                                }
                                if (FontService.INSTANCE.getInitialFont() instanceof Sadu) {
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals(str)) {
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                } else {
                                    fontInputMethodService = FontInputMethodService.this;
                                    fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                    str = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str2, null);
                                    if (str != null) {
                                        FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(str)));
                                    }
                                }
                            }
                            FontInputMethodService.this.selectFont(FontService.INSTANCE.getInitialFont(), true);
                        }
                    }
                });
                this.rl_font.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        FontInputMethodService.this.rl_first.setVisibility(View.GONE);
                        FontInputMethodService.this.rl_second.setVisibility(View.VISIBLE);
                        FontInputMethodService.this.fontButtons.clear();
                        FontInputMethodService.this.fontButtons.removeAll(FontInputMethodService.this.fontButtons);
                        FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(FontInputMethodService.this.sharedPreferenceAapnar.getCurrentEmojiArray());
                        view = FontInputMethodService.this.container.findViewById(R.id.fonts_tabs_linear_layout);
                        FontInputMethodService fontInputMethodService = FontInputMethodService.this;
                        fontInputMethodService.linearLayout = (LinearLayout) view;
                        fontInputMethodService.linearLayout.removeAllViews();
                        for (final FontInter fontInter : FontService.INSTANCE.getFontOrderEmoji()) {
                            View inflate = LayoutInflater.from(FontInputMethodService.this.getApplicationContext()).inflate(R.layout.style_lay_button, null);
                            ImageView imageView = (ImageView) inflate.findViewById(R.id.ispro);
                            FontInputMethodService.this.button6 = (Button) inflate.findViewById(R.id.btn_font);
                            FontInputMethodService.this.button6.setAllCaps(false);
                            int applyDimension = (int) TypedValue.applyDimension(1, 10.0f, FontInputMethodService.this.getResources().getDisplayMetrics());
                            FontInputMethodService.this.button6.setPadding(applyDimension, 0, applyDimension, (int) (((float) applyDimension) * fontInter.getExtraPaddingDownFactor()));
                            FontInputMethodService.this.button6.setTextSize(2, fontInter.getSizeFactorButton() * 16.0f);
                            String name = fontInter.getName();
                            String str = "🄰🄱🄲";
                            if (name.equals(str)) {
                                FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                            } else if (name.equals("😉😴🤣")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("😥😮🤐")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("😀😁😂")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("♕␈𐂃")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("♡⌫☏")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("☼᯽✫")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("🏧🚮🚰")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("1️⃣2️⃣3️⃣")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("👶🏻👮🏻‍♀👦🏻")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("🔇🔔🎵")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("🍇🍈🍉")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("🍔🍟🍕")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals("💪🏻👈🏻☝")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else if (name.equals(str)) {
                                FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                            } else {
                                str = "ABC";
                                if (name.equals(str)) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals(str)) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("ɐqɔ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("ᗩᗷᑕ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("ⒶⒷⒸ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("🅐🅑🅒")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("🅰🅱🅲")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("ᏗᏰፈ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("卂乃匚")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else if (name.equals("ǟɮƈ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                } else {
                                    str = "ค๖¢";
                                    if (name.equals(str)) {
                                        FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                    } else {
                                        String str2 = "₳฿₵";
                                        if (name.equals(str2)) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("【A】【B】【C】")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("『A』『B』『C』")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals(str2)) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("A♥B♥C♥")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("A̶B̶C̶")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("A̶̷̲̅B̶̷̲̅C̶̷̲̅")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("A҉B҉C҉")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("Ⱥβ↻")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("ꋫꃃꏸ")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("ΛϦㄈ")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals(str)) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        }
                                    }
                                }
                            }
                            FontInputMethodService.this.button6.setText(fontInter.getName());
                            FontInputMethodService.this.button6.setOnClickListener(new OnClickListener() {
                                public void onClick(View view) {
                                    view.setSelected(true);
                                    String str = "imagePreferance";
                                    FontInputMethodService fontInputMethodService;
                                    String image;
                                    if (fontInter instanceof Sadu) {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    } else {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    }
                                    FontInputMethodService.this.selectFont(fontInter, true);
                                    if (FontInputMethodService.this.keyboardView != null) {
                                        FontInputMethodService.this.keyboardView.invalidateAllKeys();
                                    }
                                    new SharedPreferenceclass(FontInputMethodService.this.getApplicationContext()).setCurrentEmojiArray(FontService.indexOf(FontService.INSTANCE.getFontOrderEmoji(), fontInter));
                                }
                            });
                            FontInputMethodService.this.fontButtons.add(new Pair(fontInter, FontInputMethodService.this.button6));
                            FontInputMethodService.this.linearLayout.addView(inflate);
                        }
                        String str3 = "imagePreferance";
                        FontInputMethodService fontInputMethodService2;
                        String image;
                        if (FontService.INSTANCE.getInitialFont() instanceof Sadu) {
                            fontInputMethodService2 = FontInputMethodService.this;
                            fontInputMethodService2.setCurrentKeyboard(fontInputMethodService2.aksharonuKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str3, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                            fontInputMethodService2 = FontInputMethodService.this;
                            fontInputMethodService2.setCurrentKeyboard(fontInputMethodService2.normalfontsKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str3, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        } else {
                            fontInputMethodService2 = FontInputMethodService.this;
                            fontInputMethodService2.setCurrentKeyboard(fontInputMethodService2.normalfontsKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str3, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        }
                        FontInputMethodService.this.selectFont(FontService.INSTANCE.getInitialFont(), false);
                    }
                });
                this.rl_emoji.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        FontInputMethodService fontInputMethodService = FontInputMethodService.this;
                        fontInputMethodService.backcheck = 1;
                        fontInputMethodService.rl_first.setVisibility(View.GONE);
                        FontInputMethodService.this.rl_second.setVisibility(View.VISIBLE);
                        FontInputMethodService.this.fontButtons.clear();
                        FontInputMethodService.this.fontButtons.removeAll(FontInputMethodService.this.fontButtons);
                        fontInputMethodService = FontInputMethodService.this;
                        fontInputMethodService.normalfontsKeyboard = new FontKeyboard(fontInputMethodService.getApplicationContext(), R.layout.style_keyboard_layout);
                        fontInputMethodService = FontInputMethodService.this;
                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                        String str = "imagePreferance";
                        String image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                        if (image != null) {
                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                        }
                        view = FontInputMethodService.this.container.findViewById(R.id.fonts_tabs_linear_layout);
                        FontInputMethodService fontInputMethodService2 = FontInputMethodService.this;
                        fontInputMethodService2.linearLayout = (LinearLayout) view;
                        fontInputMethodService2.linearLayout.removeAllViews();
                        FontInputMethodService.this.sharedPreferenceAapnar.setCurrentFontIndex(25);
                        for (final FontInter fontInter : FontService.INSTANCE.getFontOrderEmoji()) {
                            View inflate = LayoutInflater.from(FontInputMethodService.this.getApplicationContext()).inflate(R.layout.style_lay_button, null);
                            ImageView imageView = (ImageView) inflate.findViewById(R.id.ispro);
                            FontInputMethodService.this.button6 = (Button) inflate.findViewById(R.id.btn_font);
                            FontInputMethodService.this.button6.setAllCaps(false);
                            int applyDimension = (int) TypedValue.applyDimension(1, 10.0f, FontInputMethodService.this.getResources().getDisplayMetrics());
                            FontInputMethodService.this.button6.setPadding(applyDimension, 0, applyDimension, (int) (((float) applyDimension) * fontInter.getExtraPaddingDownFactor()));
                            FontInputMethodService.this.button6.setTextSize(2, fontInter.getSizeFactorButton() * 16.0f);
                            String name = fontInter.getName();
                            if (name.equals("🄰🄱🄲")) {
                                FontInputMethodService.this.button6.setVisibility(View.GONE);
                            } else {
                                String str2 = "ABC";
                                if (name.equals(str2)) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ꍏꌃꏳ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals(str2)) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ɐqɔ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ᗩᗷᑕ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ⒶⒷⒸ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("🅐🅑🅒")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("🅰🅱🅲")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ᏗᏰፈ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("卂乃匚")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else if (name.equals("ǟɮƈ")) {
                                    FontInputMethodService.this.button6.setVisibility(View.GONE);
                                } else {
                                    str2 = "ค๖¢";
                                    if (name.equals(str2)) {
                                        FontInputMethodService.this.button6.setVisibility(View.GONE);
                                    } else {
                                        String str3 = "₳฿₵";
                                        if (name.equals(str3)) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("【A】【B】【C】")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("『A』『B』『C』")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals(str3)) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("A♥B♥C♥")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("A̶B̶C̶")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("A̶̷̲̅B̶̷̲̅C̶̷̲̅")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("A҉B҉C҉")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("Ⱥβ↻")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("ꋫꃃꏸ")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("ΛϦㄈ")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals(str2)) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("😉😴🤣")) {
                                            FontInputMethodService.this.button6.setVisibility(View.GONE);
                                        } else if (name.equals("😥😮🤐")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("😀😁😂")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("♕␈𐂃")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("♡⌫☏")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("☼᯽✫")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("🏧🚮🚰")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("1️⃣2️⃣3️⃣")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("👶🏻👮🏻‍♀👦🏻")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("🔇🔔🎵")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("🍇🍈🍉")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("🍔🍟🍕")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("💪🏻👈🏻☝")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        } else if (name.equals("Default")) {
                                            FontInputMethodService.this.button6.setVisibility(View.VISIBLE);
                                        }
                                    }
                                }
                            }
                            FontInputMethodService.this.button6.setText(fontInter.getName());
                            FontInputMethodService.this.button6.setOnClickListener(new OnClickListener() {
                                public void onClick(View view) {
                                    view.setSelected(true);
                                    String str = "imagePreferance";
                                    FontInputMethodService fontInputMethodService;
                                    String image;
                                    if (fontInter instanceof Sadu) {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    } else {
                                        fontInputMethodService = FontInputMethodService.this;
                                        fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                        image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                        if (image != null) {
                                            FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                        }
                                    }
                                    fontInter.toString();
                                    FontInputMethodService.this.selectFont(fontInter, true);
                                    if (FontInputMethodService.this.keyboardView != null) {
                                        FontInputMethodService.this.keyboardView.invalidateAllKeys();
                                    }
                                }
                            });
                            FontInputMethodService.this.fontButtons.add(new Pair(fontInter, FontInputMethodService.this.button6));
                            FontInputMethodService.this.linearLayout.addView(inflate);
                        }
                        if (FontService.INSTANCE.getInitialFont() instanceof Sadu) {
                            fontInputMethodService = FontInputMethodService.this;
                            fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                            fontInputMethodService = FontInputMethodService.this;
                            fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        } else {
                            fontInputMethodService = FontInputMethodService.this;
                            fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                            image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                            if (image != null) {
                                FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                            }
                        }
                        FontInputMethodService.this.selectFont(FontService.INSTANCE.getInitialFont(), false);
                    }
                });
                relativeLayout = this.container;
                if (relativeLayout != null) {
                    inflate = relativeLayout.findViewById(R.id.fonts_tabs_linear_layout);
                    if (inflate != null) {
                        LinearLayout linearLayout = (LinearLayout) inflate;
                        RelativeLayout relativeLayout2 = this.container;
                        if (relativeLayout2 != null) {
                            this.horizontalScrollView = (HorizontalScrollView) relativeLayout2.findViewById(R.id.horizontal_scroll_view);
                            Button button = new Button(getApplicationContext());
                            this.shareButton = button;
                            if (button != null) {
                                button.setAllCaps(false);
                                button = this.shareButton;
                                if (button != null) {
//                                    if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                                        button.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.btnclr)));
//                                    }
                                    button = this.shareButton;
                                    if (button != null) {
                                        button.setLayoutParams(new LayoutParams(-1, -1));
                                        button = this.shareButton;
                                        if (button != null) {
                                            button.setTextSize(2, 16.0f);
                                            setShareButtonBehavior();
                                            button = this.shareButton;
                                            if (button != null) {
                                                linearLayout.addView(button);
                                                new Button(getApplicationContext()).getTextSize();
                                                FontInter[] fontOrderEmoji = FontService.INSTANCE.getFontOrderEmoji();
                                                int length = fontOrderEmoji.length;
                                                int i2 = 0;
                                                while (i2 < length) {
                                                    final FontInter fontInter = fontOrderEmoji[i2];
                                                    View inflate2 = LayoutInflater.from(getApplicationContext()).inflate(R.layout.style_lay_button, null);
                                                    ImageView imageView = (ImageView) inflate2.findViewById(R.id.ispro);
                                                    Button button2 = (Button) inflate2.findViewById(R.id.btn_font);
                                                    this.button6 = button2;
                                                    button2.setAllCaps(false);
                                                    int applyDimension = (int) TypedValue.applyDimension(i, 10.0f, getResources().getDisplayMetrics());
                                                    this.button6.setPadding(applyDimension, 0, applyDimension, (int) (((float) applyDimension) * fontInter.getExtraPaddingDownFactor()));
                                                    this.button6.setTextSize(2, fontInter.getSizeFactorButton() * 16.0f);
                                                    fontInter.getName();
                                                    this.button6.setText(fontInter.getName());
                                                    this.button6.setOnClickListener(new OnClickListener() {
                                                        public void onClick(View view) {
                                                            view.setSelected(true);
                                                            String str = "imagePreferance";
                                                            FontInputMethodService fontInputMethodService;
                                                            String image;
                                                            if (fontInter instanceof Sadu) {
                                                                fontInputMethodService = FontInputMethodService.this;
                                                                fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                                                image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                                                if (image != null) {
                                                                    FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                                                }
                                                            } else if (FontInputMethodService.this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                                                                fontInputMethodService = FontInputMethodService.this;
                                                                fontInputMethodService.setCurrentKeyboard(fontInputMethodService.aksharonuKeyboard);
                                                                image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                                                if (image != null) {
                                                                    FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                                                }
                                                            } else {
                                                                fontInputMethodService = FontInputMethodService.this;
                                                                fontInputMethodService.setCurrentKeyboard(fontInputMethodService.normalfontsKeyboard);
                                                                image = FontInputMethodService.this.sharedPreferenceAapnar.getImage(str, null);
                                                                if (image != null) {
                                                                    FontInputMethodService.this.keyboardView.setBackground(new BitmapDrawable(FontInputMethodService.this.getResources(), Const.decodeBase64(image)));
                                                                }
                                                            }
                                                            FontInputMethodService.this.selectFont(fontInter, true);
                                                            if (FontInputMethodService.this.keyboardView != null) {
                                                                FontInputMethodService.this.keyboardView.invalidateAllKeys();
                                                            }
                                                        }
                                                    });
                                                    this.fontButtons.add(new Pair(fontInter, this.button6));
                                                    linearLayout.addView(inflate2);
                                                    i2++;
                                                    i = 1;
                                                }
                                                String image3;
                                                if (FontService.INSTANCE.getInitialFont() instanceof Sadu) {
                                                    setCurrentKeyboard(this.aksharonuKeyboard);
                                                    image3 = this.sharedPreferenceAapnar.getImage(str, null);
                                                    if (image3 != null) {
                                                        this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image3)));
                                                    }
                                                } else if (this.sharedPreferenceAapnar.getLanguage().equals("eng")) {
                                                    setCurrentKeyboard(this.aksharonuKeyboard);
                                                    image3 = this.sharedPreferenceAapnar.getImage(str, null);
                                                    if (image2 != null) {
                                                        this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image3)));
                                                    }
                                                } else {
                                                    setCurrentKeyboard(this.normalfontsKeyboard);
                                                    image3 = this.sharedPreferenceAapnar.getImage(str, null);
                                                    if (image3 != null) {
                                                        this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image3)));
                                                    }
                                                }
                                                selectFont(FontService.INSTANCE.getInitialFont(), false);
                                                return;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void onInitializeInterface() {
        super.onInitializeInterface();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onInitializeInterface ");
        stringBuilder.append(this.sharedPreferenceAapnar.getLanguage());
        this.symbolsKeyboard = new Keyboard(this, R.layout.style_symbols);
        this.gujaratiKeyboard = new Keyboard(this, R.layout.style_gujrati_symbols);
        this.arabKeyboard = new Keyboard(this, R.layout.style_arabic_symbols);
        this.hindiKeyboard = new Keyboard(this, R.layout.style_hindi_symbols);
        this.symbolsShiftedKeyboard = new Keyboard(this, R.layout.style_symbols_shift);
    }

    public View onCreateInputView() {
        this.mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        Utils.setStaticVariables(this);
        this.language = this.sharedPreferenceAapnar.getLanguage();
        int intValue = this.sharedPreferenceAapnar.getLanguagepos().intValue();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onCreateInputView: ");
        stringBuilder.append(intValue);
        String str = this.language;
        if (str.hashCode() == 98468) {
            str.equals("chi");
        }
        if (intValue == 0) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 1) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_jap_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 2) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_russian_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 3) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_thai_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 4) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_chinese_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 5) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_gujarati_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 6) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_arb_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 7) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_urdu_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        } else if (intValue == 8) {
            this.aksharonuKeyboard = new FontKeyboard(this, R.layout.style_keyboard_hindi_layout);
            this.normalfontsKeyboard = new FontKeyboard(this, R.layout.style_keyboard_layout);
        }
        initalizeKeyboard();
        RelativeLayout relativeLayout = this.container;
        if (relativeLayout != null) {
            return relativeLayout;
        }
        throw null;
    }

    private final void setShareButtonBehavior() {
        if (this.shareButton != null) {
            Button button;
            if (getCurrentInputEditorInfo().packageName.equals("com.instagram.android")) {
                button = this.shareButton;
                if (button != null) {
                    button.setText("@fonts");
                }
                button = this.shareButton;
                if (button != null) {
                    button.setOnClickListener(new OnClickListener() {
                        public void onClick(View view) {
                            FontInputMethodService.this.getCurrentInputConnection().commitText("@fonts", 1);
                        }
                    });
                }
                return;
            }
            button = this.shareButton;
            if (button != null) {
                button.setText("Share App");
                button.setVisibility(View.GONE);
            }
            button = this.shareButton;
            if (button != null) {
                button.setTextColor(getResources().getColor(R.color.colorKeyText));
            }
            button = this.shareButton;
            if (button != null) {
                button.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        InputConnection currentInputConnection = FontInputMethodService.this.getCurrentInputConnection();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Share");
                        stringBuilder.append(FontInputMethodService.this.getPackageName());
                        currentInputConnection.commitText(stringBuilder.toString(), 1);
                    }
                });
            }
        }
    }

    public final void selectFont(FontInter fontInter, boolean z) {
        Iterator it = this.fontButtons.iterator();
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            if (pair.first.equals(fontInter)) {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ((Button) pair.second).setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.color_toolbar)));
                }
                ((Button) pair.second).setTextColor(getResources().getColor(R.color.color_text));
                HorizontalScrollView horizontalScrollView = this.horizontalScrollView;
                if (horizontalScrollView == null) {
                    throw new ExceptionInInitializerError("horizontalScrollView");
                } else if (horizontalScrollView.getScrollX() <= ((Button) pair.second).getLeft() && this.horizontalScrollView.getScrollX() + this.horizontalScrollView.getWidth() < ((Button) pair.second).getRight()) {
                    if (z) {
                        ((Button) pair.second).getRight();
                    } else {
                        ((Button) pair.second).getRight();
                    }
                }
            } else {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ((Button) pair.second).setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.color_toolbar)));
                }
                ((Button) pair.second).setTextColor(getResources().getColor(R.color.color_text));
            }
        }
        FontService.INSTANCE.setCurrentFont(fontInter);
    }

    public void onStartInputView(EditorInfo editorInfo, boolean z) {
        super.onStartInputView(editorInfo, z);
        setInputView(onCreateInputView());
    }

    public void onStartInput(EditorInfo editorInfo, boolean z) {
        super.onStartInput(editorInfo, z);
        long currentTimeMillis = System.currentTimeMillis();
        SharedPreferenceclass sharedPreferenceclass = this.sharedPreferenceAapnar;
        if (sharedPreferenceclass != null) {
            if (currentTimeMillis - sharedPreferenceclass.getLastUsedDate().getTime() > 7000 && this.container != null) {
                this.sharedPreferenceAapnar.setLastUsedDate(new Date(System.currentTimeMillis()));
                SharedPreferenceclass sharedPreferenceclass2 = this.sharedPreferenceAapnar;
                sharedPreferenceclass2.setUsedKeyboardCount(sharedPreferenceclass2.getUsedKeyboardCount() + 1);
            }
            if (this.sharedPreferenceAapnar.getisKeyboardChanged()) {
                this.sharedPreferenceAapnar.setCurrentFontIndex(0);
                setInputView(onCreateInputView());
                this.sharedPreferenceAapnar.isKeyboardunlocked(false);
                this.sharedPreferenceAapnar.isKeyboardChanged(false);
            }
            setShareButtonBehavior();
            if (editorInfo != null) {
                int i = editorInfo.inputType & 15;
                if (i != 1) {
                    if (i != 2) {
                        if (i == 3) {
                            this.currentKeyboard = this.symbolsKeyboard;
                        } else if (i != 4) {
                            this.currentKeyboard = this.aksharonuKeyboard;
                            updateShiftKeyState(editorInfo);
                        }
                    }
                    this.currentKeyboard = this.symbolsKeyboard;
                } else {
                    this.currentKeyboard = this.aksharonuKeyboard;
                    updateShiftKeyState(editorInfo);
                }
                updateShiftKeyState(editorInfo);
                return;
            }
            return;
        }
        throw null;
    }

    public void onKey(int i, int[] iArr) {
        InputConnection currentInputConnection = getCurrentInputConnection();
        this.language = this.sharedPreferenceAapnar.getLanguage();
        if (currentInputConnection != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onKey ");
            stringBuilder.append(i);
            if (i == -5) {
                handleBackspace();
            } else if (i == -1) {
                handleShift();
            } else if (i == -4) {
                currentInputConnection.sendKeyEvent(new KeyEvent(0, 66));
            } else if (i == FontKeyboard.Companion.getKEYCODE_LANGUAGE_SWITCH()) {
                handleLanguageSwitch();
            } else if (i == -2) {
                String str = "imagePreferance";
                FontKeyboard2 fontKeyboard2;
                Keyboard keyboard;
                FontKeyboard fontKeyboard;
                String image;
                if (this.language.equals("guj")) {
                    fontKeyboard2 = this.keyboardView;
                    keyboard = fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null;
                    if (keyboard != null && (keyboard == this.gujaratiKeyboard || keyboard == this.symbolsShiftedKeyboard)) {
                        fontKeyboard = this.aksharonuKeyboard;
                        if (fontKeyboard != null) {
                            if (fontKeyboard != null) {
                                setCurrentKeyboard(fontKeyboard);
                                image = this.sharedPreferenceAapnar.getImage(str, null);
                                if (image != null) {
                                    this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                                }
                                return;
                            }
                            throw null;
                        }
                    }
                    keyboard = this.gujaratiKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(false);
                        setCurrentKeyboard(this.gujaratiKeyboard);
                        image = this.sharedPreferenceAapnar.getImage(str, null);
                        if (image != null) {
                            this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                        }
                    }
                } else if (this.language.equals("arab")) {
                    fontKeyboard2 = this.keyboardView;
                    keyboard = fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null;
                    if (keyboard != null && (keyboard == this.arabKeyboard || keyboard == this.symbolsShiftedKeyboard)) {
                        fontKeyboard = this.aksharonuKeyboard;
                        if (fontKeyboard != null) {
                            if (fontKeyboard != null) {
                                setCurrentKeyboard(fontKeyboard);
                                image = this.sharedPreferenceAapnar.getImage(str, null);
                                if (image != null) {
                                    this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                                }
                                return;
                            }
                            throw null;
                        }
                    }
                    keyboard = this.arabKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(false);
                        setCurrentKeyboard(this.arabKeyboard);
                        image = this.sharedPreferenceAapnar.getImage(str, null);
                        if (image != null) {
                            this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                        }
                    }
                } else if (this.language.equals("hindi")) {
                    fontKeyboard2 = this.keyboardView;
                    keyboard = fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null;
                    if (keyboard != null && (keyboard == this.hindiKeyboard || keyboard == this.symbolsShiftedKeyboard)) {
                        fontKeyboard = this.aksharonuKeyboard;
                        if (fontKeyboard != null) {
                            if (fontKeyboard != null) {
                                setCurrentKeyboard(fontKeyboard);
                                image = this.sharedPreferenceAapnar.getImage(str, null);
                                if (image != null) {
                                    this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                                }
                                return;
                            }
                            throw null;
                        }
                    }
                    keyboard = this.hindiKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(false);
                        setCurrentKeyboard(this.hindiKeyboard);
                        image = this.sharedPreferenceAapnar.getImage(str, null);
                        if (image != null) {
                            this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                        }
                    }
                } else {
                    fontKeyboard2 = this.keyboardView;
                    keyboard = fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null;
                    if (keyboard != null && (keyboard == this.symbolsKeyboard || keyboard == this.symbolsShiftedKeyboard)) {
                        fontKeyboard = this.aksharonuKeyboard;
                        if (fontKeyboard != null) {
                            if (fontKeyboard != null) {
                                setCurrentKeyboard(fontKeyboard);
                                image = this.sharedPreferenceAapnar.getImage(str, null);
                                if (image != null) {
                                    this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                                }
                                return;
                            }
                            throw null;
                        }
                    }
                    keyboard = this.symbolsKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(false);
                        setCurrentKeyboard(this.symbolsKeyboard);
                        image = this.sharedPreferenceAapnar.getImage(str, null);
                        if (image != null) {
                            this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                        }
                    }
                }
            } else if (i == 10) {
                keyDownUp(66);
            } else {
                if (this.capsLockOn || this.keyboardView.getKeyboard().isShifted()) {
                    currentInputConnection.commitText(String.valueOf((char) i).toUpperCase(), 1);
                } else {
                    currentInputConnection.commitText(String.valueOf((char) i), 1);
                }
                if (this.keyboardView.getKeyboard() == this.aksharonuKeyboard) {
                    updateShiftKeyState(getCurrentInputEditorInfo());
                    this.keyboardView.invalidateAllKeys();
                }
                if (FontService.INSTANCE.getCurrentFont().isUpsideDown()) {
                    currentInputConnection.sendKeyEvent(new KeyEvent(0, 21));
                    currentInputConnection.sendKeyEvent(new KeyEvent(1, 21));
                }
                if (isWordSeparator(i)) {
                    updateShiftKeyState(getCurrentInputEditorInfo());
                }
            }
        }
    }

    public void onText(CharSequence charSequence) {
        InputConnection currentInputConnection = getCurrentInputConnection();
        if (currentInputConnection != null) {
            currentInputConnection.commitText(charSequence, 1);
            if (FontService.INSTANCE.getCurrentFont().isUpsideDown()) {
                getCurrentInputConnection().sendKeyEvent(new KeyEvent(0, 21));
                getCurrentInputConnection().sendKeyEvent(new KeyEvent(1, 21));
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    public final void setCurrentKeyboard(Keyboard keyboard) {
        this.currentKeyboard = keyboard;
        FontKeyboard2 fontKeyboard2 = this.keyboardView;
        if (fontKeyboard2 != null) {
            fontKeyboard2.setKeyboard(keyboard);
        }
        String image = this.sharedPreferenceAapnar.getImage("imagePreferance", null);
        if (image != null) {
            this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
        }
    }

    private final void handleLanguageSwitch() {
        if (VERSION.SDK_INT < 28 || !shouldOfferSwitchingToNextInputMethod()) {
            InputMethodManager inputMethodManager = this.inputMethodManager;
            if (inputMethodManager == null) {
                throw new ExceptionInInitializerError("inputMethodManager");
            } else if (VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if (inputMethodManager.shouldOfferSwitchingToNextInputMethod(getToken())) {
                    this.inputMethodManager.switchToNextInputMethod(getToken(), false);
                    return;
                } else if (hasNavigationKeyboardSwitchButton()) {
                    showChangeKeyboardOverlayView();
                    return;
                } else {
                    showChangeKeyboardNotificationOverlayView();
                    return;
                }
            }
        }
        if (VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            switchToNextInputMethod(false);
        }
    }

    private final IBinder getToken() {
        Dialog window = getWindow();
        if (window != null) {
            Window window2 = window.getWindow();
            if (window2 != null) {
                return window2.getAttributes().token;
            }
        }
        return null;
    }

    private final void handleBackspace() {
        if (FontService.INSTANCE.getCurrentFont().isUpsideDown()) {
            getCurrentInputConnection().sendKeyEvent(new KeyEvent(0, 22));
            getCurrentInputConnection().sendKeyEvent(new KeyEvent(1, 22));
        }
        keyDownUp(67);
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private final void keyDownUp(int i) {
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(0, i));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(1, i));
    }

    public final boolean isWordSeparator(int i) {
        String str = this.wordSeparators;
        if (str != null) {
            return str.contains(String.valueOf((char) i));
        }
        throw new ExceptionInInitializerError("wordSeparators");
    }

    public final boolean hasNavigationKeyboardSwitchButton() {
        Object systemService = getSystemService(WINDOW_SERVICE);
        if (!(systemService instanceof WindowManager)) {
            return true;
        }
        Display defaultDisplay = ((WindowManager) systemService).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            defaultDisplay.getRealMetrics(displayMetrics);
        }
        int i = displayMetrics.heightPixels;
        int i2 = displayMetrics.widthPixels;
        DisplayMetrics displayMetrics2 = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics2);
        int i3 = displayMetrics2.heightPixels;
        if (i2 - displayMetrics2.widthPixels > 125 || i - i3 > 125) {
            return true;
        }
        return false;
    }

    private final void updateShiftKeyState(EditorInfo editorInfo) {
        if (editorInfo != null) {
            Keyboard keyboard = this.normalfontsKeyboard;
            if (keyboard != null) {
                FontKeyboard2 fontKeyboard2 = this.keyboardView;
                if (fontKeyboard2 != null) {
                    boolean z = true;
                    int cursorCapsMode;
                    FontKeyboard fontKeyboard;
                    if (keyboard == (fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null)) {
                        cursorCapsMode = (getCurrentInputEditorInfo() == null || getCurrentInputEditorInfo().inputType == 0) ? 0 : getCurrentInputConnection().getCursorCapsMode(editorInfo.inputType);
                        fontKeyboard = this.normalfontsKeyboard;
                        if (fontKeyboard != null) {
                            if (!this.capsLockOn && cursorCapsMode == 0) {
                                z = false;
                            }
                            fontKeyboard.setShifted(z);
                        }
                    } else if (this.keyboardView.getKeyboard() == this.aksharonuKeyboard) {
                        cursorCapsMode = (getCurrentInputEditorInfo() == null || getCurrentInputEditorInfo().inputType == 0) ? 0 : getCurrentInputConnection().getCursorCapsMode(editorInfo.inputType);
                        fontKeyboard = this.aksharonuKeyboard;
                        if (fontKeyboard != null) {
                            if (!this.capsLockOn && cursorCapsMode == 0) {
                                z = false;
                            }
                            fontKeyboard.setShifted(z);
                        }
                    }
                }
            }
        }
    }

    private final void handleShift() {
        if (!(this.normalfontsKeyboard == null || this.symbolsKeyboard == null || this.symbolsShiftedKeyboard == null)) {
            FontKeyboard2 fontKeyboard2 = this.keyboardView;
            boolean z = false;
            if ((fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null) == this.normalfontsKeyboard) {
                checkToggleCapsLock();
                fontKeyboard2 = this.keyboardView;
                if (fontKeyboard2 != null) {
                    if (this.capsLockOn || fontKeyboard2 == null || !fontKeyboard2.isShifted()) {
                        z = true;
                    }
                    this.keyboardView.setShifted(z);
                }
                return;
            }
            fontKeyboard2 = this.keyboardView;
            if ((fontKeyboard2 != null ? fontKeyboard2.getKeyboard() : null) == this.aksharonuKeyboard) {
                checkToggleCapsLock();
                fontKeyboard2 = this.keyboardView;
                if (fontKeyboard2 != null) {
                    if (this.capsLockOn || fontKeyboard2 == null || !fontKeyboard2.isShifted()) {
                        z = true;
                    }
                    this.keyboardView.setShifted(z);
                }
                return;
            }
            Keyboard keyboard = this.currentKeyboard;
            Keyboard keyboard2 = this.symbolsKeyboard;
            String str = "imagePreferance";
            String image;
            if (keyboard == keyboard2) {
                if (keyboard2 != null) {
                    keyboard2.setShifted(true);
                }
                keyboard = this.symbolsShiftedKeyboard;
                if (keyboard != null) {
                    setCurrentKeyboard(keyboard);
                    image = this.sharedPreferenceAapnar.getImage(str, null);
                    if (image != null) {
                        this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                    }
                    keyboard = this.symbolsShiftedKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(true);
                    }
                } else {
                    throw null;
                }
            } else if (keyboard == this.symbolsShiftedKeyboard) {
                if (keyboard2 != null) {
                    keyboard2.setShifted(false);
                }
                keyboard = this.symbolsKeyboard;
                if (keyboard != null) {
                    setCurrentKeyboard(keyboard);
                    image = this.sharedPreferenceAapnar.getImage(str, null);
                    if (image != null) {
                        this.keyboardView.setBackground(new BitmapDrawable(getResources(), Const.decodeBase64(image)));
                    }
                    keyboard = this.symbolsShiftedKeyboard;
                    if (keyboard != null) {
                        keyboard.setShifted(false);
                    }
                } else {
                    throw null;
                }
            }
        }
    }

    private final void checkToggleCapsLock() {
        long currentTimeMillis = System.currentTimeMillis();
        if (this.lastShiftTime + 400 > currentTimeMillis || this.capsLockOn) {
            this.capsLockOn = true;
            this.lastShiftTime = 0;
            return;
        }
        this.lastShiftTime = currentTimeMillis;
    }
}
