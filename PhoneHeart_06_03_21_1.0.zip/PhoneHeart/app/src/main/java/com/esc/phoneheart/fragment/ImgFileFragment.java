package com.esc.phoneheart.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.DrawableTypeRequest;
import com.bumptech.glide.Glide;
import com.esc.phoneheart.activity.DuplicatesFileTabScreen;
import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.duplicatefiles.DupFileMediaMapData;
import com.esc.phoneheart.duplicatefiles.DuplicateFilesData;
import com.esc.phoneheart.adapter.SectionGridViewAdapterFiles;
import com.esc.phoneheart.adapter.SectionGridViewAdapterFiles.Section;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

public class ImgFileFragment extends Fragment {
    public Context U;
    public ArrayList<DupFileMediaMapData> V;
    public int deviceHeight;
    public int deviceWidth;
    public Section[] dummy;
    public SectionGridViewAdapterFiles mSectionedAdapter;
    public RecyclerView mediaNameRecyclerView;
    public View root;

    public ImgFileFragment(Context context, ArrayList<DupFileMediaMapData> arrayList) {
        this.U = context;
        this.V = arrayList;
        setDeviceDimensions();
    }

    public class SimpleAdapter extends Adapter<SimpleAdapter.SimpleViewHolder> {
        public int a = 0;
        public final Context mContext;
        public final ArrayList<BigSizeFilesWrapper> mItems;
        public final int width;

        public class SimpleViewHolder extends ViewHolder {
            public final ImageView img;
            public ImageView info;
            public AppCompatCheckBox img_chk;
            public TextView txt_junkListItemSize;

            public SimpleViewHolder(SimpleAdapter simpleAdapter, View view) {
                super(view);
                this.img = (ImageView) view.findViewById(R.id.img);
                this.info = (ImageView) view.findViewById(R.id.listiteminfo);
                this.img_chk = (AppCompatCheckBox) view.findViewById(R.id.img_chk);
                this.txt_junkListItemSize = (TextView) view.findViewById(R.id.junkListItemSize);
                LayoutParams layoutParams = (LayoutParams) this.img.getLayoutParams();
                layoutParams.height = (ImgFileFragment.this.deviceHeight * 14) / 100;
                layoutParams.width = (ImgFileFragment.this.deviceWidth * 24) / 100;
                    Log.e("------", "set hieght,width");
                this.img.setLayoutParams(layoutParams);
            }
        }

        public SimpleAdapter(Context context, Map<Integer, ArrayList<BigSizeFilesWrapper>> map) {
            this.mContext = context;
            this.width = dip2px(83.33f);
            ArrayList arrayList = new ArrayList();
            for (Entry value : map.entrySet()) {
                ArrayList arrayList2 = (ArrayList) value.getValue();
                this.a += arrayList2.size();
                arrayList.addAll(arrayList2);
            }
            this.mItems = new ArrayList(this.a);
            for (int i = 0; i < a; i++) {
                a(i, (BigSizeFilesWrapper) arrayList.get(i));
            }
        }

        private int dip2px(float f) {
            return (int) ((f * this.mContext.getResources().getDisplayMetrics().density) + 0.5f);
        }

        private ArrayList<BigSizeFilesWrapper> getCurrentlySelectedGroup(String str) {
            int i = 0;
            for (Integer intValue : PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages.keySet()) {
                i++;
                ArrayList arrayList = new ArrayList((Collection) PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages.get(Integer.valueOf(intValue.intValue())));
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    if (((BigSizeFilesWrapper) arrayList.get(i2)).path.equals(str)) {
                        PhoneCleaner.getInstance().duplicateFilesData.currentGroupIndex = i;
                        PhoneCleaner.getInstance().duplicateFilesData.currentGroupChildIndex = i2;
                        return arrayList;
                    }
                }
            }
            return null;
        }

        private void openFile(Context context, File file) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(268435456);
            intent.addFlags(3);
            Uri uriForFile = FileProvider.getUriForFile(context, "com.esc.phoneheart.fileprovider", file);
            String mimeType = Util.getMimeType(file.getAbsolutePath());
            if (mimeType != null) {
                intent.setDataAndType(uriForFile, mimeType);
            } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
                intent.setDataAndType(uriForFile, "application/msword");
            } else if (file.toString().contains(".pdf")) {
                intent.setDataAndType(uriForFile, "application/pdf");
            } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
                intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
            } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
                intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
            } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
                intent.setDataAndType(uriForFile, "application/x-wav");
            } else if (file.toString().contains(".rtf")) {
                intent.setDataAndType(uriForFile, "application/rtf");
            } else if (file.toString().contains(".wav") || file.toString().contains(".mp3") || file.toString().contains(".wma") || file.toString().contains(".ogg") || file.toString().contains(".flac") || file.toString().contains(".aac")) {
                intent.setDataAndType(uriForFile, "audio/*");
            } else if (file.toString().contains(".gif")) {
                intent.setDataAndType(uriForFile, "image/gif");
            } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
                intent.setDataAndType(uriForFile, "image/*");
            } else if (file.toString().contains(".txt")) {
                intent.setDataAndType(uriForFile, "text/plain");
            } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
                intent.setDataAndType(uriForFile, "video/*");
            } else if (file.toString().contains(".apk")) {
                intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
            } else {
                intent.setDataAndType(uriForFile, "*/*");
            }
            context.startActivity(intent);
        }

        public int getItemCount() {
            return this.mItems.size();
        }

        public void refreshRecyclerView() {
            ArrayList arrayList = new ArrayList();
            int i = 0;
            for (Entry entry : PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages.entrySet()) {
                ArrayList arrayList2 = (ArrayList) entry.getValue();
                int i2 = 0;
                int i3 = 0;
                for (int i4 = 0; i4 < arrayList2.size(); i4++) {
                    if (((BigSizeFilesWrapper) arrayList2.get(i4)).lockImg) {
                        i2++;
                    }
                    if (((BigSizeFilesWrapper) arrayList2.get(i4)).ischecked) {
                        i3++;
                    }
                }
                boolean z = true;
                if (i2 == 0) {
                    if (i3 == arrayList2.size() - 1) {
                        boolean z2 = z;
                        StringBuilder sb = new StringBuilder();
                        sb.append(ImgFileFragment.this.getResources().getString(R.string.dup_photo_groups));
                        sb.append(entry.getKey());
                        String sb2 = sb.toString();
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("");
                        sb3.append(arrayList2.size());
                        String sb4 = sb3.toString();
                        StringBuilder sb5 = new StringBuilder();
                        sb5.append(i3);
                        sb5.append("/");
                        sb5.append(arrayList2.size());
                        Section section = new Section(i, sb2, sb4, sb5.toString(), z2);
                        arrayList.add(section);
                        i += arrayList2.size();
                    }
                } else if (i2 + i3 == arrayList2.size()) {
                    boolean z22 = z;
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(ImgFileFragment.this.getResources().getString(R.string.dup_photo_groups));
                    sb6.append(entry.getKey());
                    String sb22 = sb6.toString();
                    StringBuilder sb32 = new StringBuilder();
                    sb32.append("");
                    sb32.append(arrayList2.size());
                    String sb42 = sb32.toString();
                    StringBuilder sb52 = new StringBuilder();
                    sb52.append(i3);
                    sb52.append("/");
                    sb52.append(arrayList2.size());
                    Section section2 = new Section(i, sb22, sb42, sb52.toString(), z22);
                    arrayList.add(section2);
                    i += arrayList2.size();
                }
                z = false;
                boolean z222 = z;
                StringBuilder sb62 = new StringBuilder();
                sb62.append(ImgFileFragment.this.getResources().getString(R.string.dup_photo_groups));
                sb62.append(entry.getKey());
                String sb222 = sb62.toString();
                StringBuilder sb322 = new StringBuilder();
                sb322.append("");
                sb322.append(arrayList2.size());
                String sb422 = sb322.toString();
                StringBuilder sb522 = new StringBuilder();
                sb522.append(i3);
                sb522.append("/");
                sb522.append(arrayList2.size());
                Section section22 = new Section(i, sb222, sb422, sb522.toString(), z222);
                arrayList.add(section22);
                i += arrayList2.size();
            }
            ImgFileFragment.this.mSectionedAdapter.setSections((Section[]) arrayList.toArray(ImgFileFragment.this.dummy));
        }

        public void removeItem(int i) {
            this.mItems.remove(i);
            notifyItemRemoved(i);
        }

        public void setDeleteBtnText() {
            if (PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems == 0) {
                ((TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean)).setText(R.string.clean);
                ((TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean)).setEnabled(false);
                return;
            }
            long j = PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems;
            String str = ")";
            String str2 = " (";
            String str3 = " ";
            TextView textView;
            StringBuilder stringBuilder;
            if (j == 1) {
                textView = (TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean);
                stringBuilder = new StringBuilder();
                stringBuilder.append(ImgFileFragment.this.getString(R.string.clean));
                stringBuilder.append(str3);
                stringBuilder.append(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems);
                stringBuilder.append(str3);
                stringBuilder.append(   ImgFileFragment.this.getString(R.string.file_manage_items));
                stringBuilder.append(str2);
                stringBuilder.append(Util.convertBytes(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize));
                stringBuilder.append(str);
                textView.setText(stringBuilder.toString());
                ((TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean)).setEnabled(true);
                return;
            }
            textView = (TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean);
            stringBuilder = new StringBuilder();
            stringBuilder.append(ImgFileFragment.this.getString(R.string.clean));
            stringBuilder.append(str3);
            stringBuilder.append(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedItems);
            stringBuilder.append(str3);
            stringBuilder.append(ImgFileFragment.this.getString(R.string.file_manage_items));
            stringBuilder.append(str2);
            stringBuilder.append(Util.convertBytes(PhoneCleaner.getInstance().duplicateFilesData.totalSelectedSize));
            stringBuilder.append(str);
            textView.setText(stringBuilder.toString());
            ((TextView) ImgFileFragment.this.getActivity().findViewById(R.id.btn_clean)).setEnabled(true);
        }

        public void onBindViewHolder(@NonNull final SimpleViewHolder simpleViewHolder, int i) {
            BigSizeFilesWrapper bigSizeFilesWrapper = (BigSizeFilesWrapper) this.mItems.get(i);
            if (bigSizeFilesWrapper.ischecked) {
                simpleViewHolder.img_chk.setChecked(true);
            } else {
                simpleViewHolder.img_chk.setChecked(false);
            }
            DrawableTypeRequest load = Glide.with(this.mContext).load(new File(bigSizeFilesWrapper.path));
            int i2 = this.width;
            load.override(i2, i2).placeholder((int) R.drawable.broken_drawable).error(R.drawable.broken_drawable).centerCrop().into(simpleViewHolder.img);
            TextView textView = simpleViewHolder.txt_junkListItemSize;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
            textView.setText(stringBuilder.toString());
            simpleViewHolder.img.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    try {
                        SimpleAdapter.this.openFile(ImgFileFragment.this.getActivity(), new File(bigSizeFilesWrapper.path));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            simpleViewHolder.img_chk.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {

                    if (bigSizeFilesWrapper.lockImg) {
                        simpleViewHolder.img_chk.setChecked(false);
                        return;
                    }
                    bigSizeFilesWrapper.ischecked = simpleViewHolder.img_chk.isChecked();
                    if (simpleViewHolder.img_chk.isChecked()) {
                        PhoneCleaner.getInstance().duplicateFilesData.currentList = null;
                        DuplicateFilesData duplicateFilesData = PhoneCleaner.getInstance().duplicateFilesData;
                        SimpleAdapter simpleAdapter = SimpleAdapter.this;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(bigSizeFilesWrapper.path);
                        stringBuilder.append("");
                        duplicateFilesData.currentList = simpleAdapter.getCurrentlySelectedGroup(stringBuilder.toString());
                        int size = PhoneCleaner.getInstance().duplicateFilesData.currentList.size();
                        int i = 0;
                        for (int i2 = 0; i2 < size; i2++) {
                            if (((BigSizeFilesWrapper) PhoneCleaner.getInstance().duplicateFilesData.currentList.get(i2)).ischecked) {
                                i++;
                            }
                        }
                        simpleViewHolder.img_chk.setChecked(true);
                        PhoneCleaner.getInstance().duplicateFilesData.selectNode(bigSizeFilesWrapper);
                        ((DuplicatesFileTabScreen) ImgFileFragment.this.getActivity()).getSelection();
                        if (size == i) {
                            bigSizeFilesWrapper.ischecked = false;
                            simpleViewHolder.img_chk.setChecked(false);
                            Toast.makeText(ImgFileFragment.this.getActivity(), ImgFileFragment.this.getString(R.string.dup_photo_markall), Toast.LENGTH_LONG).show();
                            PhoneCleaner.getInstance().duplicateFilesData.unselectNode(bigSizeFilesWrapper);
                        }
                    } else {
                        simpleViewHolder.img_chk.setChecked(false);
                        ((AppCompatCheckBox) ((DuplicatesFileTabScreen) ImgFileFragment.this.getActivity()).findViewById(R.id.check_all)).setChecked(false);
                        PhoneCleaner.getInstance().duplicateFilesData.unselectNode(bigSizeFilesWrapper);
                    }
                    SimpleAdapter.this.setDeleteBtnText();
                    SimpleAdapter.this.refreshRecyclerView();
                    SimpleAdapter.this.notifyDataSetChanged();
                }
            });
            simpleViewHolder.info.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    final Dialog dialog = new Dialog(ImgFileFragment.this.U);
                    if (dialog.getWindow() != null) {
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
                    }
                    dialog.setContentView(R.layout.new_dialog_junk_cancel);
                    dialog.setCancelable(true);
                    dialog.setCanceledOnTouchOutside(true);
                    dialog.getWindow().setLayout(-1, -1);
                    dialog.getWindow().setGravity(17);
                    dialog.findViewById(R.id.dialog_img).setVisibility(View.GONE);
                    dialog.findViewById(R.id.dialog_title).setVisibility(View.GONE);
                    TextView textView = (TextView) dialog.findViewById(R.id.dialog_msg);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(ImgFileFragment.this.getResources().getString(R.string.pcl_name));
                    String str = " ";
                    stringBuilder.append(str);
                    stringBuilder.append(bigSizeFilesWrapper.name);
                    String str2 = "\n\n";
                    stringBuilder.append(str2);
                    stringBuilder.append(ImgFileFragment.this.getResources().getString(R.string.pcl_path));
                    stringBuilder.append(str);
                    stringBuilder.append(bigSizeFilesWrapper.path);
                    stringBuilder.append(str2);
                    stringBuilder.append(ImgFileFragment.this.getResources().getString(R.string.pcl_size));
                    stringBuilder.append(str);
                    stringBuilder.append(Util.convertBytes(bigSizeFilesWrapper.size));
                    textView.setText(stringBuilder.toString());
                    dialog.findViewById(R.id.ll_yes_no).setVisibility(View.GONE);
                    dialog.findViewById(R.id.ll_ok).setVisibility(View.VISIBLE);
                    dialog.findViewById(R.id.ll_ok).setOnClickListener(new OnClickListener() {
                        public void onClick(View view) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                }
            });
        }

        @NonNull
        public SimpleViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new SimpleViewHolder(this, LayoutInflater.from(this.mContext).inflate(R.layout.item, viewGroup, false));
        }

        public void a(int i, BigSizeFilesWrapper bigSizeFilesWrapper) {
            this.mItems.add(i, bigSizeFilesWrapper);
            notifyItemInserted(i);
        }
    }

    private void setDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        @SuppressLint("WrongConstant") WindowManager windowManager = (WindowManager) this.U.getSystemService("window");
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
    }

    private void setIMGAdapter() {
        PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages = new TreeMap();
        int i = 0;
        for (int i2 = 0; i2 < this.V.size(); i2++) {
            if (((DupFileMediaMapData) this.V.get(i2)).list.size() != 1) {
                i++;
                ArrayList arrayList = new ArrayList();
                for (int i3 = 0; i3 < ((DupFileMediaMapData) this.V.get(i2)).list.size(); i3++) {
                    arrayList.add(((DupFileMediaMapData) this.V.get(i2)).list.get(i3));
                }
                PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages.put(Integer.valueOf(i), arrayList);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        int i4 = 0;
        for (Entry entry : PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages.entrySet()) {
            ArrayList arrayList3 = (ArrayList) entry.getValue();
            int i5 = 0;
            for (int i6 = 0; i6 < arrayList3.size(); i6++) {
                if (((BigSizeFilesWrapper) arrayList3.get(i6)).ischecked) {
                    i5++;
                }
            }
            boolean z = i5 == arrayList3.size() - 1;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getResources().getString(R.string.dup_photo_groups));
            stringBuilder.append(entry.getKey());
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("");
            stringBuilder3.append(arrayList3.size());
            String stringBuilder4 = stringBuilder3.toString();
            stringBuilder3 = new StringBuilder();
            stringBuilder3.append(i5);
            stringBuilder3.append("/");
            stringBuilder3.append(arrayList3.size());
            arrayList2.add(new Section(i4, stringBuilder2, stringBuilder4, stringBuilder3.toString(), z));
            i4 += arrayList3.size();
        }
        SimpleAdapter simpleAdapter = new SimpleAdapter(this.U, PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages);
        this.dummy = new Section[arrayList2.size()];
        mSectionedAdapter = new SectionGridViewAdapterFiles(this.U, R.layout.section, this.mediaNameRecyclerView, simpleAdapter, PhoneCleaner.getInstance().duplicateFilesData.duplicateGridImages);
        mSectionedAdapter.setSections((Section[]) arrayList2.toArray(this.dummy));
        this.mediaNameRecyclerView.setAdapter(this.mSectionedAdapter);
        if (arrayList2.size() == 0) {
            try {
                ((View) this.root.findViewById(R.id.tv_empty).getParent()).setVisibility(View.VISIBLE);
                this.mediaNameRecyclerView.setVisibility(View.GONE);
            } catch (Exception unused) {
            }
        }
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.dup_file_fragment, viewGroup, false);
        this.root = inflate;
        this.mediaNameRecyclerView = (RecyclerView) inflate.findViewById(R.id.rv_img_file_adapter);
        if (this.V.size() == 0) {
            ((View) this.root.findViewById(R.id.tv_empty).getParent()).setVisibility(View.VISIBLE);
            this.mediaNameRecyclerView.setVisibility(View.GONE);
        } else {
            this.mediaNameRecyclerView.setHasFixedSize(true);
            this.mediaNameRecyclerView.setLayoutManager(new GridLayoutManager(this.U, 4));
            setIMGAdapter();
        }
        return this.root;
    }

    public void onResume() {
        super.onResume();
        try {
            setIMGAdapter();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onStart() {
        super.onStart();
        this.V = PhoneCleaner.getInstance().duplicateFilesData.getPerticulerDupFileDataList(getString(R.string.images));
    }
}
