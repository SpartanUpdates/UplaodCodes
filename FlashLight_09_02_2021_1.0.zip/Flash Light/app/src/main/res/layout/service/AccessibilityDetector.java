package flash.light.shine.com.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import flash.light.shine.com.APP;
import flash.light.shine.com.config.Config;
import flash.light.shine.com.database.DBAdapterFilteredPackages;
import flash.light.shine.com.flashlight.FlashService;
import flash.light.shine.com.util.FlashAlertUtil;
import flash.light.shine.com.util.PrefManager;

public class AccessibilityDetector extends AccessibilityService {
    private static final String TAG = "ACCESSIBILITY SERVICE";
    private static boolean isInit;

    public static boolean isInit() {
        return isInit;
    }

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        String str = "onAccessibilityEvent: " + accessibilityEvent.getEventType();
        String str2 = TAG;
        Log.e(str2, str);
        if (accessibilityEvent.getEventType() == 64) {
            str = String.valueOf(accessibilityEvent.getPackageName());
            Log.e(str2, "event target: " + str);
            String str3 = "com.android.phone";
            String str4 = "android.sms";
            String str5 = "android.mms";
            if ((accessibilityEvent.getParcelableData() instanceof Notification) && (str.contains(str5) | str.contains(str4)) == 0 && !str.contains(str3)) {
                Log.e(str2, "is: " + str);
            }
            if ((accessibilityEvent.getParcelableData() instanceof Notification) && (str.contains(str5) | str.contains(str4)) == 0 && !str.contains(str3)) {
                String[] strArr = Config.IGNORE_PACKAGE;
                Log.d(str2, "Nikss in");
                int length = strArr.length;
                int i = 0;
                while (i < length) {
                    if (!str.equals(strArr[i])) {
                        i++;
                    } else {
                        return;
                    }
                }
                boolean isFilteredPackage = isFilteredPackage(getApplicationContext(), str);
                Log.d(str2, "filteredPackage? " + isFilteredPackage);
                if (isFilteredPackage) {
                    handleChangedStatusBarState();
                    Log.d(str2, "REACTION. flash.");
                    return;
                }
                Log.d(str2, "REACTION. no flash.");
            }
            Log.d(str2, "Nikss out");
        }
    }

    private boolean isFilteredPackage(Context context, String str) {
        PrefManager prefManager = APP.getPrefManager();
        DBAdapterFilteredPackages dBAdapterFilteredPackages = new DBAdapterFilteredPackages(context);
        dBAdapterFilteredPackages.open();
        int filterModeApplication = prefManager.getFilterModeApplication();
        boolean z = false;
        String str2 = TAG;
        if (filterModeApplication != 2) {
            Log.e(str2, "yes is that no");
            dBAdapterFilteredPackages.clear();
            dBAdapterFilteredPackages.close();
            prefManager.setFilterModeApplication(2);
            return false;
        }
        Cursor fetchAll = dBAdapterFilteredPackages.fetchAll();
        int count = fetchAll.getCount();
        Log.e(str2, count + ":size");
        if (fetchAll != null && count > 0) {
            while (fetchAll.moveToNext()) {
                Log.e(str2, fetchAll.getString(1) + ":  c.getString(1)");
                if (str.equals(fetchAll.getString(1))) {
                    z = true;
                }
            }
        }
        fetchAll.close();
        dBAdapterFilteredPackages.close();
        return z;
    }

    /* Access modifiers changed, original: protected */
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "ACCESSIBILITY SERVICE CONECTED");
        if (!isInit) {
            AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
            accessibilityServiceInfo.eventTypes = 64;
            accessibilityServiceInfo.feedbackType = 16;
            accessibilityServiceInfo.notificationTimeout = 0;
            accessibilityServiceInfo.flags = 1;
            setServiceInfo(accessibilityServiceInfo);
            isInit = true;
            APP.getPrefManager().setUseStatusBar(true);
        }
    }

    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "ACCESSIBILITY SERVICE UNBIND");
        isInit = false;
        APP.getPrefManager().setUseStatusBar(false);
        return super.onUnbind(intent);
    }

    public void onInterrupt() {
        Log.d(TAG, "ACCESSIBILITY SERVICE INTERRUPT");
        isInit = false;
    }

    private void handleChangedStatusBarState() {
        Intent checkChangedStatusBarState = FlashAlertUtil.checkChangedStatusBarState(getApplicationContext());
        if (checkChangedStatusBarState != null) {
            FlashService.runIntentInService(getApplicationContext(), checkChangedStatusBarState);
        }
    }
}
