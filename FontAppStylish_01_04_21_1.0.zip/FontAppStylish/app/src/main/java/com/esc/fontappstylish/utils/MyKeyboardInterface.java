package com.esc.fontappstylish.utils;

import java.io.InputStream;

public class MyKeyboardInterface {

    public interface onClickListener {
        void onClick();
    }

    public interface subThemeSelection {
        void getSubThemePosition(InputStream inputStream);
    }
}
