package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.text.Editable;
import android.text.Html;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.style.ClickableSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;
import com.ironsource.sdk.constants.Constants;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class DemoActivity extends AppCompatActivity implements OnTouchListener, OnSeekBarChangeListener {
    static final int DRAG = 1;
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 111;
    static final int NONE = 0;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    static final int ZOOM = 2;
    public static boolean change_bg = false;
    public static Editor editor;
    public static Boolean isbold;
    public static Boolean isitalic;
    public static Boolean isunderline;
    public static Activity resultactivity;
    public static SharedPreferences sharedPreferences;
    PointF DownPT = null;
    int RESULT_LOAD_IMG = 1;
    PointF StartPT = null;
    private int _xDelta;
    private int _yDelta;
    private int _y_up;
    int[] array = new int[]{R.color.btn1, R.color.btn2, R.color.btn3, R.color.btn4, R.color.btn5, R.color.btn6, R.color.btn7, R.color.btn8, R.color.btn9, R.color.btn10, R.color.btn11, R.color.btn12, R.color.btn13, R.color.btn14, R.color.btn15, R.color.btn16, R.color.btn17, R.color.btn18, R.color.btn19, R.color.btn20, R.color.btn21, R.color.btn22, R.color.btn23, R.color.btn24, R.color.btn25, R.color.btn26, R.color.btn27, R.color.btn28};
    Button b;
    ImageView bg;
    ImageView bgimg;
    Bitmap bm;
    ImageView bold;
    Button[] btnarray = new Button[28];
    Bundle bundle;
    ImageView centeralign;
    String changedtxt;
    OnClickListener click = new OnClickListener() {
        public void onClick(View view) {
            DemoActivity demoActivity = DemoActivity.this;
            demoActivity.b = (Button) view;
            int intValue = ((Integer) demoActivity.b.getTag()).intValue();
            DemoActivity.this.txtmsg.setTextColor(DemoActivity.this.getResources().getColor(DemoActivity.this.array[intValue]));
            DemoActivity.this.editmsg.setTextColor(DemoActivity.this.getResources().getColor(DemoActivity.this.array[intValue]));
        }
    };
    Context context;
    CoordinatorLayout coordinatorLayout;
    float dX;
    float dY;
    int default_height;
    int default_width;
    TextView desc1;
    TextView desc2;
    TextView desc3;
    TextView desc4;
    TextView desc5;
    TextView desc6;
    Dialog dialogR;
    EditText editmsg;
    RelativeLayout editoptions;
    SpannableString editspannableContent;
    ImageView edittxt;
    File fil;
    OnClickListener fontclick = new OnClickListener() {
        public void onClick(View view) {
            DemoActivity demoActivity = DemoActivity.this;
            demoActivity.t = (TextView) view;
            int intValue = ((Integer) demoActivity.t.getTag()).intValue();
            DemoActivity.this.txtmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.fonts[intValue]));
            DemoActivity.this.editmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.fonts[intValue]));
            DemoActivity.this.txtviewy.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.fonts[intValue]));
            demoActivity = DemoActivity.this;
            demoActivity.txttypeface = demoActivity.fonts[intValue];
            DemoActivity.this.applyFont();
        }
    };
    String[] fonts;
    TextView[] fontstyle = new TextView[18];
    int imageHeight;
    int imageWidth;
    String images;
    String imgalign;
    int imgheight;
    int imgwidth;
    ImageView italic;
    ImageView leftalign;
    String mFilePath;
    ReviewManager manager;
    Matrix matrix = new Matrix();
    int max = 1000;
    PointF mid = new PointF();
    int min = 0;
    float minX;
    float minY;
    int mode = 0;
    ImageView moveimg;
    String msg;
    int mygravity = 0;
    int number;
    Float oldDist = Float.valueOf(1.0f);
    File output;
    Random random;
    RelativeLayout rel;
    RelativeLayout rel1;
    ReviewInfo reviewInfo;
    ImageView rightalign;
    Matrix savedMatrix = new Matrix();
    SeekBar seekBar;
    int selectedimage;
    ArrayList<Integer> small = new ArrayList();
    Snackbar snackbar;
    String source;
    SpannableString spannableContent;
    PointF start = new PointF();
    TextView t;
    String textalign;
    String txtcolor;
    int txtlength;
    TextView txtmsg;
    String txttypeface;
    TextView txtview;
    TextView txtviewy;
    ImageView underline;
    ImageView uploadbtn;
    int windowheight;
    int windowwidth;
    float x;
    int xDelta;
    float y;
    int yDelta;

    class MyClickableSpan extends ClickableSpan {
        String clicked;

        public MyClickableSpan(String str) {
            this.clicked = str;
        }

        public void onClick(View view) {
            Toast.makeText(DemoActivity.this, this.clicked, Toast.LENGTH_SHORT).show();
        }

        public void updateDrawState(TextPaint textPaint) {
            textPaint.setUnderlineText(false);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    static {
        Boolean valueOf = Boolean.valueOf(false);
        isbold = valueOf;
        isitalic = valueOf;
        isunderline = valueOf;
    }


    public void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        setContentView(R.layout.activity_demo);
        System.gc();
        int i2 = 0;
        sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        editor = sharedPreferences.edit();
        String str = "inappreview";
        editor.putInt(str, sharedPreferences.getInt(str, 0) + 1).apply();
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview1(getApplicationContext());
        }
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            this.default_height = 500;
            this.default_width = 500;
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            this.default_height = 400;
            this.default_width = 400;
        } else {
            this.default_height = 300;
            this.default_width = 300;
        }
        resultactivity = this;
        for (i = 15; i < 21; i++) {
            this.small.add(Integer.valueOf(i));
        }
        getSupportActionBar().setTitle("");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText("Personalized Greetings");
        textView.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf"));
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        this.context = this;
        this.bundle = getIntent().getExtras();
        this.images = this.bundle.getString("images");
        this.selectedimage = this.bundle.getInt("selectedimage");
        this.txtcolor = this.bundle.getString("txtcolor");
        this.textalign = this.bundle.getString("textalign");
        this.imgalign = this.bundle.getString("imgalign");
        this.msg = this.bundle.getString(NotificationCompat.CATEGORY_MESSAGE);
        this.source = sharedPreferences.getString("source", "");
        this.random = new Random();
        this.number = this.random.nextInt(this.max - this.min) + this.min;
        this.bgimg = findViewById(R.id.bgimg);
        this.moveimg = findViewById(R.id.movableimg);
        this.uploadbtn = findViewById(R.id.uploadbtn);
        this.txtmsg = findViewById(R.id.txtmsg);
        this.txtview = findViewById(R.id.txtview);
        this.txtviewy = findViewById(R.id.txtviewy);
        this.desc1 = findViewById(R.id.desc1);
        this.desc2 = findViewById(R.id.desc2);
        this.desc3 = findViewById(R.id.desc3);
        this.desc4 = findViewById(R.id.desc4);
        this.desc5 = findViewById(R.id.desc5);
        this.desc6 = findViewById(R.id.desc6);
        this.txtmsg.setText(Html.fromHtml(this.msg.replaceAll("<br>", " ")));
        this.txtviewy.setText(this.txtmsg.getText());
        this.editmsg = findViewById(R.id.editmsg);
        this.rel = findViewById(R.id.rel);
        this.rel1 = findViewById(R.id.rel1);
        this.editoptions = findViewById(R.id.editoptions);
        this.bold = findViewById(R.id.bold);
        this.italic = findViewById(R.id.italic);
        this.underline = findViewById(R.id.underline);
        this.leftalign = findViewById(R.id.leftalign);
        this.centeralign = findViewById(R.id.centeralign);
        this.rightalign = findViewById(R.id.rightalign);
        this.bg = findViewById(R.id.bg);
        this.seekBar = findViewById(R.id.seekbar);
        this.seekBar.setOnSeekBarChangeListener(this);
        this.txtlength = this.txtmsg.getText().length();
        this.edittxt = findViewById(R.id.edittxt);
        this.bgimg.setImageResource(this.selectedimage);
        this.coordinatorLayout = findViewById(R.id.coordinatorLayout);
        this.windowwidth = getWindowManager().getDefaultDisplay().getWidth();
        this.windowheight = getWindowManager().getDefaultDisplay().getHeight();
        LayoutParams layoutParams = (LayoutParams) this.txtmsg.getLayoutParams();
        if (this.textalign.equals("bottom")) {
            layoutParams.addRule(12);
        } else if (this.textalign.equals("top")) {
            layoutParams.addRule(10);
        } else {
            layoutParams.addRule(13);
        }
        layoutParams = (LayoutParams) this.moveimg.getLayoutParams();
        double d;
        if (this.imgalign.equals("center")) {
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.setMargins((int) (d * 0.1d), 0, 0, 0);
        } else if (this.imgalign.equals("rightbottom")) {
            d = this.windowwidth;
            Double.isNaN(d);
            int i3 = (int) (d * 0.2d);
            d = this.windowheight;
            Double.isNaN(d);
            layoutParams.setMargins(i3, (int) (d * 0.1d), 0, 0);
        } else if (this.imgalign.equals("leftbottom")) {
            d = this.windowheight;
            Double.isNaN(d);
            layoutParams.setMargins(0, (int) (d * 0.1d), 0, 0);
        }
        if (this.images.equals("no")) {
            this.uploadbtn.setAlpha(0.5f);
        }
        if (this.txtcolor.equals("black")) {
            this.editmsg.setTextColor(getResources().getColor(R.color.btn4));
            this.txtmsg.setTextColor(getResources().getColor(R.color.btn4));
        } else {
            this.editmsg.setTextColor(getResources().getColor(R.color.btn5));
            this.txtmsg.setTextColor(getResources().getColor(R.color.btn5));
        }
        this.edittxt.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.txtmsg.setVisibility(View.INVISIBLE);
                DemoActivity.this.editmsg.setVisibility(View.VISIBLE);
                DemoActivity.this.editmsg.setText(DemoActivity.this.txtmsg.getText());
                InputMethodManager inputMethodManager = (InputMethodManager) DemoActivity.this.getSystemService(INPUT_METHOD_SERVICE);
                if (inputMethodManager != null) {
                    inputMethodManager.toggleSoftInput(2, 0);
                }
            }
        });
        this.rel1.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.hideSoftKeyboard();
                DemoActivity.this.editmsg.setVisibility(View.INVISIBLE);
                DemoActivity.this.txtmsg.setVisibility(View.VISIBLE);
                if (DemoActivity.this.changedtxt != null) {
                    DemoActivity.this.txtmsg.setText(DemoActivity.this.changedtxt);
                    DemoActivity.this.txtviewy.setText(DemoActivity.this.changedtxt);
                    if (DemoActivity.isunderline.booleanValue()) {
                        DemoActivity demoActivity = DemoActivity.this;
                        demoActivity.spannableContent = new SpannableString(demoActivity.txtmsg.getText());
                        DemoActivity.this.spannableContent.setSpan(new UnderlineSpan(), 0, DemoActivity.this.txtmsg.getText().length(), 0);
                        DemoActivity.this.txtmsg.setText(DemoActivity.this.spannableContent);
                    }
                }
            }
        });
        this.bg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.change_bg = true;
                Intent intent = new Intent(DemoActivity.this, GreetingActivity.class);
                intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, DemoActivity.this.msg);
                DemoActivity.this.startActivity(intent);
            }
        });
        this.editmsg.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("ONtext changed ");
                stringBuilder.append(charSequence.toString());
                printStream.println(stringBuilder.toString());
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("beforeTextChanged ");
                stringBuilder.append(charSequence.toString());
                printStream.println(stringBuilder.toString());
            }

            public void afterTextChanged(Editable editable) {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("afterTextChanged ");
                stringBuilder.append(editable.toString());
                printStream.println(stringBuilder.toString());
                DemoActivity.this.changedtxt = editable.toString();
            }
        });
        this.fonts = new String[]{"fonts/Allura-Regular.ttf", "fonts/ArchitectsDaughter.ttf", "fonts/BubblegumSans-Regular.ttf", "fonts/Calligraffitti-Regular.ttf", "fonts/Cookie-Regular.ttf", "fonts/Courgette-Regular.ttf", "fonts/DancingScript-Regular.ttf", "fonts/Dynalight-Regular.ttf", "fonts/GreatVibes-Regular.ttf", "fonts/JosefinSans-Regular.ttf", "fonts/JosefinSlab-Regular.ttf", "fonts/Lobster-Regular.ttf", "fonts/Neucha.ttf", "fonts/OpenSansCondensed-Light.ttf", "fonts/Quicksand-Regular.ttf", "fonts/RobotoSlab-Regular.ttf", "fonts/Rochester-Regular.ttf", "fonts/ShadowsIntoLight.ttf"};
        this.desc1.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.desc2.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.desc3.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.desc4.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.desc5.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.desc6.setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[15]));
        this.leftalign.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.txtmsg.setGravity(GravityCompat.START);
            }
        });
        this.rightalign.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.txtmsg.setGravity(GravityCompat.END);
            }
        });
        this.centeralign.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.txtmsg.setGravity(17);
            }
        });
        this.bold.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DemoActivity.isbold.booleanValue()) {
                    if (DemoActivity.this.txttypeface != null) {
                        DemoActivity.this.txtmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                        DemoActivity.this.txtviewy.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                        DemoActivity.this.editmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                    } else {
                        DemoActivity.this.txtmsg.setTypeface(null, Typeface.NORMAL);
                        DemoActivity.this.editmsg.setTypeface(null, Typeface.NORMAL);
                    }
                    DemoActivity.isbold = Boolean.valueOf(false);
                    DemoActivity.this.bold.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn5));
                } else {
                    DemoActivity.this.bold.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn23));
                    DemoActivity.this.txtmsg.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.BOLD);
                    DemoActivity.this.txtviewy.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.BOLD);
                    DemoActivity.this.editmsg.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.BOLD);
                    DemoActivity.isbold = Boolean.valueOf(true);
                }
                DemoActivity.this.applyFont();
            }
        });
        this.italic.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DemoActivity.isitalic.booleanValue()) {
                    if (DemoActivity.this.txttypeface != null) {
                        DemoActivity.this.txtmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                        DemoActivity.this.txtviewy.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                        DemoActivity.this.editmsg.setTypeface(Typeface.createFromAsset(DemoActivity.this.getAssets(), DemoActivity.this.txttypeface));
                    } else {
                        DemoActivity.this.txtmsg.setTypeface(null, Typeface.NORMAL);
                        DemoActivity.this.txtviewy.setTypeface(null, Typeface.NORMAL);
                        DemoActivity.this.editmsg.setTypeface(null, Typeface.NORMAL);
                    }
                    DemoActivity.isitalic = Boolean.valueOf(false);
                    DemoActivity.this.italic.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn5));
                } else {
                    DemoActivity.this.italic.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn23));
                    DemoActivity.this.txtmsg.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.ITALIC);
                    DemoActivity.this.txtviewy.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.ITALIC);
                    DemoActivity.this.editmsg.setTypeface(DemoActivity.this.txtmsg.getTypeface(), Typeface.ITALIC);
                    DemoActivity.isitalic = Boolean.valueOf(true);
                }
                DemoActivity.this.applyFont();
            }
        });
        this.underline.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DemoActivity.isunderline.booleanValue()) {
                    DemoActivity.this.underline.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn5));
                    DemoActivity.isunderline = Boolean.valueOf(false);
                    SpannableString spannableString = new SpannableString(DemoActivity.this.txtmsg.getText());
                    SpannableString spannableString2 = new SpannableString(DemoActivity.this.editmsg.getText());
                    ClickableSpan anonymousClass1 = new ClickableSpan() {
                        public void onClick(View view) {
                        }

                        public void updateDrawState(TextPaint textPaint) {
                            textPaint.setUnderlineText(false);
                        }
                    };
                    spannableString.setSpan(anonymousClass1, 0, spannableString.length(), 33);
                    DemoActivity.this.txtmsg.setText(spannableString);
                    if (DemoActivity.this.editmsg.isShown()) {
                        spannableString2.setSpan(anonymousClass1, 0, spannableString.length(), 33);
                        DemoActivity.this.editmsg.setText(spannableString2);
                    }
                } else {
                    DemoActivity.this.underline.setBackgroundColor(DemoActivity.this.getResources().getColor(R.color.btn23));
                    DemoActivity demoActivity = DemoActivity.this;
                    demoActivity.spannableContent = new SpannableString(demoActivity.txtmsg.getText());
                    DemoActivity.this.spannableContent.setSpan(new UnderlineSpan(), 0, DemoActivity.this.txtmsg.getText().length(), 0);
                    DemoActivity.this.txtmsg.setText(DemoActivity.this.spannableContent);
                    demoActivity = DemoActivity.this;
                    demoActivity.editspannableContent = new SpannableString(demoActivity.editmsg.getText());
                    DemoActivity.this.editspannableContent.setSpan(new UnderlineSpan(), 0, DemoActivity.this.editmsg.getText().length(), 0);
                    DemoActivity.this.editmsg.setText(DemoActivity.this.editspannableContent);
                    DemoActivity.isunderline = Boolean.valueOf(true);
                }
                DemoActivity.this.applyFont();
            }
        });
        this.fontstyle[0] = findViewById(R.id.txt1);
        this.fontstyle[1] = findViewById(R.id.txt2);
        this.fontstyle[2] = findViewById(R.id.txt3);
        this.fontstyle[3] = findViewById(R.id.txt4);
        this.fontstyle[4] = findViewById(R.id.txt5);
        this.fontstyle[5] = findViewById(R.id.txt6);
        this.fontstyle[6] = findViewById(R.id.txt7);
        this.fontstyle[7] = findViewById(R.id.txt8);
        this.fontstyle[8] = findViewById(R.id.txt9);
        this.fontstyle[9] = findViewById(R.id.txt10);
        this.fontstyle[10] = findViewById(R.id.txt11);
        this.fontstyle[11] = findViewById(R.id.txt12);
        this.fontstyle[12] = findViewById(R.id.txt13);
        this.fontstyle[13] = findViewById(R.id.txt14);
        this.fontstyle[14] = findViewById(R.id.txt15);
        this.fontstyle[15] = findViewById(R.id.txt16);
        this.fontstyle[16] = findViewById(R.id.txt17);
        this.fontstyle[17] = findViewById(R.id.txt18);
        this.btnarray[0] = findViewById(R.id.btn1);
        this.btnarray[1] = findViewById(R.id.btn2);
        this.btnarray[2] = findViewById(R.id.btn3);
        this.btnarray[3] = findViewById(R.id.btn4);
        this.btnarray[4] = findViewById(R.id.btn5);
        this.btnarray[5] = findViewById(R.id.btn6);
        this.btnarray[6] = findViewById(R.id.btn7);
        this.btnarray[7] = findViewById(R.id.btn8);
        this.btnarray[8] = findViewById(R.id.btn9);
        this.btnarray[9] = findViewById(R.id.btn10);
        this.btnarray[10] = findViewById(R.id.btn11);
        this.btnarray[11] = findViewById(R.id.btn12);
        this.btnarray[12] = findViewById(R.id.btn13);
        this.btnarray[13] = findViewById(R.id.btn14);
        this.btnarray[14] = findViewById(R.id.btn15);
        this.btnarray[15] = findViewById(R.id.btn16);
        this.btnarray[16] = findViewById(R.id.btn17);
        this.btnarray[17] = findViewById(R.id.btn18);
        this.btnarray[18] = findViewById(R.id.btn19);
        this.btnarray[19] = findViewById(R.id.btn20);
        this.btnarray[20] = findViewById(R.id.btn21);
        this.btnarray[21] = findViewById(R.id.btn22);
        this.btnarray[22] = findViewById(R.id.btn23);
        this.btnarray[23] = findViewById(R.id.btn24);
        this.btnarray[24] = findViewById(R.id.btn25);
        this.btnarray[25] = findViewById(R.id.btn26);
        this.btnarray[26] = findViewById(R.id.btn27);
        this.btnarray[27] = findViewById(R.id.btn28);
        i = 0;
        while (true) {
            Button[] buttonArr = this.btnarray;
            if (i >= buttonArr.length) {
                break;
            }
            buttonArr[i].setOnClickListener(this.click);
            this.btnarray[i].setTag(Integer.valueOf(i));
            i++;
        }
        while (i2 < this.fonts.length) {
            this.fontstyle[i2].setOnClickListener(this.fontclick);
            this.fontstyle[i2].setTag(Integer.valueOf(i2));
            this.fontstyle[i2].setTypeface(Typeface.createFromAsset(getAssets(), this.fonts[i2]));
            i2++;
        }
        this.txtmsg.bringToFront();
        this.DownPT = new PointF();
        this.StartPT = new PointF();
        this.txtmsg.setOnTouchListener(this);
        this.txtmsg.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DemoActivity.this.txtmsg.setOnTouchListener(null);
            }
        });
        this.txtmsg.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View view) {
                DemoActivity.this.txtmsg.setOnTouchListener(DemoActivity.this);
                return false;
            }
        });
        this.moveimg.setVisibility(View.INVISIBLE);
        this.bgimg.getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {
            public boolean onPreDraw() {
                DemoActivity.this.setTextViewWidth();
                return true;
            }
        });
        this.moveimg.setOnTouchListener(new OnTouchListener() {

            public boolean onTouch(View r8, MotionEvent r9) {
                /*
                r7 = this;
                r8 = (android.widget.ImageView) r8;
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0.dumpEvent(r9);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0.hideSoftKeyboard();
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.editmsg;
                r1 = 4;
                r0.setVisibility(r1);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.txtmsg;
                r2 = 0;
                r0.setVisibility(r2);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.changedtxt;
                if (r0 == 0) goto L_0x0072;
            L_0x0022:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.txtmsg;
                r3 = com.waf.wifemessages.DemoActivity.this;
                r3 = r3.changedtxt;
                r0.setText(r3);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.txtviewy;
                r3 = com.waf.wifemessages.DemoActivity.this;
                r3 = r3.changedtxt;
                r0.setText(r3);
                r0 = com.waf.wifemessages.DemoActivity.isunderline;
                r0 = r0.booleanValue();
                if (r0 == 0) goto L_0x0072;
            L_0x0040:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r3 = new android.text.SpannableString;
                r4 = r0.txtmsg;
                r4 = r4.getText();
                r3.<init>(r4);
                r0.spannableContent = r3;
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.spannableContent;
                r3 = new android.text.style.UnderlineSpan;
                r3.<init>();
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.txtmsg;
                r4 = r4.getText();
                r4 = r4.length();
                r0.setSpan(r3, r2, r4, r2);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.txtmsg;
                r3 = com.waf.wifemessages.DemoActivity.this;
                r3 = r3.spannableContent;
                r0.setText(r3);
            L_0x0072:
                r0 = r9.getAction();
                r0 = r0 & 255;
                r3 = 1;
                if (r0 == 0) goto L_0x0170;
            L_0x007b:
                if (r0 == r3) goto L_0x016b;
            L_0x007d:
                r4 = 1092616192; // 0x41200000 float:10.0 double:5.398241246E-315;
                r5 = 2;
                if (r0 == r5) goto L_0x00ba;
            L_0x0082:
                r1 = 5;
                if (r0 == r1) goto L_0x008a;
            L_0x0085:
                r9 = 6;
                if (r0 == r9) goto L_0x016b;
            L_0x0088:
                goto L_0x018e;
            L_0x008a:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r1 = r0.spacing(r9);
                r1 = java.lang.Float.valueOf(r1);
                r0.oldDist = r1;
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.oldDist;
                r0 = r0.floatValue();
                r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1));
                if (r0 <= 0) goto L_0x018e;
            L_0x00a2:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.savedMatrix;
                r1 = com.waf.wifemessages.DemoActivity.this;
                r1 = r1.matrix;
                r0.set(r1);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r1 = r0.mid;
                r0.midPoint(r1, r9);
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9.mode = r5;
                goto L_0x018e;
            L_0x00ba:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.mode;
                if (r0 != r3) goto L_0x00ea;
            L_0x00c0:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.matrix;
                r1 = com.waf.wifemessages.DemoActivity.this;
                r1 = r1.savedMatrix;
                r0.set(r1);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.matrix;
                r1 = r9.getX();
                r2 = com.waf.wifemessages.DemoActivity.this;
                r2 = r2.start;
                r2 = r2.x;
                r1 = r1 - r2;
                r9 = r9.getY();
                r2 = com.waf.wifemessages.DemoActivity.this;
                r2 = r2.start;
                r2 = r2.y;
                r9 = r9 - r2;
                r0.postTranslate(r1, r9);
                goto L_0x018e;
            L_0x00ea:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.mode;
                if (r0 != r5) goto L_0x018e;
            L_0x00f0:
                r0 = 9;
                r0 = new float[r0];
                r5 = com.waf.wifemessages.DemoActivity.this;
                r9 = r5.spacing(r9);
                r4 = (r9 > r4 ? 1 : (r9 == r4 ? 0 : -1));
                if (r4 <= 0) goto L_0x0125;
            L_0x00fe:
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.matrix;
                r5 = com.waf.wifemessages.DemoActivity.this;
                r5 = r5.savedMatrix;
                r4.set(r5);
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.oldDist;
                r4 = r4.floatValue();
                r9 = r9 / r4;
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.matrix;
                r5 = com.waf.wifemessages.DemoActivity.this;
                r5 = r5.mid;
                r5 = r5.x;
                r6 = com.waf.wifemessages.DemoActivity.this;
                r6 = r6.mid;
                r6 = r6.y;
                r4.postScale(r9, r9, r5, r6);
            L_0x0125:
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9 = r9.matrix;
                r9.getValues(r0);
                r9 = r0[r2];
                r0 = r0[r1];
                r1 = 1060320051; // 0x3f333333 float:0.7 double:5.23867711E-315;
                r2 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1));
                if (r2 > 0) goto L_0x014e;
            L_0x0137:
                r2 = com.waf.wifemessages.DemoActivity.this;
                r2 = r2.matrix;
                r9 = r1 / r9;
                r1 = r1 / r0;
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.mid;
                r0 = r0.x;
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.mid;
                r4 = r4.y;
                r2.postScale(r9, r1, r0, r4);
                goto L_0x018e;
            L_0x014e:
                r1 = 1084227584; // 0x40a00000 float:5.0 double:5.356796015E-315;
                r2 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1));
                if (r2 < 0) goto L_0x018e;
            L_0x0154:
                r2 = com.waf.wifemessages.DemoActivity.this;
                r2 = r2.matrix;
                r9 = r1 / r9;
                r1 = r1 / r0;
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.mid;
                r0 = r0.x;
                r4 = com.waf.wifemessages.DemoActivity.this;
                r4 = r4.mid;
                r4 = r4.y;
                r2.postScale(r9, r1, r0, r4);
                goto L_0x018e;
            L_0x016b:
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9.mode = r2;
                goto L_0x018e;
            L_0x0170:
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.savedMatrix;
                r1 = com.waf.wifemessages.DemoActivity.this;
                r1 = r1.matrix;
                r0.set(r1);
                r0 = com.waf.wifemessages.DemoActivity.this;
                r0 = r0.start;
                r1 = r9.getX();
                r9 = r9.getY();
                r0.set(r1, r9);
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9.mode = r3;
            L_0x018e:
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9 = r9.moveimg;
                r9 = r9.isShown();
                if (r9 == 0) goto L_0x01a6;
            L_0x0198:
                r9 = com.waf.wifemessages.DemoActivity.this;
                r0 = r9.matrix;
                r9.limitDrag(r0, r8);
                r9 = com.waf.wifemessages.DemoActivity.this;
                r9 = r9.matrix;
                r8.setImageMatrix(r9);
            L_0x01a6:
                return r3;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.waf.wifemessages.DemoActivity$AnonymousClass16.onTouch(android.view.View, android.view.MotionEvent):boolean");
            }
        });
        this.uploadbtn.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (DemoActivity.this.images.equals("yes")) {
                    Intent intent = new Intent("android.intent.action.PICK");
                    intent.setType("image/*");
                    DemoActivity demoActivity = DemoActivity.this;
                    demoActivity.startActivityForResult(intent, demoActivity.RESULT_LOAD_IMG);
                }
            }
        });
        setTextViewWidth();
    }


    public Bitmap ShrinkBitmap(String str, int i, int i2) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        i2 = (int) Math.ceil(((float) options.outHeight) / ((float) i2));
        i = (int) Math.ceil(((float) options.outWidth) / ((float) i));
        if (i2 > 1 || i > 1) {
            if (i2 > i) {
                options.inSampleSize = i2;
            } else {
                options.inSampleSize = i;
            }
        }
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    public void setTextViewWidth() {
        ViewGroup.LayoutParams layoutParams;
        double d;
        double d2;
        if ((this.context.getResources().getConfiguration().screenLayout & 15) == 4) {
            layoutParams = this.bgimg.getLayoutParams();
            double d3 = this.windowwidth;
            Double.isNaN(d3);
            layoutParams.width = (int) (d3 * 0.75d);
            layoutParams = this.bgimg.getLayoutParams();
            d3 = this.windowheight;
            Double.isNaN(d3);
            layoutParams.height = (int) (d3 * 0.7d);
            this.imgheight = this.bgimg.getMeasuredHeight();
            this.imgwidth = this.bgimg.getMeasuredWidth();
            layoutParams = this.txtmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.75d);
            layoutParams = this.editmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.75d);
            this.x = this.bgimg.getX();
            this.y = this.bgimg.getY();
            layoutParams = this.rel1.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.75d);
        } else if ((this.context.getResources().getConfiguration().screenLayout & 15) == 3) {
            layoutParams = this.bgimg.getLayoutParams();
            d2 = this.windowwidth;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.8d);
            layoutParams = this.bgimg.getLayoutParams();
            d2 = this.windowheight;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.7d);
            this.imgheight = this.bgimg.getMeasuredHeight();
            this.imgwidth = this.bgimg.getMeasuredWidth();
            layoutParams = this.txtmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
            layoutParams = this.editmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
            this.x = this.bgimg.getX();
            this.y = this.bgimg.getY();
            layoutParams = this.rel1.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
        } else {
            layoutParams = this.bgimg.getLayoutParams();
            d2 = this.windowwidth;
            Double.isNaN(d2);
            layoutParams.width = (int) (d2 * 0.8d);
            layoutParams = this.bgimg.getLayoutParams();
            d2 = this.windowheight;
            Double.isNaN(d2);
            layoutParams.height = (int) (d2 * 0.7d);
            this.imgheight = this.bgimg.getMeasuredHeight();
            this.imgwidth = this.bgimg.getMeasuredWidth();
            layoutParams = this.txtmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
            layoutParams = this.editmsg.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
            this.x = this.bgimg.getX();
            this.y = this.bgimg.getY();
            layoutParams = this.rel1.getLayoutParams();
            d = this.windowwidth;
            Double.isNaN(d);
            layoutParams.width = (int) (d * 0.8d);
        }
    }

    private void limitDrag(Matrix matrix, ImageView imageView) {
        float[] fArr = new float[9];
        matrix.getValues(fArr);
        float f = fArr[2];
        float f2 = fArr[5];
        float f3 = fArr[0];
        f3 = fArr[4];
        Rect bounds = imageView.getDrawable().getBounds();
        int i = getResources().getDisplayMetrics().widthPixels;
        int i2 = getResources().getDisplayMetrics().heightPixels;
        if (i2 <= 480) {
            this._y_up = 0;
        }
        if (i2 > 480 && i2 < 980) {
            this._y_up = 140;
        }
        int i3 = bounds.right;
        i3 = bounds.left;
        i3 = bounds.bottom;
        int i4 = bounds.top;
        float f4 = (float) (-(i / 2));
        float f5 = (float) (-(i2 / 2));
        float f6 = (float) i;
        if (f > f6) {
            f = f6;
        } else if (f < f4) {
            f = f4;
        }
        float f7 = -f;
        if (f7 > f6) {
            f = (float) (-i);
        } else if (f7 < f4) {
            f = -(f4 + 30.0f);
        }
        f4 = (float) i2;
        if (f2 > f4) {
            f2 = f4;
        } else if (f2 < f5) {
            f2 = ((float) this._y_up) + f5;
        }
        f3 = -f2;
        if (f3 > f4) {
            f2 = (float) (-i2);
        } else if (f3 < f5) {
            f2 = -(f5 + 170.0f);
        }
        fArr[2] = f;
        fArr[5] = f2;
        matrix.setValues(fArr);
    }

    private void dumpEvent(MotionEvent motionEvent) {
        String[] string = new String[10];
        int i = 0;
        string[0] = "DOWN";
        string[1] = "UP";
        string[2] = "MOVE";
        string[3] = "CANCEL";
        string[4] = "OUTSIDE";
        string[5] = "POINTER_DOWN";
        string[6] = "POINTER_UP";
        string[7] = "7?";
        string[8] = "8?";
        string[9] = "9?";
        StringBuilder stringBuilder = new StringBuilder();
        int action = motionEvent.getAction();
        int i2 = action & 255;
        stringBuilder.append("event ACTION_");
        stringBuilder.append(string[i2]);
        String str = "(pid ";
        if (i2 == 5 || i2 == 6) {
            stringBuilder.append(str);
            stringBuilder.append(action >> 8);
            stringBuilder.append(")");
        }
        stringBuilder.append(Constants.RequestParameters.LEFT_BRACKETS);
        while (i < motionEvent.getPointerCount()) {
            stringBuilder.append("#");
            stringBuilder.append(i);
            stringBuilder.append(str);
            stringBuilder.append(motionEvent.getPointerId(i));
            stringBuilder.append(")=");
            stringBuilder.append((int) motionEvent.getX(i));
            stringBuilder.append(",");
            stringBuilder.append((int) motionEvent.getY(i));
            i++;
            if (i < motionEvent.getPointerCount()) {
                stringBuilder.append(";");
            }
        }
        stringBuilder.append(Constants.RequestParameters.RIGHT_BRACKETS);
    }

    private float spacing(MotionEvent motionEvent) {
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((x * x) + (y * y));
    }

    private void midPoint(PointF pointF, MotionEvent motionEvent) {
        pointF.set((motionEvent.getX(0) + motionEvent.getX(1)) / 2.0f, (motionEvent.getY(0) + motionEvent.getY(1)) / 2.0f);
    }

    /* Access modifiers changed, original: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        String str = "...";
        super.onActivityResult(i, i2, intent);
        if (i2 == -1) {
            try {
                InputStream openInputStream = getContentResolver().openInputStream(intent.getData());
                Options options = new Options();
                options.inSampleSize = 1;
                Bitmap decodeStream = BitmapFactory.decodeStream(openInputStream, null, options);
                this.imageHeight = decodeStream.getHeight();
                this.imageWidth = decodeStream.getWidth();
                Uri data = intent.getData();
                imgheightwidth_calculation();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(this.imageHeight);
                stringBuilder.append(str);
                stringBuilder.append(this.imageWidth);
                stringBuilder.append(str);
                Log.e("Imagefetch_hw", stringBuilder.toString());
                Picasso.get().load(data).resize(this.imageWidth, this.imageHeight).into(this.moveimg);
                this.moveimg.setVisibility(View.VISIBLE);
                return;
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(e.getMessage());
                Log.e("Imagefetch", stringBuilder2.toString());
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
                return;
            }
        }
        Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
    }

    public void imgheightwidth_calculation() {
        int i = this.imageHeight;
        int i2 = this.imageWidth;
        if (i > i2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("h&w...");
            stringBuilder.append(this.imageHeight);
            String str = ".....";
            stringBuilder.append(str);
            stringBuilder.append(this.imageWidth);
            String str2 = "Imagefetch";
            Log.e(str2, stringBuilder.toString());
            i = this.imageWidth;
            int i3 = this.default_height;
            this.imageWidth = (i * i3) / this.imageHeight;
            this.imageHeight = i3;
            stringBuilder = new StringBuilder();
            stringBuilder.append("calculatedval...");
            stringBuilder.append(this.imageHeight);
            stringBuilder.append(str);
            stringBuilder.append(this.imageWidth);
            Log.e(str2, stringBuilder.toString());
        } else if (i2 > i) {
            int i4 = this.default_width;
            this.imageHeight = (i * i4) / i2;
            this.imageWidth = i4;
        } else if (i == i2) {
            this.imageHeight = this.default_height;
            this.imageWidth = this.default_width;
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int action = motionEvent.getAction();
        if (action == 0) {
            this.dX = view.getX() - motionEvent.getRawX();
            this.dY = view.getY() - motionEvent.getRawY();
        } else if (action != 2) {
            return false;
        } else {
            action = (int) (motionEvent.getRawX() + this.dX);
            if (((float) action) < this.bgimg.getX()) {
                action = (int) this.bgimg.getX();
            }
            if (((float) (this.txtmsg.getWidth() + action)) > this.txtview.getX()) {
                action = (int) this.txtmsg.getX();
            }
            int rawY = (int) (motionEvent.getRawY() + this.dY);
            if (rawY < 0) {
                rawY = (int) this.bgimg.getY();
            }
            if (((float) rawY) > this.txtviewy.getY()) {
                rawY = (int) this.txtviewy.getY();
            }
            view.animate().x((float) action).y((float) rawY).setDuration(0).start();
        }
        return true;
    }

    public void applyFont() {
        TextView textView;
        EditText editText;
        if (isitalic.booleanValue() && isbold.booleanValue() && isunderline.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD_ITALIC);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.BOLD_ITALIC);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.BOLD_ITALIC);
        } else if (isbold.booleanValue() && isitalic.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD_ITALIC);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.BOLD_ITALIC);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.BOLD_ITALIC);
        } else if (isbold.booleanValue() && isunderline.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.NORMAL);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.NORMAL);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.NORMAL);
        } else if (isitalic.booleanValue() && isunderline.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.ITALIC);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.ITALIC);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.ITALIC);
        } else if (isbold.booleanValue() && !isitalic.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.NORMAL);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.NORMAL);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.NORMAL);
        } else if (isitalic.booleanValue() && !isbold.booleanValue()) {
            textView = this.txtmsg;
            textView.setTypeface(textView.getTypeface(), Typeface.ITALIC);
            this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.ITALIC);
            editText = this.editmsg;
            editText.setTypeface(editText.getTypeface(), Typeface.ITALIC);
        }
        if (isbold.booleanValue() || isitalic.booleanValue() || isunderline.booleanValue()) {
            if (isbold.booleanValue() && !isitalic.booleanValue() && !isunderline.booleanValue()) {
                textView = this.txtmsg;
                textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
                this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.BOLD);
                editText = this.editmsg;
                editText.setTypeface(editText.getTypeface(), Typeface.BOLD);
            } else if (!isbold.booleanValue() && isitalic.booleanValue() && !isunderline.booleanValue()) {
                textView = this.txtmsg;
                textView.setTypeface(textView.getTypeface(), Typeface.ITALIC);
                this.txtviewy.setTypeface(this.txtmsg.getTypeface(), Typeface.ITALIC);
                editText = this.editmsg;
                editText.setTypeface(editText.getTypeface(), Typeface.ITALIC);
            }
        } else if (this.txttypeface != null) {
            this.txtmsg.setTypeface(Typeface.createFromAsset(getAssets(), this.txttypeface));
            this.txtviewy.setTypeface(Typeface.createFromAsset(getAssets(), this.txttypeface));
            this.editmsg.setTypeface(Typeface.createFromAsset(getAssets(), this.txttypeface));
        } else {
            this.txtmsg.setTypeface(null, Typeface.NORMAL);
            this.txtviewy.setTypeface(null, Typeface.NORMAL);
            this.editmsg.setTypeface(null, Typeface.NORMAL);
        }
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        int i2 = i;
        int i3;
        if ((this.context.getResources().getConfiguration().screenLayout & 15) == 4) {
            if (i2 > 0 && i2 <= 7) {
                this.txtmsg.setTextSize(23.5f);
                this.txtviewy.setTextSize(23.5f);
                this.editmsg.setTextSize(23.5f);
            }
            if (i2 > 7 && i2 <= 14) {
                this.txtmsg.setTextSize(24.0f);
                this.txtviewy.setTextSize(24.0f);
                this.editmsg.setTextSize(24.0f);
            }
            if (i2 > 14 && i2 <= 21) {
                this.txtmsg.setTextSize(24.5f);
                this.txtviewy.setTextSize(24.5f);
                this.editmsg.setTextSize(24.5f);
            }
            if (i2 > 21 && i2 <= 28) {
                this.txtmsg.setTextSize(25.0f);
                this.txtviewy.setTextSize(25.0f);
                this.editmsg.setTextSize(25.0f);
            }
            if (i2 > 28 && i2 <= 35) {
                this.txtmsg.setTextSize(25.5f);
                this.txtviewy.setTextSize(25.5f);
                this.editmsg.setTextSize(25.5f);
            }
            if (i2 > 35 && i2 <= 42) {
                this.txtmsg.setTextSize(26.0f);
                this.txtviewy.setTextSize(26.0f);
                this.editmsg.setTextSize(26.0f);
            }
            i3 = 49;
            if (i2 > 42 && i2 <= 49) {
                this.txtmsg.setTextSize(26.5f);
                this.txtviewy.setTextSize(26.5f);
                this.editmsg.setTextSize(26.5f);
                i3 = 49;
            }
            if (i2 > i3 && i2 <= 56) {
                this.txtmsg.setTextSize(27.0f);
                this.txtviewy.setTextSize(27.0f);
                this.editmsg.setTextSize(27.0f);
            }
            if (i2 > 56 && i2 <= 63) {
                this.txtmsg.setTextSize(27.5f);
                this.txtviewy.setTextSize(27.5f);
                this.editmsg.setTextSize(27.5f);
            }
            if (i2 > 63 && i2 <= 70) {
                this.txtmsg.setTextSize(28.0f);
                this.txtviewy.setTextSize(28.0f);
                this.editmsg.setTextSize(28.0f);
            }
            if (i2 > 70 && i2 <= 77) {
                this.txtmsg.setTextSize(28.5f);
                this.txtviewy.setTextSize(28.5f);
                this.editmsg.setTextSize(28.5f);
            }
            if (i2 > 77 && i2 <= 84) {
                this.txtmsg.setTextSize(29.0f);
                this.txtviewy.setTextSize(29.0f);
                this.editmsg.setTextSize(29.0f);
            }
            if (i2 > 84 && i2 <= 91) {
                this.txtmsg.setTextSize(29.5f);
                this.txtviewy.setTextSize(29.5f);
                this.editmsg.setTextSize(29.5f);
            }
            if (i2 > 91 && i2 <= 100) {
                this.txtmsg.setTextSize(30.0f);
                this.txtviewy.setTextSize(30.0f);
                this.editmsg.setTextSize(30.0f);
            }
        } else if ((this.context.getResources().getConfiguration().screenLayout & 15) == 3) {
            if (i2 > 0 && i2 <= 7) {
                this.txtmsg.setTextSize(20.5f);
                this.txtviewy.setTextSize(20.5f);
                this.editmsg.setTextSize(20.5f);
            }
            if (i2 > 7 && i2 <= 14) {
                this.txtmsg.setTextSize(21.0f);
                this.txtviewy.setTextSize(21.0f);
                this.editmsg.setTextSize(21.0f);
            }
            if (i2 > 14 && i2 <= 21) {
                this.txtmsg.setTextSize(21.5f);
                this.txtviewy.setTextSize(21.5f);
                this.editmsg.setTextSize(21.5f);
            }
            if (i2 > 21 && i2 <= 28) {
                this.txtmsg.setTextSize(22.0f);
                this.txtviewy.setTextSize(22.0f);
                this.editmsg.setTextSize(22.0f);
            }
            if (i2 > 28 && i2 <= 35) {
                this.txtmsg.setTextSize(22.5f);
                this.txtviewy.setTextSize(22.5f);
                this.editmsg.setTextSize(22.5f);
            }
            if (i2 > 35 && i2 <= 42) {
                this.txtmsg.setTextSize(23.0f);
                this.txtviewy.setTextSize(23.0f);
                this.editmsg.setTextSize(23.0f);
            }
            if (i2 > 42 && i2 <= 49) {
                this.txtmsg.setTextSize(23.5f);
                this.txtviewy.setTextSize(23.5f);
                this.editmsg.setTextSize(23.5f);
            }
            if (i2 > 49 && i2 <= 56) {
                this.txtmsg.setTextSize(24.0f);
                this.txtviewy.setTextSize(24.0f);
                this.editmsg.setTextSize(24.0f);
            }
            if (i2 > 56 && i2 <= 63) {
                this.txtmsg.setTextSize(24.5f);
                this.txtviewy.setTextSize(24.5f);
                this.editmsg.setTextSize(24.5f);
            }
            if (i2 > 63 && i2 <= 70) {
                this.txtmsg.setTextSize(25.0f);
                this.txtviewy.setTextSize(25.0f);
                this.editmsg.setTextSize(25.0f);
            }
            if (i2 > 70 && i2 <= 77) {
                this.txtmsg.setTextSize(25.5f);
                this.txtviewy.setTextSize(25.5f);
                this.editmsg.setTextSize(25.5f);
            }
            if (i2 > 77 && i2 <= 84) {
                this.txtmsg.setTextSize(26.0f);
                this.txtviewy.setTextSize(26.0f);
                this.editmsg.setTextSize(26.0f);
            }
            if (i2 > 84 && i2 <= 91) {
                this.txtmsg.setTextSize(26.5f);
                this.txtviewy.setTextSize(26.5f);
                this.editmsg.setTextSize(26.5f);
            }
            if (i2 > 91 && i2 <= 100) {
                this.txtmsg.setTextSize(27.0f);
                this.txtviewy.setTextSize(27.0f);
                this.editmsg.setTextSize(27.0f);
            }
        } else {
            if (i2 > 0 && i2 <= 7) {
                this.txtmsg.setTextSize(14.5f);
                this.txtviewy.setTextSize(14.5f);
                this.editmsg.setTextSize(14.5f);
            }
            if (i2 > 7 && i2 <= 14) {
                this.txtmsg.setTextSize(15.0f);
                this.txtviewy.setTextSize(15.0f);
                this.editmsg.setTextSize(15.0f);
            }
            if (i2 > 14 && i2 <= 21) {
                this.txtmsg.setTextSize(15.5f);
                this.txtviewy.setTextSize(15.5f);
                this.editmsg.setTextSize(15.5f);
            }
            if (i2 > 21 && i2 <= 28) {
                this.txtmsg.setTextSize(16.0f);
                this.txtviewy.setTextSize(16.0f);
                this.editmsg.setTextSize(16.0f);
            }
            if (i2 > 28 && i2 <= 35) {
                this.txtmsg.setTextSize(16.5f);
                this.txtviewy.setTextSize(16.5f);
                this.editmsg.setTextSize(16.5f);
            }
            if (i2 > 35 && i2 <= 42) {
                this.txtmsg.setTextSize(17.0f);
                this.txtviewy.setTextSize(17.0f);
                this.editmsg.setTextSize(17.0f);
            }
            i3 = 49;
            if (i2 > 42 && i2 <= 49) {
                this.txtmsg.setTextSize(17.5f);
                this.txtviewy.setTextSize(17.5f);
                this.editmsg.setTextSize(17.5f);
                i3 = 49;
            }
            if (i2 > i3 && i2 <= 56) {
                this.txtmsg.setTextSize(18.0f);
                this.txtviewy.setTextSize(18.0f);
                this.editmsg.setTextSize(18.0f);
            }
            if (i2 > 56 && i2 <= 63) {
                this.txtmsg.setTextSize(18.5f);
                this.txtviewy.setTextSize(18.5f);
                this.editmsg.setTextSize(18.5f);
            }
            if (i2 > 63 && i2 <= 70) {
                this.txtmsg.setTextSize(19.0f);
                this.txtviewy.setTextSize(19.0f);
                this.editmsg.setTextSize(19.0f);
            }
            if (i2 > 70 && i2 <= 77) {
                this.txtmsg.setTextSize(19.5f);
                this.txtviewy.setTextSize(19.5f);
                this.editmsg.setTextSize(19.5f);
            }
            if (i2 > 77 && i2 <= 84) {
                this.txtmsg.setTextSize(20.0f);
                this.txtviewy.setTextSize(20.0f);
                this.editmsg.setTextSize(20.0f);
            }
            if (i2 > 84 && i2 <= 91) {
                this.txtmsg.setTextSize(20.5f);
                this.txtviewy.setTextSize(20.5f);
                this.editmsg.setTextSize(20.5f);
            }
            if (i2 > 91 && i2 <= 100) {
                this.txtmsg.setTextSize(21.0f);
                this.txtviewy.setTextSize(21.0f);
                this.editmsg.setTextSize(21.0f);
            }
        }
    }

    public void saveImage() {
        File file = new File("/sdcard/greeting/");
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.number);
        stringBuilder.append(".jpg");
        this.output = new File(file, stringBuilder.toString());
        if (this.editmsg.isShown()) {
            this.editmsg.setVisibility(View.INVISIBLE);
            this.txtmsg.setVisibility(View.VISIBLE);
            String str = this.changedtxt;
            if (str != null) {
                this.txtmsg.setText(str);
                if (isunderline.booleanValue()) {
                    this.spannableContent = new SpannableString(this.txtmsg.getText());
                    this.spannableContent.setSpan(new UnderlineSpan(), 0, this.txtmsg.getText().length(), 0);
                    this.txtmsg.setText(this.spannableContent);
                }
            }
        }
        View findViewById = findViewById(R.id.rel1);
        findViewById.setDrawingCacheEnabled(true);
        Bitmap drawingCache = findViewById.getDrawingCache();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(this.output);
            drawingCache.compress(CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            this.snackbar = Snackbar.make(this.coordinatorLayout, "Image is saved in Gallery", 10000).setAction("Share", new OnClickListener() {
                public void onClick(View view) {
                    String str = "<br>";
                    try {
                        TextView textView = new TextView(DemoActivity.this);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(DemoActivity.this.getResources().getString(R.string.fromshare));
                        stringBuilder.append(str);
                        stringBuilder.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                        textView.setText(Html.fromHtml(stringBuilder.toString()));
                        View findViewById = DemoActivity.this.findViewById(R.id.rel1);
                        findViewById.setDrawingCacheEnabled(true);
                        Uri parse = Uri.parse(Media.insertImage(DemoActivity.this.getContentResolver(), findViewById.getDrawingCache(), "title", null));
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.setType("image/*");
                        intent.putExtra("android.intent.extra.SUBJECT", DemoActivity.this.getResources().getString(R.string.appname));
                        intent.putExtra("android.intent.extra.STREAM", parse);
                        intent.putExtra("android.intent.extra.TEXT", textView.getText().toString().replaceAll(str, "\n"));
                        DemoActivity.this.startActivity(intent);
                    } catch (Exception unused) {
                        Toast.makeText(DemoActivity.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                    }
                }
            });
            this.snackbar.show();
            MediaScannerConnection.scanFile(getApplicationContext(), new String[]{this.output.toString()}, null, new OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                    Log.d("appname", "image is saved in gallery and gallery is refreshed.");
                }
            });
        } catch (Exception unused) {
            Toast.makeText(this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        for (int i = 0; i < menu.size(); i++) {
            menu.getItem(i).setShowAsAction(2);
        }
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        String str = "<br>";
        if (ContextCompat.checkSelfPermission(this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            Toast.makeText(this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
            checkAndRequestPermissions();
        } else {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.doneicon) {
                saveImage();
            }
            if (itemId == R.id.share) {
                AddRateClicks();
                try {
                    TextView textView = new TextView(this);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(getResources().getString(R.string.fromshare));
                    stringBuilder.append(str);
                    stringBuilder.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    textView.setText(Html.fromHtml(stringBuilder.toString()));
                    View findViewById = findViewById(R.id.rel1);
                    findViewById.setDrawingCacheEnabled(true);
                    Uri parse = Uri.parse(Media.insertImage(getContentResolver(), findViewById.getDrawingCache(), "title", null));
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("image/*");
                    intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.appname));
                    intent.putExtra("android.intent.extra.STREAM", parse);
                    intent.putExtra("android.intent.extra.TEXT", textView.getText().toString().replaceAll(str, "\n"));
                    startActivity(intent);
                } catch (Exception e) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(">>>>>>>");
                    stringBuilder2.append(e);
                    Log.e("Exception share", stringBuilder2.toString());
                    Toast.makeText(this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                }
            }
        }
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private boolean checkAndRequestPermissions() {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        int checkSelfPermission = ContextCompat.checkSelfPermission(this.context, str);
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission != 0) {
            arrayList.add(str);
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
        return false;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 111 && iArr.length > 0) {
            i = iArr[0];
        }
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        View currentFocus = getCurrentFocus();
        if (currentFocus != null && ((motionEvent.getAction() == 1 || motionEvent.getAction() == 2) && (currentFocus instanceof EditText) && !currentFocus.getClass().getName().startsWith("android.webkit."))) {
            int[] iArr = new int[2];
            currentFocus.getLocationOnScreen(iArr);
            float rawX = (motionEvent.getRawX() + ((float) currentFocus.getLeft())) - ((float) iArr[0]);
            float rawY = (motionEvent.getRawY() + ((float) currentFocus.getTop())) - ((float) iArr[1]);
            if (rawX < ((float) currentFocus.getLeft()) || rawX > ((float) currentFocus.getRight()) || rawY < ((float) currentFocus.getTop()) || rawY > ((float) currentFocus.getBottom())) {
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindow().getDecorView().getApplicationWindowToken(), 0);
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    /* Access modifiers changed, original: 0000 */
    public void RateAndReview1(Context context) {
        this.manager = ReviewManagerFactory.create(context);
        this.manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            public void onComplete(Task<ReviewInfo> task) {
                String str = "inapp reivew";
                if (task.isSuccessful()) {
                    DemoActivity.this.reviewInfo = task.getResult();
                    Log.e(str, "In-app REVIEW SUCCESSFUL");
                    return;
                }
                Log.e(str, "In-app REVIEW ERROR or FAILED or LIMIT COMPLETED");
            }
        });
    }

    public void RateAndReview() {
        String str = "inapp reivew";
        String str2 = "inappreview";
        if (sharedPreferences.getInt(str2, 0) > 6) {
            editor.putInt(str2, 1).apply();
        }
        try {
            if (this.manager != null) {
                if (this.reviewInfo != null) {
                    this.manager.launchReviewFlow(this, this.reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(Task<Void> task) {
                            Log.e("inapp reivew", "In-app REVIEW SUCCESSFUL");
                            DemoActivity.this.finish();
                        }
                    });
                    return;
                }
            }
            RATE_DIALOG();
            Log.e(str, "In-app REVIEW SUCCESSFUL NULL");
        } catch (Exception unused) {
            Log.e(str, "In-app REVIEW SUCCESSFUL ERROR");
            RATE_DIALOG();
        }
    }

    public void onBackPressed() {
        String str = "inappreview";
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview();
            return;
        }
        str = "rateagain";
        if (sharedPreferences.getInt(str, 0) > 12 || sharedPreferences.getInt("applaunched", 0) == 0) {
            editor.putInt(str, 0);
            editor.commit();
            RATE_DIALOG();
            return;
        }
        super.onBackPressed();
    }


    public void AddRateClicks() {
        String str = "rateagain";
        if (sharedPreferences.getInt(str, 0) < 13) {
            int i = sharedPreferences.getInt(str, 0) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            Log.e("clicks ", stringBuilder.toString());
        }
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        Button button = this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                DemoActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                DemoActivity.this.finish();
                DemoActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                DemoActivity.this.finish();
                DemoActivity.this.dialogR.cancel();
            }
        });
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
