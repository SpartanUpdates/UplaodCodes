package com.unitedvideos.Retrofit;

public class AppConstant {
    public static String BASEURL ="http://uvadmin.trendinganimations.com/public/api/";
    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "7";
}
