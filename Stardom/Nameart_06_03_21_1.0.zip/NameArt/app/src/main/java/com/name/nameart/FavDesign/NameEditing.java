package com.name.nameart.FavDesign;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.name.nameart.FavDesign.ShareScreen;
import com.name.nameart.MyUtils.MyPreference;
import com.name.nameart.R;
import com.name.nameart.ThropicalData.ThropicalStart;
import com.name.nameart.adapter.BGAdapter;
import com.name.nameart.adapter.ColorAdapter;
import com.name.nameart.adapter.CustomeColorSticker;
import com.name.nameart.adapter.FontAdapter;
import com.name.nameart.adapter.GradientAdapter;
import com.name.nameart.adapter.ImageTextShader;
import com.name.nameart.adapter.StickerAdapter;
import com.name.nameart.kprogresshud.KProgressHUD;
import com.name.nameart.motionview.MyTouchMation;
import com.name.nameart.sticker.StickerView;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

public class NameEditing extends AppCompatActivity {

    Activity activity = NameEditing.this;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";
    public static RelativeLayout contain_sticker;
    public static ArrayList<View> mViews;
    public static ArrayList<View> mViews_pic;
    public static RelativeLayout main_save_layout;
    public static RecyclerView recycle_bg;
    public static RecyclerView recycle_color;
    public static RecyclerView recycle_color_sticker_tint;
    public static RecyclerView recycle_font;
    public static RecyclerView recycle_gradient;
    public static RecyclerView recycle_sticker;
    public final int PICK_IMAGE = 1;
    public LinearLayout add_text__ll;
    public boolean bgSelected = false;
    public ImageView bg_img;
    public LinearLayout bg_ll;
    public int bgcolor = ViewCompat.MEASURED_STATE_MASK;
    public ImageView close_sticker_btn;
    public LinearLayout clr_ll;
    public TextView download;
    public FrameLayout dynamicStickerFrame;
    private Exception e;
    public FrameLayout flTextManager;
    public ImageView font;
    public LinearLayout font_ll;
    public LinearLayout gr_ll;
    public ImageView gradient;
    public LinearLayout hide_shadow;
    public LinearLayout imgShader_ll;
    public ImageView iv_shadow_switch;
    public LinearLayout llCatAngle;
    public LinearLayout llCatButterfly;
    public LinearLayout llCatCity;
    public LinearLayout llCatDevil;
    public LinearLayout llCatEar;
    public LinearLayout llCatFlower;
    public LinearLayout llCatHipster;
    public LinearLayout llCatKing;
    public LinearLayout llCatLion;
    public LinearLayout llCatMickyMouse;
    public LinearLayout llCatPanda;
    public LinearLayout llCatSmily;
    public LinearLayout llCatStar;
    public LinearLayout llCatdiwali;
    public LinearLayout llCatfeather;
    public LinearLayout llCatlines;
    public LinearLayout llCatlove;
    public LinearLayout ll_adjust_3d_text;
    public Bitmap mBitmap;
    public StickerView mCurrentView_pic;
    public SeekBar opacity_seek;
    public final int pick = 2;
    public String real_text = "";
    public RecyclerView recycle_imgShader;
    public LinearLayout recycles_sticker_editing;
    public Uri resultUri;
    public SeekBar rotate_seek_x;
    public SeekBar rotate_seek_y;
    public Boolean selected = false;
    public View selectedShadowSticker = null;
    public ScrollView shadow_content_layout;
    public SeekBar shadow_opacity_seek;
    public boolean shadow_switch_checked = true;
    public ImageView sticker;
    public LinearLayout sticker_category_ll;
    public LinearLayout sticker_ll;
    public LinearLayout sticker_pic_ll;
    public String tag = "";
    public ImageView text_background;
    public ImageView text_color;
    public LinearLayout text_edit_ll;
    public LinearLayout threeD_text;


    public KProgressHUD hud;
    private int id;
    public InterstitialAd mInterstitialAd;

    private UCrop basisConfig(UCrop uCrop) {
        return uCrop;
    }

    public void addShadowSticker(String str, int i) {
        final View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.shadow_view_child, (ViewGroup) null, false);
        TextView textView = (TextView) inflate.findViewById(R.id.realtext);
        TextView textView2 = (TextView) inflate.findViewById(R.id.flipedtext);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.delete_text);
        ImageView imageView2 = (ImageView) inflate.findViewById(R.id.shadow_img);
        ConstraintLayout constraintLayout = (ConstraintLayout) inflate.findViewById(R.id.shadowlayout1);
        if (this.bgSelected) {
            constraintLayout.setVisibility(View.GONE);
        } else {
            constraintLayout.setVisibility(View.VISIBLE);
            imageView2.setColorFilter(i);
        }
        imageView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    NameEditing.this.dynamicStickerFrame.removeView(inflate);
                    NameEditing.this.showSelectedRecycle(null);
                    NameEditing.this.text_edit_ll.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        textView.setText(str);
        textView2.setText(str);
        inflate.setTag("" + (System.currentTimeMillis() / 100));
        inflate.setOnTouchListener(new MyTouchMation(this, inflate.getTag().toString()));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        if (this.dynamicStickerFrame.getChildCount() == 0) {
            layoutParams.gravity = 17;
        }
        inflate.setLayoutParams(layoutParams);
        this.dynamicStickerFrame.addView(inflate);
    }

    public void setStickerSelectedByTag(String str) {
        for (int i = 0; i < this.dynamicStickerFrame.getChildCount(); i++) {
            if (this.dynamicStickerFrame.getChildAt(i).getTag().equals(str)) {
                this.selectedShadowSticker = this.dynamicStickerFrame.getChildAt(i);
                this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackgroundResource(R.drawable.border_textview);
                ((ImageView) this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.VISIBLE);
            } else {
                this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                ((ImageView) this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
            }
        }
        if (StickerAdapter.mCurrentView != null) {
            StickerAdapter.mCurrentView.setInEdit(false);
        }
        StickerView stickerView = this.mCurrentView_pic;
        if (stickerView != null) {
            stickerView.setInEdit(false);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_name_editing);
        this.dynamicStickerFrame = (FrameLayout) findViewById(R.id.dynamicStickerFrame);
        this.hide_shadow = (LinearLayout) findViewById(R.id.hide_shadow);
        this.ll_adjust_3d_text = (LinearLayout) findViewById(R.id.ll_adjust_3d_text);
        this.threeD_text = (LinearLayout) findViewById(R.id.threeD_text);
        this.rotate_seek_x = (SeekBar) findViewById(R.id.rotate_seek_x);
        this.rotate_seek_y = (SeekBar) findViewById(R.id.rotate_seek_y);
        this.opacity_seek = (SeekBar) findViewById(R.id.opacity_seek);
        this.shadow_opacity_seek = (SeekBar) findViewById(R.id.shadow_opacity_seek);
        this.iv_shadow_switch = (ImageView) findViewById(R.id.iv_shadow_switch);
        this.shadow_content_layout = (ScrollView) findViewById(R.id.shadow_content_layout);
        mViews = new ArrayList<>();
        mViews_pic = new ArrayList<>();
        recycle_gradient = (RecyclerView) findViewById(R.id.recycle_gradient);
        recycle_font = (RecyclerView) findViewById(R.id.recycle_font);
        recycle_sticker = (RecyclerView) findViewById(R.id.recycle_sticker);
        recycle_color = (RecyclerView) findViewById(R.id.recycle_color);
        recycle_bg = (RecyclerView) findViewById(R.id.recycle_bg);
        this.text_edit_ll = (LinearLayout) findViewById(R.id.text_edit_ll);
        this.close_sticker_btn = (ImageView) findViewById(R.id.close_sticker_btn);
        this.sticker_pic_ll = (LinearLayout) findViewById(R.id.sticker_pic_ll);
        this.bg_img = (ImageView) findViewById(R.id.bg_img);
        //recycle_color_sticker_tint = (RecyclerView) findViewById(R.id.recycle_color_sticker_tint);
        this.add_text__ll = (LinearLayout) findViewById(R.id.add_text__ll);
        this.recycles_sticker_editing = (LinearLayout) findViewById(R.id.recycles_sticker_editing);
        this.imgShader_ll = (LinearLayout) findViewById(R.id.imgShader_ll);
        this.recycle_imgShader = (RecyclerView) findViewById(R.id.recycle_imgShader);

        findViews();
        interstitialAd();

        set_layout_listners();

        this.gradient = (ImageView) findViewById(R.id.gradient);
        this.font = (ImageView) findViewById(R.id.font);
        this.sticker = (ImageView) findViewById(R.id.sticker);
        this.text_color = (ImageView) findViewById(R.id.text_color);
        this.download = (TextView) findViewById(R.id.download);
        this.text_background = (ImageView) findViewById(R.id.text_background);
        contain_sticker = (RelativeLayout) findViewById(R.id.contain_sticker);
        main_save_layout = (RelativeLayout) findViewById(R.id.main_save_layout);
        try {
            MyPreference.Companion.writeSharedPreferences(MyPreference.FONT_STYLE, "f14.otf");
            String stringExtra = getIntent().getStringExtra("real_txt");
            this.real_text = stringExtra;
            if (stringExtra != null) {
                addShadowSticker(stringExtra, ViewCompat.MEASURED_STATE_MASK);
                for (int i = 0; i < this.dynamicStickerFrame.getChildCount(); i++) {
                    this.selectedShadowSticker = this.dynamicStickerFrame.getChildAt(i);
                    this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackgroundResource(R.drawable.border_textview);
                    ((ImageView) this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.VISIBLE);
                }
            }
            recycle_gradient.setAdapter(new GradientAdapter(this, ((TextView) this.selectedShadowSticker.findViewById(R.id.realtext)).getText().toString(), new GradientAdapter.OnSelect() {

                @Override
                public void onSelectgradient(String str, String str2, String str3) {
                    TextView textView = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.realtext);
                    TextView textView2 = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.flipedtext);
                    if (!str3.equals("")) {
                        LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, textView.getTextSize(), new int[]{Color.parseColor(str), Color.parseColor(str3), Color.parseColor(str2)}, (float[]) null, Shader.TileMode.CLAMP);
                        textView.getPaint().setShader(linearGradient);
                        textView2.getPaint().setShader(linearGradient);
                        textView.postInvalidate();
                        textView2.invalidate();
                        return;
                    }
                    LinearGradient linearGradient2 = new LinearGradient(0.0f, 0.0f, 0.0f, textView.getTextSize(), Color.parseColor(str), Color.parseColor(str2), Shader.TileMode.CLAMP);
                    textView.getPaint().setShader(linearGradient2);
                    textView2.getPaint().setShader(linearGradient2);
                    textView.invalidate();
                    textView2.invalidate();
                }
            }));
            selectedViewBackground(this.gr_ll);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        recycle_gradient.setLayoutManager(new GridLayoutManager(this, getNumberOfColumnstext()));
        recycle_font.setLayoutManager(new GridLayoutManager(this, getNumberOfColumnstext()));
        recycle_sticker.setLayoutManager(new GridLayoutManager(this, getNumberOfColumns()));
        recycle_color.setLayoutManager(new GridLayoutManager(this, getNumberOfColumns()));
        recycle_bg.setLayoutManager(new GridLayoutManager(this, getNumberOfColumns()));
        // recycle_color_sticker_tint.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        // recycle_color_sticker_tint.setAdapter(new CustomeColorSticker(this));
        this.recycle_imgShader.setLayoutManager(new GridLayoutManager(this, getNumberOfColumns()));
        this.rotate_seek_x.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                NameEditing.this.selectedShadowSticker.setRotationX((float) i);
            }
        });
        this.rotate_seek_y.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                NameEditing.this.selectedShadowSticker.setRotationY((float) i);
            }
        });
        this.opacity_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                float f = ((float) i) / 255.0f;
                NameEditing.this.selectedShadowSticker.findViewById(R.id.realtext).setAlpha(f);
                NameEditing.this.selectedShadowSticker.findViewById(R.id.shadowlayout1).setAlpha(f);
            }
        });
        this.shadow_opacity_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                NameEditing.this.selectedShadowSticker.findViewById(R.id.shadowlayout1).setAlpha(((float) i) / 255.0f);
            }
        });
        this.threeD_text.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (NameEditing.this.ll_adjust_3d_text.getVisibility() == View.VISIBLE) {
                    View view2 = null;
                    NameEditing.this.showSelectedRecycle(view2);
                    NameEditing.this.selectedViewBackground(view2);
                    return;
                }
                NameEditing nameEditing = NameEditing.this;
                nameEditing.showSelectedRecycle(nameEditing.ll_adjust_3d_text);
                YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.this.ll_adjust_3d_text);
                NameEditing nameEditing2 = NameEditing.this;
                nameEditing2.selectedViewBackground(nameEditing2.threeD_text);
            }
        });
        this.hide_shadow.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (NameEditing.this.shadow_content_layout.getVisibility() == View.VISIBLE) {
                    View view2 = null;
                    NameEditing.this.showSelectedRecycle(view2);
                    NameEditing.this.selectedViewBackground(view2);
                    return;
                }
                NameEditing nameEditing = NameEditing.this;
                nameEditing.showSelectedRecycle(nameEditing.shadow_content_layout);
                YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.this.shadow_content_layout);
                NameEditing nameEditing2 = NameEditing.this;
                nameEditing2.selectedViewBackground(nameEditing2.hide_shadow);
            }
        });
        this.iv_shadow_switch.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                ConstraintLayout constraintLayout = (ConstraintLayout) NameEditing.this.selectedShadowSticker.findViewById(R.id.shadowlayout1);
                if (constraintLayout.getVisibility() == View.VISIBLE) {
                    NameEditing.this.shadow_switch_checked = false;
                    NameEditing.this.iv_shadow_switch.setImageResource(R.drawable.ic_shadow_off);
                    constraintLayout.setVisibility(View.GONE);
                    return;
                }
                NameEditing.this.shadow_switch_checked = true;
                NameEditing.this.iv_shadow_switch.setImageResource(R.drawable.ic_shadow_on);
                constraintLayout.setVisibility(View.VISIBLE);
            }
        });
        this.add_text__ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    final Dialog dialog = new Dialog(NameEditing.this);
                    dialog.requestWindowFeature(1);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.setCancelable(true);
                    dialog.setContentView(R.layout.text_dialog);
                    final EditText editText = (EditText) dialog.findViewById(R.id.txtmsg);
                    editText.requestFocus();
                    ((InputMethodManager) NameEditing.this.getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(2, 0);
                    ((ImageView) dialog.findViewById(R.id.btncancel)).setOnClickListener(new View.OnClickListener() {

                        public final void onClick(View view) {
                            dialog.dismiss();
                            ((InputMethodManager) NameEditing.this.getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                        }
                    });
                    ((Button) dialog.findViewById(R.id.btnok)).setOnClickListener(new View.OnClickListener() {

                        public final void onClick(View view) {
                            if (TextUtils.isEmpty(editText.getText())) {
                                Toast.makeText(NameEditing.this.getApplicationContext(), "Please Enter Text !", Toast.LENGTH_LONG).show();
                                return;
                            }
                            NameEditing.this.addShadowSticker(editText.getText().toString(), NameEditing.this.bgcolor);
                            dialog.dismiss();
                            ((InputMethodManager) NameEditing.this.getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                        }
                    });
                    dialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        this.imgShader_ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.this.recycle_imgShader.setAdapter(new ImageTextShader(NameEditing.this, new ImageTextShader.OnSelect() {

                    @Override
                    public void onSelectoverlay(Bitmap bitmap) {
                        TextView textView = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.realtext);
                        TextView textView2 = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.flipedtext);
                        textView.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
                        textView2.getPaint().setShader(new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
                        textView.invalidate();
                        textView2.invalidate();
                    }
                }));
                if (NameEditing.this.recycle_imgShader.getVisibility() != View.VISIBLE) {
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.showSelectedRecycle(nameEditing.recycle_imgShader);
                    YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.this.recycle_imgShader);
                    NameEditing nameEditing2 = NameEditing.this;
                    nameEditing2.selectedViewBackground(nameEditing2.imgShader_ll);
                    return;
                }
                View view2 = null;
                NameEditing.this.showSelectedRecycle(view2);
                NameEditing.this.selectedViewBackground(view2);
            }
        });
        this.close_sticker_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    NameEditing.this.recycles_sticker_editing.setVisibility(View.GONE);
                    NameEditing.this.sticker_category_ll.setVisibility(View.GONE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        main_save_layout.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    if (StickerAdapter.mCurrentView != null) {
                        StickerAdapter.mCurrentView.setInEdit(false);
                    }
                    if (NameEditing.this.mCurrentView_pic != null) {
                        NameEditing.this.mCurrentView_pic.setInEdit(false);
                    }
                    NameEditing.this.sticker_availability();
                    NameEditing.this.showSelectedRecycle(null);
                    NameEditing.this.selectedViewBackground(null);
                    for (int i = 0; i < NameEditing.this.dynamicStickerFrame.getChildCount(); i++) {
                        NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                        ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
                        NameEditing.this.showSelectedRecycle(null);
                        NameEditing.this.invisibleeditlayouts(false);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        this.gr_ll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    if (NameEditing.recycle_gradient.getVisibility() != View.VISIBLE) {
                        NameEditing.this.showSelectedRecycle(NameEditing.recycle_gradient);
                        YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.recycle_gradient);
                        NameEditing nameEditing = NameEditing.this;
                        nameEditing.selectedViewBackground(nameEditing.gr_ll);
                    } else {
                        NameEditing.this.showSelectedRecycle(null);
                        NameEditing.this.selectedViewBackground(null);
                    }
                    NameEditing.this.selected = false;
                } catch (Exception e) {
                    try {
                        e.printStackTrace();
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            }
        });
        this.bg_ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    NameEditing.recycle_bg.setAdapter(new BGAdapter(NameEditing.this, "bg", new BGAdapter.OnSelect() {

                        @Override
                        public void onSelectbg(int i, int i2) {
                            if (i2 <= 56) {
                                NameEditing.this.hide_shadow.setVisibility(View.GONE);
                                NameEditing.this.shadow_content_layout.setVisibility(View.GONE);
                                for (int i3 = 0; i3 < NameEditing.this.dynamicStickerFrame.getChildCount(); i3++) {
                                    NameEditing.this.dynamicStickerFrame.getChildAt(i3).findViewById(R.id.shadowlayout1).setVisibility(View.GONE);
                                }
                                NameEditing.this.bgSelected = true;
                                if (i2 == 0) {
                                    try {
                                        NameEditing.this.pickImagebgFromSource(2);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    for (int i4 = 0; i4 < NameEditing.this.dynamicStickerFrame.getChildCount(); i4++) {
                                        NameEditing.this.dynamicStickerFrame.getChildAt(i4).findViewById(R.id.shadowlayout1).setVisibility(View.GONE);
                                    }
                                    Glide.with((FragmentActivity) NameEditing.this).load(Integer.valueOf(i)).into(NameEditing.this.bg_img);
                                }
                            } else {
                                NameEditing.this.bgcolor = i;
                                NameEditing.this.bgSelected = false;
                                NameEditing.this.hide_shadow.setVisibility(View.VISIBLE);
                                NameEditing.this.shadow_content_layout.setVisibility(View.GONE);
                                NameEditing.this.bg_img.setImageDrawable(null);
                                NameEditing.this.bg_img.setBackgroundColor(i);
                                for (int i5 = 0; i5 < NameEditing.this.dynamicStickerFrame.getChildCount(); i5++) {
                                    ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i5).findViewById(R.id.shadow_img)).setColorFilter(i);
                                    NameEditing.this.dynamicStickerFrame.getChildAt(i5).findViewById(R.id.shadowlayout1).setVisibility(View.VISIBLE);
                                }
                            }
                        }
                    }));
                    if (NameEditing.recycle_bg.getVisibility() != View.VISIBLE) {
                        NameEditing.this.showSelectedRecycle(NameEditing.recycle_bg);
                        YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.recycle_bg);
                        NameEditing nameEditing = NameEditing.this;
                        nameEditing.selectedViewBackground(nameEditing.bg_ll);
                    } else {
                        NameEditing.this.showSelectedRecycle(null);
                        NameEditing.this.selectedViewBackground(null);
                    }
                    NameEditing.this.selected = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        this.font_ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    RecyclerView recyclerView = NameEditing.recycle_font;
                    NameEditing nameEditing = NameEditing.this;
                    recyclerView.setAdapter(new FontAdapter(nameEditing, ((TextView) nameEditing.selectedShadowSticker.findViewById(R.id.realtext)).getText().toString(), new FontAdapter.OnSelect() {
                        @Override
                        public void onSelectfont(String str) {
                            AssetManager assets = NameEditing.this.getAssets();
                            Typeface createFromAsset = Typeface.createFromAsset(assets, "fonts/" + str);
                            ((TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.realtext)).setTypeface(createFromAsset);
                            ((TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.flipedtext)).setTypeface(createFromAsset);
                        }
                    }));

                    if (NameEditing.recycle_font.getVisibility() != View.VISIBLE) {
                        NameEditing.this.showSelectedRecycle(NameEditing.recycle_font);
                        YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.recycle_font);
                        NameEditing nameEditing2 = NameEditing.this;
                        nameEditing2.selectedViewBackground(nameEditing2.font_ll);
                    } else {
                        NameEditing.this.showSelectedRecycle(null);
                        NameEditing.this.selectedViewBackground(null);
                    }

                    NameEditing.this.selected = false;

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        this.sticker_ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    NameEditing.this.selectedViewBackground(null);
                    NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                    if (NameEditing.this.recycles_sticker_editing.getVisibility() != View.VISIBLE) {
                        NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                        YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.this.recycles_sticker_editing);
                    }
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.showSelectedRecycle(nameEditing.recycles_sticker_editing);
                    NameEditing.this.sticker_availability();
                    try {
                        NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "diwali"));
                        NameEditing nameEditing2 = NameEditing.this;
                        nameEditing2.selectedViewBackground(nameEditing2.llCatdiwali);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    NameEditing.this.sticker_category_ll.setVisibility(View.VISIBLE);
                    NameEditing.this.font_ll.setBackgroundColor(0);
                    NameEditing.this.bg_ll.setBackgroundColor(0);
                    NameEditing.this.clr_ll.setBackgroundColor(0);
                    NameEditing.this.gr_ll.setBackgroundColor(0);
                    NameEditing.this.add_text__ll.setBackgroundColor(0);
                    NameEditing.this.imgShader_ll.setBackgroundColor(0);
                    NameEditing.this.selected = false;
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        this.clr_ll.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                try {
                    NameEditing.recycle_color.setAdapter(new ColorAdapter(NameEditing.this, "t_color", new ColorAdapter.OnSelect() {

                        @Override
                        public void onSelectColor(int i) {
                            TextView textView = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.realtext);
                            TextView textView2 = (TextView) NameEditing.this.selectedShadowSticker.findViewById(R.id.flipedtext);
                            Shader shader = null;
                            textView.getPaint().setShader(shader);
                            textView2.getPaint().setShader(shader);
                            textView.setTextColor(i);
                            textView2.setTextColor(i);
                        }
                    }));
                    if (NameEditing.recycle_color.getVisibility() != View.VISIBLE) {
                        NameEditing.this.showSelectedRecycle(NameEditing.recycle_color);
                        YoYo.with(Techniques.SlideInUp).duration(500).repeat(0).playOn(NameEditing.recycle_color);
                        NameEditing nameEditing = NameEditing.this;
                        nameEditing.selectedViewBackground(nameEditing.clr_ll);
                    } else {
                        NameEditing.this.showSelectedRecycle(null);
                        NameEditing.this.selectedViewBackground(null);
                    }
                    NameEditing.this.selected = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        this.sticker_pic_ll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                NameEditing.recycle_color.setVisibility(View.GONE);
                NameEditing.recycle_bg.setVisibility(View.GONE);
                NameEditing.recycle_sticker.setVisibility(View.GONE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.GONE);
                NameEditing.recycle_font.setVisibility(View.GONE);
                NameEditing.recycle_gradient.setVisibility(View.GONE);
                NameEditing.this.recycle_imgShader.setVisibility(View.GONE);
                NameEditing.this.selectedViewBackground(null);
                NameEditing.this.selected = false;
                NameEditing.this.pickImagebgFromSource(1);
            }
        });
        this.download.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    try {
                        if (StickerAdapter.mCurrentView != null) {
                            StickerAdapter.mCurrentView.setInEdit(false);
                        }
                        if (NameEditing.this.mCurrentView_pic != null) {
                            NameEditing.this.mCurrentView_pic.setInEdit(false);
                        }
                        for (int i = 0; i < NameEditing.this.dynamicStickerFrame.getChildCount(); i++) {
                            NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                            ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
                            NameEditing.this.showSelectedRecycle(null);
                            NameEditing.this.invisibleeditlayouts(false);
                        }
                        NameEditing nameEditing = NameEditing.this;
                        nameEditing.saveBitmapToGallery(nameEditing.getBitmapFromView(NameEditing.main_save_layout, NameEditing.main_save_layout.getHeight(), NameEditing.main_save_layout.getWidth()));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public void pickImagebgFromSource(int i) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), i);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            try {
                this.tag = "1";
                startCropActivity(intent.getData());
            } catch (Exception e2) {
                e2.printStackTrace();
                return;
            }
        } else if (i == 2) {
            this.tag = ExifInterface.GPS_MEASUREMENT_2D;
            advancedConfig(basisConfig(UCrop.of(intent.getData(), Uri.fromFile(new File(getCacheDir(), "SampleCropImage.png"))))).withAspectRatio(1.0f, 1.0f).start(this);
        }
        handleCropResult(intent);
    }

    private void startCropActivity(Uri uri) {
        advancedConfig(basisConfig(UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), "SampleCropImage.png"))))).start(this);
    }

    private UCrop advancedConfig(UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();
        options.setToolbarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarWidgetColor(getResources().getColor(R.color.white));
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        return uCrop.withOptions(options);
    }

    private void handleCropResult(Intent intent) {
        try {
            Uri output = UCrop.getOutput(intent);
            this.resultUri = output;
            if (output != null) {
                try {
                    this.mBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), this.resultUri);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
                if (this.tag.equals("1")) {
                    addStickerView(this.mBitmap);
                } else if (this.tag.equals(ExifInterface.GPS_MEASUREMENT_2D)) {
                    Glide.with((FragmentActivity) this).load(this.mBitmap).into(this.bg_img);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void addStickerView(Bitmap bitmap) {
        boolean z = false;
        int i = 0;
        while (true) {
            if (i < contain_sticker.getChildCount()) {
                if ((contain_sticker.getChildAt(i) instanceof StickerView) && ((StickerView) contain_sticker.getChildAt(i)).getEditMode()) {
                    ((StickerView) contain_sticker.getChildAt(i)).replaceBitmap(bitmap);
                    z = true;
                    break;
                }
                i++;
            } else {
                break;
            }
        }
        if (!z) {
            final StickerView stickerView = new StickerView(this);
            stickerView.setBitmap(bitmap);
            stickerView.setOperationListener(new StickerView.OperationListener() {

                @Override
                public void onDeleteClick() {
                    NameEditing.mViews_pic.remove(stickerView);
                    NameEditing.contain_sticker.removeView(stickerView);
                }

                @Override
                public void onEdit(StickerView stickerView) {
                    NameEditing.this.mCurrentView_pic.setInEdit(false);
                    NameEditing.this.mCurrentView_pic = stickerView;
                    NameEditing.this.mCurrentView_pic.setInEdit(true);
                    NameEditing.this.showSelectedRecycle(null);
                    for (int i = 0; i < NameEditing.this.dynamicStickerFrame.getChildCount(); i++) {
                        NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                        ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
                        NameEditing.this.invisibleeditlayouts(false);
                    }
                    if (StickerAdapter.mCurrentView != null) {
                        StickerAdapter.mCurrentView.setInEdit(false);
                    }
                }

                @Override
                public void onTop(StickerView stickerView) {
                    int indexOf = NameEditing.mViews_pic.indexOf(stickerView);
                    if (indexOf != NameEditing.mViews_pic.size() - 1) {
                        NameEditing.mViews_pic.add(NameEditing.mViews_pic.size(), (StickerView) NameEditing.mViews_pic.remove(indexOf));
                    }
                }
            });
            contain_sticker.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
            mViews_pic.add(stickerView);
            setCurrentEdit(stickerView);
        }
    }

    private void setCurrentEdit(StickerView stickerView) {
        StickerView stickerView2 = this.mCurrentView_pic;
        if (stickerView2 != null) {
            stickerView2.setInEdit(false);
        }
        this.mCurrentView_pic = stickerView;
        stickerView.setInEdit(true);
    }

    public Bitmap getBitmapFromView(View view, int i, int i2) {
        Bitmap createBitmap = Bitmap.createBitmap(i2, i, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Drawable background = view.getBackground();
        if (background != null) {
            background.draw(canvas);
        }
        view.draw(canvas);
        return createBitmap;
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                NameEditing.this.openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivityForResult(intent, 101);
    }

    public File saveBitmapToGallery(Bitmap bitmap) {
        FileOutputStream fileOutputStream=null;
        File file = null;
        try {
            File file2 = new File(Environment.getExternalStorageDirectory(), getResources().getString(R.string.app_name));
            if (!file2.exists()) {
                file2.mkdirs();
            }
            File file3 = new File(file2, "IMG_" + Calendar.getInstance().getTimeInMillis() + ".png");
            try {
                if (file3.exists()) {
                    file3.delete();
                }
                try {
                    fileOutputStream = new FileOutputStream(file3);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    MediaScannerConnection.scanFile(this, new String[]{file3.getAbsolutePath()}, null, null);
                    Intent intent = new Intent(this, ShareScreen.class);
                    intent.putExtra("picture_path", file3.getAbsolutePath());
                    intent.putExtra("picture_file", file3);
                    startActivity(intent);
                    finish();

                    return file3;

                } catch (Exception e3) {
                    e3.printStackTrace();
                    return null;
                }
            } catch (Exception e4) {

                e4.printStackTrace();
                return file;
            }
        } catch (Exception e6) {
            e6.printStackTrace();
            return file;
        }
    }

    public void back(View view) {
        onBackPressed();
    }

    private void findViews() {
        this.llCatKing = (LinearLayout) findViewById(R.id.ll_cat_king);
        this.llCatHipster = (LinearLayout) findViewById(R.id.ll_cat_hipster);
        this.llCatlove = (LinearLayout) findViewById(R.id.ll_cat_love);
        this.llCatlines = (LinearLayout) findViewById(R.id.ll_cat_lines);
        this.llCatfeather = (LinearLayout) findViewById(R.id.ll_cat_feather);
        this.llCatAngle = (LinearLayout) findViewById(R.id.ll_cat_angle);
        this.llCatDevil = (LinearLayout) findViewById(R.id.ll_cat_devil);
        this.llCatSmily = (LinearLayout) findViewById(R.id.ll_cat_smily);
        this.llCatLion = (LinearLayout) findViewById(R.id.ll_cat_lion);
        this.llCatFlower = (LinearLayout) findViewById(R.id.ll_cat_flower);
        this.llCatButterfly = (LinearLayout) findViewById(R.id.ll_cat_butterfly);
        this.llCatStar = (LinearLayout) findViewById(R.id.ll_cat_star);
        this.llCatPanda = (LinearLayout) findViewById(R.id.ll_cat_panda);
        this.llCatMickyMouse = (LinearLayout) findViewById(R.id.ll_cat_micky_mouse);
        this.llCatEar = (LinearLayout) findViewById(R.id.ll_cat_ear);
        this.llCatCity = (LinearLayout) findViewById(R.id.ll_cat_city);
        this.llCatdiwali = (LinearLayout) findViewById(R.id.llCatdiwali);
        this.sticker_category_ll = (LinearLayout) findViewById(R.id.sticker_category_ll);
        this.sticker_ll = (LinearLayout) findViewById(R.id.sticker_ll);
        this.font_ll = (LinearLayout) findViewById(R.id.font_ll);
        this.bg_ll = (LinearLayout) findViewById(R.id.bg_ll);
        this.clr_ll = (LinearLayout) findViewById(R.id.clr_ll);
        this.gr_ll = (LinearLayout) findViewById(R.id.gr_ll);
    }

    private void set_layout_listners() {
        this.llCatKing.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "king"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatKing);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatHipster.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "hipster"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatHipster);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatlove.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "love"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatlove);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatlines.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "lines"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatlines);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatfeather.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "feather"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatfeather);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatAngle.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "angle"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatAngle);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatDevil.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "devil"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatDevil);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        this.llCatSmily.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "smily"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatSmily);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatLion.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "lion"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatLion);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatFlower.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "flower"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatFlower);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatButterfly.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "butterfly"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatButterfly);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatStar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "star"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatStar);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatPanda.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "panda"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatPanda);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatMickyMouse.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "micky_mouse"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatMickyMouse);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatEar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "ear"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatEar);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatCity.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "city"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatCity);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        this.llCatdiwali.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                NameEditing.recycle_sticker.setVisibility(View.VISIBLE);
                NameEditing.this.recycles_sticker_editing.setVisibility(View.VISIBLE);
                try {
                    NameEditing.recycle_sticker.setAdapter(new StickerAdapter(NameEditing.this, "diwali"));
                    NameEditing nameEditing = NameEditing.this;
                    nameEditing.selectedViewBackground(nameEditing.llCatdiwali);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public int getNumberOfColumns() {
        View inflate = View.inflate(this, R.layout.color_adapter, null);
        inflate.measure(0, 0);
        int measuredWidth = inflate.getMeasuredWidth();
        int i = getResources().getDisplayMetrics().widthPixels / measuredWidth;
        return getResources().getDisplayMetrics().widthPixels - (measuredWidth * i) > measuredWidth + -15 ? i + 1 : i;
    }

    public int getNumberOfColumnstext() {
        View inflate = View.inflate(this, R.layout.font_adapter, null);
        inflate.measure(0, 0);
        int measuredWidth = inflate.getMeasuredWidth();
        int i = getResources().getDisplayMetrics().widthPixels / measuredWidth;
        return getResources().getDisplayMetrics().widthPixels - (measuredWidth * i) > measuredWidth + -15 ? i + 1 : i;
    }

    public void sticker_availability() {
        boolean z = false;
        for (int i = 0; i < contain_sticker.getChildCount(); i++) {
            if ((contain_sticker.getChildAt(i) instanceof StickerView) && ((StickerView) contain_sticker.getChildAt(i)).getEditMode()) {
                // recycle_color_sticker_tint.setVisibility(View.VISIBLE);
                z = true;
            }
        }
        if (!z) {
            //  recycle_color_sticker_tint.setVisibility(View.GONE);
        }
    }

    public void invisibleeditlayouts(Boolean bool) {
        if (bool.booleanValue()) {
            this.text_edit_ll.setVisibility(View.VISIBLE);
        } else {
            this.text_edit_ll.setVisibility(View.GONE);
        }
    }

    public void showSelectedRecycle(View view) {
        recycle_gradient.setVisibility(View.GONE);
        this.recycle_imgShader.setVisibility(View.GONE);
        recycle_font.setVisibility(View.GONE);
        this.recycles_sticker_editing.setVisibility(View.GONE);
        recycle_color.setVisibility(View.GONE);
        recycle_bg.setVisibility(View.GONE);
        this.ll_adjust_3d_text.setVisibility(View.GONE);
        this.shadow_content_layout.setVisibility(View.GONE);
        if (view != null) {
            view.setVisibility(View.VISIBLE);
        }
    }

    public void selectedViewBackground(View view) {
        this.sticker_ll.setBackgroundColor(0);
        this.font_ll.setBackgroundColor(0);
        this.bg_ll.setBackgroundColor(0);
        this.clr_ll.setBackgroundColor(0);
        this.gr_ll.setBackgroundColor(0);
        this.add_text__ll.setBackgroundColor(0);
        this.imgShader_ll.setBackgroundColor(0);
        this.hide_shadow.setBackgroundColor(0);
        this.threeD_text.setBackgroundColor(0);
        this.llCatKing.setBackgroundColor(0);
        this.llCatHipster.setBackgroundColor(0);
        this.llCatlove.setBackgroundColor(0);
        this.llCatlines.setBackgroundColor(0);
        this.llCatfeather.setBackgroundColor(0);
        this.llCatAngle.setBackgroundColor(0);
        this.llCatDevil.setBackgroundColor(0);
        this.llCatSmily.setBackgroundColor(0);
        this.llCatLion.setBackgroundColor(0);
        this.llCatFlower.setBackgroundColor(0);
        this.llCatButterfly.setBackgroundColor(0);
        this.llCatStar.setBackgroundColor(0);
        this.llCatPanda.setBackgroundColor(0);
        this.llCatMickyMouse.setBackgroundColor(0);
        this.llCatEar.setBackgroundColor(0);
        this.llCatCity.setBackgroundColor(0);
        this.llCatdiwali.setBackgroundColor(0);
        if (view != null) {
            view.setBackgroundResource(R.drawable.actionbar_bg);
        }
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        try {
                            if (StickerAdapter.mCurrentView != null) {
                                StickerAdapter.mCurrentView.setInEdit(false);
                            }
                            if (NameEditing.this.mCurrentView_pic != null) {
                                NameEditing.this.mCurrentView_pic.setInEdit(false);
                            }
                            for (int i = 0; i < NameEditing.this.dynamicStickerFrame.getChildCount(); i++) {
                                NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                                ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
                                NameEditing.this.showSelectedRecycle(null);
                                NameEditing.this.invisibleeditlayouts(false);
                            }
                            NameEditing nameEditing = NameEditing.this;
                            nameEditing.saveBitmapToGallery(nameEditing.getBitmapFromView(NameEditing.main_save_layout, NameEditing.main_save_layout.getHeight(), NameEditing.main_save_layout.getWidth()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    public void RequestInterstitial() {
        try {
            mInterstitialAd = new InterstitialAd(activity);
            mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   /* public void loadAd() {
        //InterstitialAd
        Log.e("aaaaaaaaaa", "aaaaaaaaaaaaa");
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(NameEditing.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);

        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                switch (id) {
                    case 100:
                        try {
                            if (StickerAdapter.mCurrentView != null) {
                                StickerAdapter.mCurrentView.setInEdit(false);
                            }
                            if (NameEditing.this.mCurrentView_pic != null) {
                                NameEditing.this.mCurrentView_pic.setInEdit(false);
                            }
                            for (int i = 0; i < NameEditing.this.dynamicStickerFrame.getChildCount(); i++) {
                                NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.ll_view1).setBackground(null);
                                ((ImageView) NameEditing.this.dynamicStickerFrame.getChildAt(i).findViewById(R.id.delete_text)).setVisibility(View.INVISIBLE);
                                NameEditing.this.showSelectedRecycle(null);
                                NameEditing.this.invisibleeditlayouts(false);
                            }
                            NameEditing nameEditing = NameEditing.this;
                            nameEditing.saveBitmapToGallery(nameEditing.getBitmapFromView(NameEditing.main_save_layout, NameEditing.main_save_layout.getHeight(), NameEditing.main_save_layout.getWidth()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(NameEditing.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads\nPlease Wait...");
            hud.show();

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }*/

}
