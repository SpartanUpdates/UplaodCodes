package com.esc.phoneheart.utility;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Process;
import android.util.Log;

import com.esc.phoneheart.processes.AndroidAppProcess;
import com.esc.phoneheart.processes.AndroidProcess;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AndroidProcesses {
    public static final int AID_READPROC = 3009;
    public static final String TAG = "AndroidProcesses";
    public static boolean loggingEnabled;

    public static final class ProcessComparator implements Comparator<AndroidProcess> {
        public int compare(AndroidProcess androidProcess, AndroidProcess androidProcess2) {
            return androidProcess.name.compareToIgnoreCase(androidProcess2.name);
        }
    }

    public AndroidProcesses() {
        throw new AssertionError("no instances");
    }

    @SuppressLint("WrongConstant")
    public static List<RunningAppProcessInfo> getRunningAppProcessInfo(Context context) {
        if (VERSION.SDK_INT < 22) {
            return ((ActivityManager) context.getSystemService("activity")).getRunningAppProcesses();
        }
        List<AndroidAppProcess> runningAppProcesses = getRunningAppProcesses();
        ArrayList arrayList = new ArrayList();
        for (AndroidAppProcess androidAppProcess : runningAppProcesses) {
            RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo(androidAppProcess.name, androidAppProcess.pid, null);
            runningAppProcessInfo.uid = androidAppProcess.uid;
            arrayList.add(runningAppProcessInfo);
        }
        return arrayList;
    }

    public static List<AndroidAppProcess> getRunningAppProcesses() {
        File[] listFiles;
        ArrayList arrayList = new ArrayList();
        for (File file : new File("/proc").listFiles()) {
            if (file.isDirectory()) {
                try {
                    int parseInt = Integer.parseInt(file.getName());
                    try {
                        try {
                            arrayList.add(new AndroidAppProcess(parseInt));
                        } catch (AndroidAppProcess.NotAndroidAppProcessException e) {
                            e.printStackTrace();
                        }
                    } catch (IOException e) {
                        log(e, "Error reading from /proc/%d.", Integer.valueOf(parseInt));
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        return arrayList;
    }

    public static List<AndroidAppProcess> getRunningForegroundApps(Context context) {
        ArrayList arrayList = new ArrayList();
        File[] listFiles = new File("/proc").listFiles();
        PackageManager packageManager = context.getPackageManager();
        for (File file : listFiles) {
            if (file.isDirectory()) {
                try {
                    int parseInt = Integer.parseInt(file.getName());
                    try {
                        AndroidAppProcess androidAppProcess = null;
                        try {
                            androidAppProcess = new AndroidAppProcess(parseInt);
                        } catch (AndroidAppProcess.NotAndroidAppProcessException e) {
                            e.printStackTrace();
                        }
                        if (androidAppProcess.foreground && ((androidAppProcess.uid < 1000 || androidAppProcess.uid > 9999) && packageManager.getLaunchIntentForPackage(androidAppProcess.getPackageName()) != null)) {
                            arrayList.add(androidAppProcess);
                        }
                    } catch (IOException e) {
                        log(e, "Error reading from /proc/%d.", Integer.valueOf(parseInt));
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        return arrayList;
    }

    public static List<AndroidProcess> getRunningProcesses() {
        File[] listFiles;
        ArrayList arrayList = new ArrayList();
        for (File file : new File("/proc").listFiles()) {
            if (file.isDirectory()) {
                try {
                    int parseInt = Integer.parseInt(file.getName());
                    try {
                        arrayList.add(new AndroidProcess(parseInt));
                    } catch (IOException e) {
                        log(e, "Error reading from /proc/%d.", Integer.valueOf(parseInt));
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        return arrayList;
    }

    public static boolean isLoggingEnabled() {
        return loggingEnabled;
    }

    public static boolean isMyProcessInTheForeground() {
        try {
            return new AndroidAppProcess(Process.myPid()).foreground;
        } catch (Exception e) {
            log(e, "Error finding our own process", new Object[0]);
            return false;
        }
    }

    public static boolean isProcessInfoHidden() {
        boolean z = false;
        BufferedReader bufferedReader = null;
        try {
            BufferedReader bufferedReader2 = new BufferedReader(new FileReader("/proc/mounts"));
            while (true) {
                try {
                    String readLine = bufferedReader2.readLine();
                    if (readLine != null) {
                        String[] split = readLine.split("\\s+");
                        if (split.length == 6 && split[1].equals("/proc")) {
                            if (split[3].contains("hidepid=1") || split[3].contains("hidepid=2")) {
                                z = true;
                            }
                            try {
                                bufferedReader2.close();
                            } catch (IOException unused) {
                            }
                            return z;
                        }
                    } else {
                        break;
                    }
                } catch (IOException unused3) {
                    bufferedReader = bufferedReader2;
                    try {
                        Log.d(TAG, "Error reading /proc/mounts. Checking if UID 'readproc' exists.");
                        if (bufferedReader != null) {
                        }
                        if (Process.getUidForName("readproc") == 3009) {
                        }
                        return z;
                    } catch (Throwable th) {
                        th = th;
                        if (bufferedReader != null) {
                            try {
                                bufferedReader.close();
                            } catch (IOException unused4) {
                            }
                        }
                    }
                } catch (Throwable th2) {
                    bufferedReader = bufferedReader2;
                    if (bufferedReader != null) {
                    }
                    throw th2;
                }
            }
        } catch (IOException unused5) {
            Log.d(TAG, "Error reading /proc/mounts. Checking if UID 'readproc' exists.");
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (Process.getUidForName("readproc") == 3009) {
            }
            return z;
        }
        if (Process.getUidForName("readproc") == 3009) {
            z = true;
        }
        return z;
    }

    public static void log(String str, Object... objArr) {
        if (loggingEnabled) {
            if (objArr.length != 0) {
                str = String.format(str, objArr);
            }
            Log.d(TAG, str);
        }
    }

    public static void setLoggingEnabled(boolean z) {
        loggingEnabled = z;
    }

    public static void log(Throwable th, String str, Object... objArr) {
        if (loggingEnabled) {
            if (objArr.length != 0) {
                str = String.format(str, objArr);
            }
            Log.d(TAG, str, th);
        }
    }
}
