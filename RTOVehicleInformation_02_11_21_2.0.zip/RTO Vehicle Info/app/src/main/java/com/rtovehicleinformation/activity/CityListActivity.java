package com.rtovehicleinformation.activity;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.rtovehicleinformation.Adapter.CityListAdapter;
import com.rtovehicleinformation.Model.PetrolDieselData;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.application.AppController;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CityListActivity extends AppCompatActivity {

    Activity activity = CityListActivity.this;
    @BindView(R.id.cityList)
    ListView listView;

    @BindView(R.id.searchCity)
    SearchView searchView;

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    int CityPosition;
    List<PetrolDieselData> petrolDieselData;
    List<PetrolDieselData> search_result_arraylist = new ArrayList();
    CityListAdapter cityListAdapter;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_list);
        ButterKnife.bind(this);
        toolbar.setTitle("Select City");
        BannerAds();
        searchView.setSearchableInfo(((SearchManager) getSystemService(SEARCH_SERVICE)).getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(true);
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            public boolean onClose() {
                search_result_arraylist.clear();
                return false;
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String str) {
                return false;
            }

            public boolean onQueryTextChange(String str) {
                if (str.equalsIgnoreCase("")) {
                    CityListActivity cityListActivity = CityListActivity.this;
                    cityListActivity.setSearchData(cityListActivity.petrolDieselData);
                } else {
                    CityListActivity.this.SearchByProductTitleName(str);
                }
                return false;
            }
        });
        petrolDieselData = (List) getIntent().getSerializableExtra("data");
        cityListAdapter = new CityListAdapter(getApplication(), this.petrolDieselData);
        listView.setAdapter(this.cityListAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long j) {
                if (AppController.mInterstitialAd != null) {
                    AppController.activity = activity;
                    AppController.AdsId = 1;
                    AppController.getInstance().search_result_arraylist = search_result_arraylist;
                    AppController.getInstance().petrolDieselData = petrolDieselData;
                    AppController.getInstance().CityPosition = i;
                    AppController.mInterstitialAd.show(activity);

                } else {
                    ListClick(i);
                }
            }
        });
    }


    private void ListClick(int i) {
        Intent intent = new Intent();
        if (search_result_arraylist.size() > 0) {
            intent.putExtra("data", search_result_arraylist.get(i));
        } else {
            intent.putExtra("data", petrolDieselData.get(i));
        }
        setResult(-1, intent);
        finish();
    }

    private void SearchByProductTitleName(String str) {
        this.search_result_arraylist.clear();
        for (int i = 0; i < this.petrolDieselData.size(); i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.petrolDieselData.get(i).getCityName().toLowerCase());
            if (stringBuilder.toString().contains(str.toLowerCase())) {
                this.search_result_arraylist.add(this.petrolDieselData.get(i));
            }
        }
        setSearchData(this.search_result_arraylist);
    }

    private void setSearchData(List<PetrolDieselData> list) {
        CityListAdapter cityListAdapter = this.cityListAdapter;
        if (cityListAdapter != null) {
            cityListAdapter.SetSearchData(list);
            this.cityListAdapter.notifyDataSetChanged();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
