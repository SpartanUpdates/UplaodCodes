package com.mbit.VideoMaker.AllData;

public class GetUrl {
    public static String a = null;
    public static String b = null;
    public static String c = null;
    public static String d = null;
    public static String e = null;
    public static String f = null;
    public static String g = null;
    public static String h = "";
    public static String i = "Theme_Id";
    public static String j;
    public static String k;
    public static String l;
    public static String m;
    public static String n;


}
