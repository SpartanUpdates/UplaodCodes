package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.jetbrains.annotations.NotNull;

public class RtoOfficeInfoDetailActivity extends AppCompatActivity {

    private Activity activity = RtoOfficeInfoDetailActivity.this;
    private String cityCode, cityName, StateName, address, contact, website;
    private TextView tv_district;
    private TextView tv_rtoCode;
    private TextView tv_address;
    private TextView tv_phone;
    private TextView tv_website;
    private TextView tv_state;
    private TextView title_tv;
    private LottieAnimationView call, map;
    private ImageView iv_back, iv_home;
    private LinearLayout ll_rtoOfficeData;
    private LinearLayout ll_address;
    private LinearLayout ll_contact;

    GGAdview gg_native;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo_detail);
        cityCode = getIntent().getStringExtra("cityCode");
        cityName = getIntent().getStringExtra("cityName");
        StateName = getIntent().getStringExtra("StateName");
        address = getIntent().getStringExtra("address");
        contact = getIntent().getStringExtra("contact");
        website = getIntent().getStringExtra("website");
        PutAnalyticsEvent();
        BindView();
        CallNativeAds();
        InterAds();
        getPermission();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(RtoOfficeInfoDetailActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        if (Utils.isOnline(activity)) {
            if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                id = 1;
                interstitialAd.show();
            } else {
                setCityData();
            }
        } else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        iv_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 3;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(RtoOfficeInfoDetailActivity.this, MainActivity.class));
                    finish();
                }
            }
        });
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void getPermission() {
        if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
        }
    }

    private void setupDarkMode() {
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        ll_rtoOfficeData.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        tv_website.setLinkTextColor(Color.parseColor("#FAFAD2"));
    }

    private void CallNativeAds(){
        gg_native = findViewById(R.id.ggAdView_native);
        gg_native.setUnitId(getResources().getString(R.string.NativeAd));
        gg_native.loadAd(new AdLoadCallback()
                         {
                             @Override
                             public void onReadyForRefresh() {

                             }
                             @Override
                             public void onUiiClosed() {

                             }
                             @Override
                             public void onUiiOpened() {

                             }
                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        setCityData();
                        break;
                    case 2:
                        startActivity(new Intent(RtoOfficeInfoDetailActivity.this, RtoOfficeInfoActivity.class));
                        finish();
                        break;
                    case 3:
                        startActivity(new Intent(RtoOfficeInfoDetailActivity.this, MainActivity.class));
                        finish();
                        break;
                    case 4:
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:" + contact));
                        startActivity(intent);
                        break;
                    case 5:
                        try {
                            Intent intent2 = new Intent(Intent.ACTION_VIEW);
                            intent2.setData(Uri.parse("geo:0,0?q=" + address));
                            startActivity(intent2);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    private void BindView() {
        tv_district = findViewById(R.id.tv_district);
        tv_rtoCode = findViewById(R.id.tv_rtoCode);
        tv_state = findViewById(R.id.tv_state);
        tv_address = findViewById(R.id.tv_address);
        tv_phone = findViewById(R.id.tv_contact);
        tv_website = findViewById(R.id.tv_website);
        iv_back = findViewById(R.id.iv_back);
        ll_address = findViewById(R.id.ll_address);
        ll_contact = findViewById(R.id.ll_contact);
        ll_rtoOfficeData = findViewById(R.id.ll_rtoOfficeData);
        title_tv = findViewById(R.id.title_tv);
        iv_home = findViewById(R.id.iv_home);
        call = findViewById(R.id.call);
        map = findViewById(R.id.map);

    }

    private void setCityData() {
        tv_district.setText(cityName);
        tv_rtoCode.setText(cityCode);
        tv_address.setText(address);
        tv_state.setText(StateName);
        tv_website.setText(website);
        if (contact.equals("null")) {
            ll_contact.setVisibility(View.GONE);
        } else {
            contact = contact.replace("-", " ");
            tv_phone.setText(contact);
            call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                    } else {
                        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                            id = 4;
                            interstitialAd.show();
                        } else {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + contact));
                            startActivity(intent);
                        }

                    }
                }
            });
            tv_phone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ContextCompat.checkSelfPermission(RtoOfficeInfoDetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(RtoOfficeInfoDetailActivity.this, new String[]{Manifest.permission.CALL_PHONE}, 101);
                    } else {
                        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                            id = 4;
                            interstitialAd.show();
                        } else {
                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + contact));
                            startActivity(intent);
                        }
                    }
                }
            });
        }

        if (address.equals("null")) {
            ll_address.setVisibility(View.GONE);
        } else {
            tv_address.setText(address);
            map.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                        id = 5;
                        interstitialAd.show();
                    } else {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:0,0?q=" + address));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            tv_address.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                        id = 5;
                        interstitialAd.show();
                    } else {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("geo:0,0?q=" + address));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 2;
            interstitialAd.show();
        } else {
            startActivity(new Intent(RtoOfficeInfoDetailActivity.this, RtoOfficeInfoActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}