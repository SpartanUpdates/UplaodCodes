package com.vidsoft.uvideostatus.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader.Builder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.vidsoft.uvideostatus.Fragments.FeatureFragment;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.FontTextView;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.wang.avi.AVLoadingIndicatorView;
import cz.msebera.android.httpclient.util.ByteArrayBuffer;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

public class FeatureAdapter extends Adapter<RecyclerView.ViewHolder> {
    public static HashMap<String, ArrayList<VideoData>> videoData1 = new HashMap<>();
    public String ADMOB_AD_UNIT_ID;
    Activity context;
    public FeatureFragment featureFragment;
    File file;
    private Handler handler = new Handler();
    public String imgPath;
    private boolean isLoading;
    private boolean loading;
    int pStatus = 0;
    private String path;
    HashMap<String, ArrayList<VideoData>> stringArrayListHashMap = new HashMap<>();
    String title;
    private int val = 0;
    VideoData vddta;
    public ArrayList<VideoData> videoDatalist = new ArrayList<>();

    public class AdViewHolder extends RecyclerView.ViewHolder {
        TextView mAdBody;
        Button mAdButton;
        TextView mAdHeadline;
        ImageView mAdIcon;
        ImageView mAdImage;
        RelativeLayout mAdParentView;
        NativeAppInstallAdView mNativeAppInstallAdView;

        public AdViewHolder(View view) {
            super(view);
            this.mAdParentView = view.findViewById(R.id.adCardView1);
            this.mNativeAppInstallAdView = view.findViewById(R.id.nativeAppInstallAdView1);
            this.mAdImage = view.findViewById(R.id.appinstall_image1);
            this.mAdIcon = view.findViewById(R.id.appinstall_app_icon1);
            this.mAdHeadline = view.findViewById(R.id.appinstall_headline1);
            this.mAdBody = view.findViewById(R.id.appinstall_body1);
            this.mAdButton = view.findViewById(R.id.appinstall_call_to_action1);
            FeatureAdapter.this.context.getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        }
    }

    public class CustomNativeAd extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        FrameLayout container;

        CustomNativeAd(View view) {
            super(view);
            this.container = view.findViewById(R.id.container);
        }
    }

    private class ImageDownloadAndSave extends AsyncTask<String, Void, Bitmap> {
        private ImageDownloadAndSave() {
        }

        public void onPreExecute() {
            FeatureFragment.loader.setVisibility(View.VISIBLE);
            FeatureFragment.lottie_download.setVisibility(View.VISIBLE);
            super.onPreExecute();
            Toast.makeText(FeatureAdapter.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public Bitmap doInBackground(String... strArr) {
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            downloadImagesToSdCard(str, sb.toString());
            return null;
        }

        public void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            Log.d("TAG", "onPostExecute: ");
            FeatureFragment.lottie_download.setVisibility(View.GONE);
            FeatureFragment.loottiedone.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    FeatureFragment.loottiedone.setVisibility(View.GONE);
                }
            }, 300);
            FeatureAdapter.this.shareMultiplePhotos();
        }

        private void downloadImagesToSdCard(String str, String str2) {
            String str3 = "/";
            FeatureAdapter.this.imgPath = str;
            FeatureAdapter featureAdapter = FeatureAdapter.this;
            featureAdapter.title = str2;
            try {
                URL url = new URL(featureAdapter.imgPath);
                StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append(str3);
                sb.append(FeatureAdapter.this.context.getString(R.string.app_name));
                File file = new File(sb.toString());
                if (!file.exists()) {
                    file.mkdirs();
                }
                String[] split = FeatureAdapter.this.imgPath.split(Pattern.quote(str3));
                StringBuilder sb2 = new StringBuilder();
                sb2.append("captureImage: ");
                sb2.append(FeatureAdapter.this.imgPath);
                sb2.append("    ");
                sb2.append(split[split.length - 1]);
                Log.d("TAG", sb2.toString());
                FeatureAdapter.this.file = new File(file.getAbsolutePath(), split[split.length - 1]);
                if (!FeatureAdapter.this.file.exists()) {
                    URLConnection openConnection = url.openConnection();
                    InputStream inputStream = null;
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode() == 200) {
                        inputStream = httpURLConnection.getInputStream();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(FeatureAdapter.this.file);
                    int contentLength = httpURLConnection.getContentLength();
                    byte[] bArr = new byte[1024];
                    int i = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        i += read;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("downloadedSize:");
                        sb3.append(i);
                        sb3.append("totalSize:");
                        sb3.append(contentLength);
                        Log.i("Progress:", sb3.toString());
                    }
                    fileOutputStream.close();
                }
                Log.d("test", "Image Saved in sdcard..");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    class ProgressBack extends AsyncTask<String, String, String> {
        public ProgressBack() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            FeatureFragment.loader.setVisibility(View.VISIBLE);
            FeatureFragment.lottie_download.setVisibility(View.VISIBLE);
            Toast.makeText(FeatureAdapter.this.context, "Video Started to download", Toast.LENGTH_LONG).show();
        }

        public String doInBackground(String... strArr) {
            FeatureAdapter featureAdapter = FeatureAdapter.this;
            String str = strArr[0];
            StringBuilder sb = new StringBuilder();
            sb.append(strArr[1]);
            sb.append(".mp4");
            featureAdapter.DownloadFile(str, sb.toString());
            return null;
        }

        public void onPostExecute(String str) {
            super.onPostExecute(str);
            FeatureFragment.lottie_download.setVisibility(View.GONE);
            FeatureFragment.loottiedone.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    FeatureFragment.loottiedone.setVisibility(View.GONE);
                }
            }, 200);
            Toast.makeText(FeatureAdapter.this.context, "Downloaded Sucessfully", Toast.LENGTH_LONG).show();
        }
    }

    public static class ProgressViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public AVLoadingIndicatorView progressBar;

        public ProgressViewHolder(View view) {
            super(view);
            this.progressBar = view.findViewById(R.id.progressBar1);
        }
    }

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public FontTextView duration;
        LottieAnimationView icon_like;
        public ImageView icon_like_main;
        public ImageView idIvVideoOption;
        public RelativeLayout llVideoList;
        public FontTextView tvVideoListingDuration;
        public FontTextView tvVideoListingName;
        public FontTextView tvVideoListingSize;
        public ImageView tvVideoListingThumbnail;

        public ViewHolder(View view) {
            super(view);
            this.tvVideoListingName = view.findViewById(R.id.tvVideoListingName);
            this.idIvVideoOption = view.findViewById(R.id.idIvVideoOption);
            this.llVideoList = view.findViewById(R.id.llVideoList);
            this.tvVideoListingThumbnail = view.findViewById(R.id.tvVideoListingThumbnail);
            this.tvVideoListingSize = view.findViewById(R.id.tvVideoListingSize);
            this.tvVideoListingDuration = view.findViewById(R.id.tvVideoListingDuration);
            this.duration = view.findViewById(R.id.duration);
            this.icon_like_main = view.findViewById(R.id.icon_like_main);
            this.icon_like = view.findViewById(R.id.icon_like);
            this.icon_like_main.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ViewHolder.this.icon_like_main.setVisibility(View.GONE);
                    ViewHolder.this.icon_like.setVisibility(View.VISIBLE);
                    ViewHolder.this.icon_like.playAnimation();
                    ViewHolder.this.icon_like.loop(false);
                }
            });
            this.idIvVideoOption.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FeatureAdapter.this.showVideoOption(FeatureAdapter.this.videoDatalist.get(ViewHolder.this.getAdapterPosition()), ViewHolder.this.idIvVideoOption);
                }
            });
        }
    }

    public FeatureAdapter(Activity activity, ArrayList<VideoData> arrayList, FeatureFragment featureFragment2) {
        this.featureFragment = featureFragment2;
        this.context = activity;
        this.videoDatalist = arrayList;
        notifyDataSetChanged();
        this.isLoading = false;
        this.ADMOB_AD_UNIT_ID = activity.getResources().getString(R.string.AdMob_NativeAdvanceAd);
    }

    @NonNull
    public androidx.recyclerview.widget.RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder;
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 1) {
            viewHolder = new ViewHolder(from.inflate(R.layout.feature_home_layout, viewGroup, false));
        } else if (i == 3) {
            return new CustomNativeAd(from.inflate(R.layout.customnativeadview, viewGroup, false));
        } else {
            viewHolder = new ProgressViewHolder(from.inflate(R.layout.progress_item, viewGroup, false));
        }
        return viewHolder;
    }

    public void onBindViewHolder(final androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, final int i) {
        if (viewHolder instanceof ProgressViewHolder) {
            ProgressViewHolder progressViewHolder = (ProgressViewHolder) viewHolder;
            progressViewHolder.progressBar.setVisibility(View.VISIBLE);
            progressViewHolder.progressBar.show();
        } else if (viewHolder instanceof CustomNativeAd) {
            Builder builder = new Builder(this.context, this.ADMOB_AD_UNIT_ID);
            builder.forUnifiedNativeAd(new OnUnifiedNativeAdLoadedListener() {
                public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                    UnifiedNativeAdView unifiedNativeAdView = (UnifiedNativeAdView) FeatureAdapter.this.context.getLayoutInflater().inflate(R.layout.native_layout_new, null);
                    FeatureAdapter.this.populateUnifiedNativeAdView(unifiedNativeAd, unifiedNativeAdView);
                    ((CustomNativeAd) viewHolder).container.setVisibility(View.VISIBLE);
                    ((CustomNativeAd) viewHolder).container.removeAllViews();
                    ((CustomNativeAd) viewHolder).container.addView(unifiedNativeAdView);
                }
            });
            builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
            builder.withAdListener(new AdListener() {
                public void onAdFailedToLoad(int i) {
                }
            }).build().loadAd(new AdRequest.Builder().build());
        } else if (viewHolder instanceof ViewHolder) {
            this.vddta = this.videoDatalist.get(i);
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            viewHolder2.tvVideoListingName.setText(this.vddta.getTitle());
            viewHolder2.tvVideoListingSize.setText(this.vddta.getLikes());
            FontTextView fontTextView = viewHolder2.tvVideoListingDuration;
            StringBuilder sb = new StringBuilder();
            sb.append(Utility.getViews(Double.parseDouble(this.vddta.getViews())));
            sb.append(" views");
            fontTextView.setText(sb.toString());
            viewHolder2.llVideoList.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FeatureAdapter.this.featureFragment.playVideo(FeatureAdapter.this.videoDatalist.get(i));
                }
            });
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.video_placeholder);
            requestOptions.error(R.drawable.video_placeholder);
            requestOptions.override(Callback.DEFAULT_SWIPE_ANIMATION_DURATION, Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
            Glide.with(this.context).load(this.vddta.getThumbnail()).apply(requestOptions).into(viewHolder2.tvVideoListingThumbnail);
        }
    }

    public void showVideoOption(final VideoData videoData, ImageView imageView) {
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.bottomsheet_video_option, null);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this.context);
        bottomSheetDialog.setContentView(inflate);
        TextView textView = bottomSheetDialog.findViewById(R.id.videoOption_Download);
        TextView textView2 = bottomSheetDialog.findViewById(R.id.videoOption_Details);
        bottomSheetDialog.findViewById(R.id.videoOption_Share).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ImageDownloadAndSave().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                new ProgressBack().execute(videoData.getReal_videopath(), videoData.getTitle());
                bottomSheetDialog.dismiss();
            }
        });
        textView2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(FeatureAdapter.this.context);
                @SuppressLint("WrongConstant") View inflate = ((LayoutInflater) FeatureAdapter.this.context.getSystemService("layout_inflater")).inflate(R.layout.dialog_report, null);
                builder.setView(inflate);
                Button button = inflate.findViewById(R.id.btn_report);
                Button button2 = inflate.findViewById(R.id.btn_cancel);
                final AlertDialog create = builder.create();
                button2.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        create.cancel();
                    }
                });
                button.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        Toast.makeText(FeatureAdapter.this.context, "Thanks for reporting", Toast.LENGTH_LONG).show();
                        create.cancel();
                    }
                });
                create.show();
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.show();
    }

    public void setLoaded() {
        this.loading = false;
    }

    public void addAll(List<VideoData> list) {
        this.videoDatalist = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        sb.append("addAll12346: ");
        sb.append(this.videoDatalist.size());
        Log.d("TAG", sb.toString());
        int i = 4;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (i == i2) {
                i += 10;
                VideoData videoData = new VideoData();
                videoData.setType(3);
                this.videoDatalist.add(videoData);
                this.videoDatalist.add(list.get(i2));
            } else {
                this.videoDatalist.add(list.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        StringBuilder sb = new StringBuilder();
        sb.append("getItemCount: ");
        sb.append(this.videoDatalist.size());
        Log.d("TAG", sb.toString());
        return this.videoDatalist.size();
    }

    public int getItemViewType(int i) {
        return this.videoDatalist.get(i).getType();
    }

    public void DownloadFile(String str, String str2) {
        try {
            String replace = str.replace(" ", "%20");
            StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStorageDirectory());
            sb.append("/Video_player");
            File file2 = new File(sb.toString());
            if (!file2.exists()) {
                file2.mkdirs();
            }
            URL url = new URL(replace);
            File file3 = new File(file2, str2);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(url.openConnection().getInputStream());
            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(20000);
            while (true) {
                int read = bufferedInputStream.read();
                if (read != -1) {
                    byteArrayBuffer.append((byte) read);
                } else {
                    FileOutputStream fileOutputStream = new FileOutputStream(file3);
                    fileOutputStream.write(byteArrayBuffer.toByteArray());
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void shareMultiplePhotos() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.SUBJECT", "Share");
        Activity activity = this.context;
        StringBuilder sb = new StringBuilder();
        sb.append(this.context.getApplicationContext().getPackageName());
        sb.append(".provider");
        intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(activity, sb.toString(), this.file));
        this.context.startActivity(Intent.createChooser(intent, "Select"));
    }

    public void populateUnifiedNativeAdView(UnifiedNativeAd unifiedNativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        unifiedNativeAdView.setMediaView((MediaView) unifiedNativeAdView.findViewById(R.id.ad_media));
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setIconView(unifiedNativeAdView.findViewById(R.id.ad_app_icon));
        unifiedNativeAdView.setPriceView(unifiedNativeAdView.findViewById(R.id.ad_price));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        unifiedNativeAdView.setAdvertiserView(unifiedNativeAdView.findViewById(R.id.ad_advertiser));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(unifiedNativeAd.getBody());
        }
        if (unifiedNativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }
        if (unifiedNativeAd.getIcon() == null) {
            unifiedNativeAdView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) unifiedNativeAdView.getIconView()).setImageDrawable(unifiedNativeAd.getIcon().getDrawable());
            unifiedNativeAdView.getIconView().setVisibility(View.VISIBLE);
        }
        if (unifiedNativeAd.getPrice() == null) {
            unifiedNativeAdView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getPriceView()).setText(unifiedNativeAd.getPrice());
        }
        if (unifiedNativeAd.getStore() == null) {
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(unifiedNativeAd.getStore());
        }
        if (unifiedNativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(unifiedNativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        if (unifiedNativeAd.getAdvertiser() == null) {
            unifiedNativeAdView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) unifiedNativeAdView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
            unifiedNativeAdView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(unifiedNativeAd);
    }
}
