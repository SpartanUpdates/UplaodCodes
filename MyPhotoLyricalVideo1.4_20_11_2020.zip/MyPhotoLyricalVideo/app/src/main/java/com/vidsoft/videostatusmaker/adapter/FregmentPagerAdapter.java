package com.vidsoft.videostatusmaker.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.vidsoft.videostatusmaker.Others.fragment.Bhojpuri_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Birthday_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Bollywood_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Dialogue_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.English_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Family_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Feeling_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Friendship_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Gujrati_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Love_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Malyalam_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Marathi_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Navratri_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.OldSong_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Panjabi_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Rain_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Rajesthani_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Romantic_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Sad_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Tamil_Fragment;
import com.vidsoft.videostatusmaker.Others.fragment.Telugu_Fragment;

public class FregmentPagerAdapter extends FragmentPagerAdapter {

    Family_Fragment family_fragment;
    Feeling_Fragment feeling_fragment;
    Friendship_Fragment friendship_fragment;
    Malyalam_Fragment malyalam_fragment;
    Marathi_Fragment marathi_fragment;
    Navratri_Fragment navratri_fragment;
    Bollywood_Fragment bollywood_fragment;
    Love_Fragment love_fragment;
    Birthday_Fragment birthday_fragment;
    Dialogue_Fragment dialogue_fragment;
    English_Fragment english_fragment;
    OldSong_Fragment oldSong_fragment;
    Panjabi_Fragment panjabi_fragment;
    Rain_Fragment rain_fragment;
    Rajesthani_Fragment rajesthani_fragment;
    Romantic_Fragment romantic_fragment;
    Sad_Fragment sad_fragment;
    Gujrati_Fragment gujrati_fragment;
    Tamil_Fragment tamil_fragment;
    Telugu_Fragment telugu_fragment;
    Bhojpuri_Fragment bhojpuri_fragment;


    public FregmentPagerAdapter(final FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    @Override
    public int getCount() {
        return 21;
    }

    @Override
    public Fragment getItem(final int n) {
        if (n == 0) {
            return this.bollywood_fragment = new Bollywood_Fragment();
        }
        if (n == 1) {
            return this.gujrati_fragment = new Gujrati_Fragment();
        }
        if (n == 2) {
            return this.bhojpuri_fragment = new Bhojpuri_Fragment();
        }
        if (n == 3) {
            return this.birthday_fragment = new Birthday_Fragment();
        }
        if (n == 4) {
            return this.dialogue_fragment = new Dialogue_Fragment();
        }
        if (n == 5) {
            return this.english_fragment = new English_Fragment();
        }
        if (n == 6) {
            return this.family_fragment = new Family_Fragment();
        }
        if (n == 7) {
            return this.feeling_fragment = new Feeling_Fragment();
        }
        if (n == 8) {
            return this.friendship_fragment = new Friendship_Fragment();
        }
        if (n == 9) {
            return this.love_fragment = new Love_Fragment();
        }
        if (n == 10) {
            return this.malyalam_fragment = new Malyalam_Fragment();
        }
        if (n == 11) {
            return this.marathi_fragment = new Marathi_Fragment();
        }
        if (n == 12) {
            return this.navratri_fragment = new Navratri_Fragment();
        }
        if (n == 13) {
            return this.oldSong_fragment = new OldSong_Fragment();
        }
        if (n == 14) {
            return this.panjabi_fragment = new Panjabi_Fragment();
        }
        if (n == 15) {
            return this.rain_fragment = new Rain_Fragment();
        }
        if (n == 16) {
            return this.rajesthani_fragment = new Rajesthani_Fragment();
        }
        if (n == 17) {
            return this.romantic_fragment = new Romantic_Fragment();
        }
        if (n == 18) {
            return this.sad_fragment = new Sad_Fragment();
        }
        if (n == 19) {
            return this.tamil_fragment = new Tamil_Fragment();
        }
        if (n == 20) {
            return this.telugu_fragment = new Telugu_Fragment();
        }
        return null;
    }
}
