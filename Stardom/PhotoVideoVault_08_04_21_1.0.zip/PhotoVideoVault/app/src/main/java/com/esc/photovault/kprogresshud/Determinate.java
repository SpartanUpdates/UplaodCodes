
package com.esc.photovault.kprogresshud;

public interface Determinate {
    void setMax(int max);
    void setProgress(int progress);
}
