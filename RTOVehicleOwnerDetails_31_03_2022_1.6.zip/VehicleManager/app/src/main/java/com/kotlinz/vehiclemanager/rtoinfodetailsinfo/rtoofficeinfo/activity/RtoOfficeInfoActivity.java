package com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.rtoinfodetailsinfo.rtoofficeinfo.Adapter.ExpandableListViewAdapter;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RtoOfficeInfoActivity extends AppCompatActivity {
    private Activity activity = RtoOfficeInfoActivity.this;
    private ArrayList<String> stateList = new ArrayList<>();
    private List<List<String>> cityList = new ArrayList<>();
    private ExpandableListView expandableListView;
    private HashMap<String, List<String>> bindingList = new HashMap();
    private ImageView iv_back;
    private AppCompatDialog dialog;
    private TextView title_tv;

    private NativeAd nativeAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rtoofficeinfo);

        expandableListView = findViewById(R.id.expandListView);
        title_tv = findViewById(R.id.title_tv);
        iv_back = findViewById(R.id.iv_back);
        PutAnalyticsEvent();
        Setlistener();
        DialogAnimation();
        LoadNativeAds();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        }

        DarkTheame darkTheame = new DarkTheame(RtoOfficeInfoActivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        }

        getRtoOfficeData();
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOfficeInfoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


     private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (RtoOfficeInfoActivity.this.nativeAd != null) {
                            RtoOfficeInfoActivity.this.nativeAd.destroy();
                        }
                        RtoOfficeInfoActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_dialog_search);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void Setlistener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        expandableListView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                expandableListView.setIndicatorBounds(expandableListView.getMeasuredWidth() - 100, expandableListView.getMeasuredWidth());
            }
        });

        final int[] prevExpandPosition = {-1};

        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                if (prevExpandPosition[0] >= 0 && prevExpandPosition[0] != groupPosition) {
                    expandableListView.collapseGroup(prevExpandPosition[0]);
                }
                prevExpandPosition[0] = groupPosition;
            }
        });
    }

    private void getRtoOfficeData() {
        String cityStateJsonData = Utils.getStateCityFromJson(RtoOfficeInfoActivity.this, "rtoofficeinfo.json");
        try {
            JSONObject obj = new JSONObject(cityStateJsonData);
            JSONArray mainArray = obj.getJSONArray("details");
            for (int i = 0; i < mainArray.length(); i++) {
                JSONObject stateObj = mainArray.getJSONObject(i);
                String stateName = stateObj.getString("name");
                stateList.add(stateName);
                List<String> CityNamelist = new ArrayList<>();
                JSONArray cityArray = stateObj.getJSONArray("rtoList");
                for (int j = 0; j < cityArray.length(); j++) {
                    JSONObject cityObj = cityArray.getJSONObject(j);
                    String insideStateName=cityObj.getString("state");
                    if(stateName.equals(insideStateName))
                    {
                        String cityName = cityObj.getString("district");
                        String rtoCode = cityObj.getString("rto_code");
                        String state = cityObj.getString("state");
                        String address = cityObj.getString("address");
                        String contact = cityObj.getString("phone");
                        String website = cityObj.getString("website");
                        CityNamelist.add(rtoCode + ">" + cityName + ">" + state + ">" + address + ">" + contact + ">" + website);
                    }
                }

                cityList.add(CityNamelist);
                bindingList.put(stateList.get(i), cityList.get(i));

                ExpandableListAdapter expandableListAdapter = new ExpandableListViewAdapter(activity, stateList, bindingList);
                expandableListView.setAdapter(expandableListAdapter);

                dialog.dismiss();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(RtoOfficeInfoActivity.this, MainActivity.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 20;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(RtoOfficeInfoActivity.this, MainActivity.class));
                finish();
            }
        }
    }
}