package com.kotlinz.photoslideshow.sidemenu.interfaces;

public interface Resourceble {
    int getImageRes();

    String getName();
}
