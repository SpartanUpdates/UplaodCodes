package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.View;

import com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter.f0;

public class d0 implements View.OnClickListener {
    public final int n;
    public final f0 o;

    public d0(f0 f0Var, int i) {
        this.o = f0Var;
        this.n = i;
    }

    public void onClick(View view) {
        f0 f0Var = this.o;
        f0Var.s.j(false, f0Var.t, f0Var.r, ((Integer) f0Var.q.get(this.n)).intValue());
    }

}
