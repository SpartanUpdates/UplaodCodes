package com.esc.fontappstylish.activity;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.core.app.NotificationCompat;

public class Utils {
    public static String THEME_PREFS = "THEME_PREFS";
    public static boolean isSoundOn = true;
    public static float mFxVolume = 0.3f;
    public static int progress = 100;

    public static void setStaticVariables(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(THEME_PREFS, 0);
        isSoundOn = sharedPreferences.getBoolean("soundEnable", true);
        mFxVolume = sharedPreferences.getFloat("soundLevel", 0.3f);
        progress = sharedPreferences.getInt(NotificationCompat.CATEGORY_PROGRESS, 10);
    }
}
