package com.example.postermaker.textitems;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import com.example.postermaker.eaz_EditActivity;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_TextSizeLayout implements OnClickListener, OnProgressChangeListener
{
    int hight;
    LayoutParams params;
    int textsize;
    int width;

    public eaz_TextSizeLayout() {
        this.params = eaz_EditActivity.logoText.getLayoutParams();
        this.textsize = (int)eaz_EditActivity.logoText.getTextSize();
        this.width = this.params.width;
        this.hight = this.params.height;
    }

    public void onClick(final View view) {
        if (view.equals(eaz_EditActivity.oktextsize)) {
            eaz_EditActivity.textsizeItemlayout.setVisibility(View.GONE);
            return;
        }
        if (view.equals(eaz_EditActivity.canceltextsize)) {
            eaz_EditActivity.logoText.setLayoutParams(this.params);
            eaz_EditActivity.logoText.setTextSize((float)this.textsize);
            eaz_EditActivity.textsizeItemlayout.setVisibility(View.GONE);
        }
    }

    public void onProgressChanged(final DiscreteSeekBar discreteSeekBar, final int n, final boolean b) {
        if (discreteSeekBar.equals(eaz_EditActivity.textbgwidth)) {
            final LayoutParams layoutParams = eaz_EditActivity.logoText.getLayoutParams();
            layoutParams.width = n;
            eaz_EditActivity.logoText.setLayoutParams(layoutParams);
            eaz_EditActivity.logoText.invalidate();
            return;
        }
        if (discreteSeekBar.equals(eaz_EditActivity.textbghight)) {
            final LayoutParams layoutParams2 = eaz_EditActivity.logoText.getLayoutParams();
            layoutParams2.height = n;
            eaz_EditActivity.logoText.setLayoutParams(layoutParams2);
            eaz_EditActivity.logoText.invalidate();
            return;
        }
        if (discreteSeekBar.equals(eaz_EditActivity.textsizes)) {
            eaz_EditActivity.logoText.setTextSize((float)n);
            eaz_EditActivity.logoText.invalidate();
        }
    }

    public void onStartTrackingTouch(final DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(final DiscreteSeekBar discreteSeekBar) {
    }

    public void showTextsizeLayout() {
        eaz_EditActivity.textsizeItemlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.textbgwidth.setOnProgressChangeListener((DiscreteSeekBar.OnProgressChangeListener)this);
        eaz_EditActivity.textbghight.setOnProgressChangeListener((DiscreteSeekBar.OnProgressChangeListener)this);
        eaz_EditActivity.textsizes.setOnProgressChangeListener((DiscreteSeekBar.OnProgressChangeListener)this);
        eaz_EditActivity.oktextsize.setOnClickListener((OnClickListener)this);
        eaz_EditActivity.canceltextsize.setOnClickListener((OnClickListener)this);
    }
}
