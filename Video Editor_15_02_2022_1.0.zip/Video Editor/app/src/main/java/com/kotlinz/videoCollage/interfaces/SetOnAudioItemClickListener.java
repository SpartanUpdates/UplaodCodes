package com.kotlinz.videoCollage.interfaces;

public interface SetOnAudioItemClickListener {
    void onAddClick(int i);

    void onItemClick(int i, String str);
}
