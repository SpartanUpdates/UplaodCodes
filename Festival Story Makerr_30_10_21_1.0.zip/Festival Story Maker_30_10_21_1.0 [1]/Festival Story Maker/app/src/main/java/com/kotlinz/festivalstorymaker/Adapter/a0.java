package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.Interface.x8;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.CanvasEditorActivity;

import java.util.ArrayList;

public class a0 extends RecyclerView.Adapter<a0.ViewHolder> {

    public CanvasEditorActivity canvasEditorActivity;
    public ArrayList<Integer> colorList;
    public int i;
    public x8 j;
    public boolean k;
    public float l;

    public a0(final Activity activity, final ArrayList<Integer> h, final int i, final x8 j, final boolean k, final int n) {
        this.l = -1.0f;
        this.canvasEditorActivity = (CanvasEditorActivity) activity;
        this.colorList = h;
        this.i = i;
        this.k = k;
        this.l = (float)n;
        this.j = j;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_color_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (this.l != -1.0f) {
            holder.rlMain.getLayoutParams().height = (int)(this.l / 3.0f) - 16;
            holder.rlMain.requestLayout();
        }
        int finalPosition = position;
        holder.cvColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j.h(false, k, i, colorList.get(finalPosition));
            }
        });
        holder.ivImagePicker.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j.h(true, k, i, 0);
            }
        }));
        if (colorList.get(position) == null) {
            holder.llCardColor.setBackground((Drawable)null);
            holder.ivImagePicker.setVisibility(View.VISIBLE);
            holder.cvColor.setCardBackgroundColor(0);
            return;
        }
        holder.cvColor.setCardBackgroundColor(colorList.get(position));
        holder.ivImagePicker.setVisibility(View.GONE);
        position = this.colorList.get(position);
        if (position == -1) {
            holder.llCardColor.setBackground(canvasEditorActivity.getResources().getDrawable(R.drawable.rounded_corner_black_border));
            return;
        }
        holder.llCardColor.setBackground((Drawable)null);
    }

    @Override
    public int getItemCount() {
        return colorList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public CardView cvColor;
        public LinearLayout llCardColor;
        public ImageView ivImagePicker;
        public RelativeLayout rlMain;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.cvColor = view.findViewById(R.id.cardColor);
            this.llCardColor = view.findViewById(R.id.cardBgColor);
            this.ivImagePicker = view.findViewById(R.id.imgPicker);
            this.rlMain = view.findViewById(R.id.rlMain);
        }
    }
}
