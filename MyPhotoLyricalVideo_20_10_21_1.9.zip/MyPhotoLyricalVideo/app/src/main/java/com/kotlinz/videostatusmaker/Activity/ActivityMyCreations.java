package com.kotlinz.videostatusmaker.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import androidx.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.videostatusmaker.App.MyApplication;
import com.kotlinz.videostatusmaker.R;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import com.kotlinz.videostatusmaker.adapter.MyCreationAdapter;
import static com.kotlinz.videostatusmaker.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;


public class ActivityMyCreations extends Activity {
    Activity activity = ActivityMyCreations.this;
    public static ArrayList<String> photoArrayList;
    Typeface typeface;
    TextView tvTitle;
    public static int pos;
    MyCreationAdapter myCreationAdapter;
    ImageView ivBack;
    String strFolderName;
    GridView gridView;
    File[] listFile;

    private NativeAd nativeAd;

    static {
        ActivityMyCreations.photoArrayList = new ArrayList<String>();
    }

    public ActivityMyCreations() {
        this.listFile = null;
    }


    public void delete(final int n) {
        final AlertDialog.Builder dialogobj = new AlertDialog.Builder((Context) this);
        dialogobj.setTitle((CharSequence) "Confirm Delete !");
        dialogobj.setMessage((CharSequence) "Are you sure to delete Image??");
        dialogobj.setPositiveButton((CharSequence) "YES", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
                if (new File(ActivityMyCreations.photoArrayList.get(n)).delete()) {
                    ActivityMyCreations.photoArrayList.remove(n);
                    Toast.makeText((Context) ActivityMyCreations.this, (CharSequence) "File Deleted", Toast.LENGTH_SHORT).show();
                    ActivityMyCreations.this.myCreationAdapter.notifyDataSetChanged();
                }
            }
        });
        dialogobj.setNegativeButton((CharSequence) "NO", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.dismiss();
            }
        });
        dialogobj.show();
    }

    public void getFromSdcard() {
        final File externalStorageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        final StringBuilder sb = new StringBuilder();
        sb.append(this.strFolderName);
        sb.append("/Video");
        final File file = new File(externalStorageDirectory, sb.toString());
        if (file.isDirectory()) {
            Arrays.sort(this.listFile = file.listFiles(), new Comparator() {
                @Override
                public int compare(final Object o, final Object o2) {
                    final File file = (File) o;
                    final long lastModified = file.lastModified();
                    final File file2 = (File) o2;
                    if (lastModified > file2.lastModified()) {
                        return -1;
                    }
                    if (file.lastModified() < file2.lastModified()) {
                        return 1;
                    }
                    return 0;
                }
            });
            for (int i = 0; i < this.listFile.length; ++i) {
                if (this.listFile[i].getName().contains("temp")) {
                    this.listFile[i].delete();
                } else {
                    ActivityMyCreations.photoArrayList.add(this.listFile[i].getAbsolutePath());
                }
            }
        }
    }

    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.mywork);
        this.getWindow().addFlags(1024);
        this.strFolderName = this.getResources().getString(R.string.app_name);
        PutAnalyticsEvent();
        LoadNativeAds();
        final StrictMode.VmPolicy.Builder strictMode$VmPolicy$Builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(strictMode$VmPolicy$Builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            strictMode$VmPolicy$Builder.detectFileUriExposure();
        }

        bindview();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivityMyCreations");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void bindview() {
        this.gridView = (GridView) this.findViewById(R.id.gridview);
        this.ivBack = (ImageView) this.findViewById(R.id.back);
        this.tvTitle = (TextView) this.findViewById(R.id.title);

    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (ActivityMyCreations.this.nativeAd != null) {
                            ActivityMyCreations.this.nativeAd.destroy();
                        }
                        ActivityMyCreations.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView =
                                (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    protected void onResume() {
        super.onResume();
        this.myCreationAdapter.notifyDataSetChanged();
    }

    public void preview(final int pos) {
        ActivityMyCreations.pos = pos;
        this.startActivity(new Intent(this.getApplicationContext(), (Class) ActivityMyCreationVideoplay.class));
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(ActivityMyCreations.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    private void init() {
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                if (MyApplication.isShowAd == 1) {
                    onBackPressed();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 13;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;
                    } else {
                        onBackPressed();
                    }
                }
            }
        });
        ActivityMyCreations.photoArrayList.clear();
        this.getFromSdcard();
        this.myCreationAdapter = new MyCreationAdapter((Context) this, ActivityMyCreations.photoArrayList);
        this.gridView.setAdapter((ListAdapter) this.myCreationAdapter);
        this.myCreationAdapter.notifyDataSetChanged();
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.tvTitle.setTypeface(this.typeface);
    }

    void setLayout() {
        final int widthPixels = this.getResources().getDisplayMetrics().widthPixels;
        final RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(widthPixels * 70 / 1080, this.getResources().getDisplayMetrics().heightPixels * 70 / 1920);
        layoutParams.addRule(15);
        layoutParams.setMargins(widthPixels * 40 / 1080, 0, 0, 0);
        this.ivBack.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
    }
}
