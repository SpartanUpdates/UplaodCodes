package com.esc.socialmediacleaner.activity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.ViewPager;

import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.datastructure.AllData;
import com.esc.socialmediacleaner.datastructure.DeleteData;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import com.esc.socialmediacleaner.datastructure.MediaType;
import com.esc.socialmediacleaner.kprogresshud.KProgressHUD;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.adapter.SectionsPagerAdapter;
import com.esc.socialmediacleaner.util.FullAdScreen;
import com.esc.socialmediacleaner.util.Util;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.android.material.tabs.TabLayout.Tab;
import com.skyfishjy.library.RippleBackground;
import java.util.ArrayList;

public class FileTabsScreen extends FullAdScreen implements OnClickListener {
    private Button btnDelete;
    private ArrayList<FileDataWrapper> filesList;
    private boolean fromClick = false;
    private long lastClickedTime = 0;
    private TabLayout tabs;
    private TextView tvTitle;
    private TextView tv_all_selection;
    private TextView tv_select_toggle;
    private ViewPager viewPager;
    private ImageView iv_back;

    public void onResume() {
        super.onResume();
        if (MyApplication.getInstance().allData.dataDeleted) {
            if (MyApplication.getInstance().allData.redirectHome) {
                finish();
            } else {
                this.filesList = getFilesList();
                manageVisibility(false);
            }
        }
    }

    private void manageVisibility(boolean z) {
        int i = 8;
        this.tabs.setVisibility(z ? View.GONE : View.VISIBLE);
        this.viewPager.setVisibility(z ? View.GONE : View.VISIBLE);
        this.btnDelete.setVisibility(z ? View.GONE : View.VISIBLE);
        this.tv_select_toggle.setVisibility(z ? View.GONE : View.VISIBLE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(z);
        }
        View findViewById = findViewById(R.id.layout_processing);
        if (z) {
            i = 0;
        }
        findViewById.setVisibility(i);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_file_tabs_screen);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");

        track("LISTSCREEN_VISIT");
        this.tvTitle = findViewById(R.id.tv_title);
        iv_back = findViewById(R.id.iv_back);
        this.tv_select_toggle = findViewById(R.id.tv_select_toggle);
        this.btnDelete = findViewById(R.id.btn_delete);
        this.tv_all_selection = findViewById(R.id.tv_all_selection);
        this.viewPager = findViewById(R.id.view_pager);
        this.tabs = findViewById(R.id.tabs);
        this.btnDelete.setOnClickListener(this);
        this.tv_select_toggle.setOnClickListener(this);
        ArrayList filesList = getFilesList();
        this.filesList = filesList;
        if (filesList.size() == 0) {
            findViewById(R.id.tv_empty).setVisibility(View.VISIBLE);
        } else {
            setAdapter();
        }
        MyApplication.getInstance().allData.setAppSpecificList(this.filesList, 0);
        setListners();
        loadAd();
    }

    private void setListners() {
        this.tabs.addOnTabSelectedListener(new OnTabSelectedListener() {
            public void onTabReselected(Tab tab) {
            }

            public void onTabUnselected(Tab tab) {
            }

            public void onTabSelected(Tab tab) {
                MyApplication.getInstance().allData.setAppSpecificList(FileTabsScreen.this.filesList, tab.getPosition());
                FileTabsScreen.this.sendMessage();
            }
        });
        this.tv_select_toggle.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                if (FileTabsScreen.this.btnDelete.getVisibility() == View.VISIBLE) {
                    FileTabsScreen fileTabsScreen;
                    if (editable.toString().equalsIgnoreCase(FileTabsScreen.this.getString(R.string.str_selecton))) {
                        fileTabsScreen = FileTabsScreen.this;
                        Toast.makeText(fileTabsScreen, fileTabsScreen.getString(R.string.selection_mode_on), Toast.LENGTH_SHORT).show();
                    } else {
                        fileTabsScreen = FileTabsScreen.this;
                        Toast.makeText(fileTabsScreen, fileTabsScreen.getString(R.string.selection_mode_off), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        iv_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                id = 100;
                if (interstitial !=null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    onBackPressed();
                }
            }
        });
    }

    private void setAdapter() {
        this.viewPager.setAdapter(null);
        this.tabs.setupWithViewPager(null);
        this.viewPager = null;
        this.tabs = null;
        ViewPager viewPager = findViewById(R.id.view_pager);
        this.viewPager = viewPager;
        viewPager.setOffscreenPageLimit(2);
        this.tabs = findViewById(R.id.tabs);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager(), this.filesList);
        this.viewPager.setAdapter(sectionsPagerAdapter);
        sectionsPagerAdapter.notifyDataSetChanged();
        this.tabs.setupWithViewPager(null);
        this.tabs.setupWithViewPager(this.viewPager);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        onBackPressed();
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        if (this.btnDelete.getVisibility() == View.VISIBLE) {
            if (!MyApplication.getInstance().isSelecting || (MyApplication.getInstance().allData.totSelectedItem <= 0 && !this.fromClick)) {
                MyApplication.getInstance().allData.uncheckAll(this.filesList);
                MyApplication.getInstance().isSelecting = false;
                super.onBackPressed();
            } else {
                this.fromClick = false;
                this.tv_select_toggle.setText(getString(R.string.str_selectoff));
                this.btnDelete.setText(getString(R.string.str_delete));
                MyApplication.getInstance().allData.uncheckAll(this.filesList);
                MyApplication.getInstance().isSelecting = false;
                TextView textView = this.tv_all_selection;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(MyApplication.getInstance().allData.totSelectedItem);
                stringBuilder.append("/");
                stringBuilder.append(MyApplication.getInstance().allData.total_filetype);
                textView.setText(stringBuilder.toString());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    this.btnDelete.setBackground(getDrawable(R.drawable.btn_gray_round));
                }
                sendMessage();
            }
        }
    }

    public void sendMessage() {
        Log.d("sender", "Broadcasting message");
        LocalBroadcastManager.getInstance(this).sendBroadcast(new Intent("back.pressed.selecting"));
    }

    private ArrayList<FileDataWrapper> getFilesList() {
        ArrayList<FileDataWrapper> arrayList = new ArrayList();
        int intExtra = getIntent().getIntExtra("TYPE", 0);
        if (intExtra == MediaType.IMAGES.ordinal()) {
            arrayList = MyApplication.getInstance().allData.imgList;
            this.tvTitle.setText(getString(R.string.str_images));
            return arrayList;
        } else if (intExtra == MediaType.VIDEOS.ordinal()) {
            arrayList = MyApplication.getInstance().allData.vidList;
            this.tvTitle.setText(getString(R.string.str_videos));
            return arrayList;
        } else if (intExtra == MediaType.AUDIOS.ordinal()) {
            arrayList = MyApplication.getInstance().allData.audList;
            this.tvTitle.setText(getString(R.string.str_audio));
            return arrayList;
        } else if (intExtra == MediaType.DOCUMENTS.ordinal()) {
            arrayList = MyApplication.getInstance().allData.docList;
            this.tvTitle.setText(getString(R.string.str_docs));
            return arrayList;
        } else if (intExtra != MediaType.GIFS.ordinal()) {
            return arrayList;
        } else {
            ArrayList arrayList2 = MyApplication.getInstance().allData.gifList;
            this.tvTitle.setText(getString(R.string.str_gif));
            return arrayList2;
        }
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_delete) {
            if (!(doubleClicked() || MyApplication.getInstance().allData.totSelectedItem == 0)) {
                final Dialog dialog = new Dialog(this);
                dialog.requestWindowFeature(1);
                if (dialog.getWindow() != null) {
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().getAttributes().windowAnimations = R.style.DefaultDialogAnimation;
                }
                dialog.setContentView(R.layout.dialog_delete);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);
                dialog.getWindow().setLayout(-1, -1);
                dialog.getWindow().setGravity(17);
                ((TextView) dialog.findViewById(R.id.dialog_title)).setText(getResources().getString(R.string.app_name));
                ((TextView) dialog.findViewById(R.id.dialog_msg)).setText(getResources().getString(R.string.confirm_delte_message));
                dialog.findViewById(R.id.ll_no_txt).setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.findViewById(R.id.ll_yes_txt).setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        FileTabsScreen fileTabsScreen = FileTabsScreen.this;
                        new DeleteData(fileTabsScreen, fileTabsScreen.filesList) {
                            public void onPreExecute() {
                                super.onPreExecute();
                                FileTabsScreen.this.manageVisibility(true);
                                RippleBackground rippleBackground = FileTabsScreen.this.findViewById(R.id.content);
                                TextView textView = FileTabsScreen.this.findViewById(R.id.tv_status);
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Cleaning ");
                                stringBuilder.append(FileTabsScreen.this.tvTitle.getText().toString());
                                textView.setText(stringBuilder.toString());
                                rippleBackground.startRippleAnimation();
                            }

                            public void onPostExecute(String str) {
                                super.onPostExecute(str);
                                new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                                    public void run() {
                                        if (MyApplication.getInstance().allData.totSelectedItem == MyApplication.getInstance().allData.total_filetype) {
                                            MyApplication.getInstance().allData.redirectHome = true;
                                        }
                                        MyApplication.getInstance().isSelecting = false;
                                        FileTabsScreen.this.tv_select_toggle.setText(FileTabsScreen.this.getString(R.string.str_selectoff));
                                        FileTabsScreen.this.btnDelete.setText(FileTabsScreen.this.getString(R.string.str_delete));
                                        AllData allData = MyApplication.getInstance().allData;
                                        allData.total_filetype -= MyApplication.getInstance().allData.totSelectedItem;
                                        String str = "";
                                        FileTabsScreen.this.tv_all_selection.setText(str);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                            FileTabsScreen.this.btnDelete.setBackground(FileTabsScreen.this.getDrawable(R.drawable.btn_gray_round));
                                        }
//                                        FileTabsScreen.this.btnDelete.setTextColor(Color.parseColor("#909090"));
//                                        if (FileTabsScreen.this.isLoaded()) {
//                                            FileTabsScreen.this.showAd();
//                                            return;
//                                        }
                                        Intent intent = new Intent(FileTabsScreen.this, ResultScreen.class);
                                        String string = FileTabsScreen.this.getString(R.string.str_recovered);
                                        Object[] objArr = new Object[1];
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append(str);
                                        stringBuilder.append(Util.convertBytes(MyApplication.getInstance().allData.totSelectedSize));
                                        objArr[0] = stringBuilder.toString();
                                        intent.putExtra("MESSAGE", String.format(string, objArr));
                                        StringBuilder stringBuilder2 = new StringBuilder();
                                        stringBuilder2.append(FileTabsScreen.this.tvTitle.getText().toString());
                                        stringBuilder2.append(str);
                                        intent.putExtra("TITLE", stringBuilder2.toString());
                                        FileTabsScreen.this.startActivity(intent);
                                        MyApplication.getInstance().allData.totSelectedItem = 0;
                                        MyApplication.getInstance().allData.totSelectedSize = 0;
                                    }
                                }, 2000);
                            }
                        }.execute();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        } else if (view.getId() == R.id.tv_select_toggle) {
            if (this.tv_select_toggle.getText().toString().equalsIgnoreCase(getString(R.string.str_selecton))) {
                this.fromClick = true;
                onBackPressed();
            } else {
                MyApplication.getInstance().isSelecting = true;
                this.tv_select_toggle.setText(getString(R.string.str_selecton));
            }
        }
    }

    public boolean doubleClicked() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.lastClickedTime;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("diff ");
        stringBuilder.append(elapsedRealtime);
        Log.e("TTTTTTTTT", stringBuilder.toString());
        this.lastClickedTime = SystemClock.elapsedRealtime();
        return elapsedRealtime < 600;
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;
    private void loadAd() {

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(FileTabsScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id)
                {
                    case 100:
                        onBackPressed();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(FileTabsScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
