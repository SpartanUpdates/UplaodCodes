package com.kotlinz.festivalstorymaker.Listener.festival;

import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class o5 implements ImageStickerViewNew.c {
    public final  ImageStickerViewNew a;
    public final  FestivalDetailActivity_New b;

    public o5(FestivalDetailActivity_New festivalDetailActivity_New, ImageStickerViewNew imageStickerViewNew) {
        this.b = festivalDetailActivity_New;
        this.a = imageStickerViewNew;
    }

    public void a(ImageStickerViewNew imageStickerViewNew) {
        imageStickerViewNew.setInEdit(false);
        this.b.b1 = imageStickerViewNew;
        imageStickerViewNew.setInEdit(true);
    }

    public void b(ImageStickerViewNew imageStickerViewNew) {
        this.b.frame.removeView(imageStickerViewNew);
    }

    public void c(Boolean bool) {
        this.b.scroll.requestDisallowInterceptTouchEvent(bool.booleanValue());
        if (bool.booleanValue()) {
            this.b.b1 = this.a;
        }
    }

    public void d(ImageStickerViewNew imageStickerViewNew) {
    }

}
