package com.wavymusic.mp3Cutter.mycreation.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.wavymusic.mp3Cutter.Model.SongCropModel;
import com.wavymusic.mp3Cutter.mycreation.activity.SongCropMycreationActivity;
import com.wavymusic.R;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.concurrent.TimeUnit;

public class MycropSongAdapter extends RecyclerView.Adapter<MycropSongAdapter.MyViewHolder> {

    public SongCropMycreationActivity ActivityOfAudioCreation;
    public int selectedPosition = -1;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_saved_music_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final SongCropModel holder2 = ActivityOfAudioCreation.songList.get(position);
        holder.tvMusicEndTime.setText(getTimeDuration(holder2.g()));
        holder.tvMusicName.setText(holder2.f());
        if (selectedPosition != position) {
            holder.Imagecontent.setSelected(false);
            Log.e("checkkkkk", "setSelected(false)");
            holder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
            holder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
        } else {
            Log.e("checkkkkk", "setSelected(true)");
            holder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_pause);
            holder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
            holder.Imagecontent.setSelected(true);
        }
        holder.IvShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ShareAudio(position);
            }
        });
        holder.IvDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Delete(holder2.e(), position);
            }
        });
        holder.Imagelayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                boolean isSelected = holder.Imagecontent.isSelected();
                int i = R.drawable.icon_song_thumb;
                if (isSelected) {
                    ActivityOfAudioCreation.p();
                    if (ActivityOfAudioCreation.q()) {
                        holder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_pause);
                        i = R.drawable.icon_song_thumb;
                    } else {
                        holder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
                    }
                    holder.Imagecontent.setImageResource(i);
                } else {
                    holder.Imagecontent.setSelected(true);
                    Log.e("DDDUUUUU", "vvvvvvvvvvv");
                    int b2 = selectedPosition;
                    if (b2 == position) {
                        Log.e("DDDUUUUU", "vvvvvvvvvvv1111");
                        holder.Imagecontent.setSelected(true);
                        holder.IvPopularPlayPause.setImageResource(R.drawable.icon_player_play);
                        holder.Imagecontent.setImageResource(R.drawable.icon_song_thumb);
                        return;
                    }
                    selectedPosition = position;
                    ActivityOfAudioCreation.a(holder2, position);
                    notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (ActivityOfAudioCreation.songList == null) {
            return 0;
        }
        return this.ActivityOfAudioCreation.songList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        protected TextView tvMusicName;
        protected TextView tvMusicEndTime;
        protected ImageView Imagecontent;
        protected LinearLayout Imagelayout;
        ImageView IvPopularPlayPause;
        ImageView IvShare;
        ImageView IvDelete;

        public MyViewHolder(View view) {
            super(view);
            tvMusicName = view.findViewById(R.id.tvMusicName);
            tvMusicEndTime= view.findViewById(R.id.tvMusicEndTime);
            Imagecontent = view.findViewById(R.id.image_content);
            Imagelayout = view.findViewById(R.id.image_layout);
            IvPopularPlayPause= view.findViewById(R.id.ivPopularPlayPause);
            IvShare= view.findViewById(R.id.ivShare);
            IvDelete = view.findViewById(R.id.ivDelete);
        }
    }

    public MycropSongAdapter(SongCropMycreationActivity songCropMycreationActivity) {
        this.ActivityOfAudioCreation = songCropMycreationActivity;
    }

    @SuppressLint("DefaultLocale")
    private String getTimeDuration(long j) {
        return String.format("%02d:%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toHours(j)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j))));
    }

    private void Delete(final String str, final int pos) {
        Log.e("deletePath", str);
        AlertDialog.Builder builder = new AlertDialog.Builder(ActivityOfAudioCreation, R.style.AppDialog);
        builder.setTitle(R.string.deletetitle);
        builder.setMessage(ActivityOfAudioCreation.getResources().getString(R.string.deleteMessage) + ActivityOfAudioCreation.songList.get(pos).f() + ".mp3 ?");
        builder.setPositiveButton(ActivityOfAudioCreation.getString(R.string.delete_btn), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    ScanFile(str, ActivityOfAudioCreation);
                    ActivityOfAudioCreation.s();
                    ActivityOfAudioCreation.songList.remove(pos);
                    notifyDataSetChanged();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        builder.setNegativeButton(ActivityOfAudioCreation.getString(R.string.cancel_btn), null);
        builder.show();
    }

    private void ScanFile(String str, Context context) {
        File file = new File(str);
        if (file.exists()) {
            file.delete();
            MediaScannerConnection.scanFile(context, new String[]{file.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {

                public void onScanCompleted(String str, Uri uri) {
                    Log.e("ExternalStorage", "Scanned " + str + ":");
                    StringBuilder sb = new StringBuilder();
                    sb.append("-> uri=");
                    sb.append(uri);
                    Log.e("ExternalStorage", sb.toString());
                }
            });
        }
    }

    private void ShareAudio(int i) {
        File file = new File(ActivityOfAudioCreation.songList.get(i).e());
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("audio/*");
        intent.putExtra("android.intent.extra.SUBJECT", ActivityOfAudioCreation.getString(R.string.app_name));
        intent.putExtra("android.intent.extra.TEXT", ActivityOfAudioCreation.getString(R.string.get_free) + ActivityOfAudioCreation.getString(R.string.app_name) + " Music at here : https://play.google.com/store/apps/details?id=" + ActivityOfAudioCreation.getPackageName());
        intent.putExtra("android.intent.extra.TITLE", "Wavy Music : Particle.ly Video Status Maker");
        final Uri ShareUri = FileProvider.getUriForFile(ActivityOfAudioCreation, ActivityOfAudioCreation.getPackageName() + ".provider", file);
        intent.putExtra("android.intent.extra.STREAM", ShareUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ActivityOfAudioCreation.startActivity(Intent.createChooser(intent, ActivityOfAudioCreation.getString(R.string.share_audio)));
    }
}