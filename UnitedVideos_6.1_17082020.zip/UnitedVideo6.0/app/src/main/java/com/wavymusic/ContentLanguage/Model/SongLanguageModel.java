package com.wavymusic.ContentLanguage.Model;

public class SongLanguageModel {
    public String LanId;
    public String LanName;
    public boolean IsLanguageSelected;

    public SongLanguageModel(String lanId, String lanName) {
        LanId = lanId;
        LanName = lanName;
    }

    public String getLanId() {
        return LanId;
    }

    public void setLanId(String lanId) {
        LanId = lanId;
    }

    public String getLanName() {
        return LanName;
    }

    public void setLanName(String lanName) {
        LanName = lanName;
    }
}
