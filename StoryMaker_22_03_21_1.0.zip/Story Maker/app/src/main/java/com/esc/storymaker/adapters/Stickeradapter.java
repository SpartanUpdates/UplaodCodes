package com.esc.storymaker.adapters;

import android.content.Context;
import android.graphics.Bitmap.Config;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.esc.storymaker.R;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions.Builder;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import java.util.ArrayList;

public class Stickeradapter extends BaseAdapter {
    ArrayList<String> arrayList = new ArrayList();
    Context context;
    LayoutInflater inflater;

    class ViewHolder {
        ImageView imageview;

        ViewHolder() {
        }
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public Stickeradapter(Context context, ArrayList<String> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        initImageLoader(context);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public Stickeradapter(Context context) {
        this.context = context;
    }

    public int getCount() {
        return this.arrayList.size();
    }

    public String getItem(int i) {
        return (String) this.arrayList.get(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            ViewHolder viewHolder = new ViewHolder();
            View inflate = this.inflater.inflate(R.layout.item_sticker, null);
            viewHolder.imageview = (ImageView) inflate.findViewById(R.id.grid_item);
            inflate.setTag(viewHolder);
            view = inflate;
        }
        ImageLoader instance = ImageLoader.getInstance();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("assets://crown/");
        stringBuilder.append((String) this.arrayList.get(i));
        instance.displayImage(stringBuilder.toString(), ((ViewHolder) view.getTag()).imageview);
        return view;
    }

    public static void initImageLoader(Context context) {
        new Builder().cacheInMemory(true).cacheOnDisc(true).showImageOnLoading(17301633).showImageForEmptyUri(17301543).showImageOnFail(17301624).considerExifParams(true).bitmapConfig(Config.RGB_565).imageScaleType(ImageScaleType.EXACTLY_STRETCHED).build();
        ImageLoader.getInstance().init(new ImageLoaderConfiguration.Builder(context).threadPriority(3).denyCacheImageMultipleSizesInMemory().discCacheFileNameGenerator(new Md5FileNameGenerator()).tasksProcessingOrder(QueueProcessingType.LIFO).defaultDisplayImageOptions(null).build());
    }
}
