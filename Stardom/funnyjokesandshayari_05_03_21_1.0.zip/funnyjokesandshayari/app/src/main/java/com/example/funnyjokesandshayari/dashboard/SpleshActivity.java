package com.example.funnyjokesandshayari.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.funnyjokesandshayari.R;

public class SpleshActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splesh);
        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SpleshActivity.this,DashboardActivity.class);
                startActivity(intent);
                finish();
            }
        },5000);
    }
}