package com.esc.socialmediacleaner.util;

import android.content.Context;
import android.os.storage.StorageManager;
import android.webkit.MimeTypeMap;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class Util {

    public static long checkTimeDifference(long j) {
        return TimeUnit.SECONDS.toSeconds(System.currentTimeMillis() - j);
    }

    public static String convertBytes(long j) {
        if (j <= 0) {
            return "0 B";
        }
        String[] strArr = new String[]{"B", "KB", "MB", "GB", "TB"};
        double d = (double) j;
        int log10 = (int) (Math.log10(d) / Math.log10(1024.0d));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(new DecimalFormat("#,##0.##").format(d / Math.pow(1024.0d, (double) log10)));
        stringBuilder.append(" ");
        stringBuilder.append(strArr[log10]);
        return stringBuilder.toString();
    }

    public static Map<String, String> getSecondaryMountedVolumesMap(Context context) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        StorageManager storageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        Object[] objArr = (Object[]) storageManager.getClass().getMethod("getVolumeList", new Class[0]).invoke(storageManager, new Object[0]);
        HashMap hashMap = new HashMap();
        for (Object obj : objArr) {
            String str = (String) obj.getClass().getMethod("getState", new Class[0]).invoke(obj, new Object[0]);
            if (!((Boolean) obj.getClass().getMethod("isPrimary", new Class[0]).invoke(obj, new Object[0])).booleanValue() && str.equals("mounted")) {
                str = (String) obj.getClass().getMethod("getPath", new Class[0]).invoke(obj, new Object[0]);
                String str2 = (String) obj.getClass().getMethod("getUuid", new Class[0]).invoke(obj, new Object[0]);
                if (!(str2 == null || str == null)) {
                    hashMap.put(str2, str);
                }
            }
        }
        return hashMap;
    }


    public static String getMimeType(String str) {
        str = MimeTypeMap.getFileExtensionFromUrl(str);
        return str != null ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(str) : null;
    }
}
