package com.esc.socialmediacleaner.datastructure;

public enum MediaType {
    IMAGES,
    VIDEOS,
    AUDIOS,
    GIFS,
    DOCUMENTS
}
