package com.rtovehicleinformation.application;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.text.TextUtils;
import android.util.Base64;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.rtovehicleinformation.OpenAds.AppOpenManager;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.utils.Utils;

import java.util.Locale;


public class AppController extends Application {

    AppOpenManager appOpenManager;
    public static final String TAG = AppController.class.getSimpleName();

    private RequestQueue mRequestQueue;
    public static String id;
    private static AppController mInstance;
    private static Context context;
    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        context = getApplicationContext();
        id = (new String( Base64.decode(Utils.id+Utils.id2, Base64.DEFAULT ) ));

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
    }

    public static Context getContext() {
        return context;
    }
    public static synchronized AppController getInstance() {
        return mInstance;
    }
    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }
        return mRequestQueue;
    }
}
