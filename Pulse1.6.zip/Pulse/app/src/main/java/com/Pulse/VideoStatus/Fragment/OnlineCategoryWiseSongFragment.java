package com.Pulse.VideoStatus.Fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.Pulse.VideoStatus.Adapter.OnlineSongAdapter;
import com.Pulse.VideoStatus.Extra.Utils;
import com.Pulse.VideoStatus.Extra.d;
import com.Pulse.VideoStatus.Model.OnlineSongModel;
import com.Pulse.VideoStatus.R;
import com.Pulse.VideoStatus.retrofit.APIClient;
import com.Pulse.VideoStatus.retrofit.ApiInterface;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class OnlineCategoryWiseSongFragment extends Fragment {

    public static MediaPlayer mediaPlayer;
    public static d sharedpreferences;
    public ArrayList<OnlineSongModel> songModelArrayList = new ArrayList<>();
    public OnlineSongAdapter onlineSongAdapter;
    Integer CategoryId = -1;
    RelativeLayout rlloadingpager;
    RecyclerView rvCategoryWiseTheme;
    LinearLayout llInternetCheck;
    Button btnRetry;
    String offlienResopnseData;
    SharedPreferences ThemeHomePreferences;
    String MY_PREF = "Song_pref";
    SharedPreferences pref;
    String[] split_AllLan;
    String[] split_selctedLan;
    Long timestamps;

    public static Fragment getInstance(int catid) {
        Bundle bundle = new Bundle();
        bundle.putInt("CategoryId", catid);
        OnlineCategoryWiseSongFragment categoryWiseSongFragment = new OnlineCategoryWiseSongFragment();
        categoryWiseSongFragment.setArguments(bundle);
        return categoryWiseSongFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CategoryId = getArguments().getInt("CategoryId");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_online_song_catwise, container, false);
        ThemeHomePreferences = getActivity().getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedpreferences = d.a(getActivity());
        split_AllLan = ("63,55,62,61,57,60,58,59,56,52,50,53,64").split(",");
        split_selctedLan = d.a(getActivity()).a("pref_key_language_list", "22").split(",");
        bindView(rootView);
        SetListener();
        SetThemeAdapter();
        if (songModelArrayList != null && songModelArrayList.size() == 0) {
            if (Utils.checkConnectivity(getActivity(), false)) {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null && timestamps != null) {
                    if (offlienResopnseData != null) {
                        new LoadOfflineData().execute();
                    }
                }
            } else {
                getOfflineCategory(getActivity(), "ThemeCategory");
                if (offlienResopnseData != null) {
                    new LoadOfflineData().execute();
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    rlloadingpager.setVisibility(View.GONE);
                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            SetThemeAdapter();
        }
        return rootView;
    }

    private void bindView(View view) {
        rvCategoryWiseTheme = view.findViewById(R.id.rv_onlinesong);
        rlloadingpager = view.findViewById(R.id.rl_load_onlinesong);
        llInternetCheck = view.findViewById(R.id.llRetry);
        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(getActivity(), false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    GetSongByCategory();
                    SetThemeAdapter();
                } else {
                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void SetThemeAdapter() {
        onlineSongAdapter = new OnlineSongAdapter(getActivity(), songModelArrayList, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvCategoryWiseTheme.setLayoutManager(mLayoutManager);
        rvCategoryWiseTheme.setAdapter(onlineSongAdapter);
        onlineSongAdapter.notifyDataSetChanged();
    }



    private void getOfflineCategory(Context ctx, String key) {
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }


  /*  private void LoadOfflineSongByCat(String Response) {
        try {
            JSONObject jsonObj = new JSONObject(Response);
            JSONArray jsonArray = jsonObj.getJSONArray("category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                if (CategoryId == Catid) {
                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                        OnlineSongModel songModel = new OnlineSongModel();
                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                            songModel.setSongCategoryId(songJSONObject.getString("id"));
                            songModel.setSongName(songJSONObject.getString("sound_filename"));
                            songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                            songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                            songModel.setSongSize(songJSONObject.getString("sound_size"));
                            songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                            songModelArrayList.add(songModel);
                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                            songModel.setSongCategoryId(songJSONObject.getString("id"));
                            songModel.setSongName(songJSONObject.getString("sound_filename"));
                            songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                            songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                            songModel.setSongSize(songJSONObject.getString("sound_size"));
                            songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                            songModelArrayList.add(songModel);
                        }
                    }
                }
            }
            onlineSongAdapter.notifyDataSetChanged();
            rlloadingpager.setVisibility(View.GONE);
        } catch (final JSONException e) {
            e.printStackTrace();
        }
    }*/

    @SuppressLint("StaticFieldLeak")
    private class LoadOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            rlloadingpager.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                    int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                    if (CategoryId == Catid) {
                        JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                        for (int j = 0; j < jSONArray4.length(); j++) {
                            JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                            OnlineSongModel songModel = new OnlineSongModel();
                            if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                songModel.setSongCategoryId(songJSONObject.getString("id"));
                                songModel.setSongName(songJSONObject.getString("sound_filename"));
                                songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                songModel.setSongSize(songJSONObject.getString("sound_size"));
                                songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                songModelArrayList.add(songModel);
                            } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                songModel.setSongCategoryId(songJSONObject.getString("id"));
                                songModel.setSongName(songJSONObject.getString("sound_filename"));
                                songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                songModel.setSongSize(songJSONObject.getString("sound_size"));
                                songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                songModelArrayList.add(songModel);
                            }

                        }
                    }
                }

            } catch (final JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            onlineSongAdapter.notifyDataSetChanged();
            rlloadingpager.setVisibility(View.GONE);
        }
    }
    private void GetSongByCategory() {
        rlloadingpager.setVisibility(View.VISIBLE);
        APIClient.getRetrofit().create(ApiInterface.class).GetAllTheme("aciativtyksdfhal5215ajal", "9").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
                            if (CategoryId == Catid) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    JSONObject songJSONObject = jSONArray4.getJSONObject(j);
                                    OnlineSongModel songModel = new OnlineSongModel();
                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                        songModel.setSongCategoryId(songJSONObject.getString("id"));
                                        songModel.setSongName(songJSONObject.getString("sound_filename"));
                                        songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                        songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                        songModel.setSongSize(songJSONObject.getString("sound_size"));
                                        songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                        songModelArrayList.add(songModel);
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        songModel.setSongCategoryId(songJSONObject.getString("id"));
                                        songModel.setSongName(songJSONObject.getString("sound_filename"));
                                        songModel.setSongUrl(songJSONObject.getString("sound_filename") + ".mp3");
                                        songModel.setSongfull_url(songJSONObject.getString("sound_file"));
                                        songModel.setSongSize(songJSONObject.getString("sound_size"));
                                        songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("sound_filename") + ".mp3");
                                        songModelArrayList.add(songModel);
                                    }
                                }
                            }
                        }
                        onlineSongAdapter.notifyDataSetChanged();
                        rlloadingpager.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void rePlayAudio(final int n, final boolean b) {
        if (b) {
            this.stopPlaying(mediaPlayer);
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.reset();
                mediaPlayer.setDataSource(Utils.INSTANCE.getMusicFolderPath() + File.separator + songModelArrayList.get(n).getSongUrl());
//                FinalMusicPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(n).getSongUrl();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.prepareAsync();
            return;
        }
    }


    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

  /*  @SuppressLint("StaticFieldLeak")
    public class GetThemeData extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            rlloadingpager.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(arg0[0]);
            if (jsonStr != null) {
                System.out.println("success");
            } else {
                System.out.println("failed");
            }

            return jsonStr;

        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObj = new JSONObject();
                if (IsofflineResopnse) {
                    String id = pref.getString(CatId, null);
                    if (id != null && !id.equals("")) {
                        getOfflineTheme(getActivity(), CatId);
                        jsonObj = new JSONObject(offlienResopnseData);
                    } else {
//                            llInternetCheck.setVisibility(View.VISIBLE);
                    }
                } else {
                    jsonObj = new JSONObject(result);
                    if (getActivity() != null) {
                        SetOfflineTheme(getActivity(), jsonObj.toString(), CatId);
                    }
                }
                JSONArray jsonArray = jsonObj.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject songJSONObject = jsonArray.getJSONObject(i);
                    OnlineSongModel songModel = new OnlineSongModel();
                    songModel.setId(i);
                    songModel.setSongId(songJSONObject.getString("Sound_Id"));
                    songModel.setSongCategoryId(songJSONObject.getString("Sound_Category_Id"));
                    songModel.setSongName(songJSONObject.getString("Sound_Name"));
                    songModel.setSongUrl(songJSONObject.getString("Sound_Name") + ".mp3");
                    songModel.setSongfull_url(songJSONObject.getString("Sound_full_url"));
                    songModel.setSongSize(songJSONObject.getString("Sound_Size"));
                    songModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getMusicFolderPath() + File.separator + songJSONObject.getString("Sound_Name") + ".mp3");
                    songModelArrayList.add(songModel);
                }
                onlineSongAdapter.notifyDataSetChanged();
                rlloadingpager.setVisibility(View.GONE);

            } catch (final JSONException e) {
                e.printStackTrace();
            }
        }
    }*/
}
