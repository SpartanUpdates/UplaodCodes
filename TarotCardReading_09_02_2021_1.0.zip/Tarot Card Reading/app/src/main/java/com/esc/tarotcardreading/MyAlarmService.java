package com.esc.tarotcardreading;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Vibrator;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationCompat.Builder;

import java.util.Random;

public class MyAlarmService extends IntentService {
    private static final int NOTIFICATION_ID = 1;
    public static final String PRIMARY_CHANNEL = "default";
    public static boolean isAlarmNotified;
    public static int random;
    public static int randomlang;
    String currentDayAndMonth1;
    String locale;
    Builder mBuilder;
    NotificationManager mNotificationManager;
    String[] ntf_txt_daily = new String[11];
    String[] ntf_txt_dreams = new String[3];
    String[] ntf_txt_emotional = new String[3];
    String[] ntf_txt_family = new String[4];
    String[] ntf_txt_focus = new String[3];
    String[] ntf_txt_health = new String[3];
    String[] ntf_txt_life = new String[4];
    String[] ntf_txt_love = new String[4];
    String[] ntf_txt_luck = new String[3];
    String[] ntf_txt_marriage = new String[3];
    String[] ntf_txt_money = new String[4];
    String[] ntf_txt_past = new String[3];
    String[] ntf_txt_sucess = new String[3];
    String[] ntf_txt_travel = new String[3];
    String[] ntf_txt_work = new String[4];
    int[] ntfdaily = new int[]{R.string.ntcd0, R.string.ntcd1, R.string.ntcd2, R.string.ntcd3, R.string.ntcd4, R.string.ntcd5, R.string.ntcd6, R.string.ntcd7, R.string.ntcd8, R.string.ntcd9, R.string.ntcd10};
    int[] ntfdreams = new int[]{R.string.ntcdreams0, R.string.ntcdreams1, R.string.ntcdreams2};
    int[] ntfemotional = new int[]{R.string.ntce0, R.string.ntce1, R.string.ntce2};
    int[] ntffamily = new int[]{R.string.ntcf0, R.string.ntcf1, R.string.ntcf2, R.string.ntcf3};
    int[] ntffocus = new int[]{R.string.ntcfocus0, R.string.ntcfocus1, R.string.ntcfocus2};
    int[] ntfhealth = new int[]{R.string.ntch0, R.string.ntch1, R.string.ntch2};
    int[] ntflife = new int[]{R.string.ntcl0, R.string.ntcl1, R.string.ntcl2, R.string.ntcl3};
    int[] ntflove = new int[]{R.string.ntclove0, R.string.ntclove1, R.string.ntclove2, R.string.ntclove3};
    int[] ntfluck = new int[]{R.string.ntcluck0, R.string.ntcluck1, R.string.ntcluck2};
    int[] ntfmarriage = new int[]{R.string.ntcm0, R.string.ntcm1, R.string.ntcm2};
    int[] ntfmoney = new int[]{R.string.ntcmoney0, R.string.ntcmoney1, R.string.ntcmoney2, R.string.ntcmoney3};
    int[] ntfpast = new int[]{R.string.ntcp0, R.string.ntcp1, R.string.ntcp2};
    int[] ntfsucess = new int[]{R.string.ntcs0, R.string.ntcs1, R.string.ntcs2};
    int[] ntftravel = new int[]{R.string.ntct0, R.string.ntct1, R.string.ntct2};
    int[] ntfwork = new int[]{R.string.ntcw0, R.string.ntcw1, R.string.ntcw2, R.string.ntcw3};
    int random_eleven;
    int random_three;
    int random_two;
    Intent resultIntent;
    PendingIntent resultPendingIntent;

    public MyAlarmService() {
        super("AlarmService");
    }


    public void onHandleIntent(Intent intent) {
        getNotify();
    }

    public void getNotify() {
        final StringBuilder sb = new StringBuilder();
        sb.append("MyAlarmService...");
        sb.append(MyAlarmService.isAlarmNotified);
        Log.e("isalarmnotified", sb.toString());
        final String language = this.getResources().getConfiguration().locale.getLanguage();
        this.locale = language;
        if (language.contains("tr")) {
            return;
        }
        MyAlarmService.isAlarmNotified = true;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("notification....>");
        sb2.append(this.locale);
        Log.e("locale", sb2.toString());
        for (int i = 0; i < 11; ++i) {
            this.ntf_txt_daily[i] = this.getResources().getString(this.ntfdaily[i]);
        }
        for (int j = 0; j < 4; ++j) {
            this.ntf_txt_life[j] = this.getResources().getString(this.ntflife[j]);
            this.ntf_txt_love[j] = this.getResources().getString(this.ntflove[j]);
            this.ntf_txt_family[j] = this.getResources().getString(this.ntffamily[j]);
            this.ntf_txt_money[j] = this.getResources().getString(this.ntfmoney[j]);
            this.ntf_txt_work[j] = this.getResources().getString(this.ntfwork[j]);
        }
        for (int k = 0; k < 3; ++k) {
            this.ntf_txt_dreams[k] = this.getResources().getString(this.ntfdreams[k]);
            this.ntf_txt_emotional[k] = this.getResources().getString(this.ntfemotional[k]);
            this.ntf_txt_health[k] = this.getResources().getString(this.ntfhealth[k]);
            this.ntf_txt_luck[k] = this.getResources().getString(this.ntfluck[k]);
            this.ntf_txt_marriage[k] = this.getResources().getString(this.ntfmarriage[k]);
            this.ntf_txt_past[k] = this.getResources().getString(this.ntfpast[k]);
            this.ntf_txt_sucess[k] = this.getResources().getString(this.ntfsucess[k]);
            this.ntf_txt_travel[k] = this.getResources().getString(this.ntftravel[k]);
            this.ntf_txt_focus[k] = this.getResources().getString(this.ntffocus[k]);
        }
        this.random_eleven = new Random().nextInt(10) + 1;
        this.random_three = new Random().nextInt(3) + 1;
        this.random_two = new Random().nextInt(2) + 1;
        MyAlarmService.random = new Random().nextInt(19) + 1;
        MyAlarmService.randomlang = new Random().nextInt(5) + 1;
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("");
        sb3.append(MyAlarmService.random);
        Log.e("random", sb3.toString());
        final String[] array = new String[20];
        array[0] = "";
        final String[] ntf_txt_daily = this.ntf_txt_daily;
        final int random_eleven = this.random_eleven;
        array[1] = ntf_txt_daily[random_eleven];
        final String[] ntf_txt_life = this.ntf_txt_life;
        final int random_three = this.random_three;
        array[2] = ntf_txt_life[random_three];
        final String[] ntf_txt_love = this.ntf_txt_love;
        array[3] = ntf_txt_love[random_three];
        final String[] ntf_txt_family = this.ntf_txt_family;
        array[4] = ntf_txt_family[random_three];
        final String[] ntf_txt_money = this.ntf_txt_money;
        final int random_two = this.random_two;
        array[5] = ntf_txt_money[random_two];
        final String[] ntf_txt_health = this.ntf_txt_health;
        array[6] = ntf_txt_health[random_two];
        array[7] = this.ntf_txt_dreams[random_two];
        array[8] = this.ntf_txt_travel[random_two];
        array[9] = this.ntf_txt_work[random_three];
        array[10] = this.ntf_txt_focus[random_two];
        array[11] = this.ntf_txt_sucess[random_two];
        array[12] = this.ntf_txt_luck[random_two];
        array[13] = this.ntf_txt_emotional[random_two];
        array[14] = this.ntf_txt_marriage[random_two];
        array[15] = this.ntf_txt_past[random_two];
        array[16] = ntf_txt_daily[random_eleven];
        array[17] = ntf_txt_daily[random_eleven];
        array[18] = ntf_txt_daily[random_eleven];
        array[19] = ntf_txt_daily[random_eleven];
        final String[] array2 = {"", ntf_txt_life[random_three], ntf_txt_love[random_three], ntf_txt_family[random_three], ntf_txt_money[random_two], ntf_txt_health[random_two]};
        if (!this.locale.contains("tr") && !this.locale.contains("zh") && !this.locale.contains("ko") && !this.locale.contains("da") && !this.locale.contains("pl") && !this.locale.contains("es") && !this.locale.contains("fr") && !this.locale.contains("hi") && !this.locale.contains("nb") && !this.locale.contains("sv") && !this.locale.contains("de") && !this.locale.contains("it") && !this.locale.contains("ms") && !this.locale.contains("ru") && !this.locale.contains("nl") && !this.locale.contains("fi") && !this.locale.contains("el") && !this.locale.contains("in") && !this.locale.contains("vi") && !this.locale.contains("tl")) {
            final int random = MyAlarmService.random;
            if (random != 1 && random != 16 && random != 17 && random != 18 && random != 19) {
                this.resultIntent = new Intent((Context) this, (Class) TaroQuestionsActivity.class);
            } else {
                this.resultIntent = new Intent((Context) this, (Class) TaroCardsQuestionActivity.class);
            }
        } else {
            (this.resultIntent = new Intent((Context) this, (Class) TaroCardsQuestionActivity.class)).putExtra("type", "one");
            final int randomlang = MyAlarmService.randomlang;
            if (randomlang == 1) {
                this.resultIntent.putExtra("head", this.getResources().getString(R.string.life));
                this.resultIntent.putExtra("ccc", "Life");
                this.resultIntent.putExtra("ccc2", this.getResources().getString(R.string.life));
            } else if (randomlang == 2) {
                this.resultIntent.putExtra("head", this.getResources().getString(R.string.loveNrel));
                this.resultIntent.putExtra("ccc", "Love & Relationships");
                this.resultIntent.putExtra("ccc2", this.getResources().getString(R.string.loveNrel));
            } else if (randomlang == 3) {
                this.resultIntent.putExtra("head", this.getResources().getString(R.string.familyNfriends));
                this.resultIntent.putExtra("ccc", "Family & Friends");
                this.resultIntent.putExtra("ccc2", this.getResources().getString(R.string.familyNfriends));
            } else if (randomlang == 4) {
                this.resultIntent.putExtra("head", this.getResources().getString(R.string.money));
                this.resultIntent.putExtra("ccc", "Money");
                this.resultIntent.putExtra("ccc2", this.getResources().getString(R.string.money));
            } else if (randomlang == 5) {
                this.resultIntent.putExtra("head", this.getResources().getString(R.string.health));
                this.resultIntent.putExtra("ccc", "Health");
                this.resultIntent.putExtra("ccc2", this.getResources().getString(R.string.health));
            }
        }
        final Bitmap decodeResource = BitmapFactory.decodeResource(this.getApplicationContext().getResources(), R.drawable.ic_launcher_background);
        this.mNotificationManager = (NotificationManager) this.getSystemService(NOTIFICATION_SERVICE);
        this.resultPendingIntent = PendingIntent.getActivity((Context) this, 0, this.resultIntent, 134217728);
        if (Build.VERSION.SDK_INT >= 26) {
            final NotificationChannel notificationChannel = new NotificationChannel("default", (CharSequence) "TAROT_CARD_READINGS", 3);
            notificationChannel.setLightColor(-16711936);
            notificationChannel.setLockscreenVisibility(0);
            this.mNotificationManager.createNotificationChannel(notificationChannel);
            Notification.Builder notification$Builder;
            if (!this.locale.contains("tr") && !this.locale.contains("zh") && !this.locale.contains("ko") && !this.locale.contains("da") && !this.locale.contains("pl") && !this.locale.contains("es") && !this.locale.contains("fr") && !this.locale.contains("hi") && !this.locale.contains("nb") && !this.locale.contains("sv") && !this.locale.contains("de") && !this.locale.contains("it") && !this.locale.contains("ms") && !this.locale.contains("ru") && !this.locale.contains("nl") && !this.locale.contains("fi") && !this.locale.contains("el") && !this.locale.contains("in") && !this.locale.contains("vi") && !this.locale.contains("tl")) {
                notification$Builder = new Notification.Builder(this.getApplicationContext(), "default").setContentTitle((CharSequence) this.getString(2131623969)).setContentText((CharSequence) array[MyAlarmService.random]).setSmallIcon(2131165434).setLargeIcon(decodeResource).setStyle((Notification.Style) new Notification.BigTextStyle().bigText((CharSequence) array[MyAlarmService.random])).setAutoCancel(true);
            } else {
                notification$Builder = new Notification.Builder(this.getApplicationContext(), "default").setContentTitle((CharSequence) this.getString(2131623969)).setContentText((CharSequence) array2[MyAlarmService.randomlang]).setSmallIcon(2131165434).setLargeIcon(decodeResource).setStyle((Notification.Style) new Notification.BigTextStyle().bigText((CharSequence) array2[MyAlarmService.randomlang])).setAutoCancel(true);
            }
            notification$Builder.setContentIntent(this.resultPendingIntent);
            this.mNotificationManager.notify(1, notification$Builder.build());
            this.startForeground(5, notification$Builder.build());
            return;
        }
        if (!this.locale.contains("tr") && !this.locale.contains("zh") && !this.locale.contains("ko") && !this.locale.contains("da") && !this.locale.contains("pl") && !this.locale.contains("es") && !this.locale.contains("fr") && !this.locale.contains("hi") && !this.locale.contains("nb") && !this.locale.contains("sv") && !this.locale.contains("de") && !this.locale.contains("it") && !this.locale.contains("ms") && !this.locale.contains("ru") && !this.locale.contains("nl") && !this.locale.contains("fi") && !this.locale.contains("el") && !this.locale.contains("in") && !this.locale.contains("vi") && !this.locale.contains("tl")) {
            Log.e("notify", "notify");
            this.mBuilder = new NotificationCompat.Builder((Context) this).setLargeIcon(decodeResource).setSmallIcon(R.drawable.smallicon).setLargeIcon(decodeResource).setContentTitle(this.getResources().getString(R.string.app_name)).setStyle(new NotificationCompat.BigTextStyle().bigText(array[MyAlarmService.random])).setContentText(array[MyAlarmService.random]);
        } else {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append(">>>>>>>>");
            sb4.append(MyAlarmService.randomlang);
            Log.e("Random...", sb4.toString());
            Log.e("notify", "notify");
            this.mBuilder = new NotificationCompat.Builder((Context) this).setContentTitle(this.getResources().getString(R.string.app_name)).setSmallIcon(2131165434).setLargeIcon(decodeResource).setStyle(new NotificationCompat.BigTextStyle().bigText(array2[MyAlarmService.randomlang])).setContentText(array2[MyAlarmService.randomlang]);
        }
        this.mBuilder.setContentIntent(this.resultPendingIntent);
        this.mBuilder.setAutoCancel(true);
        this.mNotificationManager.notify(1, this.mBuilder.build());
        ((Vibrator) this.getApplicationContext().getSystemService(VIBRATOR_SERVICE)).vibrate(300L);
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(Utils.changeLang(context, context.getApplicationContext().getSharedPreferences("MyPref", 0).getString("languagetoload", "en")));
    }
}
