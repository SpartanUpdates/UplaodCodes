package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class j5 implements View.OnClickListener {
    public final FrameEditorNewDesign e;

    public j5(final FrameEditorNewDesign e) {
        this.e = e;
    }

    public void onClick(final View view) {
        this.e.u0();
        if (FrameEditorNewDesign.M1) {
            final boolean o1 = FrameEditorNewDesign.O1;
            FrameEditorNewDesign.w1.setVisibility(8);
            return;
        }
        FrameEditorNewDesign.v1.setVisibility(8);
    }
}
