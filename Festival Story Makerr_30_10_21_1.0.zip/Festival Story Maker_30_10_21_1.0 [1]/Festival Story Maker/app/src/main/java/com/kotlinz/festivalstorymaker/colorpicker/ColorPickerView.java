package com.kotlinz.festivalstorymaker.colorpicker;

public class ColorPickerView {
}
