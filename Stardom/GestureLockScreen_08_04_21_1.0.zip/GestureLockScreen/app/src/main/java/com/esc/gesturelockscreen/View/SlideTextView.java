package com.esc.gesturelockscreen.View;

import android.os.Build;
import android.view.*;
import android.content.*;
import android.util.*;
import android.graphics.*;
import androidx.annotation.RequiresApi;

public class SlideTextView extends View
{
  private float density;
  private float left1;
  private float left2;
  private int mColor;
  private String mText;
  private Matrix matrix;
  private float moveX;
  private boolean start;
  private float top1;
  private float top2;
  private Paint txtPaint;
  private Paint txtPaint1;

  public SlideTextView(final Context context) {
    this(context, null);
  }

  public SlideTextView(final Context context, final AttributeSet set) {
    super(context, set);
    this.top1 = 0.0f;
    this.top2 = 0.0f;
    this.left1 = 0.0f;
    this.left2 = 0.0f;
    this.moveX = 0.0f;
    this.start = true;
    this.mColor = -1;
    this.density = 1.0f;
    this.matrix = new Matrix();
    this.init();
  }

  public SlideTextView(final Context context, final AttributeSet set, final int n) {
    super(context, set, n);
    this.top1 = 0.0f;
    this.top2 = 0.0f;
    this.left1 = 0.0f;
    this.left2 = 0.0f;
    this.moveX = 0.0f;
    this.start = true;
    this.mColor = -1;
    this.density = 1.0f;
    this.matrix = new Matrix();
    this.init();
  }

  @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
  public SlideTextView(final Context context, final AttributeSet set, final int n, final int n2) {
    super(context, set, n, n2);
    this.top1 = 0.0f;
    this.top2 = 0.0f;
    this.left1 = 0.0f;
    this.left2 = 0.0f;
    this.moveX = 0.0f;
    this.start = true;
    this.mColor = -1;
    this.density = 1.0f;
    this.matrix = new Matrix();
    this.init();
  }

  private void init() {
    (this.txtPaint = new Paint()).setColor(this.mColor);
    this.txtPaint.setFakeBoldText(true);
    this.txtPaint.setAntiAlias(true);
    this.density = this.getContext().getResources().getDisplayMetrics().density;
    this.txtPaint.setTextSize(TypedValue.applyDimension(2, 20.0f, this.getContext().getResources().getDisplayMetrics()));
    (this.txtPaint1 = new Paint()).setColor(this.mColor);
    this.txtPaint1.setFakeBoldText(true);
    this.txtPaint1.setAntiAlias(true);
    this.txtPaint1.setTextSize(TypedValue.applyDimension(2, 45.0f, this.getContext().getResources().getDisplayMetrics()));
    this.txtPaint1.setTextScaleX(0.4f);
    this.mText = "Slide to Unlock";
    if (!this.isInEditMode()) {
      this.txtPaint.setTypeface(ClockTextView.get(this.getContext(), "Exo_Medium"));
      this.txtPaint1.setTypeface(ClockTextView.get(this.getContext(), "Roboto_Thin_0"));
    }
    final Rect rect = new Rect();
    this.txtPaint1.getTextBounds(">", 0, 1, rect);
    this.top1 = (this.density * 50.0f + rect.height()) * 0.5f;
    final Rect rect2 = new Rect();
    this.txtPaint.getTextBounds(this.mText, 0, this.mText.length(), rect2);
    this.top2 = (this.density * 45.0f + rect2.height()) * 0.5f;
    this.left2 = this.density * 100.0f - rect2.width() * 0.5f + rect.width() * 2;
    this.left1 = this.left2 - rect.width() * 2;
    final LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 200.0f, 0.0f, new int[] { Color.argb(255, 116, 116, 116), Color.argb(255, 116, 116, 116), Color.argb(255, 116, 116, 116), Color.argb(255, 245, 245, 245) }, new float[] { 0.0f, 0.3f, 0.6f, 1.0f }, Shader.TileMode.MIRROR);
    this.txtPaint.setShader((Shader)linearGradient);
    this.txtPaint1.setShader((Shader)linearGradient);
  }

  protected void onDraw(final Canvas canvas) {
    if (this.start) {
      this.moveX += 5.0f;
      if (!this.start || this.isInEditMode()) {
        this.matrix.setTranslate(0.0f, 0.0f);
      }
      else {
        this.matrix.setTranslate(this.moveX, 0.0f);
        this.invalidate();
      }
      if (this.txtPaint.getShader() != null) {
        this.txtPaint.getShader().setLocalMatrix(this.matrix);
      }
      if (this.txtPaint1.getShader() != null) {
        this.txtPaint1.getShader().setLocalMatrix(this.matrix);
      }
      canvas.drawText(">", this.left1, this.top1, this.txtPaint1);
      canvas.drawText(this.mText, this.left2, this.top2, this.txtPaint);
      super.onDraw(canvas);
      return;
    }
    super.onDraw(canvas);
  }

  public void setStart(final boolean start) {
    this.start = start;
    this.invalidate();
    this.requestLayout();
  }

  public void setText(final String mText) {
    this.mText = mText;
    this.invalidate();
    this.requestLayout();
  }

  public void setTextColor(final int mColor) {
    this.mColor = mColor;
    this.txtPaint.setColor(this.mColor);
    this.invalidate();
  }
}
