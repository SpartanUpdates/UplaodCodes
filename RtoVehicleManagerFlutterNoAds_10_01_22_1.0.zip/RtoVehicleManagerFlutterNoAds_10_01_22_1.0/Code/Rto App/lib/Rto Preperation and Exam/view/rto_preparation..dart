import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/controller/rto_question_controller.dart';
import 'package:rto_app/Rto%20Preperation%20and%20Exam/model/rto_question_model.dart';
import 'package:rto_app/Utils/comman_dailog.dart';
import 'package:velocity_x/src/extensions/context_ext.dart';
import 'package:velocity_x/src/flutter/padding.dart';
import 'package:velocity_x/src/flutter/widgets.dart';

class RtoPreperation extends StatelessWidget {
  bool isRtoPreparation = true;

  RtoPreperation(this.isRtoPreparation);

  @override
  Widget build(BuildContext context) {
    RtoQuestionController controller =
        Get.put(RtoQuestionController(context, isRtoPreparation));
    return WillPopScope(
      onWillPop: () {
        CommanDialog.exitDialog(context, "Are you sure want to exit ?");
        return Future.value(false);
      },
      child: Material(
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Theme.of(context).primaryColor,
            body: NestedScrollView(
              physics: BouncingScrollPhysics(),
              floatHeaderSlivers: true,
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return <Widget>[
                  SliverAppBar(
                    backwardsCompatibility: false,
                    backgroundColor: Theme.of(context).primaryColor,
                    title: Text(
                      "RTO Preparation",
                      style: TextStyle(
                          fontSize: 18,
                          color: Theme.of(context).accentColor,
                          fontFamily: "Circular Bold"),
                    ),
                    leading: Container(
                      color: Theme.of(context).primaryColor,
                      padding: EdgeInsets.all(10),
                      child: Material(
                        color: Colors.transparent,
                        shape: CircleBorder(),
                        clipBehavior: Clip.hardEdge,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              CommanDialog.exitDialog(
                                  context, "Are you sure want to exit ?");
                            },
                            icon: Hero(
                              tag: isRtoPreparation
                                  ? "rtopreparation"
                                  : "rtoexam",
                              transitionOnUserGestures: true,
                              child: Icon(
                                Icons.arrow_back_ios_rounded,
                                color: Theme.of(context).accentColor,
                                size: 22,
                              ),
                            )),
                      ),
                    ),
                  )
                ];
              },
              body: Align(
                alignment: Alignment.center,
                child: Container(
                    color: Theme.of(context).primaryColor,
                    child: Center(
                      child: ScoreCard(controller, isRtoPreparation),
                    )),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ScoreCard extends StatelessWidget {
  static CountDownController countController = CountDownController();
  int duration = 45;
  int maxQuestion = 25;
  int passLimite = 15;
  static bool isAcorrect = false;
  static bool isBcorrect = false;
  static bool isCcorrect = false;
  static bool isNoSelected = true;
  static bool clickA = true;
  static bool clickB = true;
  static bool clickC = true;
  RtoQuestionController controllers;
  bool isRtoPreparation;

  ScoreCard(this.controllers, this.isRtoPreparation);

  @override
  Widget build(BuildContext context) {
    controllers.fetchRtoQuestionData();
    if (isRtoPreparation) {
      maxQuestion = 25;
      passLimite = 15;
    } else {
      maxQuestion = 15;
      passLimite = 11;
    }

    return Align(
      alignment: Alignment.center,
      child: Column(
        children: [
          Expanded(
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Positioned(
                  child: SizedBox(
                    child: Card(
                      color: Theme.of(context).dialogBackgroundColor,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      child: GetBuilder<RtoQuestionController>(
                        builder: (controllers) {
                          return SizedBox(
                            height: 165,
                            child: Stack(
                              children: [
                                Positioned(
                                    child: Row(
                                  children: [
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              width: double.infinity,
                                              child: isRtoPreparation
                                                  ? Text(
                                                      "25",
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                          fontSize: 30,
                                                          color:
                                                              Theme.of(context)
                                                                  .hintColor,
                                                          fontFamily:
                                                              "Circular Medium"),
                                                    )
                                                  : Text(
                                                      "15",
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                          fontSize: 30,
                                                          color:
                                                              Theme.of(context)
                                                                  .hintColor,
                                                          fontFamily:
                                                              "Circular Medium"),
                                                    ),
                                            ),
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                "Total \nQuestions",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    color: Color(0xff757381),
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ).pOnly(top: 5)
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        color: Colors.blueGrey,
                                        height: 60,
                                        width: 0.2,
                                      ),
                                    ).pOnly(top: 15),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                controllers.currentQue
                                                    .toString(),
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 30,
                                                    color: Theme.of(context)
                                                        .hintColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                "Current \nQuestion",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    color: Color(0xff757381),
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ).pOnly(top: 5)
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        color: Colors.blueGrey,
                                        height: 60,
                                        width: 0.2,
                                      ),
                                    ).pOnly(top: 15),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                controllers.yourScore
                                                    .toString(),
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 30,
                                                    color: Theme.of(context)
                                                        .hintColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                "Your\nScore",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    color: Color(0xff757381),
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ).pOnly(top: 5)
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Container(
                                        color: Colors.blueGrey,
                                        height: 60,
                                        width: 0.2,
                                      ),
                                    ).pOnly(top: 15),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                controllers.highScore
                                                    .toString(),
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 30,
                                                    color: Theme.of(context)
                                                        .hintColor,
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ),
                                            SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                "High\nScore",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    color: Color(0xff757381),
                                                    fontFamily:
                                                        "Circular Medium"),
                                              ),
                                            ).pOnly(top: 5)
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                )),
                                Positioned(
                                  bottom: 8,
                                  left: 25,
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        child: Text(
                                          controllers.rightAns.toString(),
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 30,
                                              color:
                                                  Theme.of(context).hintColor,
                                              fontFamily: "Circular Medium"),
                                        ),
                                      ),
                                      SizedBox(
                                        child: Text(
                                          "Right\nAnswer",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 11,
                                              color: Color(0xff757381),
                                              fontFamily: "Circular Medium"),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Positioned(
                                  bottom: 8,
                                  right: 25,
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        child: Text(
                                          controllers.wrongAns.toString(),
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 30,
                                              color:
                                                  Theme.of(context).hintColor,
                                              fontFamily: "Circular Medium"),
                                        ),
                                      ),
                                      SizedBox(
                                        child: Text(
                                          "Wrong\nAnswer",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 11,
                                              color: Color(0xff757381),
                                              fontFamily: "Circular Medium"),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                    top: 175,
                    child: GetBuilder<RtoQuestionController>(
                      builder: (controller) {
                        RtoQuestionModel rtoQuestionModel =
                            controller.randomQuestion;
                        return SingleChildScrollView(
                          physics: BouncingScrollPhysics(),
                          child: controllers.isDataAvailable
                              ? SizedBox(
                                  width: double.infinity,
                                  child: Card(
                                      color: Theme.of(context)
                                          .dialogBackgroundColor,
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            child: Align(
                                              alignment: Alignment.topCenter,
                                              child: Text(
                                                rtoQuestionModel.question,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    color: Theme.of(context)
                                                        .hintColor,
                                                    fontFamily:
                                                        "Circular Bold"),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            height: 0.1,
                                            width: 280,
                                            color: Colors.blueGrey,
                                          ).py(15),
                                          Container(
                                                  padding: EdgeInsets.all(2),
                                                  child: Material(
                                                    color: Theme.of(context)
                                                        .backgroundColor,
                                                    child: Ink(
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: InkWell(
                                                        customBorder: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.only(
                                                                topRight: Radius
                                                                    .circular(
                                                                        15),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        15))),
                                                        splashColor:
                                                            Theme.of(context)
                                                                .hoverColor,
                                                        onTap: () {
                                                          if (clickA) {
                                                            functionA(
                                                                context,
                                                                rtoQuestionModel,
                                                                controller,
                                                                isRtoPreparation);
                                                          }
                                                        },
                                                        child: ListTile(
                                                          leading: IconButton(
                                                            icon:
                                                                AnimatedSwitcher(
                                                                    duration: const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                    transitionBuilder:
                                                                        (child, anim) =>
                                                                            RotationTransition(
                                                                              turns: child.key == ValueKey('icon1')
                                                                                  ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                  : child.key == ValueKey('icon2')
                                                                                      ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                      : Tween<double>(begin: 0.75, end: 1).animate(anim),
                                                                              child: ScaleTransition(scale: anim, child: child),
                                                                            ),
                                                                    child: controllers.currentIndexA ==
                                                                            0
                                                                        ? Image.asset(
                                                                            "assets/images/a.png",
                                                                            height:
                                                                                25,
                                                                            width:
                                                                                25,
                                                                            color:
                                                                                Theme.of(context).cursorColor,
                                                                            key: const ValueKey('icon1'))
                                                                        : controllers.currentIndexA == 1
                                                                            ? Icon(
                                                                                CupertinoIcons.check_mark_circled,
                                                                                color: Theme.of(context).cursorColor,
                                                                                size: 25,
                                                                                key: const ValueKey('icon2'),
                                                                              )
                                                                            : Icon(
                                                                                CupertinoIcons.clear,
                                                                                size: 25,
                                                                                color: Theme.of(context).cursorColor,
                                                                                key: const ValueKey('icon3'),
                                                                              )),
                                                            onPressed: () {},
                                                          ),
                                                          title: Text(
                                                            rtoQuestionModel
                                                                .optionA,
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: isNoSelected
                                                                    ? Colors.blueGrey
                                                                    : isAcorrect
                                                                        ? Theme.of(context).hintColor
                                                                        : Colors.redAccent,
                                                                fontFamily: "Circular Medium"),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ).cornerRadius(10))
                                              .py(5),
                                          Container(
                                                  padding: EdgeInsets.all(2),
                                                  child: Material(
                                                    color: Theme.of(context)
                                                        .backgroundColor,
                                                    child: Ink(
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: InkWell(
                                                        customBorder: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.only(
                                                                topRight: Radius
                                                                    .circular(
                                                                        15),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        15))),
                                                        splashColor:
                                                            Theme.of(context)
                                                                .hoverColor,
                                                        onTap: () {
                                                          if (clickB) {
                                                            functionB(
                                                                context,
                                                                rtoQuestionModel,
                                                                controller,
                                                                maxQuestion,
                                                                isRtoPreparation);
                                                          }
                                                        },
                                                        child: ListTile(
                                                          leading: IconButton(
                                                            icon:
                                                                AnimatedSwitcher(
                                                                    duration: const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                    transitionBuilder:
                                                                        (child, anim) =>
                                                                            RotationTransition(
                                                                              turns: child.key == ValueKey('icon1')
                                                                                  ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                  : child.key == ValueKey('icon2')
                                                                                      ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                      : Tween<double>(begin: 0.75, end: 1).animate(anim),
                                                                              child: ScaleTransition(scale: anim, child: child),
                                                                            ),
                                                                    child: controllers.currentIndexB ==
                                                                            0
                                                                        ? Image.asset(
                                                                            "assets/images/b.png",
                                                                            height:
                                                                                25,
                                                                            width:
                                                                                25,
                                                                            color:
                                                                                Theme.of(context).cursorColor,
                                                                            key: const ValueKey('icon1'))
                                                                        : controllers.currentIndexB == 1
                                                                            ? Icon(
                                                                                CupertinoIcons.check_mark_circled,
                                                                                size: 25,
                                                                                color: Theme.of(context).cursorColor,
                                                                                key: const ValueKey('icon2'),
                                                                              )
                                                                            : Icon(
                                                                                CupertinoIcons.clear,
                                                                                size: 25,
                                                                                color: Theme.of(context).cursorColor,
                                                                                key: const ValueKey('icon3'),
                                                                              )),
                                                            onPressed: () {},
                                                          ),
                                                          title: Text(
                                                            rtoQuestionModel
                                                                .optionB,
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: isNoSelected
                                                                    ? Colors.blueGrey
                                                                    : isBcorrect
                                                                        ? Theme.of(context).hintColor
                                                                        : Colors.redAccent,
                                                                fontFamily: "Circular Medium"),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ).cornerRadius(10))
                                              .py(5),
                                          Container(
                                                  padding: EdgeInsets.all(2),
                                                  child: Material(
                                                    color: Theme.of(context)
                                                        .backgroundColor,
                                                    child: Ink(
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: InkWell(
                                                        customBorder: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.only(
                                                                topRight: Radius
                                                                    .circular(
                                                                        15),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                        15))),
                                                        splashColor:
                                                            Theme.of(context)
                                                                .hoverColor,
                                                        onTap: () {
                                                          if (clickC) {
                                                            functionC(
                                                                context,
                                                                rtoQuestionModel,
                                                                controller,
                                                                isRtoPreparation);
                                                          }
                                                        },
                                                        child: ListTile(
                                                          leading: IconButton(
                                                            icon:
                                                                AnimatedSwitcher(
                                                                    duration: const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                    transitionBuilder:
                                                                        (child, anim) =>
                                                                            RotationTransition(
                                                                              turns: child.key == ValueKey('icon1')
                                                                                  ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                  : child.key == ValueKey('icon2')
                                                                                      ? Tween<double>(begin: 0.75, end: 1).animate(anim)
                                                                                      : Tween<double>(begin: 0.75, end: 1).animate(anim),
                                                                              child: ScaleTransition(scale: anim, child: child),
                                                                            ),
                                                                    child: controllers.currentIndexC ==
                                                                            0
                                                                        ? Image.asset(
                                                                            "assets/images/c.png",
                                                                            height:
                                                                                25,
                                                                            width:
                                                                                25,
                                                                            color:
                                                                                Theme.of(context).cursorColor,
                                                                            key: const ValueKey('icon1'))
                                                                        : controllers.currentIndexC == 1
                                                                            ? Icon(
                                                                                CupertinoIcons.check_mark_circled,
                                                                                size: 25,
                                                                                color: Theme.of(context).cursorColor,
                                                                                key: const ValueKey('icon2'),
                                                                              )
                                                                            : Icon(
                                                                                CupertinoIcons.clear,
                                                                                size: 25,
                                                                                color: Theme.of(context).cursorColor,
                                                                                key: const ValueKey('icon3'),
                                                                              )),
                                                            onPressed: () {},
                                                          ),
                                                          title: Text(
                                                            rtoQuestionModel
                                                                .optionC,
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: isNoSelected
                                                                    ? Colors.blueGrey
                                                                    : isCcorrect
                                                                        ? Theme.of(context).hintColor
                                                                        : Colors.redAccent,
                                                                fontFamily: "Circular Medium"),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ).cornerRadius(10))
                                              .py(5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 40,
                                                width: 100,
                                                child: Material(
                                                  color: Theme.of(context)
                                                      .dialogTheme
                                                      .backgroundColor,
                                                  child: Ink(
                                                    decoration: BoxDecoration(),
                                                    child: InkWell(
                                                      customBorder: RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius.only(
                                                                  topRight: Radius
                                                                      .circular(
                                                                          25),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          25))),
                                                      splashColor:
                                                          Theme.of(context)
                                                              .hoverColor,
                                                      onTap: () {
                                                        CommanDialog.restartDialog(
                                                            controllers,
                                                            context,
                                                            "Are you sure want to Restart ?",
                                                            isAcorrect,
                                                            isBcorrect,
                                                            isCcorrect,
                                                            isNoSelected,
                                                            clickA,
                                                            clickB,
                                                            clickC,
                                                            countController,
                                                            controllers,
                                                            isRtoPreparation);
                                                      },
                                                      child: Center(
                                                        child: Text(
                                                          "Restart",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontFamily:
                                                                  "Circular Medium"),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ).cornerRadius(25).px(20).py(15),
                                              isRtoPreparation
                                                  ? Container(
                                                      height: 40,
                                                      width: 100,
                                                      child: Material(
                                                        color: Theme.of(context)
                                                            .dialogTheme
                                                            .backgroundColor,
                                                        child: Ink(
                                                          decoration:
                                                              BoxDecoration(),
                                                          child: InkWell(
                                                            customBorder: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.only(
                                                                    topRight: Radius
                                                                        .circular(
                                                                            25),
                                                                    bottomRight:
                                                                        Radius.circular(
                                                                            25))),
                                                            splashColor:
                                                                Theme.of(
                                                                        context)
                                                                    .hoverColor,
                                                            onTap: () {
                                                              clickA = true;
                                                              clickB = true;
                                                              clickC = true;
                                                              if (isAcorrect ||
                                                                  isBcorrect ||
                                                                  isCcorrect) {
                                                                isAcorrect =
                                                                    false;
                                                                isBcorrect =
                                                                    false;
                                                                isCcorrect =
                                                                    false;
                                                                isNoSelected =
                                                                    true;
                                                                countController
                                                                    .restart(
                                                                        duration:
                                                                            duration);
                                                                controllers
                                                                    .changingIndex(
                                                                        0,
                                                                        0,
                                                                        0);
                                                                if (controllers
                                                                        .currentQue <
                                                                    25) {
                                                                  controller
                                                                      .fetchRtoQuestionData();
                                                                }
                                                              } else {
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Row(
                                                                      children: <
                                                                          Widget>[
                                                                        Text(
                                                                          "Please select the answer",
                                                                          style:
                                                                              TextStyle(color: Colors.white),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    duration: Duration(
                                                                        seconds:
                                                                            2),
                                                                    backgroundColor:
                                                                        Colors
                                                                            .black,
                                                                  ),
                                                                );
                                                              }

                                                              if (controllers
                                                                      .currentQue >=
                                                                  maxQuestion) {
                                                                isAcorrect =
                                                                    false;
                                                                isBcorrect =
                                                                    false;
                                                                isCcorrect =
                                                                    false;
                                                                isNoSelected =
                                                                    true;
                                                                clickA = false;
                                                                clickB = false;
                                                                clickC = false;
                                                                countController
                                                                    .pause();
                                                                if (controllers
                                                                        .rightAns >=
                                                                    passLimite) {
                                                                  CommanDialog.showResultDialog(
                                                                      context,
                                                                      controller,
                                                                      countController,
                                                                      "Congratulations",
                                                                      controller
                                                                          .yourScore,
                                                                      controller
                                                                          .highScore,
                                                                      controller
                                                                          .rightAns,
                                                                      controller
                                                                          .wrongAns,
                                                                      maxQuestion,
                                                                      isRtoPreparation,
                                                                      isAcorrect,
                                                                      isBcorrect,
                                                                      isCcorrect,
                                                                      isNoSelected,
                                                                      clickA,
                                                                      clickB,
                                                                      clickC);
                                                                } else {
                                                                  CommanDialog.showResultDialog(
                                                                      context,
                                                                      controller,
                                                                      countController,
                                                                      "Fail",
                                                                      controller
                                                                          .yourScore,
                                                                      controller
                                                                          .highScore,
                                                                      controller
                                                                          .rightAns,
                                                                      controller
                                                                          .wrongAns,
                                                                      maxQuestion,
                                                                      isRtoPreparation,
                                                                      isAcorrect,
                                                                      isBcorrect,
                                                                      isCcorrect,
                                                                      isNoSelected,
                                                                      clickA,
                                                                      clickB,
                                                                      clickC);
                                                                }
                                                              }
                                                            },
                                                            child: Center(
                                                              child: controllers
                                                                          .currentQue <
                                                                      25
                                                                  ? Text("Next",
                                                                      style: TextStyle(
                                                                          color: Colors
                                                                              .white,
                                                                          fontFamily:
                                                                              "Circular Medium"))
                                                                  : Text(
                                                                      "Result",
                                                                      style: TextStyle(
                                                                          color: Colors
                                                                              .white,
                                                                          fontFamily:
                                                                              "Circular Medium"),
                                                                    ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                      .cornerRadius(25)
                                                      .px(20)
                                                      .py(15)
                                                  : Container()
                                            ],
                                          )
                                        ],
                                      ).pOnly(top: 35, left: 20, right: 20)))
                              : Center(
                                  child: CircularProgressIndicator(),
                                ),
                        );
                      },
                    )),
                Positioned(
                  top: 110,
                  child: Container(
                    width: 90,
                    height: 90,
                    decoration: new BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      shape: BoxShape.circle,
                    ),
                    padding: EdgeInsets.all(6),
                    child: Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50)),
                      color: Colors.yellow,
                      child: CircularCountDownTimer(
                        duration: duration,
                        initialDuration: 0,
                        controller: countController,
                        width: MediaQuery.of(context).size.width / 2,
                        height: MediaQuery.of(context).size.height / 2,
                        ringColor: Theme.of(context).hintColor,
                        ringGradient: null,
                        fillColor: context.backgroundColor,
                        fillGradient: null,
                        backgroundColor: context.backgroundColor,
                        backgroundGradient: null,
                        strokeWidth: 7,
                        strokeCap: StrokeCap.round,
                        textStyle: TextStyle(
                            fontSize: 33.0,
                            color: Theme.of(context).accentColor,
                            fontFamily: "Circular Medium"),
                        textFormat: CountdownTextFormat.S,
                        isReverse: true,
                        isReverseAnimation: false,
                        isTimerTextShown: true,
                        autoStart: false,
                        onStart: () {},
                        onComplete: () {
                          if (controllers.currentQue < maxQuestion) {
                            countController.restart(duration: duration);
                            controllers.incWrongAns();
                            clickA = true;
                            clickB = true;
                            clickC = true;
                            isAcorrect = false;
                            isBcorrect = false;
                            isCcorrect = false;
                            isNoSelected = true;
                            controllers.fetchRtoQuestionData();
                            controllers.changingIndex(0, 0, 0);
                          } else {
                            controllers.incWrongAns();
                            countController.pause();
                            isAcorrect = false;
                            isBcorrect = false;
                            isCcorrect = false;
                            isNoSelected = true;
                            if (controllers.rightAns >= passLimite) {
                              CommanDialog.showResultDialog(
                                  context,
                                  controllers,
                                  countController,
                                  "Congratulations",
                                  controllers.yourScore,
                                  controllers.highScore,
                                  controllers.rightAns,
                                  controllers.wrongAns,
                                  maxQuestion,
                                  isRtoPreparation,
                                  isAcorrect,
                                  isBcorrect,
                                  isCcorrect,
                                  isNoSelected,
                                  clickA,
                                  clickB,
                                  clickC);
                            } else {
                              CommanDialog.showResultDialog(
                                  context,
                                  controllers,
                                  countController,
                                  "Fail",
                                  controllers.yourScore,
                                  controllers.highScore,
                                  controllers.rightAns,
                                  controllers.wrongAns,
                                  maxQuestion,
                                  isRtoPreparation,
                                  isAcorrect,
                                  isBcorrect,
                                  isCcorrect,
                                  isNoSelected,
                                  clickA,
                                  clickB,
                                  clickC);
                            }
                          }
                        },
                      ),
                    ),
                  ),
                )
              ],
            ).px(15).pOnly(top: 10),
          )
        ],
      ),
    );
  }

  void functionA(BuildContext context, RtoQuestionModel rtoQuestionModel,
      RtoQuestionController controller, bool isRtoPreperation) {
    countController.pause();
    clickA = false;
    clickB = false;
    clickC = false;
    if (rtoQuestionModel.optionA == rtoQuestionModel.answer) {
      isAcorrect = true;
      isBcorrect = false;
      isCcorrect = false;
      isNoSelected = false;
      controller.incRightAns();
      controllers.changingIndex(1, 2, 2);
    }
    if (rtoQuestionModel.optionB == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = true;
      isCcorrect = false;
      isNoSelected = false;
      controller.incWrongAns();
      controllers.changingIndex(2, 1, 2);
      countController.pause();
    }
    if (rtoQuestionModel.optionC == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = false;
      isCcorrect = true;
      isNoSelected = false;
      controllers.incWrongAns();
      controllers.changingIndex(2, 2, 1);
      countController.pause();
    }
    if (!isRtoPreparation) {
      countController.pause();
      Future.delayed(Duration(milliseconds: 1500), () {
        print("current question : ${controllers.currentQue}");
        if (controllers.currentQue < maxQuestion) {
          if (controllers.currentQue < 25) {
            clickA = true;
            clickB = true;
            clickC = true;
            if (isAcorrect || isBcorrect || isCcorrect) {
              isAcorrect = false;
              isBcorrect = false;
              isCcorrect = false;
              isNoSelected = true;
              controller.fetchRtoQuestionData();
              countController.restart(duration: duration);
              controllers.changingIndex(0, 0, 0);
            }
          }
        } else {
          if (controllers.rightAns >= maxQuestion) {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Congratulations",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          } else {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Fail",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          }
        }
      });
    }
  }

  void functionB(BuildContext context, RtoQuestionModel rtoQuestionModel,
      RtoQuestionController controller, maxQuestion, bool isRtoPreperation) {
    countController.pause();
    clickA = false;
    clickB = false;
    clickC = false;
    if (rtoQuestionModel.optionA == rtoQuestionModel.answer) {
      isAcorrect = true;
      isBcorrect = false;
      isCcorrect = false;
      isNoSelected = false;
      controller.incWrongAns();
      controllers.changingIndex(1, 2, 2);
      countController.pause();
    }
    if (rtoQuestionModel.optionB == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = true;
      isCcorrect = false;
      isNoSelected = false;
      controller.incRightAns();
      controllers.changingIndex(2, 1, 2);
      countController.pause();
    }
    if (rtoQuestionModel.optionC == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = false;
      isCcorrect = true;
      isNoSelected = false;
      controller.incWrongAns();
      controllers.changingIndex(2, 2, 1);
      countController.pause();
    }
    if (!isRtoPreparation) {
      countController.pause();
      Future.delayed(Duration(milliseconds: 1500), () {
        if (controllers.currentQue < maxQuestion) {
          clickA = true;
          clickB = true;
          clickC = true;
          if (isAcorrect || isBcorrect || isCcorrect) {
            isAcorrect = false;
            isBcorrect = false;
            isCcorrect = false;
            isNoSelected = true;
            controller.fetchRtoQuestionData();
            countController.restart(duration: duration);
            controllers.changingIndex(0, 0, 0);
          }
        } else {
          if (controllers.rightAns >= maxQuestion) {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Congratulations",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          } else {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Fail",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          }
        }
      });
    }
  }

  void functionC(BuildContext context, RtoQuestionModel rtoQuestionModel,
      RtoQuestionController controller, bool isRtoPreperation) {
    countController.pause();
    clickA = false;
    clickB = false;
    clickC = false;
    if (rtoQuestionModel.optionA == rtoQuestionModel.answer) {
      isAcorrect = true;
      isBcorrect = false;
      isCcorrect = false;
      isNoSelected = false;
      controller.incWrongAns();
      controllers.changingIndex(1, 2, 2);
      countController.pause();
    }
    if (rtoQuestionModel.optionB == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = true;
      isCcorrect = false;
      isNoSelected = false;
      controller.incWrongAns();
      controllers.changingIndex(2, 1, 2);
      countController.pause();
    }
    if (rtoQuestionModel.optionC == rtoQuestionModel.answer) {
      isAcorrect = false;
      isBcorrect = false;
      isCcorrect = true;
      isNoSelected = false;
      controller.incRightAns();
      controllers.changingIndex(2, 2, 1);
      countController.pause();
    }
    if (!isRtoPreparation) {
      countController.pause();
      Future.delayed(Duration(milliseconds: 1500), () {
        if (controllers.currentQue < maxQuestion) {
          clickA = true;
          clickB = true;
          clickC = true;
          if (isAcorrect || isBcorrect || isCcorrect) {
            isAcorrect = false;
            isBcorrect = false;
            isCcorrect = false;
            isNoSelected = true;
            controller.fetchRtoQuestionData();
            countController.restart(duration: duration);
            controllers.changingIndex(0, 0, 0);
          }
        } else {
          if (controllers.rightAns >= maxQuestion) {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Congratulations",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          } else {
            CommanDialog.showResultDialog(
                context,
                controller,
                countController,
                "Fail",
                controller.yourScore,
                controller.highScore,
                controller.rightAns,
                controller.wrongAns,
                maxQuestion,
                isRtoPreparation,
                isAcorrect,
                isBcorrect,
                isCcorrect,
                isNoSelected,
                clickA,
                clickB,
                clickC);
          }
        }
      });
    }
  }
}
