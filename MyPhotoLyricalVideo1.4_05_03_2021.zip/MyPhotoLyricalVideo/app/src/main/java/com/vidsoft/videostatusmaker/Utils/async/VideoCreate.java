package com.vidsoft.videostatusmaker.Utils.async;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.vidsoft.videostatusmaker.Activity.ActivityPreview;
import com.vidsoft.videostatusmaker.App.MyApplication;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

public class VideoCreate extends AsyncTask<Void, Void, Boolean> {
    String folderPath;
    String string;
    Context context;
    String strOutputPath;


    public VideoCreate(final Context context, final String string) {
        this.context = context;
        this.string = string;
        final StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory());
        sb.append("/");
        sb.append(context.getResources().getString(R.string.app_name));
        this.folderPath = sb.toString();
    }


    protected Boolean doInBackground(Void... voidArr) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.folderPath);
        stringBuilder.append("/Video");
        File absoluteFile = new File(stringBuilder.toString()).getAbsoluteFile();
        if (!absoluteFile.exists()) {
            absoluteFile.mkdir();
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(absoluteFile);
        stringBuilder.append(File.separator);
        stringBuilder.append("temp.mp4");
        this.strOutputPath = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.folderPath);
        stringBuilder2.append("/");
        stringBuilder2.append(this.context.getString(R.string.temp_folder));
        stringBuilder2.append("/temp/anim%d.jpg");
        String stringBuilder3 = stringBuilder2.toString();
        String[] strArr;
        if (MyApplication.Variable_VIDEO_WIDTH == 720) {
            strArr = new String[]{"-y", "-r", this.string, "-i", stringBuilder3, "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-preset", "ultrafast", this.strOutputPath};
        } else {
            strArr = new String[]{"-y", "-r", this.string, "-i", stringBuilder3, "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-vf", "scale=1080:1920", "-preset", "ultrafast", this.strOutputPath};
        }
        ExcuteFFmpeg(strArr);
        return Boolean.TRUE;
    }

    protected void onPostExecute(final Boolean b) {
        super.onPostExecute(b);
    }

    protected void onPreExecute() {
        super.onPreExecute();
    }



    public void ExcuteFFmpeg(final String[] command) {
        FFmpeg.executeAsync(command, new ExecuteCallback() {
            @Override
            public void apply(final long executionId, final int returnCode) {
                if (returnCode == RETURN_CODE_SUCCESS) {
                    ((ActivityPreview) context).addMusic(strOutputPath);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    Log.e("TAG", "Async command execution cancelled by user.");
                } else {
                    Log.e("TAG", String.format("Async command execution failed with returnCode=%d.", returnCode));
                }
            }
        });
    }
}
