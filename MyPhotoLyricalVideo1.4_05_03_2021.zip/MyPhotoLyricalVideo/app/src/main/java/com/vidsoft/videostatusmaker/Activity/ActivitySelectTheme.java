package com.vidsoft.videostatusmaker.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.vidsoft.videostatusmaker.adapter.ThemeAdapter;

import static com.vidsoft.videostatusmaker.NativeAds.NativeAdMethod.populateNativeAdView;

public class ActivitySelectTheme extends AppCompatActivity {

    ThemeAdapter themeAdapter;
    ImageView ivBack;
    Typeface typeface;
    ImageLoader imageLoader;
    GridView stylelist;
    String[] theme;
    TextView title;

    private UnifiedNativeAd nativeAd;

    private void initImageLoader() {
        (this.imageLoader = ImageLoader.getInstance()).init(new ImageLoaderConfiguration.Builder((Context) this).defaultDisplayImageOptions(new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).build()).build());
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.select_typface);
        this.getWindow().addFlags(1024);
        PutAnalyticsEvent();
        LoadNativeAds();
        this.initImageLoader();
        init();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ActivitySelectTheme");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout =
                        findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.layout_native_advance, null);
                populateNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }


    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    private void init() {
        this.ivBack = this.findViewById(R.id.back);
        this.title = this.findViewById(R.id.title);
        this.ivBack.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                ActivitySelectTheme.this.onBackPressed();
            }
        });
        this.typeface = Typeface.createFromAsset(this.getAssets(), "Montserrat-Regular_0.otf");
        this.title.setTypeface(this.typeface);
        this.title.setText((CharSequence) "Themes");
        this.stylelist = this.findViewById(R.id.stylelist);
        try {
            this.theme = this.getResources().getAssets().list("theme");
            this.themeAdapter = new ThemeAdapter(this.getApplicationContext(), this.theme);
            this.stylelist.setAdapter((ListAdapter) this.themeAdapter);
            this.stylelist.setNumColumns(2);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.stylelist.setOnItemClickListener((AdapterView.OnItemClickListener) new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int theme, final long n) {
                if (theme == 0) {
                    Log.e("LOG", "====11111====");
                    ActivityPreview.THEME = theme;
                    ActivityPreview.complete = false;
                    if (theme == 4) {
                        Log.e("LOG", "====22222====");
                        ActivityPreview.lyricTxt1.setTextColor(-16777216);
                        ActivityPreview.lyricTxt2.setTextColor(-16777216);
                    } else {
                        Log.e("LOG", "====33333====");
                        ActivityPreview.lyricTxt1.setTextColor(-1);
                        ActivityPreview.lyricTxt2.setTextColor(-1);
                    }
                    Log.e("LOG", "====44444====");
                    ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                    ActivitySelectTheme.this.finish();
                    return;
                }
                Log.e("LOG","====5555555====");
                ActivityPreview.complete = false;
                ActivityPreview.THEME = theme;
                if (n == 4) {
                    Log.e("LOG","====66666====");
                    ActivityPreview.lyricTxt1.setTextColor(-16777216);
                    ActivityPreview.lyricTxt2.setTextColor(-16777216);
                } else if (n == 5) {
                    Log.e("LOG","====777777====");
                    ActivityPreview.lyricTxt1.setTextColor(Color.parseColor("#000004"));
                    ActivityPreview.lyricTxt2.setTextColor(Color.parseColor("#000004"));
                } else {
                    Log.e("LOG","====88888====");
                    ActivityPreview.lyricTxt1.setTextColor(-1);
                    ActivityPreview.lyricTxt2.setTextColor(-1);
                }
                ActivitySelectTheme.this.setResult(-1, new Intent(ActivitySelectTheme.this.getApplicationContext(), (Class) ActivityPreview.class));
                ActivitySelectTheme.this.finish();
            }
        });
    }
}
