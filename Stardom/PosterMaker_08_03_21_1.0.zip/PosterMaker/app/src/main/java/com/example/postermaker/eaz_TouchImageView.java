package com.example.postermaker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.SimpleOnScaleGestureListener;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.OverScroller;
import android.widget.Scroller;

@SuppressLint("AppCompatCustomView")
public class eaz_TouchImageView extends ImageView {
    private static final String DEBUG = "DEBUG";
    private static final float SUPER_MAX_MULTIPLIER = 1.25f;
    private static final float SUPER_MIN_MULTIPLIER = 0.75f;
    private Context context;
    private ZoomVariables delayedZoomVariables;
    private OnDoubleTapListener doubleTapListener = null;
    private float[] f1662m;
    private Fling fling;
    private boolean imageRenderedAtLeastOnce;
    private GestureDetector mGestureDetector;
    private ScaleGestureDetector mScaleDetector;
    private ScaleType mScaleType;
    private float matchViewHeight;
    private float matchViewWidth;
    private Matrix matrix;
    private float maxScale;
    private float minScale;
    private float normalizedScale;
    private boolean onDrawReady;
    private float prevMatchViewHeight;
    private float prevMatchViewWidth;
    private Matrix prevMatrix;
    private int prevViewHeight;
    private int prevViewWidth;
    private State state;
    private float superMaxScale;
    private float superMinScale;
    private OnTouchImageViewListener touchImageViewListener = null;
    private OnTouchListener userTouchListener = null;
    private int viewHeight;
    private int viewWidth;

    static class C11061 {

        C11061() {
        }

        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Missing block: B:13:?, code skipped:
            return;
     */
       /* static {
            *//*
            r0 = android.widget.ImageView.ScaleType.values();
            r0 = r0.length;
            r0 = new int[r0];
            $SwitchMap$android$widget$ImageView$ScaleType = r0;
            r1 = android.widget.ImageView.ScaleType.CENTER;	 Catch:{ NoSuchFieldError -> 0x0012 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 1;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r0 = $SwitchMap$android$widget$ImageView$ScaleType;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = android.widget.ImageView.ScaleType.CENTER_CROP;	 Catch:{ NoSuchFieldError -> 0x001d }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x001d }
            r2 = 2;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x001d }
        L_0x001d:
            r0 = $SwitchMap$android$widget$ImageView$ScaleType;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = android.widget.ImageView.ScaleType.CENTER_INSIDE;	 Catch:{ NoSuchFieldError -> 0x0028 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0028 }
            r2 = 3;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0028 }
        L_0x0028:
            r0 = $SwitchMap$android$widget$ImageView$ScaleType;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = android.widget.ImageView.ScaleType.FIT_CENTER;	 Catch:{ NoSuchFieldError -> 0x0033 }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x0033 }
            r2 = 4;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r0 = $SwitchMap$android$widget$ImageView$ScaleType;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = android.widget.ImageView.ScaleType.FIT_XY;	 Catch:{ NoSuchFieldError -> 0x003e }
            r1 = r1.ordinal();	 Catch:{ NoSuchFieldError -> 0x003e }
            r2 = 5;
            r0[r1] = r2;	 Catch:{ NoSuchFieldError -> 0x003e }
        L_0x003e:
            return;
            *//*
            throw new UnsupportedOperationException("Method not decompiled: com.fippleappzone.postermaker.eaz_TouchImageView$C11061.<clinit>():void");
        }*/
    }

    private class CompatScroller {
        boolean isPreGingerbread;
        OverScroller overScroller;
        Scroller scroller;

        public CompatScroller(Context context) {
            if (VERSION.SDK_INT < 9) {
                this.isPreGingerbread = true;
                this.scroller = new Scroller(context);
                return;
            }
            this.isPreGingerbread = false;
            this.overScroller = new OverScroller(context);
        }

        public void fling(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            if (this.isPreGingerbread) {
                this.scroller.fling(i, i2, i3, i4, i5, i6, i7, i8);
            } else {
                this.overScroller.fling(i, i2, i3, i4, i5, i6, i7, i8);
            }
        }

        public void forceFinished(boolean z) {
            if (this.isPreGingerbread) {
                this.scroller.forceFinished(z);
            } else {
                this.overScroller.forceFinished(z);
            }
        }

        public boolean isFinished() {
            if (this.isPreGingerbread) {
                return this.scroller.isFinished();
            }
            return this.overScroller.isFinished();
        }

        public boolean computeScrollOffset() {
            if (this.isPreGingerbread) {
                return this.scroller.computeScrollOffset();
            }
            this.overScroller.computeScrollOffset();
            return this.overScroller.computeScrollOffset();
        }

        public int getCurrX() {
            if (this.isPreGingerbread) {
                return this.scroller.getCurrX();
            }
            return this.overScroller.getCurrX();
        }

        public int getCurrY() {
            if (this.isPreGingerbread) {
                return this.scroller.getCurrY();
            }
            return this.overScroller.getCurrY();
        }
    }

    private class DoubleTapZoom implements Runnable {
        private static final float ZOOM_TIME = 500.0f;
        private float bitmapX;
        private float bitmapY;
        private PointF endTouch;
        private AccelerateDecelerateInterpolator interpolator = new AccelerateDecelerateInterpolator();
        private long startTime;
        private PointF startTouch;
        private float startZoom;
        private boolean stretchImageToSuper;
        private float targetZoom;

        DoubleTapZoom(float f, float f2, float f3, boolean z) {
            eaz_TouchImageView.this.setState(State.ANIMATE_ZOOM);
            this.startTime = System.currentTimeMillis();
            this.startZoom = eaz_TouchImageView.this.normalizedScale;
            this.targetZoom = f;
            this.stretchImageToSuper = z;
            PointF access$200 = eaz_TouchImageView.this.transformCoordTouchToBitmap(f2, f3, false);
            this.bitmapX = access$200.x;
            f = access$200.y;
            this.bitmapY = f;
            this.startTouch = eaz_TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, f);
            this.endTouch = new PointF((float) (eaz_TouchImageView.this.viewWidth / 2), (float) (eaz_TouchImageView.this.viewHeight / 2));
        }

        public void run() {
            float interpolate = interpolate();
            eaz_TouchImageView.this.scaleImage(calculateDeltaScale(interpolate), this.bitmapX, this.bitmapY, this.stretchImageToSuper);
            translateImageToCenterTouchPosition(interpolate);
            eaz_TouchImageView.this.fixScaleTrans();
            eaz_TouchImageView eaz_touchimageview = eaz_TouchImageView.this;
            eaz_touchimageview.setImageMatrix(eaz_touchimageview.matrix);
            if (eaz_TouchImageView.this.touchImageViewListener != null) {
                eaz_TouchImageView.this.touchImageViewListener.onMove();
            }
            if (interpolate < 1.0f) {
                eaz_TouchImageView.this.compatPostOnAnimation(this);
            } else {
                eaz_TouchImageView.this.setState(State.NONE);
            }
        }

        private void translateImageToCenterTouchPosition(float f) {
            float f2 = this.startTouch.x + ((this.endTouch.x - this.startTouch.x) * f);
            float f3 = this.startTouch.y + ((this.endTouch.y - this.startTouch.y) * f);
            PointF access$300 = eaz_TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, this.bitmapY);
            eaz_TouchImageView.this.matrix.postTranslate(f2 - access$300.x, f3 - access$300.y);
        }

        private float interpolate() {
            return this.interpolator.getInterpolation(Math.min(1.0f, ((float) (System.currentTimeMillis() - this.startTime)) / ZOOM_TIME));
        }

        private double calculateDeltaScale(float f) {
            float f2 = this.startZoom;
            double d = (double) (f2 + ((this.targetZoom - f2) * f));
            double access$100 = (double) eaz_TouchImageView.this.normalizedScale;
            Double.isNaN(d);
            Double.isNaN(access$100);
            return d / access$100;
        }
    }

    private class Fling implements Runnable {
        int currX;
        int currY;
        CompatScroller scroller;

        Fling(int i, int i2) {
            int access$400;
            int i3;
            int access$500;
            int i4;
            eaz_TouchImageView.this.setState(State.FLING);
            this.scroller = new CompatScroller(eaz_TouchImageView.this.context);
            eaz_TouchImageView.this.matrix.getValues(eaz_TouchImageView.this.f1662m);
            int i5 = (int) eaz_TouchImageView.this.f1662m[2];
            int i6 = (int) eaz_TouchImageView.this.f1662m[5];
            if (eaz_TouchImageView.this.getImageWidth() > ((float) eaz_TouchImageView.this.viewWidth)) {
                access$400 = eaz_TouchImageView.this.viewWidth - ((int) eaz_TouchImageView.this.getImageWidth());
                i3 = 0;
            } else {
                access$400 = i5;
                i3 = access$400;
            }
            if (eaz_TouchImageView.this.getImageHeight() > ((float) eaz_TouchImageView.this.viewHeight)) {
                access$500 = eaz_TouchImageView.this.viewHeight - ((int) eaz_TouchImageView.this.getImageHeight());
                i4 = 0;
            } else {
                access$500 = i6;
                i4 = access$500;
            }
            this.scroller.fling(i5, i6, i, i2, access$400, i3, access$500, i4);
            this.currX = i5;
            this.currY = i6;
        }

        public void cancelFling() {
            if (this.scroller != null) {
                eaz_TouchImageView.this.setState(State.NONE);
                this.scroller.forceFinished(true);
            }
        }

        public void run() {
            if (eaz_TouchImageView.this.touchImageViewListener != null) {
                eaz_TouchImageView.this.touchImageViewListener.onMove();
            }
            if (this.scroller.isFinished()) {
                this.scroller = null;
            } else if (this.scroller.computeScrollOffset()) {
                int currX = this.scroller.getCurrX();
                int currY = this.scroller.getCurrY();
                int i = currX - this.currX;
                int i2 = currY - this.currY;
                this.currX = currX;
                this.currY = currY;
                eaz_TouchImageView.this.matrix.postTranslate((float) i, (float) i2);
                eaz_TouchImageView.this.fixTrans();
                eaz_TouchImageView eaz_touchimageview = eaz_TouchImageView.this;
                eaz_touchimageview.setImageMatrix(eaz_touchimageview.matrix);
                eaz_TouchImageView.this.compatPostOnAnimation(this);
            }
        }
    }

    private class GestureListener extends SimpleOnGestureListener {
        private GestureListener() {
        }

        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            if (eaz_TouchImageView.this.doubleTapListener != null) {
                return eaz_TouchImageView.this.doubleTapListener.onSingleTapConfirmed(motionEvent);
            }
            return eaz_TouchImageView.this.performClick();
        }

        public void onLongPress(MotionEvent motionEvent) {
            eaz_TouchImageView.this.performLongClick();
        }

        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            if (eaz_TouchImageView.this.fling != null) {
                eaz_TouchImageView.this.fling.cancelFling();
            }
            eaz_TouchImageView.this.fling = new Fling((int) f, (int) f2);
            eaz_TouchImageView eaz_touchimageview = eaz_TouchImageView.this;
            eaz_touchimageview.compatPostOnAnimation(eaz_touchimageview.fling);
            return super.onFling(motionEvent, motionEvent2, f, f2);
        }

        public boolean onDoubleTap(MotionEvent motionEvent) {
            boolean onDoubleTap = eaz_TouchImageView.this.doubleTapListener != null ? eaz_TouchImageView.this.doubleTapListener.onDoubleTap(motionEvent) : false;
            if (eaz_TouchImageView.this.state != State.NONE) {
                return onDoubleTap;
            }
            eaz_TouchImageView eaz_touchimageview = eaz_TouchImageView.this;
            eaz_TouchImageView eaz_touchimageview2 = eaz_TouchImageView.this;
            eaz_touchimageview.compatPostOnAnimation(new DoubleTapZoom(eaz_touchimageview2.normalizedScale == eaz_TouchImageView.this.minScale ? eaz_TouchImageView.this.maxScale : eaz_TouchImageView.this.minScale, motionEvent.getX(), motionEvent.getY(), false));
            return true;
        }

        public boolean onDoubleTapEvent(MotionEvent motionEvent) {
            return eaz_TouchImageView.this.doubleTapListener != null ? eaz_TouchImageView.this.doubleTapListener.onDoubleTapEvent(motionEvent) : false;
        }
    }

    public interface OnTouchImageViewListener {
        void onMove();
    }


    private class PrivateOnTouchListener implements OnTouchListener
    {
        private PointF last;

        private PrivateOnTouchListener() {
            this.last = new PointF();
        }

        public boolean onTouch(final View view, final MotionEvent motionEvent) {
            eaz_TouchImageView.this.mScaleDetector.onTouchEvent(motionEvent);
            eaz_TouchImageView.this.mGestureDetector.onTouchEvent(motionEvent);
            final PointF pointF = new PointF(motionEvent.getX(), motionEvent.getY());
            Label_0302: {
                if (eaz_TouchImageView.this.state == State.NONE || eaz_TouchImageView.this.state == State.DRAG || eaz_TouchImageView.this.state == State.FLING) {
                    final int action = motionEvent.getAction();
                    if (action != 0) {
                        if (action != 1) {
                            if (action != 2) {
                                if (action != 6) {
                                    break Label_0302;
                                }
                            }
                            else {
                                if (eaz_TouchImageView.this.state == State.DRAG) {
                                    final float y = pointF.y;
                                    final float y2 = this.last.y;
                                    final Matrix access$800 = eaz_TouchImageView.this.matrix;
                                    final float access$801 = eaz_TouchImageView.this.getFixDragTrans(pointF.x - this.last.x, (float)eaz_TouchImageView.this.viewWidth, eaz_TouchImageView.this.getImageWidth());
                                    final eaz_TouchImageView this$0 = eaz_TouchImageView.this;
                                    access$800.postTranslate(access$801, this$0.getFixDragTrans(y - y2, (float)this$0.viewHeight, eaz_TouchImageView.this.getImageHeight()));
                                    eaz_TouchImageView.this.fixTrans();
                                    this.last.set(pointF.x, pointF.y);
                                }
                                break Label_0302;
                            }
                        }
                        eaz_TouchImageView.this.setState(State.NONE);
                    }
                    else {
                        this.last.set(pointF);
                        if (eaz_TouchImageView.this.fling != null) {
                            eaz_TouchImageView.this.fling.cancelFling();
                        }
                        eaz_TouchImageView.this.setState(State.DRAG);
                    }
                }
            }
            final eaz_TouchImageView this$2 = eaz_TouchImageView.this;
            this$2.setImageMatrix(this$2.matrix);
            if (eaz_TouchImageView.this.userTouchListener != null) {
                eaz_TouchImageView.this.userTouchListener.onTouch(view, motionEvent);
            }
            if (eaz_TouchImageView.this.touchImageViewListener != null) {
                eaz_TouchImageView.this.touchImageViewListener.onMove();
            }
            return true;
        }
    }

    private class ScaleListener extends SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            eaz_TouchImageView.this.setState(State.ZOOM);
            return true;
        }

        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            eaz_TouchImageView.this.scaleImage((double) scaleGestureDetector.getScaleFactor(), scaleGestureDetector.getFocusX(), scaleGestureDetector.getFocusY(), true);
            if (eaz_TouchImageView.this.touchImageViewListener != null) {
                eaz_TouchImageView.this.touchImageViewListener.onMove();
            }
            return true;
        }

        public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
            super.onScaleEnd(scaleGestureDetector);
            eaz_TouchImageView.this.setState(State.NONE);
            float access$100 = eaz_TouchImageView.this.normalizedScale;
            Object obj = 1;
            if (eaz_TouchImageView.this.normalizedScale > eaz_TouchImageView.this.maxScale) {
                access$100 = eaz_TouchImageView.this.maxScale;
            } else if (eaz_TouchImageView.this.normalizedScale < eaz_TouchImageView.this.minScale) {
                access$100 = eaz_TouchImageView.this.minScale;
            } else {
                obj = null;
            }
            float f = access$100;
            if (obj != null) {
                eaz_TouchImageView eaz_touchimageview = eaz_TouchImageView.this;
                eaz_TouchImageView eaz_touchimageview2 = eaz_TouchImageView.this;
                eaz_touchimageview.compatPostOnAnimation(new DoubleTapZoom(f, (float) (eaz_touchimageview2.viewWidth / 2), (float) (eaz_TouchImageView.this.viewHeight / 2), true));
            }
        }
    }

    private enum State {
        NONE,
        DRAG,
        ZOOM,
        FLING,
        ANIMATE_ZOOM
    }

    private class ZoomVariables {
        public float focusX;
        public float focusY;
        public float scale;
        public ScaleType scaleType;

        public ZoomVariables(float f, float f2, float f3, ScaleType scaleType) {
            this.scale = f;
            this.focusX = f2;
            this.focusY = f3;
            this.scaleType = scaleType;
        }
    }

    private float getFixDragTrans(float f, float f2, float f3) {
        return f3 <= f2 ? 0.0f : f;
    }

    private float getFixTrans(float f, float f2, float f3) {
        if (f3 <= f2) {
            f3 = f2 - f3;
            f2 = 0.0f;
        } else {
            f2 -= f3;
            f3 = 0.0f;
        }
        return f < f2 ? (-f) + f2 : f > f3 ? (-f) + f3 : 0.0f;
    }

    public eaz_TouchImageView(Context context) {
        super(context);
        sharedConstructing(context);
    }

    public eaz_TouchImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        sharedConstructing(context);
    }

    public eaz_TouchImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        sharedConstructing(context);
    }

    private void sharedConstructing(Context context) {
        super.setClickable(true);
        this.context = context;
        this.mScaleDetector = new ScaleGestureDetector(context, new ScaleListener());
        this.mGestureDetector = new GestureDetector(context, new GestureListener());
        this.matrix = new Matrix();
        this.prevMatrix = new Matrix();
        this.f1662m = new float[9];
        this.normalizedScale = 1.0f;
        if (this.mScaleType == null) {
            this.mScaleType = ScaleType.FIT_CENTER;
        }
        this.minScale = 1.0f;
        this.maxScale = 3.0f;
        this.superMinScale = 1.0f * SUPER_MIN_MULTIPLIER;
        this.superMaxScale = 3.0f * SUPER_MAX_MULTIPLIER;
        setImageMatrix(this.matrix);
        setScaleType(ScaleType.MATRIX);
        setState(State.NONE);
        this.onDrawReady = false;
        super.setOnTouchListener(new PrivateOnTouchListener());
    }

    public void setOnTouchListener(OnTouchListener onTouchListener) {
        this.userTouchListener = onTouchListener;
    }

    public void setOnTouchImageViewListener(OnTouchImageViewListener onTouchImageViewListener) {
        this.touchImageViewListener = onTouchImageViewListener;
    }

    public void setOnDoubleTapListener(OnDoubleTapListener onDoubleTapListener) {
        this.doubleTapListener = onDoubleTapListener;
    }

    public void setImageResource(int i) {
        super.setImageResource(i);
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        savePreviousImageValues();
        fitImageToView();
    }

    public void setScaleType(ScaleType scaleType) {
        if (scaleType == ScaleType.FIT_START || scaleType == ScaleType.FIT_END) {
            throw new UnsupportedOperationException("TouchImageView does not support FIT_START or FIT_END");
        } else if (scaleType == ScaleType.MATRIX) {
            super.setScaleType(ScaleType.MATRIX);
        } else {
            this.mScaleType = scaleType;
            if (this.onDrawReady) {
                setZoom(this);
            }
        }
    }

    public ScaleType getScaleType() {
        return this.mScaleType;
    }

    public boolean isZoomed() {
        return this.normalizedScale != 1.0f;
    }

    public RectF getZoomedRect() {
        if (this.mScaleType != ScaleType.FIT_XY) {
            PointF transformCoordTouchToBitmap = transformCoordTouchToBitmap(0.0f, 0.0f, true);
            PointF transformCoordTouchToBitmap2 = transformCoordTouchToBitmap((float) this.viewWidth, (float) this.viewHeight, true);
            float intrinsicWidth = (float) getDrawable().getIntrinsicWidth();
            float intrinsicHeight = (float) getDrawable().getIntrinsicHeight();
            return new RectF(transformCoordTouchToBitmap.x / intrinsicWidth, transformCoordTouchToBitmap.y / intrinsicHeight, transformCoordTouchToBitmap2.x / intrinsicWidth, transformCoordTouchToBitmap2.y / intrinsicHeight);
        }
        throw new UnsupportedOperationException("getZoomedRect() not supported with FIT_XY");
    }

    private void savePreviousImageValues() {
        Matrix matrix = this.matrix;
        if (matrix != null && this.viewHeight != 0 && this.viewWidth != 0) {
            matrix.getValues(this.f1662m);
            this.prevMatrix.setValues(this.f1662m);
            this.prevMatchViewHeight = this.matchViewHeight;
            this.prevMatchViewWidth = this.matchViewWidth;
            this.prevViewHeight = this.viewHeight;
            this.prevViewWidth = this.viewWidth;
        }
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        bundle.putFloat("saveScale", this.normalizedScale);
        bundle.putFloat("matchViewHeight", this.matchViewHeight);
        bundle.putFloat("matchViewWidth", this.matchViewWidth);
        bundle.putInt("viewWidth", this.viewWidth);
        bundle.putInt("viewHeight", this.viewHeight);
        this.matrix.getValues(this.f1662m);
        bundle.putFloatArray("matrix", this.f1662m);
        bundle.putBoolean("imageRendered", this.imageRenderedAtLeastOnce);
        return bundle;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            this.normalizedScale = bundle.getFloat("saveScale");
            float[] floatArray = bundle.getFloatArray("matrix");
            this.f1662m = floatArray;
            this.prevMatrix.setValues(floatArray);
            this.prevMatchViewHeight = bundle.getFloat("matchViewHeight");
            this.prevMatchViewWidth = bundle.getFloat("matchViewWidth");
            this.prevViewHeight = bundle.getInt("viewHeight");
            this.prevViewWidth = bundle.getInt("viewWidth");
            this.imageRenderedAtLeastOnce = bundle.getBoolean("imageRendered");
            super.onRestoreInstanceState(bundle.getParcelable("instanceState"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    /* Access modifiers changed, original: protected */
    public void onDraw(Canvas canvas) {
        this.onDrawReady = true;
        this.imageRenderedAtLeastOnce = true;
        ZoomVariables zoomVariables = this.delayedZoomVariables;
        if (zoomVariables != null) {
            setZoom(zoomVariables.scale, this.delayedZoomVariables.focusX, this.delayedZoomVariables.focusY, this.delayedZoomVariables.scaleType);
            this.delayedZoomVariables = null;
        }
        super.onDraw(canvas);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        savePreviousImageValues();
    }

    public float getMaxZoom() {
        return this.maxScale;
    }

    public void setMaxZoom(float f) {
        this.maxScale = f;
        this.superMaxScale = f * SUPER_MAX_MULTIPLIER;
    }

    public float getMinZoom() {
        return this.minScale;
    }

    public float getCurrentZoom() {
        return this.normalizedScale;
    }

    public void setMinZoom(float f) {
        this.minScale = f;
        this.superMinScale = f * SUPER_MIN_MULTIPLIER;
    }

    public void resetZoom() {
        this.normalizedScale = 1.0f;
        fitImageToView();
    }

    public void setZoom(float f) {
        setZoom(f, 0.5f, 0.5f);
    }

    public void setZoom(float f, float f2, float f3) {
        setZoom(f, f2, f3, this.mScaleType);
    }

    public void setZoom(float f, float f2, float f3, ScaleType scaleType) {
        if (this.onDrawReady) {
            if (scaleType != this.mScaleType) {
                setScaleType(scaleType);
            }
            resetZoom();
            scaleImage((double) f, (float) (this.viewWidth / 2), (float) (this.viewHeight / 2), true);
            this.matrix.getValues(this.f1662m);
            this.f1662m[2] = -((getImageWidth() * f2) - (((float) this.viewWidth) * 0.5f));
            this.f1662m[5] = -((getImageHeight() * f3) - (((float) this.viewHeight) * 0.5f));
            this.matrix.setValues(this.f1662m);
            fixTrans();
            setImageMatrix(this.matrix);
            return;
        }
        this.delayedZoomVariables = new ZoomVariables(f, f2, f3, scaleType);
    }

    public void setZoom(eaz_TouchImageView eaz_touchimageview) {
        PointF scrollPosition = eaz_touchimageview.getScrollPosition();
        setZoom(eaz_touchimageview.getCurrentZoom(), scrollPosition.x, scrollPosition.y, eaz_touchimageview.getScaleType());
    }

    public PointF getScrollPosition() {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            return null;
        }
        int intrinsicWidth = drawable.getIntrinsicWidth();
        int intrinsicHeight = drawable.getIntrinsicHeight();
        PointF transformCoordTouchToBitmap = transformCoordTouchToBitmap((float) (this.viewWidth / 2), (float) (this.viewHeight / 2), true);
        transformCoordTouchToBitmap.x /= (float) intrinsicWidth;
        transformCoordTouchToBitmap.y /= (float) intrinsicHeight;
        return transformCoordTouchToBitmap;
    }

    public void setScrollPosition(float f, float f2) {
        setZoom(this.normalizedScale, f, f2);
    }

    private void fixTrans() {
        this.matrix.getValues(this.f1662m);
        float[] fArr = this.f1662m;
        float f = fArr[2];
        float f2 = fArr[5];
        f = getFixTrans(f, (float) this.viewWidth, getImageWidth());
        f2 = getFixTrans(f2, (float) this.viewHeight, getImageHeight());
        if (f != 0.0f || f2 != 0.0f) {
            this.matrix.postTranslate(f, f2);
        }
    }

    private void fixScaleTrans() {
        fixTrans();
        this.matrix.getValues(this.f1662m);
        float imageWidth = getImageWidth();
        int i = this.viewWidth;
        if (imageWidth < ((float) i)) {
            this.f1662m[2] = (((float) i) - getImageWidth()) / 2.0f;
        }
        imageWidth = getImageHeight();
        i = this.viewHeight;
        if (imageWidth < ((float) i)) {
            this.f1662m[5] = (((float) i) - getImageHeight()) / 2.0f;
        }
        this.matrix.setValues(this.f1662m);
    }

    private float getImageWidth() {
        return this.matchViewWidth * this.normalizedScale;
    }

    private float getImageHeight() {
        return this.matchViewHeight * this.normalizedScale;
    }

    /* Access modifiers changed, original: protected */
    public void onMeasure(int i, int i2) {
        Drawable drawable = getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() == 0 || drawable.getIntrinsicHeight() == 0) {
            setMeasuredDimension(0, 0);
            return;
        }
        int intrinsicWidth = drawable.getIntrinsicWidth();
        int intrinsicHeight = drawable.getIntrinsicHeight();
        int size = MeasureSpec.getSize(i);
        i = MeasureSpec.getMode(i);
        int size2 = MeasureSpec.getSize(i2);
        i2 = MeasureSpec.getMode(i2);
        this.viewWidth = setViewSize(i, size, intrinsicWidth);
        i = setViewSize(i2, size2, intrinsicHeight);
        this.viewHeight = i;
        setMeasuredDimension(this.viewWidth, i);
        fitImageToView();
    }

    private void fitImageToView() {
        Drawable drawable = getDrawable();
        if (drawable != null && drawable.getIntrinsicWidth() != 0 && drawable.getIntrinsicHeight() != 0 && this.matrix != null && this.prevMatrix != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            float f = (float) intrinsicWidth;
            float f2 = ((float) this.viewWidth) / f;
            float f3 = (float) intrinsicHeight;
            float f4 = ((float) this.viewHeight) / f3;
            //int i = C11061.$SwitchMap$android$widget$ImageView$ScaleType[this.mScaleType.ordinal()];
          /*  if (i != 1) {
                if (i == 2) {
                    f2 = Math.max(f2, f4);
                } else if (i == 3) {
                    f2 = Math.min(1.0f, Math.min(f2, f4));
                } else if (!(i == 4 || i == 5)) {
                    throw new UnsupportedOperationException("TouchImageView does not support FIT_START or FIT_END");
                }
                f4 = f2;
            } else {
                f2 = 1.0f;
                f4 = 1.0f;
            }*/
            f2 = Math.min(f2, f4);
            int i2 = this.viewWidth;
            float f5 = ((float) i2) - (f * f2);
            int i3 = this.viewHeight;
            float f6 = ((float) i3) - (f3 * f2);
            this.matchViewWidth = ((float) i2) - f5;
            this.matchViewHeight = ((float) i3) - f6;
            if (isZoomed() || this.imageRenderedAtLeastOnce) {
                if (this.prevMatchViewWidth == 0.0f || this.prevMatchViewHeight == 0.0f) {
                    savePreviousImageValues();
                }
                this.prevMatrix.getValues(this.f1662m);
                float[] fArr = this.f1662m;
                f5 = this.matchViewWidth / f;
                f = this.normalizedScale;
                fArr[0] = f5 * f;
                fArr[4] = (this.matchViewHeight / f3) * f;
                f3 = fArr[2];
                float f7 = fArr[5];
                translateMatrixAfterRotate(2, f3, this.prevMatchViewWidth * f, getImageWidth(), this.prevViewWidth, this.viewWidth, intrinsicWidth);
                translateMatrixAfterRotate(5, f7, this.prevMatchViewHeight * this.normalizedScale, getImageHeight(), this.prevViewHeight, this.viewHeight, intrinsicHeight);
                this.matrix.setValues(this.f1662m);
            } else {
                this.matrix.setScale(f2, f2);
                this.matrix.postTranslate(f5 / 2.0f, f6 / 2.0f);
                this.normalizedScale = 1.0f;
            }
            fixTrans();
            setImageMatrix(this.matrix);
        }
    }

    private int setViewSize(int i, int i2, int i3) {
        if (i != Integer.MIN_VALUE) {
            return i != 0 ? i2 : i3;
        } else {
            return Math.min(i3, i2);
        }
    }

    private void translateMatrixAfterRotate(int i, float f, float f2, float f3, int i2, int i3, int i4) {
        float f4 = (float) i3;
        if (f3 < f4) {
            float[] fArr = this.f1662m;
            fArr[i] = (f4 - (((float) i4) * fArr[0])) * 0.5f;
        } else if (f > 0.0f) {
            this.f1662m[i] = -((f3 - f4) * 0.5f);
        } else {
            this.f1662m[i] = -((((Math.abs(f) + (((float) i2) * 0.5f)) / f2) * f3) - (f4 * 0.5f));
        }
    }

    private void setState(State state) {
        this.state = state;
    }

    public boolean canScrollHorizontallyFroyo(int i) {
        return canScrollHorizontally(i);
    }

    public boolean canScrollHorizontally(int i) {
        this.matrix.getValues(this.f1662m);
        float f = this.f1662m[2];
        if (getImageWidth() < ((float) this.viewWidth)) {
            return false;
        }
        if (f >= -1.0f && i < 0) {
            return false;
        }
        if ((Math.abs(f) + ((float) this.viewWidth)) + 1.0f < getImageWidth() || i <= 0) {
            return true;
        }
        return false;
    }

    private void scaleImage(double d, float f, float f2, boolean z) {
        float f3;
        float f4;
        if (z) {
            f3 = this.superMinScale;
            f4 = this.superMaxScale;
        } else {
            f3 = this.minScale;
            f4 = this.maxScale;
        }
        float f5 = this.normalizedScale;
        double d2 = (double) f5;
        Double.isNaN(d2);
        float f6 = (float) (d2 * d);
        this.normalizedScale = f6;
        if (f6 > f4) {
            this.normalizedScale = f4;
            d = (double) (f4 / f5);
        } else if (f6 < f3) {
            this.normalizedScale = f3;
            d = (double) (f3 / f5);
        }
        float f7 = (float) d;
        this.matrix.postScale(f7, f7, f, f2);
        fixScaleTrans();
    }

    private PointF transformCoordTouchToBitmap(float f, float f2, boolean z) {
        this.matrix.getValues(this.f1662m);
        float intrinsicWidth = (float) getDrawable().getIntrinsicWidth();
        float intrinsicHeight = (float) getDrawable().getIntrinsicHeight();
        f = ((f - this.f1662m[2]) * intrinsicWidth) / getImageWidth();
        f2 = ((f2 - this.f1662m[5]) * intrinsicHeight) / getImageHeight();
        if (z) {
            f = Math.min(Math.max(f, 0.0f), intrinsicWidth);
            f2 = Math.min(Math.max(f2, 0.0f), intrinsicHeight);
        }
        return new PointF(f, f2);
    }

    private PointF transformCoordBitmapToTouch(float f, float f2) {
        this.matrix.getValues(this.f1662m);
        return new PointF(this.f1662m[2] + (getImageWidth() * (f / ((float) getDrawable().getIntrinsicWidth()))), this.f1662m[5] + (getImageHeight() * (f2 / ((float) getDrawable().getIntrinsicHeight()))));
    }

    private void compatPostOnAnimation(Runnable runnable) {
        if (VERSION.SDK_INT >= 16) {
            postOnAnimation(runnable);
        } else {
            postDelayed(runnable, 16);
        }
    }

    private void printMatrixInfo() {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scale: ");
        stringBuilder.append(fArr[0]);
        stringBuilder.append(" TransX: ");
        stringBuilder.append(fArr[2]);
        stringBuilder.append(" TransY: ");
        stringBuilder.append(fArr[5]);
        Log.d(DEBUG, stringBuilder.toString());
    }
}
