package com.name.nameart.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.MyUtils.MyPreference;
import com.name.nameart.R;
import com.name.nameart.sticker.StickerView;

import java.util.ArrayList;

public class GradientAdapter extends RecyclerView.Adapter<GradientAdapter.ViewHolder> {
    public static StickerView mCurrentView;
    ArrayList<String> arraygradintCenter;
    ArrayList<String> arraygradintOne;
    ArrayList<String> arraygradintTwo;
    public ArrayList<Integer> coloe_array;
    Context context;
    Typeface face;
    int index = -1;
    OnSelect onSelect;
    String status;

    public interface OnSelect {
        void onSelectgradient(String str, String str2, String str3);
    }

    public GradientAdapter(Context context2, String str, OnSelect onSelect2) {
        AssetManager assets = context2.getAssets();
        this.face = Typeface.createFromAsset(assets, "fonts/" + MyPreference.Companion.getAppPrefString(MyPreference.FONT_STYLE, "f14.otf"));
        this.onSelect = onSelect2;
        this.context = context2;
        this.status = str;
        this.arraygradintOne = new ArrayList<>();
        this.arraygradintTwo = new ArrayList<>();
        this.arraygradintCenter = new ArrayList<>();
        this.arraygradintOne.add("#D7A456");
        this.arraygradintOne.add("#e65245");
        this.arraygradintOne.add("#b29f94");
        this.arraygradintOne.add("#3A4750");
        this.arraygradintOne.add("#113A5D");
        this.arraygradintOne.add("#A0FE65");
        this.arraygradintOne.add("#52ACFF");
        this.arraygradintOne.add("#6284FF");
        this.arraygradintOne.add("#fc2f00");
        this.arraygradintOne.add("#ff499e");
        this.arraygradintOne.add("#133c55");
        this.arraygradintOne.add("#25ced1");
        this.arraygradintOne.add("#247ba0");
        this.arraygradintOne.add("#03071e");
        this.arraygradintOne.add("#7400b8");
        this.arraygradintOne.add("#00416A");
        this.arraygradintOne.add("#833ab4");
        this.arraygradintOne.add("#40E0D0");
        this.arraygradintOne.add("#FC354C");
        this.arraygradintOne.add("#FF4E50");
        this.arraygradintOne.add("#000000");
        this.arraygradintOne.add("#FFA69E");
        this.arraygradintOne.add("#5F0A87");
        this.arraygradintOne.add("#20BF55");
        this.arraygradintOne.add("#74F2CE");
        this.arraygradintOne.add("#A40606");
        this.arraygradintOne.add("#380036");
        this.arraygradintOne.add("#E58C8A");
        this.arraygradintOne.add("#80FF72");
        this.arraygradintOne.add("#7EE8FA");
        this.arraygradintOne.add("#EC9F05");
        this.arraygradintOne.add("#9FA4C4");
        this.arraygradintOne.add("#9E768F");
        this.arraygradintOne.add("#8693AB");
        this.arraygradintOne.add("#B279A7");
        this.arraygradintOne.add("#D387AB");
        this.arraygradintOne.add("#0D324D");
        this.arraygradintOne.add("#B91372");
        this.arraygradintOne.add("#F2A65A");
        this.arraygradintOne.add("#A7ACD9");
        this.arraygradintOne.add("#E7A977");
        this.arraygradintOne.add("#FF928B");
        this.arraygradintOne.add("#233329");
        this.arraygradintOne.add("#29524A");
        this.arraygradintOne.add("#FC575E");
        this.arraygradintOne.add("#F1A7F1");
        this.arraygradintOne.add("#FF8489");
        this.arraygradintOne.add("#F9D976");
        this.arraygradintOne.add("#00FFFF");
        this.arraygradintOne.add("#F53844");
        this.arraygradintOne.add("#19A186");
        this.arraygradintOne.add("#55D284");
        this.arraygradintOne.add("#1E9AFE");
        this.arraygradintTwo.add("#F0BE72");
        this.arraygradintTwo.add("#e43a15");
        this.arraygradintTwo.add("#603813");
        this.arraygradintTwo.add("#F6C90E");
        this.arraygradintTwo.add("#FF7A8A");
        this.arraygradintTwo.add("#FA016D");
        this.arraygradintTwo.add("#FFE32C");
        this.arraygradintTwo.add("#FF0000");
        this.arraygradintTwo.add("#054a29");
        this.arraygradintTwo.add("#49b6ff");
        this.arraygradintTwo.add("#91e5f6");
        this.arraygradintTwo.add("#ea526f");
        this.arraygradintTwo.add("#b2dbbf");
        this.arraygradintTwo.add("#ffba08");
        this.arraygradintTwo.add("#80ffdb");
        this.arraygradintTwo.add("#FFE000");
        this.arraygradintTwo.add("#fcb045");
        this.arraygradintTwo.add("#FF0080");
        this.arraygradintTwo.add("#0ABFBC");
        this.arraygradintTwo.add("#F9D423");
        this.arraygradintTwo.add("#e74c3c");
        this.arraygradintTwo.add("#861657");
        this.arraygradintTwo.add("#A4508B");
        this.arraygradintTwo.add("#01BAEF");
        this.arraygradintTwo.add("#7CFFCB");
        this.arraygradintTwo.add("#D98324");
        this.arraygradintTwo.add("#0CBABA");
        this.arraygradintTwo.add("#EEC0C6");
        this.arraygradintTwo.add("#7EE8FA");
        this.arraygradintTwo.add("#EEC0C6");
        this.arraygradintTwo.add("#FF4E00");
        this.arraygradintTwo.add("#B3CDD1");
        this.arraygradintTwo.add("#9FA4C4");
        this.arraygradintTwo.add("#BDD4E7");
        this.arraygradintTwo.add("#D387AB");
        this.arraygradintTwo.add("#E899DC");
        this.arraygradintTwo.add("#7F5A83");
        this.arraygradintTwo.add("#6B0F1A");
        this.arraygradintTwo.add("#772F1A");
        this.arraygradintTwo.add("#9E8FB2");
        this.arraygradintTwo.add("#EBBE9B");
        this.arraygradintTwo.add("#FFAC81");
        this.arraygradintTwo.add("#63D471");
        this.arraygradintTwo.add("#E9BCB7");
        this.arraygradintTwo.add("#90D5EC");
        this.arraygradintTwo.add("#FAD0C4");
        this.arraygradintTwo.add("#D5ADC8");
        this.arraygradintTwo.add("#F39F86");
        this.arraygradintTwo.add("#008000");
        this.arraygradintTwo.add("#42378F");
        this.arraygradintTwo.add("#F2CF43");
        this.arraygradintTwo.add("#F2CF07");
        this.arraygradintTwo.add("#60DFCD");
        this.arraygradintCenter.add("#AB661B");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("#ffffff");
        this.arraygradintCenter.add("#d264b6");
        this.arraygradintCenter.add("#386fa4");
        this.arraygradintCenter.add("#fceade");
        this.arraygradintCenter.add("#ff1654");
        this.arraygradintCenter.add("#dc2f02");
        this.arraygradintCenter.add("#48bfe3");
        this.arraygradintCenter.add("#799F0C");
        this.arraygradintCenter.add("#fd1d1d");
        this.arraygradintCenter.add("#FF8C00");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
        this.arraygradintCenter.add("");
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gradient_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        try {
            viewHolder.gradient_row_txt.setText(this.status);
            viewHolder.gradient_row_txt.setTypeface(this.face);
            if (!this.arraygradintCenter.get(i).equals("")) {
                viewHolder.gradient_row_txt.getPaint().setShader(new LinearGradient(0.0f, 0.0f, 0.0f, viewHolder.gradient_row_txt.getTextSize(), new int[]{Color.parseColor(this.arraygradintOne.get(i)), Color.parseColor(this.arraygradintCenter.get(i)), Color.parseColor(this.arraygradintTwo.get(i))}, (float[]) null, Shader.TileMode.CLAMP));
            } else {
                viewHolder.gradient_row_txt.getPaint().setShader(new LinearGradient(0.0f, 0.0f, 0.0f, viewHolder.gradient_row_txt.getTextSize(), Color.parseColor(this.arraygradintOne.get(i)), Color.parseColor(this.arraygradintTwo.get(i)), Shader.TileMode.CLAMP));
            }
        } catch (Exception e) {
            try {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
                return;
            }
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                GradientAdapter.this.index = i;
                GradientAdapter.this.onSelect.onSelectgradient(GradientAdapter.this.arraygradintOne.get(i), GradientAdapter.this.arraygradintTwo.get(i), GradientAdapter.this.arraygradintCenter.get(i));
                GradientAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.index == i) {
            viewHolder.row_grdnt.setBackgroundResource(R.drawable.bg_selected);
        } else {
            viewHolder.row_grdnt.setBackgroundColor(0);
        }
    }

    @Override
    public int getItemCount() {
        return this.arraygradintTwo.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView gradient_row_txt;
        public View parentLayout;
        public ConstraintLayout row_grdnt;

        public ViewHolder(View view) {
            super(view);
            this.gradient_row_txt = (TextView) view.findViewById(R.id.gradient_row_txt);
            this.row_grdnt = (ConstraintLayout) view.findViewById(R.id.row_grdnt);
        }
    }
}
