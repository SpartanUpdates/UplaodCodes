package com.vidsoft.uvideostatus.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnScrollListener;
import com.vidsoft.uvideostatus.Activity.Video_play_Activity;
import com.vidsoft.uvideostatus.Adapters.CatogoryAdapter;
import com.vidsoft.uvideostatus.Models.VideoData;
import com.vidsoft.uvideostatus.R;
import com.vidsoft.uvideostatus.Utility.Utility;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdsManager;
import com.google.android.exoplayer.text.ttml.TtmlNode;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.ResponseHandlerInterface;
import cz.msebera.android.httpclient.Header;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CatogoryFragment extends Fragment {
    RecyclerView album_recyclerview;
    String cateoryid;
    String catogory;
    int counterlimit = 0;
    public boolean isLastPage = false;
    CatogoryAdapter mAdapter;
    LinearLayoutManager mLayoutManager;
    public int totalCount = 1;
    private ArrayList<VideoData> videoData = new ArrayList<>();
    public NativeAdsManager mAdsManager;

    class dataCatogoryHandler extends AsyncHttpResponseHandler {
        public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
        }

        dataCatogoryHandler() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
            String str = "url";
            String str2 = new String(bArr);
            try {
                JSONArray jSONArray = new JSONArray(str2);
                Log.e("JArry", "" + jSONArray);
                StringBuilder sb = new StringBuilder();
                sb.append("getcatogoryvideo:catfirst ");
                sb.append(str2);
                Log.d("ContentValues", sb.toString());
                videoData = new ArrayList<>();
                try {
                    if (jSONArray.length() != 0) {
                        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                            Log.e("JArrylength", "" + jSONArray.length());
                            JSONObject jSONObject = jSONArray.getJSONObject(i2);
                            VideoData videoDataobj = new VideoData();
                            videoDataobj.setVideo_id(jSONObject.getLong(TtmlNode.ATTR_ID));
                            videoDataobj.setTitle(jSONObject.getString("title"));
                            videoDataobj.setUrl(jSONObject.getString(str));
                            videoDataobj.setReal_videopath(jSONObject.getString(str));
                            videoDataobj.setThumbnail(jSONObject.getString(TtmlNode.TAG_IMAGE));
                            videoDataobj.setCatagory(jSONObject.getString("cname"));
                            videoDataobj.setViews(jSONObject.getString("downloads"));
//                            videoData.add(videoDataobj);

                            if ((videoData.size() + 1) %3 == 0) {
                                videoDataobj.IsNativeAds = true;
                                videoData.add(videoDataobj);
                                Log.e("DataAdd",""+videoData);
                            } else {
                                videoData.add(videoDataobj);
                            }
                        }
                        SetAdapter();
                        CatogoryFragment.this.totalCount = CatogoryFragment.this.totalCount + 1;
                        if (CatogoryFragment.this.videoData.size() < 20) {
                            CatogoryFragment.this.isLastPage = true;
                        } else {
                            CatogoryFragment.this.isLastPage = false;
                        }
                    } else {
                        CatogoryFragment.this.isLastPage = true;
                    }
                    CatogoryFragment.this.mAdapter.setLoaded();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } catch (Exception unused) {
            }
        }
    }

    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.trending_fragment, viewGroup, false);
        if (getArguments() != null) {
            this.cateoryid = getArguments().getString(TtmlNode.ATTR_ID);
            this.catogory = getArguments().getString("catogory");
            Log.e("Categoryid", "" + cateoryid);
        }
        initViews(inflate);
        initNativeAds();
        return inflate;
    }

    private void initViews(View view) {
        this.album_recyclerview = (RecyclerView) view.findViewById(R.id.album_recyclerview);
        this.album_recyclerview.addOnScrollListener(new OnScrollListener() {
            public void onScrollStateChanged(RecyclerView recyclerView, int i) {
                super.onScrollStateChanged(recyclerView, i);
            }

            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (i2 > 0) {
                    if (CatogoryFragment.this.mLayoutManager.getChildCount() + CatogoryFragment.this.mLayoutManager.findFirstVisibleItemPosition() >= CatogoryFragment.this.mLayoutManager.getItemCount() && !CatogoryFragment.this.isLastPage) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("");
                        sb.append(CatogoryFragment.this.counterlimit);
                        Log.e("=>>>>>", sb.toString());
                        CatogoryFragment catogoryFragment = CatogoryFragment.this;
                        catogoryFragment.getcatogoryvideo(catogoryFragment.counterlimit);
                    }
                }
            }
        });
        getcatogoryvideo(this.counterlimit);
    }

    public void SetAdapter() {
        this.mLayoutManager = new LinearLayoutManager(getActivity());
        this.album_recyclerview.setLayoutManager(this.mLayoutManager);
        this.album_recyclerview.setItemAnimator(new DefaultItemAnimator());
        this.album_recyclerview.addItemDecoration(new DividerItemDecoration(getActivity(), 0));
        this.mAdapter = new CatogoryAdapter(getActivity(), this.videoData, this, this.album_recyclerview);
        this.album_recyclerview.setAdapter(this.mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    public void initNativeAds() {
        mAdsManager = new NativeAdsManager(getActivity(), getResources().getString(R.string.fb_native), 5);
        mAdsManager.loadAds();
        mAdsManager.setListener(new NativeAdsManager.Listener() {
            @Override
            public void onAdsLoaded() {
                Log.e("FBAds", "Native Ad Load");
                Log.e("title",""+mAdsManager.nextNativeAd().getAdHeadline());
                Log.e("BodyText",""+mAdsManager.nextNativeAd().getAdBodyText());
            }

            @Override
            public void onAdError(AdError adError) {
                Log.e("FBAds", "Native Ad Not Load : " + adError.getErrorMessage());

            }
        });
    }

    public void getcatogoryvideo(int i) {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        try {
            jSONObject.put("cid", this.cateoryid);
            jSONObject2.put("_id", -1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestParams requestParams = new RequestParams();
        requestParams.put("q", jSONObject.toString());
        Log.e("CatIdQ", "" + jSONObject.toString());
        requestParams.put("sk", i);
        Log.e("CatSK", "" + i);
        requestParams.put("l", 20);
        requestParams.put("s", jSONObject2.toString());
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.setTimeout(60000);
        StringBuilder sb = new StringBuilder();
        sb.append(Utility.baseUrl);
        sb.append("collections/tbl_video?apiKey=");
        sb.append(Utility.apiKey);
        asyncHttpClient.get(sb.toString(), requestParams, (ResponseHandlerInterface) new dataCatogoryHandler());
        this.counterlimit += 3;
    }

    public void playVideo(VideoData videoData2) {
        Intent intent = new Intent(getActivity(), Video_play_Activity.class);
        intent.putExtra("VIDEO_PATH", videoData2.getReal_videopath());
        intent.putExtra("cid", this.cateoryid);
        intent.putExtra("list", videoData2);
        StringBuilder sb = new StringBuilder();
        sb.append("playVideo: ");
        sb.append(videoData2.getReal_videopath());
        sb.append(" ");
        sb.append(videoData2.getTitle());
        Log.d("TAG", sb.toString());
        startActivity(intent);
    }
}
