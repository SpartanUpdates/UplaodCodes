package com.esc.dailyrandomfacts.reminders;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Build.VERSION;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import com.esc.dailyrandomfacts.managers.RemindersManager;
import com.esc.dailyrandomfacts.model.Pref;
import com.esc.dailyrandomfacts.receivers.AlarmReceiver;
import com.esc.dailyrandomfacts.util.Constants;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class RemindersUtils {
    public static final String DEFAULT_END_HOUR = "22:00";
    public static final String DEFAULT_START_HOUR = "09:00";
    public static final int REMINDERS_CONFIGURED_CHECK = 35;
    public static final int REMINDERS_CONFIGURED_MAX = 45;
    public static final String REMINDERS_DEFAULT = "10";
    public static final int REMINDERS_MAX = 30;
    public static final int REMINDERS_MAX_FREE = 30;
    public static ArrayList<AlarmManager> alarmsManager = new ArrayList();
    public static ArrayList<PendingIntent> pendingIntents = new ArrayList();
    public static int remindersConfigured = 0;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @SuppressLint("WrongConstant")
    public static void setAlarmOnTime(Context context) {
        Context context2 = context;
        cancelAlarms(context);
        remindersConfigured = 0;
        RemindersManager.resetRemindersLaunched();
        int i = 1;
        context.getPackageManager().setComponentEnabledSetting(new ComponentName(context2, AlarmReceiver.class), 1, 1);
        int parseInt = Integer.parseInt(Pref.getValue(context2, Constants.PREF_REPEAT_RATIO, REMINDERS_DEFAULT));
        String str = Constants.NOTIFICATION_START_TIME;
        String str2 = DEFAULT_START_HOUR;
        String str3 = ":";
        int parseInt2 = Integer.parseInt(Pref.getValue(context2, str, str2).split(str3)[0]);
        int parseInt3 = Integer.parseInt(Pref.getValue(context2, Constants.NOTIFICATION_START_TIME, str2).split(str3)[1]);
        Calendar instance = Calendar.getInstance();
        instance.set(11, parseInt2);
        instance.set(12, parseInt3);
        instance.set(13, 0);
        long timeInMillis = instance.getTimeInMillis();
        String str4 = Constants.NOTIFICATION_END_TIME;
        String str5 = DEFAULT_END_HOUR;
        int parseInt4 = Integer.parseInt(Pref.getValue(context2, str4, str5).split(str3)[0]);
        int parseInt5 = Integer.parseInt(Pref.getValue(context2, Constants.NOTIFICATION_END_TIME, str5).split(str3)[1]);
        Calendar instance2 = Calendar.getInstance();
        instance2.set(11, parseInt4);
        instance2.set(12, parseInt5);
        instance2.set(13, 0);
        long timeInMillis2 = (instance2.getTimeInMillis() - timeInMillis) / ((long) parseInt);
        parseInt2 = 0;
        while (true) {
            int i2 = 45;
            if (parseInt2 < 45) {
                if (parseInt2 != 0) {
                    instance.add(5, i);
                }
                timeInMillis = instance.getTimeInMillis();
                parseInt4 = 0;
                while (parseInt4 < parseInt) {
                    long j = (((long) parseInt4) * timeInMillis2) + timeInMillis;
                    if (j > Calendar.getInstance().getTimeInMillis()) {
                        int i3 = remindersConfigured + i;
                        remindersConfigured = i3;
                        if (i3 <= i2) {
                            AlarmManager alarmManager = (AlarmManager) context2.getSystemService(NotificationCompat.CATEGORY_ALARM);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(parseInt2);
                            stringBuilder.append("");
                            stringBuilder.append(parseInt4);
                            PendingIntent broadcast = PendingIntent.getBroadcast(context2, Integer.parseInt(stringBuilder.toString()), new Intent(context2, AlarmReceiver.class), 134217728);
                            if (VERSION.SDK_INT >= 23) {
                                alarmManager.setExactAndAllowWhileIdle(0, j, broadcast);
                            } else {
                                alarmManager.setExact(0, j, broadcast);
                            }
                            alarmsManager.add(alarmManager);
                            pendingIntents.add(broadcast);
                        } else {
                            return;
                        }
                    }
                    parseInt4++;
                    i = 1;
                    i2 = 45;
                }
                parseInt2++;
                i = 1;
            } else {
                return;
            }
        }
    }

    @SuppressLint("WrongConstant")
    public static void cancelAlarms(Context context) {
        context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, AlarmReceiver.class), 2, 1);
        Iterator it = alarmsManager.iterator();
        while (it.hasNext()) {
            AlarmManager alarmManager = (AlarmManager) it.next();
            PendingIntent pendingIntent = (PendingIntent) pendingIntents.get(alarmsManager.indexOf(alarmManager));
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
        alarmsManager = new ArrayList();
        pendingIntents = new ArrayList();
    }

    private static String printDate(long j) {
        return new SimpleDateFormat("dd HH:mm").format(new Date(j));
    }
}
