package com.kotlinz.festivalstorymaker.sticker;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.view.MotionEvent;

public class h implements f {
    @Override
    public void a(final StickerView stickerView, final MotionEvent motionEvent) {
        if (stickerView.getOnStickerOperationListener() != null) {
            stickerView.getOnStickerOperationListener().a(stickerView.getCurrentSticker());
        }
    }

    @Override
    public void b(final StickerView stickerView, final MotionEvent motionEvent) {
        if (stickerView.B != null) {
            final PointF t = stickerView.t;
            final float b = stickerView.b(t.x, t.y, motionEvent.getX(), motionEvent.getY());
            final PointF t2 = stickerView.t;
            final float d = stickerView.d(t2.x, t2.y, motionEvent.getX(), motionEvent.getY());
            stickerView.n.set(stickerView.m);
            final Matrix n = stickerView.n;
            final float n2 = b / stickerView.y;
            final PointF t3 = stickerView.t;
            n.postScale(n2, n2, t3.x, t3.y);
            final Matrix n3 = stickerView.n;
            final float z = stickerView.z;
            final PointF t4 = stickerView.t;
            n3.postRotate(d - z, t4.x, t4.y);
            stickerView.B.g.set(stickerView.n);
        }
    }

    @Override
    public void c(final StickerView stickerView, final MotionEvent motionEvent) {
    }
}
