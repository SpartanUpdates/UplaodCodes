package com.esc.storymaker;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.ItemTouchHelper.Callback;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.models.Draft;
import com.esc.storymaker.utils.AppUtil;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import java.io.File;

public class PreviewActivity extends AppCompatActivity {

    public static final String mypreference = "myprefadmob";
    private ImageView ImageOverlayadview;
    AppCompatActivity activity;
    ConnectionDetector connectionDetector;
    @BindView(R.id.cv_wrapper)
    CardView cvWrapper;
    int displayad;
    private Draft draft;
    @BindView(R.id.iv_saved)
    ImageView imageSaved;
    private File imgFile;
    private Uri imgUri;
    private Intent intent;
    boolean isActivityLeft;
    private boolean isFromCreation;
    private long mLastClickTime = System.currentTimeMillis();
    SharedPreferences sharedpreferences;
    @BindView(R.id.tv_dimension)
    TextView tvDimension;
    @BindView(R.id.tv_path)
    TextView tvPath;
    @BindView(R.id.tv_size)
    TextView tvSize;
    int whichActivitytoStart = 0;
    int whichAdFirst;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private void init() {

    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_preview);
        ButterKnife.bind(this);
        this.sharedpreferences = getSharedPreferences("myprefadmob", 0);
        this.isActivityLeft = false;
        this.activity = this;
        this.connectionDetector = new ConnectionDetector(getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.ImageOverlayadview = findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
            }
        });
        BannerAds();
        if (isConnectingToInternet) {
        } else {
            findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        init();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void isClickable() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.mLastClickTime >= 3000) {
            this.mLastClickTime = currentTimeMillis;
        }
    }

    @OnClick({R.id.tb_edit})
    public void onEditClick() {
        isClickable();
        if (this.imgFile.delete()) {
            sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(this.imgFile)));
        }
        AppUtil.removeDraft(this.draft);
        this.isFromCreation = true;
        onBackPressed();
    }

    @OnClick({R.id.tb_close})
    public void onCloseClick() {
        isClickable();
        onBackPressed();
    }

    @OnClick({R.id.tb_home})
    public void onHomeClick() {
        this.whichActivitytoStart = 1;
    }

    @OnClick({R.id.tb_trash})
    public void onTrashClick() {
        isClickable();
        final Dialog dialog = new Dialog(this);
        View inflate = LayoutInflater.from(this).inflate(R.layout.wg_delete_alert_dialog, null);
        AppUtil.showBottomDialog(this, dialog, inflate, true);
        inflate.findViewById(R.id.btn_negative).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btn_positive).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (PreviewActivity.this.imgFile.delete()) {
                    PreviewActivity previewActivity = PreviewActivity.this;
                    previewActivity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(previewActivity.imgFile)));
                }
                PreviewActivity.this.onBackPressed();
            }
        });
    }

    public void onBackPressed() {
        if (this.isFromCreation) {
            overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
            finish();
            return;
        }
        final Dialog dialog = new Dialog(this);
        View inflate = LayoutInflater.from(this).inflate(R.layout.wg_bottom_alert_dialog, null);
        AppUtil.showBottomDialog(this, dialog, inflate, true);
        inflate.findViewById(R.id.btn_neutral).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        inflate.findViewById(R.id.btn_negative).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                PreviewActivity.this.onHomeClick();
            }
        });
        TextView textView = inflate.findViewById(R.id.btn_positive);
        textView.setText(getString(R.string.BTN_EDIT));
        textView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
                PreviewActivity.this.onEditClick();
            }
        });
    }

    @OnClick({R.id.fab_instagram})
    public void onInstagramClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.instagram.android", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_snapchat})
    public void onSnapchatClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.snapchat.android", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_facebook})
    public void onFacebookClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.facebook.katana", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_messenger})
    public void onMessengerClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.facebook.orca", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_whatsapp})
    public void onWhatsappClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.whatsapp", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_pinterest})
    public void onPinterestClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.pinterest", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_pinterest})
    public void onGmailClick() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by ");
        stringBuilder.append(getString(R.string.app_name));
        stringBuilder.append(" ");
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.shareIntent(this, "com.google.android.gm", stringBuilder.toString(), this.imgUri);
    }

    @OnClick({R.id.fab_other})
    public void onOtherClick() {
        this.intent = new Intent();
        this.intent.setAction("android.intent.action.SEND");
        this.intent.putExtra("android.intent.extra.STREAM", this.imgUri);
        Intent intent = this.intent;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Create by https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        this.intent.setType("image/jpeg");
        startActivity(Intent.createChooser(this.intent, getResources().getText(R.string.APD_SEND_TO)));
    }

    @OnClick({R.id.tv_rateus})
    public void onRateClick() {
        Context applicationContext = getApplicationContext();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("https://play.google.com/store/apps/details?id=");
        stringBuilder.append(getPackageName());
        AppUtil.openUrl(applicationContext, stringBuilder.toString());
    }

    @OnClick({R.id.tv_setas})
    public void onSetAsClick() {
        this.intent = new Intent("android.intent.action.ATTACH_DATA");
        this.intent.addCategory("android.intent.category.DEFAULT");
        String str = "image/*";
        this.intent.setDataAndType(this.imgUri, str);
        this.intent.putExtra("mimeType", str);
        startActivityForResult(Intent.createChooser(this.intent, "Set As"), Callback.DEFAULT_DRAG_ANIMATION_DURATION);
    }



    public void onPause() {
        super.onPause();
        this.isActivityLeft = true;
    }

    public void onResume() {
        super.onResume();
        this.isActivityLeft = false;
    }


    public void onStop() {
        super.onStop();
        this.isActivityLeft = true;
    }


    public void onDestroy() {
        super.onDestroy();
        this.isActivityLeft = true;
    }

    private void replaceScreen() {
        if (this.whichActivitytoStart == 1) {
            isClickable();
            this.intent = new Intent(this, MainActivity.class);
            startActivity(this.intent);
            overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
            finish();
        }
    }
}
