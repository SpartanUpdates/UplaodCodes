package com.MV.Lyrics.Retrofit;

public class AppConstant {
    public static String BASEURL = "http://lyricaladmin.trendinganimations.com/public/api/";

    public static String BASEURL_PARTICAL = "http://uvadmin.trendinganimations.com/public/api/";
    public static String ApplicationIdParticle = "61";

    public static String Token = "aciativtyksdfhal5215ajal";
    public static String ApplicationId = "7";
    public static String DataFilePath = "https://lyricaladmin.s3.ap-south-1.amazonaws.com/video_data/";
    public static String VideoThumbPath = "https://lyricaladmin.s3.ap-south-1.amazonaws.com/video_thumb/";

    public static String AssetPath = "https://raw.githubusercontent.com/SpartanUpdates/UplaodCodes/master/asset_bundle.json";

    public static String[] split_AllLan= ("28,36,35,34,33,32,31,37").split(",");


    public static  String AspectRatioUnity;
    public  static  String ImagePath;
    public static  String IsNew;
}
