package com.vidsoft.collagemaker.Utils.Stickers;

import android.view.MotionEvent;

public class EclairMotionEvent extends WrapMotionEvent {
	protected EclairMotionEvent(final MotionEvent motionEvent) {
		super(motionEvent);
	}

	@Override
	public int getPointerCount() {
		return this.event.getPointerCount();
	}

	@Override
	public int getPointerId(final int n) {
		return this.event.getPointerId(n);
	}

	@Override
	public float getX(final int n) {
		return this.event.getX(n);
	}

	@Override
	public float getY(final int n) {
		return this.event.getY(n);
	}
}
