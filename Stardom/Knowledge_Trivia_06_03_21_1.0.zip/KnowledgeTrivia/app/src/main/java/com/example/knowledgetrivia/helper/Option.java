package com.example.knowledgetrivia.helper;

public enum Option {
    A,
    B,
    C,
    D,
    Z
}
