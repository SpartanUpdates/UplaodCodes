package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import com.esc.gesturelockscreen.Other.Constant;
import com.esc.gesturelockscreen.Other.PrefUtils;
import com.esc.gesturelockscreen.Other.StaticBitmapUtils;
import com.esc.gesturelockscreen.R;
import androidx.appcompat.app.AppCompatActivity;

public class SlideLockWithFrameSetActivity extends AppCompatActivity implements OnClickListener {
    private Bitmap bitmapOriginal;
    private int blurRadius = 0;
    private ImageView btnDone;
    private DisplayMetrics displayMetrics;
    private int height;
    private ImageView imageViewBackground;
    private Activity mContext;
    private int width;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_slide_lock_with_frame_set);
        this.mContext = this;
        findID();
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        this.displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(this.displayMetrics);
        this.height = this.displayMetrics.heightPixels;
        this.width = this.displayMetrics.widthPixels;
        getPreference();
    }

    private void findID() {
        this.imageViewBackground = (ImageView) findViewById(R.id.imageview_Background);
        this.btnDone = (ImageView) findViewById(R.id.btn_Done);
        this.btnDone.setOnClickListener(this);
    }

    private void getPreference() {
        boolean booleanPref = PrefUtils.getBooleanPref(getApplicationContext(), PrefUtils.PRF_IS_SET_GALLERY, false);
        boolean booleanPref2 = PrefUtils.getBooleanPref(getApplicationContext(), PrefUtils.PRF_IS_SET_BACKGROUND, false);
        Options options = new Options();
        options.inSampleSize = 8;
        if (booleanPref) {
            this.bitmapOriginal = StaticBitmapUtils.decodeFileFromUriToBitmap(Uri.parse(PrefUtils.getStringPref(getApplicationContext(), PrefUtils.PRF_SELECTED_GALLERY_IMG_URI, "")));
            this.imageViewBackground.setImageBitmap(this.bitmapOriginal);
        } else if (booleanPref2) {
            int intPref = PrefUtils.getIntPref(getApplicationContext(), PrefUtils.PRF_BACKGROUND_IMG_POSITION, 0);
            this.bitmapOriginal = BitmapFactory.decodeResource(getResources(), Constant.arrBG[intPref].intValue(), options);
            this.imageViewBackground.setBackgroundResource(Constant.arrBG[intPref].intValue());
        } else {
            this.bitmapOriginal = BitmapFactory.decodeResource(getResources(), R.drawable.music_bg1, options);
            this.imageViewBackground.setImageBitmap(this.bitmapOriginal);
        }
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_Done) {
            PrefUtils.setBooleanPref(getApplicationContext(), PrefUtils.PRF_IS_SET_LOCK, true);
            PrefUtils.setIntPref(getApplicationContext(), PrefUtils.PRF_SET_FRAME_BLUR_RADIUS, this.blurRadius);
            startActivity(new Intent(getApplicationContext(), SetWallpaperActivity.class));
            finish();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
