﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSwap : MonoBehaviour
{
    public int targetWay;
    public WayPoints wayPoints;
    public GameObject leftObject, rightObject;
    void Start()
    {
        leftObject.SetActive(false);
        rightObject.SetActive(false);
        if (wayPoints.finalWayValue[targetWay] == 0)
        {
            leftObject.SetActive(false);
            rightObject.SetActive(true);
        }
        else if(wayPoints.finalWayValue[targetWay] == 1)
        {
            leftObject.SetActive(true);
            rightObject.SetActive(false);
        }
       
    }

    void OnTriggerEnter(Collider target)
    {
        if (target.CompareTag("Enemy"))
        {
            this.GetComponent<BoxCollider>().enabled = false;
            leftObject.GetComponent<Animator>().enabled = true;
            rightObject.GetComponent<Animator>().enabled = true;
        }
    }
}
