package com.vidsoft.Filters.AllStickerSupports;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Canvas;
import android.graphics.EmbossMaskFilter;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;

import com.vidsoft.collagemaker.pipphotoeffect.R;

public class TextSticker extends Sticker {
    private static final String mEllipsis = "\u2026";
    private Alignment mAlignment;
    private Context mContext;
    private Drawable mDrawable;
    private float mLineSpacingExtra;
    private float mLineSpacingMultiplier;
    private float mMaxTextSizePixels;
    private float mMinTextSizePixels;
    private Rect mRealBounds;
    private StaticLayout mStaticLayout;
    private String mText;
    private TextPaint mTextPaint;
    private Rect mTextRect;

    public TextSticker(Context context) {
        this(context, null);
    }

    public TextSticker(Context context, Drawable drawable) {
        this.mLineSpacingMultiplier = 1.0f;
        this.mLineSpacingExtra = 0.0f;
        this.mContext = context;
        this.mDrawable = drawable;
        if (drawable == null) {
            this.mDrawable = ContextCompat.getDrawable(context, R.drawable.transparent_background);
        }
        this.matrix = new Matrix();
        this.mTextPaint = new TextPaint(1);
        this.mRealBounds = new Rect(0, 0, getWidth(), getHeight());
        this.mTextRect = new Rect(0, 0, getWidth(), getHeight());
        this.mMinTextSizePixels = convertSpToPx(50.0f);
        this.mMaxTextSizePixels = convertSpToPx(100.0f);
        this.mAlignment = Alignment.ALIGN_CENTER;
        this.mTextPaint.setTextSize(this.mMaxTextSizePixels);
    }

    public void draw(Canvas canvas) {
        canvas.save();
        canvas.concat(this.matrix);
        if (this.mDrawable != null) {
            this.mDrawable.setBounds(this.mRealBounds);
            this.mDrawable.draw(canvas);
        }
        canvas.restore();
        canvas.save();
        canvas.concat(this.matrix);
        if (this.mTextRect.width() == getWidth()) {
            canvas.translate(0.0f, (float) ((getHeight() / 2) - (this.mStaticLayout.getHeight() / 2)));
        } else {
            canvas.translate((float) this.mTextRect.left, (float) ((this.mTextRect.top + (this.mTextRect.height() / 2)) - (this.mStaticLayout.getHeight() / 2)));
        }
        this.mStaticLayout.draw(canvas);
        canvas.restore();
    }

    public int getWidth() {
        return this.mDrawable.getIntrinsicWidth();
    }

    public int getHeight() {
        return this.mDrawable.getIntrinsicHeight();
    }

    public void release() {
        super.release();
        if (this.mDrawable != null) {
            this.mDrawable = null;
        }
    }

    public Drawable getDrawable() {
        return this.mDrawable;
    }

    public void setDrawable(Drawable drawable) {
        this.mDrawable = drawable;
        this.mRealBounds.set(0, 0, getWidth(), getHeight());
        this.mTextRect.set(0, 0, getWidth(), getHeight());
    }

    public void setDrawable(Drawable drawable, Rect region) {
        this.mDrawable = drawable;
        this.mRealBounds.set(0, 0, getWidth(), getHeight());
        if (region == null) {
            this.mTextRect.set(0, 0, getWidth(), getHeight());
        } else {
            this.mTextRect.set(region.left, region.top, region.right, region.bottom);
        }
    }

    public void setTypeface(Typeface typeface) {
        this.mTextPaint.setTypeface(typeface);
    }

    public void setTextColor(int color) {
        this.mTextPaint.setShader(null);
        this.mTextPaint.setColor(color);
    }

    public void applyFilter(Blur blur, int val) {
        BlurMaskFilter blurMaskFilter = new BlurMaskFilter((float) val, blur);
        this.mTextPaint.clearShadowLayer();
        this.mTextPaint.setMaskFilter(blurMaskFilter);
    }

    public void setShader(Context mContext, Bitmap bitmap) {
        this.mTextPaint.setShader(new BitmapShader(bitmap, TileMode.REPEAT, TileMode.REPEAT));
    }

    public void debossEffect() {
        EmbossMaskFilter debossFilter = new EmbossMaskFilter(new float[]{0.0f, -1.0f, 0.5f}, 0.8f, 13.0f, 7.0f);
        this.mTextPaint.clearShadowLayer();
        this.mTextPaint.setMaskFilter(debossFilter);
    }

    public void originalEffect() {
        this.mTextPaint.setMaskFilter(null);
    }

    public void embossEffect() {
        EmbossMaskFilter embossFilter = new EmbossMaskFilter(new float[]{1.0f, 5.0f, 1.0f}, 0.8f, 8.0f, 7.0f);
        this.mTextPaint.clearShadowLayer();
        this.mTextPaint.setMaskFilter(embossFilter);
    }

    public void setTextShadowColor(int radius, int color) {
        this.mTextPaint.setShadowLayer((float) radius, 2.0f, 2.0f, color);
    }

    public void setTextAlign(Alignment alignment) {
        this.mAlignment = alignment;
    }

    public void setMaxTextSize(float size) {
        setMaxTextSize(2, size);
    }

    public void setMaxTextSize(int unit, float size) {
        this.mTextPaint.setTextSize(convertSpToPx(size));
        this.mMaxTextSizePixels = this.mTextPaint.getTextSize();
    }

    public void setMinTextSize(float minTextSizeScaledPixels) {
        this.mMinTextSizePixels = convertSpToPx(minTextSizeScaledPixels);
    }

    public void setLineSpacing(float add, float multiplier) {
        this.mLineSpacingMultiplier = multiplier;
        this.mLineSpacingExtra = add;
    }

    public void setText(String text) {
        this.mText = text;
    }

    public String getText() {
        return this.mText;
    }

    public float getTextSize() {
        return this.mTextPaint.getTextSize();
    }

    public void resizeText() {
        int availableHeightPixels = this.mTextRect.height();
        int availableWidthPixels = this.mTextRect.width();
        CharSequence text = getText();
        if (text != null && text.length() > 0 && availableHeightPixels > 0 && availableWidthPixels > 0 && this.mMaxTextSizePixels > 0.0f) {
            float targetTextSizePixels = this.mMaxTextSizePixels;
            int targetTextHeightPixels = getTextHeightPixels(text, availableWidthPixels, targetTextSizePixels);
            while (targetTextHeightPixels > availableHeightPixels && targetTextSizePixels > this.mMinTextSizePixels) {
                targetTextSizePixels = Math.max(targetTextSizePixels - 2.0f, this.mMinTextSizePixels);
                targetTextHeightPixels = getTextHeightPixels(text, availableWidthPixels, targetTextSizePixels);
            }
            if (targetTextSizePixels == this.mMinTextSizePixels && targetTextHeightPixels > availableHeightPixels) {
                TextPaint textPaintCopy = new TextPaint(this.mTextPaint);
                textPaintCopy.setTextSize(targetTextSizePixels);
                StaticLayout staticLayout = new StaticLayout(text, textPaintCopy, availableWidthPixels, Alignment.ALIGN_NORMAL, this.mLineSpacingMultiplier, this.mLineSpacingExtra, false);
                if (staticLayout.getLineCount() > 0) {
                    int lastLine = staticLayout.getLineForVertical(availableHeightPixels) - 1;
                    if (lastLine >= 0) {
                        int startOffset = staticLayout.getLineStart(lastLine);
                        int endOffset = staticLayout.getLineEnd(lastLine);
                        float lineWidthPixels = staticLayout.getLineWidth(lastLine);
                        float ellipseWidth = textPaintCopy.measureText(mEllipsis);
                        while (((float) availableWidthPixels) < lineWidthPixels + ellipseWidth) {
                            endOffset--;
                            lineWidthPixels = textPaintCopy.measureText(text.subSequence(startOffset, endOffset + 1).toString());
                        }
                        setText(text.subSequence(0, endOffset) + mEllipsis);
                    }
                }
            }
            this.mTextPaint.setTextSize(targetTextSizePixels);
            this.mStaticLayout = new StaticLayout(this.mText, this.mTextPaint, this.mTextRect.width(), this.mAlignment, this.mLineSpacingMultiplier, this.mLineSpacingExtra, true);
        }
    }

    public float getMinTextSizePixels() {
        return this.mMinTextSizePixels;
    }

    public int getTextHeightPixels(CharSequence source, int availableWidthPixels, float textSizePixels) {
        this.mTextPaint.setTextSize(textSizePixels);
        return new StaticLayout(source, this.mTextPaint, availableWidthPixels, Alignment.ALIGN_NORMAL, this.mLineSpacingMultiplier, this.mLineSpacingExtra, true).getHeight();
    }

    private float convertSpToPx(float scaledPixels) {
        return this.mContext.getResources().getDisplayMetrics().scaledDensity * scaledPixels;
    }
}
