package game.kidspop.gk.quiz.info;

import android.app.Application;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {
    private static MyApplication instance;
    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        AdSettings.addTestDevice("2f2dd121-230c-41d1-b4df-4942b0746e44");
        AudienceNetworkAds.initialize(this);
    }
}
