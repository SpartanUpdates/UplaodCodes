package com.esc.phoneheart.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.esc.phoneheart.model.DownloadsData;
import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;
import com.esc.phoneheart.wrappers.DownloadWrapper;
import java.io.File;
import java.util.Arrays;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

public class FilesDownloadAdapter extends Adapter<FilesDownloadAdapter.MyViewHolder> {
    public String TAG = FilesDownloadAdapter.class.getSimpleName();
    public List arrExtensionAudio = Arrays.asList(new String[]{"mp3", "mpa", "aac", "oga"});
    public List arrExtensionImage = Arrays.asList(new String[]{"jpeg", "jpg", "JPEG", "JPG", "png", "gif", "tiff", "tif", "bmp", "svg", "webp"});
    public List arrExtensionVideo = Arrays.asList(new String[]{"mp4", "3gp", "avi", "mpeg", "webm", "flv", "wmv", "mkv", "m4a", "wav", "wma", "mmf", "mp2", "flac", "au", "ac3", "mpg", "mov", "mpv", "mpe", "ogg"});
    public final Button btn;
    public final Context context;
    public DownloadsData downloadsData;
    public List textFileExtensions = Arrays.asList(new String[]{"pdf", "doc", "docx", "xls", "ppt", "odt", "rtf", "txt", "pptx", "htm", "html", "log", "csv", "dot", "dotx", "docm", "dotm", "xml", "mht", "dic", "xlsx", NotificationCompat.CATEGORY_MESSAGE, "mhtml", "pps", "xltx", "xlt", "xlsm", "xltm", "ppsx", "pptm", "ppsm"});

    public class MyViewHolder extends ViewHolder {
        public CheckBox cBox;
        public LinearLayout checkBoxLout;
        public ImageView imgIcon;
        public TextView size;
        public TextView title;

        public MyViewHolder(FilesDownloadAdapter filesDownloadAdapter, View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.tvdownload_app_name);
            this.size = (TextView) view.findViewById(R.id.tvdownload_app_size);
            this.imgIcon = (ImageView) view.findViewById(R.id.img_fileicon);
            this.checkBoxLout = (LinearLayout) view.findViewById(R.id.check_down_layout);
            this.cBox = (CheckBox) view.findViewById(R.id.check_download);
        }
    }

    public FilesDownloadAdapter(Context context, Button button) {
        this.btn = button;
        this.context = context;
        this.downloadsData = PhoneCleaner.getInstance().downloadsData;
    }

    private Drawable getADrawable(int i) {
        if (VERSION.SDK_INT >= 21) {
            return this.context.getResources().getDrawable(i, this.context.getTheme());
        }
        return this.context.getResources().getDrawable(i);
    }

    private void getDrawableResource(DownloadWrapper downloadWrapper, ImageView imageView) {
        String str = downloadWrapper.ext;
        if (str.equalsIgnoreCase("zip")) {
            imageView.setImageDrawable(getADrawable(R.drawable.ic_apk));
        } else if (str.equalsIgnoreCase("apk")) {
            imageView.setImageDrawable(getADrawable(R.drawable.ic_apk_unpress));
        } else if (this.arrExtensionImage.contains(str)) {

            Glide.with(this.context)
                    .load(downloadWrapper.path)
                    .placeholder(R.mipmap.ic_launcher)
                    .error(R.mipmap.ic_launcher)
                    .override(50, 50)
                    .into(imageView);
        } else if (this.arrExtensionAudio.contains(str)) {
            imageView.setImageDrawable(getADrawable(R.drawable.ic_audio_unpress));
        } else if (this.arrExtensionVideo.contains(str)) {
            Glide.with(this.context)
                    .load(downloadWrapper.path)
                    .placeholder(R.mipmap.ic_launcher)
                    .error(R.mipmap.ic_launcher)
                    .override(50, 50)
                    .centerCrop()
                    .into(imageView);
        } else if (this.textFileExtensions.contains(str)) {
            imageView.setImageDrawable(getADrawable(R.drawable.ic_documents_unpress));
        } else {
            imageView.setImageDrawable(getADrawable(R.drawable.ic_documents_unpress));
        }
    }

    @SuppressLint("WrongConstant")
    private void openDownloadFile(Context context, File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(335544320);
        intent.addFlags(1);
        Uri uriForFile = FileProvider.getUriForFile(context, "com.esc.phoneheart.provider", file);
        String mimeType = Util.getMimeType(file.getAbsolutePath());
        if (mimeType != null) {
            intent.setDataAndType(uriForFile, mimeType);
        } else if (file.toString().contains(".doc") || file.toString().contains(".docx")) {
            intent.setDataAndType(uriForFile, "application/msword");
        } else if (file.toString().contains(".pdf")) {
            intent.setDataAndType(uriForFile, "application/pdf");
        } else if (file.toString().contains(".ppt") || file.toString().contains(".pptx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-powerpoint");
        } else if (file.toString().contains(".xls") || file.toString().contains(".xlsx")) {
            intent.setDataAndType(uriForFile, "application/vnd.ms-excel");
        } else if (file.toString().contains(".zip") || file.toString().contains(".rar")) {
            intent.setDataAndType(uriForFile, "application/x-wav");
        } else if (file.toString().contains(".rtf")) {
            intent.setDataAndType(uriForFile, "application/rtf");
        } else if (file.toString().contains(".wav") || file.toString().contains(".mp3")) {
            intent.setDataAndType(uriForFile, "audio/*");
        } else if (file.toString().contains(".gif")) {
            intent.setDataAndType(uriForFile, "image/gif");
        } else if (file.toString().contains(".jpg") || file.toString().contains(".jpeg") || file.toString().contains(".png")) {
            intent.setDataAndType(uriForFile, "image/*");
        } else if (file.toString().contains(".txt")) {
            intent.setDataAndType(uriForFile, "text/plain");
        } else if (file.toString().contains(".3gp") || file.toString().contains(".mpg") || file.toString().contains(".mpeg") || file.toString().contains(".mpe") || file.toString().contains(".mp4") || file.toString().contains(".avi")) {
            intent.setDataAndType(uriForFile, "video/*");
        } else if (file.toString().contains(".apk")) {
            intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(uriForFile, "*/*");
        }
        try {
            Util.appendLogphonecleaner(this.TAG, "openFile try block", GlobalData.FILE_NAME);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            String str = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("openFile catch block");
            stringBuilder.append(e.getMessage());
            Util.appendLogphonecleaner(str, stringBuilder.toString(), GlobalData.FILE_NAME);
        }
    }

    public int getItemCount() {
        return this.downloadsData.downloadsList.size();
    }

    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        final DownloadWrapper downloadWrapper = (DownloadWrapper) this.downloadsData.downloadsList.get(i);
        TextView textView = myViewHolder.title;
        StringBuilder stringBuilder = new StringBuilder();
        String str = "";
        stringBuilder.append(str);
        stringBuilder.append(downloadWrapper.name);
        textView.setText(stringBuilder.toString());
        textView = myViewHolder.size;
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(Util.convertBytes(downloadWrapper.size));
        textView.setText(stringBuilder.toString());
        getDrawableResource(downloadWrapper, myViewHolder.imgIcon);
        ((View) myViewHolder.title.getParent()).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    FilesDownloadAdapter.this.openDownloadFile(FilesDownloadAdapter.this.context, new File(downloadWrapper.path));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        myViewHolder.checkBoxLout.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DownloadsData b;
                if (myViewHolder.cBox.isChecked()) {
                    myViewHolder.cBox.setChecked(false);
                    downloadWrapper.checked = false;
                    b = FilesDownloadAdapter.this.downloadsData;
                    b.totalSelected--;
                    b = FilesDownloadAdapter.this.downloadsData;
                    b.totalSelectedsize = (int) (((long) b.totalSelectedsize) - downloadWrapper.size);
                } else {
                    myViewHolder.cBox.setChecked(true);
                    downloadWrapper.checked = true;
                    b = FilesDownloadAdapter.this.downloadsData;
                    b.totalSelected++;
                    b = FilesDownloadAdapter.this.downloadsData;
                    b.totalSelectedsize = (int) (((long) b.totalSelectedsize) + downloadWrapper.size);
                }
                if (FilesDownloadAdapter.this.downloadsData.totalSelected == 0) {
                    FilesDownloadAdapter.this.btn.setText(FilesDownloadAdapter.this.context.getString(R.string.clean));
                    return;
                }
                Button c = FilesDownloadAdapter.this.btn;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(FilesDownloadAdapter.this.context.getString(R.string.clean));
                stringBuilder.append(" ");
                stringBuilder.append(Util.convertBytes((long) FilesDownloadAdapter.this.downloadsData.totalSelectedsize));
                c.setText(stringBuilder.toString());
            }
        });
        myViewHolder.cBox.setChecked(downloadWrapper.checked);
    }

    @NonNull
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(this, LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.downlaod_adapter_layout, viewGroup, false));
    }
}
