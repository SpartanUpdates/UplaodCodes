package com.kotlinz.puzzlecreator.activity;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.kotlinz.puzzlecreator.Preferance.SessionManager;
import com.kotlinz.puzzlecreator.R;

import pl.droidsonroids.gif.GifImageView;

public class BaseFragment extends Fragment {
    public FirebaseCrashlytics crashlytics;
    public FirebaseAnalytics mFirebaseAnalytics;
    public SessionManager sessionManager;
    public Dialog dialog;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sessionManager = new SessionManager(getContext());
        crashlytics = FirebaseCrashlytics.getInstance();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(getContext());
        crashlytics = FirebaseCrashlytics.getInstance();
        crashlytics.setCustomKey("User_ID", sessionManager.getUserId());
        mFirebaseAnalytics.setUserId(sessionManager.getUserId());
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void showProgressDialog() {

        dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.progress_dialog_layout);

        dialog.show();

    }

    public void noNetworkDialog() {

        Dialog dialogtkn = new Dialog(getContext());
        dialogtkn.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogtkn.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialogtkn.setCancelable(false);
        dialogtkn.setContentView(R.layout.network_dialog_layout);

        ImageView btnok = dialogtkn.findViewById(R.id.btn_dialog);

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialogtkn.dismiss();
                // sessionManager.logoutUser();
            }
        });

        dialogtkn.show();
    }

    public void showtokenexpire() {

        Dialog dialogtkn = new Dialog(getContext());
        dialogtkn.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogtkn.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialogtkn.setCancelable(false);
        dialogtkn.setContentView(R.layout.session_dialog_layout);

        Button btnok = dialogtkn.findViewById(R.id.btn_dialog);

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialogtkn.dismiss();
                sessionManager.logoutUser();
            }
        });

        dialogtkn.show();

    }

    public void showerrorDialog(String main, String Msg) {

        Dialog dialogerr = new Dialog(getContext());
        dialogerr.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogerr.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialogerr.setCancelable(false);
        dialogerr.setContentView(R.layout.dialog_layout);

        TextView txtmain = dialogerr.findViewById(R.id.txtmain);
        TextView txtmsg = dialogerr.findViewById(R.id.text_dialog);
        ImageView btnok = dialogerr.findViewById(R.id.btn_dialog);
        GifImageView gif = dialogerr.findViewById(R.id.anim_tryagain);
        if (main.equalsIgnoreCase("Report")) {
            gif.setImageResource(R.drawable.report);
        }

        txtmain.setText(main);
        txtmsg.setText(Msg);
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Msg.equalsIgnoreCase("Token Invalid.")) {
                    dialogerr.dismiss();
                    showtokenexpire();
                } else {
                    dialogerr.dismiss();
                }
            }
        });

        dialogerr.show();

    }

    public void cancel_dialog() {
        dialog.dismiss();
    }
}


