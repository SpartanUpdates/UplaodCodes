package com.wavymusic.Utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import androidx.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.widget.TextView;
import com.wavymusic.R;
import com.wavymusic.application.MyApplication;
import com.wavymusic.videolib.libffmpeg.FFmpeg;
import com.wavymusic.videolib.libffmpeg.FFmpegLoadBinaryResponseHandler;
import com.wavymusic.videolib.libffmpeg.FileUtils;
import com.wavymusic.videolib.libffmpeg.Util;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.videolib.libffmpeg.exceptions.FFmpegNotSupportedException;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class AppGeneral {

    public static Context context;
    public static Float LastTime;
    public static String VideoOutputFullPath;
    public static String VideoName;
    public static Float Progress;
    public static Dialog AudioProcessDialog;
    public static TextView tvAudioProgress;
    static String mArcName;
    static int GlobleTotalProgress;
    static int strtProgress;
    static String timeRe;
    static float toatalSecond;
    private static File TEMP_DIRECTORY;
    private static File AudioInput;
    private static File AudioFilePath;
    private static File TempAudioPath;

    static {
        AppGeneral.TEMP_DIRECTORY = new File(Utils.INSTANCE.getStoryFolderPath(), ".123");
        AppGeneral.mArcName = null;
        AppGeneral.GlobleTotalProgress = 0;
        AppGeneral.timeRe = "\\btime=\\b\\d\\d:\\d\\d:\\d\\d.\\d\\d";
        AppGeneral.LastTime = 0.0f;
        AppGeneral.AudioInput = new File(AppGeneral.TEMP_DIRECTORY, "input.txt");
        AppGeneral.AudioFilePath = new File(AppGeneral.TEMP_DIRECTORY, "input.mp3");
        AppGeneral.TempAudioPath = new File(AppGeneral.TEMP_DIRECTORY, "temp.mp3");
    }


    public static void loadFFMpeg(Context ctx) {
        context = ctx;
        final File ffmpegFile = new File(String.valueOf(AppGeneral.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg");
        if (ffmpegFile.exists()) {
            LoadFromUnity(AppGeneral.context);
        } else {
            new AppGeneral.UnzipDownloadedFile().execute();
        }
    }

    private static boolean unpackZip(final String path, final String zipname) {
        try {
            final InputStream is = new FileInputStream(String.valueOf(path) + zipname);
            final ZipInputStream zis = new ZipInputStream(new BufferedInputStream(is));
            final byte[] buffer = new byte[1024];
            ZipEntry ze;
            while ((ze = zis.getNextEntry()) != null) {
                final String filename = ze.getName();
                if (ze.isDirectory()) {
                    final File fmd = new File(String.valueOf(path) + filename);
                    fmd.mkdirs();
                } else {
                    final FileOutputStream fout = new FileOutputStream(String.valueOf(path) + filename);
                    int count;
                    while ((count = zis.read(buffer)) != -1) {
                        fout.write(buffer, 0, count);
                    }
                    fout.close();
                    zis.closeEntry();
                }
            }
            zis.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static void LoadFromUnity(final Context cntx) {
        try {
            loadLib(cntx);
        } catch (FFmpegNotSupportedException e) {
            e.printStackTrace();
        }
    }

    public static void loadLib(final Context cntx) throws FFmpegNotSupportedException {
        final File f = new File(Utils.INSTANCE.getCropSongPath());
        if (!f.exists()) {
            f.mkdirs();
        }
        final FFmpeg fFmpeg = FFmpeg.getInstance(cntx);
        fFmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
            @Override
            public void onStart() {
            }

            @Override
            public void onFinish() {
            }

            @Override
            public void onSuccess(final String cpuType) {
            }

            @Override
            public void onFailure(final String cpuType) {
            }

            @Override
            public void onSuccess() {
                try {
                    final String[] command_chk = {"/system/bin/ls", "-l", String.valueOf(AppGeneral.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg"};
                    final String[] command_run = {"/system/bin/chmod", "744", String.valueOf(AppGeneral.context.getFilesDir().getAbsolutePath()) + File.separator + "ffmpeg"};
                    AppGeneral.checkPermission(command_chk);
                    AppGeneral.checkPermission(command_run);
                    AppGeneral.checkPermission(command_chk);
                } catch (IOException | InterruptedException ex2) {
                    ex2.printStackTrace();
                }
            }

            @Override
            public void onFailure() {
            }
        });
    }

    static class UnzipDownloadedFile extends AsyncTask<Void, Void, Void> {
        String LocalmArcName;
        File LocalFullFile;

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected Void doInBackground(final Void... arg0) {
            this.LocalmArcName = "armeabi-v7a";
            this.LocalFullFile = new File(String.valueOf(FileUtils.getFileDownloadName(this.LocalmArcName)) + File.separator + "ffmpeg");
            copyBinaryFromAssetsToData(context, String.valueOf("armeabi-v7a") + ".zip", String.valueOf("armeabi-v7a") + ".zip");
            unpackZip(String.valueOf(FileUtils.getHiddenFolderPath()) + File.separator, "armeabi-v7a.zip");
            return null;
        }

        protected void onPostExecute(final Void result) {
            if (!AppGeneral.isFullExtracted(this.LocalFullFile.getAbsolutePath())) {
                AppGeneral.deleteRecursive(this.LocalFullFile);
                new UnzipDownloadedFile().execute();
            } else {
                AppGeneral.LoadFromUnity(AppGeneral.context);
            }
            super.onPostExecute(result);
        }
    }

    static void deleteRecursive(final File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = fileOrDirectory.listFiles()).length, i = 0; i < length; ++i) {
                final File child = listFiles[i];
                deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }

    private static Float durationToprogtess(final String input) {
        Float progress = 0.0f;
        final Matcher matcher = Pattern.compile(AppGeneral.timeRe).matcher(input);
        final int SECOND = 1;
        final int MINUTE = SECOND * 60;
        final int HOUR = MINUTE * 60;
        if (TextUtils.isEmpty(input) || !input.contains("time=")) {
            return AppGeneral.LastTime;
        }
        while (matcher.find()) {
            String time = matcher.group();
            time = time.substring(time.lastIndexOf(61) + 1);
            final String[] splitTime = time.split(":");
            final float hour = Float.valueOf(splitTime[0]) * HOUR + Float.valueOf(splitTime[1]) * MINUTE + Float.valueOf(splitTime[2]);
            progress = (hour * 100.0f / AppGeneral.toatalSecond);
        }

        return AppGeneral.LastTime = progress;

    }

    public static void checkPermission(final String[] arg_command) throws IOException, InterruptedException {
        final Process process = Runtime.getRuntime().exec(arg_command);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        final String output = "";
        String line;
        while ((line = reader.readLine()) != null) {
            output.concat(String.valueOf(line) + "\n");
        }
        reader.close();
        process.waitFor();
    }

    public static boolean isFullExtracted(final String FullFilePath) {
        boolean Extracted = false;
        final File mFile = new File(FullFilePath);
        final long armeabi_v7a_size = 18439556L;
        final long x86_size = 21898044L;
        Extracted = (mFile.length() >= armeabi_v7a_size);
        return Extracted;
    }

    static void getContx(final Context context) {
        AppGeneral.context = context;
    }


    static void close(final OutputStream outputStream) {
        if (outputStream != null) {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    static void close(final InputStream inputStream) {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException ex) {
            }
        }
    }

    static boolean copyBinaryFromAssetsToData(final Context context, final String fileNameFromAssets, final String outputFileName) {
        final File filesDirectory = new File(FileUtils.getHiddenFolderPath());
        try {
            final InputStream is = context.getAssets().open(fileNameFromAssets);
            final FileOutputStream os = new FileOutputStream(new File(filesDirectory, outputFileName));
            final byte[] buffer = new byte[4096];
            int n;
            while (-1 != (n = is.read(buffer))) {
                os.write(buffer, 0, n);
            }
            close(os);
            close(is);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void AudioProcessDialog(Context context) {
        AudioProcessDialog = new Dialog(context, R.style.AppAlertDialog);
        AudioProcessDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        AudioProcessDialog.setContentView(R.layout.layout_song_crop);
        AudioProcessDialog.setCancelable(false);
        AudioProcessDialog.setCanceledOnTouchOutside(false);
        AudioProcessDialog.getWindow().setBackgroundDrawableResource(R.color.transparent_black);
        AudioProcessDialog.show();
        tvAudioProgress = AudioProcessDialog.findViewById(R.id.tv_progress_msg);
    }

    public static void AudioVideoShort(final Context context, final String videoInputName, final String VideoOutputName) {
        new Thread(new Runnable() {
            public void run() {
                String VideoOutNameMute = String.valueOf(Utils.INSTANCE.getStoryFolderPath()) + File.separator + videoInputName;
                String VideoInputNameUnited = String.valueOf(Utils.INSTANCE.getStoryFolderPath()) + File.separator + VideoOutputName;
                MyApplication.IsVideoready = true;
                if (!MyApplication.IsSongCuttingready) {
                } else if (!MyApplication.IsAudioVideoMearge) {
                    MyApplication.IsAudioVideoMearge = true;
                    AppGeneral.VideoMaker(VideoOutNameMute, MyApplication.CutSongPath, VideoInputNameUnited);
                    UnityPlayer.UnitySendMessage("StackManager", "SoundAdded", "NiceAudio");
                    AudioProcessDialog.dismiss();
                    MyApplication.IsAudioVideoMearge = false;
                    MyApplication.IsSongCuttingready = false;
                    MyApplication.IsVideoready = false;
                    if (new File(VideoOutNameMute).exists()) {
                        new File(VideoOutNameMute).delete();
                    }
                    if (new File(MyApplication.CutSongPath).exists()) {
                        new File(MyApplication.CutSongPath).delete();
                    }
                }
            }
        }).start();
    }


    public static void AddSongTOVideo(final Context mContext, final String VideoOutNameMute, final String fromSdcard, final String AudioInputpath, final String VideoInputNameUnited) {
        ((Activity) mContext).runOnUiThread(new Runnable() {
            public void run() {
                AudioProcessDialog(mContext);
            }
        });
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void run() {
                try {
                    AppGeneral.strtProgress = 0;
                    int Songtime = 0;
                    if (fromSdcard.equals("0")) {
                        final File filesDirectory = new File(Utils.INSTANCE.getMusicFolderPath());
                        if (!filesDirectory.exists()) {
                            filesDirectory.mkdirs();
                        }
                        try {
                            final InputStream is = context.getAssets().open("mbit.mp3");
                            final FileOutputStream os = new FileOutputStream(new File(filesDirectory, "mbit.mp3"));
                            final byte[] buffer = new byte[4096];
                            int n;
                            while (-1 != (n = is.read(buffer))) {
                                os.write(buffer, 0, n);
                            }
                            Songtime = SongDurationTime(filesDirectory.toString() + File.separator + "mbit.mp3");
                            close(os);
                            close(is);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Songtime = SongDurationTime(AudioInputpath);
                    }
                    final int parseFloat = (int) (0.0f + Songtime);
                    final String videoInput = String.valueOf(Utils.INSTANCE.getStoryFolderPath()) + File.separator + VideoOutNameMute;
                    VideoOutputFullPath = String.valueOf(Utils.INSTANCE.getStoryFolderPath()) + File.separator + VideoInputNameUnited;
                    VideoName = VideoInputNameUnited;
                    AppGeneral.getContx(mContext);
                    if (!AppGeneral.TEMP_DIRECTORY.exists()) {
                        AppGeneral.TEMP_DIRECTORY.mkdirs();
                    }
                    try {
                        if (AppGeneral.TempAudioPath.exists()) {
                            FileUtils.deleteFile(AppGeneral.TempAudioPath);
                        }
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                    InputStream in = null;
                    try {
                        if (fromSdcard.equals("1")) {
                            in = new FileInputStream(AudioInputpath);
                        } else {
                            in = AppGeneral.context.getAssets().open(AudioInputpath);
                        }
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    FileOutputStream out = null;
                    try {
                        out = new FileOutputStream(AppGeneral.TempAudioPath);
                    } catch (FileNotFoundException e3) {
                        e3.printStackTrace();
                    }
                    final byte[] buff = new byte[1024];
                    int read = 0;
                    try {
                        while ((read = in.read(buff)) > 0) {
                            out.write(buff, 0, read);
                        }
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                    AppGeneral.AudioFilePath.delete();
                    AppGeneral.AudioInput.delete();
                    final int durationAudio = SongDurationTime(AppGeneral.TempAudioPath.getAbsolutePath());
                    final int durationVideo = (int) (0.0f + parseFloat);
                    int d = 0;
                    while (true) {
                        appendAudioLog(String.format("file '%s'", AppGeneral.TempAudioPath));
                        if (durationVideo <= durationAudio * d) {
                            break;
                        }
                        ++d;
                    }
                    final String[] inputCode = {FileUtils.getFFmpeg(AppGeneral.context), "-f", "concat", "-safe", "0", "-i", AppGeneral.AudioInput.getAbsolutePath(), "-c", "copy", "-preset", "ultrafast", "-ac", "2", AppGeneral.AudioFilePath.getAbsolutePath()};
                    executeCommand3D(inputCode);
                    final long currentTime = System.currentTimeMillis();
                    final String currTimeStr = String.valueOf(currentTime);
                    final String cutAudio = String.valueOf(Utils.INSTANCE.getStoryFolderPath()) + File.separator + "cut_" + currTimeStr + "_audio" + ".m4a";
                    AppGeneral.strtProgress = 1;
                    final Float seconds = durationVideo / 1000.0f;
                    AppGeneral.toatalSecond = seconds;
                    final String[] audioCut = {FileUtils.getFFmpeg(AppGeneral.context), "-i", AppGeneral.AudioFilePath.getAbsolutePath(), "-ss", "0", "-t", String.valueOf(seconds), "-preset", "ultrafast", cutAudio};
                    executeCommand3D(audioCut);
                    MyApplication.IsSongCuttingready = true;
                    MyApplication.CutSongPath = cutAudio;
                    if (!MyApplication.IsVideoready) {
                    } else if (!MyApplication.IsAudioVideoMearge) {
                        MyApplication.IsAudioVideoMearge = true;
                        AppGeneral.VideoMaker(videoInput, cutAudio, VideoOutputFullPath);
                        UnityPlayer.UnitySendMessage("StackManager", "SoundAdded", "NiceAudio");
                        AudioProcessDialog.dismiss();
                        MyApplication.IsAudioVideoMearge = false;
                        MyApplication.IsSongCuttingready = false;
                        MyApplication.IsVideoready = false;
                        if (new File(videoInput).exists()) {
                            new File(videoInput).delete();
                        }
                        if (new File(cutAudio).exists()) {
                            new File(cutAudio).delete();
                        }
                    }

                } catch (Resources.NotFoundException e5) {
                    e5.printStackTrace();
                }
            }
        }).start();
    }

    private static void appendAudioLog(final String text) {
        if (!AppGeneral.TEMP_DIRECTORY.exists()) {
            AppGeneral.TEMP_DIRECTORY.mkdirs();
        }
        final File logFile = new File(AppGeneral.AudioInput.getAbsolutePath());
        if (!logFile.exists()) {
            try {
                logFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            final BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(text);
            buf.newLine();
            buf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public static void VideoMaker(final String InVid, final String InAud, final String outPutPath) {
        String outputFile = "";
        try {
            final File file = new File(outPutPath);
            file.createNewFile();
            outputFile = file.getAbsolutePath();
            final MediaExtractor videoExtractor = new MediaExtractor();
            final File kk = new File(InVid);
            final FileInputStream fileInputStream = new FileInputStream(kk);
            final FileDescriptor fd = fileInputStream.getFD();
            videoExtractor.setDataSource(fd, 0L, kk.length());
            final MediaExtractor audioExtractor = new MediaExtractor();
            audioExtractor.setDataSource(InAud);
            final MediaMuxer muxer = new MediaMuxer(outputFile, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            videoExtractor.selectTrack(0);
            final MediaFormat videoFormat = videoExtractor.getTrackFormat(0);
            final int videoTrack = muxer.addTrack(videoFormat);
            audioExtractor.selectTrack(0);
            final MediaFormat audioFormat = audioExtractor.getTrackFormat(0);
            final int audioTrack = muxer.addTrack(audioFormat);
            boolean sawEOS = false;
            int frameCount = 0;
            final int offset = 100;
            final int sampleSize = 16777216;
            final ByteBuffer videoBuf = ByteBuffer.allocate(sampleSize);
            final ByteBuffer audioBuf = ByteBuffer.allocate(sampleSize);
            final MediaCodec.BufferInfo videoBufferInfo = new MediaCodec.BufferInfo();
            final MediaCodec.BufferInfo audioBufferInfo = new MediaCodec.BufferInfo();
            videoExtractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            audioExtractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            muxer.start();
            while (!sawEOS) {
                videoBufferInfo.offset = offset;
                videoBufferInfo.size = videoExtractor.readSampleData(videoBuf, offset);
                if (videoBufferInfo.size < 0 || audioBufferInfo.size < 0) {
                    sawEOS = true;
                    videoBufferInfo.size = 0;
                } else {
                    videoBufferInfo.presentationTimeUs = videoExtractor.getSampleTime();
                    videoBufferInfo.flags = videoExtractor.getSampleFlags();
                    muxer.writeSampleData(videoTrack, videoBuf, videoBufferInfo);
                    videoExtractor.advance();
                    ++frameCount;
                }
            }
            boolean sawEOS2 = false;
            int frameCount2 = 0;
            while (!sawEOS2) {
                ++frameCount2;
                audioBufferInfo.offset = offset;
                audioBufferInfo.size = audioExtractor.readSampleData(audioBuf, offset);
                if (videoBufferInfo.size < 0 || audioBufferInfo.size < 0) {
                    sawEOS2 = true;
                    audioBufferInfo.size = 0;
                } else {
                    audioBufferInfo.presentationTimeUs = audioExtractor.getSampleTime();
                    audioBufferInfo.flags = audioExtractor.getSampleFlags();
                    muxer.writeSampleData(audioTrack, audioBuf, audioBufferInfo);
                    audioExtractor.advance();
                }
            }
            muxer.stop();
            muxer.release();
        } catch (IOException e2) {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void executeCommand3D(final String[] cmd) {
        Process videoProcess = null;
        try {
            videoProcess = Runtime.getRuntime().exec(cmd);
            while (!Util.isProcessCompleted(videoProcess)) {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(videoProcess.getErrorStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (AppGeneral.strtProgress == 1) {
                        Progress = durationToprogtess(line);
                        ((Activity) AppGeneral.context).runOnUiThread(new Runnable() {
                            public void run() {
                                if (Progress >= 100) {
                                    tvAudioProgress.setText("100.00 %");
                                } else {
//                                    tvAudioProgress.setText(String.valueOf(String.format("%.2f", Progress)) + " %");
                                    tvAudioProgress.setText(String.valueOf(Math.round(Progress)) + " %");
                                }
                            }
                        });
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        } finally {
            Util.destroyProcess(videoProcess);
        }
        Util.destroyProcess(videoProcess);
    }

    private static int SongDurationTime(final String file) {
        MediaPlayer mp = MediaPlayer.create(AppGeneral.context, Uri.parse(file));
        final int duration = mp.getDuration();
        mp.release();
        return duration;
    }

}
