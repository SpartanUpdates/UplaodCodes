package com.kotlinz.videoCollage.flying.poiphoto;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore.Video.Media;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Album;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class VideoManager {
    private List<String> mBucketIds;
    private ContentResolver mContentResolver;
    private Context mContext;

    public VideoManager(Context context) {
        this.mContext = context;
        this.mContentResolver = context.getContentResolver();
        this.mBucketIds = new ArrayList();
    }

    public List<Album> getAlbum() {
        this.mBucketIds.clear();
        ArrayList arrayList = new ArrayList();
        String str = "bucket_id";
        String str2 = "bucket_display_name";
        Cursor query = this.mContentResolver.query(Media.EXTERNAL_CONTENT_URI, new String[]{str, str2}, null, null, "date_modified");
        if (query != null && query.moveToFirst()) {
            do {
                Album album = new Album();
                String string = query.getString(query.getColumnIndex(str));
                if (!this.mBucketIds.contains(string)) {
                    this.mBucketIds.add(string);
                    String string2 = query.getString(query.getColumnIndex(str2));
                    String frontCoverData = getFrontCoverData(string);
                    album.setId(string);
                    album.setName(string2);
                    album.setCoverPath(frontCoverData);
                    arrayList.add(album);
                }
            } while (query.moveToNext());
            query.close();
        }
        return arrayList;
    }

    public List<Video> getVideo(String str) {
        ArrayList arrayList = new ArrayList();
        String str2 = "_data";
        String str3 = "date_added";
        String str4 = "date_modified";
        String str5 = "duration";
        Cursor query = this.mContentResolver.query(Media.EXTERNAL_CONTENT_URI, new String[]{str2, str3, str4, str5}, "bucket_id=?", new String[]{str}, "date_modified");
        if (query != null && query.moveToFirst()) {
            do {
                String string = query.getString(query.getColumnIndex(str2));
                Long valueOf = Long.valueOf(query.getLong(query.getColumnIndex(str3)));
                Long valueOf2 = Long.valueOf(query.getLong(query.getColumnIndex(str4)));
                Long valueOf3 = Long.valueOf(query.getLong(query.getColumnIndex(str5)));
                if (!(valueOf3.longValue() > 60000 || valueOf3.longValue() < 1000 || string.contains(".flv") || string.contains(".m2ts") || string.contains(".ts") || string.contains(".webm") || string.contains(".mov"))) {
                    arrayList.add(new Video(string, valueOf.longValue(), valueOf2.longValue(), valueOf3.longValue()));
                }
            } while (query.moveToNext());
            query.close();
        }
        return arrayList;
    }

    private String getFrontCoverData(String str) {
        String str2 = "_data";
        Cursor query = this.mContentResolver.query(Media.EXTERNAL_CONTENT_URI, new String[]{str2}, "bucket_id=?", new String[]{str}, "date_modified");
        if (query == null || !query.moveToFirst()) {
            return "empty";
        }
        String string = query.getString(query.getColumnIndex(str2));
        query.close();
        return string;
    }

    public List<Video> getAllVideo() {
        ArrayList arrayList = new ArrayList();
        String str = "_data";
        String str2 = "date_added";
        String str3 = "date_modified";
        String str4 = "duration";
        Cursor query = this.mContentResolver.query(Media.EXTERNAL_CONTENT_URI, new String[]{str, str2, str3, str4}, null, null, "date_modified");
        if (query != null && query.moveToFirst()) {
            do {
                String string = query.getString(query.getColumnIndex(str));
                Long valueOf = Long.valueOf(query.getLong(query.getColumnIndex(str2)));
                Long valueOf2 = Long.valueOf(query.getLong(query.getColumnIndex(str3)));
                Long valueOf3 = Long.valueOf(query.getLong(query.getColumnIndex(str4)));
                if (!(valueOf3.longValue() > 60000 || valueOf3.longValue() < 1000 || string.contains(".flv") || string.contains(".m2ts") || string.contains(".ts") || string.contains(".webm") || string.contains(".mov"))) {
                    arrayList.add(new Video(string, valueOf.longValue(), valueOf2.longValue(), valueOf3.longValue()));
                }
            } while (query.moveToNext());
            query.close();
        }
        Collections.sort(arrayList, new Comparator<Video>() {
            public int compare(Video video, Video video2) {
                int i = (video.getDataModified() > video2.getDataModified() ? 1 : (video.getDataModified() == video2.getDataModified() ? 0 : -1));
                if (i > 0) {
                    return -1;
                }
                return i == 0 ? 0 : 1;
            }
        });
        return arrayList;
    }
}
