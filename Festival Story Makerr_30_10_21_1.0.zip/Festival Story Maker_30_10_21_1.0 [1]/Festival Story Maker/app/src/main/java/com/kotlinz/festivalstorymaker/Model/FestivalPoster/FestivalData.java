package com.kotlinz.festivalstorymaker.Model.FestivalPoster;

import com.google.gson.annotations.SerializedName;

public class FestivalData {

	@SerializedName("image")
	private String image;

	@SerializedName("festival_name")
	private String festivalName;

	@SerializedName("festival_date")
	private String festivalDate;

	@SerializedName("id")
	private String id;

	public String getImage(){
		return image;
	}

	public String getFestivalName(){
		return festivalName;
	}

	public String getFestivalDate(){
		return festivalDate;
	}

	public String getId(){
		return id;
	}
}