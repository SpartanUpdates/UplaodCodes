package com.vidsoft.collagemaker.GridThreeD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;

import com.vidsoft.collagemaker.Activity.MainActivity;
import com.vidsoft.collagemaker.Adapters.GridImageAdapter;
import com.vidsoft.collagemaker.Model.Grid3D;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.DataBinder;

import java.util.ArrayList;

public class GridSelectionActivity extends AppCompatActivity {
    Activity activity;
    ArrayList<Grid3D> grid3DArrayList;
    GridImageAdapter gridImageAdapter;
    GridLayoutManager gridLayoutManager;
    RecyclerView recyclerView;

    public GridSelectionActivity() {
        this.activity = this;
        this.grid3DArrayList = new ArrayList();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_grid_selection);
        bindToolbar();
        bindControls();
        initLayout();
    }

    private void initLayout() {
        this.grid3DArrayList.clear();
        this.grid3DArrayList = DataBinder.fetchGrid3dData();
        Log.e("databinder", "" + grid3DArrayList);
        this.gridImageAdapter = new GridImageAdapter(this.activity, this.grid3DArrayList);
        this.gridLayoutManager = new GridLayoutManager(this, 2);
        this.recyclerView.setLayoutManager(this.gridLayoutManager);
        this.gridImageAdapter.setLayoutManager(this.gridLayoutManager);
        this.recyclerView.setAdapter(this.gridImageAdapter);
    }

    private void bindToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_btn_selector);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(getResources().getString(R.string.GridSelectionActivity_Title));
    }

    private void bindControls() {
        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.recyclerView.setLayoutManager(new GridLayoutManager(this.activity, 2));
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                    startActivity(new Intent(GridSelectionActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                return true;
            default:
                return false;
        }
    }

    public void onBackPressed() {
            startActivity(new Intent(GridSelectionActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));

    }
}