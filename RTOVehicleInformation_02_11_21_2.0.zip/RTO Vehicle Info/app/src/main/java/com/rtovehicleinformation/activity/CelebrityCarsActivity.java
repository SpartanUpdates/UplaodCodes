package com.rtovehicleinformation.activity;

import android.app.Activity;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.rtovehicleinformation.Adapter.CelebrityCarsAdapter;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.utils.Utils;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CelebrityCarsActivity extends AppCompatActivity {

    Activity activity = CelebrityCarsActivity.this;
    @BindView(R.id.celeb_cars)
    RecyclerView rvcelebcars;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.iv_back)
    ImageView ivback;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    CelebrityCarsAdapter celebrityCarsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celebrity_cars);
        ButterKnife.bind(this);
        rvcelebcars.setLayoutManager(new GridLayoutManager(this, 1));
        celebrityCarsAdapter = new CelebrityCarsAdapter(this, Utils.celebsCarImg, Utils.celebsName, Utils.celebsNum, new CelebrityCarsAdapter.OnItemClickListener() {
            public void onItemClick(View view, int i) {
                substring(getResources().getString(Utils.celebsNum[i]));
            }
        });
        rvcelebcars.setAdapter(this.celebrityCarsAdapter);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        BannerAds();
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdUnitId(getString(R.string.Banner_ad_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void substring(String str) {
        String substring = str.substring(0, 6);
        str = str.substring(6);
        Intent intent = new Intent(this, VehicleDetailActivity.class);
        intent.putExtra("firstPart", substring);
        intent.putExtra("lastPart", str);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
