package com.kotlinz.videoCollage.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.TextureView;

public class AutoFitTextureView extends TextureView {
    private int mRatioHeight;
    private int mRatioWidth;

    public AutoFitTextureView(Context context) {
        this(context, null);
    }

    public AutoFitTextureView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AutoFitTextureView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mRatioWidth = 0;
        this.mRatioHeight = 0;
    }

    public void setAspectRatio(int i, int i2) {
        if (i < 0 || i2 < 0) {
            throw new IllegalArgumentException("Size cannot be negative.");
        }
        this.mRatioWidth = i;
        this.mRatioHeight = i2;
        requestLayout();
    }


    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = MeasureSpec.getSize(i);
        i2 = MeasureSpec.getSize(i2);
        int i3 = this.mRatioWidth;
        if (i3 != 0) {
            int i4 = this.mRatioHeight;
            if (i4 != 0) {
                if (i < (i2 * i3) / i4) {
                    setMeasuredDimension(i, (i4 * i) / i3);
                    return;
                } else {
                    setMeasuredDimension((i3 * i2) / i4, i2);
                    return;
                }
            }
        }
        setMeasuredDimension(i, i2);
    }
}
