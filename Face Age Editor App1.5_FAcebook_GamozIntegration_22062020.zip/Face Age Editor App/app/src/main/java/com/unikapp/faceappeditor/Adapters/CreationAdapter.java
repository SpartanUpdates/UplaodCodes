package com.unikapp.faceappeditor.Adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.unikapp.faceage.editorapp.R;

import java.util.ArrayList;

public class CreationAdapter extends BaseAdapter {
    private static LayoutInflater inflater = null;
    private Activity activity;
    ArrayList<String> imagegallary = new ArrayList();
    private final SparseBooleanArray sparse_BooleanArray;
    static class Viewholder {
        ImageView imageView;

        Viewholder() {
        }
    }
    public CreationAdapter(Activity dAct, ArrayList<String> dUrl) {
        this.activity = dAct;
        this.imagegallary = dUrl;
        inflater = (LayoutInflater) this.activity
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.sparse_BooleanArray = new SparseBooleanArray(
                this.imagegallary.size());
    }

    public int getCount() {
        return this.imagegallary.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View convertview, ViewGroup viewGroup) {
        Viewholder holder;
        View row = convertview;
        if (row == null) {
            row = inflater.inflate(R.layout.gridview_item, null);
            holder = new Viewholder();
            holder.imageView = (ImageView) row.findViewById(R.id.imageview);
            row.setTag(holder);
        } else {
            holder = (Viewholder) row.getTag();
        }
        holder.imageView.setImageBitmap(BitmapFactory
                .decodeFile((String) this.imagegallary.get(i)));
        return row;

    }
}