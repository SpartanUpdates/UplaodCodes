package com.esc.flashlight.flashlight.controller;

import android.view.SurfaceView;

public interface BaseFlashControllerInterface {
    void flashOff();

    void flashOn();

    void useStart(SurfaceView surfaceView);

    void useStop();
}
