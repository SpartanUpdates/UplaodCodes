package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import android.view.View.OnClickListener;
import com.kotlinz.festivalstorymaker.activity.HighlightDetailsDetailActivity;

public class v6 implements OnClickListener {
    public v6(HighlightDetailsDetailActivity highlightDetailsDetailActivity) {
    }

    public void onClick(View view) {
    }
}
