package com.rtovehicleinformation.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
//import com.google.android.gms.common.api.GoogleApiClient;
//import com.google.android.gms.common.api.Result;
//import com.google.android.gms.common.api.ResultCallback;
//import com.google.android.gms.common.api.Status;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rtovehicleinformation.BuildConfig;
import com.rtovehicleinformation.Model.PersonalizedAds;
import com.rtovehicleinformation.Model.PetrolDieselData;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.utils.Const;
import com.rtovehicleinformation.utils.Pref;

import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.google.android.gms.location.LocationServices.API;

public class MainActivity extends AppCompatActivity implements LocationListener {

    Activity activity = MainActivity.this;

    String Latitude;
    PersonalizedAds ads;
    String city;
    String country;
    GoogleApiClient googleApiClient;

    LocationManager locationManager;
    String longitude;
    List<PetrolDieselData> petroldata;
    String strDate;

    @BindView(R.id.changeCity)
    TextView tvchangeCity;

    @BindView(R.id.city)
    TextView tvcityState;

    @BindView(R.id.diesel)
    TextView tvdiesel;

    @BindView(R.id.dieselname)
    TextView tvdieselname;

    @BindView(R.id.errorMsg)
    TextView tverrorMsg;

    @BindView(R.id.petrol)
    TextView tvpetrol;

    @BindView(R.id.petrolDiesel)
    LinearLayout layoutpetrolDiesel;

    @BindView(R.id.petrolname)
    TextView tvpetrolname;

    @BindView(R.id.progress)
    ProgressBar progress;

    @BindView(R.id.retry)
    TextView tvretry;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.cv_owner_info)
    CardView reg;

    @BindView(R.id.cv_trafficSymbols)
    CardView trafficSymbols;

    @BindView(R.id.cv_trending)
    CardView trending;

    @BindView(R.id.cv_vehicleExpense)
    CardView vehicleExpense;

    @BindView(R.id.cv_vehicleMileage)
    CardView vehicleMileage;

    @BindView(R.id.iv_share)
    ImageView iv_share;

    @BindView(R.id.view1)
    View view1;

    @BindView(R.id.view2)
    View view2;

    AdRequest adRequest;
    AdView adView;

    private class GeocoderHandler extends Handler {

        private GeocoderHandler() {
        }

        public void handleMessage(Message message) {
            String str;
            if (message.what != 1) {
                str = null;
            } else {
                str = message.getData().getString("address");
            }
            if (!str.isEmpty()) {
                String[] split = str.split("\n");
                MainActivity mainActivity = MainActivity.this;
                mainActivity.city = split[0];
                mainActivity.country = split[1];
                Pref.setStringValue(mainActivity, Const.PREF_LAST_CITY, MainActivity.this.city);
                Pref.setStringValue(MainActivity.this, Const.PREF_LAST_COUNTRY, MainActivity.this.country);
            }
        }
    }

    public void onProviderDisabled(String str) {
    }

    public void onProviderEnabled(String str) {
    }

    public void onStatusChanged(String str, int i, Bundle bundle) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        loadBannerAd();
        this.strDate = new SimpleDateFormat("ddMMMyyyy").format(Calendar.getInstance().getTime());
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        int i = 1;
        NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
        NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
        int i2 = networkInfo != null ? 1 : 0;
        if (networkInfo2 == null) {
            i = 0;
        }
        if ((i & i2) != 0) {
            if ((networkInfo2.isConnected() | networkInfo.isConnected())) {
                initLocation();
                this.tvretry.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(CONNECTIVITY_SERVICE);
                        int i = 1;
                        NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
                        NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
                        int i2 = networkInfo != null ? 1 : 0;
                        if (networkInfo2 == null) {
                            i = 0;
                        }
                        if ((i & i2) != 0) {
                            if ((networkInfo2.isConnected() | networkInfo.isConnected())) {
                                MainActivity.this.tverrorMsg.setVisibility(View.GONE);
                                MainActivity.this.tvretry.setVisibility(View.GONE);
                                MainActivity.this.initLocation();
                                return;
                            }
                        }
                        Toast.makeText(MainActivity.this, "Please check your Internet Connection.", Toast.LENGTH_SHORT).show();
                    }
                });

                vehicleExpense.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        startActivity(new Intent(activity, VehicleExpenseActivity.class));
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                });
                vehicleMileage.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        startActivity(new Intent(activity, MileageActivity.class));
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                });
                reg.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        startActivity(new Intent(activity, HomeActivity.class));
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                });
                trafficSymbols.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        startActivity(new Intent(activity, TrafficSymbolsActivity.class));
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                });
                trending.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        startActivity(new Intent(activity, TrendingActivity.class));
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                });

            }
        }
//        this.progress.setVisibility(View.GONE);
//        this.tverrorMsg.setVisibility(View.VISIBLE);
//        this.tvretry.setVisibility(View.VISIBLE);
//        this.tverrorMsg.setText("Please check your Internet Connection.");
        this.tvretry.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                final ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(CONNECTIVITY_SERVICE);
                boolean b = true;
                final NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
                final NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
                final boolean b2 = networkInfo != null;
                if (networkInfo2 == null) {
                    b = false;
                }
                if ((b & b2) && (networkInfo2.isConnected() | networkInfo.isConnected())) {
                    MainActivity.this.tverrorMsg.setVisibility(View.GONE);
                    MainActivity.this.tvretry.setVisibility(View.GONE);
                    MainActivity.this.initLocation();
                    return;
                }
                Toast.makeText(MainActivity.this, "Please check your Internet Connection.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void loadBannerAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    public static void geocode(final String s, final String s2, final Context context, final Handler handler) {
        new Thread() {
            @Override
            public void run() {
                final Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                try {
                    try {
                        final List fromLocation = geocoder.getFromLocation((double) Float.parseFloat(s), (double) Float.parseFloat(s2), 1);
                        String string;
                        if (fromLocation != null && fromLocation.size() > 0) {
                            Address address = (Address) fromLocation.get(0);
                            final StringBuilder sb = new StringBuilder();
                            sb.append(address.getLocality());
                            sb.append("\n");
                            sb.append(address.getCountryName());
                            sb.append("\n");
                            string = sb.toString();
                        } else {
                            string = null;
                        }
                        final Message obtain = Message.obtain();
                        obtain.setTarget(handler);
                        if (string != null) {
                            obtain.what = 1;
                            final Bundle data = new Bundle();
                            data.putString("address", string);
                            obtain.setData(data);
                        } else {
                            obtain.what = 1;
                            final Bundle data2 = new Bundle();
                            data2.putString("address", "");
                            obtain.setData(data2);
                        }
                        obtain.sendToTarget();
                        return;
                    } finally {
                    }
                } catch (IOException ex) {
                    Log.e("GeocodingLocation", "Unable to connect to Geocoder", ex);
                    final Message obtain2 = Message.obtain();
                    obtain2.setTarget(handler);
                    obtain2.what = 1;
                    final Bundle data3 = new Bundle();
                    data3.putString("address", "");
                    obtain2.setData(data3);
                    obtain2.sendToTarget();
                    return;
                }
            }
        }.start();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.homescreen, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        } else if (itemId == R.id.share) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "RTO Information");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("\nLet me recommend you this application\n\n");
                stringBuilder.append("https://play.google.com/store/apps/details?id=");
                stringBuilder.append(BuildConfig.APPLICATION_ID);
                stringBuilder.append("\n\n");
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                startActivity(Intent.createChooser(intent, "choose one"));
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            } catch (Exception unused) {
                unused.printStackTrace();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onLocationChanged(Location location) {
        if (location != null) {
            this.Latitude = String.valueOf(location.getLatitude());
            this.longitude = String.valueOf(location.getLongitude());
            if (location != null) {
                geocode(this.Latitude, this.longitude, this.getApplication(), new GeocoderHandler());
            }
        }
    }

    private void GetPrice() {
        RequestQueue newRequestQueue = Volley.newRequestQueue(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("http://yptech.in/petrolprice//priceapi.php?priceDate=");
        stringBuilder.append(this.strDate);
        newRequestQueue.add(new JsonObjectRequest(0, stringBuilder.toString(), null, new Response.Listener<JSONObject>() {
            public void onResponse(JSONObject jSONObject) {
                Gson gson = new Gson();
                try {
                    Type type = new TypeToken<List<PetrolDieselData>>() {
                    }.getType();
                    MainActivity.this.petroldata = gson.fromJson(jSONObject.getJSONArray("prices").toString(), type);
                    for (PetrolDieselData petrolDieselData : petroldata) {
                        if (petrolDieselData.getCityName().toLowerCase().equals(Pref.getStringValue(MainActivity.this, Const.PREF_LAST_CITY, "").toLowerCase())) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("₹ ");
                            stringBuilder.append(petrolDieselData.getPPrice());
                            tvpetrol.setText(stringBuilder.toString());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("₹ ");
                            stringBuilder.append(petrolDieselData.getDPrice());
                            tvdiesel.setText(stringBuilder.toString());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(petrolDieselData.getCityName());
                            stringBuilder.append(", ");
                            stringBuilder.append(petrolDieselData.getStateName());
                            tvcityState.setText(stringBuilder.toString());
                        }
                        progress.setVisibility(View.GONE);
                        layoutpetrolDiesel.setVisibility(View.VISIBLE);
                        tvchangeCity.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(CONNECTIVITY_SERVICE);
                                NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
                                NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
                                if (((networkInfo != null ? 1 : 0) & (networkInfo2 != null ? 1 : 0)) != 0) {
                                    if ((networkInfo2.isConnected() | networkInfo.isConnected())) {
                                        Intent intent = new Intent(MainActivity.this, CityListActivity.class);
                                        intent.putExtra("data", (Serializable) MainActivity.this.petroldata);
                                        startActivityForResult(intent, 1);
                                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                                        return;
                                    }
                                }
                                layoutpetrolDiesel.setVisibility(View.GONE);
                                progress.setVisibility(View.GONE);
                                tverrorMsg.setVisibility(View.VISIBLE);
                                tvretry.setVisibility(View.VISIBLE);
                                tverrorMsg.setText("Please check your Internet Connection.");
                            }
                        });
                    }
                } catch (Exception unused) {
                    Toast.makeText(MainActivity.this, "Your internet Connection slow..!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(MainActivity.this, "Check Your Internet Connection..!", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    public void onActivityResult(int i, int i2, @Nullable Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1 && i2 == -1) {
            PetrolDieselData petrolDieselData = (PetrolDieselData) intent.getSerializableExtra("data");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(petrolDieselData.getCityName());
            stringBuilder.append(", ");
            stringBuilder.append(petrolDieselData.getStateName());
            tvcityState.setText(stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append("₹ ");
            stringBuilder.append(petrolDieselData.getPPrice());
            tvpetrol.setText(stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append("₹ ");
            stringBuilder.append(petrolDieselData.getDPrice());
            tvdiesel.setText(stringBuilder.toString());
        }
    }

    public void initLocation() {
        this.progress.setVisibility(View.VISIBLE);
        if (!(ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0)) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}, 101);
        }
        this.progress.setVisibility(View.VISIBLE);
        if (this.googleApiClient == null) {
            this.googleApiClient = new GoogleApiClient.Builder(getApplicationContext()).addApi(API).build();
            this.googleApiClient.connect();
            LocationRequest create = LocationRequest.create();
            create.setPriority(100);
            create.setInterval(30000);
            create.setFastestInterval(5000);
            LocationSettingsRequest.Builder addLocationRequest = new LocationSettingsRequest.Builder().addLocationRequest(create);
            addLocationRequest.setAlwaysShow(true);
            LocationServices.SettingsApi.checkLocationSettings(this.googleApiClient, addLocationRequest.build()).setResultCallback(new ResultCallback() {
                public void onResult(Result result) {
                    Status status = result.getStatus();
                    int statusCode = status.getStatusCode();
                    if (statusCode != 0 && statusCode == 6) {
                        try {
                            status.startResolutionForResult(MainActivity.this, 1000);
                        } catch (IntentSender.SendIntentException unused) {
                            unused.printStackTrace();
                        }
                    }
                }
            });
            this.googleApiClient = new GoogleApiClient.Builder(this).addApi(API).build();
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            this.locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            this.locationManager.requestLocationUpdates("gps", 0, 0.0f, this);
            onLocationChanged(this.locationManager.getLastKnownLocation("network"));
        }
        GetPrice();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(MainActivity.this, MoreAppActivity.class));
        finish();
    }
}
