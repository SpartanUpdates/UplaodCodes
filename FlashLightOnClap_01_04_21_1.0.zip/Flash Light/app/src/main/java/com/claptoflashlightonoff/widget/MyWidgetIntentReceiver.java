package com.claptoflashlightonoff.widget;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.widget.RemoteViews;
import android.widget.Toast;
import com.claptoflashlightonoff.util.Utility;
import com.example.speaktourchtight.R;

public class MyWidgetIntentReceiver extends BroadcastReceiver {
  public static boolean isLightOn = false;
  private boolean hasFlash;

  public void onReceive(Context context, Intent intent) {
    RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget);
    this.hasFlash = context.getApplicationContext().getPackageManager().hasSystemFeature("android.hardware.camera.flash");
    if (intent == null || !intent.hasExtra("isFromActivity")) {
      if (!this.hasFlash) {
        Toast.makeText(context, R.string.flash_message, Toast.LENGTH_SHORT).show();
      } else if (isLightOn) {
        views.setImageViewResource(R.id.ivWidget, R.drawable.widget_off);
      } else {
        views.setImageViewResource(R.id.ivWidget, R.drawable.widget_on);
      }
      AppWidgetManager.getInstance(context).updateAppWidget(new ComponentName(context, MyWidgetProvider.class), views);
      Parameters param;
      if (!isLightOn) {
        Utility.camera = Camera.open();
        Utility.tempCameraOpenChecker = true;
        if (Utility.camera == null) {
          Toast.makeText(context, R.string.flash_message, Toast.LENGTH_SHORT).show();
          return;
        }
        views.setImageViewResource(R.id.ivWidget, R.drawable.widget_on);
        param = Utility.camera.getParameters();
        param.setFlashMode("torch");
        try {
          Utility.camera.setParameters(param);
          Utility.camera.startPreview();
          isLightOn = true;
          Utility.flagWidget = true;
          return;
        } catch (Exception e) {
          Toast.makeText(context, R.string.flash_message, Toast.LENGTH_SHORT).show();
          return;
        }
      } else if (Utility.camera != null) {
        views.setImageViewResource(R.id.ivWidget, R.drawable.widget_off);
        param = Utility.camera.getParameters();
        param.setFlashMode("off");
        Utility.camera.setParameters(param);
        Utility.camera.stopPreview();
        Utility.camera.release();
        Utility.camera = null;
        Utility.tempCameraOpenChecker = false;
        isLightOn = false;
        Utility.flagWidget = false;
        return;
      } else {
        return;
      }
    }
    views.setImageViewResource(R.id.ivWidget, R.drawable.widget_off);
    AppWidgetManager.getInstance(context).updateAppWidget(new ComponentName(context, MyWidgetProvider.class), views);
  }
}
