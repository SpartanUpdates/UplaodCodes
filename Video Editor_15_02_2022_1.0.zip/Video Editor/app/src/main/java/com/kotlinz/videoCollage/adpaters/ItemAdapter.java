package com.kotlinz.videoCollage.adpaters;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.util.Pair;

import com.kotlinz.videoCollage.GridActivity;
import com.kotlinz.videoCollage.other.ImageUtils;
import com.kotlinz.videoCollage.sticker.ResizableStickerView;
import com.kotlinz.videoCollage.textmodule.AutofitTextRel;
import com.kotlinz.videoeditor.R;
import com.woxthebox.draglistview.DragItemAdapter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class ItemAdapter extends DragItemAdapter<Pair<Long, View>, ItemAdapter.ViewHolder> {
    Activity activity;
    private boolean mDragOnLongPress;
    private int mGrabHandleId;
    private int mLayoutId;

    class ViewHolder extends com.woxthebox.draglistview.DragItemAdapter.ViewHolder {
        ImageView img_lock;
        ImageView mImage;
        TextView mText;
        ImageView textView;

        public void onItemClicked(View view) {
        }

        public boolean onItemLongClicked(View view) {
            return true;
        }

        ViewHolder(View view) {
            super(view, ItemAdapter.this.mGrabHandleId, ItemAdapter.this.mDragOnLongPress);
            this.mText = (TextView) view.findViewById(R.id.text);
            this.mImage = (ImageView) view.findViewById(R.id.image1);
            this.textView = (ImageView) view.findViewById(R.id.auto_fit_edit_text);
            this.img_lock = (ImageView) view.findViewById(R.id.img_lock);
        }
    }

    public ItemAdapter(Activity activity, ArrayList<Pair<Long, View>> arrayList, int i, int i2, boolean z) {
        this.mLayoutId = i;
        this.mGrabHandleId = i2;
        this.activity = activity;
        this.mDragOnLongPress = z;
        setItemList(arrayList);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(this.mLayoutId, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        super.onBindViewHolder(viewHolder, i);
        final View view = (View) ((Pair) this.mItemList.get(i)).second;
        try {
            InputStream inputStream = null;
            if (view instanceof ResizableStickerView) {
                View childAt = ((ResizableStickerView) view).getChildAt(1);
                Bitmap createBitmap = Bitmap.createBitmap(childAt.getWidth(), childAt.getHeight(), Config.ARGB_8888);
                childAt.draw(new Canvas(createBitmap));
                float[] fArr = new float[9];
                ((ImageView) childAt).getImageMatrix().getValues(fArr);
                float f = fArr[0];
                float f2 = fArr[4];
                Drawable drawable = ((ImageView) childAt).getDrawable();
                int intrinsicWidth = drawable.getIntrinsicWidth();
                int intrinsicHeight = drawable.getIntrinsicHeight();
                int round = Math.round(((float) intrinsicWidth) * f);
                int round2 = Math.round(((float) intrinsicHeight) * f2);
                viewHolder.mImage.setImageBitmap(Bitmap.createBitmap(createBitmap, (createBitmap.getWidth() - round) / 2, (createBitmap.getHeight() - round2) / 2, round, round2));
                viewHolder.mImage.setRotationY(childAt.getRotationY());
                viewHolder.mImage.setTag(this.mItemList.get(i));
                viewHolder.mImage.setAlpha(1.0f);
                viewHolder.textView.setImageBitmap(null);
            }
            if (view instanceof AutofitTextRel) {
                if (((AutofitTextRel) view).getTextInfo().getBG_COLOR() != 0) {
                    Bitmap createBitmap2 = Bitmap.createBitmap(150, 150, Config.ARGB_8888);
                    new Canvas(createBitmap2).drawColor(((AutofitTextRel) view).getTextInfo().getBG_COLOR());
                    viewHolder.mImage.setImageBitmap(createBitmap2);
                    viewHolder.mImage.setAlpha(((float) ((AutofitTextRel) view).getTextInfo().getBG_ALPHA()) / 255.0f);
                } else if (((AutofitTextRel) view).getTextInfo().getBG_DRAWABLE().equals("0")) {
                    viewHolder.mImage.setAlpha(1.0f);
                    viewHolder.mImage.setImageResource(R.drawable.trans);
                } else {
                    try {
                        AssetManager assets = this.activity.getAssets();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("background/");
                        stringBuilder.append(((AutofitTextRel) view).getTextInfo().getBG_DRAWABLE());
                        inputStream = assets.open(stringBuilder.toString());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    viewHolder.mImage.setImageBitmap(ImageUtils.getTiledBitmap(BitmapFactory.decodeStream(inputStream), 150, 150));
                    viewHolder.mImage.setAlpha(((float) ((AutofitTextRel) view).getTextInfo().getBG_ALPHA()) / 255.0f);
                }
                View childAt2 = ((AutofitTextRel) view).getChildAt(2);
                Bitmap createBitmap3 = Bitmap.createBitmap(childAt2.getWidth(), childAt2.getHeight(), Config.ARGB_8888);
                childAt2.draw(new Canvas(createBitmap3));
                viewHolder.textView.setImageBitmap(createBitmap3);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (view instanceof ResizableStickerView) {
            if (((ResizableStickerView) view).isMultiTouchEnabled) {
                viewHolder.img_lock.setImageResource(R.drawable.ic_unlock);
            } else {
                viewHolder.img_lock.setImageResource(R.drawable.ic_lock);
            }
        }
        if (view instanceof AutofitTextRel) {
            if (((AutofitTextRel) view).isMultiTouchEnabled) {
                viewHolder.img_lock.setImageResource(R.drawable.ic_unlock);
            } else {
                viewHolder.img_lock.setImageResource(R.drawable.ic_lock);
            }
        }
        viewHolder.img_lock.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                view = view;
                if (view instanceof ResizableStickerView) {
                    if (((ResizableStickerView) view).isMultiTouchEnabled) {
                        view = view;
                        ((ResizableStickerView) view).isMultiTouchEnabled = ((ResizableStickerView) view).setDefaultTouchListener(false);
                        viewHolder.img_lock.setImageResource(R.drawable.ic_lock);
                    } else {
                        view = view;
                        ((ResizableStickerView) view).isMultiTouchEnabled = ((ResizableStickerView) view).setDefaultTouchListener(true);
                        viewHolder.img_lock.setImageResource(R.drawable.ic_unlock);
                    }
                }
                view = view;
                if (view instanceof AutofitTextRel) {
                    if (((AutofitTextRel) view).isMultiTouchEnabled) {
                        view = view;
                        ((AutofitTextRel) view).isMultiTouchEnabled = ((AutofitTextRel) view).setDefaultTouchListener(false);
                        viewHolder.img_lock.setImageResource(R.drawable.ic_lock);
                    } else {
                        view = view;
                        ((AutofitTextRel) view).isMultiTouchEnabled = ((AutofitTextRel) view).setDefaultTouchListener(true);
                        viewHolder.img_lock.setImageResource(R.drawable.ic_unlock);
                    }
                }
                ((GridActivity) ItemAdapter.this.activity).listFragment.getLayoutChild(false);
            }
        });
    }

    public long getUniqueItemId(int i) {
        return ((Long) ((Pair) this.mItemList.get(i)).first).longValue();
    }
}
