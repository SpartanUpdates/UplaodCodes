package com.kotlinz.festivalstorymaker.Preferance;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.Date;

public class ThemeDataPreferences {
    public static final ThemeDataPreferences INSTANCE;

    public long ApiUpdateTime = 1800000L;//After 30 Minute To Update Api Data
    public static String AllModuleData = "AllModule";
    public static String AllModuleDataResponseTime = "AllModuleResponseTime";

    public static String PosterMaker = "PosterMaker";
    public static String PosterMakerResponseTime = "PosterMakerResponseTime";

    public static String PosterMakerTheme = "PosterMakerTheme";
    public static String PosterMakerThemeResponseTime = "PosterMakerThemeResponseTime";

    public static String StoryMaker = "StoryMaker";
    public static String StoryMakerResponseTime = "StoryMakerResponseTime";

    public static String StoryMakerTheme = "StoryMakerTheme";
    public static String StoryMakerThemeResponseTime = "StoryMakerThemeResponseTime";

    public static String QuoteMaker = "QuoteMaker";
    public static String QuoteMakerResponseTime = "QuoteMakerResponseTime";

    public static String QuoteMakerTheme = "QuoteMakerTheme";
    public static String QuoteMakerThemeResponseTime = "QuoteMakerThemeResponseTime";

    public static String CollageMaker = "CollageMaker";
    public static String CollageMakerResponseTime = "CollageMakerResponseTime";

    public static String CollageMakerTheme = "CollageMakerTheme";
    public static String CollageMakerThemeResponseTime = "CollageMakerThemeResponseTime";

    public static String ZoomCollage = "ZoomCollage";
    public static String ZoomCollageResponseTime = "ZoomCollageResponseTime";

    public static String ZoomCollageTheme = "ZoomCollageTheme";
    public static String ZoomcollageThemeResponseTime = "ZoomCollageThemeResponseTime";

    static {
        INSTANCE = new ThemeDataPreferences();
    }

    public SharedPreferences pref;

    public void setDataToOffline(Context context, String response, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(preferencesKey, response);
        editor.apply();
    }

    public void SetApiCallResponseTime(Context context, final Date date, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(preferencesKey, date.getTime());
        editor.apply();
    }

    public String getPreferencesData(Context context, String preferencesKey) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        return pref.getString(preferencesKey, "");
    }

    public long getPreferencesResponseTime(Context context, String preferencesKey, long DefaultValue) {
        pref = PreferenceManager.getDefaultSharedPreferences(context);
        return pref.getLong(preferencesKey, DefaultValue);
    }
}
