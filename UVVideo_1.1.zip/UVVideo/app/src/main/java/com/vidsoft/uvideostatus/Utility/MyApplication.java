package com.vidsoft.uvideostatus.Utility;

import android.app.Application;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;

public class MyApplication extends Application {
    public void onCreate() {
        super.onCreate();
        TypefaceUtil.overrideFont(getApplicationContext(), "SERIF", "helvetica_neue_regular.ttf");
        AdSettings.addTestDevice("7e9eaedc-bf68-41b4-880f-c2d83b0c9f09");
        AudienceNetworkAds.initialize(this);
    }
}
