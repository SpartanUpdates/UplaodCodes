package com.kotlinz.festivalstorymaker.Listener.SetListener;


import android.view.View;
import android.widget.FrameLayout;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class QuoteAddText implements View.OnClickListener {
    public final  FrameLayout frameLayout;
    public final  QuoteMakerDetailActivity activity;

    public QuoteAddText(QuoteMakerDetailActivity quoteMakerDetailActivity, FrameLayout frameLayout) {
        this.activity = quoteMakerDetailActivity;
        this.frameLayout = frameLayout;
    }

    public void onClick(View view) {
        FrameLayout frameLayout = this.frameLayout;
        activity.flStickerView = frameLayout;
        TextStickerViewNew1 d0 = activity.d0(activity, activity.svScroll, frameLayout.getWidth(), activity.flStickerView.getHeight(), "");
        activity.g0(activity.flStickerView, d0);
        d0.setOperationListener(new QuoteTextOptrationListener(activity, d0));
        d0.setOnOutSideTouchListner(new QuoteTouchListener(activity));
        com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.G(activity.U, d0);
        activity.U.add(new com.kotlinz.festivalstorymaker.Models.z.c());
        activity.flStickerView.addView(d0);
        activity.flStickerView.requestLayout();
    }
}
