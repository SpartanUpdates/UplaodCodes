package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;


public class e5 implements View.OnClickListener {
    public e5(final FrameEditorNewDesign frameEditorNewDesign) {
    }

    public void onClick(final View view) {
    }
}
