package com.unitedvideosapp.photovideomaker.videolib.libffmpeg;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Environment;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Map;

public class FileUtils {
    public static File APP_DIRECTORY;
    private static final int DEFAULT_BUFFER_SIZE = 4096;
    private static final int EOF = -1;
    public static final File TEMP_DIRECTORY;
    public static final File TEMP_DIRECTORY_AUDIO;
    public static final File TEMP_IMG_DIRECTORY;
    public static final File TEMP_VID_DIRECTORY;
    static final String ffmpegFileName = "ffmpeg";
    public static final File frameFile;
    public static final String hiddenDirectoryName = ".MyGalaryLock/";
    public static final String hiddenDirectoryNameImage = "Image/";
    public static String hiddenDirectoryNameThumb = ".MyGalaryLock/.thumbnail/";
    public static final String hiddenDirectoryNameThumbImage = ".thumb/Image/";
    public static final String hiddenDirectoryNameThumbVideo = ".thumb/Video/";
    public static final String hiddenDirectoryNameVideo = "Video/";
    public static long mDeleteFileCount = 0L;
    public static File mDownloadDir;
    public static File mSdCard;
    private static File[] mStorageList;
    public static final String rawExternalStorage;
    public static String rawSecondaryStoragesStr;
    public static String unlockDirectoryNameImage = "GalaryLock/Image/";
    public static String unlockDirectoryNameVideo = "GalaryLock/Video/";

    static {
        rawExternalStorage = System.getenv("EXTERNAL_STORAGE");
        FileUtils.rawSecondaryStoragesStr = System.getenv("SECONDARY_STORAGE");
        FileUtils.mSdCard = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
        FileUtils.mDownloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        FileUtils.APP_DIRECTORY = new File(FileUtils.mSdCard, "Video Maker");
        TEMP_DIRECTORY = new File(FileUtils.APP_DIRECTORY, ".temp");
        TEMP_VID_DIRECTORY = new File(FileUtils.TEMP_DIRECTORY, ".temp_vid");
        TEMP_DIRECTORY_AUDIO = new File(FileUtils.APP_DIRECTORY, ".temp_audio");
        TEMP_IMG_DIRECTORY = new File(FileUtils.APP_DIRECTORY, ".temp_image");
        frameFile = new File(FileUtils.APP_DIRECTORY, ".frame.png");
        if (!FileUtils.TEMP_IMG_DIRECTORY.exists()) {
            FileUtils.TEMP_IMG_DIRECTORY.mkdirs();
        }
        if (!FileUtils.TEMP_DIRECTORY.exists()) {
            FileUtils.TEMP_DIRECTORY.mkdirs();
        }
        if (!FileUtils.TEMP_VID_DIRECTORY.exists()) {
            FileUtils.TEMP_VID_DIRECTORY.mkdirs();
        }
    }

    public FileUtils() {
        FileUtils.mDeleteFileCount = 0L;
    }

    static String SHA1(InputStream is) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
            final byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            for (int read; (read = is.read(buffer)) != -1;) {
                messageDigest.update(buffer, 0, read);
            }

            Formatter formatter = new Formatter();
            for (final byte b : messageDigest.digest()) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        } catch (NoSuchAlgorithmException e) {
        } catch (IOException e) {
        } finally {
            Util.close(is);
        }
        return null;
    }

    static String SHA1(String file) {
        InputStream is = null;
        try {
            is = new BufferedInputStream(new FileInputStream(file));
            return SHA1(is);
        } catch (IOException e) {
        } finally {
            Util.close(is);
        }
        return null;
    }



    static boolean copyBinaryFromAssetsToData(final Context context, final String s, final String s2) {
        final File filesDirectory = getFilesDirectory(context);
        try {
            final InputStream open = context.getAssets().open(s);
            final FileOutputStream fileOutputStream = new FileOutputStream(new File(filesDirectory, s2));
            final byte[] array = new byte[4096];
            while (true) {
                final int read = open.read(array);
                if (-1 == read) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            Util.close((OutputStream) fileOutputStream);
            Util.close(open);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public static void copyFile(final File file, final File file2) throws IOException {
        final FileInputStream fileInputStream = new FileInputStream(file);
        final FileOutputStream fileOutputStream = new FileOutputStream(file2);
        final byte[] array = new byte[1024];
        while (true) {
            final int read = fileInputStream.read(array);
            if (read <= 0) {
                break;
            }
            fileOutputStream.write(array, 0, read);
        }
        fileInputStream.close();
        fileOutputStream.close();
    }

    public static boolean deleteFile(final File file) {
        boolean delete = false;
        int i = 0;
        if (file == null) {
            return false;
        }
        if (file.exists()) {
            if (file.isDirectory()) {
                final File[] listFiles = file.listFiles();
                if (listFiles != null && listFiles.length > 0) {
                    while (i < listFiles.length) {
                        final File file2 = listFiles[i];
                        FileUtils.mDeleteFileCount += file2.length();
                        deleteFile(file2);
                        ++i;
                    }
                }
                FileUtils.mDeleteFileCount += file.length();
                return file.delete();
            }
            FileUtils.mDeleteFileCount += file.length();
            delete = file.delete();
        }
        return delete;
    }


    public static void deleteTempDir() {
        final File[] listFiles = FileUtils.TEMP_DIRECTORY.listFiles();
        for (int length = listFiles.length, i = 0; i < length; ++i) {
            final int finalI = i;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    FileUtils.deleteFile(listFiles[finalI]);
                }
            }).start();
        }
    }

    public static boolean deleteThemeDir(final String s) {
        return deleteFile(getImageDirectory(s));
    }


    @SuppressLint({"DefaultLocale"})
    public static String getDuration(long n) {
        if (n < 1000L) {
            return String.format("%02d:%02d", 0, 0);
        }
        final long n2 = n / 1000L;
        n = n2 / 3600L;
        final long n3 = 3600L * n;
        final long n4 = (n2 - n3) / 60L;
        final long n5 = n2 - (n3 + 60L * n4);
        if (n == 0L) {
            return String.format("%02d:%02d", n4, n5);
        }
        return String.format("%02d:%02d:%02d", n, n4, n5);
    }

    public static String getFFmpeg(final Context context) {
        final StringBuilder sb = new StringBuilder();
        sb.append(getFilesDirectory(context).getAbsolutePath());
        sb.append(File.separator);
        sb.append("ffmpeg");
        return sb.toString();
    }

    static String getFFmpeg(Context context, Map<String, String> map) {
        String str = "";
        if (map != null) {
            final Iterator<Map.Entry<String, String>> iterator = map.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append((String) entry.getKey());
                stringBuilder.append("=");
                stringBuilder.append((String) entry.getValue());
                stringBuilder.append(" ");
                str = stringBuilder.toString();
            }
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(getFFmpeg(context));
        return sb.toString();
    }


    static File getFilesDirectory(final Context context) {
        return context.getFilesDir();
    }


    public static File getImageDirectory(final String s) {
        final File file = new File(FileUtils.TEMP_DIRECTORY, s);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static File getImageDirectory(final String s, final int n) {
        final File file = new File(getImageDirectory(s), String.format("IMG_%03d", n));
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

}
