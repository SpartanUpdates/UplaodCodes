package com.kotlinz.festivalstorymaker.Model.CollageMaker;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class CollageResponse {

	@SerializedName("data")
	private ArrayList<CollageMainCategory> data;

	@SerializedName("status")
	private String status;

	public ArrayList<CollageMainCategory> getData(){
		return data;
	}

	public String getStatus(){
		return status;
	}
}