package com.kotlinz.videoeditor.Utils;


import android.os.Environment;


import com.kotlinz.videoeditor.MyApplication.MyApplication;
import com.kotlinz.videoeditor.R;


import java.io.File;

public class Constant {


    public static final File DCIMFolder;
    public static final File DCIMFolder1;
    public static final File DCIMFolder2;
    public static final File DCIMFolder3;
    public static final File DCIMFolder4;
    public static final File DCIMFolder5;
    public static final File DCIMFolder6;
    public static final File DCIMFolder7;
    public static final File DCIMFolder8;
    public static final File DCIMFolder9;
    public static final File DCIMFolder10;
    public static final File DCIMFolder11;


    public static final String FINL_PATH;
    public static int[] IMAGE;
    public static final File MainFileFolder;
    public static final File MainFileFolder1;
    public static final File MainFileFolder2;
    public static final File MainFileFolder3;
    public static final File MainFileFolder4;
    public static final File MainFileFolder5;
    public static final File MainFileFolder6;
    public static final File MainFileFolder7;
    public static final File MainFileFolder8;
    public static final File MainFileFolder9;
    public static final File MainFileFolder10;
    public static final File MainFileFolder11;


    public static final File MyCreation;
    public static final File MyCreation1;
    public static final File MyCreation2;
    public static final File MyCreation3;
    public static final File MyCreation4;
    public static final File MyCreation5;
    public static final File MyCreation6;
    public static final File MyCreation7;
    public static final File MyCreation8;
    public static final File MyCreation9;
    public static final File MyCreation10;
    public static final File MyCreation11;

    public static final String Transition_ThumbNm;
    public static int[] ramdom3dNumbers;
    public static int[] randomNumbers;
    public static String[] themeListhum;

    static {
        FINL_PATH = MyApplication.getInstance().getFilesDir().getAbsolutePath();
        final StringBuilder sb = new StringBuilder();
        sb.append(Constant.FINL_PATH);
        sb.append("/");
        sb.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder));
        MainFileFolder = new File(sb.toString());

        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Constant.FINL_PATH);
        stringBuilder.append("/");
        stringBuilder.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder1));
        MainFileFolder1 = new File(stringBuilder.toString());

        final StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(Constant.FINL_PATH);
        stringBuilder1.append("/");
        stringBuilder1.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder2));
        MainFileFolder2 = new File(stringBuilder1.toString());

        final StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(Constant.FINL_PATH);
        stringBuilder2.append("/");
        stringBuilder2.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder3));
        MainFileFolder3 = new File(stringBuilder2.toString());

        final StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(Constant.FINL_PATH);
        stringBuilder3.append("/");
        stringBuilder3.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder4 = new File(stringBuilder2.toString());

        final StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(Constant.FINL_PATH);
        stringBuilder4.append("/");
        stringBuilder4.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder5 = new File(stringBuilder4.toString());

        final StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append(Constant.FINL_PATH);
        stringBuilder5.append("/");
        stringBuilder5.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder6 = new File(stringBuilder5.toString());

        final StringBuilder stringBuilder6 = new StringBuilder();
        stringBuilder6.append(Constant.FINL_PATH);
        stringBuilder6.append("/");
        stringBuilder6.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder7 = new File(stringBuilder6.toString());

        final StringBuilder stringBuilder7 = new StringBuilder();
        stringBuilder7.append(Constant.FINL_PATH);
        stringBuilder7.append("/");
        stringBuilder7.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder8 = new File(stringBuilder7.toString());

        final StringBuilder stringBuilder8 = new StringBuilder();
        stringBuilder8.append(Constant.FINL_PATH);
        stringBuilder8.append("/");
        stringBuilder8.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder4));
        MainFileFolder9 = new File(stringBuilder8.toString());

        final StringBuilder stringBuilder9 = new StringBuilder();
        stringBuilder9.append(Constant.FINL_PATH);
        stringBuilder9.append("/");
        stringBuilder9.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder10));
        MainFileFolder10 = new File(stringBuilder9.toString());

        final StringBuilder stringBuilder10 = new StringBuilder();
        stringBuilder9.append(Constant.FINL_PATH);
        stringBuilder9.append("/");
        stringBuilder9.append(MyApplication.getInstance().getResources().getString(R.string.MainFolder11));
        MainFileFolder11 = new File(stringBuilder9.toString());


        DCIMFolder = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder1 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder2 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder3 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder4 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder5 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder6 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder7 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder8 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder9 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder10 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());
        DCIMFolder11 = new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/VEditor/").getAbsolutePath());

        MyCreation = new File(Constant.DCIMFolder, MyApplication.getInstance().getResources().getString(R.string.My_creation));
        MyCreation1 = new File(Constant.DCIMFolder1, MyApplication.getInstance().getResources().getString(R.string.My_creation1));
        MyCreation2 = new File(Constant.DCIMFolder2, MyApplication.getInstance().getResources().getString(R.string.My_creation2));
        MyCreation3 = new File(Constant.DCIMFolder3, MyApplication.getInstance().getResources().getString(R.string.My_creation3));
        MyCreation4 = new File(Constant.DCIMFolder4, MyApplication.getInstance().getResources().getString(R.string.My_creation4));
        MyCreation5 = new File(Constant.DCIMFolder5, MyApplication.getInstance().getResources().getString(R.string.My_creation5));
        MyCreation6 = new File(Constant.DCIMFolder6, MyApplication.getInstance().getResources().getString(R.string.My_creation6));
        MyCreation7 = new File(Constant.DCIMFolder7, MyApplication.getInstance().getResources().getString(R.string.My_creation7));
        MyCreation8 = new File(Constant.DCIMFolder8, MyApplication.getInstance().getResources().getString(R.string.My_creation8));
        MyCreation9 = new File(Constant.DCIMFolder9, MyApplication.getInstance().getResources().getString(R.string.My_creation9));
        MyCreation10 = new File(Constant.DCIMFolder10, MyApplication.getInstance().getResources().getString(R.string.My_creation10));
        MyCreation11 = new File(Constant.DCIMFolder11, MyApplication.getInstance().getResources().getString(R.string.My_creation11));

        Transition_ThumbNm = MyApplication.getInstance().getResources().getString(R.string.theme_img_name);


        Constant.ramdom3dNumbers = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
        Constant.randomNumbers = new int[] { 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 };
        Constant.themeListhum = new String[] { "flower_parti" };
    }

    public static String getTime(int i) {
        int i3 = i % 3600;
        return String.format("%02d", Integer.valueOf(i3 / 60)) + ":" + String.format("%02d", Integer.valueOf(i3 % 60));
    }
}
