package com.mbit.VideoMaker.Adapter;


import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.mbit.VideoMaker.Activity.ImageSelectActivity;
import com.mbit.VideoMaker.Interface.OnItemClickListner;
import com.mbit.VideoMaker.Model.ImageInfo;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.View.CircleImageView;
import com.mbit.VideoMaker.View.ObjectScaleAnimation;
import com.mbit.VideoMaker.application.MyApplication;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class AlbumWiseFolder extends RecyclerView.Adapter<AlbumWiseFolder.ViewHolder> {

    public ImageSelectActivity activity;
    public Context context;
    public LayoutInflater layoutInflater;
    private MyApplication application;
    private OnItemClickListner<Object> itemClickListner;

    public AlbumWiseFolder(Context context) {
        this.layoutInflater = LayoutInflater.from(context);
        this.application = MyApplication.getInstance();
        this.context = context;
        this.activity = (ImageSelectActivity) context;
    }

    public static void AnimatedObjectItem(ObjectAnimator objectAnimator, String str, String str2, Path path) {
        ObjectAnimator objectAnimator2 = objectAnimator;
        String str3 = str;
        String str4 = str2;
        Path path2 = path;
        if (str3 != null || str4 != null) {
            PropertyValuesHolder fArr;
            int i = 0;
            PathMeasure pathMeasure = new PathMeasure(path2, false);
            List arrayList = new ArrayList();
            arrayList.add(Float.valueOf(0.0f));
            float f = 0.0f;
            do {
                f += pathMeasure.getLength();
                arrayList.add(Float.valueOf(f));
            } while (pathMeasure.nextContour());
            pathMeasure = new PathMeasure(path2, false);
            int min = Math.min(100, ((int) (2.0f * f)) + 1);
            float[] fArr2 = new float[min];
            float[] fArr3 = new float[min];
            float[] fArr4 = new float[2];
            f /= (float) (min - 1);
            int i2 = 0;
            float f2 = 0.0f;
            int i3 = 0;
            while (true) {
                fArr = null;
                if (i2 >= min) {
                    break;
                }
                pathMeasure.getPosTan(f2, fArr4, null);
                fArr2[i2] = fArr4[i];
                fArr3[i2] = fArr4[1];
                f2 += f;
                int i4 = i3 + 1;
                if (i4 < arrayList.size() && f2 > ((Float) arrayList.get(i4)).floatValue()) {
                    f2 -= ((Float) arrayList.get(i4)).floatValue();
                    pathMeasure.nextContour();
                    i3 = i4;
                }
                i2++;
                i = 0;
            }

            PropertyValuesHolder ofFloat = str3 != null ? PropertyValuesHolder.ofFloat(str3, fArr2) : null;
            if (str4 != null) {
                fArr = PropertyValuesHolder.ofFloat(str4, fArr3);

            }
            if (ofFloat == null) {
                objectAnimator2.setValues(fArr);

            } else if (fArr == null) {
                objectAnimator2.setValues(ofFloat);

            } else {
                objectAnimator2.setValues(ofFloat, fArr);
            }
        }
    }


    public ImageInfo getItem(final int pos) {
        return application.getImageByAlbum(application.getSelectedFolderId()).get(pos);
    }

    public final void AnimatedObjectItemView(View view, AlbumWiseFolder avar, int i) {
        ObjectAnimator ofFloat;
        View view2 = view;
        view2.setDrawingCacheEnabled(true);
        Bitmap drawingCache = view.getDrawingCache();
        RelativeLayout relativeLayout = ((ImageSelectActivity) this.context).rlRootlayout;
        drawingCache = drawingCache != null ? Bitmap.createBitmap(drawingCache) : null;
        view2.setDrawingCacheEnabled(false);
        int[] iArr = new int[2];
        view2.getLocationOnScreen(iArr);
        int[] iArr2 = new int[2];
        View imageView = ((ImageSelectActivity) context).ViewexpandIcon.getImageView();
        imageView.getLocationOnScreen(iArr2);
        CircleImageView circleImageview = new CircleImageView(context);
        circleImageview.setLayoutParams(new LayoutParams(view.getWidth(), view.getHeight()));
        circleImageview.setImageBitmap(drawingCache);
        circleImageview.setX((float) iArr[0]);
        circleImageview.setY((float) iArr[1]);
        relativeLayout.addView(circleImageview);
        float x = circleImageview.getX() + ((float) (circleImageview.getWidth() / 2));
        float y = circleImageview.getY() + ((float) (circleImageview.getHeight() / 2));
        float width = (float) (iArr2[0] + (imageView.getWidth() / 2));
        float height = (float) (iArr2[1] + (imageView.getHeight() / 2));
        float f = (x + width) / 2.0f;
        float f2 = y - 600.0f;
        Path path = new Path();
        path.moveTo(x, y);
        path.cubicTo(x, y, f, f2, width, height);
        String str = "translationY";
        String str2 = "translationX";
        if (Build.VERSION.SDK_INT >= 21) {
            ofFloat = ObjectAnimator.ofFloat(circleImageview, str2, str, path);
        } else {
            ofFloat = new ObjectAnimator();
            ofFloat.setTarget(circleImageview);
            AnimatedObjectItem(ofFloat, str2, str, path);
        }
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(circleImageview, "scaleX", 1.0f, 0.1f);
        ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(circleImageview, "scaleY", 1.0f, 0.1f);
        ObjectAnimator ofFloat4 = ObjectAnimator.ofFloat(circleImageview, "pivotX", 0.5f, 0.05f);
        ObjectAnimator ofFloat5 = ObjectAnimator.ofFloat(circleImageview, "pivotY", 0.5f, 0.05f);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.setDuration(700);
        animatorSet.playTogether(ofFloat, ofFloat2, ofFloat3, ofFloat4, ofFloat5);
        animatorSet.addListener(new ObjectScaleAnimation(avar, circleImageview));
        animatorSet.start();


    }

    public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
        this.itemClickListner = clickListner;
    }


    public int getItemCount() {
        return application.getImageByAlbum(application.getSelectedFolderId()).size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(this, this.layoutInflater.inflate(R.layout.items_by_folder, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int pos) {
        ImageView imageView;
        boolean z;
        final ImageInfo imageInfo = getItem(pos);
        Glide.with(activity).load(imageInfo.getThumbbailImage()).into(holder.cvThumb);
        if (imageInfo.NoOfImage == 0) {
            imageView = holder.cvThumb;
            z = false;
        } else {
            imageView = holder.cvThumb;
            z = true;
        }
        imageView.setSelected(z);
        holder.cvThumb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.cvThumb.getDrawable() == null) {
                    Toast.makeText(application, "Image currpted or not support.", Toast.LENGTH_LONG).show();
                    return;
                }
                if (application.getSelectedImageslist().size() < MyApplication.TotalSelectedImage) {
                    application.addSelectedImage(imageInfo);
                    notifyItemChanged(pos);
                    AnimatedObjectItemView(holder.cvThumb, holder.albumWiseFolder, pos);
                    activity.Done();
                } else {
                    Toast.makeText(application, "Please Select only " + MyApplication.TotalSelectedImage + "Image", Toast.LENGTH_SHORT).show();
                }
                if (itemClickListner != null) {
                    itemClickListner.onItemClick(v, imageInfo);
                }
            }
        });
        holder.cvThumb.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final Dialog dialog = new Dialog(activity, R.style.AppImageAlertDialog);
                View inflate = activity.getLayoutInflater().inflate(R.layout.dialog_with_image, null);
                dialog.setContentView(inflate);
                ImageView imageView = inflate.findViewById(R.id.ivImage);
                imageView.setImageURI(Uri.fromFile(new File(imageInfo.ImagePath)));
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();

                    }
                });
                dialog.getWindow().getDecorView().setSystemUiVisibility(5892);
                dialog.getWindow().clearFlags(8);
                dialog.show();
                return false;
            }
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final AlbumWiseFolder albumWiseFolder;
        public CircleImageView cvThumb;
        public View view;

        public ViewHolder(AlbumWiseFolder hVar, View view) {
            super(view);
            this.albumWiseFolder = hVar;
            this.view = view;
            this.cvThumb = view.findViewById(R.id.iv_image);
        }

        public void onItemClick(View view, Object item) {
            if (itemClickListner != null) {
                itemClickListner.onItemClick(view, item);
            }
        }
    }

}
