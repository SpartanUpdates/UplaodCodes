package com.name.nameart.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.name.nameart.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ImageTextShader extends RecyclerView.Adapter<ImageTextShader.ViewHolder> {
    Context context;
    int index = -1;
    OnSelect onSelect;
    List<String> textures;

    public interface OnSelect {
        void onSelectoverlay(Bitmap bitmap);
    }

    public ImageTextShader(Context context2, OnSelect onSelect2) {
        this.context = context2;
        this.onSelect = onSelect2;
        try {
            List<String> list = this.textures;
            if (list != null && list.size() > 0) {
                this.textures.clear();
                this.textures.addAll(Arrays.asList(this.context.getAssets().list("imageshader")));
            }
            ArrayList arrayList = new ArrayList();
            this.textures = arrayList;
            arrayList.addAll(Arrays.asList(this.context.getAssets().list("imageshader")));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.color_adapter, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        try {
            viewHolder.color_img_row.setImageDrawable(null);
            RequestManager with = Glide.with(this.context);
            with.load(Uri.parse("file:///android_asset/imageshader/" + this.textures.get(i))).into(viewHolder.color_img_row);
            viewHolder.color_img_row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    InputStream inputStream;
                    ImageTextShader.this.index = i;
                    try {
                        AssetManager assets = ImageTextShader.this.context.getAssets();
                        inputStream = assets.open("imageshader/" + ImageTextShader.this.textures.get(i));
                    } catch (IOException e) {
                        e.printStackTrace();
                        inputStream = null;
                    }
                    ImageTextShader.this.onSelect.onSelectoverlay(BitmapFactory.decodeStream(inputStream));
                    ImageTextShader.this.notifyDataSetChanged();
                }
            });
            if (this.index == i) {
                viewHolder.row_bg.setBackgroundResource(R.drawable.bg_selected);
            } else {
                viewHolder.row_bg.setBackgroundColor(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return this.textures.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView color_img_row;
        public ConstraintLayout row_bg;

        public ViewHolder(View view) {
            super(view);
            this.color_img_row = (ImageView) view.findViewById(R.id.color_img_row);
            this.row_bg = (ConstraintLayout) view.findViewById(R.id.row_bg);
        }

        public ImageView getImage() {
            return this.color_img_row;
        }
    }
}
