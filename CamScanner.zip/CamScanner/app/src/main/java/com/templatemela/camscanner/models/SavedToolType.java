package com.templatemela.camscanner.models;

public enum SavedToolType {
    EDIT,
    OPENPDF,
    NAME,
    ROTATE,
    NOTE,
    ImageToText,
    SHARE,
    DELETE
}
