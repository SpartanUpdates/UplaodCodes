package com.kotlinz.videoCollage.flying.puzzle.slant;

import android.graphics.PointF;

class CrossoverPointF extends PointF {
    SlantLine horizontal;
    SlantLine vertical;

    CrossoverPointF() {
    }

    CrossoverPointF(float f, float f2) {
        this.x = f;
        this.y = f2;
    }

    CrossoverPointF(SlantLine slantLine, SlantLine slantLine2) {
        this.horizontal = slantLine;
        this.vertical = slantLine2;
    }

    /* Access modifiers changed, original: 0000 */
    public void update() {
        SlantLine slantLine = this.horizontal;
        if (slantLine != null) {
            SlantLine slantLine2 = this.vertical;
            if (slantLine2 != null) {
                SlantUtils.intersectionOfLines(this, slantLine, slantLine2);
            }
        }
    }
}
