package com.example.logomaker;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.os.Build.VERSION_CODES.Q;

public class SpleshActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splesh);
        if (getSupportActionBar()!=null)
        {
           getSupportActionBar().hide();
        }

        if (Build.VERSION.SDK_INT >= Q) {
            checkMultiplePermissions();
        } else {
            callfordata();
        }
    }

    private void checkMultiplePermissions() {
        if (Build.VERSION.SDK_INT >= Q) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            if (!addPermission(arrayList2, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                arrayList.add("Read Storage");
            }
            if (!addPermission(arrayList2, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            {
                arrayList.add("Write Storage");
            }

            if (arrayList2.size() > 0) {
                requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 111);
                return;
            }
            callfordata();
        }
    }

    private boolean addPermission(List<String> list, String str) {
        if (Build.VERSION.SDK_INT >= Q && checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
            list.add(str);
            if (!shouldShowRequestPermissionRationale(str)) {
                return false;
            }
        }
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 111) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        HashMap hashMap = new HashMap();
        int i2 = 0;
        String str = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        hashMap.put(str, Integer.valueOf(0));
        String str2 =Manifest.permission.READ_EXTERNAL_STORAGE;
        hashMap.put(str2, Integer.valueOf(0));

        while (i2 < strArr.length)
        {
            hashMap.put(strArr[i2], Integer.valueOf(iArr[i2]));
            i2++;
        }
        if (((Integer) hashMap.get(str2)).intValue() == 0 && ((Integer) hashMap.get(str)).intValue() == 0) {
            callfordata();
        } else if (Build.VERSION.SDK_INT >= Q) {
            Toast.makeText(getApplicationContext(), "My App cannot run without Storage Permissions.\nRelaunch My App or allow permissions in Applications Settings", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void callfordata()
    {
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run() {
                Intent intent=new Intent(SpleshActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        },4000);
    }
}