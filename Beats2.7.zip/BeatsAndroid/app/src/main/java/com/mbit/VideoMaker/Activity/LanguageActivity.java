package com.mbit.VideoMaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.mbit.VideoMaker.Adapter.SelectLanguageAdapter;
import com.mbit.VideoMaker.Extra.d;
import com.mbit.VideoMaker.Extra.h;
import com.mbit.VideoMaker.Model.LanguageModel;
import com.mbit.VideoMaker.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class LanguageActivity extends AppCompatActivity {

    Activity activity = LanguageActivity.this;
    TextView tvSelectDone;
    RecyclerView rvlanguage;
    LinearLayout layoutRetry;
    RelativeLayout layoutLoading;
    AdRequest adRequest;
    AdView adView;
    GridLayoutManager gridLayoutManager;
    SelectLanguageAdapter languageAdapter;
    private ArrayList<LanguageModel> languageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);
        BindView();
        AddLanguageList();
        loadAd();
        SetAdapter();
        getArrayOfApp();
    }

    public void getArrayOfApp() {
        String[] stringsArry = {
                "Photo Slideshow with Music: Video Status Maker",
                "Music Video Maker: Slideshow",
                "Photo Video Editor",
                "MBit Music : Particle.ly Video Status Maker",
                "MBit",
                "Particle.ly",
                "Video Editor",
                "Tiktok Video Maker",
                "Photo Video Maker",
                "Video Status Maker",
                "Image to Video Maker",
                "bits video maker",
                "bits",
                "Particle.ly : bits",
                "Bets : Video Status Maker",
                "Beats",
                "Video Editor With Music App, Video Maker Of Photo"
        };
    }

    private void AddLanguageList() {
        languageList.add(0, new LanguageModel("35", "Rajashthahni"));
        languageList.add(1, new LanguageModel("27", "Malayalam"));
        languageList.add(2, new LanguageModel("34", "Marathi"));
        languageList.add(3, new LanguageModel("33", "Tamil"));
        languageList.add(4, new LanguageModel("29", "kannada"));
        languageList.add(5, new LanguageModel("32", "Telugu"));
        languageList.add(6, new LanguageModel("30", "Bengali"));
        languageList.add(7, new LanguageModel("31", "Bhojpuri"));
        languageList.add(8, new LanguageModel("28", "Islamic"));
        languageList.add(9, new LanguageModel("24", "English"));
        languageList.add(10, new LanguageModel("22", "Hindi"));
        languageList.add(11, new LanguageModel("25", "Gujarati"));
        languageList.add(12, new LanguageModel("36", "Punjabi"));
        SaveLanInPref(LanguageActivity.this, languageList);
    }

    private void BindView() {
        tvSelectDone = findViewById(R.id.tv_lan_select_done);
        rvlanguage = findViewById(R.id.rvLanguageList);
        layoutRetry = findViewById(R.id.llRetry);
        layoutLoading = findViewById(R.id.rl_loading_pager);
        tvSelectDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (languageList != null) {
                        final StringBuilder sb = new StringBuilder();
                        for (final LanguageModel languageModel : languageList) {
                            if (languageModel.d) {
                                sb.append(languageModel.LanId);
                                sb.append(",");
                            }
                        }
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(sb.length());
                        Log.e("Lan", sb2.toString());
                        if (sb.length() != 0) {
                            if (!d.a(activity).a("pref_key_language_list", "1,2,3,4").equals(sb.substring(0, sb.length() - 1))) {
//                                if (MyApplication.q != null) {
//                                    MyApplication.q.finish();
//                                }
                                h.b();
                            }
                            d.a(activity).c("pref_key_language_list", sb.substring(0, sb.length() - 1));
                            d.a(activity).b("pref_key_is_language_set", true);
                            startActivity(new Intent(activity, HomeActivity.class));
                            finish();
                            return;
                        }
                        Toast.makeText(activity, "Please Select any language", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ex) {
                    final StringBuilder sb3 = new StringBuilder("Error : ");
                    sb3.append(ex.getMessage());
                    Log.e("LangError", sb3.toString());
                    ex.printStackTrace();
                }
            }
        });
    }

    private void SaveLanInPref(LanguageActivity selectCountryAndLanguage, final ArrayList<LanguageModel> list) {
        final String[] split = d.a(selectCountryAndLanguage).a("pref_key_language_list", "22").split(",");
        languageList = new ArrayList<>();
        for (int length = split.length, i = 0; i < length; ++i) {
            Log.e("TAG", "Language Split" + split[i]);
        }
        for (final LanguageModel languageModel : list) {
            languageModel.d = Arrays.asList(split).contains(String.valueOf(languageModel.LanId));
            languageList.add(languageModel);
        }
        Collections.sort(languageList, new Comparator<LanguageModel>() {

            @Override
            public int compare(LanguageModel obj, LanguageModel obj2) {
                return Boolean.compare(obj2.d, obj.d);
            }
        });
    }

    private void SetAdapter() {
        gridLayoutManager = new GridLayoutManager(activity, 2);
        languageAdapter = new SelectLanguageAdapter(activity, languageList);
        rvlanguage.setLayoutManager(gridLayoutManager);
        rvlanguage.setAdapter(languageAdapter);
    }

    private void loadAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
