package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import androidx.appcompat.app.AppCompatActivity;
import org.jetbrains.annotations.NotNull;

public class VehicleExpenseCategory extends AppCompatActivity implements View.OnClickListener {
    private Activity activity = VehicleExpenseCategory.this;

    ImageView iv_accessories;
    ImageView iv_carfuel;
    ImageView iv_cleanlines;
    ImageView iv_maintenance;
    ImageView iv_otherexpense;
    ImageView iv_back, iv_home;
    TextView title_tv;

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense_category);
        BindView();
        BannerAds();
        InterAds();
        DarkTheame darkTheame = new DarkTheame(VehicleExpenseCategory.this);
        if (darkTheame.modeData().equals("nightMode")) {
            title_tv.setTextColor(Color.parseColor("#FFFFFF"));
            iv_accessories.setImageResource(R.drawable.ic_accessoriestunning_selector_dark);
            iv_cleanlines.setImageResource(R.drawable.ic_cleanlinesandcomfort_selector_dark);
            iv_otherexpense.setImageResource(R.drawable.ic_other_expense_selector_dark);
            iv_carfuel.setImageResource(R.drawable.ic_carfuel_selector_dark);
            iv_maintenance.setImageResource(R.drawable.ic_maintenence_selector_dark);
        }
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                Intent intent;
                switch (id) {
                    case 1:
                        startActivity(new Intent(VehicleExpenseCategory.this, VehicleExpenseActivity.class));
                        finish();
                        break;
                    case 2:
                        startActivity(new Intent(VehicleExpenseCategory.this, MainActivity.class));
                        finish();
                        break;
                    case 3:
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Accessories & Tuning");
                        intent.putExtra("categoryimg", R.drawable.ic_accessories_tuning);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                        break;
                    case 4:
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Cleanlines & comfort");
                        intent.putExtra("categoryimg", R.drawable.ic_cleanlines_comfort);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                        break;
                    case 5:
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Other expense");
                        intent.putExtra("categoryimg", R.drawable.ic_otherexpense);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                        break;
                    case 6:
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Car Fuel");
                        intent.putExtra("categoryimg", R.drawable.ic_carfuel);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                        break;
                    case 7:
                        intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                        intent.putExtra("categoryname", "Maintenance");
                        intent.putExtra("categoryimg", R.drawable.ic_maintenance);
                        intent.putExtra("btn", "SAVE");
                        startActivity(intent);
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }

    public void BindView() {
        iv_accessories = findViewById(R.id.iv_accessories);
        iv_carfuel = findViewById(R.id.iv_carfuel);
        iv_cleanlines = findViewById(R.id.iv_cleanlines);
        iv_maintenance = findViewById(R.id.iv_maintenance);
        iv_otherexpense = findViewById(R.id.iv_otherexpense);
        iv_back = findViewById(R.id.iv_back);
        title_tv = findViewById(R.id.title_tv);
        iv_home = findViewById(R.id.iv_home);

        iv_back.setOnClickListener(this);
        iv_home.setOnClickListener(this);
        iv_accessories.setOnClickListener(this);
        iv_carfuel.setOnClickListener(this);
        iv_cleanlines.setOnClickListener(this);
        iv_maintenance.setOnClickListener(this);
        iv_otherexpense.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.iv_accessories:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 3;
                    interstitialAd.show();
                } else {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Accessories & Tuning");
                    intent.putExtra("categoryimg", R.drawable.ic_accessories_tuning);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                }
                break;

            case R.id.iv_cleanlines:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 4;
                    interstitialAd.show();
                } else {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Cleanlines & comfort");
                    intent.putExtra("categoryimg", R.drawable.ic_cleanlines_comfort);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                }
                break;

            case R.id.iv_carfuel:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 6;
                    interstitialAd.show();
                } else {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Car Fuel");
                    intent.putExtra("categoryimg", R.drawable.ic_carfuel);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                }
                break;

            case R.id.iv_maintenance:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 7;
                    interstitialAd.show();
                } else {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Maintenance");
                    intent.putExtra("categoryimg", R.drawable.ic_maintenance);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                }
                break;

            case R.id.iv_otherexpense:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 5;
                    interstitialAd.show();
                } else {
                    intent = new Intent(VehicleExpenseCategory.this, VehicleExpenseDetailAtivity.class);
                    intent.putExtra("categoryname", "Other expense");
                    intent.putExtra("categoryimg", R.drawable.ic_otherexpense);
                    intent.putExtra("btn", "SAVE");
                    startActivity(intent);
                }
                break;

            case R.id.iv_back:
                onBackPressed();
                break;

            case R.id.iv_home:
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 2;
                    interstitialAd.show();
                } else {
                    startActivity(new Intent(VehicleExpenseCategory.this, MainActivity.class));
                    finish();
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(VehicleExpenseCategory.this, VehicleExpenseActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}