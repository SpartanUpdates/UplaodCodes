package com.esc.socialmediacleaner.datastructure;

public class PathData {
    public String path;
    public PathType pathType;

    public PathData(String str, PathType pathType) {
        this.pathType = pathType;
        this.path = str;
    }
}
