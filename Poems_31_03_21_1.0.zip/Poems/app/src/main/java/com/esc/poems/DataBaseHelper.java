package com.esc.poems;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    static final boolean assertionsDisabled = false;
    private static String DB_NAME = "wishafriend";
    private static String DB_PATH = "";
    private static String TAG = "DataBaseHelper";
    private final Context mContext;
    private SQLiteDatabase mDataBase;
    private ArrayList<String> mid;

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {

    }

    DataBaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.mContext = context;
        String str = "/databases/";
        StringBuilder stringBuilder;
        if (VERSION.SDK_INT >= 17) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(context.getApplicationInfo().dataDir);
            stringBuilder.append(str);
            DB_PATH = stringBuilder.toString();
            return;
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("/data/data/");
        stringBuilder.append(context.getPackageName());
        stringBuilder.append(str);
        DB_PATH = stringBuilder.toString();
    }


    public void createDataBase() {
        String str;
        StringBuilder stringBuilder;
        String str2 = "";
        if (!checkDataBase()) {
            try {
                getReadableDatabase();
                close();
            } catch (Exception e) {
                str = TAG;
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(e.getMessage());
                Log.e(str, stringBuilder.toString());
            }
            try {
                copyDataBase();
                Log.e(TAG, "createDatabase database created");
                int i = 0;
                while (i < this.mid.size()) {
                    try {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("favorite", Integer.valueOf(1));
                        SQLiteDatabase writableDatabase = getWritableDatabase();
                        this.mDataBase = writableDatabase;
                        String str3;
                        StringBuilder stringBuilder2;
                        try {
                            String str4 = "message";
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("msg_id=");
                            stringBuilder3.append((String) this.mid.get(i));
                            int update = writableDatabase.update(str4, contentValues, stringBuilder3.toString(), null);
                            str3 = TAG;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("favorite copied done = ");
                            stringBuilder2.append(update);
                            Log.e(str3, stringBuilder2.toString());
                        } catch (Exception e2) {
                            str3 = TAG;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str2);
                            stringBuilder2.append(e2.getMessage());
                            Log.e(str3, stringBuilder2.toString());
                        }
                        i++;
                    } catch (Exception e3) {
                        str = TAG;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str2);
                        stringBuilder.append(e3.getMessage());
                        Log.e(str, stringBuilder.toString());
                        return;
                    }
                }
            } catch (IOException unused) {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }

    private boolean checkDataBase() {
        String str;
        StringBuilder stringBuilder;
        String str2 = "";
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(DB_PATH);
        stringBuilder2.append(DB_NAME);
        File file = new File(stringBuilder2.toString());
        if (file.exists()) {
            try {
                this.mid = new ArrayList();
                SQLiteDatabase readableDatabase = getReadableDatabase();
                this.mDataBase = readableDatabase;
                try {
                    Cursor rawQuery = readableDatabase.rawQuery("select msg_id from message where favorite=1", null);
                    while (rawQuery.moveToNext()) {
                        this.mid.add(rawQuery.getString(0));
                    }
                    rawQuery.close();
                } catch (Exception e) {
                    str = TAG;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(e.getMessage());
                    Log.e(str, stringBuilder.toString());
                }
                this.mDataBase.close();
            } catch (Exception e2) {
                str = TAG;
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(e2.getMessage());
                Log.e(str, stringBuilder.toString());
            }
        }
        file.delete();
        return file.exists();
    }

    private void copyDataBase() throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(stringBuilder.toString());
        byte[] bArr = new byte[9216];
        InputStream open = this.mContext.getAssets().open("waf");
        while (open.read(bArr) > 0) {
            fileOutputStream.write(bArr);
        }
        fileOutputStream.flush();
        fileOutputStream.close();
        open.close();
    }

    public boolean openDataBase() throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DB_PATH);
        stringBuilder.append(DB_NAME);
        SQLiteDatabase openDatabase = SQLiteDatabase.openDatabase(stringBuilder.toString(), null, 268435456);
        this.mDataBase = openDatabase;
        return openDatabase != null;
    }

    public synchronized void close() {
        if (this.mDataBase != null) {
            this.mDataBase.close();
        }
        super.close();
    }


    public ArrayList<String> getCategoryid(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        this.mDataBase = getReadableDatabase();
        Cursor cursor = null;
        for (String str : strArr) {
            SQLiteDatabase sQLiteDatabase = this.mDataBase;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("select c_id from category where category=\"");
            stringBuilder.append(str);
            stringBuilder.append("\"");
            cursor = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
            while (cursor.moveToNext()) {
                arrayList.add(cursor.getString(0));
            }
        }
        cursor.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getSubCategory(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select p.pg_title from pageinfo p,categorydetails d where p.pg_id=d.sc_id AND d.c_id=");
        stringBuilder.append(i);
        stringBuilder.append(" AND p.pg_title LIKE '%poem%' group by pg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getMessagesCount(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select count(msg_id) from messagedetail where pg_id IN(select p.pg_id from pageinfo p,categorydetails d where p.pg_id=d.sc_id AND d.c_id=");
        stringBuilder.append(i);
        stringBuilder.append(" AND p.pg_title LIKE '%poem%') group by pg_id ");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        Log.e("COUNT MESAge", arrayList.toString());
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getSubCategoryId(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select p.pg_id from pageinfo p,categorydetails d where p.pg_id=d.sc_id AND d.c_id=");
        stringBuilder.append(i);
        stringBuilder.append(" AND p.pg_title LIKE '%poem%'   group by pg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getMessages(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT msg FROM message WHERE msg_id IN (SELECT msg_id FROM messagedetail WHERE pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id DESC");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getMessagesId(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT msg_id FROM message WHERE msg_id IN (SELECT msg_id FROM messagedetail WHERE pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id DESC");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public boolean updateFavorite(int i, int i2) {
        String str = " ";
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("favorite", Integer.valueOf(i));
            SQLiteDatabase writableDatabase = getWritableDatabase();
            this.mDataBase = writableDatabase;
            String str2 = "message";
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("msg_id=");
            stringBuilder.append(i2);
            int update = writableDatabase.update(str2, contentValues, stringBuilder.toString(), null);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("informationupdated ");
            stringBuilder2.append(update);
            stringBuilder2.append(str);
            stringBuilder2.append(i2);
            stringBuilder2.append(str);
            stringBuilder2.append(i);
            Log.d("Update", stringBuilder2.toString());
            return true;
        } catch (Exception unused) {
            return false;
        }
    }


    public ArrayList<Integer> getFavorite(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT favorite FROM message WHERE msg_id IN (SELECT msg_id FROM messagedetail WHERE pg_id=");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id DESC");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getFavorite() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("select favorite from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public int getFav(int i) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select favorite from message where msg_id=");
        stringBuilder.append(i);
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        int i2 = 0;
        while (rawQuery.moveToNext()) {
            i2 = Integer.parseInt(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return i2;
    }


    public ArrayList<String> getFavoriteMessages() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("select msg from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getFavoriteMessagesid() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("select msg_id from message where favorite=1", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public String getFavSection(int i) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select sectionid from pageinfo where pg_id =(select pg_id from messagedetail where msg_id=");
        stringBuilder.append(i);
        stringBuilder.append(")");
        String stringBuilder2 = stringBuilder.toString();
        String str = null;
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder2, null);
        while (rawQuery.moveToNext()) {
            str = rawQuery.getString(0);
        }
        rawQuery.close();
        this.mDataBase.close();
        return str;
    }


    public ArrayList<String> getTopCategories() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("Select category from topcat order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getTopCategoriesUnlockKey() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("Select unlockkey from topcat order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getTopMessages(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg from message where msg_id IN (select msg_id from topcat_msg where cat_id = ");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getTopMessagesId(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select msg_id from message where msg_id IN (select msg_id from topcat_msg where cat_id = ");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<Integer> getTopFavMessages(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select favorite from message where msg_id IN (select msg_id from topcat_msg where cat_id = ");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getTopMessagesImage(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select image from message where msg_id IN (select msg_id from topcat_msg where cat_id = ");
        stringBuilder.append(i);
        stringBuilder.append(") ORDER by msg_id");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getTopMessagesUrl(int i) {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select p.pg_url from pageinfo p, messagedetail d where p.pg_id = d.pg_id AND d.msg_id IN (select msg_id from message where msg_id IN (select msg_id from topcat_msg where cat_id = ");
        stringBuilder.append(i);
        stringBuilder.append(" ORDER by msg_id) ORDER by msg_id)");
        Cursor rawQuery = readableDatabase.rawQuery(stringBuilder.toString(), null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getUsersPoems() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("SELECT poems FROM userspoems order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<Integer> getUsersPoemsId() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("SELECT id FROM userspoems order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(Integer.valueOf(rawQuery.getInt(0)));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getUsersName() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("SELECT usersname FROM userspoems order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }


    public ArrayList<String> getUsersLocation() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        this.mDataBase = readableDatabase;
        Cursor rawQuery = readableDatabase.rawQuery("SELECT location FROM userspoems order by id", null);
        while (rawQuery.moveToNext()) {
            arrayList.add(rawQuery.getString(0));
        }
        rawQuery.close();
        this.mDataBase.close();
        return arrayList;
    }
}
