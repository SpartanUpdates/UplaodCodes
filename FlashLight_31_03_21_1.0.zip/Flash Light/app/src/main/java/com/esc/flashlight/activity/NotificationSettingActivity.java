package com.esc.flashlight.activity;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.esc.flashlight.App.APP;
import com.esc.flashlight.R;
import com.esc.flashlight.util.FALib;
import com.esc.flashlight.util.PrefManager;
import com.esc.flashlight.view.StrobeSettingView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;


public class NotificationSettingActivity extends BaseActivity {
    Activity activity = NotificationSettingActivity.this;
    private TextView btnTest;
    private int intervalOff;
    private int intervalOn;
    private PrefManager pref;
    private StrobeSettingView ssvCount;
    private StrobeSettingView ssvOff;
    private StrobeSettingView ssvOn;
    private int strobeCount;
    ImageView ivback;
    TextView tvtitle;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private class MyClickListener implements OnClickListener {
        private MyClickListener() {
        }

        public void onClick(View view) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.statusbar");
        }
    }

    private class MyCountChangeListener implements OnSeekBarChangeListener {
        private MyCountChangeListener() {

        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            NotificationSettingActivity.this.strobeCount = i + 1;
            NotificationSettingActivity.this.pref.setStrobeCountStatusBar(NotificationSettingActivity.this.strobeCount);
            NotificationSettingActivity notificationSettingActivity = NotificationSettingActivity.this;
            notificationSettingActivity.displayStrobeCount(notificationSettingActivity.strobeCount);
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }
    }

    private class MyOffChangeListener implements OnSeekBarChangeListener {
        private MyOffChangeListener() {
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            NotificationSettingActivity.this.intervalOff = i + 1;
            NotificationSettingActivity.this.pref.setOffIntervalStatusBar(NotificationSettingActivity.this.intervalOff);
            NotificationSettingActivity notificationSettingActivity = NotificationSettingActivity.this;
            notificationSettingActivity.displayIntervalOff(notificationSettingActivity.intervalOff);
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }
    }

    private class MyOnChangeListener implements OnSeekBarChangeListener {
        private MyOnChangeListener() {
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            NotificationSettingActivity.this.intervalOn = i + 1;
            NotificationSettingActivity.this.pref.setOnIntervalStatusBar(NotificationSettingActivity.this.intervalOn);
            NotificationSettingActivity notificationSettingActivity = NotificationSettingActivity.this;
            notificationSettingActivity.displayIntervalOn(notificationSettingActivity.intervalOn);
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            FALib.sendBroadcastFlashActionIntent(NotificationSettingActivity.this.getApplicationContext(), "flash.light.shine.off");
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.av_setting_strobe);
        initDatas();
        initViews();
        BannerAds();
    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 82) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            finish();
        }
        return true;
    }


    public void onPause() {
        super.onPause();
        FALib.sendBroadcastFlashActionIntent(getApplicationContext(), "flash.light.shine.off");
    }

    private void initDatas() {
        PrefManager prefManager = APP.getPrefManager();
        this.pref = prefManager;
        this.intervalOn = prefManager.getOnIntervalStatusBar();
        this.intervalOff = this.pref.getOffIntervalStatusBar();
        this.strobeCount = this.pref.getStrobeCountStatusBar();
    }

    private void initViews() {
        ivback=findViewById(R.id.iv_back);
        tvtitle=findViewById(R.id.tv_title);
        TextView textView = findViewById(R.id.btn_test);
        this.btnTest = textView;
        textView.setOnClickListener(new MyClickListener());
        this.ssvOn = findViewById(R.id.ssv_on);
        this.ssvOff = findViewById(R.id.ssv_off);
        this.ssvCount = findViewById(R.id.ssv_count);
        this.ssvOn.setMax(29);
        this.ssvOff.setMax(29);
        this.ssvCount.setMax(29);
        this.ssvOn.setProgress(this.intervalOn);
        this.ssvOff.setProgress(this.intervalOff);
        this.ssvCount.setProgress(this.strobeCount);
        this.ssvOn.setOnSeekBarChangeListener(new MyOnChangeListener());
        this.ssvOff.setOnSeekBarChangeListener(new MyOffChangeListener());
        this.ssvCount.setOnSeekBarChangeListener(new MyCountChangeListener());
        Resources resources = getResources();
        this.ssvOn.setTitle(resources.getString(R.string.setting_time_on));
        this.ssvOff.setTitle(resources.getString(R.string.setting_time_off));
        this.ssvCount.setTitle(resources.getString(R.string.setting_strobe_count));
        displayIntervalOn(this.intervalOn);
        displayIntervalOff(this.intervalOff);
        displayStrobeCount(this.strobeCount);
        tvtitle.setText(getString(R.string.main_changed_status_bar));
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void displayStrobeCount(int i) {
        this.ssvCount.setDesc(new StringBuilder(String.valueOf(i)).append(getResources().getString(R.string.setting_times)).toString());
    }

    private void displayIntervalOff(int i) {
        this.ssvOff.setDesc(new StringBuilder(String.valueOf(((long) i) * 50)).append("ms").toString());
    }

    private void displayIntervalOn(int i) {
        this.ssvOn.setDesc(new StringBuilder(String.valueOf(((long) i) * 50)).append("ms").toString());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
