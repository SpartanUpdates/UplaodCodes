package com.esc.fontappstylish.FontColl;

import com.esc.fontappstylish.utils.FontInter;
import com.esc.fontappstylish.utils.FontInter.DefaultImpls;

public class Font_3 implements FontInter {
    public CharSequence[] getLowercase() {
        return new CharSequence[]{"a♥", "b♥", "c♥", "d♥", "e♥", "f♥", "g♥", "h♥", "i♥", "j♥", "k♥", "l♥", "m♥", "n♥", "o♥", "p♥", "q♥", "r♥", "s♥", "t♥", "u♥", "v♥", "w♥", "x♥", "y♥", "z♥"};
    }

    public String getName() {
        return "A♥B♥C♥";
    }

    public CharSequence[] getUppercase() {
        return new CharSequence[]{"A♥", "B♥", "C♥", "D♥", "E♥", "F♥", "G♥", "H♥", "I♥", "J♥", "K♥", "L♥", "M♥", "N♥", "O♥", "P♥", "Q♥", "R♥", "S♥", "T♥", "U♥", "V♥", "W♥", "X♥", "Y♥", "Z♥"};
    }

    public float getExtraPaddingDownFactor() {
        return DefaultImpls.getExtraPaddingDownFactor(this);
    }

    public float getSizeFactorButton() {
        return DefaultImpls.getSizeFactorButton(this);
    }

    public float getSizeFactorKeys() {
        return DefaultImpls.getSizeFactorKeys(this);
    }

    public boolean isUpsideDown() {
        return DefaultImpls.isUpsideDown(this);
    }

    public CharSequence letter(int i, boolean z) {
        return DefaultImpls.letter(this, i, z);
    }
}
