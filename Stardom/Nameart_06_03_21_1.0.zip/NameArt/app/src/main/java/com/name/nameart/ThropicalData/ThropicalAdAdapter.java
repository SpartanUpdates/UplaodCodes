package com.name.nameart.ThropicalData;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.name.nameart.R;

import java.util.ArrayList;

public class ThropicalAdAdapter extends RecyclerView.Adapter<ThropicalAdAdapter.AppListViewHolder>
{
    ArrayList<ThropicalDataList> appLists = new ArrayList();
    Context context;
    LayoutInflater layoutInflater;
    ArrayList<ThropicalDataList>arrayList;

    public ThropicalAdAdapter(Context context, ArrayList<ThropicalDataList> arrayList) {
        this.context=context;
        this.appLists=arrayList;
    }

    class AppListViewHolder extends ViewHolder {
        ImageView applogo;
        TextView appname;
        LinearLayout getapk;
        LinearLayout ll_app;
        LinearLayout llbg;

        public AppListViewHolder(View view) {
            super(view);
            this.applogo = (ImageView) view.findViewById(R.id.applogo);
            this.appname = (TextView) view.findViewById(R.id.appname);
            this.getapk = (LinearLayout) view.findViewById(R.id.getapk);
            this.ll_app = (LinearLayout) view.findViewById(R.id.ll_app);
            this.llbg = (LinearLayout) view.findViewById(R.id.llbg);

            this.appname.setSelected(true);
            this.getapk.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        ThropicalAdAdapter.this.context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(((ThropicalDataList) ThropicalAdAdapter.this.appLists.get(AppListViewHolder.this.getAdapterPosition())).getPackg())));
                    } catch (ActivityNotFoundException unused) {
                        Toast.makeText(ThropicalAdAdapter.this.context, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                    }
                }
            }); {

            this.ll_app.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    try {
                        ThropicalAdAdapter.this.context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(((ThropicalDataList) ThropicalAdAdapter.this.appLists.get(AppListViewHolder.this.getAdapterPosition())).getPackg())));
                    } catch (ActivityNotFoundException unused) {
                        Toast.makeText(ThropicalAdAdapter.this.context, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    }

    @NonNull
    @Override
    public AppListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.thropical_ad_items,parent,false);
        return new AppListViewHolder(view);
    }

    public void onBindViewHolder(AppListViewHolder appListViewHolder, int i) {
        appListViewHolder.appname.setText(((ThropicalDataList) this.appLists.get(i)).getAppname());
        ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).asBitmap().load(((ThropicalDataList) this.appLists.get(i)).getLogo()).fitCenter()).placeholder((int) R.mipmap.ic_launcher)).into(appListViewHolder.applogo);
    }

    public int getItemCount() {
        return this.appLists.size();
    }
}
