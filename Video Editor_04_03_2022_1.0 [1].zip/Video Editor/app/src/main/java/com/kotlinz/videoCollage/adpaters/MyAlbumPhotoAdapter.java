package com.kotlinz.videoCollage.adpaters;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.kotlinz.videoCollage.interfaces.MyAlbumPhotoAdapterCallBackInterface;
import com.kotlinz.videoCollage.models.Images;
import com.kotlinz.videoeditor.R;

import java.util.ArrayList;

public class MyAlbumPhotoAdapter extends Adapter<MyAlbumPhotoAdapter.PhotoViewHolder> {
    private Context context;
    private int height;
    private ArrayList<Images> imagePaths;
    private MyAlbumPhotoAdapterCallBackInterface listener;
    private int width;

    public static class PhotoViewHolder extends ViewHolder {
        FrameLayout frameTrans;
        ImageView imgDelete;
        ImageView imgShare;
        ImageView mIvPhoto;
        RelativeLayout mMain;
        ProgressBar progressBar;

        public PhotoViewHolder(View view) {
            super(view);
            this.mIvPhoto = (ImageView) view.findViewById(R.id.iv_photo);
            this.mMain = (RelativeLayout) view.findViewById(R.id.photo_item_main_layout);
            this.imgShare = (ImageView) view.findViewById(R.id.img_album_share);
            this.imgDelete = (ImageView) view.findViewById(R.id.img_album_delete);
            this.progressBar = (ProgressBar) view.findViewById(R.id.loading_progress);
            this.frameTrans = (FrameLayout) view.findViewById(R.id.fram_trans);
        }
    }

    public MyAlbumPhotoAdapter(Context context, ArrayList<Images> arrayList, MyAlbumPhotoAdapterCallBackInterface myAlbumPhotoAdapterCallBackInterface) {
        this.context = context;
        this.imagePaths = arrayList;
        this.listener = myAlbumPhotoAdapterCallBackInterface;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.height = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
    }

    public PhotoViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new PhotoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.my_album_photo_items, viewGroup, false));
    }

    public void onBindViewHolder(final PhotoViewHolder photoViewHolder, final int i) {
        LayoutParams layoutParams = photoViewHolder.mMain.getLayoutParams();
        layoutParams.height = this.width / 2;
        photoViewHolder.mMain.setLayoutParams(layoutParams);
        final String path = ((Images) this.imagePaths.get(i)).getPath();
        Glide.with(this.context).load(path).listener(new RequestListener<Drawable>() {
            public boolean onLoadFailed(GlideException glideException, Object obj, Target<Drawable> target, boolean z) {
                photoViewHolder.progressBar.setVisibility(View.GONE);
                return false;
            }

            public boolean onResourceReady(Drawable drawable, Object obj, Target<Drawable> target, DataSource dataSource, boolean z) {
                photoViewHolder.progressBar.setVisibility(View.GONE);
                return false;
            }
        }).into(photoViewHolder.mIvPhoto);
        photoViewHolder.mIvPhoto.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumPhotoAdapter.this.listener.itemClick(i, path);
            }
        });
        photoViewHolder.imgShare.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumPhotoAdapter.this.listener.itemShare(i, path);
            }
        });
        photoViewHolder.imgDelete.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MyAlbumPhotoAdapter.this.listener.itemDelete(i, path);
            }
        });
    }

    public int getItemCount() {
        ArrayList arrayList = this.imagePaths;
        return arrayList == null ? 0 : arrayList.size();
    }
}
