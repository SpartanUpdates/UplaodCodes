package com.Pulse.VideoStatus.Extra;


import com.Pulse.VideoStatus.application.MyApplication;

import java.io.File;

public class h {
    public static String c = "asset_theam";

    public static void b() {
        StringBuilder stringBuilder = new StringBuilder("/data/data/");
        stringBuilder.append(MyApplication.getInstance().getPackageName());
        stringBuilder.append("/");
        stringBuilder.append(c);
        a(new File(stringBuilder.toString()));
    }

    private static void a(File file) {
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
        }
    }

}
