package com.esc.phoneheart.processes;

import android.os.Parcel;
import android.os.Parcelable;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
public class Status extends ProcFile {
    public static final Creator<Status> CREATOR = new Creator<Status>() {
        public Status createFromParcel(Parcel parcel) {
            return new Status(parcel);
        }

        public Status[] newArray(int i) {
            return new Status[i];
        }
    };


    public static Status get(int i) throws IOException {
        return new Status(String.format("/proc/%d/status", new Object[]{Integer.valueOf(i)}));
    }

    public int getGid() {
        try {
            return Integer.parseInt(getValue("Gid").split("\\s+")[0]);
        } catch (Exception unused) {
            return -1;
        }
    }

    public int getUid() {
        try {
            return Integer.parseInt(getValue("Uid").split("\\s+")[0]);
        } catch (Exception unused) {
            return -1;
        }
    }

    public String getValue(String str) {
        for (String str2 : this.content.split(IOUtils.LINE_SEPARATOR_UNIX)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
//            String str3 = Utils.APP_ID_IDENTIFICATION_SUBSTRING;
//            stringBuilder.append(str3);
            if (str2.startsWith(stringBuilder.toString())) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
//                stringBuilder2.append(str3);
                return str2.split(stringBuilder2.toString())[1].trim();
            }
        }
        return null;
    }

    public Status(String str) throws IOException {
        super(str);
    }

    public Status(Parcel parcel) {
        super(parcel);
    }
}
