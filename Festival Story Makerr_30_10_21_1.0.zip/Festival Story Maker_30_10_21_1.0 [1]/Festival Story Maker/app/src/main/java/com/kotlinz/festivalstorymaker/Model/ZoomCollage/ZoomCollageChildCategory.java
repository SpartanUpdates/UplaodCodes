package com.kotlinz.festivalstorymaker.Model.ZoomCollage;

import com.google.gson.annotations.SerializedName;

public class ZoomCollageChildCategory {

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("cat_name")
	private String catName;

	@SerializedName("child_cat_name")
	private String childCatName;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("child_cat_id")
	private int childCatId;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getCatName(){
		return catName;
	}

	public String getChildCatName(){
		return childCatName;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public int getChildCatId(){
		return childCatId;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}
}