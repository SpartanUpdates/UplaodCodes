﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace BallCollect
{
	public class Vibrate : MonoBehaviour
	{
		protected virtual void Start()
		{
			this.DisplayInformation();
		}

		protected virtual void DisplayInformation()
		{
			if (VibrationManager.Android())
			{
				this._platformString = "API version " + VibrationManager.AndroidSDKVersion().ToString();
			}
			else
			{
				this._platformString = Application.platform + ", not supported by Nice Vibrations for now.";
			}
			//this.DebugTextBox.text = "Platform : " + this._platformString + "\n Nice Vibrations v1.6";
		}

		public virtual void TriggerDefault()
		{
			Handheld.Vibrate();
		}

		public virtual void TriggerVibrate()
		{
			VibrationManager.Vibrate();
		}

		public virtual void TriggerSelection()
		{
			VibrationManager.Haptic(VibrateType.Selection, false);
		}

		public virtual void TriggerSuccess()
		{
			VibrationManager.Haptic(VibrateType.Success, false);
		}

		public virtual void TriggerWarning()
		{
			VibrationManager.Haptic(VibrateType.Warning, false);
		}

		public virtual void TriggerFailure()
		{
			VibrationManager.Haptic(VibrateType.Failure, false);
		}

		public virtual void TriggerLightImpact()
		{
			VibrationManager.Haptic(VibrateType.LightImpact, false);
		}

		public virtual void TriggerMediumImpact()
		{
			VibrationManager.Haptic(VibrateType.MediumImpact, false);
		}

		public virtual void TriggerHeavyImpact()
		{
			VibrationManager.Haptic(VibrateType.HeavyImpact, false);
		}

		//public Text DebugTextBox;

		protected string _debugString;

		protected string _platformString;

		protected const string _CURRENTVERSION = "1.6";
	}
}
