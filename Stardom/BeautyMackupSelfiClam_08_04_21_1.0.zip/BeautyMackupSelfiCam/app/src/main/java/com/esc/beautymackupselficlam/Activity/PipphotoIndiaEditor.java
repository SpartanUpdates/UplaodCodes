package com.esc.beautymackupselficlam.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import  com.esc.beautymackupselficlam.library.Imageutils;
import  com.esc.beautymackupselficlam.library.Imageutils.ImageAttachmentListener;
import  com.esc.beautymackupselficlam.library.TouchImageView;
import  com.esc.beautymackupselficlam.library.Utility;
import  com.esc.beautymackupselficlam.utils.CustomStckerTextView;
import  com.esc.beautymackupselficlam.utils.CustomTextView;
import  com.esc.beautymackupselficlam.utils.FontStyleAdapter;
import  com.esc.beautymackupselficlam.utils.StickerAdapter;
import  com.esc.beautymackupselficlam.utils.StickerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class PipphotoIndiaEditor extends AppCompatActivity implements OnClickListener, ImageAttachmentListener {
    private static final String IMAGE_DIRECTORY_NAME = "SweetSelfie";
    public static int int_select_pip = 0;
    private Bitmap bitmap_background;
    private Bitmap bitmap_picture;
    private ImageView Imgbtn_1;
    private ImageView Imgbtn_10;
    private ImageView Imgbtn_11;
    private ImageView Imgbtn_12;
    private ImageView Imgbtn_13;
    private ImageView Imgbtn_14;
    private ImageView Imgbtn_15;
    private ImageView Imgbtn_16;
    private ImageView Imgbtn_17;
    private ImageView Imgbtn_18;
    private ImageView Imgbtn_19;
    private ImageView Imgbtn_2;
    private ImageView Imgbtn_20;
    private ImageView Imgbtn_21;
    private ImageView Imgbtn_22;
    private ImageView Imgbtn_23;
    private ImageView Imgbtn_24;
    private ImageView Imgbtn_25;
    private ImageView Imgbtn_26;
    private ImageView Imgbtn_27;
    private ImageView Imgbtn_3;
    private ImageView Imgbtn_4;
    private ImageView Imgbtn_5;
    private ImageView Imgbtn_6;
    private ImageView Imgbtn_7;
    private ImageView Imgbtn_8;
    private ImageView Imgbtn_9;
    private LinearLayout ll_Stickers;
    private LinearLayout ll_pip;
    private LinearLayout ll_save;
    private LinearLayout ll_text;
    public static Uri contentUri;
    private Dialog dialog;
    private int height = 0;
    private Imageutils imageutils;
    private TouchImageView img_view;
    private LinearLayout layout_pip;
    private LinearLayout layout_stickers;
    private ImageView ImgView;
    private RelativeLayout rl_main;
    private int width = 0;
    HorizontalScrollView hl_effectList;
    private CustomStckerTextView currentTextView;
    private StickerView currentView;
    InputMethodManager inputmethodmanager;
    GridView grid_colorlist;
    GridView grid_fontlist;
    String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
            "font4.TTF", "font5.ttf", "font6.TTF", "font9.ttf", "font11.ttf",
            "font12.ttf", "font14.TTF", "font16.TTF", "font17.ttf",
            "font20.ttf"};
    private Typeface typeface;
    private int pickedColor = -1;
    ImageView imageview_keyboard;
    ImageView imageview_fontstyle;
    ImageView imageview_color;
    ImageView imageview_gravity;
    ImageView imageview_done;
    public static Bitmap textBitmap;
    private ArrayList<View> stickers = new ArrayList();
    private int w = 0;
    public static Bitmap Bbitmap;
    public static Canvas canvas;
    private LinearLayout ll_colorlist;
    private LinearLayout ll_fontlist;
    private EditText edittext;
    private static int columnWidth = 80;
    private ArrayList<Integer> stickerlist;
    private StickerAdapter stickerAdapter;
    private ArrayList<View> views;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private class saves extends AsyncTask<String, Void, Boolean> {
        ProgressDialog mProgress;

        private saves() {
        }

        protected void onPreExecute() {
            this.mProgress = new ProgressDialog(PipphotoIndiaEditor.this);
            this.mProgress.setIndeterminate(true);
            this.mProgress.setCancelable(true);
            this.mProgress.setMessage("Please wait...");
            this.mProgress.show();
        }

        protected Boolean doInBackground(String... args) {
            PipphotoIndiaEditor.this.getScreenSnapShot();
            return Boolean.valueOf(true);
        }

        protected void onPostExecute(Boolean success) {
            if (interstitial != null && interstitial.isLoaded()) {
                try {
                    hud = KProgressHUD.create(PipphotoIndiaEditor.this)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Showing Ads")
                            .setDetailsLabel("Please Wait...");
                    hud.show();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            hud.dismiss();
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();

                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        } catch (Exception e3) {
                            e3.printStackTrace();
                        }
                        if (interstitial != null && interstitial.isLoaded()) {
                            id = R.id.ll_save;
                            interstitial.show();
                        }
                    }
                }, 2000);
            } else {
                Intent i = new Intent(PipphotoIndiaEditor.this, shareActivity.class);
                i.putExtra("key", 7);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }
            this.mProgress.hide();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pipphoto_editor);
        int_select_pip = 0;
        loadAd();
        this.views = new ArrayList();
        BindView();
        seListeners();
        initView();
    }

    private void initView() {
        this.imageutils = new Imageutils(this);
        if (Utility.int_image_type == 1) {
            this.imageutils.launchCamera(1);
        } else if (Utility.int_image_type == 2) {
            this.imageutils.launchGallery(1);
        }
        ImageView back = (ImageView) findViewById(R.id.iv_back);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitial != null && interstitial.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(PipphotoIndiaEditor.this)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = R.id.iv_back;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                } else {
                    onBackPressed();
                }
            }
        });
    }

    private void seListeners() {
        this.Imgbtn_1.setOnClickListener(this);
        this.Imgbtn_2.setOnClickListener(this);
        this.Imgbtn_3.setOnClickListener(this);
        this.Imgbtn_4.setOnClickListener(this);
        this.Imgbtn_5.setOnClickListener(this);
        this.Imgbtn_6.setOnClickListener(this);
        this.Imgbtn_7.setOnClickListener(this);
        this.Imgbtn_8.setOnClickListener(this);
        this.Imgbtn_9.setOnClickListener(this);
        this.Imgbtn_10.setOnClickListener(this);
        this.Imgbtn_11.setOnClickListener(this);
        this.Imgbtn_12.setOnClickListener(this);
        this.Imgbtn_13.setOnClickListener(this);
        this.Imgbtn_14.setOnClickListener(this);
        this.Imgbtn_15.setOnClickListener(this);
        this.Imgbtn_16.setOnClickListener(this);
        this.Imgbtn_17.setOnClickListener(this);
        this.Imgbtn_18.setOnClickListener(this);
        this.Imgbtn_19.setOnClickListener(this);
        this.Imgbtn_20.setOnClickListener(this);
        this.Imgbtn_21.setOnClickListener(this);
        this.Imgbtn_22.setOnClickListener(this);
        this.Imgbtn_23.setOnClickListener(this);
        this.Imgbtn_24.setOnClickListener(this);
        this.Imgbtn_25.setOnClickListener(this);
        this.Imgbtn_26.setOnClickListener(this);
        this.Imgbtn_27.setOnClickListener(this);
    }

    private void BindView() {
        this.ll_pip = (LinearLayout) findViewById(R.id.ll_pipframe1);
        this.ll_pip.setOnClickListener(this);
        this.ll_Stickers = (LinearLayout) findViewById(R.id.ll_Stickers);
        this.ll_Stickers.setOnClickListener(this);
        this.ll_text = (LinearLayout) findViewById(R.id.ll_text);
        this.ll_text.setOnClickListener(this);
        this.ll_save = (LinearLayout) findViewById(R.id.ll_save);
        this.ll_save.setOnClickListener(this);
        hl_effectList = (HorizontalScrollView) findViewById(R.id.hl_effects);
        this.rl_main = (RelativeLayout) findViewById(R.id.ll_main);
        this.ImgView = (ImageView) findViewById(R.id.imageview_id);
        this.img_view = (TouchImageView) findViewById(R.id.imageview_main);
        this.layout_pip = (LinearLayout) findViewById(R.id.ll_pipframe);
        this.layout_stickers = (LinearLayout) findViewById(R.id.ll_stickers);
        this.Imgbtn_1 = (ImageView) findViewById(R.id.img_1);
        this.Imgbtn_2 = (ImageView) findViewById(R.id.img_2);
        this.Imgbtn_3 = (ImageView) findViewById(R.id.img_3);
        this.Imgbtn_4 = (ImageView) findViewById(R.id.img_4);
        this.Imgbtn_5 = (ImageView) findViewById(R.id.img_5);
        this.Imgbtn_6 = (ImageView) findViewById(R.id.img_6);
        this.Imgbtn_7 = (ImageView) findViewById(R.id.img_7);
        this.Imgbtn_8 = (ImageView) findViewById(R.id.img_8);
        this.Imgbtn_9 = (ImageView) findViewById(R.id.img_9);
        this.Imgbtn_10 = (ImageView) findViewById(R.id.img_10);
        this.Imgbtn_11 = (ImageView) findViewById(R.id.img_11);
        this.Imgbtn_12 = (ImageView) findViewById(R.id.img_12);
        this.Imgbtn_13 = (ImageView) findViewById(R.id.img_13);
        this.Imgbtn_14 = (ImageView) findViewById(R.id.img_14);
        this.Imgbtn_15 = (ImageView) findViewById(R.id.img_15);
        this.Imgbtn_16 = (ImageView) findViewById(R.id.img_16);
        this.Imgbtn_17 = (ImageView) findViewById(R.id.img_17);
        this.Imgbtn_18 = (ImageView) findViewById(R.id.img_18);
        this.Imgbtn_19 = (ImageView) findViewById(R.id.img_19);
        this.Imgbtn_20 = (ImageView) findViewById(R.id.img_20);
        this.Imgbtn_21 = (ImageView) findViewById(R.id.img_21);
        this.Imgbtn_22 = (ImageView) findViewById(R.id.img_22);
        this.Imgbtn_23 = (ImageView) findViewById(R.id.img_23);
        this.Imgbtn_24 = (ImageView) findViewById(R.id.img_24);
        this.Imgbtn_25 = (ImageView) findViewById(R.id.img_25);
        this.Imgbtn_26 = (ImageView) findViewById(R.id.img_26);
        this.Imgbtn_27 = (ImageView) findViewById(R.id.img_27);
    }

    private void PiPIcons() {
        this.Imgbtn_1.setImageResource(R.drawable.ind_pip1);
        this.Imgbtn_2.setImageResource(R.drawable.ind_pip2);
        this.Imgbtn_3.setImageResource(R.drawable.ind_pip3);
        this.Imgbtn_4.setImageResource(R.drawable.ind_pip4);
        this.Imgbtn_5.setImageResource(R.drawable.ind_pip5);
        this.Imgbtn_6.setImageResource(R.drawable.ind_pip6);
        this.Imgbtn_7.setImageResource(R.drawable.ind_pip7);
        this.Imgbtn_8.setImageResource(R.drawable.ind_pip8);
        this.Imgbtn_9.setImageResource(R.drawable.ind_pip9);
        this.Imgbtn_10.setImageResource(R.drawable.ind_pip10);
        this.Imgbtn_11.setImageResource(R.drawable.ind_pip11);
        this.Imgbtn_12.setImageResource(R.drawable.ind_pip12);
        this.Imgbtn_13.setImageResource(R.drawable.ind_pip13);
        this.Imgbtn_14.setImageResource(R.drawable.ind_pip14);
        this.Imgbtn_15.setImageResource(R.drawable.ind_pip15);
        this.Imgbtn_16.setImageResource(R.drawable.ind_pip16);
        this.Imgbtn_17.setImageResource(R.drawable.ind_pip17);
        this.Imgbtn_18.setImageResource(R.drawable.ind_pip18);
        this.Imgbtn_19.setImageResource(R.drawable.ind_pip19);
        this.Imgbtn_20.setImageResource(R.drawable.ind_pip20);
        this.Imgbtn_21.setImageResource(R.drawable.pipicon_21);
        this.Imgbtn_22.setImageResource(R.drawable.pipicon_22);
        this.Imgbtn_23.setImageResource(R.drawable.pipicon_23);
        this.Imgbtn_24.setImageResource(R.drawable.pipicon_24);
        this.Imgbtn_25.setImageResource(R.drawable.pipicon_25);
        this.Imgbtn_26.setImageResource(R.drawable.pipicon_26);
        this.Imgbtn_27.setImageResource(R.drawable.pipicon_27);
    }


    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        this.width = this.rl_main.getWidth();
        this.height = this.rl_main.getHeight();
        if (int_select_pip == 2) {
            frame1();
            PiPIcons();
        }
    }

    private void ShowPip() {
        PiPIcons();
        this.layout_pip.setVisibility(View.VISIBLE);
        this.layout_stickers.setVisibility(View.GONE);
    }

    public void onClick(View v) {
        if (v == this.ll_pip) {
            hl_effectList.setVisibility(View.VISIBLE);
            ShowPip();
        } else if (v == this.ll_Stickers) {
            hl_effectList.setVisibility(View.INVISIBLE);
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            showStickerDialog();
        } else if (v == this.ll_text) {
            hl_effectList.setVisibility(View.INVISIBLE);
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            selecttext();
        } else if (v == this.ll_save) {
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }

            new saves().execute(new String[0]);
        } else if (v == this.Imgbtn_1) {
            int_select_pip = 1;
            frame1();
        } else if (v == this.Imgbtn_2) {
            int_select_pip = 1;
            frame2();
        } else if (v == this.Imgbtn_3) {
            int_select_pip = 1;
            frame3();
        } else if (v == this.Imgbtn_4) {
            int_select_pip = 1;
            frame4();
        } else if (v == this.Imgbtn_5) {
            int_select_pip = 1;
            frame5();
        } else if (v == this.Imgbtn_6) {
            int_select_pip = 1;
            frame6();
        } else if (v == this.Imgbtn_7) {
            int_select_pip = 1;
            frame7();
        } else if (v == this.Imgbtn_8) {
            int_select_pip = 1;
            frame8();
        } else if (v == this.Imgbtn_9) {
            int_select_pip = 1;
            frame9();
        } else if (v == this.Imgbtn_10) {
            int_select_pip = 1;
            frame10();
        } else if (v == this.Imgbtn_11) {
            int_select_pip = 1;
            frame11();
        } else if (v == this.Imgbtn_12) {
            int_select_pip = 1;
            frame12();
        } else if (v == this.Imgbtn_13) {
            int_select_pip = 1;
            frame13();
        } else if (v == this.Imgbtn_14) {
            int_select_pip = 1;
            frame14();
        } else if (v == this.Imgbtn_15) {
            int_select_pip = 1;
            frame15();
        } else if (v == this.Imgbtn_16) {
            int_select_pip = 1;
            frame16();
        } else if (v == this.Imgbtn_17) {
            int_select_pip = 1;
            frame17();
        } else if (v == this.Imgbtn_18) {
            int_select_pip = 1;
            frame18();
        } else if (v == this.Imgbtn_19) {
            int_select_pip = 1;
            frame19();
        } else if (v == this.Imgbtn_20) {
            int_select_pip = 1;
            frame20();
        } else if (v == this.Imgbtn_21) {
            int_select_pip = 1;
            frame21();
        } else if (v == this.Imgbtn_22) {
            int_select_pip = 1;
            frame22();
        } else if (v == this.Imgbtn_23) {
            int_select_pip = 1;
            frame23();
        } else if (v == this.Imgbtn_24) {
            int_select_pip = 1;
            frame24();
        } else if (v == this.Imgbtn_25) {
            int_select_pip = 1;
            frame25();
        } else if (v == this.Imgbtn_26) {
            int_select_pip = 1;
            frame26();
        } else if (v == this.Imgbtn_27) {
            int_select_pip = 1;
            frame27();
        }
    }

    private void frame1() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask1, R.drawable.ind_pipframe1, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame2() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask2, R.drawable.ind_frame2, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame3() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask3, R.drawable.ind_frame3, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame4() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask4, R.drawable.ind_frame4, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame5() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask5, R.drawable.ind_frame5, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame6() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask6, R.drawable.ind_frame6, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame7() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask7, R.drawable.ind_frame7, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame8() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask8, R.drawable.ind_frame8, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame9() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask9, R.drawable.ind_frame9, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame10() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask10, R.drawable.ind_frame10, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame11() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask11, R.drawable.ind_frame11, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame12() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask12, R.drawable.ind_frame12, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame13() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask13, R.drawable.ind_frame13, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame14() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask14, R.drawable.ind_frame14, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame15() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask15, R.drawable.ind_frame15, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame16() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask16, R.drawable.ind_frame16, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame17() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask17, R.drawable.ind_frame17, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame18() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask18, R.drawable.ind_frame18, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame19() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask19, R.drawable.ind_frame19, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame20() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.ind_mask20, R.drawable.ind_frame20, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame21() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_21, R.drawable.frame_21, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame22() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_22, R.drawable.frame_22, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame23() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_23, R.drawable.frame_23, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame24() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_24, R.drawable.frame_24, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame25() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_25, R.drawable.frame_25, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame26() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_26, R.drawable.frame_26, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }

    private void frame27() {
        Utility.makeMaskImage(this, this.ImgView, this.bitmap_background, R.drawable.mask_27, R.drawable.frame_27, this.width, this.height);
        this.img_view.setImageBitmap(this.bitmap_picture);
    }


    void getScreenSnapShot() {
        View content = findViewById(R.id.ll_main);
        content.setDrawingCacheEnabled(true);
        content.buildDrawingCache(true);
        saveBitmap(content.getDrawingCache());
        content.setDrawingCacheEnabled(false);
        content.destroyDrawingCache();
    }

    public void saveBitmap(Bitmap bitmap) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME);
        if (!(mediaStorageDir.exists() || mediaStorageDir.mkdirs())) {
        }
        String filepath = mediaStorageDir.getPath() + File.separator + "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".jpg";
        try {
            FileOutputStream fos = new FileOutputStream(new File(filepath));
            bitmap.compress(CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
        } catch (IOException e2) {
        }
        Intent mediaScanIntent = new Intent(Intent.ACTION_SEND);
        this.contentUri = Uri.fromFile(new File(filepath));
        mediaScanIntent.setData(this.contentUri);

        sendBroadcast(mediaScanIntent);
    }


    public void onBackPressed() {
        int_select_pip = 0;
        super.onBackPressed();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1) {
            this.imageutils.onActivityResult(requestCode, resultCode, data);
        } else if (resultCode == 0) {
            finish();
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        this.imageutils.request_permission_result(requestCode, permissions, grantResults);
    }

    public void image_attachment(int from, String filename, Bitmap file, Uri uri) {
        try {
            this.bitmap_background = Utility.getResizedBitmap(file, 500);
            this.bitmap_picture = this.bitmap_background;
            int_select_pip = 2;
        } catch (Exception e) {
            finish();
        }
        this.imageutils.createImage(file, filename, Environment.getExternalStorageDirectory() + File.separator + IMAGE_DIRECTORY_NAME + File.separator, false);
    }


    protected void selecttext() {
        this.dialog = new Dialog(this);
        this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.inputmethodmanager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        this.inputmethodmanager.toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        this.edittext = (EditText) this.dialog.findViewById(R.id.edittext);
        this.edittext.requestFocus();
        this.ll_fontlist = (LinearLayout) this.dialog
                .findViewById(R.id.llfontlist);
        this.ll_fontlist.setVisibility(View.GONE);
        this.grid_fontlist = (GridView) this.dialog.findViewById(R.id.grid_fontlist);
        this.grid_fontlist.setAdapter(new FontStyleAdapter(this, this.fonts));
        this.grid_fontlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                PipphotoIndiaEditor.this.typeface = Typeface.createFromAsset(
                        PipphotoIndiaEditor.this.getAssets(),
                        PipphotoIndiaEditor.this.fonts[i]);
                PipphotoIndiaEditor.this.edittext
                        .setTypeface(PipphotoIndiaEditor.this.typeface);
                textView.setTypeface(PipphotoIndiaEditor.this.typeface);
            }
        });
        this.ll_colorlist = (LinearLayout) this.dialog
                .findViewById(R.id.ll_colorlist);
        this.ll_colorlist.setVisibility(View.GONE);
        this.grid_colorlist = (GridView) this.dialog
                .findViewById(R.id.grid_colorlist);
        ArrayList colors = HSVColors();
        final ArrayList arrayList = colors;
        this.grid_colorlist.setAdapter(new ArrayAdapter<Integer>(
                getApplicationContext(), 17367043, colors) {
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView,
                        parent);
                view.setBackgroundColor(((Integer) arrayList.get(position))
                        .intValue());
                view.setText("");
                view.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
                AbsListView.LayoutParams params = (AbsListView.LayoutParams) view
                        .getLayoutParams();
                params.width = PipphotoIndiaEditor.columnWidth;
                params.height = PipphotoIndiaEditor.columnWidth;
                view.setLayoutParams(params);
                view.requestLayout();
                return view;
            }
        });
        this.grid_colorlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                PipphotoIndiaEditor.this.pickedColor = ((Integer) adapterView
                        .getItemAtPosition(i)).intValue();
                PipphotoIndiaEditor.this.edittext
                        .setTextColor(PipphotoIndiaEditor.this.pickedColor);
                textView.setTextColor(PipphotoIndiaEditor.this.pickedColor);
            }
        });
        this.imageview_keyboard = (ImageView) this.dialog
                .findViewById(R.id.imgview_keyboard);
        this.imageview_keyboard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) PipphotoIndiaEditor.this
                        .getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(
                        PipphotoIndiaEditor.this.edittext, 2);
                PipphotoIndiaEditor.this.ll_fontlist.setVisibility(View.GONE);
                PipphotoIndiaEditor.this.ll_colorlist.setVisibility(View.GONE);
            }
        });
        this.imageview_fontstyle = (ImageView) this.dialog
                .findViewById(R.id.imgview_fontstyle);
        this.imageview_fontstyle.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                PipphotoIndiaEditor.this.ll_fontlist.setVisibility(View.VISIBLE);
                PipphotoIndiaEditor.this.ll_colorlist.setVisibility(View.GONE);
                ((InputMethodManager) PipphotoIndiaEditor.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                PipphotoIndiaEditor.this.edittext
                                        .getWindowToken(), 0);
            }
        });
        this.imageview_color = (ImageView) this.dialog.findViewById(R.id.imgview_color);
        this.imageview_color.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) PipphotoIndiaEditor.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                PipphotoIndiaEditor.this.edittext
                                        .getWindowToken(), 0);
                PipphotoIndiaEditor.this.ll_colorlist.setVisibility(View.VISIBLE);
                PipphotoIndiaEditor.this.ll_fontlist.setVisibility(View.GONE);
            }
        });
        this.imageview_gravity = (ImageView) this.dialog.findViewById(R.id.imgview_gravity);
        this.imageview_gravity.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (PipphotoIndiaEditor.this.w == 0) {
                    PipphotoIndiaEditor.this.w = 1;
                    PipphotoIndiaEditor.this.imageview_gravity
                            .setImageDrawable(PipphotoIndiaEditor.this
                                    .getResources().getDrawable(
                                            R.drawable.alignright));
                    PipphotoIndiaEditor.this.edittext.setGravity(5);
                    textView.setGravity(5);
                } else if (PipphotoIndiaEditor.this.w == 1) {
                    PipphotoIndiaEditor.this.imageview_gravity
                            .setImageDrawable(PipphotoIndiaEditor.this
                                    .getResources().getDrawable(
                                            R.drawable.alignleft));
                    PipphotoIndiaEditor.this.edittext.setGravity(3);
                    textView.setGravity(3);
                    PipphotoIndiaEditor.this.w = 2;
                } else if (PipphotoIndiaEditor.this.w == 2) {
                    PipphotoIndiaEditor.this.w = 0;
                    PipphotoIndiaEditor.this.imageview_gravity
                            .setImageDrawable(PipphotoIndiaEditor.this
                                    .getResources().getDrawable(
                                            R.drawable.aligncenter));
                    PipphotoIndiaEditor.this.edittext.setGravity(17);
                    textView.setGravity(17);
                }
            }
        });
        this.imageview_done = (ImageView) this.dialog.findViewById(R.id.imgview_done);
        final TextView txtEnteredText = (TextView) this.dialog
                .findViewById(R.id.txtEnteredText);
        txtEnteredText.setDrawingCacheEnabled(true);
        this.imageview_done.setOnClickListener(new OnClickListener() {


            public void onClick(View view) {
                PipphotoIndiaEditor.this.inputmethodmanager.hideSoftInputFromWindow(
                        view.getWindowToken(), 0);
                String st = PipphotoIndiaEditor.this.edittext.getText()
                        .toString();
                if (st.isEmpty()) {
                    Toast.makeText(PipphotoIndiaEditor.this, "text empty",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                txtEnteredText.setText(st);
                txtEnteredText.setTypeface(PipphotoIndiaEditor.this.typeface);
                txtEnteredText
                        .setTextColor(PipphotoIndiaEditor.this.pickedColor);
                txtEnteredText.setGravity(17);
                ImageView textImg = new ImageView(PipphotoIndiaEditor.this);
                txtEnteredText.buildDrawingCache();
                textImg.setImageBitmap(txtEnteredText.getDrawingCache());
                PipphotoIndiaEditor.textBitmap = PipphotoIndiaEditor
                        .loadBitmapFromView(textImg);
                PipphotoIndiaEditor.textBitmap = PipphotoIndiaEditor.this
                        .CropBitmapTransparency(PipphotoIndiaEditor.textBitmap);
                txtEnteredText.setDrawingCacheEnabled(false);
                ((InputMethodManager) PipphotoIndiaEditor.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                PipphotoIndiaEditor.this.edittext
                                        .getWindowToken(), 0);
                final CustomStckerTextView stickerTextView = new CustomStckerTextView(
                        PipphotoIndiaEditor.this);
                stickerTextView.setBitmap(PipphotoIndiaEditor.textBitmap);
                PipphotoIndiaEditor.this.rl_main.addView(stickerTextView,
                        new FrameLayout.LayoutParams(-1, -1, 17));
                PipphotoIndiaEditor.this.stickers.add(stickerTextView);
                stickerTextView.setInEdit(true);
                PipphotoIndiaEditor.this
                        .setCurrentEditForText(stickerTextView);
                stickerTextView
                        .setOperationListener(new CustomStckerTextView.OperationListener() {
                            public void onDeleteClick() {
                                PipphotoIndiaEditor.this.stickers
                                        .remove(stickerTextView);
                                PipphotoIndiaEditor.this.rl_main
                                        .removeView(stickerTextView);
                            }

                            public void onEdit(
                                    CustomStckerTextView customTextView) {
                                PipphotoIndiaEditor.this.currentTextView
                                        .setInEdit(false);
                                PipphotoIndiaEditor.this.currentTextView = customTextView;
                                PipphotoIndiaEditor.this.currentTextView
                                        .setInEdit(true);
                            }

                            public void onTop(
                                    CustomStckerTextView customTextView) {
                                int position = PipphotoIndiaEditor.this.stickers
                                        .indexOf(customTextView);
                                if (position != PipphotoIndiaEditor.this.stickers
                                        .size() - 1) {
                                    PipphotoIndiaEditor.this.stickers
                                            .add(PipphotoIndiaEditor.this.stickers
                                                            .size(),
                                                    (CustomTextView) PipphotoIndiaEditor.this.stickers
                                                            .remove(position));
                                }
                            }
                        });
                PipphotoIndiaEditor.this.dialog.dismiss();
            }
        });
        this.dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            public boolean onKey(DialogInterface dialogInterface, int i,
                                 KeyEvent keyEvent) {
                if (i != 4 || keyEvent.getAction() != 1
                        || keyEvent.isCanceled()) {
                    return false;
                }
                PipphotoIndiaEditor.this.dialog.cancel();
                return true;
            }
        });
        this.dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        Window window2 = this.dialog.getWindow();
        layoutParams.copyFrom(window2.getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -1;
        window2.setAttributes(layoutParams);
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    public static ArrayList HSVColors() {
        final ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i <= 360; i += 20) {
            list.add(HSVColor(i, 1.0f, 1.0f));
        }
        for (int j = 0; j <= 360; j += 20) {
            list.add(HSVColor(j, 0.25f, 1.0f));
            list.add(HSVColor(j, 0.5f, 1.0f));
            list.add(HSVColor(j, 0.75f, 1.0f));
        }
        for (int k = 0; k <= 360; k += 20) {
            list.add(HSVColor(k, 1.0f, 0.5f));
            list.add(HSVColor(k, 1.0f, 0.75f));
        }
        for (float n = 0.0f; n <= 1.0f; n += 0.1f) {
            list.add(HSVColor(0.0f, 0.0f, n));
        }
        return list;
    }

    Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                if (((sourceBitmap.getPixel(x, y) >> 24) & 255) > 0) {
                    if (x < minX) {
                        minX = x;
                    }
                    if (x > maxX) {
                        maxX = x;
                    }
                    if (y < minY) {
                        minY = y;
                    }
                    if (y > maxY) {
                        maxY = y;
                    }
                }
            }
        }
        if (maxX < minX || maxY < minY) {
            return null;
        }
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1,
                (maxY - minY) + 1);
    }

    private void setCurrentEditForText(CustomStckerTextView stickerTextView) {
        this.currentTextView = stickerTextView;
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(true);
        }
    }

    public static Bitmap loadBitmapFromView(View v) {
        if (v.getMeasuredHeight() <= 0) {
            v.measure(-2, -2);
            Bbitmap = Bitmap.createBitmap(v.getMeasuredWidth(),
                    v.getMeasuredHeight(), Config.ARGB_8888);
            canvas = new Canvas(Bbitmap);
            v.layout(0, 0, v.getMeasuredWidth(), v.getMeasuredHeight());
            v.draw(canvas);
            return Bbitmap;
        }
        Bbitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(),
                Config.ARGB_8888);
        canvas = new Canvas(Bbitmap);
        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(canvas);
        return Bbitmap;
    }

    public void showStickerDialog() {
        final Dialog dial = new Dialog(this, R.style.Theme_AppCompat);
        dial.requestWindowFeature(1);
        dial.setContentView(R.layout.sticker_dialog);
        dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dial.setCanceledOnTouchOutside(true);
        ((ImageView) dial.findViewById(R.id.back_dialog))
                .setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        dial.dismiss();
                    }
                });
        this.stickerlist = new ArrayList();
        GridView grid_sticker = (GridView) dial
                .findViewById(R.id.gridStickerList);
        setStickerList1();
        this.stickerAdapter = new StickerAdapter(getApplicationContext(),
                this.stickerlist);
        grid_sticker.setAdapter(this.stickerAdapter);
        grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                PipphotoIndiaEditor.this
                        .addStickerView(((Integer) PipphotoIndiaEditor.this.stickerlist
                                .get(i)).intValue());
                dial.dismiss();
            }
        });
        dial.show();
    }

    private void setStickerList1() {
        this.stickerlist.add(Integer.valueOf(R.drawable.ss1));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss2));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss3));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss4));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss5));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss6));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss7));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss8));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss9));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss10));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss11));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss12));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss13));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss14));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss15));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss16));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss17));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss18));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss19));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss20));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss21));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss22));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss23));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss24));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss25));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss26));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss27));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss28));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss29));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s29));
        this.stickerlist.add(Integer.valueOf(R.drawable.s30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s31));
        this.stickerlist.add(Integer.valueOf(R.drawable.s32));
        this.stickerlist.add(Integer.valueOf(R.drawable.s33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s34));
        this.stickerlist.add(Integer.valueOf(R.drawable.s35));
        this.stickerlist.add(Integer.valueOf(R.drawable.s36));
        this.stickerlist.add(Integer.valueOf(R.drawable.s37));
        this.stickerlist.add(Integer.valueOf(R.drawable.s38));
        this.stickerlist.add(Integer.valueOf(R.drawable.s39));
        this.stickerlist.add(Integer.valueOf(R.drawable.s40));
        this.stickerlist.add(Integer.valueOf(R.drawable.s41));
        this.stickerlist.add(Integer.valueOf(R.drawable.s42));
        this.stickerlist.add(Integer.valueOf(R.drawable.s43));
        this.stickerlist.add(Integer.valueOf(R.drawable.s44));
        this.stickerlist.add(Integer.valueOf(R.drawable.s45));
        this.stickerlist.add(Integer.valueOf(R.drawable.s46));
        this.stickerlist.add(Integer.valueOf(R.drawable.s47));
        this.stickerlist.add(Integer.valueOf(R.drawable.s48));
        this.stickerlist.add(Integer.valueOf(R.drawable.s49));
        this.stickerlist.add(Integer.valueOf(R.drawable.s50));
        this.stickerlist.add(Integer.valueOf(R.drawable.s51));
        this.stickerlist.add(Integer.valueOf(R.drawable.s52));
        this.stickerlist.add(Integer.valueOf(R.drawable.s53));
        this.stickerlist.add(Integer.valueOf(R.drawable.s54));
        this.stickerlist.add(Integer.valueOf(R.drawable.s55));

    }

    private void addStickerView(int id) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                PipphotoIndiaEditor.this.views.remove(stickerView);
                PipphotoIndiaEditor.this.rl_main.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                if (PipphotoIndiaEditor.this.currentTextView != null) {
                    PipphotoIndiaEditor.this.currentTextView.setInEdit(false);
                }
                PipphotoIndiaEditor.this.currentView.setInEdit(false);
                PipphotoIndiaEditor.this.currentView = stickerView;
                PipphotoIndiaEditor.this.currentView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = PipphotoIndiaEditor.this.views
                        .indexOf(stickerView);
                if (position != PipphotoIndiaEditor.this.views.size() - 1) {
                    PipphotoIndiaEditor.this.views.add(
                            PipphotoIndiaEditor.this.views.size(),
                            (StickerView) PipphotoIndiaEditor.this.views
                                    .remove(position));
                }
            }
        });
        this.rl_main.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.views.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(false);
        }
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

    private void loadAd() {
        //interstitial FullScreenAd
        interstitial = new InterstitialAd(PipphotoIndiaEditor.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        onBackPressed();
                        break;
                    case R.id.ll_save:
                        Intent i = new Intent(PipphotoIndiaEditor.this, shareActivity.class);
                        i.putExtra("key", 7);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(PipphotoIndiaEditor.this);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
