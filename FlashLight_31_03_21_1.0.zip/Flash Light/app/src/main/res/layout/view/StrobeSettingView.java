package flash.light.shine.com.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import flash.light.shine.com.R;

public class StrobeSettingView extends FrameLayout {
    public static final int TYPE_OFF = 1;
    public static final int TYPE_ON = 0;
    private SeekBar seekBar;
    private TextView tvDesc;
    private TextView tvTitle;

    public StrobeSettingView(Context context) {
        super(context);
        initViews();
    }

    public StrobeSettingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initViews();
    }

    public StrobeSettingView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        initViews();
    }

    private void initViews() {
        LayoutInflater.from(getContext()).inflate(R.layout.v_strobe_setting, this);
        this.seekBar = (SeekBar) findViewById(R.id.seekBar);
        this.tvTitle = (TextView) findViewById(R.id.tv_title);
        this.tvDesc = (TextView) findViewById(R.id.tv_desc);
    }

    public void setTitle(String str) {
        this.tvTitle.setText(str);
    }

    public void setDesc(String str) {
        this.tvDesc.setText(str);
    }

    public void setOnSeekBarChangeListener(OnSeekBarChangeListener onSeekBarChangeListener) {
        this.seekBar.setOnSeekBarChangeListener(onSeekBarChangeListener);
    }

    public void setMax(int i) {
        this.seekBar.setMax(i);
    }

    public void setProgress(int i) {
        this.seekBar.setProgress(i);
    }
}
