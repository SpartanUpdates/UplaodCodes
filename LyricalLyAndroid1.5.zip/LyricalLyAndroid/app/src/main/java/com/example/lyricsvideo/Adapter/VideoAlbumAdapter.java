package com.example.lyricsvideo.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.activity.FullVideoPlayActivity;
import com.example.lyricsvideo.activity.MyCreationActivity;
import java.io.File;


public class VideoAlbumAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    MyCreationActivity ListActivity;
    private Context mContext;

    public VideoAlbumAdapter(Context context) {
        mContext = context;
        ListActivity = ((MyCreationActivity) context);
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.row_mycreation, parent, false);
        return new MyViewHolder(v);
    }

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final MyViewHolder videoholder = (MyViewHolder) holder;
        final StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(videoholder.itemView.getLayoutParams());
        layoutParams.setFullSpan(false);
        videoholder.itemView.setLayoutParams(layoutParams);
        Glide.with(this.mContext).load(this.ListActivity.videoInfos.get(position).videoFullPath).into(videoholder.ivVideoThumb);
        videoholder.tvVideoName.setText(ListActivity.videoInfos.get(position).videoName + ".mp4");
        AppFont.Textfont(mContext, videoholder.tvVideoName);
        videoholder.ivVideoThumb.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                final Intent intent = new Intent(mContext, FullVideoPlayActivity.class);
                intent.putExtra("Url", ListActivity.videoInfos.get(position).videoFullPath);
                intent.putExtra("Name", ListActivity.videoInfos.get(position).videoName + ".mp4");
                intent.putExtra("IsPlayVidoeFromHome", false);
                intent.putExtra("IsVideoFromList", true);
                mContext.startActivity(intent);
            }
        });
        videoholder.ivBtnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                try {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(VideoAlbumAdapter.this.mContext, R.style.AppDialog);
                    builder.setTitle(R.string.deletetitle);
                    builder.setMessage(String.valueOf(VideoAlbumAdapter.this.mContext.getResources().getString(R.string.deleteMessage)) + VideoAlbumAdapter.this.ListActivity.videoInfos.get(position).videoName + ".mp4" + " ?");
                    builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int which) {
                            try {
                                Utils.deleteFile(new File(VideoAlbumAdapter.this.ListActivity.videoInfos.get(position).videoFullPath));
                                ((MyCreationActivity) VideoAlbumAdapter.this.mContext).RemoveVideoFromList(position);
                                VideoAlbumAdapter.this.notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", null);
                    builder.show();
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        videoholder.ivBtnShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                final File file = new File(VideoAlbumAdapter.this.ListActivity.videoInfos.get(position).videoFullPath);
                final Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("video/*");
                shareIntent.putExtra("android.intent.extra.SUBJECT", VideoAlbumAdapter.this.mContext.getString(R.string.app_name));
                shareIntent.putExtra("android.intent.extra.TEXT", String.valueOf(VideoAlbumAdapter.this.mContext.getString(R.string.get_free)) + VideoAlbumAdapter.this.mContext.getString(R.string.app_name) + " at here : " + "https://play.google.com/store/apps/details?id=" + VideoAlbumAdapter.this.mContext.getPackageName());
                shareIntent.putExtra("android.intent.extra.TITLE", VideoAlbumAdapter.this.ListActivity.videoInfos.get(position).videoName);
                final Uri ShareUri = FileProvider.getUriForFile(VideoAlbumAdapter.this.mContext, String.valueOf(VideoAlbumAdapter.this.mContext.getPackageName()) + ".provider", file);
                shareIntent.putExtra("android.intent.extra.STREAM", ShareUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                VideoAlbumAdapter.this.mContext.startActivity(Intent.createChooser(shareIntent, "Share Video"));
            }
        });
    }


    public int getItemCount() {
        return ListActivity.videoInfos.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView ivBtnShare;
        ImageView ivBtnDelete;
        ImageView ivVideoThumb;
        TextView tvVideoName;

        public MyViewHolder(View v) {
            super(v);
            tvVideoName = itemView.findViewById(R.id.txtSongName);
            ivVideoThumb = v.findViewById(R.id.imgVideoThumbnail);
            ivBtnDelete = v.findViewById(R.id.imgDelete);
            ivBtnShare = v.findViewById(R.id.imgWhatsapp);
        }
    }

}
