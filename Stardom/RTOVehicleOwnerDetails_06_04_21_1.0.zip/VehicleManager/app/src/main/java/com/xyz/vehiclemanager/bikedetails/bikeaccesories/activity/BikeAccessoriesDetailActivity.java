package com.xyz.vehiclemanager.bikedetails.bikeaccesories.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikeaccesories.adapter.BikeAccessoriesDetailsAdapter;
import com.xyz.vehiclemanager.bikedetails.bikeaccesories.model.BikeAccessories;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;
import java.util.ArrayList;

public class BikeAccessoriesDetailActivity extends AppCompatActivity implements View.OnClickListener
{
    private Activity activity= BikeAccessoriesDetailActivity.this;
    private String brandName, brandId;
    private RecyclerView rv_bikeAccessoriesDetals;
    private BikeAccessoriesDetailsAdapter bikeAccessoriesDetailsAdapter;
    private ImageView iv_back;
    private TextView tv_title;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bike_accessories_detail);

        Intent intent = getIntent();
        brandId = intent.getStringExtra("id");
        brandName = intent.getStringExtra("brandName");

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        PutAnalyticsEvent();
        BindView();
        BannerAds();
        DialogAnimation();
        if (Utils.isOnline(activity)){
            getBikeAssesoriesDetails();
        }else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView()
    {
        iv_back = findViewById(R.id.iv_back);
        tv_title = findViewById(R.id.tv_title);
        rv_bikeAccessoriesDetals = findViewById (R.id.rv_carAccessoriesDetails);

        iv_back.setOnClickListener(this);
        tv_title.setText(brandName);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeAccessoriesDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId()){

            case R.id.iv_back:
                onBackPressed();
            break;
        }
    }

    private void getBikeAssesoriesDetails()
    {
        Call<BikeAccessories> call = rtoDetailsInterface.getBikeDetailAccessories(brandId);
        call.enqueue(new Callback<BikeAccessories>() {
            @Override
            public void onResponse(Call<BikeAccessories> call, Response<BikeAccessories> response)
            {
                if (response.isSuccessful())
                {
                    if (dialog != null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    ArrayList<BikeAccessories> bikeAccessorielist = response.body().getData();
                    bikeAccessoriesDetailsAdapter=new BikeAccessoriesDetailsAdapter(activity, bikeAccessorielist);
                    rv_bikeAccessoriesDetals.setLayoutManager(new LinearLayoutManager(activity));
                    rv_bikeAccessoriesDetals.setAdapter(bikeAccessoriesDetailsAdapter);
                }
            }

            @Override
            public void onFailure(Call<BikeAccessories> call, Throwable t) {
                if (dialog != null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}