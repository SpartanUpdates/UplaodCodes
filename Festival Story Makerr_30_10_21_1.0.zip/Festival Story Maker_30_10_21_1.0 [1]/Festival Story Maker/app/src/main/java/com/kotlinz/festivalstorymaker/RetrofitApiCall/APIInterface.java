package com.kotlinz.festivalstorymaker.RetrofitApiCall;


import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CategoryWiseData.CollageCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.CollageResponse;
import com.kotlinz.festivalstorymaker.Model.CollageMaker.Element.ElementResponse;
import com.kotlinz.festivalstorymaker.Model.DashBord.AllModuleResponse;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.CategoryWiseData.CategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.PosterMaker.PosterMakerResponse;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMakerResponse;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData.StoryCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.StoryMakerResponse;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData.ZoomCollageCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.ZoomCollage.ZoomCollageResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIInterface {

    @FormUrlEncoded
    @POST("getallmodules")
    Call<AllModuleResponse> getAllModule(@Field("token") String token, @Field("application_id") String ApplicationId);

    @FormUrlEncoded
    @POST("getcategory")
    Call<PosterMakerResponse> getModuleWiseCategory(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getthemes")
    Call<CategoryWiseResponse> getCategoryWiseData(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId, @Field("page_no") String PageNo, @Field("parent_cat_id") String ParentCatId, @Field("child_cat_id") String ChildCatId);

    @FormUrlEncoded
    @POST("getcategory")
    Call<StoryMakerResponse> getStoryModuleWiseCategory(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getthemes")
    Call<StoryCategoryWiseResponse> getStoryCategoryWiseData(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId, @Field("page_no") String PageNo, @Field("parent_cat_id") String ParentCatId, @Field("child_cat_id") String ChildCatId);

    @FormUrlEncoded
    @POST("getcategory")
    Call<QuoteMakerResponse> getQuoteModuleWiseCategory(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getthemes")
    Call<QuoteCategoryWiseResponse> getQuoteCategoryWiseData(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId, @Field("page_no") String PageNo, @Field("parent_cat_id") String ParentCatId, @Field("child_cat_id") String ChildCatId);

    @FormUrlEncoded
    @POST("getcategory")
    Call<CollageResponse> getCollageModuleWiseCategory(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getthemes")
    Call<CollageCategoryWiseResponse> getCollageCategoryWiseData(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId, @Field("page_no") String PageNo, @Field("parent_cat_id") String ParentCatId, @Field("child_cat_id") String ChildCatId);


    @FormUrlEncoded
    @POST("getcategory")
    Call<ZoomCollageResponse> getZoomCollageModuleWiseCategory(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getthemes")
    Call<ZoomCollageCategoryWiseResponse> getZoomCollageCategoryWiseData(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId, @Field("page_no") String PageNo, @Field("parent_cat_id") String ParentCatId, @Field("child_cat_id") String ChildCatId);

    @FormUrlEncoded
    @POST("getcollagethemes")
    Call<ElementResponse> getElementDetails(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);

    @FormUrlEncoded
    @POST("getcollagebackthemes")
    Call<BackgroundResponse> getBackgroundDetails(@Field("token") String token, @Field("application_id") String ApplicationId, @Field("module_id") String ModuleId);
}
