package com.kotlinz.videoCollage.adpaters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.interfaces.TextShadowColorAdapterCallBackInterface;
import com.kotlinz.videoeditor.R;

public class TextShadowColorAdapter extends RecyclerView.Adapter<TextShadowColorAdapter.ViewHolder> {
    private Context context;
    public TextShadowColorAdapterCallBackInterface listener;
    public int pos = 1;
    private String[] textColorList;

    public TextShadowColorAdapter(String[] strArr, Context context2, TextShadowColorAdapterCallBackInterface textShadowColorAdapterCallBackInterface) {
        this.textColorList = strArr;
        this.listener = textShadowColorAdapterCallBackInterface;
        this.context = context2;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_text_shadow_color, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = textColorList[i];
        viewHolder.imgTextShadowColor.setBackgroundResource(R.drawable.round_bg_color);
        GradientDrawable gradientDrawable = (GradientDrawable) viewHolder.imgTextShadowColor.getBackground();
        gradientDrawable.setColor(Color.parseColor(str));
        viewHolder.imgTextShadowColor.setBackground(gradientDrawable);
        viewHolder.imgTextShadowColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TextShadowColorAdapter.this.listener.itemClick(i);
                TextShadowColorAdapter.this.notifyDataSetChanged();
            }
        });
        if (this.pos == i) {
            viewHolder.imgTextShadowColorSelector.setBackgroundResource(R.drawable.bg_round_selector);
        } else {
            viewHolder.imgTextShadowColorSelector.setBackgroundResource(R.drawable.bg_round_un_selector);
        }
    }

    public void setPos(int i) {
        this.pos = i;
    }

    public int getItemCount() {
        return this.textColorList.length;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgTextShadowColor;
        ImageView imgTextShadowColorSelector;

        ViewHolder(View view) {
            super(view);
            this.imgTextShadowColor = view.findViewById(R.id.img_text_shadow_color);
            this.imgTextShadowColorSelector = view.findViewById(R.id.img_text_shadow_color_selector);
        }
    }
}
