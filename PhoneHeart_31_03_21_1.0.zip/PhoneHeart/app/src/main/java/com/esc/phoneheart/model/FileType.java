package com.esc.phoneheart.model;

public class FileType {

    public enum FileTypes {
        Image,
        Video,
        Audio,
        Document,
        GIF,
        Others,
        APK,
        ALL
    }
}
