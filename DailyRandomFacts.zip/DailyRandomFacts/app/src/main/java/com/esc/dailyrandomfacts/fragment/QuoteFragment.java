package com.esc.dailyrandomfacts.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.appcompat.widget.AppCompatTextView;

import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;

import com.esc.dailyrandomfacts.R;
import com.esc.dailyrandomfacts.activity.ThemeActivity;
import com.esc.dailyrandomfacts.managers.FavoritesManager;
import com.esc.dailyrandomfacts.managers.PastQuotesManager;
import com.esc.dailyrandomfacts.managers.SettingsManager;
import com.esc.dailyrandomfacts.managers.ThemeManager;
import com.esc.dailyrandomfacts.model.Quote;
import com.esc.dailyrandomfacts.model.Theme;
import com.esc.dailyrandomfacts.util.JsonUtils;
import com.esc.dailyrandomfacts.util.QuoteUtils;
import com.esc.dailyrandomfacts.util.TrackerEventUtils;
import com.esc.dailyrandomfacts.activity.QuotesHomeActivity;

import java.util.Iterator;

public class QuoteFragment extends Fragment {
    public static final String QUOTE = "quote";
    private String quote;
    private View quoteView;
    private View rootView;
    private AppCompatTextView txtQuote;

    public static QuoteFragment newInstance(String str) {
        QuoteFragment quoteFragment = new QuoteFragment();
        Bundle bundle = new Bundle();
        bundle.putString(QUOTE, str);
        quoteFragment.setArguments(bundle);
        return quoteFragment;
    }

//    public void onCreate(Bundle bundle) {
//        super.onCreate(bundle);
//        if (getArguments() != null) {
//            this.quote = getArguments().getString(QUOTE);
//        }
//    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rootView = layoutInflater.inflate(R.layout.fragment_quote, viewGroup, false);
        bindUi();
        setListeners();
        if (getArguments() != null) {
            this.quote = getArguments().getString(QUOTE);
        }
        if (this.quote.contains("SHOW AD #")) {
            setData(this.quote.split("#")[1]);
        } else {
            setData(this.quote);
        }
        return this.rootView;
    }

    private void bindUi() {
        this.txtQuote = this.rootView.findViewById(R.id.txtQuote);
        this.quoteView = this.rootView.findViewById(R.id.llQuoteView);
    }

    private void setListeners() {
        this.quoteView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((QuotesHomeActivity) getActivity()).showNextQuote();
            }
        });
    }

    @SuppressLint("WrongConstant")
    private void setData(String str) {
        Theme theme = ThemeManager.getTheme();
        if (theme != null) {
            if (theme.getName().equals("Default") && SettingsManager.isDarkMode().booleanValue()) {
                theme.setBackground("1A1C1E");
                theme.setColor("FFFFFF");
            }
            setTextStyle(theme);
        }
        Quote quote = QuoteUtils.getQuote(this.txtQuote.getLineCount(), str, false);
        AppCompatTextView appCompatTextView = this.txtQuote;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(quote.getText());
        stringBuilder.append(quote.getAuthor());
        appCompatTextView.setText(stringBuilder.toString());
        if (!(quote.getAuthor() == null || quote.getAuthor().isEmpty())) {
            SpannableString spannableString = new SpannableString(this.txtQuote.getText().toString());
            spannableString.setSpan(new RelativeSizeSpan(0.6f), quote.getText().length(), this.txtQuote.getText().length(), 0);
            this.txtQuote.setText(spannableString);
        }
    }

    @SuppressLint("ResourceType")
    public void setTextStyle(Theme theme) {
        AppCompatTextView appCompatTextView;
        StringBuilder stringBuilder;
        String str = "#";
        if (theme.getColor() != null) {
            appCompatTextView = this.txtQuote;
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(theme.getColor());
            appCompatTextView.setTextColor(Color.parseColor(stringBuilder.toString()));
        }
        if (theme.getLeftAligned() != 0) {
            this.txtQuote.setGravity(3);
        }
        if (theme.getShadowColor() != null) {
            float textSize = this.txtQuote.getTextSize() / 6.0f;
            AppCompatTextView appCompatTextView2 = this.txtQuote;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str);
            stringBuilder2.append(theme.getShadowColor());
            appCompatTextView2.setShadowLayer(textSize, 0.0f, 0.0f, Color.parseColor(stringBuilder2.toString()));
        } else {
            this.txtQuote.setShadowLayer(0.0f, 0.0f, 0.0f, R.color.transparent);
        }
        appCompatTextView = this.txtQuote;
        AssetManager assets = getActivity().getAssets();
        stringBuilder = new StringBuilder();
        stringBuilder.append(theme.getFont());
        stringBuilder.append(".ttf");
        appCompatTextView.setTypeface(Typeface.createFromAsset(assets, stringBuilder.toString()));
        this.txtQuote.setBackgroundColor(getResources().getColor(17170445));
    }

    public void setUserVisibleHint(boolean z) {
        super.setUserVisibleHint(z);
        if (z && isResumed()) {
            onResume();
        }
    }

    public void onResume() {
        super.onResume();
        if (getUserVisibleHint()) {
            if (this.quote.contains("SHOW AD #")) {
                PastQuotesManager.addPastQuote(this.quote.split("#")[1]);
            } else {
                PastQuotesManager.addPastQuote(this.quote);
            }
        }
    }

    public void setFavoriteStatus() {
        int parseColor;
        Theme theme = ThemeManager.getTheme();
        if (theme == null) {
            theme = getDefaultTheme();
            ThemeManager.saveThemeData(theme);
        }
        if (theme.getColor() != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("#");
            stringBuilder.append(theme.getColor());
            parseColor = Color.parseColor(stringBuilder.toString());
        } else {
            parseColor = Color.parseColor("#ffffff");
        }
    }

    private Theme getDefaultTheme() {
        Iterator it = JsonUtils.getThemes(getContext()).iterator();
        while (it.hasNext()) {
            Theme theme = (Theme) it.next();
            if (theme.getName().equalsIgnoreCase(getString(R.string.default_th))) {
                return theme;
            }
        }
        return null;
    }
}
