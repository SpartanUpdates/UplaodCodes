package com.Pulse.VideoStatus.Model;

public class TabIcon {

}
