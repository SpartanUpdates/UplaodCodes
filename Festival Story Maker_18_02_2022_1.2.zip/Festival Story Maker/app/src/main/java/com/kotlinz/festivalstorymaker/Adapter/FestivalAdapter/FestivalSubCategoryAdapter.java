package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.AppUtils.Utils;
import com.kotlinz.festivalstorymaker.AppUtils.View.AVLoadingView.AVLoadingIndicatorView;
import com.kotlinz.festivalstorymaker.Download.StoryThemeDownload;
import com.kotlinz.festivalstorymaker.Model.FestivalPoster.categoryWiseData.CategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.StoryMaker.CategoryWiseData.StoryCategoryWiseData;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.Utils.Constant;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.activity.FestivalTemplateActivity;
import com.kotlinz.festivalstorymaker.activity.StoryMakerActivity;

import java.io.File;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FestivalSubCategoryAdapter extends RecyclerView.Adapter<FestivalSubCategoryAdapter.MyViewHolder> {

    public FestivalTemplateActivity festivalActivity;
    public int position = -1;
    public ArrayList<CategoryWiseData> festivalsubCategoryList;


    public FestivalSubCategoryAdapter(Context context, ArrayList<CategoryWiseData> storysubCategoryList) {
        this.festivalActivity = (FestivalTemplateActivity) context;
        this.festivalsubCategoryList = storysubCategoryList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_festival_subcategory, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        CategoryWiseData festivalCategoryWiseData = festivalsubCategoryList.get(position);

        Glide.with(festivalActivity).load(festivalsubCategoryList.get(position).getThemeThumbnail()).centerCrop().placeholder(R.drawable.ic_placehoder).into(holder.ivCategoryThumb);

        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*DownloadFile(position, holder.ivDownload, holder.ThemeDownProgress, holder.indicatorThemeProgress, holder.tvThemeDownProgress, storyCategoryWiseData);*/
                festivalActivity.startActivity(new Intent(festivalActivity, FestivalDetailActivity_New.class).putExtra("image", festivalCategoryWiseData.getThemeThumbnail()).putExtra("catid", festivalActivity.FestivalCategoryId));
            }
        });
    }

    @Override
    public int getItemCount() {
        return festivalsubCategoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.llMain)
        public CardView llMain;
        @BindView(R.id.ivCategoryThumb)
        public ImageView ivCategoryThumb;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

