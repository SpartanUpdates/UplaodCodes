package com.xyz.vehiclemanager.car.CarVarianDetails.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.adapter.VariantItemAttrAdapter;
import com.xyz.vehiclemanager.car.CarVarianDetails.activity.CarVariantTabActivity;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarOverview;
import com.xyz.vehiclemanager.car.CarVarianDetails.model.CarVariantRoot;
import com.xyz.vehiclemanager.model.Item;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CarOverViewFragment extends Fragment {
    private View view;
    private RecyclerView overviewRecycleView;
    private ArrayList<Item> overViewDataList = new ArrayList<>();
    private VariantItemAttrAdapter variantItemAttrAdapter;
    private RtoDetailsInterface rv_variantdetails;
    private TextView tv_title;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_variant_details, container, false);

        rv_variantdetails = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        overviewRecycleView = view.findViewById(R.id.rv_variantdetails);
        tv_title = view.findViewById(R.id.tv_title);
        getOverviewVariantData();
        return view;
    }
    private void getOverviewVariantData() {
        Call<CarVariantRoot> call = rv_variantdetails.getCarVariantsDetail(CarVariantTabActivity.varientId);
        call.enqueue(new Callback<CarVariantRoot>() {
            @Override
            public void onResponse(Call<CarVariantRoot> call, Response<CarVariantRoot> response) {
                if (response.isSuccessful())
                {
                    tv_title.setText("OverView");
                    if (CarVariantTabActivity.dialog != null && CarVariantTabActivity.dialog.isShowing())
                    {
                        CarVariantTabActivity.dialog.dismiss();
                    }
                    ArrayList<CarOverview> variantlist = response.body().getDetails().getOverview();
                    for (int i = 0; i < variantlist.size(); i++)
                    {
                        String key = variantlist.get(i).getKey();
                        ArrayList<Item> itemlist = response.body().getDetails().getOverview().get(i).getItems();
                        for (int j = 0; j < itemlist.size(); j++)
                        {
                            Item item = new Item();
                            String sAttrName = itemlist.get(j).getAttrName();
                            String sAttrValue = itemlist.get(j).getAttrValue();
                            item.setAttrName(sAttrName);
                            item.setAttrValue(sAttrValue);
                            overViewDataList.add(item);
                        }
                        variantItemAttrAdapter = new VariantItemAttrAdapter(getActivity(), overViewDataList);
                        overviewRecycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
                        overviewRecycleView.setAdapter(variantItemAttrAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<CarVariantRoot> call, Throwable t) {
                if (CarVariantTabActivity.dialog != null && CarVariantTabActivity.dialog.isShowing())
                {
                    CarVariantTabActivity.dialog.dismiss();
                }
               Toast.makeText(getActivity(), "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }
}