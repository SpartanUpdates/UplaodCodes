package com.vidsoft.collagemaker.Adapters;

import android.app.Activity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.vidsoft.collagemaker.pipphotoeffect.R;
import com.vidsoft.collagemaker.Utils.Const;

public class BottomAdapter extends Adapter<BottomAdapter.ViewHolder> {
    String Selection;
    Activity activity;
    BottomCallback bottomCallback;
    int[] list;

    public interface BottomCallback {
        void BottomMethod(int i);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout border;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.imageView = (ImageView) itemView.findViewById(R.id.imageView);
            this.border = (LinearLayout) itemView.findViewById(R.id.rl_border);
        }
    }

    public BottomAdapter(Activity activity, int[] list) {
        this.Selection = "0";
        this.list = list;
        this.activity = activity;
        this.bottomCallback = (BottomCallback) activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.bottom_lay_adapter, parent, false));
    }

    public void onBindViewHolder(ViewHolder holder, final int position) {
        if (position == Integer.parseInt(this.Selection)) {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.selectedColor));
        } else {
            holder.imageView.setColorFilter(ContextCompat.getColor(this.activity, Const.normalColor));
        }
        Glide.with(this.activity).load(Integer.valueOf(this.list[position])).into(holder.imageView);
        holder.border.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomAdapter.this.Selection = String.valueOf(position);
                BottomAdapter.this.notifyDataSetChanged();
                BottomAdapter.this.bottomCallback.BottomMethod(position);

            }
        });
    }

    public int getItemCount() {
        return this.list.length;
    }
}