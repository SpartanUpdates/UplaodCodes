package com.xyz.vehiclemanager.bike.BikeVariantDetails.model;

import com.google.gson.annotations.SerializedName;
import com.xyz.vehiclemanager.model.Item;

import java.util.ArrayList;

public class BikeOverview
{
    @SerializedName("key")
    public String key;
    @SerializedName("items")
    public ArrayList<Item> items;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }
}
