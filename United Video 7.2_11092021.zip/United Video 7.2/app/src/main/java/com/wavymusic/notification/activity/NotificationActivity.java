package com.wavymusic.notification.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.DashBord.View.AVLoadingView.AVLoadingIndicatorView;
import com.wavymusic.DashBord.activity.DashbordActivity;
import com.wavymusic.Partical.Model.ParticalCategoryModel;
import com.wavymusic.Partical.Model.ParticalItemModel;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.APIClient;
import com.wavymusic.RetrofitApiCall.APIInterface;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.kprogresshud.KProgressHUD;
import com.wavymusic.notification.Download.DownloadFile;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = NotificationActivity.this;
    ImageView ivBack;
    public LinearLayout layoutDownload;
    public ImageView ivThumb;
    public ImageView ivThumbDownload;
    public ImageView ivUseTheme;
    public TextView tvVideoName, tvProgress;
    public AVLoadingIndicatorView indicatorView;
    public RelativeLayout layoutNotification;


    GGAdview gg_banner;
    public GGInterstitialAd interstitialAd;

    public SharedPreferences pref;
    public boolean isParticlesApiRunning = false;
    APIInterface apiInterfaceUv;
    public boolean IsNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        apiInterfaceUv = APIClient.getClientUv().create(APIInterface.class);
        IsNotification = getIntent().getBooleanExtra("IsFromNotification", false);
        BindView();
        PutAnalyticsEvent();
        SetAssetTheme();
        if (MyApplication.notificcationModels != null && MyApplication.notificcationModels.size() != 0) {
            tvVideoName.setText(MyApplication.notificcationModels.get(0).getThemeName());
            Glide.with(activity).load(MyApplication.notificcationModels.get(0).getThemeThumbnail()).diskCacheStrategy(DiskCacheStrategy.ALL).into(ivThumb);
            if (new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(0).getSongFileName()).exists() && new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(0).getParticalBundelName()).exists()) {
                ivThumbDownload.setVisibility(View.GONE);
                tvProgress.setVisibility(View.GONE);
                ivUseTheme.setVisibility(View.VISIBLE);
            }
        }
        BannerAds();
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdClosed() {
                GoToPreview();
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void BindView() {
        ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(this);
        ivThumb = findViewById(R.id.ivThumb);
        tvVideoName = findViewById(R.id.tvVideoName);
        tvProgress = findViewById(R.id.tv_Progress);
        ivThumbDownload = findViewById(R.id.ivThumbDownload);
        indicatorView = findViewById(R.id.indicator);
        layoutDownload = findViewById(R.id.ll_download);
        ivUseTheme = findViewById(R.id.ivUseTheme);
        layoutNotification = findViewById(R.id.rlnotification);

        layoutNotification.setOnClickListener(this);
        ivUseTheme.setOnClickListener(this);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "NotificationActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void DownloadFile(int position) {
        if (MyApplication.notificcationModels != null && MyApplication.notificcationModels.size() != 0) {
            MyApplication.NotificationPath = MyApplication.notificcationModels.get(position).getSoundPath() + MyApplication.SPLIT_PATTERN + Utils.INSTANCE.getThemeFolderPath() + File.separator + MyApplication.notificcationModels.get(position).getThemeName() + ".png" + MyApplication.SPLIT_PATTERN + MyApplication.notificcationModels.get(position).getBundelPath() + MyApplication.SPLIT_PATTERN + MyApplication.notificcationModels.get(position).getGameobjectName() + MyApplication.SPLIT_PATTERN + AppConstant.ThemeHome;
            MyApplication.ParticalCatid = MyApplication.notificcationModels.get(position).getParticleCategoryName();
            MyApplication.ThemeAssetCatSelectedPosition = MyApplication.notificcationModels.get(position).getParticleCategoryName();
            MyApplication.ThemeAssetSelectedPosition = MyApplication.notificcationModels.get(position).getParticalName();

            int SoundFileSize = Integer.parseInt(String.valueOf(new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(position).getSongFileName()).length()));
            int ParticalSize = Integer.parseInt(String.valueOf(new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(position).getParticalBundelName()).length()));
            if (new File(Utils.INSTANCE.getThemeFolderPath() + MyApplication.notificcationModels.get(position).getSongFileName()).exists() && new File(Utils.INSTANCE.getNotification() + MyApplication.notificcationModels.get(position).getParticalBundelName()).exists()) {
                if (SoundFileSize == MyApplication.notificcationModels.get(position).getSongSize() && ParticalSize == MyApplication.notificcationModels.get(position).getParticalSize()) {
                    if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                        interstitialAd.show();
                    } else {
                        GoToPreview();
                    }
                } else {
                    if (Utils.checkConnectivity(activity, true)) {
                        ivThumbDownload.setVisibility(View.GONE);
                        tvProgress.setVisibility(View.VISIBLE);
                        new DownloadFile(activity, ivThumbDownload, ivUseTheme, tvProgress, MyApplication.notificcationModels);
                    } else {
                        Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                    }
                }
            } else {
                if (Utils.checkConnectivity(activity, true)) {
                    ivThumbDownload.setVisibility(View.GONE);
                    tvProgress.setVisibility(View.VISIBLE);
                    new DownloadFile(activity, ivThumbDownload, ivUseTheme, tvProgress, MyApplication.notificcationModels);
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void GoToPreview() {
        UnityPlayer.UnitySendMessage("AndroidManager", "GoWavyPreview", MyApplication.NotificationPath);
        MyApplication.DashbordAct.finish();
        ShowBannerAds();
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                onBackPressed();
                break;
            case R.id.rlnotification:
                DownloadFile(0);
                break;
        }
    }

    public String getFileFormAsset() {
        try {
            InputStream open = getAssets().open("asset_bundel.json");
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    private void SetAssetTheme() {
        if (Utils.checkConnectivity(activity, false)) {
            if (!isParticlesApiRunning) {
                ParticalWavy();
            }
        } else {
            if (pref.getString("offlineParticles", "").equalsIgnoreCase("")) {
                SetParticlesData(getFileFormAsset());
            } else {
                SetParticlesData(pref.getString("offlineParticles", ""));
            }
        }
    }

    private void ParticalWavy() {
        isParticlesApiRunning = true;
        Call<JsonObject> call = apiInterfaceUv.ParticalWavy(AppConstant.Token, AppConstant.ParticleApplicationId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineParticle(activity, jsonObj.toString(), "offlineParticles");
                        //Set Response Time
                        SetOfflineParticleTime(activity, new Date(), "offlineParticlesTime");
                        isParticlesApiRunning = false;
                        if (!MyApplication.isEditCallWavy) {
                            SetParticlesData(jsonObj.toString());
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }


    public void SetParticlesData(String result) {
        if (result != null) {
            if (UnityPlayerActivity.unityPlayeractivity.particalCategoryModels != null) {
                Utils.INSTANCE.particalAssetModels.clear();
                UnityPlayerActivity.unityPlayeractivity.particalCategoryModels.clear();
            }
            final String bundelpath = Utils.INSTANCE.getAssetUnityPath();
            try {
                JSONObject jsonObj = new JSONObject(result);
                String AssetUrl = jsonObj.getString("theme_bundle_url");
                String ParticalThumbUrl = jsonObj.getString("theme_thumb_url");
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); ++i) {
                    final JSONObject jsonObject = jsonArray.getJSONObject(i);
                    ParticalCategoryModel particalCategoryModel = new ParticalCategoryModel();
                    particalCategoryModel.setCatId(jsonObject.getString("id"));
                    particalCategoryModel.setCatName(jsonObject.getString("name"));
                    UnityPlayerActivity.unityPlayeractivity.particalCategoryModels.add(particalCategoryModel);
                    JSONArray jSONArray4 = jsonObject.getJSONArray("themes");
                    for (int j = 0; j < jSONArray4.length(); j++) {
                        JSONObject themeJSONObject = jSONArray4.getJSONObject(j);
                        final ParticalItemModel particalModel = new ParticalItemModel();
                        particalModel.setThemeId(Integer.parseInt(themeJSONObject.getString("theme_id")));
                        particalModel.setParticalCatName(particalCategoryModel.getCatName());
                        particalModel.setCatId(Integer.parseInt(themeJSONObject.getString("cat_name")));
                        particalModel.setThemeName(themeJSONObject.getString("theme_name"));
                        particalModel.setBundelName(themeJSONObject.getString("theme_name") + ".zip");
                        particalModel.setBundelSize(Integer.parseInt(themeJSONObject.getString("bundle_size")));
                        particalModel.isAvailableOffline = CheckFileExistWithSize(new File(Utils.PathOfAssetFolder).getAbsolutePath() + File.separator + particalModel.getBundelName(), particalModel.getBundelSize());
                        particalModel.setGmaeObjName(themeJSONObject.getString("game_object_name"));
                        particalModel.setIsPreimum(themeJSONObject.getString("is_premuim"));
                        if (themeJSONObject.getString("from_asset").equals("true")) {
                            particalModel.setFromAsset(true);
                            particalModel.setThemeBundel(AssetUrl + themeJSONObject.getString("theme_bundle"));
                            particalModel.setThumbImage(ParticalThumbUrl + themeJSONObject.getString("theme_thumbnail"));
                        } else {
                            particalModel.setFromAsset(false);
                            particalModel.setThemeBundel(AssetUrl + themeJSONObject.getString("theme_bundle"));
                            particalModel.setThumbImage(ParticalThumbUrl + themeJSONObject.getString("theme_thumbnail"));
                        }
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(bundelpath);
                        sb2.append(particalModel.getThemeName());
                        sb2.append(File.separator);
                        sb2.append(particalModel.getThemeName());
                        sb2.append(".unity3d");
                        particalModel.setThemeUnity3dPath(sb2.toString());
                        UnityPlayerActivity.unityPlayeractivity.particalListModels.add(particalModel);
                        Utils.INSTANCE.particalAssetModels.add(particalModel);
                    }
                }
            } catch (JSONException ex2) {
                ex2.printStackTrace();
            }
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void SetOfflineParticle(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineParticleTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    public boolean CheckFileExistWithSize(String file, int size) {
        return new File(file).exists() && new File(file).length() >= size;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, DashbordActivity.class));
        finish();
    }
}