﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class PlayerSelection : MonoBehaviour
    {
        public static PlayerSelection instance;

        public int unlockAmount = 700;

        public DragRect scrollRact;

        public GameObject[] playerBtn;

        public GameObject[] ballBtn;

        public GameObject unlockLable;

        public Image showPlayer;

        public Text unlockTxt, unlockTxt2;

        public MeshRenderer playerMesh;

        public Material playerColor, playerSkin, ballMaterial;

        public Texture[] playerSkinTexture;

        public Sprite[] ballImage, playerImage;
        private void Awake()
        {
            instance = this;
            unlockLable.SetActive(false);

        }
        void Start()
        {
            unlockAmount = 700;
            ChangePlayer();
            ChangeBall();
        }
        public void ChangePlayer()
        {
            if (DataBase.GetPlayer() <= 9)
            {
                playerMesh.material = playerColor;
                try
                {
                    playerMesh.material.color = ColorManager.PlayerColor[DataBase.GetPlayer() - 1];
                }
                catch (System.Exception e) { }
            }
            else
            {
                playerMesh.material = playerSkin;
                playerMesh.material.SetTexture("_MainTex", playerSkinTexture[DataBase.GetPlayer() - 1]);
            }
        }
        public void ChangeBall()
        {
            try
            {
                ballMaterial.color = ColorManager.ballColors[DataBase.GetBall() - 1];
            }
            catch (System.Exception e) { }
        }
        public void PageChange(int index)
        {
            SoundManger.instance.PlaySound("BtnClick");
        Analytics.CustomEvent("Setting_Page_Change", new Dictionary<string, object>
        {
            { "Page_No", index }
        });
            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);

            scrollRact.ChangePage(index);
        }

        public void SelectPlayer(int Playerno)
        {
            SoundManger.instance.PlaySound("BtnClick");
            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);

            Analytics.CustomEvent("Select_Player_Button");
            if (PlayerPrefs.GetInt("Player" + Playerno) == 0)
            {
                if (DataBase.GetCoins() >= unlockAmount)
                {
                    PlayerPrefs.SetInt("Player" + Playerno, 1);
                    DataBase.SetCoins(DataBase.GetCoins() - unlockAmount);
                    GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                    unlockLable.SetActive(false);
                    showPlayer.sprite = playerImage[Playerno - 1];
                    playerBtn[Playerno - 1].GetComponent<CheckUnlock>().CheckButton();
                    DataBase.SetPlayer(Playerno);
                    for (int i = 0; i < playerBtn.Length; i++)
                    {
                        playerBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                    }
                    playerBtn[Playerno - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                    Analytics.CustomEvent("Player_Purchase_SuccessFully_"+Playerno);
                }
                else
                {
                    unlockLable.SetActive(false);
                    StartCoroutine(playerBtn[Playerno - 1].GetComponent<CheckUnlock>().UnLockColor());
                    unlockLable.SetActive(true);
                    Analytics.CustomEvent("Player_Purchase_Not_Enough_Coin");
                }
            }
            else
            {
                showPlayer.sprite = playerImage[Playerno - 1];
                DataBase.SetPlayer(Playerno);
                for (int i = 0; i < playerBtn.Length; i++)
                {
                    playerBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                }
                playerBtn[Playerno - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                Analytics.CustomEvent("Purchase_Player_Change");
            }
            ChangePlayer();
        }


        public void SelectBall(int ballNo)
        {
            SoundManger.instance.PlaySound("BtnClick");

            if (GameController.instance.isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);
            Analytics.CustomEvent("Select_Ball_Button");
            if (PlayerPrefs.GetInt("Ball" + ballNo) == 0)
            {
                if (DataBase.GetCoins() >= unlockAmount)
                {
                    PlayerPrefs.SetInt("Ball" + ballNo, 1);
                    DataBase.SetCoins(DataBase.GetCoins() - unlockAmount);
                    GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                    unlockLable.SetActive(false);
                    showPlayer.sprite = ballImage[ballNo - 1];//EventSystem.current.currentSelectedGameObject.transform.GetChild(0).GetComponent<Image>().sprite;
                    ballBtn[ballNo - 1].GetComponent<CheckUnlock>().CheckButton();
                    DataBase.SetBall(ballNo);
                    for (int i = 0; i < ballBtn.Length; i++)
                    {
                        ballBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                    }
                    ballBtn[ballNo - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                    Analytics.CustomEvent("Ball_Purchase_SuccessFully_"+ballNo);
                }
                else
                {
                    unlockLable.SetActive(false);
                    StartCoroutine(ballBtn[ballNo - 1].GetComponent<CheckUnlock>().UnLockColor());
                    unlockLable.SetActive(true);
                    Analytics.CustomEvent("Ball_Purchase_Not_Enough_Coin");

                }
            }
            else
            {
                unlockLable.SetActive(false);
                showPlayer.sprite = ballImage[ballNo - 1];
                DataBase.SetBall(ballNo);
                for (int i = 0; i < ballBtn.Length; i++)
                {
                    ballBtn[i].GetComponent<CheckUnlock>().UnlockImage();
                }
                ballBtn[ballNo - 1].GetComponent<CheckUnlock>().unlockImg.SetActive(true);
                Analytics.CustomEvent("Purchase_Ball_Change");

            }
            ChangeBall();
        }
        void OnApplicationQuit()
        {
            ballMaterial.color = ColorManager.ballColors[0];
        }
    }
}