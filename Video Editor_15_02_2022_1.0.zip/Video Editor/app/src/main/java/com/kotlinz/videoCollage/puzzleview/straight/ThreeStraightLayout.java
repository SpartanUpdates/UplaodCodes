package com.kotlinz.videoCollage.puzzleview.straight;


import com.kotlinz.videoCollage.flying.puzzle.Line;

public class ThreeStraightLayout extends NumberStraightLayout {
    public int getThemeCount() {
        return 6;
    }

    public ThreeStraightLayout(int i) {
        super(i);
    }

    public void layout() {
        int i = this.theme;
        if (i == 0) {
            cutAreaEqualPart(0, 3, Line.Direction.HORIZONTAL);
        } else if (i == 1) {
            cutAreaEqualPart(0, 3, Line.Direction.VERTICAL);
        } else if (i == 2) {
            addLine(0, Line.Direction.HORIZONTAL, 0.5f);
            addLine(0, Line.Direction.VERTICAL, 0.5f);
        } else if (i == 3) {
            addLine(0, Line.Direction.HORIZONTAL, 0.5f);
            addLine(1, Line.Direction.VERTICAL, 0.5f);
        } else if (i == 4) {
            addLine(0, Line.Direction.VERTICAL, 0.5f);
            addLine(0, Line.Direction.HORIZONTAL, 0.5f);
        } else if (i != 5) {
            cutAreaEqualPart(0, 3, Line.Direction.HORIZONTAL);
        } else {
            addLine(0, Line.Direction.VERTICAL, 0.5f);
            addLine(1, Line.Direction.HORIZONTAL, 0.5f);
        }
    }
}
