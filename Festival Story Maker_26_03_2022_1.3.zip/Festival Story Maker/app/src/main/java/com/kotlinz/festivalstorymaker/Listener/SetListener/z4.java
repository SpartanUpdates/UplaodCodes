package com.kotlinz.festivalstorymaker.Listener.SetListener;


import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;

public class z4 implements ImageStickerViewNew.c {
    public final FrameEditorNewDesign a;

    public z4(final FrameEditorNewDesign a) {
        this.a = a;
    }

    @Override
    public void a(final ImageStickerViewNew j1) {
        j1.setInEdit(false);
        j1.setInEdit(true);
        this.a.j1 = j1;
    }

    @Override
    public void b(final ImageStickerViewNew imageStickerViewNew) {
    }

    @Override
    public void c(final Boolean b) {
        this.a.scroll.requestDisallowInterceptTouchEvent((boolean) b);
    }

    @Override
    public void d(final ImageStickerViewNew imageStickerViewNew) {
    }
}
