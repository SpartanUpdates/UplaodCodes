package com.kotlinz.videoCollage.puzzleview.slant;

import android.util.Log;
import com.kotlinz.videoCollage.flying.puzzle.slant.SlantPuzzleLayout;


public abstract class NumberSlantLayout extends SlantPuzzleLayout {
    static final String TAG = "NumberSlantLayout";
    protected int theme;

    public abstract int getThemeCount();

    public NumberSlantLayout(int i) {
        if (i >= getThemeCount()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("NumberSlantLayout: the most theme count is ");
            stringBuilder.append(getThemeCount());
            stringBuilder.append(" ,you should let theme from 0 to ");
            stringBuilder.append(getThemeCount() - 1);
            stringBuilder.append(" .");
            Log.e(TAG, stringBuilder.toString());
        }
        this.theme = i;
    }

    public int getTheme() {
        return this.theme;
    }
}
