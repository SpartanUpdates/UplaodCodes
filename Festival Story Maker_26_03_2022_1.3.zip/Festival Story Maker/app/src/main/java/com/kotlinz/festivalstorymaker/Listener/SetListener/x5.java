package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.Color;
import android.view.View;

import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class x5 implements View.OnClickListener {
    FrameEditorNewDesign frameEditorNewDesign;
    public final int e;
    public final FrameEditorNewDesign.ColorListAdapter f;

    public x5(FrameEditorNewDesign frameEditorNewDesign,final FrameEditorNewDesign.ColorListAdapter f, final int e) {
        this.f = f;
        this.e = e;
        this.frameEditorNewDesign = frameEditorNewDesign;
    }

    public void onClick(final View view) {
        final FrameEditorNewDesign.ColorListAdapter f = this.f;
        /* FrameEditorNewDesign.h0(f.i, Color.parseColor(f.h[this.e]));*/
        frameEditorNewDesign.o0(Color.parseColor(f.h[this.e]));

    }
}
