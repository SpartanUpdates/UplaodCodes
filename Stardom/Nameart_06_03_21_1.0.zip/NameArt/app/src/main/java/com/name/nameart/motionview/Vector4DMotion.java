package com.name.nameart.motionview;

import android.graphics.PointF;

public class Vector4DMotion extends PointF {

    public Vector4DMotion() {

    }

    public static float getAngle(Vector4DMotion vector4DMotion, Vector4DMotion vector4DMotion2) {
        vector4DMotion.normalize();
        vector4DMotion2.normalize();
        return (float) ((Math.atan2((double) vector4DMotion2.y, (double) vector4DMotion2.x) - Math.atan2((double) vector4DMotion.y, (double) vector4DMotion.x)) * 57.29577951308232d);
    }

    public void normalize() {
        float sqrt = (float) Math.sqrt((double) ((this.x * this.x) + (this.y * this.y)));
        this.x /= sqrt;
        this.y /= sqrt;
    }
}
