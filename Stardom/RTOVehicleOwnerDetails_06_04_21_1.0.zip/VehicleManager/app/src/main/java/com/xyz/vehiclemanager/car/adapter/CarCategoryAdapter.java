package com.xyz.vehiclemanager.car.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.car.activity.CarVariantActivity;
import com.xyz.vehiclemanager.car.model.CarBrandCategory;
import com.xyz.vehiclemanager.favourite.Room.FavoriteDatabase;
import com.xyz.vehiclemanager.favourite.model.FavoriteCarModel;

import java.util.ArrayList;
import java.util.List;

public class CarCategoryAdapter extends RecyclerView.Adapter<CarCategoryAdapter.ViewHolder> {
    private Context context;
    private ArrayList<CarBrandCategory> carCategorylist;


    public CarCategoryAdapter(Context context, ArrayList<CarBrandCategory> categorylist) {
        this.context = context;
        this.carCategorylist = categorylist;

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView bikeModelImage;
        TextView bikeModelName;
        TextView bikePrice;
        LikeButton likeButton;
        LinearLayout ll_main;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bikeModelImage = itemView.findViewById(R.id.iv_category);
            bikeModelName = itemView.findViewById(R.id.tv_carname);
            bikePrice = itemView.findViewById(R.id.tv_modelprice);
            likeButton = itemView.findViewById(R.id.likeButton);
            ll_main = itemView.findViewById(R.id.ll_main);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CarBrandCategory categorylist = carCategorylist.get(position);
        final String id = categorylist.getId();
        holder.bikeModelName.setText(categorylist.getCarModelName());
        holder.bikePrice.setText(categorylist.getExShowroomPrice());

        final String imageurl = categorylist.getImageUrl();

        Glide.with(context)
                .load(categorylist.getImageUrl())
                .placeholder(R.drawable.ic_car)
                .into(holder.bikeModelImage);

        holder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CarVariantActivity.class);
                intent.putExtra("modelId", id);
                intent.putExtra("modelName", categorylist.getCarModelName());
                intent.putExtra("imageUrl", imageurl);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        holder.setIsRecyclable(false);
        List<FavoriteCarModel> favoriteCarModelList = FavoriteDatabase.getFavoriteDatabase(context).favoriteCarDao().getFavoriteCarList();
        for (int i = 0; i < favoriteCarModelList.size(); i++) {
            if (favoriteCarModelList.get(i).getModelId().equals(id)) {
                holder.likeButton.setLiked(true);
            }
        }
        holder.likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteCarModel favoriteCarModel = new FavoriteCarModel(id, categorylist.getCarModelName(), categorylist.getExShowroomPrice(), categorylist.getImageUrl());
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteCarDao().insertCarFavorite(favoriteCarModel);
                    }
                });
                thread.start();
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                Thread thread=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        FavoriteDatabase.getFavoriteDatabase(context).favoriteCarDao().deleteCarFavorite(id);
                    }
                });
                thread.start();

            }
        });
    }

    @Override
    public int getItemCount() {
        return carCategorylist.size();
    }
}
