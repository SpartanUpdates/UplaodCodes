package com.UnitedVideos.CropImage.photoview.scrollerproxy;

import android.content.Context;
import android.widget.Scroller;

public class PreGingerScroller
        extends ScrollerProxy {
    private final Scroller mScroller;

    public PreGingerScroller(Context context) {
        mScroller = new Scroller(context);
    }

    public boolean computeScrollOffset() {
        return mScroller.computeScrollOffset();
    }


    public void fling(int startX, int startY, int velocityX, int velocityY, int minX, int maxX, int minY, int maxY, int overX, int overY) {
        mScroller.fling(startX, startY, velocityX, velocityY, minX, maxX, minY, maxY);
    }

    public void forceFinished(boolean finished) {
        mScroller.forceFinished(finished);
    }

    public boolean isFinished() {
        return mScroller.isFinished();
    }

    public int getCurrX() {
        return mScroller.getCurrX();
    }

    public int getCurrY() {
        return mScroller.getCurrY();
    }
}
