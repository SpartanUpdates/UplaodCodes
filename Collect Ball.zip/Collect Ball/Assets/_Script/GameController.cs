﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

namespace BallCollect
{
    public class GameController : MonoBehaviour
    {
        public static GameController instance;

        public GameObject currentLevel;

        public GameObject destroyLevel;

        public Vector3 camStartPos = new Vector3(0, 8.5f, -9), camStartRotate = new Vector3(30, 0, 0);

        public GameObject[] Levels;

        public GameObject gameOverPanel, levelFinishPanel, gameHud, pausePanel, pauseButton;

        public GameObject gameOverP1, gameOverP2;

        public bool isGameOver = false, isPlayable = false, isPaues = false;

        public int currentLevelNo;

        public Text curLeveltext, nextLevelText, coinText, goLevelNo, goLevelNo2, finishLevelNo, txtScore, txtScoreGo, txtScoreGo2;

        public GameObject[] pointImage;

        public int colorNo, nextLevelColor, oceneColor;

        public MeshRenderer[] startPlatfrom;

        public Texture[] oceanTexture;

        [HideInInspector]
        public bool isGameCoti = true;  // COlor Manager 

        public GameObject mainPanel;

        [HideInInspector]
        public bool isSound, isVibrate;

        public GameObject buttonRestart, btnHome;

        public Image saveMeRing;

        public Button saveMebutton;

        int saveMechance = 02;

        public int levelScore = 0;

        public GameObject noAddPanel, noAddText,noAddInter;

        public bool isLCompleteClick = false, isRestartClick = false, isHomeClick = false;

        bool isSaveMeProcess = false, isLevelFinish = false;

        public Animator star;
        private void Awake()
        {
            instance = this;
            gameOverPanel.SetActive(false);
            levelFinishPanel.SetActive(false);
            noAddPanel.SetActive(false);
            noAddInter.SetActive(false);
            if (!PlayerPrefs.HasKey("isFirstTime"))
            {
                DataBase.SetCurrentLevel(1);
                PlayerPrefs.SetInt("isFirstTime", 1);
                PlayerPrefs.SetInt("IsRestart", 0);
                PlayerPrefs.SetInt("CurrentPlayer", 1);
                PlayerPrefs.SetInt("CurrentBall", 1);
            }

            if (Manager.instance.isLastColor == 1)
            {
                colorNo = Manager.instance.colorNo;
                oceneColor = Manager.instance.oceneNo;
                Manager.instance.isLastColor = 0;
            }
            else
            {
                colorNo = UnityEngine.Random.Range(0, ColorManager.PlatfromColor.Length);
                oceneColor = UnityEngine.Random.Range(0, ColorManager.oceanColors.Length);
            }

            nextLevelColor = UnityEngine.Random.Range(0, ColorManager.PlatfromColor.Length);

            for (int i = 0; i < startPlatfrom.Length; i++)
            {
                startPlatfrom[i].material.color = ColorManager.PlatfromColor[colorNo];
                startPlatfrom[i].material.SetVector("_EmissionColor", ColorManager.PlatfromColor[colorNo]);
            }

            if (DataBase.GetCurrentLevel() > Levels.Length)
            {
                currentLevel = Instantiate(Levels[DataBase.GetLastLevel()], transform.position, Quaternion.identity);
            }
            else
            {
                currentLevel = Instantiate(Levels[DataBase.GetCurrentLevel() - 1], transform.position, Quaternion.identity);
            }
            currentLevelNo = DataBase.GetCurrentLevel();
            gameHud.SetActive(false);
            curLeveltext.text = DataBase.GetCurrentLevel().ToString();
            nextLevelText.text = (DataBase.GetCurrentLevel() + 1).ToString();
            coinText.text = DataBase.GetCoins().ToString();
        }
        public Text saveMeCounter;
        private void Update()
        {
            if (Application.platform != RuntimePlatform.Android)
            {
                MainMenu.instance.isVibrate = false;
                GameController.instance.isVibrate = false;
            }

            if (isGameOver)
            {
                if (isSaveMeProcess)
                {

                    if (saveMeRing.fillAmount >= 1f)
                    {
                        saveMebutton.interactable = false;
                        isSaveMeProcess = false;
                        return;
                    }

                    saveMeRing.fillAmount += 0.002f;

                    saveMeCounter.text = "" + ((1 - saveMeRing.fillAmount) * 10).ToString("0");
                    if (saveMeRing.fillAmount > 0.3f)
                    {
                        buttonRestart.GetComponent<Button>().interactable = true;
                        btnHome.GetComponent<Button>().interactable = true;
                    }
                }
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (isPlayable && !isGameOver && !isLevelFinish && !pausePanel.activeSelf)
                {
                        btnPause();
                }
                else if (isPlayable && !isGameOver && !isLevelFinish && pausePanel.activeSelf)
                {
                        btnPauseClose();
                }
            }
        }

        bool isVibrateWait = false;
        public void BallTouchVibrate()
        {
            if (!isVibrateWait)
            {
                isVibrateWait = true;
                Invoke("BallTouchVibrateWait", 0.05f);
                if (isVibrate)
                    VibrationManager.Haptic(VibrateType.Selection, false);
            }
        }
        void BallTouchVibrateWait()
        {
            isVibrateWait = false;
        }
        public void StartGame()
        {
            if (Manager.instance.setIsGameRestart == 0)
            {
                btnSoundPlay();
            }
            isPlayable = true;
            gameHud.SetActive(true);
            mainPanel.SetActive(false);
            isSaveMeProcess = false;
            PlayerMove.instance.Play();
        }
        void OnApplicationQuit()
        {
            Manager.instance.isLastColor = 0;
            Manager.instance.setIsGameRestart = 0;
        }

        public void GameOver()
        {
            gameHud.SetActive(false);
            SoundManger.instance.PlaySound("LevelFail");
            saveMeRing.fillAmount = 0;
            saveMebutton.interactable = true;
            isSaveMeProcess = false;
            if (saveMechance == 0 || PlayerMove.instance.ContiBallCounter.pointNo == 1)
            {
                gameOverP1.SetActive(false);
                gameOverP2.SetActive(true);
            }
            else
            {
                gameOverP1.SetActive(true);
                gameOverP2.SetActive(false);
                buttonRestart.GetComponent<Button>().interactable = false;
                btnHome.GetComponent<Button>().interactable = false;
                isSaveMeProcess = true;
            }
            goLevelNo.text = "Level " + DataBase.GetCurrentLevel().ToString();
            goLevelNo2.text = "Level " + DataBase.GetCurrentLevel().ToString();
            txtScoreGo.text = levelScore.ToString();
            txtScoreGo2.text = levelScore.ToString();
            gameOverPanel.SetActive(true);
            star.Play("GOStar"+ PlayerMove.instance.ContiBallCounter.pointNo);
            PlayerMove.instance.Stop();
        }
        public void SaveMeButton()
        {
            btnSoundPlay();
            if (RewardAddShow.instance.rewardBasedVideo.IsLoaded())
            {
                RewardAddShow.instance.ShowVideo();
                noAddPanel.SetActive(true);
            }
            else
            {
                noAddPanel.SetActive(true);
                noAddText.SetActive(true);
                Invoke("CloseAddBGPanel", 2);
                RewardAddShow.instance.RequestRewardBasedVideo();
            }
            isSaveMeProcess = false;
        }
        public void SaveMe()
        {
            gameOverPanel.SetActive(false);
            saveMechance--;
            PlayerMove.instance.isSwapMove = true;
            noAddPanel.SetActive(false);
            PlayerMove.instance.ContiBallCounter.checkPointAnimation.enabled = true;
            PlayerMove.instance.lastPoint = PlayerMove.instance.ContiBallCounter.pointNo;
            isGameOver = false;
            gameHud.SetActive(true);
            buttonRestart.GetComponent<Button>().interactable = false;
            btnHome.GetComponent<Button>().interactable = true;
            isSaveMeProcess = false;
        }
        public void SkipVideoAdd()
        {
            gameOverPanel.SetActive(false);
            Time.timeScale = 1;
            Manager.instance.isLastColor = 1;
            Manager.instance.colorNo = colorNo;
            Manager.instance.oceneNo = oceneColor;
            Manager.instance.setIsGameRestart = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            noAddPanel.SetActive(false);
        }

        int tempLevel;
        public void LoadNextLevel()
        {
            Vector3 pos = GameObject.FindGameObjectWithTag("NextLevel").transform.position;
            destroyLevel = currentLevel;
            tempLevel = UnityEngine.Random.Range(1, Levels.Length);
            if (DataBase.GetCurrentLevel() >= Levels.Length)
                currentLevel = Instantiate(Levels[tempLevel], pos, Quaternion.identity);
            else
                currentLevel = Instantiate(Levels[DataBase.GetCurrentLevel()], pos, Quaternion.identity);
        }
        public void LevelCompleted()
        {
            Manager.instance.levelFinishCount++;
            isLevelFinish = true;
            if (Manager.instance.levelFinishCount == 3)
            {
                Manager.instance.levelFinishCount = 0;
                if (InterstitialAddShow.instance.interstitial.IsLoaded())
                {
                    InterstitialAddShow.instance.ShowInterstitial();
                    isLCompleteClick = true;
                }
                else
                {
                    LevelCompletedAfter();
                    InterstitialAddShow.instance.RequestInterstitial();
                }
            }
            else
            {
                LevelCompletedAfter();
            }
        }
        public void LevelCompletedAfter()
        {
            SoundManger.instance.PlaySound("LevelFinish");
            finishLevelNo.text = "Level " + DataBase.GetCurrentLevel().ToString();
            txtScore.text = levelScore.ToString();
            noAddInter.SetActive(false);
            levelFinishPanel.SetActive(true);
            gameHud.SetActive(false);
            DataBase.SetCurrentLevel(currentLevelNo + 1);
            DataBase.SetLastLevel(tempLevel);
            currentLevelNo = DataBase.GetCurrentLevel();
            curLeveltext.text = DataBase.GetCurrentLevel().ToString();
            nextLevelText.text = (DataBase.GetCurrentLevel() + 1).ToString();
            for (int i = 0; i < pointImage.Length; i++)
            {
                pointImage[i].SetActive(false);
            }
            isLCompleteClick = false;
            saveMechance = 2;
            levelScore = 0;
        }
        public void btnPause()
        {
            if (!isStopAnimation)
            {
                btnSoundPlay();
                pauseButton.SetActive(false);
                pausePanel.SetActive(true);
                Time.timeScale = 0;
                isPaues = true;
                StartCoroutine(stopTimer());
            }
        }
        public void btnPauseClose()
        {
            if (!isStopAnimation)
            {
                btnSoundPlay();
                pauseButton.SetActive(true);
                pausePanel.SetActive(false);
                Time.timeScale = 1;
                isPaues = false;
            }
        }
        bool isStopAnimation = false;

        IEnumerator stopTimer()
        {
            isStopAnimation = true;
            yield return new WaitForSecondsRealtime(0.7f);
            isStopAnimation = false;
        }

        public void BtnHome()
        {
            btnSoundPlay();
            if (InterstitialAddShow.instance.interstitial.IsLoaded())
            {
                InterstitialAddShow.instance.ShowInterstitial();
                isHomeClick = true;
                noAddInter.SetActive(true);
            }
            else
            {
                BtnHomeAfter();
                InterstitialAddShow.instance.RequestInterstitial();
            }
            BtnCommonCode();
        }
       
        public void BtnHomeAfter()
        {
            Time.timeScale = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            isHomeClick = false;
        }
        void BtnCommonCode()
        {
            gameOverPanel.SetActive(false);
            pausePanel.SetActive(false);
            levelFinishPanel.SetActive(false);
            Manager.instance.isLastColor = 1;
            Manager.instance.colorNo = colorNo;
            Manager.instance.oceneNo = oceneColor;
            isLevelFinish = false;
        }
        public void btnRestart1(string name)
        {
            btnSoundPlay();
            Manager.instance.restartCount++;

            if (Manager.instance.restartCount == 3)
            {
                Manager.instance.restartCount = 0;

                if (InterstitialAddShow.instance.interstitial.IsLoaded())
                {
                    InterstitialAddShow.instance.ShowInterstitial();
                    isRestartClick = true;
                    noAddInter.SetActive(true);
                }
                else
                {
                    BtnRestartAfter();
                    InterstitialAddShow.instance.RequestInterstitial();
                }
            }
            else
            {
                BtnRestartAfter();
            }
            if (name == "levelfinish")
            {
                DataBase.SetCurrentLevel(currentLevelNo - 1);
            }
            BtnCommonCode();
        }
        public void BtnRestartAfter()
        {
            Time.timeScale = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            isRestartClick = false;
            Manager.instance.setIsGameRestart = 1;
        }
        public void btnTapToConti()
        {
            btnSoundPlay();
            levelFinishPanel.SetActive(false);
            gameHud.SetActive(true);
            PlayerMove.instance.Play();
            isLevelFinish = false;
        }

        public void CloseAddBGPanel()
        {
            noAddPanel.SetActive(false);
            noAddText.SetActive(false);
            isSaveMeProcess = true;
        }

        void btnSoundPlay()
        {
            SoundManger.instance.PlaySound("BtnClick");

            if (isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);
        }
    }
}
