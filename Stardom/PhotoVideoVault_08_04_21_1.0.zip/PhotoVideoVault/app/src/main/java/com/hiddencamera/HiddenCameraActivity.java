package com.hiddencamera;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresPermission;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public abstract class HiddenCameraActivity extends AppCompatActivity implements CameraCallbacks {
    private CameraConfig mCachedCameraConfig;
    private CameraPreview mCameraPreview;

    private CameraPreview addPreView() {
        final CameraPreview cameraPreview = new CameraPreview((Context) this, this);
        cameraPreview.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        final View child = ((ViewGroup) this.getWindow().getDecorView().getRootView()).getChildAt(0);
        if (child instanceof LinearLayout) {
            ((LinearLayout) child).addView((View) cameraPreview, (ViewGroup.LayoutParams) new LinearLayout.LayoutParams(1, 1));
            return cameraPreview;
        }
        if (child instanceof RelativeLayout) {
            final RelativeLayout relativeLayout = (RelativeLayout) child;
            final RelativeLayout.LayoutParams relativeLayoutLayoutParams = new RelativeLayout.LayoutParams(1, 1);
            relativeLayoutLayoutParams.addRule(9, -1);
            relativeLayoutLayoutParams.addRule(12, -1);
            relativeLayout.addView((View) cameraPreview, (ViewGroup.LayoutParams) relativeLayoutLayoutParams);
            return cameraPreview;
        }
        if (child instanceof FrameLayout) {
            ((FrameLayout) child).addView((View) cameraPreview, (ViewGroup.LayoutParams) new FrameLayout.LayoutParams(1, 1));
            return cameraPreview;
        }
        throw new RuntimeException("Root view of the activity/fragment cannot be other than Linear/Relative/Frame layout");
    }

    @Override
    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.mCameraPreview = this.addPreView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.stopCamera();
    }

    public void onPause() {
        super.onPause();
        if (this.mCameraPreview != null) {
            this.mCameraPreview.stopPreviewAndFreeCamera();
        }
    }

    @SuppressLint("MissingPermission")
    public void onResume() {
        super.onResume();
        if (this.mCachedCameraConfig != null) {
            this.startCamera(this.mCachedCameraConfig);
        }
    }

    @RequiresPermission("android.permission.CAMERA")
    public void startCamera(final CameraConfig mCachedCameraConfig) {
        if (ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA") != 0) {
            this.onCameraError(5472);
            return;
        }
        if (mCachedCameraConfig.getFacing() == 1 && !HiddenCameraUtils.isFrontCameraAvailable((Context) this)) {
            this.onCameraError(8722);
            return;
        }
        this.mCachedCameraConfig = mCachedCameraConfig;
        this.mCameraPreview.startCameraInternal(mCachedCameraConfig);
    }

    public void stopCamera() {
        this.mCachedCameraConfig = null;
        if (this.mCameraPreview != null) {
            this.mCameraPreview.stopPreviewAndFreeCamera();
        }
    }

    public void takePicture() {
        if (this.mCameraPreview != null) {
            if (this.mCameraPreview.isSafeToTakePictureInternal()) {
                this.mCameraPreview.takePictureInternal();
            }
            return;
        }
        throw new RuntimeException("Background camera not initialized. Call startCamera() to initialize the camera.");
    }
}
