package com.esc.flashlight.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.esc.flashlight.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class PermissionActivity extends BaseActivity {

    Activity activity = PermissionActivity.this;
    private AlertDialog mCurrentDialog;
    ImageView permisson;
    TextView welcometxt;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public InterstitialAd mInterstitialAd;

    class C01794 implements OnClickListener {
        C01794() {
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            if (i == -1) {
                PermissionActivity.this.performMoveAccessibility();
            }
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView((int) R.layout.activity_permiossion);
        this.welcometxt = (TextView) findViewById(R.id.id_welcome_txt);
        this.permisson = (ImageView) findViewById(R.id.id_give_permission);
        this.welcometxt.setText(getString(R.string.welcome_txt) + " " + getString(R.string.app_name));
        BannerAds();
        LoadInterstitialAd();
        this.permisson.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    GetPermission();
                }
            }
        });

    }

    private void GetPermission() {
        if (isStoragePermissionGranted()) {
            startActivity(new Intent(PermissionActivity.this, FlashLightActivity.class));
            finish();
        }

    }

    private void BannerAds() {
        try {
            this.adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) this.adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            this.adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.adContainerView.getLayoutParams();
            layoutParams.height = this.adSize.getHeightInPixels(this);
            this.adContainerView.setLayoutParams(layoutParams);
            this.adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void LoadInterstitialAd() {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                GetPermission();
                requestNewInterstitialAdmob();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void requestNewInterstitialAdmob() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void performMoveAccessibility() {
        startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
    }

    private void showAccessibilityDialog() {
        C01794 c01794 = new C01794();
        AlertDialog alertDialog = this.mCurrentDialog;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
        AlertDialog create = new Builder(this).setTitle(R.string.accessibility_title).setMessage(R.string.accessibility_message).setPositiveButton(R.string.accessibility_setting, c01794).create();
        this.mCurrentDialog = create;
        create.setCancelable(false);
        this.mCurrentDialog.show();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr[0] == 0) {
            String str = "Permission: ";
            Log.v(str, str + strArr[0] + "was " + iArr[0]);
            if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.READ_PHONE_STATE") == 0) {
                startActivity(new Intent(this, FlashLightActivity.class));
                finish();
            }
        }
    }

    public boolean isStoragePermissionGranted() {
        String str = "Permission is granted";
        String str2 = "Permission";
        if (VERSION.SDK_INT >= 23) {
            String str1 = "android.permission.CAMERA";
            String str3 = "android.permission.READ_PHONE_STATE";
            String str4 = "android.permission.CALL_PHONE";
            if (ContextCompat.checkSelfPermission(this, str1) == 0 && ContextCompat.checkSelfPermission(this, str4) == 0 && ContextCompat.checkSelfPermission(this, str3) == 0) {
                Log.v(str2, str);
                return true;
            }
            Log.v(str2, "Permission is revoked");
            ActivityCompat.requestPermissions(this, new String[]{str1, str4, str3}, 1);
            return false;
        }
        Log.v(str2, str);
        return true;
    }
}
