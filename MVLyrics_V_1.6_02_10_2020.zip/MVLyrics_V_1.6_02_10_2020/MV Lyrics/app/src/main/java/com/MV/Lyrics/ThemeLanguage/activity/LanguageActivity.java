package com.MV.Lyrics.ThemeLanguage.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.MV.Lyrics.Home.activity.HomeActivity;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.R;
import com.MV.Lyrics.ThemeLanguage.Adapter.LanguageAdapter;
import com.MV.Lyrics.ThemeLanguage.Model.LanguageModel;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class LanguageActivity extends AppCompatActivity {

    Activity activity = LanguageActivity.this;
    ImageView ivback;
    TextView tvDone;
    RecyclerView rvlanguage;
    LinearLayout layoutRetry;
    RelativeLayout layoutLoading;
    GridLayoutManager gridLayoutManager;
    LanguageAdapter languageAdapter;
    SharedPreferences pref;
    private ArrayList<LanguageModel> languageDataList = new ArrayList<>();

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public LanguageActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_select);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        PutAnalyticsEvent();
        BindView();
        PutLanguageList();
        SetAdapter();
        BannerAds();
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "LanguageSelectActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void PutLanguageList() {
        languageDataList.add(0, new LanguageModel("28", "Hindi"));
        languageDataList.add(1, new LanguageModel("36", "English"));
        languageDataList.add(2, new LanguageModel("35", "Rajashthahni"));
        languageDataList.add(3, new LanguageModel("34", "Punjabi"));
        languageDataList.add(4, new LanguageModel("33", "Islamic"));
        languageDataList.add(5, new LanguageModel("32", "Gujarati"));
        languageDataList.add(6, new LanguageModel("31", "Bengali"));
        languageDataList.add(7, new LanguageModel("37", "Tamil"));

        SaveLanInPref(LanguageActivity.this, languageDataList);
    }

    private void BindView() {
        ivback=findViewById(R.id.ivBack);
        tvDone = findViewById(R.id.tv_lan_done);
        rvlanguage = findViewById(R.id.rvLanguageList);
        layoutRetry = findViewById(R.id.llRetry);
        layoutLoading = findViewById(R.id.rl_loading_pager);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (languageDataList != null) {
                        final StringBuilder sb = new StringBuilder();
                        for (final LanguageModel LanguageModel : languageDataList) {
                            if (LanguageModel.isLanguage) {
                                sb.append(LanguageModel.LanId);
                                sb.append(",");
                            }
                        }
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(sb.length());
                        if (sb.length() != 0) {
                            if (!LanguagePref.a(activity).a("pref_key_language_list", "28").equals(sb.substring(0, sb.length() - 1))) {
                                Log.e("TAG", "PrefDefault");
                            }
                            LanguagePref.a(activity).c("pref_key_language_list", sb.substring(0, sb.length() - 1));
                            LanguagePref.a(activity).b("pref_key_is_language_set", true);
                            Intent intent = new Intent(activity, HomeActivity.class);
                            intent.putExtra("IsFromLanguage", true);
                            startActivity(intent);
                            finish();
                            return;
                        }
                        Toast.makeText(activity, "Please Select any language", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SaveLanInPref(LanguageActivity selectCountryAndLanguage, final ArrayList<LanguageModel> list) {
        final String[] split = LanguagePref.a(selectCountryAndLanguage).a("pref_key_language_list", "28").split(",");
        languageDataList = new ArrayList<>();
        for (final LanguageModel LanguageModel : list) {
            LanguageModel.isLanguage = Arrays.asList(split).contains(String.valueOf(LanguageModel.LanId));
            languageDataList.add(LanguageModel);
        }
        Collections.sort(languageDataList, new Comparator<LanguageModel>() {

            @Override
            public int compare(LanguageModel obj, LanguageModel obj2) {
                return Boolean.compare(obj2.isLanguage, obj.isLanguage);
            }
        });
    }

    private void SetAdapter() {
        gridLayoutManager = new GridLayoutManager(activity, 2);
        languageAdapter = new LanguageAdapter(activity, languageDataList);
        rvlanguage.setLayoutManager(gridLayoutManager);
        rvlanguage.setAdapter(languageAdapter);
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
