package com.unitedvideos.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.unitedvideos.Adapter.VideoAdapter;
import com.unitedvideos.Model.VideoModel;
import com.unitedvideos.R;
import com.unitedvideos.Utils.Utils;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.File;
import java.util.ArrayList;

public class MyVideoActivity extends AppCompatActivity {

    public ArrayList<VideoModel> videoList;
    Activity activity = MyVideoActivity.this;
    LinearLayout llcreatevideo;
    ImageView ivBack;
    TextView txtMainTitle;
    String from = "";
    TextView tvcreatevideoNow;
    RecyclerView rvVideoList;
    VideoAdapter videoAdapter;
    AdView adView;
    AdRequest adRequest;
    private StaggeredGridLayoutManager gridLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_video);
        from = getIntent().getStringExtra("from");
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyVideoActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        BannerAds();
        setAdapṭer();
        addListener();
    }

    private void BannerAds() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    @Override
    protected void onDestroy() {
        this.adView.removeView(this.adView);
        AdView adView = this.adView;
        if (adView != null) {
            adView.destroy();
            this.adView = null;
        }
        super.onDestroy();
    }

    private void bindView() {
        ivBack = findViewById(R.id.ivBack);
        txtMainTitle = findViewById(R.id.tv_name);
        llcreatevideo = findViewById(R.id.ll_novideo);
        tvcreatevideoNow = findViewById(R.id.tv_create_now);
        rvVideoList = findViewById(R.id.rvAlubmPhotos);
    }


    private void addListener() {
        ivBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (from != null && from.equalsIgnoreCase("unity")) {
                    finish();
                } else {
                    onBackPressed();
                }
            }

        });
        tvcreatevideoNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, HomeActivity.class));
                finish();
            }
        });
    }

    private void init() {
        getVideoList();
        if (videoList.size() > 0) {
            llcreatevideo.setVisibility(View.GONE);
        } else {
            llcreatevideo.setVisibility(View.VISIBLE);
        }
    }

    private void getVideoList() {
        this.videoList = new ArrayList<VideoModel>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        final Uri video = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "datetaken";
        final Cursor cur = getContentResolver().query(video, projection, "_data like '%" + Utils.INSTANCE.getStoryFolderPath() + "%'", null, "datetaken DESC");
        if (cur.moveToFirst()) {
            final int bucketColumn = cur.getColumnIndex("duration");
            final int data = cur.getColumnIndex("_data");
            final int name = cur.getColumnIndex("title");
            final int dateTaken = cur.getColumnIndex("datetaken");
            do {
                final VideoModel videoData = new VideoModel();
                videoData.videoDuration = cur.getLong(bucketColumn);
                videoData.videoFullPath = cur.getString(data);
                videoData.videoName = cur.getString(name);
                videoData.dateTaken = cur.getLong(dateTaken);
                if (new File(videoData.videoFullPath).exists()) {
                    this.videoList.add(videoData);
                }
            } while (cur.moveToNext());
        }
    }

    private void setAdapṭer() {
        if (videoList.size() <= 0) {
            rvVideoList.setVisibility(View.GONE);
        } else {
            rvVideoList.setVisibility(View.VISIBLE);
        }
        videoAdapter = new VideoAdapter(activity, videoList);
        gridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        gridLayoutManager.setAutoMeasureEnabled(true);
        rvVideoList.setLayoutManager(gridLayoutManager);
        rvVideoList.setAdapter(videoAdapter);
        videoAdapter.notifyDataSetChanged();

    }

    public void onBackPressed() {
        Intent intent = new Intent(activity, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    public void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }
}
