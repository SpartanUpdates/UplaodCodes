package com.esc.flashlight.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.esc.flashlight.flashlight.FlashService;
import com.esc.flashlight.util.FlashAlertUtil;

public class PhoneStateBroadcastReceiver extends BroadcastReceiver {
    private static final String ACTION_PHONE_STATE = "android.intent.action.PHONE_STATE";
    private static final String TAG = "PhoneStateBroadcastReceiver";

    private class MyListener extends PhoneStateListener {
        private MyListener() {
        }

        public void onCallStateChanged(int i, String str) {
            super.onCallStateChanged(i, str);
            if (i == 0) {
                Log.e(PhoneStateBroadcastReceiver.TAG, "CALL_STATE_IDLE");
            } else if (i == 1) {
                Log.e(PhoneStateBroadcastReceiver.TAG, "CALL_STATE_RINGING");
            } else if (i == 2) {
                Log.e(PhoneStateBroadcastReceiver.TAG, "CALL_STATE_OFFHOOK");
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        ((TelephonyManager) context.getSystemService("phone")).listen(new MyListener(), 32);
        Log.e("df", "onReceive: " + intent.getAction());
        if (ACTION_PHONE_STATE.equals(intent.getAction())) {
            String stringExtra = intent.getStringExtra("state");
            Log.e(TAG, "phone state onReceive: " + stringExtra);
            if (stringExtra != null) {
                handlePhoneState(context, stringExtra, intent);
            }
        }
    }

    private void handlePhoneState(Context context, String str, Intent intent) {
        Log.e(TAG, "call state: " + str);
        if (FlashAlertUtil.checkedPhoneState(context, str, intent)) {
            FlashService.runIntentInService(context, intent);
        } else {
            context.stopService(new Intent(context, FlashService.class));
        }
    }
}
