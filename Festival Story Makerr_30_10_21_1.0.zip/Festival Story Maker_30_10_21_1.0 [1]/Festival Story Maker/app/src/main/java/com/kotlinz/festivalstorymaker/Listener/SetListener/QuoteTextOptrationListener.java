package com.kotlinz.festivalstorymaker.Listener.SetListener;

import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;

public class QuoteTextOptrationListener implements com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1.a {
    public final TextStickerViewNew1 stickerViewNew1;
    public final  QuoteMakerDetailActivity activity;

    public QuoteTextOptrationListener(QuoteMakerDetailActivity quoteMakerDetailActivity, TextStickerViewNew1 textStickerViewNew1) {
        this.activity = quoteMakerDetailActivity;
        this.stickerViewNew1 = textStickerViewNew1;
    }

    public void a(TextStickerViewNew1 textStickerViewNew1) {
        this.activity.svScroll.requestDisallowInterceptTouchEvent(true);
        TextStickerViewNew1 textStickerViewNew12 = this.activity.stickerViewNew1;
        if (textStickerViewNew12 != null) {
            textStickerViewNew12.setInEdit(false);
            this.activity.stickerViewNew1.setShowHelpBox(false);
        }
        this.activity.stickerViewNew1 = textStickerViewNew1;
        textStickerViewNew1.setInEdit(true);
        this.activity.stickerViewNew1.setShowHelpBox(true);
    }

    public void b(TextStickerViewNew1 textStickerViewNew1) {
        activity.g0(activity.flStickerView, this.stickerViewNew1);
    }

    public void c(TextStickerViewNew1 textStickerViewNew1) {
        if (this.activity.stickerViewNew1 != null && textStickerViewNew1.getTag().equals(activity.stickerViewNew1.getTag()) && textStickerViewNew1.u) {
            this.activity.flStickerView.removeView(textStickerViewNew1);
            QuoteMakerDetailActivity.i0(activity, false);
        }
    }

    public void d(TextStickerViewNew1 textStickerViewNew1) {
        activity.isText = true;
        activity.stickerViewNew1 = textStickerViewNew1;
        QuoteMakerDetailActivity.i0(activity, true);
    }
}
