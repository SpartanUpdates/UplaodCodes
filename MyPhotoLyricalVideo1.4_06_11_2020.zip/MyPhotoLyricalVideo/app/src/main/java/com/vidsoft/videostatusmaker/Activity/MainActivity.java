package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdView;

import java.io.File;

import com.vidsoft.videostatusmaker.Others.gallery.ActivityImageFolder;

public class MainActivity extends AppCompatActivity {
    public static int anInt;
    public static Activity activity;
    ImageView fullscreen;
    ImageView square1;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        activity = this;
        getWindow().addFlags(1024);
        this.square1 = (ImageView) findViewById(R.id.square1);
        this.fullscreen = (ImageView) findViewById(R.id.fullscreen);
        anInt = 0;
        loadAds();
        btnClick();
    }

    private void btnClick() {
        this.square1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.anInt = 0;
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
            }
        });
        this.fullscreen.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.anInt = 1;
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
            }
        });
    }


    private NativeAd mNativeBannerAd;

    private void loadAds() {
        mNativeBannerAd = new NativeAd(this, getString(R.string.FB_Native));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG","onError"+adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeAdView.render(MainActivity.this, mNativeBannerAd, NativeAdView.Type.HEIGHT_300);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        mNativeBannerAd.loadAd();
    }

    protected void onResume() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/");
            stringBuilder.append(getResources().getString(R.string.app_name));
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("/");
            stringBuilder3.append(getString(R.string.temp_folder));
            deleteRecursive(new File(stringBuilder3.toString()));
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(MainActivity.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    public static void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }

    public void onDestroy() {

        super.onDestroy();
    }


}
