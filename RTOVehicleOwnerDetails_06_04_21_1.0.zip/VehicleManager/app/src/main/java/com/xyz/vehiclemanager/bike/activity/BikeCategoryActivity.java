package com.xyz.vehiclemanager.bike.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bike.adapter.BikeCategoryAdapter;
import com.xyz.vehiclemanager.bike.model.BikeBrandCategory;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeCategoryActivity extends AppCompatActivity {

    private Activity activity = BikeCategoryActivity.this;
    private String brandId, brandName;
    private TextView tv_title;
    private ImageView iv_back;
    private RecyclerView rv_bikecategory;
    private BikeCategoryAdapter bikeCategoryAdapter;
    private AppCompatDialog dialog;
    private RtoDetailsInterface rtoDetailsInterface;


    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bike_category);

        brandId = getIntent().getStringExtra("id");
        brandName = getIntent().getStringExtra("name");
        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        BindView();
        BannerAds();
        PutAnalyticsEvent();
        DialogAnimation();
        if (Utils.isOnline(activity)) {
            getBikeCategory();
        } else {
            Toast.makeText(this, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }


    private void BindView() {
        tv_title = findViewById(R.id.tv_title);
        iv_back = findViewById(R.id.iv_back);
        rv_bikecategory = findViewById(R.id.rv_bikecategory);
        tv_title.setText(brandName);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeCategoryActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void DialogAnimation() {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void getBikeCategory() {
        Call<BikeBrandCategory> call = rtoDetailsInterface.getBikeCategory(brandId);
        call.enqueue(new Callback<BikeBrandCategory>() {
            @Override
            public void onResponse(Call<BikeBrandCategory> call, Response<BikeBrandCategory> response) {
                if (response.isSuccessful()) {
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    ArrayList<BikeBrandCategory> brandlist = response.body().getData();
                    bikeCategoryAdapter = new BikeCategoryAdapter(activity, brandlist);
                    rv_bikecategory.setLayoutManager(new LinearLayoutManager(activity));
                    rv_bikecategory.setAdapter(bikeCategoryAdapter);
                }
            }

            @Override
            public void onFailure(Call<BikeBrandCategory> call, Throwable t) {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
                Toast.makeText(BikeCategoryActivity.this, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}