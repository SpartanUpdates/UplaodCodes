package com.kotlinz.vehiclemanager.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class DarkTheame {
    private Context context;

    public DarkTheame(Context context) {
        this.context = context;
    }

    public SharedPreferences getSharedPreference() {
        return context.getSharedPreferences("CurrentFuelData", Context.MODE_PRIVATE);
    }


    public String modeData() {
        return getSharedPreference().getString("mode", "");
    }


}
