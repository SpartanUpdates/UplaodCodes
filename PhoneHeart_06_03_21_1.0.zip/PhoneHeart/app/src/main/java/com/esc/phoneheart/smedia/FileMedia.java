package com.esc.phoneheart.smedia;

import com.esc.phoneheart.model.MediaList;
import com.esc.phoneheart.utility.GlobalData;
import com.esc.phoneheart.utility.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class FileMedia {
    public static final String SELECTED_MEDIA = "media";
    public String TAG = "SocialMedia";
    public ArrayList<MediaList> arrContents;
    public HashMap<Integer, MediaList> hmFileTypeToMediaList;
    public String name;

    public FileMedia(String str) {
        this.name = str;
        this.arrContents = new ArrayList();
    }

    public void selectAll() {
        Util.appendLogphonecleaner(this.TAG, " method selectAll call ", GlobalData.FILE_NAME);
        for (int i = 0; i < this.arrContents.size(); i++) {
            ((MediaList) this.arrContents.get(i)).selectAll();
        }
    }

    public void unSelectAll() {
        Util.appendLogphonecleaner(this.TAG, " method unSelectAll call ", GlobalData.FILE_NAME);
        for (int i = 0; i < this.arrContents.size(); i++) {
            ((MediaList) this.arrContents.get(i)).unSelectAll();
        }
    }

    public void updateHashMapFileTypeToMediaList() {
        try {
            this.hmFileTypeToMediaList = new HashMap(this.arrContents.size());
            Iterator it = this.arrContents.iterator();
            while (it.hasNext()) {
                MediaList mediaList = (MediaList) it.next();
                try {
                    this.hmFileTypeToMediaList.put(Integer.valueOf(mediaList.mediaType.ordinal()), mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
