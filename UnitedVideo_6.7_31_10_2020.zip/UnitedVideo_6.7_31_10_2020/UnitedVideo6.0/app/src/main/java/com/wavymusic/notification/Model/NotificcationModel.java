package com.wavymusic.notification.Model;

public class NotificcationModel {
    private String ThemeName;
    private String ThemeThumbnail;
    private String SongUrl;
    private String SongFileName;
    private String SoundPath;
    private int SongSize;
    private String ParticleCategoryName;
    private String ParticalName;
    private String ParticalBundelName;
    private String ParticalThumbnail;
    private String ParticalBundel;
    private String BundelPath;
    private int ParticalSize;
    private String GameobjectName;
    public boolean isAvailableOffline = false;
//    private boolean IsFromAsset;
    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String themeName) {
        ThemeName = themeName;
    }

    public String getThemeThumbnail() {
        return ThemeThumbnail;
    }

    public void setThemeThumbnail(String themeThumbnail) {
        ThemeThumbnail = themeThumbnail;
    }

    public String getSongUrl() {
        return SongUrl;
    }

    public void setSongUrl(String songUrl) {
        SongUrl = songUrl;
    }

    public String getSoundPath() {
        return SoundPath;
    }

    public void setSoundPath(String soundPath) {
        SoundPath = soundPath;
    }

    public String getSongFileName() {
        return SongFileName;
    }

    public void setSongFileName(String songFileName) {
        SongFileName = songFileName;
    }

    public int getSongSize() {
        return SongSize;
    }

    public void setSongSize(int songSize) {
        SongSize = songSize;
    }

    public String getParticleCategoryName() {
        return ParticleCategoryName;
    }

    public void setParticleCategoryName(String particleCategoryName) {
        ParticleCategoryName = particleCategoryName;
    }

    public String getParticalName() {
        return ParticalName;
    }

    public void setParticalName(String particalName) {
        ParticalName = particalName;
    }

    public String getParticalBundelName() {
        return ParticalBundelName;
    }

    public void setParticalBundelName(String particalBundelName) {
        ParticalBundelName = particalBundelName;
    }

    public String getParticalThumbnail() {
        return ParticalThumbnail;
    }

    public void setParticalThumbnail(String particalThumbnail) {
        ParticalThumbnail = particalThumbnail;
    }

    public String getParticalBundel() {
        return ParticalBundel;
    }

    public void setParticalBundel(String particalBundel) {
        ParticalBundel = particalBundel;
    }

    public String getBundelPath() {
        return BundelPath;
    }

    public void setBundelPath(String bundelPath) {
        BundelPath = bundelPath;
    }

    public int getParticalSize() {
        return ParticalSize;
    }

    public void setParticalSize(int particalSize) {
        ParticalSize = particalSize;
    }

    public String getGameobjectName() {
        return GameobjectName;
    }

    public void setGameobjectName(String gameobjectName) {
        GameobjectName = gameobjectName;
    }

//    public boolean isFromAsset() {
//        return IsFromAsset;
//    }
//
//    public void setFromAsset(boolean fromAsset) {
//        IsFromAsset = fromAsset;
//    }
}
