package com.vidsoft.videostatusmaker.Utils;

import android.content.*;
import android.util.*;
import android.graphics.*;
import android.view.*;
import android.annotation.*;

public class DrawingView extends View
{
  private static final float TOUCH_TOLERANCE = 4.0f;
  public static Paint paint;
  private Bitmap bitmap;
  private Paint bitmapPaint;
  private Canvas canvas;
  private float mX;
  private float mY;
  private Path path;

  public DrawingView(final Context context, final AttributeSet set) {
    super(context, set);
    this.path = new Path();
    this.bitmapPaint = new Paint(4);
    (DrawingView.paint = new Paint()).setAntiAlias(true);
    DrawingView.paint.setDither(true);
    DrawingView.paint.setColor(-16777216);
    DrawingView.paint.setStyle(Paint.Style.STROKE);
    DrawingView.paint.setStrokeJoin(Paint.Join.ROUND);
    DrawingView.paint.setStrokeCap(Paint.Cap.ROUND);
    DrawingView.paint.setStrokeWidth(10.0f);
  }

  private void touchMove(final float mx, final float my) {
    final float abs = Math.abs(mx - this.mX);
    final float abs2 = Math.abs(my - this.mY);
    if (abs >= 4.0f || abs2 >= 4.0f) {
      this.path.quadTo(this.mX, this.mY, (this.mX + mx) / 2.0f, (this.mY + my) / 2.0f);
      this.mX = mx;
      this.mY = my;
    }
  }

  private void touchStart(final float mx, final float my) {
    this.path.reset();
    this.path.moveTo(mx, my);
    this.mX = mx;
    this.mY = my;
  }

  private void touchUp() {
    this.path.lineTo(this.mX, this.mY);
    this.canvas.drawPath(this.path, DrawingView.paint);
    this.path.reset();
  }

  public void clear() {
    this.bitmap.eraseColor(0);
    this.invalidate();
    System.gc();
  }

  public Bitmap getBitmap() {
    this.setDrawingCacheEnabled(true);
    this.buildDrawingCache();
    final Bitmap bitmap = Bitmap.createBitmap(this.getDrawingCache());
    this.setDrawingCacheEnabled(false);
    return bitmap;
  }

  protected void onDraw(final Canvas canvas) {
    canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, this.bitmapPaint);
    canvas.drawPath(this.path, DrawingView.paint);
  }

  protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
    super.onSizeChanged(n, n2, n3, n4);
    this.bitmap = Bitmap.createBitmap(n, n2, Bitmap.Config.ARGB_8888);
    this.canvas = new Canvas(this.bitmap);
  }

  @SuppressLint({ "ClickableViewAccessibility" })
  public boolean onTouchEvent(final MotionEvent motionEvent) {
    final float x = motionEvent.getX();
    final float y = motionEvent.getY();
    switch (motionEvent.getAction()) {
      case 2: {
        this.touchMove(x, y);
        this.invalidate();
        break;
      }
      case 1: {
        this.touchUp();
        this.invalidate();
        break;
      }
      case 0: {
        this.touchStart(x, y);
        this.invalidate();
        break;
      }
    }
    return true;
  }

  public void setPathColor(final int color) {
    DrawingView.paint.setColor(color);
  }
}
