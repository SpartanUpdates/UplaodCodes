package com.esc.fontappstylish.adapter;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.esc.fontappstylish.activity.ChangeImageActivity;
import com.esc.fontappstylish.utils.MyKeyboardInterface.onClickListener;
import com.esc.fontappstylish.utils.MyKeyboardInterface.subThemeSelection;
import com.esc.fontappstylish.R;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class SubThemeAdapter extends Adapter<SubThemeAdapter.ViewHolder> {
    Activity activity;
    LayoutInflater inflater;
    ArrayList<String> list;
    subThemeSelection subThemeSelection;

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCheck;
        ImageView imgbg;
        CardView loutMainTheme;

        public ViewHolder(View view) {
            super(view);
            this.imgbg = (ImageView) view.findViewById(R.id.imgbg);
            this.loutMainTheme = (CardView) view.findViewById(R.id.loutMainTheme);
            this.imgCheck = (ImageView) view.findViewById(R.id.imgCheck);
        }
    }

    public SubThemeAdapter(ChangeImageActivity changeImageActivity, ArrayList arrayList, subThemeSelection subthemeselection) {
        this.activity = changeImageActivity;
        this.list = arrayList;
        this.inflater = LayoutInflater.from(changeImageActivity);
        this.subThemeSelection = subthemeselection;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this.inflater.inflate(R.layout.subthemeitem, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        InputStream open;
        try {
            AssetManager assets = this.activity.getAssets();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("albums/");
            stringBuilder.append(list.get(i));
            open = assets.open(stringBuilder.toString());
            Log.e("OpenImage","OpenImage==>"+open);

        } catch (IOException e) {
            e.printStackTrace();
            Log.e("Error","Error==> "+e.getMessage());
            open = null;
        }

        viewHolder.imgbg.setImageBitmap(BitmapFactory.decodeStream(open));
        viewHolder.loutMainTheme.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
//                if (i == 0) {
//                    SubThemeAdapter.this.onClickListener.onClick();
//                    return;
//                }
                InputStream inputStream = null;
                try {
                    AssetManager assets = SubThemeAdapter.this.activity.getAssets();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("albums/");
                    stringBuilder.append(list.get(i));
                    inputStream = assets.open(stringBuilder.toString());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                SubThemeAdapter.this.subThemeSelection.getSubThemePosition(inputStream);
            }
        });
    }

    public int getItemCount() {
        Log.e("getImgItemSize","Size==> "+list. size());
        return this.list.size();
    }
}
