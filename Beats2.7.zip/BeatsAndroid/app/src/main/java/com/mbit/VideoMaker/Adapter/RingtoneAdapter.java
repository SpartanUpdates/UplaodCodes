package com.mbit.VideoMaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mbit.VideoMaker.Activity.RingtonSetActivity;
import com.mbit.VideoMaker.Download.SongDownload;
import com.mbit.VideoMaker.Extra.Utils;
import com.mbit.VideoMaker.Fragment.RingtoneSetCatFragment;
import com.mbit.VideoMaker.Model.OnlineSongModel;
import com.mbit.VideoMaker.R;
import com.mbit.VideoMaker.View.CircleImageView;
import com.mbit.VideoMaker.View.DonutProgress;

import java.io.File;
import java.util.List;

public class RingtoneAdapter extends RecyclerView.Adapter<RingtoneAdapter.SongViewHolder> {


    public static boolean IsSongPlay = false;
    RingtoneSetCatFragment ringtoneSetCatFragment;
    private int selectedPosition = -1;
    private List<OnlineSongModel> songList;
    private Context mContext;
    private RingtonSetActivity ActivityOfsong;


    public RingtoneAdapter(Context mContext, List<OnlineSongModel> songList, RingtoneSetCatFragment ringtoneSetCatFragment) {
        this.songList = songList;
        this.mContext = mContext;
        this.ActivityOfsong = (RingtonSetActivity) mContext;
        this.ringtoneSetCatFragment = ringtoneSetCatFragment;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_ringtoneset_item, null);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SongViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final OnlineSongModel songModel = songList.get(position);
        holder.tvSongName.setText(songList.get(position).getSongName());
        holder.cbSong.setChecked(selectedPosition == position);
        if (!songList.get(position).isAvailableOffline) {
            if (songList.get(position).isDownloading) {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.GONE);
                holder.dpDownSong.setVisibility(View.VISIBLE);
            } else {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.VISIBLE);
                holder.dpDownSong.setVisibility(View.GONE);
            }
        } else {
            holder.layoutUseSong.setVisibility(View.VISIBLE);
            holder.ivDownload.setVisibility(View.GONE);
            holder.dpDownSong.setVisibility(View.GONE);
        }
        if (selectedPosition == position) {
            holder.cbSong.setChecked(true);
            holder.cvThumb.setBackgroundResource(R.drawable.img_ring_press);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_pause);

        } else {
            holder.cbSong.setChecked(false);
            holder.cvThumb.setBackgroundResource(R.drawable.img_ring);
            holder.ivPalayPause.setImageResource(R.drawable.icon_player_play);
        }

        holder.tvUseSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityOfsong.FinalSongPath = Utils.INSTANCE.getMusicFolderPath() + File.separator + songList.get(position).getSongUrl();
                /*if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isLoaded()) {
                    try {
                        ActivityOfsong.hud = KProgressHUD.create(mContext)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        ActivityOfsong.hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ActivityOfsong.hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isLoaded()) {
                                ringtoneSetCatFragment.stopPlaying(ringtoneSetCatFragment.mediaPlayer);
                                ActivityOfsong.id = 203;
                                ActivityOfsong.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    ringtoneSetCatFragment.stopPlaying(ringtoneSetCatFragment.mediaPlayer);
                    if (songModel.getSongUrl() != null) {
                        final String SoundPath = Utils.INSTANCE.getThemeFolderPath() + File.separator + songModel.getSongUrl();
                        try {
                            if (Build.VERSION.SDK_INT < 23) {
                                RingTonePtah(SoundPath, mContext);
//                                ActivityOfsong.finish();
                                notifyDataSetChanged();
                            } else if (!Utils.INSTANCE.SetPermission(ActivityOfsong)) {
                                Toast.makeText(mContext, mContext.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                            } else if (!(SoundPath == null || mContext == null)) {
                                RingTonePtah(SoundPath, mContext);
                                notifyDataSetChanged();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(mContext, mContext.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                        }
                    }
                }*/
                ringtoneSetCatFragment.stopPlaying(ringtoneSetCatFragment.mediaPlayer);
                if (songModel.getSongUrl() != null) {
                    final String SoundPath = Utils.INSTANCE.getThemeFolderPath() + File.separator + songModel.getSongUrl();
                    try {
                        if (Build.VERSION.SDK_INT < 23) {
                            RingTonePtah(SoundPath, mContext);
                            notifyDataSetChanged();
                        } else if (!Utils.INSTANCE.SetPermission(ActivityOfsong)) {
                            Toast.makeText(mContext, mContext.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                        } else if (!(SoundPath == null || mContext == null)) {
                            RingTonePtah(SoundPath, mContext);
                            notifyDataSetChanged();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(mContext, mContext.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadSongFiles(position, holder.ivDownload, holder.dpDownSong, holder.layoutUseSong, holder.ivPalayPause, songModel);
            }
        });
    }


    public void RingTonePtah(final String SongfilePath, final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                try {
                    if (SongfilePath != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(Utils.d);
                        stringBuilder.append(File.separator);
                        stringBuilder.append("Ringtone");
                        stringBuilder.append(File.separator);
                        stringBuilder.append("ringtone.mp3");
                        String stringBuilder2 = stringBuilder.toString();
                        File file = new File(stringBuilder2);
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(Utils.d);
                        stringBuilder3.append(File.separator);
                        stringBuilder3.append("Ringtone");
                        Utils.INSTANCE.CopyFileToStorage(SongfilePath, stringBuilder2, stringBuilder3.toString());
                        stringBuilder3 = new StringBuilder("path : ");
                        stringBuilder3.append(SongfilePath);
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_data", file.getAbsolutePath());
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(file.getName());
                        contentValues.put("title", stringBuilder4.toString());
                        contentValues.put("is_ringtone", Boolean.TRUE);
                        contentValues.put("mime_type", "audio/mp3");
                        stringBuilder3 = new StringBuilder("file://");
                        stringBuilder3.append(file.getAbsolutePath());
                        Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(stringBuilder3.toString());
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder stringBuilder5 = new StringBuilder("_data=\"");
                        stringBuilder5.append(file.getAbsolutePath());
                        stringBuilder5.append("\"");
                        contentResolver.delete(contentUriForPath, stringBuilder5.toString(), null);
                        Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                        ((Activity) context).runOnUiThread(new Runnable() {
                            public final void run() {
                                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void DownloadSongFiles(int position, ImageView ivDonload, DonutProgress dpSongProgress, LinearLayout layoutUseSong, ImageView ivplapause, OnlineSongModel themelModel) {
        int UnitySoundSize = Integer.parseInt(songList.get(position).getSongSize());
        String SongName = songList.get(position).getSongUrl();
        File SongPath = new File(Utils.INSTANCE.getMusicFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        if (new File(Utils.INSTANCE.getMusicFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
                ringtoneSetCatFragment.rePlayAudio(position, true);
                selectedPosition = position;
                notifyDataSetChanged();
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDonload.setVisibility(View.GONE);
                    dpSongProgress.setVisibility(View.VISIBLE);
                    new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDonload.setVisibility(View.GONE);
                dpSongProgress.setVisibility(View.VISIBLE);
                new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }


    public class SongViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutMain;
        CircleImageView cvThumb;
        ImageView ivPalayPause;
        TextView tvSongName, tvSongTime;
        LinearLayout layoutUseSong;
        TextView tvUseSong;
        LinearLayout layoutDownSong;
        ImageView ivDownload;
        DonutProgress dpDownSong;
        CheckBox cbSong;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutMain = itemView.findViewById(R.id.image_layout);
            cvThumb = itemView.findViewById(R.id.image_content);
            ivPalayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            tvSongName = itemView.findViewById(R.id.tvMusicName);
            tvSongTime = itemView.findViewById(R.id.tvMusicEndTime);
            layoutUseSong = itemView.findViewById(R.id.llUseMusic);
            tvUseSong = itemView.findViewById(R.id.tvUseMusic);
            layoutDownSong = itemView.findViewById(R.id.ll_download);
            ivDownload = itemView.findViewById(R.id.iv_dowload);
            dpDownSong = itemView.findViewById(R.id.donut_progress);
            cbSong = itemView.findViewById(R.id.cb_music);

        }
    }
}
