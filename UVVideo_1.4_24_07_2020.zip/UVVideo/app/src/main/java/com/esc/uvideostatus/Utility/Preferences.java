package com.esc.uvideostatus.Utility;

import android.content.Context;
import android.content.SharedPreferences.Editor;

public class Preferences {
    private static final String NAME_PREF = "My_pref";

    public static void setTagValueStr(Context context, String str, int i) {
        Editor edit = context.getSharedPreferences(NAME_PREF, 0).edit();
        edit.putInt(str, i);
        edit.commit();
    }

    public static String getTagValueStr(Context context, String str) {
        return context.getSharedPreferences(NAME_PREF, 0).getString(str, null);
    }
}
