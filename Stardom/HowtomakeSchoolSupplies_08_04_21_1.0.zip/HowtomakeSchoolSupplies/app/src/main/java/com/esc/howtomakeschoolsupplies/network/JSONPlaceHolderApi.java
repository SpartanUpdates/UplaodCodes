package com.esc.howtomakeschoolsupplies.network;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import com.esc.howtomakeschoolsupplies.pojo.Article;
import com.esc.howtomakeschoolsupplies.pojo.Category;

public interface JSONPlaceHolderApi {
    @GET("get_category")
    Call<List<Category>> getCategoryID(@Query("lang") String str);

    @GET("get_article")
    Call<List<Article>> getPostWithID(@Query("lang") String str);

}
