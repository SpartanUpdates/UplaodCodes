package com.MV.Lyrics.bottomSheet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.R;
import com.MV.Lyrics.UnityPlayerActivity;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.root.UnitySendValue.AndroidUnityCall;
import com.unity3d.player.UnityPlayer;

public class SaveVideo extends BottomSheetDialogFragment {
    ImageView ivDown;
    Button btnHd, btnFullHd;
    CheckBox cbDoNotAsk;

    public static SaveVideo newInstance() {
        return new SaveVideo();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.export_dialog, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        BindView(view);
    }

    private void BindView(View view) {
        ivDown=view.findViewById(R.id.iv_down);
        btnHd = view.findViewById(R.id.btnHd);
        btnFullHd = view.findViewById(R.id.btnFullHd);
        cbDoNotAsk = view.findViewById(R.id.cbDoNotAsk);
        ivDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        btnHd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "0");
                AndroidUnityCall.HideBannerAds(UnityPlayerActivity.unityPlayeractivity);
                UnityPlayerActivity.unityPlayeractivity.HidebottomViewLyrics();
                UnityPlayerActivity.unityPlayeractivity.HideLyricsStyle();
                UnityPlayerActivity.unityPlayeractivity.SetDefaultRatio();
                LanguagePref.a(UnityPlayerActivity.unityPlayeractivity).b("pref_key_export_quality", "Medium");
                dismiss();
            }
        });
        btnFullHd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UnityPlayer.UnitySendMessage("AppManager", "ExportScene", "1");
                AndroidUnityCall.HideBannerAds(UnityPlayerActivity.unityPlayeractivity);
                UnityPlayerActivity.unityPlayeractivity.HidebottomViewLyrics();
                UnityPlayerActivity.unityPlayeractivity.HideLyricsStyle();
                UnityPlayerActivity.unityPlayeractivity.SetDefaultRatio();
                LanguagePref.a(UnityPlayerActivity.unityPlayeractivity).b("pref_key_export_quality", "High");
                dismiss();
            }
        });

        cbDoNotAsk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                LanguagePref languagePref;
                String str;
                String str2;
                if (z) {
                    languagePref = LanguagePref.a(UnityPlayerActivity.unityPlayeractivity);
                    str = "pref_last_load_time_ads";
                    str2 = "0";
                } else {
                    languagePref = LanguagePref.a(UnityPlayerActivity.unityPlayeractivity);
                    str = "pref_last_load_time_ads";
                    str2 = "1";
                }
                languagePref.b(str, str2);
            }
        });

    }
}
