package com.name.nameart.FavDesign;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.name.nameart.R;
import com.name.nameart.adapter.MyCreationAdapter;
import java.io.File;
import java.util.ArrayList;


public final class SavedScreen extends AppCompatActivity {
    private ArrayList<String> arrayList = new ArrayList();

    public File[] listFile;
    public MyCreationAdapter myCreationAdapter;

    public final ArrayList<String> getF() {
        return this.arrayList;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.saved_screen);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.ll_ad_container);


        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SavedScreen.this.finish();
            }
        });
        ((RecyclerView) findViewById(R.id.rvCreation)).setLayoutManager(new GridLayoutManager(this, 2));
        getFromSdcard();
    }

    private final void getFromSdcard() {
        try {
            File file = new File(Environment.getExternalStorageDirectory(), getResources().getString(R.string.app_name));
            if (file.isDirectory())
            {
                File[] listFiles = file.listFiles();
                this.listFile = listFiles;
                int length = listFiles.length;
                for (int i = 0; i < length; i++)
                {
                    this.arrayList.add(this.listFile[i].getAbsolutePath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (this.arrayList.size() > 0)
        {
            ((TextView) findViewById(R.id.tvNoRecord)).setVisibility(View.GONE);
            ((RecyclerView) findViewById(R.id.rvCreation)).setVisibility(View.VISIBLE);
            this.myCreationAdapter = new MyCreationAdapter(this, this.arrayList);
            ((RecyclerView) findViewById(R.id.rvCreation)).setAdapter(this.myCreationAdapter);
            this.myCreationAdapter.setClickListener(new MyCreationAdapter.OnMyCreationClick() {
                public void onClick(int i) {
                    Intent intent = new Intent(SavedScreen.this, ShareScreen.class);
                    intent.putExtra("picture_path", (String) SavedScreen.this.getF().get(i));
                    SavedScreen.this.startActivity(intent);
                }
            });
            return;
        }
        ((TextView) findViewById(R.id.tvNoRecord)).setVisibility(View.VISIBLE);
        ((RecyclerView) findViewById(R.id.rvCreation)).setVisibility(View.GONE);
    }

    public void onResume() {
        super.onResume();
    }

}
