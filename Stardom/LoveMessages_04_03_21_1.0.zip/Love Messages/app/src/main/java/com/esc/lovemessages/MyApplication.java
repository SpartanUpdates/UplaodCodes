package com.esc.lovemessages;

import android.app.Application;
import android.content.Context;
import androidx.multidex.MultiDex;

import com.esc.lovemessages.OpenAds.AppOpenManager;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MyApplication extends Application {

    AppOpenManager appOpenManager;

    public void onCreate() {
        try {
            Class.forName("android.os.AsyncTask");
        } catch (Throwable t) {
            t.printStackTrace();
        }
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);

        super.onCreate();
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }
}
