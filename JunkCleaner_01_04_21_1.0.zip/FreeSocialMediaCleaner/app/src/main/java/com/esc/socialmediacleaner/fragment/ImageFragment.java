package com.esc.socialmediacleaner.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.RelativeLayout.LayoutParams;
import com.esc.socialmediacleaner.R;
import com.esc.socialmediacleaner.myapp.MyApplication;
import com.esc.socialmediacleaner.adapter.ImageAdapter;
import com.esc.socialmediacleaner.datastructure.FileDataWrapper;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ImageFragment extends Fragment {
    private ImageAdapter adapter;
    private final AppCompatCheckBox cheSlectAll;
    private final Context context;
    private final ArrayList<FileDataWrapper> dataList;
    private int deviceHeight;
    private int deviceWidth;
    private boolean fromTouch = false;
    private RecyclerView gridView;
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (context != null) {
                if (intent.getBooleanExtra("REFRESH", false)) {
                    ImageFragment.this.gridView.removeAllViews();
                }
                int intExtra = intent.getIntExtra("SORT", 0);
                if (intExtra == 1) {
                    ImageFragment.this.sortByDate();
                } else if (intExtra == 2) {
                    ImageFragment.this.sortBySize();
                }
                try {
                    ImageFragment.this.cheSlectAll.setChecked(ImageFragment.this.getCheck());
                    ImageFragment.this.adapter.notifyDataSetChanged();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    };
    private View root;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onResume() {
        super.onResume();
        if (MyApplication.getInstance().allData.dataDeleted) {
            int size = this.dataList.size();
            int i = 0;
            while (i < size) {
                if (new File(((FileDataWrapper) this.dataList.get(i)).path).exists()) {
                    i++;
                } else {
                    this.dataList.remove(i);
                    size--;
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.dataList.size());
            stringBuilder.append("");
            ImageAdapter imageAdapter = this.adapter;
            if (imageAdapter != null) {
                imageAdapter.notifyDataSetChanged();
            }
        }
        ArrayList arrayList = this.dataList;
        if (arrayList != null && arrayList.size() == 0) {
            this.root.findViewById(R.id.tv_empty).setVisibility(View.VISIBLE);
        }
    }

    public ImageFragment(Context context, ArrayList<FileDataWrapper> arrayList, AppCompatCheckBox appCompatCheckBox) {
        this.context = context;
        this.dataList = arrayList;
        this.cheSlectAll = appCompatCheckBox;
        setDeviceDimensions();
        sortBySize();
    }

    private void sortBySize() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.size, fileDataWrapper.size);
            }
        });
    }

    private void sortByDate() {
        Collections.sort(this.dataList, new Comparator<FileDataWrapper>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public int compare(FileDataWrapper fileDataWrapper, FileDataWrapper fileDataWrapper2) {
                return Long.compare(fileDataWrapper2.lastModified, fileDataWrapper.lastModified);
            }
        });
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.img_fragment, viewGroup, false);
        this.root = inflate;
        this.gridView = (RecyclerView) inflate.findViewById(R.id.grid_view);
        int dimensionPixelSize = getResources().getDimensionPixelSize(R.dimen.margin);
        this.gridView.setLayoutManager(new GridLayoutManager(this.context, 2));
        LayoutParams layoutParams = (LayoutParams) this.gridView.getLayoutParams();
        layoutParams.height = (this.deviceHeight * 90) / 100;
        this.gridView.setLayoutParams(layoutParams);
        this.gridView.setPadding(dimensionPixelSize, 0, dimensionPixelSize, 0);
        ImageAdapter imageAdapter = new ImageAdapter(getActivity(), R.layout.row_staggered_demo, this.dataList, this.cheSlectAll);
        this.adapter = imageAdapter;
        this.gridView.setAdapter(imageAdapter);
        this.adapter.notifyDataSetChanged();
        LocalBroadcastManager.getInstance(this.context).registerReceiver(this.mMessageReceiver, new IntentFilter("back.pressed.selecting"));
        return this.root;
    }

    private void setDeviceDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) this.context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        this.deviceHeight = displayMetrics.heightPixels;
        this.deviceWidth = displayMetrics.widthPixels;
    }

    private boolean getCheck() {
        ArrayList arrayList = MyApplication.getInstance().allData.appList;
        boolean z = false;
        for (int i = 0; i < arrayList.size(); i++) {
            if (!((FileDataWrapper) arrayList.get(i)).ischecked) {
                break;
            }
        }
        z = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(z);
        return z;
    }
}
