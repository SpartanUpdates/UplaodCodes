package com.kotlinz.puzzlecreator.activity;

import static com.kotlinz.puzzlecreator.NativeAds.CustomNativeAd.populateUnifiedNativeAdView;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.kotlinz.puzzlecreator.AppConstant.DataManager;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.creator.activity.CreatePuzzleActivity;
import com.kotlinz.puzzlecreator.creator.fragment.CreatorFragment;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import com.kotlinz.puzzlecreator.reviewer.ReviewerFragment;
import com.kotlinz.puzzlecreator.solver.SolverFragment;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import nl.dionsegijn.konfetti.KonfettiView;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends BaseActivity {
    Activity activity = MainActivity.this;
    private NavigationView navigationView;
    private DrawerLayout drawer;
    private View navHeader;
    public static TextView txtName, txtpoint, txtwalletpoint, txtSolver, txtCreator, iconText;
    private Toolbar toolbar;
    public static LottieAnimationView coincollect;
    public static int navItemIndex = 0;
    ImageView btnadd;
    private static final String TAG_HOME = "home";

    public static String CURRENT_TAG = TAG_HOME;

    private final boolean shouldLoadHomeFragOnBackPress = true;
    private Handler mHandler;
    LinearLayout lswitch;
    public static AppBarLayout appBarLayout;
    public static KonfettiView konfettiView;

    private NativeAd nativeAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        appBarLayout = findViewById(R.id.appbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.mipmap.ic_launcher);

        mHandler = new Handler();

        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navHeader = navigationView.getHeaderView(0);
        txtName = navHeader.findViewById(R.id.name);
        txtSolver = navHeader.findViewById(R.id.txtsolver);
        txtCreator = navHeader.findViewById(R.id.txtreceiver);
        lswitch = navHeader.findViewById(R.id.lswitch);
        iconText = navHeader.findViewById(R.id.icon_text);
        iconText.setText(sessionManager.getUserName().substring(0, 1));
        txtpoint = navHeader.findViewById(R.id.point);
        btnadd = findViewById(R.id.btnadd);
        konfettiView = findViewById(R.id.viewKonfetti);
        coincollect = findViewById(R.id.anim_collectcoin);

        txtSolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtSolver.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                txtSolver.setBackground(getResources().getDrawable(R.drawable.border));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    txtSolver.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                }
                Bundle params = new Bundle();
                mFirebaseAnalytics.logEvent("Switch_Creator_To_Solver", params);
                txtCreator.setTextColor(getResources().getColor(R.color.white));
                txtCreator.setBackgroundColor(getResources().getColor(R.color.transparant));
                sessionManager.setUserMode("s");
                setToolbarTitle("Solver");
                btnadd.setVisibility(View.GONE);
                loadHomeFragment(new SolverFragment());

            }
        });
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                mFirebaseAnalytics.logEvent("Create_Puzzle_Activity_Open", params);
                Intent i = new Intent(MainActivity.this, CreatePuzzleActivity.class);
                if (Build.VERSION.SDK_INT > 20) {
                    ActivityOptions options =
                            ActivityOptions.makeSceneTransitionAnimation(MainActivity.this);
                    startActivity(i, options.toBundle());
                } else {
                    startActivity(i);
                }
            }
        });
        txtCreator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtCreator.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                txtCreator.setBackground(getResources().getDrawable(R.drawable.border));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    txtCreator.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                }
                txtSolver.setTextColor(getResources().getColor(R.color.white));
                txtSolver.setBackgroundColor(getResources().getColor(R.color.transparant));
                Bundle params = new Bundle();
                mFirebaseAnalytics.logEvent("Switch_Solver_To_Creator", params);
                sessionManager.setUserMode("c");
                setToolbarTitle("Creator");
                btnadd.setVisibility(View.VISIBLE);
                loadHomeFragment(new CreatorFragment());
            }
        });


        if (sessionManager.getUserType().equalsIgnoreCase(DataManager.reviewer)) {
            navigationView.getMenu().getItem(1).setVisible(false);
            navigationView.getMenu().getItem(2).setVisible(false);
            lswitch.setVisibility(View.GONE);
            setToolbarTitle("Reviewer");
            btnadd.setVisibility(View.GONE);
            loadHomeFragment(new ReviewerFragment());

        } else {
            if (sessionManager.getUserMode().equalsIgnoreCase("c")) {
                txtCreator.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                txtCreator.setBackground(getResources().getDrawable(R.drawable.border));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    txtCreator.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                }
                txtSolver.setTextColor(getResources().getColor(R.color.white));
                setToolbarTitle("Creator");
                btnadd.setVisibility(View.VISIBLE);
                loadHomeFragment(new CreatorFragment());
            } else {
                txtSolver.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                txtSolver.setBackground(getResources().getDrawable(R.drawable.border));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    txtSolver.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                }
                txtCreator.setTextColor(getResources().getColor(R.color.white));
                btnadd.setVisibility(View.GONE);
                setToolbarTitle("Solver");
                loadHomeFragment(new SolverFragment());
            }
        }

        loadNavHeader();

        setUpNavigationView();

        if (savedInstanceState == null) {
            navItemIndex = 0;
            CURRENT_TAG = TAG_HOME;
        }

    }

    private void loadNavHeader() {
        txtName.setText(sessionManager.getUserName().substring(0, 1).toUpperCase() + sessionManager.getUserName().substring(1));
        txtpoint.setText(sessionManager.getUserPoints() + " Points");
    }

    private void loadHomeFragment(Fragment fragment) {
        selectNavMenu();
        Runnable mPendingRunnable = new Runnable() {
            @Override
            public void run() {
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.setCustomAnimations(android.R.anim.fade_in,
                        android.R.anim.fade_out);
                fragmentTransaction.replace(R.id.frame, fragment, CURRENT_TAG);
                fragmentTransaction.commitAllowingStateLoss();
            }
        };

        if (mPendingRunnable != null) {
            mHandler.post(mPendingRunnable);
        }
        drawer.closeDrawers();
        invalidateOptionsMenu();
    }

    private void setToolbarTitle(String title) {
        getSupportActionBar().setTitle(title);
    }

    private void selectNavMenu() {
        navigationView.getMenu().getItem(navItemIndex).setChecked(true);
    }

    private void setUpNavigationView() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                Intent intent;
                switch (menuItem.getItemId()) {
                    case R.id.nav_home:
                        if (sessionManager.getUserType().equalsIgnoreCase(DataManager.reviewer)) {
                            setToolbarTitle("Reviewer");
                            btnadd.setVisibility(View.GONE);
                            loadHomeFragment(new ReviewerFragment());
                        } else {
                            if (sessionManager.getUserMode().equalsIgnoreCase("c")) {
                                txtCreator.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                                txtCreator.setBackground(getResources().getDrawable(R.drawable.border));
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    txtCreator.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                                }
                                txtSolver.setTextColor(getResources().getColor(R.color.white));
                                setToolbarTitle("Creator");
                                btnadd.setVisibility(View.VISIBLE);
                                loadHomeFragment(new CreatorFragment());
                            } else {
                                txtSolver.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
                                txtSolver.setBackground(getResources().getDrawable(R.drawable.border));
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    txtSolver.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.white)));
                                }
                                txtCreator.setTextColor(getResources().getColor(R.color.white));
                                setToolbarTitle("Solver");
                                btnadd.setVisibility(View.GONE);
                                loadHomeFragment(new SolverFragment());
                            }
                        }
                        return true;
                    case R.id.nav_my_wallet:
                        intent = new Intent(MainActivity.this, WallateActivity.class);
                        startActivity(intent);
                        return true;

                    case R.id.nav_about_us:
                        intent = new Intent(MainActivity.this, AboutUsActivity.class);
                        startActivity(intent);
                        return true;
                    case R.id.nav_contect_us:
                        sendEmail();
                        return true;

                    case R.id.nav_privacy_policy:
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.privacy_policy_link)));
                        startActivity(browserIntent);
                        return true;

                    case R.id.nav_how_Earn:
                        intent = new Intent(MainActivity.this, HowToEarnActivity.class);
                        startActivity(intent);
                        return true;

                    case R.id.nav_logout:
                        Logout();
                    default:
                        navItemIndex = 0;
                }

                menuItem.setChecked(!menuItem.isChecked());

                return true;
            }
        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.openDrawer, R.string.closeDrawer) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };

        drawer.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    protected void sendEmail() {
        String[] TO = {getResources().getString(R.string.contact_us)};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/*");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(MainActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawers();
            return;
        }

        if (shouldLoadHomeFragOnBackPress) {
            if (navItemIndex != 0) {
                navItemIndex = 0;
                CURRENT_TAG = TAG_HOME;
                return;
            }
        }
        ExitDialog();

    }

    private void ExitDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.exit_dialog_layout);

        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        ImageView btncancel = dialog.findViewById(R.id.btn_cancel);

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (MainActivity.this.nativeAd != null) {
                            MainActivity.this.nativeAd.destroy();
                        }
                        MainActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
                dialog.dismiss();
            }
        });
        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void Logout() {
        showProgressDialog();
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).Logout(sessionManager.getToken());
        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            Bundle params = new Bundle();
                            params.putString("User_type", sessionManager.getUserType());
                            params.putString("User_ID", sessionManager.getUserId());
                            mFirebaseAnalytics.logEvent("Logout", params);
                            sessionManager.logoutUser();
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (sessionManager.getUserType().equalsIgnoreCase(DataManager.creator)) {
            getMenuInflater().inflate(R.menu.wallet, menu);
            final MenuItem customizerItem = menu.findItem(R.id.itm_wallet);
            View v = customizerItem.getActionView();
            txtwalletpoint = v.findViewById(R.id.txtwalletpoints);
            txtwalletpoint.setText(sessionManager.getUserPoints() + " Points");
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onOptionsItemSelected(customizerItem);
                }
            });
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.itm_wallet) {
            Intent intent = new Intent(MainActivity.this, WallateActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}