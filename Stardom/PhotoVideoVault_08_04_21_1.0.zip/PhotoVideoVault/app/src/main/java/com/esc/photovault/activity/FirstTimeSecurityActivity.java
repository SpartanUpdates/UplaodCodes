package com.esc.photovault.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.photovault.R;
import com.esc.photovault.pref.SharedPreference;
import com.esc.photovault.util.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;
import java.util.List;

public class FirstTimeSecurityActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    private Activity activity = FirstTimeSecurityActivity.this;
    private ImageView back_icon, done_icon;
    private EditText editText;
    private String Change_securityQuestion;
    Bundle bundle;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security);

        bundle = getIntent().getExtras();
        if (bundle != null) {
            Change_securityQuestion = bundle.getString("Change_security Question");
        }
        BannerAds();
        back_icon = (ImageView) findViewById(R.id.back);
        done_icon = (ImageView) findViewById(R.id.done_next);
        editText = (EditText) findViewById(R.id.ans_edt_text);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) FirstTimeSecurityActivity.this);
        List<String> categories = new ArrayList<String>();
        categories.add("Favourite Movie");
        categories.add("Favourite Football Player");
        categories.add("Favourite Actore");
        categories.add("Pet Name");
        categories.add("Favourite Teacher");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, R.layout.spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        back_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Change_securityQuestion != null) {
                    Intent intent1 = new Intent(FirstTimeSecurityActivity.this, Vault_folder.class);
                    startActivity(intent1);
                    finish();
                } else {
                    finish();
                }
            }
        });

        done_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editText.getText().toString().equals("")) {
                    SharedPreference.storeSecurity(FirstTimeSecurityActivity.this, Utils.FIRST_TIME_SELECT_ANSWER, editText.getText().toString());
                    if (Change_securityQuestion != null) {
                        Intent intent1 = new Intent(FirstTimeSecurityActivity.this, Vault_folder.class);
                        startActivity(intent1);
                        finish();
                    } else {
                        Intent intent1 = new Intent(FirstTimeSecurityActivity.this, LockScreenActivity.class);
                        startActivity(intent1);
                        finish();
                    }
                } else {
                    Toast.makeText(FirstTimeSecurityActivity.this, "Please enter Answer!!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        SharedPreference.storeSecurity(FirstTimeSecurityActivity.this, Utils.FIRST_TIME_SELECT_QUESTION, item);
    }

    public void onNothingSelected(AdapterView arg0) {

    }
}
