package com.kotlinz.puzzlecreator.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.AppConstant.DataManager;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.kotlinz.puzzlecreator.activity.MainActivity.txtwalletpoint;

public class WallateActivity extends BaseActivity  {
    private Button btninvite, btnwithdraw;
    TextView txtpoint, txtbalance;
    ProgressBar progress;

    /*private NativeAd nativeAd;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallate);
        setToolbar("My Wallet");

        btninvite = (Button) findViewById(R.id.btninvite);
        btnwithdraw = (Button) findViewById(R.id.btnwithdraw);

        progress = (ProgressBar) findViewById(R.id.progress);

        txtpoint = (TextView) findViewById(R.id.txtpoint);
        txtbalance = (TextView) findViewById(R.id.txtbalance);
      /*  LoadNativeAds();*/
        txtpoint.setText(sessionManager.getUserPoints());
        if (sessionManager.getBalance().equalsIgnoreCase("")) {
            txtbalance.setText("0");
        } else {
            txtbalance.setText(sessionManager.getBalance());
        }

        progress.setMax(Integer.parseInt(DataManager.threshold_point));
        progress.setProgress(Integer.parseInt(txtpoint.getText().toString()));

        if (Integer.parseInt(txtpoint.getText().toString()) > Integer.parseInt(DataManager.threshold_point)) {
            countation();
        }
        btninvite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text = " Hey!!\n" +
                        "\n" +
                        "I find something interested download app from here " +
                        "https://play.google.com/store/apps/details?id=" + getPackageName() + " and " +
                        "register your self with my referral code " + sessionManager.getReferalCode() + " and play puzzle" +
                        "this platform rewarded us with 50 points ";
                Bundle params = new Bundle();
                mFirebaseAnalytics.logEvent("Referral_Code_Share", params);

                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                shareIntent.setType("text/*");
                startActivity(Intent.createChooser(shareIntent, "Share Puzzle..."));

            }
        });
    }

   /* private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (WallateActivity.this.nativeAd != null) {
                            WallateActivity.this.nativeAd.destroy();
                        }
                        WallateActivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }*/

    public void countation() {
        int totalpoints = Integer.parseInt(txtpoint.getText().toString());
        int rounded = 100 * Math.round(totalpoints / 100);
        int pay = (rounded * 100) / Integer.parseInt(DataManager.threshold_point);
        sessionManager.setBalance(String.valueOf(pay));
        txtbalance.setText(sessionManager.getBalance());
        ManagePoints("2", String.valueOf(rounded));
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void ManagePoints(String status, String points) {
        showProgressDialog();
        Credentials manage = new Credentials();
        manage.status = status;
        manage.points = points;
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).Manage_Points(sessionManager.getToken(), manage);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {

                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();
                            sessionManager.setUserPoints(obj.getJSONObject("response").getString("user_points"));
                            showerrorDialog("Congratulations", "Your earning points are converted in real money , Now you can withdraw it");
                            txtpoint.setText(sessionManager.getUserPoints());
                            MainActivity.txtpoint.setText(sessionManager.getUserPoints() + " Points");
                            txtwalletpoint.setText(sessionManager.getUserPoints() + " Points");

                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        cancel_dialog();
                        showerrorDialog("Failed", obj.getString("message"));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }
}