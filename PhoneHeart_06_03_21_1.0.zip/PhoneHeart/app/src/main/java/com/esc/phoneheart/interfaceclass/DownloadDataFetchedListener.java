package com.esc.phoneheart.interfaceclass;

public interface DownloadDataFetchedListener {
    void onFetched(int i, long j);
}
