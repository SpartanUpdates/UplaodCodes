package com.esc.phoneheart.wrappers;

public class DownloadWrapper {
    public boolean checked = false;
    public String ext;
    public boolean isFolder = false;
    public String name;
    public String path;
    public long size;
}
