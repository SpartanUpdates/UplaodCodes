package com.kotlinz.videoeditor.videojoiner.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.kotlinz.videoeditor.videojoiner.fragment.MyVideoFragment;
import com.kotlinz.videoeditor.videojoiner.fragment.SelectVideoFragment;
import com.google.android.material.tabs.TabLayout;
import com.kotlinz.videoeditor.R;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MyAlbumActivity extends AppCompatActivity {
    static final boolean a = true;
    private TabLayout b;
    private ViewPager c;
    private final int[] d = {R.drawable.icon_video, R.drawable.icon_myalbum};

    class a extends FragmentPagerAdapter {
        private final List<Fragment> b = new ArrayList();
        private final List<String> c = new ArrayList();

        public a(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public Fragment getItem(int i) {
            return this.b.get(i);
        }

        public int getCount() {
            return this.b.size();
        }

        public void a(Fragment fragment, String str) {
            this.b.add(fragment);
            this.c.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return this.c.get(i);
        }
    }

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView( R.layout.liststatusactivity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText("Video Joiner");
        setSupportActionBar(toolbar);
        ActionBar supportActionBar = getSupportActionBar();
        PutAnalyticsEvent();
        if (a || supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(a);
            supportActionBar.setDisplayShowTitleEnabled(false);
            this.c = findViewById(R.id.viewpager);
            a(this.c);
            this.b = findViewById(R.id.tabs);
            this.b.setupWithViewPager(this.c);
            a();
            return;
        }
        throw new AssertionError();
    }

    //Firebase AnalyticsEvent
    @SuppressLint("MissingPermission")
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MyAlbumActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }


    private void a() {
        this.b.getTabAt(0).setIcon(this.d[0]);
        this.b.getTabAt(1).setIcon(this.d[1]);
    }

    private void a(ViewPager viewPager) {
        a aVar = new a(getSupportFragmentManager());
        aVar.a(new SelectVideoFragment(), "VIDEO");
        aVar.a(new MyVideoFragment(), "MY ALBUM");
        viewPager.setAdapter(aVar);
    }
    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }

     public void onBackPressed(String str) {

        super.onBackPressed();

        finish();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return a;
    }

   @Override public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            return a;
        }
        if (itemId == R.id.shareapp) {
            StringBuilder sb = new StringBuilder();

            String sb2 = sb.toString();
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.TEXT", sb2);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @SuppressLint("MissingPermission")
    public boolean isOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager.getActiveNetworkInfo() == null || !connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting()) {
            return false;
        }
        return a;
    }
}
