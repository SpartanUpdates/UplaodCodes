package com.esc.beautymackupselficlam.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class PiPEditCategory extends Activity implements OnClickListener {
    private RelativeLayout rl_pipIndianEdior;
    private RelativeLayout rl_pipeditor;
    private RelativeLayout rl_pipPakisanEditor;
    private RelativeLayout rl_pipMagazineeditor;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pip_category);
        loadAd();
        BindView();
    }

    private void BindView() {
        this.rl_pipeditor = (RelativeLayout) findViewById(R.id.ll_editor);
        this.rl_pipeditor.setOnClickListener(this);
        this.rl_pipMagazineeditor = (RelativeLayout) findViewById(R.id.ll_Editor);
        this.rl_pipMagazineeditor.setOnClickListener(this);
        this.rl_pipPakisanEditor = (RelativeLayout) findViewById(R.id.ll_CollageEditor);
        this.rl_pipPakisanEditor.setOnClickListener(this);
        this.rl_pipIndianEdior = (RelativeLayout) findViewById(R.id.ll_IndianPIPEditor);
        this.rl_pipIndianEdior.setOnClickListener(this);
    }

    public void onClick(View v) {
        if (v == this.rl_pipeditor) {
            id = R.id.ll_editor;
            if (interstitial != null && interstitial.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                startActivity(new Intent(this, PIPPhotoEditor.class));
            }
        } else if (v == this.rl_pipMagazineeditor) {
            startActivity(new Intent(this, PipPhotoMagazineEditor.class));
        } else if (v == this.rl_pipPakisanEditor) {
            startActivity(new Intent(this, PipPhotoPakistanEditor.class));
        } else if (v == this.rl_pipIndianEdior) {
            id = R.id.ll_IndianPIPEditor;
            if (interstitial != null && interstitial.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                startActivity(new Intent(this, PipphotoIndiaEditor.class));
            }
        }
    }

    private FrameLayout adContainerView;
    private InterstitialAd interstitial;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //AdaptiveBannerAd
        adContainerView = findViewById(R.id.ad_view_container);
        adView = new AdView(this);
        adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
        adContainerView.addView(adView);

        AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(PiPEditCategory.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ll_editor:
                        startActivity(new Intent(PiPEditCategory.this, PIPPhotoEditor.class));
                        break;
                    case R.id.ll_IndianPIPEditor:
                        startActivity(new Intent(PiPEditCategory.this, PipphotoIndiaEditor.class));
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    private AdSize getAdSize()
    {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(PiPEditCategory.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
