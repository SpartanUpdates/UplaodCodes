package com.kotlinz.puzzlecreator.reviewer;

import static com.kotlinz.puzzlecreator.NativeAds.CustomNativeAd.populateUnifiedNativeAdViewbig;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.kotlinz.puzzlecreator.App.MyApplication;
import com.kotlinz.puzzlecreator.activity.BaseFragment;
import com.kotlinz.puzzlecreator.R;
import com.kotlinz.puzzlecreator.kprogresshud.KProgressHUD;
import com.kotlinz.puzzlecreator.model.Credentials;
import com.kotlinz.puzzlecreator.model.puzzle_get_set;
import com.kotlinz.puzzlecreator.retrofit.APIClient;
import com.kotlinz.puzzlecreator.retrofit.APIInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import pl.droidsonroids.gif.GifImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReviewerAllListFragment extends BaseFragment {
    PuzzleAdapter adapter;
    RecyclerView recyclerView;
    ArrayList<puzzle_get_set> PuzzleList = new ArrayList<>();
    private ProgressBar loadingPB;
    private NestedScrollView nestedSV;
    int page = 1, lastpage = 0;
    SwipeRefreshLayout swipeRefreshLayout;
    LottieAnimationView anim_nodata;

    public InterstitialAd mInterstitialAd;
    private KProgressHUD hud;


    public ReviewerAllListFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reviewer_all_list, container, false);

        recyclerView = view.findViewById(R.id.recycleall);
        loadingPB = view.findViewById(R.id.idPBLoading);
        nestedSV = view.findViewById(R.id.idNestedSV);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        anim_nodata = view.findViewById(R.id.anim_nodata);
        interstitialAd();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (isNetworkAvailable()) {
                    page = 1;
                    getPuzzle();
                } else {
                    noNetworkDialog();
                }
                swipeRefreshLayout.setRefreshing(false);
                swipeRefreshLayout.setEnabled(false);
            }
        });
        nestedSV.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) {
                    if (isNetworkAvailable()) {
                        if (page <= lastpage) {
                            page++;
                            loadingPB.setVisibility(View.VISIBLE);
                            getPuzzle();
                        } else {
                            loadingPB.setVisibility(View.GONE);
                        }
                    } else {
                        noNetworkDialog();
                        loadingPB.setVisibility(View.GONE);

                    }
                }
            }
        });
        adapter = new PuzzleAdapter(getContext(), PuzzleList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        return view;
    }


    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(getActivity(), getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (MyApplication.AdsId) {
                                            case 1:
                                                Log.e("TAG", "Close Dialog");
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isNetworkAvailable()) {
            page = 1;
            getPuzzle();
        } else {
            noNetworkDialog();
        }
    }

    public class PuzzleAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private final int ITEM_TYPE_DATA = 0;
        public final int ITEM_TYPE_AD = 1;
        private final ArrayList<puzzle_get_set> listdata;
        Context context;
        private int AdsIndex = 0;

        public PuzzleAdapter(Context context, ArrayList<puzzle_get_set> listdata) {
            this.listdata = listdata;
            this.context = context;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (viewType == ITEM_TYPE_AD) {
                return new NativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_coustomads, parent, false));
            } else {
                LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
                View listItem = layoutInflater.inflate(R.layout.reviewer_puzzleview_layout, parent, false);
                PuzzleAdapter.ViewHolder viewHolder = new PuzzleAdapter.ViewHolder(listItem);
                return viewHolder;
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (getItemViewType(position) == ITEM_TYPE_AD) {
                NativeAdViewHolder nativeAdViewHolder = (NativeAdViewHolder) holder;
                if (MyApplication.getInstance().mNativeAds != null) {
                    if (AdsIndex < MyApplication.getInstance().mNativeAds.size()) {
                        NativeAd nativeAd = MyApplication.getInstance().mNativeAds.get(AdsIndex);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.row_native_ad_item, null);
                        populateUnifiedNativeAdViewbig(nativeAd, adView);
                        nativeAdViewHolder.frameLayout.removeAllViews();
                        nativeAdViewHolder.frameLayout.addView(adView);
                        AdsIndex++;
                    } else {
                        AdsIndex = 0;
                    }
                }
            } else {
                if (holder instanceof ViewHolder) {
                    ViewHolder PuzzleViewHolder = (ViewHolder) holder;
                    puzzle_get_set puzzle = listdata.get(position);
                    PuzzleViewHolder.txtquestion.setText(puzzle.getQuestion());

                    if (puzzle.getPuzzleimg() == null || puzzle.getPuzzleimg().equalsIgnoreCase("null") || puzzle.getPuzzleimg().equalsIgnoreCase("")) {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.GONE);
                    } else {
                        PuzzleViewHolder.puzzleimg.setVisibility(View.VISIBLE);
                        Glide.with(context).load(puzzle.getPuzzleimg()).into(PuzzleViewHolder.puzzleimg);
                    }
                    PuzzleViewHolder.lans.removeAllViews();
                    for (int i = 0; i < puzzle.getOptions().size(); i++) {
                        TextView textView = new TextView(context);
                        textView.setText(puzzle.getOptions().get(i));
                        textView.setBackground(getResources().getDrawable(R.drawable.eclips));

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            textView.setTypeface(getResources().getFont(R.font.poppins_medium));
                        }

                        textView.setPadding(10, 20, 10, 20);
                        textView.setTextColor(getResources().getColor(R.color.mcq_color));
                        textView.setTextSize(15);
                        textView.setGravity(Gravity.CENTER);

                        if (puzzle.getTrueans().equalsIgnoreCase(puzzle.getOptions().get(i))) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                textView.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                                textView.setTextColor(Color.WHITE);
                            }
                        } else {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                textView.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                                textView.setTextColor(Color.WHITE);

                            }
                        }
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );

                        params.setMargins(15, 5, 15, 5);
                        textView.setLayoutParams(params);
                        PuzzleViewHolder.lans.addView(textView);
                    }
                    if (puzzle.getLevel().equalsIgnoreCase("high")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.high));
                    } else if (puzzle.getLevel().equalsIgnoreCase("medium")) {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.medium));
                    } else {
                        PuzzleViewHolder.imglevel.setVisibility(View.VISIBLE);
                        PuzzleViewHolder.imglevel.setImageDrawable(getResources().getDrawable(R.drawable.low));
                    }
                    PuzzleViewHolder.laccept.setVisibility(View.GONE);
                    PuzzleViewHolder.lreject.setVisibility(View.GONE);
                    PuzzleViewHolder.laddmylist.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AddMyProfile(puzzle.getId());
                        }
                    });
                }
            }

        }

        @Override
        public int getItemViewType(int position) {
            if ((position > 0) && ((position + 1) % 2 == 0)) {
                return ITEM_TYPE_AD;
            } else {
                return ITEM_TYPE_DATA;
            }
        }

        @Override
        public int getItemCount() {
            return listdata.size();
        }

        public class NativeAdViewHolder extends RecyclerView.ViewHolder {
            FrameLayout frameLayout;

            public NativeAdViewHolder(View view) {
                super(view);
                frameLayout = view.findViewById(R.id.fl_adplaceholder);
            }
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView puzzleimg, imglevel;
            public TextView txtquestion;
            public LinearLayout laccept, lreject, laddmylist;
            CardView cardimg;
            GridLayout lans;

            public ViewHolder(View itemView) {
                super(itemView);
                puzzleimg = itemView.findViewById(R.id.img);
                lans = itemView.findViewById(R.id.lans);
                cardimg = itemView.findViewById(R.id.cardimg);
                imglevel = itemView.findViewById(R.id.imglevel);

                txtquestion = itemView.findViewById(R.id.txtquestion);

                laccept = itemView.findViewById(R.id.laccept);
                lreject = itemView.findViewById(R.id.lreject);
                laddmylist = itemView.findViewById(R.id.laddmylist);

            }
        }
    }

    private void AddMyProfile(String puzzleid) {

        showProgressDialog();
        Credentials registration = new Credentials();
        registration.puzzle_id = puzzleid;

        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).AddToMyList(sessionManager.getToken(), registration);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (res.code() == 200) {
                    try {
                        String result = res.body().string();
                        JSONObject obj = new JSONObject(result);
                        if (obj.getBoolean("status")) {
                            cancel_dialog();
                            showSuccessDialog("Success", obj.getString("message"));
                        } else {
                            cancel_dialog();
                            showerrorDialog("Failed", obj.getString("message"));
                        }
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                    cancel_dialog();
                } else {
                    try {
                        JSONObject obj = new JSONObject(res.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

    public void showSuccessDialog(String main, String Msg) {

        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_layout);

        TextView txtmain = dialog.findViewById(R.id.txtmain);
        TextView txtmsg = dialog.findViewById(R.id.text_dialog);
        ImageView btnok = dialog.findViewById(R.id.btn_dialog);
        GifImageView gimg = dialog.findViewById(R.id.anim_tryagain);
        gimg.setImageResource(R.drawable.success_anim);
        txtmain.setVisibility(View.GONE);
        txtmain.setText(main);
        txtmsg.setText(Msg);
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInterstitialAd != null) {
                    try {
                        hud = KProgressHUD.create(getActivity()).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setLabel("Showing Ads").setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null) {
                                MyApplication.AdsId = 1;
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        dialog.dismiss();
                                        getPuzzle();
                                    }
                                }, 100);
                                mInterstitialAd.show(getActivity());
                            }
                        }
                    }, 2000);
                } else {
                    dialog.dismiss();
                    getPuzzle();
                }
            }
        });
        dialog.show();

    }

    private void getPuzzle() {
        if (page == 1) {
            PuzzleList.clear();
        }
        showProgressDialog();
        Call<ResponseBody> call = APIClient.getClient().create(APIInterface.class).GetReviewerAll(sessionManager.getToken(), page);
        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String res = response.body().string();
                        JSONObject jsonObject = new JSONObject(res);
                        if (jsonObject.getBoolean("status")) {
                            Log.e("TAG", "onResponse CloseDialog");
                            JSONObject resp = jsonObject.getJSONObject("response");

                            JSONArray puzzleData = resp.getJSONArray("puzzle_data");
                            if (page == 1 && puzzleData.length() == 0) {
                                cancel_dialog();
                                swipeRefreshLayout.setVisibility(View.GONE);
                                anim_nodata.setVisibility(View.VISIBLE);

                            } else {
                                anim_nodata.setVisibility(View.GONE);
                                swipeRefreshLayout.setVisibility(View.VISIBLE);
                                for (int i = 0; i < puzzleData.length(); i++) {
                                    JSONObject pzl = puzzleData.getJSONObject(i);
                                    puzzle_get_set puzzle = new puzzle_get_set();
                                    puzzle.setId(pzl.getString("puzzle_id"));
                                    puzzle.setQuestion(pzl.getString("question"));
                                    puzzle.setPuzzletype(pzl.getString("question_type"));
                                    puzzle.setPuzzleimg(pzl.getString("image"));
                                    puzzle.setTrueans(pzl.getString("true_answer"));
                                    puzzle.setHint(pzl.getString("hint"));
                                    puzzle.setLevel(pzl.getString("difficulty_level"));
                                    JSONArray option = pzl.getJSONArray("options");
                                    List<String> opt = new ArrayList<>();
                                    for (int j = 0; j < option.length(); j++) {
                                        opt.add(option.getString(j));
                                    }

                                    puzzle.setOptions(opt);
                                    PuzzleList.add(puzzle);
                                    if (isNetworkAvailable()) {
                                        if ((PuzzleList.size() + 1) % 2 == 0) {
                                            puzzle.setNativeAds(true);
                                            PuzzleList.add(null);
                                        }
                                    }
                                }
                                cancel_dialog();
                                adapter.notifyDataSetChanged();
                                swipeRefreshLayout.setEnabled(true);

                                Log.e("Page1", "......." + page + resp.getInt("last_page"));
                                lastpage = resp.getInt("last_page");
                                if (page > lastpage) {
                                    cancel_dialog();
                                    Log.e("Page", "......." + page + resp.getInt("last_page"));
                                    Toast.makeText(getContext(), "No more data..", Toast.LENGTH_SHORT).show();
                                    loadingPB.setVisibility(View.GONE);
                                    return;
                                }
                            }
                        }

                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject obj = new JSONObject(response.errorBody().string());
                        JSONArray error = obj.getJSONArray("errors");
                        cancel_dialog();
                        swipeRefreshLayout.setEnabled(true);

                        showerrorDialog("Failed", error.getString(0));
                    } catch (IOException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    } catch (JSONException e) {
                        cancel_dialog();
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                cancel_dialog();
                showerrorDialog("Failed", "Try Again");
            }
        });
    }

}