package com.unitedvideos.videolib.libffmpeg;

public abstract interface FFmpegLoadBinaryResponseHandler
  extends ResponseHandler
{
  public abstract void onFailure();
  
  public abstract void onFailure(String paramString);
  
  public abstract void onSuccess();
  
  public abstract void onSuccess(String paramString);
}
