package com.esc.motivationquotes.usecases;

import com.esc.motivationquotes.helpers.QuoteHelper;

public class AddReadQuoteUsecase implements Usecase {
    private String mQuote;

    public AddReadQuoteUsecase(String str) {
        this.mQuote = str;
    }

    public void execute() {
        QuoteHelper.getInstance().addReadQuote(this.mQuote);
    }
}
