package com.mbit.VideoMaker.cropImage;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.ExifInterface;

import java.io.IOException;

public class C1721b {
    public static Bitmap m5446a(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width == i && height == i2) {
            return bitmap;
        }
        float f = (float) i;
        float f2 = (float) width;
        float f3 = (float) i2;
        float f4 = (float) height;
        float max = Math.max(f / f2, f3 / f4);
        f2 *= max;
        max *= f4;
        f = (f - f2) / 2.0f;
        f3 = (f3 - max) / 2.0f;
        RectF rectF = new RectF(f, f3, f2 + f, max + f3);
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, bitmap.getConfig());
        new Canvas(createBitmap).drawBitmap(bitmap, null, rectF, null);
        return createBitmap;
    }

    public static Bitmap m5447a(Bitmap bitmap, Bitmap bitmap2, int i, int i2) {
        bitmap2 = a.a(a.a(bitmap2, 25, true), 25, true);
        Canvas canvas = new Canvas(bitmap2);
        Paint paint = new Paint();
        float width = (float) bitmap.getWidth();
        float height = (float) bitmap.getHeight();
        float f = (float) i;
        float f2 = f / width;
        float f3 = (float) i2;
        float f4 = f3 / height;
        f3 = (f3 - (height * f2)) / 2.0f;
        if (f3 < 0.0f) {
            f = (f - (width * f4)) / 2.0f;
            f2 = f4;
            f3 = 0.0f;
        } else {
            f = 0.0f;
        }
        Matrix matrix = new Matrix();
        matrix.postTranslate(f, f3);
        matrix.preScale(f2, f2);
        canvas.drawBitmap(bitmap, matrix, paint);
        return bitmap2;
    }

    public static Bitmap m5448a(String str) {
        Options options = new Options();
        int z = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        Bitmap decodeFile = BitmapFactory.decodeFile(str, new Options());
        try {
            str = new ExifInterface(str).getAttribute("Orientation");
            if (str != null) {
                z = Integer.parseInt(str);
            }
            int i = 0;
            if (z==6) {
                i = 90;
            }
            if (z==3) {
                i = 180;
            }
            if (z==8) {
                i = 270;
            }
            Matrix matrix = new Matrix();
            matrix.setRotate((float) i, ((float) decodeFile.getWidth()) / 2.0f, ((float) decodeFile.getHeight()) / 2.0f);
            return Bitmap.createBitmap(decodeFile, 0, 0, options.outWidth, options.outHeight, matrix, true);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
