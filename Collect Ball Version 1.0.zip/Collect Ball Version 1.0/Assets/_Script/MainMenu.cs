﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Analytics;

namespace BallCollect
{
    public class MainMenu : MonoBehaviour
    {
        public static MainMenu instance;

        public GameObject btnSetting, shopPanel, mainPanel, coinBase, bannerViewPanel;

        public GameObject quitPanel, coinGetparticles;

        public Image btnSound, btnVibrate, btnMusic;

        bool isSound = true, isMusic = true;

        public Sprite musicOn, musicOff, soundOn, soundOff, vibrateOn, vibrateOff, settingPress;

        public Sprite musicOnPress, musicOffPress, soundOnPress, soundOffPress, vibrateOnPress, vibrateOffPress;

        public GameObject PPPanel;

        public bool isVibrate = true, isRewardSetting = false, isRewardDone = false;

        bool isQuit = false;

        SpriteState spriteState = new SpriteState(); 
        
        public GameObject settingPanel;

        bool isSetting = false, issettingStop = false;

        public GameObject InformationPanel;

        bool isInformation = false, isInformationStop = false;

        public GameObject rateUs, longTextQuit;

        void Awake()
        {
            instance = this;
            PPPanel.SetActive(false);
            if (PlayerPrefs.GetInt("iAgree") == 0)
            {
                PPPanel.SetActive(true);
            }
        }
        void Start()
        {
            if (Manager.instance.setIsGameRestart == 0)
            {
                shopPanel.SetActive(false);
                mainPanel.SetActive(true);
                coinBase.SetActive(true);
                quitPanel.SetActive(false);
            }
            else
            {
                GameController.instance.gameHud.SetActive(true);
                GameController.instance.mainPanel.SetActive(false);
                shopPanel.SetActive(false);
                mainPanel.SetActive(false);
                coinBase.SetActive(true);
                quitPanel.SetActive(false);
                GameController.instance.StartGame();
            }
            Manager.instance.setIsGameRestart = 0;


            spriteState = btnVibrate.GetComponent<Button>().spriteState;
            if (DataBase.GetVibrationOn() == 0)
            {
                isVibrate = true;
                GameController.instance.isVibrate = true;
                btnVibrate.sprite = vibrateOn;
                spriteState.pressedSprite = vibrateOnPress;

            }
            else
            {
                isVibrate = false;
                GameController.instance.isVibrate = false;
                btnVibrate.sprite = vibrateOff;
                spriteState.pressedSprite = vibrateOffPress;
            }
            btnVibrate.GetComponent<Button>().spriteState = spriteState;

            spriteState = btnSound.GetComponent<Button>().spriteState;

            if (DataBase.GetSoundOn() == 0)
            {
                isSound = true;
                GameController.instance.isSound = true;
                btnSound.sprite = soundOn;
                spriteState.pressedSprite = soundOnPress;
            }
            else
            {
                isSound = false;
                GameController.instance.isSound = false;
                btnSound.sprite = soundOff;
                spriteState.pressedSprite = soundOffPress;
            }
            btnSound.GetComponent<Button>().spriteState = spriteState;

            spriteState = btnMusic.GetComponent<Button>().spriteState;

            if (DataBase.GetMusicOn() == 0)
            {
                isMusic = true;
                btnMusic.sprite = musicOn;
                spriteState.pressedSprite = musicOnPress;
            }
            else
            {
                isMusic = false;
                btnMusic.sprite = musicOff;
                spriteState.pressedSprite = musicOffPress;
            }
            btnMusic.GetComponent<Button>().spriteState = spriteState;

            bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, CalculateBannerHeight() + 8);
            if (Manager.instance.isNetWorkOn)
            {
                bannerViewPanel.SetActive(true);
            }
            else
            {
                bannerViewPanel.SetActive(false);
            }
            if (Manager.instance.isUnityAdsShow)
                bannerViewPanel.GetComponent<RectTransform>().sizeDelta = new Vector2(0, 158);

            if (PlayerPrefs.GetInt("IsRateUS") == 0)
                rateUs.SetActive(true);
            else
                longTextQuit.SetActive(true);
        }
       
        int CalculateBannerHeight()
        {
            if (Screen.height <= 400 * Screen.dpi / 160)
            {
                return Mathf.RoundToInt(32 * Screen.dpi / 160);
            }
            else if (Screen.height <= 720 * Screen.dpi / 160)
            {
                return Mathf.RoundToInt(50 * Screen.dpi / 160 * 1.5f);
            }
            else
            {
                return Mathf.RoundToInt(90 * Screen.dpi / 160);
            }
        }
       
        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape) && !GameController.instance.isPlayable)
            {
                if (!GameController.instance.noAddPanel.activeSelf)
                {
                    if (shopPanel.activeSelf)
                    {
                        CloseShopPanel();
                        return;
                    }
                    if (isSetting)
                    {
                        SettingClick();
                        return;
                    }
                    if (isInformation)
                    {
                        InformationClick();
                        return;
                    }

                    if (PPPanel.activeSelf)
                    {
                        btnSoundPlay();
                        Application.Quit();
                    }
                    if (!isQuit)
                    {
                        if (!isStopAnimation)
                        {
                            btnSoundPlay();
                            quitPanel.SetActive(true);
                            isQuit = true;
                            StartCoroutine(stopTimer());
                        }
                    }
                    else
                    {
                        if (!isStopAnimation)
                        {
                            btnSoundPlay();
                            isQuit = false;
                            quitPanel.SetActive(false);
                        }
                    }
                }
            }
        }
        bool isStopAnimation = false;

        IEnumerator stopTimer()
        {
            isStopAnimation = true;
            yield return new WaitForSecondsRealtime(0.5f);
            isStopAnimation = false;
        }
        public void SoundClick()
        {
            spriteState = btnSound.GetComponent<Button>().spriteState;
            Analytics.CustomEvent("SoundButtonClick");

            if (isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);
            if (isSound)
            {
                DataBase.SetSoundOn(1);
                isSound = false;
                GameController.instance.isSound = false;
                btnSound.sprite = soundOff;
                spriteState.pressedSprite = soundOffPress;
            }
            else
            {
                isSound = true;
                DataBase.SetSoundOn(0);
                GameController.instance.isSound = true;
                SoundManger.instance.PlaySound("BtnClick");
                btnSound.sprite = soundOn;
                spriteState.pressedSprite = soundOnPress;
            }
            btnSound.GetComponent<Button>().spriteState = spriteState;
        }

        public void MusicClick()
        {
            spriteState = btnMusic.GetComponent<Button>().spriteState;
            Analytics.CustomEvent("MusicButtonClick");
            btnSoundPlay();
            if (isMusic)
            {
                DataBase.SetMusicOn(1);
                isMusic = false;
                btnMusic.sprite = musicOff;
                SoundManger.instance.bgMusic.mute = true;
                spriteState.pressedSprite = musicOffPress;
            }
            else
            {
                isMusic = true;
                DataBase.SetMusicOn(0);
                SoundManger.instance.bgMusic.mute = false;
                btnMusic.sprite = musicOn;
                spriteState.pressedSprite = musicOnPress;
            }
            btnMusic.GetComponent<Button>().spriteState = spriteState;
        }
        public void VibrateClick()
        {
            spriteState = btnVibrate.GetComponent<Button>().spriteState;
            Analytics.CustomEvent("VibrateButtonClick");

            SoundManger.instance.PlaySound("BtnClick");

            if (isVibrate)
            {
                isVibrate = false;
                DataBase.SetVibrationOn(1);
                GameController.instance.isVibrate = false;
                btnVibrate.sprite = vibrateOff;
                spriteState.pressedSprite = vibrateOffPress;
            }
            else
            {
                isVibrate = true;
                DataBase.SetVibrationOn(0);
                GameController.instance.isVibrate = true;
                btnVibrate.sprite = vibrateOn;
                VibrationManager.Haptic(VibrateType.Selection, false);
                spriteState.pressedSprite = vibrateOnPress;
            }
            btnVibrate.GetComponent<Button>().spriteState = spriteState;
        }
        
        public void SettingClick()
        {
            Analytics.CustomEvent("SettingButtonClick");

            if (!issettingStop)
            {
                btnSoundPlay();
                StartCoroutine(SettingFalse());

                if (!isSetting)
                {
                    isSetting = true;
                    settingPanel.SetActive(true);
                    settingPanel.GetComponent<Animator>().Play("SettingBtn");
                }
                else
                {
                    isSetting = false;
                    settingPanel.GetComponent<Animator>().Play("SettingBtnReturn");
                    StartCoroutine(SettingpanelClose());
                }
            }
        }
        IEnumerator SettingpanelClose()
        {
            yield return new WaitForSecondsRealtime(0.4f);
            settingPanel.SetActive(false);
        }
        IEnumerator SettingFalse()
        {
            issettingStop = true;
            yield return new WaitForSecondsRealtime(0.5f);
            issettingStop = false;
        }

        public void CloseShopPanel()
        {
            btnSoundPlay();
            Analytics.CustomEvent("ShopCloseButtonClick");

            this.shopPanel.SetActive(false);
            mainPanel.SetActive(true);
            if (Manager.instance.isFbAdsShow)
            {
                BannerFbAds.instance.ShowBannerAds();
            }
            else if (Manager.instance.isUnityAdsShow)
            {
                BannerUnityAds.instance.BannerAdsUnityShow();
            }
            if (Manager.instance.isNetWorkOn)
                bannerViewPanel.SetActive(true);
        }
        public void OpenShowPanel()
        {
            Analytics.CustomEvent("ShopOpenButtonClick");

            btnSoundPlay();
            if (Manager.instance.isFbAdsShow)
            {
                BannerFbAds.instance.HideBannerAds();
            }
            else if(Manager.instance.isUnityAdsShow){
                BannerUnityAds.instance.BannerAdsUnityHide();
            }
            bannerViewPanel.SetActive(false);
            this.shopPanel.SetActive(true);
            mainPanel.SetActive(false);
        }

        public void BtnShowRewared()
        {
            coinGetparticles.SetActive(false);
            btnSoundPlay();
            if (RewaredlUnityAds.instance.isVideoUnityLoad)
            {
                RewaredlUnityAds.instance.ShowRewaredVideo();
                isRewardSetting = true;
                Analytics.CustomEvent("PlayerSelectRewaredUnityAdsShows");
            }
            else if (RewardedFbAds.instance.isFBRewaredLoaded)
            {
                RewardedFbAds.instance.ShowRewardedVideo();
                RewardedFbAds.instance.isFBRewaredLoaded = false;
                isRewardSetting = true;
                Analytics.CustomEvent("PlayerSelectRewaredFbAdsShows");
            }
            else
            {
                GameController.instance.noAddPanel.SetActive(true);
                GameController.instance.noAddText.SetActive(true);
                Invoke("CloseNoAddPanel", 2);
                if (!RewardedFbAds.instance.isFBRewaredLoaded)
                    RewardedFbAds.instance.LoadRewardedVideo();
                Analytics.CustomEvent("PlayerSelectRewaredNotLoaded");
            }
        }
        public void RewardDone()
        {
            isRewardSetting = false;
            GameController.instance.noAddPanel.SetActive(false);
            if (isRewardDone)
            {
                StartCoroutine(CoinAdd());
                isRewardDone = false;
            }
        }
        IEnumerator CoinAdd()
        {
            int a = 0;
            WaitForSecondsRealtime delay = new WaitForSecondsRealtime(0.1f);
            while (a != 300)
            {
                a += 5;
                DataBase.SetCoins(DataBase.GetCoins() + 5);
                GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                if (a > 20 && !coinGetparticles.activeSelf)
                {
                    coinGetparticles.SetActive(true);
                }
                yield return 0;
            }
            yield return delay;
            a = 0;
        }
        void CloseNoAddPanel()
        {
            GameController.instance.noAddPanel.SetActive(false);
            GameController.instance.noAddText.SetActive(false);
        }
        public void QuitClick()
        {
            Analytics.CustomEvent("QuitGameButtonYes");
            btnSoundPlay();
            Application.Quit();
        }

        public void QuitCloseClick()
        {
            Analytics.CustomEvent("QuitGameButtonNo");
            btnSoundPlay();
            isQuit = false;
            quitPanel.SetActive(false);
        }
      
        public void InformationClick()
        {
            Analytics.CustomEvent("InformationButtonClick");

            if (!isInformationStop)
            {
                btnSoundPlay();
                StartCoroutine(InformationFalse());

                if (!isInformation)
                {
                    isInformation = true;
                    InformationPanel.SetActive(true);
                    InformationPanel.GetComponent<Animator>().Play("Information");
                }
                else
                {
                    isInformation = false;
                    InformationPanel.GetComponent<Animator>().Play("InformationReturn");
                    StartCoroutine(InformationClose());
                }
            }
        }
        IEnumerator InformationClose()
        {
            yield return new WaitForSecondsRealtime(0.4f);
            InformationPanel.SetActive(false);
        }
        IEnumerator InformationFalse()
        {
            isInformationStop = true;
            yield return new WaitForSecondsRealtime(0.5f);
            isInformationStop = false;
        }

        public void BtnLike()
        {
            Analytics.CustomEvent("LikeButtonClick");
            btnSoundPlay();
            Application.OpenURL(Manager.instance.strLike);

        }
        public void BtbnPP()
        {
            Analytics.CustomEvent("PPButtonClick");
            btnSoundPlay();
            Application.OpenURL(Manager.instance.strPrivacyPolicy);
        }

        public void BtnShareApp()
        {
            Analytics.CustomEvent("ShareButtonClick");
            btnSoundPlay();

#if UNITY_ANDROID
            // Get the required Intent and UnityPlayer classes.
            AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
            AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");

            // Construct the intent.
            AndroidJavaObject intent = new AndroidJavaObject("android.content.Intent");
            intent.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_SEND"));
            intent.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_TEXT"), Manager.instance.strShareApp);
            intent.Call<AndroidJavaObject>("setType", "text/plain");

            // Display the chooser.
            AndroidJavaObject currentActivity = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject chooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", intent, "Share");
            currentActivity.Call("startActivity", chooser);
#endif
        }

        public void PPAgree()
        {
            Analytics.CustomEvent("PPAgree");
            btnSoundPlay();
            PPPanel.SetActive(false);
            PlayerPrefs.SetInt("iAgree",1);
        }

        void btnSoundPlay()
        {
            SoundManger.instance.PlaySound("BtnClick");
            if (isVibrate)
                VibrationManager.Haptic(VibrateType.Selection, false);
        }
        public void DemoScene()
        {
            SceneManager.LoadScene("Demo");
            Time.timeScale = 01;
        }
        public void BtbMoreAPP()
        {
            Analytics.CustomEvent("MoreAppButtonClick");
            btnSoundPlay();
            Application.OpenURL(Manager.instance.strMoreApp);
        }

        public void BtnRateUs()
        {
            Analytics.CustomEvent("RateUSButtonClick");
            btnSoundPlay();
            Application.OpenURL(Manager.instance.strRateUs);
            PlayerPrefs.SetInt("IsRateUS",1);
        }
    }
}