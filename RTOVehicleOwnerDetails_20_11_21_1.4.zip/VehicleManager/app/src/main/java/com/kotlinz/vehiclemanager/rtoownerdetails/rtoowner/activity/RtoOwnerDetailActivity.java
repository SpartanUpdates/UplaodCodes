package com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.room.Room;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.greedygame.core.adview.general.AdLoadCallback;
import com.greedygame.core.adview.general.GGAdview;
import com.greedygame.core.app_open_ads.general.AdOrientation;
import com.greedygame.core.app_open_ads.general.GGAppOpenAds;
import com.greedygame.core.interstitial.general.GGInterstitialAd;
import com.greedygame.core.interstitial.general.GGInterstitialEventsListener;
import com.greedygame.core.models.general.AdErrors;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.history.Model.OwnerHistoryPaidModel;
import com.kotlinz.vehiclemanager.history.Room.HistoryDatabase;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.kotlinz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.kotlinz.vehiclemanager.rtoownerdetails.rtoowner.model.OwnerInfoModel;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.utils.HeaderFooterPageEvent;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class RtoOwnerDetailActivity extends AppCompatActivity {
    private Activity activity = RtoOwnerDetailActivity.this;
    private String strOwnerName, strRegistrationNumber, strRegistrationDate, strFuelType, strEngineNumber, strInsuranceUpto, strVehicleType, strCity, strState;
    private LinearLayout header, ll_ownerDataLayout2;
    private TextView tv_address, tv_registrationNo, tv_registrationDate, tv_engineNo, tv_ownerName, tv_vehicleClass,
            tv_fuelType, tv_insuranceUpto,
            title_tv;
    private TextView ownerName2, regNumber2, vehicleClass2, registrationDate2, insuranceUpto2, engineNumber2, fuelType2, city2, state2;
    private String sOwnerName, sRegNumber, sVehicleClass, sRegistrationDate, sInsuranceUpto, sEngineNumber, sFuelType, sCity, sState;
    private Button download2;
    private Button btn_getData;
    private Button btn_download;
    private ScrollView scrollView;
    private EditText input1, input2, input3, input4;
    private String result, resultTwo;
    private ProgressDialog pddownload;
    private ArrayList<OwnerInfoModel> ownerDetaillist;
    private List<OwnerHistoryPaidModel> ownerHistoryPaidModelList = new ArrayList<>();
    private Boolean userExists = true;
    private ImageView iv_back;
    private ImageView iv_reset;
    private String first;
    private String second;
    private String Third;
    private String Fourth;
    private Boolean checkDark = false;
    private LinearLayout ll_ownerData, ll_ownerDataLayout;
    private AppCompatDialog dialog;
    HistoryDatabase historyDatabase;

    GGAdview gg_banner;

    private int id;
    public GGInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rto_owner_detail);
        getPermission();
        PutAnalyticsEvent();
        first = getIntent().getStringExtra("first");
        second = getIntent().getStringExtra("second");
        Third = getIntent().getStringExtra("third");
        Fourth = getIntent().getStringExtra("fourth");

        strOwnerName = getIntent().getStringExtra("ownerName");
        strRegistrationNumber = getIntent().getStringExtra("registrationNumber");
        strRegistrationDate = getIntent().getStringExtra("registrationDate");
        strFuelType = getIntent().getStringExtra("fuelType");
        strEngineNumber = getIntent().getStringExtra("engineNumber");
        strInsuranceUpto = getIntent().getStringExtra("insuranceUpto");
        strVehicleType = getIntent().getStringExtra("vehicleClass");
        strCity = getIntent().getStringExtra("city");
        strState = getIntent().getStringExtra("state");

        ownerDetaillist = new ArrayList<>();

        historyDatabase = Room.databaseBuilder(RtoOwnerDetailActivity.this, HistoryDatabase.class, "VehicleDetailsHistory").allowMainThreadQueries().build();
        DarkTheame darkTheame = new DarkTheame(RtoOwnerDetailActivity.this);

        BannerAds();
        InterAds();
        BindView();
        SetClickListener();
        getStringFromHistory();

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupNightMode();
            checkDark = true;
        }
        if (darkTheame.modeData().equals("nightMode")) {
            setupNightMode();
            checkDark = true;
        }

        if (first != null && second != null && Third != null && Fourth != null) {
            input1.setText(first);
            input2.setText(second);
            input3.setText(Third);
            input4.setText(Fourth);

            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
        }
        if (strRegistrationNumber != null) {
            ll_ownerDataLayout2.setVisibility(View.VISIBLE);
            getStringFromHistory();
        }
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "RtoOwnerDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        gg_banner = findViewById(R.id.ggAdView_banner);
        gg_banner.setUnitId(getResources().getString(R.string.BannerAd));
        gg_banner.loadAd(new AdLoadCallback() {
                             @Override
                             public void onReadyForRefresh() {

                             }

                             @Override
                             public void onUiiClosed() {

                             }

                             @Override
                             public void onUiiOpened() {

                             }

                             @Override
                             public void onAdLoaded() {

                             }

                             @Override
                             public void onAdLoadFailed(@NotNull AdErrors adErrors) {

                             }
                         }
        );
    }

    private void InterAds() {
        GGAppOpenAds.setOrientation(AdOrientation.PORTRAIT);
        interstitialAd = new GGInterstitialAd(activity, getResources().getString(R.string.gg_inter));
        interstitialAd.setListener(new GGInterstitialEventsListener() {
            @Override
            public void onAdLoaded() {


            }

            @Override
            public void onAdClosed() {
                switch (id) {
                    case 1:
                        startActivity(new Intent(RtoOwnerDetailActivity.this, MainActivity.class));
                        finish();
                        break;
                    case 2:
                        input1.setEnabled(true);
                        input2.setEnabled(true);
                        input3.setEnabled(true);
                        input4.setEnabled(true);
                        ResetData();
                        break;
                    case 3:
                        getDataFromPaidApi(result);
                        break;
                    case 4:
                        if (strEngineNumber == null) {
                            printDataFromApiDirect();
                        } else {
                            printDataFromHistory();
                        }
                        break;
                }
            }

            @Override
            public void onAdOpened() {

            }

            @Override
            public void onAdShowFailed() {

            }

            @Override
            public void onAdLoadFailed(AdErrors cause) {

            }
        });
        interstitialAd.loadAd();
    }


    private void getPermission() {
        if (ContextCompat.checkSelfPermission(RtoOwnerDetailActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(RtoOwnerDetailActivity.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    101);

        }
    }

    private void setupNightMode() {
        ll_ownerDataLayout2.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        header.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        title_tv.setTextColor(Color.parseColor("#FFFFFF"));
        input1.setTextColor(Color.parseColor("#FFFFFF"));
        input1.setHintTextColor(Color.parseColor("#756B6B"));
        input2.setTextColor(Color.parseColor("#FFFFFF"));
        input2.setHintTextColor(Color.parseColor("#756B6B"));
        input3.setTextColor(Color.parseColor("#FFFFFF"));
        input3.setHintTextColor(Color.parseColor("#756B6B"));
        input4.setTextColor(Color.parseColor("#FFFFFF"));
        input4.setHintTextColor(Color.parseColor("#756B6B"));
        btn_getData.setTextColor(Color.parseColor("#FFFFFF"));
        btn_download.setTextColor(Color.parseColor("#FFFFFF"));
        ll_ownerDataLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
    }

    private void BindView() {
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);

        iv_back = findViewById(R.id.iv_back);
        iv_reset = findViewById(R.id.iv_reset);

        btn_getData = findViewById(R.id.btn_getData);
        tv_address = findViewById(R.id.city);
        tv_registrationNo = findViewById(R.id.regNumber);
        tv_registrationDate = findViewById(R.id.regDate);
        tv_engineNo = findViewById(R.id.engineNo);
        tv_ownerName = findViewById(R.id.ownerName);
        tv_vehicleClass = findViewById(R.id.tv_vehicleClass);
        tv_fuelType = findViewById(R.id.fuelType);
        tv_insuranceUpto = findViewById(R.id.insUpto);
        title_tv = findViewById(R.id.title_tv);
        btn_download = findViewById(R.id.btn_download);
        ll_ownerData = findViewById(R.id.ll_ownerData);
        ll_ownerDataLayout = findViewById(R.id.ll_ownerDataLayout);
        ll_ownerDataLayout2 = findViewById(R.id.ll_ownerDataLayout2);
        header = findViewById(R.id.header);
        ownerName2 = findViewById(R.id.ownerName2);
        regNumber2 = findViewById(R.id.regNumber2);
        vehicleClass2 = findViewById(R.id.tv_vehicleClass2);
        insuranceUpto2 = findViewById(R.id.insuranceUpto2);
        engineNumber2 = findViewById(R.id.engineNo2);
        fuelType2 = findViewById(R.id.fuelType2);
        city2 = findViewById(R.id.city2);
        state2 = findViewById(R.id.state2);
        registrationDate2 = findViewById(R.id.regDate2);
        download2 = findViewById(R.id.btn_download2);

        scrollView = findViewById(R.id.scrollView);
        scrollView.setScrollbarFadingEnabled(false);
        scrollView.setSmoothScrollingEnabled(true);
    }

    private void getStringFromHistory() {

        if (strRegistrationNumber != null) {
            ownerName2.setText(strOwnerName);
            regNumber2.setText(strRegistrationNumber);
            vehicleClass2.setText(strVehicleType);
            registrationDate2.setText(strRegistrationDate);
            insuranceUpto2.setText(strInsuranceUpto);
            engineNumber2.setText(strEngineNumber);
            fuelType2.setText(strFuelType);
            city2.setText(strCity);
            state2.setText(strState);

            if (strOwnerName.equals("")) {
                ownerName2.setText("--");
            }
            if (strRegistrationNumber.equals("")) {
                regNumber2.setText("--");
            }
            if (strVehicleType.equals("")) {
                vehicleClass2.setText("--");
            }
            if (strRegistrationDate.equals("")) {
                registrationDate2.setText("--");
            }
            if (strInsuranceUpto.equals("")) {
                insuranceUpto2.setText("--");
            }
            if (strEngineNumber.equals("")) {
                engineNumber2.setText("--");
            }
            if (strFuelType.equals("")) {
                fuelType2.setText("--");
            }
            if (strCity.equals("")) {
                city2.setText("--");
            }
            if (strState.equals("")) {
                state2.setText("--");
            }

            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
            btn_getData.setEnabled(false);
        }
    }

    public void SetClickListener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        iv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 2;
                    interstitialAd.show();
                } else {
                    input1.setEnabled(true);
                    input2.setEnabled(true);
                    input3.setEnabled(true);
                    input4.setEnabled(true);
                    ResetData();
                }
            }
        });

        input1.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input1.getText().toString().length() == 2) {
                    input2.setText("");
                    input2.requestFocus();
                }
            }
        });
        input2.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input2.getText().toString().length() == 2) {
                    input3.setText("");
                    input3.requestFocus();
                }
            }
        });
        input3.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input3.getText().toString().length() == 2) {
                    input4.setText("");
                    input4.requestFocus();
                }
            }
        });

        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (input4.length() == 3) {
                    View view = getCurrentFocus();
                    if (view != null) {
                        InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        btn_getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetData();
            }
        });

        download2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
                    id = 4;
                    interstitialAd.show();
                } else {
                    if (strEngineNumber == null) {
                        printDataFromApiDirect();
                    } else {
                        printDataFromHistory();
                    }
                }
            }
        });
    }

    private void printDataFromHistory() {
        if (Build.VERSION.SDK_INT > 22) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
                return;
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Owner Name : ");
            sb3.append(strOwnerName);
            sb3.append("\nRegistration No : ");
            sb3.append(strRegistrationNumber);
            sb3.append("\nRegistration Date : ");
            sb3.append(strRegistrationDate);
            sb3.append("\nFuel Type : ");
            sb3.append(strFuelType);
            sb3.append("\nEngine Number : ");
            sb3.append(strEngineNumber);
            sb3.append("\nInsurance Upto : ");
            sb3.append(strInsuranceUpto);
            sb3.append("\nVehicle Class : ");
            sb3.append(strVehicleType);
            sb3.append("\nCity : ");
            sb3.append(strCity);
            sb3.append("\nState : ");
            sb3.append(strState);
            sb3.append("\n\nGet All Inidia Vehicle details using ");
            sb3.append(getResources().getString(R.string.app_name));
            Chunk chunk = new Chunk("\n click here to download the app \n");
            chunk.setBackground(BaseColor.YELLOW);
            chunk.setAnchor("https://play.google.com/store/apps/details?id=" + getPackageName());
            createandDisplayPdf(String.valueOf(sb3), strOwnerName, chunk);
        }
    }

    private void printDataFromApiDirect() {
       /* if (Build.VERSION.SDK_INT > 22) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
                return;
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Owner Name : ");
            sb3.append(sOwnerName);
            sb3.append("\nRegistration No : ");
            sb3.append(sRegNumber);
            sb3.append("\nRegistration Date : ");
            sb3.append(sRegistrationDate);
            sb3.append("\nFuel Type : ");
            sb3.append(sFuelType);
            sb3.append("\nEngine Number : ");
            sb3.append(sEngineNumber);
            sb3.append("\nInsurance Upto : ");
            sb3.append(sInsuranceUpto);
            sb3.append("\nVehicle Class : ");
            sb3.append(sVehicleClass);
            sb3.append("\nCity : ");
            sb3.append(sCity);
            sb3.append("\nState : ");
            sb3.append(sState);
            sb3.append("\n\nGet All India Vehicle details using ");
            sb3.append(getResources().getString(R.string.app_name));
            Chunk chunk = new Chunk("\n click here to download the app \n");
            chunk.setBackground(BaseColor.YELLOW);
            chunk.setAnchor("https://play.google.com/store/apps/details?id=" + getPackageName());
            createandDisplayPdf(String.valueOf(sb3), sOwnerName, chunk);
        }*/
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("Owner Name : ");
        sb3.append(sOwnerName);
        sb3.append("\nRegistration No : ");
        sb3.append(sRegNumber);
        sb3.append("\nRegistration Date : ");
        sb3.append(sRegistrationDate);
        sb3.append("\nFuel Type : ");
        sb3.append(sFuelType);
        sb3.append("\nEngine Number : ");
        sb3.append(sEngineNumber);
        sb3.append("\nInsurance Upto : ");
        sb3.append(sInsuranceUpto);
        sb3.append("\nVehicle Class : ");
        sb3.append(sVehicleClass);
        sb3.append("\nCity : ");
        sb3.append(sCity);
        sb3.append("\nState : ");
        sb3.append(sState);
        sb3.append("\n\nGet All India Vehicle details using ");
        sb3.append(getResources().getString(R.string.app_name));
        Chunk chunk = new Chunk("\n click here to download the app \n");
        chunk.setBackground(BaseColor.YELLOW);
        chunk.setAnchor("https://play.google.com/store/apps/details?id=" + getPackageName());
        createandDisplayPdf(String.valueOf(sb3), sOwnerName, chunk);
    }

    private void getDataFromPaidApi(String result) {
        DialogAnimation();
        ownerHistoryPaidModelList = historyDatabase.ownerHistoryDao().getOwnerHistory();
        for (int i = 0; i < ownerHistoryPaidModelList.size(); i++) {
            String regNo = ownerHistoryPaidModelList.get(i).getRegistrationNo();
            if (regNo.equals(result)) {
                ll_ownerDataLayout2.setVisibility(View.VISIBLE);

                userExists = false;

                sOwnerName = ownerHistoryPaidModelList.get(i).getOwnerName();
                sRegNumber = ownerHistoryPaidModelList.get(i).getRegistrationNo();
                sRegistrationDate = ownerHistoryPaidModelList.get(i).getRegistrationDate();
                sVehicleClass = ownerHistoryPaidModelList.get(i).getVehicleClass();
                sInsuranceUpto = ownerHistoryPaidModelList.get(i).getInsuranceUpto();
                sEngineNumber = ownerHistoryPaidModelList.get(i).getEngineNumber();
                sFuelType = ownerHistoryPaidModelList.get(i).getFuelType();
                sCity = ownerHistoryPaidModelList.get(i).getCity();
                sState = ownerHistoryPaidModelList.get(i).getState();

                ownerName2.setText(sOwnerName);
                regNumber2.setText(sRegNumber);
                registrationDate2.setText(sRegistrationDate);
                vehicleClass2.setText(sVehicleClass);
                insuranceUpto2.setText(sInsuranceUpto);
                engineNumber2.setText(sEngineNumber);
                fuelType2.setText(sFuelType);
                city2.setText(sCity);
                state2.setText(sState);

                if (sOwnerName.equals("")) {
                    ownerName2.setText("--");
                }
                if (sRegNumber.equals("")) {
                    regNumber2.setText("--");
                }
                if (sRegistrationDate.equals("")) {
                    registrationDate2.setText("--");
                }
                if (sVehicleClass.equals("")) {
                    vehicleClass2.setText("--");
                }
                if (sInsuranceUpto.equals("")) {
                    insuranceUpto2.setText("--");
                }
                if (sEngineNumber.equals("")) {
                    engineNumber2.setText("--");
                }
                if (sFuelType.equals("")) {
                    fuelType2.setText("--");
                }
                if (sCity.equals("")) {
                    city2.setText("--");
                }
                if (sState.equals("")) {
                    state2.setText("--");
                }
                dialog.dismiss();
            }
        }
        if (userExists) {
            RtoDetailsInterface rtoDetailsInterface = RtoDetailsApiClient.getOwnerDetailsFromPaidApi().create(RtoDetailsInterface.class);
            Call<OwnerInfoModel> call = rtoDetailsInterface.getVehicleOwnerDetails(String.valueOf(R.string.app_link), MyApplication.id, result);
            call.enqueue(new Callback<OwnerInfoModel>() {
                @Override
                public void onResponse(Call<OwnerInfoModel> call, Response<OwnerInfoModel> response) {
                    if (response.isSuccessful()) {
                        OwnerInfoModel OwnerInfoModel = response.body();
                        int code = OwnerInfoModel.getCode();
                        if (code == 200) {

                            ll_ownerDataLayout2.setVisibility(View.VISIBLE);

                            sOwnerName = OwnerInfoModel.getResponse().getOwner_name();
                            sRegNumber = OwnerInfoModel.getResponse().getLicense_plate();
                            sRegistrationDate = OwnerInfoModel.getResponse().getRegistration_date();
                            String[] newDate;
                            try {
                                newDate = sRegistrationDate.split("-");
                                sRegistrationDate = newDate[1] + " - " + newDate[2] + " - " +
                                        "" + newDate[0];
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            sVehicleClass = OwnerInfoModel.getResponse().getVehicleClass();
                            sInsuranceUpto = OwnerInfoModel.getResponse().getInsurance_expiry();
                            String[] newInsDate;
                            try {
                                newInsDate = sInsuranceUpto.split("-");
                                sInsuranceUpto = newInsDate[1] + " - " + newInsDate[2] + " - " + newInsDate[0];
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            sEngineNumber = OwnerInfoModel.getResponse().getEngine_number();
                            sFuelType = OwnerInfoModel.getResponse().getFuel_type();
                            sCity = OwnerInfoModel.getResponse().getRto_code() + " - " + OwnerInfoModel.getResponse().getRto();
                            sState = OwnerInfoModel.getResponse().getState();

                            insertOwnerDataIntoRoom();

                            ownerName2.setText(sOwnerName);
                            regNumber2.setText(sRegNumber);
                            registrationDate2.setText(sRegistrationDate);
                            vehicleClass2.setText(sVehicleClass);
                            insuranceUpto2.setText(sInsuranceUpto);
                            engineNumber2.setText(sEngineNumber);
                            fuelType2.setText(sFuelType);
                            city2.setText(sCity);
                            state2.setText(sState);

                            if (sOwnerName.equals("")) {
                                ownerName2.setText("--");
                            }
                            if (sRegNumber.equals("")) {
                                regNumber2.setText("--");
                            }
                            if (sRegistrationDate.equals("")) {
                                registrationDate2.setText("--");
                            }
                            if (sVehicleClass.equals("")) {
                                vehicleClass2.setText("--");
                            }
                            if (sVehicleClass.equals("class")) {
                                vehicleClass2.setText("--");
                            }
                            if (sInsuranceUpto.equals("")) {
                                insuranceUpto2.setText("--");
                            }
                            if (sEngineNumber.equals("")) {
                                engineNumber2.setText("--");
                            }
                            if (sFuelType.equals("")) {
                                fuelType2.setText("--");
                            }
                            if (sCity.equals("")) {
                                city2.setText("--");
                            }
                            if (sState.equals("")) {
                                state2.setText("--");
                            }

                            dialog.dismiss();
                        } else {
                            Toast.makeText(RtoOwnerDetailActivity.this, "Server error !", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                    }
                }

                @Override
                public void onFailure(Call<OwnerInfoModel> call, Throwable t) {
                    Toast.makeText(RtoOwnerDetailActivity.this, "No data found on this registration number !", Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                }
            });
        }
    }

    public void GetData() {
        ll_ownerDataLayout2.setVisibility(View.GONE);
        tv_ownerName.setText("");
        tv_registrationNo.setText("");
        tv_registrationDate.setText("");
        tv_fuelType.setText("");
        tv_engineNo.setText("");
        tv_insuranceUpto.setText("");
        tv_vehicleClass.setText("");
        tv_address.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input4.getWindowToken(), 0);
        input4.clearFocus();
        if (!isConnected(activity)) {
            Toast.makeText(activity, "No Internet Connection", Toast.LENGTH_SHORT).show();
            return;
        }
        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        result = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("&reg2=");
        sb2.append(string4);
        resultTwo = sb2.toString();

        if (TextUtils.isEmpty(string)) {
            input1.setError("This should not be empty");
            input1.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string2)) {
            input2.setError("This should not be empty");
            input2.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string3)) {
            input3.setError("This should not be empty");
            input3.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string4)) {
            input4.setError("This should not be empty");
            input4.requestFocus();
            return;
        }

        scrollView.fullScroll(ScrollView.FOCUS_UP);
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 3;
            interstitialAd.show();
        } else {
            getDataFromPaidApi(result);
        }
    }

    private void DialogAnimation() {
        if (checkDark) {
            dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
            dialog.setContentView(R.layout.layout_dialog_search_dark);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        } else {
            dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
            dialog.setContentView(R.layout.layout_dialog_search);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        }
    }

    public void ResetData() {
        tv_ownerName.setText("");
        tv_registrationNo.setText("");
        tv_registrationDate.setText("");
        tv_fuelType.setText("");
        tv_engineNo.setText("");
        tv_insuranceUpto.setText("");
        tv_vehicleClass.setText("");
        tv_address.setText("");

        input1.setText("");
        input2.setText("");
        input3.setText("");
        input4.setText("");
        ll_ownerDataLayout2.setVisibility(View.GONE);
        btn_getData.setEnabled(true);
        scrollView.fullScroll(ScrollView.FOCUS_UP);
        input1.requestFocus();
    }

    public void createandDisplayPdf(final String s, String strOwnerName, Chunk chunk) {

        if (Build.VERSION.SDK_INT > 29) {
            pddownload = new ProgressDialog(activity);
            pddownload.setMessage("Downloading...");
            pddownload.setCancelable(false);
            pddownload.show();
            StringBuilder sb2;
            final Document document = new Document(PageSize.A4, 20.0f, 20.0f, 50.0f, 25.0f);
            try {
                try {
                    "mounted".equals(Environment.getExternalStorageState());
                    final StringBuilder sb = new StringBuilder();
                    sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
                    sb.append(File.separator);
                    sb.append("ViewVehicleDetails");
                    File file = new File(sb.toString());
                    if (!file.exists()) {
                        file.mkdir();
                    }
                    sb2 = new StringBuilder();
                    sb2.append(strOwnerName);
                    sb2.append(".pdf");
                    final File file2 = new File(file, sb2.toString());

                    PdfWriter.getInstance(document, new FileOutputStream(file2)).setPageEvent(new HeaderFooterPageEvent());
                    document.open();
                    final Paragraph paragraph = new Paragraph(s);
                    paragraph.add(chunk);
                    final Font font = new Font(Font.FontFamily.COURIER);
                    paragraph.setAlignment(0);
                    paragraph.setFont(font);
                    document.addTitle("VEHICLE DETAILS");
                    document.add(paragraph);
                    document.close();

                    new CountDownTimer(500L, 500L) {
                        public void onFinish() {
                            openScreenshot(file2);
                            pddownload.dismiss();
                        }

                        public void onTick(final long n) {
                        }
                    }.start();
                } finally {
                }
            } catch (IOException ex) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("ioException:");
                sb3.append(ex);
                Log.e("TAG","Ex"+sb3.toString());
                pddownload.dismiss();
            } catch (DocumentException ex2) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append("DocumentException:");
                sb4.append(ex2);
                Log.e("TAG","DEx"+sb4.toString());
                pddownload.dismiss();
            }
            document.close();
        } else {
            pddownload = new ProgressDialog(activity);
            pddownload.setMessage("Downloading...");
            pddownload.setCancelable(false);
            pddownload.show();
            StringBuilder sb2;
            final Document document = new Document(PageSize.A4, 20.0f, 20.0f, 50.0f, 25.0f);
            try {
                try {
                    "mounted".equals(Environment.getExternalStorageState());
                    final StringBuilder sb = new StringBuilder();
                    sb.append(Environment.getExternalStorageDirectory());
                    sb.append(File.separator);
                    sb.append("ViewVehicleDetails");
                    File file = new File(sb.toString());
                    if (!file.exists()) {
                        file.mkdir();
                    }
                    sb2 = new StringBuilder();
                    sb2.append(strOwnerName);
                    sb2.append(".pdf");
                    final File file2 = new File(file, sb2.toString());
                    PdfWriter.getInstance(document, new FileOutputStream(file2)).setPageEvent(new HeaderFooterPageEvent());
                    document.open();
                    Paragraph paragraph = new Paragraph(s);
                    paragraph.add(chunk);
                    final Font font = new Font(Font.FontFamily.COURIER);
                    paragraph.setAlignment(0);
                    paragraph.setFont(font);
                    document.addTitle("VEHICLE DETAILS");
                    document.add(paragraph);
                    document.close();
                    new CountDownTimer(500L, 500L) {
                        public void onFinish() {
                            openScreenshot(file2);
                            pddownload.dismiss();
                        }

                        public void onTick(final long n) {
                        }
                    }.start();
                } finally {
                }
            } catch (IOException ex) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("ioException:");
                sb3.append(ex);
                pddownload.dismiss();
            } catch (DocumentException ex2) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append("DocumentException:");
                sb4.append(ex2);
                pddownload.dismiss();
            }
            document.close();
        }
    }


    private void openScreenshot(final File file) {
        final Uri uriForFile = FileProvider.getUriForFile(activity, getPackageName() + ".provider", file);
        final AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Share vehicle details");
        builder.setMessage("Your  Vehicle Details have been saved to PDF in \"ViewVehicleDetails\" folder.").setCancelable(true).setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(uriForFile, "application/pdf");
                target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                target.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent intent = Intent.createChooser(target, "Open File");
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "No Application available to view pdf", Toast.LENGTH_LONG).show();
                }
            }
        }).setNegativeButton("Share", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                final StringBuilder sb = new StringBuilder();
                sb.append("View All India Vehicle details - Get \n App @ https://play.google.com/store/apps/details?id=");
                sb.append(getPackageName());
                final Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                intent.putExtra(Intent.EXTRA_TEXT, sb.toString());
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
        builder.create().show();
    }

    private boolean checkIfAlreadyhavePermission() {
        return ContextCompat.checkSelfPermission(activity, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    public boolean isConnected(final Context context) {
        final ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting()) {
            final NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
            final NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
            return (networkInfo2 != null && networkInfo2.isConnectedOrConnecting()) || (networkInfo != null && networkInfo.isConnectedOrConnecting());
        }
        return false;
    }

    private void insertOwnerDataIntoRoom() {
        Thread thread = new Thread(new Runnable() {
            public void run() {
                OwnerHistoryPaidModel ownerHistory = new OwnerHistoryPaidModel(sOwnerName, sRegNumber, sRegistrationDate, sFuelType, sEngineNumber, sInsuranceUpto, sVehicleClass, sCity, sState);
                historyDatabase.ownerHistoryDao().insertOwnerData(ownerHistory);
            }
        });
        thread.start();
    }

    @Override
    public void onBackPressed() {
        if (interstitialAd != null && interstitialAd.isAdLoaded()) {
            id = 1;
            interstitialAd.show();
        } else {
            startActivity(new Intent(RtoOwnerDetailActivity.this, MainActivity.class));
            finish();
            super.onBackPressed();
        }
    }
}