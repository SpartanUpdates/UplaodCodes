package com.kotlinz.festivalstorymaker.Model.ZoomCollage.CategoryWiseData;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class ZoomCollageCategoryWiseResponse {

	@SerializedName("data")
	private ArrayList<ZoomCollageCategoryWiseData> data;

	@SerializedName("total_records")
	private int totalRecords;

	@SerializedName("status")
	private String status;

	public ArrayList<ZoomCollageCategoryWiseData> getData(){
		return data;
	}

	public int getTotalRecords(){
		return totalRecords;
	}

	public String getStatus(){
		return status;
	}
}