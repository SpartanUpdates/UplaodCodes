package com.esc.lovemessages;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;

public class StickerTextView extends StickerView {
    private AutoResizeTextView tv_main;

    public StickerTextView(Context context) {
        super(context);
    }

    public StickerTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public StickerTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public View getMainView() {
        AutoResizeTextView autoResizeTextView = this.tv_main;
        if (autoResizeTextView != null) {
            return autoResizeTextView;
        }
        this.tv_main = new AutoResizeTextView(getContext());
        this.tv_main.setTextColor(-1);
        this.tv_main.setGravity(17);
        this.tv_main.setTextSize(400.0f);
        LayoutParams layoutParams = new LayoutParams(-1, -1);
        layoutParams.gravity = 17;
        this.tv_main.setLayoutParams(layoutParams);
        return this.tv_main;
    }

    public void setText(String str) {
        AutoResizeTextView autoResizeTextView = this.tv_main;
        if (autoResizeTextView != null) {
            autoResizeTextView.setText(str);
        }
    }

    public void setTextLines() {
        AutoResizeTextView autoResizeTextView = this.tv_main;
        if (autoResizeTextView != null) {
            autoResizeTextView.setSingleLine(true);
        }
    }

    public void setColor(String str) {
        this.tv_main.setTextColor(Color.parseColor(str));
    }

    public String getText() {
        AutoResizeTextView autoResizeTextView = this.tv_main;
        return autoResizeTextView != null ? autoResizeTextView.getText().toString() : null;
    }

    public static float pixelsToSp(Context context, float f) {
        return f / context.getResources().getDisplayMetrics().scaledDensity;
    }

    public void onScaling(boolean z) {
        super.onScaling(z);
    }

    public void setControlItemsHidden(boolean z) {
        super.setControlItemsHidden(z);
    }

    public void reCenter(double d, double d2, double d3, double d4) {
        super.reCenter(d, d2, d3, d4);
    }

    public void setTypeface(Typeface typeface) {
        this.tv_main.setTypeface(typeface);
    }

    public void setTextSize(int i) {
        this.tv_main.setTextSize(0, (float) i);
    }
}
