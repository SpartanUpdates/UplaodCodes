package com.vidsoft.videostatusmaker.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vidsoft.videostatusmaker.App.MyApplication;
import com.vidsoft.videostatusmaker.myphotolyricalvideo.R;
import java.io.File;
import com.vidsoft.videostatusmaker.Others.gallery.ActivityImageFolder;

import static com.vidsoft.videostatusmaker.NativeAds.NativeAdMethod.populateUnifiedNativeAdViewBig;

public class MainActivity extends AppCompatActivity {
    public static int anInt;
    public static Activity activity;
    ImageView fullscreen;
    ImageView square1;

    private UnifiedNativeAd nativeAd;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        activity = this;
        getWindow().addFlags(1024);
        square1 = findViewById(R.id.square1);
        fullscreen = findViewById(R.id.fullscreen);
        anInt = 0;
        PutAnalyticsEvent();
        LoadNativeAds();
        btnClick();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void btnClick() {
        square1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.anInt = 0;
                MyApplication.Variable_VIDEO_HEIGHT = 720;
                MyApplication.Variable_VIDEO_WIDTH = 720;
                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
            }
        });
        fullscreen.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.anInt = 1;
                MyApplication.Variable_VIDEO_WIDTH = 1080;
                MyApplication.Variable_VIDEO_HEIGHT = 1920;
                startActivity(new Intent(MainActivity.this.getApplicationContext(), ActivityImageFolder.class));
            }
        });
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.native_ad));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.layout_ad_big, null);
                populateUnifiedNativeAdViewBig(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    protected void onResume() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Environment.getExternalStorageDirectory());
            stringBuilder.append("/");
            stringBuilder.append(getResources().getString(R.string.app_name));
            String stringBuilder2 = stringBuilder.toString();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append("/");
            stringBuilder3.append(getString(R.string.temp_folder));
            deleteRecursive(new File(stringBuilder3.toString()));
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(MainActivity.this, FirstActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    public static void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File deleteRecursive : file.listFiles()) {
                deleteRecursive(deleteRecursive);
            }
        }
        file.delete();
    }
}


