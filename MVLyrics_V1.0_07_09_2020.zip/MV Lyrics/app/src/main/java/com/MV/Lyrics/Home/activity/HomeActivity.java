package com.MV.Lyrics.Home.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.MV.Lyrics.App.MyApplication;
import com.MV.Lyrics.AppUtils.Utils;
import com.MV.Lyrics.ExitApplication.activity.ExitAppActivity;
import com.MV.Lyrics.Home.Model.CategoryModel;
import com.MV.Lyrics.Home.Model.ThemeHorizontalModel;
import com.MV.Lyrics.Home.fragment.ThemeFragmentByCategory;
import com.MV.Lyrics.LyricsSelect.LanguagePref;
import com.MV.Lyrics.MyStudio.activity.YourVideoActivity;
import com.MV.Lyrics.Partical.Model.ParticalModel;
import com.MV.Lyrics.R;
import com.MV.Lyrics.Retrofit.APIClient;
import com.MV.Lyrics.Retrofit.APIInterface;
import com.MV.Lyrics.Retrofit.AppConstant;
import com.MV.Lyrics.Setting.SettingActivity;
import com.MV.Lyrics.ThemeLanguage.activity.LanguageActivity;
import com.MV.Lyrics.UnityPlayerActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    Activity activity = HomeActivity.this;
    ArrayList<CategoryModel> tabcategorylist = new ArrayList<>();
    RelativeLayout rlLoading;
    LinearLayout llRetry;
    Button btnRetry;
    TextView tvtitle;
    Toolbar toolbar;
    ViewPagerAdapter adp;
    String[] split_selctedLan;
    SharedPreferences pref;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    APIInterface apiInterface;
    ImageView ivSetting;
    TextView tvLanguage;
    LinearLayout layoutLyrics, layoutSlideShow, layoutMyVideos;
    ImageView ivSong, ivMyStudio;
    TextView tvSong, tvMystudio;
    public boolean IsFromLanguage;

    boolean isSetupRedy = false;
    public boolean isApiRunning = false;
    public boolean isParticlesApiRunning = false;

    TextView tv_prg_msg;

    public MediaPlayer mediaPlayer;
    public int selectedSongPosition;
    public int SelectedTabPosition;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        selectedSongPosition = -1;
        SelectedTabPosition = 0;
        split_selctedLan = LanguagePref.a(activity).a("pref_key_language_list", "28").split(",");
        IsFromLanguage = getIntent().getBooleanExtra("IsFromLanguage", false);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        PutAnalyticsEvent();
        BindView();
        MyApplication.isEditCall = false;
        if (Utils.checkConnectivity(activity, false)) {
            if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                GetCategory();
            } else if (((new Date().getTime() - pref.getLong("offlineResponseTime", 1588598205L)) >= 300000L)) {
                if (!isApiRunning) {
                    isApiRunning = true;
                    GetCategory();
                }
            } else if (IsFromLanguage) {
                if (!isApiRunning) {
                    isApiRunning = true;
                    GetCategory();
                } else if (MyApplication.Tempcall != null) {
                    MyApplication.Tempcall.cancel();
                    isApiRunning = true;
                    GetCategory();
                }
            }
        } else if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            llRetry.setVisibility(View.VISIBLE);
        }
        SetListener();
        BannerAds();
        SetThemeData();
        Utils.INSTANCE.CopyAssets(activity);
    }


    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HomeActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void SetThemeData() {
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
            isSetupRedy = true;
        } else if (!IsFromLanguage) {
            Log.e("TAG", "OfflineRes" + pref.getString("offlineResponse", ""));
            SetupDataInLayout(pref.getString("offlineResponse", ""));
        } else {
            isSetupRedy = true;
        }
    }

    private void SetAssetTheme() {
        SetParticlesData(getFileFormAsset());
        /*if (Utils.checkConnectivity(activity, false)) {
            if (pref.getString("offlineParticles", "").equalsIgnoreCase("")) {
                SetParticlesData(getFileFormAsset());
                if (!isParticlesApiRunning) {
                    Partical();
                }

            } else if (((new Date().getTime() - pref.getLong("offlineParticlesTime", 1588598205L)) >= 300000L)) {
                SetParticlesData(pref.getString("offlineParticles", ""));
                if (!isParticlesApiRunning) {
                    Partical();
                }
            } else {
                SetParticlesData(pref.getString("offlineParticles", ""));
            }
        } else {
            if (pref.getString("offlineParticles", "").equalsIgnoreCase("")) {
                SetParticlesData(getFileFormAsset());
            } else {
                SetParticlesData(pref.getString("offlineParticles", ""));
            }
        }*/
    }

    public String getFileFormAsset() {
        try {
            InputStream open = getAssets().open("asset_bundle.json");
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void BindView() {
        toolbar = findViewById(R.id.toolbar);
        tvtitle = findViewById(R.id.tv_app_name);
        tvLanguage = findViewById(R.id.tv_language);
        ivSetting = findViewById(R.id.ivNavDrawer);
        rlLoading = findViewById(R.id.rl_loading);
        tabLayout = findViewById(R.id.mTabLayout);
        viewPager = findViewById(R.id.mViewPager);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);

        tv_prg_msg = findViewById(R.id.tv_prg_msg);
        tv_prg_msg.setText("Please wait…");

        ivSetting.setOnClickListener(this);
        tvLanguage.setOnClickListener(this);

        layoutLyrics = findViewById(R.id.llLyrics);
        layoutSlideShow = findViewById(R.id.llSlideshow);
        layoutMyVideos = findViewById(R.id.llMyVideos);
        ivSong = findViewById(R.id.ivSong);
        ivMyStudio = findViewById(R.id.ivMyStudio);
        tvSong = findViewById(R.id.tvSong);
        tvMystudio = findViewById(R.id.tvMyStudio);
        layoutLyrics.setOnClickListener(this);
        layoutSlideShow.setOnClickListener(this);
        layoutMyVideos.setOnClickListener(this);

        ivSong.setImageDrawable(getResources().getDrawable(R.drawable.ic_music_press));
        tvSong.setTextColor(getResources().getColor(R.color.app_gradiant_end));
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llRetry.setVisibility(View.GONE);
                    GetCategory();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetOfflineCategory(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineResponseTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    private void SetOfflineParticle(Context c, String userObject, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    private void SetOfflineParticleTime(Context c, final Date date, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putLong(key, date.getTime());
        editor.apply();
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    public void SetSong(ThemeHorizontalModel themModel, int position) {
        selectedSongPosition = position;
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(Utils.INSTANCE.getThemeFolderPath() + themModel.getZipDownloadCatName() + File.separator + themModel.getZipFolderName() + File.separator + "sound.mp3");
            mediaPlayer.prepare();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(final MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void SongPlayPause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
        }
    }

    public boolean isSongPlay() {
        if (mediaPlayer.isPlaying()) {
            return true;
        }
        mediaPlayer.isPlaying();
        return false;
    }

    public void onStart() {
        super.onStart();
        mediaPlayer = new MediaPlayer();
    }

    @Override
    public void onPause() {
        super.onPause();
        stopPlaying(mediaPlayer);
    }

    public void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(adp.getTabView(i));
        }

        ((TextView) tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.white));
        View underline = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getCustomView().findViewById(R.id.underLine);
        underline.setVisibility(View.VISIBLE);

        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.VISIBLE);
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.white));
//                SelectedTabPosition = tab.getPosition();
                selectedSongPosition = -1;
                MyApplication.ThemePosition = 0;
                MyApplication.CatSelectedPosition = tab.getPosition();
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.white));
                View underline = customView.findViewById(R.id.underLine);
                underline.setVisibility(View.GONE);
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.tv_cat_Name)).setTextColor(getResources().getColor(R.color.white));
                }
            }
        });
    }

    private void setUpPagerNew() {
        adp = new ViewPagerAdapter(getSupportFragmentManager());
        int i;
        viewPager.setAdapter(adp);
        if (MyApplication.CatSelectedPosition != -1) {
            i = MyApplication.CatSelectedPosition;
        } else {
            i = 0;
        }
        viewPager.setCurrentItem(i);
        tabLayout.setupWithViewPager(viewPager);
    }


    private void GetCategory() {
        final Handler handler = new Handler();
        if (pref.getString("offlineResponse", "").equalsIgnoreCase("") || IsFromLanguage) {
            Log.e("HomeActivity", "Handler Running");
            handler.postDelayed(new Runnable() {
                public void run() {
                    Log.e("HomeActivity", "Your Internet Connection Too Slow");
                    tv_prg_msg.setText("Slow Internet Connection");
                }
            }, 10000);
        }
        rlLoading.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.doGetUserList(AppConstant.Token, AppConstant.ApplicationId, "1", "1");
        MyApplication.Tempcall = call;
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        if (handler != null) {
                            Log.e("HomeActivity", "removeCallbacksAndMessages");
                            handler.removeCallbacksAndMessages(null);
                        }
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineCategory(activity, jsonObj.toString(), "offlineResponse");
                        //Set Response Time
                        SetOfflineResponseTime(activity, new Date(), "offlineResponseTime");
                        isApiRunning = false;
                        if (isSetupRedy) {
                            SetupDataInLayout(jsonObj.toString());
                        }
                    } catch (JSONException e) {
                        e.getMessage();
                    }


                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                isApiRunning = false;
                rlLoading.setVisibility(View.GONE);
                if (pref.getString("offlineResponse", "").equalsIgnoreCase("")) {
                    llRetry.setVisibility(View.VISIBLE);
                    Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetupDataInLayout(String response) {
        try {
            JSONObject jsonObj = new JSONObject(response);
            JSONArray tabcategory = jsonObj.getJSONArray("category");
            for (int i = 0; i < tabcategory.length(); i++) {
                JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                String CategoryId = tabcategoryJSONObject.getString("id");
                SetOfflineCategory(activity, tabcategoryJSONObject.toString(), CategoryId);
                CategoryModel categoryModel = new CategoryModel();

                categoryModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                categoryModel.setName(tabcategoryJSONObject.getString("name"));
                if (!Arrays.asList(AppConstant.split_AllLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                    tabcategorylist.add(categoryModel);
                } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(categoryModel.getCategoryId()))) {
                    tabcategorylist.add(categoryModel);
                }
            }
            setUpPagerNew();
            SetTabLayout();
            rlLoading.setVisibility(View.GONE);
            SetAssetTheme();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivNavDrawer:
                Setting();
                break;
            case R.id.tv_language:
                Language();
                break;
            case R.id.llLyrics:
                break;
            /*case R.id.llSlideshow:
                ivSlideShow.setImageDrawable(getResources().getDrawable(R.drawable.ic_slideshow_press));
                tvslideshow.setTextColor(getResources().getColor(R.color.app_gradiant_end));
                break;*/
            case R.id.llMyVideos:
                ivMyStudio.setImageDrawable(getResources().getDrawable(R.drawable.ic_my_studio_press));
                tvMystudio.setTextColor(getResources().getColor(R.color.app_gradiant_end));

                ivSong.setImageDrawable(getResources().getDrawable(R.drawable.ic_music));
                tvSong.setTextColor(getResources().getColor(R.color.white));
                MyVideo();
                break;
        }
    }

    private void Setting() {
        startActivity(new Intent(activity, SettingActivity.class));
        finish();
    }

    private void Language() {
        startActivity(new Intent(activity, LanguageActivity.class));
        finish();
    }

    private void MyVideo() {
        startActivity(new Intent(activity, YourVideoActivity.class));
        finish();
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return ThemeFragmentByCategory.newInstance(Integer.parseInt(tabcategorylist.get(position).getCategoryId()), position);
        }


        @Override
        public int getCount() {
            return tabcategorylist.size();
        }


        public View getTabView(int position) {
            View tabCatView = LayoutInflater.from(activity).inflate(R.layout.row_category_item, null);
            TextView tv = tabCatView.findViewById(R.id.tv_cat_Name);
            tv.setText(tabcategorylist.get(position).getName());
            return tabCatView;
        }
    }

    public void ShowBannerAds() {
        try {
            UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SetParticlesData(String result) {
        if (result != null) {
            Utils.INSTANCE.particalAssetModels.clear();
            UnityPlayerActivity.unityPlayeractivity.particalModels.clear();
            final String bundelpath = Utils.INSTANCE.getAssetUnityPath();
            try {
                JSONArray jsonArray = new JSONArray(result);
                for (int i = 0; i < jsonArray.length(); ++i) {
                    final JSONObject jsonObject = jsonArray.getJSONObject(i);
                    final ParticalModel particalModel = new ParticalModel();
                    particalModel.setThemeName(jsonObject.getString("theme_name"));
                    particalModel.setBundelName(jsonObject.getString("theme_bundle"));
                    particalModel.setGmaeObjName(jsonObject.getString("game_object_name"));
                    particalModel.setBundelSize(Integer.parseInt(jsonObject.getString("bundle_size")));
                    particalModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfAssetFolder).getAbsolutePath() + File.separator + particalModel.getBundelName());
                    if (jsonObject.getString("from_asset").equals("true")) {
                        particalModel.setFromAsset(true);
                        particalModel.setThemeBundel(jsonObject.getString("theme_bundle"));
                        particalModel.setThumbImage(jsonObject.getString("theme_thumbnail"));
                    } else {
                        particalModel.setFromAsset(false);
                        particalModel.setThemeBundel(jsonObject.getString("theme_bundle"));
                        particalModel.setThumbImage(jsonObject.getString("theme_thumbnail"));
                    }
                    particalModel.IsAssetSelected = false;
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(bundelpath);
                    sb2.append(particalModel.getBundelName());
                    particalModel.setThemeUnity3dPath(sb2.toString());
                    Utils.INSTANCE.particalAssetModels.add(particalModel);
                    UnityPlayerActivity.unityPlayeractivity.particalModels.add(particalModel);
                }
            } catch (JSONException ex2) {
                ex2.printStackTrace();
            }
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

   /* private void Partical() {
        isParticlesApiRunning = true;
        Call<JsonObject> call = apiInterface.Partical(AppConstant.Token, AppConstant.ApplicationId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        //Set Response In Offline
                        SetOfflineParticle(activity, jsonObj.toString(), "offlineParticles");
                        //Set Response Time
                        SetOfflineParticleTime(activity, new Date(), "offlineParticlesTime");
                        isParticlesApiRunning = false;
                        if (!MyApplication.isEditCall) {
                            SetParticlesData(jsonObj.toString());
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }*/

    /* *//*Using Api*//*
    public void SetParticlesData(String result) {
        if (result != null) {
            Utils.INSTANCE.particalAssetModels.clear();
            UnityPlayerActivity.unityPlayeractivity.particalModels.clear();
            final String bundelpath = Utils.INSTANCE.AssetBundleUntiy3dPath();
            try {
                JSONObject jsonObj = new JSONObject(result);
                String AssetUrl = jsonObj.getString("theme_bundle_url");
                String ParticalThumbUrl = jsonObj.getString("theme_thumb_url");
                JSONArray jsonArray = jsonObj.getJSONArray("category");
                for (int i = 0; i < jsonArray.length(); ++i) {
                    final JSONObject jsonObject = jsonArray.getJSONObject(i);
                    Log.e("TAG", "AllTheme" + jsonObject.length());
                    for (int j = 0; j < jsonArray.length(); ++j) {
                        final JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                        final ParticalModel particalModel = new ParticalModel();
                        particalModel.setThemeName(themeJSONObject.getString("theme_name"));
                        particalModel.setBundelName(themeJSONObject.getString("theme_bundle"));
                        particalModel.setGmaeObjName(themeJSONObject.getString("game_object_name"));
                        particalModel.setBundelSize(Integer.parseInt(themeJSONObject.getString("bundle_size")));
                        particalModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfAssetFolder).getAbsolutePath() + File.separator + particalModel.getBundelName());
                        if (themeJSONObject.getString("from_asset").equals("true")) {
                            particalModel.setFromAsset(true);
                            particalModel.setThemeBundel(AssetUrl + themeJSONObject.getString("theme_bundle"));
                            particalModel.setThumbImage(ParticalThumbUrl + themeJSONObject.getString("theme_thumbnail"));
                        } else {
                            particalModel.setFromAsset(false);
                            particalModel.setThemeBundel(AssetUrl + themeJSONObject.getString("theme_bundle"));
                            particalModel.setThumbImage(ParticalThumbUrl + themeJSONObject.getString("theme_thumbnail"));
                        }
                        particalModel.IsAssetSelected = false;
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(bundelpath);
                        sb2.append(particalModel.getBundelName());
                        particalModel.setThemeUnity3dPath(sb2.toString());
                        Utils.INSTANCE.particalAssetModels.add(particalModel);
                        UnityPlayerActivity.unityPlayeractivity.particalModels.add(particalModel);
                    }
                }
            } catch (JSONException ex2) {
                ex2.printStackTrace();
            }
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                }
            });
        }
    }*/

    @Override
    public void onBackPressed() {
        if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
            MyApplication.AdsId = 2;
            MyApplication.AdsShowContext = activity;
            MyApplication.mInterstitialAd.show();
        } else {
            GoToExit();
        }
    }

    private void GoToExit() {
        startActivity(new Intent(activity, ExitAppActivity.class));
        finish();
    }
}