package com.vidsoft.Filters.scrollgalleryview;

import android.content.*;
import android.annotation.*;
import android.graphics.drawable.*;
import android.util.*;
import android.content.res.*;
import android.os.*;
import android.graphics.*;
import android.net.*;
import android.widget.*;
import android.view.animation.*;
import android.view.*;

public class TouchImageView extends ImageView
{
    private static final String DEBUG = "DEBUG";
    private static final float SUPER_MAX_MULTIPLIER = 1.25f;
    private static final float SUPER_MIN_MULTIPLIER = 1.0f;
    private Context context;
    private ZoomVariables delayedZoomVariables;
    private GestureDetector.OnDoubleTapListener doubleTapListener;
    private Fling fling;
    private boolean imageRenderedAtLeastOnce;
    private float[] m;
    private GestureDetector mGestureDetector;
    private ScaleGestureDetector mScaleDetector;
    private ScaleType mScaleType;
    private float matchViewHeight;
    private float matchViewWidth;
    private Matrix matrix;
    private float maxScale;
    private float minScale;
    private float normalizedScale;
    private boolean onDrawReady;
    private float prevMatchViewHeight;
    private float prevMatchViewWidth;
    private Matrix prevMatrix;
    private int prevViewHeight;
    private int prevViewWidth;
    private State state;
    private float superMaxScale;
    private float superMinScale;
    private OnTouchImageViewListener touchImageViewListener;
    private OnTouchListener userTouchListener;
    private int viewHeight;
    private int viewWidth;

    public TouchImageView(final Context context) {
        super(context);
        this.doubleTapListener = null;
        this.userTouchListener = null;
        this.touchImageViewListener = null;
        this.sharedConstructing(context);
    }

    public TouchImageView(final Context context, final AttributeSet set) {
        super(context, set);
        this.doubleTapListener = null;
        this.userTouchListener = null;
        this.touchImageViewListener = null;
        this.sharedConstructing(context);
    }

    public TouchImageView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.doubleTapListener = null;
        this.userTouchListener = null;
        this.touchImageViewListener = null;
        this.sharedConstructing(context);
    }

    @TargetApi(16)
    private void compatPostOnAnimation(final Runnable runnable) {
        if (Build.VERSION.SDK_INT >= 16) {
            this.postOnAnimation(runnable);
            return;
        }
        this.postDelayed(runnable, 16L);
    }

    private void fitImageToView() {
        final Drawable drawable = this.getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() == 0 || drawable.getIntrinsicHeight() == 0 || this.matrix == null || this.prevMatrix == null) {
            return;
        }
        final int intrinsicWidth = drawable.getIntrinsicWidth();
        final int intrinsicHeight = drawable.getIntrinsicHeight();
        final float n = this.viewWidth / intrinsicWidth;
        final float n2 = this.viewHeight / intrinsicHeight;
        float n3 = n;
        float n4 = n2;
        float min = n;
        float n5 = n2;
        Label_0151: {
            switch (this.mScaleType) {
                default: {
                    throw new UnsupportedOperationException("TouchImageView does not support FIT_START or FIT_END");
                }
                case CENTER: {
                    n4 = 1.0f;
                    n3 = 1.0f;
                    break Label_0151;
                }
                case CENTER_INSIDE: {
                    n5 = (min = Math.min(1.0f, Math.min(n, n2)));
                }
                case FIT_CENTER: {
                    n4 = (n3 = Math.min(min, n5));
                    break Label_0151;
                }
                case CENTER_CROP: {
                    n4 = (n3 = Math.max(n, n2));
                }
                case FIT_XY: {
                    final float n6 = this.viewWidth - intrinsicWidth * n3;
                    final float n7 = this.viewHeight - intrinsicHeight * n4;
                    this.matchViewWidth = this.viewWidth - n6;
                    this.matchViewHeight = this.viewHeight - n7;
                    if (!this.isZoomed() && !this.imageRenderedAtLeastOnce) {
                        this.matrix.setScale(n3, n4);
                        this.matrix.postTranslate(n6 / 2.0f, n7 / 2.0f);
                        this.normalizedScale = 1.0f;
                    }
                    else {
                        if (this.prevMatchViewWidth == 0.0f || this.prevMatchViewHeight == 0.0f) {
                            this.savePreviousImageValues();
                        }
                        this.prevMatrix.getValues(this.m);
                        this.m[0] = this.matchViewWidth / intrinsicWidth * this.normalizedScale;
                        this.m[4] = this.matchViewHeight / intrinsicHeight * this.normalizedScale;
                        final float n8 = this.m[2];
                        final float n9 = this.m[5];
                        this.translateMatrixAfterRotate(2, n8, this.prevMatchViewWidth * this.normalizedScale, this.getImageWidth(), this.prevViewWidth, this.viewWidth, intrinsicWidth);
                        this.translateMatrixAfterRotate(5, n9, this.prevMatchViewHeight * this.normalizedScale, this.getImageHeight(), this.prevViewHeight, this.viewHeight, intrinsicHeight);
                        this.matrix.setValues(this.m);
                    }
                    this.fixTrans();
                    this.setImageMatrix(this.matrix);
                }
            }
        }
    }

    private void fixScaleTrans() {
        this.fixTrans();
        this.matrix.getValues(this.m);
        if (this.getImageWidth() < this.viewWidth) {
            this.m[2] = (this.viewWidth - this.getImageWidth()) / 2.0f;
        }
        if (this.getImageHeight() < this.viewHeight) {
            this.m[5] = (this.viewHeight - this.getImageHeight()) / 2.0f;
        }
        this.matrix.setValues(this.m);
    }

    private void fixTrans() {
        this.matrix.getValues(this.m);
        final float n = this.m[2];
        final float n2 = this.m[5];
        final float fixTrans = this.getFixTrans(n, this.viewWidth, this.getImageWidth());
        final float fixTrans2 = this.getFixTrans(n2, this.viewHeight, this.getImageHeight());
        if (fixTrans != 0.0f || fixTrans2 != 0.0f) {
            this.matrix.postTranslate(fixTrans, fixTrans2);
        }
    }

    private float getFixDragTrans(float n, final float n2, final float n3) {
        if (n3 <= n2) {
            n = 0.0f;
        }
        return n;
    }

    private float getFixTrans(final float n, float n2, float n3) {
        if (n3 <= n2) {
            final float n4 = 0.0f;
            n2 -= n3;
            n3 = n4;
        }
        else {
            n3 = n2 - n3;
            n2 = 0.0f;
        }
        if (n < n3) {
            return -n + n3;
        }
        if (n > n2) {
            return -n + n2;
        }
        return 0.0f;
    }

    private float getImageHeight() {
        return this.matchViewHeight * this.normalizedScale;
    }

    private float getImageWidth() {
        return this.matchViewWidth * this.normalizedScale;
    }

    private void printMatrixInfo() {
        final float[] array = new float[9];
        this.matrix.getValues(array);
        Log.d("DEBUG", "Scale: " + array[0] + " TransX: " + array[2] + " TransY: " + array[5]);
    }

    private void savePreviousImageValues() {
        if (this.matrix != null && this.viewHeight != 0 && this.viewWidth != 0) {
            this.matrix.getValues(this.m);
            this.prevMatrix.setValues(this.m);
            this.prevMatchViewHeight = this.matchViewHeight;
            this.prevMatchViewWidth = this.matchViewWidth;
            this.prevViewHeight = this.viewHeight;
            this.prevViewWidth = this.viewWidth;
        }
    }

    private void scaleImage(double n, final float n2, final float n3, final boolean b) {
        float normalizedScale;
        float normalizedScale2;
        if (b) {
            normalizedScale = this.superMinScale;
            normalizedScale2 = this.superMaxScale;
        }
        else {
            normalizedScale = this.minScale;
            normalizedScale2 = this.maxScale;
        }
        final float normalizedScale3 = this.normalizedScale;
        this.normalizedScale *= (float)n;
        if (this.normalizedScale > normalizedScale2) {
            this.normalizedScale = normalizedScale2;
            n = normalizedScale2 / normalizedScale3;
        }
        else if (this.normalizedScale < normalizedScale) {
            this.normalizedScale = normalizedScale;
            n = normalizedScale / normalizedScale3;
        }
        this.matrix.postScale((float)n, (float)n, n2, n3);
        this.fixScaleTrans();
    }

    private void setState(final State state) {
        this.state = state;
    }

    private int setViewSize(final int n, final int n2, final int n3) {
        switch (n) {
            default: {
                return n2;
            }
            case 1073741824: {
                return n2;
            }
            case Integer.MIN_VALUE: {
                return Math.min(n3, n2);
            }
            case 0: {
                return n3;
            }
        }
    }

    private void sharedConstructing(final Context context) {
        super.setClickable(true);
        this.context = context;
        this.mScaleDetector = new ScaleGestureDetector(context, (ScaleGestureDetector.OnScaleGestureListener)new ScaleListener());
        this.mGestureDetector = new GestureDetector(context, (GestureDetector.OnGestureListener)new GestureListener());
        this.matrix = new Matrix();
        this.prevMatrix = new Matrix();
        this.m = new float[9];
        this.normalizedScale = 1.0f;
        if (this.mScaleType == null) {
            this.mScaleType = ScaleType.FIT_CENTER;
        }
        this.minScale = 1.0f;
        this.maxScale = 3.0f;
        this.superMinScale = this.minScale * 1.0f;
        this.superMaxScale = 1.25f * this.maxScale;
        this.setImageMatrix(this.matrix);
        this.setScaleType(ScaleType.MATRIX);
        this.setState(State.NONE);
        this.onDrawReady = false;
        super.setOnTouchListener((OnTouchListener)new PrivateOnTouchListener());
    }

    private PointF transformCoordBitmapToTouch(float n, float n2) {
        this.matrix.getValues(this.m);
        final float n3 = this.getDrawable().getIntrinsicWidth();
        final float n4 = this.getDrawable().getIntrinsicHeight();
        n /= n3;
        n2 /= n4;
        return new PointF(this.m[2] + this.getImageWidth() * n, this.m[5] + this.getImageHeight() * n2);
    }

    private PointF transformCoordTouchToBitmap(float min, float min2, final boolean b) {
        this.matrix.getValues(this.m);
        final float n = this.getDrawable().getIntrinsicWidth();
        final float n2 = this.getDrawable().getIntrinsicHeight();
        final float n3 = this.m[2];
        final float n4 = this.m[5];
        final float n5 = (min - n3) * n / this.getImageWidth();
        final float n6 = (min2 - n4) * n2 / this.getImageHeight();
        min2 = n5;
        min = n6;
        if (b) {
            min2 = Math.min(Math.max(n5, 0.0f), n);
            min = Math.min(Math.max(n6, 0.0f), n2);
        }
        return new PointF(min2, min);
    }

    private void translateMatrixAfterRotate(final int n, float n2, final float n3, final float n4, final int n5, final int n6, final int n7) {
        if (n4 < n6) {
            this.m[n] = (n6 - n7 * this.m[0]) * 0.5f;
            return;
        }
        if (n2 > 0.0f) {
            this.m[n] = -((n4 - n6) * 0.5f);
            return;
        }
        n2 = (Math.abs(n2) + n5 * 0.5f) / n3;
        this.m[n] = -(n2 * n4 - n6 * 0.5f);
    }

    public boolean canScrollHorizontally(final int n) {
        this.matrix.getValues(this.m);
        final float n2 = this.m[2];
        return this.getImageWidth() >= this.viewWidth && (n2 < -1.0f || n >= 0) && (Math.abs(n2) + this.viewWidth + 1.0f < this.getImageWidth() || n <= 0);
    }

    public boolean canScrollHorizontallyFroyo(final int n) {
        return this.canScrollHorizontally(n);
    }

    public float getCurrentZoom() {
        return this.normalizedScale;
    }

    public float getMaxZoom() {
        return this.maxScale;
    }

    public float getMinZoom() {
        return this.minScale;
    }

    public ScaleType getScaleType() {
        return this.mScaleType;
    }

    public PointF getScrollPosition() {
        final Drawable drawable = this.getDrawable();
        if (drawable == null) {
            return null;
        }
        final int intrinsicWidth = drawable.getIntrinsicWidth();
        final int intrinsicHeight = drawable.getIntrinsicHeight();
        final PointF transformCoordTouchToBitmap = this.transformCoordTouchToBitmap(this.viewWidth / 2, this.viewHeight / 2, true);
        transformCoordTouchToBitmap.x /= intrinsicWidth;
        transformCoordTouchToBitmap.y /= intrinsicHeight;
        return transformCoordTouchToBitmap;
    }

    public RectF getZoomedRect() {
        if (this.mScaleType == ScaleType.FIT_XY) {
            throw new UnsupportedOperationException("getZoomedRect() not supported with FIT_XY");
        }
        final PointF transformCoordTouchToBitmap = this.transformCoordTouchToBitmap(0.0f, 0.0f, true);
        final PointF transformCoordTouchToBitmap2 = this.transformCoordTouchToBitmap(this.viewWidth, this.viewHeight, true);
        final float n = this.getDrawable().getIntrinsicWidth();
        final float n2 = this.getDrawable().getIntrinsicHeight();
        return new RectF(transformCoordTouchToBitmap.x / n, transformCoordTouchToBitmap.y / n2, transformCoordTouchToBitmap2.x / n, transformCoordTouchToBitmap2.y / n2);
    }

    public boolean isZoomed() {
        return this.normalizedScale != 1.0f;
    }

    public void onConfigurationChanged(final Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.savePreviousImageValues();
    }

    protected void onDraw(final Canvas canvas) {
        this.onDrawReady = true;
        this.imageRenderedAtLeastOnce = true;
        if (this.delayedZoomVariables != null) {
            this.setZoom(this.delayedZoomVariables.scale, this.delayedZoomVariables.focusX, this.delayedZoomVariables.focusY, this.delayedZoomVariables.scaleType);
            this.delayedZoomVariables = null;
        }
        super.onDraw(canvas);
    }

    protected void onMeasure(int mode, int mode2) {
        final Drawable drawable = this.getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() == 0 || drawable.getIntrinsicHeight() == 0) {
            this.setMeasuredDimension(0, 0);
            return;
        }
        final int intrinsicWidth = drawable.getIntrinsicWidth();
        final int intrinsicHeight = drawable.getIntrinsicHeight();
        final int size = MeasureSpec.getSize(mode);
        mode = MeasureSpec.getMode(mode);
        final int size2 = MeasureSpec.getSize(mode2);
        mode2 = MeasureSpec.getMode(mode2);
        this.viewWidth = this.setViewSize(mode, size, intrinsicWidth);
        this.viewHeight = this.setViewSize(mode2, size2, intrinsicHeight);
        this.setMeasuredDimension(this.viewWidth, this.viewHeight);
        this.fitImageToView();
    }

    public void onRestoreInstanceState(final Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            final Bundle bundle = (Bundle)parcelable;
            this.normalizedScale = bundle.getFloat("saveScale");
            this.m = bundle.getFloatArray("matrix");
            this.prevMatrix.setValues(this.m);
            this.prevMatchViewHeight = bundle.getFloat("matchViewHeight");
            this.prevMatchViewWidth = bundle.getFloat("matchViewWidth");
            this.prevViewHeight = bundle.getInt("viewHeight");
            this.prevViewWidth = bundle.getInt("viewWidth");
            this.imageRenderedAtLeastOnce = bundle.getBoolean("imageRendered");
            super.onRestoreInstanceState(bundle.getParcelable("instanceState"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        final Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        bundle.putFloat("saveScale", this.normalizedScale);
        bundle.putFloat("matchViewHeight", this.matchViewHeight);
        bundle.putFloat("matchViewWidth", this.matchViewWidth);
        bundle.putInt("viewWidth", this.viewWidth);
        bundle.putInt("viewHeight", this.viewHeight);
        this.matrix.getValues(this.m);
        bundle.putFloatArray("matrix", this.m);
        bundle.putBoolean("imageRendered", this.imageRenderedAtLeastOnce);
        return (Parcelable)bundle;
    }

    public void resetZoom() {
        this.normalizedScale = 1.0f;
        this.fitImageToView();
    }

    public void setImageBitmap(final Bitmap imageBitmap) {
        super.setImageBitmap(imageBitmap);
        this.savePreviousImageValues();
        this.fitImageToView();
    }

    public void setImageDrawable(final Drawable imageDrawable) {
        super.setImageDrawable(imageDrawable);
        this.savePreviousImageValues();
        this.fitImageToView();
    }

    public void setImageResource(final int imageResource) {
        super.setImageResource(imageResource);
        this.savePreviousImageValues();
        this.fitImageToView();
    }

    public void setImageURI(final Uri imageURI) {
        super.setImageURI(imageURI);
        this.savePreviousImageValues();
        this.fitImageToView();
    }

    public void setMaxZoom(final float maxScale) {
        this.maxScale = maxScale;
        this.superMaxScale = 1.25f * this.maxScale;
    }

    public void setMinZoom(final float minScale) {
        this.minScale = minScale;
        this.superMinScale = 1.0f * this.minScale;
    }

    public void setOnDoubleTapListener(final GestureDetector.OnDoubleTapListener doubleTapListener) {
        this.doubleTapListener = doubleTapListener;
    }

    public void setOnTouchImageViewListener(final OnTouchImageViewListener touchImageViewListener) {
        this.touchImageViewListener = touchImageViewListener;
    }

    public void setOnTouchListener(final OnTouchListener userTouchListener) {
        this.userTouchListener = userTouchListener;
    }

    public void setScaleType(final ScaleType mScaleType) {
        if (mScaleType == ScaleType.FIT_START || mScaleType == ScaleType.FIT_END) {
            throw new UnsupportedOperationException("TouchImageView does not support FIT_START or FIT_END");
        }
        if (mScaleType == ScaleType.MATRIX) {
            super.setScaleType(ScaleType.MATRIX);
        }
        else {
            this.mScaleType = mScaleType;
            if (this.onDrawReady) {
                this.setZoom(this);
            }
        }
    }

    public void setScrollPosition(final float n, final float n2) {
        this.setZoom(this.normalizedScale, n, n2);
    }

    public void setZoom(final float n) {
        this.setZoom(n, 0.5f, 0.5f);
    }

    public void setZoom(final float n, final float n2, final float n3) {
        this.setZoom(n, n2, n3, this.mScaleType);
    }

    public void setZoom(final float n, final float n2, final float n3, final ScaleType scaleType) {
        if (!this.onDrawReady) {
            this.delayedZoomVariables = new ZoomVariables(n, n2, n3, scaleType);
            return;
        }
        if (scaleType != this.mScaleType) {
            this.setScaleType(scaleType);
        }
        this.resetZoom();
        this.scaleImage(n, this.viewWidth / 2, this.viewHeight / 2, true);
        this.matrix.getValues(this.m);
        this.m[2] = -(this.getImageWidth() * n2 - this.viewWidth * 0.5f);
        this.m[5] = -(this.getImageHeight() * n3 - this.viewHeight * 0.5f);
        this.matrix.setValues(this.m);
        this.fixTrans();
        this.setImageMatrix(this.matrix);
    }

    public void setZoom(final TouchImageView touchImageView) {
        final PointF scrollPosition = touchImageView.getScrollPosition();
        this.setZoom(touchImageView.getCurrentZoom(), scrollPosition.x, scrollPosition.y, touchImageView.getScaleType());
    }

    @TargetApi(9)
    private class CompatScroller
    {
        boolean isPreGingerbread;
        OverScroller overScroller;
        Scroller scroller;

        public CompatScroller(final Context context) {
            if (Build.VERSION.SDK_INT < 9) {
                this.isPreGingerbread = true;
                this.scroller = new Scroller(context);
                return;
            }
            this.isPreGingerbread = false;
            this.overScroller = new OverScroller(context);
        }

        public boolean computeScrollOffset() {
            if (this.isPreGingerbread) {
                return this.scroller.computeScrollOffset();
            }
            this.overScroller.computeScrollOffset();
            return this.overScroller.computeScrollOffset();
        }

        public void fling(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final int n8) {
            if (this.isPreGingerbread) {
                this.scroller.fling(n, n2, n3, n4, n5, n6, n7, n8);
                return;
            }
            this.overScroller.fling(n, n2, n3, n4, n5, n6, n7, n8);
        }

        public void forceFinished(final boolean b) {
            if (this.isPreGingerbread) {
                this.scroller.forceFinished(b);
                return;
            }
            this.overScroller.forceFinished(b);
        }

        public int getCurrX() {
            if (this.isPreGingerbread) {
                return this.scroller.getCurrX();
            }
            return this.overScroller.getCurrX();
        }

        public int getCurrY() {
            if (this.isPreGingerbread) {
                return this.scroller.getCurrY();
            }
            return this.overScroller.getCurrY();
        }

        public boolean isFinished() {
            if (this.isPreGingerbread) {
                return this.scroller.isFinished();
            }
            return this.overScroller.isFinished();
        }
    }

    private class DoubleTapZoom implements Runnable
    {
        private static final float ZOOM_TIME = 500.0f;
        private float bitmapX;
        private float bitmapY;
        private PointF endTouch;
        private AccelerateDecelerateInterpolator interpolator;
        private long startTime;
        private PointF startTouch;
        private float startZoom;
        private boolean stretchImageToSuper;
        private float targetZoom;

        DoubleTapZoom(final float targetZoom, final float n, final float n2, final boolean stretchImageToSuper) {
            this.interpolator = new AccelerateDecelerateInterpolator();
            TouchImageView.this.setState(State.ANIMATE_ZOOM);
            this.startTime = System.currentTimeMillis();
            this.startZoom = TouchImageView.this.normalizedScale;
            this.targetZoom = targetZoom;
            this.stretchImageToSuper = stretchImageToSuper;
            final PointF access$2300 = TouchImageView.this.transformCoordTouchToBitmap(n, n2, false);
            this.bitmapX = access$2300.x;
            this.bitmapY = access$2300.y;
            this.startTouch = TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, this.bitmapY);
            this.endTouch = new PointF((float)(TouchImageView.this.viewWidth / 2), (float)(TouchImageView.this.viewHeight / 2));
        }

        private double calculateDeltaScale(final float n) {
            return (this.startZoom + (this.targetZoom - this.startZoom) * n) / TouchImageView.this.normalizedScale;
        }

        private float interpolate() {
            return this.interpolator.getInterpolation(Math.min(1.0f, (System.currentTimeMillis() - this.startTime) / 500.0f));
        }

        private void translateImageToCenterTouchPosition(final float n) {
            final float x = this.startTouch.x;
            final float x2 = this.endTouch.x;
            final float x3 = this.startTouch.x;
            final float y = this.startTouch.y;
            final float y2 = this.endTouch.y;
            final float y3 = this.startTouch.y;
            final PointF access$2400 = TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, this.bitmapY);
            TouchImageView.this.matrix.postTranslate(x + (x2 - x3) * n - access$2400.x, y + (y2 - y3) * n - access$2400.y);
        }

        @Override
        public void run() {
            final float interpolate = this.interpolate();
            TouchImageView.this.scaleImage(this.calculateDeltaScale(interpolate), this.bitmapX, this.bitmapY, this.stretchImageToSuper);
            this.translateImageToCenterTouchPosition(interpolate);
            TouchImageView.this.fixScaleTrans();
            TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
            if (TouchImageView.this.touchImageViewListener != null) {
                TouchImageView.this.touchImageViewListener.onMove();
            }
            if (interpolate < 1.0f) {
                TouchImageView.this.compatPostOnAnimation(this);
                return;
            }
            TouchImageView.this.setState(State.NONE);
        }
    }

    private class Fling implements Runnable
    {
        int currX;
        int currY;
        CompatScroller scroller;

        Fling(final int n, final int n2) {
            TouchImageView.this.setState(State.FLING);
            this.scroller = new CompatScroller(TouchImageView.this.context);
            TouchImageView.this.matrix.getValues(TouchImageView.this.m);
            final int currX = (int)TouchImageView.this.m[2];
            final int currY = (int)TouchImageView.this.m[5];
            int n3;
            int n4;
            if (TouchImageView.this.getImageWidth() > TouchImageView.this.viewWidth) {
                n3 = TouchImageView.this.viewWidth - (int)TouchImageView.this.getImageWidth();
                n4 = 0;
            }
            else {
                n4 = currX;
                n3 = currX;
            }
            int n5;
            int n6;
            if (TouchImageView.this.getImageHeight() > TouchImageView.this.viewHeight) {
                n5 = TouchImageView.this.viewHeight - (int)TouchImageView.this.getImageHeight();
                n6 = 0;
            }
            else {
                n6 = currY;
                n5 = currY;
            }
            this.scroller.fling(currX, currY, n, n2, n3, n4, n5, n6);
            this.currX = currX;
            this.currY = currY;
        }

        public void cancelFling() {
            if (this.scroller != null) {
                TouchImageView.this.setState(State.NONE);
                this.scroller.forceFinished(true);
            }
        }

        @Override
        public void run() {
            if (TouchImageView.this.touchImageViewListener != null) {
                TouchImageView.this.touchImageViewListener.onMove();
            }
            if (this.scroller.isFinished()) {
                this.scroller = null;
            }
            else if (this.scroller.computeScrollOffset()) {
                final int currX = this.scroller.getCurrX();
                final int currY = this.scroller.getCurrY();
                final int currX2 = this.currX;
                final int currY2 = this.currY;
                this.currX = currX;
                this.currY = currY;
                TouchImageView.this.matrix.postTranslate((float)(currX - currX2), (float)(currY - currY2));
                TouchImageView.this.fixTrans();
                TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
                TouchImageView.this.compatPostOnAnimation(this);
            }
        }
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onDoubleTap(final MotionEvent motionEvent) {
            boolean onDoubleTap = false;
            if (TouchImageView.this.doubleTapListener != null) {
                onDoubleTap = TouchImageView.this.doubleTapListener.onDoubleTap(motionEvent);
            }
            if (TouchImageView.this.state == State.NONE) {
                float n;
                if (TouchImageView.this.normalizedScale == TouchImageView.this.minScale) {
                    n = TouchImageView.this.maxScale;
                }
                else {
                    n = TouchImageView.this.minScale;
                }
                TouchImageView.this.compatPostOnAnimation(new DoubleTapZoom(n, motionEvent.getX(), motionEvent.getY(), false));
                onDoubleTap = true;
            }
            return onDoubleTap;
        }

        public boolean onDoubleTapEvent(final MotionEvent motionEvent) {
            return TouchImageView.this.doubleTapListener != null && TouchImageView.this.doubleTapListener.onDoubleTapEvent(motionEvent);
        }

        public boolean onFling(final MotionEvent motionEvent, final MotionEvent motionEvent2, final float n, final float n2) {
            if (TouchImageView.this.fling != null) {
                TouchImageView.this.fling.cancelFling();
            }
            TouchImageView.this.fling = new Fling((int)n, (int)n2);
            TouchImageView.this.compatPostOnAnimation(TouchImageView.this.fling);
            return super.onFling(motionEvent, motionEvent2, n, n2);
        }

        public void onLongPress(final MotionEvent motionEvent) {
            TouchImageView.this.performLongClick();
        }

        public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
            if (TouchImageView.this.doubleTapListener != null) {
                return TouchImageView.this.doubleTapListener.onSingleTapConfirmed(motionEvent);
            }
            return TouchImageView.this.performClick();
        }
    }

    public interface OnTouchImageViewListener
    {
        void onMove();
    }

    private class PrivateOnTouchListener implements OnTouchListener
    {
        private PointF last;

        private PrivateOnTouchListener() {
            this.last = new PointF();
        }

        public boolean onTouch(final View view, final MotionEvent motionEvent) {
            TouchImageView.this.mScaleDetector.onTouchEvent(motionEvent);
            TouchImageView.this.mGestureDetector.onTouchEvent(motionEvent);
            final PointF pointF = new PointF(motionEvent.getX(), motionEvent.getY());
            if (TouchImageView.this.state == State.NONE || TouchImageView.this.state == State.DRAG || TouchImageView.this.state == State.FLING) {
                switch (motionEvent.getAction()) {
                    case 0: {
                        this.last.set(pointF);
                        if (TouchImageView.this.fling != null) {
                            TouchImageView.this.fling.cancelFling();
                        }
                        TouchImageView.this.setState(State.DRAG);
                        break;
                    }
                    case 2: {
                        if (TouchImageView.this.state == State.DRAG) {
                            TouchImageView.this.matrix.postTranslate(TouchImageView.this.getFixDragTrans(pointF.x - this.last.x, TouchImageView.this.viewWidth, TouchImageView.this.getImageWidth()), TouchImageView.this.getFixDragTrans(pointF.y - this.last.y, TouchImageView.this.viewHeight, TouchImageView.this.getImageHeight()));
                            TouchImageView.this.fixTrans();
                            this.last.set(pointF.x, pointF.y);
                            break;
                        }
                        break;
                    }
                    case 1:
                    case 6: {
                        TouchImageView.this.setState(State.NONE);
                        break;
                    }
                }
            }
            TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
            if (TouchImageView.this.userTouchListener != null) {
                TouchImageView.this.userTouchListener.onTouch(view, motionEvent);
            }
            if (TouchImageView.this.touchImageViewListener != null) {
                TouchImageView.this.touchImageViewListener.onMove();
            }
            return true;
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener
    {
        public boolean onScale(final ScaleGestureDetector scaleGestureDetector) {
            TouchImageView.this.scaleImage(scaleGestureDetector.getScaleFactor(), scaleGestureDetector.getFocusX(), scaleGestureDetector.getFocusY(), true);
            if (TouchImageView.this.touchImageViewListener != null) {
                TouchImageView.this.touchImageViewListener.onMove();
            }
            return true;
        }

        public boolean onScaleBegin(final ScaleGestureDetector scaleGestureDetector) {
            TouchImageView.this.setState(State.ZOOM);
            return true;
        }

        public void onScaleEnd(final ScaleGestureDetector scaleGestureDetector) {
            super.onScaleEnd(scaleGestureDetector);
            TouchImageView.this.setState(State.NONE);
            int n = 0;
            float n2 = TouchImageView.this.normalizedScale;
            if (TouchImageView.this.normalizedScale > TouchImageView.this.maxScale) {
                n2 = TouchImageView.this.maxScale;
                n = 1;
            }
            else if (TouchImageView.this.normalizedScale < TouchImageView.this.minScale) {
                n2 = TouchImageView.this.minScale;
                n = 1;
            }
            if (n != 0) {
                TouchImageView.this.compatPostOnAnimation(new DoubleTapZoom(n2, TouchImageView.this.viewWidth / 2, TouchImageView.this.viewHeight / 2, true));
            }
        }
    }

    private enum State
    {
        ANIMATE_ZOOM,
        DRAG,
        FLING,
        NONE,
        ZOOM;
    }

    private class ZoomVariables
    {
        public float focusX;
        public float focusY;
        public float scale;
        public ScaleType scaleType;

        public ZoomVariables(final float scale, final float focusX, final float focusY, final ScaleType scaleType) {
            this.scale = scale;
            this.focusX = focusX;
            this.focusY = focusY;
            this.scaleType = scaleType;
        }
    }
}
