package com.rtovehicleinformation.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.rtovehicleinformation.Model.OwnerRootPaidModel;
import com.rtovehicleinformation.Model.VehicleDetails;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.Retrofit.APIClient;
import com.rtovehicleinformation.Retrofit.APIInterface;
import com.rtovehicleinformation.Room.HistoryDatabase;
import com.rtovehicleinformation.Room.OwnerHistoryPaidModel;
import com.rtovehicleinformation.application.AppController;
import com.rtovehicleinformation.kprogresshud.KProgressHUD;
import com.rtovehicleinformation.utils.HeaderFooterPageEvent;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.room.Room;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VehicleDetailActivity extends AppCompatActivity {
    Activity activity = VehicleDetailActivity.this;
    APIInterface apiInterface;
    private String sOwnerName, sRegNumber, sVehicleClass, sRegistrationDate, sInsuranceUpto, sEngineNumber, sFuelType, sCity, sState;
    TextView registrationNo, registrationDate, engineNo, ownerName, vehicleClass, fuelType, insuranceUpto, city, state;
    ImageView vehicleImage;
    Button btn_getData;
    Button btn_print;
    ScrollView scrollView;
    EditText input1, input2, input3, input4;
    String result;
    String resultTwo;
    ProgressDialog pd;
    ArrayList<VehicleDetails> VehicleDatalist;
    ImageView iv_back;
    ImageView iv_reset;
    String first;
    String second;
    String Third;
    String Fourth;
    private long totalRequest = 0;
    private DatabaseReference databaseReference, databaseReference2;
    HistoryDatabase historyDatabase;
    List<OwnerHistoryPaidModel> ownerHistoryPaidModelList = new ArrayList<>();
    private String key;
    private Boolean userExists = true;
    private CardView dataLayout;
    int size;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_detail);
        first = getIntent().getStringExtra("first");
        second = getIntent().getStringExtra("second");
        Third = getIntent().getStringExtra("third");
        Fourth = getIntent().getStringExtra("fourth");

        BindView();
        SetClickListener();
        loadAd();

        apiInterface = APIClient.getClient().create(APIInterface.class);
        key = AppController.key;
        if (key == null || key.equals("")) {
            Toast.makeText(activity, "Please check your internet connection and restart the application !", Toast.LENGTH_LONG).show();
            btn_getData.setEnabled(false);
        }

        databaseReference2 = FirebaseDatabase.getInstance().getReference("totalRequest");
        databaseReference = FirebaseDatabase.getInstance().getReference("dailyRequest");
        loadData();
        historyDatabase = Room.databaseBuilder(VehicleDetailActivity.this, HistoryDatabase.class, "VehicleDetailsHistory").allowMainThreadQueries().build();


        if (first != null && second != null && Third != null && Fourth != null) {
            input1.setText(first);
            input2.setText(second);
            input3.setText(Third);
            input4.setText(Fourth);

            input1.setTextColor(getResources().getColor(R.color.colorAccent));
            input2.setTextColor(getResources().getColor(R.color.colorAccent));
            input3.setTextColor(getResources().getColor(R.color.colorAccent));
            input4.setTextColor(getResources().getColor(R.color.colorAccent));

            input1.setEnabled(false);
            input2.setEnabled(false);
            input3.setEnabled(false);
            input4.setEnabled(false);
        }
    }

    public void BindView() {
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);

        iv_back = findViewById(R.id.iv_back);
        iv_reset = findViewById(R.id.iv_reset);

        btn_getData = findViewById(R.id.btn_getData);
        registrationNo = findViewById(R.id.regNumber);
        registrationDate = findViewById(R.id.regDate);
        engineNo = findViewById(R.id.engineNo);
        ownerName = findViewById(R.id.ownerName);
        vehicleClass = findViewById(R.id.vehicleClass);
        fuelType = findViewById(R.id.fuelType);
        insuranceUpto = findViewById(R.id.insUpto);
        dataLayout = findViewById(R.id.dataLayout);
        state = findViewById(R.id.state);
        city = findViewById(R.id.city);
        btn_print = findViewById(R.id.btn_print);
        scrollView = findViewById(R.id.scrollView);
        scrollView.setDrawingCacheEnabled(true);
    }

    public void loadData() {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                List<String> dateList = new ArrayList<>();

                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        totalRequest = 0;
                        /*dateList.add(String.valueOf(snapshot.getChildrenCount()));*/
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            totalRequest = totalRequest + dataSnapshot.getChildrenCount();
                        }
                        databaseReference2.setValue(totalRequest);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                System.out.println(dateList);
            }
        });
    }

    public void SetClickListener() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(activity, MainActivity.class));
                databaseReference2.setValue(totalRequest);
                finish();
            }
        });

        iv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ResetData();
            }
        });

        input1.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input1.getText().toString().length() == 2) {
                    input2.setText("");
                    input2.requestFocus();
                }
            }
        });
        input2.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input2.getText().toString().length() == 2) {
                    input3.setText("");
                    input3.requestFocus();
                }
            }
        });
        input3.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(final Editable editable) {
            }

            public void beforeTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
            }

            public void onTextChanged(final CharSequence charSequence, final int n, final int n2, final int n3) {
                if (input3.getText().toString().length() == 2) {
                    input4.setText("");
                    input4.requestFocus();
                }
            }
        });

        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (input4.length() == 3) {
                    View view = getCurrentFocus();
                    if (view != null) {
                        InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if (input4.length() == 4) {
            View view = this.getCurrentFocus();
            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        btn_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                printData();
            }
        });

        btn_getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Adid = 101;
                if (interstitialAd !=null && interstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    GetData();
                }
            }
        });
    }

    public void GetData() {
        ownerName.setText("");
        registrationNo.setText("");
        registrationDate.setText("");
        fuelType.setText("");
        engineNo.setText("");
        insuranceUpto.setText("");
        vehicleClass.setText("");
        state.setText("");
        city.setText("");

        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input4.getWindowToken(), 0);
        input4.clearFocus();

        final String string = input1.getText().toString();
        final String string2 = input2.getText().toString();
        final String string3 = input3.getText().toString();
        final String string4 = input4.getText().toString();
        final StringBuilder sb = new StringBuilder();
        sb.append(string);
        sb.append(string2);
        sb.append(string3);
        sb.append(string4);
        Log.e("TAG", "Number" + sb.toString());
        result = sb.toString();
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("&reg2=");
        sb2.append(string4);
        resultTwo = sb2.toString();

        if (TextUtils.isEmpty(string)) {
            input1.setError("This should not be empty");
            input1.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string2)) {
            input2.setError("This should not be empty");
            input2.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string3)) {
            input3.setError("This should not be empty");
            input3.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(string4)) {
            input4.setError("This should not be empty");
            input4.requestFocus();
            return;
        }
        (pd = new ProgressDialog(activity)).setMessage("Please Wait...");
        pd.setCancelable(false);
        pd.show();
        GetVehicleDetail(result);
    }

    public void ResetData() {

        Adid = 100;
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            DialogShow();
            AdsDialogShow();
        } else {

            dataLayout.setVisibility(View.INVISIBLE);

            ownerName.setText("");
            registrationNo.setText("");
            registrationDate.setText("");
            fuelType.setText("");
            engineNo.setText("");
            insuranceUpto.setText("");
            vehicleClass.setText("");
            city.setText("");
            state.setText("");

            input1.setText("");
            input2.setText("");
            input3.setText("");
            input4.setText("");
        }
    }

    public void createandDisplayPdf(final String s) {
        (this.pd = new ProgressDialog(activity)).setMessage("Printing...");
        this.pd.show();
        final Document document = new Document(PageSize.A4, 20.0f, 20.0f, 50.0f, 25.0f);
        try {
            try {
                "mounted".equals(Environment.getExternalStorageState());
                final StringBuilder sb = new StringBuilder();
                sb.append(Environment.getExternalStorageDirectory());
                sb.append(File.separator);
                sb.append("ViewVehicleDetails");
                final File file = new File(sb.toString());
                if (!file.exists()) {
                    file.mkdir();
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(result);
                sb2.append(".pdf");
                final File file2 = new File(file, sb2.toString());
                Log.e("File2", "File2==> " + file2);
                PdfWriter.getInstance(document, new FileOutputStream(file2)).setPageEvent(new HeaderFooterPageEvent());
                document.open();
                final Paragraph paragraph = new Paragraph(s);
                final Font font = new Font(Font.FontFamily.COURIER);
                paragraph.setAlignment(0);
                paragraph.setFont(font);
                document.addTitle("VEHICLE DETAILS");
                document.add(paragraph);
                document.close();
                new CountDownTimer(500L, 500L) {
                    public void onFinish() {
                        openScreenshot(file2);
                        pd.dismiss();
                    }

                    public void onTick(final long n) {
                    }
                }.start();
            } finally {
            }
        } catch (IOException ex) {
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("ioException:");
            sb3.append(ex);
        } catch (DocumentException ex2) {
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("DocumentException:");
            sb4.append(ex2);
        }
        document.close();
    }

    private void openScreenshot(final File file) {
        final Uri uriForFile = FileProvider.getUriForFile(activity, getPackageName() + ".provider", file);
        final AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Share vehicle details");
        builder.setMessage("Your  Vehicle Details have been saved to PDF in \"ViewVehicleDetails\" folder.").setCancelable(true).setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(uriForFile, "application/pdf");
                target.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                target.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent intent = Intent.createChooser(target, "Open File");
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "No Application available to view pdf", Toast.LENGTH_LONG).show();
                }
            }
        }).setNegativeButton("Share", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                Log.e("ShareFile", "ShareFile==>  " + uriForFile);

                final StringBuilder sb = new StringBuilder();
                sb.append("View All India Vehicle details - Get \n App @ https://play.google.com/store/apps/details?id=");
                sb.append(getPackageName());
                final Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                intent.putExtra(Intent.EXTRA_TEXT, sb.toString());
                intent.putExtra(Intent.EXTRA_STREAM, uriForFile);
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
        builder.create().show();
    }

    private void printData() {
        if (Build.VERSION.SDK_INT > 22) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
                return;
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Owner Name : ");
            sb3.append(sOwnerName);
            sb3.append("\nRegistration No : ");
            sb3.append(sRegNumber);
            sb3.append("\nRegistration Date : ");
            sb3.append(sRegistrationDate);
            sb3.append("\nFuel Type : ");
            sb3.append(sFuelType);
            sb3.append("\nEngine Number : ");
            sb3.append(sEngineNumber);
            sb3.append("\nInsurance Upto : ");
            sb3.append(sInsuranceUpto);
            sb3.append("\nVehicle Class : ");
            sb3.append(sVehicleClass);
            sb3.append("\nCity : ");
            sb3.append(sCity);
            sb3.append("\nState : ");
            sb3.append(sState);
            sb3.append("\n\nGet All Inidia Vehicle details using ");
            sb3.append(getResources().getString(R.string.app_name));
            sb3.append(" Android App get app @ \n https://play.google.com/store/apps/details?id=");
            sb3.append(getPackageName());
            createandDisplayPdf(sb3.toString());
            Log.e("TAG", "PrintData" + sb3.toString());
            scrollView.setDrawingCacheEnabled(true);
        }
    }

    private boolean checkIfAlreadyhavePermission() {
        return ContextCompat.checkSelfPermission(activity, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }


    private void GetVehicleDetail(String number) {

        int min = 1;
        int max = 50000;

        double a = Math.random() * (max - min + 1) + min;
        double b = Math.random() * (max - min + 1) + min;

        DecimalFormat form = new DecimalFormat("00000");
        String randomNo1 = form.format(a);
        String randomNo2 = form.format(b);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String currentDateandTime = sdf.format(new Date());

        ownerHistoryPaidModelList = historyDatabase.ownerHistoryDao().getOwnerHistory();
        for (int i = 0; i < ownerHistoryPaidModelList.size(); i++) {
            String regNo = ownerHistoryPaidModelList.get(i).getRegistrationNo();
            if (regNo.equals(number)) {
                dataLayout.setVisibility(View.VISIBLE);

                userExists = false;

                sOwnerName = ownerHistoryPaidModelList.get(i).getOwnerName();
                sRegNumber = ownerHistoryPaidModelList.get(i).getRegistrationNo();
                sRegistrationDate = ownerHistoryPaidModelList.get(i).getRegistrationDate();
                sVehicleClass = ownerHistoryPaidModelList.get(i).getVehicleClass();
                sInsuranceUpto = ownerHistoryPaidModelList.get(i).getInsuranceUpto();
                sEngineNumber = ownerHistoryPaidModelList.get(i).getEngineNumber();
                sFuelType = ownerHistoryPaidModelList.get(i).getFuelType();
                sCity = ownerHistoryPaidModelList.get(i).getCity();
                sState = ownerHistoryPaidModelList.get(i).getState();

                ownerName.setText(sOwnerName);
                registrationNo.setText(sRegNumber);
                registrationDate.setText(sRegistrationDate);
                vehicleClass.setText(sVehicleClass);
                insuranceUpto.setText(sInsuranceUpto);
                engineNo.setText(sEngineNumber);
                fuelType.setText(sFuelType);
                city.setText(sCity);
                state.setText(sState);

                pd.dismiss();
            }
        }

        if (userExists) {

            APIInterface apiInterface = APIClient.getVehicleInfo().create(APIInterface.class);

            Call<OwnerRootPaidModel> call = apiInterface.getVehicleOwnerDetails("https://play.google.com/store/apps/details?id=com.storymaker.rtovehicalinformation", AppController.key, number);
            call.enqueue(new Callback<OwnerRootPaidModel>() {
                @Override
                public void onResponse(Call<OwnerRootPaidModel> call, Response<OwnerRootPaidModel> response) {
                    if (response.isSuccessful()) {

                        OwnerRootPaidModel ownerRootPaidModel = response.body();

                        String status = ownerRootPaidModel.getStatus();
                        if (status.equals("success")) {
                            AsyncTask.execute(new Runnable() {
                                @Override
                                public void run() {
                                    databaseReference.child(currentDateandTime).child(randomNo1 + randomNo2).setValue("Sent");
                                }
                            });

                            dataLayout.setVisibility(View.VISIBLE);

                            sOwnerName = ownerRootPaidModel.getResponse().getOwner_name();
                            sRegNumber = ownerRootPaidModel.getResponse().getLicense_plate();
                            sRegistrationDate = ownerRootPaidModel.getResponse().getRegistration_date();
                            sVehicleClass = ownerRootPaidModel.getResponse().getVehicleClass();
                            sInsuranceUpto = ownerRootPaidModel.getResponse().getInsurance_expiry();
                            sEngineNumber = ownerRootPaidModel.getResponse().getEngine_number();
                            sFuelType = ownerRootPaidModel.getResponse().getFuel_type();
                            sCity = ownerRootPaidModel.getResponse().getRto_code() + " " + ownerRootPaidModel.getResponse().getRto();
                            sState = ownerRootPaidModel.getResponse().getState();

                            insertOwnerDataIntoRoom();

                            ownerName.setText(sOwnerName);
                            registrationNo.setText(sRegNumber);
                            registrationDate.setText(sRegistrationDate);
                            vehicleClass.setText(sVehicleClass);
                            insuranceUpto.setText(sInsuranceUpto);
                            engineNo.setText(sEngineNumber);
                            fuelType.setText(sFuelType);
                            city.setText(sCity);
                            state.setText(sState);

                            pd.dismiss();
                        } else {
                            Toast.makeText(VehicleDetailActivity.this, "Server error !", Toast.LENGTH_SHORT).show();
                            pd.dismiss();
                        }
                    }
                }

                @Override
                public void onFailure(Call<OwnerRootPaidModel> call, Throwable t) {
                    Toast.makeText(VehicleDetailActivity.this, "Check Your Internet Connection !", Toast.LENGTH_SHORT).show();
                    pd.dismiss();
                }
            });
        }
    }

    private void insertOwnerDataIntoRoom() {
        Thread thread = new Thread(new Runnable() {
            public void run() {
                OwnerHistoryPaidModel ownerHistory = new OwnerHistoryPaidModel(sOwnerName, sRegNumber, sRegistrationDate, sFuelType, sEngineNumber, sInsuranceUpto, sVehicleClass, sCity, sState);
                historyDatabase.ownerHistoryDao().insertOwnerData(ownerHistory);
            }
        });
        thread.start();
    }

    private InterstitialAd interstitialAd;
    private int Adid;
    private KProgressHUD hud;

    private void loadAd() {

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.interstitial));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (Adid) {
                    case 100:
                        ResetData();
                        break;

                    case 101:
                        GetData();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(VehicleDetailActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(activity, MainActivity.class));
        finish();
    }
}