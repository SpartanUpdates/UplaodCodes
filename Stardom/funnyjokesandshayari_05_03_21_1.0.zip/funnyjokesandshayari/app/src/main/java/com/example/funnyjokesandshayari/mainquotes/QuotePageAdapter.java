package com.example.funnyjokesandshayari.mainquotes;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.viewpager.widget.PagerAdapter;

import com.example.funnyjokesandshayari.R;

import java.util.ArrayList;

public class QuotePageAdapter extends PagerAdapter {
    private Object QuotePageAdapter;
    MainActivity activity;
    Context context;
    ArrayList<Quote> list;
    public int position = -1;

    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public QuotePageAdapter(ArrayList<Quote> arrayList, Context context, MainActivity mainActivity) {
        this.list = arrayList;
        this.context = context;
        this.activity = mainActivity;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int i) {
        final Quote quote = (Quote) list.get(i);
        Log.e("TAG", "Quote" + i);
        ViewGroup viewGroup2 = (ViewGroup) LayoutInflater.from(this.context).inflate(R.layout.slide_layout, viewGroup, false);


        TextView textView = viewGroup2.findViewById(R.id.quoteHolder);

        textView.setText(quote.getQuote());

        Log.e("GEEEETTTTEEE",quote.getQuote());

        ImageView imageButton = (ImageView) viewGroup2.findViewById(R.id.wp);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("instantiateItem: ");
        stringBuilder.append(quote.getQuote());
        Log.d("YYYYYY", stringBuilder.toString());
        imageButton.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(quote.getQuote());
                stringBuilder.append("Download App : "+"\nhttps://play.google.com/store/apps/details?id="+context.getPackageName());
                String stringBuilder2 = stringBuilder.toString();
                Intent intent = new Intent();
                intent.setPackage("com.whatsapp");
                intent.setAction("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.TEXT", stringBuilder2);
                intent.setType("text/plain");
                QuotePageAdapter.this.context.startActivity(Intent.createChooser(intent, null));
            }
        });

        /*((ImageButton) viewGroup2.findViewById(R.id.fb)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(quote.getQuote());
                stringBuilder.append("                                                              Download App : http://bit.ly/3aHQzPx");
                String stringBuilder2 = stringBuilder.toString();
                Intent intent = new Intent();
                intent.setPackage("com.facebook.katana");
                intent.setAction("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.TEXT", stringBuilder2);
                QuotePageAdapter.this.context.startActivity(Intent.createChooser(intent, null));
            }
        });*/

        ((ImageView) viewGroup2.findViewById(R.id.shareButton)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(quote.getQuote());
                stringBuilder.append("Download App : "+"\nhttps://play.google.com/store/apps/details?id="+context.getPackageName());
                String stringBuilder2 = stringBuilder.toString();
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.TEXT", stringBuilder2);
                intent.setType("text/plain");
                QuotePageAdapter.this.context.startActivity(Intent.createChooser(intent, null));
            }
        });
        ((ImageView) viewGroup2.findViewById(R.id.copy)).setOnClickListener(new OnClickListener()
        {
            public void onClick(View view) {
                QuotePageAdapter.this.activity.callCopyClipboard(quote.getQuote());
            }
        });

        viewGroup.addView(viewGroup2);
        return viewGroup2;
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj)
    {
        viewGroup.removeView((View) obj);
    }

    public int getCount() {

        return this.list.size();
    }
}
