package com.esc.phoneheart.advancedclean;

import android.app.AppOpsManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.util.Log;

import com.esc.phoneheart.advancedclean.BaseActivity.IPActivityListener;

public class StepCheckReadProcPermission extends Step implements IPActivityListener {
    public static final String TAG = "StepCheckReadProcPerm";
    public BaseActivity mActivity;

    public StepCheckReadProcPermission(BaseActivity baseActivity) {
        this.mActivity = baseActivity;
    }

    private void afterSetting() {
        boolean hasPermissionForBlocking = hasPermissionForBlocking();
        String str = TAG;
        if (hasPermissionForBlocking) {
            Log.i(str, "we are granted to ReadProc, check next.");
            doNext();
            return;
        }
        Log.i(str, "permission not grant yet,we can't step forward,finish it.");
        this.mActivity.finish();
    }

    public void doAction() {
        if (hasPermissionForBlocking()) {
            doNext();
            return;
        }
        Log.i(TAG, "we are not grant to access running stats.");
        this.mActivity.addResultListener(this);
        this.mActivity.startActivityForResult(new Intent("android.settings.USAGE_ACCESS_SETTINGS"), 1003);
    }

    public boolean hasPermissionForBlocking() {
        try {
            ApplicationInfo applicationInfo = this.mActivity.getPackageManager().getApplicationInfo(this.mActivity.getPackageName(), 0);
            if ((VERSION.SDK_INT >= 19 ? ((AppOpsManager) this.mActivity.getSystemService("appops")).checkOpNoThrow("android:get_usage_stats", applicationInfo.uid, applicationInfo.packageName) : 0) == 0) {
                return true;
            }
            return false;
        } catch (NameNotFoundException unused) {
            return false;
        }
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        if (1003 != i) {
            return false;
        }
        afterSetting();
        return true;
    }

    public void onRestart() {
        afterSetting();
    }
}
