package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class FavoriteActivity extends AppCompatActivity {
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 111;
    public static boolean backpressed = false;
    public static Runnable changeAdBool = new Runnable() {
        public void run() {
            if (FavoriteActivity.i == 0) {
                FavoriteActivity.i++;
                FavoriteActivity.startbool = true;
                FavoriteActivity.handler.postDelayed(FavoriteActivity.changeAdBool, 60000);
                return;
            }
            FavoriteActivity.showbool = true;
            FavoriteActivity.i = 0;
            FavoriteActivity.stopbool = true;
            FavoriteActivity.stopRunnable();
        }
    };
    public static Boolean exitbool = Boolean.valueOf(false);
    private static String greeting = null;
    public static Handler handler = new Handler();
    static int i = 0;
    public static String image_url = "";
    public static int lockCounter;
    private static boolean showbool = false;
    private static boolean startbool = false;
    private static boolean stopbool = false;
    public RecyclerAdapter Radapter;
    Activity activity = this;
    String appname = "Love Messages For Wife";
    DataBaseHelper basehelper;
    String cat;
    ArrayList<String> catList = new ArrayList();
    Dialog dialogR;
    public Editor editor;
    public Editor editorAds;
    RelativeLayout exitparent;
    private int f;
    public Typeface face1;
    public Typeface face2;
    ArrayList<String> favfav = new ArrayList();
    ArrayList<String> favid = new ArrayList();
    ArrayList<String> favimg = new ArrayList();
    ArrayList<String> favmsg = new ArrayList();
    RelativeLayout gridparent;
    int height;
    TextView ifNoFavoriteMessage;
    ImageView image;
    String msg2;
    ArrayList<String> pg_id = new ArrayList();
    RecyclerView recyclerview;
    public SharedPreferences sharedPreferences;
    public SharedPreferences sharedPreferencesAds;
    File shfile;
    String url;
    ArrayList<String> urlList = new ArrayList();
    int width;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    private class Async extends AsyncTask<Void, Void, Void> {
        private Async() {
        }

        Async(FavoriteActivity favoriteActivity) {
            this();
        }


        public Void doInBackground(Void... voidArr) {
            FavoriteActivity.image_url = "https://www.wishafriend.com/";
            FavoriteActivity.this.ImageUrlString();
            return null;
        }
    }

    public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
        public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
        Activity activity;
        Button btn;
        private ArrayList<String> cat;
        Context context;
        ArrayList<String> favfavAdapter;
        ArrayList<String> favidAdapter;
        ArrayList<String> favimgAdapter;
        ArrayList<String> favmsgAdapter;
        LayoutInflater inflater;
        private ArrayList<String> pg_url;

        public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            TextView copyTextButton;
            ImageView imgfav;
            LinearLayout linear;
            ImageView msgimg;
            Button personalized;
            RelativeLayout rel;
            RelativeLayout rel2;
            TextView saveImageButton;
            LinearLayout saveShareLinearLayout;
            TextView shareimage;
            TextView sharetxt;
            TextView txtview;

            public ViewHolder(View view) {
                super(view);
                this.msgimg = (ImageView) view.findViewById(R.id.msgimg);
                this.txtview = (TextView) view.findViewById(R.id.msg);
                this.linear = (LinearLayout) view.findViewById(R.id.linear);
                this.shareimage = (TextView) view.findViewById(R.id.shareimage);
                this.imgfav = (ImageView) view.findViewById(R.id.imgfav);
                this.sharetxt = (TextView) view.findViewById(R.id.sharetxt);
                this.rel = (RelativeLayout) view.findViewById(R.id.rel1);
                this.rel2 = (RelativeLayout) view.findViewById(R.id.rel2);
                this.saveShareLinearLayout = (LinearLayout) view.findViewById(R.id.save_share_linearlayout);
                this.copyTextButton = (TextView) view.findViewById(R.id.copy_text);
                this.saveImageButton = (TextView) view.findViewById(R.id.save_image);
                this.personalized = (Button) view.findViewById(R.id.personalized);
                this.txtview.setTypeface(FavoriteActivity.this.face2);
                this.shareimage.setTypeface(FavoriteActivity.this.face1);
                this.sharetxt.setTypeface(FavoriteActivity.this.face1);
                this.saveImageButton.setTypeface(FavoriteActivity.this.face1);
                this.copyTextButton.setTypeface(FavoriteActivity.this.face1);
                this.personalized.setTypeface(FavoriteActivity.this.face1);
                LayoutParams layoutParams;
                double d;
                double d2;
                if ((FavoriteActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
                    this.txtview.setTextSize(30.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(30.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.4d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(30.0f);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.saveImageButton.setTextSize(30.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.copyTextButton.setTextSize(30.0f);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(30.0f);
                } else if ((FavoriteActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
                    this.txtview.setTextSize(24.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(24.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.38d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(24.0f);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(24.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.saveImageButton.setTextSize(24.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.copyTextButton.setTextSize(24.0f);
                } else {
                    this.txtview.setTextSize(20.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(18.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.35d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(18.0f);
                    layoutParams = this.imgfav.getLayoutParams();
                    d = (double) MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.06d);
                    layoutParams = this.personalized.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.personalized.setTextSize(18.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.saveImageButton.setTextSize(18.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d2 = (double) MainActivity.height;
                    Double.isNaN(d2);
                    layoutParams.height = (int) (d2 * 0.05d);
                    this.copyTextButton.setTextSize(18.0f);
                }
            }
        }

        RecyclerAdapter(FavoriteActivity favoriteActivity, Context context, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4, ArrayList arrayList5, ArrayList arrayList6, Activity activity) {
            this(context, arrayList, arrayList2, arrayList3, arrayList4, arrayList5, arrayList6, activity);
        }

        private RecyclerAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4, ArrayList<String> arrayList5, ArrayList<String> arrayList6, Activity activity) {
            this.favidAdapter = new ArrayList();
            this.favmsgAdapter = new ArrayList();
            this.favimgAdapter = new ArrayList();
            this.favfavAdapter = new ArrayList();
            this.inflater = null;
            this.favidAdapter = arrayList;
            this.favmsgAdapter = arrayList2;
            this.favimgAdapter = arrayList3;
            this.favfavAdapter = arrayList4;
            this.context = context;
            this.cat = arrayList5;
            this.pg_url = arrayList6;
            this.activity = activity;
        }

        public int getItemViewType(int i) {
            return ((String) this.favimgAdapter.get(i)).contains("0") ? 0 : 1;
        }

        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.messageitem1, viewGroup, false));
        }

        public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
            final String str = (String) this.favmsgAdapter.get(i);
            Log.e("favmsg", str);
            viewHolder.txtview.setText(Html.fromHtml(str));
            if (FavoriteActivity.this.sharedPreferences.getBoolean("lock", true)) {
                Log.e("kkkkkkkk", "jjjjjj");
                viewHolder.personalized.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.lock, 0);
                viewHolder.personalized.setPadding(0, 0, 50, 0);
            }
            if (getItemViewType(i) == 1) {
                String stringBuilder;
                StringBuilder stringBuilder2;
                String str2 = ".jpg";
                String str3 = "-";
                String str4 = "";
                StringBuilder stringBuilder3;
                if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(MainActivity.image_url);
                    stringBuilder3.append(str4);
                    stringBuilder3.append((String) this.cat.get(i));
                    stringBuilder3.append("/");
                    stringBuilder3.append((String) FavoriteActivity.this.favid.get(i));
                    stringBuilder3.append(str3);
                    stringBuilder3.append((String) this.pg_url.get(i));
                    stringBuilder3.append(str2);
                    stringBuilder = stringBuilder3.toString();
                } else {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(MainActivity.image_url);
                    stringBuilder3.append(str4);
                    stringBuilder3.append((String) this.cat.get(i));
                    stringBuilder3.append("/uploads/");
                    stringBuilder3.append((String) FavoriteActivity.this.favid.get(i));
                    stringBuilder3.append(str3);
                    stringBuilder3.append((String) this.pg_url.get(i));
                    stringBuilder3.append(str2);
                    stringBuilder = stringBuilder3.toString();
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str4);
                    stringBuilder2.append(stringBuilder);
                    Log.e("url", stringBuilder2.toString());
                }
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("OnBindView Holder   url ");
                stringBuilder2.append(stringBuilder);
                Log.e("Favorite Adaptor ", stringBuilder2.toString());
                ((RequestBuilder) Glide.with(this.context).load(stringBuilder).placeholder((int) R.drawable.loading)).into(viewHolder.msgimg);
            } else if (getItemViewType(i) == 0) {
                viewHolder.msgimg.setImageDrawable(null);
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) viewHolder.msgimg.getLayoutParams();
                viewHolder.msgimg.getLayoutParams().height = 0;
                viewHolder.msgimg.getLayoutParams().width = 0;
            }
            if (Integer.parseInt(((String) this.favfavAdapter.get(i)).toString()) == 0) {
                viewHolder.imgfav.setImageResource(R.drawable.ic_favorite_border_white_24dp);
            } else {
                viewHolder.imgfav.setImageResource(R.drawable.ic_favorite_white_24dp);
            }
            viewHolder.linear.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    new Builder(view.getContext()).create().show();
                }
            });
            viewHolder.imgfav.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ImageView imageView = (ImageView) view.findViewById(R.id.imgfav);
                    imageView.setTag(viewHolder.imgfav.getTag());
                    try {
                        FavoriteActivity.this.basehelper.createDataBase();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    FavoriteActivity.this.f = Integer.parseInt((String) RecyclerAdapter.this.favfavAdapter.get(i));
                    if (FavoriteActivity.this.f == 0) {
                        imageView.setImageResource(R.drawable.ic_favorite_white_24dp);
                        FavoriteActivity.this.basehelper.updateFavorite(1, Integer.parseInt((String) RecyclerAdapter.this.favidAdapter.get(i)));
                        Toast.makeText(FavoriteActivity.this.getApplicationContext(), FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.marked), Toast.LENGTH_LONG).show();
                        imageView.invalidate();
                        RecyclerAdapter.this.notifyDataSetChanged();
                        RecyclerAdapter.this.favfavAdapter.set(i, "1");
                    } else if (FavoriteActivity.this.f == 1) {
                        imageView.setImageResource(R.drawable.ic_favorite_border_white_24dp);
                        FavoriteActivity.this.basehelper.updateFavorite(0, Integer.parseInt((String) RecyclerAdapter.this.favidAdapter.get(i)));
                        Toast.makeText(FavoriteActivity.this.getApplicationContext(), FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.Unmarked), Toast.LENGTH_LONG).show();
                        imageView.invalidate();
                        RecyclerAdapter.this.notifyDataSetChanged();
                        RecyclerAdapter.this.favfavAdapter.set(i, "0");
                    }
                }
            });
            viewHolder.sharetxt.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    FavoriteActivity.this.AddRateClicks();
                    String obj = Html.fromHtml((String) FavoriteActivity.this.favmsg.get(i)).toString();
                    FavoriteActivity favoriteActivity = FavoriteActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(obj);
                    stringBuilder.append("\n");
                    StringBuilder stringBuilder2 = new StringBuilder();
                    String str = "<br>";
                    stringBuilder2.append(str);
                    stringBuilder2.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                    stringBuilder2.append(str);
                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                    favoriteActivity.msg2 = stringBuilder.toString();
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "Love Messages For Wife");
                    intent.putExtra("android.intent.extra.TEXT", FavoriteActivity.this.msg2);
                    FavoriteActivity.this.startActivity(Intent.createChooser(intent, FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                    Map hashMap = new HashMap();
                    hashMap.put(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favsharetext), MainActivity.gridtitle);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favsharetext));
                    stringBuilder2.append("  ");
                    stringBuilder2.append(MainActivity.gridtitle);
                    Log.e("Flurry", stringBuilder2.toString());
                }
            });
            viewHolder.saveImageButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(RecyclerAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(RecyclerAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        RecyclerAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    FavoriteActivity.this.AddRateClicks();
                    String str = ".jpg";
                    String str2 = "-";
                    String str3 = "";
                    FavoriteActivity favoriteActivity;
                    StringBuilder stringBuilder;
                    if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                        favoriteActivity = FavoriteActivity.this;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(MainActivity.image_url);
                        stringBuilder.append(str3);
                        stringBuilder.append((String) RecyclerAdapter.this.cat.get(i));
                        stringBuilder.append("/");
                        stringBuilder.append((String) FavoriteActivity.this.favid.get(i));
                        stringBuilder.append(str2);
                        stringBuilder.append((String) RecyclerAdapter.this.pg_url.get(i));
                        stringBuilder.append(str);
                        favoriteActivity.url = stringBuilder.toString();
                    } else {
                        favoriteActivity = FavoriteActivity.this;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(MainActivity.image_url);
                        stringBuilder.append(str3);
                        stringBuilder.append((String) RecyclerAdapter.this.cat.get(i));
                        stringBuilder.append("/uploads/");
                        stringBuilder.append((String) FavoriteActivity.this.favid.get(i));
                        stringBuilder.append(str2);
                        stringBuilder.append((String) RecyclerAdapter.this.pg_url.get(i));
                        stringBuilder.append(str);
                        favoriteActivity.url = stringBuilder.toString();
                    }
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("url...in Save Image");
                    stringBuilder2.append(FavoriteActivity.this.url);
                    Log.e("Favorite", stringBuilder2.toString());
                    try {
                        if (FavoriteActivity.this.isNetworkAvailable()) {
                            Glide.with(FavoriteActivity.this.getApplicationContext()).asBitmap().load(FavoriteActivity.this.url).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    FavoriteActivity.this.saveImage(bitmap, Integer.parseInt((String) FavoriteActivity.this.favid.get(i)));
                                }
                            });
                            return;
                        }
                        Builder builder = new Builder(FavoriteActivity.this);
                        builder.setTitle(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                        builder.setMessage(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.error));
                        builder.setCancelable(false).setPositiveButton(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, final int i) {
                                if (FavoriteActivity.this.isNetworkAvailable()) {
                                    Glide.with(FavoriteActivity.this.getApplicationContext()).asBitmap().load(FavoriteActivity.this.url).into(new SimpleTarget<Bitmap>() {
                                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                            FavoriteActivity.this.saveImage(bitmap, Integer.parseInt((String) FavoriteActivity.this.favid.get(i)));
                                        }
                                    });
                                } else {
                                    Toast.makeText(FavoriteActivity.this, FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).setNegativeButton(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                        builder.create().show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            viewHolder.copyTextButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Context applicationContext = FavoriteActivity.this.getApplicationContext();
                    FavoriteActivity.this.getApplicationContext();
                    ClipboardManager clipboardManager = (ClipboardManager) applicationContext.getSystemService(CLIPBOARD_SERVICE);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(Html.fromHtml((String) FavoriteActivity.this.favmsg.get(i)));
                    String str = "<br>";
                    stringBuilder.append(str);
                    stringBuilder.append(FavoriteActivity.this.getResources().getString(R.string.fromshare));
                    stringBuilder.append(str);
                    stringBuilder.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    clipboardManager.setPrimaryClip(ClipData.newPlainText("label", stringBuilder.toString()));
                    Toast.makeText(FavoriteActivity.this.getApplicationContext().getApplicationContext(), FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
                    Map hashMap = new HashMap();
                    hashMap.put(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favcopytext), MainActivity.gridtitle);
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favcopytext));
                    stringBuilder2.append("  ");
                    stringBuilder2.append(MainActivity.gridtitle);
                    Log.e("Flurry", stringBuilder2.toString());
                }
            });
            viewHolder.shareimage.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(RecyclerAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(RecyclerAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        RecyclerAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    final String stringBuilder;
                    FavoriteActivity.this.AddRateClicks();
                    String str = ".jpg";
                    String str2 = "-";
                    String str3 = "";
                    StringBuilder stringBuilder2;
                    if (!MainActivity.image_url.contains(".com") || MainActivity.image_url.contains("amazonaws")) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(MainActivity.image_url);
                        stringBuilder2.append(str3);
                        stringBuilder2.append((String) RecyclerAdapter.this.cat.get(i));
                        stringBuilder2.append("/");
                        stringBuilder2.append((String) FavoriteActivity.this.favid.get(i));
                        stringBuilder2.append(str2);
                        stringBuilder2.append((String) RecyclerAdapter.this.pg_url.get(i));
                        stringBuilder2.append(str);
                        stringBuilder = stringBuilder2.toString();
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(MainActivity.image_url);
                        stringBuilder2.append(str3);
                        stringBuilder2.append((String) RecyclerAdapter.this.cat.get(i));
                        stringBuilder2.append("/uploads/");
                        stringBuilder2.append((String) FavoriteActivity.this.favid.get(i));
                        stringBuilder2.append(str2);
                        stringBuilder2.append((String) RecyclerAdapter.this.pg_url.get(i));
                        stringBuilder2.append(str);
                        stringBuilder = stringBuilder2.toString();
                    }
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(" ");
                    stringBuilder3.append(stringBuilder);
                    Log.e("URL", stringBuilder3.toString());
                    if (FavoriteActivity.this.isNetworkAvailable()) {
                        try {
                            Glide.with(FavoriteActivity.this.getApplicationContext()).asBitmap().load(stringBuilder).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                    FavoriteActivity favoriteActivity = FavoriteActivity.this;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append((String) FavoriteActivity.this.favid.get(i));
                                    stringBuilder.append(".jpg");
                                    favoriteActivity.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                    try {
                                        FileOutputStream fileOutputStream = new FileOutputStream(FavoriteActivity.this.shfile);
                                        bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                        try {
                                            fileOutputStream.flush();
                                            fileOutputStream.close();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    } catch (FileNotFoundException e2) {
                                        e2.printStackTrace();
                                        Toast.makeText(RecyclerAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                    }
                                    FavoriteActivity favoriteActivity2 = FavoriteActivity.this;
                                    StringBuilder stringBuilder2 = new StringBuilder();
                                    String str = "\n";
                                    stringBuilder2.append(str);
                                    stringBuilder2.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                    stringBuilder2.append(str);
                                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                    favoriteActivity2.msg2 = stringBuilder2.toString();
                                    Uri uriForFile = FileProvider.getUriForFile(FavoriteActivity.this, getPackageName() + ".provider", FavoriteActivity.this.shfile);
                                    Intent intent = new Intent();
                                    intent.setAction("android.intent.action.SEND");
                                    intent.setType("image/*");
                                    intent.putExtra("android.intent.extra.SUBJECT", FavoriteActivity.this.appname);
                                    intent.putExtra("android.intent.extra.TEXT", FavoriteActivity.this.msg2);
                                    intent.putExtra("android.intent.extra.STREAM", uriForFile);
                                    FavoriteActivity.this.startActivity(Intent.createChooser(intent, FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                                    Map hashMap = new HashMap();
                                    hashMap.put(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favshareimage), MainActivity.gridtitle);
                                    StringBuilder stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("");
                                    stringBuilder3.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.favshareimage));
                                    stringBuilder3.append("  ");
                                    stringBuilder3.append(MainActivity.gridtitle);
                                    Log.e("Flurry", stringBuilder3.toString());
                                }
                            });
                            return;
                        } catch (Exception e) {
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("share exc ");
                            stringBuilder3.append(e);
                            Log.e("jjjj", stringBuilder3.toString());
                            e.printStackTrace();
                            return;
                        }
                    }
                    Builder builder = new Builder(FavoriteActivity.this);
                    builder.setTitle(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                    builder.setMessage(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.error));
                    builder.setCancelable(false).setPositiveButton(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, final int i) {
                            if (FavoriteActivity.this.isNetworkAvailable()) {
                                try {
                                    Glide.with(FavoriteActivity.this.getApplicationContext()).asBitmap().load(stringBuilder).into(new SimpleTarget<Bitmap>() {
                                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                            File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                            FavoriteActivity favoriteActivity = FavoriteActivity.this;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append((String) FavoriteActivity.this.favid.get(i));
                                            stringBuilder.append(".jpg");
                                            favoriteActivity.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                            try {
                                                FileOutputStream fileOutputStream = new FileOutputStream(FavoriteActivity.this.shfile);
                                                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                                try {
                                                    fileOutputStream.flush();
                                                    fileOutputStream.close();
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }
                                            } catch (FileNotFoundException e2) {
                                                e2.printStackTrace();
                                                Toast.makeText(RecyclerAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                            }
                                            FavoriteActivity favoriteActivity2 = FavoriteActivity.this;
                                            StringBuilder stringBuilder2 = new StringBuilder();
                                            String str = "\n";
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                            stringBuilder2.append(str);
                                            stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                            favoriteActivity2.msg2 = stringBuilder2.toString();
                                            Uri uriForFile = FileProvider.getUriForFile(FavoriteActivity.this, String.valueOf(activity.getPackageName()) + ".provider", FavoriteActivity.this.shfile);
                                            Intent intent = new Intent();
                                            intent.setAction("android.intent.action.SEND");
                                            intent.setType("image/*");
                                            intent.putExtra("android.intent.extra.SUBJECT", FavoriteActivity.this.appname);
                                            intent.putExtra("android.intent.extra.TEXT", FavoriteActivity.this.msg2);
                                            intent.putExtra("android.intent.extra.STREAM", uriForFile);
                                            FavoriteActivity.this.startActivity(Intent.createChooser(intent, "Share via..."));
                                        }
                                    });
                                    return;
                                } catch (Exception e) {
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("share exc ");
                                    stringBuilder.append(e);
                                    Log.e("jjjj", stringBuilder.toString());
                                    e.printStackTrace();
                                    return;
                                }
                            }
                            Toast.makeText(FavoriteActivity.this, FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                        }
                    }).setNegativeButton(FavoriteActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    builder.create().show();
                }
            });
            viewHolder.personalized.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    String str = "date";
                    String str2 = "dd/M/yyyy hh:mm:ss";
                    FavoriteActivity.greeting = str;
                    try {
                        String string = FavoriteActivity.this.sharedPreferences.getString(str, new SimpleDateFormat(str2, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
                        Date time = Calendar.getInstance().getTime();
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str2, Locale.ENGLISH);
                        int difference = MainActivity.getDifference(simpleDateFormat.parse(string), simpleDateFormat.parse(simpleDateFormat.format(time)));
                        String str3 = "unlocked";
                        if (FavoriteActivity.this.sharedPreferences.getBoolean("lock", true)) {
                            if (!FavoriteActivity.this.isNetworkAvailable()) {
                                Toast.makeText(FavoriteActivity.this.getApplicationContext(), "Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                            } else if (FavoriteActivity.lockCounter >= 7) {
                                MainActivity.unlocked = Boolean.valueOf(true);
                                str2 = new SimpleDateFormat(str2, Locale.ENGLISH).format(Calendar.getInstance().getTime());
                                FavoriteActivity.this.editor.putBoolean(str3, true);
                                FavoriteActivity.this.editor.putString(str, str2);
                                FavoriteActivity.this.editor.commit();
                                FavoriteActivity.this.checkRewarded();
                            } else {
                                FavoriteActivity.lockCounter++;
                                Toast.makeText(FavoriteActivity.this.getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                            }
                        } else if (difference < 5) {
                            FavoriteActivity.this.editor.putBoolean(str3, false);
                            if (MainActivity.isFirst) {
                                MainActivity.isFirst = false;
                            }
                            FavoriteActivity.this.editor.commit();
                            Intent intent = new Intent(RecyclerAdapter.this.context, GreetingActivity.class);
                            intent.putExtra("source", "MainActivity");
                            intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, FavoriteActivity.greeting);
                            FavoriteActivity.this.startActivity(intent);
                        }
                    } catch (ParseException unused) {
                        unused.printStackTrace();
                    }
                }
            });
            if (getItemViewType(i) == 1) {
                viewHolder.rel2.setVisibility(View.VISIBLE);
                viewHolder.shareimage.setVisibility(View.VISIBLE);
                viewHolder.saveShareLinearLayout.setVisibility(View.VISIBLE);
            } else {
                viewHolder.rel2.setVisibility(View.GONE);
                viewHolder.msgimg.setImageDrawable(null);
                viewHolder.shareimage.setVisibility(View.INVISIBLE);
                viewHolder.saveShareLinearLayout.setVisibility(View.GONE);
            }
            viewHolder.txtview.setText(Html.fromHtml((String) FavoriteActivity.this.favmsg.get(i)));
        }

        private boolean checkAndRequestPermissions() {
            String str = "android.permission.WRITE_EXTERNAL_STORAGE";
            int checkSelfPermission = ContextCompat.checkSelfPermission(this.context, str);
            ArrayList arrayList = new ArrayList();
            if (checkSelfPermission != 0) {
                arrayList.add(str);
            }
            if (arrayList.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(this.activity, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
            return false;
        }

        public int getItemCount() {
            return FavoriteActivity.this.favid.size();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_favorite);
        String str = "MYPREFERENCE";
        this.sharedPreferences = getSharedPreferences(str, 0);
        this.sharedPreferencesAds = getSharedPreferences(str, 0);
        this.editorAds = this.sharedPreferencesAds.edit();
        this.editor = this.sharedPreferences.edit();
        MyApplication myApplication = (MyApplication) getApplication();
        this.basehelper = new DataBaseHelper(getApplicationContext());
        this.face1 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        this.face2 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Regular.ttf");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        CharSequence charSequence = "";
        getSupportActionBar().setTitle(charSequence);
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = (TextView) inflate.findViewById(R.id.action_bar_title);
        textView.setText(getResources().getString(R.string.favorites));
        textView.setTypeface(this.face1);
        this.ifNoFavoriteMessage = (TextView) findViewById(R.id.no_favorite_text);
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        try {
            this.basehelper.createDataBase();
        } catch (IOException e) {
            e.printStackTrace();
        }
        BannerAds();
        new Async(this).execute(new Void[0]);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
        this.recyclerview = (RecyclerView) findViewById(R.id.favlist);
        this.image = (ImageView) findViewById(R.id.msgimg);
        this.recyclerview.setHasFixedSize(true);
        this.favid = this.basehelper.getFavMsgId();
        Log.e("favid", String.valueOf(this.favid));
        this.favmsg = this.basehelper.getFavMsg();
        Log.e("favMsg", String.valueOf(this.favmsg));
        this.favimg = this.basehelper.getFavImage();
        String str2 = "favi";
        Log.e(str2, String.valueOf(this.favimg));
        this.favfav = this.basehelper.getFavFav();
        Log.e(str2, String.valueOf(this.favfav));
        this.urlList = this.basehelper.getFavUrl();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(charSequence);
        stringBuilder.append(this.urlList);
        Log.e("url", stringBuilder.toString());
        this.catList = this.basehelper.getFavCat();
        stringBuilder = new StringBuilder();
        stringBuilder.append(charSequence);
        stringBuilder.append(this.catList);
        Log.e("category", stringBuilder.toString());
        if (this.favfav.size() == 0) {
            this.ifNoFavoriteMessage.setVisibility(View.VISIBLE);
        } else {
            this.ifNoFavoriteMessage.setVisibility(View.GONE);
        }
        this.Radapter = new RecyclerAdapter(this, getApplicationContext(), this.favid, this.favmsg, this.favimg, this.favfav, this.catList, this.urlList, this.activity);
        this.recyclerview.setAdapter(this.Radapter);
        this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void stopRunnable() {
        if (stopbool) {
            Log.e("AAAAaA", "StopRunnnable");
            handler.removeCallbacks(changeAdBool);
        }
    }

    public static void startRunnable() {
        if (!startbool) {
            changeAdBool.run();
            i = 0;
            showbool = false;
            stopbool = false;
            Log.e("AAAA", "starrunnable");
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 111 && iArr.length > 0) {
            i = iArr[0];
        }
    }


    public void onStop() {
        super.onStop();
        this.editor.putInt("lockcounter", lockCounter);
    }

    public void ImageUrlString() {

    }

    private String readStream(InputStream inputStream) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int read = inputStream.read();
            while (read != -1) {
                byteArrayOutputStream.write(read);
                read = inputStream.read();
            }
            return byteArrayOutputStream.toString();
        } catch (IOException unused) {
            return "error";
        }
    }

    public void copyText() {
        String str = "https://play.google.com/store/apps/details?id=" + getPackageName();
        String str2 = "clipboard";
        String str3 = "<br>";
        if (VERSION.SDK_INT >= 11) {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            str2 = getApplicationContext().getResources().getString(R.string.label);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.msg2);
            stringBuilder.append(str3);
            stringBuilder.append(getResources().getString(R.string.fromshare));
            stringBuilder.append(str3);
            stringBuilder.append(str);
            clipboardManager.setPrimaryClip(ClipData.newPlainText(str2, Html.fromHtml(stringBuilder.toString())));
            Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
            return;
        }
        android.text.ClipboardManager clipboardManager2 = (android.text.ClipboardManager) getSystemService(str2);
        ClipData.newPlainText(getApplicationContext().getResources().getString(R.string.textlabel), getApplicationContext().getResources().getString(R.string.textclip));
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.msg2);
        stringBuilder2.append(str3);
        stringBuilder2.append(getResources().getString(R.string.fromshare));
        stringBuilder2.append(str3);
        stringBuilder2.append(str);
        clipboardManager2.setText(Html.fromHtml(stringBuilder2.toString()));
        Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void saveImage(Bitmap bitmap, int i) {
        try {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i);
            stringBuilder.append(".jpg");
            File file = new File(externalStorageDirectory, stringBuilder.toString());
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.ImageSave), Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
                Toast.makeText(getApplicationContext(), "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
            }
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(file));
            getApplicationContext().sendBroadcast(intent);
            Map hashMap = new HashMap();
            hashMap.put(getApplicationContext().getResources().getString(R.string.favsaveimage), MainActivity.gridtitle);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(getApplicationContext().getResources().getString(R.string.favsaveimage));
            stringBuilder2.append("  ");
            stringBuilder2.append(MainActivity.gridtitle);
            Log.e("Flurry", stringBuilder2.toString());
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        String str = "rateagain";
        if (this.sharedPreferences.getInt(str, 8) == 8) {
            this.editor.putInt(str, 0);
            this.editor.commit();
            RATE_DIALOG();
            return;
        }
        super.onBackPressed();
        MainActivity.check_paused = true;
        backpressed = true;
        finish();
    }

    public void onResume() {
        super.onResume();
        checkRewarded();
    }


    public void checkRewarded() {
        String str = "lock";
        String str2 = "unlocked";
        String str3 = "dd/M/yyyy hh:mm:ss";
        try {
            String string = this.sharedPreferences.getString("date", new SimpleDateFormat(str3, Locale.ENGLISH).format(Calendar.getInstance().getTime()));
            Date time = Calendar.getInstance().getTime();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str3, Locale.ENGLISH);
            if (MainActivity.getDifference(simpleDateFormat.parse(string), simpleDateFormat.parse(simpleDateFormat.format(time))) >= 5) {
                MainActivity.isFirst = true;
                this.editor.putBoolean(str2, false);
                this.editor.putBoolean(str, true);
                this.editor.commit();
                RecyclerAdapter recyclerAdapter = new RecyclerAdapter(this, getApplicationContext(), this.favid, this.favmsg, this.favimg, this.favfav, this.catList, this.urlList, this);
                this.recyclerview.setAdapter(this.Radapter);
                this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            }
        } catch (ParseException unused) {
        }
        if (MainActivity.unlocked.booleanValue() && this.sharedPreferences.getBoolean(str2, false)) {
            Intent intent = new Intent(this, GreetingActivity.class);
            intent.putExtra(NotificationCompat.CATEGORY_MESSAGE, greeting);
            intent.putExtra("source", "FavoriteActivity");
            startActivity(intent);
            MainActivity.unlocked = Boolean.valueOf(false);
            lockCounter = 0;
            this.Radapter = new RecyclerAdapter(this, getApplicationContext(), this.favid, this.favmsg, this.favimg, this.favfav, this.catList, this.urlList, this.activity);
            this.recyclerview.setAdapter(this.Radapter);
            this.recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            this.editor.putInt("lockcounter", 0);
            this.editor.putBoolean(str, false);
            this.editor.commit();
            Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.unlocked), Toast.LENGTH_LONG).show();
        }
    }


    public void AddRateClicks() {
        String str = "rateagain";
        if (this.sharedPreferences.getInt(str, 8) < 8) {
            int i = this.sharedPreferences.getInt(str, 8) + 1;
            this.editor.putInt(str, i);
            this.editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
            Log.e("clicks ", stringBuilder.toString());
        }
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = (TextView) this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        Button button = (Button) this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = (Button) this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                FavoriteActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                FavoriteActivity.this.finish();
                FavoriteActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                FavoriteActivity.this.finish();
                FavoriteActivity.this.dialogR.cancel();
            }
        });
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
