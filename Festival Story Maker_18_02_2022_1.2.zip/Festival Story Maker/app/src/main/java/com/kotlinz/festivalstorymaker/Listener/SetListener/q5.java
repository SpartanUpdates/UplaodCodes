package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class q5 implements View.OnTouchListener {
    public final GestureDetector e;
    public final TextView f;
    public final FrameEditorNewDesign g;

    public q5(final FrameEditorNewDesign g, final GestureDetector e, final TextView f) {
        this.g = g;
        this.e = e;
        this.f = f;
    }

    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        if (this.e.onTouchEvent(motionEvent)) {
            return true;
        }
        final FrameEditorNewDesign g = this.g;
        if (!g.d1) {
            if (this.f.getBackground() != null) {
                final int actionMasked = motionEvent.getActionMasked();
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked == 2) {
                            this.g.scroll.requestDisallowInterceptTouchEvent(true);
                            view.setY(motionEvent.getRawY() + this.g.g1);
                            view.setX(motionEvent.getRawX() + this.g.f1);
                            return true;
                        }
                        if (actionMasked != 6) {
                            return false;
                        }
                    }
                    this.f.setBackground((Drawable) null);
                    return true;
                }
                this.g.scroll.requestDisallowInterceptTouchEvent(true);
                this.g.f1 = view.getX() - motionEvent.getRawX();
                this.g.g1 = view.getY() - motionEvent.getRawY();
            }
            return true;
        }
        return g.d1 = false;
    }
}
