package com.kotlinz.festivalstorymaker.Listener.festival;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class c5 implements View.OnTouchListener
{
    public final  GestureDetector n;
    public final  FestivalDetailActivity_New o;

    public c5(final FestivalDetailActivity_New o, final GestureDetector n) {
        this.o = o;
        this.n = n;
    }

    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        this.n.onTouchEvent(motionEvent);
        return true;
    }
}
