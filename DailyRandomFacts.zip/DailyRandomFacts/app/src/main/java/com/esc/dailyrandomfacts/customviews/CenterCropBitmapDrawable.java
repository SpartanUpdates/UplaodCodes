package com.esc.dailyrandomfacts.customviews;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;

public class CenterCropBitmapDrawable extends BitmapDrawable {
    private final int viewHeight;
    private final int viewWidth;

    public CenterCropBitmapDrawable(Resources resources, Bitmap bitmap, int i, int i2) {
        super(resources, bitmap);
        this.viewWidth = i;
        this.viewHeight = i2;
    }

    public void draw(Canvas canvas) {
        float f;
        float f2;
        float f3;
        Matrix matrix = new Matrix();
        int intrinsicWidth = getIntrinsicWidth();
        int intrinsicHeight = getIntrinsicHeight();
        int i = this.viewWidth;
        int i2 = this.viewHeight;
        int saveCount = canvas.getSaveCount();
        canvas.save();
        if (intrinsicWidth * i2 > i * intrinsicHeight) {
            f = ((float) i2) / ((float) intrinsicHeight);
            f2 = (((float) i) - (((float) intrinsicWidth) * f)) * 0.8f;
            f3 = 0.0f;
        } else {
            float f4 = ((float) i) / ((float) intrinsicWidth);
            f3 = (((float) i2) - (((float) intrinsicHeight) * f4)) * 0.8f;
            f = f4;
            f2 = 0.0f;
        }
        matrix.setScale(f, f);
        matrix.postTranslate((float) Math.round(f2), (float) Math.round(f3));
        canvas.concat(matrix);
        canvas.drawBitmap(getBitmap(), 0.0f, 0.0f, getPaint());
        canvas.restoreToCount(saveCount);
    }
}
