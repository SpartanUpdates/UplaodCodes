package com.esc.mynameringtonemaker.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.esc.mynameringtonemaker.Common.ItemClickListener;
import com.esc.mynameringtonemaker.R;
import java.util.ArrayList;

public class PrefixPostfixAdapter extends Adapter<ViewHolder> {
    private int ITEM_DATA = 0;
    private Activity activity;
    private ItemClickListener itemClickListener;
    private ArrayList<String> list;

    public class ItemHolder extends ViewHolder {
        private TextView tvName;
        private View viewDivider;

        public ItemHolder(View view) {
            super(view);
            this.tvName = (TextView) view.findViewById(R.id.tvName);
            this.viewDivider = view.findViewById(R.id.viewDivider);
        }
    }

    public PrefixPostfixAdapter(Activity activity, ArrayList<String> arrayList, ItemClickListener itemClickListener) {
        this.activity = activity;
        this.list = arrayList;
        this.itemClickListener = itemClickListener;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return i == this.ITEM_DATA ? new ItemHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_prefix_postfix, viewGroup, false)) : null;
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str = (String) this.list.get(i);
        if (getItemViewType(i) == this.ITEM_DATA) {
            ItemHolder itemHolder = (ItemHolder) viewHolder;
            itemHolder.tvName.setText(str);
            if (i == this.list.size() - 1) {
                itemHolder.viewDivider.setVisibility(View.GONE);
            }
            itemHolder.tvName.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    PrefixPostfixAdapter.this.itemClickListener.onItemClick(view, i);
                }
            });
        }
    }

    public int getItemCount() {
        return this.list.size();
    }

    public int getItemViewType(int i) {
        return this.ITEM_DATA;
    }
}
