package com.name.nameart.ThropicalData;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;
import com.name.nameart.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.os.Build.VERSION_CODES.Q;

public class LauncherScreen extends AppCompatActivity {
    private static final int REQ_CODE_PERMISSOINS = 111;
    private LottieAnimationView animationView;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);

        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.launch_screen);

        if (VERSION.SDK_INT >= 23) {
            checkMultiplePermissions();
        } else {
            callfordata();
        }
    }

    private void checkMultiplePermissions() {
        if (VERSION.SDK_INT >= 23) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            if (!addPermission(arrayList2, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                arrayList.add("Read Storage");
            }
            if (!addPermission(arrayList2, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            {
                arrayList.add("Write Storage");
            }
            if (arrayList2.size() > 0) {
                requestPermissions((String[]) arrayList2.toArray(new String[arrayList2.size()]), 111);
                return;
            }
            callfordata();
        }
    }

    private boolean addPermission(List<String> list, String str) {
        if (VERSION.SDK_INT >= 23 && checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
            list.add(str);
            if (!shouldShowRequestPermissionRationale(str)) {
                return false;
            }
        }
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 111) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        HashMap hashMap = new HashMap();
        int i2 = 0;
        String str = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        hashMap.put(str, Integer.valueOf(0));
        String str2 =Manifest.permission.READ_EXTERNAL_STORAGE;
        hashMap.put(str2, Integer.valueOf(0));

        while (i2 < strArr.length)
        {
            hashMap.put(strArr[i2], Integer.valueOf(iArr[i2]));
            i2++;
        }
        if (((Integer) hashMap.get(str2)).intValue() == 0 && ((Integer) hashMap.get(str)).intValue() == 0) {
            callfordata();
        } else if (VERSION.SDK_INT >= 23) {
            Toast.makeText(getApplicationContext(), "My App cannot run without Storage Permissions.\nRelaunch My App or allow permissions in Applications Settings", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void callfordata()
    {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                LauncherScreen.this.HomeScreen();
            }
        }, 5000);
    }

    private void HomeScreen() {
        startActivity(new Intent(this, ThropicalStart.class));
        finish();
    }

}
