package com.kotlinz.festivalstorymaker.Models;

import java.io.Serializable;

public class n implements Serializable {
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public boolean l;
}
