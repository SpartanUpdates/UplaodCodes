package com.esc.storymaker.models;

public class SliderModel {
    private String ImagePath;


    public SliderModel(String imagePath) {
        ImagePath = imagePath;
    }

    public String getImagePath() {
        return ImagePath;
    }

    public void setImagePath(String imagePath) {
        ImagePath = imagePath;
    }


}
