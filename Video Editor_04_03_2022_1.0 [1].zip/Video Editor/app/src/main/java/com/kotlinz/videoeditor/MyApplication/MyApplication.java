package com.kotlinz.videoeditor.MyApplication;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.kotlinz.videoCollage.SelectActivity;
import com.kotlinz.videoeditor.Model.VideoModel;
import com.kotlinz.videoeditor.OpenAppAds.AppOpenAdManager;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.Utils.FileUtils;
import com.kotlinz.videoeditor.activity.MyCreationActivity;
import com.kotlinz.videoeditor.activity.StartActivity;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.activity.VideoSelectActivity;
import com.kotlinz.videoeditor.editvideo.activity.EditActivity;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.ArrayList;
import java.util.HashMap;

public class MyApplication extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {


    private static MyApplication instance;
    public static Context mContext;


    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public static Activity activity;

    public static InterstitialAd mInterstitialAd;
    public static int AdsId;
    public static int isShowAd = 0;

    public final ArrayList<VideoModel> selectedVideo;

    public HashMap<String, ArrayList<VideoModel>> allAlbum;
    private ArrayList<String> allFolder;
    private String selectedFolderId;

    public String VideoFileName;
    public String VideoFileNameRotate;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        mContext = this;
        this.registerActivityLifecycleCallbacks(this);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        appOpenAdManager = new AppOpenAdManager();
        interstitialAd();
    }
    public void KeepScreenOn(Activity activity){
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void interstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.InterstitialAd_id), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {
                                        requestNewInterstitial();
                                        switch (AdsId) {
                                            case 1:
                                                Intent intent = new Intent(activity, VideoSelectActivity.class);
                                                intent.putExtra("IsVideoFrom", "Single");
                                                activity.startActivity(intent);
                                                activity.finish();
                                                break;
                                            case 2:
                                                Intent intentMerge = new Intent(activity, VideoSelectActivity.class);
                                                intentMerge.putExtra("IsVideoFrom", "MergeVideo");
                                                activity.startActivity(intentMerge);
                                                activity.finish();
                                                break;
                                            case 3:
                                                activity.startActivity(new Intent(activity, SelectActivity.class));
                                                activity.finish();
                                                break;
                                            case 4:
                                                activity.startActivity(new Intent(activity, StartActivity.class));
                                                activity.finish();
                                                break;
                                            case 5:
                                                Intent intentMyCreation = new Intent(activity, MyCreationActivity.class);
                                                activity.startActivity(intentMyCreation);
                                                activity.finish();
                                                break;
                                            case 6:
                                                activity.startActivity(new Intent(activity, StartActivity.class));
                                                activity.finish();
                                                break;
                                            case 7:
                                                activity.startActivity(new Intent(activity, StartActivity.class));
                                                activity.finish();
                                                break;
                                            case 8:
                                                activity.startActivity(new Intent(activity, StartActivity.class));
                                                activity.finish();
                                                break;
                                            case 9:
                                                Intent intentEdit = new Intent(activity, EditActivity.class);
                                                intentEdit.putExtra("videofilename", VideoFileName);
                                                activity.startActivity(intentEdit);
                                                activity.finish();
                                                break;
                                            case 10:
                                                Intent intentPreview = new Intent(activity, TrimVideoPrivewActivity.class);
                                                intentPreview.putExtra("videofilename", VideoFileNameRotate);
                                                activity.startActivity(intentPreview);
                                                activity.finish();
                                                break;
                                            case 11:
                                                activity.startActivity(new Intent(activity, StartActivity.class));
                                                activity.finish();
                                                break;

                                        }
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    }
                });

    }

    private void requestNewInterstitial() {
        interstitialAd();
    }

    public MyApplication() {
        selectedVideo = new ArrayList<VideoModel>();
    }

    public static synchronized MyApplication getInstance() {
        MyApplication myApplication;
        synchronized (MyApplication.class) {
            myApplication = instance;
        }
        return myApplication;
    }

    public void init() {
        this.getFolderList();
    }


    public String getSelectedFolderId() {
        return this.selectedFolderId;
    }

    public void setSelectedFolderId(final String selectedFolderId) {
        this.selectedFolderId = selectedFolderId;
    }

    public HashMap<String, ArrayList<VideoModel>> getAllAlbum() {
        return this.allAlbum;
    }

    public ArrayList<VideoModel> getImageByAlbum(final String folderId) {
        ArrayList<VideoModel> imageDatas = this.getAllAlbum().get(folderId);
        if (imageDatas == null) {
            imageDatas = new ArrayList<VideoModel>();
        }
        return imageDatas;
    }

    public ArrayList<VideoModel> getSelectedVideo() {
        return this.selectedVideo;
    }

    public void addSelectedImage(final VideoModel imageData) {
        this.selectedVideo.add(imageData);
        ++imageData.imageCount;
    }

    public void removeSelectedImage(final VideoModel imageData) {
        this.selectedVideo.remove(imageData);
        --imageData.imageCount;
    }

    public void ReplaceSelectedImage(VideoModel imageData, int pos) {
        this.selectedVideo.set(pos, imageData);
    }

    public void getFolderList() {
        this.allFolder = new ArrayList<String>();
        this.allAlbum = new HashMap<String, ArrayList<VideoModel>>();
        final String[] projection = {"_data", "_id", "bucket_display_name", "bucket_id", "datetaken", "duration", "_data"};
        final Uri images = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        final String orderBy = "_data";
        final Cursor cur = this.getContentResolver().query(images, projection, (String) null, (String[]) null, "_data DESC");
        if (cur.moveToFirst()) {
            final int bucketColumnName = cur.getColumnIndex("bucket_display_name");
            final int bucketIdColumnId = cur.getColumnIndex("bucket_id");
            VideoModel data = null;
            setSelectedFolderId(cur.getString(bucketIdColumnId));
            do {
                data = new VideoModel();
                data.imagePath = cur.getString(cur.getColumnIndex("_data"));
                data.imageThumbnail = cur.getString(cur.getColumnIndex("_data"));
                String string6 = cur.getString(cur.getColumnIndex(projection[5]));
                if (string6 == null) {
                    string6 = null;
                } else if (!string6.contains(":")) {
                    string6 = FileUtils.makeShortTimeString( Long.parseLong(string6) / 1000);
                }
                if (string6 != null) {
                    data.setVideoDuration(string6);
                    Log.e("TAG", "Video Duration" +data.getVideoDuration());
                }

                if (!data.imagePath.endsWith(".gif")) {
                    final String folderName = cur.getString(bucketColumnName);
                    final String folderId = cur.getString(bucketIdColumnId);
                    if (!allFolder.contains(folderId)) {
                        allFolder.add(folderId);
                    }
                    ArrayList<VideoModel> imagePath = allAlbum.get(folderName);
                    if (imagePath == null) {
                        imagePath = new ArrayList<VideoModel>();
                    }
                    data.folderName = folderName;
                    imagePath.add(data);
                    allAlbum.put(folderName, imagePath);
                }
            } while (cur.moveToNext());
        }
    }


    /*AppOpenAds Start*/
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    protected void onMoveToForeground() {
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    /**
     * Shows an app open ad.
     *
     * @param activity                 the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete
     * (i.e. dismissed or fails to show).
     */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    /*AppOpenAds End*/

}
