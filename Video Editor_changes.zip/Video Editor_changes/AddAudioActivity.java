package com.kotlinz.videoeditor.videojoiner.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaScannerConnection;
import android.net.ParseException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.kotlinz.videoeditor.activity.TrimVideoPrivewActivity;
import com.kotlinz.videoeditor.view.AudioSliceSeekBar;
import com.kotlinz.videoeditor.R;
import com.kotlinz.videoeditor.activity.SelectMusicActivity;
import com.kotlinz.videoeditor.Utils.UtilCommand;
import com.kotlinz.videoeditor.view.VideoPlayerState;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar;
import com.kotlinz.videoeditor.view.VideoSliceSeekBar.SeekBarChangeListener;
import com.kotlinz.videoeditor.audiovideomixer.Utils.AddAudio;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;
import static com.kotlinz.videoeditor.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;


@SuppressLint({"WrongConstant"})
public class AddAudioActivity extends AppCompatActivity {

    Activity activity = AddAudioActivity.this;
    static AudioSliceSeekBar a = null;
    static LinearLayout b = null;
    static MediaPlayer d = null;
    static Boolean e = Boolean.valueOf(false);
    static ImageView play = null;
    static VideoSliceSeekBar g = null;
    static VideoView videoView = null;
    static final boolean BOOLEAN = true;

    public static TextView textView;

    public static a r = new a();
    ImageView j;
    Context k;
    String l;
    ProgressDialog m = null;
    Uri n;

    public TextView s;

    public TextView t;

    ImageView ivSelectAudio;

    public TextView u;

    public VideoPlayerState videoPlayerState = new VideoPlayerState();

    ImageView ivback, ivDone;

    private NativeAd nativeAd;

    private static class a extends Handler {
        private boolean a;
        private final Runnable b;

        private a() {
            this.a = false;
            this.b = new Runnable() {
                public void run() {
                    AddAudioActivity.a.this.a();
                }
            };
        }


        public void a() {
            if (!this.a) {
                this.a = AddAudioActivity.BOOLEAN;
                sendEmptyMessage(0);
            }
        }

        @Override
        public void handleMessage(Message message) {
            this.a = false;
            g.videoPlayingProgress(videoView.getCurrentPosition());
            if (d != null && AddAudioActivity.d.isPlaying()) {
                try {
                    AddAudioActivity.a.videoPlayingProgress(AddAudioActivity.d.getCurrentPosition());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (!videoView.isPlaying() || videoView.getCurrentPosition() >= AddAudioActivity.g.getRightProgress()) {
                try {
                    if (videoView.isPlaying()) {
                        try {
                            videoView.pause();
                            e = Boolean.valueOf(false);
                        } catch (OutOfMemoryError e2) {
                            e2.printStackTrace();
                        } catch (ArrayIndexOutOfBoundsException e3) {
                            e3.printStackTrace();
                        } catch (ActivityNotFoundException e4) {
                            e4.printStackTrace();
                        } catch (NotFoundException e5) {
                            e5.printStackTrace();
                        } catch (NullPointerException e6) {
                            e6.printStackTrace();
                        } catch (StackOverflowError e7) {
                            e7.printStackTrace();
                        }
                    }
                    g.setSliceBlocked(false);
                    g.removeVideoStatusThumb();
                    if (d != null && d.isPlaying()) {
                        try {
                            AddAudioActivity.d.pause();
                            AddAudioActivity.a.setSliceBlocked(false);
                            AddAudioActivity.a.removeVideoStatusThumb();
                            return;
                        } catch (IllegalStateException e8) {
                            e8.printStackTrace();
                        }
                    }
                    return;
                } catch (IllegalStateException e9) {
                    e9.printStackTrace();
                }
            }
            postDelayed(b, 50);
        }
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.audiovideomixeractivity);
        PutAnalyticsEvent();
        LoadNativeAds();
        AddAudio.status = 0;
        AddAudio.audioPath = "";
        e = Boolean.valueOf(false);
        this.k = this;
        ivback = findViewById(R.id.iv_back);
        ivDone = findViewById(R.id.iv_done);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        ivDone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                AddAudio();
            }
        });
        b = findViewById(R.id.lnr_audio_select);
        ivSelectAudio = findViewById(R.id.iv_selectaudio);
        g();
        Object lastNonConfigurationInstance = getLastNonConfigurationInstance();
        if (lastNonConfigurationInstance != null) {
            try {
                this.videoPlayerState = (VideoPlayerState) lastNonConfigurationInstance;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                Bundle extras = getIntent().getExtras();
                this.videoPlayerState.setFilename(extras.getString("song"));
                extras.getString("song").split("/");
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        h();
        ivSelectAudio.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                AddAudioActivity.this.startActivity(new Intent(activity, SelectMusicActivity.class));
            }
        });
    }

    private void AddAudio() {
        if (videoView != null && videoView.isPlaying()) {
            try {
                videoView.pause();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        if (d != null) {
            try {
                d.pause();
            } catch (IllegalStateException e4) {
                e4.printStackTrace();
            }
        }
        f();
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AddAudioActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
            @Override
            public void onNativeAdLoaded(NativeAd nativeAd) {
                boolean isDestroyed = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    isDestroyed = isDestroyed();
                }
                if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                    nativeAd.destroy();
                    return;
                }
                if (AddAudioActivity.this.nativeAd != null) {
                    AddAudioActivity.this.nativeAd.destroy();
                }
                AddAudioActivity.this.nativeAd = nativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdView(nativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {

            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void e() {
        Intent intent = new Intent(activity, TrimVideoPrivewActivity.class);
        intent.putExtra("videofilename", l);
        startActivity(intent);
        finish();
    }

    private void f() {
        String format = new SimpleDateFormat("_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb.append("/");
        sb.append(getResources().getString(R.string.MainFolderName));
        sb.append("/");
        sb.append(getResources().getString(R.string.VideoJoiner));
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsoluteFile());
        sb2.append("/");
        sb2.append(getResources().getString(R.string.MainFolderName));
        sb2.append("/");
        sb2.append(getResources().getString(R.string.VideoJoiner));
        sb2.append("/videojoiner");
        sb2.append(format);
        sb2.append(".mkv");
        l = sb2.toString();
        int duration = videoPlayerState.getDuration() / 1000;
        a(new String[]{"-y", "-ss", String.valueOf(videoPlayerState.getStart() / 1000), "-t", String.valueOf(duration), "-i", videoPlayerState.getFilename(), "-ss", String.valueOf((a != null ? a.getLeftProgress() : 0) / 1000), "-i", AddAudio.audioPath, "-map", "0:0", "-map", "1:0", "-acodec", "copy", "-vcodec", "copy", "-preset", "ultrafast", "-ss", "0", "-t", String.valueOf(duration), l}, l);
    }

    private void a(String[] strArr, final String str) {
        m = new ProgressDialog(k);
        m.setMessage("Adding Audio...");
        m.setCancelable(false);
        m.setIndeterminate(BOOLEAN);
        m.show();
        String ffmpegCommand = UtilCommand.main(strArr);
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {

            @Override
            public void apply(final long executionId, final int returnCode) {
                m.dismiss();
                if (returnCode == RETURN_CODE_SUCCESS) {
                    if (m != null && m.isShowing()) {
                        m.dismiss();
                    }
                    MediaScannerConnection.scanFile(k, new String[]{l}, new String[]{"mkv"}, null);
                    File file = new File(videoPlayerState.getFilename());
                    if (file.exists()) {
                        file.delete();
                        try {
                            ContentResolver contentResolver = AddAudioActivity.this.getContentResolver();
                            Uri uri = AddAudioActivity.this.n;
                            StringBuilder sb = new StringBuilder();
                            sb.append("_data=\"");
                            sb.append(videoPlayerState.getFilename());
                            sb.append("\"");
                            contentResolver.delete(uri, sb.toString(), null);
                        } catch (Exception unused) {
                            unused.printStackTrace();
                        }
                    }
                    MediaScannerConnection.scanFile(k, new String[]{AddAudioActivity.this.videoPlayerState.getFilename()}, new String[]{"mkv"}, null);
                    e();
                    refreshGallery(str);
                } else if (returnCode == RETURN_CODE_CANCEL) {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Error Creating Video", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                } else {
                    try {
                        new File(str).delete();
                        deleteFromGallery(str);
                        Toast.makeText(activity, "Select Audio First", Toast.LENGTH_SHORT).show();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        });
        getWindow().clearFlags(16);
    }

    private void g() {
        this.s = findViewById(R.id.left_pointer);
        this.u = findViewById(R.id.right_pointer);
        a = findViewById(R.id.audioSeekBar);
        g = findViewById(R.id.seekbar3);
        videoView = findViewById(R.id.videoView1);
        this.j = findViewById(R.id.ivScreen);
        play = findViewById(R.id.btnPlayVideo);
        this.t = findViewById(R.id.tvStartAudio);
        textView = findViewById(R.id.tvEndAudio);
    }

    private void h() {
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(final MediaPlayer mediaPlayer) {
                AddAudioActivity.g.setSeekBarChangeListener(new SeekBarChangeListener() {
                    public void SeekBarValueChanged(int i, int i2) {
                        if (g.getSelectedThumb() == 1) {
                            videoView.seekTo(g.getLeftProgress());
                        }
                        s.setText(AddAudioActivity.formatTimeUnit(i, AddAudioActivity.BOOLEAN));
                        u.setText(AddAudioActivity.formatTimeUnit(i2, AddAudioActivity.BOOLEAN));
                        videoPlayerState.setStart(i);
                        videoPlayerState.setStop(i2);
                        if (d != null && d.isPlaying()) {
                            try {
                                d.seekTo(a.getLeftProgress());
                                a.videoPlayingProgress(AddAudioActivity.a.getLeftProgress());
                                d.start();
                            } catch (IllegalStateException ewq) {
                                ewq.printStackTrace();
                            }
                        }
                        mediaPlayer.setVolume(0.0f, 0.0f);
                    }
                });
                g.setMaxValue(mediaPlayer.getDuration());
                g.setLeftProgress(videoPlayerState.getStart());
                g.setRightProgress(videoPlayerState.getStop());
                g.setProgressMinDiff(0);
                videoView.seekTo(100);
            }
        });
        videoView.setVideoPath(this.videoPlayerState.getFilename());
        play.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (d != null) {
                    try {
                        d.start();
                    } catch (IllegalStateException ewqe) {
                        ewqe.printStackTrace();
                    }
                }
                if (e.booleanValue()) {
                    try {
                        play.setBackgroundResource(R.drawable.ic_play_upress);
                        e = Boolean.valueOf(false);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                } else {
                    try {
                        play.setBackgroundResource(R.drawable.ic_pause_unpresss);
                        e = Boolean.valueOf(AddAudioActivity.BOOLEAN);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                i();
            }
        });
        videoView.setOnCompletionListener(new OnCompletionListener() {
            public void onCompletion(MediaPlayer mediaPlayer) {
                videoView.seekTo(0);
                play.setBackgroundResource(R.drawable.ic_play_upress);
            }
        });
    }

    public void i() {
        if (videoView.isPlaying()) {
            try {
                videoView.pause();
                g.setSliceBlocked(BOOLEAN);
                g.removeVideoStatusThumb();
                if (d != null && d.isPlaying()) {
                    d.pause();
                    return;
                }
                return;
            } catch (IllegalStateException e3) {
                e3.printStackTrace();
            }
        }
        videoView.seekTo(g.getLeftProgress());
        videoView.start();
        g.videoPlayingProgress(g.getLeftProgress());
        r.a();
        if (d != null && d.isPlaying()) {
            try {
                d.seekTo(a.getLeftProgress());
                a.videoPlayingProgress(a.getLeftProgress());
                d.start();
            } catch (IllegalStateException e4) {
                e4.printStackTrace();
            }
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        try {
            if (AddAudio.status == 1) {
                d = new MediaPlayer();
                play.setBackgroundResource(R.drawable.ic_play_upress);
                e = Boolean.valueOf(false);
                h();
                b.setVisibility(0);
                try {
                    String[] split = AddAudio.audioPath.split("/");
                    d.setDataSource(AddAudio.audioPath);
                    d.prepare();
                } catch (IllegalArgumentException e2) {
                    e2.printStackTrace();
                } catch (SecurityException e3) {
                    e3.printStackTrace();
                } catch (IllegalStateException e4) {
                    e4.printStackTrace();
                } catch (IOException e5) {
                    e5.printStackTrace();
                }
                d.setOnPreparedListener(new OnPreparedListener() {
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        a.setSeekBarChangeListener(new AudioSliceSeekBar.SeekBarChangeListener() {
                            public void SeekBarValueChanged(int i, int i2) {
                                if (a.getSelectedThumb() == 1) {
                                    d.seekTo(AddAudioActivity.a.getLeftProgress());
                                }
                                t.setText(formatTimeUnit(i, BOOLEAN));
                                textView.setText(AddAudioActivity.formatTimeUnit(i2, BOOLEAN));
                                if (videoView != null && videoView.isPlaying()) {
                                    videoView.seekTo(g.getLeftProgress());
                                    videoView.start();
                                    g.videoPlayingProgress(g.getLeftProgress());
                                    r.a();
                                }
                            }
                        });
                        a.setMaxValue(mediaPlayer.getDuration());
                        a.setLeftProgress(0);
                        a.setRightProgress(mediaPlayer.getDuration());
                        a.setProgressMinDiff(0);
                        t.setText("00:00");
                        try {
                            textView.setText(AddAudioActivity.formatTimeUnit1(mediaPlayer.getDuration()));
                        } catch (Exception sde) {
                            sde.printStackTrace();
                        }
                    }
                });
                d.setOnErrorListener(new OnErrorListener() {
                    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                        return AddAudioActivity.BOOLEAN;
                    }
                });
                return;
            }
            play.setBackgroundResource(R.drawable.ic_play_upress);
            e = Boolean.valueOf(false);
            AddAudio.status = 0;
            AddAudio.audioPath = "";
            b.setVisibility(8);
        } catch (Exception unused) {
        }
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit1(long j2) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    @SuppressLint({"NewApi"})
    public static String formatTimeUnit(long j2, boolean z) throws ParseException {
        return String.format("%02d:%02d", Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(j2)), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j2) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j2))));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        AddAudio.status = 0;
        AddAudio.audioPath = "";
        if (d != null && d.isPlaying()) {
            d.stop();
            d.release();
            d = null;
        }
    }

    @SuppressLint("ResourceType")
    public void k() {
        new AlertDialog.Builder(this).setTitle("Device not supported").setMessage("FFmpeg is not supported on your device").setCancelable(false).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                AddAudioActivity.this.finish();
            }
        }).create().show();
    }

    public void deleteFromGallery(String str) {
        String[] strArr = {"_id"};
        String[] strArr2 = {str};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        Cursor query = contentResolver.query(uri, strArr, "_data = ?", strArr2, null);
        if (query.moveToFirst()) {
            try {
                contentResolver.delete(ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndexOrThrow("_id"))), null, null);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
            }
        } else {
            try {
                new File(str).delete();
                refreshGallery(str);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        query.close();
    }

    public void refreshGallery(String str) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(Uri.fromFile(new File(str)));
        sendBroadcast(intent);
    }
}
