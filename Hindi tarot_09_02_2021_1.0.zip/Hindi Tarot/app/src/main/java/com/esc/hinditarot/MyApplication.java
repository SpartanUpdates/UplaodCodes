package com.esc.hinditarot;

import android.app.Application;
import android.content.Context;


public class MyApplication extends Application {

    public void onCreate() {
        super.onCreate();
    }
}
