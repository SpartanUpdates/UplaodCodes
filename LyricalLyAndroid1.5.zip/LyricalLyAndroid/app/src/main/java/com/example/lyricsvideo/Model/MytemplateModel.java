package com.example.lyricsvideo.Model;

public class MytemplateModel {

    private String VideoName;
    private String SmallThemeImage;
    private String PreviewVideoUrl;
    private int NoOfImages;
    private String ContentZipFolderName;

    public String getVideoName() {
        return VideoName;
    }

    public void setVideoName(String videoName) {
        VideoName = videoName;
    }

    public String getSmallThemeImage() {
        return SmallThemeImage;
    }

    public void setSmallThemeImage(String smallThemeImage) {
        SmallThemeImage = smallThemeImage;
    }

    public String getPreviewVideoUrl() {
        return PreviewVideoUrl;
    }

    public void setPreviewVideoUrl(String previewVideoUrl) {
        PreviewVideoUrl = previewVideoUrl;
    }

    public int getNoOfImages() {
        return NoOfImages;
    }

    public void setNoOfImages(int noOfImages) {
        NoOfImages = noOfImages;
    }

    public String getContentZipFolderName() {
        return ContentZipFolderName;
    }

    public void setContentZipFolderName(String contentZipFolderName) {
        ContentZipFolderName = contentZipFolderName;
    }
}
