package game.kidspop.gk.quiz.info;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;

public class HomeActivity extends AppCompatActivity {
    Activity activity = HomeActivity.this;
    String PlayerDefaultName = "Player";
    TextView buttonAppPrivacy;
    Button buttonHighScore;
    TextView buttonPlayer;
    Button buttonQStart;
    TextView buttonRateUs;
    TextView buttonResetQueFlags;
    TextView buttonShareApp;
    private NativeBannerAd nativeBannerAd;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getSupportActionBar().hide();
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_home);
        this.ePreferences = EPreferences.getInstance((Context) this);
        loadAd();
        this.buttonHighScore = (Button) findViewById(R.id.ibuttonHighScore);
        this.buttonQStart = (Button) findViewById(R.id.ibuttonQStart);
        this.buttonPlayer = (TextView) findViewById(R.id.ibuttonPlayer);
        this.buttonShareApp = (TextView) findViewById(R.id.ibuttonShareApp);
        this.buttonRateUs = (TextView) findViewById(R.id.ibuttonRateUs);
        this.buttonAppPrivacy = (TextView) findViewById(R.id.ibuttonAppPrivacy);
        this.buttonResetQueFlags = (TextView) findViewById(R.id.ibuttonResetQueFlags);
        mClassUtil.setspv_CountQuizPlay(this, Integer.valueOf(0));
        mClassUtil.setspv_CountPageView(this, Integer.valueOf(1));
        if (mClassUtil.getspv_PlayerName(this) == null) {
            mClassUtil.setspv_PlayerName(this, this.PlayerDefaultName);
        }
        if (mClassUtil.getspv_QueLang(this) != null && mClassUtil.getspv_QueLang(this).toUpperCase().equals("HINDI")) {
            ((RadioButton) findViewById(R.id.irbtnHindi)).setChecked(true);
        }
        this.buttonHighScore.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd.isAdLoaded()) {
                    mInterstitialAd.show();
                } else {
                    HomeActivity.this.startActivity(new Intent(HomeActivity.this.getApplicationContext(), HighScoreActivity.class));
                }
            }
        });
        this.buttonQStart.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                mClassUtil.setspv_QueLang(HomeActivity.this, ((RadioButton) HomeActivity.this.findViewById(((RadioGroup) HomeActivity.this.findViewById(R.id.irgQueLang)).getCheckedRadioButtonId())).getText().toString());
                HomeActivity.this.startActivity(new Intent(HomeActivity.this.getApplicationContext(), QuizPlayActivity.class));
            }
        });
        mfunc_buttonPlayer_OnClickOf();
        mfunc_buttonShareApp_OnClickOf();
        mfunc_buttonRateUs_OnClickOf();
        mfunc_buttonAppPrivacy_OnClickOf();
        mfunc_buttonResetQueFlags_OnClickOf();
        String string = getString(R.string.verNameApp_now);
        String str = mClassUtil.getspv_AppVerNew(this);
        if (!str.equals(string) && !str.equals("")) {
            Snackbar.make((RelativeLayout) findViewById(R.id.relativeLayout), (CharSequence) "App new update available now.", 0).setAction((CharSequence) "Update App", new OnClickListener() {
                public void onClick(View view) {
                    HomeActivity.this.mfunc_RateApp_Procedure();
                }
            }).show();
        }
    }

    private InterstitialAd mInterstitialAd;

    private void loadAd() {
        mInterstitialAd = new InterstitialAd(activity, getResources().getString(R.string.fb_interstitial));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                HomeActivity.this.startActivity(new Intent(HomeActivity.this.getApplicationContext(), HighScoreActivity.class));
                requestNewInterstitial();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        mInterstitialAd.loadAd();
    }

    private void requestNewInterstitial() {
        mInterstitialAd = new InterstitialAd(activity, getResources().getString(R.string.fb_interstitial));
        mInterstitialAd.loadAd();
    }

    private void mfunc_buttonPlayer_OnClickOf() {
        this.buttonPlayer.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                String str = mClassUtil.getspv_PlayerName(HomeActivity.this);
                final Dialog dialog = new Dialog(HomeActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.dialog_player_name);
                final EditText editText = (EditText) dialog.findViewById(R.id.ietPlayerName);
                editText.setText(str);
                editText.setSelection(editText.getText().length());
                ((TextView) dialog.findViewById(R.id.ibtnSavePlayerName)).setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        String str = "";
                        String replace = editText.getText().toString().trim().replace("'", str);
                        if (replace.equals(str)) {
                            mClassUtil.setspv_PlayerName(HomeActivity.this, HomeActivity.this.PlayerDefaultName);
                        } else {
                            mClassUtil.setspv_PlayerName(HomeActivity.this, replace);
                        }
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }

    private void mfunc_buttonShareApp_OnClickOf() {
        this.buttonShareApp.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "KIDS QUIZ GK");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("\nDownload KIDS QUIZ GK mobile App from Play Store for children. ");
                    stringBuilder.append("This will help you in learning General Knowledge as a play.");
                    String stringBuilder2 = stringBuilder.toString();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(stringBuilder2);
                    stringBuilder.append(" You can make your kids smarter than other by using this APP.\n\n");
                    stringBuilder2 = stringBuilder.toString();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(stringBuilder2);
                    stringBuilder.append("http://play.google.com/store/apps/details?id=");
                    stringBuilder.append(HomeActivity.this.getPackageName());
                    stringBuilder.append(" \n\n");
                    intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                    HomeActivity.this.startActivity(Intent.createChooser(intent, "Select One Option"));
                } catch (Exception unused) {
                }
            }
        });
    }

    private void mfunc_buttonRateUs_OnClickOf() {
        this.buttonRateUs.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                HomeActivity.this.mfunc_RateApp_Procedure();
            }
        });
    }

    private void mfunc_buttonAppPrivacy_OnClickOf() {
        this.buttonAppPrivacy.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                try {
                    HomeActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://kidsmaniagk.blogspot.com/p/blog-page.html")));
                } catch (Exception unused) {
                }
            }
        });
    }

    private void mfunc_buttonResetQueFlags_OnClickOf() {
        this.buttonResetQueFlags.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CharSequence charSequence = "Cancel";
                new AlertDialog.Builder(HomeActivity.this).setTitle((CharSequence) "Confirm Reset Quiz").setMessage((CharSequence) "Remember : All questions played by you will come again after reset APP in next Quiz. \n\nऐप को रिसेट करने के बाद, आपके द्वारा खेले गए सभी प्रश्न अगले क्विज़ में फिर से आएंगे \n\nAre you sure to Reset App?").setPositiveButton((CharSequence) "Reset", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            if (HomeActivity.this.getDatabasePath(HomeActivity.this.getString(R.string.dbName)).exists()) {
                                SQLiteDatabase OpenSQLiteDatabase = mClassUtil.OpenSQLiteDatabase(HomeActivity.this);
                                OpenSQLiteDatabase.execSQL("Update tableKQ set SeenFlag=null");
                                OpenSQLiteDatabase.close();
                                Toast.makeText(HomeActivity.this, "Reset completed.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Toast.makeText(HomeActivity.this, "Can not reset now.", Toast.LENGTH_SHORT).show();
                        } catch (Exception unused) {
                            Toast.makeText(HomeActivity.this, "Error in Reset.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton(charSequence, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).show();
            }
        });
    }


    private void mfunc_RateApp_Procedure() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("market://details?id=");
        stringBuilder.append(getPackageName());
        String str = "android.intent.action.VIEW";
        Intent intent = new Intent(str, Uri.parse(stringBuilder.toString()));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("http://play.google.com/store/apps/details?id=");
            stringBuilder2.append(getPackageName());
            startActivity(new Intent(str, Uri.parse(stringBuilder2.toString())));
        }
    }

    EPreferences ePreferences;
//    private UnifiedNativeAd nativeAd;

    @Override
    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(HomeActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        /*AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());*/
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = dialog.findViewById(R.id.banner_container);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    ePreferences.putBoolean("pref_key_rate", true);
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(HomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        /*AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());*/
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = dialog.findViewById(R.id.banner_container);
                dialog.findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    /*private void populateUnifiedNativeAdViewDialog(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }*/
}