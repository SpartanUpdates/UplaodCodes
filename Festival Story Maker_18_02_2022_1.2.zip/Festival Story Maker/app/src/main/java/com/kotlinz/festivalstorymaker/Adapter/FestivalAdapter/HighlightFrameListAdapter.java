package com.kotlinz.festivalstorymaker.Adapter.FestivalAdapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.kotlinz.festivalstorymaker.Models.festival.k;
import com.kotlinz.festivalstorymaker.R;
import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

public class HighlightFrameListAdapter extends RecyclerView.Adapter<HighlightFrameListAdapter.MyViewHolder> {

    public Activity p;
    public ArrayList<k> q;
    public a r;
    public int s;

    public interface a {
        void a(int i, int i2);
    }

    public HighlightFrameListAdapter(Activity activity, ArrayList<k> arrayList, a aVar, int i) {
        this.p = activity;
        this.q = arrayList;
        this.r = aVar;
        this.s = i;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_highlight_bg_list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.imgLock.setVisibility(View.GONE);
        if (((k) this.q.get(position)).p.length() > 0) {
            Glide.with(p).load(q.get(position).p).placeholder(R.drawable.progress).into(holder.img);
        }
        holder.img.setOnClickListener(new com.kotlinz.festivalstorymaker.Listener.festival.o(this, position));

    }

    @Override
    public int getItemCount() {
        return q.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.imgBg)
        public ImageView img;
        @BindView(R.id.imgLock)
        public ImageView imgLock;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
