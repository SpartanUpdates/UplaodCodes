package com.esc.beautymackupselficlam.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.beautymackupselficlam.R;
import com.esc.beautymackupselficlam.collage.CollageTouchImageView;
import com.esc.beautymackupselficlam.collage.GallerySelection;
import com.esc.beautymackupselficlam.kprogresshud.KProgressHUD;
import com.esc.beautymackupselficlam.library.MultiTouchListener;
import com.esc.beautymackupselficlam.utils.CustomStckerTextView;
import com.esc.beautymackupselficlam.utils.CustomTextView;
import com.esc.beautymackupselficlam.utils.FontStyleAdapter;
import com.esc.beautymackupselficlam.utils.StickerAdapter;
import com.esc.beautymackupselficlam.utils.StickerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CollagePhotoEdiotrActivity extends Activity implements OnClickListener {
    private static final String IMAGE_DIRECTORY_NAME = "SweetSelfie";
    public static int int_adz_num = 0;
    private Bitmap bitmap_five;
    private Bitmap bitmap_four;
    private Bitmap bitmap_one;
    private Bitmap bitmap_six;
    private Bitmap bitmap_three;
    private Bitmap bitmap_two;
    private ImageView Imgbtn_eight;
    private ImageView Imgbtn_five;
    private ImageView Imgbtn_four;
    private LinearLayout ll_collagely;
    private ImageView Imgbtn_nine;
    private ImageView Imgbtn_one;
    private LinearLayout ll_save;
    private ImageView Imgbtn_seven;
    private ImageView Imgbtn_six;
    private LinearLayout ll_Stickers;
    private ImageView Imgbtn_ten;
    private LinearLayout ll_text;
    private ImageView Imgbtn_three;
    private ImageView Imgbtn_two;
    public static Uri contentUri;
    private Dialog dialog;
    private ImageView img_con_1;
    private ImageView img_con_10;
    private ImageView img_con_11;
    private ImageView img_con_12;
    private ImageView img_con_13;
    private ImageView img_con_14;
    private ImageView img_con_15;
    private ImageView img_con_16;
    private ImageView img_con_17;
    private ImageView img_con_18;
    private ImageView img_con_19;
    private ImageView img_con_2;
    private ImageView img_con_20;
    private ImageView img_con_3;
    private ImageView img_con_4;
    private ImageView img_con_5;
    private ImageView img_con_6;
    private ImageView img_con_7;
    private ImageView img_con_8;
    private ImageView img_con_9;
    private ImageView img_control_text;
    private ImageView img_em_1;
    private ImageView img_em_10;
    private ImageView img_em_11;
    private ImageView img_em_12;
    private ImageView img_em_13;
    private ImageView img_em_14;
    private ImageView img_em_15;
    private ImageView img_em_16;
    private ImageView img_em_17;
    private ImageView img_em_18;
    private ImageView img_em_19;
    private ImageView img_em_2;
    private ImageView img_em_20;
    private ImageView img_em_3;
    private ImageView img_em_4;
    private ImageView img_em_5;
    private ImageView img_em_6;
    private ImageView img_em_7;
    private ImageView img_em_8;
    private ImageView img_em_9;
    private int int_backPress = 0;
    private int int_photo_size = 3;
    private LinearLayout ll_collage;
    private LinearLayout ll_main;
    private LinearLayout ll_stickers;
    private View view3_eight;
    private View view3_five;
    private View view3_four;
    private View view3_nine;
    private View view3_one;
    private View view3_seven;
    private View view3_six;
    private View view3_ten;
    private View view3_three;
    private View view3_two;
    private View view4_eight;
    private View view4_five;
    private View view4_four;
    private View view4_nine;
    private View view4_one;
    private View view4_seven;
    private View view4_six;
    private View view4_ten;
    private View view4_three;
    private View view4_two;
    private View view5_eight;
    private View view5_five;
    private View view5_four;
    private View view5_nine;
    private View view5_one;
    private View view5_seven;
    private View view5_six;
    private View view5_ten;
    private View view5_three;
    private View view5_two;
    private View view6_eight;
    private View view6_five;
    private View view6_four;
    private View view6_nine;
    private View view6_one;
    private View view6_seven;
    private View view6_six;
    private View view6_ten;
    private View view6_three;
    private View view6_two;
    CollageTouchImageView Collageimg_two;
    CollageTouchImageView Collageimg_three;
    CollageTouchImageView Collageimg_four;
    CollageTouchImageView Collageimg_five;
    private CustomStckerTextView currentTextView;
    private StickerView currentView;
    InputMethodManager inputmethodmanager;
    GridView grid_colorlist;
    GridView grid_fontlist;
    String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
            "font4.TTF", "font5.ttf", "font6.TTF", "font9.ttf", "font11.ttf",
            "font12.ttf", "font14.TTF", "font16.TTF", "font17.ttf",
            "font20.ttf"};
    private Typeface typeface;
    private int pickedColor = -1;
    ImageView imageview_keyboard;
    ImageView imageview_fontstyle;
    ImageView imageview_color;
    ImageView imageview_gravity;
    ImageView imageview_done;
    public static Bitmap textBitmap;
    private ArrayList<View> stickers = new ArrayList();
    private int w = 0;
    public static Bitmap Bbitmap;
    public static Canvas canvas;
    private LinearLayout ll_colorlist;
    private LinearLayout ll_fontlist;
    private EditText edittext;
    private static int columnWidth = 80;
    private ArrayList<Integer> stickerlist;
    private StickerAdapter stickerAdapter;
    private ArrayList<View> views;
    RelativeLayout ll;
    private int width = 0;

    private class saves extends AsyncTask<String, Void, Boolean> {
        private saves() {
        }

        ProgressDialog mProgress;

        protected void onPreExecute() {

            this.mProgress = new ProgressDialog(CollagePhotoEdiotrActivity.this);
            this.mProgress.setIndeterminate(true);
            this.mProgress.setCancelable(true);
            this.mProgress.setMessage("Please wait...");
            this.mProgress.show();
        }

        protected Boolean doInBackground(String... args) {
            CollagePhotoEdiotrActivity.this.getScreenSnapShot();
            return Boolean.valueOf(true);
        }

        protected void onPostExecute(Boolean success) {
            id = R.id.ll_save;
            if (interstitial != null && interstitial.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                Intent i = new Intent(CollagePhotoEdiotrActivity.this, shareActivity.class);
                i.putExtra("key", 1);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }
            this.mProgress.hide();
        }
    }


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.collage_main);
        this.width = getResources().getDisplayMetrics().widthPixels;
        this.int_backPress = 0;
        int_adz_num = 0;
        loadAd();
        this.views = new ArrayList();
        BindView();
        IntiCollage();
        BottomLayout();
        emoticons_menu();
        MenuTool(this.int_photo_size);

    }

    private void BindView() {
        this.Imgbtn_one = (ImageView) findViewById(R.id.btncollage_1);
        this.Imgbtn_one.setOnClickListener(this);
        this.Imgbtn_two = (ImageView) findViewById(R.id.btncollage_2);
        ll = (RelativeLayout) findViewById(R.id.ll_menu_frame);
        this.Imgbtn_two.setOnClickListener(this);
        this.Imgbtn_three = (ImageView) findViewById(R.id.btncollage_3);
        this.Imgbtn_three.setOnClickListener(this);
        this.Imgbtn_four = (ImageView) findViewById(R.id.btncollage_4);
        this.Imgbtn_four.setOnClickListener(this);
        this.Imgbtn_five = (ImageView) findViewById(R.id.btncollage_5);
        this.Imgbtn_five.setOnClickListener(this);
        this.Imgbtn_six = (ImageView) findViewById(R.id.btncollage_6);
        this.Imgbtn_six.setOnClickListener(this);
        this.Imgbtn_seven = (ImageView) findViewById(R.id.btncollage_7);
        this.Imgbtn_seven.setOnClickListener(this);
        this.Imgbtn_eight = (ImageView) findViewById(R.id.btncollage_8);
        this.Imgbtn_eight.setOnClickListener(this);
        this.Imgbtn_nine = (ImageView) findViewById(R.id.btncollage_9);
        this.Imgbtn_nine.setOnClickListener(this);
        this.Imgbtn_ten = (ImageView) findViewById(R.id.btncollage_10);
        this.Imgbtn_ten.setOnClickListener(this);
        this.int_photo_size = GallerySelection.int_photo_size;
        this.bitmap_one = GallerySelection.bitmap_one;
        this.bitmap_two = GallerySelection.bitmap_two;
        this.bitmap_three = GallerySelection.bitmap_three;
        this.bitmap_four = GallerySelection.bitmap_four;
        this.bitmap_five = GallerySelection.bitmap_five;
        this.bitmap_six = GallerySelection.bitmap_six;
        ImageView back = (ImageView) findViewById(R.id.iv_back);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    onBackPressed();
                }
            }
        });
    }

    private void emoticons_menu() {
        this.ll_stickers = (LinearLayout) findViewById(R.id.ll_stickers);
        this.ll_collage = (LinearLayout) findViewById(R.id.ll_collage);
        this.img_em_1 = (ImageView) findViewById(R.id.control_1);
        this.img_em_1.setOnClickListener(this);
        this.img_em_2 = (ImageView) findViewById(R.id.control_2);
        this.img_em_2.setOnClickListener(this);
        this.img_em_3 = (ImageView) findViewById(R.id.control_3);
        this.img_em_3.setOnClickListener(this);
        this.img_em_4 = (ImageView) findViewById(R.id.control_4);
        this.img_em_4.setOnClickListener(this);
        this.img_em_5 = (ImageView) findViewById(R.id.control_5);
        this.img_em_5.setOnClickListener(this);
        this.img_em_6 = (ImageView) findViewById(R.id.control_6);
        this.img_em_6.setOnClickListener(this);
        this.img_em_7 = (ImageView) findViewById(R.id.control_7);
        this.img_em_7.setOnClickListener(this);
        this.img_em_8 = (ImageView) findViewById(R.id.control_8);
        this.img_em_8.setOnClickListener(this);
        this.img_em_9 = (ImageView) findViewById(R.id.control_9);
        this.img_em_9.setOnClickListener(this);
        this.img_em_10 = (ImageView) findViewById(R.id.control_10);
        this.img_em_10.setOnClickListener(this);
        this.img_em_11 = (ImageView) findViewById(R.id.control_11);
        this.img_em_11.setOnClickListener(this);
        this.img_em_12 = (ImageView) findViewById(R.id.control_12);
        this.img_em_12.setOnClickListener(this);
        this.img_em_13 = (ImageView) findViewById(R.id.control_13);
        this.img_em_13.setOnClickListener(this);
        this.img_em_14 = (ImageView) findViewById(R.id.control_14);
        this.img_em_14.setOnClickListener(this);
        this.img_em_15 = (ImageView) findViewById(R.id.control_15);
        this.img_em_15.setOnClickListener(this);
        this.img_em_16 = (ImageView) findViewById(R.id.control_16);
        this.img_em_16.setOnClickListener(this);
        this.img_em_17 = (ImageView) findViewById(R.id.control_17);
        this.img_em_17.setOnClickListener(this);
        this.img_em_18 = (ImageView) findViewById(R.id.control_18);
        this.img_em_18.setOnClickListener(this);
        this.img_em_19 = (ImageView) findViewById(R.id.control_19);
        this.img_em_19.setOnClickListener(this);
        this.img_em_20 = (ImageView) findViewById(R.id.control_20);
        this.img_em_20.setOnClickListener(this);
        this.img_con_1 = (ImageView) findViewById(R.id.img_control_1);
        this.img_con_1.setOnTouchListener(new MultiTouchListener());
        this.img_con_2 = (ImageView) findViewById(R.id.img_control_2);
        this.img_con_2.setOnTouchListener(new MultiTouchListener());
        this.img_con_3 = (ImageView) findViewById(R.id.img_control_3);
        this.img_con_3.setOnTouchListener(new MultiTouchListener());
        this.img_con_4 = (ImageView) findViewById(R.id.img_control_4);
        this.img_con_4.setOnTouchListener(new MultiTouchListener());
        this.img_con_5 = (ImageView) findViewById(R.id.img_control_5);
        this.img_con_5.setOnTouchListener(new MultiTouchListener());
        this.img_con_6 = (ImageView) findViewById(R.id.img_control_6);
        this.img_con_6.setOnTouchListener(new MultiTouchListener());
        this.img_con_7 = (ImageView) findViewById(R.id.img_control_7);
        this.img_con_7.setOnTouchListener(new MultiTouchListener());
        this.img_con_8 = (ImageView) findViewById(R.id.img_control_8);
        this.img_con_8.setOnTouchListener(new MultiTouchListener());
        this.img_con_9 = (ImageView) findViewById(R.id.img_control_9);
        this.img_con_9.setOnTouchListener(new MultiTouchListener());
        this.img_con_10 = (ImageView) findViewById(R.id.img_control_10);
        this.img_con_10.setOnTouchListener(new MultiTouchListener());
        this.img_con_11 = (ImageView) findViewById(R.id.img_control_11);
        this.img_con_11.setOnTouchListener(new MultiTouchListener());
        this.img_con_12 = (ImageView) findViewById(R.id.img_control_12);
        this.img_con_12.setOnTouchListener(new MultiTouchListener());
        this.img_con_13 = (ImageView) findViewById(R.id.img_control_13);
        this.img_con_13.setOnTouchListener(new MultiTouchListener());
        this.img_con_14 = (ImageView) findViewById(R.id.img_control_14);
        this.img_con_14.setOnTouchListener(new MultiTouchListener());
        this.img_con_15 = (ImageView) findViewById(R.id.img_control_15);
        this.img_con_15.setOnTouchListener(new MultiTouchListener());
        this.img_con_16 = (ImageView) findViewById(R.id.img_control_16);
        this.img_con_16.setOnTouchListener(new MultiTouchListener());
        this.img_con_17 = (ImageView) findViewById(R.id.img_control_17);
        this.img_con_17.setOnTouchListener(new MultiTouchListener());
        this.img_con_18 = (ImageView) findViewById(R.id.img_control_18);
        this.img_con_18.setOnTouchListener(new MultiTouchListener());
        this.img_con_19 = (ImageView) findViewById(R.id.img_control_19);
        this.img_con_19.setOnTouchListener(new MultiTouchListener());
        this.img_con_20 = (ImageView) findViewById(R.id.img_control_20);
        this.img_con_20.setOnTouchListener(new MultiTouchListener());
        this.img_control_text = (ImageView) findViewById(R.id.txt_image);
        this.img_control_text.setOnTouchListener(new MultiTouchListener());
    }

    private void BottomLayout() {
        this.ll_collagely = (LinearLayout) findViewById(R.id.btn_layout);
        this.ll_Stickers = (LinearLayout) findViewById(R.id.ll_Stickers);
        this.ll_save = (LinearLayout) findViewById(R.id.ll_save);
        this.ll_text = (LinearLayout) findViewById(R.id.ll_text);
        this.ll_collagely.setOnClickListener(this);
        this.ll_Stickers.setOnClickListener(this);
        this.ll_save.setOnClickListener(this);
        this.ll_text.setOnClickListener(this);
    }

    private void MenuTool(int int_num) {
        this.Imgbtn_one.setImageResource(0);
        this.Imgbtn_two.setImageResource(0);
        this.Imgbtn_three.setImageResource(0);
        this.Imgbtn_four.setImageResource(0);
        this.Imgbtn_five.setImageResource(0);
        this.Imgbtn_six.setImageResource(0);
        this.Imgbtn_seven.setImageResource(0);
        this.Imgbtn_eight.setImageResource(0);
        this.Imgbtn_nine.setImageResource(0);
        this.Imgbtn_ten.setImageResource(0);
        if (int_num == 3) {
            this.Imgbtn_one.setImageResource(R.drawable.collage3_1);
            this.Imgbtn_two.setImageResource(R.drawable.collage3_2);
            this.Imgbtn_three.setImageResource(R.drawable.collage3_3);
            this.Imgbtn_four.setImageResource(R.drawable.collage3_4);
            this.Imgbtn_five.setImageResource(R.drawable.collage3_5);
            this.Imgbtn_six.setImageResource(R.drawable.collage3_6);
            this.Imgbtn_seven.setImageResource(R.drawable.collage3_7);
            this.Imgbtn_eight.setImageResource(R.drawable.collage3_8);
            this.Imgbtn_nine.setImageResource(R.drawable.collage3_9);
            this.Imgbtn_ten.setImageResource(R.drawable.collage3_10);
        } else if (int_num == 4) {
            this.Imgbtn_one.setImageResource(R.drawable.collage4_1);
            this.Imgbtn_two.setImageResource(R.drawable.collage4_2);
            this.Imgbtn_three.setImageResource(R.drawable.collage4_3);
            this.Imgbtn_four.setImageResource(R.drawable.collage4_4);
            this.Imgbtn_five.setImageResource(R.drawable.collage4_5);
            this.Imgbtn_six.setImageResource(R.drawable.collage4_6);
            this.Imgbtn_seven.setImageResource(R.drawable.collage4_7);
            this.Imgbtn_eight.setImageResource(R.drawable.collage4_8);
            this.Imgbtn_nine.setImageResource(R.drawable.collage4_9);
            this.Imgbtn_ten.setImageResource(R.drawable.collage4_10);
        } else if (int_num == 5) {
            this.Imgbtn_one.setImageResource(R.drawable.collage5_1);
            this.Imgbtn_two.setImageResource(R.drawable.collage5_2);
            this.Imgbtn_three.setImageResource(R.drawable.collage5_3);
            this.Imgbtn_four.setImageResource(R.drawable.collage5_4);
            this.Imgbtn_five.setImageResource(R.drawable.collage5_5);
            this.Imgbtn_six.setImageResource(R.drawable.collage5_6);
            this.Imgbtn_seven.setImageResource(R.drawable.collage5_7);
            this.Imgbtn_eight.setImageResource(R.drawable.collage5_8);
            this.Imgbtn_nine.setImageResource(R.drawable.collage5_9);
            this.Imgbtn_ten.setImageResource(R.drawable.collage5_10);
        } else if (int_num >= 6) {
            this.Imgbtn_one.setImageResource(R.drawable.collage6_1);
            this.Imgbtn_two.setImageResource(R.drawable.collage6_2);
            this.Imgbtn_three.setImageResource(R.drawable.collage6_3);
            this.Imgbtn_four.setImageResource(R.drawable.collage6_4);
            this.Imgbtn_five.setImageResource(R.drawable.collage6_5);
            this.Imgbtn_six.setImageResource(R.drawable.collage6_6);
            this.Imgbtn_seven.setImageResource(R.drawable.collage6_7);
            this.Imgbtn_eight.setImageResource(R.drawable.collage6_8);
            this.Imgbtn_nine.setImageResource(R.drawable.collage6_9);
            this.Imgbtn_ten.setImageResource(R.drawable.collage6_10);
        }
        Collage_One(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
    }

    private void IntiCollage() {
        this.view3_one = findViewById(R.id.cs3_one);
        this.view3_two = findViewById(R.id.cs3_two);
        this.view3_three = findViewById(R.id.cs3_three);
        this.view3_four = findViewById(R.id.cs3_four);
        this.view3_five = findViewById(R.id.cs3_five);
        this.view3_six = findViewById(R.id.cs3_six);
        this.view3_seven = findViewById(R.id.cs3_seven);
        this.view3_eight = findViewById(R.id.cs3_eight);
        this.view3_nine = findViewById(R.id.cs3_nine);
        this.view3_ten = findViewById(R.id.cs3_ten);
        this.view3_one.setVisibility(View.GONE);
        this.view3_two.setVisibility(View.GONE);
        this.view3_three.setVisibility(View.GONE);
        this.view3_four.setVisibility(View.GONE);
        this.view3_five.setVisibility(View.GONE);
        this.view3_six.setVisibility(View.GONE);
        this.view3_seven.setVisibility(View.GONE);
        this.view3_eight.setVisibility(View.GONE);
        this.view3_nine.setVisibility(View.GONE);
        this.view3_ten.setVisibility(View.GONE);
        this.view4_one = findViewById(R.id.cs4_one);
        this.view4_two = findViewById(R.id.cs4_two);
        this.view4_three = findViewById(R.id.cs4_three);
        this.view4_four = findViewById(R.id.cs4_four);
        this.view4_five = findViewById(R.id.cs4_five);
        this.view4_six = findViewById(R.id.cs4_six);
        this.view4_seven = findViewById(R.id.cs4_seven);
        this.view4_eight = findViewById(R.id.cs4_eight);
        this.view4_nine = findViewById(R.id.cs4_nine);
        this.view4_ten = findViewById(R.id.cs4_ten);
        this.view4_one.setVisibility(View.GONE);
        this.view4_two.setVisibility(View.GONE);
        this.view4_three.setVisibility(View.GONE);
        this.view4_four.setVisibility(View.GONE);
        this.view4_five.setVisibility(View.GONE);
        this.view4_six.setVisibility(View.GONE);
        this.view4_seven.setVisibility(View.GONE);
        this.view4_eight.setVisibility(View.GONE);
        this.view4_nine.setVisibility(View.GONE);
        this.view4_ten.setVisibility(View.GONE);
        this.view5_one = findViewById(R.id.cs5_one);
        this.view5_two = findViewById(R.id.cs5_two);
        this.view5_three = findViewById(R.id.cs5_three);
        this.view5_four = findViewById(R.id.cs5_four);
        this.view5_five = findViewById(R.id.cs5_five);
        this.view5_six = findViewById(R.id.cs5_six);
        this.view5_seven = findViewById(R.id.cs5_seven);
        this.view5_eight = findViewById(R.id.cs5_eight);
        this.view5_nine = findViewById(R.id.cs5_nine);
        this.view5_ten = findViewById(R.id.cs5_ten);
        this.view5_one.setVisibility(View.GONE);
        this.view5_two.setVisibility(View.GONE);
        this.view5_three.setVisibility(View.GONE);
        this.view5_four.setVisibility(View.GONE);
        this.view5_five.setVisibility(View.GONE);
        this.view5_six.setVisibility(View.GONE);
        this.view5_seven.setVisibility(View.GONE);
        this.view5_eight.setVisibility(View.GONE);
        this.view5_nine.setVisibility(View.GONE);
        this.view5_ten.setVisibility(View.GONE);
        this.view6_one = findViewById(R.id.cs6_one);
        this.view6_two = findViewById(R.id.cs6_two);
        this.view6_three = findViewById(R.id.cs6_three);
        this.view6_four = findViewById(R.id.cs6_four);
        this.view6_five = findViewById(R.id.cs6_five);
        this.view6_six = findViewById(R.id.cs6_six);
        this.view6_seven = findViewById(R.id.cs6_seven);
        this.view6_eight = findViewById(R.id.cs6_eight);
        this.view6_nine = findViewById(R.id.cs6_nine);
        this.view6_ten = findViewById(R.id.cs6_ten);
        this.view6_one.setVisibility(View.GONE);
        this.view6_two.setVisibility(View.GONE);
        this.view6_three.setVisibility(View.GONE);
        this.view6_four.setVisibility(View.GONE);
        this.view6_five.setVisibility(View.GONE);
        this.view6_six.setVisibility(View.GONE);
        this.view6_seven.setVisibility(View.GONE);
        this.view6_eight.setVisibility(View.GONE);
        this.view6_nine.setVisibility(View.GONE);
        this.view6_ten.setVisibility(View.GONE);
    }

    private void ResetCollage(int int_num) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_one.setVisibility(View.GONE);
                this.view3_two.setVisibility(View.GONE);
                this.view3_three.setVisibility(View.GONE);
                this.view3_four.setVisibility(View.GONE);
                this.view3_five.setVisibility(View.GONE);
                this.view3_six.setVisibility(View.GONE);
                this.view3_seven.setVisibility(View.GONE);
                this.view3_eight.setVisibility(View.GONE);
                this.view3_nine.setVisibility(View.GONE);
                this.view3_ten.setVisibility(View.GONE);
            } else if (int_num == 4) {
                this.view4_one.setVisibility(View.GONE);
                this.view4_two.setVisibility(View.GONE);
                this.view4_three.setVisibility(View.GONE);
                this.view4_four.setVisibility(View.GONE);
                this.view4_five.setVisibility(View.GONE);
                this.view4_six.setVisibility(View.GONE);
                this.view4_seven.setVisibility(View.GONE);
                this.view4_eight.setVisibility(View.GONE);
                this.view4_nine.setVisibility(View.GONE);
                this.view4_ten.setVisibility(View.GONE);
            } else if (int_num == 5) {
                this.view5_one.setVisibility(View.GONE);
                this.view5_two.setVisibility(View.GONE);
                this.view5_three.setVisibility(View.GONE);
                this.view5_four.setVisibility(View.GONE);
                this.view5_five.setVisibility(View.GONE);
                this.view5_six.setVisibility(View.GONE);
                this.view5_seven.setVisibility(View.GONE);
                this.view5_eight.setVisibility(View.GONE);
                this.view5_nine.setVisibility(View.GONE);
                this.view5_ten.setVisibility(View.GONE);
            } else if (int_num >= 6) {
                this.view6_one.setVisibility(View.GONE);
                this.view6_two.setVisibility(View.GONE);
                this.view6_three.setVisibility(View.GONE);
                this.view6_four.setVisibility(View.GONE);
                this.view6_five.setVisibility(View.GONE);
                this.view6_six.setVisibility(View.GONE);
                this.view6_seven.setVisibility(View.GONE);
                this.view6_eight.setVisibility(View.GONE);
                this.view6_nine.setVisibility(View.GONE);
                this.view6_ten.setVisibility(View.GONE);
            }
        }
    }

    private void Collage_One(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_one.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_one.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_one.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_one.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_one.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_one.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_one.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_one.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_one.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_one.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_one.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_one.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_one.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_one.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_one.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_one.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_one.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_one.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_one.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_one.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_one.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_one.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_one.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_one.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_one.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_one.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Two(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_two.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_two.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_two.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_two.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_two.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_two.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_two.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_two.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_two.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_two.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_two.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_two.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_two.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_two.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_two.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_two.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_two.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_two.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_two.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_two.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_two.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_two.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_two.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_two.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_two.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_two.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Three(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_three.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_three.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_three.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_three.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_three.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_three.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_three.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_three.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_three.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_three.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_three.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_three.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_three.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_three.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_three.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_three.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_three.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_three.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_three.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_three.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_three.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_three.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_three.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_three.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_three.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_three.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Four(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_four.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_four.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_four.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_four.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_four.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_four.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_four.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_four.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_four.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_four.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_four.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_four.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_four.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_four.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_four.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_four.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_four.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_four.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_four.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_four.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_four.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_four.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_four.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_four.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_four.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_four.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Five(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_five.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_five.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_five.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_five.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_five.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_five.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_five.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_five.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_five.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_five.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_five.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_five.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_five.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_five.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_five.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_five.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_five.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_five.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_five.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_five.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_five.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_five.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_five.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_five.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_five.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_five.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Six(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_six.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_six.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_six.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_six.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_six.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_six.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_six.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_six.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_six.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_six.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_six.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_six.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_six.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_six.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_six.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_six.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_six.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_six.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_six.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_six.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_six.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_six.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_six.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_six.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_six.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_six.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Seven(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_seven.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_seven.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_seven.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_seven.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_seven.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_seven.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_seven.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_seven.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_seven.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_seven.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_seven.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_seven.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_seven.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_seven.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_seven.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_seven.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_seven.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_seven.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_seven.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_seven.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_seven.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_seven.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_seven.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_seven.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_seven.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_seven.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Eight(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_eight.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_eight.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_eight.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_eight.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_eight.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_eight.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_eight.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_eight.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_eight.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_eight.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_eight.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_eight.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_eight.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_eight.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_eight.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_eight.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_eight.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_eight.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_eight.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_eight.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_eight.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_eight.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_eight.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_eight.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_eight.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_eight.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Nine(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_nine.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_nine.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_nine.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_nine.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_nine.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {
                this.view4_nine.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_nine.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_nine.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_nine.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_nine.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_nine.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                this.view5_nine.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_nine.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_nine.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_nine.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_nine.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_nine.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_nine.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_nine.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_nine.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_nine.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_nine.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_nine.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_nine.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_nine.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_nine.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    private void Collage_Ten(int int_num, Bitmap bm_1, Bitmap bm_2, Bitmap bm_3, Bitmap bm_4, Bitmap bm_5, Bitmap bm_6) {
        if (int_num != 1 && int_num != 2) {
            if (int_num == 3) {
                this.view3_ten.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view3_ten.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view3_ten.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view3_ten.findViewById(R.id.img_Editor);
                ((CollageTouchImageView) this.view3_ten.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
            } else if (int_num == 4) {

                this.view4_ten.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view4_ten.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view4_ten.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view4_ten.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view4_ten.findViewById(R.id.img_CollageEditor);
                ((CollageTouchImageView) this.view4_ten.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
            } else if (int_num == 5) {
                Log.e("5", "5");
                this.view5_ten.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view5_ten.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view5_ten.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view5_ten.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view5_ten.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view5_ten.findViewById(R.id.imgCollage_five);
                ((CollageTouchImageView) this.view5_ten.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
            } else if (int_num >= 6) {
                this.view6_ten.setVisibility(View.VISIBLE);
                this.ll_main = (LinearLayout) this.view6_ten.findViewById(R.id.ll_main);
                this.ll_main.setBackgroundResource(R.color.colorWhite);
                Collageimg_two = (CollageTouchImageView) this.view6_ten.findViewById(R.id.img_two);
                Collageimg_three = (CollageTouchImageView) this.view6_ten.findViewById(R.id.img_Editor);
                Collageimg_four = (CollageTouchImageView) this.view6_ten.findViewById(R.id.img_CollageEditor);
                Collageimg_five = (CollageTouchImageView) this.view6_ten.findViewById(R.id.imgCollage_five);
                CollageTouchImageView img_six = (CollageTouchImageView) this.view6_ten.findViewById(R.id.imgCollage_six);
                ((CollageTouchImageView) this.view6_ten.findViewById(R.id.img_one)).setImageBitmap(bm_1);
                Collageimg_two.setImageBitmap(bm_2);
                Collageimg_three.setImageBitmap(bm_3);
                Collageimg_four.setImageBitmap(bm_4);
                Collageimg_five.setImageBitmap(bm_5);
                img_six.setImageBitmap(bm_6);
            }
        }
    }

    void getScreenSnapShot() {
        View content = findViewById(R.id.collagebox);
        content.setDrawingCacheEnabled(true);
        content.buildDrawingCache(true);
        saveBitmap(content.getDrawingCache());
        content.setDrawingCacheEnabled(false);
        content.destroyDrawingCache();
    }

    public void saveBitmap(Bitmap bitmap) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), IMAGE_DIRECTORY_NAME);
        if (!(mediaStorageDir.exists() || mediaStorageDir.mkdirs())) {
            Log.d(IMAGE_DIRECTORY_NAME, "Oops! Failed create SweetSelfie directory");
        }
        String filepath = mediaStorageDir.getPath() + File.separator + "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".jpg";
        try {
            FileOutputStream fos = new FileOutputStream(new File(filepath));
            bitmap.compress(CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
        } catch (IOException e2) {
        }
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        this.contentUri = Uri.fromFile(new File(filepath));
        mediaScanIntent.setData(this.contentUri);
        sendBroadcast(mediaScanIntent);
    }


    public void onClick(View v) {
        if (v == this.Imgbtn_one) {
            ResetCollage(this.int_photo_size);
            Collage_One(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_two) {
            ResetCollage(this.int_photo_size);
            Collage_Two(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_three) {
            ResetCollage(this.int_photo_size);
            Collage_Three(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_four) {
            ResetCollage(this.int_photo_size);
            Collage_Four(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_five) {
            ResetCollage(this.int_photo_size);
            Collage_Five(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_six) {
            ResetCollage(this.int_photo_size);
            Collage_Six(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_seven) {
            ResetCollage(this.int_photo_size);
            Collage_Seven(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_eight) {
            ResetCollage(this.int_photo_size);
            Collage_Eight(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_nine) {
            ResetCollage(this.int_photo_size);
            Collage_Nine(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.Imgbtn_ten) {
            ResetCollage(this.int_photo_size);
            Collage_Ten(this.int_photo_size, this.bitmap_one, this.bitmap_two, this.bitmap_three, this.bitmap_four, this.bitmap_five, this.bitmap_six);
        } else if (v == this.ll_collagely) {
            this.ll_stickers.setVisibility(View.GONE);
            this.ll_collage.setVisibility(View.VISIBLE);
            this.img_control_text.setEnabled(false);
            this.img_control_text.setClickable(false);
            MenuTool(this.int_photo_size);
        } else if (v == this.ll_Stickers) {

            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            showStickerDialog();

        } else if (v == this.ll_save) {
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            new saves().execute(new String[0]);
        } else if (v == this.ll_text) {
            if (this.currentTextView != null) {
                this.currentTextView.setInEdit(false);
            }
            if (this.currentView != null) {
                this.currentView.setInEdit(false);
            }
            selecttext();

        }
    }


    public void onBackPressed() {
        this.int_backPress = 1;
        CollagePhotoEdiotrActivity.this.finish();
    }

    protected void selecttext() {
        this.dialog = new Dialog(this);
        this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.inputmethodmanager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        this.inputmethodmanager.toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        this.edittext = (EditText) this.dialog.findViewById(R.id.edittext);
        this.edittext.requestFocus();
        this.ll_fontlist = (LinearLayout) this.dialog
                .findViewById(R.id.llfontlist);
        this.ll_fontlist.setVisibility(View.GONE);
        this.grid_fontlist = (GridView) this.dialog.findViewById(R.id.grid_fontlist);
        this.grid_fontlist.setAdapter(new FontStyleAdapter(this, this.fonts));
        this.grid_fontlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                CollagePhotoEdiotrActivity.this.typeface = Typeface.createFromAsset(
                        CollagePhotoEdiotrActivity.this.getAssets(),
                        CollagePhotoEdiotrActivity.this.fonts[i]);
                CollagePhotoEdiotrActivity.this.edittext
                        .setTypeface(CollagePhotoEdiotrActivity.this.typeface);
                textView.setTypeface(CollagePhotoEdiotrActivity.this.typeface);
            }
        });
        this.ll_colorlist = (LinearLayout) this.dialog
                .findViewById(R.id.ll_colorlist);
        this.ll_colorlist.setVisibility(View.GONE);
        this.grid_colorlist = (GridView) this.dialog
                .findViewById(R.id.grid_colorlist);
        ArrayList colors = HSVColors();
        final ArrayList arrayList = colors;
        this.grid_colorlist.setAdapter(new ArrayAdapter<Integer>(
                getApplicationContext(), android.R.layout.simple_list_item_1, colors) {
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView,
                        parent);
                view.setBackgroundColor(((Integer) arrayList.get(position))
                        .intValue());
                view.setText("");
                view.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
                AbsListView.LayoutParams params = (AbsListView.LayoutParams) view
                        .getLayoutParams();
                params.width = CollagePhotoEdiotrActivity.columnWidth;
                params.height = CollagePhotoEdiotrActivity.columnWidth;
                view.setLayoutParams(params);
                view.requestLayout();
                return view;
            }
        });
        this.grid_colorlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                CollagePhotoEdiotrActivity.this.pickedColor = ((Integer) adapterView
                        .getItemAtPosition(i)).intValue();
                CollagePhotoEdiotrActivity.this.edittext
                        .setTextColor(CollagePhotoEdiotrActivity.this.pickedColor);
                textView.setTextColor(CollagePhotoEdiotrActivity.this.pickedColor);
            }
        });
        this.imageview_keyboard = (ImageView) this.dialog
                .findViewById(R.id.imgview_keyboard);
        this.imageview_keyboard.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) CollagePhotoEdiotrActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(
                        CollagePhotoEdiotrActivity.this.edittext, 2);
                CollagePhotoEdiotrActivity.this.ll_fontlist.setVisibility(View.GONE);
                CollagePhotoEdiotrActivity.this.ll_colorlist.setVisibility(View.GONE);
            }
        });
        this.imageview_fontstyle = (ImageView) this.dialog
                .findViewById(R.id.imgview_fontstyle);
        this.imageview_fontstyle.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                CollagePhotoEdiotrActivity.this.ll_fontlist.setVisibility(View.VISIBLE);
                CollagePhotoEdiotrActivity.this.ll_colorlist.setVisibility(View.GONE);
                ((InputMethodManager) CollagePhotoEdiotrActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                CollagePhotoEdiotrActivity.this.edittext
                                        .getWindowToken(), 0);
            }
        });
        this.imageview_color = (ImageView) this.dialog.findViewById(R.id.imgview_color);
        this.imageview_color.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) CollagePhotoEdiotrActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                CollagePhotoEdiotrActivity.this.edittext
                                        .getWindowToken(), 0);
                CollagePhotoEdiotrActivity.this.ll_colorlist.setVisibility(View.VISIBLE);
                CollagePhotoEdiotrActivity.this.ll_fontlist.setVisibility(View.GONE);
            }
        });
        this.imageview_gravity = (ImageView) this.dialog.findViewById(R.id.imgview_gravity);
        this.imageview_gravity.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (CollagePhotoEdiotrActivity.this.w == 0) {
                    CollagePhotoEdiotrActivity.this.w = 1;
                    CollagePhotoEdiotrActivity.this.imageview_gravity
                            .setImageDrawable(CollagePhotoEdiotrActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.alignright));
                    CollagePhotoEdiotrActivity.this.edittext.setGravity(5);
                    textView.setGravity(5);
                } else if (CollagePhotoEdiotrActivity.this.w == 1) {
                    CollagePhotoEdiotrActivity.this.imageview_gravity
                            .setImageDrawable(CollagePhotoEdiotrActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.alignleft));
                    CollagePhotoEdiotrActivity.this.edittext.setGravity(3);
                    textView.setGravity(3);
                    CollagePhotoEdiotrActivity.this.w = 2;
                } else if (CollagePhotoEdiotrActivity.this.w == 2) {
                    CollagePhotoEdiotrActivity.this.w = 0;
                    CollagePhotoEdiotrActivity.this.imageview_gravity
                            .setImageDrawable(CollagePhotoEdiotrActivity.this
                                    .getResources().getDrawable(
                                            R.drawable.aligncenter));
                    CollagePhotoEdiotrActivity.this.edittext.setGravity(17);
                    textView.setGravity(17);
                }
            }
        });
        this.imageview_done = (ImageView) this.dialog.findViewById(R.id.imgview_done);
        final TextView txtEnteredText = (TextView) this.dialog
                .findViewById(R.id.txtEnteredText);
        txtEnteredText.setDrawingCacheEnabled(true);
        this.imageview_done.setOnClickListener(new OnClickListener() {


            public void onClick(View view) {
                CollagePhotoEdiotrActivity.this.inputmethodmanager.hideSoftInputFromWindow(
                        view.getWindowToken(), 0);
                String st = CollagePhotoEdiotrActivity.this.edittext.getText()
                        .toString();
                if (st.isEmpty()) {
                    Toast.makeText(CollagePhotoEdiotrActivity.this, "text empty",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                txtEnteredText.setText(st);
                txtEnteredText.setTypeface(CollagePhotoEdiotrActivity.this.typeface);
                txtEnteredText
                        .setTextColor(CollagePhotoEdiotrActivity.this.pickedColor);
                txtEnteredText.setGravity(17);
                ImageView textImg = new ImageView(CollagePhotoEdiotrActivity.this);
                txtEnteredText.buildDrawingCache();
                textImg.setImageBitmap(txtEnteredText.getDrawingCache());
                CollagePhotoEdiotrActivity.textBitmap = CollagePhotoEdiotrActivity
                        .loadBitmapFromView(textImg);
                CollagePhotoEdiotrActivity.textBitmap = CollagePhotoEdiotrActivity.this
                        .CropBitmapTransparency(CollagePhotoEdiotrActivity.textBitmap);
                txtEnteredText.setDrawingCacheEnabled(false);
                ((InputMethodManager) CollagePhotoEdiotrActivity.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                CollagePhotoEdiotrActivity.this.edittext
                                        .getWindowToken(), 0);
                final CustomStckerTextView stickerTextView = new CustomStckerTextView(
                        CollagePhotoEdiotrActivity.this);
                stickerTextView.setBitmap(CollagePhotoEdiotrActivity.textBitmap);
                CollagePhotoEdiotrActivity.this.ll.addView(stickerTextView,
                        new FrameLayout.LayoutParams(-1, -1, 17));
                CollagePhotoEdiotrActivity.this.stickers.add(stickerTextView);
                stickerTextView.setInEdit(true);
                CollagePhotoEdiotrActivity.this
                        .setCurrentEditForText(stickerTextView);
                stickerTextView
                        .setOperationListener(new CustomStckerTextView.OperationListener() {
                            public void onDeleteClick() {
                                CollagePhotoEdiotrActivity.this.stickers
                                        .remove(stickerTextView);
                                CollagePhotoEdiotrActivity.this.ll
                                        .removeView(stickerTextView);
                            }

                            public void onEdit(
                                    CustomStckerTextView customTextView) {
                                CollagePhotoEdiotrActivity.this.currentTextView
                                        .setInEdit(false);
                                CollagePhotoEdiotrActivity.this.currentTextView = customTextView;
                                CollagePhotoEdiotrActivity.this.currentTextView
                                        .setInEdit(true);
                            }

                            public void onTop(
                                    CustomStckerTextView customTextView) {
                                int position = CollagePhotoEdiotrActivity.this.stickers
                                        .indexOf(customTextView);
                                if (position != CollagePhotoEdiotrActivity.this.stickers
                                        .size() - 1) {
                                    CollagePhotoEdiotrActivity.this.stickers
                                            .add(CollagePhotoEdiotrActivity.this.stickers
                                                            .size(),
                                                    (CustomTextView) CollagePhotoEdiotrActivity.this.stickers
                                                            .remove(position));
                                }
                            }
                        });
                CollagePhotoEdiotrActivity.this.dialog.dismiss();
            }

        });
        this.dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            public boolean onKey(DialogInterface dialogInterface, int i,
                                 KeyEvent keyEvent) {
                if (i != 4 || keyEvent.getAction() != 1
                        || keyEvent.isCanceled()) {
                    return false;
                }
                CollagePhotoEdiotrActivity.this.dialog.cancel();
                return true;
            }
        });
        this.dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        Window window2 = this.dialog.getWindow();
        layoutParams.copyFrom(window2.getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -1;
        window2.setAttributes(layoutParams);
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    public static ArrayList HSVColors() {
        final ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i <= 360; i += 20) {
            list.add(HSVColor(i, 1.0f, 1.0f));
        }
        for (int j = 0; j <= 360; j += 20) {
            list.add(HSVColor(j, 0.25f, 1.0f));
            list.add(HSVColor(j, 0.5f, 1.0f));
            list.add(HSVColor(j, 0.75f, 1.0f));
        }
        for (int k = 0; k <= 360; k += 20) {
            list.add(HSVColor(k, 1.0f, 0.5f));
            list.add(HSVColor(k, 1.0f, 0.75f));
        }
        for (float n = 0.0f; n <= 1.0f; n += 0.1f) {
            list.add(HSVColor(0.0f, 0.0f, n));
        }
        return list;
    }

    Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                if (((sourceBitmap.getPixel(x, y) >> 24) & 255) > 0) {
                    if (x < minX) {
                        minX = x;
                    }
                    if (x > maxX) {
                        maxX = x;
                    }
                    if (y < minY) {
                        minY = y;
                    }
                    if (y > maxY) {
                        maxY = y;
                    }
                }
            }
        }
        if (maxX < minX || maxY < minY) {
            return null;
        }
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1,
                (maxY - minY) + 1);
    }

    private void setCurrentEditForText(CustomStckerTextView stickerTextView) {
        this.currentTextView = stickerTextView;
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(true);
        }
    }

    public static Bitmap loadBitmapFromView(View v) {
        if (v.getMeasuredHeight() <= 0) {
            v.measure(-2, -2);
            Bbitmap = Bitmap.createBitmap(v.getMeasuredWidth(),
                    v.getMeasuredHeight(), Config.ARGB_8888);
            canvas = new Canvas(Bbitmap);
            v.layout(0, 0, v.getMeasuredWidth(), v.getMeasuredHeight());
            v.draw(canvas);
            return Bbitmap;
        }
        Bbitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(),
                Config.ARGB_8888);
        canvas = new Canvas(Bbitmap);
        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(canvas);
        return Bbitmap;
    }

    public void showStickerDialog() {
        final Dialog dial = new Dialog(this, android.R.style.Theme_Translucent);
        dial.requestWindowFeature(1);
        dial.setContentView(R.layout.sticker_dialog);
        dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dial.setCanceledOnTouchOutside(true);
        ((ImageView) dial.findViewById(R.id.back_dialog))
                .setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        dial.dismiss();
                    }
                });
        this.stickerlist = new ArrayList();
        GridView grid_sticker = (GridView) dial
                .findViewById(R.id.gridStickerList);
        setStickerList1();
        this.stickerAdapter = new StickerAdapter(getApplicationContext(),
                this.stickerlist);
        grid_sticker.setAdapter(this.stickerAdapter);
        grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                CollagePhotoEdiotrActivity.this
                        .addStickerView(((Integer) CollagePhotoEdiotrActivity.this.stickerlist
                                .get(i)).intValue());
                dial.dismiss();
            }
        });
        dial.show();
    }

    private void setStickerList1() {
        this.stickerlist.add(Integer.valueOf(R.drawable.ss1));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss2));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss3));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss4));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss5));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss6));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss7));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss8));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss9));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss10));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss11));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss12));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss13));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss14));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss15));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss16));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss17));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss18));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss19));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss20));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss21));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss22));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss23));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss24));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss25));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss26));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss27));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss28));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss29));
        this.stickerlist.add(Integer.valueOf(R.drawable.ss30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s29));
        this.stickerlist.add(Integer.valueOf(R.drawable.s30));
        this.stickerlist.add(Integer.valueOf(R.drawable.s31));
        this.stickerlist.add(Integer.valueOf(R.drawable.s32));
        this.stickerlist.add(Integer.valueOf(R.drawable.s33));
        this.stickerlist.add(Integer.valueOf(R.drawable.s34));
        this.stickerlist.add(Integer.valueOf(R.drawable.s35));
        this.stickerlist.add(Integer.valueOf(R.drawable.s36));
        this.stickerlist.add(Integer.valueOf(R.drawable.s37));
        this.stickerlist.add(Integer.valueOf(R.drawable.s38));
        this.stickerlist.add(Integer.valueOf(R.drawable.s39));
        this.stickerlist.add(Integer.valueOf(R.drawable.s40));
        this.stickerlist.add(Integer.valueOf(R.drawable.s41));
        this.stickerlist.add(Integer.valueOf(R.drawable.s42));
        this.stickerlist.add(Integer.valueOf(R.drawable.s43));
        this.stickerlist.add(Integer.valueOf(R.drawable.s44));
        this.stickerlist.add(Integer.valueOf(R.drawable.s45));
        this.stickerlist.add(Integer.valueOf(R.drawable.s46));
        this.stickerlist.add(Integer.valueOf(R.drawable.s47));
        this.stickerlist.add(Integer.valueOf(R.drawable.s48));
        this.stickerlist.add(Integer.valueOf(R.drawable.s49));
        this.stickerlist.add(Integer.valueOf(R.drawable.s50));
        this.stickerlist.add(Integer.valueOf(R.drawable.s51));
        this.stickerlist.add(Integer.valueOf(R.drawable.s52));
        this.stickerlist.add(Integer.valueOf(R.drawable.s53));
        this.stickerlist.add(Integer.valueOf(R.drawable.s54));
        this.stickerlist.add(Integer.valueOf(R.drawable.s55));

    }

    private void addStickerView(int id) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                CollagePhotoEdiotrActivity.this.views.remove(stickerView);
                CollagePhotoEdiotrActivity.this.ll.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                if (CollagePhotoEdiotrActivity.this.currentTextView != null) {
                    CollagePhotoEdiotrActivity.this.currentTextView.setInEdit(false);
                }
                CollagePhotoEdiotrActivity.this.currentView.setInEdit(false);
                CollagePhotoEdiotrActivity.this.currentView = stickerView;
                CollagePhotoEdiotrActivity.this.currentView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = CollagePhotoEdiotrActivity.this.views
                        .indexOf(stickerView);
                if (position != CollagePhotoEdiotrActivity.this.views.size() - 1) {
                    CollagePhotoEdiotrActivity.this.views.add(
                            CollagePhotoEdiotrActivity.this.views.size(),
                            (StickerView) CollagePhotoEdiotrActivity.this.views
                                    .remove(position));
                }
            }
        });
        this.ll.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.views.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.currentTextView != null) {
            this.currentTextView.setInEdit(false);
        }
        if (this.currentView != null) {
            this.currentView.setInEdit(false);
        }
        this.currentView = stickerView;
        stickerView.setInEdit(true);
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(CollagePhotoEdiotrActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        CollagePhotoEdiotrActivity.this.finish();
                        break;
                    case R.id.ll_save:
                        Intent i = new Intent(CollagePhotoEdiotrActivity.this, shareActivity.class);
                        i.putExtra("key", 1);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(CollagePhotoEdiotrActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
