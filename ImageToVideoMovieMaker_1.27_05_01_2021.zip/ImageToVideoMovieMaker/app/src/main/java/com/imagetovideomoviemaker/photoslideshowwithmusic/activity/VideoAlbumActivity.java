package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Video.Media;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.imagetovideomoviemaker.video.FileUtils;
import com.xyz.imagetovideomoviewmaker.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.MyApplication;
import com.imagetovideomoviemaker.photoslideshowwithmusic.ProgressBar.kprogresshud.KProgressHUD;
import com.imagetovideomoviemaker.photoslideshowwithmusic.adapters.VideoAlbumAdapter;
import com.imagetovideomoviemaker.photoslideshowwithmusic.data.VideoData;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.PermissionModelUtil;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.EmptyRecyclerView;
import com.imagetovideomoviemaker.photoslideshowwithmusic.view.SpacesItemDecoration;
import java.io.File;
import java.util.ArrayList;

public class VideoAlbumActivity extends AppCompatActivity {
    public static final String EXTRA_FROM_VIDEO = "EXTRA_FROM_VIDEO";
    private boolean isFromVideo = false;
    private VideoAlbumAdapter mVideoAlbumAdapter;
    private ArrayList<VideoData> mVideoDatas;
    PermissionModelUtil modelUtil;
    private EmptyRecyclerView rvVideoAlbum;
    private Toolbar toolbar;
    public KProgressHUD hud;
    Activity activity = VideoAlbumActivity.this;
    ImageView ivback;
    TextView tvToolbarTitle;
    LinearLayout layoutSlideShowMain;
    TextView tvNoVideo;
    TextView tvLoadingAds;

    private NativeBannerAd nativeBannerAd;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        try {
            sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.fromFile(FileUtils.APP_DIRECTORY)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onCreate(savedInstanceState);
        this.isFromVideo = getIntent().hasExtra(EXTRA_FROM_VIDEO);
        setContentView(R.layout.activity_movie_album);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VideoAlbumActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        setActionBar();
        bindView();
        init();
        setUpRecyclerView();
        addListener();
        LoadNativeAds();
        if (mVideoDatas.size() > 0) {
            Log.e("TAG", "Size" + MyApplication.getInstance().getAllFolder().size());
            layoutSlideShowMain.setBackgroundColor(getResources().getColor(R.color.white));
            toolbar.setBackground(getResources().getDrawable(R.drawable.bg_toobar_gradint));
            tvToolbarTitle.setTextColor(getResources().getColor(R.color.white));
            tvLoadingAds.setTextColor(getResources().getColor(R.color.black));
        } else {
            layoutSlideShowMain.setBackground(getResources().getDrawable(R.drawable.main_bg));
            toolbar.setBackground(getResources().getDrawable(R.drawable.bg_toolbar));
            tvToolbarTitle.setTextColor(getResources().getColor(R.color.text_color));
            tvLoadingAds.setTextColor(getResources().getColor(R.color.white));
        }
    }


    protected void onResume() {
        super.onResume();
        if (this.mVideoAlbumAdapter != null) {
            this.mVideoAlbumAdapter.notifyDataSetChanged();
        }
    }

    private void bindView() {
        toolbar = findViewById(R.id.toolbar);
        ivback = findViewById(R.id.iv_back);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        tvNoVideo = findViewById(R.id.tv_no_video_create_yet);
        this.rvVideoAlbum = findViewById(R.id.rvVideoAlbum);
        layoutSlideShowMain = findViewById(R.id.layout_My_slide_show_main);
        tvLoadingAds = findViewById(R.id.tvLoadAds);
        ivback.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        Utils.setFont(activity, tvToolbarTitle);
        Utils.setFont(activity, tvNoVideo);
    }



    private void init() {
        getVideoList();
        this.modelUtil = new PermissionModelUtil(this);
        if (this.modelUtil.needPermissionCheck()) {
            this.modelUtil.showPermissionExplanationThenAuthorization();
        } else {
            MyApplication.getInstance().getFolderList();
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(1001);
    }

    private void setActionBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textView = toolbar.findViewById(R.id.toolbar_title);
        textView.setText(getString(R.string.my_creation));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Utils.setFont(this, textView);
    }

    private void setUpRecyclerView() {
        LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 1);
        this.mVideoAlbumAdapter = new VideoAlbumAdapter(this, this.mVideoDatas);
        this.rvVideoAlbum.setLayoutManager(gridLayoutManager);
        this.rvVideoAlbum.setItemAnimator(new DefaultItemAnimator());
        this.rvVideoAlbum.addItemDecoration(new SpacesItemDecoration(getResources().getDimensionPixelSize(R.dimen.spacing)));
        this.rvVideoAlbum.setEmptyView(findViewById(R.id.list_empty));
        this.rvVideoAlbum.setAdapter(this.mVideoAlbumAdapter);
    }

    private void getVideoList() {
        this.mVideoDatas = new ArrayList();
        String[] strArr = new String[]{"_data", "_id", "bucket_display_name", "duration", "title", "datetaken", "_display_name"};
        Uri uri = Media.EXTERNAL_CONTENT_URI;
        ContentResolver contentResolver = getContentResolver();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("_data like '%");
        stringBuilder.append(FileUtils.APP_DIRECTORY.getAbsolutePath());
        stringBuilder.append("%'");
        Cursor query = contentResolver.query(uri, strArr, stringBuilder.toString(), null, "datetaken DESC");
        if (query.moveToFirst()) {
            int columnIndex = query.getColumnIndex("duration");
            int columnIndex2 = query.getColumnIndex("_data");
            int columnIndex3 = query.getColumnIndex("title");
            int columnIndex4 = query.getColumnIndex("datetaken");
            do {
                VideoData videoData = new VideoData();
                videoData.videoDuration = query.getLong(columnIndex);
                videoData.videoFullPath = query.getString(columnIndex2);
                videoData.videoName = query.getString(columnIndex3);
                videoData.dateTaken = query.getLong(columnIndex4);
                if (new File(videoData.videoFullPath).exists()) {
                    this.mVideoDatas.add(videoData);
                }
            } while (query.moveToNext());
        }
    }


    private void addListener() {
        findViewById(R.id.btnCreateVideo).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    ActivityAnimUtil.startActivitySafely(view, new Intent(VideoAlbumActivity.this, ImageSelectionActivity.class));
                    VideoAlbumActivity.this.finish();
                    return;
                }
                Toast.makeText(VideoAlbumActivity.this.getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.list_empty).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MyApplication.getInstance().getAllFolder().size() > 0) {
                    MyApplication.isStoryAdded = false;
                    MyApplication.isBreak = false;
                    MyApplication.getInstance().setMusicData(null);
                    ActivityAnimUtil.startActivitySafely(view, new Intent(VideoAlbumActivity.this, ImageSelectionActivity.class));
                    VideoAlbumActivity.this.finish();
                    return;
                }
                Toast.makeText(VideoAlbumActivity.this.getApplicationContext(), R.string.no_images_found_in_device_please_add_images_in_sdcard, Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void LoadNativeAds() {
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = (LinearLayout) findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
    }


//    public boolean onOptionsItemSelected(MenuItem menuItem) {
//        if (menuItem.getItemId() == android.R.id.home) {
//            Toast.makeText(activity, "GoToHomeCalled...", Toast.LENGTH_SHORT).show();
//            onBackPressed();
//        }
//        return super.onOptionsItemSelected(menuItem);
//    }

    public void onBackPressed() {
        MyApplication.id = 105;
        MyApplication.activityContext = VideoAlbumActivity.this;
        ShowInterstitial();
    }


    public void ShowInterstitial2() {
        if (MyApplication.interstitialAd2 != null) {
            if (MyApplication.interstitialAd2.isAdLoaded()) {
//                dialogAd.show();
                AdsDialogShow(2);
            } else {
                MyApplication.loadInterstitialNew2(VideoAlbumActivity.this);
                MyApplication.getInstance().setFrame(0);
                Intent intent = new Intent(this, LauncherActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                ActivityAnimUtil.startActivitySafely(this.toolbar, intent);
                finish();
            }
        } else {
            MyApplication.loadInterstitialAd2(VideoAlbumActivity.this);
            MyApplication.getInstance().setFrame(0);
            Intent intent = new Intent(this, LauncherActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            ActivityAnimUtil.startActivitySafely(this.toolbar, intent);
            finish();
        }
    }

    public void ShowInterstitial() {
        if (MyApplication.interstitialAd != null) {
            if (MyApplication.interstitialAd.isAdLoaded()) {
//                dialogAd.show();
                AdsDialogShow(1);
            } else {
                MyApplication.loadInterstitialNew(VideoAlbumActivity.this);
                ShowInterstitial2();
            }
        } else {
            MyApplication.loadInterstitialAd(VideoAlbumActivity.this);
            ShowInterstitial2();
        }
    }

//    Dialog dialogAd;
//    private void InitAdDialog() {
//        dialogAd = new Dialog(VideoAlbumActivity.this);
//        dialogAd.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialogAd.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//        dialogAd.getWindow().setGravity(Gravity.CENTER);
//        dialogAd.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
//        dialogAd.setContentView(R.layout.dialog_layout_ads);
//        dialogAd.setCanceledOnTouchOutside(false);
//    }

    private void AdsDialogShow(final int ads) {
//        final Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                dialogAd.dismiss();
//                if (ads == 2) {
//                    MyApplication.interstitialAd2.show();
//                } else {
//                    MyApplication.interstitialAd.show();
//                }
//            }
//        }, 2000L);

        try {
            hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    hud.dismiss();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();

                } catch (NullPointerException e2) {
                    e2.printStackTrace();
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
                if (ads == 2) {
                    MyApplication.interstitialAd2.show();
                } else {
                    MyApplication.interstitialAd.show();
                }
            }
        }, 2000);
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }
}
