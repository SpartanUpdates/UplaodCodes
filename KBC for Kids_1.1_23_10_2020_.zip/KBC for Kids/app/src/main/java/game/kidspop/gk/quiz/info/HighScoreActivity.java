package game.kidspop.gk.quiz.info;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;

import java.util.ArrayList;

public class HighScoreActivity extends AppCompatActivity {
    Activity activity = HighScoreActivity.this;
    ArrayList<getset_Player_Score> arrScoreList = new ArrayList();
    private NativeBannerAd nativeBannerAd;

    public class getset_Player_Score {
        private String mPlayerName;
        private String mPlayerScore;

        public getset_Player_Score(String str, String str2) {
            this.mPlayerName = str;
            this.mPlayerScore = str2;
        }

        public String getPlayerName() {
            return this.mPlayerName;
        }

        public String getPlayerScore() {
            return this.mPlayerScore;
        }
    }

    public class myAdpt_High_Score extends ArrayAdapter<getset_Player_Score> {
        private ArrayList<getset_Player_Score> arrList;
        private int layoutResourceId;
        private getset_Player_Score obj;

        public class ViewHolderRow {
            public TextView mtvHighScore;
            public TextView mtvPlayerName;
        }

        public myAdpt_High_Score(Context context, int i, ArrayList<getset_Player_Score> arrayList) {
            super(context, i, arrayList);
            this.layoutResourceId = i;
            this.arrList = arrayList;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolderRow viewHolderRow;
            if (view == null) {
                view = ((LayoutInflater) getContext().getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(this.layoutResourceId, null);
                viewHolderRow = new ViewHolderRow();
                view.setTag(viewHolderRow);
            } else {
                viewHolderRow = (ViewHolderRow) view.getTag();
            }
            ArrayList arrayList = this.arrList;
            if (arrayList != null && i + 1 <= arrayList.size()) {
                this.obj = (getset_Player_Score) this.arrList.get(i);
                viewHolderRow.mtvPlayerName = (TextView) view.findViewById(R.id.itvPlayerName);
                viewHolderRow.mtvPlayerName.setText(this.obj.getPlayerName());
                viewHolderRow.mtvHighScore = (TextView) view.findViewById(R.id.itvHighScore);
                viewHolderRow.mtvHighScore.setText(this.obj.getPlayerScore());
            }
            return view;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getSupportActionBar().hide();
        getWindow().setFlags(1024, 1024);
        setContentView((int) R.layout.activity_high_score);
        Fill_Score_List();
        LoadNativeAds();
        myAdpt_High_Score myadpt_high_score = new myAdpt_High_Score(this, R.layout.high_score_grid, this.arrScoreList);
        ListView listView = (ListView) findViewById(R.id.ilvHighScore);
        listView.setItemsCanFocus(false);
        listView.setAdapter(myadpt_high_score);
    }

    public void Fill_Score_List() {
        SQLiteDatabase OpenOrCreateLocalDatabase = OpenOrCreateLocalDatabase();
        Cursor rawQuery = OpenOrCreateLocalDatabase.rawQuery("Select * from tblHighScore order by WinScore desc,WinCount Desc", null);
        if (rawQuery != null) {
            Integer.valueOf(0);
            this.arrScoreList.clear();
            while (rawQuery.moveToNext()) {
                String string = rawQuery.getString(rawQuery.getColumnIndex("PlayerName"));
                String string2 = rawQuery.getString(rawQuery.getColumnIndex("WinScore"));
                Integer valueOf = Integer.valueOf(Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("WinCount"))));
                if (valueOf.intValue() > 0) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(Integer.toString(valueOf.intValue()));
                    stringBuilder.append(" x ");
                    stringBuilder.append(string2);
                    string2 = stringBuilder.toString();
                }
                this.arrScoreList.add(new getset_Player_Score(string, string2));
            }
        }
        rawQuery.close();
        OpenOrCreateLocalDatabase.close();
    }

    /*private UnifiedNativeAd nativeAd;
    private void loadAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.admob_native));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                populateUnifiedNativeAdViewDialog(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }*/

    private void LoadNativeAds() {
        nativeBannerAd = new NativeBannerAd(this, getString(R.string.fb_nativeBanner));
        nativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("TAG", "onError" + adError.getErrorMessage());

            }

            @Override
            public void onAdLoaded(Ad ad) {
                View adView = NativeBannerAdView.render(activity, nativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = findViewById(R.id.banner_container);
                findViewById(R.id.tvLoadAds).setVisibility(View.GONE);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });
        nativeBannerAd.loadAd();
    }

    private SQLiteDatabase OpenOrCreateLocalDatabase() {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            sQLiteDatabase = openOrCreateDatabase("AppLocalDb.db", 0, null);
            sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS tblHighScore('PlayerName' TEXT,'WinScore' NUMERIC,'WinCount' NUMERIC,'Col1' TEXT,'Col2' TEXT,'Col3' TEXT);");
            return sQLiteDatabase;
        } catch (Exception unused) {
            return sQLiteDatabase;
        }
    }

    /*private void populateUnifiedNativeAdViewDialog(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }*/
}