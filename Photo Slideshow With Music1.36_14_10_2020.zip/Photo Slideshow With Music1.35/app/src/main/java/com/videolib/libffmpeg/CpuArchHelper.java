package com.videolib.libffmpeg;

import android.os.Build;

class CpuArchHelper {
    static String getArm64CpuAbi() {
        return "arm64-v8a";
    }

    static String getArmeabiv7CpuAbi() {
        return "armeabi-v7a";
    }

    static String getX86_64CpuAbi() {
        return "x86_64";
    }

    static String getx86CpuAbi() {
        return "x86";
    }

    CpuArchHelper() {
    }

    static CpuAr getCpuArch() {
        if (Build.CPU_ABI.equals(getx86CpuAbi())) {
            return CpuAr.x86;
        }
        if (Build.CPU_ABI.equals(getArmeabiv7CpuAbi())) {
            return CpuAr.ARMv7;
        }
        if (Build.CPU_ABI.equals(getX86_64CpuAbi())) {
            return CpuAr.x86;
        }
        if (Build.CPU_ABI.equals(getArm64CpuAbi())) {
            return CpuAr.ARMv7;
        }
        return CpuAr.NONE;
    }
}
