package com.esc.motivationquotes.util;

import android.annotation.SuppressLint;
import androidx.lifecycle.GeneratedAdapter;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MethodCallsLogger;

public class AppLifecycleObserver_LifecycleAdapter implements GeneratedAdapter {
    final AppLifecycleObserver mReceiver;

    AppLifecycleObserver_LifecycleAdapter(AppLifecycleObserver appLifecycleObserver) {
        this.mReceiver = appLifecycleObserver;
    }

    @SuppressLint("RestrictedApi")
    public void callMethods(LifecycleOwner lifecycleOwner, Lifecycle.Event event, boolean z, MethodCallsLogger methodCallsLogger) {
        Object obj = methodCallsLogger != null ? 1 : null;
        if (!z) {
            if (event == Lifecycle.Event.ON_START) {
                if (obj == null || methodCallsLogger.approveCall("onEnterForeground", 1)) {
                    this.mReceiver.onEnterForeground();
                }
            } else if (event == Lifecycle.Event.ON_STOP) {
                if (obj == null || methodCallsLogger.approveCall("onEnterBackground", 1)) {
                    this.mReceiver.onEnterBackground();
                }
            } else {
                if (event == Lifecycle.Event.ON_DESTROY && (obj == null || methodCallsLogger.approveCall("onCloseApp", 1))) {
                    this.mReceiver.onCloseApp();
                }
            }
        }
    }
}
