package com.vidsoft.collagemaker.Model;

public class Frame
{
  int icon;
  int image;

  public Frame(int paramInt1, int paramInt2)
  {
    this.icon = paramInt1;
    this.image = paramInt2;
  }

  public int getIcon()
  {
    return this.icon;
  }

  public int getImage()
  {
    return this.image;
  }

  public void setIcon(int paramInt)
  {
    this.icon = paramInt;
  }

  public void setImage(int paramInt)
  {
    this.image = paramInt;
  }
}
