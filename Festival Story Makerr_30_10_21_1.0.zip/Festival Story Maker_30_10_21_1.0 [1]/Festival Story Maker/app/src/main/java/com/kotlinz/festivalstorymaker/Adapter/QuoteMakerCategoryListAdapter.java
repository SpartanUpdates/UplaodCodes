package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.QuoteMakerDetailActivity;
import com.kotlinz.festivalstorymaker.Models.n;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QuoteMakerCategoryListAdapter extends RecyclerView.Adapter<QuoteMakerCategoryListAdapter.ViewHolder> {
    public a g;
    public QuoteMakerDetailActivity activity;
    public ArrayList<n> QuoteList;
    public int SelectedPosition = 0;

    public QuoteMakerCategoryListAdapter(Activity activity, ArrayList<com.kotlinz.festivalstorymaker.Models.n> arrayList, a aVar, int i) {
        this.g = aVar;
        this.activity = (QuoteMakerDetailActivity) activity;
        this.QuoteList = arrayList;
        this.SelectedPosition = i;
    }

    public interface a {

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_background_category_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Resources resources;
        holder.txt.setText(((n) this.QuoteList.get(position)).f);
        int i2 = this.SelectedPosition;
        int i3 = R.color.black;
        holder.txt.setTextColor(position == i2 ? activity.getResources().getColor(R.color.white) : activity.getResources().getColor(R.color.black));
        if (position == SelectedPosition) {
            resources = activity.getResources();
        } else {
            resources = activity.getResources();
            i3 = R.color.transparent;
        }
        holder.txt.setBackgroundColor(resources.getColor(i3));
        holder.rlMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                activity.h0(activity, position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.QuoteList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.rlMain)
        public RelativeLayout rlMain;
        @BindView(R.id.txt)
        public TextView txt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
