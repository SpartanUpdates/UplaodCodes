package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.view.View;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class r5 implements View.OnClickListener {
    public final FrameEditorNewDesign e;

    public r5(final FrameEditorNewDesign e) {
        this.e = e;
    }

    public void onClick(final View view) {
        this.e.m1.dismiss();
    }
}
