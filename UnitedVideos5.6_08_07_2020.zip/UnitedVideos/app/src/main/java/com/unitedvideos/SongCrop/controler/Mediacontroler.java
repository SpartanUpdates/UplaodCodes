package com.unitedvideos.SongCrop.controler;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;

import com.unitedvideos.Adapter.PhoneSongAdapter;
import com.unitedvideos.activity.PhoneSongActivity;


public class Mediacontroler {
//    private AssetManager assetManager;
//    private String b = null;
//    public MediaPlayer mediaPlayer = new MediaPlayer();
//
//    class musiclistener implements OnPreparedListener {
//        final Mediacontroler mediacontroler;
//
//        musiclistener(Mediacontroler mediacontroler) {
//            this.mediacontroler = mediacontroler;
//        }
//
//        public void onPrepared(MediaPlayer mediaPlayer) {
//            if (PhoneSongAdapter.IsSongPlay) {
//                mediaPlayer.start();
//            } else {
//                PhoneSongAdapter.IsSongPlay = true;
//            }
//        }
//    }
//
//    public Mediacontroler(Context context) {
//        this.assetManager = context.getAssets();
//    }
//
//    public String a() {
//        return this.b;
//    }
//
//    public void a(long j) {
//        this.mediaPlayer.seekTo((int) j);
//    }
//
//    public void a(String str) {
//        this.b = str;
//    }
//
//    public void b() {
//        this.mediaPlayer.reset();
//        try {
//            this.mediaPlayer.setDataSource(this.b);
//            this.mediaPlayer.prepare();
//            this.mediaPlayer.setOnPreparedListener(new musiclistener(this));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public int c() {
//        return this.mediaPlayer.getCurrentPosition();
//    }
//
//    public void d() {
//        if (this.mediaPlayer.isPlaying()) {
//            this.mediaPlayer.pause();
//        }
//    }
//
//    public boolean e() {
//        return this.mediaPlayer.isPlaying();
//    }
//
//    public void f() {
//        if (!this.mediaPlayer.isPlaying()) {
//            this.mediaPlayer.start();
//        }
//    }
//
//    public void g() {
//        if (this.mediaPlayer.isPlaying()) {
//            this.mediaPlayer.stop();
//        }
//    }


    private AssetManager f6062a;
    private String f6063b = null;
    private MediaPlayer f6064c = new MediaPlayer();

    public Mediacontroler(Context context) {
        this.f6062a = context.getAssets();
    }

    public String a() {
        return this.f6063b;
    }

    public void a(long j) {
        this.f6064c.seekTo((int) j);
    }

    public void a(String str) {
        this.f6063b = str;
    }

    public void b() {
        this.f6064c.reset();
        try {
            this.f6064c.setDataSource(this.f6063b);
            this.f6064c.prepare();
            this.f6064c.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer mediaPlayer) {
                    if (PhoneSongActivity.l) {
                        mediaPlayer.start();
                    } else {
                        PhoneSongActivity.l = true;
                    }
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public int c() {
        return this.f6064c.getCurrentPosition();
    }

    public void d() {
        if (this.f6064c.isPlaying()) {
            this.f6064c.pause();
        }
    }

    public boolean e() {
        return this.f6064c.isPlaying();
    }

    public void f() {
        if (!this.f6064c.isPlaying()) {
            this.f6064c.start();
        }
    }

    public void g() {
        if (this.f6064c.isPlaying()) {
            this.f6064c.stop();
        }
    }
}
