package game.kidspop.gk.quiz.info;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import java.util.Random;

public class QuizPlayActivity extends AppCompatActivity {
    Activity activity = QuizPlayActivity.this;
    String QAns;
    int mLifeLUsed5050 = 0;
    MediaPlayer mMediaPlayer;
    int mQlevelSNo = 0;
    String mQueLang = "";
    LinearLayout villQuizQA;
    TextView vitvQLevelNo01;
    TextView vitvQLevelNo02;
    TextView vitvQLevelNo03;
    TextView vitvQLevelNo04;
    TextView vitvQLevelNo05;
    TextView vitvQLevelNo06;
    TextView vitvQLevelNo07;
    TextView vitvQLevelNo08;
    TextView vitvQLevelNo09;
    TextView vitvQLevelNo10;
    TextView vitvQLevelNo11;
    TextView vitvQLevelNo12;
    TextView vitvQLevelNo13;
    TextView vitvQLevelNo14;
    TextView vitvQLevelNo15;
    TextView vitvQLevelNo16;
    TextView vitvQLevelNo17;
    TextView vitvQLevelNo18;
    TextView vitvQLevelNo19;
    TextView vitvQLevelNo20;
    ImageView vivLifeL501;
    ImageView vivLifeL502;
    ImageView vivLifeLFlip1;
    ImageView vivLifeLFlip2;
    RelativeLayout vrlA;
    RelativeLayout vrlB;
    RelativeLayout vrlC;
    RelativeLayout vrlD;
    TextView vtvQA;
    TextView vtvQB;
    TextView vtvQC;
    TextView vtvQD;
    TextView vtvQQ;
    TextView vtvWinAmt;
    String[] str = new String[]{"50", "100", "150", "200", "250", "300", "500", "600", "700", "800", "900", "1000", "2000", "3000", "4000", "5000", "7000", "9000", "12000", "15000"
    };

    private void prc_Analytics_Tracker_ScreenName(String str) {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getSupportActionBar().hide();
        getWindow().setFlags(1024, 1024);
        setContentView((int) R.layout.activity_quiz_play);
        new mClassDBHelper(this).prcCreateDatabase();
        prc_Update_QSeenFlag_NewDB();
        this.vivLifeLFlip2 = (ImageView) findViewById(R.id.iivLifeLFlip2);
        this.vivLifeLFlip1 = (ImageView) findViewById(R.id.iivLifeLFlip1);
        this.vivLifeL502 = (ImageView) findViewById(R.id.iivLifeL502);
        this.vivLifeL501 = (ImageView) findViewById(R.id.iivLifeL501);
        this.vitvQLevelNo01 = (TextView) findViewById(R.id.itvQLevelNo01);
        this.vitvQLevelNo11 = (TextView) findViewById(R.id.itvQLevelNo11);
        this.vitvQLevelNo02 = (TextView) findViewById(R.id.itvQLevelNo02);
        this.vitvQLevelNo12 = (TextView) findViewById(R.id.itvQLevelNo12);
        this.vitvQLevelNo03 = (TextView) findViewById(R.id.itvQLevelNo03);
        this.vitvQLevelNo13 = (TextView) findViewById(R.id.itvQLevelNo13);
        this.vitvQLevelNo04 = (TextView) findViewById(R.id.itvQLevelNo04);
        this.vitvQLevelNo14 = (TextView) findViewById(R.id.itvQLevelNo14);
        this.vitvQLevelNo05 = (TextView) findViewById(R.id.itvQLevelNo05);
        this.vitvQLevelNo15 = (TextView) findViewById(R.id.itvQLevelNo15);
        this.vitvQLevelNo06 = (TextView) findViewById(R.id.itvQLevelNo06);
        this.vitvQLevelNo16 = (TextView) findViewById(R.id.itvQLevelNo16);
        this.vitvQLevelNo07 = (TextView) findViewById(R.id.itvQLevelNo07);
        this.vitvQLevelNo17 = (TextView) findViewById(R.id.itvQLevelNo17);
        this.vitvQLevelNo08 = (TextView) findViewById(R.id.itvQLevelNo08);
        this.vitvQLevelNo18 = (TextView) findViewById(R.id.itvQLevelNo18);
        this.vitvQLevelNo09 = (TextView) findViewById(R.id.itvQLevelNo09);
        this.vitvQLevelNo19 = (TextView) findViewById(R.id.itvQLevelNo19);
        this.vitvQLevelNo10 = (TextView) findViewById(R.id.itvQLevelNo10);
        this.vitvQLevelNo20 = (TextView) findViewById(R.id.itvQLevelNo20);
        this.vtvWinAmt = (TextView) findViewById(R.id.itvWinningAmt);
        this.vtvQQ = (TextView) findViewById(R.id.itvQuizQ);
        this.vtvQB = (TextView) findViewById(R.id.itvQuizB);
        this.vtvQC = (TextView) findViewById(R.id.itvQuizC);
        this.vtvQA = (TextView) findViewById(R.id.itvQuizA);
        this.vtvQD = (TextView) findViewById(R.id.itvQuizD);
        this.villQuizQA = (LinearLayout) findViewById(R.id.illQuizQA);
        this.vrlD = (RelativeLayout) findViewById(R.id.irlQuizD);
        this.vrlB = (RelativeLayout) findViewById(R.id.irlQuizB);
        this.vrlA = (RelativeLayout) findViewById(R.id.irlQuizA);
        this.vrlC = (RelativeLayout) findViewById(R.id.irlQuizC);
        this.mQueLang = mClassUtil.getspv_QueLang(this);
        mClassUtil.setspv_CountQuizPlay(this, Integer.valueOf(Integer.valueOf(mClassUtil.getspv_CountQuizPlay(this)).intValue() + 1));
        prc_start_the_Quiz_Now();
        loadAd();
    }

    public void prc_onClick_RL_Quiz_AnsC(View view) {
        prc_check_Q_Ans(view, "C");
    }

    public void prc_onClick_RL_Quiz_AnsA(View view) {
        prc_check_Q_Ans(view, "A");
    }

    public void prc_onClick_RL_Quiz_AnsD(View view) {
        prc_check_Q_Ans(view, "D");
    }

    public void prc_onClick_RL_Quiz_AnsB(View view) {
        prc_check_Q_Ans(view, "B");
    }

    public void prc_onClick_LifeL_Flip2(View view) {
        view.setClickable(false);
        this.vivLifeLFlip2.setImageResource(R.drawable.icon_skip_used);
        prc_LifeL_Flip();
    }

    public void prc_onClick_LifeL_502(View view) {
        if (this.mLifeLUsed5050 != 1) {
            this.mLifeLUsed5050 = 1;
            view.setClickable(false);
            this.vivLifeL502.setImageResource(R.drawable.icon_life_used);
            prc_LifeL_5050();
        }
    }

    public void prc_onClick_LifeL_501(View view) {
        if (this.mLifeLUsed5050 != 1) {
            this.mLifeLUsed5050 = 1;
            view.setClickable(false);
            this.vivLifeL501.setImageResource(R.drawable.icon_life_used);
            prc_LifeL_5050();
        }
    }

    public void prc_onClick_LifeL_Flip1(View view) {
        view.setClickable(false);
        this.vivLifeLFlip1.setImageResource(R.drawable.icon_skip_used);
        prc_LifeL_Flip();
    }

    private void prc_Reset_Que_SeenFlag() {
        Integer valueOf = Integer.valueOf(0);
        SQLiteDatabase OpenSQLiteDatabase = mClassUtil.OpenSQLiteDatabase(this);
        Cursor rawQuery = OpenSQLiteDatabase.rawQuery("SELECT count(*) as n FROM tableKQ where SeenFlag is null", null);
        if (rawQuery != null && rawQuery.moveToFirst()) {
            Integer.valueOf(520);
            valueOf = Integer.valueOf(Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("n"))));
        }
        rawQuery.close();
        if (valueOf.intValue() < 20) {
            OpenSQLiteDatabase.execSQL("Update tableKQ set SeenFlag=null");
        }
        OpenSQLiteDatabase.close();
    }

    private void prc_show_the_QuestionAns() {
        SQLiteDatabase sQLiteDatabase;
        this.villQuizQA.setVisibility(View.INVISIBLE);
        Object valueOf = Integer.valueOf(0);
        SQLiteDatabase OpenSQLiteDatabase = mClassUtil.OpenSQLiteDatabase(this);
        Cursor rawQuery = OpenSQLiteDatabase.rawQuery("SELECT * FROM tableKQ where SeenFlag is null ORDER BY RANDOM() LIMIT 1", null);
        if (rawQuery == null || !rawQuery.moveToFirst()) {
            sQLiteDatabase = OpenSQLiteDatabase;
        } else {
            Integer valueOf2 = Integer.valueOf(Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("ID"))));
            String str = "QE";
            String string = rawQuery.getString(rawQuery.getColumnIndex(str));
            String str2 = "QH";
            String string2 = rawQuery.getString(rawQuery.getColumnIndex(str2));
            String str3 = "BE";
            String str4 = "AE";
            String str5 = "DE";
            String str6 = "CE";
            String str7 = "BH";
            String str8 = "DH";
            String str9 = "AH";
            Integer num = valueOf2;
            String str10 = "CH";
            sQLiteDatabase = OpenSQLiteDatabase;
            String str11 = "";
            if (this.mQueLang.toUpperCase().equals("ENGLISH")) {
                if (string.equals(str11)) {
                    this.vtvQQ.setText(rawQuery.getString(rawQuery.getColumnIndex(str2)));
                    this.vtvQC.setText(rawQuery.getString(rawQuery.getColumnIndex(str10)));
                    this.vtvQD.setText(rawQuery.getString(rawQuery.getColumnIndex(str8)));
                    this.vtvQA.setText(rawQuery.getString(rawQuery.getColumnIndex(str9)));
                    this.vtvQB.setText(rawQuery.getString(rawQuery.getColumnIndex(str7)));
                    Toast.makeText(this, "Sorry! This Question is available in Hindi.", Toast.LENGTH_SHORT).show();
                } else {
                    this.vtvQQ.setText(rawQuery.getString(rawQuery.getColumnIndex(str)));
                    this.vtvQC.setText(rawQuery.getString(rawQuery.getColumnIndex(str6)));
                    this.vtvQD.setText(rawQuery.getString(rawQuery.getColumnIndex(str5)));
                    this.vtvQA.setText(rawQuery.getString(rawQuery.getColumnIndex(str4)));
                    this.vtvQB.setText(rawQuery.getString(rawQuery.getColumnIndex(str3)));
                }
            } else if (string2.equals(str11)) {
                this.vtvQQ.setText(rawQuery.getString(rawQuery.getColumnIndex(str)));
                this.vtvQC.setText(rawQuery.getString(rawQuery.getColumnIndex(str6)));
                this.vtvQD.setText(rawQuery.getString(rawQuery.getColumnIndex(str5)));
                this.vtvQA.setText(rawQuery.getString(rawQuery.getColumnIndex(str4)));
                this.vtvQB.setText(rawQuery.getString(rawQuery.getColumnIndex(str3)));
                Toast.makeText(this, "माफ़ कीजिए! यह प्रश्न अभी अंग्रेगी में उपलब्ध है", Toast.LENGTH_SHORT).show();
            } else {
                this.vtvQQ.setText(rawQuery.getString(rawQuery.getColumnIndex(str2)));
                this.vtvQC.setText(rawQuery.getString(rawQuery.getColumnIndex(str10)));
                this.vtvQA.setText(rawQuery.getString(rawQuery.getColumnIndex(str9)));
                this.vtvQD.setText(rawQuery.getString(rawQuery.getColumnIndex(str8)));
                this.vtvQB.setText(rawQuery.getString(rawQuery.getColumnIndex(str7)));
            }
            this.QAns = rawQuery.getString(rawQuery.getColumnIndex("QAns")).toUpperCase();
            valueOf = num;
        }
        rawQuery.close();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Update tableKQ set SeenFlag='Y' where id='");
        stringBuilder.append(valueOf);
        stringBuilder.append("'");
        SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase;
        sQLiteDatabase2.execSQL(stringBuilder.toString());
        sQLiteDatabase2.close();
        this.vrlB.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_ans));
        this.vrlD.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_ans));
        this.vrlA.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_ans));
        this.vrlC.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_ans));
        this.vrlB.setClickable(true);
        this.vrlD.setClickable(true);
        this.vrlC.setClickable(true);
        this.vrlA.setClickable(true);
        this.mQlevelSNo++;
        prc_set_Level_ScoreBoard();
        this.mLifeLUsed5050 = 0;
        new Handler().postDelayed(new Runnable() {
            public void run() {
                if (mQlevelSNo % 4 == 0) {
                    Log.e("Call", "======QUIZ Module 4===");
                    idd = 101;
                    if (mInterstitialAd.isAdLoaded() && mInterstitialAd != null) {
                        mInterstitialAd.show();
                    } else {
                        QuizPlayActivity.this.villQuizQA.setVisibility(View.VISIBLE);
                        QuizPlayActivity quizPlayActivity = QuizPlayActivity.this;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("PQL-Num-");
                        stringBuilder.append(Integer.toString(QuizPlayActivity.this.mQlevelSNo));
                        quizPlayActivity.prc_Analytics_Tracker_ScreenName(stringBuilder.toString());
                    }
                } else {
                    QuizPlayActivity.this.villQuizQA.setVisibility(View.VISIBLE);
                    QuizPlayActivity quizPlayActivity = QuizPlayActivity.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("PQL-Num-");
                    stringBuilder.append(Integer.toString(QuizPlayActivity.this.mQlevelSNo));
                    quizPlayActivity.prc_Analytics_Tracker_ScreenName(stringBuilder.toString());
                }
            }
        }, 500);
    }

    private void prc_start_the_Quiz_Now() {
        prc_Reset_Que_SeenFlag();
        this.vtvWinAmt.setText("");
        this.mQlevelSNo = 0;
        this.vivLifeLFlip1.setClickable(true);
        this.vivLifeL501.setClickable(true);
        this.vivLifeL502.setClickable(true);
        this.vivLifeLFlip2.setClickable(true);
        this.vivLifeLFlip2.setImageResource(R.drawable.icon_life_flip);
        this.vivLifeL501.setImageResource(R.drawable.icon_life_50);
        this.vivLifeLFlip1.setImageResource(R.drawable.icon_life_flip);
        this.vivLifeL502.setImageResource(R.drawable.icon_life_50);
        prc_show_the_QuestionAns();
    }

    private void prc_check_Q_Ans(View view, String str) {
        String str2 = "N";
        final String str3 = str.equals(this.QAns) ? "Y" : str2;
        String str4 = "A";
        String str5 = "D";
        String str6 = "C";
        String str7 = "B";
        RelativeLayout relativeLayout = null;
        RelativeLayout relativeLayout2 = this.QAns.equals(str4) ? this.vrlA : this.QAns.equals(str7) ? this.vrlB : this.QAns.equals(str6) ? this.vrlC : this.QAns.equals(str5) ? this.vrlD : null;
        if (str3.equals(str2)) {
            if (str.equals(str4)) {
                relativeLayout = this.vrlA;
            } else if (str.equals(str7)) {
                relativeLayout = this.vrlB;
            } else if (str.equals(str6)) {
                relativeLayout = this.vrlC;
            } else if (str.equals(str5)) {
                relativeLayout = this.vrlD;
            }
        }
        if (relativeLayout != null) {
            relativeLayout.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_r));
        }
        if (relativeLayout2 != null) {
            relativeLayout2.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_g));
        }
        this.vrlB.setClickable(false);
        this.vrlA.setClickable(false);
        this.vrlD.setClickable(false);
        this.vrlC.setClickable(false);
        prc_play_Sound_Music(str3);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                if (str3.equals("N")) {
                    idd = 102;
                    if (mInterstitialAd.isAdLoaded()) {
                        mInterstitialAd.show();
                    } else {
                        QuizPlayActivity.this.prc_goto_Win_or_Loss_Activity(false);
                    }
                } else if (QuizPlayActivity.this.mQlevelSNo < 20) {
                    QuizPlayActivity.this.prc_set_Level_Wining_Amt();
                    QuizPlayActivity.this.prc_show_the_QuestionAns();
                } else {
                    QuizPlayActivity.this.prc_set_Level_Wining_Amt();
                    QuizPlayActivity.this.prc_goto_Win_or_Loss_Activity(true);
                    QuizPlayActivity.this.prc_play_Sound_Music("W");

                }
            }
        }, 3000);
    }

    private void prc_LifeL_Flip() {
        this.mQlevelSNo--;
        prc_show_the_QuestionAns();
    }


    private void prc_LifeL_5050() {
        int n;
        if (this.QAns.equals("A")) {
            n = 1;
        } else if (this.QAns.equals("B")) {
            n = 2;
        } else if (this.QAns.equals("C")) {
            n = 3;
        } else if (this.QAns.equals("D")) {
            n = 4;
        } else {
            n = 0;
        }
        final Random random = new Random();
        final int n2 = random.nextInt(4) + 1;
        final int n3 = random.nextInt(4) + 1;
        int n4 = n2;
        if (n2 > 4) {
            n4 = 4;
        }
        int n5;
        if ((n5 = n3) > 4) {
            n5 = 4;
        }
        int n6;
        if ((n6 = n4) < 1) {
            n6 = 1;
        }
        int n7;
        if ((n7 = n5) < 1) {
            n7 = 1;
        }
        int n8;
        if ((n8 = n6) == n7) {
            if (n6 < 4) {
                n8 = n6 + 1;
            } else {
                n8 = n6 - 1;
            }
        }
        int n9;
        if (n7 == n) {
            n9 = n8;
        } else {
            n9 = n7;
            n7 = n8;
        }
        int n10 = n7;
        Label_0247:
        {
            if (n7 == n) {
                if (n7 < 4) {
                    n10 = n7 + 1;
                    if (n10 != n9) {
                        break Label_0247;
                    }
                    if (n10 < 4) {
                        n10 = n7 + 2;
                        break Label_0247;
                    }
                } else {
                    if ((n10 = n7) != 4) {
                        break Label_0247;
                    }
                    if (n9 == 3) {
                        n10 = n7 - 2;
                        break Label_0247;
                    }
                }
                n10 = n7 - 1;
            }
        }
        RelativeLayout relativeLayout = null;
        RelativeLayout relativeLayout2;
        if (n10 == 1) {
            relativeLayout2 = this.vrlA;
        } else if (n10 == 2) {
            relativeLayout2 = this.vrlB;
        } else if (n10 == 3) {
            relativeLayout2 = this.vrlC;
        } else if (n10 == 4) {
            relativeLayout2 = this.vrlD;
        } else {
            relativeLayout2 = null;
        }
        if (n9 == 1) {
            relativeLayout = this.vrlA;
        } else if (n9 == 2) {
            relativeLayout = this.vrlB;
        } else if (n9 == 3) {
            relativeLayout = this.vrlC;
        } else if (n9 == 4) {
            relativeLayout = this.vrlD;
        }
        relativeLayout2.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_qa50));
        relativeLayout.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_qa50));
        relativeLayout2.setClickable(false);
        relativeLayout.setClickable(false);
    }

    private void prc_set_Level_Wining_Amt() {
        this.vtvWinAmt.setText(str[this.mQlevelSNo - 1]);
    }

    private void prc_set_Level_ScoreBoard() {
        int i = this.mQlevelSNo;
        TextView textView = i == 1 ? this.vitvQLevelNo01 : i == 2 ? this.vitvQLevelNo02 : i == 3 ? this.vitvQLevelNo03 : i == 4 ? this.vitvQLevelNo04 : i == 5 ? this.vitvQLevelNo05 : i == 6 ? this.vitvQLevelNo06 : i == 7 ? this.vitvQLevelNo07 : i == 8 ? this.vitvQLevelNo08 : i == 9 ? this.vitvQLevelNo09 : i == 10 ? this.vitvQLevelNo10 : i == 11 ? this.vitvQLevelNo11 : i == 12 ? this.vitvQLevelNo12 : i == 13 ? this.vitvQLevelNo13 : i == 14 ? this.vitvQLevelNo14 : i == 15 ? this.vitvQLevelNo15 : i == 16 ? this.vitvQLevelNo16 : i == 17 ? this.vitvQLevelNo17 : i == 18 ? this.vitvQLevelNo18 : i == 19 ? this.vitvQLevelNo19 : i == 20 ? this.vitvQLevelNo20 : null;
        this.vitvQLevelNo01.setBackground(null);
        this.vitvQLevelNo02.setBackground(null);
        this.vitvQLevelNo19.setBackground(null);
        this.vitvQLevelNo20.setBackground(null);
        this.vitvQLevelNo05.setBackground(null);
        this.vitvQLevelNo06.setBackground(null);
        this.vitvQLevelNo13.setBackground(null);
        this.vitvQLevelNo14.setBackground(null);
        this.vitvQLevelNo09.setBackground(null);
        this.vitvQLevelNo10.setBackground(null);
        this.vitvQLevelNo11.setBackground(null);
        this.vitvQLevelNo12.setBackground(null);
        this.vitvQLevelNo15.setBackground(null);
        this.vitvQLevelNo07.setBackground(null);
        this.vitvQLevelNo08.setBackground(null);
        this.vitvQLevelNo16.setBackground(null);
        this.vitvQLevelNo17.setBackground(null);
        this.vitvQLevelNo18.setBackground(null);
        this.vitvQLevelNo03.setBackground(null);
        this.vitvQLevelNo04.setBackground(null);
        textView.setBackground(getResources().getDrawable(R.drawable.dr_bg_button_qlevel_no));
    }

    private void prc_goto_Win_or_Loss_Activity(boolean z) {
        String str = mClassUtil.getspv_PlayerName(this);
        String charSequence = this.vtvWinAmt.getText().toString();
        if (charSequence.equals("")) {
            charSequence = "0";
        }
        SQLiteDatabase OpenOrCreateLocalDatabase = OpenOrCreateLocalDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select count(*) as n from tblHighScore where PlayerName='");
        stringBuilder.append(str);
        stringBuilder.append("' and WinScore>='");
        stringBuilder.append(charSequence);
        String str2 = "'";
        stringBuilder.append(str2);
        Cursor rawQuery = OpenOrCreateLocalDatabase.rawQuery(stringBuilder.toString(), null);
        Object obj = (rawQuery == null || !rawQuery.moveToFirst() || Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("n"))) <= 0) ? null : 1;
        rawQuery.close();
        if (obj == null) {
            Object valueOf = Integer.valueOf(0);
            if (z) {
                valueOf = Integer.valueOf(1);
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("delete from tblHighScore where PlayerName='");
            stringBuilder2.append(str);
            stringBuilder2.append(str2);
            OpenOrCreateLocalDatabase.execSQL(stringBuilder2.toString());
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("insert into tblHighScore (PlayerName,WinScore,WinCount) values('");
            stringBuilder3.append(str);
            String str3 = "','";
            stringBuilder3.append(str3);
            stringBuilder3.append(charSequence);
            stringBuilder3.append(str3);
            stringBuilder3.append(valueOf);
            stringBuilder3.append("')");
            OpenOrCreateLocalDatabase.execSQL(stringBuilder3.toString());
        } else if (z) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Update tblHighScore Set WinCount=WinCount+1 where PlayerName='");
            stringBuilder.append(str);
            stringBuilder.append(str2);
            OpenOrCreateLocalDatabase.execSQL(stringBuilder.toString());
        }
        OpenOrCreateLocalDatabase.close();
        Intent intent = new Intent(getApplicationContext(), QuizPlayWinLossActivity.class);
        intent.putExtra("QL", this.mQlevelSNo);
        intent.putExtra("isQuizWon", z);
        intent.putExtra("WinningAmt", charSequence);
        intent.putExtra("PlayerName", str);
        startActivity(intent);
        finish();

    }


    private SQLiteDatabase OpenOrCreateLocalDatabase() {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            sQLiteDatabase = openOrCreateDatabase("AppLocalDb.db", 0, null);
            sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS tblHighScore('PlayerName' TEXT,'WinScore' NUMERIC,'WinCount' NUMERIC,'Col1' TEXT,'Col2' TEXT,'Col3' TEXT);");
            return sQLiteDatabase;
        } catch (Exception unused) {
            return sQLiteDatabase;
        }
    }

    public void prc_Update_QSeenFlag_NewDB() {
        try {
            if (mClassUtil.getspv_DbUpdateQSeenFlag(this).equals("Y")) {
                String str = "'0'";
                SQLiteDatabase OpenSQLiteDatabase_Old_SF = mClassUtil.OpenSQLiteDatabase_Old_SF(this);
                Cursor rawQuery = OpenSQLiteDatabase_Old_SF.rawQuery("SELECT ID FROM tableKQ where SeenFlag is not null", null);
                if (rawQuery != null) {
                    rawQuery.moveToFirst();
                    while (!rawQuery.isAfterLast()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(str);
                        stringBuilder.append(",'");
                        stringBuilder.append(rawQuery.getString(rawQuery.getColumnIndex("ID")));
                        stringBuilder.append("'");
                        str = stringBuilder.toString();
                        rawQuery.moveToNext();
                    }
                }
                rawQuery.close();
                OpenSQLiteDatabase_Old_SF.close();
                OpenSQLiteDatabase_Old_SF = mClassUtil.OpenSQLiteDatabase(this);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Update tableKQ set SeenFlag='Y' where id in (");
                stringBuilder2.append(str);
                stringBuilder2.append(")");
                OpenSQLiteDatabase_Old_SF.execSQL(stringBuilder2.toString());
                OpenSQLiteDatabase_Old_SF.close();
                mClassUtil.setspv_DbUpdateQSeenFlag(this, "N");
                Toast.makeText(this, "SF Done.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception unused) {
            Toast.makeText(this, "SF Error!...", Toast.LENGTH_SHORT).show();
        }
    }

    private void prc_play_Sound_Music(String str) {
        try {
            if (str.equals("Y")) {
                this.mMediaPlayer = MediaPlayer.create(this, R.raw.ans_c);
            } else if (str.equals("N")) {
                this.mMediaPlayer = MediaPlayer.create(this, R.raw.ans_w);
            } else if (str.equals("W")) {
                this.mMediaPlayer = MediaPlayer.create(this, R.raw.win_clap);
            }
            this.mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                public void onCompletion(MediaPlayer mediaPlayer) {
                    mediaPlayer.release();
                }
            });
            this.mMediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onBackPressed() {
        new AlertDialog.Builder(this).setTitle((CharSequence) "Confirm").setMessage((CharSequence) "Do you want to left the Quiz still running?").setPositiveButton((CharSequence) "Yes", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                QuizPlayActivity.this.finish();
            }
        }).setNegativeButton((CharSequence) "No", null).show();
    }

    private InterstitialAd mInterstitialAd;
    private int idd;

    private void loadAd() {
        mInterstitialAd = new InterstitialAd(activity, getResources().getString(R.string.fb_interstitial));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (idd) {
                    case 101:
                        QuizPlayActivity.this.villQuizQA.setVisibility(View.VISIBLE);
                        QuizPlayActivity quizPlayActivity = QuizPlayActivity.this;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("PQL-Num-");
                        stringBuilder.append(Integer.toString(QuizPlayActivity.this.mQlevelSNo));
                        quizPlayActivity.prc_Analytics_Tracker_ScreenName(stringBuilder.toString());
                        break;
                    case 102:
                        QuizPlayActivity.this.prc_goto_Win_or_Loss_Activity(false);
                        break;

                }
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
    }

    private void requestNewInterstitial() {
        mInterstitialAd = new InterstitialAd(activity, getResources().getString(R.string.fb_interstitial));
        mInterstitialAd.loadAd();
    }
}