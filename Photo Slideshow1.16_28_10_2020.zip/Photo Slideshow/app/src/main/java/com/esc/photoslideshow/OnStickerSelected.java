package com.esc.photoslideshow;

import android.graphics.Typeface;

public interface OnStickerSelected {
    void onStickerTouch(int i);

    void onTextStyleChange(Typeface typeface);
}
