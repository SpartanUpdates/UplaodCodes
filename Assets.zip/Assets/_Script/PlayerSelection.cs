﻿using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSelection : MonoBehaviour
{
    public static PlayerSelection instane;

    public GameObject pencilMain, eraserMain,noAdsPanel, coinGetparticles;

    public GameObject[] pencilLock;

    public GameObject[] pencilObject;

    public GameObject[] eraserLock;

    public GameObject[] eraserObject;

    public GameObject priceObj;

    [HideInInspector]
    public int currentPencil = 0, currentEraser = 0;

    int lastSelectedPencil = 0, lastSelectedEraser;

    [HideInInspector]
    public bool isRewardClick = false,isRewardDone=false;
    void Awake()
    {
        instane = this;
        if (!PlayerPrefs.HasKey("PencilSelect"))
        {
            PlayerPrefs.SetInt("PencilSelect0", 1);
            PlayerPrefs.SetInt("EraserSelect0", 1);
        }
    }
    public void OnStart()
    {
        for (int i = 0; i < pencilLock.Length; i++)
        {
            pencilObject[i].SetActive(false);
            if (PlayerPrefs.GetInt("PencilSelect" + i) == 1)
            {
                pencilLock[i].SetActive(false);
            }
        }
        pencilObject[PlayerPrefs.GetInt("Pencil")].SetActive(true);
        priceObj.SetActive(false);
        currentPencil = PlayerPrefs.GetInt("Pencil");
        lastSelectedPencil = currentPencil;
        pencilMain.SetActive(true);
        eraserMain.SetActive(false);
    }

    public void OnPlayerSelect(int no)
    {
        ButtonClickSound();

        pencilObject[lastSelectedPencil].SetActive(false);
        pencilObject[no].SetActive(true);
        lastSelectedPencil = no;
        if (PlayerPrefs.GetInt("PencilSelect" + no) == 0)
        {
            priceObj.SetActive(true);
        }
        else
        {
            priceObj.SetActive(false);
            PlayerPrefs.SetInt("Pencil", no);
        }
        currentPencil = no;
    }
    public void OnStartEraser()
    {
        for (int i = 0; i < eraserLock.Length; i++)
        {
            eraserObject[i].SetActive(false);
            if (PlayerPrefs.GetInt("EraserSelect" + i) == 1)
            {
                eraserLock[i].SetActive(false);
            }
        }
        eraserObject[PlayerPrefs.GetInt("Eraser")].SetActive(true);
        priceObj.SetActive(false);
        currentEraser = PlayerPrefs.GetInt("Eraser");
        lastSelectedEraser = currentEraser;
    }
    public void OnEraserSelect(int no)
    {

        ButtonClickSound();

        eraserObject[lastSelectedEraser].SetActive(false);
        eraserObject[no].SetActive(true);
        lastSelectedEraser = no;
        if (PlayerPrefs.GetInt("EraserSelect" + no) == 0)
        {
            priceObj.SetActive(true);
        }
        else
        {
            priceObj.SetActive(false);
            PlayerPrefs.SetInt("Eraser", no);
        }
        currentEraser = no;
    }

    public string cntPlayer = "pencil";

    public void OnBuyClick()
    {
        if (PlayerPrefs.GetInt("Coins") >= 300)
        {
            SoundManger.instance.itemPurchase.Play();
            SoundManger.instance.Vibrate();
            priceObj.SetActive(false);
            PlayerPrefs.SetInt("Coins", PlayerPrefs.GetInt("Coins") - 300);
            if (cntPlayer == "pencil")
            {
                PlayerPrefs.SetInt("PencilSelect" + currentPencil, 1);
                PlayerPrefs.SetInt("Pencil", currentPencil);
                pencilLock[currentPencil].SetActive(false);
            }
            else
            {
                PlayerPrefs.SetInt("EraserSelect" + currentEraser, 1);
                PlayerPrefs.SetInt("Eraser", currentEraser);
                eraserLock[currentEraser].SetActive(false);
            }
        }
        else
        {
            ButtonClickSound();
            priceObj.GetComponent<CameraShake>().enabled = false;
            priceObj.GetComponent<CameraShake>().enabled = true;
        }
    }
    public void BtnShowRewared()
    {
        coinGetparticles.SetActive(false);
        ButtonClickSound();
        if (RewardAddShow.instance.rewardBasedVideo.IsLoaded())
        {
            RewardAddShow.instance.ShowVideo();
            isRewardClick = true;
        }
        else
        {
            noAdsPanel.SetActive(true);
            RewardAddShow.instance.RequestRewardBasedVideo();
            Invoke("CloseNoAddPanel", 2);
        }
    }
    public void RewardDone()
    {
        isRewardClick = false;
        if (isRewardDone)
        {
            StartCoroutine(CoinAdd());
            isRewardDone = false;
        }
    }
    IEnumerator CoinAdd()
    {
        int a = 0;
        WaitForSecondsRealtime delay = new WaitForSecondsRealtime(0.1f);
        while (a != 100)
        {
            a += 4;
            PlayerPrefs.SetInt("Coins", PlayerPrefs.GetInt("Coins") + 4);
            if (a > 20 && !coinGetparticles.activeSelf)
            {
                coinGetparticles.SetActive(true);
            }
            yield return 0;
        }
        yield return delay;
        a = 0;
    }
    void CloseNoAddPanel()
    {
        noAdsPanel.SetActive(false);
    }
    void ButtonClickSound()
    {
        SoundManger.instance.Vibrate();
        if (!SoundManger.instance.btnClick.isPlaying)
            SoundManger.instance.btnClick.Play();
    }
}
