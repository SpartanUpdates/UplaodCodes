package com.esc.photovault.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.andrognito.pinlockview.IndicatorDots;
import com.andrognito.pinlockview.PinLockListener;
import com.andrognito.pinlockview.PinLockView;
import com.esc.photovault.R;
import com.esc.photovault.kprogresshud.KProgressHUD;
import com.esc.photovault.model.BreakModel;
import com.esc.photovault.util.FingerprintHandler;
import com.esc.photovault.util.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hiddencamera.CameraConfig;
import com.hiddencamera.CameraError;
import com.hiddencamera.HiddenCameraActivity;
import com.hiddencamera.HiddenCameraFragment;
import com.hiddencamera.config.CameraImageFormat;
import com.hiddencamera.config.CameraRotation;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class LockScreenActivity extends HiddenCameraActivity {

    private Activity activity = LockScreenActivity.this;
    private static final String KEY_NAME = "PhotoVault";
    public static ArrayList<BreakModel> break_data_array = new ArrayList();
    public static boolean lock_status;
    private ImageView background_color;
    private Cipher cipher = null;
    private RelativeLayout dialog_box_email_rel;
    private RelativeLayout dialog_box_passcode_rel;
    private TextView enter_datatype;
    private TextView forget_pwd_txt;
    private ImageView image_bg;
    private Double latitude = Double.valueOf(0.0d);
    private Double longitude = Double.valueOf(0.0d);
    private CameraConfig mCameraConfig;
    private HiddenCameraFragment mHiddenCameraFragment;
    private IndicatorDots mIndicatorDots;
    private PinLockListener mPinLockListener = new PinLock();
    private PinLockView mPinLockView;
    private String passcode;
    private String pwd = "";
    private String theme_type;
    private String wrong_passcode;
    private int Permission_Request_Code = 123;
    private SharedPreferences prefs4;
    private Editor editor;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;
    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private String[] PERMISSIONS =
    {
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    class PinLock implements PinLockListener {

        class C06221 implements Runnable {
            C06221() {
            }

            public void run() {
                LockScreenActivity.this.takePicture();
            }
        }

        PinLock() {
        }

        public void onComplete(String pin) {
            LockScreenActivity.this.passcode = prefs4.getString("pwd", "");

            if (LockScreenActivity.this.passcode.equals("") && LockScreenActivity.this.pwd.equals("")) {
                editor = LockScreenActivity.this.getSharedPreferences("VARIABLE", 0).edit();
                editor.putBoolean("first time", true);
                editor.commit();
                LockScreenActivity.this.enter_datatype.setText("Conform Passcode");
                LockScreenActivity.this.pwd = pin;
                LockScreenActivity.this.passcode = pin;
            } else if (LockScreenActivity.this.pwd.equals(pin)) {
                editor = LockScreenActivity.this.getSharedPreferences("SCREEN_PWD", 0).edit();
                editor.putString("pwd", pin);
                editor.commit();
                LockScreenActivity.this.enter_datatype.setText("Enter Passcode");
                LockScreenActivity.lock_status = true;
                Vault_folder.first_time = true;
                LockScreenActivity.this.finish();
                LockScreenActivity.this.startActivity(new Intent(LockScreenActivity.this, Vault_folder.class));
            } else if (LockScreenActivity.this.passcode.equals(pin)) {
                editor = LockScreenActivity.this.getSharedPreferences("SCREEN_PWD", 0).edit();
                editor.putString("pwd", pin);
                editor.commit();
                LockScreenActivity.this.enter_datatype.setText("Enter Passcode");
                LockScreenActivity.lock_status = true;
                Vault_folder.first_time = true;
                LockScreenActivity.this.finish();
                LockScreenActivity.this.startActivity(new Intent(LockScreenActivity.this, Vault_folder.class));
            } else {
                LockScreenActivity.this.wrong_passcode = pin;
                new Handler().postDelayed(new C06221(), 200);
                ((Vibrator) LockScreenActivity.this.getSystemService(VIBRATOR_SERVICE)).vibrate(700);
            }
            LockScreenActivity.this.mPinLockView.resetPinLockView();
        }

        public void onEmpty() {
        }

        public void onPinChange(int pinLength, String intermediatePin) {
        }
    }

    class TocanType extends TypeToken<ArrayList<BreakModel>> {
        TocanType() {
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_screen);
        if (hasPermissions(LockScreenActivity.this, PERMISSIONS)) {
            initView();
        } else {
            ActivityCompat.requestPermissions(LockScreenActivity.this, PERMISSIONS, Permission_Request_Code);
        }
        loadAd();
        BannerAds();
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        int result = 0;
        for (int i = 0; i < grantResults.length; i++) {
            if (requestCode == Permission_Request_Code &&
                    grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                result = result + 1;
            }
        }
        if (result == permissions.length) {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                initView();
            }
        } else {
            ActivityCompat.requestPermissions(LockScreenActivity.this, PERMISSIONS, Permission_Request_Code);
        }
    }

    private void initView() {
        prefs4 = LockScreenActivity.this.getSharedPreferences("SCREEN_PWD", 0);
        editor = prefs4.edit();
        this.forget_pwd_txt = (TextView) findViewById(R.id.forget_pwd_txt);
        this.theme_type = getSharedPreferences("LOCK_THEME", 0).getString("lock_theme", "image");
        this.background_color = (ImageView) findViewById(R.id.background_color);
        this.image_bg = (ImageView) findViewById(R.id.image_bg);
        if (getSharedPreferences("SCREEN_PWD", 0).getString("pwd", "").equals("")) {
            this.forget_pwd_txt.setEnabled(false);
        } else {
            this.forget_pwd_txt.setEnabled(true);
        }
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String forgot = extras.getString("forgot");
            if (forgot.equals("forgot")) {
                editor.clear();
                editor.apply();
                passcode = "";
                pwd = "";
            }
        }
        if (this.theme_type.equals("image")) {
            String previouslyEncodedImage = PreferenceManager.getDefaultSharedPreferences(this).getString("image_data", "");
            if (previouslyEncodedImage.equals("")) {
                Editor editor = getSharedPreferences("LOCK_THEME", 0).edit();
                editor.putString("lock_theme", "color");
                editor.commit();
                this.background_color.setBackgroundColor(Color.parseColor(getSharedPreferences("COLOR_THEME", 0).getString("color_theme", "#ff263237")));
                this.image_bg.setVisibility(View.GONE);
                this.background_color.setVisibility(View.VISIBLE);
            } else {
                byte[] b = Base64.decode(previouslyEncodedImage, 0);
                if (VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    this.image_bg.setImageBitmap(Utils.blur(getApplicationContext(), BitmapFactory.decodeByteArray(b, 0, b.length)));
                }
                this.image_bg.setVisibility(View.VISIBLE);
                this.background_color.setVisibility(View.GONE);
            }
        } else {
            this.background_color.setBackgroundColor(Color.parseColor(getSharedPreferences("COLOR_THEME", 0).getString("color_theme", "#ff263237")));
            this.image_bg.setVisibility(View.GONE);
            this.background_color.setVisibility(View.VISIBLE);
        }
        if (break_data_array == null) {
            break_data_array = new ArrayList();
        }
        break_data_array.clear();
        break_data_array = (ArrayList) new Gson().fromJson(getSharedPreferences("naimee", 0).getString("patel", null), new TocanType().getType());
        boolean toggle_btn_sttaus = getSharedPreferences("FIGUARE_PRINT", 0).getBoolean("figure_print", false);
        if (VERSION.SDK_INT >= 23 && toggle_btn_sttaus) {
            FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (fingerprintManager.isHardwareDetected() && ActivityCompat.checkSelfPermission(this, "android.permission.USE_FINGERPRINT") == 0 && fingerprintManager.hasEnrolledFingerprints() && keyguardManager.isKeyguardSecure() && cipherInit(generateKey())) {
                new FingerprintHandler(this).startAuth(fingerprintManager, new CryptoObject(this.cipher));
            }
        }
        this.mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
        this.mIndicatorDots = (IndicatorDots) findViewById(R.id.indicator_dots);
        this.mPinLockView.attachIndicatorDots(this.mIndicatorDots);
        this.mPinLockView.setPinLockListener(this.mPinLockListener);
        this.mPinLockView.setPinLength(4);
        this.mPinLockView.setTextColor(ContextCompat.getColor(this, R.color.white));
        this.mIndicatorDots.setIndicatorType(IndicatorDots.IndicatorType.FIXED);
        this.dialog_box_email_rel = (RelativeLayout) findViewById(R.id.dialog_box_email_rel);
        this.dialog_box_passcode_rel = (RelativeLayout) findViewById(R.id.dialog_box_passcode_rel);
        Typeface typeface2 = Typeface.createFromAsset(getAssets(), "fonts/Mada-Regular.ttf");
        this.forget_pwd_txt.setTypeface(typeface2);
        this.enter_datatype = (TextView) findViewById(R.id.enter_datatype);
        this.enter_datatype.setText("Enter Passcode");
        this.enter_datatype.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/Mada-Medium.ttf"));
        if (this.mHiddenCameraFragment != null) {
            getSupportFragmentManager().beginTransaction().remove(this.mHiddenCameraFragment).commit();
            this.mHiddenCameraFragment = null;
        }
        this.mCameraConfig = new CameraConfig().getBuilder(this).setCameraFacing(1).setCameraResolution(2006).setImageFormat(CameraImageFormat.FORMAT_JPEG).setImageRotation(CameraRotation.ROTATION_270).build();
        if (ActivityCompat.checkSelfPermission(this, Utils.permission.CAMERA) == 0) {
            startCamera(this.mCameraConfig);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Utils.permission.CAMERA}, 101);
        }
        if (getSharedPreferences("SCREEN_PWD", 0).getString("pwd", "").equals("")) {
            this.forget_pwd_txt.setVisibility(View.GONE);
        } else {
            this.forget_pwd_txt.setVisibility(View.VISIBLE);
        }
        this.forget_pwd_txt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (interstitial !=null && interstitial.isLoaded()){
                    try {
                        hud = KProgressHUD.create(activity)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (interstitial != null && interstitial.isLoaded()) {
                                id = 100;
                                interstitial.show();
                            }
                        }
                    }, 2000);
                }else {
                    Intent intent = new Intent(LockScreenActivity.this, ForgotSecurityActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    private void loadAd() {

        //interstitial FullScreenAd
        interstitial = new InterstitialAd(LockScreenActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        Intent intent = new Intent(LockScreenActivity.this, ForgotSecurityActivity.class);
                        startActivity(intent);
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        try {
            interstitial = new InterstitialAd(activity);
            interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
            interstitial.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    protected KeyStore generateKey() {
        Exception e;
        GeneralSecurityException e2;
        GeneralSecurityException e3;
        KeyStore kk = null;
        try {
            kk = KeyStore.getInstance("AndroidKeyStore");
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            try {
                kk.load(null);
                if (VERSION.SDK_INT >= 23) {
                    keyGenerator.init(new KeyGenParameterSpec.Builder(KEY_NAME, 3).setBlockModes(new String[]{"CBC"}).setUserAuthenticationRequired(true).setEncryptionPaddings(new String[]{"PKCS7Padding"}).build());
                }
                keyGenerator.generateKey();
                return kk;
            } catch (NoSuchAlgorithmException e4) {
                e3 = e4;
                throw new RuntimeException(e3);
            } catch (InvalidAlgorithmParameterException e5) {
                e3 = e5;
                throw new RuntimeException(e3);
            } catch (CertificateException e6) {
                e3 = e6;
                throw new RuntimeException(e3);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        } catch (NoSuchAlgorithmException e8) {
            e2 = e8;
            throw new RuntimeException("Failed to get KeyGenerator instance", e2);
        } catch (NoSuchProviderException e9) {
            e2 = e9;
            throw new RuntimeException("Failed to get KeyGenerator instance", e2);
        }
        return null;
    }

    @RequiresApi(api = 23)
    public boolean cipherInit(KeyStore kk) {
        GeneralSecurityException e;
        if (VERSION.SDK_INT < 23) {
            return false;
        }
        try {
            this.cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            try {
                kk.load(null);
                this.cipher.init(1, (SecretKey) kk.getKey(KEY_NAME, null));
                return true;
            } catch (InvalidKeyException e2) {
                return false;
            } catch (Exception e3) {
                throw new RuntimeException("Failed to init Cipher", e3);
            }
        } catch (NoSuchAlgorithmException e4) {
            e = e4;
            throw new RuntimeException("Failed to get Cipher", e);
        } catch (NoSuchPaddingException e5) {
            e = e5;
            throw new RuntimeException("Failed to get Cipher", e);
        }
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    public void onImageCapture(@NonNull File imageFile) {
        Options options = new Options();
        options.inPreferredConfig = Config.RGB_565;
        BreakModel client1 = new BreakModel();
        client1.setPath_break(imageFile.getAbsolutePath());
        client1.setImage_name(imageFile.getName());
        client1.setPassword(this.wrong_passcode);
        client1.setDate(new SimpleDateFormat("dd-MMM-yyyy  hh:mm a").format(Long.valueOf(Date.parse(String.valueOf(new Date(imageFile.lastModified()))))));
        client1.setLat(this.latitude.doubleValue());
        client1.setLang(this.longitude.doubleValue());
        if (break_data_array == null) {
            break_data_array = new ArrayList();
        }
        break_data_array.add(client1);
        Editor editor = getSharedPreferences("naimee", 0).edit();
        editor.putString("patel", new Gson().toJson(break_data_array));
        editor.commit();
        SaveImage(BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options));
    }

    public void onCameraError(int errorCode) {
        switch (errorCode) {
            case CameraError.ERROR_CAMERA_OPEN_FAILED:
                Toast.makeText(this, "Cannot open camera.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_CAMERA_PERMISSION_NOT_AVAILABLE:
                Toast.makeText(this, "Camera permission not available.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_DOES_NOT_HAVE_FRONT_CAMERA:
                Toast.makeText(this, "Your device does not have front camera.", Toast.LENGTH_SHORT).show();
                return;
            case CameraError.ERROR_IMAGE_WRITE_FAILED:
                Toast.makeText(this, "Cannot write image captured by camera.", Toast.LENGTH_SHORT).show();
                return;
            default:
                return;
        }
    }

    private void SaveImage(Bitmap finalBitmap) {
        File myDir = new File(Environment.getExternalStorageDirectory().toString() + "/Person_image");
        myDir.mkdirs();
        File file = new File(myDir, "Image-" + new Random().nextInt(10000) + ".jpg");
        if (file.exists()) {
            file.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
