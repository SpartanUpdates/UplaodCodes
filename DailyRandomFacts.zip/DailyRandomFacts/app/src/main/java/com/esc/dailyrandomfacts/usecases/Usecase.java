package com.esc.dailyrandomfacts.usecases;

public interface Usecase {
    void execute();
}
