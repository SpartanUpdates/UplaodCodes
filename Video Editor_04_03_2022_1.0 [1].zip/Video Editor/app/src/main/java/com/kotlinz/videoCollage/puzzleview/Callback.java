package com.kotlinz.videoCollage.puzzleview;

public interface Callback {
    void onFailed();

    void onSuccess(String str);
}
