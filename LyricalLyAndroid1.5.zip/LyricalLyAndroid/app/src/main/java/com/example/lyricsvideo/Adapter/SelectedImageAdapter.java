package com.example.lyricsvideo.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.example.lyricsvideo.activity.SelectImageActivity;
import com.example.lyricsvideo.Interface.OnItemClickListner;
import com.example.lyricsvideo.Model.ImageInfo;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.application.App;

import java.util.ArrayList;

public class SelectedImageAdapter extends RecyclerView.Adapter<SelectedImageAdapter.Holder>
{
  private App application;
  private LayoutInflater inflater;
  private OnItemClickListner<Object> itemClickListner;
  public boolean isExpanded;
  private RequestManager glidemanager;
  SelectImageActivity activity;
  Context mContext;

  public SelectedImageAdapter(final Context activity) {
    this.isExpanded = false;
    this.mContext = activity;
    this.activity = (SelectImageActivity)activity;
    this.application = App.getInstance();
    this.inflater = LayoutInflater.from(activity);
    this.glidemanager = Glide.with(activity);
  }

  public void setOnItemClickListner(final OnItemClickListner<Object> clickListner) {
    this.itemClickListner = clickListner;
  }

  public int getItemCount() {
    final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
    if (!this.isExpanded) {
      return list.size() + 20;
    }
    return list.size();
  }

  public int getItemViewType(final int position) {
    super.getItemViewType(position);
    if (this.isExpanded) {
      return 0;
    }
    final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
    if (position >= list.size()) {
      return 1;
    }
    return 0;
  }

  private boolean hideRemoveBtn() {
    return this.application.getSelectedImageslist().size() <= 3 && this.activity.isFromPreview;
  }

  public ImageInfo getItem(final int pos) {
    final ArrayList<ImageInfo> list = this.application.getSelectedImageslist();
    if (list.size() <= pos) {
      return new ImageInfo();
    }
    return list.get(pos);
  }

  public void onBindViewHolder(@NonNull final Holder holder, @SuppressLint("RecyclerView") final int pos) {
    if (this.getItemViewType(pos) == 1) {
      holder.parent.setVisibility(View.INVISIBLE);
      return;
    }
    holder.parent.setVisibility(View.VISIBLE);
    final ImageInfo data = this.getItem(pos);
    this.glidemanager.load(data.ImagePath).into(holder.ivSelectedThumImage);
    if (this.hideRemoveBtn()) {
      holder.ivRemove.setVisibility(View.GONE);
    }
    else {
      holder.ivRemove.setVisibility(View.VISIBLE);
    }
    holder.ivRemove.setOnClickListener(new View.OnClickListener() {
      public void onClick(final View v) {
        if (SelectedImageAdapter.this.activity.isFromPreview) {
          SelectedImageAdapter.this.application.MinimumPosition = Math.min(SelectedImageAdapter.this.application.MinimumPosition, Math.max(0, pos - 1));
        }
        if (SelectImageActivity.isFirstImage && pos <= SelectImageActivity.tempImage.size() && SelectedImageAdapter.this.application.getSelectedImageslist().contains(SelectImageActivity.tempImage.get(pos).ImagePath)) {
          SelectImageActivity.tempImage.remove(pos);
        }
        SelectedImageAdapter.this.application.removeSelectedImage(pos);
        if (SelectedImageAdapter.this.itemClickListner != null) {
          SelectedImageAdapter.this.itemClickListner.onItemClick(v, data);
        }
        if (SelectedImageAdapter.this.hideRemoveBtn()) {
          Toast.makeText(SelectedImageAdapter.this.activity, R.string.at_least_3_images_require_if_you_want_to_remove_this_images_than_add_more_images_, Toast.LENGTH_LONG).show();
        }
        SelectedImageAdapter.this.notifyDataSetChanged();
      }
    });
  }

  @NonNull
  public Holder onCreateViewHolder(@NonNull final ViewGroup parent, final int pos) {
    final View view = this.inflater.inflate(R.layout.row_selected_item, parent, false);
    final Holder holder = new Holder(view);
    if (this.getItemViewType(pos) == 1) {
      view.setVisibility(View.INVISIBLE);
    }
    else {
      view.setVisibility(View.VISIBLE);
    }
    return holder;
  }

  public class Holder extends RecyclerView.ViewHolder
  {
    View parent;
    private ImageView ivRemove;
    private ImageView ivSelectedThumImage;

    public Holder(final View v) {
      super(v);
      this.parent = v;
      this.ivSelectedThumImage = v.findViewById(R.id.ivSelectThumbImage);
      this.ivRemove = v.findViewById(R.id.ivRemoveImage);
    }

    public void onItemClick(final View view, final Object item) {
      if (SelectedImageAdapter.this.itemClickListner != null) {
        SelectedImageAdapter.this.itemClickListner.onItemClick(view, item);
      }
    }
  }
}
