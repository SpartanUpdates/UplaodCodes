package com.libffmpeg;

interface ResponseHandler {
    void onFinish();

    void onStart();
}
