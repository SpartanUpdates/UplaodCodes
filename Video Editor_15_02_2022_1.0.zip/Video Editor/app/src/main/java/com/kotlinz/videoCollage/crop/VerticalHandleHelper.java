package com.kotlinz.videoCollage.crop;

import android.graphics.Rect;

class VerticalHandleHelper extends HandleHelper {
    private Edge mEdge;

    VerticalHandleHelper(Edge edge) {
        super(null, edge);
        this.mEdge = edge;
    }

    public void updateCropWindow(float f, float f2, float f3, Rect rect, float f4) {
        this.mEdge.adjustCoordinate(f, f2, rect, f4, f3);
        f = Edge.LEFT.getCoordinate();
        f2 = Edge.TOP.getCoordinate();
        float coordinate = Edge.RIGHT.getCoordinate();
        float coordinate2 = Edge.BOTTOM.getCoordinate();
        f = (AspectRatioUtil.calculateHeight(f, coordinate, f3) - (coordinate2 - f2)) / 2.0f;
        coordinate2 += f;
        Edge.TOP.setCoordinate(f2 - f);
        Edge.BOTTOM.setCoordinate(coordinate2);
        if (Edge.TOP.isOutsideMargin(rect, f4) && !this.mEdge.isNewRectangleOutOfBounds(Edge.TOP, rect, f3)) {
            Edge.BOTTOM.offset(-Edge.TOP.snapToRect(rect));
            this.mEdge.adjustCoordinate(f3);
        }
        if (Edge.BOTTOM.isOutsideMargin(rect, f4) && !this.mEdge.isNewRectangleOutOfBounds(Edge.BOTTOM, rect, f3)) {
            Edge.TOP.offset(-Edge.BOTTOM.snapToRect(rect));
            this.mEdge.adjustCoordinate(f3);
        }
    }
}
