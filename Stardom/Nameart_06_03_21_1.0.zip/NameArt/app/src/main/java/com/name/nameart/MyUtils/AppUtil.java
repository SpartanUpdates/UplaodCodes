package com.name.nameart.MyUtils;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

public class AppUtil {
    public static void shareIntent(Context context, String str, String str2, Uri uri) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.setPackage(str);
        if (TextUtils.isEmpty(str2)) {
            str2 = "";
        }
        intent.putExtra("android.intent.extra.TEXT", str2);
        if (uri != null) {
            intent.putExtra("android.intent.extra.STREAM", uri);
            intent.setType("image/*");
        }
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(context,"No Such App Found", Toast.LENGTH_SHORT).show();
        }
    }
}
