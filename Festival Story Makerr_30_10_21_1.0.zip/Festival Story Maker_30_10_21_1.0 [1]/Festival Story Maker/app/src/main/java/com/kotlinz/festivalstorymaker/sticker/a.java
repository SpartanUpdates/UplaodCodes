package com.kotlinz.festivalstorymaker.sticker;

import android.graphics.drawable.Drawable;
import android.view.MotionEvent;

public class a extends c implements f
{
    public float l;
    public float m;
    public float n;
    public int o;
    public f p;

    public a(final Drawable drawable, final int o) {
        super(drawable);
        this.l = 30.0f;
        this.o = 0;
        this.o = o;
    }

    @Override
    public void a(final StickerView stickerView, final MotionEvent motionEvent) {
        final f p2 = this.p;
        if (p2 != null) {
            p2.a(stickerView, motionEvent);
        }
    }

    @Override
    public void b(final StickerView stickerView, final MotionEvent motionEvent) {
        final f p2 = this.p;
        if (p2 != null) {
            p2.b(stickerView, motionEvent);
        }
    }

    @Override
    public void c(final StickerView stickerView, final MotionEvent motionEvent) {
        final f p2 = this.p;
        if (p2 != null) {
            p2.c(stickerView, motionEvent);
        }
    }
}
