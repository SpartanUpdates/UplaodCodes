package com.esc.photovault.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

public class Utils {

    private static final float BITMAP_SCALE = 0.7f;
    private static final float BLUR_RADIUS = 7.5f;
    public static String FIRST_TIME_SELECT_QUESTION="First_Time_select_question";
    public static String SECOND_TIME_SELECT_QUESTION="Second_Time_select_question";
    public static String FIRST_TIME_SELECT_ANSWER="First_Time_select_Answer";
    public static String SECOND_TIME_SELECT_ANSWER="Second_Time_select_Answer";

    public static final class permission {
        public static final String ACCESS_COARSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
        public static final String ACCESS_FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
        public static final String CAMERA = "android.permission.CAMERA";
        public static final String READ_EXTERNAL_STORAGE = "android.permission.READ_EXTERNAL_STORAGE";
        public static final String WRITE_EXTERNAL_STORAGE = "android.permission.WRITE_EXTERNAL_STORAGE";
    }

    public static ArrayList<String> listIcon;
    public static ArrayList<String> listName;
    public static ArrayList<String> listUrl;
    public static ArrayList<String> listStatus;

    static {
        listIcon = new ArrayList();
        listName = new ArrayList();
        listUrl = new ArrayList();
        listStatus = new ArrayList();
    }

    @RequiresApi(api = 17)
    public static Bitmap blur(Context context, Bitmap image) {
        Bitmap inputBitmap = Bitmap.createScaledBitmap(image, Math.round(((float) image.getWidth()) * BITMAP_SCALE), Math.round(((float) image.getHeight()) * BITMAP_SCALE), false);
        Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
        RenderScript rs = RenderScript.create(context);
        ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
        Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
        Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
        theIntrinsic.setRadius(BLUR_RADIUS);
        theIntrinsic.setInput(tmpIn);
        theIntrinsic.forEach(tmpOut);
        tmpOut.copyTo(outputBitmap);
        return outputBitmap;
    }
}
