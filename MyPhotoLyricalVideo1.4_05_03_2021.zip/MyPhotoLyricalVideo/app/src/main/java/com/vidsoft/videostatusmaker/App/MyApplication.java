package com.vidsoft.videostatusmaker.App;

import android.app.Application;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.vidsoft.videostatusmaker.OpenAds.AppOpenManager;

public class MyApplication extends Application {

    AppOpenManager appOpenManager;

    private static MyApplication instance;

    public static int Variable_VIDEO_HEIGHT = 720;
    public static int Variable_VIDEO_WIDTH = 720;


    public static MyApplication getInstance() {
        return MyApplication.instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MyApplication.instance = this;
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
    }
}
