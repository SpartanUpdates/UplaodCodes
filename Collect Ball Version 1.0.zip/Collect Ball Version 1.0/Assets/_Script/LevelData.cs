﻿using UnityEngine;

namespace BallCollect
{
    public class LevelData : MonoBehaviour
    {
        public GameObject[] changeColorObj;
        public GameObject[] nextLevelObj;
        public GameObject ocean;

        int number = 0;
        public void Start()
        {
            int nextColor = GameController.instance.nextLevelColor;

            if (GameController.instance.isGameCoti)
            {
                number = GameController.instance.colorNo;
                GameController.instance.isGameCoti = false;
            }
            else
            {
                number = GameController.instance.nextLevelColor;
                GameController.instance.colorNo = number;
                GameController.instance.nextLevelColor = UnityEngine.Random.Range(0, ColorManager.PlatfromColor.Length);
                nextColor = GameController.instance.nextLevelColor;
            }

            for (int i = 0; i < changeColorObj.Length; i++)
            {
                foreach (Material mat in changeColorObj[i].GetComponent<Renderer>().materials)
                {
                    mat.color = ColorManager.PlatfromColor[number];
                    mat.SetVector("_EmissionColor", ColorManager.PlatfromColor[number]);
                }
            }

            for (int i = 0; i < nextLevelObj.Length; i++)
            {
                foreach (Material mat in nextLevelObj[i].GetComponent<Renderer>().materials)
                {
                    mat.color = ColorManager.PlatfromColor[nextColor];
                    mat.SetVector("_EmissionColor", ColorManager.PlatfromColor[nextColor]);
                }
            }
           
            ocean.GetComponent<Renderer>().material.SetTexture("_MainTex",GameController.instance.oceanTexture[GameController.instance.oceneColor]);
        }
        private void OnDisable()
        {
            System.GC.Collect();
        }
    }
}