package com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.activity;

import static com.kotlinz.vehiclemanager.coustomNativeAds.CustomNativeAd.populateUnifiedNativeAdView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.vehiclemanager.R;
import com.kotlinz.vehiclemanager.activity.MainActivity;
import com.kotlinz.vehiclemanager.myApp.MyApplication;
import com.kotlinz.vehiclemanager.utils.DarkTheame;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.database.ExpenseSqlite;
import com.kotlinz.vehiclemanager.vehicledetails.vehicleexpense.model.VehicleExpense;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;

public class VehicleExpenseDetailAtivity extends AppCompatActivity implements View.OnClickListener {

    private Activity activity = VehicleExpenseDetailAtivity.this;

    private Button btnCancel;
    private Button btnSave;
    private EditText etAmount;
    private EditText etDueDate;
    private EditText etNotes;
    private EditText etPayeeItem;
    private TextInputLayout dateInputLayout;
    private TextInputLayout amountInputLayout;
    private TextInputLayout etItemInput;
    private TextInputLayout etnotesInput;
    private ImageView ivback, iv_home;
    private TextView tvTitle;
    private int catImg;
    private String catName;
    private SimpleDateFormat dateFormat;
    private int day;
    private String dueDate;
    private String addList;
    private String amount;
    private ExpenseSqlite openSQLite;
    private String payee;
    private int year;
    private int month;
    private String note;
    private Intent intent;
    private LinearLayout ll_inputDataLayout;


    private NativeAd nativeAd;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_expense_detail_ativity);
        LoadNativeAds();
        intent = getIntent();
        if (getIntent().getExtras() != null) {
            addList = intent.getStringExtra("btn");
            if (addList.equals("SAVE")) {
                catName = intent.getStringExtra("categoryname");
                catImg = intent.getIntExtra("categoryimg", R.drawable.ic_otherexpense);
            } else {
                payee = intent.getExtras().getString("BPAYEE");
                amount = intent.getExtras().getString("BAMOUNT");
                note = intent.getExtras().getString("BNOTE");
                dueDate = intent.getExtras().getString("BDUEDATE");
                catName = intent.getExtras().getString("BCATNAME");
                catImg = intent.getExtras().getInt("BCATICON");
            }
        }
        PutAnalyticsEvent();
        BindView();
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
            setupDarkMode();
        }
        DarkTheame darkTheame = new DarkTheame(VehicleExpenseDetailAtivity.this);
        if (darkTheame.modeData().equals("nightMode")) {
            setupDarkMode();
        }
        openSQLite = new ExpenseSqlite(getApplicationContext());
        dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.US);

        Calendar instance = Calendar.getInstance();
        day = instance.get(1);
        month = instance.get(Calendar.MONTH);
        year = instance.get(5);
        etDueDate.setFocusable(false);
        etDueDate.setClickable(true);
        if (addList.equals("UPDATE")) {
            btnSave.setTag("UPDATE");
            btnSave.setText("Update");
            etPayeeItem.setText(payee);
            etAmount.setText(amount);
            etNotes.setText(note);
            etDueDate.setText(dueDate);
        } else {
            SetHint();
        }
        etDueDate.setOnClickListener(new DueDateClick(this));
        tvTitle.setText(catName);
    }

    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "VehicleExpenseDetailAtivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void LoadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.NativeAdvanceAd_id));
        builder.forNativeAd(
                new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        boolean isDestroyed = false;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            isDestroyed = isDestroyed();
                        }
                        if (isDestroyed || isFinishing() || isChangingConfigurations()) {
                            nativeAd.destroy();
                            return;
                        }
                        if (VehicleExpenseDetailAtivity.this.nativeAd != null) {
                            VehicleExpenseDetailAtivity.this.nativeAd.destroy();
                        }
                        VehicleExpenseDetailAtivity.this.nativeAd = nativeAd;
                        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                        NativeAdView adView = (NativeAdView) getLayoutInflater().inflate(R.layout.ad_unified_small, null);
                        populateUnifiedNativeAdView(nativeAd, adView);
                        frameLayout.removeAllViews();
                        frameLayout.addView(adView);
                    }
                });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }



    private void setupDarkMode() {
        tvTitle.setTextColor(Color.parseColor("#FFFFFF"));
        ll_inputDataLayout.setBackgroundResource(R.drawable.round_white_shadowbg_dark);
        etPayeeItem.setTextColor(Color.parseColor("#FFFFFF"));
        etNotes.setTextColor(Color.parseColor("#FFFFFF"));
        etAmount.setTextColor(Color.parseColor("#FFFFFF"));
        etDueDate.setTextColor(Color.parseColor("#FFFFFF"));
        btnSave.setTextColor(Color.parseColor("#FFFFFF"));
        btnCancel.setTextColor(Color.parseColor("#FFFFFF"));
    }

    private void BindView() {
        amountInputLayout = findViewById(R.id.amountInputLayout);
        dateInputLayout = findViewById(R.id.dateInputLayout);
        etItemInput = findViewById(R.id.itemInputLayout);
        etnotesInput = findViewById(R.id.notesInputLayout);

        etAmount = findViewById(R.id.etAmount);
        etNotes = findViewById(R.id.etNotes);
        etPayeeItem = findViewById(R.id.etPayeeItem);
        etDueDate = findViewById(R.id.etDueDate);

        ivback = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);
        iv_home = findViewById(R.id.iv_home);

        ll_inputDataLayout = findViewById(R.id.ll_inputDataLayout);

        ivback.setOnClickListener(this);
        iv_home.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        btnSave.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;

            case R.id.btnCancel:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseCategory.class));
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 34;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseCategory.class));
                    }
                }
                break;

            case R.id.btnSave:
                SaveDetails();
                break;

            case R.id.iv_home:
                if (MyApplication.isShowAd == 1) {
                    startActivity(new Intent(VehicleExpenseDetailAtivity.this, MainActivity.class));
                    finish();
                    MyApplication.isShowAd = 0;
                } else {
                    if (MyApplication.mInterstitialAd != null) {
                        MyApplication.activity = activity;
                        MyApplication.AdsId = 20;
                        MyApplication.mInterstitialAd.show(activity);
                        MyApplication.isShowAd = 1;

                    } else {
                        startActivity(new Intent(VehicleExpenseDetailAtivity.this, MainActivity.class));
                        finish();
                    }
                }
                break;
        }
    }

    class DueDateClick implements View.OnClickListener {
        VehicleExpenseDetailAtivity expenceFormActivity;

        class DateSet implements DatePickerDialog.OnDateSetListener {
            DueDateClick DueDateClick;

            public DateSet(DueDateClick dueDateClick) {
                DueDateClick = dueDateClick;
            }

            public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                Calendar instance = Calendar.getInstance();
                instance.set(i, i2, i3);
                DueDateClick.expenceFormActivity.etDueDate.setText(DueDateClick.expenceFormActivity.dateFormat.format(instance.getTime()));
            }
        }

        public DueDateClick(VehicleExpenseDetailAtivity expenceFormActivity) {
            this.expenceFormActivity = expenceFormActivity;
        }

        @SuppressLint({"WrongConstant"})
        public void onClick(View view) {
            Calendar instance = Calendar.getInstance();
            new DatePickerDialog(expenceFormActivity, new DateSet(this), instance.get(1), instance.get(2), instance.get(5)).show();
        }
    }

    class Hndlr implements Runnable {
        VehicleExpenseDetailAtivity vehicleExpenseDetailAtivity;

        public Hndlr(VehicleExpenseDetailAtivity vehicleExpenseDetailAtivity) {
            this.vehicleExpenseDetailAtivity = vehicleExpenseDetailAtivity;
        }

        public void run() {
            this.vehicleExpenseDetailAtivity.DateFormat(day, month, year);
        }
    }

    private void SaveDetails() {
        if (PayeeItem() && Note() && Setdate() && Amount() && CategorySet()) {
            VehicleExpense vehicleExpenseModel = new VehicleExpense(etAmount.getText().toString(), catName, etPayeeItem.getText().toString(), etNotes.getText().toString(), etDueDate.getText().toString(), catImg);
            if (btnSave.getTag().equals("Save")) {
                Save(vehicleExpenseModel);
                startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseActivity.class));
                return;
            }
            Update(intent.getExtras().getInt("BID"), vehicleExpenseModel);
            startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseActivity.class));
        }
    }

    private void DateFormat(int i, int i2, int i3) {
        Date parse;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d/yyyy");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i2 + 1);
            stringBuilder.append("/");
            stringBuilder.append(i3);
            stringBuilder.append("/");
            stringBuilder.append(i);
            parse = simpleDateFormat.parse(String.valueOf(stringBuilder));
        } catch (ParseException e) {
            e.printStackTrace();
            parse = null;
        }
        this.etDueDate.setText(new SimpleDateFormat("dd-MM-yyyy").format(parse));
    }

    private void Update(int i, VehicleExpense vehicleExpense) {
        if (((long) this.openSQLite.updt(i, vehicleExpense)) > 0) {
            finish();
        }
    }

    private void str(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(5);
        }
    }

    private void Save(VehicleExpense vehicleExpense) {
        if (this.openSQLite.insrt(vehicleExpense) > 0) {
            finish();
        }
    }

    private boolean Amount() {

        if (etAmount.getText().toString().trim().isEmpty()) {
            TextInputLayout textInputLayout = this.amountInputLayout;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.please_enter));
            stringBuilder.append(" Your Amount ");
            textInputLayout.setError(stringBuilder.toString());
            str(this.etAmount);
            return false;
        }
        this.amountInputLayout.setErrorEnabled(false);
        return true;
    }

    private boolean PayeeItem() {
        if (etPayeeItem.getText().toString().trim().isEmpty()) {
            TextInputLayout textInputLayout = this.etItemInput;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.please_enter));
            stringBuilder.append(" Your Payee/Item");
            textInputLayout.setError(stringBuilder.toString());
            str(etPayeeItem);
            return false;
        }
        etItemInput.setErrorEnabled(false);
        return true;
    }

    private boolean Note() {
        if (etNotes.getText().toString().trim().isEmpty()) {
            TextInputLayout textInputLayout = this.etnotesInput;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getString(R.string.please_enter));
            stringBuilder.append(" Your Notes");
            textInputLayout.setError(stringBuilder.toString());
            str(etNotes);
            return false;
        }
        etnotesInput.setErrorEnabled(false);
        return true;
    }

    private boolean Setdate() {
        if (etDueDate.getText().toString().trim().isEmpty()) {
            DateFormat(day, month, year);
        }
        return true;
    }

    private boolean CategorySet() {
        if (catImg == 0) {
            catImg = R.drawable.ic_otherexpense;
        }
        if (catName == null) {
            catName = "Other";
        }
        return true;
    }

    public void SetHint() {
        etItemInput.setHint("Payee/Item Name");
        etnotesInput.setHint("Notes");
        amountInputLayout.setHint("Amount(Rs)");
        new Handler().postDelayed(new Hndlr(this), 500);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != android.R.id.home) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBackPressed();
        return true;
    }

    public void onBackPressed() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseCategory.class));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 35;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;

            } else {
                startActivity(new Intent(VehicleExpenseDetailAtivity.this, VehicleExpenseCategory.class));
                finish();
            }
        }
    }
}