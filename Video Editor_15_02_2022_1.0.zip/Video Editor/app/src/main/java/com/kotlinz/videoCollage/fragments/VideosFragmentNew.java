package com.kotlinz.videoCollage.fragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.videoCollage.SelectActivity;
import com.kotlinz.videoCollage.flying.poiphoto.GetAllVideoTask;
import com.kotlinz.videoCollage.flying.poiphoto.VideoManager;
import com.kotlinz.videoCollage.flying.poiphoto.datatype.Video;
import com.kotlinz.videoCollage.flying.poiphoto.ui.adapter.VideoAdapter;
import com.kotlinz.videoCollage.other.Util;
import com.kotlinz.videoCollage.puzzleview.PuzzleUtils;
import com.kotlinz.videoeditor.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.LoadedFrom;
import com.squareup.picasso.Target;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class VideosFragmentNew extends Fragment {
    private Map<Integer, Map<String, View>> arrayVideoPaths = new HashMap();
    private int deviceWidth;
    private LinearLayout lineEmpty;
    private Context myContext;
    private int pos;
    private PuzzleHandler puzzleHandler;
    private List<Target> targets = new ArrayList();
    private VideoAdapter videoAdapter;
    private List<String> videoPaths = new ArrayList();
    private RecyclerView videoRecycler;

    private static class PuzzleHandler extends Handler {
        private WeakReference<VideosFragmentNew> mReference;

        PuzzleHandler(VideosFragmentNew videosFragmentNew) {
            this.mReference = new WeakReference(videosFragmentNew);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (message.what == 119) {
                ((VideosFragmentNew) this.mReference.get()).refreshLayout();
            } else if (message.what == 120) {
                ((VideosFragmentNew) this.mReference.get()).fetchBitmap((String) message.obj);
            }
        }
    }
    public VideosFragmentNew(Context context) {
        this.myContext = context;
        this.puzzleHandler = new PuzzleHandler(this);
        this.deviceWidth = context.getResources().getDisplayMetrics().widthPixels;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_video, viewGroup, false);
        this.videoRecycler = (RecyclerView) inflate.findViewById(R.id.video_list);
        this.lineEmpty = (LinearLayout) inflate.findViewById(R.id.line_empty);
        VideoAdapter videoAdapter = new VideoAdapter(this.myContext, "select");
        this.videoAdapter = videoAdapter;
        videoAdapter.setMaxCount(4);
        this.videoAdapter.setSelectedResId(R.drawable.color_half_transparent_bg);
        this.videoRecycler.setAdapter(this.videoAdapter);
        this.videoRecycler.setLayoutManager(new GridLayoutManager(this.myContext, 4));
        loadVideos();
        this.videoAdapter.setOnVideoSelectedListener(new VideoAdapter.OnVideoSelectedListener() {
            static final boolean $assertionsDisabled = false;


            public void onVideoSelected(Video video, int i) {
                Bitmap createVideoThumbnail = ThumbnailUtils.createVideoThumbnail(video.getPath(), 2);
                int nextInt = new Random().nextInt(10000);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Image-");
                stringBuilder.append(nextInt);
                stringBuilder.append(".jpg");
                File file = new File(VideosFragmentNew.this.myContext.getCacheDir(), stringBuilder.toString());
                if (file.exists()) {
                    file.delete();
                }
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    createVideoThumbnail.compress(CompressFormat.JPEG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                VideosFragmentNew.this.pos = i;
                SelectActivity.selectedPath.add(video.getPath());
                Message obtain = Message.obtain();
                obtain.what = 120;
                obtain.obj = file.getAbsolutePath();
                VideosFragmentNew.this.puzzleHandler.sendMessage(obtain);
                Picasso with = Picasso.get();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("file:///");
                stringBuilder2.append(file.getAbsolutePath());
                with.load(stringBuilder2.toString()).resize(VideosFragmentNew.this.deviceWidth, VideosFragmentNew.this.deviceWidth).centerInside().fetch();
                ((SelectActivity) VideosFragmentNew.this.myContext).setSelectedVidImg();
            }
        });
        this.videoAdapter.setOnVideoUnSelectedListener(new VideoAdapter.OnVideoUnSelectedListener() {
            public void onVideoUnSelected(Video video, int i) {
                if (VideosFragmentNew.this.arrayVideoPaths.containsKey(Integer.valueOf(i))) {
                    VideosFragmentNew.this.arrayVideoPaths.remove(Integer.valueOf(i));
                }
                SelectActivity.selectedPath.remove(video.getPath());
                if (SelectActivity.selectedPath.size() == 0) {
                    SelectActivity.mainLin.removeAllViews();
                    SelectActivity.viewPieces.clear();
                    VideosFragmentNew.this.videoPaths.clear();
                }
                Util.selectedVid = VideosFragmentNew.this.videoPaths.size();
                if (com.kotlinz.videoCollage.flying.poiphoto.Util.selectedItemsCount < 2) {
                    SelectActivity.puzzleList.post(new Runnable() {
                        public void run() {
                            SelectActivity.puzzleAdapter.refreshData(PuzzleUtils.getPuzzleLayouts(0), new ArrayList());
                        }
                    });
                } else {
                    SelectActivity.puzzleList.post(new Runnable() {
                        public void run() {
                            SelectActivity.puzzleAdapter.refreshData(PuzzleUtils.getPuzzleLayouts(SelectActivity.viewPieces.size()), SelectActivity.viewPieces);
                        }
                    });
                }
                ((SelectActivity) VideosFragmentNew.this.myContext).setSelectedVidImg();
            }
        });

        this.videoAdapter.setOnSelectedMaxListener(new VideoAdapter.OnSelectedMaxListener() {
            public void onSelectedMax() {
                Toast.makeText(VideosFragmentNew.this.myContext, "Maximum 4 videos allowed", Toast.LENGTH_SHORT).show();
            }
        });
        this.videoAdapter.setOnSelectedTotalListener(new VideoAdapter.OnSelectedTotalListener() {
            public void onSelectedTotal() {
                Toast.makeText(VideosFragmentNew.this.myContext, "Maximum 4 photos/videos allowed", Toast.LENGTH_SHORT).show();
            }
        });
        return inflate;
    }

    private void loadVideos() {
        new GetAllVideoTask() {

            public void onPostExecute(List<Video> list) {
                super.onPostExecute(list);
                VideosFragmentNew.this.videoAdapter.refreshData(list);
            }
        }.execute(new VideoManager[]{new VideoManager(this.myContext)});
    }

    private void refreshLayout() {
        if (com.kotlinz.videoCollage.flying.poiphoto.Util.selectedItemsCount >= 2) {
            SelectActivity.puzzleList.post(new Runnable() {
                public void run() {
                    SelectActivity.puzzleAdapter.refreshData(PuzzleUtils.getPuzzleLayouts(SelectActivity.viewPieces.size()), SelectActivity.viewPieces);
                }
            });
        }
    }

    public void fetchBitmap(final String str) {
        Target anonymousClass7 = new Target() {
            public void onBitmapFailed(Drawable drawable) {
            }

            public void onPrepareLoad(Drawable drawable) {
            }

            public void onBitmapLoaded(Bitmap bitmap, LoadedFrom loadedFrom) {
                LayoutParams layoutParams;
                VideosFragmentNew.this.videoPaths.add(str);
                Util.selectedVid = VideosFragmentNew.this.videoPaths.size();
                LinearLayout linearLayout = new LinearLayout(VideosFragmentNew.this.myContext);
                linearLayout.setId(VideosFragmentNew.this.pos);
                Bitmap resize = Util.resize(BitmapFactory.decodeFile(str), str);
                Bitmap scaleBitmap = Util.scaleBitmap(resize);
                if (scaleBitmap != null) {
                    layoutParams = new RelativeLayout.LayoutParams(scaleBitmap.getWidth(), scaleBitmap.getHeight());
                } else {
                    layoutParams = new RelativeLayout.LayoutParams(1, 1);
                }
                ImageView imageView = new ImageView(VideosFragmentNew.this.myContext);
                imageView.setImageBitmap(resize);
                linearLayout.setLayoutParams(layoutParams);
                linearLayout.addView(imageView);
                SelectActivity.viewPieces.add(linearLayout);
                SelectActivity.mainLin.addView(linearLayout);
                HashMap hashMap = new HashMap();
                hashMap.put(str, imageView);
                VideosFragmentNew.this.arrayVideoPaths.put(Integer.valueOf(VideosFragmentNew.this.pos), hashMap);
                VideosFragmentNew.this.puzzleHandler.sendEmptyMessage(119);
                VideosFragmentNew.this.targets.remove(this);
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {

            }
        };
        Picasso with = Picasso.get();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///");
        stringBuilder.append(str);
        with.load(stringBuilder.toString()).resize(300, 300).centerInside().config(Config.RGB_565).into(anonymousClass7);
        this.targets.add(anonymousClass7);
    }
}
