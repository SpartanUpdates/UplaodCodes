package com.example.lyricsvideo.CoustomControl;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class CoustomRecyclerView extends RecyclerView
{
  private View emptyView;
  private AdapterDataObserver dataObserver = new AdapterDataObserver()
  {
    public void onChanged()
    {
      Adapter<?> adapter = getAdapter();
      if ((adapter != null) && (emptyView != null)) {
        if (adapter.getItemCount() == 0) {
          emptyView.setVisibility(View.VISIBLE);
          setVisibility(View.GONE);
        } else {
          emptyView.setVisibility(View.GONE);
          setVisibility(View.VISIBLE);
        }
      }
    }
  };

  public CoustomRecyclerView(Context context) {
    this(context, null);
  }

  public CoustomRecyclerView(Context context, android.util.AttributeSet attr) {
    this(context, attr, 0);
  }

  public CoustomRecyclerView(Context context, android.util.AttributeSet attr, int defStyle)
  {
    super(context, attr, defStyle);
  }
  


  public void setAdapter(Adapter adapter)
  {
    super.setAdapter(adapter);
    if (adapter != null) {
      adapter.registerAdapterDataObserver(dataObserver);
    }
    dataObserver.onChanged();
  }
  
  public void setEmptyView(View emptyView) {
    this.emptyView = emptyView;
  }
}
