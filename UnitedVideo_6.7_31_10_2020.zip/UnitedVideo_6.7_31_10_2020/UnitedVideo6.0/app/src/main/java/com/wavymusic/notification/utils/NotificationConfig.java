package com.wavymusic.notification.utils;

public class NotificationConfig {

    public static final String TOPIC_GLOBAL = "global";
    public static final int NOTIFICATION_ID = 1001;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 1002;
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";
    public static final String SHARED_PREF = "ah_firebase";


    public static final String FCM_PARAM = "picture";
    public static final String CHANNEL_NAME = "FCM";
    public static final String CHANNEL_DESC = "Firebase Cloud Messaging";
}