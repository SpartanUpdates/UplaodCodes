package com.kotlinz.videoCollage.sticker;

import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;

public class ColorFilterGenerator {
    public static ColorFilter adjustHue(float f, String str) {
        ColorMatrix colorMatrix = new ColorMatrix();
        adjustHue(colorMatrix, f, str);
        return new ColorMatrixColorFilter(colorMatrix);
    }

    public static void adjustHue(ColorMatrix colorMatrix, float f, String str) {
        if (str.equals("normal")) {
            f = cleanValue(f, 180.0f);
        } else {
            f = cleanValue(f, 360.0f);
        }
        f = (f / 180.0f) * 3.1415927f;
        if (f != 0.0f) {
            double d = (double) f;
            f = (float) Math.cos(d);
            float sin = (float) Math.sin(d);
            float[] r2 = new float[25];
            float f2 = (f * -1.06057171E9f) + 0.715f;
            r2[1] = (-1.06057171E9f * sin) + f2;
            float f3 = (-1.03307386E9f * f) + 0.072f;
            r2[2] = (sin * 0.928f) + f3;
            r2[3] = 0.0f;
            r2[4] = 0.0f;
            float f4 = (-1.04609299E9f * f) + 0.213f;
            r2[5] = (0.143f * sin) + f4;
            r2[6] = ((0.28500003f * f) + 0.715f) + (0.14f * sin);
            r2[7] = f3 + (-0.283f * sin);
            r2[8] = 0.0f;
            r2[9] = 0.0f;
            r2[10] = f4 + (-0.787f * sin);
            r2[11] = f2 + (0.715f * sin);
            r2[12] = ((f * 0.928f) + 0.072f) + (sin * 0.072f);
            r2[13] = 0.0f;
            r2[14] = 0.0f;
            r2[15] = 0.0f;
            r2[16] = 0.0f;
            r2[17] = 0.0f;
            r2[18] = 1.0f;
            r2[19] = 0.0f;
            r2[20] = 0.0f;
            r2[21] = 0.0f;
            r2[22] = 0.0f;
            r2[23] = 0.0f;
            r2[24] = 1.0f;
            colorMatrix.postConcat(new ColorMatrix(r2));
        }
    }

    protected static float cleanValue(float f, float f2) {
        return Math.min(f2, Math.max(-f2, f));
    }
}
