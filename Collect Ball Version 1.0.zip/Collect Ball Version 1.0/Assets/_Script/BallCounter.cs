﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace BallCollect
{
    public class BallCounter : MonoBehaviour
    {
        [HideInInspector]
        int ballCounter;

        public int pointNo = 1;

        public int targetBall = 10;

        public TextMeshPro text1;

        public Animator checkPointAnimation;

        public TextMeshPro text2;

        bool isRestart = false;

        string[] txt = {"Nice!!","Good!!", "Smart!!","Perfect!!","Awesome!!","Amazing!!","Super!!" };

        private void Awake()
        {
            checkPointAnimation.enabled = false;
            ballCounter = 00;
            text1.text = ballCounter + " / " + targetBall;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (isCounterStart)
            {
                if (other.CompareTag("Ball"))
                {
                    other.gameObject.tag = "Untagged";
                    DataBase.SetCoins(DataBase.GetCoins() + 1);
                    GameController.instance.coinText.text = DataBase.GetCoins().ToString();
                    ballCounter++;
                    text1.text = ballCounter + " / " + targetBall;
                    GameController.instance.levelScore++;
                    if (ballCounter >= targetBall && !isRestart)
                    {
                        isRestart = true;
                        text2.text = txt[UnityEngine.Random.Range(0, txt.Length)].ToString();
                        Invoke("GoAhead", 2.5f);
                        PlayerMove.instance.lastPoint = pointNo;
                    }
                }
            }
        }
        float counter = 0;
        [HideInInspector]
        public bool isCounterStart = false;
        public void Update()
        {
            if (isCounterStart)
            {
                if (!GameController.instance.isPaues)
                {
                    counter += Time.deltaTime;
                    if (counter > 3.5f)
                    {
                        isCounterStart = false;
                        isRestart = true;
                        if (ballCounter < targetBall)
                        {
                            isRestart = true;
                            GameController.instance.isGameOver = true;
                            GameController.instance.GameOver();
                        }
                    }
                }
            }
        }
        void GoAhead()
        {
            checkPointAnimation.enabled = true;
        }
    }
}