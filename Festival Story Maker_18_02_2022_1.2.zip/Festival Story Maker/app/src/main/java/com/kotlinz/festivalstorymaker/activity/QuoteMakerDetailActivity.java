package com.kotlinz.festivalstorymaker.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.Slide;
import androidx.transition.TransitionManager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.kotlinz.festivalstorymaker.Adapter.QuoteMakerCatAdapter;
import com.kotlinz.festivalstorymaker.Adapter.QuoteMakerCategoryListAdapter;
import com.kotlinz.festivalstorymaker.App.MyApplication;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteAddText;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseData;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.CategoryWiseData.QuoteCategoryWiseResponse;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMainCategory;
import com.kotlinz.festivalstorymaker.Model.QuoteMaker.QuoteMakerResponse;
import com.kotlinz.festivalstorymaker.Preferance.ThemeDataPreferences;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIClient;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.APIInterface;
import com.kotlinz.festivalstorymaker.RetrofitApiCall.AppConstant;
import com.kotlinz.festivalstorymaker.Other.TextInputDilaog;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.TypeFace.Font;
import com.kotlinz.festivalstorymaker.coustomSticker.ImageStickerViewNew;
import com.kotlinz.festivalstorymaker.coustomSticker.TextStickerViewNew1;
import com.kotlinz.festivalstorymaker.Listener.SetListener.FontSpecing;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteAddLogo;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteDownload;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteMakerColorList;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteMakerFontHeight;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteSetFont;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteShare;
import com.kotlinz.festivalstorymaker.Listener.SetListener.QuoteText;
import com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter;
import com.kotlinz.festivalstorymaker.texteditor.FontListAdapter;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.TextSticker;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuoteMakerDetailActivity extends BaseActivity implements com.kotlinz.festivalstorymaker.texteditor.FontListAdapter.a, com.kotlinz.festivalstorymaker.texteditor.ColorListAdapter.a {

    Activity activity = QuoteMakerDetailActivity.this;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listFont)
    public RecyclerView rvFont;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llAlign)
    public LinearLayout llAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llCaps)
    public LinearLayout C;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llColors)
    public LinearLayout llColors;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llDeleteImage)
    public LinearLayout llDeleteImage;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llFonts)
    public LinearLayout llFonts;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llLine)
    public LinearLayout llLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llSpacing)
    public LinearLayout llSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llList)
    public LinearLayout llList;

    @BindView(com.kotlinz.festivalstorymaker.R.id.llTextEditor)
    public LinearLayout llTextEditor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlFull)
    public RelativeLayout rlFull;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rlMain)
    public RelativeLayout rlMain;

    @BindView(com.kotlinz.festivalstorymaker.R.id.scroll)
    public ScrollView svScroll;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontSpacing)
    public SeekBar sbFontSpacing;

    @BindView(com.kotlinz.festivalstorymaker.R.id.seekBarFontHeight)
    public SeekBar sbFontHeight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.txtDataNotAvailable)
    public TextView tvNoDataAvalible;

    @BindView(com.kotlinz.festivalstorymaker.R.id.catList)
    public RecyclerView rvCatList;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlign)
    public ImageView ivAlign;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignCenter)
    public ImageView ivAlignCenter;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignLeft)
    public ImageView ivAlignLeft;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAlignRight)
    public ImageView ivAlignRight;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgAllCap)
    public ImageView ivAllCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgCaps)
    public ImageView ivCaps;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgColor)
    public ImageView ivColor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFirstCap)
    public ImageView ivFirstCap;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgFont)
    public ImageView ivFont;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgLine)
    public ImageView ivLine;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSmall)
    public ImageView ivSmall;

    @BindView(com.kotlinz.festivalstorymaker.R.id.imgSpace)
    public ImageView ivSpace;

    @BindView(com.kotlinz.festivalstorymaker.R.id.listColor)
    public RecyclerView rvColor;

    @BindView(com.kotlinz.festivalstorymaker.R.id.rv_quote_category)
    public RecyclerView rvQuoteMakerCategory;

    @BindView(R.id.ll_main_Data)
    LinearLayout llMainData;

    @BindView(R.id.llRetry)
    LinearLayout llRetry;

    public FrameLayout flStickerView;
    public int M = 10;
    public int P = -1;
    public int S = -1;
    public int T = -1;

    public ImageStickerViewNew imageStickerViewNew;
    public FontListAdapter fontListAdapter;
    public ColorListAdapter colorListAdapter;
    public ArrayList<com.kotlinz.festivalstorymaker.Models.z.c> U = new ArrayList();
    public TextStickerViewNew1 stickerViewNew1;
    public boolean isText;

    private int ModuleId;
    private ProgressDialog progressDialog;
    APIInterface apiInterface;

    ArrayList<QuoteMainCategory> quoteMainCategories;
    QuoteMakerCatAdapter quoteMakerCatListAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    public ArrayList<QuoteCategoryWiseData> quoteSubCategoryList;

    Gson gson = new Gson();

    private void DownloadComplete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View customLayout = getLayoutInflater().inflate(com.kotlinz.festivalstorymaker.R.layout.layout_download_complete, null);
        builder.setView(customLayout);
        AlertDialog dialog = builder.create();
        ImageView ivOk = customLayout.findViewById(com.kotlinz.festivalstorymaker.R.id.iv_ok);
        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public QuoteMakerDetailActivity() {

    }


    public class d extends AsyncTask<Integer, Boolean, File> {
        public boolean a;

        public d(boolean z) {
            this.a = z;
        }

        public void onPreExecute() {
            super.onPreExecute();
            QuoteMakerDetailActivity.this.u = new Utils(QuoteMakerDetailActivity.this);
            QuoteMakerDetailActivity quoteMakerDetailActivity = QuoteMakerDetailActivity.this;
            quoteMakerDetailActivity.u.c(quoteMakerDetailActivity.getResources().getString(com.kotlinz.festivalstorymaker.R.string.downloading));
            if (!QuoteMakerDetailActivity.this.isFinishing()) {
                QuoteMakerDetailActivity.this.u.m();
            }
        }


        @Override
        protected File doInBackground(Integer... integers) {
            Integer[] numArr = integers;
            boolean z = this.a;
            try {
                Bitmap e0 = QuoteMakerDetailActivity.this.e0(flStickerView);
                File o0 = QuoteMakerDetailActivity.this.o0();
                if (o0 != null) {
                    FileOutputStream fileOutputStream = new FileOutputStream(o0.getAbsolutePath());
                    e0.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.close();
                    Utils.K(QuoteMakerDetailActivity.this, o0);
                    if (z) {
                        Utils.d();
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.setType("image/*");
                        intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(o0));
                        startActivity(Intent.createChooser(intent, "Share image using"));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(File obj) {
            super.onPostExecute(obj);
            File file = obj;
            QuoteMakerDetailActivity quoteMakerDetailActivity = QuoteMakerDetailActivity.this;
            DownloadComplete();
            if (!QuoteMakerDetailActivity.this.isFinishing()) {
                QuoteMakerDetailActivity.this.u.u();
            }
        }
    }

    public class a implements TextInputDilaog.d {
        public final FrameLayout frameLayout;
        public final TextStickerViewNew1 b;

        public a(QuoteMakerDetailActivity quoteMakerDetailActivity, FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
            this.frameLayout = frameLayout;
            this.b = textStickerViewNew1;
        }

        public void a(String str, int i) {
            if (str.length() == 0) {
                this.frameLayout.removeView(this.b);
            } else {
                this.b.setText(str);
            }
            this.frameLayout.requestLayout();
        }

        public void b(String str) {

        }
    }

    public class c implements QuoteMakerCategoryListAdapter.a {

    }

    public void h0(QuoteMakerDetailActivity quoteMakerDetailActivity, int i) {
        llList.removeAllViews();
        llList.requestLayout();
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(i).getCatId() + quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {
                GetStoryCategoryDataByID(String.valueOf(quoteMainCategories.get(i).getCatId()), String.valueOf(quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()));
            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.QuoteMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetStoryCategoryDataByID(String.valueOf(quoteMainCategories.get(i).getCatId()), String.valueOf(quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()));
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(i).getCatId() + quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(i).getCatId() + quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(i).getCatId() + quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()).equalsIgnoreCase("")) {
                llMainData.setVisibility(View.GONE);
                llRetry.setVisibility(View.VISIBLE);
            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(i).getCatId() + quoteMainCategories.get(i).getChildCategory().get(0).getChildCatId()));
            }
        }
    }

    private void InitProgressDialog() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Please Wait...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void SetQuiteMakerList() {
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker).equalsIgnoreCase("")) {
                GetQuoteList(ModuleId);
            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.QuoteMakerResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetQuoteList(ModuleId);
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker).equalsIgnoreCase("")) {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker).equalsIgnoreCase("")) {
                llMainData.setVisibility(View.VISIBLE);
                llRetry.setVisibility(View.GONE);
            } else {
                SetOfflineDataMainCategory(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker));
            }
        }
    }

    private void GetQuoteList(int ModuleId) {
        progressDialog.show();
        Call<QuoteMakerResponse> call = apiInterface.getQuoteModuleWiseCategory(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId));
        call.enqueue(new Callback<QuoteMakerResponse>() {
            @Override
            public void onResponse(Call<QuoteMakerResponse> call, Response<QuoteMakerResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.QuoteMaker);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.QuoteMakerResponseTime);
                    SetOfflineDataMainCategory(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<QuoteMakerResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMaker).equalsIgnoreCase("")) {
                    llMainData.setVisibility(View.VISIBLE);
                    llRetry.setVisibility(View.GONE);
                    Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineDataMainCategory(String response) {
        QuoteMakerResponse quoteMakerResponse = gson.fromJson(response, QuoteMakerResponse.class);
        quoteMainCategories = quoteMakerResponse.getData();

        quoteMakerCatListAdapter = new QuoteMakerCatAdapter(activity, quoteMainCategories);
        mLayoutManager = new LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false);
        rvQuoteMakerCategory.setLayoutManager(mLayoutManager);
        rvQuoteMakerCategory.setAdapter(quoteMakerCatListAdapter);

        SetQuoteThemeData(0, quoteMainCategories);
        progressDialog.dismiss();
    }

    public void SetQuoteThemeData(int Position, ArrayList<QuoteMainCategory> quoteMakerCategoryList) {
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMakerCategoryList.get(Position).getCatId() + quoteMakerCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                GetStoryCategoryDataByID(String.valueOf(quoteMainCategories.get(Position).getCatId()), String.valueOf(quoteMainCategories.get(Position).getChildCategory().get(Position).getChildCatId()));
            } else if (((new Date().getTime() - ThemeDataPreferences.INSTANCE.getPreferencesResponseTime(activity, ThemeDataPreferences.QuoteMakerThemeResponseTime, 1588598205L))) >= ThemeDataPreferences.INSTANCE.ApiUpdateTime) {
                GetStoryCategoryDataByID(String.valueOf(quoteMainCategories.get(Position).getCatId()), String.valueOf(quoteMainCategories.get(Position).getChildCategory().get(Position).getChildCatId()));
            } else if (!ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMakerCategoryList.get(Position).getCatId() + quoteMakerCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(Position).getCatId() + quoteMainCategories.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        } else {
            if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMakerCategoryList.get(Position).getCatId() + quoteMakerCategoryList.get(Position).getChildCategory().get(Position).getChildCatId()).equalsIgnoreCase("")) {
                llMainData.setVisibility(View.VISIBLE);
                llRetry.setVisibility(View.GONE);
            } else {
                SetOfflineThemeData(ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + quoteMainCategories.get(Position).getCatId() + quoteMainCategories.get(Position).getChildCategory().get(Position).getChildCatId()));
            }
        }
    }

    public void GetStoryCategoryDataByID(String ParentCatId, String ChildCatId) {
        progressDialog.show();
        Call<QuoteCategoryWiseResponse> call = apiInterface.getQuoteCategoryWiseData(AppConstant.token, AppConstant.ApplicationId, String.valueOf(ModuleId), "0", ParentCatId, ChildCatId);
        call.enqueue(new Callback<QuoteCategoryWiseResponse>() {
            @Override
            public void onResponse(Call<QuoteCategoryWiseResponse> call, Response<QuoteCategoryWiseResponse> response) {
                if (response.isSuccessful()) {
                    ThemeDataPreferences.INSTANCE.setDataToOffline(activity, new Gson().toJson(response.body()), ThemeDataPreferences.QuoteMakerTheme + ParentCatId + ChildCatId);
                    ThemeDataPreferences.INSTANCE.SetApiCallResponseTime(activity, new Date(), ThemeDataPreferences.QuoteMakerThemeResponseTime);
                    SetOfflineThemeData(new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<QuoteCategoryWiseResponse> call, Throwable t) {
                if (ThemeDataPreferences.INSTANCE.getPreferencesData(activity, ThemeDataPreferences.QuoteMakerTheme + ParentCatId + ChildCatId).equalsIgnoreCase("")) {
                    llMainData.setVisibility(View.VISIBLE);
                    llRetry.setVisibility(View.GONE);
                    Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SetOfflineThemeData(String response) {
        QuoteCategoryWiseResponse categoryWiseResponse = gson.fromJson(response, QuoteCategoryWiseResponse.class);
        quoteSubCategoryList = categoryWiseResponse.getData();
        n0();
        progressDialog.dismiss();
    }

    @OnClick(R.id.iv_my_creation)
    public void MyCreation() {
        if (MyApplication.isShowAd == 1) {
            startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom", "Quote Maker"));
            finish();
            MyApplication.isShowAd = 0;
        } else {
            if (MyApplication.mInterstitialAd != null) {
                MyApplication.activity = activity;
                MyApplication.AdsId = 22;
                MyApplication.mInterstitialAd.show(activity);
                MyApplication.isShowAd = 1;
            } else {
                startActivity(new Intent(activity, MyPostActivity.class).putExtra("IsFrom", "Quote Maker"));
                finish();
            }
        }
    }

    public static void i0(QuoteMakerDetailActivity quoteMakerDetailActivity, boolean z) {
        if (z && quoteMakerDetailActivity.stickerViewNew1 != null) {
            quoteMakerDetailActivity.m0(quoteMakerDetailActivity.ivFont);
            com.kotlinz.festivalstorymaker.Models.z.c cVar = quoteMakerDetailActivity.U.get(((Integer) quoteMakerDetailActivity.stickerViewNew1.getTag()).intValue());
            quoteMakerDetailActivity.S = cVar.d;
            quoteMakerDetailActivity.T = cVar.f;
            quoteMakerDetailActivity.sbFontHeight.setProgress(cVar.a);
            quoteMakerDetailActivity.sbFontSpacing.setProgress(cVar.b);
            quoteMakerDetailActivity.colorListAdapter.k(quoteMakerDetailActivity.S);
            quoteMakerDetailActivity.fontListAdapter.k(quoteMakerDetailActivity.T);
            quoteMakerDetailActivity.k0(cVar.c);
            quoteMakerDetailActivity.l0(cVar.e);
        }
        LinearLayout linearLayout = quoteMakerDetailActivity.llTextEditor;
        RelativeLayout relativeLayout = quoteMakerDetailActivity.rlMain;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(linearLayout);
        TransitionManager.beginDelayedTransition(relativeLayout, slide);
        linearLayout.setVisibility(z ? View.VISIBLE : View.GONE);
    }

    public void B(Typeface typeface, int i) {
        Font font = this.stickerViewNew1.getFont();
        font.c = typeface;
        this.stickerViewNew1.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.U.get(((Integer) this.stickerViewNew1.getTag()).intValue());
        cVar.f = i;
        this.U.set(((Integer) this.stickerViewNew1.getTag()).intValue(), cVar);
    }

    public void D(int i) {
        Font font = stickerViewNew1.getFont();
        font.a = Color.parseColor(colorList[i]);
        this.stickerViewNew1.setFont(font);
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.U.get(((Integer) this.stickerViewNew1.getTag()).intValue());
        cVar.d = i;
        this.U.set(((Integer) this.stickerViewNew1.getTag()).intValue(), cVar);
    }

    public void L(int i, String str) {

    }

    public final void g0(FrameLayout frameLayout, TextStickerViewNew1 textStickerViewNew1) {
        TextInputDilaog.q0(this, textStickerViewNew1.getText(), false, "").m0 = new a(this, frameLayout, textStickerViewNew1);
    }

    public void j0(String str, float f, float f2, float f3, float f4, int i) {
        ImageStickerViewNew imageStickerViewNew = new ImageStickerViewNew(this, str, f, f2, f3, f4, i, true);
        String str2 = str;
        File file = new File(str);
        if (file.exists()) {
            try {
                Bitmap decodeFile = BitmapFactory.decodeFile(file.getAbsolutePath());
                imageStickerViewNew.setGif(false);
                imageStickerViewNew.setTag(com.kotlinz.festivalstorymaker.Other.AppConstant.D1);
                imageStickerViewNew.i0 = true;
                imageStickerViewNew.setWH(flStickerView.getWidth(), flStickerView.getHeight());
                imageStickerViewNew.setBitmap(decodeFile, Boolean.TRUE);
                imageStickerViewNew.setOperationListener(new QuoteText(this));
                imageStickerViewNew.setSize(150.0f);
                flStickerView.addView(imageStickerViewNew);
                flStickerView.requestLayout();
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressLint({"NewApi"})
    public final void k0(int i) {
        int i2 = -16777216;
        ivAlignCenter.setColorFilter(i == 0 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAlignLeft.setColorFilter(i == -1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivAlignRight;
        if (i != 1) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = stickerViewNew1.getText();
        TextStickerViewNew1 textStickerViewNew1 = this.stickerViewNew1;
        Layout.Alignment alignment = i == 0 ? Layout.Alignment.ALIGN_CENTER : i == 1 ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
        textStickerViewNew1.setAlign(alignment);
        stickerViewNew1.setText(str);
        stickerViewNew1.requestLayout();
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.U.get(((Integer) this.stickerViewNew1.getTag()).intValue());
        cVar.c = i;
        U.set(((Integer) this.stickerViewNew1.getTag()).intValue(), cVar);
    }

    public final void l0(int i) {
        int i2 = -16777216;
        ivFirstCap.setColorFilter(i == 1 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ivAllCap.setColorFilter(i == 2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        ImageView imageView = ivSmall;
        if (i != 0) {
            i2 = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView.setColorFilter(i2);
        String str = this.stickerViewNew1.getText();
        if (i != -1) {
            TextStickerViewNew1 textStickerViewNew1 = this.stickerViewNew1;
            str = i == 2 ? str.toUpperCase() : i == 0 ? str.toLowerCase() : f0(str);
            textStickerViewNew1.setText(str);
        }
        com.kotlinz.festivalstorymaker.Models.z.c cVar = this.U.get(((Integer) this.stickerViewNew1.getTag()).intValue());
        cVar.e = i;
        this.U.set(((Integer) this.stickerViewNew1.getTag()).intValue(), cVar);
    }

    public final void m0(ImageView imageView) {
        LinearLayout linearLayout;
        ImageView imageView2 = ivFont;
        int i = -16777216;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivColor;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivAlign;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivSpace;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivLine;
        imageView2.setColorFilter(imageView == imageView2 ? -16777216 : getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray));
        imageView2 = ivCaps;
        if (imageView != imageView2) {
            i = getResources().getColor(com.kotlinz.festivalstorymaker.R.color.gray);
        }
        imageView2.setColorFilter(i);
        if (imageView == ivFont) {
            linearLayout = llFonts;
        } else if (imageView == ivColor) {
            linearLayout = llColors;
        } else if (imageView == ivAlign) {
            linearLayout = llAlign;
        } else if (imageView == ivSpace) {
            linearLayout = llSpacing;
        } else if (imageView == ivLine) {
            linearLayout = llLine;
        } else if (imageView == ivCaps) {
            linearLayout = C;
        } else {
            return;
        }
        linearLayout.bringToFront();
    }

    @SuppressLint("ClickableViewAccessibility")
    public final void n0() {
        for (int i = 0; i < quoteSubCategoryList.size(); i++) {
            View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(com.kotlinz.festivalstorymaker.R.layout.adapter_quote_maker_detail_list_item, null);
            ImageView imageView = inflate.findViewById(R.id.img);
            ImageView imageView2 = inflate.findViewById(R.id.imgWaterMark);
            FrameLayout frameLayout = inflate.findViewById(R.id.frameMain);
            StickerView stickerView = inflate.findViewById(R.id.sticker_view);
            Picasso.get().load((quoteSubCategoryList.get(i)).getThemeThumbnail()).placeholder(com.kotlinz.festivalstorymaker.R.drawable.ic_placehoder).into(imageView, null);
            imageView2.setVisibility(Utils.y(this, false) ? View.GONE : View.VISIBLE);
            frameLayout.getLayoutParams().height = this.P;
            frameLayout.requestLayout();
            inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardLogo).setOnClickListener(new QuoteAddLogo(this, frameLayout));
            /*inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardAddText).setOnClickListener(new QuoteAddText(this, frameLayout));*/
            inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardAddText).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                    View customLayout = getLayoutInflater().inflate(R.layout.add_text_dialog, null);
                    builder.setCancelable(false);
                    builder.setView(customLayout);
                    AlertDialog dialog = builder.create();
                    EditText etText = customLayout.findViewById(R.id.add_text_edit_text);
                    ImageView ivCancel = customLayout.findViewById(R.id.add_text_cancel_tv);
                    ImageView ivDone = customLayout.findViewById(R.id.add_text_done_tv);
                    ivCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                    ivDone.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TextSticker sticker = new TextSticker(activity);
                            if (etText.getText().toString().matches("")) {
                                Toast.makeText(activity, "Enter Text First", Toast.LENGTH_SHORT).show();
                            } else {
                                sticker.setText(etText.getText().toString());
                                sticker.setTextColor(Color.BLACK);
                                sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
                                sticker.resizeText();
                                stickerView.addSticker(sticker);
                                dialog.dismiss();
                            }
                        }
                    });
                    dialog.show();
                }
            });
            imageView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            stickerView.setLocked(!stickerView.isLocked());
                            break;
                    }
                    return false;
                }
            });

            stickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
                @Override
                public void onStickerAdded(@NonNull Sticker sticker) {
                }

                @Override
                public void onStickerClicked(@NonNull Sticker sticker) {
                    if (sticker instanceof TextSticker) {
                        ((TextSticker) sticker).setTextColor(Color.BLACK);
                        stickerView.replace(sticker);
                        stickerView.invalidate();
                    }
                }

                @Override
                public void onStickerDeleted(@NonNull Sticker sticker) {

                }

                @Override
                public void onStickerDragFinished(@NonNull Sticker sticker) {
                }

                @Override
                public void onStickerTouchedDown(@NonNull Sticker sticker) {
                    svScroll.requestDisallowInterceptTouchEvent(true);
                }

                @Override
                public void onStickerZoomFinished(@NonNull Sticker sticker) {

                }

                @Override
                public void onStickerFlipped(@NonNull Sticker sticker) {

                }

                @Override
                public void onStickerDoubleTapped(@NonNull Sticker sticker) {

                }
            });
            inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardShare).setOnClickListener(new QuoteShare(this, frameLayout));
            inflate.findViewById(com.kotlinz.festivalstorymaker.R.id.cardDownload).setOnClickListener(new QuoteDownload(this, frameLayout));
            llList.addView(inflate);
            llList.requestLayout();
        }
    }


    public File o0() {
        String absolutePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + "Festival Story Maker" + File.separator + "My Post" + File.separator + "Quote Maker";
        String s = com.kotlinz.festivalstorymaker.Other.l.a.b.a.a.s(new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US));
        File file = new File(absolutePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(file);
        stringBuilder.append(File.separator);
        stringBuilder.append(s);
        stringBuilder.append(".jpg");
        absolutePath = stringBuilder.toString();
        return TextUtils.isEmpty(absolutePath) ? null : new File(absolutePath);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        i2 = com.kotlinz.festivalstorymaker.Other.AppConstant.H;
        if (i == 7924 && intent != null) {
            String stringExtra = intent.getStringExtra("path");
            if (!stringExtra.isEmpty()) {
                i = 0;
                while (i < flStickerView.getChildCount()) {
                    if (flStickerView.getChildAt(i).getTag() != null && flStickerView.getChildAt(i).getTag().equals(com.kotlinz.festivalstorymaker.Other.AppConstant.D1)) {
                        flStickerView.removeViewAt(i);
                    }
                    i++;
                }
                Bitmap decodeFile = BitmapFactory.decodeFile(new File(stringExtra).getAbsolutePath());
                j0(stringExtra, ((float) this.M) + (((float) (decodeFile.getWidth() / 2)) - ((((float) decodeFile.getWidth()) - ((((float) decodeFile.getWidth()) * 150.0f) / ((float) decodeFile.getHeight()))) / 2.0f)), (((float) (decodeFile.getHeight() / 2)) - ((((float) decodeFile.getHeight()) - 150.0f) / 2.0f)) + ((float) this.M), 1.0f, 0.0f, 2);
            }
        }
    }

    public void onClick(View view) {
        finish();
    }


    public void onClicks(View view) {
        ImageView imageView;
        switch (view.getId()) {
            case com.kotlinz.festivalstorymaker.R.id.imgAlign:
                imageView = ivAlignLeft;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignCenter:
                k0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignLeft:
                k0(-1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAlignRight:
                k0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgAllCap:
                l0(2);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgCaps:
                imageView = ivCaps;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgColor:
                imageView = ivColor;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgFirstCap:
                l0(1);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgFont:
                imageView = ivFont;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgLine:
                imageView = ivLine;
                break;
            case com.kotlinz.festivalstorymaker.R.id.imgSmall:
                l0(0);
                return;
            case com.kotlinz.festivalstorymaker.R.id.imgSpace:
                imageView = ivSpace;
                break;
            default:
                return;
        }
        m0(imageView);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.kotlinz.festivalstorymaker.R.layout.activity_quote_maker_detail);
        ButterKnife.bind(this);
        PutAnalyticsEvent();
        com.kotlinz.festivalstorymaker.Other.l.c.a.a.b.b = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);
        ModuleId = getIntent().getIntExtra("moduleid", 0);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        InitProgressDialog();
        SetQuiteMakerList();
        ivLine.setColorFilter(-16777216);
        llFonts.bringToFront();
        fontListAdapter = new FontListAdapter(this, fontList, new QuoteSetFont(this), this.T);
        rvFont.setAdapter(fontListAdapter);
        colorListAdapter = new ColorListAdapter(this, colorList, new QuoteMakerColorList(this), this.S);
        rvColor.setAdapter(colorListAdapter);
        sbFontHeight.setOnSeekBarChangeListener(new QuoteMakerFontHeight(this));
        sbFontSpacing.setOnSeekBarChangeListener(new FontSpecing(this));
    }


    //Firebase AnalyticsEvent
    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "QuoteMakerDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    @OnClick(R.id.llRetry)
    public void RetryData() {
        if (com.kotlinz.festivalstorymaker.AppUtils.Utils.checkConnectivity(activity, false)) {
            llMainData.setVisibility(View.VISIBLE);
            llRetry.setVisibility(View.GONE);
            GetQuoteList(ModuleId);
        } else {
            Toast.makeText(activity, "Data/wifi Not Available", Toast.LENGTH_SHORT).show();
        }
    }

    @OnClick({com.kotlinz.festivalstorymaker.R.id.cardCancelImage, com.kotlinz.festivalstorymaker.R.id.cardDeleteImage})
    public void onViewClick(View view) {
        int id = view.getId();
        if (id == com.kotlinz.festivalstorymaker.R.id.cardCancelImage || id == com.kotlinz.festivalstorymaker.R.id.cardDeleteImage) {
            p0(false);
        }
    }

    public final void p0(boolean z) {
        int i = 0;
        rlFull.setVisibility(z ? View.VISIBLE : View.GONE);
        LinearLayout linearLayout = llDeleteImage;
        RelativeLayout relativeLayout = rlMain;
        Slide slide = new Slide(Gravity.BOTTOM);
        slide.setDuration(500);
        slide.addTarget(llDeleteImage);
        TransitionManager.beginDelayedTransition(relativeLayout, slide);
        if (!z) {
            i = 8;
        }
        linearLayout.setVisibility(i);
    }

    @OnClick(com.kotlinz.festivalstorymaker.R.id.iv_back)
    public void GoToHome() {
        onBackPressed();
    }

    public void onBackPressed() {
        startActivity(new Intent(activity, DashBordActivity.class));
        finish();
    }
}
