package com.xyz.vehiclemanager.bikedetails.bikeservice.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.xyz.vehiclemanager.R;
import com.xyz.vehiclemanager.bikedetails.bikeservice.adapter.BikeServiceDetailAdapter;
import com.xyz.vehiclemanager.bikedetails.bikeservice.model.BikeService;
import com.xyz.vehiclemanager.cardetails.carservice.activity.CarServiceSelectStateActivity;
import com.xyz.vehiclemanager.retrofit.RtoDetailsApiClient;
import com.xyz.vehiclemanager.retrofit.RtoDetailsInterface;
import com.xyz.vehiclemanager.utils.Utils;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BikeServiceDetailActivity extends AppCompatActivity implements View.OnClickListener
{
    private Activity activity = BikeServiceDetailActivity.this;
    private String cityId,brandId,cityName;
    private TextView tv_cityname;
    private ImageView iv_back;
    private BikeServiceDetailAdapter bikeServiceDetailAdapter;
    private RecyclerView rv_servicedetail;
    private Button btn_changecity;
    private RtoDetailsInterface rtoDetailsInterface;
    private AppCompatDialog dialog;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikeservice_detail);

        Intent intent = getIntent();
        brandId = intent.getStringExtra("id");
        cityName = intent.getStringExtra("cityname");
        cityId = intent.getStringExtra("cityid");
        if(brandId == null)
        {
            brandId = CarServiceSelectStateActivity.brandId;
        }

        rtoDetailsInterface = RtoDetailsApiClient.getClient().create(RtoDetailsInterface.class);
        BindView();
        PutAnalyticsEvent();
        BannerAds();
        DialogAnimation();
        if (Utils.isOnline(activity)){
            getBikeServiceDetails();
        }else {
            Toast.makeText(activity, getResources().getString(R.string.conne_msg), Toast.LENGTH_SHORT).show();
        }
    }

    private void BindView()
    {
        iv_back = findViewById(R.id.iv_back);
        tv_cityname = findViewById(R.id.tv_cityname);
        rv_servicedetail = findViewById(R.id.rv_servicedetail);
        btn_changecity = findViewById(R.id.btn_changecity);

        btn_changecity.setOnClickListener(this);
        iv_back.setOnClickListener(this);

        tv_cityname.setText(cityName);
    }

    private void PutAnalyticsEvent() {
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "BikeServiceDetailActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_BannerAd));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void  DialogAnimation()
    {
        dialog = new AppCompatDialog(activity, R.style.DialogStyleLight);
        dialog.setContentView(R.layout.layout_bikedialog);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn_changecity:
                onBackPressed();
            break;

            case R.id.iv_back:
                onBackPressed();
            break;
        }
    }

    private void getBikeServiceDetails(){
        Call<BikeService> call = rtoDetailsInterface.getBikeServiceDetails(brandId,cityId);
        call.enqueue(new Callback<BikeService>() {
            @Override
            public void onResponse(Call<BikeService> call, Response<BikeService> response) {
                if (response.isSuccessful()){
                    if (dialog != null && dialog.isShowing())
                    {
                        dialog.dismiss();
                    }
                    ArrayList<BikeService> bikeservicelist = response.body().getData();
                    String statusMessage = response.body().getStatusMessage();
                    if(statusMessage.contains("Sorry! No matching bike service centers found."))
                    {
                        Toast.makeText(activity, "No Data found", Toast.LENGTH_SHORT).show();
                    }else
                        {
                        bikeServiceDetailAdapter = new BikeServiceDetailAdapter(activity, bikeservicelist);
                        rv_servicedetail.setAdapter(bikeServiceDetailAdapter);
                        rv_servicedetail.setLayoutManager(new LinearLayoutManager(activity));
                    }
                }
            }

            @Override
            public void onFailure(Call<BikeService> call, Throwable t) {
                if (dialog != null && dialog.isShowing())
                {
                    dialog.dismiss();
                }
                 Toast.makeText(activity, "Slow Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
       super.onBackPressed();
    }
}