package com.esc.phoneheart.adapter;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import com.esc.phoneheart.activity.DuplicatesFileTabScreen;
import com.esc.phoneheart.activity.PhoneCleaner;
import com.esc.phoneheart.R;
import com.esc.phoneheart.fragment.AudFileFragment;
import com.esc.phoneheart.fragment.DocFileFragment;
import com.esc.phoneheart.fragment.ImgFileFragment.SimpleAdapter;
import com.esc.phoneheart.fragment.VidFileFragment;
import com.esc.phoneheart.wrappers.BigSizeFilesWrapper;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.AdapterDataObserver;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;

public class SectionGridViewAdapterFiles extends Adapter<ViewHolder> {

    public Map<Integer, ArrayList<BigSizeFilesWrapper>> duplicateGridImages;
    public Adapter mBaseAdapter;
    public final Context mContext;
    public int mSectionResourceId;
    public SparseArray<Section> mSections = new SparseArray();
    public boolean mValid = true;

    public static class Section {
        public String a;
        public int b;
        public int c;
        public CharSequence d;
        public String e;
        public boolean f;

        public Section(int i, CharSequence charSequence, String str, String str2, boolean z) {
            this.b = i;
            this.d = charSequence;
            this.e = str;
            this.a = str2;
            this.f = z;
        }

        public String getCount() {
            return this.e;
        }

        public CharSequence getTitle() {
            return this.d;
        }
    }

    public static class SectionViewHolder extends ViewHolder {
        public TextView section_text2;
        public TextView section_text;
        public TextView tv_group_childcount;
        public CheckBox grp_chk;

        public SectionViewHolder(View view) {
            super(view);
            this.section_text = (TextView) view.findViewById(R.id.section_text);
            this.section_text2 = (TextView) view.findViewById(R.id.section_text2);
            this.tv_group_childcount = (TextView) view.findViewById(R.id.tv_group_childcount);
            this.grp_chk = (CheckBox) view.findViewById(R.id.grp_chk);
        }
    }

    public SectionGridViewAdapterFiles(Context context, int i, RecyclerView recyclerView, Adapter adapter, Map<Integer, ArrayList<BigSizeFilesWrapper>> map) {
        this.mSectionResourceId = i;
        this.mBaseAdapter = adapter;
        this.mContext = context;
        this.duplicateGridImages = map;
        adapter.registerAdapterDataObserver(new AdapterDataObserver() {
            public void onChanged() {
                SectionGridViewAdapterFiles sectionGridViewAdapterFiles = SectionGridViewAdapterFiles.this;
                sectionGridViewAdapterFiles.mValid = sectionGridViewAdapterFiles.mBaseAdapter.getItemCount() > 0;
                SectionGridViewAdapterFiles.this.notifyDataSetChanged();
            }

            public void onItemRangeChanged(int i, int i2) {
                SectionGridViewAdapterFiles sectionGridViewAdapterFiles = SectionGridViewAdapterFiles.this;
                sectionGridViewAdapterFiles.mValid = sectionGridViewAdapterFiles.mBaseAdapter.getItemCount() > 0;
                SectionGridViewAdapterFiles.this.notifyItemRangeChanged(i, i2);
            }

            public void onItemRangeInserted(int i, int i2) {
                SectionGridViewAdapterFiles sectionGridViewAdapterFiles = SectionGridViewAdapterFiles.this;
                sectionGridViewAdapterFiles.mValid = sectionGridViewAdapterFiles.mBaseAdapter.getItemCount() > 0;
                SectionGridViewAdapterFiles.this.notifyItemRangeInserted(i, i2);
            }

            public void onItemRangeRemoved(int i, int i2) {
                SectionGridViewAdapterFiles sectionGridViewAdapterFiles = SectionGridViewAdapterFiles.this;
                sectionGridViewAdapterFiles.mValid = sectionGridViewAdapterFiles.mBaseAdapter.getItemCount() > 0;
                SectionGridViewAdapterFiles.this.notifyItemRangeRemoved(i, i2);
            }
        });
        final GridLayoutManager gridLayoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
        if (gridLayoutManager != null) {
            gridLayoutManager.setSpanSizeLookup(new SpanSizeLookup() {
                public int getSpanSize(int i) {
                    return SectionGridViewAdapterFiles.this.isSectionHeaderPosition(i) ? gridLayoutManager.getSpanCount() : 1;
                }
            });
        }
    }

    public int getItemCount() {
        return this.mValid ? this.mBaseAdapter.getItemCount() + this.mSections.size() : 0;
    }

    public long getItemId(int i) {
        if (isSectionHeaderPosition(i)) {
            return (long) (Integer.MAX_VALUE - this.mSections.indexOfKey(i));
        }
        return this.mBaseAdapter.getItemId(sectionedPositionToPosition(i));
    }

    public int getItemViewType(int i) {
        if (isSectionHeaderPosition(i)) {
            return 0;
        }
        return this.mBaseAdapter.getItemViewType(sectionedPositionToPosition(i)) + 1;
    }

    public boolean isSectionHeaderPosition(int i) {
        return this.mSections.get(i) != null;
    }

    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int position) {
        if (isSectionHeaderPosition(position)) {
            SectionViewHolder sectionViewHolder = (SectionViewHolder) viewHolder;
            sectionViewHolder.section_text.setText(this.mSections.get(position).d);
            sectionViewHolder.section_text2.setText("");
            sectionViewHolder.tv_group_childcount.setText(((Section) this.mSections.get(position)).a);
            if (((Section) this.mSections.get(position)).f) {
                sectionViewHolder.grp_chk.setChecked(true);
            } else {
                sectionViewHolder.grp_chk.setChecked(false);
            }
            sectionViewHolder.grp_chk.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ArrayList arrayList = (ArrayList) SectionGridViewAdapterFiles.this.duplicateGridImages.get(Integer.valueOf(Integer.valueOf(((Section) SectionGridViewAdapterFiles.this.mSections.get(position)).d.toString().split(SectionGridViewAdapterFiles.this.mContext.getString(R.string.dup_photo_groups))[1]).intValue()));
                    if (((SectionViewHolder) viewHolder).grp_chk.isChecked()) {
                        ((SectionViewHolder) viewHolder).grp_chk.setChecked(((SectionViewHolder) viewHolder).grp_chk.isChecked());
                        for (int i = 0; i < arrayList.size(); i++) {
                            if (i == 0) {
                                if (((BigSizeFilesWrapper) arrayList.get(0)).ischecked) {
                                    ((BigSizeFilesWrapper) arrayList.get(0)).ischecked = false;
                                    PhoneCleaner.getInstance().duplicateFilesData.unselectNode((BigSizeFilesWrapper) arrayList.get(i));
                                }
                            } else if (!((BigSizeFilesWrapper) arrayList.get(i)).ischecked) {
                                ((BigSizeFilesWrapper) arrayList.get(i)).ischecked = true;
                                PhoneCleaner.getInstance().duplicateFilesData.selectNode((BigSizeFilesWrapper) arrayList.get(i));
                            }
                        }
                        ((DuplicatesFileTabScreen) SectionGridViewAdapterFiles.this.mContext).getSelection();
                    } else {
                        ((SectionViewHolder) viewHolder).grp_chk.setChecked(false);
                        ((Section) SectionGridViewAdapterFiles.this.mSections.get(position)).f = false;
                        for (int i2 = 0; i2 < arrayList.size(); i2++) {
                            if (((BigSizeFilesWrapper) arrayList.get(i2)).ischecked) {
                                ((BigSizeFilesWrapper) arrayList.get(i2)).ischecked = false;
                                PhoneCleaner.getInstance().duplicateFilesData.unselectNode((BigSizeFilesWrapper) arrayList.get(i2));
                            }
                        }
                        ((AppCompatCheckBox) ((DuplicatesFileTabScreen) SectionGridViewAdapterFiles.this.mContext).findViewById(R.id.check_all)).setChecked(false);
                    }
                    if (SectionGridViewAdapterFiles.this.mBaseAdapter instanceof SimpleAdapter) {
                        ((SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).setDeleteBtnText();
                        ((SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).refreshRecyclerView();
                    } else if (SectionGridViewAdapterFiles.this.mBaseAdapter instanceof VidFileFragment.SimpleAdapter) {
                        ((VidFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).setDeleteBtnText();
                        ((VidFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).refreshRecyclerView();
                    } else if (SectionGridViewAdapterFiles.this.mBaseAdapter instanceof AudFileFragment.SimpleAdapter) {
                        ((AudFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).setDeleteBtnText();
                        ((AudFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).refreshRecyclerView();
                    } else {
                        ((DocFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).setDeleteBtnText();
                        ((DocFileFragment.SimpleAdapter) SectionGridViewAdapterFiles.this.mBaseAdapter).refreshRecyclerView();
                    }
                }
            });
            return;
        }
        this.mBaseAdapter.onBindViewHolder(viewHolder, sectionedPositionToPosition(position));
    }

    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new SectionViewHolder(LayoutInflater.from(this.mContext).inflate(this.mSectionResourceId, viewGroup, false));
        }
        return this.mBaseAdapter.onCreateViewHolder(viewGroup, i - 1);
    }

    public int sectionedPositionToPosition(int i) {
        if (isSectionHeaderPosition(i)) {
            return -1;
        }
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.mSections.size() && ((Section) this.mSections.valueAt(i2)).c <= i) {
            i3--;
            i2++;
        }
        return i + i3;
    }

    public void setSections(Section[] sectionArr) {
        this.mSections.clear();
        Arrays.sort(sectionArr, new Comparator<Section>() {
            public int compare(Section section, Section section2) {
                int i = section.b;
                int i2 = section2.b;
                if (i == i2) {
                    return 0;
                }
                return i < i2 ? -1 : 1;
            }
        });
        int i = 0;
        for (Section section : sectionArr) {
            int i2 = section.b + i;
            section.c = i2;
            this.mSections.append(i2, section);
            i++;
        }
        notifyDataSetChanged();
    }
}
