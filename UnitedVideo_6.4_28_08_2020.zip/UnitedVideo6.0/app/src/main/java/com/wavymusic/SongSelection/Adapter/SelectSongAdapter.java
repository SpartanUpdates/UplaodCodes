package com.wavymusic.SongSelection.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.unity3d.player.UnityPlayer;
import com.wavymusic.App.MyApplication;
import com.wavymusic.AppUtils.Utils;
import com.wavymusic.R;
import com.wavymusic.RetrofitApiCall.AppConstant;
import com.wavymusic.SongSelection.DownloadSongFile.SongDownload;
import com.wavymusic.SongSelection.Fragment.SongByCatFragment;
import com.wavymusic.SongSelection.Model.SongModel;
import com.wavymusic.SongSelection.View.CircleImageView;
import com.wavymusic.SongSelection.View.DonutProgress;
import com.wavymusic.SongSelection.activity.SongSelectActivity;

import java.io.File;
import java.util.List;

public class SelectSongAdapter extends RecyclerView.Adapter<SelectSongAdapter.SongViewHolder> {

    SongByCatFragment songFragment;
    private List<SongModel> songList;
    private Context mContext;
    private SongSelectActivity ActivityOfSelectsong;

    public SelectSongAdapter(Context mContext, List<SongModel> songList, SongByCatFragment songFragment) {
        this.songList = songList;
        this.mContext = mContext;
        this.ActivityOfSelectsong = (SongSelectActivity) mContext;
        this.songFragment = songFragment;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_select_song, null);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SongViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final SongModel songModel = songList.get(position);
        holder.tvSongName.setText(songList.get(position).getSongName());
        holder.cbSong.setChecked(ActivityOfSelectsong.selectedSongPosition == position);
        if (!songList.get(position).isAvailableOffline) {
            if (songList.get(position).isDownloading) {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.GONE);
                holder.dpDownSong.setVisibility(View.VISIBLE);
            } else {
                holder.layoutUseSong.setVisibility(View.GONE);
                holder.ivDownload.setVisibility(View.VISIBLE);
                holder.dpDownSong.setVisibility(View.GONE);
            }
        } else {
            holder.layoutUseSong.setVisibility(View.VISIBLE);
            holder.ivDownload.setVisibility(View.GONE);
            holder.dpDownSong.setVisibility(View.GONE);
        }

        if (ActivityOfSelectsong.selectedSongPosition != position) {
            holder.cvThumb.setSelected(false);
            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
            holder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
            holder.cvThumb.setBackgroundResource(R.drawable.ic_song_select);
        } else {
            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
            holder.ivPlayPause.setImageResource(R.drawable.icon_player_pause_selected);
            holder.cvThumb.setBackgroundResource(R.drawable.ic_song_select_press);
            holder.cvThumb.setSelected(true);
        }


        holder.tvUseSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApplication.FinalSongPath = Utils.INSTANCE.getMusicFolderPath() + songList.get(position).getSongUrl();
                if (AppConstant.SongSelectAdCountWavy == 0) {
                    if (MyApplication.mInterstitialAdWavy != null && MyApplication.mInterstitialAdWavy.isLoaded()) {
                        ActivityOfSelectsong.stopPlaying(ActivityOfSelectsong.mediaPlayer);
                        MyApplication.AdsId = 5;
                        MyApplication.AdsShowContext = ActivityOfSelectsong;
                        MyApplication.mInterstitialAdWavy.show();
                    } else if (MyApplication.fbinterstitialAd != null && MyApplication.fbinterstitialAd.isAdLoaded()) {
                        ActivityOfSelectsong.stopPlaying(ActivityOfSelectsong.mediaPlayer);
                        MyApplication.AdsId = 5;
                        MyApplication.AdsShowContext = ActivityOfSelectsong;
                        MyApplication.fbinterstitialAd.show();
                    } else {
                        ActivityOfSelectsong.stopPlaying(ActivityOfSelectsong.mediaPlayer);
                        UnityPlayer.UnitySendMessage("WavyThemeData", "LoadMusic", MyApplication.FinalSongPath);
                        ((Activity) mContext).finish();
                    }
                } else {
                    ActivityOfSelectsong.stopPlaying(ActivityOfSelectsong.mediaPlayer);
                    UnityPlayer.UnitySendMessage("WavyThemeData", "LoadMusic", MyApplication.FinalSongPath);
                    AppConstant.SongSelectAdCountWavy = 0;
                    ((Activity) mContext).finish();
                }
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadSongFiles(position, holder.ivDownload, holder.dpDownSong, holder.layoutUseSong, holder.ivPlayPause, songModel, holder);
            }
//                DownloadSongFiles(position, holder.ivDownload, holder.dpDownSong, holder.layoutUseSong, holder.ivPalayPause, songModel);
        });
    }

    private void DownloadSongFiles(int position, ImageView ivDonload, DonutProgress dpSongProgress, LinearLayout layoutUseSong, ImageView ivplapause, SongModel songModel, SongViewHolder holder) {
        int UnitySoundSize = Integer.parseInt(songList.get(position).getSongSize());
        String SongName = songList.get(position).getSongUrl();
        File SongPath = new File(Utils.INSTANCE.getMusicFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        if (new File(Utils.INSTANCE.getMusicFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
                if (holder.cvThumb.isSelected()) {
                    ActivityOfSelectsong.SongPlayPause();
                    if (ActivityOfSelectsong.isSongPlay()) {
                        holder.ivPlayPause.setImageResource(R.drawable.icon_player_pause_selected);
                        holder.cvThumb.setImageResource(R.drawable.icon_song_thumb);
                    } else {
                        holder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
                        holder.cvThumb.setImageResource(R.drawable.icon_song_thumb);
                    }
                } else {
                    holder.cvThumb.setSelected(true);
                    if (ActivityOfSelectsong.SelectedTabPosition == songFragment.getTabIndex()) {
                        if (ActivityOfSelectsong.selectedSongPosition == position) {
                            holder.cvThumb.setSelected(true);
                            holder.tvUseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                            holder.ivPlayPause.setImageResource(R.drawable.icon_player_play);
                            holder.cvThumb.setImageResource(R.drawable.ic_song_select_press);
                            return;
                        }
                    }
                    ActivityOfSelectsong.SetSong(songList.get(position), position);
                    notifyDataSetChanged();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDonload.setVisibility(View.GONE);
                    dpSongProgress.setVisibility(View.VISIBLE);
                    new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, songModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDonload.setVisibility(View.GONE);
                dpSongProgress.setVisibility(View.VISIBLE);
                new SongDownload(mContext, songList.get(position).getSongfull_url(), songList.get(position).getSongUrl(), Integer.parseInt(songList.get(position).getSongSize()), ivDonload, dpSongProgress, layoutUseSong, songModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }

    public class SongViewHolder extends RecyclerView.ViewHolder {

        LinearLayout layoutMain;
        CircleImageView cvThumb;
        ImageView ivPlayPause;
        TextView tvSongName, tvSongTime;
        LinearLayout layoutUseSong;
        TextView tvUseSong;
        LinearLayout layoutDownSong;
        ImageView ivDownload;
        DonutProgress dpDownSong;
        CheckBox cbSong;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutMain = itemView.findViewById(R.id.image_layout);
            cvThumb = itemView.findViewById(R.id.image_content);
            ivPlayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            tvSongName = itemView.findViewById(R.id.tvMusicName);
            tvSongTime = itemView.findViewById(R.id.tvMusicEndTime);
            layoutUseSong = itemView.findViewById(R.id.llUseMusic);
            tvUseSong = itemView.findViewById(R.id.tvUseMusic);
            layoutDownSong = itemView.findViewById(R.id.ll_download);
            ivDownload = itemView.findViewById(R.id.iv_dowload);
            dpDownSong = itemView.findViewById(R.id.donut_progress);
            cbSong = itemView.findViewById(R.id.cb_music);
        }
    }
}
