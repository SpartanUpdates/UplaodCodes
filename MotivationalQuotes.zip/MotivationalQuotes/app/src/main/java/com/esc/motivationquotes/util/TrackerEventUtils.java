package com.esc.motivationquotes.util;

import com.esc.motivationquotes.Quotes;
import com.esc.motivationquotes.managers.SettingsManager;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class TrackerEventUtils {
    public static final String ACTION_ADD_WIDGET = "Add widget";
    public static final String ACTION_ADD_YOUR_OWN_VIEW = "Add Your Own View";
    public static final String ACTION_CATEGORIES_VIEW = "Categories View";
    public static final String ACTION_FAVORITED_OR_SHARED_MIXPANEL = "Favorited OR Shared";
    public static final String ACTION_FAVORITES_VIEW = "Favorites View";
    public static final String ACTION_FAVORITE_TOUCHED = "Favorite touched";
    public static final String ACTION_FAVORITE_TOUCHED_MIXPANEL = "Favorite Touched";
    public static final String ACTION_LAUNCHED_FROM_QUOTE_MIXPANEL = "Launched from quote";
    public static final String ACTION_LAUNCHED_FROM_REMINDER = "Launched from reminder";
    public static final String ACTION_LAUNCHED_FROM_WIDGET = "Launched from widget";
    public static final String ACTION_OPEN_14_DAY = "Opened after 14 days";
    public static final String ACTION_OPEN_1_DAY = "Opened after 1 day";
    public static final String ACTION_OPEN_1_DAY_MIXPANEL = "Opened after 1 days";
    public static final String ACTION_READ_QUOTE = "Read Quote";
    public static final String ACTION_REMOVE_WIDGET = "Remove widget";
    public static final String ACTION_SELECTED_CATEGORY = "Selected category";
    public static final String ACTION_SELECTED_CATEGORY_MIXPANEL = "Selected Category";
    public static final String ACTION_SELECTED_THEME = "Selected theme";
    public static final String ACTION_SELECTED_THEME_MIXPANEL = "Selected Theme";
    public static final String ACTION_SHARED_MIXPANEL = "Shared";
    public static final String ACTION_SHARE_TOUCHED = "Shared touched";
    public static final String ACTION_THEMES_VIEW = "Themes View";
    public static final String KEY_CATEGORY = "Category";
    public static final String KEY_FULL_QUOTE = "Full quote";
    public static final String KEY_QUOTE = "Quote";
    public static final String KEY_THEME = "Theme";

    public static void registerAction(String str, String str2, String str3) {
        Map hashMap = new HashMap();
        if (str2 != null) {
            hashMap.put(str2, str3);
        }
        try {
            new JSONObject().put(str2, str3);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (SettingsManager.getLanguage().equals("es")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(" - ");
            stringBuilder.append(SettingsManager.getLanguage());
            return;
        }
    }

    public static void registerActionMixpanel(String str, String str2, String str3, String str4) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(KEY_QUOTE, str2);
            jSONObject.put(KEY_CATEGORY, str3);
            jSONObject.put(KEY_THEME, str4);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
