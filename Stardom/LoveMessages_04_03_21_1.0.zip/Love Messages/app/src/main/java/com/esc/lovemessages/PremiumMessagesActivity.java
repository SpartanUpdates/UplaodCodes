package com.esc.lovemessages;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AlertDialog.Builder;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd.OnUnifiedNativeAdLoadedListener;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.OnCompleteListener;
import com.google.android.play.core.tasks.Task;
import com.ironsource.mediationsdk.IronSource;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class PremiumMessagesActivity extends AppCompatActivity {
    static Activity activity = null;
    public static Editor editor = null;
    public static String premiumKey = "premium";
    static int rewarded_position;
    public static int sh;
    public static SharedPreferences sharedPreferences;
    public static int sw;
    AdRequest adRequest;
    String appname = "";
    ArrayList<Integer> arrayListFavoriteMessages;
    DataBaseHelper baseHelper;
    int cat_id;
    String cat_name;
    TextView cattext;
    Context context;
    Dialog dialogR;
    public Typeface face1;
    public Typeface face2;
    File file;
    float imagescaling;
    private int lockedcount = 0;
    ReviewManager manager;
    String msgURL;
    ArrayList<String> msg_id;
    ArrayList<String> msgs;
    private PremiumAdapter premiumAdapter;
    String premium_url;
    private RecyclerView recyclerView;
    ReviewInfo reviewInfo;
    String trans;

    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;


    public class PremiumAdapter extends RecyclerView.Adapter<PremiumAdapter.ViewHolder> {
        public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
        Activity activity;
        Context context;
        DataBaseHelper db;
        private final ArrayList<Integer> favorite;
        private final LayoutInflater inflate = null;
        private final ArrayList<String> msg;
        String msgURL;
        private final ArrayList<String> msgid;
        int nu;
        File shfile;
        String stringCategoryName;
        String title;

        public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            TextView copyTextButton;
            ImageView imageViewFavorite;
            LinearLayout linear;
            RelativeLayout mainimg_lock;
            ImageView msgimg;
            RelativeLayout rel;
            RelativeLayout rel2;
            TextView saveImageButton;
            LinearLayout saveShareLinearLayout;
            TextView shareimage;
            TextView sharetxt;
            TextView txt;

            public ViewHolder(View view) {
                super(view);
                this.txt = view.findViewById(R.id.msg);
                this.msgimg = view.findViewById(R.id.msgimg);
                this.rel = view.findViewById(R.id.rel1);
                this.shareimage = view.findViewById(R.id.shareimage);
                this.sharetxt = view.findViewById(R.id.sharetxt);
                this.rel2 = view.findViewById(R.id.rel2);
                this.linear = view.findViewById(R.id.linear);
                this.imageViewFavorite = view.findViewById(R.id.imgfav);
                this.mainimg_lock = view.findViewById(R.id.myImage_lock);
                this.saveShareLinearLayout = view.findViewById(R.id.save_share_linearlayout);
                this.copyTextButton = view.findViewById(R.id.copy_text);
                this.saveImageButton = view.findViewById(R.id.save_image);
                this.txt.setTypeface(PremiumMessagesActivity.this.face2);
                this.shareimage.setTypeface(PremiumMessagesActivity.this.face1);
                this.sharetxt.setTypeface(PremiumMessagesActivity.this.face1);
                this.saveImageButton.setTypeface(PremiumMessagesActivity.this.face1);
                this.copyTextButton.setTypeface(PremiumMessagesActivity.this.face1);
                LayoutParams layoutParams;
                double d;
                if ((PremiumMessagesActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
                    this.txt.setTextSize(33.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(30.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.4d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(30.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(30.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(30.0f);
                } else if ((PremiumMessagesActivity.this.getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
                    this.txt.setTextSize(24.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(24.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.38d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(24.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(24.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(24.0f);
                } else {
                    this.txt.setTextSize(20.0f);
                    layoutParams = this.shareimage.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.shareimage.setTextSize(18.0f);
                    layoutParams = this.msgimg.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.35d);
                    layoutParams = this.sharetxt.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.sharetxt.setTextSize(18.0f);
                    layoutParams = this.saveImageButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.saveImageButton.setTextSize(18.0f);
                    layoutParams = this.copyTextButton.getLayoutParams();
                    d = MainActivity.height;
                    Double.isNaN(d);
                    layoutParams.height = (int) (d * 0.05d);
                    this.copyTextButton.setTextSize(18.0f);
                }
            }
        }

        public long getItemId(int i) {
            return i;
        }

        public PremiumAdapter(Context context, ArrayList<String> arrayList, ArrayList<String> arrayList2, Activity activity, String str, String str2, ArrayList<Integer> arrayList3) {
            this.activity = activity;
            this.context = context;
            this.msg = arrayList;
            this.msgid = arrayList2;
            this.msgURL = str;
            this.stringCategoryName = str2;
            this.favorite = arrayList3;
            this.db = new DataBaseHelper(this.context);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.msg.size());
            stringBuilder.append("");
            Log.e("msgs size", stringBuilder.toString());
        }

        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_premium_item, viewGroup, false));
        }

        public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
            String str = this.msg.get(i);
            Log.e("Messages", str);
            viewHolder.txt.setText(Html.fromHtml(str));
          /*  if (i % 2 == 0) {
                viewHolder.tail1.setVisibility(View.VISIBLE);
                viewHolder.tail2.setVisibility(View.INVISIBLE);
            } else {
                viewHolder.tail1.setVisibility(View.INVISIBLE);
                viewHolder.tail2.setVisibility(View.VISIBLE);
            }*/
            if (this.favorite.get(i).intValue() == 0) {
                viewHolder.imageViewFavorite.setImageResource(R.drawable.ic_favorite_border_white_24dp);
            } else {
                viewHolder.imageViewFavorite.setImageResource(R.drawable.ic_favorite_white_24dp);
            }
            this.nu = Integer.parseInt(this.msgid.get(i));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(PremiumMessagesActivity.this.premium_url);
            stringBuilder.append(this.nu);
            stringBuilder.append("-");
            stringBuilder.append(this.msgURL);
            stringBuilder.append(".jpg");
            str = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("url");
            stringBuilder2.append(str);
            ((RequestBuilder) Glide.with(this.context).load(str).placeholder(R.drawable.loading)).into(viewHolder.msgimg);
            if (PremiumMessagesActivity.this.cat_id == 659) {
                if ((i + 1) % 4 != 0) {
                    viewHolder.mainimg_lock.setVisibility(View.INVISIBLE);
                    viewHolder.rel.setClickable(true);
                    viewHolder.sharetxt.setClickable(true);
                    viewHolder.shareimage.setClickable(true);
                    viewHolder.copyTextButton.setClickable(true);
                    viewHolder.saveImageButton.setClickable(true);
                    viewHolder.msgimg.setClickable(true);
                } else {
                    SharedPreferences sharedPreferences = PremiumMessagesActivity.sharedPreferences;
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(PremiumMessagesActivity.premiumKey);
                    stringBuilder3.append(i);
                    if (sharedPreferences.getBoolean(stringBuilder3.toString(), false)) {
                        viewHolder.mainimg_lock.setVisibility(View.INVISIBLE);
                        viewHolder.rel.setClickable(true);
                        viewHolder.sharetxt.setClickable(true);
                        viewHolder.shareimage.setClickable(true);
                        viewHolder.copyTextButton.setClickable(true);
                        viewHolder.saveImageButton.setClickable(true);
                        viewHolder.msgimg.setClickable(true);
                    } else {
                        viewHolder.mainimg_lock.setVisibility(View.VISIBLE);
                        viewHolder.rel.setClickable(false);
                        viewHolder.sharetxt.setClickable(false);
                        viewHolder.shareimage.setClickable(false);
                        viewHolder.msgimg.setClickable(false);
                        viewHolder.copyTextButton.setClickable(false);
                        viewHolder.saveImageButton.setClickable(false);
                    }
                }
            }
            viewHolder.rel.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    CharSequence[] charSequenceArr = new CharSequence[]{"Copy Text"};
                    Builder builder = new Builder(PremiumMessagesActivity.this);
                    builder.setItems(charSequenceArr, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Context applicationContext = PremiumMessagesActivity.this.getApplicationContext();
                            PremiumMessagesActivity.this.getApplicationContext();
                            ((ClipboardManager) applicationContext.getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.label), Html.fromHtml(PremiumAdapter.this.msg.get(i))));
                            Toast.makeText(PremiumMessagesActivity.this.getApplicationContext().getApplicationContext(), PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
                            Map hashMap = new HashMap();
                            hashMap.put(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext), PremiumMessagesActivity.this.cat_name);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("");
                            stringBuilder.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext));
                            stringBuilder.append("  ");
                            stringBuilder.append(PremiumMessagesActivity.this.cat_name);
                        }
                    });
                    AlertDialog create = builder.create();
                    create.show();
                    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                    layoutParams.copyFrom(create.getWindow().getAttributes());
                    layoutParams.width = 500;
                    create.getWindow().setAttributes(layoutParams);
                }
            });
            viewHolder.sharetxt.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    String obj = Html.fromHtml(PremiumAdapter.this.msg.get(i)).toString();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(obj);
                    stringBuilder.append("\n");
                    StringBuilder stringBuilder2 = new StringBuilder();
                    String str = "<br>";
                    stringBuilder2.append(str);
                    stringBuilder2.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                    stringBuilder2.append(str);
                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                    obj = stringBuilder.toString();
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", PremiumMessagesActivity.this.appname);
                    intent.putExtra("android.intent.extra.TEXT", obj);
                    PremiumMessagesActivity.this.startActivity(Intent.createChooser(intent, PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                    Map hashMap = new HashMap();
                    hashMap.put(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharetext), PremiumMessagesActivity.this.cat_name);
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("");
                    stringBuilder2.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharetext));
                    stringBuilder2.append("  ");
                    stringBuilder2.append(PremiumMessagesActivity.this.cat_name);
                    Log.e("Flurry", stringBuilder2.toString());
                    PremiumMessagesActivity.this.AddRateClicks();
                }
            });
            viewHolder.copyTextButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Context applicationContext = PremiumMessagesActivity.this.getApplicationContext();
                    PremiumMessagesActivity.this.getApplicationContext();
                    ClipboardManager clipboardManager = (ClipboardManager) applicationContext.getSystemService(CLIPBOARD_SERVICE);
                    String string = PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.label);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(PremiumAdapter.this.msg.get(i));
                    StringBuilder stringBuilder2 = new StringBuilder();
                    String str = "<br>";
                    stringBuilder2.append(str);
                    stringBuilder2.append(PremiumAdapter.this.context.getResources().getString(R.string.fromshare));
                    stringBuilder2.append(str);
                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                    stringBuilder.append(Html.fromHtml(stringBuilder2.toString()));
                    clipboardManager.setPrimaryClip(ClipData.newPlainText(string, stringBuilder.toString()));
                    Toast.makeText(PremiumMessagesActivity.this.getApplicationContext().getApplicationContext(), PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.ClipboardCopied), Toast.LENGTH_LONG).show();
                    Map hashMap = new HashMap();
                    hashMap.put(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext), PremiumMessagesActivity.this.cat_name);
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("");
                    stringBuilder3.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.copytext));
                    stringBuilder3.append("  ");
                    stringBuilder3.append(PremiumMessagesActivity.this.cat_name);
                }
            });
            viewHolder.imageViewFavorite.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Map hashMap = new HashMap();
                    hashMap.put("Subcategory", PremiumAdapter.this.stringCategoryName);
                    hashMap.put("MessageId", PremiumAdapter.this.msgid.get(i));
                    String str = "Favorite";
                    if (PremiumAdapter.this.favorite.get(i).intValue() == 0) {
                        viewHolder.imageViewFavorite.setImageResource(R.drawable.ic_favorite_white_24dp);
                        PremiumAdapter.this.db.updateFavorite(1, Integer.parseInt(PremiumAdapter.this.msgid.get(i)));
                        viewHolder.imageViewFavorite.invalidate();
                        PremiumAdapter.this.favorite.set(i, Integer.valueOf(1));
                        String str2 = "Marked";
                        hashMap.put(str, str2);
                        hashMap.put(str2, PremiumAdapter.this.msgid.get(i));
                    } else if (PremiumAdapter.this.favorite.get(i).intValue() == 1) {
                        viewHolder.imageViewFavorite.setImageResource(R.drawable.ic_favorite_border_white_24dp);
                        PremiumAdapter.this.db.updateFavorite(0, Integer.parseInt(PremiumAdapter.this.msgid.get(i)));
                        viewHolder.imageViewFavorite.invalidate();
                        PremiumAdapter.this.favorite.set(i, Integer.valueOf(0));
                        hashMap.put(str, "UnMarked");
                        hashMap.put("Unmarked", PremiumAdapter.this.msgid.get(i));
                    }
                }
            });
            viewHolder.saveImageButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(PremiumAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(PremiumAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        PremiumAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    PremiumAdapter premiumAdapter = PremiumAdapter.this;
                    premiumAdapter.nu = Integer.parseInt(premiumAdapter.msgid.get(i));
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(PremiumMessagesActivity.this.premium_url);
                    stringBuilder.append(PremiumAdapter.this.nu);
                    stringBuilder.append("-");
                    stringBuilder.append(PremiumAdapter.this.msgURL);
                    stringBuilder.append(".jpg");
                    final String stringBuilder2 = stringBuilder.toString();
                    try {
                        if (PremiumMessagesActivity.this.isNetworkAvailable()) {
                            Glide.with(PremiumMessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder2).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    PremiumMessagesActivity.this.saveImage(bitmap, Integer.parseInt(PremiumAdapter.this.msgid.get(i)));
                                }
                            });
                        } else {
                            Builder builder = new Builder(PremiumMessagesActivity.this);
                            builder.setTitle(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                            builder.setMessage(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.error));
                            builder.setCancelable(false).setPositiveButton(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, final int i) {
                                    if (PremiumMessagesActivity.this.isNetworkAvailable()) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("/////////   ");
                                        stringBuilder.append(stringBuilder2);
                                        Glide.with(PremiumMessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder2).into(new SimpleTarget<Bitmap>() {
                                            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                                PremiumMessagesActivity.this.saveImage(bitmap, Integer.parseInt(PremiumAdapter.this.msgid.get(i)));
                                            }
                                        });
                                        return;
                                    }
                                    Toast.makeText(PremiumMessagesActivity.this, PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                                }
                            }).setNegativeButton(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                }
                            });
                            builder.create().show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    PremiumMessagesActivity.this.AddRateClicks();
                }
            });
            viewHolder.shareimage.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    if (ContextCompat.checkSelfPermission(PremiumAdapter.this.context, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                        Toast.makeText(PremiumAdapter.this.context, "Provide Storage Permission To Share Image ", Toast.LENGTH_LONG).show();
                        PremiumAdapter.this.checkAndRequestPermissions();
                        return;
                    }
                    PremiumMessagesActivity.this.AddRateClicks();
                    PremiumAdapter premiumAdapter = PremiumAdapter.this;
                    premiumAdapter.nu = Integer.parseInt(premiumAdapter.msgid.get(i));
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(PremiumMessagesActivity.this.premium_url);
                    stringBuilder.append(PremiumAdapter.this.nu);
                    stringBuilder.append("-");
                    stringBuilder.append(PremiumAdapter.this.msgURL);
                    stringBuilder.append(".jpg");
                    final String stringBuilder2 = stringBuilder.toString();
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(" ");
                    stringBuilder3.append(stringBuilder2);
                    Log.e("URL", stringBuilder3.toString());
                    if (PremiumMessagesActivity.this.isNetworkAvailable()) {
                        try {
                            Glide.with(PremiumMessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder2).into(new SimpleTarget<Bitmap>() {
                                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                    File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                    PremiumAdapter premiumAdapter = PremiumAdapter.this;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append(PremiumAdapter.this.nu);
                                    stringBuilder.append(".jpg");
                                    premiumAdapter.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                    try {
                                        FileOutputStream fileOutputStream = new FileOutputStream(PremiumAdapter.this.shfile);
                                        bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                        try {
                                            fileOutputStream.flush();
                                            fileOutputStream.close();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    } catch (FileNotFoundException e2) {
                                        e2.printStackTrace();
                                        Toast.makeText(PremiumAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                    }
                                    StringBuilder stringBuilder2 = new StringBuilder();
                                    String str = "\n";
                                    stringBuilder2.append(str);
                                    stringBuilder2.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                    stringBuilder2.append(str);
                                    stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                    String stringBuilder3 = stringBuilder2.toString();
                                    Uri uriForFile = FileProvider.getUriForFile(PremiumMessagesActivity.this, activity.getPackageName() + ".provider", PremiumAdapter.this.shfile);
                                    Intent intent = new Intent();
                                    intent.setAction("android.intent.action.SEND");
                                    intent.setType("image/*");
                                    intent.putExtra("android.intent.extra.SUBJECT", PremiumMessagesActivity.this.appname);
                                    intent.putExtra("android.intent.extra.TEXT", stringBuilder3);
                                    intent.putExtra("android.intent.extra.STREAM", uriForFile);
                                    PremiumMessagesActivity.this.startActivity(Intent.createChooser(intent, PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                                    Map hashMap = new HashMap();
                                    hashMap.put(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.shareimage), PremiumMessagesActivity.this.cat_name);
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("");
                                    stringBuilder2.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.shareimage));
                                    stringBuilder2.append("  ");
                                    stringBuilder2.append(PremiumMessagesActivity.this.cat_name);
                                }
                            });
                            return;
                        } catch (Exception e) {
                            e.printStackTrace();
                            return;
                        }
                    }
                    Builder builder = new Builder(PremiumMessagesActivity.this);
                    builder.setTitle(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.errror));
                    builder.setMessage(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.error));
                    builder.setCancelable(false).setPositiveButton(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.retry), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, final int i) {
                            if (PremiumMessagesActivity.this.isNetworkAvailable()) {
                                try {
                                    Glide.with(PremiumMessagesActivity.this.getApplicationContext()).asBitmap().load(stringBuilder2).into(new SimpleTarget<Bitmap>() {
                                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                                            File externalStorageDirectory = Environment.getExternalStorageDirectory();
                                            PremiumAdapter premiumAdapter = PremiumAdapter.this;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append(PremiumAdapter.this.msgid.get(i));
                                            stringBuilder.append(".jpg");
                                            premiumAdapter.shfile = new File(externalStorageDirectory, stringBuilder.toString());
                                            try {
                                                FileOutputStream fileOutputStream = new FileOutputStream(PremiumAdapter.this.shfile);
                                                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                                                try {
                                                    fileOutputStream.flush();
                                                    fileOutputStream.close();
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }
                                            } catch (FileNotFoundException e2) {
                                                e2.printStackTrace();
                                                Toast.makeText(PremiumAdapter.this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
                                            }
                                            StringBuilder stringBuilder2 = new StringBuilder();
                                            String str = "\n";
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.fromshare));
                                            stringBuilder2.append(str);
                                            stringBuilder2.append("https://play.google.com/store/apps/details?id=" + getPackageName());
                                            String stringBuilder3 = stringBuilder2.toString();
                                            Uri uriForFile = FileProvider.getUriForFile(PremiumMessagesActivity.this, activity.getPackageName() + ".provider", PremiumAdapter.this.shfile);
                                            Intent intent = new Intent();
                                            intent.setAction("android.intent.action.SEND");
                                            intent.setType("image/*");
                                            intent.putExtra("android.intent.extra.SUBJECT", PremiumMessagesActivity.this.appname);
                                            String str2 = "android.intent.extra.STREAM";
                                            intent.putExtra(str2, stringBuilder3);
                                            intent.putExtra(str2, uriForFile);
                                            PremiumMessagesActivity.this.startActivity(Intent.createChooser(intent, PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.sharevia)));
                                        }
                                    });
                                    return;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    return;
                                }
                            }
                            Toast.makeText(PremiumMessagesActivity.this, PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.error), Toast.LENGTH_SHORT).show();
                        }
                    }).setNegativeButton(PremiumMessagesActivity.this.getApplicationContext().getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    builder.create().show();
                }
            });
        }

        private boolean checkAndRequestPermissions() {
            String str = "android.permission.WRITE_EXTERNAL_STORAGE";
            int checkSelfPermission = ContextCompat.checkSelfPermission(this.context, str);
            ArrayList arrayList = new ArrayList();
            if (checkSelfPermission != 0) {
                arrayList.add(str);
            }
            if (arrayList.isEmpty()) {
                return true;
            }
            ActivityCompat.requestPermissions(this.activity, (String[]) arrayList.toArray(new String[arrayList.size()]), 1);
            return false;
        }

        public int getItemCount() {
            return PremiumMessagesActivity.this.msgs.size();
        }
    }


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_messages);
        this.context = this;
        activity = this;
        this.trans = Locale.getDefault().getLanguage();
        this.baseHelper = new DataBaseHelper(getApplicationContext());
        this.appname = getResources().getString(R.string.appname);
        sharedPreferences = getSharedPreferences("MYPREFERENCE", 0);
        editor = sharedPreferences.edit();
        String str = "inappreview";
        editor.putInt(str, sharedPreferences.getInt(str, 0) + 1).apply();
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview1(getApplicationContext());
        }
        this.msg_id = new ArrayList();
        this.msgs = new ArrayList();
        this.arrayListFavoriteMessages = new ArrayList();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            this.cat_id = ((Integer) extras.get("cat_id")).intValue();
            this.cat_name = (String) extras.get("cat_name");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("cat_id =");
            stringBuilder.append(this.cat_id);
            stringBuilder.append("cat_name ");
            stringBuilder.append(this.cat_name);
        }
        this.msgs = this.baseHelper.getPremiumMessages(this.cat_id);
        this.msg_id = this.baseHelper.getPremiumMessagesid(this.cat_id);
        this.msgURL = this.baseHelper.getPremiumMessagesURL(this.cat_id);
        this.arrayListFavoriteMessages = this.baseHelper.getPremiumMessagesFavorite(this.cat_id);
        this.premium_url = "https://www.wishafriend.com/love/uploads/";
        if (this.cat_id == 659) {
            int i = 0;
            while (i < this.msg_id.size()) {
                int i2 = i + 1;
                String str2 = "onCreate : UnLocked Position ";
                StringBuilder stringBuilder2;
                StringBuilder stringBuilder3;
                if (i2 % 4 != 0) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(premiumKey);
                    stringBuilder2.append(i);
                    editor.putBoolean(stringBuilder2.toString(), true);
                    editor.commit();
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(str2);
                    stringBuilder3.append(i);
                } else {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(premiumKey);
                    stringBuilder2.append(i);
                    if (!sharedPreferences.getBoolean(stringBuilder2.toString(), false)) {
                        this.lockedcount++;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(str2);
                        stringBuilder3.append(i);
                    }
                }
                i = i2;
            }
        }
        this.face1 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Bold.ttf");
        this.face2 = Typeface.createFromAsset(getAssets(), "fonts/CormorantGaramond-Regular.ttf");
        this.cattext = findViewById(R.id.categorytext);
        this.cattext.setTypeface(this.face1);
        this.cattext.setText(this.cat_name);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("");
        View inflate = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.action_bar_title, null);
        getSupportActionBar().setCustomView(inflate);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        TextView textView = inflate.findViewById(R.id.action_bar_title);
        textView.setText(getResources().getString(R.string.appname));
        textView.setTypeface(this.face1);
        BannerAds();
        if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
        } else if ((getApplicationContext().getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(30.0f);
        } else {
            textView.setTextSize(20.0f);
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        sw = displayMetrics.widthPixels;
        sh = displayMetrics.heightPixels;
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            this.imagescaling = 0.5f;
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            this.imagescaling = 0.42f;
        } else {
            this.imagescaling = 0.38f;
        }
        this.recyclerView = findViewById(R.id.recylerview);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.premiumAdapter = new PremiumAdapter(this, this.msgs, this.msg_id, activity, this.msgURL, this.cat_name, this.arrayListFavoriteMessages);
        this.recyclerView.setAdapter(this.premiumAdapter);
    }


    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.banner_ad_unit_id));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveImage(Bitmap bitmap, int i) {
        try {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i);
            stringBuilder.append(".jpg");
            File file = new File(externalStorageDirectory, stringBuilder.toString());
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                bitmap.compress(CompressFormat.JPEG, 100, fileOutputStream);
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.ImageSave), Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
                Toast.makeText(this.context, "Go to settings and allow storage permission for this app \"Love Messages for Wife\"", Toast.LENGTH_LONG).show();
            }
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(file));
            sendBroadcast(intent);
            Map hashMap = new HashMap();
            hashMap.put(getApplicationContext().getResources().getString(R.string.saveimage), this.cat_name);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(getApplicationContext().getResources().getString(R.string.saveimage));
            stringBuilder2.append("  ");
            stringBuilder2.append(this.cat_name);
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
        } else if (itemId == R.id.favmenu) {
            Intent intent = new Intent(this, FavoriteActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public void onResume() {
        super.onResume();
        this.premiumAdapter.notifyDataSetChanged();
    }


    public void RateAndReview1(Context context) {
        this.manager = ReviewManagerFactory.create(context);
        this.manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener<ReviewInfo>() {
            public void onComplete(Task<ReviewInfo> task) {
                String str = "inapp reivew";
                if (task.isSuccessful()) {
                    PremiumMessagesActivity.this.reviewInfo = task.getResult();
                    Log.e(str, "In-app REVIEW SUCCESSFUL");
                    return;
                }
                Log.e(str, "In-app REVIEW ERROR or FAILED or LIMIT COMPLETED");
            }
        });
    }

    public void RateAndReview() {
        String str = "inapp reivew";
        String str2 = "inappreview";
        if (sharedPreferences.getInt(str2, 0) > 6) {
            editor.putInt(str2, 1).apply();
        }
        try {
            if (this.manager != null) {
                if (this.reviewInfo != null) {
                    this.manager.launchReviewFlow(this, this.reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(Task<Void> task) { PremiumMessagesActivity.this.finish();
                        }
                    });
                    return;
                }
            }
            RATE_DIALOG();
        } catch (Exception unused) {
            RATE_DIALOG();
        }
    }

    public void onBackPressed() {
        String str = "inappreview";
        if (sharedPreferences.getInt(str, 0) > 6 || sharedPreferences.getInt(str, 0) == 1) {
            RateAndReview();
            return;
        }
        String str2 = "rateagain";
        if (sharedPreferences.getInt(str2, 0) > 12 || sharedPreferences.getInt("applaunched", 0) == 0) {
            editor.putInt(str2, 0);
            editor.commit();
            RATE_DIALOG();
            return;
        }
        MainActivity.check_paused = true;
        super.onBackPressed();
    }


    public void AddRateClicks() {
        String str = "rateagain";
        if (sharedPreferences.getInt(str, 0) < 13) {
            int i = sharedPreferences.getInt(str, 0) + 1;
            editor.putInt(str, i);
            editor.commit();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(i);
        }
    }

    private void RATE_DIALOG() {
        View inflate = View.inflate(this, R.layout.rateus_dialog, null);
        this.dialogR = new Dialog(this);
        Dialog dialog = this.dialogR;
        dialog.getWindow();
        dialog.requestWindowFeature(1);
        this.dialogR.setContentView(inflate);
        this.dialogR.setCancelable(false);
        TextView textView = this.dialogR.findViewById(R.id.ratedailog_text);
        textView.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        textView.setText(getResources().getString(R.string.rate_us));
        Button button = this.dialogR.findViewById(R.id.btn_yes);
        Button button2 = this.dialogR.findViewById(R.id.btn_later);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Yes I will Clicked");
                PremiumMessagesActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                PremiumMessagesActivity.this.finish();
                PremiumMessagesActivity.this.dialogR.cancel();
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Map hashMap = new HashMap();
                String str = "Rate";
                hashMap.put(str, "Rate Later Clicked");
                MainActivity.check_paused = true;
                PremiumMessagesActivity.this.finish();
                PremiumMessagesActivity.this.dialogR.cancel();
            }
        });
        if ((getResources().getConfiguration().screenLayout & 15) == 4) {
            textView.setTextSize(32.0f);
            button.setTextSize(30.0f);
            button2.setTextSize(30.0f);
        } else if ((getResources().getConfiguration().screenLayout & 15) == 3) {
            textView.setTextSize(28.0f);
            button.setTextSize(26.0f);
            button2.setTextSize(26.0f);
        } else {
            textView.setTextSize(20.0f);
            button.setTextSize(18.0f);
            button2.setTextSize(18.0f);
        }
        if (!isFinishing()) {
            this.dialogR.show();
        }
    }
}
