package com.esc.flashlight.database;

import static android.os.Build.ID;

public interface IDBFilteredPackageName {
    public static final int COLUMN_FILTERED_PACKAGE_NAME = 1;
    public static final int COLUMN_ID = 0;
    public static final String DB_NAME = "filtered_packages.db";
    public static final String DB_TABLE = "filtered_packages";
    public static final int DB_VERSION = 1;
    public static final String FILTERED_PACKAGE_NAME = "filtered_package_name";
    public static final String[] QUERY_COLUMNS_FILTERED_APPLICATION = new String[]{ID, FILTERED_PACKAGE_NAME};
    public static final String SQL_DB_CREATE = "create table filtered_packages (_id integer primary key autoincrement, filtered_package_name text not null)";
    public static final String _ID = "_id";
}
