package com.claptoflashlightonoff.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import com.example.speaktourchtight.R;

public class MyWidgetProvider extends AppWidgetProvider {
  public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
    Intent receiver = new Intent(context, MyWidgetIntentReceiver.class);
    receiver.setAction("FLASHLIGHT");
    receiver.putExtra("appWidgetIds", appWidgetIds);
    PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, receiver, 0);
    RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget);
    views.setOnClickPendingIntent(R.id.ivWidget, pendingIntent);
    appWidgetManager.updateAppWidget(appWidgetIds, views);
  }
}
