package api.natsuite.natcorder;

import api.natsuite.natcorder.utility.*;

import android.os.*;
import android.util.*;

import java.io.*;

import android.view.*;
import android.media.*;
import android.opengl.*;

import java.nio.*;

import api.natsuite.natrender.*;

public class HEVCRecorder implements MediaRecorder {
    private final int width;
    private final int height;
    private final MediaCodec videoCodec;
    private final MediaCodec audioCodec;
    private final GLRenderContext renderContext;
    private final HandlerThread audioQueueThread;
    private MediaWriter mediaWriter;
    private Handler renderContextHandler;
    private Handler audioQueueHandler;
    private GLBlitEncoder blitEncoder;
    private int frameTexture;
    private final Runnable videoCodecFlusher;
    private final Runnable audioCodecFlusher;

    public int setVideoBitRateInKBytes(int bitRate) {
        if ((double) (this.width * this.height * 30 * 2) * 7.0E-5D < (double) bitRate) {
            bitRate = (int) ((double) (this.width * this.height * 30 * 2) * 7.0E-5D);
        }
        int a = bitRate * 1024;
        return a;
    }

    public HEVCRecorder(final int width, final int height, final float framerate, final int bitrate, final int keyframeInterval, int sampleRate, int channelCount) {
        this.audioQueueThread = new HandlerThread("HEVCRecorder Audio Thread");
        this.videoCodecFlusher = new Runnable() {
            @Override
            public void run() {
                final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                while (true) {
                    try {
                        Thread.sleep(2L);
                    } catch (InterruptedException ex) {
                    }
                    final int bufferIndex = HEVCRecorder.this.videoCodec.dequeueOutputBuffer(bufferInfo, -1L);
                    if (bufferIndex < 0) {
                        continue;
                    }
                    final MediaFormat format = HEVCRecorder.this.videoCodec.getOutputFormat();
                    final ByteBuffer buffer = HEVCRecorder.this.videoCodec.getOutputBuffer(bufferIndex);
                    HEVCRecorder.this.mediaWriter.appendVideoFrame(format, buffer, bufferInfo);
                    HEVCRecorder.this.videoCodec.releaseOutputBuffer(bufferIndex, false);
                    if ((bufferInfo.flags & 0x4) != 0x0) {
                        break;
                    }
                }
                Log.v("Unity", "NatCorder: HEVC video encoder encountered EOS");
                HEVCRecorder.this.videoCodec.stop();
                HEVCRecorder.this.videoCodec.release();
                HEVCRecorder.this.mediaWriter.finishWriting();
            }
        };
        this.audioCodecFlusher = new Runnable() {
            @Override
            public void run() {
                final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                long lastAudioBufferTimestamp = 0L;
                while (true) {
                    try {
                        Thread.sleep(2L);
                    } catch (InterruptedException ex) {
                    }
                    final int bufferIndex = HEVCRecorder.this.audioCodec.dequeueOutputBuffer(bufferInfo, -1L);
                    if (bufferIndex < 0) {
                        continue;
                    }
                    while (bufferInfo.presentationTimeUs < lastAudioBufferTimestamp) {
                        final MediaCodec.BufferInfo bufferInfo2 = bufferInfo;
                        bufferInfo2.presentationTimeUs += 23219L;
                    }
                    lastAudioBufferTimestamp = bufferInfo.presentationTimeUs;
                    final MediaFormat format = HEVCRecorder.this.audioCodec.getOutputFormat();
                    final ByteBuffer buffer = HEVCRecorder.this.audioCodec.getOutputBuffer(bufferIndex);
                    HEVCRecorder.this.mediaWriter.appendAudioFrame(format, buffer, bufferInfo);
                    HEVCRecorder.this.audioCodec.releaseOutputBuffer(bufferIndex, false);
                    if ((bufferInfo.flags & 0x4) != 0x0) {
                        break;
                    }
                }
                Log.v("Unity", "NatCorder: HEVC audio encoder encountered EOS");
                HEVCRecorder.this.audioCodec.stop();
                HEVCRecorder.this.audioCodec.release();
                HEVCRecorder.this.mediaWriter.finishWriting();
            }
        };
        MediaCodec videoCodec = null;
        this.width = width;
        this.height = height;
        final MediaFormat videoFormat = MediaFormat.createVideoFormat("video/hevc", width, height);
        videoFormat.setInteger("color-format", 2130708361);
//        videoFormat.setInteger("bitrate", bitrate);
        Log.e("Bitrate", "" + setVideoBitRateInKBytes(4000));
        Log.e("Width", "" + width);
        Log.e("Height", "" + height);
        Log.e("framerate", "" + framerate);
        Log.e("bitrate unity", "" + bitrate);
        Log.e("keyInterval", "" + keyframeInterval);
        videoFormat.setInteger("bitrate", (1000 * 1024));
        videoFormat.setFloat("frame-rate", 24);
        videoFormat.setInteger("i-frame-interval", 1);
        Log.v("Unity", "NatCorder: Preparing HEVC video encoder with format: " + videoFormat);
        try {
            videoCodec = MediaCodec.createEncoderByType("video/hevc");
        } catch (IOException ex) {
        }
        videoCodec.configure(videoFormat, (Surface) null, (MediaCrypto) null, 1);
        MediaCodec audioCodec = null;
        sampleRate = 48000;
        channelCount = 2;
        if (sampleRate != 0 || channelCount != 0) {
            final MediaFormat audioFormat = MediaFormat.createAudioFormat("audio/mp4a-latm", sampleRate, channelCount);
            audioFormat.setInteger("aac-profile", 2);
            audioFormat.setInteger("channel-mask", (channelCount == 2) ? 12 : 16);
            audioFormat.setInteger("bitrate", 64000);
            audioFormat.setInteger("channel-count", channelCount);
            audioFormat.setInteger("max-input-size", 16384);
            Log.v("Unity", "NatCorder: Preparing HEVC audio encoder with format: " + audioFormat);
            try {
                audioCodec = MediaCodec.createEncoderByType("audio/mp4a-latm");
            } catch (IOException ex2) {
            }
            audioCodec.configure(audioFormat, (Surface) null, (MediaCrypto) null, 1);
        }
        this.videoCodec = videoCodec;
        this.renderContext = new GLRenderContext((EGLContext) null, videoCodec.createInputSurface(), true);
        this.audioCodec = audioCodec;
    }

    @Override
    public void startRecording(final String recordingPath, final Callback completionHandler) {
        try {
            this.mediaWriter = new MediaWriter(recordingPath, (this.audioCodec != null) ? 2 : 1, completionHandler);
        } catch (IOException ex) {
            Log.e("Unity", "NatCorder Error: Failed to create HEVC writer with error: " + ex.getLocalizedMessage());
            this.videoCodec.release();
            if (this.audioCodec != null) {
                this.audioCodec.release();
            }
            return;
        }
        this.videoCodec.start();
        if (this.audioCodec != null) {
            this.audioCodec.start();
            this.audioQueueThread.start();
            this.audioQueueHandler = new Handler(this.audioQueueThread.getLooper());
        }
        this.renderContext.start();
        (this.renderContextHandler = new Handler(this.renderContext.getLooper())).post((Runnable) new Runnable() {
            @Override
            public void run() {
                HEVCRecorder.this.blitEncoder = GLBlitEncoder.blitEncoder();
                HEVCRecorder.this.frameTexture = GLBlitEncoder.getTexture();
                GLES20.glTexImage2D(3553, 0, 6408, HEVCRecorder.this.width, HEVCRecorder.this.height, 0, 6408, 5121, (Buffer) null);
            }
        });
        new Thread(this.videoCodecFlusher, "HEVCRecorder Video Encoding Thread").start();
        if (this.audioCodec != null) {
            new Thread(this.audioCodecFlusher, "HEVCRecorder Audio Encoding Thread").start();
        }
    }

    @Override
    public synchronized void stopRecording() {
        if (this.renderContextHandler == null) {
            Log.e("Unity", "NatCorder Error: HEVCRecorder cannot stop recording because recording was never started");
            return;
        }
        if (this.audioQueueHandler != null) {
            this.audioQueueHandler.post((Runnable) new Runnable() {
                @Override
                public void run() {
                    final int bufferIndex = HEVCRecorder.this.audioCodec.dequeueInputBuffer(-1L);
                    HEVCRecorder.this.audioCodec.queueInputBuffer(bufferIndex, 0, 0, 0L, 4);
                }
            });
            this.audioQueueThread.quitSafely();
        }
        this.renderContextHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                HEVCRecorder.this.blitEncoder.release();
                HEVCRecorder.this.renderContext.getSurface().release();
                GLBlitEncoder.releaseTexture(HEVCRecorder.this.frameTexture);
                HEVCRecorder.this.videoCodec.signalEndOfInputStream();
            }
        });
        this.renderContext.quitSafely();
    }

    @Override
    public synchronized void encodeFrame(final ByteBuffer pixelBuffer, final long timestamp) {
        final byte[] pixelData = new byte[this.width * this.height * 4];
        pixelBuffer.get(pixelData);
        this.renderContextHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                GLES20.glBindTexture(3553, HEVCRecorder.this.frameTexture);
                GLES20.glTexSubImage2D(3553, 0, 0, 0, HEVCRecorder.this.width, HEVCRecorder.this.height, 6408, 5121, (Buffer) ByteBuffer.wrap(pixelData));
                HEVCRecorder.this.blitEncoder.blit(HEVCRecorder.this.frameTexture);
                HEVCRecorder.this.renderContext.setPresentationTime(timestamp);
                HEVCRecorder.this.renderContext.swapBuffers();
            }
        });
    }

    @Override
    public synchronized void encodeFrame(final long nativeBuffer, final long timestamp) {
        this.encodeFrame(Unmanaged.wrapBuffer(nativeBuffer, (long) (this.width * this.height * 4)), timestamp);
    }

    @Override
    public synchronized void encodeSamples(final float[] samples, final long timestamp) {
        this.audioQueueHandler.post((Runnable) new Runnable() {
            @Override
            public void run() {
                final short[] sampleBuffer = new short[samples.length];
                for (int i = 0; i < samples.length; ++i) {
                    sampleBuffer[i] = (short) (samples[i] * 32767.0f);
                }
                final int bufferIndex = HEVCRecorder.this.audioCodec.dequeueInputBuffer(-1L);
                final ByteBuffer buffer = HEVCRecorder.this.audioCodec.getInputBuffer(bufferIndex);
                buffer.asShortBuffer().put(sampleBuffer);
                HEVCRecorder.this.audioCodec.queueInputBuffer(bufferIndex, 0, sampleBuffer.length * 2, timestamp / 1000L, 0);
            }
        });
    }
}
