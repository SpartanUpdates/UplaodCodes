package com.example.postermaker.editorsclasses.designitems;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.example.postermaker.R;
import com.example.postermaker.eaz_ConstantValues;
import com.example.postermaker.eaz_EditActivity;
import com.example.postermaker.utilities.eaz_GradientDrawable;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar.OnProgressChangeListener;

public class eaz_BackgroundColor implements OnClickListener, OnProgressChangeListener {
    int[] allcolors;
    Context context;

    public void onStartTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public void onStopTrackingTouch(DiscreteSeekBar discreteSeekBar) {
    }

    public eaz_BackgroundColor(Context context) {
        this.context = context;
    }

    public void loadBackgroundColors() {
        this.allcolors = this.context.getResources().getIntArray(R.array.allcolors);
        eaz_EditActivity.backgroundcolorlayout.setVisibility(View.VISIBLE);
        eaz_EditActivity.ok.setOnClickListener(this);
        eaz_EditActivity.cancel.setOnClickListener(this);
        eaz_EditActivity.backgroundbirghtness.setOnProgressChangeListener(this);
        loadColors();
    }

    public void loadColors() {
        eaz_EditActivity.backgroundcolorcontainer.removeAllViews();
        for (int i = 0; i < this.allcolors.length; i++) {
            ImageView imageView = new ImageView(this.context);
            circularImageView(imageView, this.allcolors[i]);
            int finalI = i;
            eaz_ConstantValues.backgroundcolor = eaz_BackgroundColor.this.allcolors[0];
            new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    eaz_ConstantValues.backgroundcolor = eaz_BackgroundColor.this.allcolors[finalI];
                    new eaz_GradientDrawable().manageShape(eaz_ConstantValues.backgroundcolor, eaz_ConstantValues.bordercolor, eaz_ConstantValues.bordersize, eaz_ConstantValues.borderspace, eaz_ConstantValues.radious);
                }
            });
            eaz_EditActivity.backgroundcolorcontainer.addView(imageView);
        }
    }

    public void circularImageView(ImageView imageView, int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.OVAL);
        gradientDrawable.setColor(i);
        imageView.setBackground(gradientDrawable);

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(
                ViewGroup.MarginLayoutParams.MATCH_PARENT,
                ViewGroup.MarginLayoutParams.WRAP_CONTENT
        );
        marginLayoutParams.setMargins(5, 5, 5, 5);
         imageView.setPadding(40, 40, 40, 40);
        imageView.setLayoutParams(marginLayoutParams);
        //imageView.setLayoutParams(new LayoutParams(45, 45));
    }

    public void onClick(View view) {
        if (view.equals(eaz_EditActivity.ok)) {
            eaz_EditActivity.backgroundcolorlayout.setVisibility(View.GONE);
        } else if (view.equals(eaz_EditActivity.cancel)) {
            if (eaz_ConstantValues.bgchoice == 1) {
                eaz_EditActivity.backgroundlayout.setBackgroundColor(0);
            } else if (eaz_ConstantValues.bgchoice == 2) {
                eaz_EditActivity.foregroundlayout.setBackgroundColor(0);
            }
            eaz_EditActivity.backgroundcolorlayout.setVisibility(View.GONE);
        }
    }

    public void onProgressChanged(DiscreteSeekBar discreteSeekBar, int i, boolean z) {
        if (eaz_ConstantValues.bgchoice == 1) {
            eaz_EditActivity.backgroundlayout.getBackground().setAlpha(i);
        }
        if (eaz_ConstantValues.bgchoice == 2) {
            eaz_EditActivity.foregroundlayout.getBackground().setAlpha(i);
        }
    }
}
