package com.example.lyricsvideo.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lyricsvideo.Fragment.VideoFragment;
import com.example.lyricsvideo.Model.LyricCategory;
import com.example.lyricsvideo.R;
import com.example.lyricsvideo.Utils.AppFont;
import com.example.lyricsvideo.Utils.Utils;
import com.example.lyricsvideo.application.App;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdsManager;
import com.facebook.ads.NativeBannerAd;
import com.facebook.ads.NativeBannerAdView;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    public static final String[] NECESSARY_PERMISSIONS = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",};
    public static com.github.hiteshsondhi88.libffmpeg.FFmpeg ffmpeg;
    public static RelativeLayout rlBottom;
    private static SharedPreferences permissionStatus;
    public boolean sentToSettings = false;
    public Activity activity;
    public ActionBarDrawerToggle mDrawerToggle;
    public String ThemeDownloadUrl = "";
    public String ThemeVideoShareUrl = "";
    public String ThemeVideoViewUrl = "";
    public String AllCategoryUrl = "";
    public String CategoryDataUrl = "";
    public NativeAdsManager mAdsManager;
    public int id;
    ThemeViewPagerAdapter ThemePageradapter;
    ArrayList<LyricCategory> tabcategorylist = new ArrayList<>();
    LinearLayout llThemeLoading, llInternetCheck;
    AVLoadingIndicatorView avLoading;
    ImageView ivcontenthamburger;
    String offlienResopnseData;
    SharedPreferences ThemeCategoryPreference, ePreferences;
    String MY_PREF = "Cat_home_preference";
    String AppId = "13";
    String Version;
    App application;
    int SelectedPosition = 0;
    InterstitialAd mInterstitialAd;
    private int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private int REQUEST_PERMISSION_SETTING = 101;
    private DrawerLayout mDrawerLayout;
    private TextView tvAppName, tvMyTemplate, tvMyCreation, tvVersion;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private boolean IsofflineResopnse = false;

    public MainActivity() {
        activity = this;
    }

    public void RequiredPermission(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        RuntimePremission();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Allow Permission");
        builder.setMessage(alertmessage)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    public void RuntimePremission() {
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("Need Storage Permission");
                builder.setMessage("This app needs storage permission.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else if (permissionStatus.getBoolean(Manifest.permission.WRITE_EXTERNAL_STORAGE, false)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("Need Storage Permission");
                builder.setMessage("Lyrical videos needs storage permission.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        sentToSettings = true;
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
                        intent.setData(uri);
                        activity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else {
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
            }
            SharedPreferences.Editor editor = permissionStatus.edit();
            editor.putBoolean(Manifest.permission.WRITE_EXTERNAL_STORAGE, true);
            editor.apply();
        } else {
            CreateDirectory();
            loadFFMpegBinary();
            Log.e("Permission", "You already have the permission, just go ahead.");
        }
    }

    private void CreateDirectory() {
        try {
            String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Lyrics Video/";
            File root = new File(rootPath);
            if (!root.exists()) {
                root.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        permissionStatus = getSharedPreferences("permissionStatus", MODE_PRIVATE);
        ThemeCategoryPreference = getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        ePreferences = getSharedPreferences("dialog_preferances", Context.MODE_PRIVATE);
        application = App.getInstance();
        AllCategoryUrl = getIntent().getStringExtra("CategoryUrl");
        CategoryDataUrl = getIntent().getStringExtra("CategoryDataUrl");
        ThemeDownloadUrl = getIntent().getStringExtra("DownloadUrl");
        ThemeVideoShareUrl = getIntent().getStringExtra("VideoShareUrl");
        ThemeVideoViewUrl = getIntent().getStringExtra("VideoViewUrl");
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle1 = new Bundle();
        bundle1.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "MainActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle1);
        ffmpeg = com.github.hiteshsondhi88.libffmpeg.FFmpeg.getInstance(this.getApplicationContext());
        loadFFMpegBinary();
        GetAppVersion();
        BindView();
        GetThemeUrl();
        initNativeAds();
        InterstitialAd();
        if (ThemeCategoryPreference.getBoolean("themecatfirsttime", true)) {
            if (Utils.CheckIntrenetConnectivity(activity, false)) {
                ThemeCategoryPreference.edit().putBoolean("themecatfirsttime", false).apply();
                new GetTabThemeCategory().execute(AllCategoryUrl, AppId);
            } else {
                llInternetCheck.setVisibility(View.VISIBLE);
                Toast.makeText(activity, "No Internet Connecation !", Toast.LENGTH_LONG).show();
            }
        } else {
            if (Utils.CheckIntrenetConnectivity(activity, false)) {
                new GetTabThemeCategory().execute(AllCategoryUrl, AppId);
            } else {
                IsofflineResopnse = true;
                new GetTabThemeCategory().execute(AllCategoryUrl, AppId);
            }
        }

        AppFont.Textfont(this, tvAppName);
        AppFont.Textfont(this, tvMyCreation);
        AppFont.Textfont(this, tvMyTemplate);
        RuntimePremission();
    }

    private void loadFFMpegBinary() {
        final File f = new File(Utils.CommanPath);
        if (!f.exists()) {
            f.mkdirs();
        }
        try {
            ffmpeg.loadBinary(new LoadBinaryResponseHandler() {
                @Override
                public void onFailure() {
                }

                @Override
                public void onSuccess() {
                    super.onSuccess();
                }
            });
        } catch (FFmpegNotSupportedException ex) {
            ex.printStackTrace();
        }
    }

    public void initNativeAds() {
        mAdsManager = new NativeAdsManager(activity, getResources().getString(R.string.FB_NATIVE_AD_ID), 5);
        mAdsManager.loadAds();
        mAdsManager.setListener(new NativeAdsManager.Listener() {
            @Override
            public void onAdsLoaded() {
                Log.e("FBAds", "Native Ad Load");
                application.IsNativeAdsLoaded = true;
            }

            @Override
            public void onAdError(AdError adError) {
                Log.e("FBAds", "Native Ad Not Load : " + adError.getErrorMessage());

            }
        });
    }

    private void InterstitialAd() {
        mInterstitialAd = new InterstitialAd(this, getString(R.string.FB_inter));
        mInterstitialAd.setAdListener(new InterstitialAdListener() {

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                switch (id) {
                    case 100:
                        GoToMyTemplate();
                        break;
                    case 101:
                        GoToMyCreation();
                        break;
                }
            }
        });
        mInterstitialAd.loadAd();
    }

    private void BindView() {
        ivcontenthamburger = findViewById(R.id.content_hamburger);
        tvAppName = findViewById(R.id.tv_app_name);
        tvVersion = findViewById(R.id.tv_version);
        tvMyCreation = findViewById(R.id.tvMycreation);
        tvMyTemplate = findViewById(R.id.tv_Mytemplate);
        llThemeLoading = findViewById(R.id.ll_pdialog);
        llInternetCheck = findViewById(R.id.ll_internet);
        avLoading = findViewById(R.id.avloadingview);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        rlBottom = findViewById(R.id.rl_bottom_main);
        NavigationView navigationView = findViewById(R.id.nav_view);
        tvVersion.setText("Version " + Version);
        ivcontenthamburger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });
        tvMyTemplate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    id = 100;
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    GoToMyTemplate();
                }

            }
        });
        tvMyCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    id = 101;
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    GoToMyCreation();
                }

            }
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
    }

    private void GoToMyCreation() {
        startActivity(new Intent(activity, MyCreationActivity.class));
        finish();
    }

    private void GoToMyTemplate() {
        startActivity(new Intent(activity, MyTemplateActivity.class));
        finish();
    }

    public void GetThemeUrl() {
        if (ThemeCategoryPreference.getString("Themecat", "Themecatfirsttime").equals("Themecatfirsttime")) {
            SharedPreferences.Editor edit = ThemeCategoryPreference.edit();
            edit.putString("Themecat", "ok");
            edit.putString("caturl", AllCategoryUrl);
            edit.putString("CatDetailUrl", CategoryDataUrl);
            edit.putString("DownloadUrl", ThemeDownloadUrl);
            edit.putString("ViewUrl", ThemeVideoViewUrl);
            edit.putString("ShareUrl", ThemeVideoShareUrl);
            edit.apply();
        } else if (ThemeCategoryPreference.getString("Themecat", null).equals("ok")) {
            AllCategoryUrl = (ThemeCategoryPreference.getString("caturl", ""));
            CategoryDataUrl = (ThemeCategoryPreference.getString("CatDetailUrl", ""));
            ThemeDownloadUrl = (ThemeCategoryPreference.getString("DownloadUrl", ""));
            ThemeVideoViewUrl = (ThemeCategoryPreference.getString("ViewUrl", ""));
            ThemeVideoShareUrl = (ThemeCategoryPreference.getString("ShareUrl", ""));
        }
    }

    private void GetAppVersion() {
        PackageManager manager = activity.getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            Version = info.versionName;
        }
    }

    private void displaySelectedScreen(int itemId) {
        switch (itemId) {
            case R.id.nav_mycreation:
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    id=101;
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    GoToMyCreation();
                }
                break;
            case R.id.nav_mytemplates:
                if (mInterstitialAd != null && mInterstitialAd.isAdLoaded()) {
                    id=100;
                    App.ShowDialog(activity);
                    mInterstitialAd.show();
                } else {
                    GoToMyTemplate();
                }
                break;
            case R.id.nav_share:
                ShareAPP();
                break;
            case R.id.nav_rateus:
                RateApp();
                break;
            case R.id.nav_privacy_policy:
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
                break;
            case R.id.nav_feedback:
                Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
                intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
                intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
                startActivity(Intent.createChooser(intent2, "Send email..."));
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        displaySelectedScreen(item.getItemId());
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void SetTabLayout() {
        int CatItemPosition;
        viewPager = findViewById(R.id.vpTheme);
        tabLayout = findViewById(R.id.tab_theme);
        ThemePageradapter = new ThemeViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(ThemePageradapter);
        if (App.CatSelectedPosition != -1) {
            CatItemPosition = App.CatSelectedPosition;
        } else {
            CatItemPosition = 0;
        }
        Log.e("TAG", "ViewPager" + CatItemPosition);
        viewPager.setCurrentItem(CatItemPosition);
        tabLayout.setupWithViewPager(viewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(ThemePageradapter.getTabView(i));
            View customView = tab.getCustomView();
            final Typeface typeFacecategory = Typeface.createFromAsset(getAssets(), "fonts/biko_regular.otf");
            ((TextView) customView.findViewById(R.id.ThemeTab)).setTypeface(typeFacecategory);
            if (tab.getPosition() == 0) {
                customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
            }
        }
        tabLayout.getTabAt(0).getCustomView().setSelected(true);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
                SelectedPosition = tab.getPosition();
                App.CatSelectedPosition = SelectedPosition;
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
            }

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    View customView = tab.getCustomView();
                    ((TextView) customView.findViewById(R.id.ThemeTab)).setTextColor(getResources().getColor(R.color.white));
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                CreateDirectory();
                loadFFMpegBinary();
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                    builder.setTitle("Need Storage Permission");
                    builder.setMessage("Lyrics Videos needs storage permission");
                    builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.show();
                } else {
                    Toast.makeText(getBaseContext(), "Unable to get Permission", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                CreateDirectory();
                loadFFMpegBinary();
            }
        }
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "LyricalVideos");
            String shareMessage = "\nGet free LyricalVideos at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void SetOfflineCategory(Context c, String userObject, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.apply();
    }

    public void getOfflineCategory(Context ctx, String key) {
        SharedPreferences pref = PreferenceManager
                .getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
    }


    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
//            IsFinish(getString(R.string.exitmessage));
            RateDialog();
        }
    }

    public void IsFinish(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AppDialog);
        builder.setTitle(R.string.exit);
        builder.setMessage(alertmessage)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    @SuppressLint("ClickableViewAccessibility")
    public void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(MainActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseBackDialogAnimation);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        final NativeBannerAd mNativeBannerAd;
        mNativeBannerAd = new NativeBannerAd(this, getString(R.string.FB_nativebanner));
        mNativeBannerAd.setAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
            }

            @Override
            public void onError(Ad ad, AdError adError) {
            }

            @Override
            public void onAdLoaded(Ad ad) {
                dialog.findViewById(R.id.tvLoadingads).setVisibility(View.GONE);
                View adView = NativeBannerAdView.render(MainActivity.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                LinearLayout nativeBannerAdContainer = dialog.findViewById(R.id.banner_container);
                nativeBannerAdContainer.addView(adView);
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });
        mNativeBannerAd.loadAd();
        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    final SharedPreferences.Editor edit = ePreferences.edit();
                    edit.putBoolean("pref_key_rate", true);
                    edit.apply();
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public class ThemeViewPagerAdapter extends FragmentPagerAdapter {

        public ThemeViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return VideoFragment.getInstance(CategoryDataUrl, Integer.parseInt(tabcategorylist.get(position).getTabcategoryid()));
        }

        @Override
        public int getCount() {
            return tabcategorylist.size();
        }

        public View getTabView(int position) {
            View tab = LayoutInflater.from(getApplicationContext()).inflate(
                    R.layout.custom_tab, null);
            TextView tv = tab.findViewById(R.id.ThemeTab);
            tv.setText(tabcategorylist.get(position).getName());
            return tab;
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class GetTabThemeCategory extends AsyncTask<String, Void, String> {

        protected void onPreExecute() {
            llThemeLoading.setVisibility(View.VISIBLE);
            avLoading.smoothToShow();
        }

        protected String doInBackground(String... arg0) {
            try {
                URL url = new URL(arg0[0]);
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("app_id", arg0[1]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(Utils.INSTANCE.getPostDataString(postDataParams));
                writer.flush();
                writer.close();
                os.close();
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuffer sb = new StringBuffer();
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonObj;
                    if (IsofflineResopnse) {
                        getOfflineCategory(activity, "ThemeCategory");
                        jsonObj = new JSONObject(offlienResopnseData);
                    } else {
                        if (App.IsFromHomeUnity) {
                            jsonObj = new JSONObject(result);
                            SetOfflineCategory(activity, jsonObj.toString(), "ThemeCategory");
                            App.IsFromHomeUnity = false;
                        } else {
                            getOfflineCategory(activity, "ThemeCategory");
                            jsonObj = new JSONObject(offlienResopnseData);
                        }
                    }
                    JSONArray tabcategory = jsonObj.getJSONArray("data");
                    for (int i = 0; i < tabcategory.length(); i++) {
                        JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                        LyricCategory tabCategoryModel = new LyricCategory();
                        tabCategoryModel.setTabcategoryid(tabcategoryJSONObject.getString("main_id"));
                        tabCategoryModel.setName(tabcategoryJSONObject.getString("main_category_name"));
                        tabcategorylist.add(tabCategoryModel);
                    }
                    SetTabLayout();
                    llThemeLoading.setVisibility(View.GONE);
                    avLoading.smoothToHide();
                } catch (final JSONException e) {
                    e.printStackTrace();
                }
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }

}
