package com.esc.howtomakeschoolsupplies.activity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.esc.howtomakeschoolsupplies.R;
import com.esc.howtomakeschoolsupplies.fragment.BeginFragment;
import com.esc.howtomakeschoolsupplies.fragment.CategoryFragment;
import com.esc.howtomakeschoolsupplies.fragment.ContentFragment;
import com.esc.howtomakeschoolsupplies.fragment.ListFragment;
import com.esc.howtomakeschoolsupplies.pref.EPreferences;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import com.esc.howtomakeschoolsupplies.fragment.BeginFragment.EventBeginFragment;
import com.esc.howtomakeschoolsupplies.adapter.CategoryAdapter.EventCategoryFragment;
import com.esc.howtomakeschoolsupplies.fragment.CategoryFragment.EventUpdateCategory;
import com.esc.howtomakeschoolsupplies.adapter.ListAdapter.EventListFragment;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer.LoadingArticles;
import com.esc.howtomakeschoolsupplies.network.ConnectToServer.LoadingCategory;
import com.esc.howtomakeschoolsupplies.network.ConnectionStateMonitor;
import com.esc.howtomakeschoolsupplies.network.ConnectionStateMonitor.ConnectionMonitor;
import com.esc.howtomakeschoolsupplies.network.NetworkStateReceiver;
import com.esc.howtomakeschoolsupplies.network.NetworkStateReceiver.NetworkStateReceiverListener;
import com.esc.howtomakeschoolsupplies.pojo.Article;
import com.esc.howtomakeschoolsupplies.pojo.Category;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

public class MainActivity extends AppCompatActivity implements EventBeginFragment, EventCategoryFragment, EventListFragment, LoadingCategory, LoadingArticles, EventUpdateCategory, NetworkStateReceiverListener, ConnectionMonitor {
    public static final Companion Companion = new Companion();
    private static boolean isEnabledInternet;
    private HashMap findViewCache;
    private boolean isCategoryLoaded;
    public List<Article> mArticles;
    private List<Category> mCategories;
    private NetworkStateReceiver networkStateReceiver;
    private SharedPreferences pref;
    private EPreferences ePreferences;

    public static final class Companion {
        private Companion() {
        }

        public final boolean isEnabledInternet() {
            return MainActivity.isEnabledInternet;
        }
    }

    public View findCachedViewById(int i) {
        if (this.findViewCache == null) {
            this.findViewCache = new HashMap();
        }
        View view = (View) this.findViewCache.get(Integer.valueOf(i));
        if (view != null) {
            return view;
        }
        view = findViewById(i);
        this.findViewCache.put(Integer.valueOf(i), view);
        return view;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        connectMonitor();
        ePreferences = EPreferences.getInstance(this);
        SharedPreferences sharedPreferences = getSharedPreferences(Constants.APP_PREFERENCES, 0);
        Intrinsics.checkExpressionValueIsNotNull(sharedPreferences, "getSharedPreferences(Con…ES, Context.MODE_PRIVATE)");
        this.pref = sharedPreferences;
        ConstraintLayout constraintLayout = (ConstraintLayout) findCachedViewById(R.id.container);
        Intrinsics.checkExpressionValueIsNotNull(constraintLayout, "container");
        ProgressBar progressBar = (ProgressBar) findCachedViewById(R.id.progressBar);
        Intrinsics.checkExpressionValueIsNotNull(progressBar, "progressBar");
        progressBar.setVisibility(View.VISIBLE);
    }

    public void onClickBtnBegin() {
        if (this.mCategories != null) {
            CategoryFragment.Companion companion = CategoryFragment.Companion;
            List list = this.mCategories;
            if (list == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mCategories");
            }
            replaceFragment(companion.newInstance(new ArrayList(list),"Category"));
            return;
        }
        new ConnectToServer().connectCategory(this);
        new ConnectToServer().connectArticle(this);
    }

    public void onClickBtnCategory(int i) {
        if (this.mArticles != null) {
            ListFragment.Companion companion = ListFragment.Companion;
            List list = this.mArticles;
            if (list == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mArticles");
            }
            replaceFragment(companion.newInstance(new ArrayList(list), i,"Category List"));
            return;
        }
        new ConnectToServer().connectArticle(this);
    }

    public void onClickBtnArticle(int i) {
        replaceFragment(ContentFragment.Companion.newInstance(i));
    }

    public void onClickBtnFavorite() {
        if (this.mArticles != null) {
            ListFragment.Companion companion = ListFragment.Companion;
            List list = this.mArticles;
            if (list == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mArticles");
            }
            replaceFragment(companion.newInstance(new ArrayList(list), -1, "Favourite"));
            return;
        }
        new ConnectToServer().connectArticle(this);
    }

    public void initCategory(List<Category> list) {
        Intrinsics.checkParameterIsNotNull(list, "categories");
        this.mCategories = list;
        this.isCategoryLoaded = true;
        isLoadedFinish();
    }

    public void initArticles(List<Article> list) {
        Intrinsics.checkParameterIsNotNull(list, "articles");
        this.mArticles = list;
        isLoadedFinish();
    }

    private final void checkNewArticlesInCategory() {
        boolean z;
        SharedPreferences sharedPreferences = this.pref;
        String str = "pref";
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException(str);
        }
        String str2 = Constants.APP_PREFERENCES_NEW_ARTICLES_CATEGORY;
        String str3 = "mArticles";
        if (sharedPreferences.contains(str2)) {
            sharedPreferences = this.pref;
            if (sharedPreferences == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            String string = sharedPreferences.getString(str2, new String());
            if (string == null) {
                Intrinsics.throwNpe();
            }
            Collection arrayList = new ArrayList();
            for (Object next : StringsKt.split((CharSequence) string, new String[]{","}, false, 0)) {
                if ((((CharSequence) ((String) next)).length() > 0 ? 1 : null) != null) {
                    arrayList.add(next);
                }
            }
            List<String> list = (List) arrayList;
            if (this.mArticles != null) {
                List<Article> list2 = this.mArticles;
                if (list2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str3);
                }
                for (Article article : list2) {
                    boolean obj;
                    for (String parseInt : list) {
                        if (article.getId() == Integer.parseInt(parseInt)) {
                            obj = true;
                        }
                    }
                    obj = false;
                    if (obj) {
                        article.setOldArticleInCategory(true);
                    }
                }
            }
        }
        MainActivity mainActivity = this;
        if (mainActivity.mCategories != null && mainActivity.mArticles != null) {
            List<Category> list3 = this.mCategories;
            str = "mCategories";
            if (list3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            for (Category newArticleSize : list3) {
                newArticleSize.setNewArticleSize(0);
            }
            List<Category> list4 = this.mCategories;
            if (list4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            for (Category category : list4) {
                List<Article> list5 = this.mArticles;
                if (list5 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException(str3);
                }
                for (Article article2 : list5) {
                    int id = category.getId();
                    Category category2 = article2.getCategory();
                    if (category2 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (id == category2.getId() && !article2.isOldArticleInCategory()) {
                        category.setNewArticleSize(category.getNewArticleSize() + 1);
                    }
                }
            }
        }
    }

    private final void replaceFragment(Fragment fragment) {
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        Intrinsics.checkExpressionValueIsNotNull(beginTransaction, "supportFragmentManager.beginTransaction()");
        beginTransaction.replace(R.id.container, fragment);
        beginTransaction.addToBackStack(null);
        beginTransaction.commit();
    }

    private final void connectMonitor() {
        if (VERSION.SDK_INT >= 21) {
            new ConnectionStateMonitor().enable(this);
            return;
        }
        NetworkStateReceiver networkStateReceiver = new NetworkStateReceiver();
        this.networkStateReceiver = networkStateReceiver;
        if (networkStateReceiver == null) {
            Intrinsics.throwNpe();
        }
        networkStateReceiver.addListener(this);
        registerReceiver(this.networkStateReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    public void updateCategory() {
        checkNewArticlesInCategory();
    }

    public void networkAvailable() {
        isEnabledInternet = true;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView textView = (TextView) findCachedViewById(R.id.torn_internet);
                Intrinsics.checkExpressionValueIsNotNull(textView, "torn_internet");
                textView.setText(getString(R.string.loading));
            }
        });
        initData();
    }

    public void networkUnavailable() {
        isEnabledInternet = false;
    }

    public void enabledConnectMonitor() {
        isEnabledInternet = true;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView textView = (TextView) findCachedViewById(R.id.torn_internet);
                Intrinsics.checkExpressionValueIsNotNull(textView, "torn_internet");
                textView.setText(getString(R.string.loading));
            }
        });
        initData();
    }

    public void disabledConnectMonitor() {
        isEnabledInternet = false;
    }

    private final void initData() {

        MainActivity mainActivity = this;
        if (mainActivity.mCategories == null) {
            new ConnectToServer().connectCategory(this);
        }
        if (mainActivity.mArticles == null) {
            new ConnectToServer().connectArticle(this);
        }
    }

    public final void isLoadedFinish() {
        if (this.mArticles != null && this.isCategoryLoaded) {

            checkNewArticlesInCategory();
            if (getSupportFragmentManager().findFragmentById(R.id.container) == null) {
                FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
                Intrinsics.checkExpressionValueIsNotNull(beginTransaction, "supportFragmentManager.beginTransaction()");
                beginTransaction.add(R.id.container, (Fragment) new BeginFragment());
                beginTransaction.addToBackStack((String) null);
                beginTransaction.commitAllowingStateLoss();
            }
            ProgressBar progressBar = (ProgressBar) findCachedViewById(R.id.progressBar);
            Intrinsics.checkExpressionValueIsNotNull(progressBar, "progressBar");
            progressBar.setVisibility(View.INVISIBLE);
            TextView textView = (TextView) findCachedViewById(R.id.torn_internet);
            Intrinsics.checkExpressionValueIsNotNull(textView, "torn_internet");
            textView.setVisibility(View.INVISIBLE);
        }
    }

    private UnifiedNativeAd nativeAd;

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = dialog.findViewById(R.id.ivStar1);
        ivStar2 = dialog.findViewById(R.id.ivStar2);
        ivStar3 = dialog.findViewById(R.id.ivStar3);
        ivStar4 = dialog.findViewById(R.id.ivStar4);
        ivStar5 = dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finishAffinity();
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        ePreferences.putBoolean("pref_key_rate", true);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    finishAffinity();
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!dialog.isShowing() && !isFinishing()) {
            dialog.show();
        }
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btncancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnyes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
        dialog.show();
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void onBackPressed() {
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        Intrinsics.checkExpressionValueIsNotNull(supportFragmentManager, "supportFragmentManager");
        if (supportFragmentManager.getBackStackEntryCount() > 1) {
            supportFragmentManager.popBackStack();
        } else if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void onDestroy() {
        super.onDestroy();
        NetworkStateReceiver networkStateReceiver = this.networkStateReceiver;
        if (networkStateReceiver != null) {
            if (networkStateReceiver == null) {
                Intrinsics.throwNpe();
            }
            networkStateReceiver.removeListener(this);
            unregisterReceiver(this.networkStateReceiver);
        }
    }
}
