package com.kotlinz.festivalstorymaker.Model.CollageMaker.Background;

import com.google.gson.annotations.SerializedName;

public class BackgroundImagesItem{

	@SerializedName("background_category_name")
	private String backgroundCategoryName;

	@SerializedName("theme_thumbnail")
	private String themeThumbnail;

	@SerializedName("updated_at")
	private String updatedAt;

	@SerializedName("is_pro")
	private String isPro;

	@SerializedName("theme_id")
	private int themeId;

	@SerializedName("created_at")
	private String createdAt;

	@SerializedName("module_name")
	private String moduleName;

	@SerializedName("application_id")
	private String applicationId;

	public String getBackgroundCategoryName(){
		return backgroundCategoryName;
	}

	public String getThemeThumbnail(){
		return themeThumbnail;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getIsPro(){
		return isPro;
	}

	public int getThemeId(){
		return themeId;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getModuleName(){
		return moduleName;
	}

	public String getApplicationId(){
		return applicationId;
	}
}