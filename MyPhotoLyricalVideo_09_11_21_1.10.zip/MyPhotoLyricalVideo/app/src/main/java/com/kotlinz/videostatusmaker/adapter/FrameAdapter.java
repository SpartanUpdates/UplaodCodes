package com.kotlinz.videostatusmaker.adapter;

import android.content.Context;
import android.net.Uri;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import com.bumptech.glide.Glide;
import com.kotlinz.videostatusmaker.Activity.ActivityEditImage;
import com.kotlinz.videostatusmaker.R;
import com.kotlinz.videostatusmaker.Utils.RoundedImageView;

public class FrameAdapter extends Adapter<FrameAdapter.MyViewHolder> {
    String[] StrArray_effect;
    Context context;

    public static class MyViewHolder extends ViewHolder {
        public RoundedImageView roundedImageView;

        public MyViewHolder(View view) {
            super(view);
            this.roundedImageView = (RoundedImageView) view.findViewById(R.id.img);
        }
    }

    public FrameAdapter(Context context, String[] strArr) {
        this.context = context;
        this.StrArray_effect = strArr;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frame_adapter, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("file:///android_asset/image_frame/");
        stringBuilder.append(this.StrArray_effect[i]);
        Log.e("FRAME====", "" + stringBuilder.toString());
        Glide.with(this.context).load(Uri.parse(stringBuilder.toString())).into(myViewHolder.roundedImageView);
        myViewHolder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ((ActivityEditImage) FrameAdapter.this.context).setFrame(i);
            }
        });
        myViewHolder.roundedImageView.setCornerRadius((float) ((this.context.getResources().getDisplayMetrics().widthPixels * 10) / 1080));
    }

    public int getItemCount() {
        return this.StrArray_effect.length;
    }
}