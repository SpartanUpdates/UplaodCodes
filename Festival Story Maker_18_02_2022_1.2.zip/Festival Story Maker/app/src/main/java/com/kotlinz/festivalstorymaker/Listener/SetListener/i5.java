package com.kotlinz.festivalstorymaker.Listener.SetListener;

import android.content.Context;
import android.os.Handler;
import android.view.View;

import com.kotlinz.festivalstorymaker.Utils.MagnifierView;
import com.kotlinz.festivalstorymaker.activity.FrameEditorNewDesign;

public class i5 implements View.OnClickListener
{
    public final FrameEditorNewDesign e;

    public i5(final FrameEditorNewDesign e) {
        this.e = e;
    }

    public void onClick(final View view) {
        this.e.u0();
        this.e.rlFull.setVisibility(0);
        new Handler().postDelayed((Runnable)new Runnable() {
            @Override
            public void run() {
                final MagnifierView.b b = new MagnifierView.b((Context)i5.this.e, FrameEditorNewDesign.u1);
                b.c((int)FrameEditorNewDesign.A1 / 2 - 60, (int)FrameEditorNewDesign.B1 / 2 - 60);
                b.d = 250;
                b.e = 250;
                b.f = 4.0f;
                b.g = 4.0f;
                b.a(16);
                b.h = 17170445;
                (FrameEditorNewDesign.X1 = b.b()).setListner(FrameEditorNewDesign.W1);
                FrameEditorNewDesign.X1.a();
            }
        }, 600L);
    }
}
