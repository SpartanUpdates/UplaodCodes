package com.esc.gesturelockscreen.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.PointerIconCompat;
import com.bumptech.glide.Glide;
import com.esc.gesturelockscreen.Other.BitmapUtils;
import com.esc.gesturelockscreen.Other.Constant;
import com.esc.gesturelockscreen.Other.PrefUtils;
import com.esc.gesturelockscreen.Other.StaticBitmapUtils;
import com.esc.gesturelockscreen.R;
import com.esc.gesturelockscreen.imagecropper.BitmapImageCompression;
import com.esc.gesturelockscreen.imagecropper.CropImage;
import com.esc.gesturelockscreen.imagecropper.CropImageView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class SetWallpaperActivity extends AppCompatActivity implements OnClickListener {
    private Activity activity = SetWallpaperActivity.this;
    int Height;
    int Width;
    BitmapUtils bitmapUtils;
    ImageView btnback;
    GridView gvBackground;
    ImageView imgBg;
    ImageView imgSelectGallery;
    Activity mContext;
    private FrameLayout adContainerView;
    private AdView adView;
    private AdSize adSize;

    public class GridAdaptor extends BaseAdapter {
        Context c;
        Integer[] imageBackground;
        private LayoutInflater inflater = null;

        public long getItemId(int i) {
            return (long) i;
        }

        public GridAdaptor(Context context, Integer[] numArr) {
            this.imageBackground = numArr;
            this.c = context;
            this.inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        public int getCount() {
            return this.imageBackground.length;
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            ImageView imageView;
            if (view == null) {
                imageView = new ImageView(SetWallpaperActivity.this.getApplicationContext());
                imageView.setLayoutParams(new LayoutParams(-1, SetWallpaperActivity.this.Height / 2));
                imageView.setScaleType(ScaleType.FIT_XY);
                imageView.setPadding(2, 2, 2, 2);
            } else {
                imageView = (ImageView) view;
            }
            Glide.with(SetWallpaperActivity.this.mContext).load(Integer.valueOf(this.imageBackground[i].intValue())).into(imageView);
            return imageView;
        }
    }

    public void getPreference() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_wallpaper_set);
        this.mContext = this;
        this.imgBg = (ImageView) findViewById(R.id.img_bg);
        this.bitmapUtils = new BitmapUtils(this);
        this.imgBg.setImageBitmap(this.bitmapUtils.getBackgroundBitmap());
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.Width = displayMetrics.widthPixels;
        this.Height = displayMetrics.heightPixels;
        findID();
        BannerAds();
        this.mContext = this;

        this.gvBackground.setAdapter(new GridAdaptor(getApplicationContext(), Constant.arrThumb));
        this.gvBackground.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    PrefUtils.setBooleanPref(SetWallpaperActivity.this.getApplicationContext(), PrefUtils.PRF_IS_SET_BACKGROUND, true);
                    PrefUtils.setIntPref(SetWallpaperActivity.this.getApplicationContext(), PrefUtils.PRF_BACKGROUND_IMG_POSITION, i);
                    PrefUtils.setBooleanPref(SetWallpaperActivity.this.getApplicationContext(), PrefUtils.PRF_IS_SET_GALLERY, false);
                    SetWallpaperActivity.this.startActivity(new Intent(SetWallpaperActivity.this.getApplicationContext(), SlideLockWithFrameSetActivity.class));
                    SetWallpaperActivity.this.finish();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void findID() {
        this.btnback = (ImageView) findViewById(R.id.btn_back);
        this.imgSelectGallery = (ImageView) findViewById(R.id.img_select_gallery);
        this.gvBackground = (GridView) findViewById(R.id.gvBackground);
        this.imgSelectGallery.setOnClickListener(this);
        this.btnback.setOnClickListener(this);
        getPreference();
    }

    public void init() {
        getPreference();
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_back) {
            finish();
        } else if (id == R.id.img_select_gallery) {
            startGallery();
        }
    }

    private void startGallery() {
        try {
            Intent intent = new Intent("android.intent.action.PICK", Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            startActivityForResult(intent, PointerIconCompat.TYPE_HAND);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(int i, int i2, Intent intent)
    {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1 && i == PointerIconCompat.TYPE_HAND) {
            try {
                passCropImageUri(intent.getData());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (i == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult activityResult = CropImage.getActivityResult(intent);
            if (i2 == -1) {
                try {
                    String compressImage = BitmapImageCompression.compressImage(getApplicationContext(), activityResult.getUri().getPath());
                    PrefUtils.setStringPref(getApplicationContext(), PrefUtils.PRF_SELECTED_GALLERY_IMG_URI, compressImage);
                    StaticBitmapUtils.decodeFileFromUriToBitmap(Uri.parse(compressImage));
                    PrefUtils.setBooleanPref(getBaseContext(), PrefUtils.PRF_IS_SET_GALLERY, true);
                    PrefUtils.setBooleanPref(getBaseContext(), PrefUtils.PRF_IS_SET_BACKGROUND, false);
                    startActivity(new Intent(getApplicationContext(), SlideLockWithFrameSetActivity.class));
                    finish();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            } else if (i2 == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Toast makeText = Toast.makeText(this, "Something Went Wrong", Toast.LENGTH_LONG);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            }
        }
    }

    private void passCropImageUri(Uri uri) {
        CropImage.activity(uri).setGuidelines(CropImageView.Guidelines.ON).setMultiTouchEnabled(false).setAspectRatio(9, 16).setFixAspectRatio(true).start(this);
    }

    private void BannerAds() {
        try {
            adContainerView = findViewById(R.id.banner_ad_view_container);
            Display defaultDisplay = getWindowManager().getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            defaultDisplay.getMetrics(displayMetrics);
            float f = displayMetrics.density;
            float width = (float) adContainerView.getWidth();
            if (width == 0.0f) {
                width = (float) displayMetrics.widthPixels;
            }
            adSize = AdSize.getPortraitAnchoredAdaptiveBannerAdSize(this, (int) (width / f));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) adContainerView.getLayoutParams();
            layoutParams.height = adSize.getHeightInPixels(this);
            adContainerView.setLayoutParams(layoutParams);
            adContainerView.post(new Runnable() {
                public final void run() {
                    ShowAds();
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private void ShowAds() {
        try {
            adView = new AdView(activity);
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                }
            });
            adView.setAdUnitId(getString(R.string.AdMob_AdaptivBanner));
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            adView.setAdSize(adSize);
            adView.loadAd(new AdRequest.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void onResume() {
        super.onResume();
        init();
    }
}
