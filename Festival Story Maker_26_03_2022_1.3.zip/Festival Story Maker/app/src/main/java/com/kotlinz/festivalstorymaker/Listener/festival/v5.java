package com.kotlinz.festivalstorymaker.Listener.festival;

import android.content.Context;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import com.kotlinz.festivalstorymaker.Other.Utils;
import com.kotlinz.festivalstorymaker.R;
import com.kotlinz.festivalstorymaker.activity.FestivalDetailActivity_New;

public class v5 implements TextView.OnEditorActionListener
{
    public final  EditText n;
    public final  EditText o;
    public final  EditText p;
    public final  EditText q;
    public final  EditText r;
    public final  FestivalDetailActivity_New s;

    public v5(final FestivalDetailActivity_New s, final EditText n, final EditText o, final EditText p6, final EditText q, final EditText r) {
        this.s = s;
        this.n = n;
        this.o = o;
        this.p = p6;
        this.q = q;
        this.r = r;
    }

    public boolean onEditorAction(final TextView textView, final int n, final KeyEvent keyEvent) {
        if (n == 6) {
            Utils.L((Context)this.s, this.n);
            EditText editText = null;
            String error = null;
            Label_0145: {
                if (Utils.p0(this.o) <= 0) {
                    editText = this.o;
                }
                else if (Utils.p0(this.n) <= 0) {
                    editText = this.n;
                }
                else if (Utils.p0(this.p) <= 0) {
                    editText = this.p;
                }
                else {
                    if (!Utils.l0(this.p)) {
                        editText = this.p;
                        error = this.s.getResources().getString(R.string.enter_valid_email);
                        break Label_0145;
                    }
                    if (Utils.p0(this.q) <= 0) {
                        editText = this.q;
                    }
                    else {
                        if (Utils.p0(this.r) > 0) {
                            FestivalDetailActivity_New.y0(this.s, this.o.getText().toString(), this.n.getText().toString(), this.p.getText().toString(), this.q.getText().toString(), this.r.getText().toString());
                            return false;
                        }
                        editText = this.r;
                    }
                }
                error = editText.getHint().toString();
            }
            editText.setError((CharSequence)error);
        }
        return false;
    }
}
