package com.kotlinz.videoCollage.interfaces;

public interface PartyStickerAdapterCallBackInterface {
    void itemClick(int i);
}
