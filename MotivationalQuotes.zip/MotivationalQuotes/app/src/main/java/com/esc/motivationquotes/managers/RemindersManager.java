package com.esc.motivationquotes.managers;

import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class RemindersManager {
    private static final String REMINDERS_LAUNCHED_NUMBER = "reminders_launched_numbercom.esc.motivationquotes.motivation";

    public static int getRemindersLaunched() {
        return PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).getInt(REMINDERS_LAUNCHED_NUMBER, 0);
    }

    public static void resetRemindersLaunched() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).edit();
        edit.putInt(REMINDERS_LAUNCHED_NUMBER, 0);
        edit.commit();
    }

    public static void addRemindersLaunched() {
        Editor edit = PreferenceManager.getDefaultSharedPreferences(SettingsManager.getContext()).edit();
        edit.putInt(REMINDERS_LAUNCHED_NUMBER, getRemindersLaunched() + 1);
        edit.commit();
    }
}
