package com.esc.storymaker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.esc.storymaker.adapters.Stickeradapter;
import com.esc.storymaker.help.ConnectionDetector;
import com.esc.storymaker.help.Utils;
import com.esc.storymaker.models.Glob_Sticker;
import com.google.android.gms.ads.AdView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class StickerActivity extends AppCompatActivity {
    public static final String mypreference = "myprefadmob";
    private ImageView ImageOverlayadview;
    AppCompatActivity activity;
    LinearLayout adContainer;
    private AdView bannerAdView;
    private LinearLayout bannerContainer;
    ConnectionDetector connectionDetector;
    int displayad;
    GridView imggriddy;
    SharedPreferences sharedpreferences;
    String[] stickername;
    int whichAdFirst;


    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_sticker);
        this.sharedpreferences = getSharedPreferences("myprefadmob", 0);
        this.activity = this;
        this.connectionDetector = new ConnectionDetector(getApplicationContext());
        boolean isConnectingToInternet = this.connectionDetector.isConnectingToInternet();
        this.displayad = this.sharedpreferences.getInt("displayad", 3);
        this.whichAdFirst = this.sharedpreferences.getInt("whichAdFirst", 2);
        this.adContainer = (LinearLayout) findViewById(R.id.adView);
        this.bannerContainer = (LinearLayout) findViewById(R.id.banner_container);
        this.ImageOverlayadview = (ImageView) findViewById(R.id.Image_overlayadview);
        this.ImageOverlayadview.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {

            }
        });
        if (isConnectingToInternet) {
            int i = this.displayad;
            if (i == 1) {
                showHideG();
            } else if (i == 2) {
                showHideF();
            } else {
                showHideG();
                showHideF();
            }
        } else {
            findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }
        this.imggriddy = (GridView) findViewById(R.id.imggriddy);
        try {
            this.stickername = getImage("crown");
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.imggriddy.setAdapter(new Stickeradapter(getApplicationContext(), new ArrayList(Arrays.asList(this.stickername))));
        this.imggriddy.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Glob_Sticker.SelectedTattooName = StickerActivity.this.stickername[i];
                StickerActivity.this.setResult(-1);
                StickerActivity.this.finish();
            }
        });
    }

    private String[] getImage(String str) throws IOException {
        return getAssets().list(str);
    }


    public void showHideG() {
        /*if (new Utils(this.activity).bId() != null) {
            AdView adView = this.bannerAdView;
            if (adView != null) {
                adView.destroy();
                this.bannerAdView = null;
            }
            addBannerLoding();
            this.bannerContainer.setVisibility(8);
            this.adContainer.setVisibility(0);
            checkDisplayOverlayBannerG();
        } else if (new Utils(this.activity).fbadId() != null) {
            com.google.android.gms.ads.AdView adView2 = this.mAdView;
            if (adView2 != null) {
                adView2.destroy();
                this.mAdView = null;
            }
            addBannerLodingFB();
            this.adContainer.setVisibility(8);
            this.bannerContainer.setVisibility(0);
            checkDisplayOverlayBannerFB();
        } else {
            this.adContainer.setVisibility(8);
            this.bannerContainer.setVisibility(8);
            findViewById(R.id.adLAyout).setVisibility(8);
        }*/
    }


    public void checkDisplayOverlayBannerG() {
        if (new Utils(this.activity).checkTimeB()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void checkDisplayOverlayBannerFB() {
        if (new Utils(this.activity).checkTimeBf()) {
            this.ImageOverlayadview.setVisibility(View.GONE);
        } else {
            this.ImageOverlayadview.setVisibility(View.VISIBLE);
        }
    }


    public void showHideF() {
        /*if (new Utils(this.activity).fbbanneradId() != null) {
            com.google.android.gms.ads.AdView adView = this.mAdView;
            if (adView != null) {
                adView.destroy();
            }
            checkDisplayOverlayBannerFB();
            addBannerLodingFB();
            this.adContainer.setVisibility(View.GONE);
            this.bannerContainer.setVisibility(View.VISIBLE);
        } else if (new Utils(this.activity).bId() != null) {
            AdView adView2 = this.bannerAdView;
            if (adView2 != null) {
                adView2.destroy();
                this.bannerAdView = null;
            }
            checkDisplayOverlayBannerG();
            addBannerLoding();
            this.bannerContainer.setVisibility(View.GONE);
            this.adContainer.setVisibility(View.VISIBLE);
        } else {
            this.adContainer.setVisibility(View.GONE);
            this.bannerContainer.setVisibility(View.GONE);
            findViewById(R.id.adLAyout).setVisibility(View.GONE);
        }*/
    }

    private void addBannerLodingFB() {
        /*AdView adView = this.bannerAdView;
        if (adView != null) {
            adView.destroy();
            this.bannerAdView = null;
        }
        if (this.bannerContainer.getChildCount() > 0) {
            this.bannerContainer.removeAllViews();
        }
        Context context = this.activity;
        this.bannerAdView = new AdView(context, new Utils(context).fbbanneradId(), AdSize.BANNER_HEIGHT_50);
        AdSettings.addTestDevice("fa3be27b-20b9-4d8d-9bf1-c9724a55c6fb");
        this.bannerContainer.addView(this.bannerAdView);
        this.bannerAdView.setAdListener(new AdListener() {
            public void onLoggingImpression(Ad ad) {
            }

            public void onError(Ad ad, AdError adError) {
                StickerActivity.this.bannerAdView;
                StickerActivity.this.showHideG();
            }

            public void onAdLoaded(Ad ad) {
                StickerActivity.this.bannerAdView;
            }

            public void onAdClicked(Ad ad) {
                StickerActivity.this.ImageOverlayadview.setVisibility(0);
                new Utils(StickerActivity.this.activity).setLastTimeBf();
            }
        });
        this.bannerAdView.loadAd();*/
    }

    public void addBannerLoding() {
        /*if (this.adContainer.getChildCount() > 0) {
            this.adContainer.removeAllViews();
        }
        this.mAdView = new com.google.android.gms.ads.AdView(this.activity);
        this.mAdView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
        this.mAdView.setAdUnitId(new Utils(this.activity).bId());
        this.adContainer.addView(this.mAdView);
        this.mAdView.loadAd(new Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").addTestDevice("6EE36877D3E7CA526E12D0D16E87D51D").build());
        this.mAdView.setAdListener(new com.google.android.gms.ads.AdListener() {
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                StickerActivity.this.showHideF();
            }

            public void onAdClosed() {
                super.onAdClosed();
            }

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdLeftApplication() {
                super.onAdLeftApplication();
                StickerActivity.this.ImageOverlayadview.setVisibility(0);
                new Utils(StickerActivity.this.activity).setLastTimeB();
            }
        });*/
    }


   /* public void onDestroy() {
        super.onDestroy();
        AdView adView = this.bannerAdView;
        if (adView != null) {
            adView.destroy();
            this.bannerAdView = null;
        }
    }*/
}
