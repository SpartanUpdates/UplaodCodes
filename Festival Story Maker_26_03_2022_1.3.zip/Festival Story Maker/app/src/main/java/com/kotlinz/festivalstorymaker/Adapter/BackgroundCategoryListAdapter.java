package com.kotlinz.festivalstorymaker.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kotlinz.festivalstorymaker.Model.CollageMaker.Background.BackgroundMainResponse;
import com.kotlinz.festivalstorymaker.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BackgroundCategoryListAdapter extends RecyclerView.Adapter<BackgroundCategoryListAdapter.ViewHolder> {

    public a g;
    public Activity activity;
    public ArrayList<BackgroundMainResponse> backgroundCatList;
    public int SelectedPosition = 0;

    public BackgroundCategoryListAdapter(Activity activity, ArrayList<BackgroundMainResponse> arrayList, a aVar, int i) {
        this.g = aVar;
        this.activity = activity;
        this.backgroundCatList = arrayList;
        this.SelectedPosition = i;
    }

    public interface a {
        void a(int i);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_background_category_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.txt.setText(backgroundCatList.get(position).getBackgroundCategoryName());
        holder.txt.setTextColor(position == SelectedPosition ? activity.getResources().getColor(R.color.element_press) : activity.getResources().getColor(R.color.element_unpress));
        if (position == SelectedPosition) {
            holder.txt.setBackgroundColor(activity.getResources().getColor(R.color.element_round));
        } else {
            holder.txt.setBackgroundColor(activity.getResources().getColor(R.color.transparent));
        }
        holder.rlMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectedPosition = position;
                g.a(position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return backgroundCatList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.rlMain)
        public RelativeLayout rlMain;
        @BindView(R.id.txt)
        public TextView txt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
